"""Tests for Salesforce Report IR generation (Phase 2).

Tests the transformer, TransformResult, _persist() edge collection,
and factory registration.
"""
from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock

import pytest
from lineage.backends.lineage.models.report import (
    Report,
    ReportIR,
    ReportIRBucket,
    ReportIRCrossFilter,
    ReportIRFilter,
    ReportIRFormula,
    ReportIRGroupBy,
    ReportIRHighlight,
    ReportIRJoin,
)
from lineage.backends.types import NodeLabel
from lineage.ingest.static_loaders.reports.base import (
    _IR_CHILD_EDGE_MAP,
    BaseReportLoader,
    TransformResult,
)
from lineage.ingest.static_loaders.reports.salesforce.transformer import (
    SalesforceIRTransformer,
)

# =============================================================================
# Fixtures
# =============================================================================


def _base_report_data(**overrides: Any) -> dict[str, Any]:
    """Build a minimal SfReport dict."""
    data: dict[str, Any] = {
        "report_id": "00O000000ABC123",
        "name": "Test Report",
        "report_format": "summary",
        "report_type": "Opportunity",
        "org_key": "testorg",
        "folder_name": "Sales Reports",
        "description": "A test report",
        "columns": [
            {"column_key": "AMOUNT", "name": "Amount", "data_type": "currency", "object_api_name": "Opportunity"},
            {"column_key": "CLOSE_DATE", "name": "Close Date", "data_type": "date", "object_api_name": "Opportunity"},
            {"column_key": "STAGE_NAME", "name": "Stage", "data_type": "picklist", "object_api_name": "Opportunity"},
        ],
        "metadata_api_json": None,
    }
    data.update(overrides)
    return data


def _metadata_with_filters() -> dict[str, Any]:
    """Metadata API JSON with filters (real Metadata API structure)."""
    return {
        "filter": {
            "booleanFilter": None,
            "criteriaItems": [
                {"column": "AMOUNT", "operator": "greaterThan", "value": "1000", "isUnlocked": False},
                {"column": "STAGE_NAME", "operator": "equals", "value": "Closed Won", "isUnlocked": True},
            ],
            "language": "en_US",
        },
    }


def _metadata_with_groupings() -> dict[str, Any]:
    """Metadata API JSON with groupings."""
    return {
        "groupingsDown": [
            {"field": "ACCOUNT_NAME", "sortOrder": "Asc"},
            {"field": "STAGE_NAME", "sortOrder": "Desc"},
        ],
        "groupingsAcross": [
            {"field": "CLOSE_DATE", "sortOrder": "Asc"},
        ],
    }


def _metadata_with_buckets() -> dict[str, Any]:
    """Metadata API JSON with buckets (real Metadata API key is ``buckets``)."""
    return {
        "buckets": [
            {
                "masterLabel": "Amount Range",
                "developerName": "BucketField_Amount",
                "sourceColumnName": "AMOUNT",
                "bucketType": "number",
                "values": [
                    {"sourceValues": [{"from": None, "to": "1000"}], "value": "Small"},
                    {"sourceValues": [{"from": "1000", "to": "10000"}], "value": "Medium"},
                ],
                "useOther": True,
                "nullTreatment": "n",
            },
        ],
    }


def _metadata_with_formulas() -> dict[str, Any]:
    """Metadata API JSON with formulas (real Metadata API field names)."""
    return {
        "customDetailFormulas": [
            {
                "label": "Win Rate",
                "developerName": "FORMULA1",
                "calculatedFormula": "WON_COUNT:SUM / TOTAL_COUNT:SUM",
                "dataType": "percent",
                "scale": 2,
                "description": "Calculated win rate",
            },
        ],
        "aggregates": [
            {
                "masterLabel": "Total Pipeline",
                "developerName": "FORMULA2",
                "calculatedFormula": "AMOUNT:SUM * PROBABILITY:AVG",
                "datatype": "currency",
            },
        ],
    }


def _metadata_with_highlights() -> dict[str, Any]:
    """Metadata API JSON with color ranges."""
    return {
        "colorRanges": [
            {
                "columnName": "AMOUNT",
                "lowColor": "#FF0000",
                "midColor": "#FFFF00",
                "highColor": "#00FF00",
                "lowBreakpoint": 1000,
                "highBreakpoint": 50000,
            },
        ],
    }


def _metadata_with_cross_filters() -> dict[str, Any]:
    """Metadata API JSON with cross-filters."""
    return {
        "crossFilters": [
            {
                "operation": "without",
                "relatedEntity": "Task",
                "relatedEntityJoinField": "WhatId",
                "criteriaItems": [
                    {"column": "Status", "operator": "equals", "value": "Open"},
                ],
            },
        ],
    }


def _columns_multi_object() -> list[dict[str, Any]]:
    """Report columns spanning multiple Salesforce objects for join tests."""
    return [
        {"column_key": "AMOUNT", "name": "Amount", "data_type": "currency", "object_api_name": "Opportunity"},
        {"column_key": "STAGE_NAME", "name": "Stage", "data_type": "picklist", "object_api_name": "Opportunity"},
        {"column_key": "ACCOUNT_NAME", "name": "Account Name", "data_type": "string", "object_api_name": "Account"},
        {"column_key": "ACCOUNT_INDUSTRY", "name": "Industry", "data_type": "string", "object_api_name": "Account"},
        {"column_key": "CONTACT_EMAIL", "name": "Contact Email", "data_type": "email", "object_api_name": "Contact"},
    ]


def _metadata_full() -> dict[str, Any]:
    """Metadata API JSON with all Phase 2 features (except joins).

    Joins are derived from report columns, not metadata.
    See ``_columns_multi_object()`` and ``TestTransformerJoins``.
    """
    result: dict[str, Any] = {}
    for fixture in (
        _metadata_with_filters,
        _metadata_with_groupings,
        _metadata_with_buckets,
        _metadata_with_formulas,
        _metadata_with_highlights,
        _metadata_with_cross_filters,
    ):
        result.update(fixture())
    return result


# =============================================================================
# Transformer tests: Phase 1
# =============================================================================


class TestTransformerPhase1:
    """Test Phase 1 node generation (Report, ReportIR, ReportIRField)."""

    def test_report_node_ids(self) -> None:
        t = SalesforceIRTransformer()
        result = t.transform(_base_report_data())

        assert result.report.id == "report::salesforce::00O000000ABC123"
        assert result.report.system == "salesforce"
        assert result.report.native_id == "00O000000ABC123"
        assert result.report.title == "Test Report"

    def test_ir_node_ids(self) -> None:
        t = SalesforceIRTransformer()
        result = t.transform(_base_report_data())

        assert result.ir.id == "report::salesforce::00O000000ABC123.ir"
        assert result.ir.report_format == "summary"
        assert result.ir.base_entity == "Opportunity"

    def test_field_count_and_types(self) -> None:
        t = SalesforceIRTransformer()
        result = t.transform(_base_report_data())

        assert len(result.fields) == 3

        by_alias = {f.alias: f for f in result.fields}
        assert by_alias["AMOUNT"].field_type == "measure"
        assert by_alias["AMOUNT"].role == "aggregation"
        assert by_alias["CLOSE_DATE"].field_type == "time"
        assert by_alias["CLOSE_DATE"].role == "grouping"
        assert by_alias["STAGE_NAME"].field_type == "dimension"
        assert by_alias["STAGE_NAME"].role == "display"

    def test_field_ref_entity(self) -> None:
        t = SalesforceIRTransformer()
        result = t.transform(_base_report_data())

        by_alias = {f.alias: f for f in result.fields}
        assert by_alias["AMOUNT"].ref_entity == "Opportunity"
        assert by_alias["AMOUNT"].ref_type == "native"

    def test_native_node(self) -> None:
        t = SalesforceIRTransformer()
        result = t.transform(_base_report_data())

        assert result.native_node is not None
        assert result.native_node.node_label == NodeLabel.SF_REPORT

    def test_no_metadata_yields_empty_ir_nodes(self) -> None:
        t = SalesforceIRTransformer()
        result = t.transform(_base_report_data())

        assert result.ir_nodes == []

    def test_empty_columns(self) -> None:
        t = SalesforceIRTransformer()
        result = t.transform(_base_report_data(columns=[]))
        assert result.fields == []


# =============================================================================
# Transformer tests: Phase 2 — individual node types
# =============================================================================


class TestTransformerFilters:
    def test_filter_count(self) -> None:
        t = SalesforceIRTransformer()
        data = _base_report_data(metadata_api_json=_metadata_with_filters())
        result = t.transform(data)

        filters = [n for n in result.ir_nodes if isinstance(n, ReportIRFilter)]
        assert len(filters) == 2

    def test_filter_fields(self) -> None:
        t = SalesforceIRTransformer()
        data = _base_report_data(metadata_api_json=_metadata_with_filters())
        result = t.transform(data)

        filters = [n for n in result.ir_nodes if isinstance(n, ReportIRFilter)]
        assert filters[0].field_ref == "AMOUNT"
        assert filters[0].operator == "greaterThan"
        assert filters[0].value == "1000"
        assert filters[1].field_ref == "STAGE_NAME"

    def test_filter_id_format(self) -> None:
        t = SalesforceIRTransformer()
        data = _base_report_data(metadata_api_json=_metadata_with_filters())
        result = t.transform(data)

        filters = [n for n in result.ir_nodes if isinstance(n, ReportIRFilter)]
        assert filters[0].id == "report::salesforce::00O000000ABC123.ir.filter.0"
        assert filters[1].id == "report::salesforce::00O000000ABC123.ir.filter.1"

    def test_single_filter_criterion_as_dict(self) -> None:
        """Metadata API may return single criteriaItem as dict instead of list."""
        t = SalesforceIRTransformer()
        metadata = {
            "filter": {
                "criteriaItems": {"column": "AMOUNT", "operator": "greaterThan", "value": "500"},
            },
        }
        data = _base_report_data(metadata_api_json=metadata)
        result = t.transform(data)

        filters = [n for n in result.ir_nodes if isinstance(n, ReportIRFilter)]
        assert len(filters) == 1
        assert filters[0].field_ref == "AMOUNT"

    def test_filter_is_runtime(self) -> None:
        """Unlocked filters are marked as runtime (promptable)."""
        t = SalesforceIRTransformer()
        data = _base_report_data(metadata_api_json=_metadata_with_filters())
        result = t.transform(data)

        filters = [n for n in result.ir_nodes if isinstance(n, ReportIRFilter)]
        assert filters[0].is_runtime is False
        assert filters[1].is_runtime is True


class TestTransformerGroupings:
    def test_grouping_count(self) -> None:
        t = SalesforceIRTransformer()
        data = _base_report_data(metadata_api_json=_metadata_with_groupings())
        result = t.transform(data)

        groups = [n for n in result.ir_nodes if isinstance(n, ReportIRGroupBy)]
        assert len(groups) == 3  # 2 down + 1 across

    def test_grouping_axis(self) -> None:
        t = SalesforceIRTransformer()
        data = _base_report_data(metadata_api_json=_metadata_with_groupings())
        result = t.transform(data)

        groups = [n for n in result.ir_nodes if isinstance(n, ReportIRGroupBy)]
        row_groups = [g for g in groups if g.axis == "row"]
        col_groups = [g for g in groups if g.axis == "column"]
        assert len(row_groups) == 2
        assert len(col_groups) == 1

    def test_grouping_sequence(self) -> None:
        t = SalesforceIRTransformer()
        data = _base_report_data(metadata_api_json=_metadata_with_groupings())
        result = t.transform(data)

        row_groups = sorted(
            [n for n in result.ir_nodes if isinstance(n, ReportIRGroupBy) and n.axis == "row"],
            key=lambda g: g.sequence or 0,
        )
        assert row_groups[0].field_alias == "ACCOUNT_NAME"
        assert row_groups[0].sequence == 0
        assert row_groups[1].field_alias == "STAGE_NAME"
        assert row_groups[1].sequence == 1

    def test_grouping_sort_order(self) -> None:
        t = SalesforceIRTransformer()
        data = _base_report_data(metadata_api_json=_metadata_with_groupings())
        result = t.transform(data)

        groups = [n for n in result.ir_nodes if isinstance(n, ReportIRGroupBy)]
        by_alias = {g.field_alias: g for g in groups}
        assert by_alias["ACCOUNT_NAME"].sort_order == "asc"
        assert by_alias["STAGE_NAME"].sort_order == "desc"

    def test_grouping_id_format(self) -> None:
        t = SalesforceIRTransformer()
        data = _base_report_data(metadata_api_json=_metadata_with_groupings())
        result = t.transform(data)

        groups = [n for n in result.ir_nodes if isinstance(n, ReportIRGroupBy)]
        by_alias = {g.field_alias: g for g in groups}
        assert by_alias["ACCOUNT_NAME"].id == "report::salesforce::00O000000ABC123.ir.groupby.ACCOUNT_NAME"


class TestTransformerBuckets:
    def test_bucket_count(self) -> None:
        t = SalesforceIRTransformer()
        data = _base_report_data(metadata_api_json=_metadata_with_buckets())
        result = t.transform(data)

        buckets = [n for n in result.ir_nodes if isinstance(n, ReportIRBucket)]
        assert len(buckets) == 1

    def test_bucket_fields(self) -> None:
        t = SalesforceIRTransformer()
        data = _base_report_data(metadata_api_json=_metadata_with_buckets())
        result = t.transform(data)

        bucket = [n for n in result.ir_nodes if isinstance(n, ReportIRBucket)][0]
        assert bucket.bucket_name == "Amount Range"
        assert bucket.source_field == "AMOUNT"
        assert bucket.bucket_type == "numeric_range"
        assert bucket.other_bucket is True
        assert bucket.ranges is not None


class TestTransformerFormulas:
    def test_formula_count(self) -> None:
        t = SalesforceIRTransformer()
        data = _base_report_data(metadata_api_json=_metadata_with_formulas())
        result = t.transform(data)

        formulas = [n for n in result.ir_nodes if isinstance(n, ReportIRFormula)]
        assert len(formulas) == 2

    def test_row_formula(self) -> None:
        t = SalesforceIRTransformer()
        data = _base_report_data(metadata_api_json=_metadata_with_formulas())
        result = t.transform(data)

        row_formulas = [n for n in result.ir_nodes if isinstance(n, ReportIRFormula) and n.formula_type == "row"]
        assert len(row_formulas) == 1
        assert row_formulas[0].formula_name == "FORMULA1"
        assert row_formulas[0].expression == "WON_COUNT:SUM / TOTAL_COUNT:SUM"
        assert row_formulas[0].return_type == "percent"
        assert row_formulas[0].decimal_places == 2

    def test_summary_formula(self) -> None:
        t = SalesforceIRTransformer()
        data = _base_report_data(metadata_api_json=_metadata_with_formulas())
        result = t.transform(data)

        summaries = [n for n in result.ir_nodes if isinstance(n, ReportIRFormula) and n.formula_type == "summary"]
        assert len(summaries) == 1
        assert summaries[0].formula_name == "FORMULA2"
        assert summaries[0].expression == "AMOUNT:SUM * PROBABILITY:AVG"
        assert summaries[0].return_type == "number"


class TestTransformerHighlights:
    def test_highlight_count(self) -> None:
        t = SalesforceIRTransformer()
        data = _base_report_data(metadata_api_json=_metadata_with_highlights())
        result = t.transform(data)

        highlights = [n for n in result.ir_nodes if isinstance(n, ReportIRHighlight)]
        assert len(highlights) == 1

    def test_highlight_fields(self) -> None:
        t = SalesforceIRTransformer()
        data = _base_report_data(metadata_api_json=_metadata_with_highlights())
        result = t.transform(data)

        h = [n for n in result.ir_nodes if isinstance(n, ReportIRHighlight)][0]
        assert h.field_alias == "AMOUNT"
        assert h.low_color == "#FF0000"
        assert h.high_color == "#00FF00"
        assert h.low_breakpoint == 1000.0
        assert h.high_breakpoint == 50000.0


class TestTransformerCrossFilters:
    def test_cross_filter_count(self) -> None:
        t = SalesforceIRTransformer()
        data = _base_report_data(metadata_api_json=_metadata_with_cross_filters())
        result = t.transform(data)

        cfs = [n for n in result.ir_nodes if isinstance(n, ReportIRCrossFilter)]
        assert len(cfs) == 1

    def test_cross_filter_fields(self) -> None:
        t = SalesforceIRTransformer()
        data = _base_report_data(metadata_api_json=_metadata_with_cross_filters())
        result = t.transform(data)

        cf = [n for n in result.ir_nodes if isinstance(n, ReportIRCrossFilter)][0]
        assert cf.mode == "without"
        assert cf.related_entity == "Task"
        assert cf.filter_conditions is not None  # JSON serialized conditions


class TestTransformerJoins:
    def test_join_from_multi_object_columns(self) -> None:
        t = SalesforceIRTransformer()
        data = _base_report_data(columns=_columns_multi_object())
        result = t.transform(data)

        joins = [n for n in result.ir_nodes if isinstance(n, ReportIRJoin)]
        assert len(joins) == 2  # Opportunity->Account, Opportunity->Contact

    def test_join_entities(self) -> None:
        t = SalesforceIRTransformer()
        data = _base_report_data(columns=_columns_multi_object())
        result = t.transform(data)

        joins = sorted(
            [n for n in result.ir_nodes if isinstance(n, ReportIRJoin)],
            key=lambda j: j.index,
        )
        assert joins[0].from_entity == "Opportunity"
        assert joins[0].to_entity == "Account"
        assert joins[1].from_entity == "Opportunity"
        assert joins[1].to_entity == "Contact"

    def test_no_joins_for_single_object(self) -> None:
        """Single-object columns should not create any join nodes."""
        t = SalesforceIRTransformer()
        metadata = {"columns": [{"field": "Opportunity.Amount"}, {"field": "Opportunity.StageName"}]}
        data = _base_report_data(metadata_api_json=metadata)
        result = t.transform(data)

        joins = [n for n in result.ir_nodes if isinstance(n, ReportIRJoin)]
        assert len(joins) == 0


# =============================================================================
# Transformer tests: full metadata
# =============================================================================


class TestTransformerFullMetadata:
    def test_all_phase2_types_present(self) -> None:
        t = SalesforceIRTransformer()
        data = _base_report_data(metadata_api_json=_metadata_full())
        result = t.transform(data)

        type_names = {type(n).__name__ for n in result.ir_nodes}
        assert "ReportIRFilter" in type_names
        assert "ReportIRGroupBy" in type_names
        assert "ReportIRBucket" in type_names
        assert "ReportIRFormula" in type_names
        assert "ReportIRHighlight" in type_names
        assert "ReportIRCrossFilter" in type_names
        # ReportIRJoin requires multi-object columns; tested in TestTransformerJoins

    def test_total_ir_node_count(self) -> None:
        t = SalesforceIRTransformer()
        data = _base_report_data(metadata_api_json=_metadata_full())
        result = t.transform(data)

        # 2 filters + 3 groupings + 1 bucket + 2 formulas + 1 highlight + 1 cross-filter = 10
        assert len(result.ir_nodes) == 10


# =============================================================================
# Edge auto-discovery registry
# =============================================================================


class TestIRChildEdgeMap:
    def test_all_phase2_types_registered(self) -> None:
        """Every Phase 2 node type should have an entry in _IR_CHILD_EDGE_MAP."""
        expected = {
            ReportIRFilter, ReportIRJoin, ReportIRGroupBy,
            ReportIRBucket, ReportIRFormula, ReportIRHighlight,
            ReportIRCrossFilter,
        }
        assert set(_IR_CHILD_EDGE_MAP.keys()) == expected

    def test_edge_allowed_pairs(self) -> None:
        """Each registered edge should allow (ReportIR, NodeType) pair."""
        for node_type, edge_cls in _IR_CHILD_EDGE_MAP.items():
            # Check that (ReportIR, node_type) is in allowed_pairs
            found = False
            for from_t, to_t in edge_cls.allowed_pairs:
                if from_t == ReportIR and to_t == node_type:
                    found = True
                    break
            assert found, f"Edge {edge_cls.__name__} missing (ReportIR, {node_type.__name__}) pair"


# =============================================================================
# TransformResult
# =============================================================================


class TestTransformResult:
    def test_defaults(self) -> None:
        tr = TransformResult(
            report=Report(name="R", system="sf", native_id="123"),
            ir=ReportIR(name="IR", report_id="report::sf::123"),
        )
        assert tr.fields == []
        assert tr.ir_nodes == []
        assert tr.native_node is None
        assert tr.native_definition is None


# =============================================================================
# _persist() edge collection
# =============================================================================


class _ConcreteLoader(BaseReportLoader):
    """Minimal concrete subclass for testing _persist()."""

    async def fetch_reports(self, storage: Any) -> list[dict]:
        return []

    def transform_to_ir(self, raw_data: dict) -> TransformResult:
        return TransformResult(
            report=Report(name="x", system="x", native_id="x"),
            ir=ReportIR(name="x", report_id="report::x::x"),
        )


class TestPersistEdgeCollection:
    """Verify _persist() builds correct nodes and edges for bulk_load."""

    def _mock_storage(self) -> MagicMock:
        storage = MagicMock()
        storage.bulk_load = MagicMock()
        return storage

    def _loader(self) -> _ConcreteLoader:
        return _ConcreteLoader()

    def test_phase1_edges(self) -> None:
        storage = self._mock_storage()

        t = SalesforceIRTransformer()
        data = _base_report_data()  # no metadata => no Phase 2
        result = t.transform(data)

        self._loader()._persist(storage, result)

        # Verify bulk_load was called
        assert storage.bulk_load.call_count == 1
        nodes, edges = storage.bulk_load.call_args[0]

        # Report + ReportIR + 3 fields = 5 nodes
        # (NativeReportDefinition is referenced via NodeIdentifier, not added as node)
        assert len(nodes) == 5

        # Edges: HasIR + 3 HasIRField + NativeInstanceOf + HasNativeDefinition
        #      + 3 MapsToNativeField = 9
        assert len(edges) == 9

        # Check edge types
        edge_types = [type(e[2]).__name__ for e in edges]
        assert edge_types.count("HasIR") == 1
        assert edge_types.count("HasIRField") == 3
        assert edge_types.count("NativeInstanceOf") == 1
        assert edge_types.count("HasNativeDefinition") == 1
        assert edge_types.count("MapsToNativeField") == 3

    def test_phase2_edges(self) -> None:
        storage = self._mock_storage()

        t = SalesforceIRTransformer()
        data = _base_report_data(metadata_api_json=_metadata_full())
        result = t.transform(data)

        self._loader()._persist(storage, result)

        nodes, edges = storage.bulk_load.call_args[0]

        # Phase 2 nodes: 10 ir_nodes (no joins — single-object columns)
        # Phase 1 nodes: Report + ReportIR + 3 fields = 5
        # Total: 15
        assert len(nodes) == 15

        edge_types = [type(e[2]).__name__ for e in edges]
        assert "HasIRFilter" in edge_types
        assert "HasIRGroupBy" in edge_types
        assert "HasIRBucket" in edge_types
        assert "HasIRFormula" in edge_types
        assert "HasIRHighlight" in edge_types
        assert "HasIRCrossFilter" in edge_types

        # MapsToNativeField: 3 (fields)
        # + 5 (aux: 2 filter + 2 groupby + 1 bucket; ACCOUNT_NAME groupby skipped — not in columns)
        # + 1 (computed: AMOUNT from formula; WON_COUNT/TOTAL_COUNT/PROBABILITY not in columns)
        # + 1 (highlight) + 2 (cross-filter, exempt from column validation) = 12
        assert edge_types.count("MapsToNativeField") == 12

    def test_filter_edge_has_sequence(self) -> None:
        """HasIRFilter edges should carry a sequence from filter index."""
        storage = self._mock_storage()

        t = SalesforceIRTransformer()
        data = _base_report_data(metadata_api_json=_metadata_with_filters())
        result = t.transform(data)

        self._loader()._persist(storage, result)

        _, edges = storage.bulk_load.call_args[0]
        filter_edges = [(from_n, to_n, e) for from_n, to_n, e in edges if type(e).__name__ == "HasIRFilter"]
        assert len(filter_edges) == 2
        assert filter_edges[0][2].sequence == 0
        assert filter_edges[1][2].sequence == 1

    def test_phase2_stitching_edges(self) -> None:
        """GroupBy/Filter/Bucket nodes should have MAPS_TO_NATIVE_FIELD edges."""
        storage = self._mock_storage()

        t = SalesforceIRTransformer()
        data = _base_report_data(metadata_api_json=_metadata_full())
        result = t.transform(data)

        self._loader()._persist(storage, result)

        _, edges = storage.bulk_load.call_args[0]
        maps_edges = [
            (from_n, to_n, e)
            for from_n, to_n, e in edges
            if type(e).__name__ == "MapsToNativeField" and e.mapping_type == "auxiliary"
        ]

        # 2 groupings (ACCOUNT_NAME skipped — not in columns) + 2 filters
        # + 1 bucket + 1 highlight + 2 cross-filter = 8
        assert len(maps_edges) == 8

        # Verify source node types
        source_types = [type(e[0]).__name__ for e in maps_edges]
        assert source_types.count("ReportIRGroupBy") == 2
        assert source_types.count("ReportIRFilter") == 2
        assert source_types.count("ReportIRBucket") == 1
        assert source_types.count("ReportIRHighlight") == 1
        assert source_types.count("ReportIRCrossFilter") == 2

    def test_synthetic_refs_not_stitched(self) -> None:
        """Synthetic refs (BucketField_*, FORMULA*) should NOT get stitching edges."""
        t = SalesforceIRTransformer()
        metadata = {
            "filter": {
                "criteriaItems": [
                    {"column": "AMOUNT", "operator": "greaterThan", "value": "0"},
                ],
            },
            "groupingsDown": [
                {"field": "BucketField_Amount", "sortOrder": "Asc"},
            ],
            "colorRanges": [
                {"columnName": "FORMULA_Sum_Amount"},
            ],
        }
        data = _base_report_data(metadata_api_json=metadata)
        result = t.transform(data)

        aux_maps = [
            e for e in result.extra_edges
            if type(e[2]).__name__ == "MapsToNativeField" and e[2].mapping_type == "auxiliary"
        ]
        # Only AMOUNT filter should be stitched; BucketField_Amount is synthetic
        assert len(aux_maps) == 1


# =============================================================================
# Factory registration
# =============================================================================


class TestFactoryRegistration:
    def test_salesforce_registered(self) -> None:
        from lineage.ingest.static_loaders.reports.factory import ReportLoaderFactory

        assert "salesforce" in ReportLoaderFactory.available_systems()

    def test_create_salesforce_loader(self) -> None:
        from lineage.ingest.static_loaders.reports.config import ReportSourceConfig
        from lineage.ingest.static_loaders.reports.factory import ReportLoaderFactory
        from lineage.ingest.static_loaders.reports.salesforce.loader import (
            SalesforceReportLoader,
        )

        config = ReportSourceConfig(system="salesforce", org_key="testorg")
        loader = ReportLoaderFactory.create(config)
        assert isinstance(loader, SalesforceReportLoader)

    def test_unknown_system_raises(self) -> None:
        from lineage.ingest.static_loaders.reports.config import ReportSourceConfig
        from lineage.ingest.static_loaders.reports.factory import ReportLoaderFactory

        config = ReportSourceConfig(system="unknown_platform")
        with pytest.raises(ValueError, match="No report loader registered"):
            ReportLoaderFactory.create(config)


# =============================================================================
# _ensure_list normalization
# =============================================================================


class TestEnsureListNormalization:
    """Test that single-dict metadata values are normalized to lists."""

    def test_single_bucket_as_dict(self) -> None:
        t = SalesforceIRTransformer()
        metadata = {
            "buckets": {
                "masterLabel": "Test Bucket",
                "sourceColumnName": "AMOUNT",
                "bucketType": "number",
            },
        }
        data = _base_report_data(metadata_api_json=metadata)
        result = t.transform(data)

        buckets = [n for n in result.ir_nodes if isinstance(n, ReportIRBucket)]
        assert len(buckets) == 1

    def test_single_grouping_as_dict(self) -> None:
        t = SalesforceIRTransformer()
        metadata = {
            "groupingsDown": {"field": "STAGE_NAME", "sortOrder": "Asc"},
        }
        data = _base_report_data(metadata_api_json=metadata)
        result = t.transform(data)

        groups = [n for n in result.ir_nodes if isinstance(n, ReportIRGroupBy)]
        assert len(groups) == 1

    def test_none_metadata_fields(self) -> None:
        """None values in metadata fields should produce empty lists."""
        t = SalesforceIRTransformer()
        metadata = {
            "filter": None,
            "groupingsDown": None,
            "buckets": None,
        }
        data = _base_report_data(metadata_api_json=metadata)
        result = t.transform(data)

        assert result.ir_nodes == []


# =============================================================================
# Gap fix tests: aggregation, date_granularity, granularity back-population
# =============================================================================


class TestAggregationPopulation:
    """Gap 1: ReportIRField.aggregation populated from Metadata API columns."""

    def test_aggregation_from_metadata_columns(self) -> None:
        """Fields with aggregateTypes in metadata should have aggregation set."""
        t = SalesforceIRTransformer()
        metadata = {
            "columns": [
                {"field": "AMOUNT", "aggregateTypes": ["Sum"]},
            ],
        }
        data = _base_report_data(metadata_api_json=metadata)
        result = t.transform(data)

        by_alias = {f.alias: f for f in result.fields}
        assert by_alias["AMOUNT"].aggregation == "Sum"

    def test_aggregation_multiple_types(self) -> None:
        """Multiple aggregateTypes should be joined with comma."""
        t = SalesforceIRTransformer()
        metadata = {
            "columns": [
                {"field": "AMOUNT", "aggregateTypes": ["Sum", "Average"]},
            ],
        }
        data = _base_report_data(metadata_api_json=metadata)
        result = t.transform(data)

        by_alias = {f.alias: f for f in result.fields}
        assert by_alias["AMOUNT"].aggregation == "Sum,Average"

    def test_aggregation_string_value(self) -> None:
        """String aggregateTypes should be stored directly."""
        t = SalesforceIRTransformer()
        metadata = {
            "columns": [
                {"field": "AMOUNT", "aggregateTypes": "Sum"},
            ],
        }
        data = _base_report_data(metadata_api_json=metadata)
        result = t.transform(data)

        by_alias = {f.alias: f for f in result.fields}
        assert by_alias["AMOUNT"].aggregation == "Sum"

    def test_no_aggregation_when_absent(self) -> None:
        """Fields without aggregateTypes should have aggregation=None."""
        t = SalesforceIRTransformer()
        metadata = {
            "columns": [
                {"field": "AMOUNT"},  # no aggregateTypes key
                {"field": "STAGE_NAME", "aggregateTypes": []},  # empty list
            ],
        }
        data = _base_report_data(metadata_api_json=metadata)
        result = t.transform(data)

        for f in result.fields:
            assert f.aggregation is None

    def test_aggregation_no_metadata(self) -> None:
        """Without metadata, all fields should have aggregation=None."""
        t = SalesforceIRTransformer()
        data = _base_report_data()  # no metadata_api_json
        result = t.transform(data)

        for f in result.fields:
            assert f.aggregation is None


class TestDateGranularityOnGrouping:
    """Gap 2: ReportIRGroupBy.date_granularity from dateGranularity."""

    def test_date_granularity_populated(self) -> None:
        """Groupings with dateGranularity should have date_granularity set."""
        t = SalesforceIRTransformer()
        metadata = {
            "groupingsDown": [
                {"field": "CLOSE_DATE", "sortOrder": "Asc", "dateGranularity": "Day"},
                {"field": "CREATED_DATE", "sortOrder": "Asc", "dateGranularity": "Month"},
            ],
        }
        data = _base_report_data(metadata_api_json=metadata)
        result = t.transform(data)

        groups = [n for n in result.ir_nodes if isinstance(n, ReportIRGroupBy)]
        by_alias = {g.field_alias: g for g in groups}
        assert by_alias["CLOSE_DATE"].date_granularity == "day"
        assert by_alias["CREATED_DATE"].date_granularity == "month"

    def test_date_granularity_none_when_absent(self) -> None:
        """Groupings without dateGranularity should have date_granularity=None."""
        t = SalesforceIRTransformer()
        metadata = {
            "groupingsDown": [
                {"field": "STAGE_NAME", "sortOrder": "Asc"},
            ],
        }
        data = _base_report_data(metadata_api_json=metadata)
        result = t.transform(data)

        groups = [n for n in result.ir_nodes if isinstance(n, ReportIRGroupBy)]
        assert groups[0].date_granularity is None


class TestGranularityBackPopulation:
    """Gap 3: ReportIRField.granularity back-populated from groupings."""

    def test_field_granularity_from_grouping(self) -> None:
        """Field granularity should be set when matching grouping has dateGranularity."""
        t = SalesforceIRTransformer()
        metadata = {
            "groupingsDown": [
                {"field": "CLOSE_DATE", "sortOrder": "Asc", "dateGranularity": "Day"},
            ],
        }
        data = _base_report_data(metadata_api_json=metadata)
        result = t.transform(data)

        by_alias = {f.alias: f for f in result.fields}
        assert by_alias["CLOSE_DATE"].granularity == "day"

    def test_field_granularity_none_without_grouping(self) -> None:
        """Fields not in a grouping should have granularity=None."""
        t = SalesforceIRTransformer()
        metadata = {
            "groupingsDown": [
                {"field": "CLOSE_DATE", "sortOrder": "Asc", "dateGranularity": "Day"},
            ],
        }
        data = _base_report_data(metadata_api_json=metadata)
        result = t.transform(data)

        by_alias = {f.alias: f for f in result.fields}
        assert by_alias["AMOUNT"].granularity is None
        assert by_alias["STAGE_NAME"].granularity is None

    def test_field_granularity_none_when_grouping_has_no_date_granularity(self) -> None:
        """Fields in a grouping without dateGranularity should have granularity=None."""
        t = SalesforceIRTransformer()
        metadata = {
            "groupingsDown": [
                {"field": "STAGE_NAME", "sortOrder": "Asc"},
            ],
        }
        data = _base_report_data(metadata_api_json=metadata)
        result = t.transform(data)

        by_alias = {f.alias: f for f in result.fields}
        assert by_alias["STAGE_NAME"].granularity is None
