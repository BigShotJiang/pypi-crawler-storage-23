"""Unit tests for Blob storage protocol and SQLite backend."""

from __future__ import annotations

from pathlib import Path

import pytest
from lineage.backends.blobs.factory import create_blob_storage
from lineage.backends.blobs.protocol import (
    Blob,
    BlobRef,
    generate_blob_id,
)
from lineage.backends.blobs.sqlite import SQLiteBlobStorage
from lineage.backends.config import SQLiteBlobConfig


@pytest.fixture
def blob_db_path(tmp_path: Path) -> Path:
    """Temporary database path for blob tests."""
    return tmp_path / "test_blobs.db"


@pytest.fixture
def blob_storage(blob_db_path: Path) -> SQLiteBlobStorage:
    """SQLiteBlobStorage instance with temp database."""
    return SQLiteBlobStorage(db_path=blob_db_path)


class TestGenerateBlobId:
    """Tests for blob ID generation."""

    def test_generates_unique_ids(self) -> None:
        """Each call produces a unique ID."""
        ids = {generate_blob_id() for _ in range(100)}
        assert len(ids) == 100

    def test_id_has_correct_prefix(self) -> None:
        """IDs have the expected blob_ prefix."""
        blob_id = generate_blob_id()
        assert blob_id.startswith("blob_")

    def test_id_has_reasonable_length(self) -> None:
        """IDs are a reasonable length for display/storage."""
        blob_id = generate_blob_id()
        assert 10 <= len(blob_id) <= 50


class TestBlobStorage:
    """Tests for SQLiteBlobStorage CRUD operations."""

    def test_store_and_get_query_result(self, blob_storage: SQLiteBlobStorage) -> None:
        """Store and retrieve a query result blob."""
        data = {
            "columns": ["id", "name", "value"],
            "rows": [
                (1, "Alice", 100),
                (2, "Bob", 200),
                (3, "Charlie", 300),
            ],
            "row_count": 3,
        }

        ref = blob_storage.store(
            thread_id="thread_1",
            run_id="run_1",
            blob_type="query_result",
            data=data,
            metadata={"sql": "SELECT * FROM users", "query_name": "user_list"},
        )

        assert isinstance(ref, BlobRef)
        assert ref.blob_id.startswith("blob_")
        assert ref.blob_type == "query_result"
        assert ref.summary == "3 rows, 3 columns"
        assert ref.row_count == 3
        assert ref.columns == ["id", "name", "value"]

        # Retrieve the blob
        blob = blob_storage.get(ref.blob_id)
        assert blob is not None
        assert isinstance(blob, Blob)
        assert blob.blob_id == ref.blob_id
        assert blob.blob_type == "query_result"
        assert blob.thread_id == "thread_1"
        assert blob.run_id == "run_1"
        assert blob.data["columns"] == ["id", "name", "value"]
        # JSON serialization converts tuples to lists
        assert blob.data["rows"] == [[1, "Alice", 100], [2, "Bob", 200], [3, "Charlie", 300]]
        assert blob.metadata["sql"] == "SELECT * FROM users"

    def test_store_table_preview(self, blob_storage: SQLiteBlobStorage) -> None:
        """Store and retrieve a table preview blob."""
        data = {
            "columns": ["col_a", "col_b"],
            "sample_rows": [[1, "x"], [2, "y"]],
        }

        ref = blob_storage.store(
            thread_id="thread_2",
            run_id="run_2",
            blob_type="table_preview",
            data=data,
        )

        assert ref.blob_type == "table_preview"
        assert ref.summary == "Preview: 2 rows, 2 columns"

        blob = blob_storage.get(ref.blob_id)
        assert blob.data["sample_rows"] == [[1, "x"], [2, "y"]]

    def test_store_explore(self, blob_storage: SQLiteBlobStorage) -> None:
        """Store and retrieve an explore blob."""
        data = {
            "title": "Revenue Model Analysis",
            "markdown": "# Analysis\n\nFound 5 models...",
        }

        ref = blob_storage.store(
            thread_id="thread_3",
            run_id="run_3",
            blob_type="explore",
            data=data,
        )

        assert ref.blob_type == "explore"
        assert ref.summary == "Exploration: Revenue Model Analysis"

    def test_get_nonexistent_blob(self, blob_storage: SQLiteBlobStorage) -> None:
        """Getting a nonexistent blob returns None."""
        result = blob_storage.get("blob_does_not_exist")
        assert result is None

    def test_delete_blob(self, blob_storage: SQLiteBlobStorage) -> None:
        """Delete removes a blob and returns True."""
        ref = blob_storage.store(
            thread_id="t",
            run_id="r",
            blob_type="query_result",
            data={"columns": [], "rows": []},
        )

        assert blob_storage.get(ref.blob_id) is not None
        deleted = blob_storage.delete(ref.blob_id)
        assert deleted is True
        assert blob_storage.get(ref.blob_id) is None

    def test_delete_nonexistent_blob(self, blob_storage: SQLiteBlobStorage) -> None:
        """Deleting a nonexistent blob returns False."""
        result = blob_storage.delete("blob_does_not_exist")
        assert result is False


class TestBlobPreview:
    """Tests for blob preview functionality."""

    def test_preview_does_not_mutate_original(self, blob_storage: SQLiteBlobStorage) -> None:
        """preview() must not mutate the original Blob returned by get()."""
        data = {
            "columns": ["id", "value"],
            "rows": [(i, f"val_{i}") for i in range(20)],
        }

        ref = blob_storage.store(
            thread_id="t",
            run_id="r",
            blob_type="query_result",
            data=data,
        )

        # Get original blob and note its row count
        original = blob_storage.get(ref.blob_id)
        assert original is not None
        original_row_count = len(original.data["rows"])
        assert original_row_count == 20

        # Preview with truncation
        preview = blob_storage.preview(ref.blob_id, sample_rows=3)
        assert preview is not None
        assert len(preview.data["rows"]) == 3

        # Original must be unchanged
        assert len(original.data["rows"]) == 20
        assert "preview_truncated" not in original.data

    def test_preview_truncates_rows(self, blob_storage: SQLiteBlobStorage) -> None:
        """Preview returns limited rows with metadata."""
        data = {
            "columns": ["id", "value"],
            "rows": [(i, f"val_{i}") for i in range(100)],
        }

        ref = blob_storage.store(
            thread_id="t",
            run_id="r",
            blob_type="query_result",
            data=data,
        )

        preview = blob_storage.preview(ref.blob_id, sample_rows=5)
        assert preview is not None
        assert len(preview.data["rows"]) == 5
        assert preview.data["total_rows"] == 100
        assert preview.data["preview_truncated"] is True

    def test_preview_small_result(self, blob_storage: SQLiteBlobStorage) -> None:
        """Preview of small result doesn't truncate."""
        data = {
            "columns": ["id"],
            "rows": [(1,), (2,), (3,)],
        }

        ref = blob_storage.store(
            thread_id="t",
            run_id="r",
            blob_type="query_result",
            data=data,
        )

        preview = blob_storage.preview(ref.blob_id, sample_rows=10)
        assert preview is not None
        assert len(preview.data["rows"]) == 3
        assert preview.data["total_rows"] == 3
        assert preview.data["preview_truncated"] is False

    def test_preview_nonexistent_blob(self, blob_storage: SQLiteBlobStorage) -> None:
        """Preview of nonexistent blob returns None."""
        result = blob_storage.preview("blob_does_not_exist")
        assert result is None


class TestBlobListByThread:
    """Tests for listing blobs by thread."""

    def test_list_by_thread(self, blob_storage: SQLiteBlobStorage) -> None:
        """List blobs for a specific thread."""
        # Create blobs for thread_1
        blob_storage.store(
            thread_id="thread_1", run_id="r1", blob_type="query_result",
            data={"columns": [], "rows": []},
        )
        blob_storage.store(
            thread_id="thread_1", run_id="r1", blob_type="explore",
            data={"title": "Test"},
        )

        # Create blob for thread_2
        blob_storage.store(
            thread_id="thread_2", run_id="r1", blob_type="query_result",
            data={"columns": [], "rows": []},
        )

        thread_1_blobs = blob_storage.list_by_thread("thread_1")
        assert len(thread_1_blobs) == 2

        thread_2_blobs = blob_storage.list_by_thread("thread_2")
        assert len(thread_2_blobs) == 1

    def test_list_by_thread_with_type_filter(self, blob_storage: SQLiteBlobStorage) -> None:
        """List only blobs of specific type."""
        blob_storage.store(
            thread_id="t", run_id="r", blob_type="query_result",
            data={"columns": [], "rows": []},
        )
        blob_storage.store(
            thread_id="t", run_id="r", blob_type="explore",
            data={"title": "Test"},
        )

        query_results = blob_storage.list_by_thread("t", blob_type="query_result")
        assert len(query_results) == 1
        assert query_results[0].blob_type == "query_result"

    def test_list_by_thread_respects_limit(self, blob_storage: SQLiteBlobStorage) -> None:
        """List respects the limit parameter."""
        for _i in range(10):
            blob_storage.store(
                thread_id="t", run_id="r", blob_type="query_result",
                data={"columns": [], "rows": []},
            )

        blobs = blob_storage.list_by_thread("t", limit=5)
        assert len(blobs) == 5

    def test_list_by_thread_empty(self, blob_storage: SQLiteBlobStorage) -> None:
        """List for empty thread returns empty list."""
        blobs = blob_storage.list_by_thread("nonexistent_thread")
        assert blobs == []


class TestBlobTTL:
    """Tests for blob TTL (time-to-live) functionality."""

    def test_expiration_comparison_is_consistent(self, blob_db_path: Path) -> None:
        """Stored timestamps use SQLite-native format (no T separator or timezone suffix)."""
        import sqlite3

        storage = SQLiteBlobStorage(db_path=blob_db_path)
        ref = storage.store(
            thread_id="t",
            run_id="r",
            blob_type="query_result",
            data={"columns": [], "rows": []},
            ttl_days=1,
        )

        conn = sqlite3.connect(str(blob_db_path))
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT created_at, expires_at FROM blobs WHERE blob_id = ?",
            (ref.blob_id,),
        ).fetchone()
        conn.close()

        for ts in (row["created_at"], row["expires_at"]):
            # Must not contain ISO 'T' separator or '+' timezone suffix
            assert "T" not in ts, f"Timestamp contains 'T': {ts}"
            assert "+" not in ts, f"Timestamp contains '+': {ts}"
            # Should match SQLite datetime format
            assert len(ts) == 19, f"Unexpected timestamp length: {ts}"

    def test_expired_blob_not_returned(self, blob_db_path: Path) -> None:
        """Expired blobs are not returned by get()."""

        storage = SQLiteBlobStorage(db_path=blob_db_path)

        # Store a blob with normal TTL
        ref = storage.store(
            thread_id="t",
            run_id="r",
            blob_type="query_result",
            data={"columns": [], "rows": []},
            ttl_days=30,
        )

        # Manually expire it by updating the expires_at to the past
        with storage._lock, storage._conn:
            storage._conn.execute(
                "UPDATE blobs SET expires_at = datetime('now', '-1 day') WHERE blob_id = ?",
                (ref.blob_id,),
            )

        # The blob should now be expired
        blob = storage.get(ref.blob_id)
        assert blob is None

    def test_cleanup_expired(self, blob_db_path: Path) -> None:
        """cleanup_expired removes expired blobs."""
        storage = SQLiteBlobStorage(db_path=blob_db_path)

        # Store two blobs with normal TTL
        ref_short = storage.store(
            thread_id="t", run_id="r", blob_type="query_result",
            data={"columns": [], "rows": []},
            ttl_days=30,
        )
        ref_long = storage.store(
            thread_id="t", run_id="r", blob_type="query_result",
            data={"columns": [], "rows": []},
            ttl_days=30,
        )

        # Manually expire the first blob
        with storage._lock, storage._conn:
            storage._conn.execute(
                "UPDATE blobs SET expires_at = datetime('now', '-1 day') WHERE blob_id = ?",
                (ref_short.blob_id,),
            )

        count = storage.cleanup_expired()
        assert count == 1

        # Expired blob should be gone, non-expired blob should remain
        assert storage.get(ref_short.blob_id) is None
        assert storage.get(ref_long.blob_id) is not None


class TestBlobStorageFactory:
    """Tests for blob storage factory."""

    def test_create_sqlite_blob_storage(self, tmp_path: Path) -> None:
        """Factory creates SQLite storage from config."""
        config = SQLiteBlobConfig(
            enabled=True,
            backend="sqlite",
            db_path=tmp_path / "factory_test.db",
        )

        storage = create_blob_storage(config)
        assert storage is not None
        assert isinstance(storage, SQLiteBlobStorage)

    def test_create_disabled_returns_none(self, tmp_path: Path) -> None:
        """Factory returns None when disabled."""
        config = SQLiteBlobConfig(
            enabled=False,
            db_path=tmp_path / "disabled.db",
        )

        storage = create_blob_storage(config)
        assert storage is None


class TestBlobDataIntegrity:
    """Tests for data integrity across store/retrieve cycles."""

    def test_complex_data_preserved(self, blob_storage: SQLiteBlobStorage) -> None:
        """Complex nested data structures are preserved."""
        data = {
            "columns": ["id", "config", "tags"],
            "rows": [
                (1, {"nested": {"deep": True}}, ["tag1", "tag2"]),
                (2, {"list": [1, 2, 3]}, []),
            ],
            "extra": {
                "nulls": [None, None],
                "unicode": "Hello! ",
            },
        }

        ref = blob_storage.store(
            thread_id="t",
            run_id="r",
            blob_type="query_result",
            data=data,
        )

        blob = blob_storage.get(ref.blob_id)
        assert blob.data["columns"] == data["columns"]
        assert blob.data["extra"]["unicode"] == "Hello! "
        assert blob.data["extra"]["nulls"] == [None, None]

    def test_large_data_handled(self, blob_storage: SQLiteBlobStorage) -> None:
        """Large data payloads are handled correctly."""
        # Create a reasonably large dataset
        data = {
            "columns": [f"col_{i}" for i in range(50)],
            "rows": [tuple(f"value_{i}_{j}" for j in range(50)) for i in range(1000)],
        }

        ref = blob_storage.store(
            thread_id="t",
            run_id="r",
            blob_type="query_result",
            data=data,
        )

        assert ref.row_count == 1000
        assert ref.summary == "1000 rows, 50 columns"

        blob = blob_storage.get(ref.blob_id)
        assert len(blob.data["rows"]) == 1000
        assert len(blob.data["columns"]) == 50
