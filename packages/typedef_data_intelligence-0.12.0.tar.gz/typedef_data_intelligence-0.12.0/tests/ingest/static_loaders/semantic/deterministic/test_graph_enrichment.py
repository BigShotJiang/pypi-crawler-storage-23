"""Tests for GraphEnricher retry/backoff behavior."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest
from lineage.ingest.static_loaders.semantic.deterministic.graph_enrichment import (
    EnrichmentResult,
    GraphEnricher,
)


@pytest.fixture
def mock_storage():
    """Create a mock LineageStorage."""
    storage = MagicMock()
    storage.execute_raw_query.return_value = MagicMock(rows=[])
    return storage


class TestGraphEnricherDefaults:
    """Verify constructor defaults."""

    def test_default_timeout_is_10(self, mock_storage):
        enricher = GraphEnricher(mock_storage)
        assert enricher.timeout_seconds == 10.0

    def test_default_max_retries_is_3(self, mock_storage):
        enricher = GraphEnricher(mock_storage)
        assert enricher.max_retries == 3

    def test_default_base_backoff_is_half_second(self, mock_storage):
        enricher = GraphEnricher(mock_storage)
        assert enricher.base_backoff == 0.5

    def test_custom_params(self, mock_storage):
        enricher = GraphEnricher(
            mock_storage, timeout_seconds=5.0, max_retries=2, base_backoff=1.0
        )
        assert enricher.timeout_seconds == 5.0
        assert enricher.max_retries == 2
        assert enricher.base_backoff == 1.0


class TestGraphEnricherRetry:
    """Verify retry and backoff on failure."""

    @pytest.mark.asyncio
    async def test_query_retries_then_succeeds(self, mock_storage):
        """Succeeds on 2nd attempt after 1st query raises exception."""
        call_count = 0

        def fail_then_succeed(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise ConnectionError("FalkorDB busy")
            return MagicMock(rows=[
                {"base": "tbl", "model_id": "model.test.tbl", "source_id": None, "physical_fqn": None}
            ])

        mock_storage.execute_raw_query.side_effect = fail_then_succeed

        enricher = GraphEnricher(mock_storage, max_retries=3, base_backoff=0.01)
        result = await enricher.enrich_model("model.test.y", {"tbl"}, [])

        assert call_count == 2
        assert "tbl" in result.relation_hints
        assert result.relation_hints["tbl"].model_id == "model.test.tbl"

    @pytest.mark.asyncio
    async def test_cache_bypasses_retry(self, mock_storage):
        """Cached results are returned immediately without retries."""
        enricher = GraphEnricher(mock_storage, max_retries=3, base_backoff=0.01)
        cached = EnrichmentResult()
        enricher._cache["model.test.cached"] = cached

        # Even if fetch would fail, cache should return immediately
        mock_storage.execute_raw_query.side_effect = RuntimeError("should not be called")

        result = await enricher.enrich_model("model.test.cached", set(), [])
        assert result is cached
        mock_storage.execute_raw_query.assert_not_called()

    @pytest.mark.asyncio
    async def test_successful_result_is_cached(self, mock_storage):
        """Successful enrichment is cached for subsequent calls."""
        enricher = GraphEnricher(mock_storage, max_retries=1, base_backoff=0.01)

        result1 = await enricher.enrich_model("model.test.cache_me", set(), [])
        result2 = await enricher.enrich_model("model.test.cache_me", set(), [])

        assert result1 is result2
        # No queries issued (no bases or aliases provided), but result is cached
        assert isinstance(result1, EnrichmentResult)

    @pytest.mark.asyncio
    async def test_all_retries_exhausted_on_exception(self, mock_storage):
        """After max_retries exceptions, returns empty result (fail-open)."""
        call_count = 0

        def always_fails(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            raise RuntimeError("persistent error")

        mock_storage.execute_raw_query.side_effect = always_fails

        enricher = GraphEnricher(mock_storage, max_retries=3, base_backoff=0.01)
        result = await enricher.enrich_model("model.test.z", {"tbl"}, ["col"])

        # 3 retries for relation hints + 3 retries for column features = 6 calls
        assert call_count == 6
        assert isinstance(result, EnrichmentResult)
        assert result.column_features == {}
        assert result.relation_hints == {}

    @pytest.mark.asyncio
    async def test_partial_failure_returns_partial_result(self, mock_storage):
        """If relation hints succeed but column features fail, partial result returned."""
        call_count = 0

        def succeed_then_fail(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                # First call: relation hints query succeeds
                return MagicMock(rows=[
                    {"base": "tbl", "model_id": "model.test.tbl", "source_id": None, "physical_fqn": None}
                ])
            # Subsequent calls: column features query fails
            raise RuntimeError("column query failed")

        mock_storage.execute_raw_query.side_effect = succeed_then_fail

        enricher = GraphEnricher(mock_storage, max_retries=2, base_backoff=0.01)
        result = await enricher.enrich_model("model.test.partial", {"tbl"}, ["col"])

        assert "tbl" in result.relation_hints
        assert result.column_features == {}
