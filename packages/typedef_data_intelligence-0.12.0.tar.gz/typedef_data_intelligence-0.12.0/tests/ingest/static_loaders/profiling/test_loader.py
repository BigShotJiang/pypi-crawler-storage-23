"""Tests for profiling loader — new fields and backward compatibility."""

from __future__ import annotations

from lineage.backends.data_query.protocol import (
    ColumnProfile,
    TableProfile,
)
from lineage.ingest.static_loaders.profiling.loader import ProfilingLoader


class TestLoadColumnProfileNewFields:
    """Verify new profiling fields are persisted in the graph."""

    def test_load_column_profile_with_new_fields(self, falkordblite_storage) -> None:
        """All five new fields should be stored on ColumnProfile node."""
        storage = falkordblite_storage
        loader = ProfilingLoader(storage)

        # Create a minimal DbtModel node so the HAS_PROFILE edge has a target
        from lineage.backends.lineage.models.dbt import DbtColumn, DbtModel

        model = DbtModel(unique_id="model.test.my_model", name="my_model", materialization="table")
        storage.upsert_node(model)
        col = DbtColumn(name="user_id", parent_id=model.id, parent_label="DbtModel", data_type="VARCHAR")
        storage.upsert_node(col)

        profile = TableProfile(
            database_name="DB",
            schema_name="SCHEMA",
            table_name="my_model",
            row_count=1000,
            column_profiles=[
                ColumnProfile(
                    column_name="user_id",
                    data_type="VARCHAR",
                    distinct_count=990,
                    null_count=0,
                    uniqueness_ratio=0.99,
                    null_rate=0.0,
                    value_pattern="uuid",
                    is_monotonic=False,
                    length_stddev=0.5,
                ),
            ],
            profile_timestamp="2024-01-01T00:00:00Z",
        )

        loader.load_table_profile(model.unique_id, profile)

        # Query the ColumnProfile node back
        result = storage.execute_raw_query(
            "MATCH (cp:ColumnProfile {column_name: 'user_id'}) "
            "RETURN cp.uniqueness_ratio AS ur, cp.null_rate AS nr, "
            "       cp.value_pattern AS vp, cp.is_monotonic AS im, "
            "       cp.length_stddev AS ls"
        )
        assert len(result.rows) == 1
        row = result.rows[0]
        assert row["ur"] == 0.99
        assert row["nr"] == 0.0
        assert row["vp"] == "uuid"
        assert row["im"] is False
        assert row["ls"] == 0.5

    def test_load_column_profile_backward_compat(self, falkordblite_storage) -> None:
        """Old profiles without new fields should load OK (fields are None)."""
        storage = falkordblite_storage
        loader = ProfilingLoader(storage)

        from lineage.backends.lineage.models.dbt import DbtColumn, DbtModel

        model = DbtModel(unique_id="model.test.old_model", name="old_model", materialization="table")
        storage.upsert_node(model)
        col = DbtColumn(name="id", parent_id=model.id, parent_label="DbtModel", data_type="INT")
        storage.upsert_node(col)

        profile = TableProfile(
            database_name="DB",
            schema_name="SCHEMA",
            table_name="old_model",
            row_count=500,
            column_profiles=[
                ColumnProfile(
                    column_name="id",
                    data_type="INT",
                    distinct_count=500,
                    null_count=0,
                    # No new fields
                ),
            ],
            profile_timestamp="2024-01-01T00:00:00Z",
        )

        loader.load_table_profile(model.unique_id, profile)

        # Node should exist without new fields
        result = storage.execute_raw_query(
            "MATCH (cp:ColumnProfile {column_name: 'id'}) "
            "RETURN cp.uniqueness_ratio AS ur, cp.null_rate AS nr, "
            "       cp.value_pattern AS vp, cp.is_monotonic AS im, "
            "       cp.length_stddev AS ls"
        )
        assert len(result.rows) == 1
        row = result.rows[0]
        # All new fields should be None/null
        assert row["ur"] is None
        assert row["nr"] is None
        assert row["vp"] is None
        assert row["im"] is None
        assert row["ls"] is None
