"""Tests for Pass 4: PK scoring and propagation."""

from __future__ import annotations

import pytest
from lineage.ingest.static_loaders.key_lineage.pass4_pk_scoring import (
    PK_CANDIDATE_THRESHOLD,
    score_pk,
)


class TestScorePK:
    """Tests for score_pk() — pure function."""

    @pytest.mark.parametrize(
        "signals,expected_score",
        [
            # Gold: unique + not_null = 0.9
            ({"dbt_unique_test", "dbt_not_null_test"}, 0.9),
            # Silver: profiling_unique + profiling_not_null = 0.7
            ({"profiling_unique", "profiling_not_null"}, 0.7),
            # Bronze: grain_member only = 0.25
            ({"grain_member"}, 0.25),
            # Heuristic: naming only = 0.15
            ({"naming_heuristic"}, 0.15),
            # No signals = 0.0
            (set(), 0.0),
            # All signals = capped at 1.0
            (
                {
                    "dbt_unique_test",
                    "dbt_not_null_test",
                    "profiling_unique",
                    "profiling_not_null",
                    "profiling_monotonic",
                    "pattern_uuid",
                    "pattern_sequential",
                    "grain_member",
                    "naming_heuristic",
                },
                1.0,
            ),
            # Gold unique only = 0.45
            ({"dbt_unique_test"}, 0.45),
            # Grain + naming = 0.4, not a candidate
            ({"grain_member", "naming_heuristic"}, 0.4),
            # Silver unique + grain = 0.6, candidate
            ({"profiling_unique", "grain_member"}, 0.6),
            # New signals: monotonic only = 0.15
            ({"profiling_monotonic"}, 0.15),
            # New signals: pattern_uuid only = 0.20
            ({"pattern_uuid"}, 0.20),
            # New signals: pattern_sequential only = 0.15
            ({"pattern_sequential"}, 0.15),
            # UUID + unique crosses threshold without dbt tests
            ({"profiling_unique", "pattern_uuid"}, 0.55),
            # Sequential + unique + monotonic
            ({"profiling_unique", "pattern_sequential", "profiling_monotonic"}, 0.65),
        ],
    )
    def test_scoring(self, signals: set[str], expected_score: float) -> None:
        assert score_pk(signals) == pytest.approx(expected_score)

    def test_pk_candidate_threshold(self) -> None:
        """Verify the threshold value matches spec."""
        assert PK_CANDIDATE_THRESHOLD == 0.5

    def test_at_threshold(self) -> None:
        """Score exactly at threshold should be a candidate."""
        # grain_member (0.25) + naming_heuristic (0.15) + something = need 0.5
        # profiling_unique (0.35) + naming_heuristic (0.15) = 0.5
        score = score_pk({"profiling_unique", "naming_heuristic"})
        assert score >= PK_CANDIDATE_THRESHOLD

    def test_below_threshold(self) -> None:
        """Score below threshold should not be a candidate."""
        # grain_member (0.25) + naming_heuristic (0.15) = 0.4
        score = score_pk({"grain_member", "naming_heuristic"})
        assert score < PK_CANDIDATE_THRESHOLD
