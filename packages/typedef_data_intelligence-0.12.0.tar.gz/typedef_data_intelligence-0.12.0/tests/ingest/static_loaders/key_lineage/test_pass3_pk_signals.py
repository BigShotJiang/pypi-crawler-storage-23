"""Tests for Pass 3: PK signal collection."""

from __future__ import annotations

from lineage.backends.lineage.models.base import NodeIdentifier
from lineage.backends.lineage.models.edges import HasColumnProfile, HasProfile
from lineage.backends.lineage.models.profiling import (
    ColumnProfile as ColumnProfileNode,
)
from lineage.backends.lineage.models.profiling import (
    TableProfile as TableProfileNode,
)
from lineage.backends.types import NodeLabel
from lineage.ingest.static_loaders.key_lineage.pass3_pk_signals import (
    collect_all_pk_signals,
    collect_dbt_test_signals,
    collect_profiling_signals,
)


class TestCollectDbtTestSignals:
    """Tests for collect_dbt_test_signals()."""

    def test_unique_and_not_null_signals(self, star_schema) -> None:
        """Columns with unique+not_null tests should get both signals."""
        s = star_schema["storage"]
        cols = star_schema["columns"]

        signals = collect_dbt_test_signals(s)

        # dim_customer.customer_id has both tests
        dim_cust_id = cols["dim_cust_id"].id
        assert dim_cust_id in signals
        assert "dbt_unique_test" in signals[dim_cust_id]
        assert "dbt_not_null_test" in signals[dim_cust_id]

        # fct_orders.order_id has both tests
        fct_order_id = cols["fct_order_id"].id
        assert fct_order_id in signals
        assert "dbt_unique_test" in signals[fct_order_id]
        assert "dbt_not_null_test" in signals[fct_order_id]

    def test_no_tests_no_signals(self, star_schema) -> None:
        """Columns without tests should not appear in signals."""
        s = star_schema["storage"]
        cols = star_schema["columns"]

        signals = collect_dbt_test_signals(s)

        # stg_accounts.account_id has no tests
        stg_acct_id = cols["stg_acct_id"].id
        assert stg_acct_id not in signals


def _add_profile(storage, model_id, col_name, row_count, **col_kwargs):
    """Helper to add TableProfile + ColumnProfile + edges for a DbtColumn."""
    tp = TableProfileNode(
        name="test_table",
        database_name="DB",
        schema_name="SCHEMA",
        table_name="test_table",
        row_count=row_count,
        profiled_at="2024-01-01T00:00:00Z",
    )
    storage.upsert_node(tp)

    cp = ColumnProfileNode(
        name=col_name,
        column_name=col_name,
        data_type="VARCHAR",
        null_count=col_kwargs.get("null_count", 0),
        distinct_count=col_kwargs.get("distinct_count", row_count),
        table_profile_id=tp.id,
        uniqueness_ratio=col_kwargs.get("uniqueness_ratio"),
        null_rate=col_kwargs.get("null_rate"),
        is_monotonic=col_kwargs.get("is_monotonic"),
        value_pattern=col_kwargs.get("value_pattern"),
        length_stddev=col_kwargs.get("length_stddev"),
    )
    storage.upsert_node(cp)

    # DbtModel -> TableProfile
    model_ident = NodeIdentifier(id=model_id, node_label=NodeLabel.DBT_MODEL)
    storage.create_edge(model_ident, tp, HasProfile())

    # TableProfile -> ColumnProfile
    storage.create_edge(tp, cp, HasColumnProfile())

    # DbtColumn -> ColumnProfile
    dbt_col_id = f"{model_id}.{col_name.lower()}"
    col_ident = NodeIdentifier(id=dbt_col_id, node_label=NodeLabel.DBT_COLUMN)
    storage.create_edge(col_ident, cp, HasProfile())

    return tp, cp


class TestCollectProfilingSignals:
    """Tests for collect_profiling_signals() with new fields."""

    def test_uniqueness_and_not_null(self, star_schema) -> None:
        """Column with uniqueness_ratio=0.99, null_rate=0 gets both signals."""
        s = star_schema["storage"]
        cols = star_schema["columns"]
        model_id = cols["dim_cust_id"].parent_id
        col_name = cols["dim_cust_id"].name

        _add_profile(
            s, model_id, col_name, row_count=1000,
            uniqueness_ratio=0.99, null_rate=0.0,
        )

        signals = collect_profiling_signals(s)
        col_id = cols["dim_cust_id"].id
        assert col_id in signals
        assert "profiling_unique" in signals[col_id]
        assert "profiling_not_null" in signals[col_id]

    def test_monotonic_signal(self, star_schema) -> None:
        """Column with is_monotonic=True gets profiling_monotonic."""
        s = star_schema["storage"]
        cols = star_schema["columns"]
        model_id = cols["fct_order_id"].parent_id
        col_name = cols["fct_order_id"].name

        _add_profile(
            s, model_id, col_name, row_count=1000,
            uniqueness_ratio=0.5, null_rate=0.1,
            is_monotonic=True,
        )

        signals = collect_profiling_signals(s)
        col_id = cols["fct_order_id"].id
        assert col_id in signals
        assert "profiling_monotonic" in signals[col_id]

    def test_pattern_uuid_signal(self, star_schema) -> None:
        """Column with value_pattern='uuid' gets pattern_uuid."""
        s = star_schema["storage"]
        cols = star_schema["columns"]
        model_id = cols["dim_cust_id"].parent_id
        col_name = cols["dim_cust_id"].name

        _add_profile(
            s, model_id, col_name, row_count=1000,
            uniqueness_ratio=0.999, null_rate=0.0,
            value_pattern="uuid",
        )

        signals = collect_profiling_signals(s)
        col_id = cols["dim_cust_id"].id
        assert "pattern_uuid" in signals[col_id]
        assert "profiling_unique" in signals[col_id]

    def test_pattern_sequential_signal(self, star_schema) -> None:
        """Column with value_pattern='sequential' gets pattern_sequential."""
        s = star_schema["storage"]
        cols = star_schema["columns"]
        model_id = cols["fct_order_id"].parent_id
        col_name = cols["fct_order_id"].name

        _add_profile(
            s, model_id, col_name, row_count=1000,
            uniqueness_ratio=1.0, null_rate=0.0,
            value_pattern="sequential",
        )

        signals = collect_profiling_signals(s)
        col_id = cols["fct_order_id"].id
        assert "pattern_sequential" in signals[col_id]

    def test_backward_compat_without_new_fields(self, star_schema) -> None:
        """Old profiles without new fields fall back to distinct_count/row_count."""
        s = star_schema["storage"]
        cols = star_schema["columns"]
        model_id = cols["dim_cust_id"].parent_id
        col_name = cols["dim_cust_id"].name

        _add_profile(
            s, model_id, col_name, row_count=100,
            distinct_count=100, null_count=0,
            # No new fields set (all None)
        )

        signals = collect_profiling_signals(s)
        col_id = cols["dim_cust_id"].id
        assert col_id in signals
        assert "profiling_unique" in signals[col_id]
        assert "profiling_not_null" in signals[col_id]


class TestCollectAllPKSignals:
    """Tests for collect_all_pk_signals()."""

    def test_aggregation(self, star_schema) -> None:
        """Should aggregate signals from all sub-collectors."""
        s = star_schema["storage"]
        cols = star_schema["columns"]

        result = collect_all_pk_signals(s)

        # At minimum, dbt test signals should be present
        dim_cust_id = cols["dim_cust_id"].id
        assert dim_cust_id in result.column_signals
        assert "dbt_unique_test" in result.column_signals[dim_cust_id]
        assert "dbt_not_null_test" in result.column_signals[dim_cust_id]

    def test_empty_graph(self, falkordblite_storage) -> None:
        result = collect_all_pk_signals(falkordblite_storage)
        assert result.column_signals == {}
        assert result.declared_fks == []
        assert result.model_grain_columns == {}
