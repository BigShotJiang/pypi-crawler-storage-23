"""Tests for KeyLineageOrchestrator."""

from __future__ import annotations

from lineage.backends.lineage.models.base import NodeIdentifier
from lineage.backends.lineage.models.edges import MapsToColumn
from lineage.backends.lineage.models.salesforce import SfField
from lineage.backends.types import NodeLabel
from lineage.ingest.static_loaders.key_lineage.orchestrator import (
    KeyLineageOrchestrator,
)


class TestKeyLineageOrchestrator:
    """Integration tests for the full orchestrator pipeline."""

    def test_build_on_star_schema(self, star_schema) -> None:
        """Full build on a star schema should produce identity classes."""
        s = star_schema["storage"]

        orchestrator = KeyLineageOrchestrator(s)
        result = orchestrator.build(dialect="snowflake")

        # Should find identity classes (account_id chain and order_id chain)
        assert result.identity_class_count >= 1
        assert result.total_members > 0
        assert result.elapsed_seconds > 0

        # Verify IdentityClass nodes in graph
        ic_result = s.execute_raw_query(
            "MATCH (ic:IdentityClass) RETURN ic.entity_name AS name"
        )
        assert ic_result.count >= 1

    def test_build_with_pk_signals(self, star_schema) -> None:
        """Build should detect PK candidates from dbt tests."""
        s = star_schema["storage"]

        orchestrator = KeyLineageOrchestrator(s)
        result = orchestrator.build()

        # dim_customer.customer_id and fct_orders.order_id have unique+not_null tests
        assert result.pk_candidate_count >= 2

        # Verify PK flags on DbtColumn
        pk_result = s.execute_raw_query(
            "MATCH (c:DbtColumn) WHERE c.is_pk_candidate = true "
            "RETURN c.id AS id, c.pk_confidence AS conf"
        )
        assert pk_result.count >= 2

    def test_idempotent_rebuild(self, star_schema) -> None:
        """Running build twice should produce identical results."""
        s = star_schema["storage"]
        orchestrator = KeyLineageOrchestrator(s)

        result1 = orchestrator.build()
        result2 = orchestrator.build()

        assert result1.identity_class_count == result2.identity_class_count
        assert result1.pk_candidate_count == result2.pk_candidate_count
        assert result1.fk_edge_count == result2.fk_edge_count

        # Verify no duplicate nodes
        ic_result = s.execute_raw_query(
            "MATCH (ic:IdentityClass) RETURN count(ic) AS count"
        )
        assert ic_result.rows[0]["count"] == result2.identity_class_count

    def test_cleanup_removes_overlay(self, star_schema) -> None:
        """Cleanup should remove all key lineage artifacts."""
        s = star_schema["storage"]
        orchestrator = KeyLineageOrchestrator(s)

        # Build first
        orchestrator.build()

        # Verify overlay exists
        ic_count = s.execute_raw_query(
            "MATCH (ic:IdentityClass) RETURN count(ic) AS count"
        ).rows[0]["count"]
        assert ic_count > 0

        # Cleanup
        orchestrator._cleanup_existing_overlay()

        # Verify overlay is gone
        ic_count = s.execute_raw_query(
            "MATCH (ic:IdentityClass) RETURN count(ic) AS count"
        ).rows[0]["count"]
        assert ic_count == 0

        fk_count = s.execute_raw_query(
            "MATCH ()-[e:INFERRED_FK]->() RETURN count(e) AS count"
        ).rows[0]["count"]
        assert fk_count == 0

    def test_sf_fields_linked_to_identity_classes(self, star_schema) -> None:
        """SfFields with MapsToColumn to an IC member should join that IC."""
        s = star_schema["storage"]

        # Create an SfField that maps to the source account_id column
        # (which is the root of the account_id IC)
        sf_field = SfField(
            name="AccountId",
            field_api_name="AccountId",
            object_api_name="Opportunity",
            org_key="default",
        )
        s.upsert_node(sf_field)

        # Create MapsToColumn: SfField -> source.sf.account.account_id
        src_acct_col_id = star_schema["columns"]["src_acct_id"].id
        sf_ref = NodeIdentifier(id=sf_field.id, node_label=NodeLabel.SF_FIELD)
        dbt_ref = NodeIdentifier(id=src_acct_col_id, node_label=NodeLabel.DBT_COLUMN)
        s.create_edge(sf_ref, dbt_ref, MapsToColumn(source="heuristic", confidence=1.0))

        # Build key lineage
        orchestrator = KeyLineageOrchestrator(s)
        result = orchestrator.build()

        # SfField should now be linked to an IC
        assert result.sf_field_links >= 1

        ic_result = s.execute_raw_query(
            "MATCH (sf:SfField)-[e:BELONGS_TO_IDENTITY_CLASS]->(ic:IdentityClass) "
            "RETURN sf.id AS sf_id, e.role AS role, ic.entity_name AS entity"
        )
        assert ic_result.count >= 1
        row = ic_result.rows[0]
        assert row["sf_id"] == sf_field.id
        assert row["role"] == "external"

    def test_sf_field_link_idempotent(self, star_schema) -> None:
        """Rebuilding should not duplicate SfField IC links."""
        s = star_schema["storage"]

        sf_field = SfField(
            name="OrderId",
            field_api_name="OrderId",
            object_api_name="Order",
            org_key="default",
        )
        s.upsert_node(sf_field)

        src_order_col_id = star_schema["columns"]["src_order_id"].id
        sf_ref = NodeIdentifier(id=sf_field.id, node_label=NodeLabel.SF_FIELD)
        dbt_ref = NodeIdentifier(id=src_order_col_id, node_label=NodeLabel.DBT_COLUMN)
        s.create_edge(sf_ref, dbt_ref, MapsToColumn(source="heuristic", confidence=1.0))

        orchestrator = KeyLineageOrchestrator(s)
        result1 = orchestrator.build()
        result2 = orchestrator.build()

        assert result1.sf_field_links == result2.sf_field_links

    def test_empty_graph(self, falkordblite_storage) -> None:
        """Build on empty graph should return zeros and not error."""
        orchestrator = KeyLineageOrchestrator(falkordblite_storage)
        result = orchestrator.build()
        assert result.identity_class_count == 0
        assert result.pk_candidate_count == 0
        assert result.fk_edge_count == 0
        assert result.sf_field_links == 0
