"""Tests for Pass 1: Classify DERIVES_FROM edges."""

from __future__ import annotations

from lineage.backends.lineage.models.dbt import CteScope
from lineage.backends.lineage.models.edges import DerivesFrom
from lineage.backends.types import Confidence
from lineage.ingest.static_loaders.key_lineage.pass1_classify_edges import (
    FANOUT_THRESHOLD,
    _expr_references_column,
    classify_edges,
)

from tests.ingest.static_loaders.key_lineage.conftest import (
    make_column,
    make_derives_from,
    make_model,
)


class TestClassifyEdges:
    """Integration tests for classify_edges()."""

    def test_passthrough_is_preserving(self, falkordblite_storage) -> None:
        s = falkordblite_storage
        make_model(s, "model.project.a", "a")
        make_model(s, "model.project.b", "b")
        col_a = make_column(s, "model.project.a", "id")
        col_b = make_column(s, "model.project.b", "id")
        make_derives_from(s, col_a, col_b, "passthrough")

        result = classify_edges(s)
        assert (col_a.id, col_b.id) in result
        assert result[(col_a.id, col_b.id)] is True

    def test_aggregated_is_breaking(self, falkordblite_storage) -> None:
        s = falkordblite_storage
        make_model(s, "model.project.a", "a")
        make_model(s, "model.project.b", "b")
        col_a = make_column(s, "model.project.a", "total")
        col_b = make_column(s, "model.project.b", "amount")
        make_derives_from(s, col_a, col_b, "aggregated")

        result = classify_edges(s)
        assert result[(col_a.id, col_b.id)] is False

    def test_computed_cast_is_preserving(self, falkordblite_storage) -> None:
        s = falkordblite_storage
        make_model(s, "model.project.a", "a")
        make_model(s, "model.project.b", "b")
        col_a = make_column(s, "model.project.a", "id")
        col_b = make_column(s, "model.project.b", "id")
        make_derives_from(s, col_a, col_b, "computed", expr="CAST(id AS VARCHAR)")

        result = classify_edges(s)
        assert result[(col_a.id, col_b.id)] is True

    def test_computed_concat_is_breaking(self, falkordblite_storage) -> None:
        s = falkordblite_storage
        make_model(s, "model.project.a", "a")
        make_model(s, "model.project.b", "b")
        col_a = make_column(s, "model.project.a", "full_name")
        col_b = make_column(s, "model.project.b", "first_name")
        make_derives_from(
            s, col_a, col_b, "computed", expr="CONCAT(first_name, last_name)"
        )

        result = classify_edges(s)
        assert result[(col_a.id, col_b.id)] is False

    def test_multiple_edges(self, falkordblite_storage) -> None:
        s = falkordblite_storage
        make_model(s, "model.project.src", "src")
        make_model(s, "model.project.stg", "stg")
        col_src_id = make_column(s, "model.project.src", "id")
        col_src_name = make_column(s, "model.project.src", "name")
        col_stg_id = make_column(s, "model.project.stg", "id")
        col_stg_name = make_column(s, "model.project.stg", "name")
        make_derives_from(s, col_stg_id, col_src_id, "passthrough")
        make_derives_from(s, col_stg_name, col_src_name, "aggregated")

        result = classify_edges(s)
        assert len(result) == 2
        assert result[(col_stg_id.id, col_src_id.id)] is True
        assert result[(col_stg_name.id, col_src_name.id)] is False

    def test_empty_graph_returns_empty(self, falkordblite_storage) -> None:
        result = classify_edges(falkordblite_storage)
        assert result == {}


class TestFanOutGuard:
    """Tests for fan-out detection on passthrough/source edges."""

    def test_renamed_passthrough_below_threshold_preserving(
        self, falkordblite_storage
    ) -> None:
        """A single rename (fanout=1) should stay preserving."""
        s = falkordblite_storage
        make_model(s, "model.project.src", "src")
        make_model(s, "model.project.stg", "stg")
        upstream = make_column(s, "model.project.src", "account_id")
        downstream = make_column(s, "model.project.stg", "customer_id")
        make_derives_from(s, downstream, upstream, "passthrough")

        result = classify_edges(s)
        assert result[(downstream.id, upstream.id)] is True

    def test_high_fanout_extraction_is_breaking(
        self, falkordblite_storage
    ) -> None:
        """An upstream column fanning out to many differently-named
        downstream columns via passthrough should be demoted to breaking."""
        s = falkordblite_storage
        make_model(s, "model.project.raw", "raw")
        make_model(s, "model.project.parsed", "parsed")
        upstream = make_column(s, "model.project.raw", "cs_uri_query")

        # Create FANOUT_THRESHOLD differently-named downstream columns
        downstream_cols = []
        for name in ["server_id", "version_full", "database_type"]:
            col = make_column(s, "model.project.parsed", name)
            make_derives_from(s, col, upstream, "passthrough")
            downstream_cols.append(col)

        assert len(downstream_cols) >= FANOUT_THRESHOLD

        result = classify_edges(s)
        # All differently-named edges from this upstream should be breaking
        for col in downstream_cols:
            assert result[(col.id, upstream.id)] is False

    def test_high_fanout_same_name_unaffected(
        self, falkordblite_storage
    ) -> None:
        """Same-named passthrough edges from a high-fanout upstream
        should remain preserving (fan-out guard only applies to name changes)."""
        s = falkordblite_storage
        make_model(s, "model.project.raw", "raw")
        make_model(s, "model.project.a", "a")
        make_model(s, "model.project.b", "b")
        make_model(s, "model.project.c", "c")
        make_model(s, "model.project.d", "d")
        upstream = make_column(s, "model.project.raw", "payload")

        # Create several differently-named downstream columns (extraction)
        for name in ["field_a", "field_b", "field_c"]:
            col = make_column(s, "model.project.a", name)
            make_derives_from(s, col, upstream, "passthrough")

        # Also create a same-named passthrough (legitimate propagation)
        same_name_col = make_column(s, "model.project.b", "payload")
        make_derives_from(s, same_name_col, upstream, "passthrough")

        result = classify_edges(s)
        # Same-named edge should still be preserving
        assert result[(same_name_col.id, upstream.id)] is True

    def test_fanout_at_exact_threshold_is_breaking(
        self, falkordblite_storage
    ) -> None:
        """Exactly at the threshold should be breaking."""
        s = falkordblite_storage
        make_model(s, "model.project.raw", "raw")
        make_model(s, "model.project.out", "out")
        upstream = make_column(s, "model.project.raw", "data")

        names = [f"col_{i}" for i in range(FANOUT_THRESHOLD)]
        cols = []
        for name in names:
            col = make_column(s, "model.project.out", name)
            make_derives_from(s, col, upstream, "passthrough")
            cols.append(col)

        result = classify_edges(s)
        for col in cols:
            assert result[(col.id, upstream.id)] is False

    def test_fanout_below_threshold_is_preserving(
        self, falkordblite_storage
    ) -> None:
        """Just below the threshold should remain preserving."""
        s = falkordblite_storage
        make_model(s, "model.project.raw", "raw")
        make_model(s, "model.project.out", "out")
        upstream = make_column(s, "model.project.raw", "data")

        names = [f"col_{i}" for i in range(FANOUT_THRESHOLD - 1)]
        cols = []
        for name in names:
            col = make_column(s, "model.project.out", name)
            make_derives_from(s, col, upstream, "passthrough")
            cols.append(col)

        result = classify_edges(s)
        for col in cols:
            assert result[(col.id, upstream.id)] is True

    def test_source_edges_also_guarded(self, falkordblite_storage) -> None:
        """Source transformation edges should also be subject to fan-out guard."""
        s = falkordblite_storage
        make_model(s, "source.sf.raw", "raw")
        make_model(s, "model.project.stg", "stg")
        upstream = make_column(s, "source.sf.raw", "json_blob")

        for name in ["parsed_a", "parsed_b", "parsed_c"]:
            col = make_column(s, "model.project.stg", name)
            make_derives_from(s, col, upstream, "source")

        result = classify_edges(s)
        for _key, val in result.items():
            assert val is False


class TestExtractionEdges:
    """Tests for extraction transformation type classification."""

    def test_extraction_edges_classified_as_breaking(
        self, falkordblite_storage
    ) -> None:
        """Edges with transformation='extraction' should be classified as breaking."""
        s = falkordblite_storage
        make_model(s, "model.project.raw", "raw")
        make_model(s, "model.project.stg", "stg")
        upstream = make_column(s, "model.project.raw", "fields")
        downstream = make_column(s, "model.project.stg", "project_id")
        make_derives_from(s, downstream, upstream, "extraction")

        result = classify_edges(s)
        assert result[(downstream.id, upstream.id)] is False


class TestExprReferenceGuard:
    """Tests for expression reference guard on computed edges."""

    def test_expr_references_column_positive(self) -> None:
        """Column referenced in expression should return True."""
        assert _expr_references_column(
            'COALESCE("T"."ACCOUNT_ID", 0)', "account_id", "snowflake"
        )

    def test_expr_references_column_negative(self) -> None:
        """Column NOT referenced in expression should return False."""
        assert not _expr_references_column(
            'COALESCE("T"."ACCOUNT_ID", 0)', "server_id", "snowflake"
        )

    def test_expr_references_column_case_insensitive(self) -> None:
        """Matching should be case-insensitive."""
        assert _expr_references_column(
            'COALESCE("T"."account_id", 0)', "ACCOUNT_ID", "snowflake"
        )

    def test_expr_references_column_parse_failure(self) -> None:
        """On parse failure, should return True (conservative)."""
        assert _expr_references_column("NOT VALID SQL !!!", "col", "snowflake")

    def test_expr_references_column_no_refs(self) -> None:
        """Expression with no column refs should return True (conservative)."""
        assert _expr_references_column("42", "col", "snowflake")

    def test_computed_coalesce_referenced_preserving(
        self, falkordblite_storage
    ) -> None:
        """Computed COALESCE where upstream is referenced stays preserving."""
        s = falkordblite_storage
        make_model(s, "model.project.a", "a")
        make_model(s, "model.project.b", "b")
        downstream = make_column(s, "model.project.a", "is_active")
        upstream = make_column(s, "model.project.b", "is_active")
        make_derives_from(
            s, downstream, upstream, "computed",
            expr='COALESCE("T"."IS_ACTIVE", FALSE)',
        )

        result = classify_edges(s)
        assert result[(downstream.id, upstream.id)] is True

    def test_computed_coalesce_unreferenced_breaking(
        self, falkordblite_storage
    ) -> None:
        """Computed COALESCE where upstream is NOT referenced becomes breaking."""
        s = falkordblite_storage
        make_model(s, "model.project.a", "a")
        make_model(s, "model.project.b", "b")
        downstream = make_column(s, "model.project.a", "is_desktop_today")
        upstream = make_column(s, "model.project.b", "server_id")
        make_derives_from(
            s, downstream, upstream, "computed",
            expr='COALESCE("T"."IS_DESKTOP", FALSE)',
        )

        result = classify_edges(s)
        # server_id not in expression → should be breaking
        assert result[(downstream.id, upstream.id)] is False

    def test_computed_cast_referenced_preserving(
        self, falkordblite_storage
    ) -> None:
        """CAST referencing the upstream column stays preserving."""
        s = falkordblite_storage
        make_model(s, "model.project.a", "a")
        make_model(s, "model.project.b", "b")
        downstream = make_column(s, "model.project.a", "created_date")
        upstream = make_column(s, "model.project.b", "created_at")
        make_derives_from(
            s, downstream, upstream, "computed",
            expr='CAST("T"."CREATED_AT" AS DATE)',
        )

        result = classify_edges(s)
        assert result[(downstream.id, upstream.id)] is True


# ---------------------------------------------------------------------------
# Helpers for CTE scope tests
# ---------------------------------------------------------------------------


def _make_cte_scope(storage, model_id: str, scope_name: str) -> CteScope:
    """Create and upsert a CteScope node."""
    node = CteScope(
        name=scope_name,
        model_id=model_id,
        scope_type="cte",
    )
    storage.upsert_node(node)
    return node


def _make_cte_derives_from(
    storage,
    from_node,
    to_node,
    transformation: str = "passthrough",
    expr: str = "",
    column_name: str = "",
    upstream_column: str = "",
) -> None:
    """Create a DERIVES_FROM edge from a CteScope to another node."""
    edge = DerivesFrom(
        confidence=Confidence.DIRECT,
        transformation=transformation,
        expr=expr,
        column_name=column_name,
        upstream_column=upstream_column,
    )
    storage.create_edge(from_node, to_node, edge)


class TestCteScopeRefinement:
    """Tests for CTE scope refinement (third pass) in classify_edges()."""

    def test_passthrough_demoted_by_cte_extraction(
        self, falkordblite_storage
    ) -> None:
        """A DbtColumn edge classified as passthrough should be demoted to
        breaking when the CTE scope for that column shows extraction."""
        s = falkordblite_storage
        model_id = "model.project.stg_events"
        make_model(s, model_id, "stg_events")
        make_model(s, "source.project.raw", "raw")

        # DbtColumn edge: stg_events.project_id -> raw.fields (passthrough)
        downstream = make_column(s, model_id, "project_id")
        upstream = make_column(s, "source.project.raw", "fields")
        make_derives_from(s, downstream, upstream, "passthrough")

        # CteScope: extracted scope has extraction edge for project_id
        cte = _make_cte_scope(s, model_id, "extracted")
        _make_cte_derives_from(
            s, cte, upstream,
            transformation="extraction",
            column_name="project_id",
            upstream_column="fields",
        )

        result = classify_edges(s)
        # Should be demoted to breaking by CTE scope refinement
        assert result[(downstream.id, upstream.id)] is False

    def test_no_cte_data_leaves_unchanged(
        self, falkordblite_storage
    ) -> None:
        """When there is no CTE scope data, preserving edges stay preserving."""
        s = falkordblite_storage
        make_model(s, "model.project.a", "a")
        make_model(s, "model.project.b", "b")
        col_a = make_column(s, "model.project.a", "id")
        col_b = make_column(s, "model.project.b", "id")
        make_derives_from(s, col_a, col_b, "passthrough")

        result = classify_edges(s)
        assert result[(col_a.id, col_b.id)] is True

    def test_multi_cte_chain_breaking(
        self, falkordblite_storage
    ) -> None:
        """CteScope->CteScope->DbtColumn chain where middle hop is breaking
        should demote the DbtColumn edge."""
        s = falkordblite_storage
        model_id = "model.project.fct_events"
        make_model(s, model_id, "fct_events")
        make_model(s, "source.project.raw", "raw")

        # DbtColumn edge: fct_events.pid -> raw.fields (passthrough)
        downstream = make_column(s, model_id, "pid")
        upstream = make_column(s, "source.project.raw", "fields")
        make_derives_from(s, downstream, upstream, "passthrough")

        # CTE chain: outer_cte -> inner_cte -> DbtColumn(fields)
        inner_cte = _make_cte_scope(s, model_id, "inner_cte")
        outer_cte = _make_cte_scope(s, model_id, "outer_cte")

        # inner_cte -> DbtColumn(fields) with extraction
        _make_cte_derives_from(
            s, inner_cte, upstream,
            transformation="extraction",
            column_name="project_id",
            upstream_column="fields",
        )

        # outer_cte -> inner_cte with passthrough
        _make_cte_derives_from(
            s, outer_cte, inner_cte,
            transformation="passthrough",
            column_name="pid",
            upstream_column="project_id",
        )

        result = classify_edges(s)
        # Should be demoted because inner_cte has extraction
        assert result[(downstream.id, upstream.id)] is False
