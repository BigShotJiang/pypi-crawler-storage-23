"""Tests for transformation and expression classification."""

from __future__ import annotations

import pytest
from lineage.ingest.static_loaders.key_lineage.classifier import (
    classify_computed_expr,
    classify_transformation,
    load_overrides,
)


class TestClassifyTransformation:
    """Tests for classify_transformation()."""

    @pytest.mark.parametrize(
        "transformation,expected",
        [
            ("passthrough", "preserving"),
            ("renamed", "preserving"),
            ("group_key", "preserving"),
            ("source", "preserving"),
            ("PASSTHROUGH", "preserving"),  # case-insensitive
            ("  renamed  ", "preserving"),  # whitespace
            ("computed", "computed"),
            ("aggregated", "breaking"),
            ("windowed", "breaking"),
            ("extraction", "breaking"),
            ("unknown", "breaking"),
            ("", "breaking"),
            ("something_else", "breaking"),
        ],
    )
    def test_classification(self, transformation: str, expected: str) -> None:
        assert classify_transformation(transformation) == expected


class TestClassifyComputedExpr:
    """Tests for classify_computed_expr()."""

    @pytest.mark.parametrize(
        "expr,expected",
        [
            # Preserving — Cast
            ("CAST(account_id AS VARCHAR)", "preserving"),
            ("TRY_CAST(x AS INT)", "preserving"),
            ("account_id::VARCHAR", "preserving"),
            # Preserving — allowlist functions
            ("COALESCE(account_id, 'unknown')", "preserving"),
            ("IFNULL(x, 0)", "preserving"),
            ("NVL(x, 0)", "preserving"),
            ("LOWER(name)", "preserving"),
            ("UPPER(name)", "preserving"),
            ("TRIM(name)", "preserving"),
            ("TO_DATE(date_str)", "preserving"),
            ("TO_TIMESTAMP(ts_str)", "preserving"),
            ("TO_VARCHAR(x)", "preserving"),
            # Breaking — Case
            ("CASE WHEN status = 'active' THEN 1 ELSE 0 END", "breaking"),
            # Breaking — arithmetic
            ("price * quantity", "breaking"),
            ("a + b", "breaking"),
            ("revenue - cost", "breaking"),
            # Breaking — Concat
            ("CONCAT(first_name, last_name)", "breaking"),
            ("first_name || last_name", "breaking"),
            # Breaking — DateTrunc
            ("DATE_TRUNC('month', created_at)", "breaking"),
            # Unknown/breaking — empty
            ("", "breaking"),
            ("   ", "breaking"),
        ],
    )
    def test_classification(self, expr: str, expected: str) -> None:
        result = classify_computed_expr(expr, dialect="snowflake")
        assert result == expected, f"classify_computed_expr({expr!r}) = {result!r}, expected {expected!r}"

    def test_parse_failure_returns_breaking(self) -> None:
        """Unparseable SQL should default to breaking."""
        result = classify_computed_expr("NOT VALID SQL {{{", dialect="snowflake")
        assert result == "breaking"

    def test_overrides_take_priority(self) -> None:
        """Project overrides should win over built-in classification."""
        overrides = {"NORMALIZE_ID": "preserving"}
        result = classify_computed_expr(
            "NORMALIZE_ID(account_id)", dialect="snowflake", overrides=overrides
        )
        assert result == "preserving"

    def test_overrides_breaking(self) -> None:
        overrides = {"HASH_KEY": "breaking"}
        result = classify_computed_expr(
            "HASH_KEY(account_id)", dialect="snowflake", overrides=overrides
        )
        assert result == "breaking"


class TestCastWrappingSemiStructured:
    """Tests for CAST-wrapping of semi-structured access in classify_computed_expr()."""

    def test_cast_wrapping_json_extract_is_breaking(self) -> None:
        """CAST(data:key AS VARCHAR) should be breaking (extraction under cast)."""
        result = classify_computed_expr("CAST(data:key AS VARCHAR)", dialect="snowflake")
        assert result == "breaking"

    def test_plain_cast_still_preserving(self) -> None:
        """CAST(account_id AS VARCHAR) should remain preserving."""
        result = classify_computed_expr("CAST(account_id AS VARCHAR)", dialect="snowflake")
        assert result == "preserving"


class TestLoadOverrides:
    """Tests for load_overrides()."""

    def test_none_path_returns_empty(self) -> None:
        assert load_overrides(None) == {}

    def test_missing_file_returns_empty(self, tmp_path) -> None:
        assert load_overrides(tmp_path / "nonexistent.yaml") == {}

    def test_valid_yaml(self, tmp_path) -> None:
        path = tmp_path / "overrides.yaml"
        path.write_text(
            "udf_classifications:\n"
            "  normalize_id: preserving\n"
            "  hash_surrogate: breaking\n"
        )
        result = load_overrides(path)
        assert result == {"NORMALIZE_ID": "preserving", "HASH_SURROGATE": "breaking"}

    def test_invalid_classification_skipped(self, tmp_path) -> None:
        path = tmp_path / "overrides.yaml"
        path.write_text(
            "udf_classifications:\n"
            "  good_func: preserving\n"
            "  bad_func: invalid_value\n"
        )
        result = load_overrides(path)
        assert result == {"GOOD_FUNC": "preserving"}
