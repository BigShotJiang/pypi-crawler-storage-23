"""Shared fixtures for key lineage tests."""

from __future__ import annotations

import pytest
from lineage.backends.lineage.models.dbt import DbtColumn, DbtModel, DbtTest
from lineage.backends.lineage.models.edges import (
    DerivesFrom,
    TestsColumn,
)
from lineage.backends.lineage.protocol import LineageStorage
from lineage.backends.types import Confidence


def make_model(storage: LineageStorage, unique_id: str, name: str) -> DbtModel:
    """Create and upsert a DbtModel."""
    model = DbtModel(
        unique_id=unique_id,
        name=name,
        materialization="table",
    )
    storage.upsert_node(model)
    return model


def make_column(
    storage: LineageStorage,
    parent_id: str,
    col_name: str,
    data_type: str = "VARCHAR",
) -> DbtColumn:
    """Create and upsert a DbtColumn."""
    col = DbtColumn(
        name=col_name,
        parent_id=parent_id,
        parent_label="DbtModel",
        data_type=data_type,
    )
    storage.upsert_node(col)
    return col


def make_derives_from(
    storage: LineageStorage,
    downstream: DbtColumn,
    upstream: DbtColumn,
    transformation: str = "passthrough",
    expr: str = "",
) -> None:
    """Create a DERIVES_FROM edge between two columns."""
    edge = DerivesFrom(
        confidence=Confidence.DIRECT,
        transformation=transformation,
        expr=expr,
    )
    storage.create_edge(downstream, upstream, edge)


def make_test(
    storage: LineageStorage,
    test_name: str,
    column: DbtColumn,
    model_id: str = "",
    unique_id: str = "",
) -> DbtTest:
    """Create a DbtTest and link it to a column via TESTS_COLUMN."""
    if not unique_id:
        unique_id = f"test.project.{test_name}_{column.name}"
    test = DbtTest(
        name=f"{test_name}_{column.name}",
        unique_id=unique_id,
        test_type="generic",
        test_name=test_name,
        column_name=column.name,
        model_id=model_id or column.parent_id,
    )
    storage.upsert_node(test)
    storage.create_edge(test, column, TestsColumn())
    return test


@pytest.fixture
def star_schema(falkordblite_storage):
    """Create a star schema with dim_customer and fct_orders.

    Graph structure:
        source.sf.account.account_id
          ^-- (passthrough) stg_accounts.account_id
                ^-- (renamed) dim_customer.customer_id [PK: unique+not_null tests]
                ^-- (passthrough) fct_orders.customer_id [FK]

        source.sf.order.order_id
          ^-- (passthrough) stg_orders.order_id
                ^-- (passthrough) fct_orders.order_id [PK: unique+not_null tests]
    """
    s = falkordblite_storage

    # Models
    src_accounts = make_model(s, "source.sf.account", "account")
    stg_accounts = make_model(s, "model.project.stg_accounts", "stg_accounts")
    dim_customer = make_model(s, "model.project.dim_customer", "dim_customer")
    src_orders = make_model(s, "source.sf.order", "order")
    stg_orders = make_model(s, "model.project.stg_orders", "stg_orders")
    fct_orders = make_model(s, "model.project.fct_orders", "fct_orders")

    # Columns — account_id chain
    src_acct_id = make_column(s, "source.sf.account", "account_id")
    stg_acct_id = make_column(s, "model.project.stg_accounts", "account_id")
    dim_cust_id = make_column(s, "model.project.dim_customer", "customer_id")
    fct_cust_id = make_column(s, "model.project.fct_orders", "customer_id")

    # Columns — order_id chain
    src_order_id = make_column(s, "source.sf.order", "order_id")
    stg_order_id = make_column(s, "model.project.stg_orders", "order_id")
    fct_order_id = make_column(s, "model.project.fct_orders", "order_id")

    # DERIVES_FROM edges — account_id chain
    make_derives_from(s, stg_acct_id, src_acct_id, "source")
    make_derives_from(s, dim_cust_id, stg_acct_id, "renamed")
    make_derives_from(s, fct_cust_id, stg_acct_id, "passthrough")

    # DERIVES_FROM edges — order_id chain
    make_derives_from(s, stg_order_id, src_order_id, "source")
    make_derives_from(s, fct_order_id, stg_order_id, "passthrough")

    # dbt tests — dim_customer.customer_id has unique + not_null
    make_test(s, "unique", dim_cust_id)
    make_test(s, "not_null", dim_cust_id)

    # dbt tests — fct_orders.order_id has unique + not_null
    make_test(s, "unique", fct_order_id)
    make_test(s, "not_null", fct_order_id)

    return {
        "storage": s,
        "models": {
            "src_accounts": src_accounts,
            "stg_accounts": stg_accounts,
            "dim_customer": dim_customer,
            "src_orders": src_orders,
            "stg_orders": stg_orders,
            "fct_orders": fct_orders,
        },
        "columns": {
            "src_acct_id": src_acct_id,
            "stg_acct_id": stg_acct_id,
            "dim_cust_id": dim_cust_id,
            "fct_cust_id": fct_cust_id,
            "src_order_id": src_order_id,
            "stg_order_id": stg_order_id,
            "fct_order_id": fct_order_id,
        },
    }
