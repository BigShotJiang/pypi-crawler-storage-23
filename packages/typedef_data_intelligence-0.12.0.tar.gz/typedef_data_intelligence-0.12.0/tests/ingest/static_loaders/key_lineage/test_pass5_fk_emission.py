"""Tests for Pass 5: FK inference and emission."""

from __future__ import annotations

from lineage.ingest.static_loaders.key_lineage.pass5_fk_emission import (
    FKCandidate,
    detect_composite_fks,
    infer_cardinality,
)


class TestInferCardinality:
    """Tests for infer_cardinality() — pure function."""

    def test_many_to_one(self) -> None:
        assert infer_cardinality(fk_is_unique=False, pk_is_unique=True) == "many_to_one"

    def test_one_to_one(self) -> None:
        assert infer_cardinality(fk_is_unique=True, pk_is_unique=True) == "one_to_one"

    def test_many_to_many(self) -> None:
        assert infer_cardinality(fk_is_unique=False, pk_is_unique=False) == "many_to_many"


class TestDetectCompositeFKs:
    """Tests for detect_composite_fks()."""

    def test_two_grain_columns_same_target(self) -> None:
        """Two grain columns pointing to same dim should be composite."""
        candidates = [
            FKCandidate(
                fk_column_id="model.project.fct.account_id",
                pk_column_id="model.project.dim.account_id",
                fk_model_id="model.project.fct",
                pk_model_id="model.project.dim",
                identity_class_id="ic::1",
            ),
            FKCandidate(
                fk_column_id="model.project.fct.product_id",
                pk_column_id="model.project.dim.product_id",
                fk_model_id="model.project.fct",
                pk_model_id="model.project.dim",
                identity_class_id="ic::2",
            ),
        ]
        grain_columns = {
            "model.project.fct": ["account_id", "product_id"],
        }

        result = detect_composite_fks(candidates, grain_columns)
        assert all(c.is_composite for c in result)
        assert result[0].composite_group == result[1].composite_group
        assert result[0].composite_group != ""

    def test_single_grain_column_not_composite(self) -> None:
        """Single grain column should not be marked composite."""
        candidates = [
            FKCandidate(
                fk_column_id="model.project.fct.account_id",
                pk_column_id="model.project.dim.account_id",
                fk_model_id="model.project.fct",
                pk_model_id="model.project.dim",
                identity_class_id="ic::1",
            ),
        ]
        grain_columns = {
            "model.project.fct": ["account_id"],
        }

        result = detect_composite_fks(candidates, grain_columns)
        assert not result[0].is_composite

    def test_different_targets_not_composite(self) -> None:
        """Grain columns pointing to different dims should not be composite."""
        candidates = [
            FKCandidate(
                fk_column_id="model.project.fct.account_id",
                pk_column_id="model.project.dim_a.account_id",
                fk_model_id="model.project.fct",
                pk_model_id="model.project.dim_a",
                identity_class_id="ic::1",
            ),
            FKCandidate(
                fk_column_id="model.project.fct.product_id",
                pk_column_id="model.project.dim_b.product_id",
                fk_model_id="model.project.fct",
                pk_model_id="model.project.dim_b",
                identity_class_id="ic::2",
            ),
        ]
        grain_columns = {
            "model.project.fct": ["account_id", "product_id"],
        }

        result = detect_composite_fks(candidates, grain_columns)
        assert not any(c.is_composite for c in result)
