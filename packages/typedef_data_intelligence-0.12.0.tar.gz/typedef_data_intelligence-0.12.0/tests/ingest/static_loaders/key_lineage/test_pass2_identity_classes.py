"""Tests for Pass 2: IdentityClass computation."""

from __future__ import annotations

from lineage.ingest.static_loaders.key_lineage.pass2_identity_classes import (
    IdentityClassResult,
    compute_identity_classes,
    persist_identity_classes,
)


class TestComputeIdentityClasses:
    """Tests for compute_identity_classes()."""

    def test_chain_forms_single_class(self, falkordblite_storage) -> None:
        """A->B->C chain with all preserving should form one IdentityClass."""
        edges = {
            ("a.id", "b.id"): True,  # a derives from b
            ("b.id", "c.id"): True,  # b derives from c
        }
        result = compute_identity_classes(edges, falkordblite_storage)
        assert len(result) == 1
        assert sorted(result[0].member_ids) == ["a.id", "b.id", "c.id"]

    def test_two_disjoint_chains(self, falkordblite_storage) -> None:
        """Two separate preserving chains should form two IdentityClasses."""
        edges = {
            ("a.id", "b.id"): True,
            ("b.id", "c.id"): True,
            ("d.pk", "e.pk"): True,
            ("x.name", "y.name"): False,  # breaking — should not connect
        }
        result = compute_identity_classes(edges, falkordblite_storage)
        assert len(result) == 2
        member_sets = [sorted(ic.member_ids) for ic in result]
        assert ["a.id", "b.id", "c.id"] in member_sets
        assert ["d.pk", "e.pk"] in member_sets

    def test_breaking_edges_excluded(self, falkordblite_storage) -> None:
        """Breaking edges should not form connections."""
        edges = {
            ("a.total", "b.amount"): False,
        }
        result = compute_identity_classes(edges, falkordblite_storage)
        assert len(result) == 0  # Single breaking edge = no components

    def test_singleton_filtered_out(self, falkordblite_storage) -> None:
        """A single preserving node with no partner is not an IdentityClass."""
        # This would only happen if one side of a preserving edge
        # is also in a breaking edge and becomes isolated
        edges = {
            ("a.id", "b.id"): True,
            ("c.name", "d.name"): False,  # breaking
        }
        result = compute_identity_classes(edges, falkordblite_storage)
        # Only {a.id, b.id} should form a class
        assert len(result) == 1

    def test_root_column_is_upstream_most(self, falkordblite_storage) -> None:
        """Root should be the column with no upstream preserving edge."""
        edges = {
            ("downstream.id", "middle.id"): True,
            ("middle.id", "upstream.id"): True,
        }
        result = compute_identity_classes(edges, falkordblite_storage)
        assert len(result) == 1
        assert result[0].root_column_id == "upstream.id"

    def test_entity_name_from_root(self, falkordblite_storage) -> None:
        """entity_name should be the root column's name."""
        edges = {
            ("model.project.stg.account_id", "source.sf.accounts.account_id"): True,
        }
        result = compute_identity_classes(edges, falkordblite_storage)
        assert len(result) == 1
        assert result[0].entity_name == "account_id"

    def test_empty_edges_returns_empty(self, falkordblite_storage) -> None:
        result = compute_identity_classes({}, falkordblite_storage)
        assert result == []

    def test_no_preserving_returns_empty(self, falkordblite_storage) -> None:
        edges = {
            ("a.x", "b.y"): False,
            ("c.x", "d.y"): False,
        }
        result = compute_identity_classes(edges, falkordblite_storage)
        assert result == []


class TestPersistIdentityClasses:
    """Integration tests for persist_identity_classes()."""

    def test_creates_nodes_and_edges(self, star_schema) -> None:
        """Persist should create IdentityClass nodes and membership edges."""
        s = star_schema["storage"]
        cols = star_schema["columns"]

        ic_result = IdentityClassResult(
            cluster_id=f"ic::{cols['src_acct_id'].id}",
            entity_name="account_id",
            source_model="source.sf.account",
            member_ids=[
                cols["src_acct_id"].id,
                cols["stg_acct_id"].id,
                cols["dim_cust_id"].id,
                cols["fct_cust_id"].id,
            ],
            root_column_id=cols["src_acct_id"].id,
        )

        persist_identity_classes([ic_result], s)

        # Verify IdentityClass node exists
        result = s.execute_raw_query(
            "MATCH (ic:IdentityClass) RETURN ic.id AS id, ic.entity_name AS name, "
            "ic.member_count AS count"
        )
        assert result.count == 1
        row = result.rows[0]
        assert row["name"] == "account_id"
        assert row["count"] == 4

        # Verify BELONGS_TO_IDENTITY_CLASS edges
        result = s.execute_raw_query(
            "MATCH (c:DbtColumn)-[:BELONGS_TO_IDENTITY_CLASS]->(ic:IdentityClass) "
            "RETURN count(c) AS edge_count"
        )
        assert result.rows[0]["edge_count"] == 4
