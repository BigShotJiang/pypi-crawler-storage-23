"""Tests for clustering static loaders."""


