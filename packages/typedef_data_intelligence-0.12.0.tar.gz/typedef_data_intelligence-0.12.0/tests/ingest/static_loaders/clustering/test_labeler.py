"""Tests for ClusterLabeler."""

from __future__ import annotations

import asyncio
from unittest.mock import MagicMock, patch

import pytest

from lineage.backends.lineage.models.clustering import ModelEnrichmentData
from lineage.ingest.static_loaders.clustering.enrichment import (
    ClusterLabeler,
    ClusterLabeling,
    ClusterLabelingError,
)


def _make_enrichment(model_id: str, role: str = "dimension", domains: list[str] | None = None) -> ModelEnrichmentData:
    return ModelEnrichmentData(
        model_id=model_id,
        role=role,
        domains=domains or [],
        has_pii=False,
        fact_count=1 if role in ("fact", "mixed") else 0,
        dimension_count=1,
        measure_names=[],
        dimension_names=[],
        fact_names=[],
    )


class _FakeStorage:
    """Minimal fake storage for labeler tests."""

    def get_all_models_with_analysis(self):
        return [
            {"model_id": "model.p.fct_orders", "model_name": "fct_orders", "intent": "Order facts"},
            {"model_id": "model.p.dim_customers", "model_name": "dim_customers", "intent": "Customer dimension"},
        ]


class TestClusterLabeler:

    def test_returns_empty_when_no_clusters(self) -> None:
        """Test that empty clusters returns empty labels."""
        labeler = ClusterLabeler(_FakeStorage())  # type: ignore[arg-type]

        with patch("lineage.ingest.static_loaders.clustering.enrichment.FENIC_AVAILABLE", True):
            session = MagicMock()
            result = asyncio.run(labeler.label_clusters(session, {}, {}))

        assert result == {}

    @patch("lineage.ingest.static_loaders.clustering.enrichment.FENIC_AVAILABLE", False)
    def test_returns_empty_when_fenic_unavailable(self) -> None:
        """Test that labeling is skipped when Fenic is not installed."""
        labeler = ClusterLabeler(_FakeStorage())  # type: ignore[arg-type]
        session = MagicMock()
        clusters = {0: ["model.p.fct_orders"]}
        enrichment = {"model.p.fct_orders": _make_enrichment("model.p.fct_orders", role="fact")}

        result = asyncio.run(labeler.label_clusters(session, clusters, enrichment))

        assert result == {}

    @patch("lineage.ingest.static_loaders.clustering.enrichment.FENIC_AVAILABLE", True)
    def test_label_clusters_success(self) -> None:
        """Test successful cluster labeling with mocked Fenic session."""
        labeler = ClusterLabeler(_FakeStorage())  # type: ignore[arg-type]

        # Mock fenic session and DataFrame pipeline
        mock_session = MagicMock()
        mock_df = MagicMock()
        mock_result_df = MagicMock()
        mock_session.create_dataframe.return_value = mock_df
        mock_df.select.return_value = mock_result_df
        mock_result_df.to_pylist.return_value = [
            {
                "cluster_id": 0,
                "labeling": {
                    "subject_area": "Order Management",
                    "description": "Manages the order lifecycle",
                    "keywords": ["orders", "fulfillment"],
                },
            }
        ]

        clusters = {0: ["model.p.fct_orders", "model.p.dim_customers"]}
        enrichment = {
            "model.p.fct_orders": _make_enrichment("model.p.fct_orders", role="fact", domains=["sales"]),
            "model.p.dim_customers": _make_enrichment("model.p.dim_customers", domains=["customers"]),
        }

        result = asyncio.run(labeler.label_clusters(
            mock_session, clusters, enrichment
        ))

        assert 0 in result
        assert result[0].subject_area == "Order Management"
        assert result[0].keywords == ["orders", "fulfillment"]

    @patch("lineage.ingest.static_loaders.clustering.enrichment.FENIC_AVAILABLE", True)
    def test_label_clusters_raises_on_fenic_error(self) -> None:
        """Test that Fenic errors are wrapped in ClusterLabelingError."""
        labeler = ClusterLabeler(_FakeStorage())  # type: ignore[arg-type]

        mock_session = MagicMock()
        mock_session.create_dataframe.side_effect = RuntimeError("LLM failed")

        clusters = {0: ["model.p.fct_orders"]}
        enrichment = {"model.p.fct_orders": _make_enrichment("model.p.fct_orders")}

        with pytest.raises(ClusterLabelingError):
            asyncio.run(labeler.label_clusters(mock_session, clusters, enrichment))

    @patch("lineage.ingest.static_loaders.clustering.enrichment.FENIC_AVAILABLE", True)
    def test_invalid_labeling_data_skipped(self) -> None:
        """Test that invalid labeling results are silently skipped."""
        labeler = ClusterLabeler(_FakeStorage())  # type: ignore[arg-type]

        mock_session = MagicMock()
        mock_df = MagicMock()
        mock_result_df = MagicMock()
        mock_session.create_dataframe.return_value = mock_df
        mock_df.select.return_value = mock_result_df
        mock_result_df.to_pylist.return_value = [
            {"cluster_id": 0, "labeling": None},  # null labeling
            {"cluster_id": 1, "labeling": {"subject_area": "Valid", "description": "Ok", "keywords": []}},
        ]

        clusters = {
            0: ["model.p.fct_orders"],
            1: ["model.p.dim_customers"],
        }
        enrichment = {
            "model.p.fct_orders": _make_enrichment("model.p.fct_orders"),
            "model.p.dim_customers": _make_enrichment("model.p.dim_customers"),
        }

        result = asyncio.run(labeler.label_clusters(mock_session, clusters, enrichment))

        assert 0 not in result  # null labeling skipped
        assert 1 in result
        assert result[1].subject_area == "Valid"
