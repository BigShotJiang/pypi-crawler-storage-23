"""Tests for model enrichment functionality."""

from __future__ import annotations

import asyncio

from lineage.ingest.static_loaders.clustering.enrichment import ModelEnricher


class _FakeStorage:
    """Minimal fake LineageStorage for testing enrichment call counts."""

    def __init__(self) -> None:
        self.enrichment_calls: int = 0

    def get_model_semantic_enrichment(self, model_id: str) -> dict:
        self.enrichment_calls += 1
        is_fact = model_id.endswith("fact")
        return {
            "measure_count": 1 if is_fact else 0,
            "dimension_count": 1,
            "measure_names": ["total_revenue"] if is_fact else [],
            "dimension_names": ["customer_id"],
            "fact_names": [],
            "has_pii": False,
        }

    def get_all_models_with_analysis(self):  # pragma: no cover
        raise AssertionError("Test should pass models explicitly to avoid extra queries")


def test_enrich_all_models_reuses_counts_from_role_classification() -> None:
    """Test that enrichment reuses counts from role classification and populates lists."""
    storage = _FakeStorage()
    enricher = ModelEnricher(storage)  # type: ignore[arg-type]

    models = [
        {"model_id": "model.project.some_fact", "domains": ["billing"]},
        {"model_id": "model.project.some_dim", "domains": ["customers"]},
    ]

    enriched = asyncio.run(enricher.enrich_all_models(models=models))

    # One enrichment query per model.
    assert storage.enrichment_calls == 2

    assert enriched["model.project.some_fact"].role in {"fact", "mixed"}
    assert enriched["model.project.some_dim"].role in {"dimension", "mixed"}

    # Verify lists are populated
    assert enriched["model.project.some_fact"].measure_names == ["total_revenue"]
    assert enriched["model.project.some_fact"].dimension_names == ["customer_id"]
    assert enriched["model.project.some_dim"].measure_names == []
    assert enriched["model.project.some_dim"].dimension_names == ["customer_id"]


