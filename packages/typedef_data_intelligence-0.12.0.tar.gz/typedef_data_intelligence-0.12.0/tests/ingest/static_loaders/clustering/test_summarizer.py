"""Tests for ClusterSummarizer."""

from __future__ import annotations

import networkx as nx
import pytest

from lineage.backends.lineage.models.clustering import ClusterAnalysis, ModelEnrichmentData
from lineage.ingest.static_loaders.clustering.enrichment import ClusterLabeling
from lineage.ingest.static_loaders.clustering.summarizer import ClusterSummarizer


def _make_enrichment(model_id: str, role: str = "dimension", domains: list[str] | None = None, has_pii: bool = False) -> ModelEnrichmentData:
    return ModelEnrichmentData(
        model_id=model_id,
        role=role,
        domains=domains or [],
        has_pii=has_pii,
        fact_count=1 if role in ("fact", "mixed") else 0,
        dimension_count=1,
        measure_names=["revenue"] if role in ("fact", "mixed") else [],
        dimension_names=["customer_id"],
        fact_names=[],
    )


def _make_graph(edges: list[tuple[str, str, float]]) -> nx.Graph:
    g = nx.Graph()
    for u, v, w in edges:
        g.add_edge(u, v, weight=w)
    return g


class TestClusterSummarizer:

    def test_single_cluster_basic(self) -> None:
        """Test basic summarization of a single cluster."""
        members = ["model.p.fct_orders", "model.p.dim_customers"]
        enrichment = {
            "model.p.fct_orders": _make_enrichment("model.p.fct_orders", role="fact", domains=["sales"]),
            "model.p.dim_customers": _make_enrichment("model.p.dim_customers", role="dimension", domains=["customers"]),
        }
        graph = _make_graph([("model.p.fct_orders", "model.p.dim_customers", 5.0)])
        clusters = {0: members}

        summarizer = ClusterSummarizer()
        results = summarizer.generate_analysis(graph, clusters, enrichment)

        assert len(results) == 1
        analysis = results[0]
        assert isinstance(analysis, ClusterAnalysis)
        assert analysis.cluster_id == 0
        assert analysis.model_count == 2
        assert "model.p.fct_orders" in analysis.fact_model_ids
        assert "model.p.dim_customers" in analysis.dimension_model_ids
        assert analysis.recommended_fact_model == "model.p.fct_orders"
        assert analysis.contains_pii is False

    def test_pii_detection(self) -> None:
        """Test that PII models are correctly identified."""
        enrichment = {
            "model.p.dim_users": _make_enrichment("model.p.dim_users", has_pii=True),
        }
        graph = nx.Graph()
        graph.add_node("model.p.dim_users")
        clusters = {0: ["model.p.dim_users"]}

        results = ClusterSummarizer().generate_analysis(graph, clusters, enrichment)

        assert results[0].contains_pii is True
        assert "model.p.dim_users" in results[0].has_pii_model_ids

    def test_llm_labels_used_when_available(self) -> None:
        """Test that LLM-generated labels override domain-based naming."""
        enrichment = {
            "model.p.fct_orders": _make_enrichment("model.p.fct_orders", role="fact"),
        }
        graph = nx.Graph()
        graph.add_node("model.p.fct_orders")
        labels = {
            0: ClusterLabeling(
                subject_area="Order Management",
                description="Manages order lifecycle",
                keywords=["orders", "fulfillment"],
            )
        }

        results = ClusterSummarizer().generate_analysis(
            graph, {0: ["model.p.fct_orders"]}, enrichment, cluster_labels=labels
        )

        assert results[0].subject_area_name == "Order Management"
        assert results[0].description == "Manages order lifecycle"
        assert results[0].keywords == ["orders", "fulfillment"]

    def test_empty_cluster_dict(self) -> None:
        """Test with no clusters."""
        results = ClusterSummarizer().generate_analysis(nx.Graph(), {}, {})
        assert results == []

    def test_missing_enrichment_skips_cluster(self) -> None:
        """Test that clusters with no enrichment data are skipped."""
        graph = nx.Graph()
        graph.add_node("model.p.orphan")
        clusters = {0: ["model.p.orphan"]}
        enrichment: dict[str, ModelEnrichmentData] = {}

        results = ClusterSummarizer().generate_analysis(graph, clusters, enrichment)
        assert results == []

    def test_partial_enrichment_filters_members(self) -> None:
        """Test that only members with enrichment are included."""
        enrichment = {
            "model.p.fct_orders": _make_enrichment("model.p.fct_orders", role="fact"),
        }
        graph = _make_graph([("model.p.fct_orders", "model.p.missing", 1.0)])
        clusters = {0: ["model.p.fct_orders", "model.p.missing"]}

        results = ClusterSummarizer().generate_analysis(graph, clusters, enrichment)

        assert len(results) == 1
        assert results[0].model_count == 1
        assert results[0].model_ids == ["model.p.fct_orders"]

    def test_domain_extraction(self) -> None:
        """Test that domains are extracted and ordered by frequency."""
        enrichment = {
            "model.p.a": _make_enrichment("model.p.a", domains=["finance", "billing"]),
            "model.p.b": _make_enrichment("model.p.b", domains=["finance", "sales"]),
            "model.p.c": _make_enrichment("model.p.c", domains=["sales"]),
        }
        graph = _make_graph([
            ("model.p.a", "model.p.b", 1.0),
            ("model.p.b", "model.p.c", 1.0),
        ])
        clusters = {0: ["model.p.a", "model.p.b", "model.p.c"]}

        results = ClusterSummarizer().generate_analysis(graph, clusters, enrichment)

        # "finance" and "sales" both appear 2x, "billing" appears 1x
        assert "finance" in results[0].domains
        assert "sales" in results[0].domains

    def test_top_edges_sorted_by_weight(self) -> None:
        """Test that top edges are sorted by weight descending."""
        enrichment = {
            f"model.p.m{i}": _make_enrichment(f"model.p.m{i}") for i in range(3)
        }
        graph = _make_graph([
            ("model.p.m0", "model.p.m1", 1.0),
            ("model.p.m1", "model.p.m2", 5.0),
            ("model.p.m0", "model.p.m2", 3.0),
        ])
        clusters = {0: [f"model.p.m{i}" for i in range(3)]}

        results = ClusterSummarizer().generate_analysis(graph, clusters, enrichment)

        top = results[0].top_edges
        assert len(top) == 3
        assert top[0]["weight"] >= top[1]["weight"] >= top[2]["weight"]
