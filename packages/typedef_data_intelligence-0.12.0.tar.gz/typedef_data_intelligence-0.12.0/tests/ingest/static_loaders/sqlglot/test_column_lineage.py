"""Tests for column-level lineage extraction via extract_column_lineage().

Covers complex expression patterns that previously failed due to the
qualify module-call bug (TD-2084):
- SUM(CASE WHEN ... THEN col END)
- COALESCE(col, 0)
- IFF(condition, col1, col2)
- col * rate (arithmetic)
- NULLIF(col, 0)
- CTE passthrough with aggregation
- Schema-qualified fallback path
"""

import sqlglot
from lineage.ingest.static_loaders.sqlglot.sqlglot_lineage import (
    extract_column_lineage,
)
from lineage.ingest.static_loaders.sqlglot.types import SqlglotSchema, TableEntry


def _make_schema(
    database: str, schema: str, table: str, columns: dict[str, str]
) -> SqlglotSchema:
    """Helper to build a SqlglotSchema from a single table."""
    entry = TableEntry(
        database=database,
        schema=schema,
        table=table,
        columns=tuple(columns.items()),
    )
    return SqlglotSchema(_entries=(entry,))


def _make_multi_schema(tables: list[tuple[str, str, str, dict[str, str]]]) -> SqlglotSchema:
    """Helper to build a SqlglotSchema from multiple tables."""
    entries = []
    for database, schema, table, columns in tables:
        entries.append(
            TableEntry(
                database=database,
                schema=schema,
                table=table,
                columns=tuple(columns.items()),
            )
        )
    return SqlglotSchema(_entries=tuple(entries))


def _source_columns(lineage_map: dict, target_col: str) -> set[str]:
    """Extract source column names from lineage result for a target column."""
    if target_col not in lineage_map:
        return set()
    return {s.column for s in lineage_map[target_col].sources}


def _source_tables(lineage_map: dict, target_col: str) -> set[str]:
    """Extract source table names from lineage result for a target column."""
    if target_col not in lineage_map:
        return set()
    return {s.table for s in lineage_map[target_col].sources if s.table}


class TestCaseWhenInsideAggregation:
    """SUM(CASE WHEN x THEN col END) AS y — y derives from col."""

    def test_sum_case_when_derives_from_column(self) -> None:
        sql = """
        SELECT
            SUM(CASE WHEN status = 'active' THEN amount END) AS active_amount
        FROM orders
        """
        expr = sqlglot.parse_one(sql)
        result = extract_column_lineage(expr)

        assert "active_amount" in result
        sources = _source_columns(result, "active_amount")
        assert "amount" in sources

    def test_sum_case_when_with_else(self) -> None:
        sql = """
        SELECT
            SUM(CASE WHEN status = 'active' THEN amount ELSE 0 END) AS active_amount
        FROM orders
        """
        expr = sqlglot.parse_one(sql)
        result = extract_column_lineage(expr)

        assert "active_amount" in result
        sources = _source_columns(result, "active_amount")
        assert "amount" in sources

    def test_count_case_when(self) -> None:
        sql = """
        SELECT
            COUNT(CASE WHEN status = 'active' THEN 1 END) AS active_count
        FROM orders
        """
        expr = sqlglot.parse_one(sql)
        result = extract_column_lineage(expr)

        assert "active_count" in result


class TestCoalesce:
    """COALESCE(col, 0) — derives from col."""

    def test_coalesce_derives_from_column(self) -> None:
        sql = "SELECT COALESCE(amount, 0) AS safe_amount FROM orders"
        expr = sqlglot.parse_one(sql)
        result = extract_column_lineage(expr)

        assert "safe_amount" in result
        sources = _source_columns(result, "safe_amount")
        assert "amount" in sources

    def test_coalesce_multiple_columns(self) -> None:
        sql = "SELECT COALESCE(primary_email, secondary_email) AS email FROM users"
        expr = sqlglot.parse_one(sql)
        result = extract_column_lineage(expr)

        assert "email" in result
        sources = _source_columns(result, "email")
        assert "primary_email" in sources
        assert "secondary_email" in sources


class TestIff:
    """IFF(condition, col1, col2) — derives from col1 and col2."""

    def test_iff_derives_from_both_columns(self) -> None:
        sql = "SELECT IFF(status = 'active', revenue, 0) AS adj_revenue FROM orders"
        expr = sqlglot.parse_one(sql, read="snowflake")
        result = extract_column_lineage(expr, dialect="snowflake")

        # Snowflake dialect uppercases identifiers
        key = "adj_revenue" if "adj_revenue" in result else "ADJ_REVENUE"
        assert key in result
        sources = {s.column.lower() for s in result[key].sources}
        assert "revenue" in sources

    def test_case_when_equivalent_of_iff(self) -> None:
        sql = """
        SELECT
            CASE WHEN status = 'active' THEN revenue ELSE discount END AS adj_value
        FROM orders
        """
        expr = sqlglot.parse_one(sql)
        result = extract_column_lineage(expr)

        assert "adj_value" in result
        sources = _source_columns(result, "adj_value")
        assert "revenue" in sources
        assert "discount" in sources


class TestArithmeticExpressions:
    """col * rate — derives from col and rate."""

    def test_multiplication_derives_from_both(self) -> None:
        sql = "SELECT quantity * unit_price AS total FROM line_items"
        expr = sqlglot.parse_one(sql)
        result = extract_column_lineage(expr)

        assert "total" in result
        sources = _source_columns(result, "total")
        assert "quantity" in sources
        assert "unit_price" in sources

    def test_addition(self) -> None:
        sql = "SELECT base_price + tax AS total_price FROM orders"
        expr = sqlglot.parse_one(sql)
        result = extract_column_lineage(expr)

        assert "total_price" in result
        sources = _source_columns(result, "total_price")
        assert "base_price" in sources
        assert "tax" in sources


class TestNullif:
    """NULLIF(col, 0) — derives from col."""

    def test_nullif_derives_from_column(self) -> None:
        sql = "SELECT NULLIF(denominator, 0) AS safe_denom FROM metrics"
        expr = sqlglot.parse_one(sql)
        result = extract_column_lineage(expr)

        assert "safe_denom" in result
        sources = _source_columns(result, "safe_denom")
        assert "denominator" in sources


class TestCtePassthrough:
    """CTE with aggregation — lineage traces through CTEs."""

    def test_cte_with_sum_case_when(self) -> None:
        sql = """
        WITH base AS (
            SELECT
                customer_id,
                SUM(CASE WHEN status = 'active' THEN amount END) AS active_amount
            FROM orders
            GROUP BY customer_id
        )
        SELECT customer_id, active_amount FROM base
        """
        expr = sqlglot.parse_one(sql)
        result = extract_column_lineage(expr)

        assert "active_amount" in result
        sources = _source_columns(result, "active_amount")
        assert "amount" in sources

    def test_cte_with_coalesce(self) -> None:
        sql = """
        WITH cleaned AS (
            SELECT id, COALESCE(value, 0) AS clean_value FROM raw_data
        )
        SELECT id, clean_value FROM cleaned
        """
        expr = sqlglot.parse_one(sql)
        result = extract_column_lineage(expr)

        assert "clean_value" in result
        sources = _source_columns(result, "clean_value")
        assert "value" in sources


class TestSchemaQualifiedFallback:
    """Tests the qualify.qualify() fallback path with a schema dict."""

    def test_qualify_fallback_with_schema(self) -> None:
        """When is_pre_qualified=False and schema is provided, qualify.qualify() runs."""
        schema = _make_schema(
            "test_db", "test_schema", "orders",
            {"id": "int", "amount": "float", "status": "varchar"},
        )
        sql = "SELECT SUM(CASE WHEN status = 'active' THEN amount END) AS active_amount FROM test_schema.orders"
        expr = sqlglot.parse_one(sql)
        result = extract_column_lineage(expr, schema=schema, is_pre_qualified=False)

        assert "active_amount" in result
        sources = _source_columns(result, "active_amount")
        assert "amount" in sources

    def test_qualify_fallback_select_star_expansion(self) -> None:
        """qualify.qualify() should expand SELECT * when schema is provided."""
        schema = _make_schema(
            "test_db", "test_schema", "orders",
            {"id": "int", "amount": "float"},
        )
        sql = "SELECT * FROM test_schema.orders"
        expr = sqlglot.parse_one(sql)
        result = extract_column_lineage(expr, schema=schema, is_pre_qualified=False)

        # After qualify, SELECT * should expand to id, amount
        assert "id" in result
        assert "amount" in result

    def test_pre_qualified_skips_qualify(self) -> None:
        """When is_pre_qualified=True, qualify.qualify() is not called."""
        sql = "SELECT amount * 2 AS doubled FROM orders"
        expr = sqlglot.parse_one(sql)
        result = extract_column_lineage(expr, is_pre_qualified=True)

        assert "doubled" in result
        sources = _source_columns(result, "doubled")
        assert "amount" in sources


class TestComplexExpressionCombinations:
    """Combinations of the above patterns in a single query."""

    def test_mixed_aggregations_and_expressions(self) -> None:
        sql = """
        SELECT
            customer_id,
            SUM(CASE WHEN status = 'active' THEN amount ELSE 0 END) AS active_revenue,
            COALESCE(SUM(discount), 0) AS total_discount,
            COUNT(CASE WHEN status = 'churned' THEN 1 END) AS churn_count
        FROM orders
        GROUP BY customer_id
        """
        expr = sqlglot.parse_one(sql)
        result = extract_column_lineage(expr)

        assert "active_revenue" in result
        assert "amount" in _source_columns(result, "active_revenue")

        assert "total_discount" in result
        assert "discount" in _source_columns(result, "total_discount")

        assert "churn_count" in result

    def test_nested_case_when(self) -> None:
        sql = """
        SELECT
            CASE
                WHEN region = 'US' THEN COALESCE(us_revenue, 0)
                WHEN region = 'EU' THEN COALESCE(eu_revenue, 0)
                ELSE 0
            END AS regional_revenue
        FROM revenue_by_region
        """
        expr = sqlglot.parse_one(sql)
        result = extract_column_lineage(expr)

        assert "regional_revenue" in result
        sources = _source_columns(result, "regional_revenue")
        assert "us_revenue" in sources
        assert "eu_revenue" in sources
