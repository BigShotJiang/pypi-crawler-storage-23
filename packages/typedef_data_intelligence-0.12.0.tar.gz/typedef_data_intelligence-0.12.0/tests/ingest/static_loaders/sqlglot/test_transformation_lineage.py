"""Comprehensive tests for the transformation-aware scope-level column lineage engine."""

from __future__ import annotations

import pytest
from lineage.ingest.static_loaders.sqlglot.transformation_lineage import (
    ColumnRef,
    ColumnTransformation,
    ScopeAnalysis,
    TransformationGraph,
    TransformationType,
    analyze_query,
)
from lineage.ingest.static_loaders.sqlglot.types import SqlglotSchema, TableEntry

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_schema(*tables: tuple[str, str, str, dict[str, str]]) -> SqlglotSchema:
    """Build a SqlglotSchema from (database, schema, table, {col: type}) tuples."""
    entries = []
    for db, schema, table, cols in tables:
        entries.append(
            TableEntry(
                database=db,
                schema=schema,
                table=table,
                columns=tuple(cols.items()),
            )
        )
    return SqlglotSchema(_entries=tuple(entries))


def _col_names(graph: TransformationGraph) -> list[str]:
    """Get output column names from a TransformationGraph."""
    return [ct.output_ref.column_name for ct in graph.output_columns]


def _col_types(graph: TransformationGraph) -> dict[str, TransformationType]:
    """Get output column name -> TransformationType mapping."""
    return {ct.output_ref.column_name: ct.transformation for ct in graph.output_columns}


def _find_col(graph: TransformationGraph, name: str) -> ColumnTransformation | None:
    """Find a specific output column transformation by name."""
    for ct in graph.output_columns:
        if ct.output_ref.column_name.lower() == name.lower():
            return ct
    return None


# ===========================================================================
# Phase 1: Data Model + Basic Classification
# ===========================================================================


class TestDataModel:
    """Test that data model classes are well-formed."""

    def test_column_ref_frozen(self):
        ref = ColumnRef("scope1", "col1")
        assert ref.scope_name == "scope1"
        assert ref.column_name == "col1"
        # frozen dataclass
        with pytest.raises(AttributeError):
            ref.scope_name = "other"  # type: ignore

    def test_transformation_type_values(self):
        assert TransformationType.PASSTHROUGH.value == "passthrough"
        assert TransformationType.AGGREGATED.value == "aggregated"
        assert TransformationType.DROPPED.value == "dropped"

    def test_extraction_enum_member(self):
        assert TransformationType.EXTRACTION.value == "extraction"

    def test_column_transformation_defaults(self):
        ct = ColumnTransformation(
            output_ref=ColumnRef("s", "c"),
            transformation=TransformationType.PASSTHROUGH,
        )
        assert ct.data_deps == []
        assert ct.control_deps == []
        assert ct.function_name is None
        assert ct.expression_sql is None

    def test_scope_analysis_defaults(self):
        sa = ScopeAnalysis(scope_name="test", scope_type="select")
        assert sa.columns == []
        assert sa.shadow_columns == []
        assert sa.has_grain_change is False
        assert sa.is_set_operation is False

    def test_transformation_graph_defaults(self):
        tg = TransformationGraph()
        assert tg.scopes == {}
        assert tg.output_columns == []
        assert tg.chains == {}


class TestBasicClassification:
    """Phase 1: simple SELECT, aliased, arithmetic, CAST, literal."""

    def test_simple_passthrough(self):
        """Simple SELECT (single table, multiple columns) -> all PASSTHROUGH."""
        schema = _make_schema(
            ("", "", "orders", {"id": "INT", "name": "VARCHAR", "amount": "DECIMAL"})
        )
        graph = analyze_query(
            "SELECT id, name, amount FROM orders",
            schema=schema,
        )
        types = _col_types(graph)
        assert types["id"] == TransformationType.PASSTHROUGH
        assert types["name"] == TransformationType.PASSTHROUGH
        assert types["amount"] == TransformationType.PASSTHROUGH

    def test_aliased_column_renamed(self):
        """Aliased column -> RENAMED."""
        schema = _make_schema(("", "", "orders", {"id": "INT", "name": "VARCHAR"}))
        graph = analyze_query(
            "SELECT id, name AS customer_name FROM orders",
            schema=schema,
        )
        types = _col_types(graph)
        assert types["id"] == TransformationType.PASSTHROUGH
        assert types["customer_name"] == TransformationType.RENAMED

    def test_arithmetic_computed(self):
        """Arithmetic expression (a + b) -> COMPUTED."""
        schema = _make_schema(("", "", "orders", {"a": "INT", "b": "INT"}))
        graph = analyze_query(
            "SELECT a + b AS total FROM orders",
            schema=schema,
        )
        ct = _find_col(graph, "total")
        assert ct is not None
        assert ct.transformation == TransformationType.COMPUTED
        assert len(ct.data_deps) == 2

    def test_cast_computed(self):
        """CAST expression -> COMPUTED."""
        schema = _make_schema(("", "", "orders", {"id": "INT"}))
        graph = analyze_query(
            "SELECT CAST(id AS VARCHAR) AS id_str FROM orders",
            schema=schema,
        )
        ct = _find_col(graph, "id_str")
        assert ct is not None
        assert ct.transformation == TransformationType.COMPUTED

    def test_literal_source(self):
        """Literal / function with no columns -> SOURCE."""
        graph = analyze_query("SELECT 1 AS one, 'hello' AS greeting")
        types = _col_types(graph)
        assert types["one"] == TransformationType.SOURCE
        assert types["greeting"] == TransformationType.SOURCE


# ===========================================================================
# Phase 2: Scope Traversal + CTE Resolution
# ===========================================================================


class TestScopeTraversal:
    """Phase 2: CTE chains, nested CTEs, FROM subquery, UNION."""

    def test_single_cte_chain(self):
        """Single CTE chain -> correct scope count, correct column refs."""
        sql = """
        WITH base AS (
            SELECT id, amount FROM orders
        )
        SELECT id, amount FROM base
        """
        schema = _make_schema(("", "", "orders", {"id": "INT", "amount": "DECIMAL"}))
        graph = analyze_query(sql, schema=schema)
        assert "base" in graph.scopes
        assert "__root__" in graph.scopes
        assert len(graph.scopes) == 2
        # Root columns should reference base scope
        types = _col_types(graph)
        assert types["id"] == TransformationType.PASSTHROUGH
        assert types["amount"] == TransformationType.PASSTHROUGH

    def test_nested_ctes(self):
        """Nested CTEs -> dependency order, upstream resolution."""
        sql = """
        WITH step1 AS (
            SELECT id, amount FROM orders
        ),
        step2 AS (
            SELECT id, amount * 2 AS doubled FROM step1
        )
        SELECT id, doubled FROM step2
        """
        schema = _make_schema(("", "", "orders", {"id": "INT", "amount": "DECIMAL"}))
        graph = analyze_query(sql, schema=schema)
        assert "step1" in graph.scopes
        assert "step2" in graph.scopes
        assert "__root__" in graph.scopes
        assert len(graph.scopes) == 3

        # step2 should have id as PASSTHROUGH and doubled as COMPUTED
        step2 = graph.scopes["step2"]
        step2_types = {
            ct.output_ref.column_name: ct.transformation for ct in step2.columns
        }
        assert step2_types["id"] == TransformationType.PASSTHROUGH
        assert step2_types["doubled"] == TransformationType.COMPUTED

    def test_from_subquery(self):
        """FROM subquery -> subquery scope detected."""
        sql = """
        SELECT sq.id, sq.total
        FROM (
            SELECT id, amount AS total FROM orders
        ) AS sq
        """
        schema = _make_schema(("", "", "orders", {"id": "INT", "amount": "DECIMAL"}))
        graph = analyze_query(sql, schema=schema)
        # Should have a subquery scope "sq" and root
        assert "sq" in graph.scopes
        assert "__root__" in graph.scopes

    def test_union_branches(self):
        """UNION branches -> set scope merging."""
        sql = """
        SELECT id, name FROM customers
        UNION ALL
        SELECT id, name FROM suppliers
        """
        schema = _make_schema(
            ("", "", "customers", {"id": "INT", "name": "VARCHAR"}),
            ("", "", "suppliers", {"id": "INT", "name": "VARCHAR"}),
        )
        graph = analyze_query(sql, schema=schema)
        # Should have output columns
        assert len(graph.output_columns) > 0

    def test_dbt_cte_pattern(self):
        """__dbt__cte__* pattern -> ephemeral CTE detected in scope names."""
        sql = """
        WITH __dbt__cte__stg_orders AS (
            SELECT id, amount FROM raw_orders
        )
        SELECT id, amount FROM __dbt__cte__stg_orders
        """
        schema = _make_schema(
            ("", "", "raw_orders", {"id": "INT", "amount": "DECIMAL"})
        )
        graph = analyze_query(sql, schema=schema)
        assert "__dbt__cte__stg_orders" in graph.scopes


# ===========================================================================
# Phase 3: Aggregation + Window Classification
# ===========================================================================


class TestAggregationAndWindows:
    """Phase 3: SUM/COUNT/AVG, GROUP BY, window functions, grain change."""

    def test_sum_aggregated(self):
        """SUM -> AGGREGATED with function name."""
        schema = _make_schema(
            ("", "", "orders", {"customer_id": "INT", "amount": "DECIMAL"})
        )
        graph = analyze_query(
            "SELECT customer_id, SUM(amount) AS total FROM orders GROUP BY customer_id",
            schema=schema,
        )
        ct = _find_col(graph, "total")
        assert ct is not None
        assert ct.transformation == TransformationType.AGGREGATED
        assert ct.function_name is not None
        assert "SUM" in ct.function_name.upper()

    def test_count_aggregated(self):
        """COUNT -> AGGREGATED."""
        schema = _make_schema(("", "", "orders", {"id": "INT"}))
        graph = analyze_query(
            "SELECT COUNT(id) AS cnt FROM orders",
            schema=schema,
        )
        ct = _find_col(graph, "cnt")
        assert ct is not None
        assert ct.transformation == TransformationType.AGGREGATED

    def test_group_by_reclassification(self):
        """GROUP BY columns -> GROUP_KEY reclassification."""
        schema = _make_schema(
            ("", "", "orders", {"customer_id": "INT", "amount": "DECIMAL"})
        )
        graph = analyze_query(
            "SELECT customer_id, SUM(amount) AS total FROM orders GROUP BY customer_id",
            schema=schema,
        )
        ct = _find_col(graph, "customer_id")
        assert ct is not None
        assert ct.transformation == TransformationType.GROUP_KEY

    def test_window_function(self):
        """Window function (ROW_NUMBER, SUM OVER) -> WINDOWED."""
        schema = _make_schema(
            ("", "", "orders", {"id": "INT", "customer_id": "INT", "amount": "DECIMAL"})
        )
        graph = analyze_query(
            "SELECT id, ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY amount) AS rn FROM orders",
            schema=schema,
        )
        ct = _find_col(graph, "rn")
        assert ct is not None
        assert ct.transformation == TransformationType.WINDOWED

    def test_grain_change_detection(self):
        """GROUP BY causes grain change."""
        schema = _make_schema(
            ("", "", "orders", {"customer_id": "INT", "amount": "DECIMAL"})
        )
        graph = analyze_query(
            "SELECT customer_id, SUM(amount) AS total FROM orders GROUP BY customer_id",
            schema=schema,
        )
        root = graph.scopes.get("__root__")
        assert root is not None
        assert root.has_grain_change is True


# ===========================================================================
# Phase 4: Shadow Columns + Clause Analysis
# ===========================================================================


class TestShadowColumns:
    """Phase 4: WHERE, JOIN ON, HAVING, ORDER BY, PARTITION BY, dropped columns."""

    def test_where_filter_predicate(self):
        """WHERE filter -> FILTER_PREDICATE shadow."""
        schema = _make_schema(
            ("", "", "orders", {"id": "INT", "status": "VARCHAR", "amount": "DECIMAL"})
        )
        graph = analyze_query(
            "SELECT id, amount FROM orders WHERE status = 'active'",
            schema=schema,
        )
        root = graph.scopes["__root__"]
        filter_shadows = [
            s
            for s in root.shadow_columns
            if s.transformation == TransformationType.FILTER_PREDICATE
        ]
        assert len(filter_shadows) > 0
        # status should appear as filter predicate
        filter_col_names = {
            dep.column_name for s in filter_shadows for dep in s.data_deps
        }
        assert "status" in filter_col_names

    def test_join_key_shadow(self):
        """JOIN ON condition -> JOIN_KEY shadow."""
        schema = _make_schema(
            ("", "", "orders", {"id": "INT", "customer_id": "INT"}),
            ("", "", "customers", {"id": "INT", "name": "VARCHAR"}),
        )
        graph = analyze_query(
            "SELECT o.id, c.name FROM orders o JOIN customers c ON o.customer_id = c.id",
            schema=schema,
        )
        root = graph.scopes["__root__"]
        join_shadows = [
            s
            for s in root.shadow_columns
            if s.transformation == TransformationType.JOIN_KEY
        ]
        assert len(join_shadows) > 0

    def test_having_filter(self):
        """HAVING filter -> FILTER_PREDICATE shadow."""
        schema = _make_schema(
            ("", "", "orders", {"customer_id": "INT", "amount": "DECIMAL"})
        )
        graph = analyze_query(
            "SELECT customer_id, SUM(amount) AS total FROM orders GROUP BY customer_id HAVING SUM(amount) > 100",
            schema=schema,
        )
        root = graph.scopes["__root__"]
        having_shadows = [
            s
            for s in root.shadow_columns
            if s.transformation == TransformationType.FILTER_PREDICATE
            and "__having__" in s.output_ref.column_name
        ]
        assert len(having_shadows) > 0

    def test_order_by_shadow(self):
        """ORDER BY -> ORDER_KEY shadow."""
        schema = _make_schema(("", "", "orders", {"id": "INT", "amount": "DECIMAL"}))
        graph = analyze_query(
            "SELECT id FROM orders ORDER BY amount",
            schema=schema,
        )
        root = graph.scopes["__root__"]
        order_shadows = [
            s
            for s in root.shadow_columns
            if s.transformation == TransformationType.ORDER_KEY
        ]
        assert len(order_shadows) > 0

    def test_window_partition_shadow(self):
        """PARTITION BY -> WINDOW_PARTITION shadow."""
        schema = _make_schema(
            ("", "", "orders", {"id": "INT", "customer_id": "INT", "amount": "DECIMAL"})
        )
        graph = analyze_query(
            "SELECT id, SUM(amount) OVER (PARTITION BY customer_id) AS running FROM orders",
            schema=schema,
        )
        root = graph.scopes["__root__"]
        partition_shadows = [
            s
            for s in root.shadow_columns
            if s.transformation == TransformationType.WINDOW_PARTITION
        ]
        assert len(partition_shadows) > 0

    def test_qualify_filter_predicate(self):
        """QUALIFY clause -> FILTER_PREDICATE shadow."""
        schema = _make_schema(
            ("", "", "orders", {"id": "INT", "customer_id": "INT", "amount": "DECIMAL"})
        )
        graph = analyze_query(
            "SELECT id, customer_id, amount FROM orders "
            "QUALIFY ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY amount DESC) = 1",
            schema=schema,
            dialect="snowflake",
        )
        root = graph.scopes["__root__"]
        qualify_shadows = [
            s
            for s in root.shadow_columns
            if s.transformation == TransformationType.FILTER_PREDICATE
            and "__qualify__" in s.output_ref.column_name
        ]
        assert len(qualify_shadows) > 0
        # customer_id and/or amount should appear as deps (from the window spec inside QUALIFY)
        dep_col_names = {
            dep.column_name for s in qualify_shadows for dep in s.data_deps
        }
        assert len(dep_col_names) > 0

    def test_dropped_column_detection(self):
        """Column dropped between CTEs -> DROPPED detection."""
        sql = """
        WITH base AS (
            SELECT id, name, amount FROM orders
        )
        SELECT id, amount FROM base
        """
        schema = _make_schema(
            ("", "", "orders", {"id": "INT", "name": "VARCHAR", "amount": "DECIMAL"})
        )
        graph = analyze_query(sql, schema=schema)
        root = graph.scopes["__root__"]
        dropped = [
            s
            for s in root.shadow_columns
            if s.transformation == TransformationType.DROPPED
        ]
        # 'name' should be dropped
        dropped_names = {dep.column_name for s in dropped for dep in s.data_deps}
        assert "name" in dropped_names

    def test_control_dependency_linking(self):
        """Output columns get control deps from filter/join shadows."""
        schema = _make_schema(
            ("", "", "orders", {"id": "INT", "status": "VARCHAR", "amount": "DECIMAL"})
        )
        graph = analyze_query(
            "SELECT id, amount FROM orders WHERE status = 'active'",
            schema=schema,
        )
        ct = _find_col(graph, "id")
        assert ct is not None
        # Should have control dependency from the WHERE clause
        assert len(ct.control_deps) > 0

    def test_non_projected_column_in_where(self):
        """Column used only in WHERE, not projected -> tracked as shadow."""
        schema = _make_schema(("", "", "orders", {"id": "INT", "status": "VARCHAR"}))
        graph = analyze_query(
            "SELECT id FROM orders WHERE status = 'active'",
            schema=schema,
        )
        root = graph.scopes["__root__"]
        # status should be a filter predicate shadow
        filter_shadows = [
            s
            for s in root.shadow_columns
            if s.transformation == TransformationType.FILTER_PREDICATE
        ]
        shadow_col_names = {
            dep.column_name for s in filter_shadows for dep in s.data_deps
        }
        assert "status" in shadow_col_names
        # status should NOT be in output columns
        output_names = {ct.output_ref.column_name for ct in root.columns}
        assert "status" not in output_names


# ===========================================================================
# Phase 5: Chain Building
# ===========================================================================


class TestChainBuilding:
    """Phase 5: Multi-step CTE chains -> complete source-to-output path."""

    def test_multi_step_chain(self):
        """Multi-step CTE chain -> complete source-to-output path."""
        sql = """
        WITH step1 AS (
            SELECT id, amount FROM orders
        ),
        step2 AS (
            SELECT id, amount * 2 AS doubled FROM step1
        )
        SELECT id, doubled FROM step2
        """
        schema = _make_schema(("", "", "orders", {"id": "INT", "amount": "DECIMAL"}))
        graph = analyze_query(sql, schema=schema)

        # Chain for 'id' should trace through step2 -> step1 -> orders
        assert "id" in graph.chains
        chain = graph.chains["id"]
        assert len(chain) >= 2  # At least step1 and root

        # Chain for 'doubled' should show COMPUTED transformation
        assert "doubled" in graph.chains
        doubled_chain = graph.chains["doubled"]
        transformations = [ct.transformation for ct in doubled_chain]
        assert TransformationType.COMPUTED in transformations

    def test_chain_records_transformations(self):
        """Transformation at each boundary recorded in chain."""
        sql = """
        WITH base AS (
            SELECT customer_id, SUM(amount) AS total FROM orders GROUP BY customer_id
        )
        SELECT customer_id, total FROM base
        """
        schema = _make_schema(
            ("", "", "orders", {"customer_id": "INT", "amount": "DECIMAL"})
        )
        graph = analyze_query(sql, schema=schema)

        # 'total' chain should include AGGREGATED at the CTE boundary
        assert "total" in graph.chains
        chain = graph.chains["total"]
        chain_types = [ct.transformation for ct in chain]
        assert TransformationType.AGGREGATED in chain_types


# ===========================================================================
# Phase 6: Edge Cases
# ===========================================================================


class TestEdgeCases:
    """Phase 6: Recursive CTE, SELECT *, no CTEs, CASE, subquery in WHERE."""

    def test_recursive_cte_anchor_only(self):
        """Recursive CTE -> only anchor member analyzed, no cycles."""
        sql = """
        WITH RECURSIVE cte AS (
            SELECT 1 AS n
            UNION ALL
            SELECT n + 1 FROM cte WHERE n < 10
        )
        SELECT n FROM cte
        """
        graph = analyze_query(sql)
        # Should complete without error (no infinite loop)
        assert "__root__" in graph.scopes
        assert len(graph.output_columns) > 0

    def test_select_star_with_schema(self):
        """SELECT * expansion with schema."""
        schema = _make_schema(
            ("", "", "orders", {"id": "INT", "name": "VARCHAR", "amount": "DECIMAL"})
        )
        graph = analyze_query("SELECT * FROM orders", schema=schema)
        # Should have all 3 columns expanded
        col_names = _col_names(graph)
        assert len(col_names) >= 3

    def test_no_ctes_simple_query(self):
        """No CTEs (simple query) -> single scope, backward compat."""
        schema = _make_schema(("", "", "orders", {"id": "INT", "amount": "DECIMAL"}))
        graph = analyze_query(
            "SELECT id, amount FROM orders",
            schema=schema,
        )
        assert "__root__" in graph.scopes
        assert len(graph.scopes) == 1
        assert len(graph.output_columns) == 2

    def test_complex_case_expression(self):
        """Complex CASE expression -> COMPUTED."""
        schema = _make_schema(
            ("", "", "orders", {"status": "VARCHAR", "amount": "DECIMAL"})
        )
        graph = analyze_query(
            "SELECT CASE WHEN status = 'active' THEN amount ELSE 0 END AS adj_amount FROM orders",
            schema=schema,
        )
        ct = _find_col(graph, "adj_amount")
        assert ct is not None
        assert ct.transformation == TransformationType.COMPUTED

    def test_subquery_in_where(self):
        """Subquery in WHERE (EXISTS) -> no crash, shadows tracked."""
        schema = _make_schema(
            ("", "", "orders", {"id": "INT", "customer_id": "INT"}),
            ("", "", "vip_customers", {"id": "INT"}),
        )
        sql = """
        SELECT id FROM orders
        WHERE EXISTS (SELECT 1 FROM vip_customers WHERE vip_customers.id = orders.customer_id)
        """
        graph = analyze_query(sql, schema=schema)
        # Should complete without error
        assert len(graph.output_columns) > 0

    def test_empty_result_on_parse_failure(self):
        """Invalid SQL -> empty TransformationGraph (graceful degradation)."""
        graph = analyze_query("THIS IS NOT SQL AT ALL", dialect=None)
        # Should not crash; may return empty graph
        assert isinstance(graph, TransformationGraph)

    def test_multiple_aggregations(self):
        """Multiple aggregations in same query."""
        schema = _make_schema(
            (
                "",
                "",
                "orders",
                {"customer_id": "INT", "amount": "DECIMAL", "qty": "INT"},
            )
        )
        graph = analyze_query(
            "SELECT customer_id, SUM(amount) AS total, AVG(qty) AS avg_qty "
            "FROM orders GROUP BY customer_id",
            schema=schema,
        )
        types = _col_types(graph)
        assert types["total"] == TransformationType.AGGREGATED
        assert types["avg_qty"] == TransformationType.AGGREGATED
        assert types["customer_id"] == TransformationType.GROUP_KEY


# ===========================================================================
# Integration: Builder + Graph Edges
# ===========================================================================


class TestBuilderIntegration:
    """Integration test: builder uses transformation engine correctly."""

    def test_extract_column_lineage_for_model_basic(self):
        """Basic model extraction via builder function produces edges."""
        from lineage.ingest.static_loaders.dbt.builder import (
            _extract_column_lineage_for_model,
        )
        from lineage.ingest.static_loaders.dbt.dbt_loader import (
            DbtColumn as LoaderDbtColumn,
        )

        from tests.test_helpers import (
            create_mock_artifacts,
            create_mock_model,
            create_mock_source,
        )

        source = create_mock_source(
            unique_id="source.test.raw.orders",
            name="orders",
            database="test_db",
            schema="raw",
            identifier="orders",
            columns={
                "id": LoaderDbtColumn(name="id", description=None, data_type="INT"),
                "amount": LoaderDbtColumn(
                    name="amount", description=None, data_type="DECIMAL"
                ),
            },
        )

        model = create_mock_model(
            unique_id="model.test.fct_orders",
            name="fct_orders",
            compiled_sql="SELECT id, amount FROM raw.orders",
            columns={
                "id": LoaderDbtColumn(name="id", description=None, data_type="INT"),
                "amount": LoaderDbtColumn(
                    name="amount", description=None, data_type="DECIMAL"
                ),
            },
            database="test_db",
            schema="test_schema",
        )

        artifacts = create_mock_artifacts(
            models=[model],
            sources=[source],
        )

        relation_lookup = artifacts.relation_lookup()
        schema = artifacts.sqlglot_schema()

        edges, discovered_columns, _cte_nodes, _cte_edges, _struct_edges = (
            _extract_column_lineage_for_model(
                artifacts=artifacts,
                model=model,
                dialect=None,
                relation_lookup=relation_lookup,
                schema=schema,
            )
        )

        assert len(edges) > 0
        # Check edge structure
        for edge in edges:
            assert "from_id" in edge
            assert "to_id" in edge
            assert "transformation" in edge

    def test_extract_with_ephemeral_cte(self):
        """Ephemeral CTE model creates scope-level edges."""
        from lineage.ingest.static_loaders.dbt.builder import (
            _extract_column_lineage_for_model,
        )
        from lineage.ingest.static_loaders.dbt.dbt_loader import (
            DbtColumn as LoaderDbtColumn,
        )

        from tests.test_helpers import (
            create_mock_artifacts,
            create_mock_model,
            create_mock_source,
        )

        source = create_mock_source(
            unique_id="source.test.raw.orders",
            name="orders",
            database="test_db",
            schema="raw",
            identifier="orders",
            columns={
                "id": LoaderDbtColumn(name="id", description=None, data_type="INT"),
                "amount": LoaderDbtColumn(
                    name="amount", description=None, data_type="DECIMAL"
                ),
            },
        )

        ephemeral_model = create_mock_model(
            unique_id="model.test.stg_orders",
            name="stg_orders",
            materialization="ephemeral",
            compiled_sql="SELECT id, amount FROM raw.orders",
            columns={
                "id": LoaderDbtColumn(name="id", description=None, data_type="INT"),
                "amount": LoaderDbtColumn(
                    name="amount", description=None, data_type="DECIMAL"
                ),
            },
        )

        downstream_model = create_mock_model(
            unique_id="model.test.fct_orders",
            name="fct_orders",
            compiled_sql="""
            WITH __dbt__cte__stg_orders AS (
                SELECT id, amount FROM raw.orders
            )
            SELECT id, amount FROM __dbt__cte__stg_orders
            """,
            columns={
                "id": LoaderDbtColumn(name="id", description=None, data_type="INT"),
                "amount": LoaderDbtColumn(
                    name="amount", description=None, data_type="DECIMAL"
                ),
            },
            depends_on_nodes=["model.test.stg_orders"],
        )

        artifacts = create_mock_artifacts(
            models=[ephemeral_model, downstream_model],
            sources=[source],
        )

        relation_lookup = artifacts.relation_lookup()
        # Verify ephemeral CTE name is in relation lookup
        normalized_cte = artifacts.normalize_relation("__dbt__cte__stg_orders")
        assert normalized_cte in relation_lookup

        schema = artifacts.sqlglot_schema()

        edges, discovered_columns, _cte_nodes, _cte_edges, _struct_edges = (
            _extract_column_lineage_for_model(
                artifacts=artifacts,
                model=downstream_model,
                dialect=None,
                relation_lookup=relation_lookup,
                schema=schema,
            )
        )

        assert len(edges) > 0
        # Should have edges for the ephemeral CTE scope
        ephemeral_edges = [
            e
            for e in edges
            if "stg_orders" in e["from_id"] or "stg_orders" in e["to_id"]
        ]
        # The CTE scope should generate edges back to source
        assert len(ephemeral_edges) > 0

    def test_transformation_metadata_in_edges(self):
        """Edges should have transformation type metadata."""
        from lineage.ingest.static_loaders.dbt.builder import (
            _extract_column_lineage_for_model,
        )
        from lineage.ingest.static_loaders.dbt.dbt_loader import (
            DbtColumn as LoaderDbtColumn,
        )

        from tests.test_helpers import (
            create_mock_artifacts,
            create_mock_model,
            create_mock_source,
        )

        source = create_mock_source(
            unique_id="source.test.raw.orders",
            name="orders",
            database="test_db",
            schema="raw",
            identifier="orders",
            columns={
                "id": LoaderDbtColumn(name="id", description=None, data_type="INT"),
                "amount": LoaderDbtColumn(
                    name="amount", description=None, data_type="DECIMAL"
                ),
            },
        )

        model = create_mock_model(
            unique_id="model.test.fct_orders",
            name="fct_orders",
            compiled_sql="SELECT id, SUM(amount) AS total FROM raw.orders GROUP BY id",
            columns={
                "id": LoaderDbtColumn(name="id", description=None, data_type="INT"),
                "total": LoaderDbtColumn(
                    name="total", description=None, data_type="DECIMAL"
                ),
            },
        )

        artifacts = create_mock_artifacts(
            models=[model],
            sources=[source],
        )

        relation_lookup = artifacts.relation_lookup()
        schema = artifacts.sqlglot_schema()

        edges, discovered_columns, _cte_nodes, _cte_edges, _struct_edges = (
            _extract_column_lineage_for_model(
                artifacts=artifacts,
                model=model,
                dialect=None,
                relation_lookup=relation_lookup,
                schema=schema,
            )
        )

        # Find the transformation types from edges
        transformations = {e["transformation"] for e in edges}
        # Should contain transformation type values (not raw SQL expressions)
        assert any(
            t in transformations for t in ("group_key", "aggregated", "passthrough")
        )

    def test_cte_chain_resolves_to_base_table(self):
        """CTE chain: root deps point to CTE, but chain traces to base table."""
        from lineage.ingest.static_loaders.dbt.builder import (
            _extract_column_lineage_for_model,
        )
        from lineage.ingest.static_loaders.dbt.dbt_loader import (
            DbtColumn as LoaderDbtColumn,
        )

        from tests.test_helpers import (
            create_mock_artifacts,
            create_mock_model,
            create_mock_source,
        )

        source = create_mock_source(
            unique_id="source.test.raw.orders",
            name="orders",
            database="test_db",
            schema="raw",
            identifier="orders",
            columns={
                "id": LoaderDbtColumn(name="id", description=None, data_type="INT"),
                "amount": LoaderDbtColumn(
                    name="amount", description=None, data_type="DECIMAL"
                ),
            },
        )

        # Model with CTE that references the source
        model = create_mock_model(
            unique_id="model.test.fct_orders",
            name="fct_orders",
            compiled_sql="""
            WITH base AS (
                SELECT id, amount FROM raw.orders
            )
            SELECT id, amount FROM base
            """,
            columns={
                "id": LoaderDbtColumn(name="id", description=None, data_type="INT"),
                "amount": LoaderDbtColumn(
                    name="amount", description=None, data_type="DECIMAL"
                ),
            },
        )

        artifacts = create_mock_artifacts(
            models=[model],
            sources=[source],
        )

        relation_lookup = artifacts.relation_lookup()
        schema = artifacts.sqlglot_schema()

        edges, discovered_columns, _cte_nodes, _cte_edges, _struct_edges = (
            _extract_column_lineage_for_model(
                artifacts=artifacts,
                model=model,
                dialect=None,
                relation_lookup=relation_lookup,
                schema=schema,
            )
        )

        # Despite CTE indirection, edges should resolve to the source table
        assert len(edges) >= 2  # id and amount
        # Verify edges point to the actual source, not the CTE
        for edge in edges:
            assert "source.test.raw.orders" in edge["to_id"]
            assert "model.test.fct_orders" in edge["from_id"]

    def test_fallback_to_legacy_on_failure(self):
        """If transformation engine fails, fallback to legacy extraction."""
        from lineage.ingest.static_loaders.dbt.builder import (
            _extract_column_lineage_for_model,
        )
        from lineage.ingest.static_loaders.dbt.dbt_loader import (
            DbtColumn as LoaderDbtColumn,
        )

        from tests.test_helpers import (
            create_mock_artifacts,
            create_mock_model,
            create_mock_source,
        )

        source = create_mock_source(
            unique_id="source.test.raw.orders",
            name="orders",
            database="test_db",
            schema="raw",
            identifier="orders",
            columns={
                "id": LoaderDbtColumn(name="id", description=None, data_type="INT"),
            },
        )

        # Use very simple SQL that legacy engine can handle
        model = create_mock_model(
            unique_id="model.test.fct_orders",
            name="fct_orders",
            compiled_sql="SELECT id FROM raw.orders",
            columns={
                "id": LoaderDbtColumn(name="id", description=None, data_type="INT"),
            },
        )

        artifacts = create_mock_artifacts(
            models=[model],
            sources=[source],
        )

        relation_lookup = artifacts.relation_lookup()
        schema = artifacts.sqlglot_schema()

        # Should work regardless of which engine is used
        edges, discovered_columns, _cte_nodes, _cte_edges, _struct_edges = (
            _extract_column_lineage_for_model(
                artifacts=artifacts,
                model=model,
                dialect=None,
                relation_lookup=relation_lookup,
                schema=schema,
            )
        )
        assert len(edges) > 0

    def test_structural_edges_from_where_clause(self):
        """WHERE clause produces STRUCTURALLY_USES edge dicts."""
        from lineage.ingest.static_loaders.dbt.builder import (
            _extract_column_lineage_for_model,
        )
        from lineage.ingest.static_loaders.dbt.dbt_loader import (
            DbtColumn as LoaderDbtColumn,
        )

        from tests.test_helpers import (
            create_mock_artifacts,
            create_mock_model,
            create_mock_source,
        )

        source = create_mock_source(
            unique_id="source.test.raw.orders",
            name="orders",
            database="test_db",
            schema="raw",
            identifier="orders",
            columns={
                "id": LoaderDbtColumn(name="id", description=None, data_type="INT"),
                "amount": LoaderDbtColumn(
                    name="amount", description=None, data_type="DECIMAL"
                ),
                "status": LoaderDbtColumn(
                    name="status", description=None, data_type="VARCHAR"
                ),
            },
        )

        model = create_mock_model(
            unique_id="model.test.fct_orders",
            name="fct_orders",
            compiled_sql="SELECT id, amount FROM raw.orders WHERE status = 'active'",
            columns={
                "id": LoaderDbtColumn(name="id", description=None, data_type="INT"),
                "amount": LoaderDbtColumn(
                    name="amount", description=None, data_type="DECIMAL"
                ),
            },
            database="test_db",
            schema="test_schema",
        )

        artifacts = create_mock_artifacts(
            models=[model],
            sources=[source],
        )

        relation_lookup = artifacts.relation_lookup()
        schema = artifacts.sqlglot_schema()

        edges, discovered_columns, _cte_nodes, _cte_edges, struct_edges = (
            _extract_column_lineage_for_model(
                artifacts=artifacts,
                model=model,
                dialect=None,
                relation_lookup=relation_lookup,
                schema=schema,
            )
        )

        # Should have value edges
        assert len(edges) > 0
        # Should have structural edges for the WHERE clause
        assert len(struct_edges) > 0
        # All structural edges should be filter_predicate type
        filter_edges = [
            e for e in struct_edges if e["transformation"] == "filter_predicate"
        ]
        assert len(filter_edges) > 0
        # The filter edge should reference the 'status' column
        upstream_cols = {e["upstream_column"] for e in filter_edges}
        assert "status" in upstream_cols
        # Verify edge properties
        for e in filter_edges:
            # Clause-only columns (e.g., status in WHERE but not in SELECT)
            # use DbtModel as from node; output columns use DbtColumn
            assert e["from_node_type"] in ("DbtColumn", "DbtModel")
            assert e["to_node_type"] == "DbtColumn"
            assert e["scope"] == "__root__"
            assert e["confidence"] == "high"

    def test_structural_edges_from_join_and_group(self):
        """JOIN ON and GROUP BY produce structural edge dicts."""
        from lineage.ingest.static_loaders.dbt.builder import (
            _extract_column_lineage_for_model,
        )
        from lineage.ingest.static_loaders.dbt.dbt_loader import (
            DbtColumn as LoaderDbtColumn,
        )

        from tests.test_helpers import (
            create_mock_artifacts,
            create_mock_model,
            create_mock_source,
        )

        orders_source = create_mock_source(
            unique_id="source.test.raw.orders",
            name="orders",
            database="test_db",
            schema="raw",
            identifier="orders",
            columns={
                "id": LoaderDbtColumn(name="id", description=None, data_type="INT"),
                "customer_id": LoaderDbtColumn(
                    name="customer_id", description=None, data_type="INT"
                ),
                "amount": LoaderDbtColumn(
                    name="amount", description=None, data_type="DECIMAL"
                ),
            },
        )

        customers_source = create_mock_source(
            unique_id="source.test.raw.customers",
            name="customers",
            database="test_db",
            schema="raw",
            identifier="customers",
            columns={
                "id": LoaderDbtColumn(name="id", description=None, data_type="INT"),
                "name": LoaderDbtColumn(
                    name="name", description=None, data_type="VARCHAR"
                ),
            },
        )

        model = create_mock_model(
            unique_id="model.test.fct_customer_revenue",
            name="fct_customer_revenue",
            compiled_sql="""
                SELECT c.name, SUM(o.amount) AS total_amount
                FROM raw.orders o
                JOIN raw.customers c ON o.customer_id = c.id
                GROUP BY c.name
            """,
            columns={
                "name": LoaderDbtColumn(
                    name="name", description=None, data_type="VARCHAR"
                ),
                "total_amount": LoaderDbtColumn(
                    name="total_amount", description=None, data_type="DECIMAL"
                ),
            },
            database="test_db",
            schema="test_schema",
        )

        artifacts = create_mock_artifacts(
            models=[model],
            sources=[orders_source, customers_source],
        )

        relation_lookup = artifacts.relation_lookup()
        schema = artifacts.sqlglot_schema()

        edges, discovered_columns, _cte_nodes, _cte_edges, struct_edges = (
            _extract_column_lineage_for_model(
                artifacts=artifacts,
                model=model,
                dialect=None,
                relation_lookup=relation_lookup,
                schema=schema,
            )
        )

        assert len(edges) > 0
        assert len(struct_edges) > 0

        # Check join_key edges exist
        join_edges = [e for e in struct_edges if e["transformation"] == "join_key"]
        assert len(join_edges) > 0

        # Check group_key edges exist
        group_edges = [e for e in struct_edges if e["transformation"] == "group_key"]
        assert len(group_edges) > 0

        # Verify all structural transformation types present are valid
        valid_types = {
            "filter_predicate",
            "join_key",
            "group_key",
            "order_key",
            "window_partition",
            "window_order",
        }
        for e in struct_edges:
            assert e["transformation"] in valid_types

    def test_no_structural_edges_for_simple_passthrough(self):
        """Simple SELECT without structural clauses produces no structural edges."""
        from lineage.ingest.static_loaders.dbt.builder import (
            _extract_column_lineage_for_model,
        )
        from lineage.ingest.static_loaders.dbt.dbt_loader import (
            DbtColumn as LoaderDbtColumn,
        )

        from tests.test_helpers import (
            create_mock_artifacts,
            create_mock_model,
            create_mock_source,
        )

        source = create_mock_source(
            unique_id="source.test.raw.orders",
            name="orders",
            database="test_db",
            schema="raw",
            identifier="orders",
            columns={
                "id": LoaderDbtColumn(name="id", description=None, data_type="INT"),
                "amount": LoaderDbtColumn(
                    name="amount", description=None, data_type="DECIMAL"
                ),
            },
        )

        model = create_mock_model(
            unique_id="model.test.stg_orders",
            name="stg_orders",
            compiled_sql="SELECT id, amount FROM raw.orders",
            columns={
                "id": LoaderDbtColumn(name="id", description=None, data_type="INT"),
                "amount": LoaderDbtColumn(
                    name="amount", description=None, data_type="DECIMAL"
                ),
            },
            database="test_db",
            schema="test_schema",
        )

        artifacts = create_mock_artifacts(
            models=[model],
            sources=[source],
        )

        relation_lookup = artifacts.relation_lookup()
        schema = artifacts.sqlglot_schema()

        edges, discovered_columns, _cte_nodes, _cte_edges, struct_edges = (
            _extract_column_lineage_for_model(
                artifacts=artifacts,
                model=model,
                dialect=None,
                relation_lookup=relation_lookup,
                schema=schema,
            )
        )

        # Should have value edges but no structural edges
        assert len(edges) > 0
        assert len(struct_edges) == 0


class TestRelationLookupEphemeral:
    """Test that relation_lookup registers __dbt__cte__ forms for ephemeral models."""

    def test_ephemeral_cte_in_relation_lookup(self):
        """Ephemeral models should register __dbt__cte__ forms."""
        from lineage.ingest.static_loaders.dbt.dbt_loader import (
            DbtColumn as LoaderDbtColumn,
        )

        from tests.test_helpers import create_mock_artifacts, create_mock_model

        ephemeral = create_mock_model(
            unique_id="model.test.stg_orders",
            name="stg_orders",
            materialization="ephemeral",
            columns={
                "id": LoaderDbtColumn(name="id", description=None, data_type="INT"),
            },
        )

        artifacts = create_mock_artifacts(models=[ephemeral])
        lookup = artifacts.relation_lookup()

        # Normal name should be registered
        assert "stg_orders" in lookup

        # __dbt__cte__ form should also be registered
        cte_normalized = artifacts.normalize_relation("__dbt__cte__stg_orders")
        assert cte_normalized in lookup
        assert lookup[cte_normalized] == "model.test.stg_orders"

    def test_non_ephemeral_no_cte_registration(self):
        """Non-ephemeral models should NOT register __dbt__cte__ forms."""
        from lineage.ingest.static_loaders.dbt.dbt_loader import (
            DbtColumn as LoaderDbtColumn,
        )

        from tests.test_helpers import create_mock_artifacts, create_mock_model

        table_model = create_mock_model(
            unique_id="model.test.fct_orders",
            name="fct_orders",
            materialization="table",
            columns={
                "id": LoaderDbtColumn(name="id", description=None, data_type="INT"),
            },
        )

        artifacts = create_mock_artifacts(models=[table_model])
        lookup = artifacts.relation_lookup()

        cte_normalized = artifacts.normalize_relation("__dbt__cte__fct_orders")
        assert cte_normalized not in lookup


# ===========================================================================
# EXTRACTION Syntax Detection
# ===========================================================================


class TestExtractionClassification:
    """Tests for EXTRACTION detection via semi-structured access syntax."""

    def test_snowflake_colon_syntax(self):
        """Snowflake variant colon access (data:key) -> EXTRACTION."""
        schema = _make_schema(
            ("", "", "t", {"fields": "VARIANT"})
        )
        graph = analyze_query(
            "SELECT fields:project_id AS pid FROM t",
            schema=schema,
            dialect="snowflake",
        )
        ct = _find_col(graph, "pid")
        assert ct is not None
        assert ct.transformation == TransformationType.EXTRACTION

    def test_snowflake_colon_with_cast(self):
        """Snowflake variant colon with cast (data:key::varchar) -> EXTRACTION."""
        schema = _make_schema(
            ("", "", "t", {"fields": "VARIANT"})
        )
        graph = analyze_query(
            "SELECT fields:project_id::varchar AS pid FROM t",
            schema=schema,
            dialect="snowflake",
        )
        ct = _find_col(graph, "pid")
        assert ct is not None
        assert ct.transformation == TransformationType.EXTRACTION

    def test_bracket_syntax(self):
        """Bracket access (data['key']) -> EXTRACTION."""
        schema = _make_schema(
            ("", "", "t", {"data": "VARIANT"})
        )
        graph = analyze_query(
            "SELECT data['key'] AS k FROM t",
            schema=schema,
            dialect="snowflake",
        )
        ct = _find_col(graph, "k")
        assert ct is not None
        assert ct.transformation == TransformationType.EXTRACTION

    def test_cte_passthrough_of_extraction(self):
        """CTE does extraction, root does passthrough -> root=PASSTHROUGH, CTE scope=EXTRACTION."""
        schema = _make_schema(
            ("", "", "t", {"fields": "VARIANT"})
        )
        graph = analyze_query(
            """
            WITH extracted AS (
                SELECT fields:project_id::varchar AS pid FROM t
            )
            SELECT pid FROM extracted
            """,
            schema=schema,
            dialect="snowflake",
        )
        # Root should see passthrough (just selecting pid from CTE)
        ct = _find_col(graph, "pid")
        assert ct is not None
        assert ct.transformation == TransformationType.PASSTHROUGH

        # CTE scope should have EXTRACTION (sqlglot may uppercase the scope name)
        cte_scope = graph.scopes.get("extracted") or graph.scopes.get("EXTRACTED")
        assert cte_scope is not None, f"Available scopes: {list(graph.scopes.keys())}"
        cte_types = {
            c.output_ref.column_name.lower(): c.transformation
            for c in cte_scope.columns
        }
        assert cte_types["pid"] == TransformationType.EXTRACTION

    def test_regular_column_not_extraction(self):
        """Regular columns should not be classified as EXTRACTION."""
        schema = _make_schema(
            ("", "", "orders", {"id": "INT", "name": "VARCHAR"})
        )
        graph = analyze_query(
            "SELECT id, name FROM orders",
            schema=schema,
        )
        types = _col_types(graph)
        assert types["id"] == TransformationType.PASSTHROUGH
        assert types["name"] == TransformationType.PASSTHROUGH
