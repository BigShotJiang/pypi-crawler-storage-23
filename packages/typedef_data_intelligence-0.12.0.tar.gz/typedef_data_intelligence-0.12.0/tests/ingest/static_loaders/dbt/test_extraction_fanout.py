"""Integration tests verifying EXTRACTION detection via the scope engine.

The builder no longer has a fan-out heuristic (_reclassify_extraction_fanout).
EXTRACTION is now detected by syntax analysis in classify_expression() when
semi-structured access patterns (JSON path, bracket notation) are encountered.

These tests verify that CTE scope edges get the 'extraction' transformation
when the scope engine processes such patterns.
"""

from __future__ import annotations

from lineage.ingest.static_loaders.sqlglot.transformation_lineage import (
    TransformationType,
    analyze_query,
)
from lineage.ingest.static_loaders.sqlglot.types import SqlglotSchema, TableEntry


def _make_schema(*tables: tuple[str, str, str, dict[str, str]]) -> SqlglotSchema:
    """Build a SqlglotSchema from (database, schema, table, {col: type}) tuples."""
    entries = []
    for db, schema, table, cols in tables:
        entries.append(
            TableEntry(
                database=db,
                schema=schema,
                table=table,
                columns=tuple(cols.items()),
            )
        )
    return SqlglotSchema(_entries=tuple(entries))


class TestExtractionViasScopeEngine:
    """Verify the scope engine classifies semi-structured access as EXTRACTION."""

    def test_cte_extraction_scope_has_extraction_type(self) -> None:
        """CTE performing variant extraction should produce EXTRACTION in scope."""
        schema = _make_schema(
            ("", "", "raw_events", {"fields": "VARIANT", "id": "INT"})
        )
        graph = analyze_query(
            """
            WITH extracted AS (
                SELECT
                    id,
                    fields:project_id::varchar AS project_id,
                    fields:summary::varchar AS summary,
                    fields:description::varchar AS description
                FROM raw_events
            )
            SELECT id, project_id, summary, description FROM extracted
            """,
            schema=schema,
            dialect="snowflake",
        )

        # CTE scope should have EXTRACTION for the variant-extracted columns
        # (sqlglot may uppercase the scope name depending on dialect)
        cte_scope = graph.scopes.get("extracted") or graph.scopes.get("EXTRACTED")
        assert cte_scope is not None, f"Available scopes: {list(graph.scopes.keys())}"
        cte_types = {
            c.output_ref.column_name.lower(): c.transformation
            for c in cte_scope.columns
        }
        assert cte_types["project_id"] == TransformationType.EXTRACTION
        assert cte_types["summary"] == TransformationType.EXTRACTION
        assert cte_types["description"] == TransformationType.EXTRACTION
        # id should remain passthrough
        assert cte_types["id"] == TransformationType.PASSTHROUGH

    def test_root_passthrough_from_extraction_cte(self) -> None:
        """Root scope selecting from extraction CTE should be PASSTHROUGH."""
        schema = _make_schema(
            ("", "", "raw_events", {"fields": "VARIANT"})
        )
        graph = analyze_query(
            """
            WITH extracted AS (
                SELECT fields:project_id::varchar AS project_id FROM raw_events
            )
            SELECT project_id FROM extracted
            """,
            schema=schema,
            dialect="snowflake",
        )

        # Root output should be PASSTHROUGH (just selecting from CTE)
        root_types = {
            c.output_ref.column_name.lower(): c.transformation
            for c in graph.output_columns
        }
        assert root_types["project_id"] == TransformationType.PASSTHROUGH

    def test_direct_extraction_without_cte(self) -> None:
        """Direct semi-structured access without CTE should be EXTRACTION."""
        schema = _make_schema(
            ("", "", "raw_events", {"fields": "VARIANT"})
        )
        graph = analyze_query(
            "SELECT fields:project_id::varchar AS project_id FROM raw_events",
            schema=schema,
            dialect="snowflake",
        )

        root_types = {
            c.output_ref.column_name.lower(): c.transformation
            for c in graph.output_columns
        }
        assert root_types["project_id"] == TransformationType.EXTRACTION
