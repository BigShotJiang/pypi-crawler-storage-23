"""Tests for source-side PhysicalTable node creation.

Tests verify that dbt sources correctly produce PhysicalTable nodes
and BUILDS edges, respecting the create_physical_nodes flag and
handling edge cases like duplicate sources and missing fields.
"""

import json
from pathlib import Path

from lineage.backends.lineage.protocol import LineageStorage
from lineage.ingest.static_loaders.dbt.builder import LineageBuilder

from tests.test_helpers import create_mock_artifacts, create_mock_source


class TestSourcePhysicalNodes:
    """Tests for PhysicalTable creation from dbt sources."""

    def test_source_creates_physical_table_and_builds_edge(
        self, falkordblite_storage: LineageStorage, tmp_path: Path
    ) -> None:
        """A source with database/schema/identifier produces a PhysicalTable
        node with the expected id and a BUILDS edge from DbtSource."""
        source = create_mock_source(
            "source.test.raw.orders",
            database="analytics",
            schema="raw",
            identifier="orders",
        )
        artifacts = create_mock_artifacts([], sources=[source])

        artifacts_dir = tmp_path / "target"
        artifacts_dir.mkdir()
        (artifacts_dir / "manifest.json").write_text(json.dumps(artifacts.manifest))
        (artifacts_dir / "catalog.json").write_text(json.dumps(artifacts.catalog))

        builder = LineageBuilder.from_dbt_artifacts(artifacts_dir)
        builder.write_typed(falkordblite_storage)

        # Verify PhysicalTable node exists with correct properties
        result = falkordblite_storage.execute_raw_query(
            "MATCH (p:PhysicalTable) "
            "RETURN p.id AS id, p.database AS database, "
            "p.schema_name AS schema_name, p.fqn AS fqn, "
            "p.relation_name AS relation_name"
        )
        assert result.count == 1
        row = result.rows[0]
        assert row["database"] == "analytics"
        assert row["schema_name"] == "raw"
        assert row["fqn"] == "analytics.raw.orders"
        assert row["relation_name"] == "orders"
        assert "physical://" in row["id"]

        # Verify BUILDS edge from DbtSource -> PhysicalTable
        result = falkordblite_storage.execute_raw_query(
            "MATCH (s:DbtSource)-[:BUILDS]->(p:PhysicalTable) "
            "RETURN s.id AS source_id, p.fqn AS physical_fqn"
        )
        assert result.count == 1
        assert result.rows[0]["source_id"] == "source.test.raw.orders"
        assert result.rows[0]["physical_fqn"] == "analytics.raw.orders"

    def test_create_physical_nodes_false_skips_source_physical_nodes(
        self, falkordblite_storage: LineageStorage, tmp_path: Path
    ) -> None:
        """create_physical_nodes=False should suppress PhysicalTable
        and BUILDS edge creation for sources."""
        source = create_mock_source(
            "source.test.raw.orders",
            database="analytics",
            schema="raw",
            identifier="orders",
        )
        artifacts = create_mock_artifacts([], sources=[source])

        artifacts_dir = tmp_path / "target"
        artifacts_dir.mkdir()
        (artifacts_dir / "manifest.json").write_text(json.dumps(artifacts.manifest))
        (artifacts_dir / "catalog.json").write_text(json.dumps(artifacts.catalog))

        builder = LineageBuilder.from_dbt_artifacts(artifacts_dir)
        builder.write_typed(falkordblite_storage, create_physical_nodes=False)

        # No PhysicalTable nodes should exist
        result = falkordblite_storage.execute_raw_query(
            "MATCH (p:PhysicalTable) RETURN COUNT(p) AS count"
        )
        assert result.rows[0]["count"] == 0

        # No BUILDS edges should exist
        result = falkordblite_storage.execute_raw_query(
            "MATCH ()-[b:BUILDS]->() RETURN COUNT(b) AS count"
        )
        assert result.rows[0]["count"] == 0

        # DbtSource should still exist
        result = falkordblite_storage.execute_raw_query(
            "MATCH (s:DbtSource) RETURN s.id AS id"
        )
        assert result.count == 1
        assert result.rows[0]["id"] == "source.test.raw.orders"

    def test_multiple_sources_same_physical_table(
        self, falkordblite_storage: LineageStorage, tmp_path: Path
    ) -> None:
        """Two DbtSource entries pointing at the same physical table should
        produce one PhysicalTable node but two BUILDS edges."""
        source_a = create_mock_source(
            "source.test.raw_a.orders",
            name="orders",
            database="analytics",
            schema="raw",
            identifier="orders",
        )
        source_b = create_mock_source(
            "source.test.raw_b.orders",
            name="orders",
            database="analytics",
            schema="raw",
            identifier="orders",
        )
        artifacts = create_mock_artifacts([], sources=[source_a, source_b])

        artifacts_dir = tmp_path / "target"
        artifacts_dir.mkdir()
        (artifacts_dir / "manifest.json").write_text(json.dumps(artifacts.manifest))
        (artifacts_dir / "catalog.json").write_text(json.dumps(artifacts.catalog))

        builder = LineageBuilder.from_dbt_artifacts(artifacts_dir)
        builder.write_typed(falkordblite_storage)

        # One PhysicalTable node
        result = falkordblite_storage.execute_raw_query(
            "MATCH (p:PhysicalTable) RETURN COUNT(p) AS count"
        )
        assert result.rows[0]["count"] == 1

        # Two BUILDS edges (one per DbtSource)
        result = falkordblite_storage.execute_raw_query(
            "MATCH (s:DbtSource)-[:BUILDS]->(p:PhysicalTable) "
            "RETURN s.id AS source_id ORDER BY s.id"
        )
        assert result.count == 2
        source_ids = {row["source_id"] for row in result.rows}
        assert source_ids == {
            "source.test.raw_a.orders",
            "source.test.raw_b.orders",
        }

    def test_source_missing_database_skips_physical_node(
        self, falkordblite_storage: LineageStorage, tmp_path: Path
    ) -> None:
        """A source with database=None should skip physical node creation."""
        source = create_mock_source(
            "source.test.raw.orders",
            database=None,
            schema="raw",
            identifier="orders",
        )
        artifacts = create_mock_artifacts([], sources=[source])

        artifacts_dir = tmp_path / "target"
        artifacts_dir.mkdir()
        (artifacts_dir / "manifest.json").write_text(json.dumps(artifacts.manifest))
        (artifacts_dir / "catalog.json").write_text(json.dumps(artifacts.catalog))

        builder = LineageBuilder.from_dbt_artifacts(artifacts_dir)
        builder.write_typed(falkordblite_storage)

        # No PhysicalTable nodes
        result = falkordblite_storage.execute_raw_query(
            "MATCH (p:PhysicalTable) RETURN COUNT(p) AS count"
        )
        assert result.rows[0]["count"] == 0

        # DbtSource should still exist
        result = falkordblite_storage.execute_raw_query(
            "MATCH (s:DbtSource) RETURN COUNT(s) AS count"
        )
        assert result.rows[0]["count"] == 1

    def test_source_missing_schema_skips_physical_node(
        self, falkordblite_storage: LineageStorage, tmp_path: Path
    ) -> None:
        """A source with schema=None should skip physical node creation."""
        source = create_mock_source(
            "source.test.raw.orders",
            database="analytics",
            schema=None,
            identifier="orders",
        )
        artifacts = create_mock_artifacts([], sources=[source])

        artifacts_dir = tmp_path / "target"
        artifacts_dir.mkdir()
        (artifacts_dir / "manifest.json").write_text(json.dumps(artifacts.manifest))
        (artifacts_dir / "catalog.json").write_text(json.dumps(artifacts.catalog))

        builder = LineageBuilder.from_dbt_artifacts(artifacts_dir)
        builder.write_typed(falkordblite_storage)

        # No PhysicalTable nodes
        result = falkordblite_storage.execute_raw_query(
            "MATCH (p:PhysicalTable) RETURN COUNT(p) AS count"
        )
        assert result.rows[0]["count"] == 0
