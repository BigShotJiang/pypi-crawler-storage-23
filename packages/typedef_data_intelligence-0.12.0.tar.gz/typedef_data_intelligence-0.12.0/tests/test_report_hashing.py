"""Tests for report content hashing and change detection.

Covers:
- compute_content_hash determinism and input types
- load_report_hashes graph state loading (mocked)
- detect_report_changes comparison logic
"""

from __future__ import annotations

from unittest.mock import Mock

import pytest
from lineage.backends.lineage.protocol import LineageStorage, RawLineageQueryResult
from lineage.ingest.static_loaders.report_hashing import (
    ReportChangeSet,
    compute_content_hash,
    detect_report_changes,
    load_report_hashes,
)

# ---------------------------------------------------------------------------
# compute_content_hash tests
# ---------------------------------------------------------------------------


class TestComputeContentHash:
    """Tests for compute_content_hash."""

    def test_same_input_same_hash(self) -> None:
        data = {"key": "value", "num": 42}
        assert compute_content_hash(data) == compute_content_hash(data)

    def test_different_input_different_hash(self) -> None:
        a = {"key": "value_a"}
        b = {"key": "value_b"}
        assert compute_content_hash(a) != compute_content_hash(b)

    def test_key_ordering_irrelevant(self) -> None:
        """sort_keys=True makes key order irrelevant."""
        a = {"z": 1, "a": 2}
        b = {"a": 2, "z": 1}
        assert compute_content_hash(a) == compute_content_hash(b)

    def test_dict_input(self) -> None:
        h = compute_content_hash({"report": "data"})
        assert isinstance(h, str)
        assert len(h) == 64  # SHA-256 hex digest length

    def test_list_input(self) -> None:
        h = compute_content_hash([1, 2, 3])
        assert isinstance(h, str)
        assert len(h) == 64

    def test_string_input(self) -> None:
        h = compute_content_hash("raw string payload")
        assert isinstance(h, str)
        assert len(h) == 64

    def test_nested_dict_determinism(self) -> None:
        data = {"outer": {"inner_b": 2, "inner_a": 1}, "list": [3, 2, 1]}
        assert compute_content_hash(data) == compute_content_hash(data)

    def test_none_values_handled(self) -> None:
        """None values in dicts are serialised as JSON null."""
        data = {"key": None, "other": "val"}
        h = compute_content_hash(data)
        assert isinstance(h, str) and len(h) == 64

    def test_empty_dict(self) -> None:
        h = compute_content_hash({})
        assert isinstance(h, str) and len(h) == 64

    def test_empty_list(self) -> None:
        h = compute_content_hash([])
        assert isinstance(h, str) and len(h) == 64

    def test_empty_string(self) -> None:
        h = compute_content_hash("")
        assert isinstance(h, str) and len(h) == 64


# ---------------------------------------------------------------------------
# detect_report_changes tests
# ---------------------------------------------------------------------------


class TestDetectReportChanges:
    """Tests for detect_report_changes."""

    def test_all_new_reports(self) -> None:
        current = {"r1": "hash1", "r2": "hash2"}
        stored: dict[str, str | None] = {}
        cs = detect_report_changes(current, stored)

        assert sorted(cs.added) == ["r1", "r2"]
        assert cs.modified == []
        assert cs.unchanged == []

    def test_all_unchanged(self) -> None:
        current = {"r1": "hash1", "r2": "hash2"}
        stored = {"r1": "hash1", "r2": "hash2"}
        cs = detect_report_changes(current, stored)

        assert cs.added == []
        assert cs.modified == []
        assert sorted(cs.unchanged) == ["r1", "r2"]

    def test_mix_added_modified_unchanged(self) -> None:
        current = {"r1": "hash1", "r2": "hash2_new", "r3": "hash3"}
        stored = {"r2": "hash2_old", "r3": "hash3"}
        cs = detect_report_changes(current, stored)

        assert cs.added == ["r1"]
        assert cs.modified == ["r2"]
        assert cs.unchanged == ["r3"]

    def test_stored_hash_none_treated_as_modified(self) -> None:
        """A node with no stored hash is treated as modified."""
        current = {"r1": "hash1"}
        stored: dict[str, str | None] = {"r1": None}
        cs = detect_report_changes(current, stored)

        assert cs.modified == ["r1"]
        assert cs.added == []
        assert cs.unchanged == []

    def test_empty_inputs(self) -> None:
        cs = detect_report_changes({}, {})
        assert cs.added == []
        assert cs.modified == []
        assert cs.unchanged == []

    def test_reports_to_process(self) -> None:
        current = {"r1": "h1", "r2": "h2_new", "r3": "h3"}
        stored = {"r2": "h2_old", "r3": "h3"}
        cs = detect_report_changes(current, stored)

        assert sorted(cs.reports_to_process) == ["r1", "r2"]


# ---------------------------------------------------------------------------
# ReportChangeSet tests
# ---------------------------------------------------------------------------


class TestReportChangeSet:
    """Tests for the ReportChangeSet dataclass."""

    def test_reports_to_process_combines_added_and_modified(self) -> None:
        cs = ReportChangeSet(added=["a1"], modified=["m1", "m2"], unchanged=["u1"])
        assert cs.reports_to_process == ["a1", "m1", "m2"]

    def test_reports_to_process_empty(self) -> None:
        cs = ReportChangeSet(added=[], modified=[], unchanged=["u1"])
        assert cs.reports_to_process == []


# ---------------------------------------------------------------------------
# load_report_hashes tests
# ---------------------------------------------------------------------------


def _make_mock_storage(rows: list[dict]) -> Mock:
    """Create a mock LineageStorage that returns the given rows."""
    mock = Mock(spec=LineageStorage)
    mock.execute_raw_query.return_value = RawLineageQueryResult(
        rows=rows, count=len(rows), query=""
    )
    return mock


class TestLoadReportHashes:
    """Tests for load_report_hashes."""

    def test_no_existing_nodes(self) -> None:
        mock = _make_mock_storage([])
        result = load_report_hashes(mock, "SfReport", ["id1", "id2"])
        assert result == {}

    def test_nodes_with_hashes(self) -> None:
        mock = _make_mock_storage([
            {"id": "id1", "content_hash": "abc123"},
            {"id": "id2", "content_hash": "def456"},
        ])
        result = load_report_hashes(mock, "SfReport", ["id1", "id2"])
        assert result == {"id1": "abc123", "id2": "def456"}

    def test_nodes_without_hashes(self) -> None:
        mock = _make_mock_storage([
            {"id": "id1", "content_hash": None},
        ])
        result = load_report_hashes(mock, "SfReport", ["id1"])
        assert result == {"id1": None}

    def test_mixed_with_and_without_hashes(self) -> None:
        mock = _make_mock_storage([
            {"id": "id1", "content_hash": "abc"},
            {"id": "id2", "content_hash": None},
        ])
        result = load_report_hashes(mock, "SfReport", ["id1", "id2"])
        assert result == {"id1": "abc", "id2": None}

    def test_filters_to_requested_ids(self) -> None:
        """Server-side filtering: query includes WHERE n.id IN $ids."""
        mock = _make_mock_storage([
            {"id": "id1", "content_hash": "h1"},
        ])
        result = load_report_hashes(mock, "SfReport", ["id1"])
        assert result == {"id1": "h1"}
        # Verify the query passes ids for server-side filtering
        call_args = mock.execute_raw_query.call_args
        assert "IN $ids" in call_args[0][0]
        assert call_args[1]["params"]["ids"] == ["id1"]

    def test_empty_ids_returns_empty(self) -> None:
        mock = Mock(spec=LineageStorage)
        result = load_report_hashes(mock, "SfReport", [])
        assert result == {}
        mock.execute_raw_query.assert_not_called()

    def test_connection_error_propagates(self) -> None:
        mock = Mock(spec=LineageStorage)
        mock.execute_raw_query.side_effect = ConnectionError("db unreachable")
        with pytest.raises(ConnectionError):
            load_report_hashes(mock, "SfReport", ["id1"])

    def test_schema_error_returns_empty(self) -> None:
        mock = Mock(spec=LineageStorage)
        mock.execute_raw_query.side_effect = RuntimeError("Table does not exist")
        result = load_report_hashes(mock, "SfReport", ["id1"])
        assert result == {}

    def test_generic_error_returns_empty(self) -> None:
        mock = Mock(spec=LineageStorage)
        mock.execute_raw_query.side_effect = ValueError("something unexpected")
        result = load_report_hashes(mock, "SfReport", ["id1"])
        assert result == {}
