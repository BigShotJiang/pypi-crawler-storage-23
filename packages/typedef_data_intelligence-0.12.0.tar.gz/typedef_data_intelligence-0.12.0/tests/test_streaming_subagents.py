"""Unit tests for the streaming_subagents module."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, List

if TYPE_CHECKING:
    from lineage.backends.threads.models import RunSummary
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from lineage.agent.pydantic.deep_types import CopilotDeps
from lineage.agent.pydantic.streaming_subagents import (
    create_streaming_subagent_toolset,
)
from lineage.agent.pydantic.types import AgentState
from lineage.backends.threads.models import Artifact, StoredMessage, ThreadContext
from pydantic_deep.types import SubAgentConfig

# ---------------------------------------------------------------------------
# Fakes / helpers
# ---------------------------------------------------------------------------

@dataclass
class _FakeCtx:
    """Minimal RunContext stand-in for unit tests."""

    deps: CopilotDeps
    tool_call_id: str = "toolcall_test"


class _FakeThreadsBackend:
    """Minimal threads backend for streaming subagent tests."""

    def __init__(self) -> None:
        self._threads: dict[str, ThreadContext] = {}
        self._metadata: dict[tuple[str, str], Any] = {}
        self._messages: dict[str, List[StoredMessage]] = {}

    def get_or_create_thread(self, thread_id: str) -> ThreadContext:
        if thread_id not in self._threads:
            self._threads[thread_id] = ThreadContext(thread_id=thread_id)
        return self._threads[thread_id]

    def add_artifact(self, thread_id: str, run_id: str, artifact: Artifact) -> None:
        thread = self.get_or_create_thread(thread_id)
        thread.artifacts.add(artifact)

    def save_run_summary(self, thread_id: str, run_summary: RunSummary) -> None:
        thread = self.get_or_create_thread(thread_id)
        thread.runs.append(run_summary)

    def thread_exists(self, thread_id: str) -> bool:
        return thread_id in self._threads

    def add_message(self, thread_id: str, message: StoredMessage) -> None:
        self._messages.setdefault(thread_id, []).append(message)

    def get_messages(self, thread_id: str) -> List[StoredMessage]:
        return list(self._messages.get(thread_id, []))

    def set_metadata(self, thread_id: str, key: str, value: Any) -> None:
        self._metadata[(thread_id, key)] = value

    def get_metadata(self, thread_id: str, key: str) -> Any | None:
        return self._metadata.get((thread_id, key))


def _make_subagent_config(
    name: str,
    description: str = "Test subagent",
    instructions: str = "Do the task.",
) -> SubAgentConfig:
    """Create a minimal SubAgentConfig dict."""
    return SubAgentConfig(
        name=name,
        description=description,
        instructions=instructions,
        tools=[],
    )


def _make_deps(
    threads_backend: _FakeThreadsBackend | None = None,
    state: AgentState | None = None,
) -> CopilotDeps:
    """Create a CopilotDeps with sensible defaults for tests."""
    from pydantic_deep import StateBackend

    return CopilotDeps(
        backend=StateBackend(),
        files={},
        todos=[],
        subagents={},
        uploads={},
        thread_id="t1",
        run_id="r1",
        threads_backend=threads_backend,
        state=state or AgentState(),
        ui_event_queue=None,  # Disable live AG-UI injection in tests
    )


def _get_task_fn(toolset):
    """Extract the `task` tool function from the toolset."""
    # FunctionToolset stores tools internally; get the callable
    tool_defs = toolset.tool_defs
    for td in tool_defs:
        if td.name == "task":
            return td.function
    raise ValueError("No 'task' tool found in toolset")


# ---------------------------------------------------------------------------
# Tests: argument normalization and validation
# ---------------------------------------------------------------------------


class TestArgumentNormalization:
    """Tests for argument aliasing and validation in task()."""

    @pytest.mark.asyncio
    async def test_name_alias_maps_to_subagent_type(self) -> None:
        """The `name` parameter is an alias for `subagent_type`."""
        configs = [_make_subagent_config("explorer")]
        toolset = create_streaming_subagent_toolset(subagents=configs)
        ctx = _FakeCtx(deps=_make_deps())

        # Using name= instead of subagent_type=, but "explorer" is valid
        # The function should NOT error on subagent_type being None
        # when name is provided.
        with patch("lineage.agent.pydantic.streaming_subagents.Agent") as MockAgent, \
             patch("lineage.agent.pydantic.streaming_subagents.create_model", return_value="test-model"):
            mock_agent = AsyncMock()
            MockAgent.return_value = mock_agent

            async def _fake_stream(*a, **kw):
                return
                yield  # make it an async generator  # noqa: E501

            mock_agent.run_stream_events = _fake_stream
            result = await toolset.tools["task"].function(
                ctx, description="Test task", name="explorer"
            )
            assert "completed" in str(result).lower() or "error" not in str(result).lower()

    @pytest.mark.asyncio
    async def test_prompt_alias_maps_to_description(self) -> None:
        """The `prompt` parameter is an alias for `description`."""
        configs = [_make_subagent_config("explorer")]
        toolset = create_streaming_subagent_toolset(subagents=configs)
        ctx = _FakeCtx(deps=_make_deps())

        with patch("lineage.agent.pydantic.streaming_subagents.Agent") as MockAgent, \
             patch("lineage.agent.pydantic.streaming_subagents.create_model", return_value="test-model"):
            mock_agent = AsyncMock()
            MockAgent.return_value = mock_agent

            async def _fake_stream(*a, **kw):
                return
                yield  # noqa: E501

            mock_agent.run_stream_events = _fake_stream
            result = await toolset.tools["task"].function(
                ctx, subagent_type="explorer", prompt="Do something"
            )
            assert "error" not in str(result).lower()

    @pytest.mark.asyncio
    async def test_missing_subagent_type_returns_error(self) -> None:
        """Missing both subagent_type and name returns an error."""
        configs = [_make_subagent_config("explorer")]
        toolset = create_streaming_subagent_toolset(subagents=configs)
        ctx = _FakeCtx(deps=_make_deps())

        result = await toolset.tools["task"].function(
            ctx, description="Test task"
        )
        assert isinstance(result, str)
        assert "missing" in result.lower()

    @pytest.mark.asyncio
    async def test_missing_description_returns_error(self) -> None:
        """Missing both description and prompt returns an error."""
        configs = [_make_subagent_config("explorer")]
        toolset = create_streaming_subagent_toolset(subagents=configs)
        ctx = _FakeCtx(deps=_make_deps())

        result = await toolset.tools["task"].function(
            ctx, subagent_type="explorer"
        )
        assert isinstance(result, str)
        assert "missing" in result.lower()

    @pytest.mark.asyncio
    async def test_unknown_subagent_type_returns_error(self) -> None:
        """An unrecognized subagent type returns an error listing allowed types."""
        configs = [_make_subagent_config("explorer")]
        toolset = create_streaming_subagent_toolset(subagents=configs)
        ctx = _FakeCtx(deps=_make_deps())

        result = await toolset.tools["task"].function(
            ctx, subagent_type="nonexistent", description="Test"
        )
        assert isinstance(result, str)
        assert "unknown" in result.lower() or "error" in result.lower()


# ---------------------------------------------------------------------------
# Tests: plan context injection
# ---------------------------------------------------------------------------


class TestPlanContextInjection:
    """Tests for automatic plan loading prefix injected into executor/mechanic."""

    @pytest.mark.asyncio
    async def test_executor_gets_plan_prefix(self) -> None:
        """Executor subagent description is prefixed with plan-loading instruction."""
        configs = [_make_subagent_config("executor")]
        toolset = create_streaming_subagent_toolset(subagents=configs)

        state = AgentState()
        state.active_plan_id = "plan_123"
        deps = _make_deps(state=state)
        ctx = _FakeCtx(deps=deps)

        captured_description = None

        with patch("lineage.agent.pydantic.streaming_subagents.Agent") as MockAgent, \
             patch("lineage.agent.pydantic.streaming_subagents.create_model", return_value="test-model"):
            mock_agent = AsyncMock()
            MockAgent.return_value = mock_agent

            async def _capture_stream(desc, **kw):
                nonlocal captured_description
                captured_description = desc
                return
                yield  # noqa: E501

            mock_agent.run_stream_events = _capture_stream
            await toolset.tools["task"].function(
                ctx, subagent_type="executor", description="Implement the feature"
            )

        assert captured_description is not None
        assert "get_plan(plan_id='plan_123')" in captured_description
        assert "Implement the feature" in captured_description

    @pytest.mark.asyncio
    async def test_explorer_does_not_get_plan_prefix(self) -> None:
        """Explorer subagent should NOT get plan prefix injected."""
        configs = [_make_subagent_config("explorer")]
        toolset = create_streaming_subagent_toolset(subagents=configs)

        state = AgentState()
        state.active_plan_id = "plan_123"
        deps = _make_deps(state=state)
        ctx = _FakeCtx(deps=deps)

        captured_description = None

        with patch("lineage.agent.pydantic.streaming_subagents.Agent") as MockAgent, \
             patch("lineage.agent.pydantic.streaming_subagents.create_model", return_value="test-model"):
            mock_agent = AsyncMock()
            MockAgent.return_value = mock_agent

            async def _capture_stream(desc, **kw):
                nonlocal captured_description
                captured_description = desc
                return
                yield  # noqa: E501

            mock_agent.run_stream_events = _capture_stream
            await toolset.tools["task"].function(
                ctx, subagent_type="explorer", description="Explore the graph"
            )

        assert captured_description is not None
        assert "get_plan" not in captured_description
        assert "Explore the graph" in captured_description

    @pytest.mark.asyncio
    async def test_plan_id_from_active_plan_id(self) -> None:
        """Plan ID is read from state.active_plan_id first."""
        configs = [_make_subagent_config("mechanic")]
        toolset = create_streaming_subagent_toolset(subagents=configs)

        state = AgentState()
        state.active_plan_id = "plan_abc"
        deps = _make_deps(state=state)
        ctx = _FakeCtx(deps=deps)

        captured_description = None

        with patch("lineage.agent.pydantic.streaming_subagents.Agent") as MockAgent, \
             patch("lineage.agent.pydantic.streaming_subagents.create_model", return_value="test-model"):
            mock_agent = AsyncMock()
            MockAgent.return_value = mock_agent

            async def _capture_stream(desc, **kw):
                nonlocal captured_description
                captured_description = desc
                return
                yield  # noqa: E501

            mock_agent.run_stream_events = _capture_stream
            await toolset.tools["task"].function(
                ctx, subagent_type="mechanic", description="Fix the bug"
            )

        assert "plan_abc" in captured_description

    @pytest.mark.asyncio
    async def test_plan_id_fallback_to_threads_backend(self) -> None:
        """When state has no plan_id, falls back to threads_backend metadata."""
        configs = [_make_subagent_config("executor")]
        toolset = create_streaming_subagent_toolset(subagents=configs)

        threads_backend = _FakeThreadsBackend()
        threads_backend.set_metadata("t1", "active_plan_id", "plan_from_thread")

        state = AgentState()
        # No active_plan_id or active_plans set
        deps = _make_deps(threads_backend=threads_backend, state=state)
        ctx = _FakeCtx(deps=deps)

        captured_description = None

        with patch("lineage.agent.pydantic.streaming_subagents.Agent") as MockAgent, \
             patch("lineage.agent.pydantic.streaming_subagents.create_model", return_value="test-model"):
            mock_agent = AsyncMock()
            MockAgent.return_value = mock_agent

            async def _capture_stream(desc, **kw):
                nonlocal captured_description
                captured_description = desc
                return
                yield  # noqa: E501

            mock_agent.run_stream_events = _capture_stream
            await toolset.tools["task"].function(
                ctx, subagent_type="executor", description="Build the model"
            )

        assert "plan_from_thread" in captured_description

    @pytest.mark.asyncio
    async def test_injection_skipped_if_description_mentions_get_plan(self) -> None:
        """If description already mentions get_plan, skip prefix injection."""
        configs = [_make_subagent_config("executor")]
        toolset = create_streaming_subagent_toolset(subagents=configs)

        state = AgentState()
        state.active_plan_id = "plan_xyz"
        deps = _make_deps(state=state)
        ctx = _FakeCtx(deps=deps)

        captured_description = None

        with patch("lineage.agent.pydantic.streaming_subagents.Agent") as MockAgent, \
             patch("lineage.agent.pydantic.streaming_subagents.create_model", return_value="test-model"):
            mock_agent = AsyncMock()
            MockAgent.return_value = mock_agent

            async def _capture_stream(desc, **kw):
                nonlocal captured_description
                captured_description = desc
                return
                yield  # noqa: E501

            mock_agent.run_stream_events = _capture_stream
            await toolset.tools["task"].function(
                ctx,
                subagent_type="executor",
                description="First call get_plan() then implement the feature",
            )

        # Should NOT be double-prefixed
        assert captured_description is not None
        assert captured_description.startswith("First call get_plan()")


# ---------------------------------------------------------------------------
# Tests: subagent resolution
# ---------------------------------------------------------------------------


class TestSubagentResolution:
    """Tests for subagent config lookup and caching."""

    @pytest.mark.asyncio
    async def test_config_not_found_returns_error(self) -> None:
        """Valid SubagentType but no matching config returns an error."""
        # Only provide "coder" config but ask for "explorer" (valid enum but not configured)
        configs = [_make_subagent_config("coder")]
        toolset = create_streaming_subagent_toolset(subagents=configs)
        ctx = _FakeCtx(deps=_make_deps())

        result = await toolset.tools["task"].function(
            ctx, subagent_type="explorer", description="Explore"
        )
        assert isinstance(result, str)
        assert "unknown" in result.lower() or "error" in result.lower()

    @pytest.mark.asyncio
    async def test_subagent_cached_after_first_creation(self) -> None:
        """Agent instances are reused after initial creation."""
        configs = [_make_subagent_config("explorer")]
        toolset = create_streaming_subagent_toolset(subagents=configs)
        ctx = _FakeCtx(deps=_make_deps())

        agent_instances = []

        with patch("lineage.agent.pydantic.streaming_subagents.Agent") as MockAgent, \
             patch("lineage.agent.pydantic.streaming_subagents.create_model", return_value="test-model"):
            mock_agent = AsyncMock()
            MockAgent.return_value = mock_agent

            def _track_creation(*a, **kw):
                inst = AsyncMock()

                async def _fake_stream(*a2, **kw2):
                    return
                    yield  # noqa: E501

                inst.run_stream_events = _fake_stream
                agent_instances.append(inst)
                return inst

            MockAgent.side_effect = _track_creation

            # First call creates
            await toolset.tools["task"].function(
                ctx, subagent_type="explorer", description="Task 1"
            )
            # Second call should reuse
            await toolset.tools["task"].function(
                ctx, subagent_type="explorer", description="Task 2"
            )

        # Agent constructor should only be called once
        assert len(agent_instances) == 1


# ---------------------------------------------------------------------------
# Tests: return values
# ---------------------------------------------------------------------------


class TestReturnValues:
    """Tests for error and cancellation return values."""

    @pytest.mark.asyncio
    async def test_error_returns_error_string(self) -> None:
        """Exception during subagent execution returns an error string."""
        configs = [_make_subagent_config("explorer")]
        toolset = create_streaming_subagent_toolset(subagents=configs)
        ctx = _FakeCtx(deps=_make_deps())

        with patch("lineage.agent.pydantic.streaming_subagents.Agent") as MockAgent, \
             patch("lineage.agent.pydantic.streaming_subagents.create_model", return_value="test-model"):
            mock_agent = AsyncMock()
            MockAgent.return_value = mock_agent

            async def _fail_stream(*a, **kw):
                raise RuntimeError("LLM exploded")
                yield  # noqa: E501

            mock_agent.run_stream_events = _fail_stream
            result = await toolset.tools["task"].function(
                ctx, subagent_type="explorer", description="Test"
            )

        assert isinstance(result, str)
        assert "failed" in result.lower()
        assert "LLM exploded" in result

    @pytest.mark.asyncio
    async def test_cancellation_returns_message(self) -> None:
        """When deps.is_cancelled is set, subagent returns a cancellation message."""
        configs = [_make_subagent_config("explorer")]
        toolset = create_streaming_subagent_toolset(subagents=configs)
        deps = _make_deps()
        ctx = _FakeCtx(deps=deps)

        with patch("lineage.agent.pydantic.streaming_subagents.Agent") as MockAgent, \
             patch("lineage.agent.pydantic.streaming_subagents.create_model", return_value="test-model"):
            mock_agent = AsyncMock()
            MockAgent.return_value = mock_agent

            async def _stream_with_cancel(*a, **kw):
                # Signal cancellation before yielding any event
                deps.request_cancellation()
                yield MagicMock()  # Yield at least one event so the loop runs

            mock_agent.run_stream_events = _stream_with_cancel
            result = await toolset.tools["task"].function(
                ctx, subagent_type="explorer", description="Test"
            )

        assert isinstance(result, str)
        assert "cancelled" in result.lower()
