"""Integration tests for SalesforceLoader and SalesforceStitcher with mock client."""
from __future__ import annotations

import asyncio
import sys
from typing import Any, Optional
from unittest.mock import MagicMock, patch

from lineage.backends.lineage.models.edges import (
    MapsToColumn,
    SfComponentUsesReport,
    SfReferences,
    SfReportColumnUsesField,
    SfReportDependsOnObject,
    SourceDependsOn,
)
from lineage.backends.lineage.models.salesforce import (
    SalesforceOrg,
    SfDashboard,
    SfDashboardComponent,
    SfField,
    SfObject,
    SfReport,
    SfReportColumn,
)
from lineage.ingest.static_loaders.salesforce.loader import SalesforceLoader
from lineage.ingest.static_loaders.salesforce.stitcher import SalesforceStitcher

# ---------------------------------------------------------------------------
# Mock client
# ---------------------------------------------------------------------------

def _make_mock_client() -> MagicMock:
    """Build a mock SalesforceMetadataClient with realistic fixture data."""
    client = MagicMock()
    client.api_version = "61.0"

    # Phase 1: org info
    client.get_org_info.return_value = {
        "org_id": "00D000000000001",
        "name": "TestOrg",
        "instance_url": "https://test.salesforce.com",
        "is_sandbox": True,
        "org_type": "Developer",
    }

    # Phase 2: SObjects
    client.list_sobjects.return_value = [
        {"name": "Account", "custom": False, "queryable": True, "keyPrefix": "001", "label": "Account"},
        {"name": "Opportunity", "custom": False, "queryable": True, "keyPrefix": "006", "label": "Opportunity"},
        {"name": "Custom_Obj__c", "custom": True, "queryable": True, "keyPrefix": "a01", "label": "Custom Object"},
    ]

    def _describe_sobject(api_name: str) -> dict:
        fields_map: dict[str, list[dict]] = {
            "Account": [
                {"name": "Id", "type": "id", "custom": False, "nillable": False, "length": 18, "referenceTo": [], "calculatedFormula": None, "label": "Account ID"},
                {"name": "Name", "type": "string", "custom": False, "nillable": False, "length": 255, "referenceTo": [], "calculatedFormula": None, "label": "Account Name"},
                {"name": "OwnerId", "type": "reference", "custom": False, "nillable": False, "length": 18, "referenceTo": ["User"], "calculatedFormula": None, "label": "Owner ID"},
            ],
            "Opportunity": [
                {"name": "Id", "type": "id", "custom": False, "nillable": False, "length": 18, "referenceTo": [], "calculatedFormula": None, "label": "Opportunity ID"},
                {"name": "AccountId", "type": "reference", "custom": False, "nillable": True, "length": 18, "referenceTo": ["Account"], "calculatedFormula": None, "label": "Account ID"},
                {"name": "Amount", "type": "currency", "custom": False, "nillable": True, "length": 0, "referenceTo": [], "calculatedFormula": None, "label": "Amount"},
            ],
            "Custom_Obj__c": [
                {"name": "Id", "type": "id", "custom": False, "nillable": False, "length": 18, "referenceTo": [], "calculatedFormula": None, "label": "Record ID"},
                {"name": "Custom_Field__c", "type": "string", "custom": True, "nillable": True, "length": 100, "referenceTo": [], "calculatedFormula": None, "label": "Custom Field"},
            ],
        }
        return {"fields": fields_map.get(api_name, [])}

    client.describe_sobject.side_effect = _describe_sobject

    # Phase 3: Reports
    client.list_reports.return_value = [
        {"id": "00O000000000001AAA", "name": "Pipeline Report", "reportTypeApiName": "Opportunity", "folderName": "Public Reports", "description": "Pipeline overview"},
    ]

    client.describe_report.return_value = {
        "reportMetadata": {
            "reportType": {"type": "OpportunityReport"},
            "detailColumns": ["Opportunity.Amount", "Account.Name"],
        },
    }

    # describe_report_type returns the SObjects backing a report type
    client.describe_report_type.return_value = {
        "reportTypeMetadata": {
            "objects": [
                {"apiName": "Opportunity"},
                {"apiName": "Account"},
            ]
        },
    }

    # Phase 4: Dashboards
    client.list_dashboards.return_value = [
        {"id": "01Z000000000001AAA", "name": "Sales Dashboard", "folderName": "Public Dashboards", "description": "Sales overview"},
    ]

    client.describe_dashboard.return_value = {
        "components": [
            {"id": "comp1", "title": "Pipeline Chart", "type": "chart", "reportId": "00O000000000001AAA"},
            {"id": "comp2", "title": "Summary", "type": "table", "reportId": None},
        ],
    }

    return client


# ---------------------------------------------------------------------------
# Mock storage with callable-based cypher handlers
# ---------------------------------------------------------------------------

class MockStorage:
    """In-memory storage that records upsert_node and create_edge calls.

    Uses a handler-list approach for ``query_cypher`` so that tests can
    register fragment+param_filter combinations returning different results.
    """

    def __init__(self) -> None:
        self.nodes: list[Any] = []
        self.edges: list[tuple[Any, Any, Any]] = []
        self._cypher_handlers: list[tuple[str, Optional[dict], list[dict]]] = []

    def upsert_node(self, node: Any) -> None:
        # Deduplicate by node id (mirrors real upsert semantics)
        node_id = getattr(node, "id", None)
        if node_id is not None:
            self.nodes = [n for n in self.nodes if getattr(n, "id", None) != node_id]
        self.nodes.append(node)

    def create_edge(self, from_node: Any, to_node: Any, edge: Any) -> None:
        self.edges.append((from_node, to_node, edge))

    def register_cypher(
        self,
        fragment: str,
        response: list[dict],
        *,
        param_filter: Optional[dict] = None,
    ) -> None:
        """Register a handler: fragment must be in query, and if
        param_filter is set every key/value must match params."""
        self._cypher_handlers.append((fragment, param_filter, response))

    def query_cypher(self, query: str, params: Optional[dict] = None) -> list[dict]:
        params = params or {}
        for fragment, pf, response in self._cypher_handlers:
            if fragment not in query:
                continue
            if pf and not all(params.get(k) == v for k, v in pf.items()):
                continue
            return response
        return []

    def execute_raw_query(self, query: str, params: Optional[dict] = None) -> Any:
        """Adapter for the stitcher's ``execute_raw_query`` protocol.

        Returns an object with a ``.rows`` attribute containing the matching
        handler rows (same data as ``query_cypher``).
        """
        rows = self.query_cypher(query, params)

        class _Result:
            def __init__(self, r: list[dict]) -> None:
                self.rows = r
        return _Result(rows)

    # Helpers
    def node_by_type(self, cls: type) -> list:
        return [n for n in self.nodes if isinstance(n, cls)]

    def edges_by_type(self, cls: type) -> list:
        return [(f, t, e) for f, t, e in self.edges if isinstance(e, cls)]


# ---------------------------------------------------------------------------
# Loader tests
# ---------------------------------------------------------------------------

class TestSalesforceLoader:
    def _run_loader(self, **kwargs: Any) -> tuple[MockStorage, SalesforceLoader]:
        client = _make_mock_client()
        storage = MockStorage()
        loader = SalesforceLoader(
            client=client,
            storage=storage,
            org_key="testorg",
            **kwargs,
        )
        asyncio.run(loader.load())
        return storage, loader

    def test_phase1_org_node_created(self) -> None:
        storage, _ = self._run_loader()
        orgs = storage.node_by_type(SalesforceOrg)
        assert len(orgs) == 1
        assert orgs[0].org_key == "testorg"

    def test_phase2_objects_created(self) -> None:
        storage, _ = self._run_loader()
        objects = storage.node_by_type(SfObject)
        assert len(objects) == 3
        names = {o.api_name for o in objects}
        assert names == {"Account", "Opportunity", "Custom_Obj__c"}

    def test_phase2_fields_created(self) -> None:
        storage, _ = self._run_loader()
        fields = storage.node_by_type(SfField)
        # Account: 3, Opportunity: 3, Custom_Obj__c: 2 = 8
        assert len(fields) == 8

    def test_phase2_references_edges(self) -> None:
        storage, _ = self._run_loader()
        ref_edges = storage.edges_by_type(SfReferences)
        # Opportunity.AccountId -> Account is the only one (User not ingested)
        assert len(ref_edges) == 1
        _, to_node, edge = ref_edges[0]
        assert to_node.api_name == "Account"
        assert edge.relationship_type == "Lookup"

    def test_phase2_sobject_filter(self) -> None:
        storage, _ = self._run_loader(sobject_filter=["Account"])
        objects = storage.node_by_type(SfObject)
        assert len(objects) == 1
        assert objects[0].api_name == "Account"

    def test_phase3_reports_created(self) -> None:
        storage, _ = self._run_loader()
        reports = storage.node_by_type(SfReport)
        assert len(reports) == 1
        assert reports[0].report_id == "00O000000000001AAA"

    def test_phase3_report_columns_created(self) -> None:
        storage, _ = self._run_loader()
        cols = storage.node_by_type(SfReportColumn)
        assert len(cols) == 2
        keys = {c.column_key for c in cols}
        assert keys == {"Opportunity.Amount", "Account.Name"}

    def test_phase3_column_object_api_name_from_dotted_key(self) -> None:
        """Dotted column keys should have object_api_name extracted from prefix."""
        storage, _ = self._run_loader()
        cols = storage.node_by_type(SfReportColumn)
        # Account.Name should have object_api_name = "Account"
        account_col = next(c for c in cols if c.column_key == "Account.Name")
        assert account_col.object_api_name == "Account"
        # Opportunity.Amount should have object_api_name = "Opportunity"
        opp_col = next(c for c in cols if c.column_key == "Opportunity.Amount")
        assert opp_col.object_api_name == "Opportunity"

    def test_phase3_report_depends_on_object(self) -> None:
        storage, _ = self._run_loader()
        deps = storage.edges_by_type(SfReportDependsOnObject)
        assert len(deps) == 2  # Opportunity + Account from report type metadata
        # All edges created with role="source" per current loader implementation
        roles = {e.role for _, _, e in deps}
        assert roles == {"source"}

    def test_phase3_column_resolution_exact(self) -> None:
        """Both Opportunity.Amount and Account.Name should resolve exactly."""
        storage, _ = self._run_loader()
        uses = storage.edges_by_type(SfReportColumnUsesField)
        exact = [(f, t, e) for f, t, e in uses if e.resolution == "exact"]
        assert len(exact) == 2
        # Verify endpoints
        resolved_fields = {t.field_api_name for _, t, _ in exact}
        assert resolved_fields == {"Amount", "Name"}

    def test_phase3_no_reports_flag(self) -> None:
        storage, _ = self._run_loader(include_reports=False)
        reports = storage.node_by_type(SfReport)
        assert len(reports) == 0

    def test_phase4_dashboards_created(self) -> None:
        storage, _ = self._run_loader()
        dashboards = storage.node_by_type(SfDashboard)
        assert len(dashboards) == 1

    def test_phase4_components_created(self) -> None:
        storage, _ = self._run_loader()
        comps = storage.node_by_type(SfDashboardComponent)
        assert len(comps) == 2

    def test_phase4_component_uses_report(self) -> None:
        storage, _ = self._run_loader()
        uses = storage.edges_by_type(SfComponentUsesReport)
        # comp1 links to report, comp2 does not
        assert len(uses) == 1
        from_node, to_node, _ = uses[0]
        assert from_node.component_key == "comp1"
        assert to_node.report_id == "00O000000000001AAA"

    def test_phase4_no_dashboards_flag(self) -> None:
        storage, _ = self._run_loader(include_dashboards=False)
        dashboards = storage.node_by_type(SfDashboard)
        assert len(dashboards) == 0

    # ------------------------------------------------------------------
    # Exclude pattern / exclude list tests
    # ------------------------------------------------------------------

    def test_exclude_patterns_filter_objects(self) -> None:
        """Glob patterns like '*Feed' exclude matching SObjects."""
        client = _make_mock_client()
        # Add Feed/History objects to the mock
        client.list_sobjects.return_value.extend([
            {"name": "AccountFeed", "custom": False, "queryable": True, "keyPrefix": None, "label": "Account Feed"},
            {"name": "OpportunityHistory", "custom": False, "queryable": True, "keyPrefix": None, "label": "Opportunity History"},
            {"name": "AccountShare", "custom": False, "queryable": True, "keyPrefix": None, "label": "Account Share"},
        ])
        storage = MockStorage()
        loader = SalesforceLoader(
            client=client,
            storage=storage,
            org_key="testorg",
            sobject_exclude_patterns=["*Feed", "*History", "*Share"],
        )
        asyncio.run(loader.load())
        objects = storage.node_by_type(SfObject)
        names = {o.api_name for o in objects}
        assert "AccountFeed" not in names
        assert "OpportunityHistory" not in names
        assert "AccountShare" not in names
        # Original objects still present
        assert "Account" in names
        assert "Opportunity" in names
        assert "Custom_Obj__c" in names

    def test_exclude_explicit_list(self) -> None:
        """Explicit exclude list removes specific SObjects."""
        client = _make_mock_client()
        client.list_sobjects.return_value.append(
            {"name": "Task", "custom": False, "queryable": True, "keyPrefix": "00T", "label": "Task"},
        )
        storage = MockStorage()
        loader = SalesforceLoader(
            client=client,
            storage=storage,
            org_key="testorg",
            sobject_exclude=["Task", "Custom_Obj__c"],
        )
        asyncio.run(loader.load())
        objects = storage.node_by_type(SfObject)
        names = {o.api_name for o in objects}
        assert "Task" not in names
        assert "Custom_Obj__c" not in names
        assert "Account" in names
        assert "Opportunity" in names

    def test_cleanup_excluded_objects_from_graph(self) -> None:
        """Stale SfObject nodes from prior loads are deleted when they match exclude rules."""
        client = _make_mock_client()
        storage = MockStorage()
        # Simulate stale nodes in the graph from a prior unfiltered load
        storage.register_cypher(
            "MATCH (o:SfObject)",
            [
                {"api_name": "Account"},
                {"api_name": "AccountFeed"},
                {"api_name": "Task"},
            ],
        )
        loader = SalesforceLoader(
            client=client,
            storage=storage,
            org_key="testorg",
            sobject_exclude_patterns=["*Feed"],
            sobject_exclude=["Task"],
        )
        # The cleanup runs during load, issuing DELETE queries for AccountFeed and Task.
        # We verify the DELETE queries were issued by checking execute_raw_query was called
        # with the right api_names.
        delete_queries: list[tuple[str, dict]] = []
        original_execute = storage.execute_raw_query

        def _tracking_execute(query: str, params: dict | None = None) -> Any:
            if "DELETE" in query:
                delete_queries.append((query, params or {}))
            return original_execute(query, params)

        storage.execute_raw_query = _tracking_execute  # type: ignore[assignment]
        asyncio.run(loader.load())

        # Should have issued DELETE for AccountFeed and Task (2 objects x 2 queries each)
        deleted_names = {q[1].get("api_name") for q in delete_queries}
        assert "AccountFeed" in deleted_names
        assert "Task" in deleted_names
        assert "Account" not in deleted_names

    def test_whitelist_takes_precedence_over_excludes(self) -> None:
        """When sobject_filter (whitelist) is set, exclude lists are ignored."""
        client = _make_mock_client()
        client.list_sobjects.return_value.append(
            {"name": "AccountFeed", "custom": False, "queryable": True, "keyPrefix": None, "label": "Account Feed"},
        )
        storage = MockStorage()
        loader = SalesforceLoader(
            client=client,
            storage=storage,
            org_key="testorg",
            sobject_filter=["Account", "AccountFeed"],
            sobject_exclude_patterns=["*Feed"],
            sobject_exclude=["Account"],
        )
        asyncio.run(loader.load())
        objects = storage.node_by_type(SfObject)
        names = {o.api_name for o in objects}
        # Both should be present because whitelist overrides excludes
        assert "Account" in names
        assert "AccountFeed" in names
        assert len(objects) == 2


# ---------------------------------------------------------------------------
# Loader degradation tests
# ---------------------------------------------------------------------------

class TestSalesforceLoaderDegradation:
    """Test graceful degradation when API calls fail."""

    def test_describe_sobject_exception_preserves_object(self) -> None:
        """If describe_sobject raises for Account, Account SfObject still exists but no SfField for it."""
        client = _make_mock_client()
        original_describe = client.describe_sobject.side_effect

        def _describe_with_failure(api_name: str) -> dict:
            if api_name == "Account":
                raise RuntimeError("API error")
            return original_describe(api_name)

        client.describe_sobject.side_effect = _describe_with_failure
        storage = MockStorage()
        loader = SalesforceLoader(client=client, storage=storage, org_key="testorg")
        asyncio.run(loader.load())

        objects = storage.node_by_type(SfObject)
        assert len(objects) == 3  # All 3 objects still created
        fields = storage.node_by_type(SfField)
        # Account fields missing (3), Opportunity (3) + Custom_Obj__c (2) = 5
        assert len(fields) == 5
        account_fields = [f for f in fields if f.object_api_name == "Account"]
        assert len(account_fields) == 0

    def test_list_reports_exception_skips_phase3(self) -> None:
        """If list_reports raises, no SfReport nodes but SfObject nodes still exist."""
        client = _make_mock_client()
        client.list_reports.side_effect = RuntimeError("API error")
        storage = MockStorage()
        loader = SalesforceLoader(client=client, storage=storage, org_key="testorg")
        asyncio.run(loader.load())

        assert len(storage.node_by_type(SfReport)) == 0
        assert len(storage.node_by_type(SfObject)) == 3

    def test_describe_report_exception_preserves_report(self) -> None:
        """If describe_report raises, SfReport node exists but no SfReportColumn."""
        client = _make_mock_client()
        client.describe_report.side_effect = RuntimeError("API error")
        storage = MockStorage()
        loader = SalesforceLoader(client=client, storage=storage, org_key="testorg")
        asyncio.run(loader.load())

        reports = storage.node_by_type(SfReport)
        assert len(reports) == 1
        cols = storage.node_by_type(SfReportColumn)
        assert len(cols) == 0

    def test_list_dashboards_exception_skips_phase4(self) -> None:
        """If list_dashboards raises, no SfDashboard nodes."""
        client = _make_mock_client()
        client.list_dashboards.side_effect = RuntimeError("API error")
        storage = MockStorage()
        loader = SalesforceLoader(client=client, storage=storage, org_key="testorg")
        asyncio.run(loader.load())

        assert len(storage.node_by_type(SfDashboard)) == 0
        # Other phases still ran
        assert len(storage.node_by_type(SfObject)) == 3

    def test_describe_dashboard_exception_preserves_dashboard(self) -> None:
        """If describe_dashboard raises, SfDashboard exists but no SfDashboardComponent."""
        client = _make_mock_client()
        client.describe_dashboard.side_effect = RuntimeError("API error")
        storage = MockStorage()
        loader = SalesforceLoader(client=client, storage=storage, org_key="testorg")
        asyncio.run(loader.load())

        dashboards = storage.node_by_type(SfDashboard)
        assert len(dashboards) == 1
        comps = storage.node_by_type(SfDashboardComponent)
        assert len(comps) == 0


# ---------------------------------------------------------------------------
# Column resolution branch tests
# ---------------------------------------------------------------------------

class TestColumnResolution:
    """Test all branches of _resolve_column_to_field."""

    def _make_client_with_columns(self, detail_columns: list[str]) -> MagicMock:
        """Client with custom report detail columns."""
        client = _make_mock_client()
        client.describe_report.return_value = {
            "reportType": {"relationships": []},
            "reportMetadata": {"detailColumns": detail_columns},
        }
        return client

    def test_exact_resolution_both_columns(self) -> None:
        """Default fixture: Opportunity.Amount and Account.Name resolve exactly."""
        client = _make_mock_client()
        storage = MockStorage()
        loader = SalesforceLoader(client=client, storage=storage, org_key="testorg")
        asyncio.run(loader.load())

        uses = storage.edges_by_type(SfReportColumnUsesField)
        exact = [(f, t, e) for f, t, e in uses if e.resolution == "exact"]
        assert len(exact) == 2
        for _, _, e in exact:
            assert e.confidence == 1.0

    def test_heuristic_single_candidate(self) -> None:
        """Column key with no dot, unique field name across all objects -> heuristic 0.8."""
        client = self._make_client_with_columns(["Amount"])
        storage = MockStorage()
        loader = SalesforceLoader(client=client, storage=storage, org_key="testorg")
        asyncio.run(loader.load())

        uses = storage.edges_by_type(SfReportColumnUsesField)
        # "Amount" only exists on Opportunity -> single candidate
        assert len(uses) == 1
        _, to_node, edge = uses[0]
        assert edge.resolution == "heuristic"
        assert edge.confidence == 0.8
        assert to_node.field_api_name == "Amount"

    def test_heuristic_ambiguous_candidates(self) -> None:
        """Column key 'Id' exists on multiple objects -> heuristic 0.5."""
        client = self._make_client_with_columns(["Id"])
        storage = MockStorage()
        loader = SalesforceLoader(client=client, storage=storage, org_key="testorg")
        asyncio.run(loader.load())

        uses = storage.edges_by_type(SfReportColumnUsesField)
        assert len(uses) == 1
        _, _, edge = uses[0]
        assert edge.resolution == "heuristic"
        assert edge.confidence == 0.5

    def test_unresolvable_column_no_edge(self) -> None:
        """Column key with no matching field -> SfReportColumn exists, no USES_FIELD edge."""
        client = self._make_client_with_columns(["NONEXISTENT_FIELD"])
        storage = MockStorage()
        loader = SalesforceLoader(client=client, storage=storage, org_key="testorg")
        asyncio.run(loader.load())

        cols = storage.node_by_type(SfReportColumn)
        assert len(cols) == 1
        assert cols[0].column_key == "NONEXISTENT_FIELD"
        uses = storage.edges_by_type(SfReportColumnUsesField)
        assert len(uses) == 0

    def test_three_part_column_key(self) -> None:
        """Column key 'A.B.Amount' -> 2 parts fail exact, falls to heuristic searching 'Amount'."""
        client = self._make_client_with_columns(["A.B.Amount"])
        storage = MockStorage()
        loader = SalesforceLoader(client=client, storage=storage, org_key="testorg")
        asyncio.run(loader.load())

        uses = storage.edges_by_type(SfReportColumnUsesField)
        # Heuristic search for "Amount" -> single candidate on Opportunity
        assert len(uses) == 1
        _, _, edge = uses[0]
        assert edge.resolution == "heuristic"

    def test_object_api_name_from_col_to_obj_mapping(self) -> None:
        """Non-dotted column keys get object_api_name from reportTypeMetadata.categories."""
        client = _make_mock_client()
        # Override to use non-dotted column keys
        client.describe_report.return_value = {
            "reportMetadata": {
                "reportType": {"type": "OpportunityReport"},
                "detailColumns": ["AMOUNT", "CLOSE_DATE"],
            },
        }
        # Add categories to report type metadata for mapping
        client.describe_report_type.return_value = {
            "reportTypeMetadata": {
                "objects": [
                    {"apiName": "Opportunity", "name": "Opportunity"},
                ],
                "categories": [
                    {
                        "label": "Opportunity Information",
                        "columns": {"AMOUNT": {}, "CLOSE_DATE": {}},
                    },
                ],
            },
        }
        storage = MockStorage()
        loader = SalesforceLoader(client=client, storage=storage, org_key="testorg")
        asyncio.run(loader.load())

        cols = storage.node_by_type(SfReportColumn)
        assert len(cols) == 2
        # Both columns should have object_api_name from category mapping
        amount_col = next(c for c in cols if c.column_key == "AMOUNT")
        assert amount_col.object_api_name == "Opportunity"
        close_date_col = next(c for c in cols if c.column_key == "CLOSE_DATE")
        assert close_date_col.object_api_name == "Opportunity"


# ---------------------------------------------------------------------------
# Dashboard component edge case tests
# ---------------------------------------------------------------------------

class TestDashboardComponentEdgeCases:
    def test_component_no_id_uses_hash(self) -> None:
        """Component dict without 'id' key gets a 12-char hex component_key."""
        client = _make_mock_client()
        client.describe_dashboard.return_value = {
            "components": [
                {"title": "No ID Chart", "type": "chart", "reportId": None},
            ],
        }
        storage = MockStorage()
        loader = SalesforceLoader(client=client, storage=storage, org_key="testorg")
        asyncio.run(loader.load())

        comps = storage.node_by_type(SfDashboardComponent)
        assert len(comps) == 1
        assert len(comps[0].component_key) == 12
        # Should be hex characters
        int(comps[0].component_key, 16)

    def test_component_report_id_not_in_graph(self) -> None:
        """Component has reportId but that report was not ingested -> no SfComponentUsesReport edge."""
        client = _make_mock_client()
        client.describe_dashboard.return_value = {
            "components": [
                {"id": "comp_x", "title": "Orphan Chart", "type": "chart", "reportId": "00O_NOT_INGESTED"},
            ],
        }
        storage = MockStorage()
        loader = SalesforceLoader(client=client, storage=storage, org_key="testorg")
        asyncio.run(loader.load())

        comps = storage.node_by_type(SfDashboardComponent)
        assert len(comps) == 1
        uses = storage.edges_by_type(SfComponentUsesReport)
        assert len(uses) == 0

    def test_report_with_empty_id_skipped(self) -> None:
        """Report dict has 'id': '' -> no SfReport node."""
        client = _make_mock_client()
        client.list_reports.return_value = [
            {"id": "", "name": "Bad Report"},
        ]
        storage = MockStorage()
        loader = SalesforceLoader(client=client, storage=storage, org_key="testorg")
        asyncio.run(loader.load())

        reports = storage.node_by_type(SfReport)
        assert len(reports) == 0

    def test_dashboard_with_empty_id_skipped(self) -> None:
        """Dashboard dict has 'id': '' -> no SfDashboard node."""
        client = _make_mock_client()
        client.list_dashboards.return_value = [
            {"id": "", "name": "Bad Dashboard"},
        ]
        storage = MockStorage()
        loader = SalesforceLoader(client=client, storage=storage, org_key="testorg")
        asyncio.run(loader.load())

        dashboards = storage.node_by_type(SfDashboard)
        assert len(dashboards) == 0


# ---------------------------------------------------------------------------
# Stitcher tests
# ---------------------------------------------------------------------------

class TestSalesforceStitcher:
    def _make_storage_with_dbt(self) -> MockStorage:
        """Storage pre-populated with DbtSource + DbtColumn for stitching tests."""
        storage = MockStorage()

        # DbtSource nodes
        storage.register_cypher(
            "MATCH (s:DbtSource) RETURN",
            [
                {"id": "source.pkg.account", "name": "account"},
                {"id": "source.pkg.opportunity", "name": "opportunity"},
            ],
        )

        # SfObject nodes
        storage.register_cypher(
            "MATCH (o:SfObject) WHERE",
            [
                {"id": "sf_object::testorg::Account", "api_name": "Account"},
                {"id": "sf_object::testorg::Opportunity", "api_name": "Opportunity"},
                {"id": "sf_object::testorg::Custom_Obj__c", "api_name": "Custom_Obj__c"},
            ],
        )

        # DbtColumn nodes for Account source
        storage.register_cypher(
            "MATERIALIZES",
            [
                {"id": "col.account.name", "name": "name"},
                {"id": "col.account.id", "name": "id"},
            ],
            param_filter={"sid": "source.pkg.account"},
        )

        # DbtColumn nodes for Opportunity source
        storage.register_cypher(
            "MATERIALIZES",
            [
                {"id": "col.opportunity.amount", "name": "amount"},
                {"id": "col.opportunity.accountid", "name": "accountid"},
            ],
            param_filter={"sid": "source.pkg.opportunity"},
        )

        # SfField nodes for Account
        storage.register_cypher(
            "SF_HAS_FIELD",
            [
                {"id": "sf_field::testorg::Account::Name", "field_api_name": "Name"},
                {"id": "sf_field::testorg::Account::Id", "field_api_name": "Id"},
            ],
            param_filter={"oid": "sf_object::testorg::Account"},
        )

        # SfField nodes for Opportunity
        storage.register_cypher(
            "SF_HAS_FIELD",
            [
                {"id": "sf_field::testorg::Opportunity::Amount", "field_api_name": "Amount"},
                {"id": "sf_field::testorg::Opportunity::AccountId", "field_api_name": "AccountId"},
            ],
            param_filter={"oid": "sf_object::testorg::Opportunity"},
        )

        return storage

    def test_tier1_source_matching(self) -> None:
        storage = self._make_storage_with_dbt()
        stitcher = SalesforceStitcher(
            storage=storage, org_key="testorg", use_llm=False
        )
        counts = stitcher.stitch()
        # Account and Opportunity should match
        assert counts["source_matches"] == 2

    def test_tier1_column_matching(self) -> None:
        storage = self._make_storage_with_dbt()
        stitcher = SalesforceStitcher(
            storage=storage, org_key="testorg", use_llm=False
        )
        counts = stitcher.stitch()
        # Account: Name + Id matched; Opportunity: Amount + AccountId matched = 4
        assert counts["column_matches"] == 4

    def test_tier1_custom_object_suffix_strip(self) -> None:
        """Custom_Obj__c should not match any dbt source (no 'custom_obj' source exists)."""
        storage = self._make_storage_with_dbt()
        stitcher = SalesforceStitcher(
            storage=storage, org_key="testorg", use_llm=False
        )
        counts = stitcher.stitch()
        # Only Account and Opportunity match; Custom_Obj__c is unmatched
        assert counts["source_matches"] == 2

    def test_no_dbt_sources_skips(self) -> None:
        storage = MockStorage()
        storage.register_cypher("MATCH (s:DbtSource)", [])
        stitcher = SalesforceStitcher(
            storage=storage, org_key="testorg", use_llm=False
        )
        counts = stitcher.stitch()
        assert counts["source_matches"] == 0

    def test_no_sf_objects_skips(self) -> None:
        storage = MockStorage()
        storage.register_cypher(
            "MATCH (s:DbtSource) RETURN",
            [{"id": "source.pkg.account", "name": "account"}],
        )
        storage.register_cypher("MATCH (o:SfObject) WHERE", [])
        stitcher = SalesforceStitcher(
            storage=storage, org_key="testorg", use_llm=False
        )
        counts = stitcher.stitch()
        assert counts["source_matches"] == 0

    def test_stitch_edges_recorded(self) -> None:
        """Verify that actual edge objects are created in storage."""
        storage = self._make_storage_with_dbt()
        stitcher = SalesforceStitcher(
            storage=storage, org_key="testorg", use_llm=False
        )
        stitcher.stitch()

        source_edges = storage.edges_by_type(SourceDependsOn)
        column_edges = storage.edges_by_type(MapsToColumn)
        assert len(source_edges) == 2
        assert len(column_edges) == 4

        # All edges should have source="heuristic"
        for _, _, e in source_edges:
            assert e.source == "heuristic"

    def test_stitch_edge_endpoints(self) -> None:
        """Verify from/to IDs on stitch edges (DbtSource -> SfObject)."""
        storage = self._make_storage_with_dbt()
        stitcher = SalesforceStitcher(
            storage=storage, org_key="testorg", use_llm=False
        )
        stitcher.stitch()

        source_edges = storage.edges_by_type(SourceDependsOn)
        from_ids = {f.id for f, _, _ in source_edges}
        to_ids = {t.id for _, t, _ in source_edges}
        assert "source.pkg.account" in from_ids
        assert "source.pkg.opportunity" in from_ids
        assert "sf_object::testorg::Account" in to_ids
        assert "sf_object::testorg::Opportunity" in to_ids


# ---------------------------------------------------------------------------
# Stitcher suffix-stripping tests (validates bug fixes)
# ---------------------------------------------------------------------------

class TestStitcherSuffixStrip:
    def test_tier1_suffix_strip_matches(self) -> None:
        """SfObject Custom_Obj__c + DbtSource custom_obj -> strip_suffix match."""
        storage = MockStorage()
        storage.register_cypher(
            "MATCH (s:DbtSource) RETURN",
            [{"id": "source.pkg.custom_obj", "name": "custom_obj"}],
        )
        storage.register_cypher(
            "MATCH (o:SfObject) WHERE",
            [{"id": "sf_object::testorg::Custom_Obj__c", "api_name": "Custom_Obj__c"}],
        )
        # No columns
        storage.register_cypher("MATERIALIZES", [])
        storage.register_cypher("SF_HAS_FIELD", [])

        stitcher = SalesforceStitcher(storage=storage, org_key="testorg", use_llm=False)
        counts = stitcher.stitch()

        assert counts["source_matches"] == 1
        source_edges = storage.edges_by_type(SourceDependsOn)
        assert len(source_edges) == 1
        _, _, edge = source_edges[0]
        assert edge.rule_id == "strip_suffix"
        assert edge.confidence == 0.9

    def test_tier1_exact_match_preferred_over_suffix(self) -> None:
        """SfObject Account + DbtSource account -> exact_name match."""
        storage = MockStorage()
        storage.register_cypher(
            "MATCH (s:DbtSource) RETURN",
            [{"id": "source.pkg.account", "name": "account"}],
        )
        storage.register_cypher(
            "MATCH (o:SfObject) WHERE",
            [{"id": "sf_object::testorg::Account", "api_name": "Account"}],
        )
        storage.register_cypher("MATERIALIZES", [])
        storage.register_cypher("SF_HAS_FIELD", [])

        stitcher = SalesforceStitcher(storage=storage, org_key="testorg", use_llm=False)
        counts = stitcher.stitch()

        assert counts["source_matches"] == 1
        source_edges = storage.edges_by_type(SourceDependsOn)
        assert len(source_edges) == 1
        _, _, edge = source_edges[0]
        assert edge.rule_id == "exact_name"
        assert edge.confidence == 1.0

    def test_tier1_column_suffix_strip_matches(self) -> None:
        """SfField Custom_Field__c + DbtColumn custom_field -> strip_suffix match."""
        storage = MockStorage()
        storage.register_cypher(
            "MATCH (s:DbtSource) RETURN",
            [{"id": "source.pkg.account", "name": "account"}],
        )
        storage.register_cypher(
            "MATCH (o:SfObject) WHERE",
            [{"id": "sf_object::testorg::Account", "api_name": "Account"}],
        )
        storage.register_cypher(
            "MATERIALIZES",
            [{"id": "col.account.custom_field", "name": "custom_field"}],
            param_filter={"sid": "source.pkg.account"},
        )
        storage.register_cypher(
            "SF_HAS_FIELD",
            [{"id": "sf_field::testorg::Account::Custom_Field__c", "field_api_name": "Custom_Field__c"}],
            param_filter={"oid": "sf_object::testorg::Account"},
        )

        stitcher = SalesforceStitcher(storage=storage, org_key="testorg", use_llm=False)
        counts = stitcher.stitch()

        assert counts["column_matches"] == 1
        col_edges = storage.edges_by_type(MapsToColumn)
        assert len(col_edges) == 1
        _, _, edge = col_edges[0]
        assert edge.rule_id == "strip_suffix"
        assert edge.confidence == 0.9


# ---------------------------------------------------------------------------
# Tier 2 LLM stitcher tests
# ---------------------------------------------------------------------------

class TestStitcherTier2:
    def _make_unmatched_storage(self) -> MockStorage:
        """Storage where Custom_Obj__c has no deterministic match."""
        storage = MockStorage()
        storage.register_cypher(
            "MATCH (s:DbtSource) RETURN",
            [{"id": "source.pkg.custom_obj", "name": "custom_obj"}],
        )
        storage.register_cypher(
            "MATCH (o:SfObject) WHERE",
            [{"id": "sf_object::testorg::UnknownObj", "api_name": "UnknownObj"}],
        )
        storage.register_cypher("MATERIALIZES", [])
        storage.register_cypher("SF_HAS_FIELD", [])
        return storage

    @patch("lineage.ingest.static_loaders.salesforce.stitcher.SalesforceStitcher._tier2_llm")
    def test_tier2_called_when_unmatched_and_enabled(self, mock_tier2: MagicMock) -> None:
        """Tier 2 is invoked when there are unmatched objects and use_llm=True."""
        mock_tier2.return_value = None
        storage = self._make_unmatched_storage()

        mock_fenic = MagicMock()
        mock_fenic.session.return_value = MagicMock()

        stitcher = SalesforceStitcher(
            storage=storage, org_key="testorg", use_llm=True,
            analysis_models=MagicMock(),
        )
        with patch.dict(sys.modules, {"fenic": mock_fenic}), \
             patch(
                 "lineage.ingest.static_loaders.semantic.config.session.create_session",
                 return_value=MagicMock(),
             ):
            stitcher.stitch()
        mock_tier2.assert_called_once()

    @patch("lineage.ingest.static_loaders.salesforce.stitcher.SalesforceStitcher._tier2_llm")
    def test_tier2_not_called_when_disabled(self, mock_tier2: MagicMock) -> None:
        """Tier 2 is not invoked when use_llm=False."""
        storage = self._make_unmatched_storage()
        stitcher = SalesforceStitcher(storage=storage, org_key="testorg", use_llm=False)
        stitcher.stitch()
        mock_tier2.assert_not_called()

    def test_tier2_llm_creates_edge_above_threshold(self) -> None:
        """Mock fenic to return high-confidence match -> SourceDependsOn with source='llm'."""
        storage = self._make_unmatched_storage()
        stitcher = SalesforceStitcher(
            storage=storage, org_key="testorg", use_llm=True, llm_confidence_threshold=0.6
        )

        mock_fenic = MagicMock()
        mock_session = MagicMock()
        mock_df = MagicMock()
        mock_session.create_dataframe.return_value = mock_df
        mock_df.with_column.return_value = mock_df

        mock_result = MagicMock()
        mock_result.dbt_source_name = "custom_obj"
        mock_result.confidence = 0.8
        mock_result.reasoning = "Similar names"
        mock_df.to_pylist.return_value = [
            {"result": mock_result, "sf_obj_id": "sf_object::testorg::UnknownObj", "api_name": "UnknownObj"},
        ]

        unmatched = [{"id": "sf_object::testorg::UnknownObj", "api_name": "UnknownObj"}]
        dbt_sources = {"custom_obj": {"id": "source.pkg.custom_obj", "name": "custom_obj"}}
        counts = {"source_matches": 0, "column_matches": 0, "llm_source_matches": 0, "llm_column_matches": 0}

        stitcher._tier2_llm(unmatched, dbt_sources, counts, fc=mock_fenic, session=mock_session)

        assert counts["llm_source_matches"] == 1
        source_edges = storage.edges_by_type(SourceDependsOn)
        assert len(source_edges) == 1
        _, _, edge = source_edges[0]
        assert edge.source == "llm"
        assert edge.rule_id == "llm_small"

    def test_tier2_llm_skips_below_threshold(self) -> None:
        """LLM returns low confidence -> no edge."""
        storage = self._make_unmatched_storage()
        stitcher = SalesforceStitcher(
            storage=storage, org_key="testorg", use_llm=True, llm_confidence_threshold=0.6
        )

        mock_fenic = MagicMock()
        mock_session = MagicMock()
        mock_df = MagicMock()
        mock_session.create_dataframe.return_value = mock_df
        mock_df.with_column.return_value = mock_df

        mock_result = MagicMock()
        mock_result.dbt_source_name = "custom_obj"
        mock_result.confidence = 0.4  # Below threshold
        mock_df.to_pylist.return_value = [
            {"result": mock_result, "sf_obj_id": "sf_object::testorg::UnknownObj", "api_name": "UnknownObj"},
        ]

        unmatched = [{"id": "sf_object::testorg::UnknownObj", "api_name": "UnknownObj"}]
        dbt_sources = {"custom_obj": {"id": "source.pkg.custom_obj", "name": "custom_obj"}}
        counts = {"source_matches": 0, "column_matches": 0, "llm_source_matches": 0, "llm_column_matches": 0}
        stitcher._tier2_llm(unmatched, dbt_sources, counts, fc=mock_fenic, session=mock_session)

        assert counts["llm_source_matches"] == 0

    def test_tier2_llm_skips_null_name(self) -> None:
        """LLM returns None for dbt_source_name -> no edge."""
        storage = self._make_unmatched_storage()
        stitcher = SalesforceStitcher(
            storage=storage, org_key="testorg", use_llm=True, llm_confidence_threshold=0.6
        )

        mock_fenic = MagicMock()
        mock_session = MagicMock()
        mock_df = MagicMock()
        mock_session.create_dataframe.return_value = mock_df
        mock_df.with_column.return_value = mock_df

        mock_result = MagicMock()
        mock_result.dbt_source_name = None
        mock_result.confidence = 0.9
        mock_df.to_pylist.return_value = [
            {"result": mock_result, "sf_obj_id": "sf_object::testorg::UnknownObj", "api_name": "UnknownObj"},
        ]

        unmatched = [{"id": "sf_object::testorg::UnknownObj", "api_name": "UnknownObj"}]
        dbt_sources = {"custom_obj": {"id": "source.pkg.custom_obj", "name": "custom_obj"}}
        counts = {"source_matches": 0, "column_matches": 0, "llm_source_matches": 0, "llm_column_matches": 0}
        stitcher._tier2_llm(unmatched, dbt_sources, counts, fc=mock_fenic, session=mock_session)

        assert counts["llm_source_matches"] == 0

    def test_tier2_llm_extraction_exception_continues(self) -> None:
        """If DataFrame pipeline raises, processing continues."""
        storage = self._make_unmatched_storage()
        stitcher = SalesforceStitcher(
            storage=storage, org_key="testorg", use_llm=True, llm_confidence_threshold=0.6
        )

        mock_fenic = MagicMock()
        mock_session = MagicMock()
        mock_df = MagicMock()
        mock_session.create_dataframe.return_value = mock_df
        mock_df.with_column.return_value = mock_df
        mock_df.to_pylist.side_effect = RuntimeError("LLM error")

        unmatched = [{"id": "sf_object::testorg::UnknownObj", "api_name": "UnknownObj"}]
        dbt_sources = {"custom_obj": {"id": "source.pkg.custom_obj", "name": "custom_obj"}}
        counts = {"source_matches": 0, "column_matches": 0, "llm_source_matches": 0, "llm_column_matches": 0}
        # Should not raise
        stitcher._tier2_llm(unmatched, dbt_sources, counts, fc=mock_fenic, session=mock_session)

        assert counts["llm_source_matches"] == 0

    def test_tier2_llm_skipped_when_fenic_unavailable(self) -> None:
        """When fenic import fails, stitch() skips LLM entirely."""
        storage = self._make_unmatched_storage()
        stitcher = SalesforceStitcher(
            storage=storage, org_key="testorg", use_llm=True,
            analysis_models=MagicMock(),
        )

        # Make fenic unavailable — stitch() catches ImportError and sets fc=None
        with patch.dict(sys.modules, {"fenic": None}):
            counts = stitcher.stitch()

        assert counts["llm_source_matches"] == 0

    def test_tier2_llm_enforces_one_to_one(self) -> None:
        """Two SfObjects both matching the same DbtSource: only highest-confidence wins."""
        storage = self._make_unmatched_storage()
        # Register a second unmatched SF object
        storage.register_cypher(
            "MATCH (o:SfObject) WHERE",
            [
                {"id": "sf_object::testorg::UnknownObj", "api_name": "UnknownObj"},
                {"id": "sf_object::testorg::AnotherObj", "api_name": "AnotherObj"},
            ],
        )
        stitcher = SalesforceStitcher(
            storage=storage, org_key="testorg", use_llm=True, llm_confidence_threshold=0.6
        )

        mock_fenic = MagicMock()
        mock_session = MagicMock()
        mock_df = MagicMock()
        mock_session.create_dataframe.return_value = mock_df
        mock_df.with_column.return_value = mock_df

        # Both objects claim the same DbtSource — higher confidence should win
        mock_df.to_pylist.return_value = [
            {
                "result": {"dbt_source_name": "custom_obj", "confidence": 0.9, "reasoning": "good"},
                "sf_obj_id": "sf_object::testorg::UnknownObj",
                "api_name": "UnknownObj",
            },
            {
                "result": {"dbt_source_name": "custom_obj", "confidence": 0.7, "reasoning": "ok"},
                "sf_obj_id": "sf_object::testorg::AnotherObj",
                "api_name": "AnotherObj",
            },
        ]

        unmatched = [
            {"id": "sf_object::testorg::UnknownObj", "api_name": "UnknownObj"},
            {"id": "sf_object::testorg::AnotherObj", "api_name": "AnotherObj"},
        ]
        dbt_sources = {"custom_obj": {"id": "source.pkg.custom_obj", "name": "custom_obj"}}
        counts = {"source_matches": 0, "column_matches": 0, "llm_source_matches": 0, "llm_column_matches": 0}

        stitcher._tier2_llm(unmatched, dbt_sources, counts, fc=mock_fenic, session=mock_session)

        # Only one edge created (highest confidence wins)
        assert counts["llm_source_matches"] == 1
        source_edges = storage.edges_by_type(SourceDependsOn)
        assert len(source_edges) == 1
        _, to_node, edge = source_edges[0]
        assert to_node.id == "sf_object::testorg::UnknownObj"
        assert edge.confidence == 0.9

    def test_tier1_claimed_sources_excluded_from_tier2(self) -> None:
        """DbtSource matched in tier 1 is not available for tier 2 LLM matching."""
        storage = MockStorage()
        # One DbtSource "account" will be claimed by tier 1
        storage.register_cypher(
            "MATCH (s:DbtSource) RETURN",
            [{"id": "source.pkg.account", "name": "account"}],
        )
        # Two SF objects: Account (matches tier 1) and UnknownObj (unmatched)
        storage.register_cypher(
            "MATCH (o:SfObject) WHERE",
            [
                {"id": "sf_object::testorg::Account", "api_name": "Account"},
                {"id": "sf_object::testorg::UnknownObj", "api_name": "UnknownObj"},
            ],
        )
        storage.register_cypher("MATERIALIZES", [])
        storage.register_cypher("SF_HAS_FIELD", [])

        stitcher = SalesforceStitcher(
            storage=storage, org_key="testorg", use_llm=True,
            analysis_models=MagicMock(),
        )

        with patch.dict(sys.modules, {"fenic": MagicMock()}), \
             patch(
                 "lineage.ingest.static_loaders.semantic.config.session.create_session",
                 return_value=MagicMock(),
             ), \
             patch.object(stitcher, "_tier2_llm") as mock_tier2:
            stitcher.stitch()

        # Tier 2 should be called with only unclaimed sources (account was claimed)
        if mock_tier2.called:
            _, kwargs = mock_tier2.call_args
            available = kwargs.get("dbt_sources") if "dbt_sources" in kwargs else mock_tier2.call_args[0][1]
            assert "account" not in available


# ---------------------------------------------------------------------------
# Stitcher LLM column matching tests
# ---------------------------------------------------------------------------

class TestStitcherColumnLLM:
    """Tests for _match_columns_llm — LLM-assisted field-to-column matching."""

    def _make_storage_for_column_llm(self) -> MockStorage:
        """Storage with one matched object pair and mixed matched/unmatched fields."""
        storage = MockStorage()

        # DbtSource + SfObject (deterministically matched)
        storage.register_cypher(
            "MATCH (s:DbtSource) RETURN",
            [{"id": "source.pkg.account", "name": "account"}],
        )
        storage.register_cypher(
            "MATCH (o:SfObject) WHERE",
            [{"id": "sf_object::testorg::Account", "api_name": "Account"}],
        )

        # DbtColumns: "name" will match deterministically, "annual_revenue" won't
        storage.register_cypher(
            "MATERIALIZES",
            [
                {"id": "col.account.name", "name": "name"},
                {"id": "col.account.annual_revenue", "name": "annual_revenue"},
            ],
            param_filter={"sid": "source.pkg.account"},
        )

        # SfFields: "Name" matches deterministically, "AnnualRevenue" doesn't
        storage.register_cypher(
            "SF_HAS_FIELD",
            [
                {"id": "sf_field::testorg::Account::Name", "field_api_name": "Name"},
                {"id": "sf_field::testorg::Account::AnnualRevenue", "field_api_name": "AnnualRevenue"},
            ],
            param_filter={"oid": "sf_object::testorg::Account"},
        )

        return storage

    @staticmethod
    def _make_mock_fenic_df(
        column_matches: list[dict] | None = None,
        raise_error: bool = False,
    ) -> tuple[MagicMock, MagicMock]:
        """Build mock fenic module + session using DataFrame API.

        Returns:
            Tuple of (mock_fenic_module, mock_session).
        """
        mock_fenic = MagicMock()

        mock_session = MagicMock()
        mock_df = MagicMock()
        mock_session.create_dataframe.return_value = mock_df
        mock_df.with_column.return_value = mock_df

        if raise_error:
            mock_df.to_pylist.side_effect = RuntimeError("LLM error")
        elif column_matches is not None:
            mock_result = MagicMock()
            match_objects = []
            for m in column_matches:
                pair = MagicMock()
                pair.sf_field_name = m["sf_field_name"]
                pair.dbt_column_name = m["dbt_column_name"]
                pair.confidence = m["confidence"]
                match_objects.append(pair)
            mock_result.matches = match_objects
            mock_df.to_pylist.return_value = [{"result": mock_result}]
        else:
            mock_result = MagicMock()
            mock_result.matches = []
            mock_df.to_pylist.return_value = [{"result": mock_result}]

        return mock_fenic, mock_session

    def test_llm_column_creates_edges(self) -> None:
        """LLM returns high-confidence match -> MapsToColumn edge with source='llm'."""
        storage = self._make_storage_for_column_llm()
        mock_fenic, mock_session = self._make_mock_fenic_df(column_matches=[
            {"sf_field_name": "AnnualRevenue", "dbt_column_name": "annual_revenue", "confidence": 0.85},
        ])

        stitcher = SalesforceStitcher(
            storage=storage, org_key="testorg", use_llm=False,
            llm_confidence_threshold=0.6,
        )

        # Run deterministic column matching first
        matched_sf, matched_dbt = stitcher._match_columns_deterministic(
            sf_obj_id="sf_object::testorg::Account",
            dbt_source_id="source.pkg.account",
            counts={"column_matches": 0, "llm_column_matches": 0},
        )

        counts: dict[str, int] = {"column_matches": 0, "llm_column_matches": 0}
        stitcher._match_columns_llm(
            sf_obj_id="sf_object::testorg::Account",
            dbt_source_id="source.pkg.account",
            matched_sf_field_ids=matched_sf,
            matched_dbt_col_ids=matched_dbt,
            counts=counts,
            fc=mock_fenic,
            session=mock_session,
        )

        assert counts["llm_column_matches"] == 1
        llm_edges = [
            (f, t, e)
            for f, t, e in storage.edges_by_type(MapsToColumn)
            if e.source == "llm"
        ]
        assert len(llm_edges) == 1
        _, _, edge = llm_edges[0]
        assert edge.rule_id == "llm_small"
        assert edge.confidence == 0.85

    def test_llm_column_respects_threshold(self) -> None:
        """LLM returns low confidence -> no edge created."""
        storage = self._make_storage_for_column_llm()
        mock_fenic, mock_session = self._make_mock_fenic_df(column_matches=[
            {"sf_field_name": "AnnualRevenue", "dbt_column_name": "annual_revenue", "confidence": 0.3},
        ])

        stitcher = SalesforceStitcher(
            storage=storage, org_key="testorg", use_llm=False,
            llm_confidence_threshold=0.6,
        )

        counts: dict[str, int] = {"column_matches": 0, "llm_column_matches": 0}
        stitcher._match_columns_llm(
            sf_obj_id="sf_object::testorg::Account",
            dbt_source_id="source.pkg.account",
            matched_sf_field_ids=set(),
            matched_dbt_col_ids=set(),
            counts=counts,
            fc=mock_fenic,
            session=mock_session,
        )

        assert counts["llm_column_matches"] == 0

    def test_llm_column_skips_already_matched(self) -> None:
        """Deterministically matched fields are not sent to LLM."""
        storage = self._make_storage_for_column_llm()
        mock_fenic, mock_session = self._make_mock_fenic_df()  # empty matches

        stitcher = SalesforceStitcher(
            storage=storage, org_key="testorg", use_llm=False,
            llm_confidence_threshold=0.6,
        )

        # Pretend all fields are already matched
        all_sf = {"sf_field::testorg::Account::Name", "sf_field::testorg::Account::AnnualRevenue"}
        all_dbt = {"col.account.name", "col.account.annual_revenue"}

        counts: dict[str, int] = {"column_matches": 0, "llm_column_matches": 0}
        stitcher._match_columns_llm(
            sf_obj_id="sf_object::testorg::Account",
            dbt_source_id="source.pkg.account",
            matched_sf_field_ids=all_sf,
            matched_dbt_col_ids=all_dbt,
            counts=counts,
            fc=mock_fenic,
            session=mock_session,
        )

        # No DataFrame creation should have been made (early return)
        mock_session.create_dataframe.assert_not_called()
        assert counts["llm_column_matches"] == 0

    def test_llm_column_empty_unmatched_skips(self) -> None:
        """When no unmatched fields remain on either side, no LLM call."""
        storage = MockStorage()
        # No SF fields for this object
        storage.register_cypher("SF_HAS_FIELD", [], param_filter={"oid": "sf_object::testorg::Empty"})
        storage.register_cypher(
            "MATERIALIZES",
            [{"id": "col.x.y", "name": "y"}],
            param_filter={"sid": "source.pkg.x"},
        )

        mock_fenic, mock_session = self._make_mock_fenic_df()
        stitcher = SalesforceStitcher(
            storage=storage, org_key="testorg", use_llm=False,
        )

        counts: dict[str, int] = {"column_matches": 0, "llm_column_matches": 0}
        stitcher._match_columns_llm(
            sf_obj_id="sf_object::testorg::Empty",
            dbt_source_id="source.pkg.x",
            matched_sf_field_ids=set(),
            matched_dbt_col_ids=set(),
            counts=counts,
            fc=mock_fenic,
            session=mock_session,
        )

        mock_session.create_dataframe.assert_not_called()

    def test_llm_column_exception_continues(self) -> None:
        """LLM extraction error doesn't crash — method returns gracefully."""
        storage = self._make_storage_for_column_llm()
        mock_fenic, mock_session = self._make_mock_fenic_df(raise_error=True)

        stitcher = SalesforceStitcher(
            storage=storage, org_key="testorg", use_llm=False,
            llm_confidence_threshold=0.6,
        )

        counts: dict[str, int] = {"column_matches": 0, "llm_column_matches": 0}
        # Should not raise
        stitcher._match_columns_llm(
            sf_obj_id="sf_object::testorg::Account",
            dbt_source_id="source.pkg.account",
            matched_sf_field_ids=set(),
            matched_dbt_col_ids=set(),
            counts=counts,
            fc=mock_fenic,
            session=mock_session,
        )

        assert counts["llm_column_matches"] == 0

    def test_llm_column_matches_counter(self) -> None:
        """Counter incremented correctly for multiple matches."""
        storage = MockStorage()

        # DbtSource + SfObject
        storage.register_cypher(
            "MATCH (s:DbtSource) RETURN",
            [{"id": "source.pkg.account", "name": "account"}],
        )
        storage.register_cypher(
            "MATCH (o:SfObject) WHERE",
            [{"id": "sf_object::testorg::Account", "api_name": "Account"}],
        )

        # 3 dbt columns: name (deterministic), annual_revenue + employee_count (LLM)
        storage.register_cypher(
            "MATERIALIZES",
            [
                {"id": "col.account.name", "name": "name"},
                {"id": "col.account.annual_revenue", "name": "annual_revenue"},
                {"id": "col.account.employee_count", "name": "employee_count"},
            ],
            param_filter={"sid": "source.pkg.account"},
        )

        # 3 SF fields: Name (deterministic), AnnualRevenue + NumberOfEmployees (LLM)
        storage.register_cypher(
            "SF_HAS_FIELD",
            [
                {"id": "sf_field::testorg::Account::Name", "field_api_name": "Name"},
                {"id": "sf_field::testorg::Account::AnnualRevenue", "field_api_name": "AnnualRevenue"},
                {"id": "sf_field::testorg::Account::NumberOfEmployees", "field_api_name": "NumberOfEmployees"},
            ],
            param_filter={"oid": "sf_object::testorg::Account"},
        )

        mock_fenic, mock_session = self._make_mock_fenic_df(column_matches=[
            {"sf_field_name": "AnnualRevenue", "dbt_column_name": "annual_revenue", "confidence": 0.9},
            {"sf_field_name": "NumberOfEmployees", "dbt_column_name": "employee_count", "confidence": 0.85},
        ])

        stitcher = SalesforceStitcher(
            storage=storage, org_key="testorg", use_llm=False,
            llm_confidence_threshold=0.6,
        )

        # Name is deterministically matched
        matched_sf = {"sf_field::testorg::Account::Name"}
        matched_dbt = {"col.account.name"}

        counts: dict[str, int] = {"column_matches": 0, "llm_column_matches": 0}
        stitcher._match_columns_llm(
            sf_obj_id="sf_object::testorg::Account",
            dbt_source_id="source.pkg.account",
            matched_sf_field_ids=matched_sf,
            matched_dbt_col_ids=matched_dbt,
            counts=counts,
            fc=mock_fenic,
            session=mock_session,
        )

        assert counts["llm_column_matches"] == 2


# ---------------------------------------------------------------------------
# Progress callback tests
# ---------------------------------------------------------------------------

class TestSalesforceLoaderProgress:
    """Test that on_progress callback is invoked during load()."""

    def test_progress_callbacks_emitted(self) -> None:
        """Loader emits progress callbacks for phases 2, 3, and 4."""
        client = _make_mock_client()
        storage = MockStorage()
        progress_calls: list[tuple[int, int, str]] = []

        def on_progress(current: int, total: int, details: str) -> None:
            progress_calls.append((current, total, details))

        loader = SalesforceLoader(
            client=client,
            storage=storage,
            org_key="testorg",
            on_progress=on_progress,
        )
        asyncio.run(loader.load())

        # Should have received callbacks for:
        # Phase 2: 3 SObjects (Account, Opportunity, Custom_Obj__c)
        # Phase 3: 1 Report
        # Phase 4: 1 Dashboard
        assert len(progress_calls) == 5

        # Verify phase 2 callbacks (SObjects)
        sobject_calls = [c for c in progress_calls if "SObjects" in c[2]]
        assert len(sobject_calls) == 3
        # Final SObject callback should have current == total
        finals = [c for c in sobject_calls if c[0] == c[1]]
        assert len(finals) == 1
        assert finals[0][1] == 3

        # Verify phase 3 callbacks (Reports)
        report_calls = [c for c in progress_calls if "Reports" in c[2]]
        assert len(report_calls) == 1
        assert report_calls[0] == (1, 1, "Reports [1/1] Pipeline Report")

        # Verify phase 4 callbacks (Dashboards)
        dash_calls = [c for c in progress_calls if "Dashboards" in c[2]]
        assert len(dash_calls) == 1
        assert dash_calls[0] == (1, 1, "Dashboards [1/1] Sales Dashboard")

    def test_no_progress_callback_is_noop(self) -> None:
        """Loader works fine with on_progress=None (default)."""
        client = _make_mock_client()
        storage = MockStorage()
        loader = SalesforceLoader(
            client=client,
            storage=storage,
            org_key="testorg",
            on_progress=None,
        )
        # Should not raise
        asyncio.run(loader.load())
        assert len(storage.node_by_type(SfObject)) == 3


# ---------------------------------------------------------------------------
# _build_mdapi_col_to_obj unit tests
# ---------------------------------------------------------------------------

class TestReportTypeToObject:
    """Unit tests for _report_type_to_object static method."""

    def test_exact_sobject(self) -> None:
        assert SalesforceLoader._report_type_to_object("Opportunity") == "Opportunity"

    def test_strip_list_suffix(self) -> None:
        assert SalesforceLoader._report_type_to_object("AccountList") == "Account"
        assert SalesforceLoader._report_type_to_object("LeadList") == "Lead"

    def test_special_case(self) -> None:
        assert SalesforceLoader._report_type_to_object("OpportunityProduct") == "OpportunityLineItem"


class TestBuildMdapiColToObj:
    """Unit tests for _build_mdapi_col_to_obj helper."""

    def _make_loader(self) -> SalesforceLoader:
        """Build loader with field nodes populated (needed for primary_obj validation)."""
        client = _make_mock_client()
        storage = MockStorage()
        loader = SalesforceLoader(client=client, storage=storage, org_key="testorg")
        # Populate _field_nodes so primary_obj validation passes
        loader._field_nodes = {
            ("Opportunity", "Amount"): SfField(name="Amount", field_api_name="Amount", object_api_name="Opportunity", org_key="testorg"),
            ("Opportunity", "Id"): SfField(name="Id", field_api_name="Id", object_api_name="Opportunity", org_key="testorg"),
            ("Account", "Name"): SfField(name="Name", field_api_name="Name", object_api_name="Account", org_key="testorg"),
            ("Account", "Id"): SfField(name="Id", field_api_name="Id", object_api_name="Account", org_key="testorg"),
        }
        return loader

    def test_basic(self) -> None:
        """Standard Object$FieldName refs produce correct mapping."""
        loader = self._make_loader()
        result = loader._build_mdapi_col_to_obj({
            "columns": [
                {"field": "Opportunity$Amount"},
                {"field": "Account$Name"},
            ]
        })
        assert result == {"amount": "Opportunity", "name": "Account"}

    def test_collision_excluded(self) -> None:
        """Same normalized field on multiple objects is excluded."""
        loader = self._make_loader()
        result = loader._build_mdapi_col_to_obj({
            "columns": [
                {"field": "Opportunity$Id"},
                {"field": "Account$Id"},
                {"field": "Opportunity$Amount"},
            ]
        })
        # id collides, amount does not
        assert result == {"amount": "Opportunity"}
        assert "id" not in result

    def test_empty_inputs(self) -> None:
        """None, empty list, empty dict all return empty mapping."""
        loader = self._make_loader()
        assert loader._build_mdapi_col_to_obj({}) == {}
        assert loader._build_mdapi_col_to_obj({"columns": None}) == {}
        assert loader._build_mdapi_col_to_obj({"columns": []}) == {}

    def test_single_dict(self) -> None:
        """Metadata API sometimes returns a single dict instead of a list."""
        loader = self._make_loader()
        result = loader._build_mdapi_col_to_obj({
            "columns": {"field": "Opportunity$Amount"}
        })
        assert result == {"amount": "Opportunity"}

    def test_bare_names_with_report_type(self) -> None:
        """Bare field refs use reportType as primary object."""
        loader = self._make_loader()
        result = loader._build_mdapi_col_to_obj({
            "reportType": "Opportunity",
            "columns": [
                {"field": "AMOUNT"},
                {"field": "CLOSE_DATE"},
            ],
        })
        assert result == {"amount": "Opportunity", "closedate": "Opportunity"}

    def test_bare_names_without_report_type_skipped(self) -> None:
        """Bare field refs without reportType are skipped."""
        loader = self._make_loader()
        result = loader._build_mdapi_col_to_obj({
            "columns": [
                {"field": "AMOUNT"},
                {"field": "STAGE_NAME"},
            ]
        })
        assert result == {}

    def test_bare_names_invalid_report_type_skipped(self) -> None:
        """Bare field refs with unknown reportType (not in field index) are skipped."""
        loader = self._make_loader()
        result = loader._build_mdapi_col_to_obj({
            "reportType": "NonExistentObject",
            "columns": [
                {"field": "AMOUNT"},
            ],
        })
        assert result == {}

    def test_mixed_bare_and_dotted(self) -> None:
        """Bare columns use reportType, dotted columns use their own object prefix."""
        loader = self._make_loader()
        result = loader._build_mdapi_col_to_obj({
            "reportType": "Opportunity",
            "columns": [
                {"field": "AMOUNT"},
                {"field": "ACCOUNT.NAME"},
            ],
        })
        # AMOUNT -> Opportunity (from reportType), NAME -> ACCOUNT (from dotted prefix)
        assert result["amount"] == "Opportunity"
        assert result["name"] == "ACCOUNT"

    def test_dot_format(self) -> None:
        """Dot-separated refs (e.g. Lead.CurrentGenerators__c) are handled."""
        loader = self._make_loader()
        result = loader._build_mdapi_col_to_obj({
            "columns": [
                {"field": "Lead.CurrentGenerators__c"},
            ]
        })
        assert result == {"currentgeneratorsc": "Lead"}


# ---------------------------------------------------------------------------
# mdapi_mapped resolution tier tests
# ---------------------------------------------------------------------------

class TestMdapiMappedResolution:
    """Integration tests for the mdapi_mapped resolution tier."""

    def test_mdapi_mapped_resolution(self) -> None:
        """MDAPI reportType resolves bare column key at confidence 0.95."""
        client = _make_mock_client()
        # REST returns bare column keys (no dots)
        client.describe_report.return_value = {
            "reportMetadata": {
                "reportType": {"type": "OpportunityReport"},
                "detailColumns": ["AMOUNT"],
            },
        }
        # No categories -> no category mapping
        client.describe_report_type.return_value = {
            "reportTypeMetadata": {
                "objects": [{"apiName": "Opportunity"}],
            },
        }
        # MDAPI provides reportType + bare columns
        client.get_report_developer_names.return_value = {
            "00O000000000001AAA": "PublicReports/Pipeline"
        }
        client.read_report_metadata_full.return_value = {
            "reportType": "Opportunity",
            "columns": [{"field": "AMOUNT"}],
        }
        storage = MockStorage()
        loader = SalesforceLoader(client=client, storage=storage, org_key="testorg")
        asyncio.run(loader.load())

        uses = storage.edges_by_type(SfReportColumnUsesField)
        assert len(uses) == 1
        _, to_node, edge = uses[0]
        assert edge.resolution == "mdapi_mapped"
        assert edge.confidence == 0.95
        assert to_node.field_api_name == "Amount"
        assert to_node.object_api_name == "Opportunity"

    def test_mdapi_collision_falls_through(self) -> None:
        """When bare column resolves to field on multiple objects, falls through to heuristic."""
        client = _make_mock_client()
        client.describe_report.return_value = {
            "reportMetadata": {
                "reportType": {"type": "OpportunityReport"},
                "detailColumns": ["Id"],
            },
        }
        client.describe_report_type.return_value = {
            "reportTypeMetadata": {
                "objects": [{"apiName": "Opportunity"}, {"apiName": "Account"}],
            },
        }
        client.get_report_developer_names.return_value = {
            "00O000000000001AAA": "PublicReports/Pipeline"
        }
        # reportType=Opportunity, but Id only appears once as bare column
        # -> maps to Opportunity. However Id exists on 3 objects in the field
        # index, so the mdapi_mapped tier WILL resolve it to Opportunity.Id.
        # This is actually correct behavior since we know the primary object!
        client.read_report_metadata_full.return_value = {
            "reportType": "Opportunity",
            "columns": [{"field": "Id"}],
        }
        storage = MockStorage()
        loader = SalesforceLoader(client=client, storage=storage, org_key="testorg")
        asyncio.run(loader.load())

        uses = storage.edges_by_type(SfReportColumnUsesField)
        assert len(uses) == 1
        _, to_node, edge = uses[0]
        # Now resolves via mdapi_mapped (reportType tells us primary object)
        assert edge.resolution == "mdapi_mapped"
        assert edge.confidence == 0.95
        assert to_node.object_api_name == "Opportunity"

    def test_no_mdapi_unchanged(self) -> None:
        """Without developer name, no MDAPI fetch -> behavior unchanged."""
        client = _make_mock_client()
        client.describe_report.return_value = {
            "reportMetadata": {
                "reportType": {"type": "OpportunityReport"},
                "detailColumns": ["Amount"],
            },
        }
        client.describe_report_type.return_value = {
            "reportTypeMetadata": {
                "objects": [{"apiName": "Opportunity"}],
            },
        }
        # No developer name -> no MDAPI fetch
        client.get_report_developer_names.return_value = {}
        storage = MockStorage()
        loader = SalesforceLoader(client=client, storage=storage, org_key="testorg")
        asyncio.run(loader.load())

        uses = storage.edges_by_type(SfReportColumnUsesField)
        assert len(uses) == 1
        _, to_node, edge = uses[0]
        # Unique field -> heuristic 0.8
        assert edge.resolution == "heuristic"
        assert edge.confidence == 0.8
        assert to_node.field_api_name == "Amount"

    def test_dotted_key_exact_wins_over_mdapi(self) -> None:
        """Dotted REST key resolves at exact tier before mdapi_mapped."""
        client = _make_mock_client()
        client.describe_report.return_value = {
            "reportMetadata": {
                "reportType": {"type": "OpportunityReport"},
                "detailColumns": ["Opportunity.Amount"],
            },
        }
        client.describe_report_type.return_value = {
            "reportTypeMetadata": {
                "objects": [{"apiName": "Opportunity"}],
            },
        }
        client.get_report_developer_names.return_value = {
            "00O000000000001AAA": "PublicReports/Pipeline"
        }
        client.read_report_metadata_full.return_value = {
            "columns": [{"field": "Opportunity$Amount"}]
        }
        storage = MockStorage()
        loader = SalesforceLoader(client=client, storage=storage, org_key="testorg")
        asyncio.run(loader.load())

        uses = storage.edges_by_type(SfReportColumnUsesField)
        assert len(uses) == 1
        _, _, edge = uses[0]
        # Exact match wins (tier 1)
        assert edge.resolution == "exact"
        assert edge.confidence == 1.0


# ---------------------------------------------------------------------------
# FK column resolution fix tests
# ---------------------------------------------------------------------------

class TestFKColumnResolution:
    """Tests for the FK column object_api_name fallback in heuristic tier."""

    def test_fk_col_uses_object_api_name(self) -> None:
        """FK column with object_api_name set resolves to heuristic_mapped 0.75."""
        client = _make_mock_client()
        # Add a second object with AccountId so the field is ambiguous
        orig_describe = client.describe_sobject.side_effect

        def _describe(api_name: str) -> dict:
            result = orig_describe(api_name)
            if api_name == "Custom_Obj__c":
                result["fields"].append({
                    "name": "AccountId", "type": "reference", "custom": False,
                    "nillable": True, "length": 18, "referenceTo": ["Account"],
                    "calculatedFormula": None, "label": "Account ID",
                })
            return result

        client.describe_sobject.side_effect = _describe
        storage = MockStorage()
        loader = SalesforceLoader(client=client, storage=storage, org_key="testorg")
        asyncio.run(loader.load())

        # Now test _resolve_column_to_field directly with a FK column node
        fk_col = SfReportColumn(
            name="AccountId",
            column_key="AccountId",
            report_id="test",
            org_key="testorg",
            data_type=None,
            object_api_name="Opportunity",  # Set from FK graph query
        )
        result = loader._resolve_column_to_field(fk_col, "AccountId", {}, {})
        assert result is not None
        field_node, edge = result
        assert edge.resolution == "heuristic_mapped"
        assert edge.confidence == 0.75
        assert field_node.object_api_name == "Opportunity"

    def test_fk_col_no_object_falls_to_ambiguous(self) -> None:
        """FK column without object_api_name falls to heuristic 0.5."""
        client = _make_mock_client()
        orig_describe = client.describe_sobject.side_effect

        def _describe(api_name: str) -> dict:
            result = orig_describe(api_name)
            if api_name == "Custom_Obj__c":
                result["fields"].append({
                    "name": "AccountId", "type": "reference", "custom": False,
                    "nillable": True, "length": 18, "referenceTo": ["Account"],
                    "calculatedFormula": None, "label": "Account ID",
                })
            return result

        client.describe_sobject.side_effect = _describe
        storage = MockStorage()
        loader = SalesforceLoader(client=client, storage=storage, org_key="testorg")
        asyncio.run(loader.load())

        fk_col = SfReportColumn(
            name="AccountId",
            column_key="AccountId",
            report_id="test",
            org_key="testorg",
            data_type=None,
            object_api_name=None,  # No object hint
        )
        result = loader._resolve_column_to_field(fk_col, "AccountId", {}, {})
        assert result is not None
        _, edge = result
        assert edge.resolution == "heuristic"
        assert edge.confidence == 0.5

    def test_mapped_obj_takes_precedence_over_object_api_name(self) -> None:
        """mapped_obj from col_to_obj takes precedence over col_node.object_api_name."""
        client = _make_mock_client()
        orig_describe = client.describe_sobject.side_effect

        def _describe(api_name: str) -> dict:
            result = orig_describe(api_name)
            if api_name == "Custom_Obj__c":
                result["fields"].append({
                    "name": "AccountId", "type": "reference", "custom": False,
                    "nillable": True, "length": 18, "referenceTo": ["Account"],
                    "calculatedFormula": None, "label": "Account ID",
                })
            return result

        client.describe_sobject.side_effect = _describe
        storage = MockStorage()
        loader = SalesforceLoader(client=client, storage=storage, org_key="testorg")
        asyncio.run(loader.load())

        fk_col = SfReportColumn(
            name="AccountId",
            column_key="AccountId",
            report_id="test",
            org_key="testorg",
            data_type=None,
            object_api_name="Custom_Obj__c",  # Wrong hint on the node
        )
        # col_to_obj says Opportunity — should take precedence
        col_to_obj = {"AccountId": "Opportunity"}
        result = loader._resolve_column_to_field(fk_col, "AccountId", col_to_obj, {})
        assert result is not None
        field_node, edge = result
        # category_mapped tier fires first (higher tier than heuristic)
        assert edge.resolution == "category_mapped"
        assert field_node.object_api_name == "Opportunity"


# ---------------------------------------------------------------------------
# Custom report type / _resolve_primary_object tests
# ---------------------------------------------------------------------------

class TestResolvePrimaryObject:
    """Tests for _resolve_primary_object three-tier fallback."""

    def _make_loader_with_fields(self) -> SalesforceLoader:
        """Build loader with pre-populated _field_nodes."""
        client = _make_mock_client()
        storage = MockStorage()
        loader = SalesforceLoader(client=client, storage=storage, org_key="testorg")
        loader._field_nodes = {
            ("Opportunity", "Amount"): SfField(
                name="Amount", field_api_name="Amount",
                object_api_name="Opportunity", org_key="testorg",
            ),
            ("Account", "Name"): SfField(
                name="Name", field_api_name="Name",
                object_api_name="Account", org_key="testorg",
            ),
        }
        return loader

    def test_tier1_static_standard(self) -> None:
        """Standard type 'Opportunity' resolves via static heuristic."""
        loader = self._make_loader_with_fields()
        result = loader._resolve_primary_object("Opportunity", None)
        assert result == "Opportunity"

    def test_tier1_static_list_suffix(self) -> None:
        """'AccountList' strips to 'Account' via static heuristic."""
        loader = self._make_loader_with_fields()
        result = loader._resolve_primary_object("AccountList", None)
        assert result == "Account"

    def test_tier2_rest_objects(self) -> None:
        """Custom type falls through tier 1, resolves via REST objects[0]."""
        loader = self._make_loader_with_fields()
        rt_desc = {
            "reportTypeMetadata": {
                "objects": [{"apiName": "Opportunity"}, {"apiName": "Account"}],
            },
        }
        result = loader._resolve_primary_object("My_Custom__c", rt_desc)
        assert result == "Opportunity"

    def test_tier3_mdapi_base_object(self) -> None:
        """Custom type, REST empty, MDAPI has baseObject."""
        loader = self._make_loader_with_fields()
        loader.client.read_reporttype_metadata.return_value = {
            "baseObject": "Account",
        }
        result = loader._resolve_primary_object("My_Custom__c", None)
        assert result == "Account"

    def test_all_tiers_fail(self) -> None:
        """Unknown type, no REST objects, no MDAPI -> None."""
        loader = self._make_loader_with_fields()
        loader.client.read_reporttype_metadata.return_value = None
        result = loader._resolve_primary_object("CompletelyUnknown", None)
        assert result is None

    def test_tier3_mdapi_exception_returns_none(self) -> None:
        """MDAPI call raises -> gracefully returns None."""
        loader = self._make_loader_with_fields()
        loader.client.read_reporttype_metadata.side_effect = RuntimeError("API error")
        result = loader._resolve_primary_object("My_Custom__c", None)
        assert result is None


class TestBuildMdapiWithPrimaryObj:
    """Tests for _build_mdapi_col_to_obj with explicit primary_obj parameter."""

    def _make_loader(self) -> SalesforceLoader:
        client = _make_mock_client()
        storage = MockStorage()
        loader = SalesforceLoader(client=client, storage=storage, org_key="testorg")
        loader._field_nodes = {
            ("Opportunity", "Amount"): SfField(
                name="Amount", field_api_name="Amount",
                object_api_name="Opportunity", org_key="testorg",
            ),
            ("Account", "Name"): SfField(
                name="Name", field_api_name="Name",
                object_api_name="Account", org_key="testorg",
            ),
        }
        return loader

    def test_primary_obj_param_skips_internal_derivation(self) -> None:
        """When primary_obj is passed, bare columns use it (not reportType)."""
        loader = self._make_loader()
        result = loader._build_mdapi_col_to_obj(
            {"columns": [{"field": "AMOUNT"}]},
            primary_obj="Opportunity",
        )
        assert result == {"amount": "Opportunity"}

    def test_primary_obj_none_falls_to_internal(self) -> None:
        """When primary_obj=None, internal reportType derivation is used."""
        loader = self._make_loader()
        result = loader._build_mdapi_col_to_obj(
            {"reportType": "Opportunity", "columns": [{"field": "AMOUNT"}]},
            primary_obj=None,
        )
        assert result == {"amount": "Opportunity"}

    def test_primary_obj_overrides_report_type(self) -> None:
        """Explicit primary_obj overrides reportType in metadata."""
        loader = self._make_loader()
        result = loader._build_mdapi_col_to_obj(
            {"reportType": "Account", "columns": [{"field": "AMOUNT"}]},
            primary_obj="Opportunity",
        )
        # primary_obj=Opportunity should be used, not Account from reportType
        assert result == {"amount": "Opportunity"}


class TestCustomReportTypeIntegration:
    """Integration test: custom report type end-to-end."""

    def test_custom_type_resolves_via_rest_objects(self) -> None:
        """Custom report type resolves primary object via REST objects[0]."""
        client = _make_mock_client()
        # Report uses a custom report type
        client.describe_report.return_value = {
            "reportMetadata": {
                "reportType": {"type": "My_Custom_Report__c"},
                "detailColumns": ["AMOUNT"],
            },
        }
        # REST describe_report_type returns Opportunity as first object
        client.describe_report_type.return_value = {
            "reportTypeMetadata": {
                "objects": [{"apiName": "Opportunity"}],
            },
        }
        # MDAPI provides bare columns (no Object$ prefix)
        client.get_report_developer_names.return_value = {
            "00O000000000001AAA": "PublicReports/Pipeline"
        }
        client.read_report_metadata_full.return_value = {
            "reportType": "My_Custom_Report__c",
            "columns": [{"field": "AMOUNT"}],
        }
        storage = MockStorage()
        loader = SalesforceLoader(client=client, storage=storage, org_key="testorg")
        asyncio.run(loader.load())

        uses = storage.edges_by_type(SfReportColumnUsesField)
        assert len(uses) == 1
        _, to_node, edge = uses[0]
        assert edge.resolution == "mdapi_mapped"
        assert edge.confidence == 0.95
        assert to_node.field_api_name == "Amount"
        assert to_node.object_api_name == "Opportunity"
