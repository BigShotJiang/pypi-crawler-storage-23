"""Tests for subject area storage methods used by agent tools.

Tests the storage-layer methods that underpin the subject area agent tools:
- list_subject_areas
- get_subject_area_by_name
- find_related_subject_areas
- search_models_by_domain

Uses a mock storage pattern that returns raw query results, testing
the parsing/normalization logic in BaseLineageStorage.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from lineage.backends.lineage.base import BaseLineageStorage
from lineage.backends.lineage.protocol import RawLineageQueryResult


class FakeStorage(BaseLineageStorage):
    """Minimal concrete implementation for testing base class methods.

    Overrides only the abstract methods that BaseLineageStorage requires,
    letting us test the subject area query methods that are implemented
    in the base class using execute_raw_query.
    """

    def __init__(self, query_results: dict[str, RawLineageQueryResult] | None = None):
        self._query_results = query_results or {}
        self._call_log: list[str] = []

    # Abstract method stubs
    def recreate_schema(self) -> None: ...
    def close(self) -> None: ...
    def upsert_node(self, *args, **kwargs): ...
    def create_edge(self, *args, **kwargs): ...
    def delete_node(self, *args, **kwargs): ...

    def execute_raw_query(self, query: str, params: dict | None = None) -> RawLineageQueryResult:
        self._call_log.append(query.strip()[:80])
        # Return pre-configured results or empty
        for key, result in self._query_results.items():
            if key in query:
                return result
        return RawLineageQueryResult(rows=[], count=0, query=query)


class TestListSubjectAreas:

    def test_returns_empty_when_no_areas(self) -> None:
        storage = FakeStorage()
        result = storage.list_subject_areas()
        assert result == []

    def test_parses_subject_area_rows(self) -> None:
        storage = FakeStorage({
            "MATCH (sa:InferredSubjectArea)": RawLineageQueryResult(
                rows=[
                    {
                        "name": "Billing",
                        "description": "Billing domain",
                        "domains": ["finance", "billing"],
                        "keywords": ["invoice", "payment"],
                        "model_count": 5,
                        "fact_count": 2,
                        "dimension_count": 3,
                        "mixed_count": 0,
                        "contains_pii": True,
                        "total_edge_weight": 15.0,
                    }
                ],
                count=1,
                query="",
            )
        })

        result = storage.list_subject_areas()

        assert len(result) == 1
        area = result[0]
        assert area["name"] == "Billing"
        assert area["description"] == "Billing domain"
        assert area["domains"] == ["finance", "billing"]
        assert area["keywords"] == ["invoice", "payment"]
        assert area["model_count"] == 5
        assert area["fact_count"] == 2
        assert area["contains_pii"] is True

    def test_handles_string_domains(self) -> None:
        """Test that comma-separated string domains are parsed correctly."""
        storage = FakeStorage({
            "MATCH (sa:InferredSubjectArea)": RawLineageQueryResult(
                rows=[{
                    "name": "Test",
                    "domains": "finance, billing, sales",
                    "keywords": "invoice,payment",
                    "model_count": 1,
                }],
                count=1,
                query="",
            )
        })

        result = storage.list_subject_areas()

        assert result[0]["domains"] == ["finance", "billing", "sales"]
        assert result[0]["keywords"] == ["invoice", "payment"]

    def test_handles_none_domains(self) -> None:
        storage = FakeStorage({
            "MATCH (sa:InferredSubjectArea)": RawLineageQueryResult(
                rows=[{
                    "name": "Test",
                    "domains": None,
                    "keywords": None,
                    "model_count": 0,
                }],
                count=1,
                query="",
            )
        })

        result = storage.list_subject_areas()

        assert result[0]["domains"] == []
        assert result[0]["keywords"] == []
        assert result[0]["model_count"] == 0
        assert result[0]["contains_pii"] is False


class TestGetSubjectAreaByName:

    def test_returns_none_when_not_found(self) -> None:
        storage = FakeStorage()
        result = storage.get_subject_area_by_name("NonExistent")
        assert result is None

    def test_returns_area_with_members(self) -> None:
        storage = FakeStorage({
            "toLower(sa.name) = toLower($name)": RawLineageQueryResult(
                rows=[{
                    "name": "Billing",
                    "cluster_id": 0,
                    "description": "Billing domain",
                    "domains": ["finance"],
                    "keywords": ["billing"],
                    "notes": [],
                    "model_count": 2,
                    "fact_count": 1,
                    "dimension_count": 1,
                    "mixed_count": 0,
                    "contains_pii": False,
                    "total_edge_weight": 5.0,
                    "recommended_fact_model": "model.p.fct_billing",
                    "top_dimension_model_ids": ["model.p.dim_customers"],
                }],
                count=1,
                query="",
            ),
            "BELONGS_TO_SUBJECT_AREA": RawLineageQueryResult(
                rows=[
                    {
                        "id": "model.p.fct_billing",
                        "name": "fct_billing",
                        "grain": "per invoice",
                        "intent": "Invoice facts",
                    },
                    {
                        "id": "model.p.dim_customers",
                        "name": "dim_customers",
                        "grain": "per customer",
                        "intent": "Customer dimension",
                    },
                ],
                count=2,
                query="",
            ),
        })

        result = storage.get_subject_area_by_name("Billing")

        assert result is not None
        assert result["name"] == "Billing"
        assert result["recommended_fact_model"] == "model.p.fct_billing"


class TestSearchModelsByDomain:

    def test_returns_empty_when_no_matches(self) -> None:
        storage = FakeStorage()
        result = storage.search_models_by_domain("nonexistent")
        assert result == []

    def test_returns_matching_models(self) -> None:
        """search_models_by_domain fetches all models and filters client-side."""
        storage = FakeStorage({
            "HAS_INFERRED_SEMANTICS": RawLineageQueryResult(
                rows=[
                    {
                        "model_id": "model.p.fct_orders",
                        "model_name": "fct_orders",
                        "domains": ["orders", "sales"],
                        "has_aggregations": True,
                        "subject_area": "Order Management",
                    },
                    {
                        "model_id": "model.p.dim_customers",
                        "model_name": "dim_customers",
                        "domains": ["customers"],
                        "has_aggregations": False,
                        "subject_area": "Customer Management",
                    },
                ],
                count=2,
                query="",
            )
        })

        result = storage.search_models_by_domain("order")

        assert len(result) == 1
        assert result[0]["name"] == "fct_orders"
        assert result[0]["role"] == "fact"

    def test_domain_matching_is_case_insensitive(self) -> None:
        storage = FakeStorage({
            "HAS_INFERRED_SEMANTICS": RawLineageQueryResult(
                rows=[{
                    "model_id": "model.p.fct_billing",
                    "model_name": "fct_billing",
                    "domains": ["Finance", "Billing"],
                    "has_aggregations": True,
                    "subject_area": "Billing",
                }],
                count=1,
                query="",
            )
        })

        result = storage.search_models_by_domain("FINANCE")
        assert len(result) == 1
