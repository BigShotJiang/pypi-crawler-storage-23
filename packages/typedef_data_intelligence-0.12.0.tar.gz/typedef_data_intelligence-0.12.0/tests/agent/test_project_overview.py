"""Tests for project overview computation."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest
from lineage.agent.overview import (
    ProjectOverviewData,
    _extract_project_name,
    _render_column_lineage_depth,
    _render_coverage,
    _render_data_flow,
    _render_directory_org_fallback,
    _render_exploration_hints_fallback,
    _render_key_lineage,
    _render_model_census,
    _render_model_index,
    _render_naming_conventions_fallback,
    _render_project_summary_fallback,
    _render_semantic_richness,
    _render_subject_areas,
    compute_project_overview,
)
from lineage.backends.lineage.protocol import RawLineageQueryResult

# ── Helpers ──


def make_raw_result(rows: list[dict], query: str = "test") -> RawLineageQueryResult:
    """Create a RawLineageQueryResult for testing."""
    return RawLineageQueryResult(rows=rows, count=len(rows), query=query)


def make_mock_storage(
    model_ids: list[str] | None = None,
    warehouse_type: str | None = None,
    mat_counts: dict[str, int] | None = None,
    source_count: int = 0,
    model_names: list[str] | None = None,
    model_paths: list[str] | None = None,
    subject_areas: list[dict] | None = None,
    model_area_map: list[dict] | None = None,
    semantic_count: int = 0,
    test_count: int = 0,
    tested_model_count: int = 0,
    ic_count: int = 0,
    with_pk: int = 0,
    with_fk: int = 0,
    fk_count: int = 0,
    join_confirmed: int = 0,
    test_confirmed: int = 0,
    models_with_grain: int = 0,
    measure_count: int = 0,
    dimension_count: int = 0,
    fact_count: int = 0,
    join_edge_count: int = 0,
    col_lineage_edges: int = 0,
    models_with_col_lineage: int = 0,
) -> MagicMock:
    """Create a mock LineageStorage with canned query results."""
    storage = MagicMock()

    model_ids = model_ids or []
    mat_counts = mat_counts or {}
    model_names = model_names or []
    model_paths = model_paths or []
    subject_areas = subject_areas or []
    model_area_map = model_area_map or []

    def execute_raw_query(query: str, params=None):
        if "m.id AS id" in query:
            return make_raw_result([{"id": mid} for mid in model_ids])
        if "warehouse_type" in query:
            if warehouse_type:
                return make_raw_result([{"wt": warehouse_type}])
            return make_raw_result([])
        if "m.materialization AS mat" in query:
            return make_raw_result(
                [{"mat": k, "cnt": v} for k, v in mat_counts.items()]
            )
        if "DbtSource" in query:
            return make_raw_result([{"cnt": source_count}])
        if "BELONGS_TO_SUBJECT_AREA" in query:
            return make_raw_result(model_area_map)
        if "m.name AS name" in query:
            return make_raw_result([{"name": n} for n in model_names])
        if "m.original_path AS path" in query:
            return make_raw_result([{"path": p} for p in model_paths])
        if "HAS_INFERRED_SEMANTICS" in query:
            return make_raw_result(
                [{"total": len(model_ids), "analyzed": semantic_count}]
            )
        if "DbtTest" in query and "HAS_TEST" in query:
            return make_raw_result([{"cnt": tested_model_count}])
        if "DbtTest" in query:
            return make_raw_result([{"cnt": test_count}])
        # Enrichment queries
        if "IdentityClass" in query:
            return make_raw_result(
                [{"ic_count": ic_count, "with_pk": with_pk, "with_fk": with_fk}]
            )
        if "INFERRED_FK" in query:
            return make_raw_result(
                [{"fk_count": fk_count, "join_confirmed": join_confirmed, "test_confirmed": test_confirmed}]
            )
        if "grain_columns" in query:
            return make_raw_result([{"models_with_grain": models_with_grain}])
        if "InferredMeasure" in query:
            return make_raw_result([{"cnt": measure_count}])
        if "InferredDimension" in query:
            return make_raw_result([{"cnt": dimension_count}])
        if "InferredFact" in query:
            return make_raw_result([{"cnt": fact_count}])
        if "JoinEdge" in query:
            return make_raw_result([{"cnt": join_edge_count}])
        if "DERIVES_FROM" in query and "DISTINCT" in query:
            return make_raw_result([{"models_with_col_lineage": models_with_col_lineage}])
        if "DERIVES_FROM" in query:
            return make_raw_result([{"col_lineage_edges": col_lineage_edges}])
        return make_raw_result([])

    storage.execute_raw_query = MagicMock(side_effect=execute_raw_query)
    storage.list_subject_areas = MagicMock(return_value=subject_areas)
    return storage


# ── Unit Tests: Helper Functions ──


class TestExtractProjectName:
    def test_extracts_from_model_ids(self):
        ids = [
            "model.my_project.dim_customer",
            "model.my_project.fct_orders",
            "model.my_project.stg_raw",
        ]
        assert _extract_project_name(ids) == "my_project"

    def test_most_common_prefix(self):
        ids = [
            "model.project_a.dim_x",
            "model.project_b.dim_y",
            "model.project_a.fct_z",
        ]
        assert _extract_project_name(ids) == "project_a"

    def test_empty_returns_unknown(self):
        assert _extract_project_name([]) == "Unknown"

    def test_malformed_ids(self):
        assert _extract_project_name(["no_dots"]) == "Unknown"


class TestRenderModelCensus:
    def test_renders_counts(self):
        result = _render_model_census({"table": 10, "view": 5, "incremental": 3})
        assert "18 models total" in result
        assert "table: 10" in result
        assert "view: 5" in result
        assert "incremental: 3" in result

    def test_empty(self):
        assert "No models" in _render_model_census({})

    def test_custom_materialization(self):
        result = _render_model_census({"table": 5, "snapshot": 2})
        assert "snapshot: 2" in result


class TestRenderSubjectAreas:
    def test_renders_table(self):
        areas = [
            {
                "name": "Finance",
                "domains": ["revenue", "billing"],
                "fact_model_count": 3,
                "dimension_model_count": 5,
                "model_count": 8,
            }
        ]
        result = _render_subject_areas(areas)
        assert "Finance" in result
        assert "revenue, billing" in result
        assert "| 3 |" in result

    def test_empty_areas(self):
        result = _render_subject_areas([])
        assert "No subject areas" in result

    def test_limits_to_15(self):
        areas = [
            {"name": f"Area {i}", "domains": [], "model_count": 1}
            for i in range(20)
        ]
        result = _render_subject_areas(areas)
        assert "Area 14" in result
        assert "Area 15" not in result


class TestRenderModelIndex:
    def test_groups_by_subject_area(self):
        model_area_map = [
            {"name": "fct_orders", "materialization": "incremental", "path": "marts/fct_orders.sql", "area_name": "Commerce"},
            {"name": "dim_customer", "materialization": "table", "path": "marts/dim_customer.sql", "area_name": "Commerce"},
            {"name": "stg_raw_orders", "materialization": "view", "path": "staging/stg_raw_orders.sql", "area_name": "Commerce"},
            {"name": "fct_revenue", "materialization": "incremental", "path": "marts/fct_revenue.sql", "area_name": "Finance"},
        ]
        subject_areas = [
            {"name": "Commerce", "domains": ["orders", "shipping"], "model_count": 3},
            {"name": "Finance", "domains": ["revenue"], "model_count": 1},
        ]
        result = _render_model_index(model_area_map, subject_areas)
        assert "**Commerce**" in result
        assert "**Finance**" in result
        assert "`fct_orders` [incremental]" in result
        assert "`dim_customer` [table]" in result
        assert "`stg_raw_orders`" in result  # view tag omitted
        assert "`fct_revenue` [incremental]" in result

    def test_uncategorized_models(self):
        model_area_map = [
            {"name": "fct_orphan", "materialization": "table", "path": "marts/fct_orphan.sql", "area_name": None},
        ]
        result = _render_model_index(model_area_map, [])
        assert "**Uncategorized**" in result
        assert "`fct_orphan`" in result

    def test_empty(self):
        result = _render_model_index([], [])
        assert "No models" in result

    def test_caps_at_10_per_tier(self):
        models = [
            {"name": f"fct_model_{i}", "materialization": "table", "path": f"marts/fct_model_{i}.sql", "area_name": "Big"}
            for i in range(14)
        ]
        subject_areas = [{"name": "Big", "domains": [], "model_count": 14}]
        result = _render_model_index(models, subject_areas)
        assert "...+4 more" in result

    def test_domains_shown(self):
        model_area_map = [
            {"name": "fct_x", "materialization": "table", "path": "marts/fct_x.sql", "area_name": "Sales"},
        ]
        subject_areas = [{"name": "Sales", "domains": ["revenue", "pipeline"], "model_count": 1}]
        result = _render_model_index(model_area_map, subject_areas)
        assert "(revenue, pipeline)" in result


class TestRenderDataFlow:
    def test_infers_tiers(self):
        paths = [
            "staging/stg_orders.sql",
            "staging/stg_customers.sql",
            "marts/fct_revenue.sql",
            "marts/dim_customer.sql",
            "intermediate/int_orders.sql",
        ]
        result = _render_data_flow({}, paths)
        assert "Staging: 2" in result
        assert "Marts: 2" in result
        assert "Intermediate: 1" in result

    def test_empty(self):
        result = _render_data_flow({}, [])
        assert "No model paths" in result


class TestRenderCoverage:
    def test_renders_percentages(self):
        result = _render_coverage(100, 75, 50, 80)
        assert "75%" in result
        assert "80%" in result
        assert "Total tests: 50" in result

    def test_zero_models(self):
        result = _render_coverage(0, 0, 0, 0)
        assert "No coverage" in result


class TestRenderNamingConventionsFallback:
    def test_counts_prefixes(self):
        names = ["fct_orders", "fct_revenue", "dim_customer", "dim_product", "stg_raw"]
        result = _render_naming_conventions_fallback(names)
        assert "`fct_*`: 2" in result
        assert "`dim_*`: 2" in result

    def test_empty(self):
        result = _render_naming_conventions_fallback([])
        assert "No models" in result


class TestRenderDirectoryOrgFallback:
    def test_counts_dirs(self):
        paths = [
            "marts/fct_orders.sql",
            "marts/dim_customer.sql",
            "staging/stg_raw.sql",
        ]
        result = _render_directory_org_fallback(paths)
        assert "`marts/`: 2" in result
        assert "`staging/`: 1" in result

    def test_empty(self):
        result = _render_directory_org_fallback([])
        assert "No model paths" in result


class TestRenderProjectSummaryFallback:
    def test_basic_summary(self):
        result = _render_project_summary_fallback(
            "my_project", 25, "snowflake",
            ["Finance", "Sales", "Marketing"], 50, 120,
        )
        assert "my_project" in result
        assert "25 models" in result
        assert "snowflake" in result
        assert "Finance" in result
        assert "120 measures" in result

    def test_no_warehouse(self):
        result = _render_project_summary_fallback("proj", 10, None, [], 0, 0)
        assert "proj" in result
        assert "10 models" in result
        assert "snowflake" not in result

    def test_zero_models(self):
        result = _render_project_summary_fallback("proj", 0, None, [], 0, 0)
        assert "0 models" in result

    def test_many_subject_areas_truncated(self):
        areas = ["A", "B", "C", "D", "E", "F"]
        result = _render_project_summary_fallback("proj", 10, None, areas, 5, 0)
        assert "A, B, C, D" in result
        assert "2 more" in result

    def test_with_sources(self):
        result = _render_project_summary_fallback("proj", 10, None, [], 50, 0)
        assert "50 sources" in result


class TestRenderKeyLineage:
    def test_full_data(self):
        result = _render_key_lineage(12, 10, 8, 15, 9, 4, 18, 25)
        assert "Entity key classes: 12" in result
        assert "10 with PK" in result
        assert "8 with FK" in result
        assert "Inferred FK relationships: 15" in result
        assert "9 join-confirmed" in result
        assert "4 test-confirmed" in result
        assert "Grain detection: 18/25" in result
        assert "72%" in result

    def test_empty(self):
        result = _render_key_lineage(0, 0, 0, 0, 0, 0, 0, 25)
        assert "has not been computed yet" in result

    def test_partial_data(self):
        result = _render_key_lineage(5, 3, 2, 0, 0, 0, 0, 10)
        assert "Entity key classes: 5" in result
        assert "Inferred FK" not in result
        assert "Grain detection" not in result


class TestRenderSemanticRichness:
    def test_full_data(self):
        result = _render_semantic_richness(45, 78, 32, 18)
        assert "Measures: 45" in result
        assert "Dimensions: 78" in result
        assert "Facts: 32" in result
        assert "Inferred join edges: 18" in result

    def test_empty(self):
        result = _render_semantic_richness(0, 0, 0, 0)
        assert "has not been run yet" in result

    def test_no_join_edges(self):
        result = _render_semantic_richness(10, 20, 5, 0)
        assert "Measures: 10" in result
        assert "join edges" not in result


class TestRenderColumnLineageDepth:
    def test_full_data(self):
        result = _render_column_lineage_depth(342, 20, 25)
        assert "342 transformations traced" in result
        assert "20/25 models" in result
        assert "80%" in result

    def test_empty(self):
        result = _render_column_lineage_depth(0, 0, 25)
        assert "has not been computed yet" in result

    def test_edges_only(self):
        result = _render_column_lineage_depth(100, 0, 25)
        assert "100 transformations traced" in result
        assert "coverage" not in result


class TestRenderCoverageEnhanced:
    def test_with_grain_and_col_lineage(self):
        result = _render_coverage(25, 20, 10, 18, models_with_grain=18, col_lineage_model_count=20)
        assert "Grain detection: 18/25" in result
        assert "Column lineage: 20/25" in result

    def test_without_enrichment(self):
        result = _render_coverage(25, 20, 10, 18)
        assert "Grain detection" not in result
        assert "Column lineage" not in result


class TestRenderExplorationHintsFallback:
    def test_suggests_fact_lineage(self):
        result = _render_exploration_hints_fallback(
            subject_area_names=["Sales"],
            fact_model_names=["fct_orders", "fct_revenue"],
            model_names=["fct_orders", "fct_revenue", "dim_customer"],
            fk_count=10, measure_count=50,
        )
        assert "fct_orders" in result
        assert "get_relation_lineage" in result
        assert 'node_type="logical"' in result

    def test_suggests_semantics_when_measures_exist(self):
        result = _render_exploration_hints_fallback(
            subject_area_names=[],
            fact_model_names=["fct_orders", "fct_revenue"],
            model_names=["fct_orders"],
            fk_count=0, measure_count=30,
        )
        assert "get_model_details" in result
        assert "include_semantics" in result

    def test_suggests_subject_area_details(self):
        result = _render_exploration_hints_fallback(
            subject_area_names=["Finance", "Sales"],
            fact_model_names=["fct_revenue"],
            model_names=["fct_revenue"],
            fk_count=0, measure_count=0,
        )
        assert "get_subject_area_details" in result
        assert "Finance" in result

    def test_suggests_downstream_impact(self):
        result = _render_exploration_hints_fallback(
            subject_area_names=[],
            fact_model_names=["fct_orders", "fct_revenue"],
            model_names=["fct_orders"],
            fk_count=15, measure_count=0,
        )
        assert "get_downstream_impact" in result

    def test_caps_at_5_hints(self):
        result = _render_exploration_hints_fallback(
            subject_area_names=["A", "B"],
            fact_model_names=["fct_x", "fct_y"],
            model_names=["fct_x", "fct_y", "dim_z"],
            fk_count=10, measure_count=50,
        )
        lines = [line for line in result.split("\n") if line.startswith("- ")]
        assert len(lines) <= 5

    def test_empty_project(self):
        result = _render_exploration_hints_fallback(
            subject_area_names=[], fact_model_names=[],
            model_names=[], fk_count=0, measure_count=0,
        )
        assert "search_graph_nodes" in result


# ── Integration Tests: compute_project_overview ──


@pytest.mark.asyncio
async def test_compute_overview_basic():
    """Test full computation with canned query results."""
    storage = make_mock_storage(
        model_ids=[
            "model.demo.fct_orders",
            "model.demo.dim_customer",
            "model.demo.stg_raw",
        ],
        warehouse_type="snowflake",
        mat_counts={"table": 2, "view": 1},
        source_count=5,
        model_names=["fct_orders", "dim_customer", "stg_raw"],
        model_paths=[
            "marts/fct_orders.sql",
            "marts/dim_customer.sql",
            "staging/stg_raw.sql",
        ],
        subject_areas=[
            {
                "name": "Orders",
                "domains": ["commerce"],
                "fact_model_count": 1,
                "dimension_model_count": 1,
                "model_count": 2,
            }
        ],
        semantic_count=2,
        test_count=10,
        tested_model_count=2,
    )

    result = await compute_project_overview(storage, session=None)

    assert isinstance(result, ProjectOverviewData)
    assert result.project_name == "demo"
    assert result.warehouse_target == "snowflake"
    assert result.model_count == 3
    assert result.source_count == 5
    assert "demo" in result.overview_markdown
    assert "snowflake" in result.overview_markdown
    assert "Orders" in result.overview_markdown


@pytest.mark.asyncio
async def test_compute_overview_empty_graph():
    """Test with no data in graph — graceful message."""
    storage = make_mock_storage()

    result = await compute_project_overview(storage, session=None)

    assert result.project_name == "Unknown"
    assert result.model_count == 0
    assert result.source_count == 0
    assert result.overview_markdown  # Should still produce some output


@pytest.mark.asyncio
async def test_compute_overview_no_session_uses_fallback():
    """Test that LLM cells fall back to templates when no session provided."""
    storage = make_mock_storage(
        model_ids=["model.proj.fct_x", "model.proj.dim_y"],
        model_names=["fct_x", "dim_y"],
        model_paths=["marts/fct_x.sql", "marts/dim_y.sql"],
        mat_counts={"table": 2},
    )

    result = await compute_project_overview(storage, session=None)

    # Naming conventions should use fallback (visible in overview_markdown)
    assert "fct_" in result.overview_markdown or "dim_" in result.overview_markdown

    # Directory org should use fallback
    assert "marts" in result.overview_markdown


@pytest.mark.asyncio
async def test_compute_overview_cell_names():
    """Verify all expected cells are present."""
    storage = make_mock_storage(
        model_ids=["model.proj.dim_x"],
        mat_counts={"table": 1},
        model_names=["dim_x"],
    )
    result = await compute_project_overview(storage, session=None)

    # All expected sections should appear in the rendered markdown
    for section in [
        "Project Summary",
        "Project Identity",
        "Model Census",
        "Data Flow Summary",
        "Key Relationships & Grain",
        "Semantic Richness",
        "Column Lineage Depth",
        "Coverage",
        "Naming Conventions",
        "Directory Organization",
        "Subject Areas",
        "Model Index",
        "Exploration Hints",
    ]:
        assert f"### {section}" in result.overview_markdown


@pytest.mark.asyncio
async def test_compute_overview_with_llm_session():
    """Test LLM cell rendering with a mock Fenic session."""
    mock_session = MagicMock()

    # Mock session.create_dataframe -> df.select -> to_pylist chain
    mock_select = MagicMock()
    mock_select.to_pylist = MagicMock(
        return_value=[{"result": "- Uses `fct_` prefix for fact tables\n- Uses `dim_` for dimensions"}]
    )
    mock_df = MagicMock()
    mock_df.select = MagicMock(return_value=mock_select)
    mock_session.create_dataframe = MagicMock(return_value=mock_df)

    storage = make_mock_storage(
        model_ids=["model.proj.fct_x", "model.proj.dim_y"],
        model_names=["fct_x", "dim_y"],
        model_paths=["marts/fct_x.sql", "staging/stg_y.sql"],
        mat_counts={"table": 2},
    )

    result = await compute_project_overview(storage, session=mock_session)

    # LLM cells should have the mock response in overview_markdown
    assert "fct_" in result.overview_markdown


@pytest.mark.asyncio
async def test_compute_overview_llm_failure_falls_back():
    """Test that LLM failure gracefully falls back to template."""
    mock_session = MagicMock()

    # Make create_dataframe raise to trigger fallback
    mock_session.create_dataframe = MagicMock(side_effect=RuntimeError("LLM unavailable"))

    storage = make_mock_storage(
        model_ids=["model.proj.fct_x"],
        model_names=["fct_x"],
        model_paths=["marts/fct_x.sql"],
        mat_counts={"table": 1},
    )

    result = await compute_project_overview(storage, session=mock_session)

    # Should still have naming conventions in overview with fallback content
    assert "Naming Conventions" in result.overview_markdown


# ── Test: ProjectOverviewLoader ──


def test_loader_generate():
    """Test that ProjectOverviewLoader calls storage.write_project_overview."""
    from lineage.ingest.static_loaders.overview.loader import ProjectOverviewLoader

    storage = make_mock_storage(
        model_ids=["model.proj.dim_x"],
        mat_counts={"table": 1},
        model_names=["dim_x"],
    )

    loader = ProjectOverviewLoader(storage)
    loader.generate(session=None, verbose=True)

    storage.write_project_overview.assert_called_once()
    call_args = storage.write_project_overview.call_args[0][0]
    assert call_args["project_name"] == "proj"
    assert call_args["model_count"] == 1


@pytest.mark.asyncio
async def test_compute_overview_with_enrichment_data():
    """Test that enrichment data (key lineage, semantic richness, column lineage) appears."""
    storage = make_mock_storage(
        model_ids=["model.demo.fct_orders", "model.demo.dim_customer"],
        mat_counts={"table": 2},
        model_names=["fct_orders", "dim_customer"],
        ic_count=12,
        with_pk=10,
        with_fk=8,
        fk_count=15,
        join_confirmed=9,
        test_confirmed=4,
        models_with_grain=2,
        measure_count=45,
        dimension_count=78,
        fact_count=32,
        join_edge_count=18,
        col_lineage_edges=342,
        models_with_col_lineage=2,
    )

    result = await compute_project_overview(storage, session=None)

    # Key lineage data in markdown
    assert "Entity key classes: 12" in result.overview_markdown
    assert "Inferred FK relationships: 15" in result.overview_markdown
    assert "Grain detection: 2/2" in result.overview_markdown

    # Semantic richness
    assert "Measures: 45" in result.overview_markdown
    assert "Dimensions: 78" in result.overview_markdown
    assert "Facts: 32" in result.overview_markdown
    assert "Inferred join edges: 18" in result.overview_markdown

    # Column lineage
    assert "342 transformations traced" in result.overview_markdown
    assert "Column lineage coverage: 2/2" in result.overview_markdown

    # Enhanced coverage
    assert "Grain detection" in result.overview_markdown
    assert "Column lineage" in result.overview_markdown


@pytest.mark.asyncio
async def test_compute_overview_enrichment_not_run():
    """Test graceful fallbacks when enrichment passes haven't been run."""
    storage = make_mock_storage(
        model_ids=["model.demo.dim_x"],
        mat_counts={"table": 1},
        model_names=["dim_x"],
    )

    result = await compute_project_overview(storage, session=None)

    assert "Key lineage has not been computed yet" in result.overview_markdown
    assert "Semantic analysis has not been run yet" in result.overview_markdown
    assert "Column lineage has not been computed yet" in result.overview_markdown


@pytest.mark.asyncio
async def test_compute_overview_project_summary_fallback():
    """Test that project summary fallback renders correctly."""
    storage = make_mock_storage(
        model_ids=["model.demo.fct_x", "model.demo.dim_y"],
        warehouse_type="snowflake",
        mat_counts={"table": 2},
        model_names=["fct_x", "dim_y"],
        subject_areas=[{"name": "Sales", "domains": ["revenue"], "model_count": 2}],
        semantic_count=1,
        ic_count=3,
    )

    result = await compute_project_overview(storage, session=None)

    assert "### Project Summary" in result.overview_markdown
    assert "demo" in result.overview_markdown
    assert "2 models" in result.overview_markdown
    assert "snowflake" in result.overview_markdown


@pytest.mark.asyncio
async def test_compute_overview_project_summary_llm():
    """Test that project summary uses LLM when session is available."""
    mock_session = MagicMock()
    mock_select = MagicMock()
    mock_select.to_pylist = MagicMock(
        return_value=[{"result": "This is a sophisticated dbt project with 2 models."}]
    )
    mock_df = MagicMock()
    mock_df.select = MagicMock(return_value=mock_select)
    mock_session.create_dataframe = MagicMock(return_value=mock_df)

    storage = make_mock_storage(
        model_ids=["model.demo.fct_x", "model.demo.dim_y"],
        mat_counts={"table": 2},
        model_names=["fct_x", "dim_y"],
    )

    result = await compute_project_overview(storage, session=mock_session)

    assert "sophisticated dbt project" in result.overview_markdown
