"""Unit tests for Salesforce Report IR transformer."""

from typing import Optional

from lineage.backends.lineage.models.edges import HighlightsFormula, MapsToNativeField
from lineage.backends.lineage.models.report import (
    ReportIRCrossFilter,
    ReportIRHighlight,
    ReportIRJoin,
)
from lineage.formula.ast import FieldRef
from lineage.ingest.static_loaders.reports.salesforce.transformer import (
    SalesforceIRTransformer,
    _column_key_from_field_ref,
)


class MockTransformer:
    """Mock transformer for testing _parse_column_key and ref_entity logic.

    This mirrors the relevant logic from SalesforceIRTransformer.
    """

    def __init__(self, org_key: str):
        self.org_key = org_key

    def _parse_column_key(self, col_key: str) -> tuple[Optional[str], Optional[str]]:
        """Parse Salesforce column key into entity and field."""
        if "." in col_key:
            parts = col_key.split(".", 1)
            return parts[0], parts[1] if len(parts) > 1 else None
        elif "!" in col_key:
            return None, col_key
        else:
            return None, col_key

    def _map_field_type(self, sf_data_type: str) -> str:
        """Map Salesforce data type to IR field type."""
        measure_types = {"currency", "double", "int", "percent", "number"}
        time_types = {"date", "datetime", "time"}

        sf_data_type_lower = sf_data_type.lower() if sf_data_type else ""
        if sf_data_type_lower in measure_types:
            return "measure"
        elif sf_data_type_lower in time_types:
            return "time"
        else:
            return "dimension"

    def _infer_role(self, field_type: str) -> str:
        """Infer role from field type."""
        if field_type == "measure":
            return "aggregation"
        elif field_type == "time":
            return "grouping"
        else:
            return "display"

    def transform_column(self, col: dict) -> dict:
        """Transform a column using the updated logic with object_api_name."""
        column_key = col.get("column_key") or col.get("name", "")
        if not column_key:
            return {}

        # Use stored object_api_name as primary source, fall back to parsing
        stored_object = col.get("object_api_name")
        parsed_entity, ref_field = self._parse_column_key(column_key)
        ref_entity = stored_object or parsed_entity

        # Use data_type from resolved field if available
        data_type = col.get("data_type")
        field_type = self._map_field_type(data_type) if data_type else "dimension"
        role = self._infer_role(field_type)

        return {
            "name": col.get("name", column_key),
            "alias": column_key,
            "field_type": field_type,
            "role": role,
            "ref_entity": ref_entity,
            "ref_field": ref_field,
            "label": col.get("name"),
        }


class TestSalesforceIRTransformerGraphBased:
    """Tests for graph-based transformation (from SfReport nodes)."""

    def test_transform_uses_object_api_name_for_ref_entity(self):
        """Test transformer uses stored object_api_name as ref_entity."""
        transformer = MockTransformer(org_key="testorg")
        col = {
            "name": "Amount",
            "column_key": "AMOUNT",
            "data_type": "currency",
            "object_api_name": "Opportunity",  # From col_to_obj mapping
        }

        result = transformer.transform_column(col)

        assert result["ref_entity"] == "Opportunity"
        assert result["ref_field"] == "AMOUNT"
        assert result["field_type"] == "measure"

    def test_transform_falls_back_to_parsing_when_no_object_api_name(self):
        """Test transformer falls back to column key parsing when object_api_name is None."""
        transformer = MockTransformer(org_key="testorg")
        col = {
            "name": "Account Name",
            "column_key": "Account.Name",
            "data_type": "string",
            "object_api_name": None,  # Not set
        }

        result = transformer.transform_column(col)

        # Should fall back to parsing "Account.Name"
        assert result["ref_entity"] == "Account"
        assert result["ref_field"] == "Name"

    def test_transform_dotted_column_key_with_object_api_name(self):
        """Test dotted column key still uses object_api_name when present."""
        transformer = MockTransformer(org_key="testorg")
        col = {
            "name": "Account Name",
            "column_key": "Account.Name",
            "data_type": "string",
            "object_api_name": "Account",  # Matches column key prefix
        }

        result = transformer.transform_column(col)

        assert result["ref_entity"] == "Account"
        assert result["ref_field"] == "Name"

    def test_transform_simple_column_key_with_object_api_name(self):
        """Test simple column key (no dot) uses object_api_name."""
        transformer = MockTransformer(org_key="testorg")
        col = {
            "name": "Close Date",
            "column_key": "CLOSE_DATE",
            "data_type": "date",
            "object_api_name": "Opportunity",
        }

        result = transformer.transform_column(col)

        assert result["ref_entity"] == "Opportunity"
        assert result["ref_field"] == "CLOSE_DATE"
        assert result["field_type"] == "time"

    def test_transform_multiple_columns_with_mixed_sources(self):
        """Test multiple columns with both object_api_name and parsing."""
        transformer = MockTransformer(org_key="testorg")
        columns = [
            {
                "name": "Amount",
                "column_key": "AMOUNT",
                "data_type": "currency",
                "object_api_name": "Opportunity",  # From mapping
            },
            {
                "name": "Account Name",
                "column_key": "Account.Name",
                "data_type": "string",
                "object_api_name": None,  # Falls back to parsing
            },
            {
                "name": "Owner Name",
                "column_key": "OWNER_NAME",
                "data_type": "string",
                "object_api_name": "User",  # From mapping
            },
        ]

        results = [transformer.transform_column(col) for col in columns]

        # AMOUNT from Opportunity (via object_api_name)
        amount_result = next(r for r in results if r["alias"] == "AMOUNT")
        assert amount_result["ref_entity"] == "Opportunity"

        # Account.Name parsed
        account_result = next(r for r in results if r["alias"] == "Account.Name")
        assert account_result["ref_entity"] == "Account"

        # OWNER_NAME from User (via object_api_name)
        owner_result = next(r for r in results if r["alias"] == "OWNER_NAME")
        assert owner_result["ref_entity"] == "User"


class TestFieldTypeMapping:
    """Tests for Salesforce data type to IR field type mapping."""

    def test_currency_maps_to_measure(self):
        """Test currency data type maps to measure field type."""
        transformer = MockTransformer(org_key="testorg")
        col = {"column_key": "AMOUNT", "data_type": "currency", "object_api_name": "Opp"}

        result = transformer.transform_column(col)

        assert result["field_type"] == "measure"
        assert result["role"] == "aggregation"

    def test_date_maps_to_time(self):
        """Test date data type maps to time field type."""
        transformer = MockTransformer(org_key="testorg")
        col = {"column_key": "CLOSE_DATE", "data_type": "date", "object_api_name": "Opp"}

        result = transformer.transform_column(col)

        assert result["field_type"] == "time"
        assert result["role"] == "grouping"

    def test_string_maps_to_dimension(self):
        """Test string data type maps to dimension field type."""
        transformer = MockTransformer(org_key="testorg")
        col = {"column_key": "NAME", "data_type": "string", "object_api_name": "Account"}

        result = transformer.transform_column(col)

        assert result["field_type"] == "dimension"
        assert result["role"] == "display"

    def test_no_data_type_defaults_to_dimension(self):
        """Test missing data type defaults to dimension field type."""
        transformer = MockTransformer(org_key="testorg")
        col = {"column_key": "UNKNOWN", "object_api_name": "X"}

        result = transformer.transform_column(col)

        assert result["field_type"] == "dimension"


class TestColumnKeyParsing:
    """Tests for _parse_column_key method."""

    def test_parse_dotted_column_key(self):
        """Test parsing column key with dot separator."""
        transformer = MockTransformer(org_key="testorg")
        entity, field = transformer._parse_column_key("Account.Name")
        assert entity == "Account"
        assert field == "Name"

    def test_parse_simple_column_key(self):
        """Test parsing simple column key without dot."""
        transformer = MockTransformer(org_key="testorg")
        entity, field = transformer._parse_column_key("AMOUNT")
        assert entity is None
        assert field == "AMOUNT"

    def test_parse_aggregate_column_key(self):
        """Test parsing aggregate column key with exclamation mark."""
        transformer = MockTransformer(org_key="testorg")
        entity, field = transformer._parse_column_key("s!AMOUNT")
        assert entity is None
        assert field == "s!AMOUNT"

    def test_parse_multi_dot_column_key(self):
        """Test parsing column key with multiple dots."""
        transformer = MockTransformer(org_key="testorg")
        entity, field = transformer._parse_column_key("Owner.Manager.Name")
        assert entity == "Owner"
        assert field == "Manager.Name"


# ---------------------------------------------------------------------------
# Formula cross-stitching tests
# ---------------------------------------------------------------------------

class TestColumnKeyFromFieldRef:
    """Tests for _column_key_from_field_ref helper."""

    def test_column_key_plain(self):
        ref = FieldRef(field_name="AMOUNT", raw="AMOUNT", aggregation=None, object_path=None)
        assert _column_key_from_field_ref(ref) == "AMOUNT"

    def test_column_key_with_aggregation(self):
        ref = FieldRef(field_name="AMOUNT", raw="AMOUNT:SUM", aggregation="SUM", object_path=None)
        assert _column_key_from_field_ref(ref) == "AMOUNT"

    def test_column_key_object_path(self):
        ref = FieldRef(field_name="Name", raw="Account.Name", aggregation=None, object_path=["Account"])
        assert _column_key_from_field_ref(ref) == "Account.Name"


class TestFormulaStitching:
    """Tests for formula→SfReportColumn cross-stitching in SalesforceIRTransformer."""

    ORG_KEY = "test_org"
    REPORT_ID = "00O000000000001"

    def _make_report_data(self, formulas_metadata: dict) -> dict:
        """Build minimal report_data with columns and formula metadata."""
        return {
            "report_id": self.REPORT_ID,
            "name": "Test Report",
            "org_key": self.ORG_KEY,
            "report_format": "TABULAR",
            "report_type": "Opportunity",
            "columns": [
                {"column_key": "TOTAL_PRICE", "name": "Total Price", "data_type": "currency"},
                {"column_key": "QUANTITY", "name": "Quantity", "data_type": "double"},
                {"column_key": "AMOUNT", "name": "Amount", "data_type": "currency"},
                {"column_key": "PROBABILITY", "name": "Probability", "data_type": "percent"},
            ],
            "metadata_api_json": formulas_metadata,
        }

    def _computed_edges(self, result):
        """Extract edges with mapping_type='computed'."""
        return [
            (src, tgt, edge)
            for src, tgt, edge in result.extra_edges
            if getattr(edge, "mapping_type", None) == "computed"
        ]

    def test_formula_stitching_row_formula(self):
        """TOTAL_PRICE / QUANTITY produces 2 computed edges."""
        data = self._make_report_data({
            "customDetailFormulas": [{
                "label": "Unit Price",
                "developerName": "FORMULA_UnitPrice",
                "calculatedFormula": "TOTAL_PRICE / QUANTITY",
                "dataType": "Currency",
            }],
        })
        result = SalesforceIRTransformer().transform(data)
        computed = self._computed_edges(result)

        target_ids = sorted(tgt.id for _, tgt, _ in computed)
        expected = sorted([
            f"sf_report_col::{self.ORG_KEY}::{self.REPORT_ID}::TOTAL_PRICE",
            f"sf_report_col::{self.ORG_KEY}::{self.REPORT_ID}::QUANTITY",
        ])
        assert target_ids == expected

    def test_formula_stitching_summary_aggregation(self):
        """AMOUNT:SUM * PROBABILITY:AVG → edges to AMOUNT and PROBABILITY."""
        data = self._make_report_data({
            "aggregates": [{
                "masterLabel": "Weighted Amount",
                "developerName": "FORMULA_Weighted",
                "calculatedFormula": "AMOUNT:SUM * PROBABILITY:AVG",
                "datatype": "Currency",
            }],
        })
        result = SalesforceIRTransformer().transform(data)
        computed = self._computed_edges(result)

        target_ids = sorted(tgt.id for _, tgt, _ in computed)
        expected = sorted([
            f"sf_report_col::{self.ORG_KEY}::{self.REPORT_ID}::AMOUNT",
            f"sf_report_col::{self.ORG_KEY}::{self.REPORT_ID}::PROBABILITY",
        ])
        assert target_ids == expected

    def test_formula_stitching_deduplication(self):
        """AMOUNT + AMOUNT → 1 edge, not 2."""
        data = self._make_report_data({
            "customDetailFormulas": [{
                "label": "Double Amount",
                "developerName": "FORMULA_Double",
                "calculatedFormula": "AMOUNT + AMOUNT",
                "dataType": "Currency",
            }],
        })
        result = SalesforceIRTransformer().transform(data)
        computed = self._computed_edges(result)
        assert len(computed) == 1
        assert computed[0][1].id == f"sf_report_col::{self.ORG_KEY}::{self.REPORT_ID}::AMOUNT"

    def test_formula_parse_error_graceful(self):
        """Unparseable expression → no computed edges, no exception."""
        data = self._make_report_data({
            "customDetailFormulas": [{
                "label": "Bad Formula",
                "developerName": "FORMULA_Bad",
                "calculatedFormula": "{{{{INVALID SYNTAX}}}}",
                "dataType": "Currency",
            }],
        })
        result = SalesforceIRTransformer().transform(data)
        computed = self._computed_edges(result)
        assert computed == []

    def test_formula_empty_expression(self):
        """Formula with no expression → skipped."""
        data = self._make_report_data({
            "customDetailFormulas": [{
                "label": "Empty",
                "developerName": "FORMULA_Empty",
                "calculatedFormula": None,
                "dataType": "Currency",
            }],
        })
        result = SalesforceIRTransformer().transform(data)
        computed = self._computed_edges(result)
        assert computed == []


# ---------------------------------------------------------------------------
# Join extraction and stitching tests
# ---------------------------------------------------------------------------

class TestJoinExtraction:
    """Tests for _extract_joins() with column-based object detection."""

    ORG_KEY = "test_org"
    REPORT_ID = "00O000000000002"

    def _make_report_data(
        self,
        columns: list[dict],
        join_fields: dict | None = None,
        metadata: dict | None = None,
    ) -> dict:
        return {
            "report_id": self.REPORT_ID,
            "name": "Join Test Report",
            "org_key": self.ORG_KEY,
            "report_format": "TABULAR",
            "report_type": "Opportunity",
            "columns": columns,
            "join_fields": join_fields or {},
            "metadata_api_json": metadata,
        }

    def _join_nodes(self, result) -> list:
        return [n for n in result.ir_nodes if isinstance(n, ReportIRJoin)]

    def test_extract_joins_from_column_objects(self):
        """Columns with Opportunity+Account → 1 join with FK fields."""
        data = self._make_report_data(
            columns=[
                {"column_key": "AMOUNT", "data_type": "currency", "object_api_name": "Opportunity"},
                {"column_key": "STAGE_NAME", "data_type": "string", "object_api_name": "Opportunity"},
                {"column_key": "ACCOUNT_NAME", "data_type": "string", "object_api_name": "Account"},
            ],
            join_fields={("Opportunity", "Account"): "AccountId"},
        )
        result = SalesforceIRTransformer().transform(data)
        joins = self._join_nodes(result)

        assert len(joins) == 1
        j = joins[0]
        assert j.from_entity == "Opportunity"
        assert j.to_entity == "Account"
        assert j.from_field == "AccountId"
        assert j.to_field == "Id"

    def test_extract_joins_single_object(self):
        """All columns same object → 0 joins."""
        data = self._make_report_data(
            columns=[
                {"column_key": "AMOUNT", "data_type": "currency", "object_api_name": "Opportunity"},
                {"column_key": "STAGE_NAME", "data_type": "string", "object_api_name": "Opportunity"},
            ],
        )
        result = SalesforceIRTransformer().transform(data)
        joins = self._join_nodes(result)
        assert len(joins) == 0

    def test_extract_joins_no_lookup_field(self):
        """Objects present but no relationship in join_fields → join with from_field=None."""
        data = self._make_report_data(
            columns=[
                {"column_key": "AMOUNT", "data_type": "currency", "object_api_name": "Opportunity"},
                {"column_key": "PRODUCT_NAME", "data_type": "string", "object_api_name": "Product2"},
            ],
            join_fields={},  # No FK relationship known
        )
        result = SalesforceIRTransformer().transform(data)
        joins = self._join_nodes(result)

        assert len(joins) == 1
        j = joins[0]
        assert j.from_entity == "Opportunity"
        assert j.to_entity == "Product2"
        assert j.from_field is None
        assert j.to_field is None

    def test_extract_joins_reverse_lookup(self):
        """Contact+Opportunity where FK is on Opportunity → reverse resolved."""
        data = self._make_report_data(
            columns=[
                {"column_key": "FULL_NAME", "data_type": "string", "object_api_name": "Contact"},
                {"column_key": "OPP_NAME", "data_type": "string", "object_api_name": "Opportunity"},
            ],
            # FK is Opportunity.ContactId → Contact, not Contact→Opportunity
            join_fields={("Opportunity", "Contact"): "ContactId"},
        )
        result = SalesforceIRTransformer().transform(data)
        joins = self._join_nodes(result)

        assert len(joins) == 1
        j = joins[0]
        assert j.from_entity == "Contact"
        assert j.to_entity == "Opportunity"
        # Reverse: Contact is primary, FK is on Opportunity side
        assert j.from_field == "Id"
        assert j.to_field == "ContactId"

    def test_extract_joins_three_objects(self):
        """3 objects → 2 joins."""
        data = self._make_report_data(
            columns=[
                {"column_key": "OPP_NAME", "data_type": "string", "object_api_name": "Opportunity"},
                {"column_key": "ACCT_NAME", "data_type": "string", "object_api_name": "Account"},
                {"column_key": "CONTACT_NAME", "data_type": "string", "object_api_name": "Contact"},
            ],
            join_fields={
                ("Opportunity", "Account"): "AccountId",
                ("Contact", "Account"): "AccountId",
            },
        )
        result = SalesforceIRTransformer().transform(data)
        joins = self._join_nodes(result)

        assert len(joins) == 2
        assert joins[0].from_entity == "Opportunity"
        assert joins[0].to_entity == "Account"
        assert joins[0].from_field == "AccountId"
        assert joins[1].from_entity == "Opportunity"
        assert joins[1].to_entity == "Contact"

    def test_extract_joins_skips_none_object(self):
        """Columns with object_api_name=None are ignored for join detection."""
        data = self._make_report_data(
            columns=[
                {"column_key": "AMOUNT", "data_type": "currency", "object_api_name": "Opportunity"},
                {"column_key": "UNKNOWN", "data_type": "string", "object_api_name": None},
            ],
        )
        result = SalesforceIRTransformer().transform(data)
        joins = self._join_nodes(result)
        assert len(joins) == 0


class TestJoinStitching:
    """Tests for ReportIRJoin → SfReportColumn cross-stitching."""

    ORG_KEY = "test_org"
    REPORT_ID = "00O000000000003"

    def _join_key_edges(self, result):
        """Extract edges with mapping_type='join_key'."""
        return [
            (src, tgt, edge)
            for src, tgt, edge in result.extra_edges
            if getattr(edge, "mapping_type", None) == "join_key"
        ]

    def test_join_stitching_fk_column_present(self):
        """Join FK column exists in report → edge created."""
        data = {
            "report_id": self.REPORT_ID,
            "name": "Stitch Test",
            "org_key": self.ORG_KEY,
            "report_format": "TABULAR",
            "report_type": "Opportunity",
            "columns": [
                {"column_key": "AMOUNT", "data_type": "currency", "object_api_name": "Opportunity"},
                {"column_key": "ACCOUNT_ID", "data_type": "id", "object_api_name": "Opportunity"},
                {"column_key": "ACCOUNT_NAME", "data_type": "string", "object_api_name": "Account"},
            ],
            "join_fields": {("Opportunity", "Account"): "AccountId"},
            "metadata_api_json": None,
        }
        result = SalesforceIRTransformer().transform(data)
        jk_edges = self._join_key_edges(result)

        assert len(jk_edges) == 1
        src, tgt, edge = jk_edges[0]
        assert isinstance(src, ReportIRJoin)
        assert tgt.id == f"sf_report_col::{self.ORG_KEY}::{self.REPORT_ID}::ACCOUNT_ID"

    def test_join_stitching_fk_column_absent(self):
        """Join FK not a report column → no edge, no error."""
        data = {
            "report_id": self.REPORT_ID,
            "name": "Stitch Test No FK",
            "org_key": self.ORG_KEY,
            "report_format": "TABULAR",
            "report_type": "Opportunity",
            "columns": [
                {"column_key": "AMOUNT", "data_type": "currency", "object_api_name": "Opportunity"},
                {"column_key": "ACCOUNT_NAME", "data_type": "string", "object_api_name": "Account"},
            ],
            "join_fields": {("Opportunity", "Account"): "AccountId"},
            "metadata_api_json": None,
        }
        result = SalesforceIRTransformer().transform(data)
        jk_edges = self._join_key_edges(result)
        assert len(jk_edges) == 0


# ---------------------------------------------------------------------------
# Highlight stitching tests
# ---------------------------------------------------------------------------

class TestHighlightStitching:
    """Tests for ReportIRHighlight cross-stitching."""

    ORG_KEY = "test_org"
    REPORT_ID = "00O000000000004"

    def _make_report_data(self, highlights_metadata: dict, extra_metadata: dict | None = None) -> dict:
        """Build minimal report_data with highlights metadata."""
        md = {}
        if extra_metadata:
            md.update(extra_metadata)
        md.update(highlights_metadata)
        return {
            "report_id": self.REPORT_ID,
            "name": "Highlight Test Report",
            "org_key": self.ORG_KEY,
            "report_format": "SUMMARY",
            "report_type": "Opportunity",
            "columns": [
                {"column_key": "AMOUNT", "name": "Amount", "data_type": "currency"},
            ],
            "metadata_api_json": md,
        }

    def _highlights_formula_edges(self, result):
        """Extract HighlightsFormula edges."""
        return [
            (src, tgt, edge)
            for src, tgt, edge in result.extra_edges
            if isinstance(edge, HighlightsFormula)
        ]

    def _highlight_native_edges(self, result):
        """Extract MAPS_TO_NATIVE_FIELD edges from ReportIRHighlight nodes."""
        return [
            (src, tgt, edge)
            for src, tgt, edge in result.extra_edges
            if isinstance(src, ReportIRHighlight) and isinstance(edge, MapsToNativeField)
        ]

    def test_highlight_formula_stitching(self):
        """FORMULA_* prefix → HighlightsFormula edge to ReportIRFormula."""
        data = self._make_report_data(
            highlights_metadata={
                "colorRanges": [{
                    "columnName": "FORMULA_Sum_Amount",
                    "lowColor": "#FF0000",
                    "highColor": "#00FF00",
                    "lowBreakpoint": 0,
                    "highBreakpoint": 100000,
                }],
            },
            extra_metadata={
                "aggregates": [{
                    "masterLabel": "Sum of Amount",
                    "developerName": "FORMULA_Sum_Amount",
                    "calculatedFormula": "AMOUNT:SUM",
                    "datatype": "Currency",
                }],
            },
        )
        result = SalesforceIRTransformer().transform(data)
        hf_edges = self._highlights_formula_edges(result)

        assert len(hf_edges) == 1
        src, tgt, edge = hf_edges[0]
        assert isinstance(src, ReportIRHighlight)
        assert src.field_alias == "FORMULA_Sum_Amount"
        # Target should be the formula node ID
        ir_id = result.ir.id
        assert tgt.id == f"{ir_id}.formula.FORMULA_Sum_Amount"

    def test_highlight_regular_field_stitching(self):
        """Regular field name → MapsToNativeField edge to SfReportColumn."""
        data = self._make_report_data(
            highlights_metadata={
                "colorRanges": [{
                    "columnName": "AMOUNT",
                    "lowColor": "#FF0000",
                    "highColor": "#00FF00",
                    "lowBreakpoint": 0,
                    "highBreakpoint": 50000,
                }],
            },
        )
        result = SalesforceIRTransformer().transform(data)
        hn_edges = self._highlight_native_edges(result)

        assert len(hn_edges) == 1
        src, tgt, edge = hn_edges[0]
        assert isinstance(src, ReportIRHighlight)
        assert tgt.id == f"sf_report_col::{self.ORG_KEY}::{self.REPORT_ID}::AMOUNT"
        assert edge.mapping_type == "auxiliary"

    def test_highlight_no_field_alias(self):
        """field_alias=None → no edge, no error."""
        data = self._make_report_data(
            highlights_metadata={
                "colorRanges": [{
                    # Missing columnName
                    "lowColor": "#FF0000",
                    "highColor": "#00FF00",
                }],
            },
        )
        result = SalesforceIRTransformer().transform(data)
        hf_edges = self._highlights_formula_edges(result)
        hn_edges = self._highlight_native_edges(result)

        assert len(hf_edges) == 0
        assert len(hn_edges) == 0


# ---------------------------------------------------------------------------
# CrossFilter stitching tests
# ---------------------------------------------------------------------------

class TestCrossFilterStitching:
    """Tests for ReportIRCrossFilter cross-stitching."""

    ORG_KEY = "test_org"
    REPORT_ID = "00O000000000005"

    def _make_report_data(self, cross_filter_metadata: dict) -> dict:
        """Build minimal report_data with cross-filter metadata."""
        return {
            "report_id": self.REPORT_ID,
            "name": "CrossFilter Test Report",
            "org_key": self.ORG_KEY,
            "report_format": "TABULAR",
            "report_type": "Account",
            "columns": [
                {"column_key": "ACCOUNT_NAME", "name": "Account Name", "data_type": "string"},
            ],
            "metadata_api_json": cross_filter_metadata,
        }

    def _crossfilter_native_edges(self, result):
        """Extract MAPS_TO_NATIVE_FIELD edges from ReportIRCrossFilter nodes."""
        return [
            (src, tgt, edge)
            for src, tgt, edge in result.extra_edges
            if isinstance(src, ReportIRCrossFilter) and isinstance(edge, MapsToNativeField)
        ]

    def test_crossfilter_stitching_related_field(self):
        """related_field → MapsToNativeField edge."""
        data = self._make_report_data({
            "crossFilters": [{
                "operation": "without",
                "relatedEntity": "Opportunity",
                "relatedEntityJoinField": "AccountId",
            }],
        })
        result = SalesforceIRTransformer().transform(data)
        cf_edges = self._crossfilter_native_edges(result)

        assert len(cf_edges) == 1
        src, tgt, edge = cf_edges[0]
        assert isinstance(src, ReportIRCrossFilter)
        assert tgt.id == f"sf_report_col::{self.ORG_KEY}::{self.REPORT_ID}::AccountId"
        assert edge.mapping_type == "auxiliary"

    def test_crossfilter_stitching_criteria_columns(self):
        """filter_conditions JSON → edges for each criterion column."""
        data = self._make_report_data({
            "crossFilters": [{
                "operation": "without",
                "relatedEntity": "Contact",
                "relatedEntityJoinField": "AccountId",
                "criteriaItems": [
                    {"column": "Email", "operator": "notEqual", "value": ""},
                    {"column": "Phone", "operator": "notEqual", "value": ""},
                ],
            }],
        })
        result = SalesforceIRTransformer().transform(data)
        cf_edges = self._crossfilter_native_edges(result)

        # 1 for related_field (AccountId) + 2 for criteria columns (Email, Phone)
        assert len(cf_edges) == 3
        target_ids = sorted(tgt.id for _, tgt, _ in cf_edges)
        expected = sorted([
            f"sf_report_col::{self.ORG_KEY}::{self.REPORT_ID}::AccountId",
            f"sf_report_col::{self.ORG_KEY}::{self.REPORT_ID}::Email",
            f"sf_report_col::{self.ORG_KEY}::{self.REPORT_ID}::Phone",
        ])
        assert target_ids == expected

    def test_crossfilter_no_fields(self):
        """No field refs → no edges, no error."""
        data = self._make_report_data({
            "crossFilters": [{
                "operation": "with",
                "relatedEntity": "Opportunity",
                # No relatedEntityJoinField, no criteriaItems
            }],
        })
        result = SalesforceIRTransformer().transform(data)
        cf_edges = self._crossfilter_native_edges(result)
        assert len(cf_edges) == 0
