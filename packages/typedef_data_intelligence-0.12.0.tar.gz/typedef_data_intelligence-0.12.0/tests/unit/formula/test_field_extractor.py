"""Tests for the field reference extractor visitor."""

import pytest
from lineage.formula import extract_field_refs, parse

# ---------------------------------------------------------------------------
# Production formulas + Salesforce test suite
# ---------------------------------------------------------------------------

PRODUCTION_CASES = [
    ("TOTAL_PRICE / QUANTITY", ["TOTAL_PRICE", "QUANTITY"]),
    ("CLOSE_DATE - DATEVALUE(CREATED_DATE)", ["CLOSE_DATE", "CREATED_DATE"]),
    ("AMOUNT / (TODAY() - DATEVALUE(CREATED_DATE))", ["AMOUNT", "CREATED_DATE"]),
    ("AMOUNT:SUM / RowCount", ["AMOUNT"]),  # RowCount is builtin
    ("AMOUNT:SUM * PROBABILITY:AVG", ["AMOUNT", "PROBABILITY"]),
    ("AMOUNT:SUM / AMOUNT:SUM", ["AMOUNT", "AMOUNT"]),
]

SF_CASES = [
    ("100 + 200", []),  # no fields, just literals
    ("customnumber1__c + customnumber2__c", ["customnumber1__c", "customnumber2__c"]),
    ("ABS(customnumber1__c)", ["customnumber1__c"]),
    ("IF(true, 1, 0)", []),  # no fields
    (
        "IF(isnull(customnumber1__c), 0, customcurrency1__c)",
        ["customnumber1__c", "customcurrency1__c"],
    ),
    ("WON:Sum / ( CLOSED:Sum - WON:Sum) * 100", ["WON", "CLOSED", "WON"]),
    ("/* comment */ IF(YEAR(TODAY()) = 2009, 0, 0)", []),
]


@pytest.mark.parametrize("formula,expected_fields", PRODUCTION_CASES + SF_CASES)
def test_extract_fields(formula: str, expected_fields: list[str]) -> None:
    tree = parse(formula)
    refs = extract_field_refs(tree)
    assert [r.field_name for r in refs] == expected_fields


def test_aggregate_info_preserved() -> None:
    refs = extract_field_refs(parse("AMOUNT:SUM * PROBABILITY:AVG"))
    assert refs[0].field_name == "AMOUNT"
    assert refs[0].aggregation == "SUM"
    assert refs[1].field_name == "PROBABILITY"
    assert refs[1].aggregation == "AVG"


def test_object_path_preserved() -> None:
    refs = extract_field_refs(parse("Account.Name"))
    assert len(refs) == 1
    assert refs[0].field_name == "Name"
    assert refs[0].object_path == ["Account"]


def test_deeply_nested() -> None:
    refs = extract_field_refs(
        parse("IF(AND(a > 0, b < 10), ROUND(c, 2), d)")
    )
    assert [r.field_name for r in refs] == ["a", "b", "c", "d"]


def test_unary_field() -> None:
    refs = extract_field_refs(parse("-(x)"))
    assert [r.field_name for r in refs] == ["x"]


def test_no_fields() -> None:
    refs = extract_field_refs(parse("1 + 2 * 3"))
    assert refs == []
