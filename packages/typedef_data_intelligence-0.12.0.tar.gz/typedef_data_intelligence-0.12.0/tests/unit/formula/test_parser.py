"""Tests for the Salesforce formula parser.

Test cases sourced from the official Salesforce formula-engine project
(/tmp/formula-engine) and real production report formulas.
"""

import pytest
from lineage.formula import (
    BinaryOp,
    FieldRef,
    FormulaNode,
    FunctionCall,
    Literal,
    UnaryOp,
    parse,
)
from lineage.formula.parser import FormulaParseError

# ---------------------------------------------------------------------------
# Parametrized: every formula must parse without error
# ---------------------------------------------------------------------------

PARSE_CASES = [
    # Arithmetic
    "100 + 200",
    "(customnumber1__c + customnumber2__c)",
    "customnumber1__c / customnumber2__c + 1",
    "customnumber1__c / (customnumber2__c + 1)",
    "customNumber1__c ^ customNumber2__c",
    # Functions (math)
    "ABS(customnumber1__c)",
    "ROUND(customnumber1__c, customnumber2__c)",
    "FLOOR(customnumber1__c)",
    "CEILING(customnumber1__c)",
    "EXP(customnumber1__c)",
    "LOG(customnumber1__c)",
    "LN(customnumber1__c)",
    "SQRT(customnumber1__c)",
    "MOD(customnumber1__c, customnumber2__c)",
    "SIN(customnumber1__c)",
    "ROUND(PI(), 12)",
    # Functions (string)
    "LEFT(customtext__c, customnumber__c)",
    "RIGHT(customtext__c, customnumber__c)",
    "LEN(customtext1__c)",
    "TRIM(customtext1__c)",
    "SUBSTITUTE(customtext1__c, customtext2__c, customtext3__c)",
    "UPPER(customText1__c)",
    "LOWER(customText1__c)",
    "MID(customtext__c, customnumber1__c, customnumber2__c)",
    "LPAD(customText1__c, customNumber1__c, customText2__c)",
    'FIND("Text", customText1__c)',
    # Functions (date/time)
    "DATE(customnumber1__c, customnumber2__c, customnumber3__c)",
    'DATETIMEVALUE("2005-11-15 17:00:00")',
    'TIMEVALUE("10:40:55.666")',
    'Hour(TIMEVALUE("10:40:55.666"))',
    "DAY(customdate1__c)",
    "MONTH(customdate3__c)",
    "YEAR(customdate2__c)",
    "WEEKDAY(customdate1__c)",
    "ADDMONTHS(customdate1__c, customnumber1__c)",
    "ISOWEEK(customdate1__c)",
    "UnixTimestamp(DATETIMEVALUE(dateString__c))",
    "FromUnixTime(customnumber1__c)",
    # Conditionals
    "IF(true, 1, 0)",
    "IF((customnumber1__c > customcurrency1__c), customcurrency2__c, customnumber2__c)",
    'IF((customtext1__c = customtext2__c), "true", "false")',
    "IF(true, if(false, null, null), TODAY())",
    "CASE(customtext1__c, customtext2__c, custompercent1__c, customtext3__c, customcurrency1__c, customnumber1__c)",
    # Boolean logic
    "AND(customformula1__c, OR(customcheckbox1__c, customcheckbox2__c))",
    "IF(AND(customcheckbox1__c, customcheckbox2__c), customformula1__c, DATE(customnumber1__c, customnumber2__c, customnumber3__c))",
    'if(not(null), "True", "False")',
    # Null handling
    "if(isnull(customnumber1__c), 0, customcurrency1__c)",
    'if(isblank(customtext1__c), "NULL", customtextarea1__c)',
    "NULLVALUE(customnumber1__c, customcurrency1__c)",
    "BLANKVALUE(customnumber1__c, customcurrency1__c)",
    # Complex nested
    "(((customnumber1__c * customnumber2__c) / (value(text(customnumber2__c)) ^ customnumber2__c)) * (customnumber3__c ^ customnumber3__c))",
    "ABS(CASE(customdate1__c, customdate2__c, customnumber1__c, customdate3__c, customnumber2__c, customnumber3__c))",
    "(floor((customdatetime1__c - customdatetime2__c) * 1440 * 60))",
    # Error handling
    "IFERROR(SQRT(customnumber1__c), -1)",
    "IFERROR(((customnumber1__c / customnumber2__c) * customnumber3__c), 0)",
    # Summary formula syntax (FIELD:AGG)
    "WON:Sum / ( CLOSED:Sum - WON:Sum) * 100",
    "AMOUNT:SUM * PROBABILITY:AVG",
    "AMOUNT:SUM / RowCount",
    # Comments
    "/* comment */ IF /* comment */(YEAR(TODAY()) = 2009 /* comment */, 0,0) /** comment **/",
    # Case-insensitivity
    "abs(1)",
    "ABS(1)",
    "Abs(1)",
    # String literals with escapes
    '"Hello \\"cruel\\" world"',
    # Unary operators
    "-(customnumber1__c)",
    # Comparison operators
    "customdate1__c > customdate2__c",
    # String concatenation
    "(customtext1__c + customtext2__c)",
    # System variables
    "$System.originDateTime",
    # Production report formulas
    "TOTAL_PRICE / QUANTITY",
    "CLOSE_DATE - DATEVALUE(CREATED_DATE)",
    "AMOUNT / (TODAY() - DATEVALUE(CREATED_DATE))",
    "AMOUNT:SUM / RowCount",
    "AMOUNT:SUM * PROBABILITY:AVG",
    "AMOUNT:SUM / AMOUNT:SUM",
    # Logical operators
    "x || y",
    "x && y",
    # Multiple equality
    "a = b",
    "a == b",
    "a <> b",
    "a != b",
]


@pytest.mark.parametrize("formula", PARSE_CASES)
def test_parse_succeeds(formula: str) -> None:
    """Every formula from the Salesforce test suite must parse without error."""
    result = parse(formula)
    assert isinstance(result, FormulaNode)


# ---------------------------------------------------------------------------
# AST structure verification
# ---------------------------------------------------------------------------


def test_ast_binary_op() -> None:
    result = parse("a / b")
    assert isinstance(result, BinaryOp)
    assert result.operator == "/"
    assert isinstance(result.left, FieldRef)
    assert result.left.field_name == "a"
    assert isinstance(result.right, FieldRef)
    assert result.right.field_name == "b"


def test_ast_function_call() -> None:
    result = parse("DATEVALUE(x)")
    assert isinstance(result, FunctionCall)
    assert result.name == "DATEVALUE"
    assert len(result.arguments) == 1
    assert isinstance(result.arguments[0], FieldRef)
    assert result.arguments[0].field_name == "x"


def test_ast_function_no_args() -> None:
    result = parse("TODAY()")
    assert isinstance(result, FunctionCall)
    assert result.name == "TODAY"
    assert result.arguments == []


def test_ast_aggregate_ref() -> None:
    result = parse("AMOUNT:SUM")
    assert isinstance(result, FieldRef)
    assert result.field_name == "AMOUNT"
    assert result.aggregation == "SUM"
    assert result.raw == "AMOUNT:SUM"


def test_ast_object_path() -> None:
    result = parse("Account.Name")
    assert isinstance(result, FieldRef)
    assert result.field_name == "Name"
    assert result.object_path == ["Account"]
    assert result.raw == "Account.Name"


def test_ast_nested_if() -> None:
    result = parse("IF(x > 1, y, 0)")
    assert isinstance(result, FunctionCall)
    assert result.name == "IF"
    assert len(result.arguments) == 3
    assert isinstance(result.arguments[0], BinaryOp)
    assert result.arguments[0].operator == ">"
    assert isinstance(result.arguments[1], FieldRef)
    assert isinstance(result.arguments[2], Literal)


def test_ast_operator_precedence() -> None:
    # a + b * c  ->  BinaryOp("+", a, BinaryOp("*", b, c))
    result = parse("a + b * c")
    assert isinstance(result, BinaryOp)
    assert result.operator == "+"
    assert isinstance(result.left, FieldRef)
    assert result.left.field_name == "a"
    assert isinstance(result.right, BinaryOp)
    assert result.right.operator == "*"


def test_ast_left_associativity() -> None:
    # a + b + c  ->  BinaryOp("+", BinaryOp("+", a, b), c)
    result = parse("a + b + c")
    assert isinstance(result, BinaryOp)
    assert result.operator == "+"
    assert isinstance(result.left, BinaryOp)
    assert result.left.operator == "+"
    assert isinstance(result.right, FieldRef)
    assert result.right.field_name == "c"


def test_ast_unary_minus() -> None:
    result = parse("-(x)")
    assert isinstance(result, UnaryOp)
    assert result.operator == "-"


def test_ast_literal_number() -> None:
    result = parse("42")
    assert isinstance(result, Literal)
    assert result.value == 42
    assert result.literal_type == "number"


def test_ast_literal_float() -> None:
    result = parse("3.14")
    assert isinstance(result, Literal)
    assert result.value == 3.14
    assert result.literal_type == "number"


def test_ast_literal_string() -> None:
    result = parse('"hello"')
    assert isinstance(result, Literal)
    assert result.value == "hello"
    assert result.literal_type == "string"


def test_ast_literal_boolean_true() -> None:
    result = parse("true")
    assert isinstance(result, Literal)
    assert result.value is True
    assert result.literal_type == "boolean"


def test_ast_literal_null() -> None:
    result = parse("null")
    assert isinstance(result, Literal)
    assert result.value is None
    assert result.literal_type == "null"


def test_ast_system_variable() -> None:
    result = parse("$System.originDateTime")
    assert isinstance(result, FieldRef)
    assert result.field_name == "originDateTime"
    assert result.object_path == ["$System"]


def test_parse_error_invalid() -> None:
    with pytest.raises(FormulaParseError):
        parse("+ + +")
