"""CLI tests for sf-login and load-salesforce auth mode auto-detection."""
from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner
from lineage.cli import _build_sf_client, main
from lineage.ingest.static_loaders.salesforce.auth.password import PasswordAuth

# ---------------------------------------------------------------------------
# _build_sf_client auto-detection
# ---------------------------------------------------------------------------

class TestBuildSfClient:
    def test_auto_detect_password(self) -> None:
        client = _build_sf_client(
            auth_mode=None,
            instance_url="https://test.sf.com",
            username="user",
            password="pass",
            security_token="tok",
            client_id=None,
            client_secret=None,
            private_key_path=None,
            login_url="https://login.salesforce.com",
            sf_org_key="default",
        )
        assert isinstance(client.auth, PasswordAuth)

    def test_auto_detect_client_credentials(self) -> None:
        client = _build_sf_client(
            auth_mode=None,
            instance_url=None,
            username=None,
            password=None,
            security_token=None,
            client_id="cid",
            client_secret="csecret",
            private_key_path=None,
            login_url="https://login.salesforce.com",
            sf_org_key="default",
        )
        from lineage.ingest.static_loaders.salesforce.auth.client_creds import (
            ClientCredentialsAuth,
        )
        assert isinstance(client.auth, ClientCredentialsAuth)

    def test_auto_detect_jwt(self, tmp_path: Path) -> None:
        key_path = tmp_path / "key.pem"
        key_path.write_text("fake")

        client = _build_sf_client(
            auth_mode=None,
            instance_url=None,
            username="user@test.com",
            password=None,
            security_token=None,
            client_id="cid",
            client_secret=None,
            private_key_path=str(key_path),
            login_url="https://login.salesforce.com",
            sf_org_key="default",
        )
        from lineage.ingest.static_loaders.salesforce.auth.jwt_bearer import (
            JWTBearerAuth,
        )
        assert isinstance(client.auth, JWTBearerAuth)

    def test_auto_detect_oauth(self) -> None:
        client = _build_sf_client(
            auth_mode=None,
            instance_url=None,
            username=None,
            password=None,
            security_token=None,
            client_id="cid",
            client_secret=None,
            private_key_path=None,
            login_url="https://login.salesforce.com",
            sf_org_key="default",
        )
        from lineage.ingest.static_loaders.salesforce.auth.oauth_pkce import (
            OAuthPKCEAuth,
        )
        assert isinstance(client.auth, OAuthPKCEAuth)

    def test_explicit_device_mode(self) -> None:
        client = _build_sf_client(
            auth_mode="device",
            instance_url=None,
            username=None,
            password=None,
            security_token=None,
            client_id="cid",
            client_secret=None,
            private_key_path=None,
            login_url="https://login.salesforce.com",
            sf_org_key="default",
        )
        from lineage.ingest.static_loaders.salesforce.auth.device_flow import (
            OAuthDeviceFlowAuth,
        )
        assert isinstance(client.auth, OAuthDeviceFlowAuth)

    def test_auto_detect_no_creds_raises(self) -> None:
        from click import ClickException
        with pytest.raises(ClickException, match="Cannot determine auth mode"):
            _build_sf_client(
                auth_mode=None,
                instance_url=None,
                username=None,
                password=None,
                security_token=None,
                client_id=None,
                client_secret=None,
                private_key_path=None,
                login_url="https://login.salesforce.com",
                sf_org_key="default",
            )

    def test_explicit_password_mode(self) -> None:
        client = _build_sf_client(
            auth_mode="password",
            instance_url="https://test.sf.com",
            username="user",
            password="pass",
            security_token="tok",
            client_id=None,
            client_secret=None,
            private_key_path=None,
            login_url="https://login.salesforce.com",
            sf_org_key="default",
        )
        assert isinstance(client.auth, PasswordAuth)

    def test_explicit_password_missing_creds_raises(self) -> None:
        from click import ClickException
        with pytest.raises(ClickException, match="Password auth requires"):
            _build_sf_client(
                auth_mode="password",
                instance_url="https://test.sf.com",
                username="user",
                password=None,
                security_token=None,
                client_id=None,
                client_secret=None,
                private_key_path=None,
                login_url="https://login.salesforce.com",
                sf_org_key="default",
            )

    def test_explicit_oauth_missing_client_id_raises(self) -> None:
        from click import ClickException
        with pytest.raises(ClickException, match="OAuth auth requires --client-id"):
            _build_sf_client(
                auth_mode="oauth",
                instance_url=None,
                username=None,
                password=None,
                security_token=None,
                client_id=None,
                client_secret=None,
                private_key_path=None,
                login_url="https://login.salesforce.com",
                sf_org_key="default",
            )

    def test_unknown_mode_raises(self) -> None:
        from click import ClickException
        with pytest.raises(ClickException, match="Unknown auth mode"):
            _build_sf_client(
                auth_mode="kerberos",
                instance_url=None,
                username=None,
                password=None,
                security_token=None,
                client_id=None,
                client_secret=None,
                private_key_path=None,
                login_url="https://login.salesforce.com",
                sf_org_key="default",
            )


# ---------------------------------------------------------------------------
# sf-login CLI command
# ---------------------------------------------------------------------------

class TestSfLoginCLI:
    @patch("lineage.ingest.static_loaders.salesforce.auth.oauth_pkce.OAuthPKCEAuth.authenticate")
    def test_sf_login_success(self, mock_auth: MagicMock) -> None:
        from lineage.ingest.static_loaders.salesforce.auth.protocol import (
            SalesforceCredentials,
        )

        mock_auth.return_value = SalesforceCredentials(
            access_token="tok", instance_url="https://myorg.sf.com"
        )

        runner = CliRunner()
        result = runner.invoke(main, ["sf-login", "--client-id", "test-key"])

        assert result.exit_code == 0
        assert "Authenticated" in result.output
        assert "https://myorg.sf.com" in result.output

    @patch("lineage.ingest.static_loaders.salesforce.auth.device_flow.OAuthDeviceFlowAuth.authenticate")
    def test_sf_login_device_flow(self, mock_auth: MagicMock) -> None:
        from lineage.ingest.static_loaders.salesforce.auth.protocol import (
            SalesforceCredentials,
        )

        mock_auth.return_value = SalesforceCredentials(
            access_token="tok", instance_url="https://myorg.sf.com"
        )

        runner = CliRunner()
        result = runner.invoke(main, ["sf-login", "--client-id", "test-key", "--device"])

        assert result.exit_code == 0
        assert "Authenticated" in result.output
        assert "device" in result.output

    def test_sf_login_missing_client_id(self) -> None:
        runner = CliRunner()
        result = runner.invoke(main, ["sf-login"])

        assert result.exit_code != 0
        assert "client-id" in result.output.lower() or "Missing" in result.output
