"""Unit tests for Salesforce node models and edge validation."""
from __future__ import annotations

import pytest
from lineage.backends.lineage.models.dbt import DbtColumn, DbtSource
from lineage.backends.lineage.models.edges import (
    MapsToColumn,
    SfComponentUsesReport,
    SfDashboardHasComponent,
    SfHasDashboard,
    SfHasField,
    SfHasObject,
    SfHasReport,
    SfReferences,
    SfReportColumnUsesField,
    SfReportDependsOnObject,
    SfReportHasColumn,
    SourceDependsOn,
)
from lineage.backends.lineage.models.salesforce import (
    SalesforceOrg,
    SfDashboard,
    SfDashboardComponent,
    SfField,
    SfObject,
    SfReport,
    SfReportColumn,
    _stable_hash,
)
from lineage.backends.types import NodeLabel

# ---------------------------------------------------------------------------
# Node ID generation
# ---------------------------------------------------------------------------

class TestSalesforceOrgId:
    def test_id_format(self) -> None:
        org = SalesforceOrg(name="MyOrg", org_key="myalias", instance_url="https://x.sf.com")
        assert org.id == "sf_org::myalias"

    def test_node_label(self) -> None:
        org = SalesforceOrg(name="MyOrg", org_key="myalias", instance_url="https://x.sf.com")
        assert org.node_label == NodeLabel.SF_ORG


class TestSfObjectId:
    def test_id_format(self) -> None:
        obj = SfObject(name="Account", api_name="Account", org_key="myalias")
        assert obj.id == "sf_object::myalias::Account"

    def test_custom_object(self) -> None:
        obj = SfObject(name="MyObj__c", api_name="MyObj__c", org_key="myalias", is_custom=True)
        assert obj.id == "sf_object::myalias::MyObj__c"
        assert obj.is_custom is True

    def test_node_label(self) -> None:
        obj = SfObject(name="Account", api_name="Account", org_key="myalias")
        assert obj.node_label == NodeLabel.SF_OBJECT


class TestSfFieldId:
    def test_id_format(self) -> None:
        f = SfField(name="OwnerId", field_api_name="OwnerId", object_api_name="Account", org_key="myalias")
        assert f.id == "sf_field::myalias::Account::OwnerId"

    def test_custom_field(self) -> None:
        f = SfField(
            name="Custom_Field__c",
            field_api_name="Custom_Field__c",
            object_api_name="Account",
            org_key="myalias",
            is_custom=True,
        )
        assert f.id == "sf_field::myalias::Account::Custom_Field__c"

    def test_node_label(self) -> None:
        f = SfField(name="OwnerId", field_api_name="OwnerId", object_api_name="Account", org_key="myalias")
        assert f.node_label == NodeLabel.SF_FIELD


class TestSfReportId:
    def test_id_format(self) -> None:
        r = SfReport(name="Pipeline Report", report_id="00O000000000001AAA", org_key="myalias")
        assert r.id == "sf_report::myalias::00O000000000001AAA"

    def test_node_label(self) -> None:
        r = SfReport(name="Pipeline Report", report_id="00O000000000001AAA", org_key="myalias")
        assert r.node_label == NodeLabel.SF_REPORT


class TestSfReportColumnId:
    def test_id_format(self) -> None:
        c = SfReportColumn(name="Amount", column_key="AMOUNT", report_id="00O000000000001AAA", org_key="myalias")
        assert c.id == "sf_report_col::myalias::00O000000000001AAA::AMOUNT"

    def test_node_label(self) -> None:
        c = SfReportColumn(name="Amount", column_key="AMOUNT", report_id="00O000000000001AAA", org_key="myalias")
        assert c.node_label == NodeLabel.SF_REPORT_COLUMN


class TestSfDashboardId:
    def test_id_format(self) -> None:
        d = SfDashboard(name="Sales Dashboard", dashboard_id="01Z000000000001AAA", org_key="myalias")
        assert d.id == "sf_dashboard::myalias::01Z000000000001AAA"

    def test_node_label(self) -> None:
        d = SfDashboard(name="Sales Dashboard", dashboard_id="01Z000000000001AAA", org_key="myalias")
        assert d.node_label == NodeLabel.SF_DASHBOARD


class TestSfDashboardComponentId:
    def test_id_format(self) -> None:
        c = SfDashboardComponent(
            name="ARR Chart",
            component_key="comp1",
            dashboard_id="01Z000000000001AAA",
            org_key="myalias",
        )
        assert c.id == "sf_dash_comp::myalias::01Z000000000001AAA::comp1"

    def test_hash_based_key(self) -> None:
        key = _stable_hash(("ARR Chart", "chart", "0"))
        assert len(key) == 12
        # Deterministic
        assert key == _stable_hash(("ARR Chart", "chart", "0"))

    def test_node_label(self) -> None:
        c = SfDashboardComponent(
            name="ARR Chart",
            component_key="comp1",
            dashboard_id="01Z000000000001AAA",
            org_key="myalias",
        )
        assert c.node_label == NodeLabel.SF_DASHBOARD_COMPONENT


# ---------------------------------------------------------------------------
# node_label on all 7 types
# ---------------------------------------------------------------------------

class TestAllNodeLabels:
    """Verify node_label ClassVar on every Salesforce node type."""

    def test_salesforce_org_label(self) -> None:
        assert SalesforceOrg.node_label == NodeLabel.SF_ORG

    def test_sf_object_label(self) -> None:
        assert SfObject.node_label == NodeLabel.SF_OBJECT

    def test_sf_field_label(self) -> None:
        assert SfField.node_label == NodeLabel.SF_FIELD

    def test_sf_report_label(self) -> None:
        assert SfReport.node_label == NodeLabel.SF_REPORT

    def test_sf_report_column_label(self) -> None:
        assert SfReportColumn.node_label == NodeLabel.SF_REPORT_COLUMN

    def test_sf_dashboard_label(self) -> None:
        assert SfDashboard.node_label == NodeLabel.SF_DASHBOARD

    def test_sf_dashboard_component_label(self) -> None:
        assert SfDashboardComponent.node_label == NodeLabel.SF_DASHBOARD_COMPONENT


# ---------------------------------------------------------------------------
# get_node_identifier
# ---------------------------------------------------------------------------

class TestGetNodeIdentifier:
    def test_sf_object_identifier(self) -> None:
        obj = SfObject(name="Account", api_name="Account", org_key="myalias")
        ident = obj.get_node_identifier()
        assert ident.id == "sf_object::myalias::Account"
        assert ident.node_label == NodeLabel.SF_OBJECT

    def test_sf_field_identifier(self) -> None:
        f = SfField(name="Name", field_api_name="Name", object_api_name="Account", org_key="myalias")
        ident = f.get_node_identifier()
        assert ident.id == "sf_field::myalias::Account::Name"
        assert ident.node_label == NodeLabel.SF_FIELD


# ---------------------------------------------------------------------------
# _stable_hash edge cases
# ---------------------------------------------------------------------------

class TestStableHash:
    def test_different_inputs_differ(self) -> None:
        h1 = _stable_hash(("a", "b", "c"))
        h2 = _stable_hash(("x", "y", "z"))
        assert h1 != h2

    def test_empty_strings(self) -> None:
        h = _stable_hash(("", "", ""))
        assert len(h) == 12

    def test_custom_length(self) -> None:
        h = _stable_hash(("test",), length=6)
        assert len(h) == 6


# ---------------------------------------------------------------------------
# search_tokenized_name
# ---------------------------------------------------------------------------

class TestSearchTokenizedName:
    def test_underscore_replaced(self) -> None:
        obj = SfObject(name="my_custom_obj", api_name="my_custom_obj", org_key="k")
        assert obj.search_tokenized_name == "my custom obj"

    def test_no_underscores(self) -> None:
        obj = SfObject(name="Account", api_name="Account", org_key="k")
        assert obj.search_tokenized_name == "Account"


# ---------------------------------------------------------------------------
# Edge pair validation
# ---------------------------------------------------------------------------

class TestSfEdgePairs:
    """Verify that each SF edge class accepts the correct node pairs."""

    def _org(self) -> SalesforceOrg:
        return SalesforceOrg(name="Org", org_key="k", instance_url="https://x.sf.com")

    def _obj(self) -> SfObject:
        return SfObject(name="Account", api_name="Account", org_key="k")

    def _field(self) -> SfField:
        return SfField(name="Name", field_api_name="Name", object_api_name="Account", org_key="k")

    def _report(self) -> SfReport:
        return SfReport(name="R", report_id="00O1", org_key="k")

    def _col(self) -> SfReportColumn:
        return SfReportColumn(name="C", column_key="C", report_id="00O1", org_key="k")

    def _dash(self) -> SfDashboard:
        return SfDashboard(name="D", dashboard_id="01Z1", org_key="k")

    def _comp(self) -> SfDashboardComponent:
        return SfDashboardComponent(name="C", component_key="c1", dashboard_id="01Z1", org_key="k")

    def test_sf_has_object(self) -> None:
        SfHasObject().validate_nodes(self._org(), self._obj())

    def test_sf_has_field(self) -> None:
        SfHasField().validate_nodes(self._obj(), self._field())

    def test_sf_references(self) -> None:
        SfReferences(relationship_type="Lookup").validate_nodes(self._field(), self._obj())

    def test_sf_has_report(self) -> None:
        SfHasReport().validate_nodes(self._org(), self._report())

    def test_sf_report_has_column(self) -> None:
        SfReportHasColumn().validate_nodes(self._report(), self._col())

    def test_sf_report_column_uses_field(self) -> None:
        SfReportColumnUsesField(resolution="exact", confidence=1.0).validate_nodes(
            self._col(), self._field()
        )

    def test_sf_report_depends_on_object(self) -> None:
        SfReportDependsOnObject(role="primary").validate_nodes(self._report(), self._obj())

    def test_sf_has_dashboard(self) -> None:
        SfHasDashboard().validate_nodes(self._org(), self._dash())

    def test_sf_dashboard_has_component(self) -> None:
        SfDashboardHasComponent().validate_nodes(self._dash(), self._comp())

    def test_sf_component_uses_report(self) -> None:
        SfComponentUsesReport().validate_nodes(self._comp(), self._report())

    def test_source_depends_on(self) -> None:
        src = DbtSource(name="account", unique_id="source.pkg.account", loader="salesforce")
        obj = self._obj()
        SourceDependsOn(source="heuristic", confidence=1.0).validate_nodes(src, obj)

    def test_maps_to_column_from_field(self) -> None:
        field = self._field()
        col = DbtColumn(name="name", parent_id="source.pkg.account", parent_label="DbtSource")
        MapsToColumn(source="heuristic", confidence=1.0).validate_nodes(field, col)

    def test_maps_to_column_from_report_column(self) -> None:
        rc = self._col()
        col = DbtColumn(name="name", parent_id="source.pkg.account", parent_label="DbtSource")
        MapsToColumn(source="llm", confidence=0.8).validate_nodes(rc, col)

    def test_invalid_pair_raises(self) -> None:
        """Non-matching pair should raise TypeError."""
        with pytest.raises(TypeError):
            SfHasObject().validate_nodes(self._obj(), self._org())  # reversed
