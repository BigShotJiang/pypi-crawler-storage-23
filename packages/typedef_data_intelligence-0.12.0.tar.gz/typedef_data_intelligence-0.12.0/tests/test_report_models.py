"""Unit tests for generic Report node models and edge validation."""
from __future__ import annotations

import pytest
from lineage.backends.lineage.models.dbt import DbtColumn, DbtModel
from lineage.backends.lineage.models.edges import (
    DerivesFrom,
    HasIR,
    HasIRBucket,
    HasIRCrossFilter,
    HasIRField,
    HasIRFilter,
    HasIRFormula,
    HasIRGroupBy,
    HasIRHighlight,
    HasIRJoin,
    HasNativeDefinition,
    HasRevision,
    MapsToNativeField,
    NativeInstanceOf,
    ReportDependsOn,
    RevisionHasIR,
)
from lineage.backends.lineage.models.physical import PhysicalTable
from lineage.backends.lineage.models.report import (
    NativeReportDefinition,
    Report,
    ReportIR,
    ReportIRBucket,
    ReportIRCrossFilter,
    ReportIRField,
    ReportIRFilter,
    ReportIRFormula,
    ReportIRGroupBy,
    ReportIRHighlight,
    ReportIRJoin,
    ReportRevision,
)
from lineage.backends.lineage.models.salesforce import (
    SfObject,
    SfReport,
    SfReportColumn,
)
from lineage.backends.types import NodeLabel

# ===========================================================================
# Phase 1: Core Schema - Node ID generation
# ===========================================================================


class TestReportId:
    def test_id_format(self) -> None:
        r = Report(name="Pipeline Report", system="salesforce", native_id="00O123")
        assert r.id == "report::salesforce::00O123"

    def test_node_label(self) -> None:
        r = Report(name="Pipeline Report", system="salesforce", native_id="00O123")
        assert r.node_label == NodeLabel.REPORT

    def test_different_systems(self) -> None:
        sf = Report(name="SF Report", system="salesforce", native_id="00O123")
        looker = Report(name="Looker Report", system="looker", native_id="look_123")
        powerbi = Report(name="PowerBI Report", system="powerbi", native_id="pb_123")

        assert sf.id == "report::salesforce::00O123"
        assert looker.id == "report::looker::look_123"
        assert powerbi.id == "report::powerbi::pb_123"


class TestReportIRId:
    def test_id_format(self) -> None:
        ir = ReportIR(name="Pipeline IR", report_id="report::salesforce::00O123")
        assert ir.id == "report::salesforce::00O123.ir"

    def test_node_label(self) -> None:
        ir = ReportIR(name="Pipeline IR", report_id="report::salesforce::00O123")
        assert ir.node_label == NodeLabel.REPORT_IR


class TestReportIRFieldId:
    def test_id_format(self) -> None:
        f = ReportIRField(
            name="Amount",
            ir_id="report::salesforce::00O123.ir",
            alias="amount",
        )
        assert f.id == "report::salesforce::00O123.ir.field.amount"

    def test_node_label(self) -> None:
        f = ReportIRField(
            name="Amount",
            ir_id="report::salesforce::00O123.ir",
            alias="amount",
        )
        assert f.node_label == NodeLabel.REPORT_IR_FIELD


class TestNativeReportDefinitionId:
    def test_id_format(self) -> None:
        d = NativeReportDefinition(
            name="SF Definition",
            report_id="report::salesforce::00O123",
            system="salesforce",
        )
        assert d.id == "report::salesforce::00O123.def.salesforce"

    def test_node_label(self) -> None:
        d = NativeReportDefinition(
            name="SF Definition",
            report_id="report::salesforce::00O123",
            system="salesforce",
        )
        assert d.node_label == NodeLabel.NATIVE_REPORT_DEFINITION


class TestReportRevisionId:
    def test_id_format(self) -> None:
        rev = ReportRevision(
            name="Revision 1",
            report_id="report::salesforce::00O123",
            revision_number=1,
        )
        assert rev.id == "report::salesforce::00O123@1"

    def test_node_label(self) -> None:
        rev = ReportRevision(
            name="Revision 1",
            report_id="report::salesforce::00O123",
            revision_number=1,
        )
        assert rev.node_label == NodeLabel.REPORT_REVISION

    def test_sequential_revisions(self) -> None:
        rev1 = ReportRevision(name="R1", report_id="report::sf::123", revision_number=1)
        rev2 = ReportRevision(name="R2", report_id="report::sf::123", revision_number=2)
        rev3 = ReportRevision(name="R3", report_id="report::sf::123", revision_number=3)

        assert rev1.id == "report::sf::123@1"
        assert rev2.id == "report::sf::123@2"
        assert rev3.id == "report::sf::123@3"


# ===========================================================================
# Phase 2: Full IR Structure - Node ID generation
# ===========================================================================


class TestReportIRFilterId:
    def test_id_format(self) -> None:
        f = ReportIRFilter(
            name="Amount Filter",
            ir_id="report::sf::123.ir",
            index=0,
            operator="greater_than",
        )
        assert f.id == "report::sf::123.ir.filter.0"

    def test_node_label(self) -> None:
        f = ReportIRFilter(name="Filter", ir_id="report::sf::123.ir", index=0)
        assert f.node_label == NodeLabel.REPORT_IR_FILTER


class TestReportIRJoinId:
    def test_id_format(self) -> None:
        j = ReportIRJoin(
            name="Account Join",
            ir_id="report::sf::123.ir",
            index=0,
            from_entity="Opportunity",
            to_entity="Account",
        )
        assert j.id == "report::sf::123.ir.join.0"

    def test_node_label(self) -> None:
        j = ReportIRJoin(name="Join", ir_id="report::sf::123.ir", index=0)
        assert j.node_label == NodeLabel.REPORT_IR_JOIN


class TestReportIRGroupById:
    def test_id_format(self) -> None:
        g = ReportIRGroupBy(
            name="Stage Grouping",
            ir_id="report::sf::123.ir",
            field_alias="stage",
        )
        assert g.id == "report::sf::123.ir.groupby.stage"

    def test_node_label(self) -> None:
        g = ReportIRGroupBy(name="Grouping", ir_id="report::sf::123.ir", field_alias="stage")
        assert g.node_label == NodeLabel.REPORT_IR_GROUPBY


class TestReportIRBucketId:
    def test_id_format(self) -> None:
        b = ReportIRBucket(
            name="Amount Ranges",
            ir_id="report::sf::123.ir",
            bucket_name="amount_range",
        )
        assert b.id == "report::sf::123.ir.bucket.amount_range"

    def test_node_label(self) -> None:
        b = ReportIRBucket(name="Bucket", ir_id="report::sf::123.ir", bucket_name="amount")
        assert b.node_label == NodeLabel.REPORT_IR_BUCKET


class TestReportIRFormulaId:
    def test_id_format(self) -> None:
        f = ReportIRFormula(
            name="Win Rate",
            ir_id="report::sf::123.ir",
            formula_name="win_rate",
            expression="WON/TOTAL",
        )
        assert f.id == "report::sf::123.ir.formula.win_rate"

    def test_node_label(self) -> None:
        f = ReportIRFormula(name="Formula", ir_id="report::sf::123.ir", formula_name="calc")
        assert f.node_label == NodeLabel.REPORT_IR_FORMULA


class TestReportIRHighlightId:
    def test_id_format(self) -> None:
        h = ReportIRHighlight(
            name="Amount Highlight",
            ir_id="report::sf::123.ir",
            index=0,
            field_alias="amount",
        )
        assert h.id == "report::sf::123.ir.highlight.0"

    def test_node_label(self) -> None:
        h = ReportIRHighlight(name="Highlight", ir_id="report::sf::123.ir", index=0)
        assert h.node_label == NodeLabel.REPORT_IR_HIGHLIGHT


class TestReportIRCrossFilterId:
    def test_id_format(self) -> None:
        cf = ReportIRCrossFilter(
            name="Without Opportunities",
            ir_id="report::sf::123.ir",
            index=0,
            mode="without",
            related_entity="Opportunity",
        )
        assert cf.id == "report::sf::123.ir.crossfilter.0"

    def test_node_label(self) -> None:
        cf = ReportIRCrossFilter(name="CrossFilter", ir_id="report::sf::123.ir", index=0)
        assert cf.node_label == NodeLabel.REPORT_IR_CROSS_FILTER


# ===========================================================================
# All node_label ClassVars
# ===========================================================================


class TestAllReportNodeLabels:
    """Verify node_label ClassVar on every Report node type."""

    # Phase 1
    def test_report_label(self) -> None:
        assert Report.node_label == NodeLabel.REPORT

    def test_report_ir_label(self) -> None:
        assert ReportIR.node_label == NodeLabel.REPORT_IR

    def test_report_ir_field_label(self) -> None:
        assert ReportIRField.node_label == NodeLabel.REPORT_IR_FIELD

    def test_native_report_definition_label(self) -> None:
        assert NativeReportDefinition.node_label == NodeLabel.NATIVE_REPORT_DEFINITION

    def test_report_revision_label(self) -> None:
        assert ReportRevision.node_label == NodeLabel.REPORT_REVISION

    # Phase 2
    def test_report_ir_filter_label(self) -> None:
        assert ReportIRFilter.node_label == NodeLabel.REPORT_IR_FILTER

    def test_report_ir_join_label(self) -> None:
        assert ReportIRJoin.node_label == NodeLabel.REPORT_IR_JOIN

    def test_report_ir_groupby_label(self) -> None:
        assert ReportIRGroupBy.node_label == NodeLabel.REPORT_IR_GROUPBY

    def test_report_ir_bucket_label(self) -> None:
        assert ReportIRBucket.node_label == NodeLabel.REPORT_IR_BUCKET

    def test_report_ir_formula_label(self) -> None:
        assert ReportIRFormula.node_label == NodeLabel.REPORT_IR_FORMULA

    def test_report_ir_highlight_label(self) -> None:
        assert ReportIRHighlight.node_label == NodeLabel.REPORT_IR_HIGHLIGHT

    def test_report_ir_cross_filter_label(self) -> None:
        assert ReportIRCrossFilter.node_label == NodeLabel.REPORT_IR_CROSS_FILTER


# ===========================================================================
# get_node_identifier
# ===========================================================================


class TestReportGetNodeIdentifier:
    def test_report_identifier(self) -> None:
        r = Report(name="Test", system="salesforce", native_id="00O123")
        ident = r.get_node_identifier()
        assert ident.id == "report::salesforce::00O123"
        assert ident.node_label == NodeLabel.REPORT

    def test_report_ir_field_identifier(self) -> None:
        f = ReportIRField(name="Amount", ir_id="report::sf::123.ir", alias="amount")
        ident = f.get_node_identifier()
        assert ident.id == "report::sf::123.ir.field.amount"
        assert ident.node_label == NodeLabel.REPORT_IR_FIELD


# ===========================================================================
# search_tokenized_name
# ===========================================================================


class TestReportSearchTokenizedName:
    def test_underscore_replaced(self) -> None:
        r = Report(name="pipeline_by_stage_report", system="salesforce", native_id="123")
        assert r.search_tokenized_name == "pipeline by stage report"

    def test_no_underscores(self) -> None:
        r = Report(name="Pipeline Report", system="salesforce", native_id="123")
        assert r.search_tokenized_name == "Pipeline Report"


# ===========================================================================
# Phase 1 Edge pair validation
# ===========================================================================


class TestPhase1ReportEdgePairs:
    """Verify that Phase 1 report edge classes accept correct node pairs."""

    def _report(self) -> Report:
        return Report(name="R", system="salesforce", native_id="00O123")

    def _ir(self) -> ReportIR:
        return ReportIR(name="IR", report_id="report::salesforce::00O123")

    def _ir_field(self) -> ReportIRField:
        return ReportIRField(name="F", ir_id="report::salesforce::00O123.ir", alias="f")

    def _native_def(self) -> NativeReportDefinition:
        return NativeReportDefinition(
            name="Def", report_id="report::salesforce::00O123", system="salesforce"
        )

    def _revision(self) -> ReportRevision:
        return ReportRevision(name="Rev", report_id="report::salesforce::00O123", revision_number=1)

    def _sf_report(self) -> SfReport:
        return SfReport(name="SF Report", report_id="00O123", org_key="myorg")

    def _sf_report_column(self) -> SfReportColumn:
        return SfReportColumn(name="Col", column_key="COL", report_id="00O123", org_key="myorg")

    def _sf_object(self) -> SfObject:
        return SfObject(name="Account", api_name="Account", org_key="myorg")

    def _dbt_model(self) -> DbtModel:
        return DbtModel(name="orders", unique_id="model.proj.orders", materialization="table")

    def _dbt_column(self) -> DbtColumn:
        return DbtColumn(name="amount", parent_id="model.proj.orders", parent_label="DbtModel")

    def _physical_table(self) -> PhysicalTable:
        return PhysicalTable(
            name="orders",
            fqn="db.schema.orders",
            database="db",
            schema_name="schema",
            relation_name="orders",
            warehouse_type="snowflake",
            environment="prod",
        )

    def test_native_instance_of(self) -> None:
        NativeInstanceOf().validate_nodes(self._sf_report(), self._report())

    def test_has_ir(self) -> None:
        HasIR().validate_nodes(self._report(), self._ir())

    def test_has_native_definition(self) -> None:
        HasNativeDefinition().validate_nodes(self._report(), self._native_def())

    def test_has_ir_field(self) -> None:
        HasIRField().validate_nodes(self._ir(), self._ir_field())

    def test_has_revision(self) -> None:
        HasRevision().validate_nodes(self._report(), self._revision())

    def test_revision_has_ir(self) -> None:
        RevisionHasIR().validate_nodes(self._revision(), self._ir())

    def test_maps_to_native_field(self) -> None:
        MapsToNativeField().validate_nodes(self._ir_field(), self._sf_report_column())

    def test_report_depends_on_sf_object(self) -> None:
        ReportDependsOn().validate_nodes(self._report(), self._sf_object())

    def test_report_depends_on_dbt_model(self) -> None:
        ReportDependsOn().validate_nodes(self._report(), self._dbt_model())

    def test_report_depends_on_physical_table(self) -> None:
        ReportDependsOn().validate_nodes(self._report(), self._physical_table())

    def test_derives_from_ir_field_to_dbt_column(self) -> None:
        DerivesFrom().validate_nodes(self._ir_field(), self._dbt_column())


# ===========================================================================
# Phase 2 Edge pair validation
# ===========================================================================


class TestPhase2ReportEdgePairs:
    """Verify that Phase 2 report edge classes accept correct node pairs."""

    def _ir(self) -> ReportIR:
        return ReportIR(name="IR", report_id="report::sf::123")

    def _filter(self) -> ReportIRFilter:
        return ReportIRFilter(name="F", ir_id="report::sf::123.ir", index=0)

    def _join(self) -> ReportIRJoin:
        return ReportIRJoin(name="J", ir_id="report::sf::123.ir", index=0)

    def _groupby(self) -> ReportIRGroupBy:
        return ReportIRGroupBy(name="G", ir_id="report::sf::123.ir", field_alias="stage")

    def _bucket(self) -> ReportIRBucket:
        return ReportIRBucket(name="B", ir_id="report::sf::123.ir", bucket_name="amount")

    def _formula(self) -> ReportIRFormula:
        return ReportIRFormula(name="F", ir_id="report::sf::123.ir", formula_name="calc")

    def _highlight(self) -> ReportIRHighlight:
        return ReportIRHighlight(name="H", ir_id="report::sf::123.ir", index=0)

    def _crossfilter(self) -> ReportIRCrossFilter:
        return ReportIRCrossFilter(name="CF", ir_id="report::sf::123.ir", index=0)

    def test_has_ir_filter(self) -> None:
        HasIRFilter().validate_nodes(self._ir(), self._filter())

    def test_has_ir_join(self) -> None:
        HasIRJoin().validate_nodes(self._ir(), self._join())

    def test_has_ir_groupby(self) -> None:
        HasIRGroupBy().validate_nodes(self._ir(), self._groupby())

    def test_has_ir_bucket(self) -> None:
        HasIRBucket().validate_nodes(self._ir(), self._bucket())

    def test_has_ir_formula(self) -> None:
        HasIRFormula().validate_nodes(self._ir(), self._formula())

    def test_has_ir_highlight(self) -> None:
        HasIRHighlight().validate_nodes(self._ir(), self._highlight())

    def test_has_ir_cross_filter(self) -> None:
        HasIRCrossFilter().validate_nodes(self._ir(), self._crossfilter())


# ===========================================================================
# Phase 2 MapsToNativeField edge pair validation
# ===========================================================================


class TestPhase2MapsToNativeFieldPairs:
    """Verify MapsToNativeField accepts Phase 2 node types."""

    def _sf_report_column(self) -> SfReportColumn:
        return SfReportColumn(name="Col", column_key="COL", report_id="00O123", org_key="myorg")

    def _groupby(self) -> ReportIRGroupBy:
        return ReportIRGroupBy(name="G", ir_id="report::sf::123.ir", field_alias="stage")

    def _filter(self) -> ReportIRFilter:
        return ReportIRFilter(name="F", ir_id="report::sf::123.ir", index=0, field_ref="AMOUNT")

    def _bucket(self) -> ReportIRBucket:
        return ReportIRBucket(name="B", ir_id="report::sf::123.ir", bucket_name="amount")

    def test_groupby_to_sf_report_column(self) -> None:
        MapsToNativeField().validate_nodes(self._groupby(), self._sf_report_column())

    def test_filter_to_sf_report_column(self) -> None:
        MapsToNativeField().validate_nodes(self._filter(), self._sf_report_column())

    def test_bucket_to_sf_report_column(self) -> None:
        MapsToNativeField().validate_nodes(self._bucket(), self._sf_report_column())


# ===========================================================================
# Invalid edge pair validation
# ===========================================================================


class TestInvalidEdgePairs:
    """Verify that invalid node pairs raise TypeError."""

    def test_reversed_native_instance_of_raises(self) -> None:
        report = Report(name="R", system="salesforce", native_id="123")
        sf_report = SfReport(name="SF", report_id="123", org_key="k")
        with pytest.raises(TypeError):
            NativeInstanceOf().validate_nodes(report, sf_report)  # reversed

    def test_wrong_ir_parent_raises(self) -> None:
        report = Report(name="R", system="salesforce", native_id="123")
        ir_field = ReportIRField(name="F", ir_id="x.ir", alias="f")
        with pytest.raises(TypeError):
            HasIRField().validate_nodes(report, ir_field)  # should be ReportIR -> ReportIRField

    def test_wrong_phase2_parent_raises(self) -> None:
        report = Report(name="R", system="salesforce", native_id="123")
        filter_node = ReportIRFilter(name="F", ir_id="x.ir", index=0)
        with pytest.raises(TypeError):
            HasIRFilter().validate_nodes(report, filter_node)  # should be ReportIR -> ReportIRFilter
