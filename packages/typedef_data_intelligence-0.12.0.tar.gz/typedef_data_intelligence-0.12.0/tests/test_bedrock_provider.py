"""Tests for Bedrock model creation and region extraction.

Tests the _create_bedrock_model function including:
- ARN-based model creation (region extraction from ARN)
- Legacy region/model-id format
- Bare model ID with default region
"""

from unittest.mock import MagicMock, patch


class TestCreateBedrockModel:
    """Tests for _create_bedrock_model function."""

    @patch("lineage.agent.pydantic.utils.AnthropicModel")
    @patch("lineage.agent.pydantic.utils.AnthropicProvider")
    @patch("lineage.agent.pydantic.utils.AsyncAnthropicBedrock")
    def test_model_with_arn(self, mock_bedrock_client, mock_provider, mock_model):
        """Model creation with ARN extracts region and model ID."""
        from lineage.agent.pydantic.utils import _create_bedrock_model

        mock_bedrock_client.return_value = MagicMock()
        mock_provider.return_value = MagicMock()
        mock_model.return_value = MagicMock()

        arn = "arn:aws:bedrock:us-west-2:025066247024:inference-profile/us.anthropic.claude-sonnet-4-20250514-v1:0"
        _create_bedrock_model(arn)

        # Region should be extracted from ARN
        mock_bedrock_client.assert_called_once_with(aws_region="us-west-2")
        # Model ID should be extracted from after the last /
        mock_model.assert_called_once()
        assert mock_model.call_args[0][0] == "us.anthropic.claude-sonnet-4-20250514-v1:0"

    @patch("lineage.agent.pydantic.utils.AnthropicModel")
    @patch("lineage.agent.pydantic.utils.AnthropicProvider")
    @patch("lineage.agent.pydantic.utils.AsyncAnthropicBedrock")
    def test_bare_model_id_uses_default_region(self, mock_bedrock_client, mock_provider, mock_model):
        """Bare model ID falls back to default region."""
        from lineage.agent.pydantic.utils import _create_bedrock_model

        mock_bedrock_client.return_value = MagicMock()
        mock_provider.return_value = MagicMock()
        mock_model.return_value = MagicMock()

        with patch.dict("os.environ", {}, clear=True):
            _create_bedrock_model("us.anthropic.claude-sonnet-4-20250514-v1:0")

        mock_bedrock_client.assert_called_once_with(aws_region="us-west-2")
        mock_model.assert_called_once()
        assert mock_model.call_args[0][0] == "us.anthropic.claude-sonnet-4-20250514-v1:0"

    @patch("lineage.agent.pydantic.utils.AnthropicModel")
    @patch("lineage.agent.pydantic.utils.AnthropicProvider")
    @patch("lineage.agent.pydantic.utils.AsyncAnthropicBedrock")
    def test_legacy_region_model_format(self, mock_bedrock_client, mock_provider, mock_model):
        """Legacy region/model-id format extracts region correctly."""
        from lineage.agent.pydantic.utils import _create_bedrock_model

        mock_bedrock_client.return_value = MagicMock()
        mock_provider.return_value = MagicMock()
        mock_model.return_value = MagicMock()

        _create_bedrock_model("eu-west-1/us.anthropic.claude-sonnet-4-20250514-v1:0")

        mock_bedrock_client.assert_called_once_with(aws_region="eu-west-1")
        mock_model.assert_called_once()
        assert mock_model.call_args[0][0] == "us.anthropic.claude-sonnet-4-20250514-v1:0"

    @patch("lineage.agent.pydantic.utils.AnthropicModel")
    @patch("lineage.agent.pydantic.utils.AnthropicProvider")
    @patch("lineage.agent.pydantic.utils.AsyncAnthropicBedrock")
    def test_region_from_env_variable(self, mock_bedrock_client, mock_provider, mock_model):
        """Bare model ID uses AWS_DEFAULT_REGION when set."""
        from lineage.agent.pydantic.utils import _create_bedrock_model

        mock_bedrock_client.return_value = MagicMock()
        mock_provider.return_value = MagicMock()
        mock_model.return_value = MagicMock()

        with patch.dict("os.environ", {"AWS_DEFAULT_REGION": "ap-southeast-1"}, clear=True):
            _create_bedrock_model("us.anthropic.claude-sonnet-4-20250514-v1:0")

        mock_bedrock_client.assert_called_once_with(aws_region="ap-southeast-1")
