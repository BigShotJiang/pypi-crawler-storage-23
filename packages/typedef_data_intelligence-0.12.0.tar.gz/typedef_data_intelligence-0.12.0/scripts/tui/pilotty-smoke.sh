#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../../.." && pwd)"

INIT_SESSION="typedef-smoke-init-$$"
CHAT_SESSION="typedef-smoke-chat-$$"
INIT_HOME="$(mktemp -d)"
CHAT_HOME="$(mktemp -d)"
CHAT_STATE_DIR="${TYPEDEF_CHAT_STATE_DIR:-$HOME/.typedef.medallio}"

cleanup() {
	pilotty kill -s "$INIT_SESSION" >/dev/null 2>&1 || true
	pilotty kill -s "$CHAT_SESSION" >/dev/null 2>&1 || true
	rm -rf "$INIT_HOME"
	rm -rf "$CHAT_HOME"
}
trap cleanup EXIT

require_command() {
	if ! command -v "$1" >/dev/null 2>&1; then
		echo "error: required command not found: $1" >&2
		exit 1
	fi
}

assert_focused_input() {
	local session_name="$1"
	local snapshot
	snapshot="$(pilotty snapshot -s "$session_name" --format full)"

	SNAPSHOT_JSON="$snapshot" uv run python - <<'PY'
import json
import os
import sys

data = json.loads(os.environ["SNAPSHOT_JSON"])
elements = data.get("elements", [])

for element in elements:
    if element.get("kind") == "input" and element.get("focused"):
        sys.exit(0)

print("error: expected focused input element was not detected", file=sys.stderr)
sys.exit(1)
PY
}

run_init_check() {
	echo "[1/2] checking typedef init screen"

	pilotty spawn --name "$INIT_SESSION" env HOME="$INIT_HOME" uv run typedef init >/dev/null
	pilotty wait-for -s "$INIT_SESSION" -t 30000 "typedef Setup Wizard" >/dev/null
	pilotty wait-for -s "$INIT_SESSION" -t 30000 "Step 1 of" >/dev/null
	pilotty wait-for -s "$INIT_SESSION" -t 30000 "Project name:" >/dev/null
	assert_focused_input "$INIT_SESSION"

	pilotty kill -s "$INIT_SESSION" >/dev/null
	echo "ok: init wizard rendered with focused input"
}

run_chat_check() {
	echo "[2/2] checking typedef chat screen"

	if [[ ! -e $CHAT_STATE_DIR ]]; then
		echo "error: chat state path does not exist: $CHAT_STATE_DIR" >&2
		echo "hint: set TYPEDEF_CHAT_STATE_DIR to a prepared typedef home" >&2
		exit 1
	fi

	ln -s "$CHAT_STATE_DIR" "$CHAT_HOME/.typedef"
	pilotty spawn --name "$CHAT_SESSION" env HOME="$CHAT_HOME" uv run typedef chat >/dev/null

	pilotty wait-for -s "$CHAT_SESSION" -t 90000 "Choose an agent" >/dev/null
	pilotty wait-for -s "$CHAT_SESSION" -t 90000 "Data Analyst" >/dev/null

	pilotty kill -s "$CHAT_SESSION" >/dev/null
	echo "ok: chat reached agent selection"
}

main() {
	cd "$REPO_ROOT"
	require_command uv
	require_command pilotty

	run_init_check
	run_chat_check

	echo ""
	echo "pilotty smoke checks passed"
}

main "$@"
