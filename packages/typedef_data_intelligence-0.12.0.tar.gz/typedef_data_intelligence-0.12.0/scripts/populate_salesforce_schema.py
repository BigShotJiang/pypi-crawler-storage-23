#!/usr/bin/env python3
r"""Populate a Salesforce org with custom objects and fields from a dbt source YAML.

Parses the mattermost-data-warehouse ``_salesforce__sources.yml`` to discover all
Salesforce objects and columns, then uses the Salesforce Metadata API (via
``simple_salesforce``) to recreate custom objects and custom fields on a target
Salesforce instance.

Managed-package fields/objects (sbqq__, netsuite_conn__, cbit__, engagio__,
dscorgpkg__) are created with a ``td_`` prefix so they don't collide with
actual managed packages.

Usage:
    # Dry run (parse only, no API calls)
    python scripts/populate_salesforce_schema.py \\
        --source-yaml /path/to/_salesforce__sources.yml \\
        --dry-run

    # Execute with OAuth (run sf-login first)
    python scripts/populate_salesforce_schema.py \\
        --source-yaml /path/to/_salesforce__sources.yml \\
        --client-id 3MVG9...

    # Execute with password auth
    python scripts/populate_salesforce_schema.py \\
        --source-yaml /path/to/_salesforce__sources.yml \\
        --instance-url https://my.salesforce.com \\
        --username user@example.com \\
        --password pass \\
        --security-token tok
"""

from __future__ import annotations

import argparse
import re
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

MANAGED_PREFIXES = ("sbqq__", "netsuite_conn__", "cbit__", "engagio__", "dscorgpkg__")

# Objects to skip entirely (not real Salesforce objects)
SKIP_OBJECTS = frozenset({
    "_sdc_rejected",
    "opportunity_sg",
    "customer_risk__history",
})

# Stitch replication columns -- never exist in Salesforce
STITCH_COLUMNS = frozenset({
    "_sdc_batched_at",
    "_sdc_extracted_at",
    "_sdc_received_at",
    "_sdc_sequence",
    "_sdc_table_version",
})

# Standard Salesforce fields that already exist on every/most objects.
# These should NEVER be created via Metadata API.
STANDARD_FIELDS = frozenset({
    "id",
    "name",
    "isdeleted",
    "createddate",
    "createdbyid",
    "lastmodifieddate",
    "lastmodifiedbyid",
    "systemmodstamp",
    "ownerid",
    "recordtypeid",
    "lastactivitydate",
    "lastreferenceddate",
    "lastvieweddate",
    "masterrecordid",
    # Account / Contact standard
    "accountid",
    "accountsource",
    "annualrevenue",
    "billingcity",
    "billingcountry",
    "billingcountrycode",
    "billinglatitude",
    "billinglongitude",
    "billingpostalcode",
    "billingstate",
    "billingstatecode",
    "billingstreet",
    "shippingcity",
    "shippingcountry",
    "shippingcountrycode",
    "shippingpostalcode",
    "shippingstate",
    "shippingstatecode",
    "shippingstreet",
    "description",
    "email",
    "fax",
    "firstname",
    "lastname",
    "phone",
    "mobilephone",
    "salutation",
    "title",
    "website",
    "industry",
    "numberofemployees",
    "ownership",
    "parentid",
    "rating",
    "sic",
    "sicdesc",
    "site",
    "tickersymbol",
    "type",
    # Lead standard
    "company",
    "country",
    "countrycode",
    "convertedaccountid",
    "convertedcontactid",
    "converteddate",
    "convertedopportunityid",
    "donotcall",
    "hasoptedoutofemail",
    "hasoptedoutoffax",
    "leadsource",
    "postalcode",
    "state",
    "statecode",
    "status",
    "street",
    "city",
    # Opportunity standard
    "amount",
    "campaignid",
    "closedate",
    "contractid",
    "expectedrevenue",
    "forecastcategory",
    "forecastcategoryname",
    "isclosed",
    "iswon",
    "nextstep",
    "pricebook2id",
    "probability",
    "stagename",
    # Campaign standard
    "actualcost",
    "amountallopportunities",
    "amountwonopportunities",
    "budgetedcost",
    "enddate",
    "expectedresponse",
    "isactive",
    "numberofcontacts",
    "numberofconvertedleads",
    "numberofleads",
    "numberofopportunities",
    "numberofresponses",
    "numberofwonopportunities",
    "numbersent",
    "startdate",
    "hierarchyactualcost",
    "hierarchyamountallopportunities",
    "hierarchyamountwonopportunities",
    "hierarchybudgetedcost",
    "hierarchyexpectedrevenue",
    "hierarchynumberofcontacts",
    "hierarchynumberofconvertedleads",
    "hierarchynumberofleads",
    "hierarchynumberofopportunities",
    "hierarchynumberofresponses",
    "hierarchynumberofwonopportunities",
    "hierarchynumbersent",
    # CampaignMember standard
    "companyoraccount",
    "contactid",
    "firstrespondeddate",
    "hasresponded",
    "leadid",
    "leadorcontactid",
    "leadorcontactownerid",
    # Contract standard
    "activatedbyid",
    "activateddate",
    "companysigneddate",
    "companysignedid",
    "contractnumber",
    "contractterm",
    "customersigneddate",
    "customersignedid",
    "customersignedtitle",
    "specialterms",
    "statuscode",
    # Event standard
    "activitydate",
    "activitydatetime",
    "durationinminutes",
    "enddatetime",
    "eventsubtype",
    "groupeventtype",
    "isalldayevent",
    "isarchived",
    "ischild",
    "isgroupevent",
    "isprivate",
    "isrecurrence",
    "isreminderset",
    "location",
    "recurrenceactivityid",
    "recurrencedayofweekmask",
    "recurrenceenddateonly",
    "recurrenceinstance",
    "recurrenceinterval",
    "recurrencestartdatetime",
    "recurrencetimezonesidkey",
    "recurrencetype",
    "reminderdatetime",
    "showas",
    "startdatetime",
    "subject",
    "whatcount",
    "whatid",
    "whocount",
    "whoid",
    # Task standard
    "calldisposition",
    "calldurationinseconds",
    "calltype",
    "ishighpriority",
    "priority",
    "tasksubtype",
    "completeddatetime",
    # OpportunityContactRole standard
    "isprimary",
    "opportunityid",
    "role",
    # OpportunityFieldHistory / OpportunityHistory standard
    "field",
    # OpportunityLineItem standard
    "discount",
    "listprice",
    "pricebookentryid",
    "product2id",
    "productcode",
    "quantity",
    "servicedate",
    "sortorder",
    "subtotal",
    "totalprice",
    "unitprice",
    # PricebookEntry standard
    "usestandardprice",
    # Product2 standard
    "family",
    # User standard
    "department",
    "division",
    "employeenumber",
    "federationidentifier",
    "managerid",
    "profileid",
    "username",
    "userroleid",
    "usertype",
    # UserRole standard
    "caseaccessforaccountowner",
    "contactaccessforaccountowner",
    "developername",
    "mayforecastmanagershare",
    "opportunityaccessforaccountowner",
    "parentroleid",
    "portaltype",
    "rollupdescription",
    # History tracking columns (not real fields)
    "newvalue__fl",
    "newvalue__st",
    "newvalue__bo",
    "newvalue__de",
    "oldvalue__fl",
    "oldvalue__st",
    "oldvalue__bo",
    "oldvalue__de",
    "record",
    "reason",
    "table_name",
})

# Standard Salesforce objects (already exist, only add custom fields)
STANDARD_OBJECTS = frozenset({
    "account",
    "campaign",
    "campaignmember",
    "contact",
    "contract",
    "event",
    "lead",
    "opportunity",
    "opportunitycontactrole",
    "opportunityfieldhistory",
    "opportunityhistory",
    "opportunitylineitem",
    "pricebookentry",
    "product2",
    "task",
    "user",
    "userrole",
})

# Map lowercase dbt table names to proper Salesforce API names for standard objects
STANDARD_OBJECT_API_NAMES: dict[str, str] = {
    "account": "Account",
    "campaign": "Campaign",
    "campaignmember": "CampaignMember",
    "contact": "Contact",
    "contract": "Contract",
    "event": "Event",
    "lead": "Lead",
    "opportunity": "Opportunity",
    "opportunitycontactrole": "OpportunityContactRole",
    "opportunityfieldhistory": "OpportunityFieldHistory",
    "opportunityhistory": "OpportunityHistory",
    "opportunitylineitem": "OpportunityLineItem",
    "pricebookentry": "PricebookEntry",
    "product2": "Product2",
    "task": "Task",
    "user": "User",
    "userrole": "UserRole",
}


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class FieldSpec:
    """Specification for a Salesforce field to create or verify."""

    original_name: str
    api_name: str
    is_standard: bool
    is_custom: bool
    is_managed: bool
    sf_type: str
    sf_config: dict[str, Any] = field(default_factory=dict)


@dataclass
class ObjectSpec:
    """Specification for a Salesforce object to create or verify."""

    original_name: str
    api_name: str
    is_standard: bool
    is_custom: bool
    is_managed: bool
    fields: list[FieldSpec] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Naming helpers
# ---------------------------------------------------------------------------

def _has_managed_prefix(name: str) -> bool:
    """Check if a name starts with a known managed-package namespace."""
    return any(name.startswith(p) for p in MANAGED_PREFIXES)


def _rename_managed(name: str) -> str:
    """Replace managed-package prefix with ``td_`` prefix.

    ``sbqq__quote__c`` -> ``td_sbqq_quote__c``
    ``cbit__clearbitdomain__c`` -> ``td_cbit_clearbitdomain__c``
    """
    for prefix in MANAGED_PREFIXES:
        if name.startswith(prefix):
            # Strip the prefix's trailing __ and rejoin with td_ and single _
            namespace = prefix.rstrip("_")  # e.g. "sbqq"
            remainder = name[len(prefix):]  # e.g. "quote__c"
            return f"td_{namespace}_{remainder}"
    return name


def _api_name_to_label(api_name: str) -> str:
    """Convert a Salesforce API name to a human-readable label.

    ``arr_contributed__c`` -> ``Arr Contributed``
    ``td_sbqq_quote__c`` -> ``Td Sbqq Quote``
    """
    # Strip __c suffix
    label = re.sub(r"__c$", "", api_name)
    # Replace underscores with spaces
    label = label.replace("_", " ")
    # Title-case
    label = label.title()
    # Fix common abbreviations
    for abbr in ("Arr", "Api", "Csm", "Mql", "Pql", "Sql", "Sso", "Url", "Id",
                 "Dwh", "Nda", "Pr", "Ha", "Emm", "Mdm", "Td", "Sbqq", "Cbit",
                 "Dscorgpkg", "Netsuite", "Conn", "Mau", "Wau", "Rvp", "Qsc",
                 "Qso", "Sdl", "Scl", "Mcl", "Mel", "Sal"):
        label = re.sub(rf"\b{abbr}\b", abbr.upper(), label)
    return label


def _pluralize(label: str) -> str:
    """Naive pluralization for object labels."""
    if label.endswith("y") and label[-2:] not in ("ey", "ay", "oy"):
        return label[:-1] + "ies"
    if label.endswith(("s", "x", "z", "ch", "sh")):
        return label + "es"
    return label + "s"


# ---------------------------------------------------------------------------
# Type inference
# ---------------------------------------------------------------------------

def _infer_sf_type(column_name: str) -> tuple[str, dict[str, Any]]:
    """Infer the Salesforce field type from the column name.

    Returns (sf_type, config_dict).
    """
    name = column_name.lower()

    # Boolean patterns
    if name.startswith(("is_", "has_")) or name in ("isdeleted",):
        return "Checkbox", {"defaultValue": False}

    # Date / DateTime patterns
    if name.endswith(("_datetime", "_at")):
        return "DateTime", {}
    # Strip __c suffix for pattern matching (e.g. account_end_date__c -> account_end_date)
    name_stripped = re.sub(r"__c$", "", name)
    if (name_stripped.endswith(("_date", "date", "datef"))
            or "_date_" in name_stripped
            or name_stripped in ("startdate", "enddate", "closedate")):
        return "Date", {}

    # Currency patterns
    if any(kw in name for kw in ("_amount", "_arr", "_price", "_value", "_revenue",
                                  "annual", "_cost", "_fee", "_total", "_subtotal")):
        return "Currency", {"precision": 18, "scale": 2}

    # Percent patterns
    if any(kw in name for kw in ("_percent", "_rate", "utilization", "_discount")):
        return "Percent", {"precision": 5, "scale": 2}

    # Number / Count patterns
    if any(kw in name for kw in ("_count", "_number", "_qty", "quantity",
                                  "number_of", "of_seats", "of_plugins",
                                  "of_webhooks", "numberof")):
        return "Number", {"precision": 18, "scale": 0}

    # Email
    if name.endswith("_email") or name == "email":
        return "Email", {}

    # Phone
    if name.endswith("_phone") or name == "phone":
        return "Phone", {}

    # URL
    if name.endswith(("_url", "_link")) or name == "website":
        return "Url", {}

    # Long text patterns
    if any(kw in name for kw in ("_description", "_notes", "_comment",
                                  "details", "requirements", "highlights",
                                  "terms", "other_", "additional_")):
        return "LongTextArea", {"length": 32768, "visibleLines": 5}

    # Foreign key references (ending in _id but not just "id")
    if name.endswith("_id") or name.endswith("id__c"):
        return "Text", {"length": 80}

    # Default to Text
    return "Text", {"length": 255}


# ---------------------------------------------------------------------------
# YAML parsing
# ---------------------------------------------------------------------------

def parse_source_yaml(yaml_path: Path) -> list[ObjectSpec]:
    """Parse a dbt source YAML and return structured object/field specs."""
    with open(yaml_path) as f:
        data = yaml.safe_load(f)

    objects: list[ObjectSpec] = []

    for source in data.get("sources", []):
        for table in source.get("tables", []):
            table_name = table["name"].lower()

            # Skip non-Salesforce tables
            if table_name in SKIP_OBJECTS:
                continue

            # Classify the object
            obj_is_managed = _has_managed_prefix(table_name)
            obj_is_custom = table_name.endswith("__c") and not obj_is_managed
            obj_is_standard = table_name in STANDARD_OBJECTS

            if obj_is_managed:
                obj_api_name = _rename_managed(table_name)
            elif obj_is_standard:
                obj_api_name = STANDARD_OBJECT_API_NAMES[table_name]
            else:
                # Custom object -- keep as-is (already has __c)
                obj_api_name = table_name

            obj = ObjectSpec(
                original_name=table_name,
                api_name=obj_api_name,
                is_standard=obj_is_standard,
                is_custom=obj_is_custom,
                is_managed=obj_is_managed,
            )

            for col in table.get("columns", []):
                col_name = col["name"].lower()

                # Skip Stitch internal columns
                if col_name in STITCH_COLUMNS:
                    continue

                # Classify the field
                fld_is_standard = col_name in STANDARD_FIELDS
                fld_is_managed = _has_managed_prefix(col_name)
                fld_is_custom = col_name.endswith("__c") and not fld_is_managed and not fld_is_standard

                if fld_is_standard:
                    fld_api_name = col_name  # won't be created
                elif fld_is_managed:
                    fld_api_name = _rename_managed(col_name)
                else:
                    fld_api_name = col_name

                sf_type, sf_config = _infer_sf_type(col_name)

                obj.fields.append(FieldSpec(
                    original_name=col_name,
                    api_name=fld_api_name,
                    is_standard=fld_is_standard,
                    is_custom=fld_is_custom,
                    is_managed=fld_is_managed,
                    sf_type=sf_type,
                    sf_config=sf_config,
                ))

            objects.append(obj)

    return objects


# ---------------------------------------------------------------------------
# Salesforce Metadata API operations
# ---------------------------------------------------------------------------

def _build_sf_connection(args: argparse.Namespace) -> Any:
    """Build a ``simple_salesforce.Salesforce`` connection from CLI args."""
    from simple_salesforce import Salesforce

    # Password auth
    if all(getattr(args, a, None) for a in ("instance_url", "username", "password", "security_token")):
        return Salesforce(
            instance_url=args.instance_url,
            username=args.username,
            password=args.password,
            security_token=args.security_token,
        )

    # OAuth / Device flow (reuse stored tokens via project auth helpers)
    if args.client_id:
        login_url = getattr(args, "login_url", "https://login.salesforce.com")
        org_key = getattr(args, "org_key", "default")

        try:
            from lineage.ingest.static_loaders.salesforce.auth.oauth_pkce import (
                OAuthPKCEAuth,
            )
            auth = OAuthPKCEAuth(
                client_id=args.client_id,
                login_url=login_url,
                org_key=org_key,
            )
            creds = auth.authenticate()
            return Salesforce(
                instance_url=creds.instance_url,
                session_id=creds.access_token,
            )
        except Exception:
            pass  # PKCE unavailable or failed — fall through to device flow

        # Fallback: device flow
        try:
            from lineage.ingest.static_loaders.salesforce.auth.device_flow import (
                OAuthDeviceFlowAuth,
            )
            auth = OAuthDeviceFlowAuth(
                client_id=args.client_id,
                login_url=login_url,
                org_key=org_key,
            )
            creds = auth.authenticate()
            return Salesforce(
                instance_url=creds.instance_url,
                session_id=creds.access_token,
            )
        except Exception as exc:
            print(f"Error: Could not authenticate with client-id: {exc}", file=sys.stderr)
            sys.exit(1)

    print(
        "Error: Provide either --client-id (with sf-login tokens) or "
        "--instance-url/--username/--password/--security-token.",
        file=sys.stderr,
    )
    sys.exit(1)


def _build_field_metadata(obj_api_name: str, fld: FieldSpec) -> dict[str, Any]:
    """Build a Metadata API ``CustomField`` dict for a single field."""
    meta: dict[str, Any] = {
        "fullName": f"{obj_api_name}.{fld.api_name}",
        "label": _api_name_to_label(fld.api_name),
        "type": fld.sf_type,
    }

    if fld.sf_type == "Text":
        meta["length"] = fld.sf_config.get("length", 255)
    elif fld.sf_type == "LongTextArea":
        meta["length"] = fld.sf_config.get("length", 32768)
        meta["visibleLines"] = fld.sf_config.get("visibleLines", 5)
    elif fld.sf_type in ("Currency", "Number", "Percent"):
        meta["precision"] = fld.sf_config.get("precision", 18)
        meta["scale"] = fld.sf_config.get("scale", 2)
    elif fld.sf_type == "Checkbox":
        meta["defaultValue"] = fld.sf_config.get("defaultValue", False)

    return meta


def create_custom_objects(sf: Any, objects: list[ObjectSpec], dry_run: bool) -> dict[str, list[str]]:
    """Create custom objects that don't already exist in Salesforce.

    Returns a dict of {status: [object_names]}.
    """
    results: dict[str, list[str]] = {"created": [], "skipped": [], "failed": []}

    objs_to_create = [o for o in objects if not o.is_standard]
    if not objs_to_create:
        return results

    print(f"\n{'=' * 60}")
    print(f"Phase 1: Custom Objects ({len(objs_to_create)} to create)")
    print(f"{'=' * 60}")

    for obj in objs_to_create:
        label = _api_name_to_label(obj.api_name)
        plural = _pluralize(label)

        print(f"  Object: {obj.api_name} (label: {label})")

        if dry_run:
            results["created"].append(obj.api_name)
            continue

        try:
            md = sf.mdapi.CustomObject(
                fullName=obj.api_name,
                label=label,
                pluralLabel=plural,
                deploymentStatus="Deployed",
                sharingModel="ReadWrite",
                nameField={
                    "label": "Name",
                    "type": "AutoNumber",
                    "displayFormat": f"{obj.api_name[:3].upper()}-{{00000}}",
                },
            )
            sf.mdapi.CustomObject.create([md])
            results["created"].append(obj.api_name)
            print("    -> Created")
        except Exception as exc:
            err_msg = str(exc)
            if "DUPLICATE" in err_msg.upper() or "ALREADY" in err_msg.upper():
                results["skipped"].append(obj.api_name)
                print("    -> Already exists, skipped")
            else:
                results["failed"].append(obj.api_name)
                print(f"    -> FAILED: {exc}")

    return results


def create_custom_fields(
    sf: Any,
    objects: list[ObjectSpec],
    dry_run: bool,
    batch_size: int = 10,
) -> dict[str, int]:
    """Create custom fields on objects via the Metadata API.

    Returns counts: {created, skipped, failed}.
    """
    counts = {"created": 0, "skipped": 0, "failed": 0}

    print(f"\n{'=' * 60}")
    print("Phase 2: Custom Fields")
    print(f"{'=' * 60}")

    for obj in objects:
        # Collect fields to create (non-standard only)
        fields_to_create = [f for f in obj.fields if not f.is_standard]
        if not fields_to_create:
            continue

        print(f"\n  Object: {obj.api_name} ({len(fields_to_create)} fields)")

        # Process in batches
        for i in range(0, len(fields_to_create), batch_size):
            batch = fields_to_create[i : i + batch_size]

            for fld in batch:
                meta = _build_field_metadata(obj.api_name, fld)
                label = f"    {meta['fullName']} ({fld.sf_type})"

                if fld.is_managed:
                    label += f" [renamed from {fld.original_name}]"

                print(label)

                if dry_run:
                    counts["created"] += 1
                    continue

                try:
                    md = sf.mdapi.CustomField(**meta)
                    sf.mdapi.CustomField.create([md])
                    counts["created"] += 1
                except Exception as exc:
                    err_msg = str(exc)
                    if "DUPLICATE" in err_msg.upper() or "ALREADY" in err_msg.upper():
                        counts["skipped"] += 1
                        print("      -> Already exists, skipped")
                    else:
                        counts["failed"] += 1
                        print(f"      -> FAILED: {exc}")

            # Brief pause between batches to avoid rate limits
            if not dry_run and i + batch_size < len(fields_to_create):
                time.sleep(0.5)

    return counts


# ---------------------------------------------------------------------------
# Dry-run report
# ---------------------------------------------------------------------------

def print_summary(
    objects: list[ObjectSpec],
    obj_results: dict[str, list[str]],
    field_counts: dict[str, int],
    dry_run: bool,
) -> None:
    """Print a summary report."""
    mode = "DRY RUN" if dry_run else "EXECUTION"

    print(f"\n{'=' * 60}")
    print(f"Summary ({mode})")
    print(f"{'=' * 60}")

    # Object summary
    std_count = sum(1 for o in objects if o.is_standard)
    custom_count = sum(1 for o in objects if o.is_custom)
    managed_count = sum(1 for o in objects if o.is_managed)

    print("\n  Objects:")
    print(f"    Standard (skip creation): {std_count}")
    print(f"    Custom (create):          {custom_count}")
    print(f"    Managed (rename+create):  {managed_count}")

    if obj_results["created"]:
        print(f"    Created: {len(obj_results['created'])}")
    if obj_results["skipped"]:
        print(f"    Skipped (exist): {len(obj_results['skipped'])}")
    if obj_results["failed"]:
        print(f"    Failed: {len(obj_results['failed'])}")
        for name in obj_results["failed"]:
            print(f"      - {name}")

    # Field summary
    total_fields = sum(len(o.fields) for o in objects)
    std_fields = sum(1 for o in objects for f in o.fields if f.is_standard)
    custom_fields = sum(1 for o in objects for f in o.fields if f.is_custom)
    managed_fields = sum(1 for o in objects for f in o.fields if f.is_managed)

    print(f"\n  Fields (total parsed: {total_fields}):")
    print(f"    Standard (skip):          {std_fields}")
    print(f"    Custom (create):          {custom_fields}")
    print(f"    Managed (rename+create):  {managed_fields}")
    print(f"    Created: {field_counts['created']}")
    print(f"    Skipped (exist): {field_counts['skipped']}")
    print(f"    Failed: {field_counts['failed']}")

    # Type distribution
    type_counts: dict[str, int] = {}
    for obj in objects:
        for fld in obj.fields:
            if not fld.is_standard:
                type_counts[fld.sf_type] = type_counts.get(fld.sf_type, 0) + 1
    if type_counts:
        print("\n  Inferred type distribution:")
        for sf_type, count in sorted(type_counts.items(), key=lambda x: -x[1]):
            print(f"    {sf_type:20s} {count}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    """Parse CLI arguments."""
    parser = argparse.ArgumentParser(
        description="Populate Salesforce schema from dbt source YAML",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "--source-yaml",
        required=True,
        type=Path,
        help="Path to the dbt _salesforce__sources.yml file",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Parse and report what would be created without calling Salesforce",
    )
    parser.add_argument(
        "--skip-objects",
        default=None,
        help="Comma-separated object names to skip",
    )
    parser.add_argument(
        "--only-objects",
        default=None,
        help="Only process these objects (comma-separated)",
    )

    # Auth options (same patterns as the main CLI)
    auth = parser.add_argument_group("authentication")
    auth.add_argument("--client-id", default=None, help="Connected App consumer key (for OAuth)")
    auth.add_argument("--instance-url", default=None, help="Salesforce instance URL (password auth)")
    auth.add_argument("--username", default=None, help="Salesforce username (password auth)")
    auth.add_argument("--password", default=None, help="Salesforce password (password auth)")
    auth.add_argument("--security-token", default=None, help="Salesforce security token (password auth)")
    auth.add_argument(
        "--login-url",
        default="https://login.salesforce.com",
        help="Salesforce login URL (default: https://login.salesforce.com)",
    )
    auth.add_argument("--org-key", default="default", help="Token store key for multi-org support")

    return parser.parse_args()


def main() -> None:
    """Populate Salesforce schema from dbt source YAML definition."""
    args = parse_args()

    # 1. Parse YAML
    if not args.source_yaml.exists():
        print(f"Error: Source YAML not found: {args.source_yaml}", file=sys.stderr)
        sys.exit(1)

    print(f"Parsing {args.source_yaml} ...")
    objects = parse_source_yaml(args.source_yaml)
    print(f"Found {len(objects)} objects")

    # Apply filters
    if args.skip_objects:
        skip = {s.strip().lower() for s in args.skip_objects.split(",")}
        objects = [o for o in objects if o.original_name not in skip]
        print(f"After --skip-objects filter: {len(objects)} objects")

    if args.only_objects:
        only = {s.strip().lower() for s in args.only_objects.split(",")}
        objects = [o for o in objects if o.original_name in only]
        print(f"After --only-objects filter: {len(objects)} objects")

    # 2. Connect to Salesforce (unless dry-run)
    sf = None
    if not args.dry_run:
        print("\nConnecting to Salesforce ...")
        sf = _build_sf_connection(args)
        print(f"Connected to {sf.sf_instance}")

    # 3. Create custom objects
    obj_results = create_custom_objects(sf, objects, args.dry_run)

    # Brief pause to let objects propagate before adding fields
    if not args.dry_run and obj_results["created"]:
        print("\nWaiting for object creation to propagate ...")
        time.sleep(5)

    # 4. Create custom fields
    field_counts = create_custom_fields(sf, objects, args.dry_run)

    # 5. Summary
    print_summary(objects, obj_results, field_counts, args.dry_run)


if __name__ == "__main__":
    main()
