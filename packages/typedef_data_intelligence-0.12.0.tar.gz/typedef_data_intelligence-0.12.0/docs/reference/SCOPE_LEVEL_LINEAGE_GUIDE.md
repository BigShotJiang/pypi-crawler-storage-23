# Scope-Level Column Lineage: Navigation Guide

The lineage graph persists per-CTE transformation data for every dbt model. This means you can trace **how** data flows through each intermediate step inside a model's SQL, not just the final input-to-output mapping.

## Graph Structure

```text
DbtModel
  ├── HAS_CTE_SCOPE ──> CteScope ("deduped")
  │                        ├── DERIVES_FROM ──> CteScope ("raw_events")   # CTE-to-CTE
  │                        └── DERIVES_FROM ──> DbtColumn (base table)    # CTE-to-leaf
  ├── HAS_CTE_SCOPE ──> CteScope ("raw_events")
  │                        └── DERIVES_FROM ──> DbtColumn (base table)
  └── MATERIALIZES ──> DbtColumn (output)
                          └── DERIVES_FROM ──> DbtColumn (input)          # model-level
                                scope: "__root__"
```

### Nodes

| Node       | Description                  |
| ---------- | ---------------------------- |
| `CteScope` | One CTE within a model's SQL |

**CteScope properties:**

| Property            | Type | Description                                                   |
| ------------------- | ---- | ------------------------------------------------------------- |
| `id`                | str  | `{model_unique_id}::cte::{scope_name_lower}`                  |
| `name`              | str  | CTE name (e.g., `deduped`, `filtered_orders`)                 |
| `model_id`          | str  | Parent model's unique_id                                      |
| `scope_type`        | str  | `"cte"`, `"union"`, `"subquery"`                              |
| `has_grain_change`  | bool | True if this CTE changes the grain (GROUP BY, DISTINCT, etc.) |
| `has_row_reduction` | bool | True if this CTE reduces rows (WHERE, HAVING, QUALIFY, etc.)  |
| `is_set_operation`  | bool | True if this is a UNION/INTERSECT/EXCEPT scope                |

### Edges

| Edge            | From      | To        | Description                           |
| --------------- | --------- | --------- | ------------------------------------- |
| `HAS_CTE_SCOPE` | DbtModel  | CteScope  | Model contains this CTE               |
| `DERIVES_FROM`  | CteScope  | CteScope  | CTE reads from another CTE            |
| `DERIVES_FROM`  | CteScope  | DbtColumn | CTE reads from a base table column    |
| `DERIVES_FROM`  | DbtColumn | DbtColumn | Model-level column lineage (existing) |

**DERIVES_FROM properties on scope-level edges:**

| Property          | Type | Description                                                                       |
| ----------------- | ---- | --------------------------------------------------------------------------------- |
| `column_name`     | str  | Output column name in the source CTE                                              |
| `upstream_column` | str  | Input column name from the upstream scope                                         |
| `transformation`  | str  | `passthrough`, `aggregated`, `computed`, `renamed`, `windowed`, `group_key`, etc. |
| `expr`            | str  | Raw SQL expression                                                                |
| `function_name`   | str  | Function applied (e.g., `SUM`, `ROW_NUMBER`, `COALESCE`)                          |
| `confidence`      | str  | Always `"direct"` for scope-level edges                                           |
| `scope`           | str  | On DbtColumn edges: `"__root__"` or ephemeral CTE name                            |

---

## Common Queries

### 1. List all CTEs in a model

```cypher
MATCH (m:DbtModel {name: 'my_model'})-[:HAS_CTE_SCOPE]->(c:CteScope)
RETURN c.name, c.scope_type, c.has_grain_change, c.has_row_reduction, c.is_set_operation
ORDER BY c.name
```

### 2. Trace the CTE dependency chain within a model

Which CTEs feed into which?

```cypher
MATCH (m:DbtModel {name: 'my_model'})-[:HAS_CTE_SCOPE]->(c1:CteScope)-[d:DERIVES_FROM]->(c2:CteScope)
RETURN DISTINCT c1.name AS cte, c2.name AS reads_from
ORDER BY c1.name
```

### 3. See what base tables a CTE reads from

```cypher
MATCH (m:DbtModel {name: 'my_model'})-[:HAS_CTE_SCOPE]->(c:CteScope {name: 'deduped'})-[d:DERIVES_FROM]->(col:DbtColumn)
RETURN d.column_name AS cte_column, col.id AS source_column, d.transformation, d.function_name
ORDER BY d.column_name
```

### 4. Find all aggregations happening inside CTEs

```cypher
MATCH (c:CteScope)-[d:DERIVES_FROM]->()
WHERE d.transformation = 'aggregated'
RETURN c.name, c.model_id, d.column_name, d.function_name, d.expr
ORDER BY d.function_name
```

### 5. Find CTEs that change the grain

Useful for understanding where row counts shift:

```cypher
MATCH (m:DbtModel)-[:HAS_CTE_SCOPE]->(c:CteScope)
WHERE c.has_grain_change = true
RETURN m.name, c.name, c.scope_type
ORDER BY m.name
```

### 6. Find UNION/set-operation CTEs

```cypher
MATCH (m:DbtModel)-[:HAS_CTE_SCOPE]->(c:CteScope)
WHERE c.is_set_operation = true
RETURN m.name, c.name
```

### 7. Full column trace through CTEs (multi-hop)

Trace a specific output column back through all CTE hops to its base table origin:

```cypher
// Start from the root-scope DbtColumn edge, then walk CTE chain
MATCH (out:DbtColumn)-[root:DERIVES_FROM]->(src:DbtColumn)
WHERE out.id CONTAINS 'my_model' AND out.name = 'revenue'
  AND root.scope = '__root__'

// Now trace the CTE chain for the same model
WITH out, root, src
MATCH (m:DbtModel)-[:HAS_CTE_SCOPE]->(c:CteScope)-[d:DERIVES_FROM*1..5]->(leaf)
WHERE m.unique_id = out.parent_id
  AND (leaf:DbtColumn OR leaf:CteScope)
RETURN c.name, d, leaf
```

### 8. Compare transformation complexity across models

Which models have the most CTE steps?

```cypher
MATCH (m:DbtModel)-[:HAS_CTE_SCOPE]->(c:CteScope)
RETURN m.name, count(c) AS cte_count
ORDER BY cte_count DESC
LIMIT 20
```

### 9. Find CTEs that filter rows (potential data loss points)

```cypher
MATCH (m:DbtModel)-[:HAS_CTE_SCOPE]->(c:CteScope)
WHERE c.has_row_reduction = true
RETURN m.name, c.name
ORDER BY m.name
```

### 10. Trace a column end-to-end through a specific model

Pick a model with known CTEs and trace one column:

```cypher
// Step 1: root scope — what does the output column derive from?
MATCH (out:DbtColumn {parent_id: 'model.project.my_model', name: 'total_revenue'})
      -[d:DERIVES_FROM]->(src:DbtColumn)
RETURN 'root' AS scope, out.name AS output, src.id AS source, d.transformation, d.expr

UNION ALL

// Step 2: CTE-level — what transformations happen at each CTE?
MATCH (m:DbtModel {unique_id: 'model.project.my_model'})-[:HAS_CTE_SCOPE]->(c:CteScope)
      -[d:DERIVES_FROM]->(target)
WHERE d.column_name = 'TOTAL_REVENUE' OR d.upstream_column = 'TOTAL_REVENUE'
RETURN c.name AS scope, d.column_name AS output,
       CASE WHEN target:DbtColumn THEN target.id ELSE target.name END AS source,
       d.transformation, d.expr
```

---

## Relationship to Model-Level Lineage

Model-level lineage (`DbtColumn → DERIVES_FROM → DbtColumn`) still works exactly as before. The `scope` property on these edges tells you which scope produced the edge:

- `scope = "__root__"` — the model's final SELECT
- `scope = "__DBT__CTE__<model_name>"` — an ephemeral model inlined as a CTE

Scope-level lineage (`CteScope → DERIVES_FROM → CteScope/DbtColumn`) provides the **internal detail** within each model. Use model-level lineage for cross-model questions ("where does this column come from?") and scope-level lineage for intra-model questions ("how is this column computed step by step?").

---

## Practical Use Cases

**Impact analysis**: A column in a base table changed. Which CTEs in downstream models reference it, and what transformations do they apply?

```cypher
MATCH (c:CteScope)-[d:DERIVES_FROM]->(col:DbtColumn)
WHERE col.id CONTAINS 'source_model.column_name'
RETURN c.model_id, c.name, d.column_name, d.transformation
```

**Debugging data quality**: A model's output has unexpected NULLs. Walk the CTE chain to find where data gets filtered or transformed:

```cypher
MATCH (m:DbtModel {name: 'problem_model'})-[:HAS_CTE_SCOPE]->(c:CteScope)
WHERE c.has_row_reduction = true OR c.has_grain_change = true
RETURN c.name, c.has_row_reduction, c.has_grain_change
```

**Documentation**: Automatically describe a model's transformation pipeline by listing its CTEs with their grain changes and key aggregations.
