# Agent Design Notes: Planning, Structured Output, and Why We Changed Course

This document explains the reasoning behind the context brief refactor
introduced in `brandon/context-brief-refactor`. We made several decisions that
deviate from how the system was originally designed, and we want the reasoning
on record so it's not re-litigated later.

---

## Background: What the original design did

The original deep orchestrator used a **tool-based incremental plan builder**.
The planner specialist called `create_plan()`, then `add_plan_section()`,
`add_plan_step()`, etc. — essentially transcribing a plan it had already formed
internally into a persistent artifact one API call at a time.

Similarly, investigation specialists (explorer, diagnostician) called
`save_context_brief()` explicitly before returning, and their return value to
the orchestrator was a free-text string summary.

The intent was:

- Make plans easily editable in small chunks
- Enable targeted replanning (change one step, not the whole thing)
- Give the orchestrator a natural-language summary it could reason over

These are reasonable goals. The implementation turned out to be the wrong way
to achieve them.

---

## Finding 1: Incremental plan building is the worst of both worlds

The core problem: **incremental tool-based planning conflates plan
representation with plan editing**.

When a planner calls `create_plan()` → `add_plan_section()` → `add_plan_step()`
× N, it is not refining a plan — it is transcribing one it already formed
internally. Every tool call is redundant work: extra latency, extra tokens,
extra failure surface, for no improvement in plan quality.

The literature is fairly clear on this. Research on plan-and-execute agents
([LangChain, 2024](https://blog.langchain.com/planning-for-agents/);
[PLAN-AND-ACT, 2025](https://arxiv.org/pdf/2503.09572)) consistently shows that
**forcing the planner to reason over the complete task before taking action
produces better plans** than step-by-step tool-calling approaches. When a model
builds a plan incrementally through tools, it is not forced to think through
how later steps interact with earlier ones — it commits early and patches later.

One-shot plan emission also **dramatically reduces LLM calls**. Calling
`add_plan_step()` 6–8 times is 6–8 round trips to the API for work the model
could do in one.

The replanning concern — "what if we need to change just one step?" — is real
but was being solved at the wrong layer. The right design is:

> **One-shot plan generation + orchestrator-controlled replanning.**

If the executor hits a dead end, the orchestrator calls the planner again with
the current plan and the failure context, and the planner returns a revised
complete plan. This is more flexible than surgical step patching, because the
planner can restructure freely — it isn't constrained by the existing step IDs
and section boundaries.

**Conclusion**: Delete the 10 plan mutation tools. The planner returns a
complete `SpecialistPlan` in one call. Replanning = call the planner again.

---

## Finding 2: Constrained structured output degrades reasoning — but has a known fix

We switched all specialists from returning `str` to returning typed Pydantic
models. The risk here is real and documented.

Tam et al. (2024), [_Let Me Speak Freely?_](https://arxiv.org/html/2408.02442v1),
showed that constrained structured generation meaningfully degrades performance
on reasoning-intensive tasks. The mechanism:

> When constrained decoding enforces a JSON schema, high-probability tokens
> that violate the grammar are masked, and the remaining tokens are
> renormalized. This distorts the model's probability distribution in ways that
> produce syntactically valid but semantically degraded outputs.

See also: [_The Hidden Cost of Structure_ (RANLP 2025)](https://acl-bg.org/proceedings/2025/RANLP%202025/pdf/2025.ranlp-1.124.pdf)
and [CRANE (2025)](https://arxiv.org/html/2502.09061v3) for the theoretical
grounding.

The fix is well-established: **put a `reasoning: str` field first in every
structured output schema**. Because pydantic-ai generates fields in order, the
model fills `reasoning` with unconstrained text before it encounters any typed
or enumerated fields. This restores the chain-of-thought that constrained
decoding otherwise forecloses.

Every specialist output model in this refactor follows this pattern:

```python
class DiagnosticResult(BaseModel):
    reasoning: str          # Unconstrained — model thinks here
    verdict: DiagnosticVerdict  # Constrained — model commits here
    root_cause_model: Optional[str] = None
    ...
```

This is not a workaround — it is the approach recommended by the research.

**Conclusion**: Structured output is fine. Include `reasoning` first. The type
system benefits (reliable parsing, typed orchestrator access) outweigh the
degradation risk once you apply the mitigation.

---

## Finding 3: Free-text specialist returns were unreliable

The original system had specialists return a short free-text summary like:

> "CONFIRMED: Root cause is int_order_details (join fanout on email). Details
> saved in brief_abc123."

The orchestrator parsed this string to decide what to do next. This works until
it doesn't — the format varies, the brief_id can be missing, and the
orchestrator has no reliable way to extract the verdict, root cause model, or
recommendation without prompt-based parsing.

Structured output removes this ambiguity entirely. The orchestrator receives:

```json
{
  "verdict": "CONFIRMED",
  "root_cause_model": "int_order_details",
  "root_cause_explanation": "join fanout on email column",
  "recommendation": "Add QUALIFY ROW_NUMBER() OVER (...) = 1 to deduplicate",
  "brief_id": "brief_abc123"
}
```

The typed fields mean the orchestrator can branch on `verdict` reliably, pass
`root_cause_model` directly into the mechanic's task description, and reference
`brief_id` without scraping it from prose.

---

## Finding 4: Markdown remains the right format for inter-specialist content

We are _not_ removing context briefs. They still exist as the store for rich,
human-readable findings that flow from investigation specialists to the planner.
The planner calls `list_context_briefs()` / `get_context_brief()` and reads
`findings_markdown` — a format LLMs process naturally.

The research supports this. Markdown-structured content consistently outperforms
JSON/XML for LLM input tasks (see [Improving Agents, 2024](https://www.improvingagents.com/blog/best-input-data-format-for-llms/)).
The specialist's internal evidence dump (hypotheses, data findings, SQL
analysis, git history) is narrative by nature and is better represented in
markdown than in a schema.

The change is that specialists no longer _call_ `save_context_brief()` — the
streaming layer auto-generates the brief from the structured output fields. This
gives us both: a typed return for the orchestrator, and a readable artifact for
downstream specialists.

---

## Summary of design rules going forward

| Decision                                 | Rationale                                                                     |
| ---------------------------------------- | ----------------------------------------------------------------------------- |
| Specialists return typed Pydantic models | Reliable orchestrator access, type system enforcement                         |
| `reasoning` field is always first        | Mitigates constrained decoding degradation (Tam et al. 2024)                  |
| Plans emitted all at once                | One-shot planning produces better plans and fewer API calls                   |
| Replanning = call the planner again      | More flexible than surgical step patching; planner can restructure freely     |
| Context briefs stay as markdown          | Natural for LLM consumption; narrative content doesn't benefit from schema    |
| Streaming layer handles persistence      | Single responsibility; specialists focus on analysis, not artifact management |

---

## References

- Tam et al. (2024). [_Let Me Speak Freely? A Study on the Impact of Format Restrictions on Performance of Large Language Models_](https://arxiv.org/html/2408.02442v1)
- [_The Hidden Cost of Structure: How Constrained Decoding Affects LLM Reasoning_](https://acl-bg.org/proceedings/2025/RANLP%202025/pdf/2025.ranlp-1.124.pdf) (RANLP 2025)
- [_CRANE: Reasoning with Constrained LLM Generation_](https://arxiv.org/html/2502.09061v3) (2025)
- [_PLAN-AND-ACT: Improving Planning of Agents for Long-Horizon Tasks_](https://arxiv.org/pdf/2503.09572) (2025)
- LangChain. [_Planning for Agents_](https://blog.langchain.com/planning-for-agents/) (2024)
- [_Generating Structured Outputs from Language Models: Benchmark and Studies_](https://arxiv.org/html/2501.10868v1) (2025)
