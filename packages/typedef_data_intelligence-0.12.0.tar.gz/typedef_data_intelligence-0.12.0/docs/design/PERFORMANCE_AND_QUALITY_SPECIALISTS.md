# Design: Performance Analyst & Data Quality Enhancements

## Overview

This document outlines the design for two specialist enhancements:

1. **Performance Analyst** - A new specialist for query performance analysis and optimization
2. **Tester Enhancements** - Before/after data comparison tools for the existing tester specialist

## Motivation

### Performance Analyst

Currently, when performance issues are identified (e.g., "full outer join on millions of rows"), we can:

- ✅ Identify the pattern in SQL
- ✅ Warn about potential issues
- ❌ Quantify actual performance impact
- ❌ Benchmark before/after improvements
- ❌ Recommend optimal solutions based on data

**Example gap:** When reviewing `fct_active_users`, we noticed inefficient join patterns but couldn't:

- Show that the query takes 45 seconds vs. a 2-second alternative
- Compare warehouse credit consumption
- Prove that incremental materialization would reduce costs by 80%

### Tester Data Quality Enhancements

The tester runs dbt tests, but these only catch explicitly defined assertions. Missing capabilities:

- ❌ Sample actual data before/after changes
- ❌ Statistical comparison (distribution shifts, new nulls, outliers)
- ❌ Validate that "additive" changes truly don't alter existing columns
- ❌ Catch unintended side effects beyond test coverage

**Example gap:** Adding a column is "additive" but if the JOIN changes, existing columns might have different values. Current tester wouldn't catch this.

---

## Design: Performance Analyst Specialist

### Role Definition

```yaml
name: performance_analyst
description: >
  Analyzes query performance, identifies bottlenecks, and recommends optimizations.
  Uses query history, execution plans, and cost data to provide actionable insights.
```

### Tools

#### 1. `get_query_history`

Retrieves recent query executions for a model or pattern.

```python
async def get_query_history(
    ctx: RunContext[AgentDeps],
    model_name: Optional[str] = None,
    query_pattern: Optional[str] = None,
    time_range_hours: int = 24,
    limit: int = 50,
) -> ToolReturn:
    """
    Get query execution history from the warehouse.

    Args:
        model_name: dbt model name to find queries for (uses compiled SQL matching)
        query_pattern: SQL pattern to search for (e.g., "fct_revenue")
        time_range_hours: How far back to look (default 24h)
        limit: Max queries to return

    Returns:
        List of query executions with:
        - query_id
        - query_text (truncated)
        - execution_time_ms
        - bytes_scanned
        - rows_produced
        - warehouse_size
        - credits_used (Snowflake)
        - status (success/error)
        - user
        - timestamp
    """
```

**Implementation notes:**

- Snowflake: `SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY`
- BigQuery: `INFORMATION_SCHEMA.JOBS_BY_PROJECT`
- DuckDB: Not applicable (local, no history)

#### 2. `explain_query`

Gets the execution plan for a SQL query.

```python
async def explain_query(
    ctx: RunContext[AgentDeps],
    sql: str,
    analyze: bool = False,
) -> ToolReturn:
    """
    Get execution plan for a SQL query.

    Args:
        sql: The SQL query to explain
        analyze: If True, actually run the query and get real statistics
                 (WARNING: may be slow/expensive for large queries)

    Returns:
        Execution plan with:
        - plan_tree: Hierarchical plan structure
        - estimated_rows: Per-operator row estimates
        - estimated_cost: Relative cost units
        - warnings: Potential issues (full table scans, etc.)

        If analyze=True, also includes:
        - actual_rows: Real row counts
        - actual_time_ms: Real execution time per operator
        - bytes_spilled: Memory spill to disk
    """
```

**Implementation notes:**

- Snowflake: `EXPLAIN` or `EXPLAIN USING JSON`
- BigQuery: `EXPLAIN` (dry run) or actual execution with `INFORMATION_SCHEMA.JOBS`
- DuckDB: `EXPLAIN ANALYZE`

#### 3. `get_model_performance_summary`

Aggregates performance metrics for a model over time.

```python
async def get_model_performance_summary(
    ctx: RunContext[AgentDeps],
    model_name: str,
    time_range_days: int = 7,
) -> ToolReturn:
    """
    Get aggregated performance metrics for a dbt model.

    Returns:
        - avg_execution_time_ms
        - p50_execution_time_ms
        - p95_execution_time_ms
        - max_execution_time_ms
        - total_executions
        - total_bytes_scanned
        - total_credits_used
        - trend: "improving" | "stable" | "degrading"
        - anomalies: List of unusually slow runs
    """
```

#### 4. `compare_query_performance`

Benchmarks two SQL variants.

```python
async def compare_query_performance(
    ctx: RunContext[AgentDeps],
    original_sql: str,
    optimized_sql: str,
    sample_size: int = 10000,
    dry_run: bool = True,
) -> ToolReturn:
    """
    Compare performance of two SQL variants.

    Args:
        original_sql: The current/baseline query
        optimized_sql: The proposed improvement
        sample_size: Limit rows for safe testing
        dry_run: If True, only EXPLAIN, don't execute

    Returns:
        - original_plan: Execution plan for original
        - optimized_plan: Execution plan for optimized
        - estimated_improvement: Percentage improvement
        - recommendation: "proceed" | "verify" | "abort"
        - warnings: Any concerns about the optimization

        If dry_run=False:
        - original_time_ms: Actual execution time
        - optimized_time_ms: Actual execution time
        - actual_improvement: Real percentage improvement
    """
```

#### 5. `get_warehouse_costs`

Gets cost attribution data.

```python
async def get_warehouse_costs(
    ctx: RunContext[AgentDeps],
    model_name: Optional[str] = None,
    time_range_days: int = 7,
    group_by: str = "model",  # "model" | "user" | "day" | "warehouse"
) -> ToolReturn:
    """
    Get warehouse cost breakdown.

    Returns:
        - total_credits: Total credits consumed
        - cost_usd: Estimated cost in USD
        - breakdown: Cost by grouping dimension
        - top_expensive_queries: Highest cost individual queries
        - optimization_opportunities: Models with high cost/low value
    """
```

#### 6. `suggest_optimizations`

AI-powered optimization recommendations.

```python
async def suggest_optimizations(
    ctx: RunContext[AgentDeps],
    model_name: str,
) -> ToolReturn:
    """
    Analyze a model and suggest performance optimizations.

    Analyzes:
    - Current materialization vs. recommended
    - Join patterns and potential improvements
    - Clustering/partitioning opportunities
    - Incremental eligibility
    - Query patterns from history

    Returns:
        - current_state: Summary of current configuration
        - recommendations: Prioritized list of optimizations
        - estimated_impact: Expected improvement per recommendation
        - implementation_notes: How to apply each optimization
    """
```

### Specialist Configuration

```python
# specialists.py

PERFORMANCE_ANALYST_TOOLS = [
    # Query analysis
    get_query_history,
    explain_query,
    get_model_performance_summary,
    compare_query_performance,
    # Cost analysis
    get_warehouse_costs,
    # Recommendations
    suggest_optimizations,
    # Context (read-only)
    read_file,
    get_model_details,
    get_downstream_impact,
]
```

### Prompt Template

```yaml
# prompts/specialists/performance_analyst.yaml.j2

name: performance_analyst
description: >
  Analyzes query performance, identifies bottlenecks, and recommends optimizations.
  Uses execution plans, query history, and cost data to provide actionable insights.

model: anthropic:claude-haiku-4-5

prompt: |
  You are a PERFORMANCE ANALYST specialist focused on query optimization.

  ## Your Expertise
  - Reading and interpreting query execution plans
  - Identifying performance anti-patterns (Cartesian joins, full scans, etc.)
  - Recommending materialization strategies
  - Quantifying performance improvements with data
  - Cost optimization for cloud warehouses

  ## Tools Available
  - get_query_history: See how queries have been running
  - explain_query: Get execution plans
  - get_model_performance_summary: Aggregated metrics over time
  - compare_query_performance: Benchmark two SQL variants
  - get_warehouse_costs: Cost attribution
  - suggest_optimizations: AI-powered recommendations

  ## Analysis Workflow

  1. **Gather context**: Query history + current SQL + execution plan
  2. **Identify issues**: Full scans, expensive joins, data skew
  3. **Quantify impact**: Actual time/cost numbers, not just "slow"
  4. **Recommend solutions**: With expected improvement percentages
  5. **Validate**: Use compare_query_performance for before/after

  ## Key Anti-Patterns to Look For

  - Full outer joins on large tables (consider incremental)
  - Missing cluster keys on frequently filtered columns
  - Table materialization for models that could be incremental
  - Repeated subqueries that could be CTEs or pre-aggregated
  - Cross-joins (even implicit ones from missing join conditions)
  - SELECT * when only few columns needed
  - ORDER BY on large intermediate results

  ## Output Format

  Always provide:
  1. **Current State**: Metrics (time, cost, rows)
  2. **Issues Found**: Specific problems with evidence
  3. **Recommendations**: Prioritized by impact
  4. **Expected Improvement**: Quantified (e.g., "50% reduction in runtime")
  5. **Implementation**: Specific changes to make

  Never say "this might be slow" - prove it with data.
```

---

## Design: Tester Data Quality Enhancements

### New Tools for Existing Tester Specialist

Rather than creating a new specialist, we enhance the tester with before/after comparison capabilities.

#### 1. `snapshot_data`

Captures a sample of data for later comparison.

```python
async def snapshot_data(
    ctx: RunContext[AgentDeps],
    model_name: str,
    snapshot_id: str,
    sample_size: int = 1000,
    columns: Optional[List[str]] = None,
    where_clause: Optional[str] = None,
) -> ToolReturn:
    """
    Capture a snapshot of model data for later comparison.

    Args:
        model_name: The dbt model to snapshot
        snapshot_id: Unique identifier for this snapshot (e.g., "before_change")
        sample_size: Number of rows to sample
        columns: Specific columns to capture (default: all)
        where_clause: Optional filter (e.g., "date >= '2024-01-01'")

    Returns:
        - snapshot_id: The ID for reference
        - row_count: Total rows in model
        - sampled_rows: Number of rows captured
        - columns: List of columns captured
        - storage_path: Where snapshot is stored (temp)
        - stats: Per-column statistics (null_count, distinct_count, min, max)
    """
```

**Implementation notes:**

- Store snapshots in memory or temp files during session
- Use deterministic sampling (hash-based) for reproducibility
- Capture column statistics for quick comparison

#### 2. `compare_snapshots`

Compares two snapshots to detect changes.

```python
async def compare_snapshots(
    ctx: RunContext[AgentDeps],
    before_snapshot_id: str,
    after_snapshot_id: str,
    tolerance: float = 0.01,  # 1% tolerance for numeric comparisons
) -> ToolReturn:
    """
    Compare two data snapshots to detect changes.

    Args:
        before_snapshot_id: Snapshot taken before changes
        after_snapshot_id: Snapshot taken after changes
        tolerance: Acceptable variance for numeric columns

    Returns:
        - schema_changes:
            - added_columns: List of new columns
            - removed_columns: List of dropped columns
            - type_changes: Columns with changed types

        - row_count_change:
            - before: Row count before
            - after: Row count after
            - change_pct: Percentage change

        - column_changes: Per-column analysis
            - column_name:
                - null_count_before / after
                - distinct_count_before / after
                - value_distribution_shift: Boolean
                - sample_differences: Example rows that changed

        - data_drift_score: 0-100 score (0 = identical, 100 = completely different)
        - verdict: "no_changes" | "expected_changes" | "unexpected_changes"
        - concerns: List of potential issues found
    """
```

#### 3. `validate_additive_change`

Specifically validates that existing columns are unchanged.

```python
async def validate_additive_change(
    ctx: RunContext[AgentDeps],
    model_name: str,
    new_columns: List[str],
    sample_size: int = 1000,
) -> ToolReturn:
    """
    Validate that adding columns didn't change existing data.

    This is a convenience wrapper that:
    1. Identifies existing columns (excluding new_columns)
    2. Compares before/after for those columns only
    3. Flags any unexpected changes

    Args:
        model_name: The model that was modified
        new_columns: Columns that were intentionally added
        sample_size: Rows to compare

    Returns:
        - existing_columns: Columns checked
        - new_columns: Columns excluded from comparison
        - validation_passed: Boolean
        - changes_detected: Any unexpected changes in existing columns
        - sample_mismatches: Example rows where existing data differs
    """
```

#### 4. `detect_anomalies`

Statistical anomaly detection on model data.

```python
async def detect_anomalies(
    ctx: RunContext[AgentDeps],
    model_name: str,
    columns: Optional[List[str]] = None,
    time_column: Optional[str] = None,
    lookback_days: int = 30,
) -> ToolReturn:
    """
    Detect statistical anomalies in model data.

    Args:
        model_name: Model to analyze
        columns: Specific columns to check (default: all numeric)
        time_column: Column to use for time-series analysis
        lookback_days: Historical period for baseline

    Returns:
        - anomalies: List of detected anomalies
            - column: Affected column
            - type: "null_spike" | "value_spike" | "distribution_shift" | "cardinality_change"
            - severity: "low" | "medium" | "high"
            - details: Specific information
            - baseline: Expected value/range
            - actual: Observed value

        - summary:
            - columns_checked: Number of columns analyzed
            - anomalies_found: Total anomaly count
            - high_severity_count: Count of high severity
    """
```

### Updated Tester Tools

```python
# specialists.py

TESTER_TOOLS = [
    # Existing tools
    dbt_test,
    dbt_build,
    dbt_run,
    execute_query,
    preview_table,
    read_file,
    get_active_plan,
    get_plan,
    # NEW: Data quality tools
    snapshot_data,
    compare_snapshots,
    validate_additive_change,
    detect_anomalies,
]
```

### Updated Tester Prompt

Add to `prompts/specialists/tester.yaml.j2`:

````yaml
  ## Data Quality Validation (Beyond dbt Tests)

  In addition to running dbt tests, you can validate actual data:

  ### Before/After Comparison Workflow

  When validating changes that might affect existing data:

  1. **Before changes are made** (orchestrator should call you first):
     ```
     snapshot_data(model_name="fct_revenue", snapshot_id="before_change")
     ```

  2. **After changes are made**:
     ```
     snapshot_data(model_name="fct_revenue", snapshot_id="after_change")
     compare_snapshots(before_snapshot_id="before_change", after_snapshot_id="after_change")
     ```

  3. **For additive changes** (new columns only):
     ```
     validate_additive_change(model_name="fct_revenue", new_columns=["customer_segment"])
     ```

  ### Anomaly Detection

  Run statistical checks on any model:

  ```python
  detect_anomalies(model_name="fct_revenue", time_column="month")
  ```

  This catches:
- Sudden spikes in null values
- Unusual value distributions
- Cardinality changes (new categories appearing)
- Numeric outliers

### When to Use Data Quality Tools

  - **Always** for changes that modify JOINs or WHERE clauses
  - **Always** for changes to fact tables with financial data
  - **Recommended** for any change affecting >1000 rows
  - **Optional** for pure additive changes (new columns with no logic changes)
````

---

## Implementation Plan

### Phase 1: Tester Enhancements (Lower Risk)

1. Implement `snapshot_data` tool
   - In-memory storage for session
   - Hash-based deterministic sampling
   - Column statistics capture

2. Implement `compare_snapshots` tool
   - Schema comparison
   - Statistical comparison
   - Sample diff generation

3. Implement `validate_additive_change` convenience wrapper

4. Update tester prompt with usage guidance

5. Test with existing workflows

**Estimated effort:** 2-3 days

### Phase 2: Performance Analyst (Higher Complexity)

1. Implement warehouse-specific query history adapters
   - Snowflake adapter (query_history view)
   - BigQuery adapter (JOBS table)
   - DuckDB stub (not applicable)

2. Implement `explain_query` with plan parsing
   - Snowflake JSON plan parsing
   - BigQuery plan parsing
   - DuckDB EXPLAIN parsing

3. Implement aggregation tools
   - `get_model_performance_summary`
   - `get_warehouse_costs`

4. Implement `compare_query_performance`

5. Implement `suggest_optimizations` (LLM-powered)

6. Create specialist configuration and prompt

7. Add to orchestrator specialists list

**Estimated effort:** 5-7 days

### Phase 3: Integration

1. Update orchestrator prompts to use performance_analyst
2. Add performance analysis to planning workflow
3. Document usage patterns
4. Create example workflows

**Estimated effort:** 1-2 days

---

## Open Questions

1. **Snapshot storage**: In-memory vs. temp files vs. dedicated storage?
   - Recommendation: In-memory for session, with optional persistence for long-running reconciler

2. **Warehouse permissions**: Some tools require elevated access (query history, cost data)
   - Recommendation: Graceful degradation if permissions unavailable

3. **Cost calculation**: How to estimate USD cost from credits?
   - Recommendation: Configurable rate, default to Snowflake standard pricing

4. **Sampling strategy**: Random vs. hash-based vs. stratified?
   - Recommendation: Hash-based on primary key for reproducibility

5. **Performance analyst scope**: Should it also recommend dbt config changes?
   - Recommendation: Yes, but flag as "requires coder to implement"

---

## Success Metrics

### Performance Analyst Metrics

- Can quantify query performance with actual numbers (not just "might be slow")
- Reduces time to identify optimization opportunities by 80%
- Provides before/after benchmarks for all optimization recommendations

### Tester Enhancements

- Catches data changes that dbt tests miss
- Reduces "additive change broke existing data" incidents to near-zero
- Provides confidence score for changes beyond "tests passed"

---

## References

- [Snowflake Query History](https://docs.snowflake.com/en/sql-reference/account-usage/query_history)
- [BigQuery JOBS View](https://cloud.google.com/bigquery/docs/information-schema-jobs)
- [dbt Materialization Strategies](https://docs.getdbt.com/docs/build/materializations)
