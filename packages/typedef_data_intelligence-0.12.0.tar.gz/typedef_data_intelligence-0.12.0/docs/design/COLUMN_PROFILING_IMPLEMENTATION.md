# Column Profiling: Implementation Notes

This document describes the implementation of Tier 1 bulk column profiling and
its integration with the PK/FK inference pipeline. It is a companion to the
design spec in `COLUMN_PROFILING.md`.

Commit: `d6b4cea0` on `feature/scope-level-column-lineage`

## Scope

This implementation covers Tier 1 (single-column profiling) from the design
spec. Tier 2 (composite keys) and Tier 3 (cross-table value overlap) are
deferred — the Tier 1 results already exceed the estimated impact (760 PK
candidates vs. 500-800 estimated; 685 FK edges vs. 0 previously).

## What Changed

19 files changed across 10 logical areas. The changes fall into three
categories: schema extensions, profiling engine rewrite, and signal pipeline
fixes.

### 1. Schema Extensions (non-breaking)

**Files**: `protocol.py`, `profiling.py` (graph model), `schema.yaml`

Five new `Optional` fields on `ColumnProfile`:

| Field              | Type    | Source                                | Purpose                             |
| ------------------ | ------- | ------------------------------------- | ----------------------------------- |
| `uniqueness_ratio` | `float` | `APPROX_COUNT_DISTINCT / row_count`   | PK uniqueness signal                |
| `null_rate`        | `float` | `null_count / row_count`              | PK completeness signal              |
| `value_pattern`    | `str`   | Python classifier on sampled rows     | Pattern-based PK evidence           |
| `is_monotonic`     | `bool`  | `(MAX - MIN) / (row_count - 1) ~ 1.0` | Surrogate key detection             |
| `length_stddev`    | `float` | `STDDEV(LENGTH(col))`                 | Filter: high variance = unlikely PK |

All fields are `Optional` with `None` default, so existing profiles load without
migration. The protocol dataclass (`backends/data_query/protocol.py`) and graph
node model (`backends/lineage/models/profiling.py`) mirror the same five fields.
`schema.yaml` declares them for schema-aware backends.

**Decision: `Optional` everywhere.** The alternative was to make fields required
and backfill existing profiles. We chose `Optional` because: (a) profiles can be
collected incrementally — not all phases run every time; (b) the signal pipeline
(pass3) already handles `None` with fallback logic; (c) no migration needed.

### 2. HasProfile Edge Fix

**File**: `backends/lineage/models/edges.py`

Added `(DbtModel, TableProfile)` and `(DbtColumn, ColumnProfile)` to
`HasProfile.allowed_pairs`.

**Why this was needed.** The profiling loader creates edges from logical nodes
(`DbtModel`, `DbtColumn`) to profile nodes, but `HasProfile.allowed_pairs` only
listed physical node types (`PhysicalTable`, `PhysicalColumn`, etc.). The graph
accepted these edges because `create_edge()` doesn't call `validate_nodes()` at
runtime, but the schema was misleading. Any tooling that inspects `allowed_pairs`
for schema validation would reject these edges. Adding the pairs makes the schema
honest about what the loader creates.

**Why DbtModel, not PhysicalTable?** The profiling loader runs in the context of
dbt models. It knows the model's `unique_id` (e.g., `model.analytics.fct_revenue`)
and profiles the corresponding warehouse table. Linking from `DbtModel` keeps the
graph path simple: `DbtModel -[:HAS_PROFILE]-> TableProfile`. Routing through
`PhysicalTable` would require a join through `BUILDS` edges, adding complexity
for no benefit since pass3 queries profiles via `DbtColumn`, not `PhysicalColumn`.

### 3. Bulk `profile_table()` Rewrite

**File**: `snowflake_native_backend.py` (lines 1144-1422)

The original `profile_table()` ran N+1 queries per table: one `COUNT(*)`, then
one `profile_column()` call per column. Each `profile_column()` ran 3-4 queries
(distinct count, null count, numeric stats or string stats, top-K). For a table
with 30 columns, that was ~120 queries.

The rewrite uses a phased approach with bulk queries:

#### Phase 0: Metadata (free, 2 queries)

```sql
-- Row count from metadata (no table scan)
SELECT ROW_COUNT FROM {db}.INFORMATION_SCHEMA.TABLES
WHERE TABLE_SCHEMA = '{schema}' AND TABLE_NAME = '{table}'

-- Column types from get_table_schema() (reuses existing method)
```

Row count from `INFORMATION_SCHEMA` avoids a `COUNT(*)` table scan. If the
metadata row count is 0 (happens for views and some transient tables), we fall
back to `SELECT COUNT(*)`.

**Decision: metadata-first, fallback to scan.** Views don't have `ROW_COUNT` in
`INFORMATION_SCHEMA.TABLES`. Rather than special-casing views vs. tables, we try
metadata first and fall back. The fallback hits ~5% of tables in practice (views
only).

#### Phase 1: Bulk stats (ceil(N/50) queries)

For each chunk of up to 50 columns, one wide `SELECT`:

```sql
SELECT
  APPROX_COUNT_DISTINCT("col1") AS "col1__approx_distinct",
  COUNT_IF("col1" IS NULL)      AS "col1__null_count",
  MIN("col1")                   AS "col1__min",       -- numeric only
  MAX("col1")                   AS "col1__max",       -- numeric only
  STDDEV(LENGTH("col1"))        AS "col1__len_stddev", -- string only
  -- ... repeat for each column in chunk
FROM {table}
```

With ~4-6 expressions per column and 50 columns per chunk, each query has
200-300 expressions — well within Snowflake's limits. Sampling is supported via
`TABLESAMPLE ({sample_size} ROWS)`.

**Decision: `APPROX_COUNT_DISTINCT` over `COUNT(DISTINCT)`.** HyperLogLog on
Snowflake's columnar storage is sublinear in cost and produces <2% error. For PK
inference, we only care whether the ratio is above 0.99, so the approximation is
more than sufficient. The exact count would be 10-100x more expensive on large
tables.

**Decision: chunk size of 50.** Snowflake has no hard limit on SELECT expressions,
but very wide queries (500+ expressions) can hit optimizer timeouts. 50 columns
per chunk keeps each query under 300 expressions. The chunk size is configurable
via `ProfilingConfig.chunk_size`.

**Decision: type detection via string matching on `DATA_TYPE`.** We check for
numeric types (`NUMBER`, `INT`, `BIGINT`, `FLOAT`, etc.) and string types
(`VARCHAR`, `TEXT`, `CHAR`, `STRING`) by substring match on the data type string
from `INFORMATION_SCHEMA`. This is fragile if Snowflake introduces new type names,
but covers all types present in the 267 tables we profile. The alternative (a
whitelist lookup table) adds complexity for hypothetical future types. If a type
isn't recognized as numeric or string, it simply gets fewer metrics (no MIN/MAX,
no STDDEV(LENGTH)), which is safe.

#### Phase 2: Derived metrics (Python, no queries)

From Phase 1 results, compute:

```python
uniqueness_ratio = approx_distinct / row_count
null_rate = null_count / row_count
is_monotonic = 0.9 <= (max - min) / (row_count - 1) <= 1.1  # numeric only
```

**Decision: monotonicity tolerance of 0.9-1.1.** A perfectly sequential column
has `(MAX - MIN) / (row_count - 1) = 1.0`. We use a 10% tolerance band because:
(a) `APPROX_COUNT_DISTINCT` can slightly inflate/deflate row count; (b) gaps in
sequences (deleted rows) shift the ratio slightly; (c) auto-increment columns
that start from a non-zero seed still have ratio ~1.0. In practice, only 6 of
7,155 columns passed this check — the signal is highly specific.

#### Phase 3: Value pattern detection (1 query)

Sample 100 rows for columns with `uniqueness_ratio > 0.8`:

```sql
SELECT {candidate_cols} FROM {table} TABLESAMPLE (100 ROWS)
```

The `_classify_value_pattern()` function runs in Python on the sample:

| Pattern           | Detection                                              | Threshold        |
| ----------------- | ------------------------------------------------------ | ---------------- |
| `uuid`            | Regex `^[0-9a-f]{8}-[0-9a-f]{4}-...`                   | >= 80% of values |
| `sequential`      | All values parse as integers, sorted diffs all equal 1 | 100%             |
| `composite`       | Values contain `_` or `-` separators (non-UUID)        | >= 80%           |
| `boolean_like`    | <= 2 distinct values                                   | exact            |
| `low_cardinality` | <= 10 distinct values in sample                        | exact            |
| `mixed`           | default                                                | fallback         |

**Decision: 100-row sample.** Pattern classification doesn't need statistical
rigor — it's a heuristic tier. 100 rows is enough to detect UUID format or
sequential integers with high confidence. Larger samples add query cost for
marginal accuracy gain. The sample size is configurable via
`ProfilingConfig.pattern_sample_size`.

**Decision: uniqueness_ratio > 0.8 filter.** Pattern detection is only useful
for high-uniqueness columns (potential PKs). Low-cardinality columns won't be PK
candidates regardless of their pattern. The 0.8 threshold avoids wasting query
time on columns that will never cross the 0.5 PK confidence threshold.

**Decision: classify in Python, not SQL.** UUID regex in Snowflake's `REGEXP`
works but is harder to test and maintain. The Python classifier is unit-tested
with 9 test cases (`test_bulk_profiling.py`) and easy to extend.

#### Phase 4: Top-K (off by default)

Per-column `GROUP BY` queries for top frequent values. Gated by
`ProfilingConfig.collect_top_k = False` because it's expensive (N queries) and
not needed for PK inference. Available for agent tools that want value
distributions.

### 4. Profiling Loader Updates

**File**: `ingest/static_loaders/profiling/loader.py`

Changes:

1. **New fields passed through.** The `_load_column_profile()` method now passes
   all five new fields from the protocol `ColumnProfile` to the graph
   `ColumnProfileNode`.

2. **Config-driven phase control.** `profile_models_parallel()` accepts an
   optional `ProfilingConfig` and forwards `collect_stats`, `detect_patterns`,
   `collect_top_k`, `chunk_size`, and `pattern_sample_size` to each
   `profile_table()` call. When no config is provided, defaults match the
   previous behavior (stats on, patterns on, top-K off).

3. **Error handling.** Changed from verbose-only `print()` to `logger.warning()`
   with `exc_info=True`. Profiling failures for individual tables are now always
   logged with full tracebacks, regardless of verbose mode. Previously, failures
   were silently swallowed unless `--verbose` was passed.

4. **Gather result handling.** `asyncio.gather(..., return_exceptions=True)`
   results are now checked for `BaseException` instances (in addition to tuple
   results), and logged appropriately.

### 5. Pass 3: Query Path Fix + New Signals

**File**: `ingest/static_loaders/key_lineage/pass3_pk_signals.py`

**The bug.** The original `collect_profiling_signals()` queried:

```cypher
MATCH (tp:TableProfile)-[:HAS_COLUMN_PROFILE]->(cp:ColumnProfile)
      <-[:HAS_PROFILE]-(pc:PhysicalColumn)-[:DERIVES_FROM]->(c:DbtColumn)
```

This path goes through `PhysicalColumn`, which the loader never links to. The
loader creates `DbtColumn -[:HAS_PROFILE]-> ColumnProfile`, not
`PhysicalColumn -[:HAS_PROFILE]-> ColumnProfile`. The query returned zero rows.

**The fix.** Replaced with:

```cypher
MATCH (c:DbtColumn)-[:HAS_PROFILE]->(cp:ColumnProfile)
      <-[:HAS_COLUMN_PROFILE]-(tp:TableProfile)
WHERE tp.row_count > 0
```

This matches the actual graph structure the loader creates. The `WHERE` clause
filters zero-row tables (division by zero in ratio computation).

**New signals.** Three new signal types extracted from the new ColumnProfile
fields:

| Signal                | Condition                       | Tier   |
| --------------------- | ------------------------------- | ------ |
| `profiling_monotonic` | `is_monotonic == true`          | silver |
| `pattern_uuid`        | `value_pattern == "uuid"`       | silver |
| `pattern_sequential`  | `value_pattern == "sequential"` | silver |

**Backward compatibility.** If `uniqueness_ratio` is `None` (old profiles), the
code falls back to computing `distinct_count / row_count`. Same for `null_rate`
— falls back to checking `null_count == 0`.

### 6. Pass 4: New Signal Weights

**File**: `ingest/static_loaders/key_lineage/pass4_pk_scoring.py`

Three new entries in `SIGNAL_WEIGHTS`:

```python
"profiling_monotonic": 0.15,
"pattern_uuid":        0.20,
"pattern_sequential":  0.15,
```

**Weight rationale:**

- `profiling_monotonic` at 0.15: Monotonicity is suggestive but not conclusive.
  Auto-increment columns are monotonic, but so are timestamp columns and running
  totals. Low weight ensures it boosts but doesn't independently cross the 0.5
  threshold.

- `pattern_uuid` at 0.20: UUID columns are almost always primary keys or unique
  identifiers. Higher weight than monotonicity because the pattern is more
  specific. Combined with `profiling_unique` (0.35), a UUID column reaches
  0.55 — crossing the threshold without any dbt tests.

- `pattern_sequential` at 0.15: Sequential integers are strong surrogate key
  indicators, but the detection is based on a 100-row sample which may
  miss gaps. Same weight as monotonicity. Combined with `profiling_unique`
  (0.35) and `profiling_not_null` (0.35), reaches 0.85.

**Score examples with new signals:**

| Column type                       | Signals                                                     | Score |
| --------------------------------- | ----------------------------------------------------------- | ----- |
| UUID column, no nulls             | profiling_unique + profiling_not_null + pattern_uuid        | 0.90  |
| Auto-increment int                | profiling_unique + profiling_not_null + profiling_monotonic | 0.85  |
| `_id` column, unique, not null    | profiling_unique + profiling_not_null + naming_heuristic    | 0.85  |
| `_id` column, unique only         | profiling_unique + naming_heuristic                         | 0.50  |
| dbt tested (unique + not_null)    | dbt_unique_test + dbt_not_null_test                         | 0.90  |
| Profiling-only, unique + not_null | profiling_unique + profiling_not_null                       | 0.70  |

### 7. Configuration

**File**: `ingest/config.py`

`ProfilingConfig` extended with granular phase controls:

```python
class ProfilingConfig(BaseModel):
    enabled: bool = False        # Master switch (opt-in)
    collect_stats: bool = True   # Phase 1-2 bulk stats
    detect_patterns: bool = True # Phase 3 value patterns
    collect_top_k: bool = False  # Phase 4 top-K (expensive)
    max_workers: int = 8
    sample_size: int = 10000
    pattern_sample_size: int = 100
    chunk_size: int = 50
```

**Decision: profiling off by default.** Profiling runs warehouse queries that
cost money. Other sync operations (manifest parsing, lineage building, semantic
analysis) are either free or use cached LLM responses. Profiling must be
explicitly enabled in `config.yaml`.

**Decision: `collect_top_k` off by default.** Top-K values require per-column
`GROUP BY` queries — the most expensive profiling operation. They're useful for
agent tools (inspecting value distributions) but not needed for PK inference.
Default-off keeps bulk sync fast; users who want value distributions can enable
it.

### 8. Integration Wiring

**File**: `integration.py`

Three fixes to the sync orchestration:

1. **Profiling decoupled from `skip_all_derived`.** Previously, `_build_worklists()`
   returned empty lists when `skip_all_derived=True` (incremental sync with no
   manifest changes). This meant profiling never ran on incremental syncs, even
   when the graph had zero profiles. Fixed by checking `_has_existing_profiles()`
   — if no profiles exist, the profiling worklist is built regardless of
   `skip_all_derived`.

   **Why this matters.** Profiling depends on warehouse data availability, not dbt
   manifest changes. On first sync with profiling enabled, the manifest hasn't
   changed (it was already loaded on a previous sync), but profiles don't exist
   yet. Without this fix, enabling profiling after initial setup would never
   collect data unless the user also modified a dbt model.

2. **Early return gate.** Line 641 had `if plan.skip_all_derived:` which returned
   before reaching `_execute_derived_work()`. Changed to
   `if plan.skip_all_derived and not plan.models_to_profile:` so profiling-only
   runs still execute.

3. **Key lineage condition.** Key lineage now runs when profiling populated new
   data (`plan.models_to_profile` is non-empty), even if semantic analysis was
   skipped. Previously, key lineage only ran when `skip_all_derived` was False.

**File**: `typedef_cli.py`

Passed `key_lineage_config=pop.key_lineage` to `load_full_lineage()`. This was
missing — the CLI read key lineage config from YAML but never forwarded it.

**File**: `progress.py`

Added `SyncPhase.KEY_LINEAGE = "Building Key Lineage"` and wired
`tracker.phase_start/phase_complete` around `_run_key_lineage()` in
`integration.py`. Key lineage was previously invisible in the progress display.

## Results

Measured on the `sf_analytics` graph (Mattermost dbt project, 302 models):

| Metric                         | Before                | After       | Change |
| ------------------------------ | --------------------- | ----------- | ------ |
| TableProfile nodes             | 0                     | 267         | new    |
| ColumnProfile nodes            | 0                     | 7,155       | new    |
| PK candidates                  | 52                    | 760         | 14.6x  |
| IdentityClasses with PK member | 52 (1.7%)             | 385 (12.3%) | 7.4x   |
| INFERRED_FK edges              | 0                     | 685         | new    |
| Total PK signals               | ~200 (dbt tests only) | 1,877       | 9.4x   |

Signal breakdown (1,877 total across 760 candidates):

| Signal                | Count | % of total |
| --------------------- | ----- | ---------- |
| `profiling_not_null`  | 733   | 39%        |
| `profiling_unique`    | 484   | 26%        |
| `naming_heuristic`    | 298   | 16%        |
| `dbt_not_null_test`   | 194   | 10%        |
| `dbt_unique_test`     | 101   | 5%         |
| `grain_member`        | 59    | 3%         |
| `profiling_monotonic` | 6     | <1%        |
| `pattern_sequential`  | 2     | <1%        |

New profiling fields populated:

| Field              | Non-null count | Coverage                           |
| ------------------ | -------------- | ---------------------------------- |
| `uniqueness_ratio` | 7,155          | 100%                               |
| `null_rate`        | 7,155          | 100%                               |
| `length_stddev`    | 1,999          | 28% (string columns only)          |
| `is_monotonic`     | 883            | 12% (numeric columns only)         |
| `value_pattern`    | 651            | 9% (columns with uniqueness > 0.8) |

## What's Not Implemented

1. **Tier 2: Composite key detection.** The design spec describes
   `APPROX_COUNT_DISTINCT((A, B))` for column pairs. Deferred because single-column
   PKs cover the majority of use cases in the Mattermost dataset. Composite keys
   are most relevant for bridge/junction tables — a smaller population that can be
   addressed later.

2. **Tier 3: Cross-table value overlap.** FK inference via value set intersection.
   Deferred because the existing pass5 FK inference (name-based matching within
   identity classes) already produces 685 edges. Value overlap would strengthen
   confidence on existing edges rather than finding new ones.

3. **Stability signal.** The design spec describes comparing profiles across two
   time points to detect unstable uniqueness ratios. Deferred because it requires
   profiling storage for multiple snapshots, and the current single-snapshot
   approach already produces good results.

4. **`pattern_uuid` signal.** Zero occurrences in the current dataset. The
   classifier works (tested in `test_bulk_profiling.py`), but the Mattermost
   project uses integer surrogate keys, not UUIDs. The signal will activate in
   projects that use UUID primary keys.

## Tests

| Test file                  | Cases | What it covers                                                                                                                  |
| -------------------------- | ----- | ------------------------------------------------------------------------------------------------------------------------------- |
| `test_bulk_profiling.py`   | 9     | `_classify_value_pattern()`: UUID, sequential, composite, boolean_like, low_cardinality, mixed, threshold edge cases            |
| `test_loader.py`           | 2     | Profiling loader: new fields persisted in graph; backward compat (old profiles without new fields)                              |
| `test_pass3_pk_signals.py` | +6    | pass3: profiling signals with new fields, monotonic, uuid pattern, sequential pattern, backward compat fallback, empty profiles |
| `test_pass4_pk_scoring.py` | +4    | pass4: new signal weights (monotonic, uuid, sequential), combined score crossing threshold                                      |

All 1,322 tests pass. Lint clean (`ruff check`).
