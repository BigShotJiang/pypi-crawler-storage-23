# Generic Report Schema Design

This document describes the cross-platform BI report schema that enables unified lineage tracking across Salesforce, Looker, PowerBI, Tableau, and other BI platforms.

## Overview

The Generic Report Schema introduces a **3-layer architecture** for modeling reports:

1. **Report** (canonical spine) - System-agnostic report identity
2. **Native instances** (SfReport, LookerLook, etc.) - Vendor-specific report nodes
3. **ReportIR** - Common intermediate representation with field-level lineage

This design enables:

- **Cross-platform queries**: Find all reports regardless of source system
- **Unified lineage**: Track data flow from warehouse columns to report fields
- **Impact analysis**: Answer "what reports break if I change this column?"
- **Version tracking**: Audit report changes over time

## Architecture

```text
                         ┌─────────────────────┐
                         │      Report         │  ← Canonical spine
                         │  (system, native_id)│
                         └──────────┬──────────┘
                                    │
              ┌─────────────────────┼─────────────────────┐
              │                     │                     │
              ▼                     ▼                     ▼
     NATIVE_INSTANCE_OF        HAS_IR          HAS_NATIVE_DEFINITION
              │                     │                     │
              ▼                     ▼                     ▼
    ┌─────────────────┐   ┌─────────────────┐   ┌─────────────────────┐
    │    SfReport     │   │    ReportIR     │   │NativeReportDefinition│
    │  (existing)     │   │  (base_entity,  │   │  (format, content)   │
    └─────────────────┘   │   grain, etc.)  │   └─────────────────────┘
                          └────────┬────────┘
                                   │
         ┌─────────────┬───────────┼───────────┬─────────────┐
         ▼             ▼           ▼           ▼             ▼
    HAS_IR_FIELD  HAS_IR_FILTER  HAS_IR_JOIN  HAS_IR_GROUPBY  ...
         │             │           │
         ▼             ▼           ▼
  ┌──────────────┐ ┌──────────┐ ┌──────────┐
  │ReportIRField │ │ReportIR  │ │ReportIR  │
  │(FieldRef)    │ │Filter    │ │Join      │
  └──────┬───────┘ └──────────┘ └──────────┘
         │
         ▼ DERIVES_FROM
  ┌──────────────┐
  │  DbtColumn   │ ← Lineage connection
  └──────────────┘
```

## Design Principles

1. **Canonical Spine Pattern**: The `Report` node serves as the system-agnostic identity. Vendor-specific nodes (SfReport, future LookerLook) link via `NATIVE_INSTANCE_OF`.

2. **IR Separation**: The `ReportIR` captures the semantic structure of the report independent of presentation details. This enables comparison across platforms.

3. **Field-Level Lineage**: `ReportIRField` nodes connect to upstream `DbtColumn`, `PhysicalColumn`, or `SfField` nodes via `DERIVES_FROM` edges.

4. **Versioning Built-In**: `ReportRevision` nodes track changes over time, each linking to an IR snapshot.

5. **Native Definition Preservation**: Raw vendor definitions (JSON, XML, LookML) are stored in `NativeReportDefinition` for debugging and reference.

## Schema: Node Types

### Phase 1: Core Schema

| Node                     | Description                  | ID Format                       |
| ------------------------ | ---------------------------- | ------------------------------- |
| `Report`                 | Canonical report spine       | `report::{system}::{native_id}` |
| `ReportIR`               | Intermediate representation  | `{report_id}.ir`                |
| `ReportIRField`          | Field reference with lineage | `{ir_id}.field.{alias}`         |
| `NativeReportDefinition` | Raw vendor definition        | `{report_id}.def.{system}`      |
| `ReportRevision`         | Version snapshot             | `{report_id}@{revision_number}` |

### Phase 2: Full IR Structure

| Node                  | Description             | ID Format                        |
| --------------------- | ----------------------- | -------------------------------- |
| `ReportIRFilter`      | Filter predicate        | `{ir_id}.filter.{index}`         |
| `ReportIRJoin`        | Join specification      | `{ir_id}.join.{index}`           |
| `ReportIRGroupBy`     | Grouping configuration  | `{ir_id}.groupby.{field_alias}`  |
| `ReportIRBucket`      | Bucketing/binning       | `{ir_id}.bucket.{bucket_name}`   |
| `ReportIRFormula`     | Calculated field        | `{ir_id}.formula.{formula_name}` |
| `ReportIRHighlight`   | Conditional formatting  | `{ir_id}.highlight.{index}`      |
| `ReportIRCrossFilter` | Exception report filter | `{ir_id}.crossfilter.{index}`    |

## Schema: Edge Types

### Phase 1 Edges

| Edge                    | From → To                       | Description                            |
| ----------------------- | ------------------------------- | -------------------------------------- |
| `NATIVE_INSTANCE_OF`    | SfReport → Report               | Links vendor report to canonical spine |
| `HAS_IR`                | Report → ReportIR               | Report has intermediate representation |
| `HAS_NATIVE_DEFINITION` | Report → NativeReportDefinition | Report has raw vendor definition       |
| `HAS_IR_FIELD`          | ReportIR → ReportIRField        | IR contains field reference            |
| `HAS_REVISION`          | Report → ReportRevision         | Report has revision history            |
| `REVISION_HAS_IR`       | ReportRevision → ReportIR       | Revision links to IR snapshot          |
| `MAPS_TO_NATIVE_FIELD`  | ReportIRField → SfReportColumn  | IR field maps to vendor column         |
| `REPORT_DEPENDS_ON`     | Report → SfObject/DbtModel/etc  | Report depends on data entity          |

### Phase 2 Edges

| Edge                  | From → To                      | Description                   |
| --------------------- | ------------------------------ | ----------------------------- |
| `HAS_IR_FILTER`       | ReportIR → ReportIRFilter      | IR has filter predicate       |
| `HAS_IR_JOIN`         | ReportIR → ReportIRJoin        | IR has join specification     |
| `HAS_IR_GROUPBY`      | ReportIR → ReportIRGroupBy     | IR has grouping configuration |
| `HAS_IR_BUCKET`       | ReportIR → ReportIRBucket      | IR has bucket configuration   |
| `HAS_IR_FORMULA`      | ReportIR → ReportIRFormula     | IR has calculated field       |
| `HAS_IR_HIGHLIGHT`    | ReportIR → ReportIRHighlight   | IR has conditional formatting |
| `HAS_IR_CROSS_FILTER` | ReportIR → ReportIRCrossFilter | IR has cross-filter           |

### Extended DERIVES_FROM

The `DERIVES_FROM` edge was extended to support report field lineage:

| From            | To                  |
| --------------- | ------------------- |
| `ReportIRField` | `DbtColumn`         |
| `ReportIRField` | `PhysicalColumn`    |
| `ReportIRField` | `SfField`           |
| `ReportIRField` | `InferredMeasure`   |
| `ReportIRField` | `InferredDimension` |

## Node Properties

### Report

```yaml
id: str # report::{system}::{native_id}
name: str # Display name
system: str # salesforce, looker, powerbi, tableau
native_id: str # ID in source system
title: str # Report title
description: str # Report description
folder: str # Folder/directory path
url: str # Link to report in source system
status: str # draft, published, archived
owner: str # Report owner
created_at: str # ISO 8601 timestamp
updated_at: str # ISO 8601 timestamp
ir_hash: str # Hash of current IR for change detection
```

### ReportIR

```yaml
id: str # {report_id}.ir
name: str # IR name
report_id: str # Parent Report ID
ir_version: str # IR schema version
canonical_hash: str # Content hash for comparison
report_format: str # tabular, summary, matrix
base_entity: str # JSON - primary entity/dataset
grain_human: str # Human-readable grain description
time_logic: str # JSON - time filtering logic
created_at: str # ISO 8601 timestamp
```

### ReportIRField

```yaml
id: str # {ir_id}.field.{alias}
name: str # Field display name
ir_id: str # Parent ReportIR ID
alias: str # Field alias/key
field_type: str # dimension, measure, time, filter_only
role: str # grouping, aggregation, display, filter

# FieldRef abstraction
ref_type: str # physical, semantic, native, expression
ref_expression: str # Expression if computed
ref_entity: str # Source entity reference
ref_field: str # Source field reference

# Type-specific properties
aggregation: str # SUM, COUNT, AVG, etc.
sort_order: str # asc, desc
axis: str # row, column (for matrix reports)
granularity: str # day, week, month, quarter, year
label: str # Display label
format: str # Number/date format
decimal_places: int # Decimal precision
```

### ReportIRFilter

```yaml
id: str # {ir_id}.filter.{index}
name: str # Filter name
ir_id: str # Parent ReportIR ID
index: int # Filter sequence
field_ref: str # Reference to filtered field
operator: str # equals, not_equals, greater_than, contains, etc.
value: str # Filter value (JSON for complex values)
value_type: str # literal, field, parameter
group_id: str # For AND/OR grouping
group_operator: str # AND, OR
is_runtime: bool # True if accepts runtime parameters
```

### ReportIRFormula

```yaml
id: str # {ir_id}.formula.{formula_name}
name: str # Formula display name
ir_id: str # Parent ReportIR ID
formula_name: str # Formula identifier
formula_type: str # row, summary
expression: str # Formula expression
return_type: str # number, currency, percent, text
decimal_places: int # Decimal precision
format: str # Output format
description: str # Formula description
```

## Example Queries

### Find all reports across platforms

```cypher
MATCH (r:Report)
RETURN r.system, r.title, r.status
ORDER BY r.system, r.title
```

### Find Salesforce reports with their canonical Report

```cypher
MATCH (sf:SfReport)-[:NATIVE_INSTANCE_OF]->(r:Report)
RETURN sf.name, r.id, r.status
```

### Impact analysis: What reports use a specific column?

```cypher
MATCH (f:ReportIRField)-[:DERIVES_FROM]->(c:DbtColumn {name: 'amount'})
MATCH (ir:ReportIR)-[:HAS_IR_FIELD]->(f)
MATCH (r:Report)-[:HAS_IR]->(ir)
RETURN r.title, r.system, f.alias, f.field_type
```

### Find reports with summary formulas

```cypher
MATCH (r:Report)-[:HAS_IR]->(ir:ReportIR)-[:HAS_IR_FORMULA]->(f:ReportIRFormula)
WHERE f.formula_type = 'summary'
RETURN r.title, f.formula_name, f.expression
```

### Find reports grouped by a specific field

```cypher
MATCH (r:Report)-[:HAS_IR]->(ir:ReportIR)-[:HAS_IR_GROUPBY]->(g:ReportIRGroupBy)
WHERE g.field_alias = 'stage'
RETURN r.title, g.axis, g.sequence
```

### Trace report field lineage to source

```cypher
MATCH (r:Report)-[:HAS_IR]->(ir:ReportIR)-[:HAS_IR_FIELD]->(f:ReportIRField)
MATCH path = (f)-[:DERIVES_FROM*1..3]->(source)
WHERE source:DbtColumn OR source:SfField
RETURN r.title, f.alias, [n IN nodes(path) | n.name] AS lineage_path
```

## Implementation

### Files Modified/Created

| File                          | Changes                                           |
| ----------------------------- | ------------------------------------------------- |
| `models/report.py`            | New file with 12 Pydantic model classes           |
| `models/edges.py`             | Added 15 edge classes for report relationships    |
| `models/__init__.py`          | Exported all new models and edges                 |
| `schema.yaml`                 | Added 12 node definitions and 15 edge definitions |
| `types.py`                    | Added NodeLabel and EdgeType enums                |
| `tests/test_report_models.py` | 63 unit tests for all components                  |

### Pydantic Models

All node types are implemented as Pydantic models inheriting from `BaseNode`:

```python
from lineage.backends.lineage.models import (
    # Phase 1
    Report, ReportIR, ReportIRField, NativeReportDefinition, ReportRevision,
    # Phase 2
    ReportIRFilter, ReportIRJoin, ReportIRGroupBy, ReportIRBucket,
    ReportIRFormula, ReportIRHighlight, ReportIRCrossFilter,
)

# Create a report
report = Report(
    name="Pipeline by Stage",
    system="salesforce",
    native_id="00O123456789",
    title="Pipeline by Stage",
    status="published",
)
print(report.id)  # report::salesforce::00O123456789

# Create IR
ir = ReportIR(
    name="Pipeline IR",
    report_id=report.id,
    report_format="summary",
    grain_human="per opportunity, grouped by stage",
)
print(ir.id)  # report::salesforce::00O123456789.ir
```

### Edge Classes

All edges are implemented with pair-based validation:

```python
from lineage.backends.lineage.models import (
    NativeInstanceOf, HasIR, HasIRField, DerivesFrom,
)

# Edges validate node pairs at runtime
edge = NativeInstanceOf()
edge.validate_nodes(sf_report, report)  # OK
edge.validate_nodes(report, sf_report)  # Raises TypeError
```

## Future Considerations

### Additional BI Platform Support

The schema is designed to accommodate additional BI platforms:

- **Looker**: `LookerLook` → `NATIVE_INSTANCE_OF` → `Report`
- **PowerBI**: `PowerBIReport` → `NATIVE_INSTANCE_OF` → `Report`
- **Tableau**: `TableauWorkbook` → `NATIVE_INSTANCE_OF` → `Report`

Each platform would have its own native node type with platform-specific properties, but all link to the canonical `Report` spine.

### Ingestion Pipeline

A future ingestion pipeline would:

1. Fetch report metadata from BI platform APIs
2. Create/update `Report` spine nodes
3. Link native nodes via `NATIVE_INSTANCE_OF`
4. Parse report structure into `ReportIR` and child nodes
5. Resolve field lineage to `DbtColumn`/`PhysicalColumn` via `DERIVES_FROM`

### Cross-Platform Comparison

The IR abstraction enables comparing reports across platforms:

```cypher
// Find similar reports across platforms (same base entity)
MATCH (ir1:ReportIR)<-[:HAS_IR]-(r1:Report {system: 'salesforce'})
MATCH (ir2:ReportIR)<-[:HAS_IR]-(r2:Report {system: 'looker'})
WHERE ir1.base_entity = ir2.base_entity
RETURN r1.title, r2.title, ir1.base_entity
```

## Related Documentation

- [Semantic Schema Design](./SEMANTIC_SCHEMA_DESIGN.md) - Inferred semantic metadata schema
- [Salesforce Auth](../reference/SALESFORCE_AUTH.md) - Salesforce OAuth configuration
- [Type Enums](../reference/TYPE_ENUMS.md) - NodeLabel and EdgeType definitions
