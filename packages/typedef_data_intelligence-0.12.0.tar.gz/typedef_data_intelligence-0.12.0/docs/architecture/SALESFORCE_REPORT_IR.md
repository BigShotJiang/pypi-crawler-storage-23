# Salesforce Report IR Implementation

This document describes the implementation of the Generic Report Schema for Salesforce reports, including the column-to-field resolution system that achieves 100% accuracy.

## Overview

The Report IR (Intermediate Representation) system transforms vendor-specific report definitions into a canonical schema that enables cross-platform analysis. For Salesforce, this means converting `SfReport` and `SfReportColumn` nodes into `Report`, `ReportIR`, and `ReportIRField` nodes.

### Key Goals

1. **100% Column Resolution**: Link every report column to its source SfField
2. **Accurate Field Classification**: Classify fields as measure, dimension, or time
3. **Role Inference**: Infer field roles (aggregation, display, grouping)
4. **Metadata Preservation**: Capture report_format, data_type, and other metadata

## Architecture

### Node Hierarchy

```text
SalesforceOrg
    └── SfReport (native Salesforce report)
            ├── report_format: tabular|summary|matrix|joined
            ├── report_type: Opportunity, Account, etc.
            └── SfReportColumn
                    ├── column_key: AMOUNT, CLOSE_DATE, OPPORTUNITY_NAME
                    ├── data_type: currency, date, string
                    └── [SF_REPORT_COLUMN_USES_FIELD] → SfField

Report (canonical)
    └── ReportIR
            ├── report_format: tabular|summary|matrix
            ├── base_entity: Opportunity, Account, etc.
            └── ReportIRField
                    ├── field_type: measure|dimension|time
                    ├── role: aggregation|display|grouping
                    └── ref_entity, ref_field: Opportunity, Amount
```

### Data Flow

```text
Salesforce Analytics API
        │
        ├── describe_report() → reportMetadata, reportExtendedMetadata
        │       └── detailColumns: [AMOUNT, CLOSE_DATE, ...]
        │       └── detailColumnInfo: {AMOUNT: {dataType: currency, label: Amount}}
        │
        └── describe_report_type() → reportTypeMetadata
                └── objects: [{apiName: Opportunity}, {apiName: Account}]
                └── categories: [{label: "Opportunity Information", columns: {AMOUNT, CLOSE_DATE, ...}}]
                                        │
                                        ▼
                        Column-to-Object Mapping
                        {AMOUNT: Opportunity, CLOSE_DATE: Opportunity, ...}
                                        │
                                        ▼
                        Column-to-Field Resolution
                        AMOUNT → Opportunity.Amount (SfField)
                                        │
                                        ▼
                        Report IR Generation
                        ReportIRField(field_type=measure, role=aggregation)
```

## Column-to-Field Resolution

The resolution system uses multiple strategies with decreasing confidence:

### Resolution Strategies

| Strategy             | Confidence | Description                                      |
| -------------------- | ---------- | ------------------------------------------------ |
| `exact`              | 1.0        | Direct `Object.Field` key match (case-sensitive) |
| `exact_normalized`   | 0.95       | Case-insensitive `Object.Field` match            |
| `category_mapped`    | 0.9        | Column found in `reportTypeMetadata.categories`  |
| `category_extracted` | 0.85       | Object prefix extracted from combined key        |
| `heuristic_mapped`   | 0.75       | Ambiguous field disambiguated by mapped object   |
| `heuristic`          | 0.5-0.8    | Field name only match (fallback)                 |

### Category Mapping

The key insight is that `reportTypeMetadata.categories` contains column-to-object mappings:

```json
{
  "reportTypeMetadata": {
    "objects": [{ "apiName": "Opportunity" }, { "apiName": "Account" }],
    "categories": [
      {
        "label": "Opportunity Information",
        "columns": {
          "AMOUNT": { "dataType": "currency", "label": "Amount" },
          "CLOSE_DATE": { "dataType": "date", "label": "Close Date" },
          "OPPORTUNITY_NAME": {
            "dataType": "string",
            "label": "Opportunity Name"
          }
        }
      }
    ]
  }
}
```

By matching category labels to object API names, we build a mapping:

- `AMOUNT` → `Opportunity`
- `CLOSE_DATE` → `Opportunity`
- `OPPORTUNITY_NAME` → `Opportunity`

### Combined Key Extraction

Some column keys combine object and field names (e.g., `OPPORTUNITY_NAME`). The system handles this by:

1. Normalizing the column key: `OPPORTUNITY_NAME` → `opportunityname`
2. Checking if it starts with the mapped object: `opportunityname`.startswith(`opportunity`) → True
3. Extracting the field: `opportunityname`[len(`opportunity`):] → `name`
4. Matching to field: `Opportunity.Name`

### Normalization

Field name normalization handles Salesforce's inconsistent casing:

```python
def _normalize_field_name(name: str) -> str:
    """CLOSE_DATE -> closedate, CloseDate -> closedate"""
    return name.lower().replace("_", "")
```

## Field Classification

Fields are classified based on their Salesforce data type:

| Salesforce Type                        | Field Type | Role        |
| -------------------------------------- | ---------- | ----------- |
| currency, double, int, percent, number | measure    | aggregation |
| date, datetime, time                   | time       | grouping    |
| string, picklist, reference, etc.      | dimension  | display     |

## Implementation Files

| File             | Purpose                                                                                      |
| ---------------- | -------------------------------------------------------------------------------------------- |
| `loader.py`      | Fetches Salesforce metadata, builds column-to-object mapping, resolves columns to fields     |
| `client.py`      | Salesforce API client with `describe_report`, `describe_report_type`, `read_report_metadata` |
| `salesforce.py`  | Pydantic models for `SfReport`, `SfReportColumn` with `report_format`, `data_type` fields    |
| `fetcher.py`     | Fetches `SfReport`/`SfReportColumn` from graph for IR transformation                         |
| `transformer.py` | Transforms Salesforce data to canonical `Report`, `ReportIR`, `ReportIRField` nodes          |

## Results

### Before

| Metric            | Value            |
| ----------------- | ---------------- |
| Column resolution | 78% (25/32)      |
| Resolution types  | Mostly heuristic |
| report_format     | "unknown"        |
| field_type        | All "dimension"  |
| field_role        | All "display"    |

### After

| Metric            | Value                                                              |
| ----------------- | ------------------------------------------------------------------ |
| Column resolution | **100% (32/32)**                                                   |
| Resolution types  | category_mapped (19), category_extracted (7), exact_normalized (6) |
| report_format     | summary (21), tabular (6), matrix (2)                              |
| field_type        | measure (16), dimension (13), time (3)                             |
| field_role        | aggregation (16), display (13), grouping (3)                       |

## Key Bug Fixes

### 1. Empty Object Name Bug

**Problem**: Objects in `reportTypeMetadata` returned `name: None`, causing empty string `''` to be added to the mapping. Empty string matches any category label but maps to `None`.

**Fix**: Skip entries where key or value is empty:

```python
if obj_name and api_name:
    obj_label_to_api[obj_name.lower()] = api_name
if api_name:
    obj_label_to_api[api_name.lower()] = api_name
```

### 2. Cache Bypass Bug

**Problem**: When `_get_rt_describe()` hit cache, it returned early without building the column-to-object mapping.

**Fix**: Always build mapping, check if already exists:

```python
if result is not None and rt_api_name not in rt_column_to_object:
    # Build mapping...
```

### 3. Edge Creation Order Bug

**Problem**: `create_edge()` was called before `upsert_node()` for columns, causing edges to fail.

**Fix**: Refactored `_resolve_column_to_field()` to return resolution info, caller creates edge after upserting node.

## API Reference

### Analytics API (Used)

- `GET /analytics/reports` - List reports
- `GET /analytics/reports/{id}/describe` - Report metadata with `detailColumnInfo`
- `GET /analytics/report-types/{type}` - Report type with `categories` mapping

### Metadata API (Available)

- `mdapi.Report.read(name)` - Full report definition with explicit `Object$Field` references

The Metadata API provides explicit field references (`Opportunity$Amount`) but is slower (SOAP-based). The Analytics API with category mapping achieves the same accuracy with better performance.

## Future Enhancements

1. **Other BI Platforms**: Extend to Tableau, Looker, Power BI
2. **Cross-Platform Analysis**: Compare reports across platforms using canonical schema
3. **Lineage Integration**: Connect Report fields to dbt models via SfField → DbtSource stitching
4. **Impact Analysis**: Trace how Salesforce field changes affect downstream reports
