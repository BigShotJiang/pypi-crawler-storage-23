# Clustering Algorithm Decision: Standardizing on Louvain

This document records the evaluation process and rationale for standardizing the join clustering pipeline on NetworkX's Louvain algorithm, removing support for Leiden, Greedy Modularity, Label Propagation, Walktrap, and Markov Clustering (MCL).

## Context

The clustering pipeline groups dbt models into subject areas based on a weighted hybrid graph. Edges encode multiple relationship signals: SQL joins, dbt lineage, shared dependencies, column lineage, and domain similarity. The clustering algorithm partitions this graph into communities that represent coherent business domains.

We initially supported six algorithms to allow experimentation. After running systematic sweeps with the `eval-clustering` devtool against the mattermost-analytics project (317 models, 1,778 edges), we found that algorithm choice had less impact than weight tuning, and that carrying five extra algorithms imposed real costs with no measurable benefit.

## Sweep Results

All sweeps were run on the same graph (317 models, 1,778 edges). The first group compares algorithms with identical baseline weights (join=2.0, lineage=1.0, shared_dep=0.5, col_lineage=0.1). The second group compares weight configurations using the same algorithm.

### Algorithm Comparison (Baseline Weights)

| Algorithm | Clusters | Modularity | Coverage | Singletons | Role Sep. | Avg Size |
| --------- | -------- | ---------- | -------- | ---------- | --------- | -------- |
| Louvain   | 15       | 0.730      | 0.905    | 5          | 0.713     | 21.1     |
| Leiden    | 15       | 0.731      | 0.908    | 5          | 0.713     | 21.1     |
| Greedy    | 16       | 0.705      | 0.889    | 5          | 0.719     | 19.8     |
| Walktrap  | 26       | 0.699      | 0.926    | 5          | 0.750     | 12.2     |

Key observations:

- **Louvain and Leiden produced nearly identical results.** Modularity differed by 0.001, coverage by 0.003. Both found 15 clusters with the same singleton count. This is expected -- Leiden is a refinement of Louvain that matters primarily on very large or pathological graphs.
- **Greedy Modularity underperformed.** Lower modularity (0.705 vs 0.730) and lower coverage (0.889 vs 0.905). It uses a bottom-up agglomerative approach that tends to produce less balanced partitions.
- **Walktrap over-fragmented.** 26 clusters (vs 15) with lower modularity (0.699). The random-walk approach splits communities that are structurally coherent. Higher coverage (0.926) is a side effect of smaller clusters having more internal edge density trivially.
- **Label Propagation and MCL** were not included in the recorded sweeps because they require additional parameters (MCL inflation/expansion) and produced unstable results across runs due to non-determinism in label propagation.

### Weight Configuration Comparison

| Config           | Join | Lineage | Shared | Col | Domain | Clusters | Modularity | Coverage |
| ---------------- | ---- | ------- | ------ | --- | ------ | -------- | ---------- | -------- |
| baseline         | 2.0  | 1.0     | 0.5    | 0.1 | 0.0    | 15       | 0.731      | 0.908    |
| join_dominant    | 5.0  | 0.5     | 0.2    | 0.0 | 0.0    | 23       | 0.768      | 0.886    |
| lineage_dominant | 1.0  | 3.0     | 1.0    | 0.0 | 0.0    | 18       | 0.728      | 0.914    |
| equal_weights    | 1.0  | 1.0     | 1.0    | 1.0 | 0.3    | 17       | 0.737      | 0.918    |
| domain_enhanced  | 2.0  | 1.0     | 0.5    | 0.1 | 0.3    | 15       | 0.731      | 0.908    |

Key observations:

- **Weight tuning had a larger effect than algorithm choice.** Modularity ranged from 0.728 to 0.768 across weight configs (0.040 spread) vs 0.699 to 0.731 across algorithms (0.032 spread).
- **Join-dominant weights produced the highest modularity** (0.768) but at the cost of over-fragmentation (23 clusters) and lower coverage (0.886). Models connected only through lineage were split apart.
- **Domain-enhanced weights** added 0.3 domain similarity weight on top of baseline. No change in cluster count or modularity, suggesting domain similarity edges reinforce existing join/lineage structure rather than creating new groupings.

### Production Configuration

After iterating on the sweeps, the production config was tuned to:

```yaml
join_weight: 12.0
lineage_weight: 0.5
shared_dependency_weight: 0.1
column_lineage_weight: 0.0
domain_similarity_weight: 0.3
resolution: 2.0
```

These are the current production values from `config.ingest.yml`. The rationale:

- **join_weight=12.0**: SQL joins are the strongest signal for domain coherence. Two models joined in SQL are almost certainly in the same subject area. Increased from the initial sweep value of 10.0 after manual tuning showed better separation.
- **lineage_weight=0.5**: dbt DAG edges indicate data flow but not necessarily domain membership. A staging model feeds many downstream domains.
- **shared_dependency_weight=0.1**: Shared parents are a weak signal. Many models share `dim_date` or `stg_` sources without belonging to the same domain.
- **column_lineage_weight=0.0**: Disabled. Column-level lineage was too noisy -- common columns like `id`, `created_at`, `updated_at` created false edges.
- **domain_similarity_weight=0.3**: Moderate reinforcement from LLM-inferred business domains. Helps disambiguate edge cases where structural signals are ambiguous.
- **resolution=2.0**: Higher than the initial sweep value (1.5) to produce more granular subject areas. Tuned after observing that resolution=1.5 still produced some overly broad clusters.

## Decision Rationale

### Why Louvain

1. **Performance parity with Leiden.** On our graph sizes (hundreds to low thousands of models), Louvain and Leiden produce equivalent partitions. Leiden's theoretical advantage (guaranteed connected communities) does not manifest at this scale.
2. **Pure Python, zero C dependencies.** Louvain is implemented natively in NetworkX. Leiden requires `igraph` (~10MB + C bindings) and `leidenalg` (~2MB + C bindings). These C extensions cause build failures on some platforms and increase Docker image size.
3. **Deterministic.** With a fixed seed, Louvain produces identical results across runs. Label Propagation is inherently non-deterministic.
4. **Resolution parameter.** Louvain supports a resolution parameter for controlling cluster granularity, which is the primary tuning lever in our pipeline.

### Why not the others

| Algorithm         | Reason for removal                                                                                                       |
| ----------------- | ------------------------------------------------------------------------------------------------------------------------ |
| Leiden            | Identical results to Louvain at our scale; adds igraph + leidenalg C deps                                                |
| Greedy Modularity | Lower modularity and coverage; no resolution parameter                                                                   |
| Label Propagation | Non-deterministic; no resolution parameter; unstable across runs                                                         |
| Walktrap          | Over-fragments; requires igraph C bindings; no resolution control                                                        |
| Markov Clustering | Requires scipy.sparse + markov-clustering; inflation/expansion params are hard to tune; MCL does not optimize modularity |

### Dependencies removed

| Package             | Size      | Reason                       |
| ------------------- | --------- | ---------------------------- |
| `igraph>=1.0.0`     | ~10MB + C | Required by Leiden, Walktrap |
| `leidenalg>=0.11.0` | ~2MB + C  | Required by Leiden only      |
| `markov-clustering` | ~100KB    | Required by MCL only         |

`scipy.sparse` import in algorithms.py was also removed (only used by MCL). NetworkX remains as a dependency (used by Louvain and graph construction).

## What remains

- **Louvain** via `networkx.community.louvain_communities` with configurable `resolution` and `seed`
- **Eval tool** (`lineage-eval-clustering`) for weight/resolution sweeps
- **All weight parameters** in `ClusteringConfig`: `join_weight`, `lineage_weight`, `shared_dependency_weight`, `column_lineage_weight`, `domain_similarity_weight`

## Reproducing the evaluation

```bash
# Run a single evaluation with current config
uv run lineage-eval-clustering --verbose

# Run a weight sweep (5 configurations)
uv run lineage-eval-clustering --sweep

# Compare two runs
uv run lineage-eval-clustering --compare run_A.json run_B.json

# View history
uv run lineage-eval-clustering --history
```

Results are saved to `.lineage_workspace/clustering_eval/` with full metrics and cluster assignments for post-hoc analysis.
