from setuptools import setup, find_packages

setup(
    name="wikicrop",
    version="0.1",
    packages=find_packages(),
    include_package_data=True, # Quan trọng để đính kèm file CSV
    package_data={
        'wikicrop': ['datasets/*.csv'],
    },
    install_requires=[
        'pandas',
        'openpyxl',
    ],
)