import pandas as pd
import os

# Lấy đường dẫn tuyệt đối đến thư mục chứa dữ liệu
_ROOT = os.path.abspath(os.path.dirname(__file__))

def load_lua():
    path = os.path.join(_ROOT, 'datasets', 'lua.csv')
    return pd.read_csv(path, encoding='utf-8-sig')

def load_dau_nanh():
    path = os.path.join(_ROOT, 'datasets', 'dau_nanh.csv')
    return pd.read_csv(path, encoding='utf-8-sig')