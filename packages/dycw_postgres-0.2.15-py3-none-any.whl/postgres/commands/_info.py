from __future__ import annotations

from typing import TYPE_CHECKING

from click import command
from utilities.click import CONTEXT_SETTINGS
from utilities.core import is_pytest, set_up_logging, to_logger

from postgres import __version__
from postgres._click import (
    print_option,
    repo_option,
    stanza_option,
    type_no_default_option,
    user_option,
)
from postgres._utilities import run_or_as_user, to_repo_num

if TYPE_CHECKING:
    from collections.abc import Callable

    from click import Command

    from postgres._enums import BackupType
    from postgres._types import RepoNameMapping, RepoNumOrName


_LOGGER = to_logger(__name__)


##


def info[T: str](
    *,
    repo: RepoNumOrName[T] | None = None,
    repo_mapping: RepoNameMapping[T] | None = None,
    stanza: str | None = None,
    type_: BackupType | None = None,
    user: str | None = None,
    print: bool = True,  # noqa: A002
) -> None:
    _LOGGER.info("Getting info...")
    args: list[str] = ["pgbackrest"]
    if repo is not None:
        repo_num = to_repo_num(repo=repo, mapping=repo_mapping)
        args.append(f"--repo={repo_num}")
    if stanza is not None:
        args.append(f"--stanza={stanza}")
    if type_ is not None:
        args.append(f"--type={type_.value}")
    run_or_as_user(*args, user=user, print=print, logger=_LOGGER)
    _LOGGER.info("Finished getting info")


##


def make_info_cmd[T: str](
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @repo_option
    @stanza_option
    @type_no_default_option
    @user_option
    @print_option
    def func(
        *,
        repo: RepoNumOrName[T] | None,
        stanza: str | None,
        type_: BackupType | None,
        user: str | None,
        print: bool,  # noqa: A002
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        info(repo=repo, stanza=stanza, type_=type_, user=user, print=print)

    return cli(
        name=name, help="Retrieve information about backups", **CONTEXT_SETTINGS
    )(func)


__all__ = ["info", "make_info_cmd"]
