"""SM2CAN command-line tools."""
