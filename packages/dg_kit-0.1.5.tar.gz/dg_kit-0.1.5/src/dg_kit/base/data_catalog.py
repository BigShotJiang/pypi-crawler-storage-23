from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Dict, Tuple
from os import environ
import logging
import pickle
from pathlib import Path

from dg_kit.base.enums import DataUnitType
from dg_kit.base.dataclasses.data_catalog import (
    DataCatalogRow,
    EntityPage,
    AttributePage,
    RelationPage,
    ObjectReference,
    IndexedCatalog,
)
from dg_kit.base.logical_model import LogicalModel
from dg_kit.base.dataclasses.logical_model import (
    Entity,
    Attribute,
    Relation,
)

logger = logging.getLogger(__name__)


class DataCatalogEngine(ABC):
    @abstractmethod
    def pull_data_catalog(
        self,
    ) -> Tuple[
        Dict[str, DataCatalogRow], Dict[str, EntityPage | AttributePage | RelationPage]
    ]:
        raise NotImplementedError

    @abstractmethod
    def update_row(self, data_catalog_row: DataCatalogRow) -> None:
        raise NotImplementedError

    @abstractmethod
    def update_page(
        self, data_unit_page: EntityPage | AttributePage | RelationPage
    ) -> None:
        raise NotImplementedError

    @abstractmethod
    def add_page(
        self, data_unit_page: EntityPage | AttributePage | RelationPage
    ) -> None:
        raise NotImplementedError

    @abstractmethod
    def add_row(self, data_catalog_row: DataCatalogRow) -> ObjectReference:
        raise NotImplementedError

    @abstractmethod
    def delete_by_id(self, id: str) -> None:
        raise NotImplementedError


class DataCatalog:
    def __init__(
        self,
        engine: DataCatalogEngine,
        config: Dict,
    ):
        self.engine = engine
        self.config = config
        self.artifact_path = Path(
            f"{self.config['data_catalog']['dc_checkpoint_path']}/{self.config['name']}.pkl"
        )

        if self.artifact_path.exists():
            try:
                logger.info("Initiating indexed DB from %s.", self.artifact_path)
                self.indexed_catalog: IndexedCatalog = self.load_from_local()
            except Exception as e:
                logger.warning(
                    "Couldn't initiate indexed catalog localy from %s. Pulling catalog from remote.",
                    self.artifact_path,
                    exc_info=e,
                )
                self.pull_data_catalog()
        else:
            logger.info(
                "Couldn't find indexed catalog localy at %s. Pulling catalog from remote.",
                self.artifact_path,
            )
            self.pull_data_catalog()

    def pull_data_catalog(self):
        self.indexed_catalog = self.engine.pull_data_catalog()
        self.save_to_local()

    def get_row_by_id(self, id: str) -> DataCatalogRow:
        return self.indexed_catalog.row_by_id.get(id)

    def get_page_by_id(self, id: str) -> Entity | Attribute | Relation:
        return self.indexed_catalog.page_by_id.get(id)

    def update_row(self, data_catalog_row: DataCatalogRow) -> None:
        self.indexed_catalog.row_by_id[data_catalog_row.id] = data_catalog_row
        self.engine.update_row(data_catalog_row)
        self.save_to_local()

    def update_page(self, page: EntityPage | AttributePage | RelationPage) -> None:
        self.indexed_catalog.page_by_id[page.id] = page
        self.engine.update_page(page)
        self.save_to_local()

    def add_page(self, page: EntityPage | AttributePage | RelationPage) -> None:
        if page.id in self.indexed_catalog.page_by_id:
            raise KeyError(
                f"Data unit page with id='{page.id}' already exists. Use update instead."
            )

        self.indexed_catalog.page_by_id[page.id] = page
        self.engine.add_page(page)
        self.save_to_local()

    def add_row(self, raw_data_catalog_row: Dict) -> None:
        if raw_data_catalog_row["id"] in self.indexed_catalog.row_by_id:
            raise KeyError(
                f"Data unit with id='{raw_data_catalog_row['id']}' already exists. Use update instead."
            )

        page_reference = self.engine.add_row(raw_data_catalog_row)
        data_catalog_row = DataCatalogRow(
            id=raw_data_catalog_row["id"],
            reference=page_reference,
            data_unit_type=raw_data_catalog_row["data_unit_type"],
            data_unit_name=raw_data_catalog_row["data_unit_name"],
            domain=raw_data_catalog_row["domain"],
        )
        self.indexed_catalog.row_by_id[raw_data_catalog_row["id"]] = data_catalog_row
        self.indexed_catalog.reference_by_id[raw_data_catalog_row["id"]] = (
            page_reference
        )
        self.save_to_local()

        return page_reference

    def delete_by_id(self, id: str) -> None:
        self.indexed_catalog.row_by_id.pop(id, None)
        self.indexed_catalog.page_by_id.pop(id, None)
        self.engine.delete_by_id(id)
        self.save_to_local()

    def sync_with_model(
        self,
        LM: LogicalModel,
    ):
        lm_ids = set(LM.all_units_by_id)
        row_ids = set(self.indexed_catalog.row_by_id)
        rows_and_lm_intersection = row_ids & lm_ids
        rows_diff = row_ids - lm_ids
        lm_diff = lm_ids - row_ids

        logger.info("Deleting data units from DC...")
        for id in rows_diff:
            self.delete_by_id(id)

        logger.info("Adding new data units...")
        for data_unit_id in lm_diff:
            if data_unit_id in LM.entities:
                data_unit_type = DataUnitType.ENTITY
            elif data_unit_id in LM.attributes:
                data_unit_type = DataUnitType.ATTRIBUTE
            elif data_unit_id in LM.relations:
                data_unit_type = DataUnitType.RELATION

            data_unit = LM.all_units_by_id[data_unit_id]

            raw_data_catalog_row = {
                "id": data_unit.id,
                "data_unit_name": data_unit.name,
                "data_unit_type": data_unit_type,
                "domain": data_unit.domain or "Unknown",
            }

            self.add_row(raw_data_catalog_row)

        for data_unit_id in lm_diff:
            if data_unit_id in LM.entities:
                entity = LM.entities[data_unit_id]

                for identifier in LM.identifiers_by_entity_id[entity.id]:
                    if identifier.is_pk:
                        pk_attributes_references = tuple(
                            [
                                self.indexed_catalog.reference_by_id[
                                    attribute.id
                                ].reference_link
                                for attribute in identifier.attributes
                            ]
                        )
                attributes_references = tuple(
                    [
                        self.indexed_catalog.reference_by_id[
                            attribute.id
                        ].reference_link
                        for attribute in LM.attributes_by_entity_id[entity.id]
                    ]
                )
                relations_references = tuple(
                    [
                        self.indexed_catalog.reference_by_id[relation.id].reference_link
                        for relation in LM.relations_by_entity_id[entity.id]
                    ]
                )

                page = EntityPage(
                    id=data_unit_id,
                    reference=self.indexed_catalog.reference_by_id[entity.id],
                    data_unit_type=DataUnitType.ENTITY,
                    description=entity.description,
                    pk_attributes_references=pk_attributes_references,
                    attributes_references=attributes_references,
                    relations_references=relations_references,
                    linked_documents=tuple(
                        [document.name for document in entity.documents]
                    ),
                    responsible_parties=tuple(
                        [party.name for party in entity.responsible_parties]
                    ),
                    pm_mapping_references=entity.pm_map,
                    source_systems=entity.source_systems,
                )

            elif data_unit_id in LM.attributes:
                attribute = LM.attributes[data_unit_id]

                page = AttributePage(
                    id=data_unit_id,
                    reference=self.indexed_catalog.reference_by_id[attribute.id],
                    data_unit_type=DataUnitType.ATTRIBUTE,
                    description=attribute.description,
                    parent_entity_reference=self.indexed_catalog.reference_by_id[
                        attribute.entity_id
                    ].reference_link,
                    data_type=attribute.data_type,
                    sensitivity_type=attribute.sensitivity_type,
                    linked_documents=tuple(
                        [document.name for document in attribute.documents]
                    ),
                    responsible_parties=tuple(
                        [party.name for party in attribute.responsible_parties]
                    ),
                    pm_mapping_references=attribute.pm_map,
                    source_systems=attribute.source_systems,
                )

            elif data_unit_id in LM.relations:
                relation = LM.relations[data_unit_id]

                page = RelationPage(
                    id=data_unit_id,
                    reference=self.indexed_catalog.reference_by_id[relation.id],
                    data_unit_type=DataUnitType.RELATION,
                    description=relation.description,
                    source_entity_reference=self.indexed_catalog.reference_by_id[
                        relation.source_entity_id
                    ].reference_link,
                    target_entity_reference=self.indexed_catalog.reference_by_id[
                        relation.target_entity_id
                    ].reference_link,
                    linked_documents=tuple(
                        [document.name for document in relation.documents]
                    ),
                    responsible_parties=tuple(
                        [party.name for party in relation.responsible_parties]
                    ),
                    pm_mapping_references=relation.pm_map,
                    source_systems=relation.source_systems,
                )

            else:
                logger.error(
                    "Unexpected data unit id %s while adding pages.", data_unit_id
                )
                continue

            self.add_page(page)

        logger.info("Updating updated data units...")
        for data_unit_id in rows_and_lm_intersection:
            if data_unit_id in LM.entities:
                entity = LM.entities[data_unit_id]
                row = DataCatalogRow(
                    id=entity.id,
                    reference=ObjectReference(
                        id=entity.id,
                        reference_link=self.indexed_catalog.reference_by_id[
                            entity.id
                        ].reference_link,
                    ),
                    data_unit_name=entity.name,
                    data_unit_type=DataUnitType.ENTITY,
                    domain=entity.domain
                    or environ.get("DG_KIT_DEFAULT_DOMAIN", "Unknown"),
                )

            elif data_unit_id in LM.attributes:
                attribute = LM.attributes[data_unit_id]
                row = DataCatalogRow(
                    id=attribute.id,
                    reference=ObjectReference(
                        id=attribute.id,
                        reference_link=self.indexed_catalog.reference_by_id[
                            attribute.id
                        ].reference_link,
                    ),
                    data_unit_name=attribute.name,
                    data_unit_type=DataUnitType.ATTRIBUTE,
                    domain=attribute.domain
                    or environ.get("DG_KIT_DEFAULT_DOMAIN", "Unknown"),
                )

            elif data_unit_id in LM.relations:
                relation = LM.relations[data_unit_id]
                row = DataCatalogRow(
                    id=relation.id,
                    reference=ObjectReference(
                        id=relation.id,
                        reference_link=self.indexed_catalog.reference_by_id[
                            relation.id
                        ].reference_link,
                    ),
                    data_unit_name=relation.name,
                    data_unit_type=DataUnitType.RELATION,
                    domain=relation.domain
                    or environ.get("DG_KIT_DEFAULT_DOMAIN", "Unknown"),
                )

            else:
                logger.error(
                    "Unexpected data unit id %s while updating rows.", data_unit_id
                )
                continue

            if row == self.indexed_catalog.row_by_id[data_unit_id]:
                continue
            else:
                self.update_row(row)

        for data_unit_id in rows_and_lm_intersection:
            if data_unit_id in LM.entities:
                entity = LM.entities[data_unit_id]

                for identifier in LM.identifiers_by_entity_id[entity.id]:
                    if identifier.is_pk:
                        pk_attributes_references = tuple(
                            [
                                self.indexed_catalog.reference_by_id[
                                    attribute.id
                                ].reference_link
                                for attribute in identifier.attributes
                            ]
                        )
                attributes_references = tuple(
                    [
                        self.indexed_catalog.reference_by_id[
                            attribute.id
                        ].reference_link
                        for attribute in LM.attributes_by_entity_id[entity.id]
                    ]
                )
                relations_references = tuple(
                    [
                        self.indexed_catalog.reference_by_id[relation.id].reference_link
                        for relation in LM.relations_by_entity_id[entity.id]
                    ]
                )

                page = EntityPage(
                    id=data_unit_id,
                    reference=self.indexed_catalog.reference_by_id[entity.id],
                    data_unit_type=DataUnitType.ENTITY,
                    description=entity.description,
                    pk_attributes_references=pk_attributes_references,
                    attributes_references=attributes_references,
                    relations_references=relations_references,
                    linked_documents=tuple(
                        [document.name for document in entity.documents]
                    ),
                    responsible_parties=tuple(
                        [party.name for party in entity.responsible_parties]
                    ),
                    pm_mapping_references=entity.pm_map,
                    source_systems=entity.source_systems,
                )

            elif data_unit_id in LM.attributes:
                attribute = LM.attributes[data_unit_id]

                page = AttributePage(
                    id=data_unit_id,
                    reference=self.indexed_catalog.reference_by_id[attribute.id],
                    data_unit_type=DataUnitType.ATTRIBUTE,
                    description=attribute.description,
                    parent_entity_reference=self.indexed_catalog.reference_by_id[
                        attribute.entity_id
                    ].reference_link,
                    data_type=attribute.data_type,
                    sensitivity_type=attribute.sensitivity_type,
                    linked_documents=tuple(
                        [document.name for document in attribute.documents]
                    ),
                    responsible_parties=tuple(
                        [party.name for party in attribute.responsible_parties]
                    ),
                    pm_mapping_references=attribute.pm_map,
                    source_systems=attribute.source_systems,
                )

            elif data_unit_id in LM.relations:
                relation = LM.relations[data_unit_id]

                page = RelationPage(
                    id=data_unit_id,
                    reference=self.indexed_catalog.reference_by_id[relation.id],
                    data_unit_type=DataUnitType.RELATION,
                    description=relation.description,
                    source_entity_reference=self.indexed_catalog.reference_by_id[
                        relation.source_entity_id
                    ].reference_link,
                    target_entity_reference=self.indexed_catalog.reference_by_id[
                        relation.target_entity_id
                    ].reference_link,
                    linked_documents=tuple(
                        [document.name for document in relation.documents]
                    ),
                    responsible_parties=tuple(
                        [party.name for party in relation.responsible_parties]
                    ),
                    pm_mapping_references=relation.pm_map,
                    source_systems=relation.source_systems,
                )

            else:
                logger.error(
                    "Unexpected data unit id %s while updating pages.", data_unit_id
                )
                continue

            if page == self.indexed_catalog.page_by_id[data_unit_id]:
                continue
            else:
                self.update_page(page)

    def save_to_local(self):
        with open(
            f"{self.config['data_catalog']['dc_checkpoint_path']}/{self.config['name']}.pkl",
            "wb",
        ) as f:
            pickle.dump(self.indexed_catalog, f)

    def load_from_local(self):
        with open(
            f"{self.config['data_catalog']['dc_checkpoint_path']}/{self.config['name']}.pkl",
            "rb",
        ) as f:
            return pickle.load(f)
