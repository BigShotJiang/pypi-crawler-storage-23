import asyncio
import sys
import time
import zlib
from datetime import datetime

import aiohttp
import dill as pickle

from ksrpc.connections import BaseConnection
from ksrpc.utils.async_ import async_to_sync
from ksrpc.utils.chunks import data_sender
from ksrpc.utils.misc import format_number
from ksrpc.utils.tqdm import update_progress, muted_print


async def process_response(response):
    """处理HTTP响应。根据不同的响应分别处理

    Parameters
    ----------
    response: Response

    Returns
    -------
    object
    json
    csv

    """
    if response.status != 200:
        raise Exception(f'{response.status}, {await response.text()}')

    t1 = time.perf_counter()
    file = sys.stderr
    print(f'{datetime.now()} 接收数据: [', end='', file=file)
    buffer = bytearray()
    buf = bytearray()
    i = -1
    size = 0
    async for chunk, end_of_http_chunk in response.content.iter_chunks():
        buf.extend(chunk)
        if end_of_http_chunk:
            if len(buf) == 0:
                continue
            size += len(buf)
            buffer.extend(zlib.decompress(buf))
            buf.clear()
            i += 1
            update_progress(i, print, file=file)
    t2 = time.perf_counter()
    print(f'] 解压完成 ({format_number(size)}B/{format_number(len(buffer))}B) {t2 - t1:.2f}s {format_number(size / (t2 - t1))}B/s', file=file)
    rsp = pickle.loads(buffer)
    buffer.clear()
    return rsp


class HttpConnection(BaseConnection):
    """HTTP请求响应模式
    1. 比WebSocket协议开销较高，延迟较高
    2. 一个请求一个连接。并发时会自动建立多个连接
    """

    def __init__(self, url: str, username=None, password=None):
        super().__init__(url, username, password)
        self._client = None
        self._lock = asyncio.Lock()
        self._timeout = aiohttp.ClientTimeout(total=60)

    def __enter__(self):
        return self

    def __exit__(self, exc_type=None, exc_val=None, exc_tb=None):
        async_to_sync(self.reset)
        if self._client:
            self._client.__exit__(exc_type, exc_val, exc_tb)
            self._client = None

    async def __aenter__(self):
        """异步async with"""
        return self

    async def __aexit__(self, exc_type=None, exc_val=None, exc_tb=None):
        """异步async with"""
        await self.reset()
        async with self._lock:
            if self._client:
                await self._client.__aexit__(exc_type, exc_val, exc_tb)
                self._client = None

    def __del__(self):
        if self._client:
            async_to_sync(self._client.close)
            self._client = None

    async def connect(self):
        async with self._lock:
            if self._client is None:
                self._client = aiohttp.ClientSession(auth=self._auth, timeout=self._timeout)

    async def reset(self):
        async with self._lock:
            if self._client:
                await self._client.close()
                self._client = None

    async def call(self, module, calls, ref_id):
        """调用函数

        Parameters
        ----------
        module: str
            多层模块名
        calls: list
            调用列表
        ref_id

        """
        await self.connect()

        d = dict(module=module, calls=calls, ref_id=ref_id)

        data = pickle.dumps(d)
        headers = {}

        response = await self._client.post(
            # key服务端目前没有检查，以后可能用到
            self._url.format(time=time.time()),
            data=data_sender(data, muted_print),
            headers=headers,
            # proxy="http://192.168.31.33:9000",
        )

        return await process_response(response)
