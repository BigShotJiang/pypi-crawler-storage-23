from ksrpc.app import create_app

web_app = create_app([])
