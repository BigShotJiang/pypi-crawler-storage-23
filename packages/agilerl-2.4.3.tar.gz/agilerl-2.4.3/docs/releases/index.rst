Releases
========

.. changelog::
    :changelog-url: https://docs.agilerl.com/en/latest/releases/index.html
    :github: https://github.com/AgileRL/AgileRL/releases
    :pypi: https://pypi.org/project/agilerl/
