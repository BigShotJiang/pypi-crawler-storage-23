.. _q_networks:

QNetwork
========

Parameters
----------

.. autoclass:: agilerl.networks.q_networks.QNetwork
  :members:

RainbowQNetwork
===============

Parameters
----------

.. autoclass:: agilerl.networks.q_networks.RainbowQNetwork
  :members:

ContinuousQNetwork
==================

Parameters
----------

.. autoclass:: agilerl.networks.q_networks.ContinuousQNetwork
  :members:
