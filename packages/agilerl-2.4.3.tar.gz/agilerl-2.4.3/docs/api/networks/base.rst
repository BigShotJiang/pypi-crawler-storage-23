.. _base_network:

EvolvableNetwork
================

Parameters
----------

.. autoclass:: agilerl.networks.base.EvolvableNetwork
  :members:
