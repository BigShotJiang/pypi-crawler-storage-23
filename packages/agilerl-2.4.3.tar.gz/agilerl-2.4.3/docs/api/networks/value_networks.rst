.. _value_functions:

ValueNetwork
==================

Parameters
----------

.. autoclass:: agilerl.networks.value_networks.ValueNetwork
  :members:
