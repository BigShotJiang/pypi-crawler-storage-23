Networks
=========

Evolvable network architectures implemented: (More coming soon!)
    * QNetwork
    * RainbowQNetwork
    * ContinuousQNetwork
    * DeterministicActor
    * StochasticActor
    * ValueNetwork

.. toctree::
   :maxdepth: 1

   base
   q_networks
   actors
   value_networks
