.. _actors:

EvolvableDistribution
=====================

Parameters
----------

.. autoclass:: agilerl.networks.actors.EvolvableDistribution
  :members:

DeterministicActor
==================

Parameters
----------

.. autoclass:: agilerl.networks.actors.DeterministicActor
  :members:

StochasticActor
===============

Parameters
----------

.. autoclass:: agilerl.networks.actors.StochasticActor
  :members:
