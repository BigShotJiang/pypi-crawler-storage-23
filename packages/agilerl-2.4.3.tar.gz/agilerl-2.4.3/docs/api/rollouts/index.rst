Rollouts
========

Utilities for gathering trajectories of experience from an environment. These helpers can be used directly or passed to
:func:`agilerl.training.train_on_policy.train_on_policy` to customise how agents interact with an environment.

.. toctree::
   :maxdepth: 1

   on_policy
