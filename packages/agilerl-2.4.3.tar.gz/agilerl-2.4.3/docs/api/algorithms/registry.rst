.. _mutations_registry:

Algorithms Mutations Registry
=============================

Parameters
------------

.. autoclass:: agilerl.algorithms.core.registry.RLParameter
  :members:

.. autoclass:: agilerl.algorithms.core.registry.HyperparameterConfig
  :members:

.. autoclass:: agilerl.algorithms.core.registry.NetworkGroup
  :members:

.. autoclass:: agilerl.algorithms.core.registry.MutationRegistry
  :members:
