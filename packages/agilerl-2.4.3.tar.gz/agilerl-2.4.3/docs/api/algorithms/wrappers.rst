.. _optimizer_wrapper:

OptimizerWrapper
=================

Parameters
------------

.. autoclass:: agilerl.algorithms.core.optimizer_wrapper.OptimizerWrapper
  :members:
