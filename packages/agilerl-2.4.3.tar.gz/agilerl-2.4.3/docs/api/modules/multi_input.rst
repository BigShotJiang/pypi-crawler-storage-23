.. _multi_input:

Evolvable Multi-Input Neural Network (Dict / Tuple Observations)
================================================================

Parameters
------------

.. autoclass:: agilerl.modules.multi_input.EvolvableMultiInput
  :members:
