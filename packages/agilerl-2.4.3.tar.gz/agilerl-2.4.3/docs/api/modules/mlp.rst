.. _mlp:

Evolvable Multi-layer Perceptron (MLP)
======================================

Parameters
----------

.. autoclass:: agilerl.modules.mlp.EvolvableMLP
  :members:
