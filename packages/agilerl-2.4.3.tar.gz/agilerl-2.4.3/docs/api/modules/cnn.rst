.. _cnn:

Evolvable Convolutional Neural Network (CNN)
============================================

Parameters
------------

.. autoclass:: agilerl.modules.cnn.EvolvableCNN
  :members:
