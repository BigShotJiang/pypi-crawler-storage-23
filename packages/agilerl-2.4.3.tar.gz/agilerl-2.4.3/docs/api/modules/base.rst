.. _base_module:

EvolvableModule
===============

Parameters
------------

.. autoclass:: agilerl.modules.base.EvolvableModule
  :members:

EvolvableWrapper
================

Parameters
------------

.. autoclass:: agilerl.modules.base.EvolvableWrapper
  :members:

ModuleDict
==========

Parameters
------------

.. autoclass:: agilerl.modules.base.ModuleDict
  :members:

Mutation Decorator
------------------

.. autofunction:: agilerl.modules.base.mutation
