.. _lstm:

Evolvable Long Short-Term Memory (LSTM)
======================================

Parameters
----------

.. autoclass:: agilerl.modules.lstm.EvolvableLSTM
  :members:
