Custom Activation Functions
===========================

Parameters
----------
.. autoclass:: agilerl.modules.custom_components.GumbelSoftmax
  :members:
