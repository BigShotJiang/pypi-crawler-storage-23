Evolvable GPT
=============

Parameters
----------

.. autoclass:: agilerl.modules.gpt.EvolvableGPT
  :members:

.. autoclass:: agilerl.modules.gpt.LayerNorm
  :members:

.. autoclass:: agilerl.modules.gpt.CausalSelfAttention
  :members:

.. autoclass:: agilerl.modules.gpt.Block
  :members:

.. autoclass:: agilerl.modules.gpt.MLP
  :members:

.. autoclass:: agilerl.modules.gpt.PositionalEncoding
  :members:

.. autoclass:: agilerl.modules.gpt.TokenEmbedding
  :members:
