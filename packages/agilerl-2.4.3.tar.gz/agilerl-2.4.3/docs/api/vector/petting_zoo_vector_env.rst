Petting Zoo Vector Base Class
==============================

Base class for vectorized pettingzoo environments.

Parameters
----------

.. autoclass:: agilerl.vector.pz_vec_env.PettingZooVecEnv
  :members:
