.. _agent_wrappers:

AgentWrapper
============

Parameters
----------

.. autoclass:: agilerl.wrappers.agent.AgentWrapper
  :members:

RSNorm
======

Parameters
----------

.. autoclass:: agilerl.wrappers.agent.RSNorm
  :members:

AsyncAgentsWrapper
==================

Parameters
----------

.. autoclass:: agilerl.wrappers.agent.AsyncAgentsWrapper
  :members:
