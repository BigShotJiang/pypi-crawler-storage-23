Petting Zoo Wrapper
===================

Parameters
----------

.. autoclass:: agilerl.wrappers.pettingzoo_wrappers.PettingZooAutoResetParallelWrapper
  :members:
