Skill
=====

Parameters
----------

.. autoclass:: agilerl.wrappers.learning.Skill
  :members:

BanditEnv
=========

Parameters
----------

.. autoclass:: agilerl.wrappers.learning.BanditEnv
  :members:
