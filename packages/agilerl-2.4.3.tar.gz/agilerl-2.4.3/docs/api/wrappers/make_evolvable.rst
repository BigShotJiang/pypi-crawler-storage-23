Make Evolvable
==============

Parameters
----------

.. autoclass:: agilerl.wrappers.make_evolvable.MakeEvolvable
  :members:
