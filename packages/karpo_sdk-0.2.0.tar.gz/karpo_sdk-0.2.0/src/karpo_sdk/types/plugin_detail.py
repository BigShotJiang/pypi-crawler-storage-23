# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .plugin import Plugin
from .._models import BaseModel

__all__ = ["PluginDetail", "PluginDetailVersion"]


class PluginDetailVersion(BaseModel):
    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    status: Optional[str] = None

    version: Optional[int] = None


class PluginDetail(Plugin):
    versions: Optional[List[PluginDetailVersion]] = None
