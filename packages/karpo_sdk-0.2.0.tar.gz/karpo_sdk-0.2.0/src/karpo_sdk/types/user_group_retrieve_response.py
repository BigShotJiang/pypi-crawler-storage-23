# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from .._models import BaseModel
from .user_group import UserGroup

__all__ = ["UserGroupRetrieveResponse"]


class UserGroupRetrieveResponse(BaseModel):
    data: Optional[UserGroup] = None
