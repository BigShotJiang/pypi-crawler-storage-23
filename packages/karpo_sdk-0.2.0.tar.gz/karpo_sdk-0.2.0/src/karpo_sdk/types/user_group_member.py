# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["UserGroupMember"]


class UserGroupMember(BaseModel):
    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    group_id: Optional[int] = FieldInfo(alias="groupId", default=None)

    user_id: Optional[str] = FieldInfo(alias="userId", default=None)
