# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from .._models import BaseModel
from .plugin_detail import PluginDetail

__all__ = ["PluginRetrieveResponse"]


class PluginRetrieveResponse(BaseModel):
    data: Optional[PluginDetail] = None
