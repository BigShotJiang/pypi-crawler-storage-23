# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from ..._models import BaseModel
from ..prompt_version import PromptVersion

__all__ = ["VersionListResponse"]


class VersionListResponse(BaseModel):
    data: Optional[List[PromptVersion]] = None
