# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["Dataset"]


class Dataset(BaseModel):
    id: Optional[str] = None

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    description: Optional[str] = None

    input_schema: Optional[Dict[str, object]] = FieldInfo(alias="inputSchema", default=None)

    metadata: Optional[Dict[str, object]] = None

    name: Optional[str] = None

    output_schema: Optional[Dict[str, object]] = FieldInfo(alias="outputSchema", default=None)

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)

    version: Optional[int] = None
