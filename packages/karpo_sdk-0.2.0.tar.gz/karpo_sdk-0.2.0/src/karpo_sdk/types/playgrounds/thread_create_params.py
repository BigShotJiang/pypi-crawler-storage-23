# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Required, Annotated, TypedDict

from ..._utils import PropertyInfo

__all__ = ["ThreadCreateParams"]


class ThreadCreateParams(TypedDict, total=False):
    name: Required[str]

    scenario: Required[str]

    test_user_id: Required[Annotated[str, PropertyInfo(alias="testUserId")]]

    agents_config: Annotated[Dict[str, object], PropertyInfo(alias="agentsConfig")]

    group_id: Annotated[int, PropertyInfo(alias="groupId")]
