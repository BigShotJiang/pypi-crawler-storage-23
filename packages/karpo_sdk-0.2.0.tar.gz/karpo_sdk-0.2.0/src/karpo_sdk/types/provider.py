# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["Provider"]


class Provider(BaseModel):
    id: Optional[str] = None

    code: Optional[str] = None

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    description: Optional[str] = None

    enabled: Optional[bool] = None

    name: Optional[str] = None

    sort_order: Optional[int] = FieldInfo(alias="sortOrder", default=None)

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)
