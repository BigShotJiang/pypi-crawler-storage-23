# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from ..._models import BaseModel
from ..import_session import ImportSession

__all__ = ["ImportCreateResponse"]


class ImportCreateResponse(BaseModel):
    data: Optional[ImportSession] = None
