# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Iterable
from typing_extensions import Required, Annotated, TypedDict

from ..._utils import PropertyInfo

__all__ = ["ImportAddBatchParams", "Item"]


class ImportAddBatchParams(TypedDict, total=False):
    id: Required[str]

    items: Required[Iterable[Item]]


class Item(TypedDict, total=False):
    input: Required[Dict[str, object]]

    expected_output: Annotated[Dict[str, object], PropertyInfo(alias="expectedOutput")]

    metadata: Dict[str, object]
