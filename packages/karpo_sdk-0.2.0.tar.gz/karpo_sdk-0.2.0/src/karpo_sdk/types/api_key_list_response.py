# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from .api_key import APIKey
from .._models import BaseModel

__all__ = ["APIKeyListResponse"]


class APIKeyListResponse(BaseModel):
    data: Optional[List[APIKey]] = None
