# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from .._models import BaseModel
from .create_api_key_response import CreateAPIKeyResponse

__all__ = ["APIKeyCreateResponse"]


class APIKeyCreateResponse(BaseModel):
    data: Optional[CreateAPIKeyResponse] = None
