# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from .._models import BaseModel
from .user_group import UserGroup

__all__ = ["UserGroupListResponse"]


class UserGroupListResponse(BaseModel):
    data: Optional[List[UserGroup]] = None
