# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from .._models import BaseModel
from .llm_model import LlmModel

__all__ = ["ModelListEnabledResponse"]


class ModelListEnabledResponse(BaseModel):
    data: Optional[List[LlmModel]] = None
