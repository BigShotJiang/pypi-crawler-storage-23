# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["LlmModel"]


class LlmModel(BaseModel):
    id: Optional[str] = None

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    enabled: Optional[bool] = None

    api_model_id: Optional[str] = FieldInfo(alias="modelId", default=None)

    name: Optional[str] = None

    provider: Optional[str] = None

    sort_order: Optional[int] = FieldInfo(alias="sortOrder", default=None)

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)
