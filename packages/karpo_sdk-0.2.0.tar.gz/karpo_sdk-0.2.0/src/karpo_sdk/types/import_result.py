# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from .._models import BaseModel

__all__ = ["ImportResult"]


class ImportResult(BaseModel):
    created: Optional[int] = None

    errors: Optional[List[str]] = None

    skipped: Optional[int] = None

    total: Optional[int] = None
