# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from .dataset import Dataset
from .._models import BaseModel

__all__ = ["DatasetCreateResponse"]


class DatasetCreateResponse(BaseModel):
    data: Optional[Dataset] = None
