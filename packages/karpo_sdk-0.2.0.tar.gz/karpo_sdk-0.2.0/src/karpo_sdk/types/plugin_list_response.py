# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from .plugin import Plugin
from .._models import BaseModel

__all__ = ["PluginListResponse"]


class PluginListResponse(BaseModel):
    data: Optional[List[Plugin]] = None
