# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["AgentVersion"]


class AgentVersion(BaseModel):
    id: Optional[str] = None

    agent_id: Optional[str] = FieldInfo(alias="agentId", default=None)

    config: Optional[Dict[str, object]] = None

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    creator_id: Optional[str] = FieldInfo(alias="creatorId", default=None)

    tags: Optional[List[str]] = None

    version: Optional[int] = None
