# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from typing_extensions import TypeAlias

from .dataset_item import DatasetItem

__all__ = ["DatasetExportResponse"]

DatasetExportResponse: TypeAlias = List[DatasetItem]
