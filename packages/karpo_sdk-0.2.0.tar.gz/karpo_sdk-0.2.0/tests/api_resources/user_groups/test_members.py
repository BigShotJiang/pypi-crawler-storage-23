# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from karpo_sdk import Karpo, AsyncKarpo
from tests.utils import assert_matches_type
from karpo_sdk.types.user_groups import (
    MemberListResponse,
    MemberCreateResponse,
    MemberDeleteResponse,
    MemberListAvailableResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestMembers:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_create(self, client: Karpo) -> None:
        member = client.user_groups.members.create(
            id="id",
            user_id="userId",
        )
        assert_matches_type(MemberCreateResponse, member, path=["response"])

    @parametrize
    def test_raw_response_create(self, client: Karpo) -> None:
        response = client.user_groups.members.with_raw_response.create(
            id="id",
            user_id="userId",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        member = response.parse()
        assert_matches_type(MemberCreateResponse, member, path=["response"])

    @parametrize
    def test_streaming_response_create(self, client: Karpo) -> None:
        with client.user_groups.members.with_streaming_response.create(
            id="id",
            user_id="userId",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            member = response.parse()
            assert_matches_type(MemberCreateResponse, member, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_create(self, client: Karpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.user_groups.members.with_raw_response.create(
                id="",
                user_id="userId",
            )

    @parametrize
    def test_method_list(self, client: Karpo) -> None:
        member = client.user_groups.members.list(
            "id",
        )
        assert_matches_type(MemberListResponse, member, path=["response"])

    @parametrize
    def test_raw_response_list(self, client: Karpo) -> None:
        response = client.user_groups.members.with_raw_response.list(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        member = response.parse()
        assert_matches_type(MemberListResponse, member, path=["response"])

    @parametrize
    def test_streaming_response_list(self, client: Karpo) -> None:
        with client.user_groups.members.with_streaming_response.list(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            member = response.parse()
            assert_matches_type(MemberListResponse, member, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_list(self, client: Karpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.user_groups.members.with_raw_response.list(
                "",
            )

    @parametrize
    def test_method_delete(self, client: Karpo) -> None:
        member = client.user_groups.members.delete(
            user_id="userId",
            id="id",
        )
        assert_matches_type(MemberDeleteResponse, member, path=["response"])

    @parametrize
    def test_raw_response_delete(self, client: Karpo) -> None:
        response = client.user_groups.members.with_raw_response.delete(
            user_id="userId",
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        member = response.parse()
        assert_matches_type(MemberDeleteResponse, member, path=["response"])

    @parametrize
    def test_streaming_response_delete(self, client: Karpo) -> None:
        with client.user_groups.members.with_streaming_response.delete(
            user_id="userId",
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            member = response.parse()
            assert_matches_type(MemberDeleteResponse, member, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_delete(self, client: Karpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.user_groups.members.with_raw_response.delete(
                user_id="userId",
                id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `user_id` but received ''"):
            client.user_groups.members.with_raw_response.delete(
                user_id="",
                id="id",
            )

    @parametrize
    def test_method_list_available(self, client: Karpo) -> None:
        member = client.user_groups.members.list_available(
            "id",
        )
        assert_matches_type(MemberListAvailableResponse, member, path=["response"])

    @parametrize
    def test_raw_response_list_available(self, client: Karpo) -> None:
        response = client.user_groups.members.with_raw_response.list_available(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        member = response.parse()
        assert_matches_type(MemberListAvailableResponse, member, path=["response"])

    @parametrize
    def test_streaming_response_list_available(self, client: Karpo) -> None:
        with client.user_groups.members.with_streaming_response.list_available(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            member = response.parse()
            assert_matches_type(MemberListAvailableResponse, member, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_list_available(self, client: Karpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.user_groups.members.with_raw_response.list_available(
                "",
            )


class TestAsyncMembers:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_create(self, async_client: AsyncKarpo) -> None:
        member = await async_client.user_groups.members.create(
            id="id",
            user_id="userId",
        )
        assert_matches_type(MemberCreateResponse, member, path=["response"])

    @parametrize
    async def test_raw_response_create(self, async_client: AsyncKarpo) -> None:
        response = await async_client.user_groups.members.with_raw_response.create(
            id="id",
            user_id="userId",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        member = await response.parse()
        assert_matches_type(MemberCreateResponse, member, path=["response"])

    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncKarpo) -> None:
        async with async_client.user_groups.members.with_streaming_response.create(
            id="id",
            user_id="userId",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            member = await response.parse()
            assert_matches_type(MemberCreateResponse, member, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_create(self, async_client: AsyncKarpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.user_groups.members.with_raw_response.create(
                id="",
                user_id="userId",
            )

    @parametrize
    async def test_method_list(self, async_client: AsyncKarpo) -> None:
        member = await async_client.user_groups.members.list(
            "id",
        )
        assert_matches_type(MemberListResponse, member, path=["response"])

    @parametrize
    async def test_raw_response_list(self, async_client: AsyncKarpo) -> None:
        response = await async_client.user_groups.members.with_raw_response.list(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        member = await response.parse()
        assert_matches_type(MemberListResponse, member, path=["response"])

    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncKarpo) -> None:
        async with async_client.user_groups.members.with_streaming_response.list(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            member = await response.parse()
            assert_matches_type(MemberListResponse, member, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_list(self, async_client: AsyncKarpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.user_groups.members.with_raw_response.list(
                "",
            )

    @parametrize
    async def test_method_delete(self, async_client: AsyncKarpo) -> None:
        member = await async_client.user_groups.members.delete(
            user_id="userId",
            id="id",
        )
        assert_matches_type(MemberDeleteResponse, member, path=["response"])

    @parametrize
    async def test_raw_response_delete(self, async_client: AsyncKarpo) -> None:
        response = await async_client.user_groups.members.with_raw_response.delete(
            user_id="userId",
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        member = await response.parse()
        assert_matches_type(MemberDeleteResponse, member, path=["response"])

    @parametrize
    async def test_streaming_response_delete(self, async_client: AsyncKarpo) -> None:
        async with async_client.user_groups.members.with_streaming_response.delete(
            user_id="userId",
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            member = await response.parse()
            assert_matches_type(MemberDeleteResponse, member, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_delete(self, async_client: AsyncKarpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.user_groups.members.with_raw_response.delete(
                user_id="userId",
                id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `user_id` but received ''"):
            await async_client.user_groups.members.with_raw_response.delete(
                user_id="",
                id="id",
            )

    @parametrize
    async def test_method_list_available(self, async_client: AsyncKarpo) -> None:
        member = await async_client.user_groups.members.list_available(
            "id",
        )
        assert_matches_type(MemberListAvailableResponse, member, path=["response"])

    @parametrize
    async def test_raw_response_list_available(self, async_client: AsyncKarpo) -> None:
        response = await async_client.user_groups.members.with_raw_response.list_available(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        member = await response.parse()
        assert_matches_type(MemberListAvailableResponse, member, path=["response"])

    @parametrize
    async def test_streaming_response_list_available(self, async_client: AsyncKarpo) -> None:
        async with async_client.user_groups.members.with_streaming_response.list_available(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            member = await response.parse()
            assert_matches_type(MemberListAvailableResponse, member, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_list_available(self, async_client: AsyncKarpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.user_groups.members.with_raw_response.list_available(
                "",
            )
