"""logmera package."""

from logmera.sdk import log

__all__ = ["__version__", "log"]
__version__ = "0.1.2"
