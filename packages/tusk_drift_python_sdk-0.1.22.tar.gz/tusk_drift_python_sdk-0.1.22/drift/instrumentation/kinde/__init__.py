"""Kinde SDK instrumentation for REPLAY mode."""

from .instrumentation import KindeInstrumentation

__all__ = ["KindeInstrumentation"]
