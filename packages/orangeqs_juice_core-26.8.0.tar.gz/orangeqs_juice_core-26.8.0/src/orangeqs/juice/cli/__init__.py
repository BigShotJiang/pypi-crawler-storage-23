"""CLI for OrangeQS Juice."""

import click

from orangeqs import juice
from orangeqs.juice.cli import config, hook, install, orchestrator, proxy, service
from orangeqs.juice.cli._warnings import configure_warnings_formatting


# main() is accessed by scripts section in pyproject.toml
@click.group()
@click.version_option(
    prog_name="OrangeQS Juice",
    version=f"{juice.__version__}, installed at {juice.__path__[0]}",  # type: ignore
)
def main() -> None:
    """Run CLI, should be called as entrypoint."""
    configure_warnings_formatting()


main.add_command(config.config, name="config")
main.add_command(hook.hook, name="hook")

# TODO: Refactor into commands and subcommands for better organization
main.add_command(install.install, name="install")
main.add_command(install.install_influxdb2, name="install_influxdb2")
main.add_command(install.install_services, name="install_services")
main.add_command(install.install_telegraf, name="install_telegraf")
main.add_command(install.install_jupyterhub, name="install_jupyterhub")

main.add_command(service.service, name="service")
main.add_command(orchestrator.orchestrator, name="orchestrator")
main.add_command(proxy.proxy, name="proxy")


if __name__ == "__main__":
    main()
