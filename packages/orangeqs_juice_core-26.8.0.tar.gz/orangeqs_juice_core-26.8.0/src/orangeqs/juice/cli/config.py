"""Juice CLI config commands."""

import warnings

import click


@click.group()
def config() -> None:
    """Juice CLI config commands."""
    pass


@config.command()
@click.argument("filename", type=str)
def list(filename: str) -> None:
    """Load a config by its filename and list all merged contents."""
    import tomli_w

    from orangeqs.juice.settings import Configurable
    from orangeqs.juice.settings._loading import (
        _load_toml_dict,  # pyright: ignore[reportPrivateUsage]
    )

    raw_settings = _load_toml_dict(filename, Configurable._lookup_locations)  # pyright: ignore[reportPrivateUsage]
    warnings.warn(
        "This command shows the raw merged configs from disk, "
        "so before applying any defaults or validation.",
    )
    if not raw_settings:
        click.echo("# No settings found.")
    else:
        click.echo(tomli_w.dumps(raw_settings))
