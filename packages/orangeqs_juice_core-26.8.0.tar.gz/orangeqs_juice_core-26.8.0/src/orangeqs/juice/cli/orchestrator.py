"""Juice CLI orchestrator command."""

import click


@click.group()
def orchestrator() -> None:
    """Manage the Juice Orchestrator service."""
    pass


@orchestrator.command()
def start() -> None:
    """Start the Juice Orchestrator service.

    Must be run on the host system as a systemd service.
    """
    from orangeqs.juice._orchestrator import start

    start()
