"""Juice CLI service command."""

import click


@click.command()
@click.argument("service_name", type=str)
def service(service_name: str) -> None:
    """Run an OrangeQS Juice service by its name."""
    from orangeqs.juice.service import start

    start(service_name)
