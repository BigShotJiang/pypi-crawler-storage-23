"""Schemas for the OrangeQS Juice Task Manager."""

from typing import ClassVar

from pydantic import BaseModel

from orangeqs.juice.settings import Configurable, RuntimeData

from .common import PortNumber


class TaskManagerNetworkConfig(BaseModel):
    """Network configuration for the OrangeQS Juice Task Manager."""

    router_port: PortNumber = 5124
    """Port the task router listens on."""

    pub_port: PortNumber = 5122
    """Port for publishing events."""

    sub_port: PortNumber = 5123
    """Port for subscribing to events."""

    ip: str | None = None
    """
    IP address the task manager listens on, or the hostname
    that resolves to an IP address.

    If not set, will default to `juice-<service_name>`,
    where `<service_name>` is the name of the task manager service.
    """


class TaskManagerConfig(Configurable):
    """Configuration for the OrangeQS Juice Task Manager."""

    filename: ClassVar[str] = "task-manager"

    websocket_ping_interval: int = 30
    """Interval for websocket pings between client and server."""

    websocket_ping_timeout: int = 30
    """Timeout for websocket pings between client and server."""

    websocket_max_message_size: int = 50 * 1024 * 1024
    """Maximum message size (in bytes) for websocket communication.

    Task data is sent over websockets, so this needs to be large enough
    to accommodate the size of task payloads and results.
    """

    network: TaskManagerNetworkConfig = TaskManagerNetworkConfig()
    """Network configuration for the task manager."""

    kernel_status_report_interval: int = 60
    """Interval (in seconds) at which the task manager reports kernel status.

    Needs to be an integer for the UI to query from the database.
    """


class TaskManagerConnectionInfo(TaskManagerNetworkConfig, RuntimeData):
    """Connection information for the OrangeQS Juice Task Manager."""

    filename: ClassVar[str] = "task-manager-connection-info"
