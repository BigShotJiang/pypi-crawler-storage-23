"""Schemas for InfluxDB tokens."""

from typing import ClassVar

from pydantic import BaseModel, Field

from orangeqs.juice.settings import Configurable


class InfluxDB2Tokens(Configurable):
    """InfluxDB2 Token Configuration."""

    filename: ClassVar[str] = "influxdb-tokens"

    tokens: dict[str, "InfluxDB2Token"] = Field(default_factory=dict)
    """A dictionary mapping identities to their corresponding InfluxDB API tokens.

    Identities are typically the names of the services or users with access to InfluxDB.
    """


class InfluxDB2Token(BaseModel):
    """An InfluxDB2 token."""

    identifier: str
    """Identifier of the token, maps to InfluxDB2's 'id'."""

    token: str
    """The value of the token itself."""
