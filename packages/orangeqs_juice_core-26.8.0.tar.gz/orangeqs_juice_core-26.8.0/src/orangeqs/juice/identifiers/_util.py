import datetime

_DATETIME_FORMAT = "%Y%m%d%H%M%S"


def generate_id(
    prefix: str, service: str, timestamp: datetime.datetime | None = None
) -> tuple[str, datetime.datetime, tuple[str, str, str]]:
    """Generate a unique identifier with the given prefix, service, and timestamp.

    If no timestamp is provided, the current UTC time will be used.

    The identifier will be in the format `{prefix}_{service}_{timestamp}`,
    where `timestamp` is in `YYYYMMDDHHMMSS` format.

    Parameters
    ----------
    prefix : str
        The prefix for the identifier.
    service : str
        The name of the service generating the identifier.
    timestamp : datetime.datetime | None, optional
        The timestamp to use for the identifier. If None, the current UTC time is used.

    Returns
    -------
    str
        The generated identifier.
    datetime.datetime
        The timestamp used in the identifier.
    tuple[str, str, str]
        The prefix, service and timestamp suffix of the identifier.

    Raises
    ------
    ValueError
        If the provided timestamp is not timezone-aware.
    """
    if timestamp is None:
        timestamp = datetime.datetime.now(tz=datetime.timezone.utc)
    if timestamp.tzinfo is None:
        raise ValueError("Timestamp must be timezone-aware.")
    suffix = timestamp.strftime(_DATETIME_FORMAT)
    identifier = f"{prefix}_{service}_{suffix}"
    return identifier, timestamp, (prefix, service, suffix)


def parse_id(identifier: str) -> tuple[str, str, datetime.datetime]:
    """Parse an identifier into its components: prefix, service, and timestamp.

    The identifier is expected to be in the format `{prefix}_{service}_{timestamp}`,
    where `timestamp` is in `YYYYMMDDHHMMSS` format.

    Parameters
    ----------
    identifier : str
        The identifier to decode.

    Returns
    -------
    tuple[str, str, datetime.datetime]
        A tuple containing the prefix, service, and timestamp.

    Raises
    ------
    ValueError
        If the identifier format is invalid.
    """
    prefix, _, rest = identifier.partition("_")
    service, _, timestamp_str = rest.rpartition("_")
    if not prefix or not service or not timestamp_str:
        raise ValueError(f"Invalid identifier format: '{identifier}'")
    try:
        # The zero-padding of the format specifiers like %H and %M is optional,
        # so we have to check the length explicitly.
        if len(timestamp_str) != 14:
            raise ValueError("Timestamp has incorrect length.")

        timestamp = datetime.datetime.strptime(timestamp_str, _DATETIME_FORMAT).replace(
            tzinfo=datetime.timezone.utc
        )
    except ValueError as e:
        raise ValueError(f"Invalid timestamp in identifier: '{identifier}'") from e
    return prefix, service, timestamp
