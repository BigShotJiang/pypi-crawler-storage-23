"""Telegraf Utilities."""

import os
import shutil
import subprocess
from pathlib import Path

from orangeqs.juice.orchestration.settings import TelegrafSettings
from orangeqs.juice.orchestration.template import load_template

_CONFIG_TEMPLATE = "telegraf.conf.j2"


def add_influxdb_gpg_key(
    url: str = "https://repos.influxdata.com/influxdata-archive.key",
) -> None:
    """Download and add the InfluxDB GPG key using rpm."""
    try:
        subprocess.run(["rpm", "--import", url], check=True)
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"Failed to add gpg key: {repr(e)}")


def add_influxdb_repo(dest: str = "/etc/yum.repos.d/influxdata.repo") -> None:
    """Create the InfluxDB repo file with appropriate content and permissions."""
    content = """[influxdata]
name = InfluxData Repository - Stable
baseurl = https://repos.influxdata.com/stable/${basearch}/main
enabled = 1
gpgcheck = 1
gpgkey = file:///etc/pki/rpm-gpg/RPM-GPG-KEY-influxdata
"""
    path = Path(dest)
    path.write_text(content)
    path.chmod(0o644)


def install_telegraf() -> bool:
    """Check if Telegraf is installed; if not, install it using dnf.

    Returns
    -------
        bool : False if Telegraf was already installed.
    """
    if shutil.which("telegraf"):
        return False

    try:
        subprocess.run(["dnf", "install", "-y", "telegraf"], check=True)
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"Failed to install telegraf: {repr(e)}")
    return True


def influxdb2_token_exists() -> bool:
    """Check if the Telegraf systemd env file exists and contains an INFLUX_TOKEN."""
    env_file = "/etc/default/telegraf"
    if not os.path.isfile(env_file):
        return False

    with open(env_file) as f:
        return any(line.strip().startswith("INFLUX_TOKEN=") for line in f)


def write_token_to_service_env(token: str) -> None:
    """Write influxDB2 token to the systemd services env file.

    Parameters
    ----------
    token : str
        The token to be written to Telegraf services environment.
    """
    with open("/etc/default/telegraf", "w") as f:
        f.write(f'INFLUX_TOKEN="{token}"\n')


def configure_rsyslog_for_telegraf() -> None:
    """Create an rsyslog config file to forward logs to Telegraf using RFC 5424."""
    config_content = """$ActionQueueType LinkedList # use asynchronous processing
$ActionQueueFileName srvrfwd # set file name, also enables disk mode
$ActionResumeRetryCount -1 # infinite retries on insert failure
$ActionQueueSaveOnShutdown on # save in-memory data if rsyslog shuts down

# forward over tcp with octet framing according to RFC 5424
*.* @@(o)127.0.0.1:6514;RSYSLOG_SyslogProtocol23Format

# uncomment to use udp according to RFC 5424
#*.* @127.0.0.1:6514;RSYSLOG_SyslogProtocol23Format
"""

    output_dir = "/etc/rsyslog.d/"
    filename = "50-telegraf.conf"
    os.makedirs(output_dir, exist_ok=True)
    file_path = os.path.join(output_dir, filename)

    with open(file_path, "w") as f:
        f.write(config_content)

    os.chmod(file_path, 0o644)


def render_telegraf_config(config: TelegrafSettings) -> None:
    """Render the configuration for telegraf.

    Overwrites the file if it already exists.

    Parameters
    ----------
    config : TelegrafSettings
        The telegraf settings to render.
    """
    destination = Path(config.config_path)
    template = load_template(_CONFIG_TEMPLATE)
    variables = config.model_dump(exclude_none=True)
    rendered_content = template.render(**variables)
    destination.write_text(rendered_content)


def add_telegraf_to_sudoers() -> None:
    """Add sudo permissions to telegraf to run podman stats."""
    content = (
        "telegraf ALL=(root) NOPASSWD: /bin/podman stats --no-stream --format=json"
    )
    output_dir = "/etc/sudoers.d"
    filename = "telegraf-podman"
    os.makedirs(output_dir, exist_ok=True)
    file_path = os.path.join(output_dir, filename)

    with open(file_path, "w") as f:
        f.write(content)

    os.chmod(file_path, 0o440)
