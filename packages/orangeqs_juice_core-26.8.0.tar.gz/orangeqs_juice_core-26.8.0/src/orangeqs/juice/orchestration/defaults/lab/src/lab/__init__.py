"""OrangeQS Juice Lab Extension."""


def hello() -> None:
    """Print a hello message."""
    print("Hello from the OrangeQS Juice Lab extension!")
