"""
Proxy kernel for OrangeQS Juice services.

Users of Juice are expected to work with the setup not from their own IPython kernel,
but from the shared OrangeQS Juice service kernels. The proxy kernels are useful when
a user or maintainer wants to execute raw IPython code in the context of a service,
avoiding any API wrappers.

Proxy kernels can be installed using {func}`install_proxy_kernels` and are visible
in Jupyter interface.
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import TYPE_CHECKING, Any

from jupyter_kernel_proxy import JupyterMessage, ProxyKernelClient, ProxyKernelServer
from tornado import ioloop

from orangeqs.juice.schemas.ipython import KernelConnectionRegistry

if TYPE_CHECKING:
    from jupyter_client.kernelspec import KernelSpecManager

_PROXY_PREFIX = "juice-proxy-"
"""Prefix used for the folder name of the installed proxy kernel specs."""


def _install_proxy_kernel(
    service: str,
    *,
    user: bool = False,
    kernel_name: str | None = None,
    display_name: str | None = None,
    prefix: str | None = None,
    env: dict[str, str] | None = None,
    kernel_spec_manager: KernelSpecManager | None = None,
) -> Path:
    """
    Install a proxy kernel for an OrangeQS Juice service.

    Parameters
    ----------
    service
        Name of a juice service.
    user
        Whether to do a user-only install, or system-wide. Default is system-wide.
    kernel_name
        Specify a name for the kernelspec.
        This is needed for having multiple IPython kernels for different environments.
    display_name
        Specify the display name for the kernelspec
    prefix
        Specify an install prefix for the kernelspec.
        This is needed to install into a non-default location, such as a conda or
        virtualenv.
    env
        A dictionary of extra environment variables for the kernel.
        These will be added to the current environment variables before the
        kernel is started

    Returns
    -------
    Path
        Path to the folder of the installed kernelspec.
    """
    import errno
    import json
    import shutil
    import stat
    import tempfile
    from pathlib import Path

    from jupyter_client.kernelspec import KernelSpecManager

    if kernel_name is None:
        kernel_name = f"{_PROXY_PREFIX}{service}"
    if display_name is None:
        display_name = f"Service: {service}"

    kernel_dict: dict[str, Any] = {
        "argv": ["juice", "proxy", "start", service, "{connection_file}"],
        "display_name": display_name,
        "language": "python",
        "metadata": {"debugger": True},
    }
    if env:
        kernel_dict["env"] = env

    static_resources = os.path.join(Path(__file__).parent, "resources")

    try:
        path = Path(tempfile.mkdtemp(suffix="_kernels")) / kernel_name

        # stage resources
        shutil.copytree(static_resources, path)

        # ensure path is writable
        mask = Path(path).stat().st_mode
        if not mask & stat.S_IWUSR:
            Path(path).chmod(mask | stat.S_IWUSR)

        with open(os.path.join(path, "kernel.json"), "w") as f:
            json.dump(kernel_dict, f, indent=1)

        dest = (kernel_spec_manager or KernelSpecManager()).install_kernel_spec(
            str(path), kernel_name=kernel_name, user=user, prefix=prefix
        )
        # cleanup afterward
        shutil.rmtree(path)
    except OSError as e:
        if e.errno == errno.EACCES:
            print(e, file=sys.stderr)
            if not user:
                print("Perhaps you want `sudo` or `--user`?", file=sys.stderr)
            sys.exit(1)
        raise
    print(f"Installed kernelspec {kernel_name} in {dest}")
    return Path(dest)


def _remove_old_proxy_kernels(existing_paths: list[Path], prefix: str = _PROXY_PREFIX):
    """Remove old proxy kernels of services that no longer exist.

    Parameters
    ----------
    existing_paths
        List of paths to existing proxy kernels that should not be removed.
    prefix
        Prefix of the proxy kernel names to look for. Default is "juice-proxy-".
    """
    import errno
    import shutil
    import sys

    if not existing_paths:
        return
    kernel_folder = existing_paths[0].parent
    for folder in kernel_folder.iterdir():
        if not folder.is_dir():
            continue
        if not folder.name.startswith(prefix):
            continue

        if any(folder.name == existing_path.name for existing_path in existing_paths):
            continue

        try:
            shutil.rmtree(folder)
            print(f"Removed old proxy kernel: {folder.name}")
        except OSError as e:
            if e.errno == errno.EACCES:
                print(f"Failed to remove {folder.name}: {e}", file=sys.stderr)
            else:
                raise


def install_proxy_kernels() -> None:
    """Install proxy kernels for all OrangeQS Juice services.

    This also removes old proxy kernels of services that no longer exist.
    """
    from orangeqs.juice.orchestration.settings import OrchestrationSettings

    services = OrchestrationSettings.load().services

    installed_paths = [
        _install_proxy_kernel(
            service,
            user=True,  # Install for the current user
        )
        for service in services
        if service != "task-manager"  # Skip task-manager service
    ]  # Hardcoded, see #207

    _remove_old_proxy_kernels(installed_paths)


class _KernelProxy:
    """
    Proxy between running Jupyter instance and OrangeQS service.

    Parameters
    ----------
    kernel_connection_dict
        Connection info for the proxy process itself, as specified in
        a kernel connection file.
    service_connection_info
        Connection info for the OrangeQS Juice service to proxy requests to.
    service_name
        Name of an OrangeQS Juice service to proxy requests to.
    """

    def __init__(
        self,
        kernel_connection_info: dict[str, Any],
        service_connection_info: dict[str, Any],
        service_name: str,
    ) -> None:
        self.service_name = service_name
        self.service_connection_info = service_connection_info

        self.server = ProxyKernelServer(kernel_connection_info)

        self._kernel_info_requests: list[str] = []
        self.server.intercept_message(
            "shell", "kernel_info_request", self._on_kernel_info_request
        )
        self.server.intercept_message(
            "shell", "kernel_info_reply", self._on_kernel_info_reply
        )

        self.connect(request_kernel_info=False)

    def _on_kernel_info_request(self, server, target_stream, data):
        msg = JupyterMessage.parse(data)
        self._kernel_info_requests.append(msg.header.get("msg_id"))
        ioloop.IOLoop.current().call_later(3, self._send_proxy_kernel_info, data)
        return data

    def _on_kernel_info_reply(self, server, target_stream, data):
        msg = JupyterMessage.parse(data)
        if msg.parent_header.get("msg_id") in self._kernel_info_requests:
            self._kernel_info_requests.remove(msg.parent_header.get("msg_id"))
        elif len(self._kernel_info_requests) > 0:
            self._kernel_info_requests.pop(0)
        return data

    def _send_proxy_kernel_info(self, request) -> None:
        parent = JupyterMessage.parse(request)
        if parent.header.get("msg_id") not in self._kernel_info_requests:
            return
        msg = self.server.make_multipart_message(
            "kernel_info_reply",
            {
                "status": "ok",
                "protocol_version": "5.3",
                "implementation": "proxy",
                "banner": "OrangeQS Juice service proxy."
                f" Service {self.service_name} does not respond.",
                "language_info": {
                    "name": "magic",
                },
            },
            parent_header=parent.header,
        )
        self.server.streams.shell.send_multipart(parent.identities + msg)
        self.server.streams.iopub.send_multipart(
            self.server.make_multipart_message(
                "stream",
                {
                    "name": "stderr",
                    "text": "Target kernel did not reply.",
                },
            )
        )
        self.server.streams.iopub.send_multipart(
            self.server.make_multipart_message(
                "status", {"execution_state": "idle"}, parent_header=parent.header
            )
        )
        self._kernel_info_requests.remove(parent.header.get("msg_id"))

    def connect(self, request_kernel_info: bool = False) -> None:
        """Connect to a service."""
        self.connected_kernel = ProxyKernelClient(self.service_connection_info)
        self.server.set_proxy_target(self.connected_kernel)
        if request_kernel_info:
            req = self.connected_kernel.make_multipart_message("kernel_info_request")
            self._on_kernel_info_request(
                self.server, self.connected_kernel.streams.shell, req
            )
            self.connected_kernel.streams.shell.send_multipart(req)


def start_proxy_kernel(service_name: str, connection_file: str) -> None:
    """
    Start a proxy kernel for an OrangeQS Juice service.

    Parameters
    ----------
    service_name
        Name of the OrangeQS Juice service to proxy requests to.
    connection_file
        Path to a kernel connection file for the proxy process itself.
        This file is provided by Jupyter when starting the proxy from the launcher.
    """
    loop = ioloop.IOLoop.current()

    kernel_configs = KernelConnectionRegistry.load()
    if service_name not in kernel_configs.services:
        print(
            (
                f"Service {service_name} not found in the kernel connection registry. "
                "This indicates that the service might not be running."
            ),
            file=sys.stderr,
        )
        sys.exit(1)

    service_connection_info = kernel_configs.services[service_name].model_dump()
    proxy_connection_info = json.loads(Path(connection_file).read_text())

    _ = _KernelProxy(proxy_connection_info, service_connection_info, service_name)

    loop.start()
