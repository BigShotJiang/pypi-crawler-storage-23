"""Handlers and Utilities for Service Logging."""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any

from influxdb_client.client.write_api import WriteOptions, WriteType

from orangeqs.juice.client import influxdb2
from orangeqs.juice.schemas.logging import LogEvent

if TYPE_CHECKING:
    from logging import LogRecord


def _serialize_log_record(log_record: LogRecord) -> str:
    return json.dumps(
        {
            "name": log_record.name,
            "levelname": log_record.levelname,
            "message": log_record.getMessage(),
            "pathname": log_record.pathname,
            "lineno": log_record.lineno,
            "created": log_record.created,
            "thread": log_record.thread,
            "process": log_record.process,
        }
    )


class JuiceInfluxLoggingHandler(logging.Handler):
    """
    JuiceInfluxLoggingHandler instances dispatch logging events to influx.

    There is no need to set a Formatter.
    The raw input will be passed on to the influx write api.
    """

    DEFAULT_LOG_RECORD_KEYS = list(logging.makeLogRecord({}).__dict__.keys()) + [
        "message"
    ]

    def __init__(self, *, bucket: str, service: str) -> None:
        """
        Initialize defaults.

        The arguments `client_args` and `write_api_args` can be dicts of kwargs.
        They are passed on to the InfluxDBClient and write_api calls respectively.
        """
        super().__init__()

        self.juice_service_name = service

        self.bucket = bucket
        self.client = influxdb2.influxdb2_client()

        self.write_api = influxdb2.influxdb2_write_api(
            write_options=WriteOptions(write_type=WriteType.synchronous)
        )

    def __del__(self) -> None:
        """Make sure all resources are closed."""
        self.close()

    def close(self) -> None:
        """Close the write_api, client and logger."""
        self.write_api.close()
        self.client.close()
        super().close()

    def emit(self, record: logging.LogRecord) -> None:
        """Emit a record via the influxDB WriteApi."""
        try:
            point = LogEvent(
                service=self.juice_service_name,
                level=record.levelno,
                serialized_record=_serialize_log_record(record),
            )
            point.write(
                self.write_api,
                bucket=self.bucket,
            )
        except Exception:
            self.handleError(record)

    def _get_extra_values(self, record: logging.LogRecord) -> dict[str, Any]:
        """
        Extract all items from the record that were injected via extra.

        Example: `logging.debug(msg, extra={key: value, ...})`.
        """
        extra = {"bucket": self.bucket}
        extra.update(
            {
                key: value
                for key, value in record.__dict__.items()
                if key not in self.DEFAULT_LOG_RECORD_KEYS
            }
        )
        return extra
