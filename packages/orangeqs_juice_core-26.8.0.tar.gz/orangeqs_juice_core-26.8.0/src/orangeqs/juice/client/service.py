"""Client functions for interacting with Juice services."""

import os
import subprocess
import xmlrpc.client
from typing import Literal

from jupyter_core.utils import run_sync

from orangeqs.juice.client._client import Client
from orangeqs.juice.client._utils import restart_supervisor_process
from orangeqs.juice.client.identity import get_identity
from orangeqs.juice.messaging._rpc._client import UnixStreamXMLRPCClient
from orangeqs.juice.schemas.tasks import RebuildEnvironmentDryRun


def restart_service(
    service_name: str, method: Literal["full", "partial"] = "full"
) -> None:
    """Restart an OrangeQS Juice service.

    Parameters
    ----------
    service_name : str
        The name of the OrangeQS Juice service to restart.
    method : "full" | "partial", optional
        The restart method to use. Defaults to "full".
        - "full": Restart the container running the service. This will use the newest
            version of the service image. Uses the Juice Orchestrator RPC.
        - "partial": Restart the service process inside the container without restarting
            the container itself. Uses the Supervisor RPC inside the container.
    """
    from orangeqs.juice.orchestration.settings import OrchestrationSettings

    orchestration_settings = OrchestrationSettings.load()
    if service_name not in orchestration_settings.services:
        raise ValueError(f"Service '{service_name}' not found")

    if method == "full":
        _restart_service_full(service_name)
    elif method == "partial":
        _restart_service_partial(service_name)
    else:
        raise ValueError(f"Invalid restart method: {method}")


def rebuild_service(
    service_name: str, mode: Literal["safe", "force", "dry-run"] = "safe"
) -> None:
    """Rebuild an OrangeQS Juice service by name.

    Parameters
    ----------
    service_name : str
        The name of the service to rebuild. This should correspond to
        a valid OrangeQS Juice service or the "singleuser" environment.
    mode : "safe" | "force" | "dry-run", optional
        The rebuild mode to use. Defaults to "safe".
        - "safe": Do a dry-run inside the service first, then rebuild if successful.
        - "force": Rebuild the service directly without a dry-run.
        - "dry-run": Only perform a dry-run inside the service.
    """
    # TODO: Support verbose output for successful (dry-run) rebuilds.

    if mode == "safe" or mode == "dry-run":
        success, output = _rebuild_service_dry_run(service_name)
        if not success:
            raise RuntimeError(
                f"Dry-run rebuild failed for service {service_name}:\n"
                + "\n".join(output)
            )

        if mode == "dry-run":
            return

    client = _orchestrator_rpc_client()
    try:
        client.rebuild_service(service_name)
    except xmlrpc.client.Fault as e:
        match e.faultCode:
            case 1:
                raise RuntimeError(
                    f"Failed to rebuild service {service_name}:\n{e.faultString}"
                )
            case _:
                raise


def _orchestrator_rpc_client() -> UnixStreamXMLRPCClient:
    """Create an XML-RPC client for the orchestrator."""
    from orangeqs.juice._orchestrator import ORCHESTRATOR_SOCKET_PATH

    return UnixStreamXMLRPCClient(ORCHESTRATOR_SOCKET_PATH)


def _restart_service_partial(service_name: str) -> None:
    """Restart the service without restarting the container."""
    supervisor_url = f"http://juice-{service_name}:9001/RPC2"
    restart_supervisor_process("juice-service", supervisor_url)


def _restart_service_full(service_name: str) -> None:
    """Restart the service by restarting the container."""
    client = _orchestrator_rpc_client()
    try:
        client.restart_service(service_name)
    except xmlrpc.client.Fault as e:
        match e.faultCode:
            case 1:
                raise RuntimeError(
                    f"Failed to restart service {service_name}:\n{e.faultString}"
                )
            case _:
                raise


def _rebuild_service_dry_run(service_name: str) -> tuple[bool, list[str]]:
    """Run a dry-run rebuild of the environment for a service.

    Parameters
    ----------
    service_name : str
        The name of the service to rebuild.

    Returns
    -------
    bool
        Whether the dry-run command was successful.
    list[str]
        The output lines from the dry-run command.
    """
    from orangeqs.juice.orchestration.environment import list_environments
    from orangeqs.juice.orchestration.settings import OrchestrationSettings

    settings = OrchestrationSettings.load()
    environments = list_environments(settings)
    if service_name not in environments:
        raise ValueError(f"Invalid service name: {service_name}")

    environment = environments[service_name]
    if environment.type != "uv":
        raise ValueError(
            f"Dry-run rebuild is only supported for 'uv' environments, "
            f"but service {service_name} has environment type '{environment.type}'."
        )

    if service_name == "singleuser":
        if get_identity()[0] != "user":
            raise ValueError(
                "Dry-run rebuild is only supported for the singleuser environment "
                "when run as a user."
            )

        return _uv_sync_dry_run()

    async def _service_dry_run() -> tuple[bool, list[str]]:
        return (
            await Client().execute(service_name, RebuildEnvironmentDryRun(), check=True)
        ).result

    return run_sync(_service_dry_run)()


def _uv_sync_dry_run() -> tuple[bool, list[str]]:
    """Run `uv sync --dry-run` in the current context.

    Returns
    -------
    bool
        Whether the dry-run command was successful.
    list[str]
        The output lines from the dry-run command.
    """
    result = subprocess.run(
        ["uv", "sync", "--dry-run", "--upgrade"],
        capture_output=True,
        env={"NO_COLOR": "1"} | os.environ,
    )
    # uv writes dry-run output to stderr, even on success.
    return result.returncode == 0, result.stderr.decode().splitlines()
