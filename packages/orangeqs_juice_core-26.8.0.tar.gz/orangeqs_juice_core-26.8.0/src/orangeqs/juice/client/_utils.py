"""Common utility functions for the Juice client libraries."""

import logging
import sys
import xmlrpc.client

logger = logging.getLogger(__name__)


def restart_supervisor_process(
    process_name: str,
    server_url: str = "http://localhost:9001/RPC2",
    is_dashboard_service_origin: bool = False,
) -> None:
    """
    Restarts a Supervisor-managed process using XML-RPC.

    Parameters
    ----------
        process_name
            The name of the process to restart.
        server_url
            The URL of the Supervisor XML-RPC server.
        is_dashboard_service_origin
            Indicates if the command is issued by the dashboard service itself.
    """
    if is_dashboard_service_origin:
        sys.exit(0)

    server = xmlrpc.client.ServerProxy(server_url)

    # First, we stop the process.
    try:
        server.supervisor.stopProcess(process_name)
    # We handle some specific faults here.
    # Fault codes: https://github.com/Supervisor/supervisor/blob/main/supervisor/xmlrpc.py#L26
    except xmlrpc.client.Fault as e:
        match e.faultCode:
            case 10:
                raise RuntimeError(f"Process '{process_name}' not found") from e
            case 70:  # If the process is not running, we suppress the error.
                pass
            case _:
                raise RuntimeError("Supervisor XML-RPC fault") from e
    except Exception as e:
        raise RuntimeError("Unexpected error") from e
    # Then, we start the process.
    try:
        server.supervisor.startProcess(process_name)
    except xmlrpc.client.Fault as e:
        raise RuntimeError("Supervisor XML-RPC fault") from e
    except Exception as e:
        raise RuntimeError("Unexpected error") from e
    logger.info(f"Successfully restarted process: {process_name}")
