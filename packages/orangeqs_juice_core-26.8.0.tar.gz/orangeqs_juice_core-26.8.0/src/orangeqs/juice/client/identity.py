"""Module to handle identity management for Juice."""

import os
from typing import Literal


def get_identity() -> tuple[Literal["service", "user"], str]:
    """Get the identity of the current context."""
    identity = os.getenv("JUICE_IDENTITY", "user-unknown")
    identity_type, identity_name = identity.split("-", 1)
    if identity_type not in ("service", "user"):
        raise ValueError(
            f"Invalid identity type: {identity_type}, must be 'service' or 'user'."
        )
    return identity_type, identity_name
