"""ZMQ proxy for pub/sub messaging."""

import logging

import zmq
import zmq.asyncio

_logger = logging.getLogger(__name__)


class ZMQProxy:
    """ZMQ proxy for pub/sub messaging."""

    def __init__(self, pub_uri: str, sub_uri: str) -> None:
        context = zmq.asyncio.Context.instance()

        # Socket to subscribe to for events, which is a pub socket.
        self._pub = context.socket(zmq.PUB)
        self._pub.linger = 0
        self._pub.bind(sub_uri)  # sub_uri is named from client perspective

        # Socket to publish new events to, which is a sub socket.
        self._sub = context.socket(zmq.SUB)
        self._sub.linger = 0
        self._sub.setsockopt(zmq.SUBSCRIBE, b"")
        self._sub.bind(pub_uri)  # pub_uri is named from client perspective

    async def run(self) -> None:
        """Run ZMQ proxy for pub/sub messaging.

        Runs indefinitely until an exception is encountered
        or the process is interrupted.
        """
        _logger.info("Starting pub/sub proxy")
        try:
            poller = zmq.asyncio.Poller()
            poller.register(self._sub, zmq.POLLIN)
            while True:
                # We set a low poll timeout to allow the underlying thread to process
                # internal commands/events.
                # See https://github.com/zeromq/libzmq/issues/2267#issuecomment-334279757
                events = await poller.poll(timeout=100)
                events = dict(events)
                if self._sub in events:
                    try:
                        # We should not use zmq.DONTWAIT as the multipart message might
                        # not be fully received yet.
                        msg = await self._sub.recv_multipart()
                        await self._pub.send_multipart(msg)  # pyright: ignore[reportUnknownMemberType]
                    except zmq.ZMQError as e:
                        if e.errno == zmq.ETERM:
                            _logger.warning(
                                "Stopping ZMQ pub/sub proxy since ETERM was received."
                            )
                            break
                        else:
                            raise
        except Exception:
            _logger.exception("ZMQ pub/sub proxy encountered an exception.")
            raise
        finally:
            self._sub.close()
            self._pub.close()
