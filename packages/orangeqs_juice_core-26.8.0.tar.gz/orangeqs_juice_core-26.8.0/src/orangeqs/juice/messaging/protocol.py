"""Protocol interfaces for messaging between Juice services.

This module defines generic interfaces that should be implemented using a base protocol,
e.g ZMQ.
All interfaces in this module are agnostic to both the underlying protocol
and Juice itself. This means that this module contains no references to Juice and/or the
underlying protocol.

Both the subscriber and publisher are expected to connect to a central proxy
such that one can publish and subscribe to messages from a single source.

As of now this module only contains interfaces for pub/sub messaging.
In the future it will also include standard interfaces for request/reply.
"""

from __future__ import annotations

import sys
from abc import ABCMeta
from typing import TYPE_CHECKING, Protocol, TypeVar, runtime_checkable

from orangeqs.juice.database import Point
from orangeqs.juice.messaging.message import Message

if sys.version_info >= (3, 13):
    from warnings import deprecated
else:
    from typing_extensions import deprecated

if TYPE_CHECKING:
    import asyncio


##########################
#        Pub Sub         #
##########################


class Event(Message, Point, metaclass=ABCMeta):
    """Message representing an event that is published to Juice services.

    Other events sent over pub/sub must inherit this class.
    See {class}`~.messaging.message.Message` for more information.
    This class also inherits from {class}`~.database.point.Point`
    which allows these events to be stored in the database.

    Examples
    --------
    For example, one can add an event that represents a kernel status changing.

    ```python
    class KernelStatusChanged(Event):
        def topic(self) -> str:
            return self.service

        service: str
        status: str
    ```

    This event includes two fields (service and status).
    Additionally, it marks that the topic of the event should be the service name.
    Now, subscribers can use a topic filter to only subscribe to kernel status updates
    of a specific service.
    If the subscriber does not add a topic filter it will receive all kernel status
    updates by default.

    Also see {meth}`~Event.topic`.
    """

    def topic(self) -> str | None:
        """
        Topic of the message.

        Can be used by listeners to filter events of the same type.
        Can be implemented by subclasses to provide fine control on subscriptions.
        Defaults to no topic.

        See the docstring of {class}`~Event` for more information on how to use topics.

        Returns
        -------
        str
            The topic of this event.
        """
        return None


EventType = TypeVar("EventType", bound=Event)
"""Type variable for {class}`~Event`."""


@runtime_checkable
class SubscriberAsync(Protocol[EventType]):
    """Asynchronous client for subscribing to events from other Juice services.

    The subscriber will not receive any events until you subscribe to events.
    See {meth}`.SubscriberAsync.subscribe` for subscribing to events.

    See {class}`PublisherAsync` or {class}`PublisherBlocking` for publishing events.

    Examples
    --------
    Instantiate a subscriber, and run two coroutines to listen and print
    new events.

    ```python
    subscriber = SubscriberAsync("<uri>")
    subscriber.subscribe(DummyEvent, topic="something"))

    async def log_events():
        event = await subscriber.queue.get()
        assert type(event) == DummyEvent
        assert event.topic().startswith("something")
        print(f"Received {type(event)} with data {event}")

    asyncio.gather(subscriber.listen(), log_events())
    ```

    Parameters
    ----------
    uri : str
        URI to connect the subscriber to. Format is implementation dependent.
    queue : asyncio.Queue, optional
        Optional queue new messages will be put in.
        Will instantiate a new queue if not provided.
    """

    # TODO: Should we support listening to multiple event types at once?

    queue: asyncio.Queue[EventType]
    """Queue to which new messages will be put that are received by `listen()`."""

    def __init__(
        self,
        uri: str,
        *,
        queue: asyncio.Queue[EventType] | None = None,
    ) -> None: ...

    def subscribe(
        self,
        event_type: type[EventType],
        *,
        topic: str | None = None,
    ) -> None:
        """Subscribe to an event.

        It is possible to subscribe to multiple event types and/or topics.
        The subscriber allows filtering by event type and an optional topic.
        The topic filter checks if the topic of the event
        starts with the topic filter.
        This means that a topic filter with value `"a.b"` will match events with topic
        `"a.b"` and `"a.b.c"`, but not `"a.c"` or  `"a.bb"`.
        Note that each topic filter always targets a specific event type,
        thus they are not shared between different event types.

        Parameters
        ----------
        event_type : type[EventType]
            Type of event to subscribe to. Will subscribe only to one specific event
            type, so not types that inherit this type.
        topic : str, optional
            Optional topic to filter events. See above for explanation.
            If not provided will subscribe to all events of specified type.
        """
        ...

    def stop(self) -> None:
        """Stop listening for new events.

        Stops the {meth}`~listen` coroutine.
        """
        ...

    async def listen(self) -> None:
        """
        Coroutine to listen for new events and append them to the queue.

        Runs continuously until `.stop()` is called.
        This coroutine should be continuously running to receive new messages
        and append them to the queue.
        """
        ...


class SubscriberBlocking(Protocol[EventType]):
    """Synchronous blocking client for subscribing to events from other Juice services.

    The subscriber will not receive any events until you subscribe to events.
    See {meth}`.subscribe` for subscribing to events.

    See {class}`PublisherBlocking` or {class}`PublisherAsync` for publishing events.

    Examples
    --------
    Instantiate a subscriber and wait for new events.

    ```python
    subscriber = SubscriberBlocking("<uri>")
    subscriber.subscribe(DummyEvent, topic="something"))

    subscriber.get()  # Blocking call to get the next event
    ```

    Parameters
    ----------
    uri : str
        URI to connect the subscriber to. Format is implementation dependent.
    """

    def __init__(
        self,
        uri: str,
        /,
    ) -> None: ...

    def subscribe(
        self,
        event_type: type[EventType],
        /,
        *,
        topic: str | None = None,
    ) -> None:
        """Subscribe to an event.

        It is possible to subscribe to multiple event types and/or topics.
        The subscriber allows filtering by event type and an optional topic.
        The topic filter checks if the topic of the event
        starts with the topic filter.
        This means that a topic filter with value `"a.b"` will match events with topic
        `"a.b"` and `"a.b.c"`, but not `"a.c"` or  `"a.bb"`.
        Note that each topic filter always targets a specific event type,
        thus they are not shared between different event types.

        Parameters
        ----------
        event_type : type[EventType]
            Type of event to subscribe to. Will subscribe only to one specific event
            type, so not types that inherit this type.
        topic : str, optional
            Optional topic to filter events. See above for explanation.
            If not provided will subscribe to all events of specified type.
        """
        ...

    def get(self, timeout: float | None = None) -> EventType:
        """
        Get the next event from the subscriber.

        This is a blocking call that waits until a new event is received.

        Parameters
        ----------
        timeout : float, optional
            Optional timeout in seconds to wait for a new event.
            If not provided, will wait indefinitely.

        Raises
        ------
        TimeoutError
            If a timeout is provided and no event is received within the timeout period.
        """
        ...


class PublisherAsync(Protocol, metaclass=ABCMeta):
    """Asynchronous client for publishing events to other Juice services.

    See {class}`SubscriberAsync` or {class}`SubscriberBlocking`
    for subscribing to events.

    Examples
    --------
    Instantiate a publisher and publish an event.

    ```python
    publisher = PublisherAsync("<uri>")
    await publisher.publish(DummyEvent(data="data"))
    ```

    Parameters
    ----------
    uri : str
        URI to connect the publisher to. Format is implementation dependent.
    """

    def __init__(
        self,
        uri: str,
    ) -> None: ...

    async def publish(self, event: Event) -> None:
        """
        Publish a message to the system.

        Parameters
        ----------
        event : Event
            Event to be published.
        """
        ...


class PublisherBlocking(Protocol, metaclass=ABCMeta):
    """Synchronous blocking client for publishing events to other Juice services.

    See {class}`SubscriberBlocking` or {class}`SubscriberAsync`
    for subscribing to events.

    Examples
    --------
    Instantiate a publisher and publish an event.

    ```python
    publisher = PublisherBlocking("<uri>")
    publisher.publish(DummyEvent(data="data"))
    ```

    Parameters
    ----------
    uri : str
        URI to connect the publisher to. Format is implementation dependent.
    """

    def __init__(
        self,
        uri: str,
    ) -> None: ...

    def publish(self, event: Event) -> None:
        """
        Publish a message to the system.

        Parameters
        ----------
        event : Event
            Event to be published.
        """
        ...


@deprecated("The name Subscriber is deprecated. Use SubscriberAsync instead.")
class Subscriber(SubscriberAsync[EventType], Protocol):  # noqa: D101
    pass


@deprecated("The name Publisher is deprecated. Use PublisherAsync instead.")
class Publisher(PublisherAsync, Protocol):  # noqa: D101
    pass


##########################
#     Request reply      #
##########################

# TODO: Add interfaces for request/reply here.
# For now this has been postponed.

__all__ = [
    "Event",
    "SubscriberAsync",
    "SubscriberBlocking",
    "PublisherAsync",
    "PublisherBlocking",
]
