"""Internal utilities for Juice."""

import asyncio
from collections.abc import Awaitable, Callable
from functools import wraps
from threading import Thread
from typing import ParamSpec, TypeVar, overload

_BaseException = TypeVar("_BaseException", bound=BaseException)


def add_note(exception: _BaseException, note: str) -> _BaseException:
    """Add a note to an exception, backported for Python <3.11.

    Ensures the exception is rendered the same way as `BaseException.add_note()`
    which was added in Python 3.11.
    See https://docs.python.org/3/library/exceptions.html#BaseException.add_note.

    Parameters
    ----------
    exception : BaseException
        The exception to attach the note to.
    note : str
        The note to attach.
    """
    # TODO: Migrate to BaseException.add_note() once we drop support for Python 3.10
    args = exception.args
    arg0 = note if not args else f"{args[0]}\n{note}"
    exception.args = (arg0,) + args[1:]
    return exception


_T = TypeVar("_T")
_P = ParamSpec("_P")


@overload
def rerun_on_exception(
    coro: Callable[_P, Awaitable[_T]],
) -> Callable[_P, Awaitable[_T]]: ...
@overload
def rerun_on_exception(
    *,
    sleeptime_s: float = 5.0,
) -> Callable[[Callable[_P, Awaitable[_T]]], Callable[_P, Awaitable[_T]]]: ...
def rerun_on_exception(
    coro: Callable[_P, Awaitable[_T]] | None = None,
    *,
    sleeptime_s: float = 5.0,
) -> (
    Callable[[Callable[_P, Awaitable[_T]]], Callable[_P, Awaitable[_T]]]
    | Callable[_P, Awaitable[_T]]
):
    """
    Rerun async function on exception.

    To prevent busy threads, sleep before rerun. The `sleeptime_s` parameter
    specifies the time to sleep before retrying. This decorator can both be used with
    and without parameters: `@rerun_on_exception` or
    `@rerun_on_exception(sleeptime_s=10)`.

    Parameters
    ----------
    sleeptime_s : float, optional
        Time to sleep before retrying, in seconds. Default is 5.0 seconds.
    """

    def _rerun_on_exception(
        coro: Callable[_P, Awaitable[_T]],
    ) -> Callable[_P, Awaitable[_T]]:
        @wraps(coro)
        async def wrapper(*args: _P.args, **kwargs: _P.kwargs) -> _T:
            while True:
                try:
                    return await coro(*args, **kwargs)
                except Exception:
                    await asyncio.sleep(sleeptime_s)

        return wrapper

    if coro is not None:
        return _rerun_on_exception(coro)
    return _rerun_on_exception


def spawn_thread(future: Awaitable[None]) -> Thread:
    """Spawn a thread to run an async function."""

    def _task() -> None:
        loop = asyncio.new_event_loop()
        loop.run_until_complete(future)

    thread = Thread(target=_task, daemon=True)
    thread.start()
    return thread
