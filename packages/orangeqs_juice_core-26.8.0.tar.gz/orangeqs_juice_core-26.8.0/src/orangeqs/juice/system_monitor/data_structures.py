"""Data Structures for the System Monitor."""

from __future__ import annotations

from typing import Annotated, ClassVar

from orangeqs.juice.messaging import Event

DEFAULT_SERVICE_NAME = "system-monitor"


class TemperaturePoint(Event):
    """Temperature Point for pubsub and database update."""

    measurement: ClassVar[str] = "temperature_measurement"
    """Measurement name for temperature measurement."""

    def topic(self) -> str:
        """Return the topic for the temperature event."""
        return f"{self.service_name}.{self.component_id}.{self.sensor_id}"

    service_name: Annotated[str, "tag"] = DEFAULT_SERVICE_NAME
    """Service name."""

    component_id: Annotated[str, "tag"]
    """Component ID."""

    sensor_id: Annotated[str, "tag"]
    """Sensor ID."""

    level: Annotated[str, "tag"] = "N/A"
    """Level where the sensor is placed, used by only the cryostat thermometers."""

    temperature: float
    """The temperature reading from the sensor."""


class PressurePoint(Event):
    """Pressure measurement Point."""

    measurement: ClassVar[str] = "pressure_measurement"
    """Measurement name for pressure measurement."""

    def topic(self) -> str:
        """Return the topic for the pressure measurement."""
        return f"{self.service_name}.{self.component_id}.{self.sensor_id}"

    service_name: Annotated[str, "tag"] = DEFAULT_SERVICE_NAME
    """Service name."""

    component_id: Annotated[str, "tag"]
    """Component ID that measured this pressure."""

    sensor_id: Annotated[str, "tag"]
    """Sensor ID that measured this pressure."""

    pressure: float
    """Measured pressure value."""

    unit: str
    """Unit of the pressure measurement."""


class ValvesettingPoint(Event):
    """Valve setting Point."""

    measurement: ClassVar[str] = "valve_setting"
    """Measurement name for valve setting."""

    def topic(self) -> str:
        """Return the topic for the pressure measurement."""
        return f"{self.service_name}.{self.component_id}.{self.valve_id}"

    service_name: Annotated[str, "tag"] = DEFAULT_SERVICE_NAME
    """Service name."""

    component_id: Annotated[str, "tag"]
    """Component ID containing the valve."""

    valve_id: Annotated[str, "tag"]
    """ID of the valve."""

    open: bool
    """Open flag of the valve."""


class FlowratePoint(Event):
    """Flowrate measurement Point."""

    measurement: ClassVar[str] = "flowrate_measurement"
    """Measurement name for flowrate measurement."""

    def topic(self) -> str:
        """Return the topic for the flowrate measurement."""
        return f"{self.service_name}.{self.component_id}.{self.sensor_id}"

    service_name: Annotated[str, "tag"] = DEFAULT_SERVICE_NAME
    """Service name."""

    component_id: Annotated[str, "tag"]
    """Component ID that measured this flowrate."""

    sensor_id: Annotated[str, "tag"]
    """Sensor ID that measured this flowrate."""

    flowrate: float
    """Measured flowrate value."""

    unit: str
    """Unit of the flowrate measurement."""


class StatusmessagePoint(Event):
    """Status message Point."""

    measurement: ClassVar[str] = "status_message"
    """Measurement name for status message."""

    def topic(self) -> str:
        """Return the topic for the status message."""
        return f"{self.service_name}.{self.component_id}.{self.message_id}"

    service_name: Annotated[str, "tag"] = DEFAULT_SERVICE_NAME
    """Service name."""

    component_id: Annotated[str, "tag"]
    """Component ID that generated this status message."""

    message_id: Annotated[str, "tag"]
    """Status message ID."""

    level: Annotated[str, "tag"]
    """Level of the status message (e.g., INFO, WARNING, ERROR)."""

    message: str
    """The status message content."""


class ComponentEnabledPoint(Event):
    """Component enabled state Point."""

    measurement: ClassVar[str] = "component_enabled_state"
    """Measurement name for component enabled state."""

    def topic(self) -> str:
        """Return the topic for the component enabled state."""
        return f"{self.service_name}.{self.component_id}"

    component_id: Annotated[str, "tag"]
    """Component ID."""

    service_name: Annotated[str, "tag"] = DEFAULT_SERVICE_NAME
    """Service name."""

    enabled: bool
    """Whether the component is enabled."""


class PowerSettingPoint(Event):
    """Power setting Point."""

    measurement: ClassVar[str] = "power_setting"
    """Measurement name for power setting."""

    def topic(self) -> str:
        """Return the topic for the power setting."""
        return f"{self.service_name}.{self.component_id}"

    component_id: Annotated[str, "tag"]
    """Component ID."""

    service_name: Annotated[str, "tag"] = DEFAULT_SERVICE_NAME
    """Service name."""

    power_setting: float
    """The power setting of the component."""

    unit: str
    """The unit of the power setting."""

    output_power: float  # Should be float("nan") by default, see #166
    """The current power of the component."""
