"""Orchestrator for the OrangeQS Juice installation.

Runs on the host system and provides XML-RPC methods for managing the installation.
For now this is limited to rebuilding services.
"""

from ._server import ORCHESTRATOR_SOCKET_PATH, start

__all__ = [
    "ORCHESTRATOR_SOCKET_PATH",
    "start",
]
