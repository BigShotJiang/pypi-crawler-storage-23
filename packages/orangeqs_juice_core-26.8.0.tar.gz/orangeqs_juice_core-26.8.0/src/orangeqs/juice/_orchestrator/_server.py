import os
from pathlib import Path

from orangeqs.juice.orchestration.settings import OrchestrationSettings
from orangeqs.juice.settings import SHARED_RUNTIME_PATH

ORCHESTRATOR_SOCKET_PATH = str(Path(SHARED_RUNTIME_PATH) / "orchestrator.sock")


def start() -> None:
    """
    Start the Juice Orchestrator XML-RPC server.

    This server listens on a Unix domain socket and provides methods
    for orchestrating Juice services. Must be run on the host system.

    The server runs indefinitely until interrupted.
    """
    from orangeqs.juice.messaging._rpc import UnixStreamXMLRPCServer

    from ._handlers import rebuild_service, restart_service

    settings = OrchestrationSettings.load()

    # Clean up any existing socket file
    Path(ORCHESTRATOR_SOCKET_PATH).unlink(missing_ok=True)

    with UnixStreamXMLRPCServer(ORCHESTRATOR_SOCKET_PATH) as server:
        # By default the socket is owned by root, change to the data folder user
        # such that services/users can write to it.
        os.chown(
            ORCHESTRATOR_SOCKET_PATH,
            settings.data_folder.user_id,
            settings.data_folder.group_id,
        )

        server.register_introspection_functions()

        server.register_function(rebuild_service)
        server.register_function(restart_service)

        server.serve_forever()
