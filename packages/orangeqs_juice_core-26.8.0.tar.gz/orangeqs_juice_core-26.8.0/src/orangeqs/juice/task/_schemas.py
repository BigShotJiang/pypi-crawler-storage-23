"""Schemas for task results and errors."""

from typing import Annotated, Any, Literal

from pydantic import BaseModel, Field


class TaskResultOk(BaseModel):
    """Result information of a successfully completed task."""

    status: Literal["ok"] = "ok"

    id: str
    """The unique identifier of the task."""

    result: Any
    """The result of the task execution."""


class TaskResultError(BaseModel):
    """Result information of a task that raised an error."""

    status: Literal["error"] = "error"

    id: str
    """The unique identifier of the task."""

    ename: str
    """The name of the error type."""

    evalue: str
    """The error message."""

    traceback: str
    """The traceback of the error."""


TaskResult = Annotated[TaskResultOk | TaskResultError, Field(discriminator="status")]
"""Union of all possible task results.
Either {class}`~.task.TaskResultOk` or {class}`~.task.TaskResultError`.
"""


class TaskExecutionError(Exception):
    """Task execution error, raised if a task fails.

    Raised by {meth}`~orangeqs.juice.Client.request` and
    {meth}`~orangeqs.juice.Client.execute` when a task fails with `check=True`
    """

    error: TaskResultError
    """The wrapped error details."""

    def __init__(self, error: TaskResultError) -> None:
        super().__init__(f"Task {error.id} failed: {error.ename}: {error.evalue}")
        self.error = error

    def __str__(self) -> str:
        return (
            f"Task {self.error.id} failed:\n{self.error.ename}: {self.error.evalue}\n"
        )

    @property
    def traceback(self) -> str:
        """The traceback of the error."""
        return self.error.traceback
