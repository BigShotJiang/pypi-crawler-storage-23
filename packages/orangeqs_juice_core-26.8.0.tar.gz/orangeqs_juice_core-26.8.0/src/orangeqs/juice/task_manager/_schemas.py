from typing import Annotated, ClassVar, Literal

from orangeqs.juice.messaging import Event


class TaskEvent(Event):
    """Model for a task event from client.

    Model that represents a task event sent from a client to the task manager.
    This model is used to write the task to the database.
    And also publish it to subscribers.
    """

    measurement: ClassVar[str] = "task_event"

    task_id: str
    """The unique identifier of the task."""

    task_target: str
    """The target service of the task."""

    task_type: str
    """The type of the task."""

    task_display_name: str
    """The display name of the task."""

    task_metadata: str
    """Metadata associated with the task.

    This field contains a JSON-serialized string representing the metadata
    dictionary for the task.
    """

    task_payload: str
    """The payload of the task.

    This field contains a JSON-serialized string representing the payload
    dictionary for the task.
    """

    task_state: Annotated[Literal["created", "started", "completed", "failed"], "tag"]
    """The current status of the task."""


class IPythonServiceState(Event):
    """Model for a IPython service state event.

    Model that represents the state of a service.
    This model is used to write the service state to the database
    and also publish it to subscribers.
    """

    def topic(self) -> str:
        """Return the topic for event."""
        return self.service

    measurement: ClassVar[str] = "service_state"

    service: Annotated[str, "tag"]
    """The name of the service."""

    state: Literal["idle", "busy", "restarting", "connecting", "unknown"]
    """The current state of the service."""
