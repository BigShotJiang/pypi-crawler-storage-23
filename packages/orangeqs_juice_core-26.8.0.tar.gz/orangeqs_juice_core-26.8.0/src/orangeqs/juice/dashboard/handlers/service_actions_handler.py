"""Handler to restart or rebuild services."""

from typing import Any

import tornado.web
from typing_extensions import override

from orangeqs.juice.client.service import rebuild_service, restart_service


class ServiceActionHandler(tornado.web.RequestHandler):
    """Handles POST requests to restart or rebuild services.

    Expects a JSON body with 'service' and 'action' keys.
    Supported actions are 'restart' and 'rebuild'.
    """

    @override
    def initialize(
        self,
        template_variables: dict[str, Any],
        *args,  # noqa: ANN002 # type: ignore
        **kwargs,  # noqa: ANN003 # type: ignore
    ) -> None:
        """Discard template variables."""
        super().initialize(*args, **kwargs)

    def post(self) -> None:
        """Handle POST requests to restart or rebuild a service.

        Expects a JSON body with 'service' and 'action' keys.
        Supported actions are 'restart' and 'rebuild'.
        """
        data = tornado.escape.json_decode(self.request.body)
        service = data.get("service")
        action = data.get("action")
        if action == "restart process":
            restart_service(service, method="partial")
        elif action == "restart container":
            restart_service(service, method="full")
        elif action == "rebuild":
            rebuild_service(service, mode="safe")
        self.write({"status": "ok"})  # pyright: ignore[reportUnknownMemberType]
