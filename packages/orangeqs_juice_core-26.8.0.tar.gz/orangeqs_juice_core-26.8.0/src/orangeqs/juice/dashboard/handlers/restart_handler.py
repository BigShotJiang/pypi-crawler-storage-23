"""Handler to restart the dashboard server."""

from typing import Any

from tornado import web
from typing_extensions import override

from orangeqs.juice.client.dashboard import restart_dashboard


class RestartDashboardHandler(web.RequestHandler):
    """Handler to restart the dashboard server."""

    @override
    def initialize(
        self,
        template_variables: dict[str, Any],
        *args,  # noqa: ANN002 # type: ignore
        **kwargs,  # noqa: ANN003 # type: ignore
    ) -> None:
        """Discard template variables."""
        super().initialize(*args, **kwargs)

    def post(self) -> None:
        """Handle POST request to restart the dashboard server."""
        restart_dashboard(is_dashboard_service_origin=True)
