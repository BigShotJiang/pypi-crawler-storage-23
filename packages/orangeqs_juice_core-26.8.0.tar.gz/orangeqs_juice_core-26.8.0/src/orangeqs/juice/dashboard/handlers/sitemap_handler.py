"""Provides API for routing within HTTPServer for dashboard."""

from __future__ import annotations

import logging
import os
from typing import Any

import tornado.routing
from tornado import web
from typing_extensions import override

_logger = logging.getLogger(__name__)


def _descend_routes(
    router: tornado.routing.Router,
    routers: set[tornado.routing.Router] | None = None,
    out: set[str] | None = None,
) -> None:
    """
    Recursively collects all route patterns and static file paths from a Tornado router.

    Parameters
    ----------
    router : tornado.routing.Router
        The router to descend.
    routers : set of tornado.routing.Router, optional
        Set of already visited routers to avoid cycles.
    out : set of str, optional
        Set to collect discovered route patterns and static file paths.

    Returns
    -------
    None
    """
    if routers is None:
        routers = set()
    if out is None:
        out = set()
    if router in routers:
        return
    routers.add(router)
    for rule in list(router.named_rules.values()) + router.rules:
        if isinstance(rule.matcher, tornado.routing.PathMatches):
            if issubclass(rule.target, tornado.web.StaticFileHandler):
                prefix = rule.matcher.regex.pattern.rstrip("(.*)$").rstrip("/")
                path = rule.target_kwargs["path"]
                for d, _, files in os.walk(path):
                    for fn in files:
                        fullpath = d + "/" + fn
                        ourpath = fullpath.replace(path, prefix).replace("\\", "/")
                        out.add(ourpath)
            else:
                out.add(rule.matcher.regex.pattern.rstrip("$"))
        if isinstance(rule.target, tornado.routing.RuleRouter):
            _descend_routes(rule.target, routers, out)


class SitemapHandler(web.RequestHandler):
    """Crawls the HTTP application to find all routes."""

    applications, bokeh_apps = [], []

    @override
    def initialize(
        self,
        template_variables: dict[str, Any],
        *args,  # noqa: ANN002 # type: ignore
        **kwargs,  # noqa: ANN003 # type: ignore
    ) -> None:
        """Discard template variables."""
        super().initialize(*args, **kwargs)

    def get(self) -> None:
        """Handle GET requests."""
        if not (self.applications or self.bokeh_apps):
            from orangeqs.juice.dashboard.utils import collect_dashboard_applications

            self.applications, self.bokeh_apps = collect_dashboard_applications()
        out: set[str] = set()
        routers: set[tornado.routing.Router] = set()
        for app in self.applications:
            _descend_routes(app.default_router, routers, out)
            _descend_routes(app.wildcard_router, routers, out)
        for bokeh_app in self.bokeh_apps:
            _logger.debug(f"Bokeh app: {app}")
            out.update(set(app.app_paths))
        self.write({"paths": sorted(out)})
