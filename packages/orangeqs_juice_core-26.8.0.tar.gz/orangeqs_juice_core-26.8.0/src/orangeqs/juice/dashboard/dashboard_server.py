"""Dashboard server module for OrangeQS Juice."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

import panel as pn

from ._constants import DASHBOARD_PORT

if TYPE_CHECKING:
    from collections.abc import Callable

    from bokeh.application import Application
    from panel.template import Template
    from tornado import web

_logger = logging.getLogger(__name__)


class Dashboard:
    """
    Base class for creating dashboards.

    This class explicitly accepts a list of documents to display and parameters
    to render it.
    """

    def __init__(
        self,
        applications: list[tuple[str, type[web.RequestHandler], dict[str, Any]]]
        | None = None,
        bokeh_apps: dict[str, Callable[..., Template] | Application] | None = None,
    ) -> None:
        """Initialize the Dashboard with pre-defined server address."""
        self.bokeh_apps = bokeh_apps or {}
        self.applications = applications or []

    @property
    def bound_addresses(self) -> list[tuple[str, int]]:
        """Return the address of the HTTP server."""
        return [s.getsockname() for s in self.server._http._sockets]  # type: ignore

    def _start_http_server(
        self,
    ) -> None:
        """Use Panel to serve the dashboard."""
        self.server = pn.serve(  # type: ignore
            port=DASHBOARD_PORT,
            panels=self.bokeh_apps,  # type: ignore
            extra_patterns=self.applications,
            # We set the websocket origins to allow all origins.
            # Deploying Juice safely behind a proxy with the appropriate CORS headers
            # is the responsibility of the user.
            websocket_origin=["*"],
        )
        _logger.info(
            f"Dashboard server started at http://{self.server.address}:{self.server.port}"  # type: ignore
        )

    def start(self) -> None:
        """Start the dashboard server."""
        self._start_http_server()
