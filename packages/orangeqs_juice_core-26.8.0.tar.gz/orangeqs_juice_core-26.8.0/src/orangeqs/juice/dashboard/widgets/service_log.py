"""Service log widget."""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import TYPE_CHECKING, Any, Literal

import pandas as pd
from bokeh.models import (
    Button,
    CDSView,
    ColumnDataSource,
    CustomJS,
    DataTable,
    DatetimePicker,
    Div,
    HTMLTemplateFormatter,
    MultiChoice,
    TableColumn,
    filters,
)

from orangeqs.juice.client.logging import (
    _query_service_logs,  # pyright: ignore[reportPrivateUsage]
)
from orangeqs.juice.dashboard.utils import get_stylesheet, to_local_time
from orangeqs.juice.orchestration.settings import OrchestrationSettings

if TYPE_CHECKING:
    from bokeh.models.widgets import Widget

_logger = logging.getLogger(__name__)

_DATETIME_FORMAT = "%Y-%m-%d %H:%M:%S %Z"
_PYTHON_LOG_LEVELS = ["CRITICAL", "ERROR", "WARNING", "INFO", "DEBUG"]


@dataclass
class _ServiceLogFilterIndex:
    services: dict[str, filters.GroupFilter] = field(
        default_factory=dict[str, filters.GroupFilter]
    )
    level: dict[str, filters.GroupFilter] = field(
        default_factory=dict[str, filters.GroupFilter]
    )


class ServiceLogWidget:
    """Widget to display log messages from services."""

    def __init__(
        self,
        max_time_interval: timedelta,
        max_num_records: int = 10_000,
    ) -> None:
        self.time_interval_end: datetime | None = None  # None means "until now"
        self._updating = False
        self.max_time_interval = max_time_interval
        self.max_num_records = max_num_records
        self.source = ColumnDataSource(
            pd.DataFrame(
                {
                    "_time": pd.Series(dtype=str),
                    "service": pd.Series(dtype=str),
                    "level": pd.Series(dtype=int),
                    "message": pd.Series(dtype=str),
                    "path": pd.Series(dtype=str),
                    "lineno": pd.Series(dtype=int),
                }
            )
        )

        settings = OrchestrationSettings.load()
        self._service_list: list[str] = list(settings.services.keys())

        self._filter_services = filters.UnionFilter(operands=[filters.AllIndices()])
        self._filter_level = filters.UnionFilter(operands=[filters.AllIndices()])
        self._selection = CDSView(
            filter=filters.IntersectionFilter(
                operands=[self._filter_services, self._filter_level],
            )
        )
        self._filters = _ServiceLogFilterIndex()
        self._last_update = datetime.fromtimestamp(0, tz=timezone.utc)

        # Create UI elements
        self.datetime_picker = DatetimePicker(
            min_width=140,
        )
        self.datetime_picker.on_change("value", self._on_change_datetime_picker)

        self.datetime_picker_reset_button = Button(
            label="Until now", button_type="primary"
        )
        self.datetime_picker_reset_button.js_on_click(
            CustomJS(
                args={"datetime_picker": self.datetime_picker},
                code="""datetime_picker.value = null;""",
            )
        )

        self.multichoice_service = MultiChoice(
            value=[],
            options=list(self._service_list),
            min_width=140,
        )
        self.multichoice_service.on_change("value", self._on_change_multichoice_service)

        self.multichoice_level = MultiChoice(
            value=[],
            options=_PYTHON_LOG_LEVELS,  # type: ignore
            min_width=140,
        )
        self.multichoice_level.on_change("value", self._on_change_multichoice_level)
        # Warning or higher by default
        self.multichoice_level.value = _PYTHON_LOG_LEVELS[:3]

        overflow_template = """
            <div style="white-space: nowrap; overflow: hidden;
                text-overflow: ellipsis;"
                title="<%= value %>">
                <%= value %>
            </div>
            """
        self.data_table = DataTable(
            source=self.source,
            columns=[
                TableColumn(field="level", title="Level", width=30),
                TableColumn(
                    field="_time",
                    title="Time",
                    width=60,
                    default_sort="descending",
                ),
                TableColumn(field="service", title="Service", width=50),
                TableColumn(field="lineno", title="Line", width=10),
                TableColumn(
                    field="path",
                    title="File",
                    formatter=HTMLTemplateFormatter(template=overflow_template),
                ),
                TableColumn(
                    field="message",
                    title="Message",
                    formatter=HTMLTemplateFormatter(template=overflow_template),
                ),
            ],
            sizing_mode="stretch_width",
            width_policy="max",
            scroll_to_selection=False,
            view=self._selection,
            stylesheets=[get_stylesheet("custom-bokeh.css")],
        )

        self._div_update_warning_style = (
            "margin-top: 6px; margin-bottom: 4px; "
            "margin-left: 12px; margin-right: 12px;"
        )
        self._div_update_warning_template = (
            f'<div style="{self._div_update_warning_style}">Last update: {{}}</div>'
        )
        self._div_update_warning = Div(
            text="",
            styles={
                "background": "#FCBF0D",
                "font-size": "16px",
                "border-radius": "24px",
            },
        )

        _logger.debug("Reached end of __init__ for ServiceLogWidget")

    def roots(self) -> dict[str, Widget]:
        """Roots for the widget."""
        return {
            "datetime_picker": self.datetime_picker,
            "datetime_picker_reset_button": self.datetime_picker_reset_button,
            "multichoice_service": self.multichoice_service,
            "multichoice_level": self.multichoice_level,
            "logs_table": self.data_table,
            "warning": self._div_update_warning,
        }

    def template_variables(self) -> dict[str, Any]:
        """Template variables for the widget."""
        return {"max_num_records": self.max_num_records}

    def initial_update(self) -> None:
        """Load initial data for the widget."""
        self._init_data(None)

    def _init_data(self, interval_end: datetime | None) -> None:
        if interval_end is None:
            interval_end = datetime.now(tz=timezone.utc)
        interval_start = interval_end - self.max_time_interval

        try:
            new_data = _retrieve_formatted_logs(
                start=interval_start,
                stop=interval_end,
                level="DEBUG",
                max_count=self.max_num_records,
            )
        except Exception:
            self._div_update_warning.text = (
                f'<div style="{self._div_update_warning_style}">'
                "Failed to fetch data</div>"
            )
        else:
            self._div_update_warning.text = ""
            if new_data is not None:
                self.source.data = ColumnDataSource.from_df(new_data)
                self._last_update = interval_end

    def update(self) -> None:
        """Update logs from the database."""
        _logger.debug("Updating service log widget")
        # If the previous callback has not returned yet, we skip update
        if self._updating:
            _logger.debug("Skipping update, previous callback still in progress")
            return

        # If user has selected the fixed time interval, periodic update is not done,
        # and manual update logic is in _on_change_datetime_picker.
        if self.time_interval_end is None:
            self._updating = True
            try:
                interval_end: datetime = datetime.now(tz=timezone.utc)
                interval_start: datetime = max(
                    self._last_update, interval_end - self.max_time_interval
                )
                _logger.debug(
                    f"Fetching logs from {interval_start.strftime(_DATETIME_FORMAT)} "
                    f"to {interval_end.strftime(_DATETIME_FORMAT)}"
                )
                new_data = _retrieve_formatted_logs(
                    start=interval_start,
                    stop=interval_end,
                    level="DEBUG",
                    max_count=self.max_num_records,
                )
            except Exception as e:
                self._div_update_warning.text = (
                    self._div_update_warning_template.format(
                        self._last_update.strftime(_DATETIME_FORMAT)
                    )
                )
                _logger.error("Failed to fetch data", exc_info=e)
            else:
                if new_data is not None:
                    self.source.stream(
                        ColumnDataSource.from_df(new_data), self.max_num_records
                    )
                    self._last_update = interval_end
                    _logger.debug(
                        "Updated logs to "
                        f"{self._last_update.strftime(_DATETIME_FORMAT)}"
                    )
                self._div_update_warning.text = ""
            finally:
                self._updating = False

    def _on_change_multichoice_service(
        self, attr: str, old: list[str], new: list[str]
    ) -> None:
        for service_name in old:
            if (
                service_name not in new
                and (old_filter := self._filters.services.pop(service_name, None))
                is not None
            ):
                # If this is the last entry, replace with an allindices filter
                if len(self._filter_services.operands) == 1:
                    self._filter_services.update(operands=[filters.AllIndices()])
                else:
                    # Re-assignment is required to enforce an update of the filter
                    self._filter_services.update(
                        operands=[
                            f for f in self._filter_services.operands if f != old_filter
                        ]
                    )

        # Add filters that are new
        for service_name in new:
            if service_name not in old and service_name not in self._filters.services:
                new_filter = filters.GroupFilter(
                    column_name="service", group=service_name
                )
                self._filters.services[service_name] = new_filter
                self._filter_services.update(
                    operands=list(self._filters.services.values())
                )

        # Update selection filter to trigger update of datatable
        self._selection.update(
            filter=filters.IntersectionFilter(
                operands=[self._filter_services, self._filter_level]
            )
        )

    def _on_change_multichoice_level(
        self, attr: str, old: list[str], new: list[str]
    ) -> None:
        for level in old:
            if (
                level not in new
                and (old_filter := self._filters.level.pop(level, None)) is not None
            ):
                # If this is the last entry, replace with an allindices filter
                if len(self._filter_level.operands) == 1:
                    self._filter_level.update(operands=[filters.AllIndices()])
                else:
                    # Re-assignment is required to enforce an update of the filter
                    self._filter_level.update(
                        operands=[
                            f for f in self._filter_level.operands if f != old_filter
                        ]
                    )

        # Add filters that are new
        for level in new:
            if level not in old and level not in self._filters.level:
                new_filter = filters.GroupFilter(column_name="level", group=level)
                self._filters.level[level] = new_filter
                self._filter_level.update(operands=list(self._filters.level.values()))

        # Update selection filter to trigger update of datatable
        self._selection.update(
            filter=filters.IntersectionFilter(
                operands=[self._filter_services, self._filter_level]
            )
        )

    def _on_change_datetime_picker(
        self, attr: str, old: float | None, new: float | None
    ) -> None:
        if attr != "value" or old == new:
            pass

        if new is None:
            # Assigned before _init_data to avoid concurrency with update()
            self.time_interval_end = None
            self._init_data(None)
        else:
            time_interval_end = datetime.fromtimestamp(new / 1000, tz=timezone.utc)
            self._init_data(time_interval_end)
            # Assigned after _init_data to avoid concurrency with update()
            self.time_interval_end = time_interval_end


def _retrieve_formatted_logs(
    start: datetime,
    stop: datetime,
    level: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
    max_count: int,
) -> pd.DataFrame | None:
    """Retrieve log messages from InfluxDB and format them for display.

    Thin wrapper around _get_service_logs that formats the output as a DataFrame.

    Parameters
    ----------
    start : int
        Start time for query
    end : int
        End time for query.

    Returns
    -------
    pd.DataFrame | None
        DataFrame containing the log messages, or None if no messages are found.
    """
    time_now = datetime.now(tz=timezone.utc)
    start_query = int((time_now - start).total_seconds())
    stop_query = int((time_now - stop).total_seconds())

    log_events = _query_service_logs(
        start=start_query,
        stop=stop_query,
        max_count=max_count,
        level=level,
    )
    _logger.debug(f"Retrieved {len(log_events)} log events")

    if len(log_events) == 0:
        _logger.info("No log events found")
        return

    _logger.debug("Formatting log events")
    data: list[dict[str, str | datetime | None]] = []
    for event in log_events:
        record: dict[str, str] = json.loads(event.serialized_record)
        local_time = to_local_time(event.time)
        data.append(  # type: ignore
            {
                "_time": local_time.strftime(_DATETIME_FORMAT),
                "service": event.service,
                "level": record.get("levelname"),
                "message": record.get("message"),
                "path": record.get("pathname"),
                "lineno": record.get("lineno"),
            }
        )
    return pd.DataFrame(data)
