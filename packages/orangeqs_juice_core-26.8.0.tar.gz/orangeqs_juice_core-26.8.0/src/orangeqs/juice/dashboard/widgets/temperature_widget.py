"""Widget for controlling thermometry units."""

import asyncio
import logging
from collections.abc import Iterator
from datetime import datetime, timedelta
from typing import Any

from bokeh.document import Document
from bokeh.layouts import Spacer, column, row
from bokeh.models import (
    ColumnDataSource,
    DataRange1d,
    DatetimeTickFormatter,
    Div,
    NumeralTickFormatter,
    Select,
    TabPanel,
)
from bokeh.plotting import figure

from orangeqs.juice.client.influxdb2 import influxdb2_query_api_async
from orangeqs.juice.dashboard.schemas import (
    CRYOSTAT_LEVELS,
    DEFAULT_SYSTEM_MONITOR_SERVICE,
)
from orangeqs.juice.dashboard.utils import (
    get_pallete,
    subscribe_to_events_task,
    to_local_time,
)
from orangeqs.juice.system_monitor.data_structures import TemperaturePoint

_logger = logging.getLogger(__name__)

_SECS_7_DAYS = 7 * 24 * 3600
_SECS_2_DAYS = 2 * 24 * 3600
_SECS_1_DAY = 1 * 24 * 3600
_SECS_12_HOURS = 12 * 3600
_SECS_6_HOURS = 6 * 3600
_SECS_3_HOURS = 3 * 3600
_SECS_1_HOUR = 1 * 3600
_SECS_15_MINUTES = 15 * 60


class _TemperaturePlot:
    def __init__(
        self,
        source: dict[str, ColumnDataSource],
        level: str,
        x_range: DataRange1d,
        sensor_ids: list[str],
        colors: Iterator[str],
    ) -> None:
        self.root = figure(
            title=f"{level} Temperature",
            x_axis_type="datetime",
            height=300,
            min_width=400,
            sizing_mode="stretch_width",
            x_range=x_range,
        )
        for sid in sensor_ids:
            self.root.line(  # type: ignore
                x="time",
                y="temperature",
                source=source[sid],
                legend_label=sid,
                color=next(colors, "#000000"),
            )
        self.root.yaxis.axis_label = "Temperature (K)"
        self.root.legend.location = "top_left"
        self.root.legend.click_policy = "hide"
        self.root.xaxis.formatter = DatetimeTickFormatter(
            days="%m/%d", hours="%H:%M", minutes="%H:%M", minsec="%H:%M:%S"
        )
        self.root.yaxis.formatter = NumeralTickFormatter(format="0.[00]a")


class TemperatureWidget:
    """Widget to display temperature measurements from thermometry units."""

    def __init__(
        self,
        doc: Document,
        thermometry_component_id: str,
        thermometer_map: dict[str, str] = {},
    ) -> None:
        self.time_ranges = {
            "7 days": _SECS_7_DAYS,
            "2 days": _SECS_2_DAYS,
            "1 day": _SECS_1_DAY,
            "12 hours": _SECS_12_HOURS,
            "6 hours": _SECS_6_HOURS,
            "3 hours": _SECS_3_HOURS,
            "1 hour": _SECS_1_HOUR,
            "15 minutes": _SECS_15_MINUTES,
        }
        self.selected_range = "3 hours"
        self.select_div = Div(text="Show data since:", align="center")
        self.range_select = Select(
            value=self.selected_range,
            options=list(self.time_ranges.keys()),
        )
        self.range_select.on_change("value", self._on_range_change)
        self.valid_levels = [
            lvl for lvl in CRYOSTAT_LEVELS if lvl in set(thermometer_map.values())
        ]
        self.source = {
            sid: ColumnDataSource(data=dict(time=[], temperature=[]))
            for sid in thermometer_map
        }
        _logger.debug(self.source)
        self.timerange = _SECS_3_HOURS
        plot_dtime = timedelta(seconds=self.timerange)
        self._plot_datarange = DataRange1d(
            max_interval=plot_dtime,
            min_interval=timedelta(minutes=1),
            follow="end",
            follow_interval=plot_dtime,
            only_visible=True,
        )
        colors = iter(get_pallete(len(thermometer_map)))
        plots = [
            _TemperaturePlot(
                source=self.source,
                level=lvl,
                x_range=self._plot_datarange,
                sensor_ids=[
                    id for id, i_lvl in thermometer_map.items() if i_lvl == lvl
                ],
                colors=colors,
            )
            for lvl in self.valid_levels
        ]
        row_1 = row(children=[p.root for p in plots[0:3]])
        row_2 = row(children=[p.root for p in plots[3:5]])

        # Add range select to the top right of the tab panel

        select_row = row(
            Spacer(sizing_mode="stretch_width"),
            self.select_div,
            self.range_select,
            sizing_mode="stretch_width",
        )
        self.tab_panel = TabPanel(
            title="Temperature",
            child=column(children=[select_row, row_1, row_2]),
        )
        self._query_api = influxdb2_query_api_async()
        self._doc = doc
        self._thermometer_map = thermometer_map
        topic_filters = [
            (
                TemperaturePoint,
                f"{DEFAULT_SYSTEM_MONITOR_SERVICE}.{thermometry_component_id}.{topic}",
            )
            for topic in thermometer_map
        ]
        # Need to keep a reference to the subscriber tasks to avoid garbage collection
        self.subscriber_tasks = lambda: subscribe_to_events_task(
            self._doc, topic_filters, self.update_sub
        )

    async def initial_update(self, timerange_s: int = -1) -> None:
        """Load initial data from InfluxDB2."""
        self.timerange = timerange_s if timerange_s > 0 else self.timerange
        query = f"""
            from(bucket: "system_monitor")
                |> range(start: -{self.timerange}s)
                |> filter(fn: (r) => r["_measurement"] == "temperature_measurement")
                |> filter(fn: (r) => r["_field"] == "temperature")
                |> filter(fn: (r) => r["level"] != "N/A")
                |> aggregateWindow(
                    every: {max(self.timerange // 500, 10)}s,
                    fn: mean, createEmpty: false
                )
                |> group()
                |> keep(columns: ["_value", "_time", "level", "sensor_id"])
                |> sort(columns: ["_time"], desc: false)
                |> yield(name: "mean")
            """
        result = await self._query_api.query(query)
        data: dict[str, dict[str, list[Any]]] = {}
        for table in result:
            for rec in table.records:
                sid = rec["sensor_id"]
                if sid not in self._thermometer_map:
                    _logger.warning(
                        f"Received data from database unknown sensor ID {sid}"
                    )
                    continue
                if sid not in data:
                    data[sid] = dict(time=[], temperature=[])
                local_time = to_local_time(rec["_time"])
                data[sid]["temperature"].append(rec["_value"])
                data[sid]["time"].append(local_time)
        _logger.debug(f"Queried data from sensors {data.keys()}")
        for sid, s_data in data.items():
            self._doc.add_next_tick_callback(
                lambda sid=sid, s_data=s_data: self.source[sid].data.update(s_data)  # type: ignore
            )
        self._sub_task = self.subscriber_tasks()

    def _on_range_change(self, attr: str, old: str, new: str) -> None:
        self.selected_range = new

        range_value = self.time_ranges.get(self.selected_range, _SECS_1_DAY)
        self._sub_task.cancel()

        self._aggregation_task = asyncio.create_task(self.initial_update(range_value))

    async def update(self) -> None:
        """Update the plot to remove old data."""
        for src in self.source.values():
            t_now = src.data.get("time", [float("inf")])[-1]
            if isinstance(t_now, datetime):
                t_now = t_now.timestamp()
                valid_map = map(
                    lambda t: t.timestamp() < t_now - self.timerange,
                    src.data["time"],  # type: ignore
                )
            else:
                valid_map = map(lambda t: t < t_now - self.timerange, src.data["time"])  # type: ignore
            i_first_valid = next((i for i, val in enumerate(valid_map) if val), -1)

            self._doc.add_next_tick_callback(
                lambda: src.stream(
                    {"time": [], "temperature": []},
                    rollover=(len(src.data["time"]) - i_first_valid),  # type: ignore
                )  # type: ignore
            )

    def update_sub(self, event: TemperaturePoint) -> None:
        """Update the plot with new data from subscriber."""
        # Process the event as needed
        _logger.debug(f"Received TemperaturePoint event: {event}")
        if event.sensor_id not in self.source:
            _logger.debug(f"event sensor {event.sensor_id} not in {self.source.keys()}")
            return
        local_time = to_local_time(event.time)
        new_data = {
            "time": [local_time],
            "temperature": [event.temperature],
        }
        _logger.debug(f"Received temp {new_data}")

        self._doc.add_next_tick_callback(
            lambda: self.source[event.sensor_id].stream(new_data)  # type: ignore
        )
