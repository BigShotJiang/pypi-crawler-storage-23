"""Widget for controlling heater units."""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Literal

from bokeh.layouts import column, row
from bokeh.models import Div, TabPanel
from bokeh.models.widgets import Button, NumericInput

from orangeqs.juice.client import Client
from orangeqs.juice.dashboard.components.on_off_widget import OnOffToggle
from orangeqs.juice.dashboard.schemas import DEFAULT_SYSTEM_MONITOR_SERVICE
from orangeqs.juice.dashboard.utils import subscribe_to_events_task
from orangeqs.juice.system_monitor.data_structures import PowerSettingPoint
from orangeqs.juice.system_monitor.tasks import (
    DisableHeater,
    EnableHeater,
    GetHeaterOutputPower,
    GetHeaterPowerSetting,
    IsHeaterEnabled,
    SetHeaterPower,
)

if TYPE_CHECKING:
    from bokeh.document import Document

logger = logging.getLogger(__name__)

W_TO_MW_CONVERSION = 1000.0


class HeatersWidget:
    """Widget to control multiple heater units."""

    def __init__(
        self,
        doc: Document,
        heaters_config: dict[str, str],
        mode: Literal["read_only", "power_user"] = "power_user",
    ) -> None:
        self._doc = doc
        self.individual_heater_widgets: list[SingleHeaterWidget] = []
        for heater_name, display_name in heaters_config.items():
            self.individual_heater_widgets.append(
                SingleHeaterWidget(
                    doc=self._doc,
                    heater_name=heater_name,
                    display_name=display_name,
                    mode=mode,
                )
            )
            logger.debug(f"Created Heater Widget: {display_name}")
        self.root = row(*[widget.root for widget in self.individual_heater_widgets])
        self.tab_panel = TabPanel(child=self.root, title="Heaters Control")

    async def initial_update(self) -> None:
        """Initialise Widget."""
        for heater_widget in self.individual_heater_widgets:
            asyncio.create_task(heater_widget.initial_update())

    async def update(self) -> None:
        """Update the heater widget data."""
        pass


class SingleHeaterWidget:
    """Widget to control a single heater unit in the system monitor."""

    def __init__(
        self,
        doc: Document,
        heater_name: str,
        display_name: str,
        mode: Literal["read_only", "power_user"] = "power_user",
    ) -> None:
        self._doc = doc
        self.power_setting = 0.0
        self.heater_name = heater_name
        self.display_name = display_name
        self.output_power = 0.0

        self.juice_client = Client()

        self.title_div = Div(text=f"<b>{display_name}</b>", width=200, height=25)
        self.on_off_toggle = OnOffToggle(
            doc=self._doc,
            service=DEFAULT_SYSTEM_MONITOR_SERVICE,
            on_task=EnableHeater(component_id=heater_name),
            off_task=DisableHeater(component_id=heater_name),
            response_timeout=10,
            device_state_check_task=IsHeaterEnabled(component_id=heater_name),
            enabled_topic=f"{DEFAULT_SYSTEM_MONITOR_SERVICE}.{heater_name}",
            title=f"{display_name}",
            button_width=120,
            button_height=30,
            mode=mode,
        )

        self.power_input = NumericInput(
            placeholder="Enter Power", mode="float", width=120, height=30
        )
        self.update_power = Button(
            label="Set Power(mW)", button_type="default", width=120, height=30
        )
        if mode == "read_only":
            self.power_input.disabled = True
            self.update_power.disabled = True

        self.measured_power_display = Div(
            text=self._return_power_display_text(),
            width=240,
            height=30,
            styles={"font-size": "15px", "color": "#2a2a2a", "text-align": "center"},
        )
        self.update_power.on_click(self.update_power_callback)

        self.power_input_row = row(self.power_input, self.update_power)

        self.root = column(
            self.title_div,
            self.on_off_toggle.root,
            self.power_input_row,
            self.measured_power_display,
            styles={
                "border-color": "black",
                "border-style": "solid",
                "border-width": "1px",
            },
        )
        self.initialized = False

    def _return_power_display_text(self) -> str:
        """Return the power display text."""
        return f"Measured Power Output: {self.output_power} mW"

    def update_power_callback(self) -> None:
        """Update power on device."""
        if self.power_input.value is None:
            return
        self.power_setting = float(self.power_input.value) / W_TO_MW_CONVERSION
        asyncio.create_task(
            self.juice_client.execute(
                DEFAULT_SYSTEM_MONITOR_SERVICE,
                SetHeaterPower(component_id=self.heater_name, power=self.power_setting),
                check=True,
            )
        )

        logger.info(
            f"Changed Output Power of {self.display_name} to {self.power_setting} mW"
        )

    async def initial_update(self) -> None:
        """Initialise the state of the widget."""
        logger.debug(f"Initialising Heater Widget: {self.display_name}")
        self.initial_update_task = asyncio.create_task(
            self.on_off_toggle.initial_update()
        )
        get_heater_power_setting_result = await self.juice_client.execute(
            DEFAULT_SYSTEM_MONITOR_SERVICE,
            GetHeaterPowerSetting(component_id=self.heater_name),
            check=True,
        )
        self.power_setting = get_heater_power_setting_result.result * W_TO_MW_CONVERSION
        get_heater_output_power_result = await self.juice_client.execute(
            DEFAULT_SYSTEM_MONITOR_SERVICE,
            GetHeaterOutputPower(component_id=self.heater_name),
            check=True,
        )
        self.output_power = get_heater_output_power_result.result * W_TO_MW_CONVERSION
        logger.debug(f"Retrieved Power for {self.display_name}: {self.output_power} mW")

        self._doc.add_next_tick_callback(self._update_power_display)

        self.listener_task = subscribe_to_events_task(
            self._doc,
            [
                (
                    PowerSettingPoint,
                    f"{DEFAULT_SYSTEM_MONITOR_SERVICE}.{self.heater_name}",
                ),
            ],
            self._handle_power_setting_point,
        )

        self.initialized = True

    def _handle_power_setting_point(self, event: PowerSettingPoint) -> None:
        """Handle updates from the system monitor about heater power changes."""
        if not self.initialized:
            return

        logger.debug(
            f"Received PowerSettingPoint for {self.display_name}: "
            f"Power={event.output_power} mW"
        )
        self.output_power = event.output_power * W_TO_MW_CONVERSION
        self.power_setting = event.power_setting * W_TO_MW_CONVERSION
        self._doc.add_next_tick_callback(self._update_power_display)

    def _update_power_display(self) -> None:
        """Update the power display in the widget."""
        self.measured_power_display.text = self._return_power_display_text()
        self.power_input.value = self.power_setting
        logger.debug(
            f"Updated Power Display for {self.display_name}: "
            f"Measured Power Output: {self.output_power} mW"
        )
