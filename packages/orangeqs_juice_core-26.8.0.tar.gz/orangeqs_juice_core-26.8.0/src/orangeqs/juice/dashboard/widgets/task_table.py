"""Widget that displays task table aligned with TaskEvent schema."""

import datetime
import logging
from typing import Any, cast

from bokeh.io import curdoc
from bokeh.models import (
    CDSView,
    ColumnDataSource,
    DataTable,
    Select,
    TableColumn,
    filters,
)
from bokeh.models.widgets import Widget

from orangeqs.juice import Client
from orangeqs.juice.client import influxdb2
from orangeqs.juice.dashboard.utils import get_stylesheet, subscribe_to_events_task
from orangeqs.juice.task_manager._schemas import TaskEvent

_logger = logging.getLogger(__name__)


class TaskTableWidget:
    """Widget that displays tasks with columns matching TaskEvent schema.

    Rows are dynamic (one per task_id). The first column is the task display name.
    Other columns map directly to TaskEvent fields.
    """

    _columns_order: list[str] = [
        "task_display_name",
        "task_target",
        "task_type",
        "task_state",
        "time",
        "task_state_raw",  # Raw state for filtering (without emoji)
    ]

    _column_titles: dict[str, str] = {
        "task_display_name": "Task",
        "task_target": "Service",
        "task_state": "State",
        "time": "Timestamp",
    }

    def __init__(
        self,
        services: list[str] = [],
    ) -> None:
        self._juice_client = Client()
        self._doc = curdoc()
        self._query_api = influxdb2.influxdb2_query_api()
        self._services = services

        self._row_index_by_task_id: dict[str, int] = {}
        self._all_task_types: set[str] = set()
        self._all_services: set[str] = set()

        empty_data: dict[str, list[Any]] = {col: [] for col in self._columns_order}
        self._tab_source = ColumnDataSource(data=empty_data)

        # Set up filters
        self._filter_state = filters.UnionFilter(operands=[filters.AllIndices()])
        self._filter_task_type = filters.UnionFilter(operands=[filters.AllIndices()])
        self._filter_service = filters.UnionFilter(operands=[filters.AllIndices()])
        self._table_view = CDSView(
            filter=filters.IntersectionFilter(
                operands=[
                    self._filter_state,
                    self._filter_task_type,
                    self._filter_service,
                ]
            )
        )

        # Create filter widgets
        # Ebumerated from task_manager._schemas.TaskEvent.task_state
        state_options: list[str | tuple[Any, str]] = [
            ("All", "All"),
            ("created", "Created"),
            ("started", "Started"),
            ("completed", "Completed"),
            ("failed", "Failed"),
        ]
        self._state_filter = Select(
            title="Filter by State:",
            value="All",
            options=state_options,
            width=180,
            margin=(5, 10, 5, 5),
        )
        self._state_filter.on_change("value", self._on_state_filter_change)

        self._task_type_filter = Select(
            title="Filter by Task Type:",
            value="All",
            options=["All"],
            width=200,
            margin=(5, 10, 5, 5),
        )
        self._task_type_filter.on_change("value", self._on_task_type_filter_change)

        self._service_filter = Select(
            title="Filter by Service:",
            value="All",
            options=cast("list[str | tuple[Any, str]]", ["All"] + self._services),
            width=180,
            margin=(5, 10, 5, 5),
        )
        self._service_filter.on_change("value", self._on_service_filter_change)

        hidden_columns = {"task_state_raw", "task_type", "task_display_name"}
        display_columns = [
            col for col in self._columns_order if col not in hidden_columns
        ]
        cols = [
            TableColumn(
                field="task_display_name",
                title="Task",
                sortable=False,
            )
        ] + [
            TableColumn(
                field=col,
                title=self._column_titles.get(col, col.capitalize()),
                sortable=False,
                width=120,  # type: ignore[arg-type]
            )
            for col in display_columns
        ]

        self._data_table = DataTable(
            source=self._tab_source,
            columns=cols,
            header_row=True,
            index_position=None,
            sizing_mode="scale_width",
            view=self._table_view,
            stylesheets=[get_stylesheet("custom-bokeh.css")],
        )

        # Start reasonably tall; will be resized after initial_update
        self._data_table.height = self._data_table.row_height * (6 + 1)

        # Subscribe to all TaskEvents
        # (no topic filter since TaskEvent.topic() returns None)
        subscription_list = [(TaskEvent, None)]

        self.subscriber_task = subscribe_to_events_task(
            doc=self._doc,
            subscriptions=subscription_list,  # type: ignore
            handler=self._update_event_handler,
        )

    def roots(self) -> dict[str, Widget]:
        """Roots for the widget."""
        return {
            "task_table_state_filter": self._state_filter,
            "task_table_task_type_filter": self._task_type_filter,
            "task_table_service_filter": self._service_filter,
            "task_table": self._data_table,
        }

    def initial_update(self) -> None:
        """Populate table with the latest known TaskEvent(s), filtered by target."""
        _logger.debug("Initializing Task Table Widget (TaskEvent schema)")

        # Fetch recent TaskEvent entries from the database
        results = TaskEvent.query(
            query_api=self._query_api,
            bucket="task-manager",
            start="-3600s",
            limit=50,
            # Consider adding limit or ordering if supported (e.g., limit per task_id)
        )
        _logger.debug(f"Initial TaskEvent results: {results}")

        # Group by task_id and keep only the latest state for each task
        latest_events: dict[str, TaskEvent] = {}
        for event in results:
            if event.task_id not in latest_events:
                latest_events[event.task_id] = event
            else:
                # Keep the event with the most recent state
                # (created < started < completed/failed)
                state_order = {"created": 0, "started": 1, "completed": 2, "failed": 2}
                current_state = state_order.get(
                    latest_events[event.task_id].task_state, -1
                )
                new_state = state_order.get(event.task_state, -1)
                if new_state > current_state:
                    latest_events[event.task_id] = event

        # Update table with latest events
        for event in latest_events.values():
            self._update_event_handler(event)

        # Update filter options based on loaded data
        self._update_filter_options()

    def _update_event_handler(self, event: TaskEvent) -> None:
        """Handle incoming TaskEvent: insert or update the row for this task."""
        _logger.debug(
            f"Received TaskEvent: id={event.task_id}, state={event.task_state}"
        )

        def _update_table() -> None:
            task_id = event.task_id
            data: dict = self._tab_source.data  # type: ignore
            # Color code for state
            state_colors = {
                "created": "🟡",
                "started": "🔵",
                "completed": "🟢",
                "failed": "🔴",
            }
            state = event.task_state
            color = state_colors[state]
            state_text = f"{color} {state}"

            # Track unique values for filter options
            self._all_task_types.add(event.task_type)
            self._all_services.add(event.task_target)

            # Convert time to human-readable format
            def format_time(ts: int | float | datetime.datetime | None) -> str:
                if ts is None:
                    return ""
                if isinstance(ts, datetime.datetime):
                    return ts.strftime("%Y-%m-%d %H:%M:%S")
                try:
                    # Assume ts is a Unix timestamp (seconds)
                    dt = datetime.datetime.fromtimestamp(ts)
                    return dt.strftime("%Y-%m-%d %H:%M:%S")
                except Exception:
                    return str(ts)

            formatted_time = format_time(event.time)

            if task_id in self._row_index_by_task_id:
                # Update existing row
                idx = self._row_index_by_task_id[task_id]
                data["task_display_name"][idx] = event.task_display_name
                data["task_target"][idx] = event.task_target
                data["task_type"][idx] = event.task_type
                data["task_state"][idx] = state_text
                data["task_state_raw"][idx] = state
                data["time"][idx] = formatted_time
            else:
                # Add new row at the front
                for col, value in [
                    ("task_display_name", event.task_display_name),
                    ("task_target", event.task_target),
                    ("task_type", event.task_type),
                    ("task_state", state_text),
                    ("task_state_raw", state),  # Store raw state for filtering
                    ("time", formatted_time),
                ]:
                    data[col].insert(0, value)  # pyright: ignore
                # Update all row indices: increment existing, set new to 0
                for k in self._row_index_by_task_id:
                    self._row_index_by_task_id[k] += 1  # pyright: ignore
                self._row_index_by_task_id[task_id] = 0  # pyright: ignore

            # Update filter options if new values were added
            self._update_filter_options()

            # Recalculate filters after data update (indices may have shifted)
            self._recalculate_filters()

            # Trigger update
            self._tab_source.trigger("data", data, data)

        self._doc.add_next_tick_callback(_update_table)

    def _update_filter_options(self) -> None:
        """Update filter dropdown options based on available data."""
        # Update task type filter options
        task_type_options = ["All"] + sorted(self._all_task_types)
        current_task_type = self._task_type_filter.value
        if current_task_type not in task_type_options:
            current_task_type = "All"
        self._task_type_filter.options = task_type_options  # type: ignore
        self._task_type_filter.value = current_task_type  # type: ignore

        # Update service filter options
        service_options = ["All"] + sorted(self._services)
        current_service = self._service_filter.value
        if current_service not in service_options:
            current_service = "All"
        self._service_filter.options = service_options  # type: ignore
        self._service_filter.value = current_service

    def _set_filter(self, filter_type: str, value: str) -> None:
        """Set the specified filter to the given value."""
        setattr(self, f"_filter_{filter_type}", value)
        source_names = {
            "state": "task_state_raw",
            "task_type": "task_type",
            "service": "task_target",
        }
        if value == "All":
            setattr(
                self,
                f"_filter_{filter_type}",
                filters.UnionFilter(
                    operands=[filters.AllIndices()]  # type: ignore
                ),
            )
            return

        indices = [
            i
            for i, state in enumerate(
                self._tab_source.data[source_names[filter_type]]  # type: ignore
            )
            if state == value
        ]
        if indices:
            setattr(
                self,
                f"_filter_{filter_type}",
                filters.UnionFilter(
                    operands=[filters.IndexFilter(indices)]  # type: ignore
                ),
            )
        else:
            setattr(
                self,
                f"_filter_{filter_type}",
                filters.UnionFilter(
                    operands=[filters.IndexFilter([])]  # type: ignore
                ),
            )

    def _recalculate_filters(self) -> None:
        """Recalculate all active filters based on current data."""
        # Recalculate state filter
        state_value = self._state_filter.value
        self._set_filter("state", state_value)  # type: ignore

        # Recalculate task type filter
        task_type_value = self._task_type_filter.value
        self._set_filter("task_type", task_type_value)  # type: ignore

        # Recalculate service filter
        service_value = self._service_filter.value
        self._set_filter("service", service_value)  # type: ignore

        self._update_table_view()

    def _on_state_filter_change(self, attr: str, old: str, new: str) -> None:
        """Handle state filter change."""
        self._set_filter("state", new)
        self._update_table_view()

    def _on_task_type_filter_change(self, attr: str, old: str, new: str) -> None:
        """Handle task type filter change."""
        self._set_filter("task_type", new)
        self._update_table_view()

    def _on_service_filter_change(self, attr: str, old: str, new: str) -> None:
        """Handle service filter change."""
        self._set_filter("service", new)
        self._update_table_view()

    def _update_table_view(self) -> None:
        """Update the table view with current filters."""
        self._table_view.filter = filters.IntersectionFilter(
            operands=[self._filter_state, self._filter_task_type, self._filter_service]
        )
