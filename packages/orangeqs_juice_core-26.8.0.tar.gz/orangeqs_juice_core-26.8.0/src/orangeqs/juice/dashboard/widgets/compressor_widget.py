"""Compressor control and monitoring widget for the Juice dashboard."""

import asyncio
import logging
from typing import Literal, ParamSpec, TypeVar

from bokeh.document import Document
from bokeh.layouts import column
from bokeh.models import (
    ColumnDataSource,
    DataTable,
    TableColumn,
    TabPanel,
)

from orangeqs.juice import Client
from orangeqs.juice.dashboard.components.on_off_widget import OnOffToggle
from orangeqs.juice.dashboard.schemas import DEFAULT_SYSTEM_MONITOR_SERVICE
from orangeqs.juice.dashboard.utils import get_stylesheet, subscribe_to_events_task
from orangeqs.juice.system_monitor.data_structures import (
    PressurePoint,
    StatusmessagePoint,
    TemperaturePoint,
)
from orangeqs.juice.system_monitor.tasks import (
    AreCompressorsEnabled,
    DisableCompressors,
    EnableCompressors,
)

_logger = logging.getLogger(__name__)


P = ParamSpec("P")
R = TypeVar("R")


class CompressorWidget:
    """Compressor control and monitoring widget."""

    def __init__(
        self,
        doc: Document,
        component_id: str,
        display_name: str,
        mode: Literal["read_only", "power_user"] = "power_user",
    ) -> None:
        self._juice_client = Client()
        self._doc = doc
        self.display_name = display_name
        self.component_id = component_id

        data_keys = [
            "Operating State",
            "Error",
            "Warning",
            "High Pressure",
            "Low Pressure",
            "Coolant In Temperature",
            "Coolant Out Temperature",
            "Oil Temperature",
            "Helium Temperature",
        ]

        data = {"Parameter": data_keys, "Value": [""] * len(data_keys)}

        self._tab_source = ColumnDataSource(data=data)

        cols = [
            TableColumn(field="Parameter", title="Parameter", sortable=False),
            TableColumn(field="Value", title="Value", sortable=False),
        ]

        self.table = DataTable(
            source=self._tab_source,
            columns=cols,
            header_row=True,
            index_position=None,
            sizing_mode="scale_width",
            stylesheets=[get_stylesheet("custom-bokeh.css")],
        )

        self._on_off_toggle = OnOffToggle(
            doc=self._doc,
            service=DEFAULT_SYSTEM_MONITOR_SERVICE,
            on_task=EnableCompressors(),
            off_task=DisableCompressors(),
            response_timeout=10,
            device_state_check_task=AreCompressorsEnabled(),
            enabled_topic=f"{DEFAULT_SYSTEM_MONITOR_SERVICE}.{component_id}",
            title=f"{self.display_name}",
            button_width=120,
            button_height=30,
            mode=mode,
        )

        self.tab_panel = TabPanel(
            title=self.display_name,
            child=column(
                self._on_off_toggle.root,
                self.table,
                sizing_mode="stretch_width",
            ),
        )

        subscription_list = [
            (TemperaturePoint, f"{DEFAULT_SYSTEM_MONITOR_SERVICE}.{self.component_id}"),
            (PressurePoint, f"{DEFAULT_SYSTEM_MONITOR_SERVICE}.{self.component_id}"),
            (
                StatusmessagePoint,
                f"{DEFAULT_SYSTEM_MONITOR_SERVICE}.{self.component_id}",
            ),
        ]

        self.subscriber_task = subscribe_to_events_task(
            doc=self._doc,
            subscriptions=subscription_list,
            handler=self._update_event_handler,
        )

    async def initial_update(self) -> None:
        """Initialize data of all widgets in the dashboard."""
        _logger.debug(f"Initialising Compressor Widget: {self.display_name}")
        self.initial_update_task = asyncio.create_task(
            self._on_off_toggle.initial_update()
        )

    async def update(self) -> None:
        """Update the compressor widget data."""
        pass

    def _update_event_handler(
        self,
        event: TemperaturePoint | PressurePoint | StatusmessagePoint,
    ) -> None:
        _logger.debug(
            f"Handling event {event.__class__.__name__} topic {event.topic()}"
        )

        def _update_table(parameter: str, value: str) -> None:
            if parameter not in self._tab_source.data["Parameter"]:  # type: ignore
                _logger.warning(f"Parameter {parameter} not found in table.")
                return
            else:
                idx = self._tab_source.data["Parameter"].index(parameter)  # type: ignore
                if parameter == "Error":
                    current_errors = self._tab_source.data["Value"][idx]  # type: ignore
                    if "NO_ERRORS" in current_errors or "NO_ERRORS" in value:
                        pass
                    elif value not in current_errors:
                        value = current_errors + "; " + value  # type: ignore
                    else:
                        value = current_errors  # type: ignore
                if parameter == "Warning":
                    current_warnings = self._tab_source.data["Value"][idx]  # type: ignore
                    if "NO_WARNINGS" in current_warnings or "NO_WARNINGS" in value:
                        pass
                    elif value not in current_warnings:
                        value = current_warnings + "; " + value  # type: ignore
                    else:
                        value = current_warnings  # type: ignore

                self._tab_source.data["Value"][idx] = value  # type: ignore
                self._tab_source.trigger(
                    "data", self._tab_source.data, self._tab_source.data
                )

        match event:
            case StatusmessagePoint():
                match event.message_id:
                    case "operating_state":
                        self._doc.add_next_tick_callback(
                            lambda: _update_table("Operating State", event.message)
                        )
                    case "warning":
                        self._doc.add_next_tick_callback(
                            lambda: _update_table("Warning", event.message)  # type: ignore
                        )
                    case "error":
                        self._doc.add_next_tick_callback(
                            lambda: _update_table("Error", event.message)  # type: ignore
                        )
                    case _:
                        _logger.warning(
                            f"Unknown message_id {event.message_id} "
                            "in StatusmessagePoint."
                        )

            case TemperaturePoint():
                if event.sensor_id in [
                    "coolant_in_temperature",
                    "coolant_out_temperature",
                    "oil_temperature",
                    "helium_temperature",
                ]:
                    self._doc.add_next_tick_callback(
                        lambda: _update_table(
                            event.sensor_id.replace("_", " ").title(),
                            f"{event.temperature:.1f} K",
                        )
                    )
            case PressurePoint():
                if event.sensor_id == "high_pressure":
                    self._doc.add_next_tick_callback(
                        lambda: _update_table(
                            "High Pressure", f"{event.pressure:.2f} {event.unit}"
                        )
                    )
                elif event.sensor_id == "low_pressure":
                    self._doc.add_next_tick_callback(
                        lambda: _update_table(
                            "Low Pressure", f"{event.pressure:.2f} {event.unit}"
                        )
                    )
