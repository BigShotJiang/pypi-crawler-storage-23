"""Bokeh DataTable widgets."""

import logging
from typing import Any

from bokeh.models import (
    ColumnDataSource,
    DataTable,
    TableColumn,
)
from pandas import DataFrame

from orangeqs.juice.dashboard.utils import get_stylesheet

_logger = logging.getLogger(__name__)


class BokehDataTableWidget:
    """Base class for Bokeh widgets with data tables. Meant to be extended."""

    source: ColumnDataSource
    root: DataTable
    _keys: list[str]
    _fields: list[str]
    _data: dict[str, list[Any]]

    """
    Parameters
    ----------
    fields : list[str]
        The column names.
    field_titles : dict[str, str], optional
        A mapping from field name to field title. Will be displayed as table header.
        If a field is not present, defaults to capitalized field name.
    data_table_opts : dict[str, Any], optional
        Bokeh DataTable options.
    keys : str, optional
        The row names. If left empty, `keys_from` needs to be passed.
    key_selector : str, optional
        What InfluxDB tag or field the widget should use as row names.
        Allows dynamic row names and amounts based on query results.
        If passed, ignores what is passed in `keys`.
    """

    def __init__(
        self,
        fields: list[str],
        field_titles: dict[str, str] | None = None,
        data_table_opts: dict[str, Any] | None = None,
        keys: list[str] | None = [],
        key_selector: str | None = "",
    ) -> None:
        if key_selector:
            self._key_selector = key_selector
            self._is_keys_dynamic = True
            self._keys = []
        else:
            if keys is None:
                raise ValueError(
                    "The keys argument must be passed if keys_from is not."
                )
            self._keys = keys
            self._is_keys_dynamic = False

        self._fields = fields
        if field_titles is None:
            field_titles = {}

        self._data = {field: [""] * len(self._keys) for field in self._fields}
        self.source = ColumnDataSource(
            data={"keys": self._keys}
            | {tag: ["loading..."] * len(self._keys) for tag in self._fields}
        )

        if data_table_opts is None:
            data_table_opts = dict(
                header_row=True, index_position=None, sizing_mode="stretch_width"
            )
        self.root = DataTable(
            source=self.source,
            columns=[
                # first column has key names
                TableColumn(field="keys", title="", sortable=False)
            ]
            + [
                TableColumn(
                    field=column,
                    title=field_titles.get(column, column.capitalize()),
                    sortable=False,
                )
                for column in self._fields
            ],
            stylesheets=[get_stylesheet("custom-bokeh.css")],
            **data_table_opts,
        )
        if not self._is_keys_dynamic:
            # Configure height to fit only the table, nothing more
            self.root.height = self.root.row_height * (len(self._keys) + 1)

    async def update(self) -> None:
        """Update the DataSource column-wise.

        Updates each of its `ColumnDataSource`s with the contents of self._data.
        Meant to be extended.
        """
        new_data = self.source.data.copy()  # type: ignore
        for field in self._fields:
            if field in self._data:
                new_data[field] = self._data[field]

        self.source.data = new_data

        if self._is_keys_dynamic:
            table_data = self.source.data  # type: ignore
            if isinstance(table_data, DataFrame):
                n_rows = len(table_data)
            else:
                n_rows = len(table_data[next(iter(table_data))]) if table_data else 0  # type: ignore
            # check if the table has to be resized
            _new_height = self.root.row_height * (n_rows + 1)
            if self.root.height != _new_height:
                self.root.height = _new_height
