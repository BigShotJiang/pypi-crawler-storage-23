"""Service log page."""

from __future__ import annotations

import logging
import traceback
from datetime import timedelta
from typing import TYPE_CHECKING, Any

import panel as pn

from orangeqs.juice.dashboard import juice_environment
from orangeqs.juice.dashboard.widgets import ServiceLogWidget

if TYPE_CHECKING:
    from panel.template import Template

_logger = logging.getLogger(__name__)


def create_service_log_doc(template_variables: dict[str, Any]) -> Template:
    """Create the Service Logs page."""
    template = juice_environment.get_panel_template("service_log.html")

    _logger.debug("Loading log viewer.")
    try:
        widget = ServiceLogWidget(
            max_time_interval=timedelta(hours=1), max_num_records=1000
        )
        for root_name, root in widget.roots().items():
            template.add_panel(root_name, root)
        for var_name, var in widget.template_variables().items():
            template.add_variable(var_name, var)

        pn.state.execute(widget.initial_update)
        pn.state.add_periodic_callback(widget.update, 1000)  # type: ignore
        _logger.debug("Loaded log viewer.")
    except Exception as ex:
        _logger.error("Failed to load log viewer.", exc_info=ex)
        _logger.error("Failed to create Service Log viewer.", exc_info=ex)
        template.add_variable("load_failed", True)
        template.add_variable("traceback", traceback.format_exc())

    # Set template and variables for Bokeh document
    template.add_variable("page_title", "Service Logs")
    for k, v in template_variables.items():
        template.add_variable(k, v)
    _logger.debug("Successfully setup log viewer bokeh document.")
    return template
