"""Pages (Bokeh documents) that can be served on the dashboard."""
