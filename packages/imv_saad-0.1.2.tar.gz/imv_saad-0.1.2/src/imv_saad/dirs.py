image_dir = r""""""
mask_dir = r""""""
pred_dir = r""""""
resize_mode = r""""""
resize_width = 0
resize_height = 0
