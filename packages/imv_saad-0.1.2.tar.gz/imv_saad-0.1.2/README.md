# imv-saad

Tkinter app for viewing images, masks, predicted masks with overlays and IoU.

## Install

```bash
pip install imv-saad