import logging
from typing import Any, Dict, List, Optional
from bw_essentials.constants.services import Services
from bw_essentials.services.api_client import ApiClient

logger = logging.getLogger(__name__)


class JobScheduler(ApiClient):
    """
    Class for making API calls to the Job Scheduler Service.

    Args:
    user (str): The user for whom the API calls are being made.
    """

    def __init__(self, user, tenant_id: str = None):
        """
        Initialize the Job Scheduler object.

        Args:
        user (str): The user for whom the API calls are being made.
        """
        super().__init__(user)
        self.base_url = self.get_base_url(Services.JOB_SCHEDULER.value)
        self.api_key = self.get_api_key(Services.JOB_SCHEDULER.value)
        self.name = Services.JOB_SCHEDULER.value
        self.tenant_id = tenant_id
        self.urls = {
            "process_user_profile": "taskmanager/process/user-portfolios/",
            "sync_users_all": "dealer_reporter/sync_users_all",
            "sync_all_portfolios": "dealer_reporter/sync_all_portfolios",
            "sync_all_subscriptions": "dealer_reporter/sync_all_subscriptions",
            "sync_all_user_portfolios": "dealer_reporter/sync_all_user_portfolios",
        }

    def _headers(self):
        """
        Prepares headers for API calls.

        Returns:
            dict: Headers
        """
        self.headers.update({
            'Content-Type': 'application/json',
            **({'X-Tenant-ID': self.tenant_id} if self.tenant_id else {}),
            'x-api-key': self.api_key
        })

    def process_user_profile(self, data):
        """
        Send a request to process a user profile.

        This method prepares the required headers and sends a POST request
        to the `process_user_profile` endpoint with the provided user data.

        Args:
            data (dict): A dictionary containing user profile information
                to be sent in the request body.

        Returns:
            None: The method does not return a value.
        """
        logger.info(f"In - process_user_profile {self.user =}")
        self._headers()
        self._post(url=self.base_url, endpoint=self.urls.get('process_user_profile'), json=data)
        logger.info(f"Out - process_user_profile")

    def sync_users_all(
        self,
        user_ids: Optional[List[Any]] = None,
        user_id: Optional[Any] = None,
    ) -> Dict[str, Any]:
        """
        Trigger sync for users.

        Args:
            user_ids: Optional list of user IDs to sync.
            user_id: Optional single user ID (legacy parameter).

        Returns:
            Parsed JSON response containing the Celery task id.
        """
        payload: Dict[str, Any] = {}
        if user_ids is not None:
            payload["user_ids"] = user_ids
        if user_id is not None:
            payload["user_id"] = user_id
        logger.info(f"In - sync_users_all {self.user =}, {payload =}")
        self._headers()
        response = self._post(url=self.base_url, endpoint=self.urls["sync_users_all"], json=payload)
        logger.info(f"Out - sync_users_all {self.user =}")
        return response

    def sync_all_portfolios(
        self,
        portfolio_id: Optional[Any] = None,
    ) -> Dict[str, Any]:
        """
        Trigger sync for portfolios.

        Args:
            portfolio_id: Optional portfolio ID to sync.

        Returns:
            Parsed JSON response containing the Celery task id.
        """
        payload: Dict[str, Any] = {}
        if portfolio_id is not None:
            payload["portfolio_id"] = portfolio_id
        logger.info(f"In - sync_all_portfolios {self.user =}, {payload =}")
        self._headers()
        response = self._post(url=self.base_url, endpoint=self.urls["sync_all_portfolios"], json=payload)
        logger.info(f"Out - sync_all_portfolios {self.user =}")
        return response

    def sync_all_subscriptions(
        self,
        user_ids: Optional[List[Any]] = None,
        user_id: Optional[Any] = None,
    ) -> Dict[str, Any]:
        """
        Trigger sync for subscriptions.

        Args:
            user_ids: Optional list of user IDs to sync.
            user_id: Optional single user ID (legacy parameter).

        Returns:
            Parsed JSON response containing the Celery task id.
        """
        payload: Dict[str, Any] = {}
        if user_ids is not None:
            payload["user_ids"] = user_ids
        if user_id is not None:
            payload["user_id"] = user_id
        logger.info(f"In - sync_all_subscriptions {self.user =}, {payload =}")
        self._headers()
        response = self._post(url=self.base_url, endpoint=self.urls["sync_all_subscriptions"], json=payload)
        logger.info(f"Out - sync_all_subscriptions {self.user =}")
        return response

    def sync_all_user_portfolios(
        self,
        user_portfolio_ids: Optional[List[Any]] = None,
        user_portfolio_id: Optional[Any] = None,
        user_ids: Optional[List[Any]] = None,
        user_id: Optional[Any] = None,
    ) -> Dict[str, Any]:
        """
        Trigger sync for user portfolio records.

        Args:
            user_portfolio_ids: Optional list of user portfolio IDs to sync.
            user_portfolio_id: Optional single user portfolio ID (legacy parameter).
            user_ids: Optional list of user IDs to sync.
            user_id: Optional single user ID (legacy parameter).

        Returns:
            Parsed JSON response containing the Celery task id.
        """
        payload: Dict[str, Any] = {}
        if user_portfolio_ids is not None:
            payload["user_portfolio_ids"] = user_portfolio_ids
        if user_portfolio_id is not None:
            payload["user_portfolio_id"] = user_portfolio_id
        if user_ids is not None:
            payload["user_ids"] = user_ids
        if user_id is not None:
            payload["user_id"] = user_id
        logger.info(f"In - sync_all_user_portfolios {self.user =}, {payload =}")
        self._headers()
        response = self._post(url=self.base_url, endpoint=self.urls["sync_all_user_portfolios"], json=payload)
        logger.info(f"Out - sync_all_user_portfolios {self.user =}")
        return response
