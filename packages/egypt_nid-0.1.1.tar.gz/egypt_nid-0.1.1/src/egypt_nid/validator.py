"""Validation strategies for Egyptian National ID numbers.

Two concrete strategies are provided:

* :class:`StrictValidator`  – raises exceptions on any violation.
* :class:`LenientValidator` – collects warnings and returns them alongside a
  ``valid`` flag; never raises.

Both implement the :class:`BaseValidator` protocol/ABC.
"""

from __future__ import annotations

import datetime
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from egypt_nid.constants import (
    CENTURY_MAP,
    FOREIGN_GOVERNORATE_CODE,
    NID_LENGTH,
    SLICE_CENTURY,
    SLICE_DAY,
    SLICE_GOVERNORATE,
    SLICE_MONTH,
    SLICE_YEAR,
)
from egypt_nid.exceptions import (
    BirthDateError,
    CenturyError,
    GovernorateError,
    LengthError,
    NonNumericError,
)
from egypt_nid.utils import build_birth_date, is_valid_luhn


@dataclass
class ValidationResult:
    """Structured result returned by :class:`LenientValidator`.

    Attributes:
        valid: ``True`` when **all** checks passed (no warnings).
        warnings: Mapping of field name → human-readable warning message.
    """

    valid: bool
    warnings: Dict[str, str] = field(default_factory=dict)

    def add_warning(self, field: str, message: str) -> None:
        """Append a warning and mark the result as invalid."""
        self.warnings[field] = message
        self.valid = False


# ---------------------------------------------------------------------------
# Parsed NID components (shared between strategies)
# ---------------------------------------------------------------------------

@dataclass
class _ParsedComponents:
    century: str
    year: str
    month: str
    day: str
    governorate_code: str
    sequence: str
    checksum_digit: str


def _split_components(nid: str) -> _ParsedComponents:
    return _ParsedComponents(
        century=nid[SLICE_CENTURY],
        year=nid[SLICE_YEAR],
        month=nid[SLICE_MONTH],
        day=nid[SLICE_DAY],
        governorate_code=nid[SLICE_GOVERNORATE],
        sequence=nid[9:13],
        checksum_digit=nid[13],
    )


# ---------------------------------------------------------------------------
# Base class
# ---------------------------------------------------------------------------

class BaseValidator(ABC):
    """Abstract base for NID validators.

    Args:
        governorates: Mapping of ``code → (en_name, ar_name)`` used for
                      governorate validation.
    """

    def __init__(self, governorates: Dict[str, Tuple[str, str]]) -> None:
        self._governorates = governorates

    @abstractmethod
    def validate(self, nid: str) -> ValidationResult:
        """Validate *nid* and return a :class:`ValidationResult`.

        Args:
            nid: The raw National ID string to validate.

        Returns:
            A :class:`ValidationResult` describing the outcome.
        """

    # ------------------------------------------------------------------
    # Shared low-level checks (return error messages or None)
    # ------------------------------------------------------------------

    @staticmethod
    def _check_length(nid: str) -> Optional[str]:
        if len(nid) != NID_LENGTH:
            return f"Expected {NID_LENGTH} digits, got {len(nid)}"
        return None

    @staticmethod
    def _check_numeric(nid: str) -> Optional[str]:
        if not nid.isdigit():
            return "ID must contain digits only"
        return None

    @staticmethod
    def _check_century(century: str) -> Optional[str]:
        if century not in CENTURY_MAP:
            return f"Century digit must be 2 or 3, got {century!r}"
        return None

    @staticmethod
    def _check_birth_date(century: str, year: str, month: str, day: str) -> Optional[str]:
        date = build_birth_date(century, year, month, day)
        if date is None:
            return f"Invalid birth date: {century}{year}-{month}-{day}"
        if date > datetime.date.today():
            return f"Birth date {date} is in the future"
        return None

    def _check_governorate(self, code: str) -> Optional[str]:
        if code not in self._governorates:
            return f"Unknown governorate code: {code!r}"
        return None

    @staticmethod
    def _check_luhn(nid: str) -> Optional[str]:
        if not is_valid_luhn(nid):
            return "Checksum mismatch – possible digit transposition or typo"
        return None


# ---------------------------------------------------------------------------
# Strict strategy
# ---------------------------------------------------------------------------

class StrictValidator(BaseValidator):
    """Validator that raises an exception on the first encountered error.

    Args:
        governorates: Governorate code mapping.

    Raises:
        LengthError: If the ID length is not 14.
        NonNumericError: If the ID contains non-digit characters.
        CenturyError: If the century digit is not 2 or 3.
        BirthDateError: If the birth date is invalid or in the future.
        GovernorateError: If the governorate code is unrecognised.
        ChecksumError: If the Luhn check digit is wrong.
    """

    def validate(self, nid: str) -> ValidationResult:
        """Validate *nid* in strict mode.

        Args:
            nid: Raw National ID string.

        Returns:
            A :class:`ValidationResult` with ``valid=True`` if all checks pass.

        Raises:
            LengthError: On length mismatch.
            NonNumericError: On non-digit characters.
            CenturyError: On invalid century digit.
            BirthDateError: On invalid or future birth date.
            GovernorateError: On unrecognised governorate code.
            ChecksumError: On Luhn checksum failure.
        """
        if msg := self._check_length(nid):
            raise LengthError(msg, field="nid", value=nid)

        if msg := self._check_numeric(nid):
            raise NonNumericError(msg, field="nid", value=nid)

        comp = _split_components(nid)

        if msg := self._check_century(comp.century):
            raise CenturyError(msg, field="century", value=comp.century)

        if msg := self._check_birth_date(comp.century, comp.year, comp.month, comp.day):
            raise BirthDateError(msg, field="birth_date")

        if msg := self._check_governorate(comp.governorate_code):
            raise GovernorateError(msg, field="governorate_code", value=comp.governorate_code)


        return ValidationResult(valid=True)


# ---------------------------------------------------------------------------
# Lenient strategy
# ---------------------------------------------------------------------------

class LenientValidator(BaseValidator):
    """Validator that collects all warnings without raising.

    All checks are run regardless of earlier failures; every violation is
    recorded as a warning in the returned :class:`ValidationResult`.

    Args:
        governorates: Governorate code mapping.
    """

    def validate(self, nid: str) -> ValidationResult:
        """Validate *nid* in lenient mode.

        Args:
            nid: Raw National ID string.

        Returns:
            A :class:`ValidationResult` containing all detected warnings.
            ``valid`` is ``False`` if any check failed.
        """
        result = ValidationResult(valid=True)

        if msg := self._check_length(nid):
            result.add_warning("length", msg)
            # Cannot continue safely if length is wrong
            return result

        if msg := self._check_numeric(nid):
            result.add_warning("numeric", msg)
            return result

        comp = _split_components(nid)

        if msg := self._check_century(comp.century):
            result.add_warning("century", msg)

        if msg := self._check_birth_date(comp.century, comp.year, comp.month, comp.day):
            result.add_warning("birth_date", msg)

        if msg := self._check_governorate(comp.governorate_code):
            result.add_warning("governorate_code", msg)


        return result
