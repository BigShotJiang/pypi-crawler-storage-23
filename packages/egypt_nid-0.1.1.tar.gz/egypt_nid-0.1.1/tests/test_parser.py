"""Tests for egypt_nid.parser."""
from __future__ import annotations
import pytest
from egypt_nid import parse, parse_lenient
from egypt_nid.exceptions import EgyptNIDError

class TestParse:
    def test_valid(self, valid_nid_str):
        assert parse(valid_nid_str).raw == valid_nid_str

    def test_caching_returns_same_object(self, valid_nid_str):
        assert parse(valid_nid_str) is parse(valid_nid_str)

    def test_invalid_raises(self):
        with pytest.raises(EgyptNIDError):
            parse("00000000000000")

    def test_any_last_digit_valid(self):
        base = "3010515010151"
        for last in "0123456789":
            assert parse(base + last) is not None

    def test_real_nid(self):
        nid = parse("30307180101511")
        assert nid.birth_date.year == 2003
        assert nid.gender == "male"
        assert nid.governorate_name_en == "Cairo"

    def test_bad_version_raises(self, valid_nid_str):
        from egypt_nid.exceptions import ConfigurationError
        with pytest.raises(ConfigurationError):
            parse(valid_nid_str, version="v999")

class TestParseLenient:
    def test_valid_returns_model(self, valid_nid_str):
        nid, result = parse_lenient(valid_nid_str)
        assert nid is not None
        assert result.valid

    def test_critical_error_returns_none(self):
        nid, result = parse_lenient("123")
        assert nid is None
        assert not result.valid

    def test_bad_governorate_warning_model_returned(self):
        nid, result = parse_lenient("30105159901511")
        assert nid is not None          # model still built
        assert not result.valid
        assert "governorate_code" in result.warnings
        assert "checksum" not in result.warnings
