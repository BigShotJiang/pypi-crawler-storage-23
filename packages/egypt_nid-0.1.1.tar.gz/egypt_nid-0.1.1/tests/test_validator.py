"""Tests for egypt_nid.validator."""

from __future__ import annotations

import pytest

from egypt_nid.constants import GOVERNORATES_V1
from egypt_nid.exceptions import (
    BirthDateError,
    CenturyError,
    GovernorateError,
    LengthError,
    NonNumericError,
)
from egypt_nid.validator import LenientValidator, StrictValidator

GOVS = GOVERNORATES_V1


def make_strict() -> StrictValidator:
    return StrictValidator(GOVS)


def make_lenient() -> LenientValidator:
    return LenientValidator(GOVS)


class TestStrictValidatorLength:
    def test_short(self):
        with pytest.raises(LengthError):
            make_strict().validate("123")

    def test_long(self):
        with pytest.raises(LengthError):
            make_strict().validate("1" * 15)


class TestStrictValidatorNumeric:
    def test_alpha(self):
        with pytest.raises(NonNumericError):
            make_strict().validate("3010515010123X")


class TestStrictValidatorCentury:
    def test_bad_century(self):
        with pytest.raises(CenturyError):
            make_strict().validate("10105150101230")


class TestStrictValidatorBirthDate:
    def test_invalid_month(self):
        with pytest.raises(BirthDateError):
            make_strict().validate("30113150101230")

    def test_future_date(self):
        with pytest.raises(BirthDateError):
            make_strict().validate("39901010101230")


class TestStrictValidatorGovernorate:
    def test_unknown_code(self):
        with pytest.raises(GovernorateError):
            make_strict().validate("30105159901230")


class TestStrictValidatorValid:
    def test_valid_passes(self, valid_nid_str):
        result = make_strict().validate(valid_nid_str)
        assert result.valid

    def test_any_last_digit_accepted(self):
        """The 14th digit is sequential — no checksum validation."""
        base = "3010515010151"
        for last in "0123456789":
            result = make_strict().validate(base + last)
            assert result.valid, f"Should accept last digit {last!r}"


class TestLenientValidator:
    def test_length_error_short_circuits(self):
        result = make_lenient().validate("123")
        assert not result.valid
        assert "length" in result.warnings

    def test_valid_nid_no_warnings(self, valid_nid_str):
        result = make_lenient().validate(valid_nid_str)
        assert result.valid
        assert result.warnings == {}

    def test_bad_century_warning(self):
        result = make_lenient().validate("10105150101511")
        assert not result.valid
        assert "century" in result.warnings

    def test_bad_governorate_warning(self):
        result = make_lenient().validate("30105159901511")
        assert not result.valid
        assert "governorate_code" in result.warnings

    def test_future_birth_date_warning(self):
        result = make_lenient().validate("39901010101511")
        assert not result.valid
        assert "birth_date" in result.warnings

    def test_no_checksum_warning_ever(self, valid_nid_str):
        """Egyptian NID has no checksum — this warning should never appear."""
        result = make_lenient().validate(valid_nid_str)
        assert "checksum" not in result.warnings
