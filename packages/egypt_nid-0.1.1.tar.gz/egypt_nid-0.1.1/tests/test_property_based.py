"""Property-based tests using Hypothesis."""

from __future__ import annotations

import datetime
import calendar

import pytest
from hypothesis import given, settings, assume
from hypothesis import strategies as st

from egypt_nid import parse
from egypt_nid.exceptions import EgyptNIDError
from egypt_nid.utils import calculate_age


VALID_GOVS = [
    "01", "02", "03", "04", "11", "12", "13", "14", "15",
    "16", "17", "18", "19", "21", "22", "23", "24", "25",
    "26", "27", "28", "29", "31", "32", "33", "34", "35", "88",
]


@st.composite
def valid_nid_strategy(draw):
    """Generate structurally valid Egyptian National ID strings."""
    century = draw(st.sampled_from(["2", "3"]))
    if century == "2":
        year = draw(st.integers(min_value=0, max_value=99))
        full_year = 1900 + year
    else:
        current_year_last2 = datetime.date.today().year - 2000
        year = draw(st.integers(min_value=0, max_value=current_year_last2))
        full_year = 2000 + year

    month = draw(st.integers(min_value=1, max_value=12))
    max_day = calendar.monthrange(full_year, month)[1]
    day = draw(st.integers(min_value=1, max_value=max_day))

    born = datetime.date(full_year, month, day)
    assume(born <= datetime.date.today())

    gov   = draw(st.sampled_from(VALID_GOVS))
    seq   = draw(st.integers(min_value=0, max_value=9999))
    last  = draw(st.integers(min_value=0, max_value=9))   # any digit — no checksum

    return f"{century}{year:02d}{month:02d}{day:02d}{gov}{seq:04d}{last}"


class TestPropertyBasedParsing:
    @given(valid_nid_strategy())
    @settings(max_examples=200)
    def test_valid_nid_always_parses(self, nid_str):
        nid = parse(nid_str)
        assert nid.raw == nid_str

    @given(valid_nid_strategy())
    @settings(max_examples=100)
    def test_age_non_negative(self, nid_str):
        assert parse(nid_str).age >= 0

    @given(valid_nid_strategy())
    @settings(max_examples=100)
    def test_gender_valid(self, nid_str):
        assert parse(nid_str).gender in ("male", "female")

    @given(valid_nid_strategy())
    @settings(max_examples=100)
    def test_to_dict_roundtrip(self, nid_str):
        d = parse(nid_str).to_dict()
        assert isinstance(d, dict)
        assert "gender" in d

    @given(valid_nid_strategy())
    @settings(max_examples=100)
    def test_masked_preserves_century(self, nid_str):
        assert parse(nid_str).masked()[0] == nid_str[0]

    @given(valid_nid_strategy())
    @settings(max_examples=100)
    def test_all_last_digits_accepted(self, nid_str):
        """Any digit in position 14 must be accepted — there is no checksum."""
        base = nid_str[:13]
        for last in "0123456789":
            nid = parse(base + last)
            assert nid is not None


class TestPropertyBasedInvalidInputs:
    @given(st.text(min_size=0, max_size=30))
    @settings(max_examples=200)
    def test_random_strings_never_crash(self, text):
        try:
            parse(text)
        except EgyptNIDError:
            pass
        except Exception as exc:
            pytest.fail(f"Unexpected exception {type(exc).__name__}: {exc}")


class TestCalculateAgeProperty:
    @given(st.dates(
        min_value=datetime.date(1900, 1, 1),
        max_value=datetime.date.today(),
    ))
    def test_age_always_non_negative(self, birth_date):
        assert calculate_age(birth_date) >= 0

    @given(st.dates(
        min_value=datetime.date(1900, 1, 1),
        max_value=datetime.date.today(),
    ))
    def test_age_reasonable_upper_bound(self, birth_date):
        assert calculate_age(birth_date) <= 130
