"""Shared pytest fixtures for the egypt-nid test suite.

NIDs are constructed from known real-world-style values.
The 14th digit is a plain sequential digit — there is no checksum algorithm
in the Egyptian National ID.
"""

from __future__ import annotations

import datetime

import pytest

from egypt_nid import NationalID, parse


# ---------------------------------------------------------------------------
# Known-good NIDs used across multiple test modules
# Format: C YY MM DD GG SSSS X
#   C    = century (2=1900s, 3=2000s)
#   YY   = 2-digit year
#   MM   = month
#   DD   = day
#   GG   = governorate code
#   SSSS = sequence (index 12 odd → male, even → female)
#   X    = final sequential digit (NOT a checksum)
# ---------------------------------------------------------------------------

# Cairo male born 2001-05-15, sequence ends in odd digit → male
VALID_NID_MALE_CAIRO   = "30105150101511"   # gov=01, seq=0151 (odd→male), last=1

# Alexandria female born 1990-08-20, sequence ends in even digit → female
VALID_NID_FEMALE_ALEX  = "29008200201240"   # gov=02, seq=0124 (even→female), last=0

# Foreign-born (governorate 88), sequence ends in odd → male
VALID_NID_FOREIGN      = "30105158801511"   # gov=88, seq=0151 (odd→male), last=1


@pytest.fixture
def nid_male_cairo() -> NationalID:
    """A valid NID for a male born in Cairo on 2001-05-15."""
    return parse(VALID_NID_MALE_CAIRO)


@pytest.fixture
def nid_female_alex() -> NationalID:
    """A valid NID for a female born in Alexandria on 1990-08-20."""
    return parse(VALID_NID_FEMALE_ALEX)


@pytest.fixture
def nid_foreign() -> NationalID:
    """A valid NID for someone born outside Egypt (code 88)."""
    return parse(VALID_NID_FOREIGN)


@pytest.fixture
def valid_nid_str() -> str:
    """Return the raw string for the Cairo male NID."""
    return VALID_NID_MALE_CAIRO
