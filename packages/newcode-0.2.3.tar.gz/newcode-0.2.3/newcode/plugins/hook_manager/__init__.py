"""Hook Manager plugin – interactive TUI for managing Claude Code hooks."""
