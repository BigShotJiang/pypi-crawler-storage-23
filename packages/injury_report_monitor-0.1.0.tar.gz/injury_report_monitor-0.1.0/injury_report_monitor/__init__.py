"""
shipp-injuries: Aggregated injury reports for NBA, MLB, and Soccer with player status tracking.
"""
__version__ = "0.1.0"
