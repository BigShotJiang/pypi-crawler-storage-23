"""
Project-to-EPUB: Convert a software project directory into an EPUB file for offline code reading.
"""

__version__ = "0.1.5"
