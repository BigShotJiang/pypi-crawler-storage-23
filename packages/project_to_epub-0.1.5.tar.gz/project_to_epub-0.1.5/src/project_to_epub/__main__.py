"""
Main entry point for running the module directly.
"""

from project_to_epub.cli import app

if __name__ == "__main__":
    app()
