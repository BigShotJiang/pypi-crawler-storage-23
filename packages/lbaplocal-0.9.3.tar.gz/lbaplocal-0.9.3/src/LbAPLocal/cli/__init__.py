###############################################################################
# (c) Copyright 2020-2024 CERN for the benefit of the LHCb Collaboration      #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""
CLI package for LbAPLocal.

Contains all command-line interface implementations:
- main: Enhanced typer/rich-based CLI (primary interface)
- legacy: Original click-based CLI (deprecated)
- wizards: Interactive wizard utilities
"""

from apd.authentication import get_auth_headers

from ..utils import production_to_versions
from .legacy import main as legacy_main
from .main import app

__all__ = ["app", "legacy_main", "production_to_versions", "get_auth_headers"]
