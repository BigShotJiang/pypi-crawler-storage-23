# FILE TO SET DECAY NAME

sample_decay = 'Bu2JpsiK_mm'
from Configurables import DaVinci
DaVinci().TupleFile=sample_decay
