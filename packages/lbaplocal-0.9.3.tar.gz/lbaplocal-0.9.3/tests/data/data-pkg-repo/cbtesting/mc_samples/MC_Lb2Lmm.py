# FILE TO SET DECAY NAME

sample_decay = 'Lb2Lmm'
from Configurables import DaVinci
DaVinci().TupleFile=sample_decay
