"""Ollama Web UI - A beautiful web interface for Ollama"""
__version__ = "0.2.1"