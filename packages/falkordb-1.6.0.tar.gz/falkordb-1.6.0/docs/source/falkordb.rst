falkordb package
================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   falkordb.asyncio

Submodules
----------

falkordb.edge module
--------------------

.. automodule:: falkordb.edge
   :members:
   :undoc-members:
   :show-inheritance:

falkordb.exceptions module
--------------------------

.. automodule:: falkordb.exceptions
   :members:
   :undoc-members:
   :show-inheritance:

falkordb.execution\_plan module
-------------------------------

.. automodule:: falkordb.execution_plan
   :members:
   :undoc-members:
   :show-inheritance:

falkordb.falkordb module
------------------------

.. automodule:: falkordb.falkordb
   :members:
   :undoc-members:
   :show-inheritance:

falkordb.graph module
---------------------

.. automodule:: falkordb.graph
   :members:
   :undoc-members:
   :show-inheritance:

falkordb.graph\_schema module
-----------------------------

.. automodule:: falkordb.graph_schema
   :members:
   :undoc-members:
   :show-inheritance:

falkordb.helpers module
-----------------------

.. automodule:: falkordb.helpers
   :members:
   :undoc-members:
   :show-inheritance:

falkordb.node module
--------------------

.. automodule:: falkordb.node
   :members:
   :undoc-members:
   :show-inheritance:

falkordb.path module
--------------------

.. automodule:: falkordb.path
   :members:
   :undoc-members:
   :show-inheritance:

falkordb.query\_result module
-----------------------------

.. automodule:: falkordb.query_result
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: falkordb
   :members:
   :undoc-members:
   :show-inheritance:
