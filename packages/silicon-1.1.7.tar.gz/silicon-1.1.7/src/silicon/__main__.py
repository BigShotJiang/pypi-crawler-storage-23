"""Entry point for `python -m <package>` invocation."""

from silicon.cli import app

if __name__ == "__main__":
    app()
