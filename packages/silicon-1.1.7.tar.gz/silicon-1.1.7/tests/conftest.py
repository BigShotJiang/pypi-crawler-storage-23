"""Common test configuration and utilities."""
