from __future__ import annotations

# Version is defined in pyproject.toml
from importlib.metadata import version

__version__ = version("refgenieserver")
