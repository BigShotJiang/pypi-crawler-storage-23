from py_autoflow.program import Program
from py_autoflow.batch import Batch
from py_autoflow.stack import Stack
from py_autoflow.wflow_smith import WfSmith
from py_autoflow.queue_manager import QueueManager
from py_autoflow.queue_managers.bash_manager import BashManager
from py_autoflow.queue_managers.slurm2_manager import Slurm2Manager
from py_autoflow.cli_manager import *

import sys

if sys.version_info[:2] >= (3, 8):
    # TODO: Import directly (no need for conditional) when `python_requires = >= 3.8`
    from importlib.metadata import PackageNotFoundError, version  # pragma: no cover
else:
    from importlib_metadata import PackageNotFoundError, version  # pragma: no cover

try:
    # Change here if project is renamed and does not equal the package name
    dist_name = __name__
    __version__ = version(dist_name)
except PackageNotFoundError:  # pragma: no cover
    __version__ = "unknown"
finally:
    del version, PackageNotFoundError
