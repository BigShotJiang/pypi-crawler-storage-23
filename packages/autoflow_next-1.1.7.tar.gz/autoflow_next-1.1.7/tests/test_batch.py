import sys

from py_autoflow.batch import Batch

def test_resources():
	command = 'algo\nresources: -s -n bigmem -c 1 -t "7-00:00:00" -m "300gb"\nalga'
	Batch.init_indexes()
	task = Batch(tag = 'test)', init = '', main_command = command, id = 'test', exec_folder = None)
	task.scan_resources(command)
	resources = {
		'cpu': task.attrib['cpu'], 'mem': task.attrib['mem'], 
		'node': task.attrib['node'], 'time': task.attrib['time'] 
	}
	expected_result = { 'cpu': 1, 'mem': "300gb", 'node': 'bigmem', 'time': '7-00:00:00' }
	assert(resources, expected_result)