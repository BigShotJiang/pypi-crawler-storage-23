"""
    Dummy conftest.py for py_autoflow.

    If you don't know what this is for, just leave it empty.
    Read more about conftest.py under:
    - https://docs.pytest.org/en/stable/fixture.html
    - https://docs.pytest.org/en/stable/writing_plugins.html
"""
import os
import sys
import json
import pytest
from py_autoflow.cli_manager import *

ROOT_PATH=os.path.dirname(__file__)
TEMPLATES_PATH = os.path.join(ROOT_PATH, 'templates')

@pytest.fixture(scope="session")
def tmp_dir(tmpdir_factory):
    fn = tmpdir_factory.mktemp("./tmp_output")
    return fn

#https://towardsdatascience.com/passing-functions-to-test-files-in-python-pytest-0f5fe9efed5d/
def print_compared_output(test_result, expected_result):
    for file, content in test_result.items():
        print(f"{file}", file=sys.stderr)
        print('=========', file=sys.stderr)
        print(content, file=sys.stderr)
        print('--------', file=sys.stderr)
        print(expected_result[file], file=sys.stderr)

def _compare_workflow(tmp_dir, template, execution_folder, json_expected_result, ignore_files = [], extra_af_args=None):
    string_extra_args = ''
    if extra_af_args != None: string_extra_args = f" {extra_af_args}"
    args = f"-b -w {os.path.join(TEMPLATES_PATH, template)} -o {os.path.join(tmp_dir, execution_folder)}{string_extra_args}".split(" ")
    autoflow(args)
    test_result = check_wf_output(os.path.join(tmp_dir, execution_folder), ignore_files)
    expected_result = None
    with open(os.path.join(TEMPLATES_PATH, json_expected_result)) as f: expected_result = json.load(f)
    #print_compared_output(test_result, expected_result)
    assert expected_result == test_result

@pytest.fixture(scope="session")
def compare_workflow():
    return _compare_workflow