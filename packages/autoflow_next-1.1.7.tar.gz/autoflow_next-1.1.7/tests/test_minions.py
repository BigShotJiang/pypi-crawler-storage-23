import os

ROOT_PATH=os.path.dirname(__file__)
TEMPLATES_PATH = os.path.join(ROOT_PATH, 'templates')
IGNORE_FILES = ['execution.sh', 'wf.json', 'output']
NESTED_JOBS_IGNORE_FILES = ['execution.sh', 'output']

def test_nested_jobs_template(tmp_dir, compare_workflow):
	compare_workflow(tmp_dir, 'nested_jobs.af', 'nested_jobs', 'nested_jobs.json', ignore_files = NESTED_JOBS_IGNORE_FILES)

def test_iter1to1_manyto1(tmp_dir, compare_workflow):
	compare_workflow(tmp_dir, 'iter1to1_Manyto1.af', 'iter1to1_Manyto1', 'iter1to1_Manyto1.json', ignore_files = IGNORE_FILES)

def test_basic_with_subsetvars(tmp_dir, compare_workflow):
	compare_workflow(tmp_dir, 'basic_with_subsetvars.af', 'basic_with_subsetvars', 'basic_with_subsetvars.json', 
		ignore_files = IGNORE_FILES, extra_af_args="-V $file_name=test,$attrtoy=hello,$attrtoy_1=bye")

