.. These are examples of badges you might want to add to your README:
   please update the URLs accordingly

    .. image:: https://api.cirrus-ci.com/github/<USER>/py_autoflow.svg?branch=main
        :alt: Built Status
        :target: https://cirrus-ci.com/github/<USER>/py_autoflow
    .. image:: https://readthedocs.org/projects/py_autoflow/badge/?version=latest
        :alt: ReadTheDocs
        :target: https://py_autoflow.readthedocs.io/en/stable/
    .. image:: https://img.shields.io/coveralls/github/<USER>/py_autoflow/main.svg
        :alt: Coveralls
        :target: https://coveralls.io/r/<USER>/py_autoflow
    .. image:: https://img.shields.io/pypi/v/py_autoflow.svg
        :alt: PyPI-Server
        :target: https://pypi.org/project/py_autoflow/
    .. image:: https://img.shields.io/conda/vn/conda-forge/py_autoflow.svg
        :alt: Conda-Forge
        :target: https://anaconda.org/conda-forge/py_autoflow
    .. image:: https://pepy.tech/badge/py_autoflow/month
        :alt: Monthly Downloads
        :target: https://pepy.tech/project/py_autoflow
    .. image:: https://img.shields.io/twitter/url/http/shields.io.svg?style=social&label=Twitter
        :alt: Twitter
        :target: https://twitter.com/py_autoflow

.. image:: https://img.shields.io/badge/-PyScaffold-005CA0?logo=pyscaffold
    :alt: Project generated with PyScaffold
    :target: https://pyscaffold.org/



=============
AutoFlow-Next
=============


    Intuitive workflow manager oriented to ease research activity


This is a port and refactored version from the Ruby version AutoFlow. It is designed to build workflows easily, you can focus in connect your tasks and AutoFlow takes the job to manage the execution storage and orchestation.


.. _pyscaffold-notes:

Note
====

This project has been set up using PyScaffold 4.5. For details and usage
information on PyScaffold see https://pyscaffold.org/.
