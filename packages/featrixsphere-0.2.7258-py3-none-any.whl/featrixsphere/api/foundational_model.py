"""
FoundationalModel class for FeatrixSphere API.

Represents a trained embedding space (foundational model).
"""

import time
import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, Any, Optional, List, Union, TYPE_CHECKING

if TYPE_CHECKING:
    from .http_client import ClientContext
    import pandas as pd
    import numpy as np

from .predictor import Predictor
from .vector_database import VectorDatabase
from .reference_record import ReferenceRecord

logger = logging.getLogger(__name__)


def _parse_datetime(value) -> Optional[datetime]:
    """Parse a datetime from ISO string or return as-is if already datetime."""
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        try:
            # Handle ISO format with or without timezone
            return datetime.fromisoformat(value.replace('Z', '+00:00'))
        except (ValueError, AttributeError):
            return None
    return None


@dataclass
class FoundationalModel:
    """
    Represents a foundational model (embedding space).

    Attributes:
        id: Session ID / FM ID
        name: Model name
        status: Training status ("training", "done", "error")
        dimensions: Embedding dimensions (d_model)
        epochs: Training epochs completed
        created_at: Creation timestamp

    Usage:
        # Create from client
        fm = featrix.create_foundational_model(
            name="customer_embeddings",
            data_file="customers.csv"
        )

        # Wait for training
        fm.wait_for_training()

        # Create classifier
        predictor = fm.create_binary_classifier(
            name="churn_predictor",
            target_column="churned"
        )

        # Create vector database
        vdb = fm.create_vector_database(
            name="customer_search",
            records=customer_records
        )

        # Encode records
        vectors = fm.encode([{"age": 35}, {"age": 42}])
    """

    id: str
    name: Optional[str] = None
    status: Optional[str] = None
    dimensions: Optional[int] = None
    epochs: Optional[int] = None
    final_loss: Optional[float] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    session_type: Optional[str] = None
    compute_cluster: Optional[str] = None
    error_message: Optional[str] = None
    training_progress: Optional[Dict[str, Any]] = None
    jobs: Optional[Dict[str, Any]] = field(default_factory=dict, repr=False)

    # Internal
    _ctx: Optional['ClientContext'] = field(default=None, repr=False)

    @classmethod
    def from_response(
        cls,
        response: Dict[str, Any],
        ctx: Optional['ClientContext'] = None
    ) -> 'FoundationalModel':
        """Create FoundationalModel from API response."""
        session_id = response.get('session_id', '')

        return cls(
            id=session_id,
            name=response.get('name'),
            status=response.get('status'),
            dimensions=response.get('d_model') or response.get('dimensions'),
            epochs=response.get('epochs') or response.get('final_epoch'),
            final_loss=response.get('final_loss'),
            created_at=_parse_datetime(response.get('created_at')),
            session_type=response.get('session_type'),
            compute_cluster=response.get('compute_cluster'),
            _ctx=ctx,
        )

    @classmethod
    def from_session_id(
        cls,
        session_id: str,
        ctx: 'ClientContext'
    ) -> 'FoundationalModel':
        """Load FoundationalModel from session ID."""
        # Get session info - response has {"session": {...}, "jobs": {...}}
        response_data = ctx.get_json(f"/compute/session/{session_id}")
        session = response_data.get('session', response_data)

        fm = cls(
            id=session_id,
            name=session.get('name'),
            status=session.get('status'),
            created_at=_parse_datetime(session.get('created_at')),
            session_type=session.get('session_type'),
            compute_cluster=session.get('compute_cluster'),
            _ctx=ctx,
        )

        # Extract model info, training stats, jobs, error_message
        fm._update_from_session(response_data)

        return fm

    def create_binary_classifier(
        self,
        target_column: str,
        name: Optional[str] = None,
        labels_file: Optional[str] = None,
        labels_df: Optional['pd.DataFrame'] = None,
        epochs: int = 0,
        rare_label_value: Optional[str] = None,
        class_imbalance: Optional[Dict[str, float]] = None,
        cost_false_positive: Optional[float] = None,
        cost_false_negative: Optional[float] = None,
        webhooks: Optional[Dict[str, str]] = None,
        **kwargs
    ) -> Predictor:
        """
        Create a binary classifier on this foundational model.

        For target columns with exactly 2 classes. Supports cost-sensitive
        optimization for asymmetric error costs (e.g., fraud detection where
        missing fraud is much worse than a false alarm).

        Args:
            target_column: Column name to predict (must have exactly 2 unique values)
            name: Predictor name (optional)
            labels_file: Path to CSV with labels (optional - uses existing data if not provided)
            labels_df: DataFrame with labels (optional - alternative to labels_file)
            epochs: Training epochs (0 = automatic based on dataset complexity)
            rare_label_value: Which class is the minority/positive class for metrics
            class_imbalance: Expected real-world class distribution, e.g.
                {"approved": 0.97, "rejected": 0.03}. Use when training data
                is resampled but production distribution differs.
            cost_false_positive: Cost of a false positive (e.g., 100 = $100 per false alarm).
                Used for Bayes-optimal threshold selection.
            cost_false_negative: Cost of a false negative (e.g., 5000 = $5000 per missed case).
                Used for Bayes-optimal threshold selection.
            webhooks: Webhook URLs for training events
            **kwargs: Additional training parameters

        Returns:
            Predictor object (training started). Call predictor.wait_for_training() to block.

        Example:
            # Basic binary classifier
            predictor = fm.create_binary_classifier(
                target_column="churned",
                rare_label_value="yes"
            )
            predictor.wait_for_training()

            # Cost-sensitive fraud detection
            predictor = fm.create_binary_classifier(
                target_column="is_fraud",
                rare_label_value="fraud",
                cost_false_positive=100,
                cost_false_negative=5000
            )
        """
        if cost_false_positive is not None:
            kwargs['cost_false_positive'] = cost_false_positive
        if cost_false_negative is not None:
            kwargs['cost_false_negative'] = cost_false_negative

        return self._create_predictor(
            target_column=target_column,
            target_type="set",
            name=name,
            labels_file=labels_file,
            labels_df=labels_df,
            epochs=epochs,
            rare_label_value=rare_label_value,
            class_imbalance=class_imbalance,
            webhooks=webhooks,
            **kwargs
        )

    def create_multi_classifier(
        self,
        target_column: str,
        name: Optional[str] = None,
        labels_file: Optional[str] = None,
        labels_df: Optional['pd.DataFrame'] = None,
        epochs: int = 0,
        class_imbalance: Optional[Dict[str, float]] = None,
        webhooks: Optional[Dict[str, str]] = None,
        **kwargs
    ) -> Predictor:
        """
        Create a multiclass classifier on this foundational model.

        For target columns with 3 or more classes. Architecture is auto-sized
        based on dataset complexity.

        Args:
            target_column: Column name to predict (3+ unique values)
            name: Predictor name (optional)
            labels_file: Path to CSV with labels (optional - uses existing data if not provided)
            labels_df: DataFrame with labels (optional - alternative to labels_file)
            epochs: Training epochs (0 = automatic based on dataset complexity)
            class_imbalance: Expected real-world class distribution, e.g.
                {"cat": 0.7, "dog": 0.2, "bird": 0.1}. Use when training data
                is resampled but production distribution differs.
            webhooks: Webhook URLs for training events
            **kwargs: Additional training parameters

        Returns:
            Predictor object (training started). Call predictor.wait_for_training() to block.

        Example:
            predictor = fm.create_multi_classifier(
                target_column="product_category",
                name="category_predictor"
            )
            predictor.wait_for_training()
        """
        return self._create_predictor(
            target_column=target_column,
            target_type="set",
            name=name,
            labels_file=labels_file,
            labels_df=labels_df,
            epochs=epochs,
            class_imbalance=class_imbalance,
            webhooks=webhooks,
            **kwargs
        )

    def create_regressor(
        self,
        target_column: str,
        name: Optional[str] = None,
        labels_file: Optional[str] = None,
        labels_df: Optional['pd.DataFrame'] = None,
        epochs: int = 0,
        webhooks: Optional[Dict[str, str]] = None,
        **kwargs
    ) -> Predictor:
        """
        Create a regressor predictor from this foundational model.

        Args:
            target_column: Column name to predict
            name: Predictor name (optional)
            labels_file: Path to labels file (optional)
            labels_df: DataFrame with labels (optional)
            epochs: Training epochs (0 = auto)
            webhooks: Webhook URLs for events
            **kwargs: Additional training parameters

        Returns:
            Predictor object (training started)
        """
        return self._create_predictor(
            target_column=target_column,
            target_type="numeric",
            name=name,
            labels_file=labels_file,
            labels_df=labels_df,
            epochs=epochs,
            webhooks=webhooks,
            **kwargs
        )

    def _create_predictor(
        self,
        target_column: str,
        target_type: str,
        name: Optional[str] = None,
        labels_file: Optional[str] = None,
        labels_df: Optional['pd.DataFrame'] = None,
        epochs: int = 0,
        rare_label_value: Optional[str] = None,
        class_imbalance: Optional[Dict[str, float]] = None,
        webhooks: Optional[Dict[str, str]] = None,
        **kwargs
    ) -> Predictor:
        """Internal method to create predictor."""
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        # If labels file/df provided, use train_on_foundational_model which
        # creates a NEW session. The proxy handles finding the FM on any node.
        if labels_file or labels_df is not None:
            return self._create_predictor_with_labels(
                target_column=target_column,
                target_type=target_type,
                name=name,
                labels_file=labels_file,
                labels_df=labels_df,
                epochs=epochs,
                rare_label_value=rare_label_value,
                class_imbalance=class_imbalance,
                webhooks=webhooks,
                **kwargs
            )

        # No labels file — train on the FM's existing data.
        # Uses the FM's session directly (data lives in its session dir).
        data = {
            "target_column": target_column,
            "target_column_type": target_type,
            "epochs": epochs,
        }
        if rare_label_value:
            data["rare_label_value"] = rare_label_value
        if class_imbalance:
            data["class_imbalance"] = class_imbalance
        if webhooks:
            data["webhooks"] = webhooks
        data.update(kwargs)

        response = self._ctx.post_json(
            f"/compute/session/{self.id}/train_predictor",
            data=data
        )

        return Predictor(
            id=response.get('predictor_id', ''),
            session_id=self.id,
            target_column=target_column,
            target_type=target_type,
            name=name,
            status="training",
            _ctx=self._ctx,
            _foundational_model=self,
        )

    def _create_predictor_with_labels(
        self,
        target_column: str,
        target_type: str,
        name: Optional[str] = None,
        labels_file: Optional[str] = None,
        labels_df: Optional['pd.DataFrame'] = None,
        epochs: int = 0,
        rare_label_value: Optional[str] = None,
        class_imbalance: Optional[Dict[str, float]] = None,
        webhooks: Optional[Dict[str, str]] = None,
        **kwargs
    ) -> Predictor:
        """Create predictor with separate labels file.

        Uses /compute/train_on_foundational_model which creates a NEW session.
        The proxy handles finding the FM on any node and forwarding its session
        data to the target compute node.
        """
        import io
        import gzip
        import json

        # Prepare the labels data
        if labels_df is not None:
            csv_buffer = io.StringIO()
            labels_df.to_csv(csv_buffer, index=False)
            file_content = csv_buffer.getvalue().encode('utf-8')
            filename = "labels.csv"
        elif labels_file:
            with open(labels_file, 'rb') as f:
                file_content = f.read()
            filename = labels_file.split('/')[-1]
        else:
            raise ValueError("Either labels_file or labels_df must be provided")

        # Compress if large
        if len(file_content) > 100_000:
            compressed = gzip.compress(file_content)
            if len(compressed) < len(file_content):
                file_content = compressed
                filename = filename + '.gz'

        # Build form data for train_on_foundational_model endpoint
        form_data = {
            "foundation_model_id": self.id,
            "target_column": target_column,
            "target_column_type": target_type,
            "epochs": str(epochs),
        }
        if name:
            form_data["name"] = name
        if rare_label_value:
            form_data["rare_label_value"] = rare_label_value
        if class_imbalance:
            form_data["class_imbalance"] = json.dumps(class_imbalance)
        if webhooks:
            form_data["webhooks"] = json.dumps(webhooks)
        # Pass through kwargs (session_name_prefix, user_metadata, etc.)
        for key, value in kwargs.items():
            if value is not None:
                if isinstance(value, (dict, list)):
                    form_data[key] = json.dumps(value)
                else:
                    form_data[key] = str(value)

        files = {"file": (filename, file_content)}

        response = self._ctx.post_multipart(
            "/compute/train_on_foundational_model",
            data=form_data,
            files=files
        )

        # The server creates a NEW session — use that session_id, not the FM's
        new_session_id = response.get('session_id', self.id)

        return Predictor(
            id=response.get('predictor_id', ''),
            session_id=new_session_id,
            target_column=target_column,
            target_type=target_type,
            name=name,
            status="training",
            _ctx=self._ctx,
            _foundational_model=self,
        )

    def create_vector_database(
        self,
        name: Optional[str] = None,
        records: Optional[Union[List[Dict[str, Any]], 'pd.DataFrame']] = None
    ) -> VectorDatabase:
        """
        Create a vector database from this foundational model.

        Args:
            name: Database name
            records: Initial records to add (optional)

        Returns:
            VectorDatabase object

        Example:
            vdb = fm.create_vector_database(
                name="customer_search",
                records=customer_records
            )
            similar = vdb.similarity_search({"age": 35}, k=5)
        """
        vdb = VectorDatabase.from_session(
            session_id=self.id,
            name=name,
            ctx=self._ctx,
            foundational_model=self,
        )

        # Add initial records if provided
        if records is not None:
            vdb.add_records(records)

        return vdb

    def create_reference_record(
        self,
        record: Dict[str, Any],
        name: Optional[str] = None
    ) -> ReferenceRecord:
        """
        Create a reference record from a specific record for similarity search.

        A reference record is a reference point in the embedding space that you can use
        to find similar records. Particularly useful when you only have a positive
        class but no negative class - just find more records like the positive example.

        Args:
            record: The record to create a reference from
            name: Optional name for the reference record

        Returns:
            ReferenceRecord object that can be used for similarity search

        Example:
            # Create a reference record from a high-value customer
            ref = fm.create_reference_record(
                record={"age": 35, "income": 100000, "plan": "premium"},
                name="high_value_customer"
            )

            # Find similar customers
            similar = ref.find_similar(k=10, vector_database=vdb)
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        return ReferenceRecord.from_record(
            record=record,
            session_id=self.id,
            name=name,
            ctx=self._ctx,
            foundational_model=self,
        )

    def wait_for_training(
        self,
        max_wait_time: int = 3600,
        poll_interval: int = 10,
        show_progress: bool = True
    ) -> 'FoundationalModel':
        """
        Wait for foundational model training to complete with tqdm progress bar.

        Args:
            max_wait_time: Maximum wait time in seconds
            poll_interval: Polling interval in seconds
            show_progress: Show progress bar (tqdm if available, fallback to simple)

        Returns:
            Self (updated with final status)

        Raises:
            TimeoutError: If training doesn't complete in time
            RuntimeError: If training fails
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        if not show_progress:
            return self._wait_simple(max_wait_time, poll_interval, show_progress=False)

        # Try tqdm first, then simple fallback
        try:
            from tqdm import tqdm
            return self._wait_with_tqdm(max_wait_time, poll_interval)
        except ImportError:
            return self._wait_simple(max_wait_time, poll_interval, show_progress=True)

    def _wait_with_tqdm(self, max_wait_time: int, poll_interval: int) -> 'FoundationalModel':
        """Wait for training with tqdm progress bar."""
        from tqdm import tqdm

        start_time = time.time()
        pbar = None
        last_total = None

        consecutive_errors = 0
        max_consecutive_errors = 30  # ~5 min at 10s poll interval

        try:
            while time.time() - start_time < max_wait_time:
                # Get session status — tolerate transient failures
                try:
                    response_data = self._ctx.get_json(f"/compute/session/{self.id}")
                    consecutive_errors = 0
                except Exception as e:
                    consecutive_errors += 1
                    elapsed = int(time.time() - start_time)
                    if pbar:
                        pbar.set_postfix_str(f"poll error {consecutive_errors}/{max_consecutive_errors}")
                    else:
                        print(f"[{elapsed}s] Poll error ({consecutive_errors}/{max_consecutive_errors}): {e}")
                    if consecutive_errors >= max_consecutive_errors:
                        if pbar:
                            pbar.close()
                        raise RuntimeError(
                            f"Training: lost contact with server after "
                            f"{consecutive_errors} consecutive poll failures over "
                            f"{elapsed}s. Last error: {e}"
                        )
                    time.sleep(poll_interval)
                    continue

                session_data = response_data.get('session', response_data)
                status = session_data.get('status', 'unknown')
                jobs = response_data.get('jobs', {})

                # Look for ES training job
                es_job = None
                for job_id, job in jobs.items():
                    if job.get('job_type') in ('train_embedding_space', 'train_es', 'training'):
                        es_job = job
                        break

                # Get progress info
                current_epoch = None
                total_epochs = None
                if es_job:
                    current_epoch = es_job.get('current_epoch') or es_job.get('epoch')
                    total_epochs = es_job.get('total_epochs') or es_job.get('epochs')
                    job_status = es_job.get('status', status)
                else:
                    job_status = status

                # Initialize or update progress bar
                if current_epoch and total_epochs:
                    if pbar is None or last_total != total_epochs:
                        if pbar is not None:
                            pbar.close()
                        pbar = tqdm(
                            total=total_epochs,
                            desc=f"Training {self.name or self.id[:12]}",
                            unit="epoch",
                            ncols=100,
                            bar_format='{desc}: {percentage:3.0f}%|{bar}| {n_fmt}/{total_fmt} epochs [{elapsed}<{remaining}]'
                        )
                        last_total = total_epochs

                    # Update progress
                    if pbar.n < current_epoch:
                        pbar.update(current_epoch - pbar.n)
                        pbar.set_postfix_str(job_status)

                # Check completion
                if job_status == 'done' or status == 'done':
                    if pbar:
                        pbar.n = pbar.total
                        pbar.refresh()
                        pbar.close()

                    self.status = 'done'
                    self._update_from_session(response_data)
                    print(f"\n✅ Training complete!")
                    if self.dimensions:
                        print(f"   Dimensions: {self.dimensions}")
                    if self.epochs:
                        print(f"   Epochs: {self.epochs}")
                    return self

                elif job_status == 'failed' or status == 'failed':
                    if pbar:
                        pbar.close()
                    error_msg = 'Unknown error'
                    if es_job:
                        error_msg = (
                            es_job.get('error')
                            or es_job.get('error_message')
                            or es_job.get('failure_reason')
                            or error_msg
                        )
                    self.status = 'error'
                    raise RuntimeError(f"Training failed: {error_msg}")

                time.sleep(poll_interval)

            if pbar:
                pbar.close()
            raise TimeoutError(f"Training did not complete within {max_wait_time}s")

        except KeyboardInterrupt:
            if pbar:
                pbar.close()
            print("\n⚠️  Training interrupted by user")
            raise

    def _wait_simple(self, max_wait_time: int, poll_interval: int, show_progress: bool) -> 'FoundationalModel':
        """Simple progress display without external dependencies."""
        start_time = time.time()
        last_epoch = None
        last_status = None
        consecutive_errors = 0
        max_consecutive_errors = 30  # ~5 min at 10s poll interval

        while time.time() - start_time < max_wait_time:
            # Get session status — tolerate transient failures
            try:
                response_data = self._ctx.get_json(f"/compute/session/{self.id}")
                consecutive_errors = 0
            except Exception as e:
                consecutive_errors += 1
                elapsed = int(time.time() - start_time)
                if show_progress:
                    print(f"[{elapsed}s] Poll error ({consecutive_errors}/{max_consecutive_errors}): {e}")
                if consecutive_errors >= max_consecutive_errors:
                    raise RuntimeError(
                        f"Training: lost contact with server after "
                        f"{consecutive_errors} consecutive poll failures over "
                        f"{elapsed}s. Last error: {e}"
                    )
                time.sleep(poll_interval)
                continue

            session_data = response_data.get('session', response_data)
            status = session_data.get('status', 'unknown')
            jobs = response_data.get('jobs', {})

            # Look for ES training job
            es_job = None
            for job_id, job in jobs.items():
                if job.get('job_type') in ('train_embedding_space', 'train_es', 'training'):
                    es_job = job
                    break

            # Get progress info
            current_epoch = None
            total_epochs = None
            if es_job:
                current_epoch = es_job.get('current_epoch') or es_job.get('epoch')
                total_epochs = es_job.get('total_epochs') or es_job.get('epochs')
                job_status = es_job.get('status', status)
            else:
                job_status = status

            # Progress update
            if show_progress:
                elapsed = int(time.time() - start_time)
                if current_epoch != last_epoch or job_status != last_status:
                    if current_epoch and total_epochs:
                        pct = int(current_epoch / total_epochs * 100)
                        bar = "█" * (pct // 5) + "░" * (20 - pct // 5)
                        print(f"[{elapsed}s] [{bar}] {current_epoch}/{total_epochs} epochs ({pct}%) - {job_status}")
                    else:
                        print(f"[{elapsed}s] Training: {job_status}")
                    last_epoch = current_epoch
                    last_status = job_status

            # Check completion
            if job_status == 'done' or status == 'done':
                self.status = 'done'
                self._update_from_session(response_data)
                if show_progress:
                    print(f"✅ Training complete!")
                    if self.dimensions:
                        print(f"   Dimensions: {self.dimensions}")
                    if self.epochs:
                        print(f"   Epochs: {self.epochs}")
                return self

            elif job_status == 'failed' or status == 'failed':
                error_msg = 'Unknown error'
                if es_job:
                    error_msg = es_job.get('error', error_msg)
                self.status = 'error'
                raise RuntimeError(f"Training failed: {error_msg}")

            time.sleep(poll_interval)

        raise TimeoutError(f"Training did not complete within {max_wait_time}s")

    def encode(
        self,
        records: Union[Dict[str, Any], List[Dict[str, Any]], 'pd.DataFrame'],
        short: bool = False,
    ) -> Union[List[Dict[str, Any]], List[List[float]]]:
        """
        Encode records to embedding vectors.

        Returns the full server response for each record, including both 3D
        (short) and full-length embeddings. If short=True, returns just the
        3D embedding vectors directly.

        Args:
            records: Single record, list of records, or DataFrame
            short: If True, return only the 3D embedding vectors (for visualization).
                   If False (default), return full results with both embeddings.

        Returns:
            If short=False: List of dicts, each containing:
                - "embedding": 3D embedding vector (for visualization)
                - "embedding_long": Full-length embedding vector
                - "query_record": The input record echoed back
            If short=True: List of 3D embedding vectors (List[List[float]])

        Example:
            # Full results with both embeddings
            results = fm.encode([
                {"age": 35, "income": 50000},
                {"age": 42, "income": 75000}
            ])
            short_vectors = [r["embedding"] for r in results]       # 3D
            full_vectors = [r["embedding_long"] for r in results]   # full

            # Just 3D vectors for visualization
            vectors_3d = fm.encode(records, short=True)
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        # Normalize input
        if isinstance(records, dict):
            records = [records]
        elif hasattr(records, 'to_dict'):
            records = records.to_dict('records')

        # Clean records
        cleaned = [self._clean_record(r) for r in records]

        response = self._ctx.post_json(
            f"/session/{self.id}/encode_records",
            data={"records": cleaned}
        )

        results = response.get('results', [])

        if short:
            return [r["embedding"] for r in results]

        return results

    def extend(
        self,
        new_data_file: Optional[str] = None,
        new_data_df: Optional['pd.DataFrame'] = None,
        epochs: Optional[int] = None,
        **kwargs
    ) -> 'FoundationalModel':
        """
        Extend this foundational model with new data.

        Args:
            new_data_file: Path to new data file
            new_data_df: DataFrame with new data
            epochs: Additional training epochs
            **kwargs: Additional parameters

        Returns:
            New FoundationalModel instance (training started)
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        # This creates a new session with extended data
        # Implementation depends on server API
        raise NotImplementedError("extend() not yet implemented - use create_foundational_model with new data")

    def get_projections(self) -> Dict[str, Any]:
        """Get 2D/3D projections for visualization."""
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        return self._ctx.get_json(f"/session/{self.id}/projections")

    def get_sphere_preview(self, save_path: str = None) -> bytes:
        """
        Get the 2D sphere projection preview image (PNG).

        Args:
            save_path: Optional path to save the PNG file. If provided, the image
                      will be written to this path.

        Returns:
            Raw PNG image bytes.
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        png_bytes = self._ctx.get_bytes(f"/session/{self.id}/preview")

        if save_path:
            with open(save_path, 'wb') as f:
                f.write(png_bytes)

        return png_bytes

    def get_training_metrics(self) -> Dict[str, Any]:
        """Get training metrics and history."""
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        return self._ctx.get_json(f"/session/{self.id}/training_metrics")

    def get_model_card(self) -> Dict[str, Any]:
        """Get the model card for this foundational model."""
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        return self._ctx.get_json(f"/session/{self.id}/model_card")

    def list_predictors(self) -> List[Predictor]:
        """List all predictors for this foundational model."""
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        # Get session info which includes jobs
        response = self._ctx.get_json(f"/compute/session/{self.id}")
        jobs = response.get('jobs', {})

        predictors = []
        for job_id, job in jobs.items():
            if job.get('job_type') == 'train_single_predictor':
                target_column = job.get('target_column', '')
                pred_id = job.get('predictor_id', f"predictor-{target_column}")

                pred = Predictor(
                    id=pred_id,
                    session_id=self.id,
                    target_column=target_column,
                    target_type=job.get('target_column_type', 'set'),
                    name=job.get('name'),
                    status=job.get('status'),
                    accuracy=job.get('accuracy'),
                    _ctx=self._ctx,
                    _foundational_model=self,
                )
                predictors.append(pred)

        return predictors

    def _update_from_session(self, response_data: Dict[str, Any]) -> None:
        """Update fields from session API response.

        The response from GET /session/{id} has structure:
            {"session": {...}, "jobs": {...}, ...}
        """
        # Handle both nested and flat response formats
        session = response_data.get('session', response_data)
        jobs = response_data.get('jobs', {})
        self.jobs = jobs

        # Core session fields
        if session.get('name') and not self.name:
            self.name = session['name']
        if session.get('status'):
            self.status = session['status']
        if session.get('session_type'):
            self.session_type = session['session_type']
        if session.get('compute_cluster'):
            self.compute_cluster = session['compute_cluster']
        if session.get('created_at') and not self.created_at:
            self.created_at = _parse_datetime(session['created_at'])
        if session.get('finished_at'):
            self.updated_at = _parse_datetime(session['finished_at'])
        elif session.get('started_at'):
            self.updated_at = _parse_datetime(session['started_at'])

        # Model info from session
        model_info = session.get('model_info', {})
        training_stats = session.get('training_stats', {})

        self.dimensions = (
            model_info.get('d_model') or
            model_info.get('embedding_dim') or
            session.get('d_model')
        )
        self.epochs = (
            training_stats.get('final_epoch') or
            training_stats.get('epochs_trained') or
            session.get('epochs')
        )
        self.final_loss = (
            training_stats.get('final_loss') or
            session.get('final_loss')
        )

        # Extract error_message and training_progress from jobs
        for job_id, job in jobs.items():
            job_type = job.get('job_type', '')
            job_status = job.get('status', '')

            # Training progress from ES training job
            if job_type in ('train_embedding_space', 'train_es', 'training'):
                current_epoch = job.get('current_epoch') or job.get('epoch')
                total_epochs = job.get('total_epochs') or job.get('epochs')
                if current_epoch or total_epochs:
                    self.training_progress = {
                        'current_epoch': current_epoch,
                        'total_epochs': total_epochs,
                        'job_status': job_status,
                    }

            # Error message from any failed job
            if job_status in ('failed', 'error'):
                err = job.get('error') or job.get('error_message')
                if err:
                    self.error_message = err

    def _clean_record(self, record: Dict[str, Any]) -> Dict[str, Any]:
        """Clean a record for API submission."""
        import math

        cleaned = {}
        for key, value in record.items():
            if isinstance(value, float):
                if math.isnan(value) or math.isinf(value):
                    value = None
            if hasattr(value, 'item'):
                value = value.item()
            cleaned[key] = value
        return cleaned

    def get_columns(self) -> List[str]:
        """
        Get the column names in this foundational model's embedding space.

        Returns:
            List of column name strings

        Example:
            columns = fm.get_columns()
            print(columns)  # ['age', 'income', 'city', ...]
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        response = self._ctx.get_json(f"/compute/session/{self.id}/columns")
        return response.get('column_names', response.get('columns', []))

    @property
    def columns(self) -> List[str]:
        """Column names in this foundational model's embedding space."""
        return self.get_columns()

    @property
    def schema_metadata(self) -> Dict[str, Any]:
        """Get schema metadata including column names and types.

        Returns:
            Dict with 'column_names', 'column_types', and 'num_columns'
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")
        return self._ctx.get_json(f"/compute/session/{self.id}/columns")

    def clone(
        self,
        target_compute_cluster: Optional[str] = None,
        new_name: Optional[str] = None,
        source_compute_cluster: Optional[str] = None,
    ) -> 'FoundationalModel':
        """
        Clone this embedding space, optionally to a different compute node.

        Args:
            target_compute_cluster: Target compute cluster (None = same node)
            new_name: Name for the cloned session
            source_compute_cluster: Source compute cluster (if routing needed)

        Returns:
            New FoundationalModel instance for the cloned embedding space

        Example:
            cloned = fm.clone(
                target_compute_cluster="churro",
                new_name="my-model-clone"
            )
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        data = {
            "to_compute": target_compute_cluster,
            "new_session_name": new_name,
        }

        response = self._ctx.post_json(
            f"/compute/session/{self.id}/clone_embedding_space",
            data=data
        )

        new_session_id = response.get('new_session_id', '')
        return FoundationalModel(
            id=new_session_id,
            name=new_name,
            status="done",
            created_at=datetime.now(),
            _ctx=self._ctx,
        )

    def refresh(self) -> Dict[str, Any]:
        """
        Refresh this foundational model's state from the server.

        Returns the full server-side info for this model, and updates
        local attributes (status, epochs, dimensions, etc.).

        Returns:
            Full model info dictionary from the server

        Example:
            info = fm.refresh()
            print(fm.status)   # Updated from server
            print(fm.epochs)   # Updated from server
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        data = self._ctx.get_json(f"/compute/session/{self.id}")
        self._update_from_session(data)
        return data

    def is_ready(self) -> bool:
        """
        Check if this foundational model has finished training and is ready for use.

        Returns:
            True if training is complete, False otherwise

        Example:
            if fm.is_ready():
                predictor = fm.create_binary_classifier(target_column="target")
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        data = self._ctx.get_json(f"/compute/session/{self.id}")
        self._update_from_session(data)
        return self.status == 'done'

    def publish(
        self,
        name: Optional[str] = None,
        max_wait_time: int = 600,
        poll_interval: int = 5,
    ) -> Dict[str, Any]:
        """
        Publish this foundational model to the production directory and cloud storage.

        Published models are protected from garbage collection and available
        across all compute nodes via the shared backplane. The model is also
        backed up to cloud storage (DO Spaces).

        The model is published under your organization (derived from your API key).
        This dispatches a background job and polls until complete.

        Args:
            name: Name for the published model (defaults to self.name)
            max_wait_time: Max seconds to wait for publish to complete (default 600)
            poll_interval: Seconds between status polls (default 5)

        Returns:
            dict with published_path, cloud_upload status, etc.

        Example:
            fm = featrix.create_foundational_model(name="my_model", data_file="data.csv")
            fm.wait_for_training()
            fm.publish(name="my_model_v1")
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        publish_name = name or self.name
        if not publish_name:
            raise ValueError("name is required (either pass it or set it on the model)")

        data = {
            "name": publish_name,
        }
        response = self._ctx.post_json(f"/compute/session/{self.id}/publish", data=data)

        # If already published, return immediately
        if response.get("status") == "already_published":
            return response

        # If the server returned a job_id, poll for completion
        job_id = response.get("job_id")
        if not job_id:
            # Old-style synchronous response (backwards compat)
            return response

        logger.info(f"Publishing model as '{publish_name}'... (job_id: {job_id})")

        start_time = time.time()
        last_message = None

        while time.time() - start_time < max_wait_time:
            time.sleep(poll_interval)

            status_response = self._ctx.get_json(
                f"/compute/session/{self.id}/publish_job/{job_id}"
            )
            status = status_response.get("status")
            message = status_response.get("message", "")

            if message and message != last_message:
                logger.info(f"  {message}")
                last_message = message

            if status == "completed":
                logger.info(f"Published successfully: {status_response.get('published_path')}")
                return status_response

            elif status == "failed":
                error = status_response.get("error", "Unknown error")
                raise RuntimeError(f"Publish failed: {error}")

        raise TimeoutError(
            f"Publish did not complete within {max_wait_time}s (job_id: {job_id}). "
            f"The job may still be running — check status at /session/{self.id}/publish_job/{job_id}"
        )

    def deprecate(
        self,
        warning_message: str,
        expiration_date: str,
    ) -> Dict[str, Any]:
        """
        Deprecate this published model with a warning and expiration date.

        The model remains available until the expiration date. Prediction
        responses will include a model_expiration field warning consumers.

        Args:
            warning_message: Warning message to display
            expiration_date: ISO format date string (e.g., "2026-06-01T00:00:00Z")

        Returns:
            dict with deprecation status

        Example:
            from datetime import datetime, timedelta
            expiration = (datetime.now() + timedelta(days=90)).isoformat() + "Z"
            fm.deprecate(
                warning_message="Replaced by v2. Migrate by expiration.",
                expiration_date=expiration
            )
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        data = {
            "warning_message": warning_message,
            "expiration_date": expiration_date,
        }
        return self._ctx.post_json(f"/compute/session/{self.id}/deprecate", data=data)

    def unpublish(self) -> Dict[str, Any]:
        """
        Unpublish this model, moving it back from the published directory.

        WARNING: After unpublishing, the model is subject to garbage
        collection and may be deleted when disk space is low.

        Returns:
            dict with unpublish status

        Example:
            fm.unpublish()
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        return self._ctx.post_json(f"/compute/session/{self.id}/unpublish", data={})

    def delete(self) -> Dict[str, Any]:
        """
        Mark this model for deletion.

        The session will be picked up by the garbage collection process
        and deleted from the compute node.

        Returns:
            dict with deletion confirmation

        Example:
            fm.delete()
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        return self._ctx.post_json(f"/compute/session/{self.id}/mark_for_deletion", data={})

    def publish_checkpoint(
        self,
        name: str,
        org_id: Optional[str] = None,
        checkpoint_epoch: Optional[int] = None,
        session_name_prefix: Optional[str] = None,
        publish: bool = True,
    ) -> 'FoundationalModel':
        """
        Publish a checkpoint from this model's training as a new foundation model.

        Creates a NEW FoundationalModel from a training checkpoint with full
        provenance tracking. Useful for snapshotting good intermediate models
        while training continues.

        Args:
            name: Name for the new foundation model (required)
            org_id: Organization ID (required if publish=True)
            checkpoint_epoch: Which epoch checkpoint to use (None = best/latest)
            session_name_prefix: Optional prefix for the new session ID
            publish: Move to published directory (default: True)

        Returns:
            New FoundationalModel instance for the published checkpoint

        Example:
            # Snapshot epoch 50 while training continues
            checkpoint_fm = fm.publish_checkpoint(
                name="My Model v0.5",
                org_id="my_org",
                checkpoint_epoch=50
            )
            # Use immediately
            predictor = checkpoint_fm.create_binary_classifier(target_column="target")
        """
        if not self._ctx:
            raise ValueError("FoundationalModel not connected to client")

        if publish and not org_id:
            raise ValueError("org_id is required when publish=True")

        data = {
            "name": name,
            "publish": publish,
        }
        if checkpoint_epoch is not None:
            data["checkpoint_epoch"] = checkpoint_epoch
        if session_name_prefix:
            data["session_name_prefix"] = session_name_prefix
        if org_id:
            data["org_id"] = org_id

        response = self._ctx.post_json(
            f"/compute/session/{self.id}/publish_partial_foundation",
            data=data
        )

        new_fm = FoundationalModel(
            id=response.get("foundation_session_id", ""),
            name=name,
            status="done",
            epochs=response.get("checkpoint_epoch"),
            created_at=datetime.now(),
            _ctx=self._ctx,
        )

        return new_fm

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            'id': self.id,
            'name': self.name,
            'status': self.status,
            'dimensions': self.dimensions,
            'epochs': self.epochs,
            'final_loss': self.final_loss,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'session_type': self.session_type,
            'compute_cluster': self.compute_cluster,
            'error_message': self.error_message,
            'training_progress': self.training_progress,
        }

    def __repr__(self) -> str:
        status_str = f", status='{self.status}'" if self.status else ""
        dims_str = f", dims={self.dimensions}" if self.dimensions else ""
        return f"FoundationalModel(id='{self.id}'{status_str}{dims_str})"
