"""
Exceptions for FeatrixSphere API client.
"""


class FeatrixAuthenticationError(Exception):
    """Raised when the server returns 401 Unauthorized.

    This means the API key is missing, invalid, or expired.
    Set your API key in ~/.featrix or the FEATRIX_API_KEY environment variable.
    """

    def __init__(self, message: str = None, status_code: int = 401):
        if message is None:
            message = (
                "Authentication required. "
                "Set your API key in ~/.featrix (as api_key=sk_live_...) "
                "or the FEATRIX_API_KEY environment variable."
            )
        self.status_code = status_code
        super().__init__(message)
