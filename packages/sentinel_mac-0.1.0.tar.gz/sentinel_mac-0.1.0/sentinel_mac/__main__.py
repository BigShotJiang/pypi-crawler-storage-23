"""Allow running as: python -m sentinel_mac"""
from sentinel_mac.core import main

if __name__ == "__main__":
    main()
