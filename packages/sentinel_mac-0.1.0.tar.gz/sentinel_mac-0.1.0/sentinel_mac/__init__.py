"""Sentinel — AI Session Guardian for macOS."""

__version__ = "0.1.0"
