from .client import CatWatch

__all__ = ["CatWatch"]
__version__ = "0.2.0"
