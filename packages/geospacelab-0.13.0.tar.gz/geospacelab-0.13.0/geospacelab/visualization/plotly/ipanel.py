

class Panel(object):
    def __init__(self):
        pass

    def add_line(self):
        pass

    def add_image(self):
        pass

    def add_pcolor(self):
        pass

    def add_scatter(self):
        pass

    
