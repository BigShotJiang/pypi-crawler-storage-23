__version__ = "0.1.0"
PORT = 1842
from lorai.client import LorAI
__all__ = ["LorAI", "PORT"]
