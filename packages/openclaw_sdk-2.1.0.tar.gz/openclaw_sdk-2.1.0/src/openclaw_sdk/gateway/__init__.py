# Gateway implementations — imported lazily to avoid import errors
# when optional deps (websockets, httpx) are not installed.
