"""OpenClaw node / presence manager."""

from openclaw_sdk.nodes.manager import NodeManager

__all__ = ["NodeManager"]
