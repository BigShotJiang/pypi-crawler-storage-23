"""Tool configuration — re-exports from tools.policy.

The original ToolConfig / DatabaseToolConfig / etc. classes were removed
because they did not map to OpenClaw's real tool configuration model.
Use :class:`ToolPolicy` and its presets instead.
"""
