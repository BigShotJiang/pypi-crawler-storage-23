"""OpenClaw text-to-speech manager (TTS gateway methods)."""

from openclaw_sdk.tts.manager import TTSManager

__all__ = ["TTSManager"]
