# Tests for shots package
