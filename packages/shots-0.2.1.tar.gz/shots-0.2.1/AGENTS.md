# Agents

## Git

- Always stage and commit in a single command: `git add file1 file2 && git commit -m "message"`
- Run git commands from the working directory directly — no `cd` or `-C` flags
