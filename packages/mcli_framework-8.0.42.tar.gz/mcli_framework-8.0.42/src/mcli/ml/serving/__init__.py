"""Model serving module for MCLI ML system."""
