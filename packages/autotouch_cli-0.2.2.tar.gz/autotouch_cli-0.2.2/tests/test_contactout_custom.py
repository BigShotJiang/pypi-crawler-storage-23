#!/usr/bin/env python3
"""
ContactOut API v2 Custom Test - Your LinkedIn URLs
Test script for specific LinkedIn profiles with phone number discovery
"""

import os
import sys
import requests
import json
import time
from dotenv import load_dotenv

# Load environment variables
load_dotenv('/Users/nicnicolo/Projects/smart_table/.env')

class ContactOutCustomTester:
    def __init__(self):
        self.api_token = os.getenv('CONTACTOUT_API_KEY')
        if not self.api_token:
            print("❌ Error: CONTACTOUT_API_KEY not found in environment variables")
            sys.exit(1)

        self.base_url = "https://api.contactout.com/v2"
        self.headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "token": self.api_token
        }
        print(f"✅ API token loaded: {self.api_token[:8]}...")

    def submit_bulk_job(self, linkedin_profiles):
        """Submit a bulk job for LinkedIn profile enrichment"""
        print(f"\n🚀 Submitting bulk job for {len(linkedin_profiles)} profiles")
        print("-" * 60)

        endpoint = f"{self.base_url}/people/linkedin/batch"

        payload = {
            "profiles": linkedin_profiles,
            "include_phone": True
        }

        print(f"📤 Submitting profiles:")
        for i, profile in enumerate(linkedin_profiles, 1):
            print(f"  {i}. {profile}")

        try:
            response = requests.post(endpoint, headers=self.headers, json=payload)
            print(f"\n📊 Status Code: {response.status_code}")

            if response.status_code == 200:
                data = response.json()
                job_id = data.get('job_id')
                status = data.get('status')

                print(f"✅ Job submitted successfully!")
                print(f"🆔 Job ID: {job_id}")
                print(f"📋 Status: {status}")

                return job_id
            else:
                print(f"❌ Request failed: {response.text}")
                try:
                    error_data = response.json()
                    print(f"❌ Error details: {json.dumps(error_data, indent=2)}")
                except:
                    pass
                return None

        except Exception as e:
            print(f"❌ Exception: {str(e)}")
            return None

    def check_job_status(self, job_id, max_wait_time=180, check_interval=10):
        """Check the status of a bulk job and wait for completion"""
        print(f"\n⏳ Monitoring job status: {job_id}")
        print("-" * 60)

        endpoint = f"{self.base_url}/people/linkedin/batch/{job_id}"
        start_time = time.time()
        checks = 0

        while time.time() - start_time < max_wait_time:
            checks += 1
            try:
                response = requests.get(endpoint, headers=self.headers)
                elapsed = int(time.time() - start_time)

                if response.status_code == 200:
                    data = response.json()
                    job_data = data.get('data', {})
                    job_status = job_data.get('status', 'UNKNOWN')

                    print(f"📋 Check #{checks} ({elapsed}s): Status = {job_status}")

                    if job_status == 'SENT':
                        print("✅ Job completed successfully!")
                        return data
                    elif job_status in ['FAILED', 'ERROR']:
                        print(f"❌ Job failed with status: {job_status}")
                        return data
                    elif job_status == 'QUEUED':
                        print(f"⏳ Still queued, checking again in {check_interval}s...")
                    else:
                        print(f"🔄 Processing ({job_status}), checking again in {check_interval}s...")

                    if elapsed < max_wait_time:
                        time.sleep(check_interval)

                else:
                    print(f"❌ Status check failed (HTTP {response.status_code}): {response.text}")
                    return None

            except Exception as e:
                print(f"❌ Exception checking status: {str(e)}")
                return None

        print(f"⏰ Timeout after {max_wait_time}s")
        return None

    def analyze_results(self, job_data):
        """Parse and display detailed results"""
        if not job_data or 'data' not in job_data:
            print("❌ No data to analyze")
            return

        results = job_data.get('data', {}).get('result', {})

        print(f"\n📋 DETAILED RESULTS")
        print("=" * 80)

        phone_found_count = 0
        email_found_count = 0

        for i, (linkedin_url, profile_data) in enumerate(results.items(), 1):
            print(f"\n👤 Profile #{i}: {linkedin_url}")
            print("-" * 50)

            # Phone numbers
            phones = profile_data.get('phones', [])
            if phones:
                phone_found_count += 1
                print(f"📞 PHONE NUMBERS FOUND ({len(phones)}):")
                for phone in phones:
                    print(f"  ✅ {phone}")
            else:
                print("📞 Phone Numbers: ❌ None found")

            # All emails
            emails = profile_data.get('emails', [])
            work_emails = profile_data.get('work_emails', [])
            personal_emails = profile_data.get('personal_emails', [])

            if emails or work_emails or personal_emails:
                email_found_count += 1

            if emails:
                print(f"📧 All Emails ({len(emails)}):")
                for email in emails:
                    print(f"  ✅ {email}")

            if work_emails:
                print(f"💼 Work Emails ({len(work_emails)}):")
                for email in work_emails:
                    print(f"  ✅ {email}")

            if personal_emails:
                print(f"👤 Personal Emails ({len(personal_emails)}):")
                for email in personal_emails:
                    print(f"  ✅ {email}")

            if not emails and not work_emails and not personal_emails:
                print("📧 Emails: ❌ None found")

        # Summary
        total_profiles = len(results)
        print(f"\n🎯 SUMMARY")
        print("=" * 50)
        print(f"📊 Profiles Processed: {total_profiles}")
        print(f"📞 Profiles with Phone Numbers: {phone_found_count}/{total_profiles} ({(phone_found_count/total_profiles)*100:.1f}%)")
        print(f"📧 Profiles with Emails: {email_found_count}/{total_profiles} ({(email_found_count/total_profiles)*100:.1f}%)")

        if phone_found_count > 0:
            print(f"\n🎉 SUCCESS! Found phone numbers for {phone_found_count} profile(s)")
        else:
            print(f"\n⚠️  No phone numbers found in this batch")

def main():
    """Run the custom test with provided LinkedIn URLs"""
    # Your specific LinkedIn URLs
    custom_profiles = [
        "https://www.linkedin.com/in/franksondors/",
        "https://www.linkedin.com/in/nicholas-nicolo/",
        "https://www.linkedin.com/in/max-mitcham/",
        "https://www.linkedin.com/in/michaelsaruggia/"
    ]

    print("🎯 ContactOut v2 Custom Test")
    print("=" * 60)
    print("Testing phone number discovery for your specific LinkedIn profiles...")
    print()

    tester = ContactOutCustomTester()

    # Step 1: Submit the job
    job_id = tester.submit_bulk_job(custom_profiles)

    if not job_id:
        print("❌ Failed to submit job - check API key and network")
        return False

    # Step 2: Wait for completion
    job_data = tester.check_job_status(job_id, max_wait_time=180, check_interval=15)

    if not job_data:
        print("❌ Failed to get job results - check job status manually")
        return False

    # Step 3: Analyze results
    tester.analyze_results(job_data)

    print("\n✅ Custom test completed!")
    return True

if __name__ == "__main__":
    main()