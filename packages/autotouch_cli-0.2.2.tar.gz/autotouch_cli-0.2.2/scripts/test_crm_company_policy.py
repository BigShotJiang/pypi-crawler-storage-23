#!/usr/bin/env python3
"""
Quick test script for CRM Company Policy

Usage:
    python scripts/test_crm_company_policy.py --org-id YOUR_ORG_ID --provider hubspot

This script will:
1. Check current sync profile
2. Test different company policies
3. Create test leads
4. Verify sync behavior
"""

import asyncio
import argparse
import sys
from typing import Dict, Any, Optional
from datetime import datetime

# Add project root to path
sys.path.insert(0, '.')

from motor.motor_asyncio import AsyncIOMotorClient
from bson import ObjectId


async def get_db_connection(mongo_uri: str = "mongodb://localhost:27017", db_name: str = "autotouch"):
    """Get MongoDB connection"""
    client = AsyncIOMotorClient(mongo_uri)
    return client[db_name]


async def get_profile(db, organization_id: str, provider: str) -> Optional[Dict[str, Any]]:
    """Get sync profile"""
    profile = await db['crm_sync_profiles'].find_one({
        "organization_id": organization_id,
        "provider": provider
    })
    return profile


async def update_profile(
    db,
    organization_id: str,
    provider: str,
    company_policy: str,
    on_company_missing: Optional[str] = None
) -> Dict[str, Any]:
    """Update sync profile"""
    update_doc = {
        "lead_sync.crm_company_match_policy": company_policy
    }
    if on_company_missing:
        update_doc["lead_sync.on_company_missing"] = on_company_missing
    
    result = await db['crm_sync_profiles'].update_one(
        {"organization_id": organization_id, "provider": provider},
        {"$set": update_doc},
        upsert=True
    )
    return {"matched": result.matched_count, "modified": result.modified_count}


async def create_test_lead(
    db,
    organization_id: str,
    email: str,
    company_domain: str,
    company_name: Optional[str] = None
) -> str:
    """Create a test lead"""
    lead_doc = {
        "organization_id": organization_id,
        "email_addresses": [{"address": email, "primary": True}],
        "first_name": "Test",
        "last_name": f"User_{datetime.utcnow().timestamp()}",
        "company_domain": company_domain,
        "created_at": datetime.utcnow(),
        "updated_at": datetime.utcnow()
    }
    
    if company_name:
        lead_doc["company"] = {
            "name": company_name,
            "domain": company_domain
        }
    
    result = await db['leads'].insert_one(lead_doc)
    return str(result.inserted_id)


async def check_sync_status(db, lead_id: str, provider: str) -> Dict[str, Any]:
    """Check if lead was synced"""
    lead = await db['leads'].find_one({"_id": ObjectId(lead_id)})
    if not lead:
        return {"error": "Lead not found"}
    
    if provider == "hubspot":
        crm_id = lead.get("hubspot_contact_id")
    elif provider == "attio":
        crm_id = lead.get("attio_person_id")
    else:
        return {"error": "Unknown provider"}
    
    return {
        "synced": crm_id is not None,
        "crm_id": crm_id,
        "company_domain": lead.get("company_domain"),
        "email": lead.get("email_addresses", [{}])[0].get("address") if lead.get("email_addresses") else None
    }


async def test_company_policy(
    db,
    organization_id: str,
    provider: str,
    policy: str,
    on_missing: Optional[str] = None
):
    """Test a specific company policy"""
    print(f"\n{'='*60}")
    print(f"Testing Policy: {policy}")
    if on_missing:
        print(f"On Company Missing: {on_missing}")
    print(f"{'='*60}")
    
    # Update profile
    print(f"\n1. Updating profile...")
    result = await update_profile(db, organization_id, provider, policy, on_missing)
    print(f"   ✅ Profile updated: {result}")
    
    # Verify profile
    profile = await get_profile(db, organization_id, provider)
    if profile:
        lead_sync = profile.get("lead_sync", {})
        print(f"   Current policy: {lead_sync.get('crm_company_match_policy')}")
        print(f"   On missing: {lead_sync.get('on_company_missing')}")
    
    # Create test lead with non-existing company
    print(f"\n2. Creating test lead with non-existing company...")
    test_email = f"test_{datetime.utcnow().timestamp()}@testcompany.com"
    lead_id = await create_test_lead(
        db,
        organization_id,
        test_email,
        "nonexistent-test-company.com",
        "Non-Existent Test Company"
    )
    print(f"   ✅ Lead created: {lead_id}")
    print(f"   Email: {test_email}")
    print(f"   Company: nonexistent-test-company.com")
    
    # Wait a bit for sync (if real-time)
    print(f"\n3. Waiting 3 seconds for sync to process...")
    await asyncio.sleep(3)
    
    # Check sync status
    print(f"\n4. Checking sync status...")
    status = await check_sync_status(db, lead_id, provider)
    print(f"   Synced: {status.get('synced')}")
    print(f"   CRM ID: {status.get('crm_id')}")
    
    if status.get('synced'):
        print(f"   ✅ Lead was synced to {provider}")
    else:
        print(f"   ⚠️  Lead was NOT synced (may be expected based on policy)")
    
    return {
        "policy": policy,
        "on_missing": on_missing,
        "lead_id": lead_id,
        "synced": status.get('synced'),
        "crm_id": status.get('crm_id')
    }


async def main():
    parser = argparse.ArgumentParser(description="Test CRM Company Policy")
    parser.add_argument("--org-id", required=True, help="Organization ID")
    parser.add_argument("--provider", choices=["hubspot", "attio"], default="hubspot", help="CRM provider")
    parser.add_argument("--mongo-uri", default="mongodb://localhost:27017", help="MongoDB URI")
    parser.add_argument("--db-name", default="autotouch", help="Database name")
    parser.add_argument("--test-all", action="store_true", help="Test all policies")
    parser.add_argument("--policy", choices=["require_existing_company", "create_company_if_missing", "no_company_association"], help="Test specific policy")
    parser.add_argument("--on-missing", choices=["skip_lead", "push_unassociated"], help="On company missing behavior")
    
    args = parser.parse_args()
    
    print("🧪 CRM Company Policy Test Script")
    print("="*60)
    print(f"Organization ID: {args.org_id}")
    print(f"Provider: {args.provider}")
    print(f"MongoDB: {args.mongo_uri}/{args.db_name}")
    print("="*60)
    
    db = await get_db_connection(args.mongo_uri, args.db_name)
    
    # Check current profile
    print("\n📋 Current Profile:")
    profile = await get_profile(db, args.org_id, args.provider)
    if profile:
        lead_sync = profile.get("lead_sync", {})
        print(f"   Policy: {lead_sync.get('crm_company_match_policy', 'default')}")
        print(f"   On Missing: {lead_sync.get('on_company_missing', 'default')}")
    else:
        print("   ⚠️  No profile found (will use defaults)")
    
    results = []
    
    if args.test_all:
        # Test all policies
        print("\n🧪 Testing All Policies...")
        
        # Test 1: require_existing_company + skip_lead
        result1 = await test_company_policy(
            db, args.org_id, args.provider,
            "require_existing_company", "skip_lead"
        )
        results.append(result1)
        
        # Test 2: require_existing_company + push_unassociated
        result2 = await test_company_policy(
            db, args.org_id, args.provider,
            "require_existing_company", "push_unassociated"
        )
        results.append(result2)
        
        # Test 3: no_company_association
        result3 = await test_company_policy(
            db, args.org_id, args.provider,
            "no_company_association"
        )
        results.append(result3)
        
        # Test 4: create_company_if_missing (default)
        result4 = await test_company_policy(
            db, args.org_id, args.provider,
            "create_company_if_missing"
        )
        results.append(result4)
        
    elif args.policy:
        # Test specific policy
        result = await test_company_policy(
            db, args.org_id, args.provider,
            args.policy, args.on_missing
        )
        results.append(result)
    else:
        print("\n⚠️  No test specified. Use --test-all or --policy")
        return
    
    # Summary
    print(f"\n{'='*60}")
    print("📊 Test Summary")
    print(f"{'='*60}")
    for result in results:
        status = "✅ SYNCED" if result['synced'] else "❌ NOT SYNCED"
        print(f"\nPolicy: {result['policy']}")
        if result.get('on_missing'):
            print(f"  On Missing: {result['on_missing']}")
        print(f"  Status: {status}")
        print(f"  Lead ID: {result['lead_id']}")
        if result.get('crm_id'):
            print(f"  CRM ID: {result['crm_id']}")
    
    print(f"\n✅ Testing complete!")
    print(f"\n💡 Next steps:")
    print(f"   1. Check logs for sync details")
    print(f"   2. Verify in {args.provider} UI")
    print(f"   3. Check MongoDB for lead documents")


if __name__ == "__main__":
    asyncio.run(main())

