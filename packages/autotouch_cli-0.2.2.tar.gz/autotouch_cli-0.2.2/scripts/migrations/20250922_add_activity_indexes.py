#!/usr/bin/env python3
"""
Add indexes for the activities collection to support efficient queries
"""

import os
import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import ASCENDING, DESCENDING, TEXT
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# MongoDB connection settings
MONGODB_URI = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
MONGODB_DB_NAME = os.getenv("MONGODB_DB_NAME", "smart_table")


async def add_activity_indexes():
    """Add indexes for activities collection"""

    client = AsyncIOMotorClient(MONGODB_URI)
    db = client[MONGODB_DB_NAME]

    try:
        # 1. Compound index for organization filtering and date sorting
        logger.info("Creating compound index on activities (organization_id, activity_date)")
        await db.activities.create_index([
            ("organization_id", ASCENDING),
            ("activity_date", DESCENDING)
        ])

        # 2. Compound index for lead activity timeline
        logger.info("Creating compound index on activities (organization_id, lead_id, activity_date)")
        await db.activities.create_index([
            ("organization_id", ASCENDING),
            ("lead_id", ASCENDING),
            ("activity_date", DESCENDING)
        ])

        # 3. Compound index for company activities
        logger.info("Creating compound index on activities (organization_id, company_id, activity_date)")
        await db.activities.create_index([
            ("organization_id", ASCENDING),
            ("company_id", ASCENDING),
            ("activity_date", DESCENDING)
        ])

        # 4. Compound index for user activities
        logger.info("Creating compound index on activities (organization_id, user_id, activity_date)")
        await db.activities.create_index([
            ("organization_id", ASCENDING),
            ("user_id", ASCENDING),
            ("activity_date", DESCENDING)
        ])

        # 5. Index for activity type filtering
        logger.info("Creating compound index on activities (organization_id, activity_type)")
        await db.activities.create_index([
            ("organization_id", ASCENDING),
            ("activity_type", ASCENDING)
        ])

        # 6. Index for channel filtering
        logger.info("Creating compound index on activities (organization_id, channel)")
        await db.activities.create_index([
            ("organization_id", ASCENDING),
            ("channel", ASCENDING)
        ])

        # 7. Index for source tracking
        logger.info("Creating compound index on activities (organization_id, source_type)")
        await db.activities.create_index([
            ("organization_id", ASCENDING),
            ("source_type", ASCENDING)
        ])

        # 8. Index for external provider sync
        logger.info("Creating compound index on activities (organization_id, external_provider, external_id)")
        await db.activities.create_index([
            ("organization_id", ASCENDING),
            ("external_provider", ASCENDING),
            ("external_id", ASCENDING)
        ])

        # 9. Index for task completion tracking
        logger.info("Creating compound index on activities (organization_id, source_type, source_id)")
        await db.activities.create_index([
            ("organization_id", ASCENDING),
            ("source_type", ASCENDING),
            ("source_id", ASCENDING)
        ])

        # 10. Text index for content search
        logger.info("Creating text index on activities for content search")
        try:
            await db.activities.create_index([
                ("subject", TEXT),
                ("content", TEXT),
                ("outcome", TEXT)
            ])
        except Exception as e:
            logger.warning(f"Text index creation failed (might already exist): {e}")

        # 11. Index for date range queries (activity_date only)
        logger.info("Creating index on activities (activity_date)")
        await db.activities.create_index([
            ("activity_date", DESCENDING)
        ])

        # 12. Index for synced activities
        logger.info("Creating compound index on activities (organization_id, synced_at)")
        await db.activities.create_index([
            ("organization_id", ASCENDING),
            ("synced_at", DESCENDING)
        ])

        # 13. Unique index for external activities to prevent duplicates
        logger.info("Creating unique compound index for external activities")
        try:
            await db.activities.create_index([
                ("organization_id", ASCENDING),
                ("external_provider", ASCENDING),
                ("external_id", ASCENDING)
            ], unique=True, sparse=True, name="external_activities_unique")  # Give it a specific name
        except Exception as e:
            logger.warning(f"Unique external activities index creation failed (might need manual intervention): {e}")
            # Try to drop the existing index and recreate
            try:
                await db.activities.drop_index("organization_id_1_external_provider_1_external_id_1")
                await db.activities.create_index([
                    ("organization_id", ASCENDING),
                    ("external_provider", ASCENDING),
                    ("external_id", ASCENDING)
                ], unique=True, sparse=True, name="external_activities_unique")
                logger.info("Successfully recreated unique external activities index")
            except Exception as e2:
                logger.warning(f"Failed to recreate unique index: {e2}")
                logger.warning("Manual intervention may be required for external activities unique index")

        # List all indexes
        logger.info("\nCurrent indexes on activities collection:")
        activities_indexes = await db.activities.list_indexes().to_list(None)
        for idx in activities_indexes:
            logger.info(f"  - {idx['name']}: {idx['key']}")
            if idx.get('unique'):
                logger.info(f"    (unique: {idx['unique']})")
            if idx.get('sparse'):
                logger.info(f"    (sparse: {idx['sparse']})")

        logger.info("\nActivity indexes created successfully!")

    except Exception as e:
        logger.error(f"Error creating activity indexes: {e}")
        raise
    finally:
        client.close()


async def analyze_activity_performance():
    """Analyze activity query performance"""

    client = AsyncIOMotorClient(MONGODB_URI)
    db = client[MONGODB_DB_NAME]

    try:
        # Check if activities collection exists
        collections = await db.list_collection_names()
        if "activities" not in collections:
            logger.warning("Activities collection does not exist yet")
            return

        # Get collection stats
        stats = await db.command("collStats", "activities")
        logger.info(f"\nActivities collection stats:")
        logger.info(f"  - Document count: {stats.get('count', 0)}")
        logger.info(f"  - Average document size: {stats.get('avgObjSize', 0)} bytes")
        logger.info(f"  - Total size: {stats.get('size', 0)} bytes")
        logger.info(f"  - Storage size: {stats.get('storageSize', 0)} bytes")
        logger.info(f"  - Total index size: {stats.get('totalIndexSize', 0)} bytes")

        # Sample query performance test (if there are documents)
        doc_count = await db.activities.count_documents({})
        if doc_count > 0:
            # Test a common query pattern
            sample_org = await db.activities.find_one({}, {"organization_id": 1})
            if sample_org:
                org_id = sample_org["organization_id"]

                # Test organization + date range query
                explain_result = await db.activities.find({
                    "organization_id": org_id,
                    "activity_date": {"$gte": "2025-01-01T00:00:00"}
                }).sort([("activity_date", -1)]).limit(10).explain()

                logger.info(f"\nQuery performance analysis:")
                execution_stats = explain_result.get("executionStats", {})
                logger.info(f"  - Execution time: {execution_stats.get('executionTimeMillis', 'N/A')}ms")
                logger.info(f"  - Documents examined: {execution_stats.get('totalDocsExamined', 'N/A')}")
                logger.info(f"  - Documents returned: {execution_stats.get('totalDocsReturned', 'N/A')}")
                logger.info(f"  - Index used: {explain_result.get('queryPlanner', {}).get('winningPlan', {}).get('inputStage', {}).get('indexName', 'No index')}")

    except Exception as e:
        logger.error(f"Error analyzing activity performance: {e}")
    finally:
        client.close()


if __name__ == "__main__":
    # Run migrations
    asyncio.run(add_activity_indexes())

    # Analyze performance
    asyncio.run(analyze_activity_performance())