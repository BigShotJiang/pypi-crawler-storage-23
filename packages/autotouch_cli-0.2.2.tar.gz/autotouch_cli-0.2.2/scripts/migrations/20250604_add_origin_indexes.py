"""
Add indexes for origin tracking in columns collection

This migration adds indexes to support efficient queries for columns
based on their origin information (source column, action type).
"""

import os
import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import IndexModel

async def migrate():
    """Run the migration to add origin indexes"""
    
    # Get MongoDB connection details from environment
    mongodb_uri = os.getenv('MONGODB_URI', 'mongodb://localhost:27017')
    db_name = os.getenv('MONGODB_DB_NAME', 'smart_table')
    
    # Connect to MongoDB
    client = AsyncIOMotorClient(mongodb_uri)
    db = client[db_name]
    
    try:
        # Create indexes for columns collection
        columns_indexes = [
            IndexModel([("table_id", 1), ("origin.columnId", 1)]),
            IndexModel([("origin.action", 1)]),
            IndexModel([("config.sourceColumnId", 1)]),
        ]
        
        await db.columns.create_indexes(columns_indexes)
        print("✓ Created indexes for columns collection")
        
        # Create index for cells collection (for JSON explode updates)
        cells_indexes = [
            IndexModel([("table_id", 1), ("column_id", 1), ("row_id", 1)]),
        ]
        
        await db.cells.create_indexes(cells_indexes)
        print("✓ Created indexes for cells collection")
        
        print("\nMigration completed successfully!")
        
    except Exception as e:
        print(f"✗ Migration failed: {str(e)}")
        raise
    finally:
        client.close()

if __name__ == "__main__":
    asyncio.run(migrate())