#!/usr/bin/env python3
"""
Migration script to convert single phone/email fields to arrays.

This migration handles:
1. Converting Lead.mobile_number to Lead.phone_numbers array
2. Converting Lead.email to Lead.email_addresses array
3. Updating existing task LeadContext objects
4. Preserving all existing data with proper metadata

Usage:
    python scripts/migrations/20250926_migrate_single_to_arrays.py

Environment variables:
    MONGODB_URI: MongoDB connection string (default: mongodb://localhost:27017)
    MONGODB_DB_NAME: Database name (default: smart_table)
    DRY_RUN: Set to 'true' to preview changes without applying them (default: false)
"""

import os
import asyncio
import re
from datetime import datetime
from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import ASCENDING, DESCENDING
import logging
from typing import Dict, List, Any, Optional

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# MongoDB connection settings
MONGODB_URI = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
MONGODB_DB_NAME = os.getenv("MONGODB_DB_NAME", "smart_table")
DRY_RUN = os.getenv("DRY_RUN", "false").lower() == "true"

class PhoneNumberNormalizer:
    """Utility class for normalizing phone numbers to E.164 format"""

    @staticmethod
    def normalize_to_e164(phone: str) -> Optional[str]:
        """Convert various phone formats to E.164"""
        if not phone:
            return None

        # Remove all non-digit characters
        digits = re.sub(r'[^\d]', '', phone.strip())

        if not digits:
            return None

        # Handle common US formats
        if len(digits) == 10:
            # Assume US number if 10 digits
            return f"+1{digits}"
        elif len(digits) == 11 and digits.startswith('1'):
            # US number with country code
            return f"+{digits}"
        elif len(digits) >= 7 and len(digits) <= 15:
            # International format, add + if missing
            return f"+{digits}"
        else:
            # Invalid length
            logger.warning(f"Invalid phone number length: {phone} -> {digits}")
            return None

    @staticmethod
    def detect_phone_type(phone: str) -> str:
        """Detect if phone is mobile or landline (simple heuristic)"""
        # This is a basic heuristic - in production you'd use a proper service
        digits = re.sub(r'[^\d]', '', phone.strip())

        if not digits:
            return "unknown"

        # US mobile prefixes (simplified)
        us_mobile_prefixes = [
            '201', '202', '203', '205', '206', '207', '208', '209', '210',
            '212', '213', '214', '215', '216', '217', '218', '219', '224',
            '225', '227', '228', '229', '231', '234', '239', '240', '248',
            '251', '252', '253', '254', '256', '260', '262', '267', '269',
            '270', '272', '274', '276', '281', '283', '301', '302', '303',
            '304', '305', '307', '308', '309', '310', '312', '313', '314',
            '315', '316', '317', '318', '319', '320', '321', '323', '325',
            '330', '331', '334', '336', '337', '339', '341', '347', '351',
            '352', '360', '361', '364', '385', '386', '401', '402', '404',
            '405', '406', '407', '408', '409', '410', '412', '413', '414',
            '415', '417', '419', '423', '424', '425', '430', '432', '434',
            '435', '440', '442', '443', '445', '447', '458', '464', '469',
            '470', '475', '478', '479', '480', '484', '501', '502', '503',
            '504', '505', '507', '508', '509', '510', '512', '513', '515',
            '516', '517', '518', '520', '530', '540', '541', '551', '559',
            '561', '562', '563', '564', '567', '570', '571', '573', '574',
            '575', '580', '585', '586', '601', '602', '603', '605', '606',
            '607', '608', '609', '610', '612', '614', '615', '616', '617',
            '618', '619', '620', '623', '626', '628', '629', '630', '631',
            '636', '641', '646', '650', '651', '657', '660', '661', '662',
            '667', '669', '678', '681', '682', '701', '702', '703', '704',
            '706', '707', '708', '712', '713', '714', '715', '716', '717',
            '718', '719', '720', '724', '725', '727', '731', '732', '734',
            '737', '740', '743', '747', '754', '757', '760', '762', '763',
            '765', '769', '770', '772', '773', '774', '775', '779', '781',
            '785', '786', '787', '801', '802', '803', '804', '805', '806',
            '808', '810', '812', '813', '814', '815', '816', '817', '818',
            '828', '830', '831', '832', '843', '845', '847', '848', '850',
            '856', '857', '858', '859', '860', '862', '863', '864', '865',
            '870', '872', '878', '901', '903', '904', '906', '907', '908',
            '909', '910', '912', '913', '914', '915', '916', '917', '918',
            '919', '920', '925', '928', '929', '931', '934', '936', '937',
            '940', '941', '947', '949', '951', '952', '954', '956', '959',
            '970', '971', '972', '973', '975', '978', '979', '980', '984',
            '985', '989'
        ]

        if len(digits) == 11 and digits.startswith('1'):
            # US number - check area code
            area_code = digits[1:4]
            return "mobile" if area_code in us_mobile_prefixes else "landline"
        elif len(digits) == 10:
            # US number without country code
            area_code = digits[:3]
            return "mobile" if area_code in us_mobile_prefixes else "landline"
        else:
            # International - assume mobile for now
            return "mobile"


class MigrationStats:
    """Track migration statistics"""

    def __init__(self):
        self.leads_processed = 0
        self.leads_with_phone = 0
        self.leads_with_email = 0
        self.tasks_processed = 0
        self.tasks_updated = 0
        self.errors = []

    def add_error(self, error: str):
        self.errors.append(error)
        logger.error(f"Migration error: {error}")

    def print_summary(self):
        logger.info("=== Migration Summary ===")
        logger.info(f"Leads processed: {self.leads_processed}")
        logger.info(f"Leads with phone converted: {self.leads_with_phone}")
        logger.info(f"Leads with email converted: {self.leads_with_email}")
        logger.info(f"Tasks processed: {self.tasks_processed}")
        logger.info(f"Tasks updated: {self.tasks_updated}")
        if self.errors:
            logger.info(f"Errors encountered: {len(self.errors)}")
            for error in self.errors[:5]:  # Show first 5 errors
                logger.info(f"  - {error}")
        logger.info("=========================")


async def backup_collections(db):
    """Create backup of collections before migration"""
    backup_timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")

    try:
        # Get collection stats
        leads_count = await db.leads.count_documents({})
        tasks_count = await db.task_queue.count_documents({})

        logger.info(f"Creating backup - Leads: {leads_count}, Tasks: {tasks_count}")

        # Note: In production, you'd export to files or another database
        # For this migration, we'll just log the counts
        logger.info(f"Backup timestamp: {backup_timestamp}")
        logger.info("In production, export collections to backup files here")

        return backup_timestamp

    except Exception as e:
        logger.error(f"Backup failed: {e}")
        raise


async def migrate_leads_to_arrays(db, stats: MigrationStats):
    """Convert single phone/email fields to arrays for all leads"""

    logger.info("Starting lead migration...")

    # Find leads with old single fields
    query = {
        "$or": [
            {"mobile_number": {"$exists": True, "$ne": None, "$ne": ""}},
            {"email": {"$exists": True, "$ne": None, "$ne": ""}}
        ]
    }

    if DRY_RUN:
        count = await db.leads.count_documents(query)
        logger.info(f"DRY RUN: Would migrate {count} leads")
        return

    cursor = db.leads.find(query)
    normalizer = PhoneNumberNormalizer()

    async for lead in cursor:
        try:
            stats.leads_processed += 1
            lead_id = lead["_id"]

            phone_numbers = []
            email_addresses = []
            update_doc = {}
            unset_doc = {}

            # Convert mobile_number to phone_numbers array
            if lead.get("mobile_number"):
                mobile_number = lead["mobile_number"].strip()
                normalized_phone = normalizer.normalize_to_e164(mobile_number)

                if normalized_phone:
                    phone_type = normalizer.detect_phone_type(mobile_number)
                    phone_obj = {
                        "number": normalized_phone,
                        "type": phone_type,
                        "is_mobile": phone_type == "mobile",
                        "provider": "legacy_migration",
                        "confidence": 0.8,  # Medium confidence for migrated data
                        "source": "mobile_number_field",
                        "metadata": {
                            "original_value": mobile_number,
                            "migration_date": datetime.utcnow()
                        },
                        "created_at": datetime.utcnow()
                    }
                    phone_numbers.append(phone_obj)
                    stats.leads_with_phone += 1
                else:
                    stats.add_error(f"Failed to normalize phone for lead {lead_id}: {mobile_number}")

                unset_doc["mobile_number"] = ""

            # Convert email to email_addresses array
            if lead.get("email"):
                email = lead["email"].strip().lower()

                # Basic email validation
                email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
                if re.match(email_pattern, email):
                    # Determine if work email (basic heuristics)
                    domain = email.split('@')[1] if '@' in email else ''
                    is_work = not any(domain.endswith(personal) for personal in [
                        'gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com',
                        'aol.com', 'icloud.com', 'live.com', 'msn.com'
                    ])

                    email_obj = {
                        "address": email,
                        "type": "work" if is_work else "personal",
                        "is_work_email": is_work,
                        "provider": "legacy_migration",
                        "confidence": 0.9,  # High confidence for email format
                        "source": "email_field",
                        "metadata": {
                            "original_value": lead["email"],
                            "migration_date": datetime.utcnow()
                        },
                        "created_at": datetime.utcnow()
                    }
                    email_addresses.append(email_obj)
                    stats.leads_with_email += 1
                else:
                    stats.add_error(f"Invalid email format for lead {lead_id}: {email}")

                unset_doc["email"] = ""

            # Update the lead document
            if phone_numbers or email_addresses:
                if phone_numbers:
                    update_doc["phone_numbers"] = phone_numbers
                if email_addresses:
                    update_doc["email_addresses"] = email_addresses

                update_doc["updated_at"] = datetime.utcnow()

                # Perform the update
                result = await db.leads.update_one(
                    {"_id": lead_id},
                    {
                        "$set": update_doc,
                        "$unset": unset_doc
                    }
                )

                if result.modified_count == 0:
                    stats.add_error(f"Failed to update lead {lead_id}")

            if stats.leads_processed % 100 == 0:
                logger.info(f"Processed {stats.leads_processed} leads...")

        except Exception as e:
            stats.add_error(f"Error processing lead {lead.get('_id', 'unknown')}: {e}")
            continue

    logger.info(f"Lead migration completed. Processed {stats.leads_processed} leads")


async def migrate_task_contexts(db, stats: MigrationStats):
    """Update existing task LeadContext objects to new structure"""

    logger.info("Starting task LeadContext migration...")

    # Find tasks with old LeadContext structure
    query = {
        "$or": [
            {"lead_context.mobile_number": {"$exists": True}},
            {"lead_context.email": {"$exists": True}}
        ]
    }

    if DRY_RUN:
        count = await db.task_queue.count_documents(query)
        logger.info(f"DRY RUN: Would migrate {count} tasks")
        return

    cursor = db.task_queue.find(query)

    async for task in cursor:
        try:
            stats.tasks_processed += 1
            task_id = task["_id"]
            lead_context = task.get("lead_context", {})

            updated = False

            # Move mobile_number to primary_phone
            if "mobile_number" in lead_context:
                lead_context["primary_phone"] = lead_context.pop("mobile_number")
                updated = True

            # Move email to business_email
            if "email" in lead_context:
                lead_context["business_email"] = lead_context.pop("email")
                updated = True

            # Add empty arrays if not present
            if "phone_numbers" not in lead_context:
                lead_context["phone_numbers"] = []
                updated = True

            if "email_addresses" not in lead_context:
                lead_context["email_addresses"] = []
                updated = True

            # Update the task if changes were made
            if updated:
                result = await db.task_queue.update_one(
                    {"_id": task_id},
                    {
                        "$set": {
                            "lead_context": lead_context,
                            "updated_at": datetime.utcnow()
                        }
                    }
                )

                if result.modified_count > 0:
                    stats.tasks_updated += 1
                else:
                    stats.add_error(f"Failed to update task {task_id}")

            if stats.tasks_processed % 100 == 0:
                logger.info(f"Processed {stats.tasks_processed} tasks...")

        except Exception as e:
            stats.add_error(f"Error processing task {task.get('_id', 'unknown')}: {e}")
            continue

    logger.info(f"Task migration completed. Processed {stats.tasks_processed} tasks, updated {stats.tasks_updated}")


async def validate_migration(db, stats: MigrationStats):
    """Validate the migration results"""

    logger.info("Validating migration results...")

    # Check for any remaining old fields in leads
    remaining_mobile = await db.leads.count_documents({"mobile_number": {"$exists": True, "$ne": None, "$ne": ""}})
    remaining_email = await db.leads.count_documents({"email": {"$exists": True, "$ne": None, "$ne": ""}})

    if remaining_mobile > 0:
        stats.add_error(f"{remaining_mobile} leads still have mobile_number field")

    if remaining_email > 0:
        stats.add_error(f"{remaining_email} leads still have email field")

    # Check for remaining old fields in tasks
    remaining_task_mobile = await db.task_queue.count_documents({"lead_context.mobile_number": {"$exists": True}})
    remaining_task_email = await db.task_queue.count_documents({"lead_context.email": {"$exists": True}})

    if remaining_task_mobile > 0:
        stats.add_error(f"{remaining_task_mobile} tasks still have lead_context.mobile_number")

    if remaining_task_email > 0:
        stats.add_error(f"{remaining_task_email} tasks still have lead_context.email")

    # Check new array fields
    leads_with_phone_arrays = await db.leads.count_documents({"phone_numbers": {"$exists": True, "$ne": []}})
    leads_with_email_arrays = await db.leads.count_documents({"email_addresses": {"$exists": True, "$ne": []}})

    logger.info(f"Validation results:")
    logger.info(f"  - Leads with phone arrays: {leads_with_phone_arrays}")
    logger.info(f"  - Leads with email arrays: {leads_with_email_arrays}")
    logger.info(f"  - Remaining mobile_number fields: {remaining_mobile}")
    logger.info(f"  - Remaining email fields: {remaining_email}")
    logger.info(f"  - Remaining task mobile_number: {remaining_task_mobile}")
    logger.info(f"  - Remaining task email: {remaining_task_email}")


async def run_migration():
    """Main migration function"""

    logger.info("Starting phone/email array migration...")
    logger.info(f"DRY RUN mode: {DRY_RUN}")
    logger.info(f"MongoDB URI: {MONGODB_URI}")
    logger.info(f"Database: {MONGODB_DB_NAME}")

    client = AsyncIOMotorClient(MONGODB_URI)
    db = client[MONGODB_DB_NAME]
    stats = MigrationStats()

    try:
        # Create backup
        if not DRY_RUN:
            backup_timestamp = await backup_collections(db)
            logger.info(f"Backup created: {backup_timestamp}")

        # Run migrations
        await migrate_leads_to_arrays(db, stats)
        await migrate_task_contexts(db, stats)

        # Validate results
        if not DRY_RUN:
            await validate_migration(db, stats)

        # Print summary
        stats.print_summary()

        if stats.errors:
            logger.warning(f"Migration completed with {len(stats.errors)} errors")
            return 1
        else:
            logger.info("Migration completed successfully!")
            return 0

    except Exception as e:
        logger.error(f"Migration failed: {e}")
        return 1
    finally:
        client.close()


if __name__ == "__main__":
    import sys

    if DRY_RUN:
        logger.info("DRY RUN MODE - No changes will be made")

    exit_code = asyncio.run(run_migration())
    sys.exit(exit_code)