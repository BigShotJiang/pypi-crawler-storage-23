#!/usr/bin/env python3
"""
Migration to create indexes for llm_responses collection.
This collection stores all LLM API calls and responses for audit and analysis.
"""
import os
import sys
from pymongo import MongoClient, ASCENDING, DESCENDING
from datetime import datetime

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from apps.api.models import LLM_RESPONSES_COLLECTION


def create_indexes():
    """Create indexes for the llm_responses collection."""
    # Get MongoDB connection from environment
    mongodb_uri = os.getenv('MONGODB_URI', 'mongodb://localhost:27017')
    db_name = os.getenv('MONGODB_DB_NAME', 'autotouch')
    
    print(f"Connecting to MongoDB: {mongodb_uri}")
    client = MongoClient(mongodb_uri)
    db = client[db_name]
    
    collection = db[LLM_RESPONSES_COLLECTION]
    
    print(f"\nCreating indexes for {LLM_RESPONSES_COLLECTION} collection...")
    
    # Compound index for finding responses by table/column/row
    print("Creating compound index for table_id, column_id, row_id...")
    collection.create_index([
        ("table_id", ASCENDING),
        ("column_id", ASCENDING),
        ("row_id", ASCENDING)
    ], name="table_column_row_idx")
    
    # Index for recent responses
    print("Creating index for created_at (descending)...")
    collection.create_index([
        ("created_at", DESCENDING)
    ], name="created_at_idx")
    
    # Index for user activity tracking
    print("Creating compound index for user_id and created_at...")
    collection.create_index([
        ("user_id", ASCENDING),
        ("created_at", DESCENDING)
    ], name="user_activity_idx")
    
    # Index for status queries
    print("Creating index for status...")
    collection.create_index([
        ("status", ASCENDING)
    ], name="status_idx")
    
    # Index for job tracking
    print("Creating index for job_id...")
    collection.create_index([
        ("job_id", ASCENDING)
    ], name="job_id_idx")
    
    # Index for error tracking
    print("Creating partial index for errors...")
    collection.create_index([
        ("status", ASCENDING),
        ("created_at", DESCENDING)
    ], name="error_tracking_idx", partialFilterExpression={"status": "error"})
    
    # Index for mode analysis (basic vs agent)
    print("Creating index for request.mode...")
    collection.create_index([
        ("request.mode", ASCENDING),
        ("created_at", DESCENDING)
    ], name="mode_analysis_idx")
    
    # Index for provider/model analysis
    print("Creating compound index for provider and model...")
    collection.create_index([
        ("request.provider", ASCENDING),
        ("request.model", ASCENDING),
        ("created_at", DESCENDING)
    ], name="provider_model_idx")
    
    print("\nAll indexes created successfully!")
    
    # Display current indexes
    print("\nCurrent indexes on collection:")
    for idx in collection.list_indexes():
        print(f"  - {idx['name']}: {idx['key']}")


def main():
    """Run the migration."""
    print("=== LLM Responses Collection Migration ===")
    print(f"Timestamp: {datetime.utcnow().isoformat()}")
    
    try:
        create_indexes()
        print("\n✅ Migration completed successfully!")
    except Exception as e:
        print(f"\n❌ Migration failed: {str(e)}")
        raise


if __name__ == "__main__":
    main()