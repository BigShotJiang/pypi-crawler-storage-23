"""Custom exceptions for the Gemini web MCP CLI."""


class GeminiError(Exception):
    """Base exception for all Gemini-related errors."""

    pass


class AuthError(GeminiError):
    """Authentication failure: invalid cookies, expired tokens, or failed login."""

    pass


class APIError(GeminiError):
    """API-level error: unexpected response format, parsing failure, or unknown error code."""

    def __init__(self, message: str, error_code: int | None = None):
        self.error_code = error_code
        super().__init__(message)


class UsageLimitExceeded(GeminiError):
    """Usage limit exceeded (error code 1037)."""

    pass


class ModelInvalid(GeminiError):
    """Model unavailable or header invalid (error codes 1050, 1052)."""

    pass


class TemporarilyBlocked(GeminiError):
    """IP temporarily blocked by Google (error code 1060)."""

    pass


class TimeoutError(GeminiError):
    """Request timed out or watchdog triggered due to stalled stream."""

    pass


class ImageGenerationError(APIError):
    """Error during image generation or parsing image response."""

    pass


class VideoGenerationError(APIError):
    """Error during video generation or parsing video response."""

    pass


class MusicGenerationError(APIError):
    """Error during music generation or parsing music response."""

    pass


class ResearchError(APIError):
    """Error during deep research or polling for results."""

    pass


class ProfileError(GeminiError):
    """Error with profile management: not found, invalid, or filesystem issues."""

    pass


class TokenFactoryError(GeminiError):
    """Chrome/BotGuard token capture failure."""

    pass
