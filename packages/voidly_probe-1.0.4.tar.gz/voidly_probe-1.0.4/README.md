# Voidly Community Probe

Help measure internet censorship worldwide. Run a lightweight probe node from anywhere.

## What it does

Tests connectivity to 62 websites (social media, news, messaging, privacy tools, human rights organizations) every 15 minutes from your network. Detects DNS blocking, TCP resets, TLS/SNI filtering, HTTP redirects, and identifies blocking entities (government firewalls, ISP filters).

Results feed into [Voidly's censorship intelligence network](https://voidly.ai) — the world's largest real-time censorship dataset.

## Install

```bash
pip install voidly-probe
```

Or with Docker:

```bash
docker run -d --name voidly-probe -v voidly-data:/data/.voidly emperormew2/voidly-probe
```

## Quick start

```bash
# First run — register and start probing
voidly-probe --consent

# Single test cycle
voidly-probe --once

# Check your node's status
voidly-probe --status

# Run in background (Linux/Mac)
nohup voidly-probe --consent &
```

## Claim your node

After your node is running, link your identity to appear on the [leaderboard](https://voidly.ai/probes) and be eligible for prizes:

1. Find your Node ID and Token in `~/.voidly/node.json`
2. Visit [voidly.ai/probes/claim](https://voidly.ai/probes/claim)
3. Enter your Node ID, Token, and Twitter/X handle
4. Your name now appears on the leaderboard instead of `cp-xxxxxxxx`

**Important:** Back up `~/.voidly/node.json` — your token is shown once during registration and cannot be recovered. If you lose it, you'll need to re-register as a new node.

## What we collect

- Domain, blocked/accessible status, latency, blocking method
- Your approximate location (country, city) — detected once during registration
- SHA256 hash of your IP (for deduplication, not stored raw)

## What we don't collect

- No browsing data
- No passwords or personal information
- No traffic inspection beyond the 62 test domains
- Your raw IP address is never stored

## Privacy

- Data is used for censorship research under CC BY 4.0
- You can stop the probe at any time with Ctrl+C
- Config stored at `~/.voidly/node.json` — delete to unregister
- Learn more: https://voidly.ai/probes

## Requirements

- Python 3.8+
- No external dependencies (stdlib only)
- No root/admin required
- No VPN tunnel

## Configuration

Environment variables:

| Variable | Default | Description |
|----------|---------|-------------|
| `VOIDLY_PROBE_INTERVAL` | `900` | Seconds between probe cycles |
| `VOIDLY_PROBE_TIMEOUT` | `10` | Timeout per request (seconds) |
| `VOIDLY_BATCH_SIZE` | `20` | Domains per cycle |
| `VOIDLY_CONFIG_DIR` | `~/.voidly` | Config directory |

## Docker

```bash
# Run in background with persistent config
docker run -d --name voidly-probe \
  -v voidly-data:/data/.voidly \
  emperormew2/voidly-probe

# View logs
docker logs -f voidly-probe

# Check node status (find Node ID in logs)
docker exec voidly-probe voidly-probe --status

# Stop
docker stop voidly-probe
```

## License

MIT — https://voidly.ai
