import lightning
import lightning.pytorch.callbacks
import numpy as np
import pytest
import zarr
from torch import nn, optim

import tests.utils
from zarrdataset import ZarrDataLoader, ZarrIterableDataset

_ENCODER = nn.Sequential(nn.Linear(50*50, 64), nn.ReLU(), nn.Linear(64, 3))
_DECODER = nn.Sequential(nn.Linear(3, 64), nn.ReLU(), nn.Linear(64, 50*50))


class AutoEncoder(lightning.LightningModule):
    def __init__(self, encoder, decoder):
        super().__init__()
        self.encoder = encoder
        self.decoder = decoder

    def _compute_loss(self, batch):
        x = batch
        x = x.view(x.size(0), -1)
        z = self.encoder(x)
        x_hat = self.decoder(z)
        loss = nn.functional.mse_loss(x_hat, x)
        return loss

    def training_step(self, batch, batch_idx):
        return self._compute_loss(batch)

    def validation_step(self, batch, batch_idx):
        loss = self._compute_loss(batch)
        self.log(name='val_loss', value=loss, prog_bar=True, on_epoch=True, on_step=False,
                 sync_dist=True)  # The last parameter is very important in multiprocessing context.

    def configure_optimizers(self):
        optimizer = optim.Adam(self.parameters(), lr=1e-3)
        return optimizer


def create_zarr_array(chunk_size: int) -> zarr.Array:
    with zarr.storage.MemoryStore() as store: # type: ignore
        nb_case = 100
        x_res = 50
        y_res = 50
        chunk_size = 10
        data = np.arange(nb_case*x_res*y_res).reshape((nb_case, x_res, y_res))
        z = zarr.create_array(store=store, shape=data.shape, dtype=np.float32,
                              chunks=(chunk_size, x_res, y_res), compressors=None)
        z[:] = data
        return z


@pytest.fixture(scope='module', params=[10])
def samples(request) -> zarr.Array:
    return create_zarr_array(request.param)


def test(samples) -> None:
    autoencoder = AutoEncoder(_ENCODER, _DECODER)
    print(f'> {samples.shape=}')
    print('> create dataset and dataloader')

    # Train on all the chunks excepted The first three for the validation.
    chunks_indexes = np.arange(samples.nchunks)
    train_chunk_indexes = chunks_indexes[3:]
    val_chunk_indexes = chunks_indexes[0:3]
    train_ds = ZarrIterableDataset(samples=samples, targets=None,
                                   selected_chunk_indexes=train_chunk_indexes,
                                   shuffle_chunks=True,
                                   chunks_shuffle_seed=1,
                                   shuffle_buffer=True,
                                   buffer_shuffle_seed=2)
    val_ds = ZarrIterableDataset(samples=samples, targets=None,
                                 selected_chunk_indexes=val_chunk_indexes,
                                 shuffle_chunks=False,
                                 shuffle_buffer=False)
    train_da = ZarrDataLoader(dataset=train_ds,
                              num_workers=2,
                              batch_size=64,
                              multiprocessing_context='fork',
                              pin_memory=True,
                              prefetch_factor=2,
                              drop_last=False)
    val_da = ZarrDataLoader(dataset=val_ds,
                            num_workers=1,
                            batch_size=64,
                            multiprocessing_context='fork',
                            pin_memory=True,
                            prefetch_factor=2,
                            drop_last=False)
    timer = lightning.pytorch.callbacks.Timer()
    trainer = lightning.Trainer(max_epochs=2,
                                callbacks=[timer])
    trainer.fit(model=autoencoder, train_dataloaders=train_da, val_dataloaders=val_da)
    print(f'train elapsed time: {tests.utils.display_duration(timer.time_elapsed("train"))}')
    print(f'validation elapsed time: {tests.utils.display_duration(timer.time_elapsed("validate"))}')
