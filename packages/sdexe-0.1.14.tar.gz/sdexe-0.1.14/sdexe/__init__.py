"""sdexe - Local tools for media downloads, PDF, images, and file conversion."""

__version__ = "0.1.14"
