"""
memctl — A Unix-native memory control plane for LLM orchestration.

One file, one truth. All memory is in a single SQLite + FTS5 + WAL database.
Policy-governed, content-addressed, and forward-compatible with RAGIX.

Author: Olivier Vitrac, PhD, HDR | olivier.vitrac@adservio.fr | Adservio
"""

__version__ = "0.23.1"

from memctl.types import (
    MemoryItem,
    MemoryProposal,
    MemoryEvent,
    MemoryLink,
    MemoryProvenance,
    CorpusMetadata,
    SearchMeta,
    SearchStrategy,
)
from memctl.store import MemoryStore, SCHEMA_VERSION
from memctl.policy import MemoryPolicy
from memctl.config import MemoryConfig

__all__ = [
    "__version__",
    "MemoryItem",
    "MemoryProposal",
    "MemoryEvent",
    "MemoryLink",
    "MemoryProvenance",
    "CorpusMetadata",
    "SearchMeta",
    "SearchStrategy",
    "MemoryStore",
    "MemoryPolicy",
    "MemoryConfig",
    "SCHEMA_VERSION",
]
