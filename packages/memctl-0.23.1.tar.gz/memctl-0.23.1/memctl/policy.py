"""
Write Governance — Memory Policy Engine

Evaluates memory proposals before storage. Two levels:
- Hard blocks: secrets, injection patterns, oversized content, missing provenance
- Soft blocks: low confidence → quarantine to STM with expiry

Never bypassed. Optional auditor LLM can refine type/tags but cannot override hard blocks.

Author: Olivier Vitrac, PhD, HDR | olivier.vitrac@adservio.fr | Adservio | 2026-02-14
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Literal, Optional

from memctl.config import PolicyConfig
from memctl.types import MemoryItem, MemoryProposal, _now_iso

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Verdict
# ---------------------------------------------------------------------------

PolicyAction = Literal["accept", "quarantine", "reject"]


@dataclass
class PolicyVerdict:
    """Result of policy evaluation on a proposal."""

    action: PolicyAction
    reasons: List[str] = field(default_factory=list)
    # If quarantined, these overrides are applied
    forced_tier: Optional[str] = None
    forced_validation: Optional[str] = None
    forced_expires_at: Optional[str] = None
    # V3.3: if True, item.injectable is set to False (excluded from recall/inject)
    forced_non_injectable: bool = False

    @property
    def accepted(self) -> bool:
        """Return True if the verdict is accept."""
        return self.action == "accept"

    @property
    def rejected(self) -> bool:
        """Return True if the verdict is reject."""
        return self.action == "reject"


# ---------------------------------------------------------------------------
# Pattern sets
# ---------------------------------------------------------------------------

# Secrets detection patterns (conservative)
_SECRET_PATTERNS = [
    re.compile(r"-----BEGIN\s+(RSA\s+)?PRIVATE\s+KEY-----", re.IGNORECASE),
    re.compile(r"-----BEGIN\s+PEM-----", re.IGNORECASE),
    re.compile(r"-----BEGIN\s+CERTIFICATE-----", re.IGNORECASE),
    re.compile(r"(?:api[_-]?key|apikey)\s*[:=]\s*\S{8,}", re.IGNORECASE),
    re.compile(r"\b(?:secret|token|password|passwd|pwd)\s*[:=]\s*\S{8,}", re.IGNORECASE),
    re.compile(r"(?:aws_access_key_id|aws_secret_access_key)\s*[:=]\s*\S+", re.IGNORECASE),
    re.compile(r"ghp_[A-Za-z0-9]{36,}", re.IGNORECASE),  # GitHub PAT
    re.compile(r"sk-[A-Za-z0-9]{20,}", re.IGNORECASE),    # OpenAI-style key
    re.compile(r"eyJ[A-Za-z0-9_-]{20,500}\.[A-Za-z0-9_-]{20,500}", re.IGNORECASE),  # JWT (bounded to prevent O(n²))
    re.compile(r"[A-Za-z0-9+/]{60,1000}={1,2}", re.IGNORECASE),  # long base64 with padding (bounded)
]

# Injection / prompt override patterns
_INJECTION_PATTERNS = [
    re.compile(r"ignore\s+(?:all\s+)?previous\s+instructions?", re.IGNORECASE),
    re.compile(r"forget\s+(?:all\s+)?(?:your\s+)?(?:previous\s+)?instructions?", re.IGNORECASE),
    re.compile(r"you\s+are\s+now\s+(?:a|an)\s+", re.IGNORECASE),
    re.compile(r"store\s+this\s+(?:as\s+)?(?:a\s+)?system\s+prompt", re.IGNORECASE),
    re.compile(r"override\s+(?:system|safety|security)", re.IGNORECASE),
    re.compile(r"<\s*system\s*>", re.IGNORECASE),
    re.compile(r"\[\s*SYSTEM\s*\]", re.IGNORECASE),
    re.compile(r"pretend\s+(?:to\s+be|you\s+are)", re.IGNORECASE),
]

# V3.3: Instructional-content patterns (§7.2)
# Items matching BLOCK patterns are rejected; QUARANTINE patterns are stored
# with injectable=False (excluded from recall/inject, visible in search).

# BLOCK: system/role fragments, tool invocation syntax, JSON payloads, MCP fragments
_INSTRUCTIONAL_BLOCK_PATTERNS = [
    re.compile(r"you\s+are\s+(?:Chat\s*GPT|Claude|GPT|Gemini|an?\s+AI)", re.IGNORECASE),
    re.compile(r"(?:^|\n)(?:System|Developer|Assistant|Human)\s*:", re.IGNORECASE),
    re.compile(r"(?:use|call|invoke|run)\s+memory_\w+", re.IGNORECASE),
    re.compile(r"(?:use|call|invoke|run)\s+(?:the\s+)?(?:tool|function)\s+", re.IGNORECASE),
    re.compile(r"\{\s*\"(?:tool_name|action|function_call|tool_use)\"\s*:", re.IGNORECASE),
    re.compile(r"\{\s*\"(?:parameters|arguments|params)\"\s*:\s*\{", re.IGNORECASE),
    re.compile(r"<\s*(?:tool_use|tool_result|result|function_call)\s*>", re.IGNORECASE),
    re.compile(r"<\s*/?\s*(?:tool_use|tool_result|result|function_call)\s*>", re.IGNORECASE),
]

# QUARANTINE: imperative self-instructions (stored but injectable=False)
_INSTRUCTIONAL_QUARANTINE_PATTERNS = [
    re.compile(r"(?:always|never)\s+(?:remember|forget)\s+(?:to\s+)?", re.IGNORECASE),
    re.compile(r"in\s+(?:future|subsequent|later)\s+(?:sessions?|conversations?|turns?)", re.IGNORECASE),
    re.compile(r"\b(?:you\s+)?(?:must|should|shall)\s+(?:always|never)\s+", re.IGNORECASE),
    re.compile(r"(?:from\s+now\s+on|henceforth|going\s+forward)\s*[,.]?\s+", re.IGNORECASE),
]

# V7: PII detection patterns (quarantine — not reject)
# PII in memory may be intentional (contact directories, provenance).
# Quarantine prevents injection into LLM context while preserving data.
_PII_PATTERNS = [
    # US Social Security Number (NNN-NN-NNNN)
    re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
    # Credit card: Visa, MC, Amex, Discover
    re.compile(
        r"\b(?:4\d{3}|5[1-5]\d{2}|3[47]\d{2}|6(?:011|5\d{2}))"
        r"[- ]?\d{4}[- ]?\d{4}[- ]?\d{3,4}\b"
    ),
    # Email address (conservative)
    re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"),
    # Phone number (US + international)
    re.compile(r"(?<!\d)(?:\+\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}(?!\d)"),
    # IBAN (European bank accounts)
    re.compile(r"\b[A-Z]{2}\d{2}[A-Z0-9]{11,30}\b"),
]


# ---------------------------------------------------------------------------
# Policy Engine
# ---------------------------------------------------------------------------

class MemoryPolicy:
    """
    Evaluates memory proposals against hard and soft rules.

    Hard blocks (reject):
    - Secret patterns detected in content/title
    - Injection-like text
    - Content exceeds max length (must use pointer type)
    - Missing provenance for MTM/LTM tier

    Soft blocks (quarantine → STM with expiry):
    - Low confidence
    - No evidence / no provenance source_id
    """

    def __init__(self, config: Optional[PolicyConfig] = None):
        """Initialize policy engine with detection configuration."""
        self._config = config or PolicyConfig()

    def evaluate_proposal(self, proposal: MemoryProposal) -> PolicyVerdict:
        """Evaluate a memory proposal. Returns verdict with action and reasons."""

        # R1: Content-length short-circuit — O(1) check before regex patterns
        if (
            len(proposal.content) > self._config.max_content_length
            and proposal.type != "pointer"
        ):
            return PolicyVerdict(action="reject", reasons=[
                f"Content too long ({len(proposal.content)} chars > "
                f"{self._config.max_content_length}); use type='pointer'"
            ])

        text = f"{proposal.title} {proposal.content}"

        # --- Hard blocks (R2: early exit on first match) ---
        if self._config.secret_patterns_enabled:
            secret_hits = self._check_secrets(text)
            if secret_hits:
                return PolicyVerdict(action="reject", reasons=secret_hits)

        if self._config.injection_patterns_enabled:
            inject_hits = self._check_injection(text)
            if inject_hits:
                return PolicyVerdict(action="reject", reasons=inject_hits)

        # V3.3: Instructional-content block patterns
        if self._config.instructional_content_enabled:
            inst_block_hits = self._check_instructional_block(text)
            if inst_block_hits:
                return PolicyVerdict(action="reject", reasons=inst_block_hits)

        # --- Soft blocks ---
        quarantine_reasons: List[str] = []
        force_non_injectable = False

        # V3.3: Instructional-content quarantine patterns
        if self._config.instructional_content_enabled:
            inst_quarantine_hits = self._check_instructional_quarantine(text)
            if inst_quarantine_hits:
                quarantine_reasons.extend(inst_quarantine_hits)
                force_non_injectable = True

        # V7: PII patterns
        if self._config.pii_patterns_enabled:
            pii_hits = self._check_pii(text)
            if pii_hits:
                quarantine_reasons.extend(pii_hits)
                force_non_injectable = True

        # Low confidence
        if proposal.why_store == "":
            quarantine_reasons.append("Missing why_store justification")

        # No provenance source_id
        prov = proposal.provenance_hint or {}
        if not prov.get("source_id"):
            quarantine_reasons.append("Missing provenance source_id")

        if quarantine_reasons:
            expiry = datetime.now(timezone.utc) + timedelta(
                hours=self._config.quarantine_expiry_hours
            )
            return PolicyVerdict(
                action="quarantine",
                reasons=quarantine_reasons,
                forced_tier="stm",
                forced_validation="unverified",
                forced_expires_at=expiry.isoformat(),
                forced_non_injectable=force_non_injectable,
            )

        return PolicyVerdict(action="accept", reasons=[])

    def evaluate_item(self, item: MemoryItem) -> PolicyVerdict:
        """
        Evaluate an existing MemoryItem (for direct writes or tier promotion).
        """
        # R1: Content-length short-circuit — O(1) check before regex patterns
        if (
            len(item.content) > self._config.max_content_length
            and item.type != "pointer"
        ):
            return PolicyVerdict(
                action="reject",
                reasons=["Content too long for non-pointer type"],
            )

        # Provenance required for MTM/LTM (cheap check, before regex)
        if item.tier in self._config.require_provenance_for:
            if not item.provenance.source_id:
                return PolicyVerdict(
                    action="reject",
                    reasons=[
                        f"Provenance source_id required for tier={item.tier}"
                    ],
                )

        text = f"{item.title} {item.content}"

        # --- Hard blocks (R2: early exit on first match) ---
        if self._config.secret_patterns_enabled:
            secret_hits = self._check_secrets(text)
            if secret_hits:
                return PolicyVerdict(action="reject", reasons=secret_hits)

        if self._config.injection_patterns_enabled:
            inject_hits = self._check_injection(text)
            if inject_hits:
                return PolicyVerdict(action="reject", reasons=inject_hits)

        # V3.3: Instructional-content block patterns
        if self._config.instructional_content_enabled:
            inst_block_hits = self._check_instructional_block(text)
            if inst_block_hits:
                return PolicyVerdict(action="reject", reasons=inst_block_hits)

        # --- Soft blocks (v0.7) ---
        quarantine_reasons: List[str] = []
        force_non_injectable = False

        if self._config.instructional_content_enabled:
            inst_hits = self._check_instructional_quarantine(text)
            if inst_hits:
                quarantine_reasons.extend(inst_hits)
                force_non_injectable = True

        if self._config.pii_patterns_enabled:
            pii_hits = self._check_pii(text)
            if pii_hits:
                quarantine_reasons.extend(pii_hits)
                force_non_injectable = True

        if quarantine_reasons:
            expiry = (
                datetime.now(timezone.utc)
                + timedelta(hours=self._config.quarantine_expiry_hours)
            ).isoformat()
            return PolicyVerdict(
                action="quarantine",
                reasons=quarantine_reasons,
                forced_tier="stm",
                forced_validation="unverified",
                forced_expires_at=expiry,
                forced_non_injectable=force_non_injectable,
            )

        return PolicyVerdict(action="accept", reasons=[])

    # -- Pattern checks ----------------------------------------------------

    def _check_secrets(self, text: str) -> List[str]:
        """Check for secret patterns. Returns list of match descriptions."""
        hits = []
        # R3: precheck — skip expensive base64 pattern (#9) if no '=' in text
        has_equals = "=" in text
        for i, pattern in enumerate(_SECRET_PATTERNS):
            if i == 9 and not has_equals:
                continue  # base64 requires padding char
            if pattern.search(text):
                hits.append(f"HARD_BLOCK: secret pattern #{i} matched")
        return hits

    def _check_injection(self, text: str) -> List[str]:
        """Check for injection patterns. Returns list of match descriptions."""
        hits = []
        for i, pattern in enumerate(_INJECTION_PATTERNS):
            if pattern.search(text):
                hits.append(f"HARD_BLOCK: injection pattern #{i} matched")
        return hits

    def _check_instructional_block(self, text: str) -> List[str]:
        """Check for instructional-content BLOCK patterns (tool syntax, system fragments)."""
        hits = []
        for i, pattern in enumerate(_INSTRUCTIONAL_BLOCK_PATTERNS):
            if pattern.search(text):
                hits.append(f"HARD_BLOCK: instructional_content pattern #{i} matched")
        return hits

    def _check_instructional_quarantine(self, text: str) -> List[str]:
        """Check for instructional-content QUARANTINE patterns (imperative self-instructions)."""
        hits = []
        for i, pattern in enumerate(_INSTRUCTIONAL_QUARANTINE_PATTERNS):
            if pattern.search(text):
                hits.append(f"QUARANTINE: instructional_self_instruction pattern #{i} matched")
        return hits

    def _check_pii(self, text: str) -> List[str]:
        """Check for PII patterns (SSN, credit card, email, phone, IBAN)."""
        hits = []
        for i, pattern in enumerate(_PII_PATTERNS):
            if pattern.search(text):
                hits.append(f"QUARANTINE: pii pattern #{i} matched")
        return hits
