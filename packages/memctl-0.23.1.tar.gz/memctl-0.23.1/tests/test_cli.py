"""
Tests for memctl CLI — all 16 commands via subprocess.

Every test exercises the real binary (`python -m memctl.cli`) against a
temporary SQLite database so there are no side-effects on the developer
machine.

Author: Olivier Vitrac, PhD, HDR | olivier.vitrac@adservio.fr | Adservio
"""

import json
import os
import subprocess
import sys
from pathlib import Path
import pytest


PYTHON = sys.executable
CLI = [PYTHON, "-m", "memctl.cli"]


def run(args, *, env=None, stdin=None, check=False, cwd=None):
    """Run a memctl CLI command and return CompletedProcess."""
    merged_env = {**os.environ, **(env or {})}
    return subprocess.run(
        CLI + args,
        capture_output=True,
        text=True,
        env=merged_env,
        input=stdin,
        timeout=30,
        cwd=cwd,
    )


@pytest.fixture
def db(tmp_path):
    """Create an initialized memory workspace and return the DB path."""
    db_path = str(tmp_path / "test" / "memory.db")
    r = run(["init", str(tmp_path / "test"), "--db", db_path, "-q"])
    assert r.returncode == 0, f"init failed: {r.stderr}"
    return db_path


@pytest.fixture
def populated_db(db, tmp_path):
    """A DB with one file ingested so push/search have data to work with."""
    sample = tmp_path / "architecture.md"
    sample.write_text(
        "# Architecture Guide\n\n"
        "We use microservices for scalability.\n\n"
        "Each service owns its database.\n\n"
        "Communication is via gRPC.\n",
        encoding="utf-8",
    )
    r = run([
        "push", "architecture",
        "--source", str(sample),
        "--db", db, "-q",
    ])
    assert r.returncode == 0, f"push failed: {r.stderr}"
    return db


# ---------------------------------------------------------------------------
# init
# ---------------------------------------------------------------------------


class TestInit:
    def test_creates_workspace(self, tmp_path):
        target = str(tmp_path / "ws")
        db_path = str(tmp_path / "ws" / "memory.db")
        r = run(["init", target, "--db", db_path])
        assert r.returncode == 0
        assert os.path.isfile(db_path)
        assert "export MEMCTL_DB" in r.stdout

    def test_creates_gitignore(self, tmp_path):
        target = str(tmp_path / "ws2")
        r = run(["init", target, "--db", str(tmp_path / "ws2" / "memory.db")])
        assert r.returncode == 0
        assert (tmp_path / "ws2" / ".gitignore").exists()

    def test_idempotent(self, db, tmp_path):
        """Running init twice on the same path returns 0, not error."""
        r = run(["init", str(tmp_path / "test"), "--db", db, "-q"])
        assert r.returncode == 0
        assert "export MEMCTL_DB" in r.stdout

    def test_force_reinit(self, db, tmp_path):
        """--force recreates the DB."""
        r = run(["init", str(tmp_path / "test"), "--db", db, "--force", "-q"])
        assert r.returncode == 0

    def test_fts_tokenizer(self, tmp_path):
        target = str(tmp_path / "fts")
        db_path = str(tmp_path / "fts" / "memory.db")
        r = run(["init", target, "--db", db_path, "--fts-tokenizer", "en", "-q"])
        assert r.returncode == 0

    def test_env_var_override(self, tmp_path):
        """MEMCTL_DB env var is used when --db is not specified."""
        target = str(tmp_path / "envtest")
        db_path = str(tmp_path / "envtest" / "memory.db")
        r = run(
            ["init", target],
            env={"MEMCTL_DB": db_path},
        )
        assert r.returncode == 0


# ---------------------------------------------------------------------------
# push
# ---------------------------------------------------------------------------


class TestPush:
    def test_push_with_source(self, db, tmp_path):
        sample = tmp_path / "note.md"
        sample.write_text("# Test Note\n\nSome content.\n", encoding="utf-8")
        r = run([
            "push", "test note",
            "--source", str(sample),
            "--db", db, "-q",
        ])
        assert r.returncode == 0
        # stdout should contain injection block (format_version=1)
        assert "format_version: 1" in r.stdout

    def test_push_no_match(self, db):
        """Query with no matching items → exit 0, no injection block."""
        r = run(["push", "xyznonexistent", "--db", db, "-q"])
        assert r.returncode == 0
        # No injection block emitted
        assert "format_version" not in r.stdout

    def test_push_stdout_purity(self, populated_db):
        """stdout must contain only the injection block, stderr has progress."""
        r = run(["push", "architecture", "--db", populated_db])
        # stdout: injection block only
        if r.stdout.strip():
            assert "## Memory (Injected)" in r.stdout
        # progress is on stderr
        # (with --quiet off, there should be stderr messages)

    def test_push_with_tags(self, db, tmp_path):
        f = tmp_path / "tagged.md"
        f.write_text("Some tagged content.\n", encoding="utf-8")
        r = run([
            "push", "tagged",
            "--source", str(f),
            "--tags", "test,doc",
            "--db", db, "-q",
        ])
        assert r.returncode == 0

    def test_push_nonexistent_source(self, db):
        r = run([
            "push", "query",
            "--source", "/nonexistent/file.md",
            "--db", db, "-q",
        ])
        assert r.returncode == 1


# ---------------------------------------------------------------------------
# pull
# ---------------------------------------------------------------------------


class TestPull:
    def test_pull_stdin(self, db):
        text = "The architecture uses event sourcing for state management."
        r = run(
            ["pull", "--db", db, "--title", "Architecture note", "-q"],
            stdin=text,
        )
        assert r.returncode == 0

    def test_pull_empty_stdin(self, db):
        """Empty stdin → exit 1."""
        r = run(["pull", "--db", db, "-q"], stdin="")
        assert r.returncode == 1

    def test_pull_with_tags(self, db):
        r = run(
            ["pull", "--db", db, "--tags", "arch,design", "-q"],
            stdin="We decided to use PostgreSQL for persistence.",
        )
        assert r.returncode == 0

    def test_pull_secret_rejected(self, db):
        """Content with secrets should be rejected by policy."""
        r = run(
            ["pull", "--db", db, "-q"],
            stdin="export AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",
        )
        assert r.returncode == 1

    def test_pull_stores_retrievable_item(self, db):
        """Pulled content must be searchable afterward."""
        r = run(
            ["pull", "--db", db, "--title", "gRPC decision", "-q"],
            stdin="We chose gRPC for inter-service communication.",
        )
        assert r.returncode == 0

        # Search for it
        r2 = run(["search", "gRPC", "--db", db, "--json", "-q"])
        assert r2.returncode == 0
        results = json.loads(r2.stdout)
        assert any("gRPC" in item.get("title", "") or "gRPC" in item.get("content_preview", "")
                    for item in results)

    def test_pull_dedup(self, db):
        """Pulling identical content twice must not create duplicate items."""
        content = "Kafka is used for async event streaming between services."
        for _ in range(2):
            r = run(
                ["pull", "--db", db, "--title", "Kafka note", "-q"],
                stdin=content,
            )
            assert r.returncode == 0

        # stats reports total items — must be exactly 1
        r2 = run(["stats", "--db", db, "--json", "-q"])
        assert r2.returncode == 0
        stats = json.loads(r2.stdout)
        assert stats["total_items"] == 1


# ---------------------------------------------------------------------------
# search
# ---------------------------------------------------------------------------


class TestSearch:
    def test_search_json(self, populated_db):
        r = run(["search", "architecture", "--db", populated_db, "--json", "-q"])
        assert r.returncode == 0
        results = json.loads(r.stdout)
        assert isinstance(results, list)
        assert len(results) >= 1

    def test_search_human(self, populated_db):
        r = run(["search", "microservices", "--db", populated_db, "-q"])
        assert r.returncode == 0
        assert "Found" in r.stdout or "item" in r.stdout.lower()

    def test_search_no_results(self, populated_db):
        r = run(["search", "xyznonexistent", "--db", populated_db, "-q"])
        assert r.returncode == 0

    def test_search_limit(self, populated_db):
        r = run(["search", "architecture", "-k", "1", "--db", populated_db, "--json", "-q"])
        assert r.returncode == 0
        results = json.loads(r.stdout)
        assert len(results) <= 1

    def test_search_tier_filter(self, populated_db):
        r = run(["search", "architecture", "--tier", "ltm", "--db", populated_db, "--json", "-q"])
        assert r.returncode == 0
        # Should be empty (all items are STM) or only LTM items
        if r.stdout.strip():
            results = json.loads(r.stdout)
            for item in results:
                assert item["tier"] == "ltm"


# ---------------------------------------------------------------------------
# show
# ---------------------------------------------------------------------------


class TestShow:
    def test_show_existing_item(self, populated_db):
        # First, search to find an item ID
        r = run(["search", "architecture", "--db", populated_db, "--json", "-q"])
        results = json.loads(r.stdout)
        assert len(results) >= 1
        item_id = results[0]["id"]

        # Show it
        r2 = run(["show", item_id, "--db", populated_db, "-q"])
        assert r2.returncode == 0
        assert item_id in r2.stdout

    def test_show_json(self, populated_db):
        r = run(["search", "architecture", "--db", populated_db, "--json", "-q"])
        results = json.loads(r.stdout)
        item_id = results[0]["id"]

        r2 = run(["show", item_id, "--db", populated_db, "--json", "-q"])
        assert r2.returncode == 0
        data = json.loads(r2.stdout)
        assert data["id"] == item_id
        assert "content" in data

    def test_show_nonexistent(self, populated_db):
        r = run(["show", "MEM-does-not-exist", "--db", populated_db, "-q"])
        assert r.returncode == 1


# ---------------------------------------------------------------------------
# promote (P6 — v0.17)
# ---------------------------------------------------------------------------


class TestPromote:
    def test_p6_t1_promote_stm_to_ltm(self, populated_db):
        """P6-T1: Promote STM → LTM works."""
        # Get an item ID
        r = run(["search", "architecture", "--db", populated_db, "--json", "-q"])
        results = json.loads(r.stdout)
        item_id = results[0]["id"]

        # Promote it
        r2 = run(["promote", item_id, "--tier", "ltm", "--db", populated_db, "-q"])
        assert r2.returncode == 0
        assert "ltm" in r2.stdout.lower()

        # Verify tier changed
        r3 = run(["show", item_id, "--db", populated_db, "--json", "-q"])
        data = json.loads(r3.stdout)
        assert data["tier"] == "ltm"

    def test_p6_t2_promote_stm_to_mtm(self, populated_db):
        """P6-T2: Promote STM → MTM works."""
        r = run(["search", "architecture", "--db", populated_db, "--json", "-q"])
        results = json.loads(r.stdout)
        item_id = results[0]["id"]

        r2 = run(["promote", item_id, "--tier", "mtm", "--db", populated_db, "-q"])
        assert r2.returncode == 0

    def test_p6_t3_promote_already_at_tier(self, populated_db):
        """P6-T3: Promote LTM → LTM exits 1."""
        r = run(["search", "architecture", "--db", populated_db, "--json", "-q"])
        results = json.loads(r.stdout)
        item_id = results[0]["id"]

        # First promote to LTM
        run(["promote", item_id, "--tier", "ltm", "--db", populated_db, "-q"])
        # Try again
        r2 = run(["promote", item_id, "--tier", "ltm", "--db", populated_db, "-q"])
        assert r2.returncode == 1

    def test_p6_t4_promote_nonexistent(self, populated_db):
        """P6-T4: Promote nonexistent ID exits 1."""
        r = run(["promote", "MEM-does-not-exist", "--db", populated_db, "-q"])
        assert r.returncode == 1

    def test_p6_t5_promote_json_output(self, populated_db):
        """P6-T5: Promote with --json returns structured output."""
        r = run(["search", "architecture", "--db", populated_db, "--json", "-q"])
        results = json.loads(r.stdout)
        item_id = results[0]["id"]

        r2 = run(["promote", item_id, "--tier", "ltm", "--db", populated_db, "--json", "-q"])
        assert r2.returncode == 0
        data = json.loads(r2.stdout)
        assert data["status"] == "ok"
        assert data["to_tier"] == "ltm"


# ---------------------------------------------------------------------------
# stats
# ---------------------------------------------------------------------------


class TestStats:
    def test_stats_json(self, populated_db):
        r = run(["stats", "--db", populated_db, "--json", "-q"])
        assert r.returncode == 0
        data = json.loads(r.stdout)
        assert data["status"] == "ok"
        assert data["total_items"] >= 1
        assert "by_tier" in data

    def test_stats_human(self, populated_db):
        r = run(["stats", "--db", populated_db, "-q"])
        assert r.returncode == 0
        assert "Memory Store Statistics" in r.stdout
        assert "Total items" in r.stdout

    def test_stats_empty_db(self, db):
        r = run(["stats", "--db", db, "--json", "-q"])
        assert r.returncode == 0
        data = json.loads(r.stdout)
        assert data["total_items"] == 0

    def test_stats_json_after_subcommand(self, db):
        """--json after subcommand is the canonical usage."""
        r = run(["stats", "--json", "--db", db, "-q"])
        assert r.returncode == 0
        d = json.loads(r.stdout)
        assert d["status"] == "ok"


# ---------------------------------------------------------------------------
# consolidate
# ---------------------------------------------------------------------------


class TestConsolidate:
    def test_consolidate_empty(self, db):
        r = run(["consolidate", "--db", db, "--json", "-q"])
        assert r.returncode == 0
        data = json.loads(r.stdout)
        assert data["items_merged"] == 0

    def test_consolidate_dry_run(self, db):
        # Insert similar items to trigger clustering
        for i in range(3):
            run(
                ["pull", "--db", db, "--tags", "arch,db", "-q"],
                stdin=f"Database design decision number {i}: use PostgreSQL.",
            )
        r = run(["consolidate", "--db", db, "--dry-run", "--json", "-q"])
        assert r.returncode == 0
        data = json.loads(r.stdout)
        assert data["items_processed"] >= 3

    def test_consolidate_merges(self, db):
        """Consolidation should merge similar items and archive originals."""
        for i in range(3):
            run(
                ["pull", "--db", db, "--tags", "arch,db", "-q"],
                stdin=f"Database design choice {i}: we use SQLite for local persistence and it works well.",
            )

        # Verify items exist pre-consolidation
        r1 = run(["stats", "--db", db, "--json", "-q"])
        before = json.loads(r1.stdout)["total_items"]
        assert before >= 3

        # Consolidate
        r = run(["consolidate", "--db", db, "--json", "-q"])
        assert r.returncode == 0
        data = json.loads(r.stdout)

        # After consolidation, merged items are archived so active count changes
        r2 = run(["stats", "--db", db, "--json", "-q"])
        after = json.loads(r2.stdout)["total_items"]
        # If clusters were found, active count decreases or stays same (merged replaces originals)
        if data["clusters_found"] > 0:
            assert data["items_merged"] >= 2


# ---------------------------------------------------------------------------
# loop (bounded recall-answer loop)
# ---------------------------------------------------------------------------


class TestLoop:
    def test_loop_no_stdin(self, db):
        """loop with no stdin exits 1."""
        r = run(["loop", "test query", "--llm", "cat", "--db", db, "-q"])
        assert r.returncode == 1
        assert "stdin" in r.stderr.lower() or "input" in r.stderr.lower()

    def test_loop_missing_llm(self, db):
        """loop without --llm exits with error."""
        r = run(["loop", "test query", "--db", db, "-q"], stdin="some context")
        assert r.returncode != 0

    def test_loop_single_pass_passive(self, db):
        """loop with passive protocol and cat as LLM → single iteration."""
        r = run(
            ["loop", "what is auth?", "--llm", "cat", "--protocol", "passive",
             "--db", db, "-q"],
            stdin="Authentication uses JWT tokens.",
        )
        assert r.returncode == 0
        # cat echoes the prompt back — answer should contain the context
        assert "JWT" in r.stdout or "auth" in r.stdout.lower()

    def test_loop_json_protocol_with_echo(self, db):
        """loop with json protocol: LLM outputs valid JSON → single pass."""
        # Use printf to simulate an LLM that outputs proper JSON protocol
        llm_cmd = '''sh -c 'echo "{\\\"need_more\\\": false, \\\"stop\\\": true}"; echo ""; echo "Final answer about auth."' '''
        r = run(
            ["loop", "auth flow", "--llm", llm_cmd, "--protocol", "json",
             "--db", db, "-q"],
            stdin="Initial context about authentication.",
        )
        assert r.returncode == 0
        assert "Final answer" in r.stdout

    def test_loop_trace_file(self, db, tmp_path):
        """loop --trace-file writes JSONL trace."""
        trace_path = str(tmp_path / "trace.jsonl")
        r = run(
            ["loop", "query", "--llm", "cat", "--protocol", "passive",
             "--trace-file", trace_path, "--db", db, "-q"],
            stdin="Context text.",
        )
        assert r.returncode == 0
        with open(trace_path) as f:
            lines = [l.strip() for l in f if l.strip()]
        assert len(lines) >= 1
        obj = json.loads(lines[0])
        assert obj["iter"] == 1
        assert obj["action"] == "llm_stop"

    def test_loop_replay(self, db, tmp_path):
        """loop --replay reads a trace file without calling LLM."""
        trace_path = str(tmp_path / "trace.jsonl")
        with open(trace_path, "w") as f:
            f.write('{"iter":1,"query":"auth","new_items":5,"sim":null,"action":"continue"}\n')
            f.write('{"iter":2,"query":null,"new_items":0,"sim":0.95,"action":"fixed_point"}\n')
        r = run(
            ["loop", "ignored", "--llm", "cat", "--replay", trace_path,
             "--db", db, "-q"],
            stdin="",  # stdin not used in replay mode
        )
        assert r.returncode == 0
        lines = [l for l in r.stdout.strip().split("\n") if l.strip()]
        assert len(lines) == 2
        assert json.loads(lines[0])["iter"] == 1
        assert json.loads(lines[1])["action"] == "fixed_point"

    def test_loop_strict_exit_code(self, db):
        """loop --strict exits 1 when LLM does not converge."""
        # cat echoes prompt → json parse fails → treated as stop → converged
        # So this actually converges. Use passive protocol to verify the flag wiring.
        r = run(
            ["loop", "q", "--llm", "cat", "--protocol", "passive",
             "--strict", "--db", db, "-q"],
            stdin="Some context.",
        )
        # Passive + cat → single iteration, LLM stop → converged → exit 0
        assert r.returncode == 0

    def test_loop_help(self):
        """loop --help shows all flags."""
        r = run(["loop", "--help"])
        assert r.returncode == 0
        assert "--llm" in r.stdout
        assert "--protocol" in r.stdout
        assert "--max-calls" in r.stdout
        assert "--threshold" in r.stdout
        assert "--replay" in r.stdout


# ---------------------------------------------------------------------------
# serve (smoke test — just verify the import check works)
# ---------------------------------------------------------------------------


class TestServe:
    def test_serve_import_check(self, db):
        """serve with missing mcp dep exits non-zero with informative message."""
        # Pass --db-root to the DB's parent so the ServerGuard
        # containment check doesn't reject the temp path before
        # we can test the actual MCP import path.
        db_root = str(Path(db).parent)
        r = run(
            ["serve", "--db", db, "--db-root", db_root, "-q"],
            env={"MEMCTL_DB": db},
        )
        # Either MCP deps are present (would block waiting for connection)
        # or not present (exit 1 or 2 with message about mcp)
        # Just verify it doesn't silently succeed without deps
        assert r.returncode != 0 or True  # pass if mcp is available
        if r.returncode != 0:
            assert "mcp" in r.stderr.lower() or "MCP" in r.stderr


# ---------------------------------------------------------------------------
# Global flags
# ---------------------------------------------------------------------------


class TestGlobalFlags:
    def test_quiet_suppresses_stderr(self, populated_db):
        r = run(["stats", "--db", populated_db, "-q"])
        assert r.returncode == 0
        # With --quiet, stderr should be empty or minimal
        # (warnings still show, but info messages don't)

    def test_verbose_flag(self, populated_db):
        r = run(["stats", "--db", populated_db, "-v", "-q"])
        assert r.returncode == 0

    def test_no_command_shows_help(self):
        r = run([])
        assert r.returncode == 1

    def test_invalid_command(self):
        r = run(["nonexistent"])
        assert r.returncode != 0


# ---------------------------------------------------------------------------
# Exit codes
# ---------------------------------------------------------------------------


class TestExitCodes:
    def test_success_is_zero(self, db):
        r = run(["stats", "--db", db, "-q"])
        assert r.returncode == 0

    def test_operational_error_is_one(self, db):
        """Missing required arg or empty input → exit 1."""
        r = run(["pull", "--db", db, "-q"], stdin="")
        assert r.returncode == 1

    def test_show_missing_item_is_one(self, db):
        r = run(["show", "MEM-nonexistent", "--db", db, "-q"])
        assert r.returncode == 1


# ---------------------------------------------------------------------------
# mount
# ---------------------------------------------------------------------------


class TestMountCLI:
    def test_mount_register(self, db, tmp_path):
        folder = tmp_path / "docs"
        folder.mkdir()
        r = run(["mount", str(folder), "--db", db])
        assert r.returncode == 0
        assert "MNT-" in r.stderr or "Mounted" in r.stderr

    def test_mount_list_empty(self, db):
        r = run(["mount", "--list", "--db", db, "-q"])
        assert r.returncode == 0

    def test_mount_list_after_register(self, db, tmp_path):
        folder = tmp_path / "docs"
        folder.mkdir()
        run(["mount", str(folder), "--name", "docs", "--db", db, "-q"])
        r = run(["mount", "--list", "--db", db, "-q"])
        assert r.returncode == 0
        assert "docs" in r.stdout or "MNT-" in r.stdout

    def test_mount_list_json(self, db, tmp_path):
        folder = tmp_path / "docs"
        folder.mkdir()
        run(["mount", str(folder), "--name", "docs", "--db", db, "-q"])
        r = run(["mount", "--list", "--json", "--db", db, "-q"])
        assert r.returncode == 0
        data = json.loads(r.stdout)
        assert isinstance(data, list)
        assert len(data) == 1
        assert data[0]["name"] == "docs"

    def test_mount_remove(self, db, tmp_path):
        folder = tmp_path / "docs"
        folder.mkdir()
        run(["mount", str(folder), "--name", "docs", "--db", db, "-q"])
        r = run(["mount", "--remove", "docs", "--db", db, "-q"])
        assert r.returncode == 0
        r2 = run(["mount", "--list", "--json", "--db", db, "-q"])
        data = json.loads(r2.stdout)
        assert len(data) == 0

    def test_mount_nonexistent_path(self, db, tmp_path):
        r = run(["mount", str(tmp_path / "nope"), "--db", db, "-q"])
        assert r.returncode == 1

    def test_mount_with_ignore(self, db, tmp_path):
        folder = tmp_path / "docs"
        folder.mkdir()
        r = run(["mount", str(folder), "--ignore", "*.log", "tmp/*", "--db", db, "-q"])
        assert r.returncode == 0

    def test_mount_with_lang(self, db, tmp_path):
        folder = tmp_path / "docs"
        folder.mkdir()
        r = run(["mount", str(folder), "--lang", "fr", "--db", db, "-q"])
        assert r.returncode == 0

    def test_mount_help(self):
        r = run(["mount", "--help"])
        assert r.returncode == 0
        assert "--name" in r.stdout
        assert "--ignore" in r.stdout


# ---------------------------------------------------------------------------
# sync
# ---------------------------------------------------------------------------


class TestSyncCLI:
    def test_sync_path(self, db, tmp_path):
        folder = tmp_path / "docs"
        folder.mkdir()
        (folder / "readme.md").write_text("# Hello\n\nContent here.")
        r = run(["sync", str(folder), "--db", db, "-q"])
        assert r.returncode == 0

    def test_sync_json(self, db, tmp_path):
        folder = tmp_path / "docs"
        folder.mkdir()
        (folder / "readme.md").write_text("# Hello\n\nContent here.")
        r = run(["sync", str(folder), "--json", "--db", db, "-q"])
        assert r.returncode == 0
        data = json.loads(r.stdout)
        assert data["files_scanned"] >= 1

    def test_sync_all_no_mounts(self, db):
        r = run(["sync", "--db", db, "-q"])
        assert r.returncode == 0

    def test_sync_full_flag(self, db, tmp_path):
        folder = tmp_path / "docs"
        folder.mkdir()
        (folder / "readme.md").write_text("# Hello\n\nContent here.")
        run(["sync", str(folder), "--db", db, "-q"])
        r = run(["sync", str(folder), "--full", "--json", "--db", db, "-q"])
        assert r.returncode == 0
        data = json.loads(r.stdout)
        assert data["files_unchanged"] == 0

    def test_sync_help(self):
        r = run(["sync", "--help"])
        assert r.returncode == 0
        assert "--full" in r.stdout


# ---------------------------------------------------------------------------
# inspect
# ---------------------------------------------------------------------------


class TestInspectCLI:
    def test_inspect_empty(self, db):
        r = run(["inspect", "--db", db, "-q"])
        assert r.returncode == 0
        assert "No files found" in r.stdout

    def test_inspect_after_sync(self, db, tmp_path):
        folder = tmp_path / "docs"
        folder.mkdir()
        (folder / "guide.md").write_text("# Guide\n\nDetailed guide.\n\nMore details.")
        run(["sync", str(folder), "--db", db, "-q"])
        r = run(["inspect", "--db", db, "-q"])
        assert r.returncode == 0
        assert "## Structure (Injected)" in r.stdout
        assert "Total files:" in r.stdout

    def test_inspect_json(self, db, tmp_path):
        folder = tmp_path / "docs"
        folder.mkdir()
        (folder / "guide.md").write_text("# Guide\n\nContent.")
        run(["sync", str(folder), "--db", db, "-q"])
        r = run(["inspect", "--json", "--db", db, "-q"])
        assert r.returncode == 0
        data = json.loads(r.stdout)
        assert "total_files" in data
        assert data["total_files"] >= 1

    def test_inspect_budget(self, db, tmp_path):
        folder = tmp_path / "docs"
        folder.mkdir()
        (folder / "guide.md").write_text("# Guide\n\nContent.")
        run(["sync", str(folder), "--db", db, "-q"])
        r = run(["inspect", "--budget", "10", "--db", db, "-q"])
        assert r.returncode == 0
        assert "[...truncated]" in r.stdout

    def test_inspect_help(self):
        r = run(["inspect", "--help"])
        assert r.returncode == 0
        assert "--mount" in r.stdout
        assert "--budget" in r.stdout
        assert "--sync" in r.stdout
        assert "--mount-mode" in r.stdout

    def test_inspect_with_path(self, db, tmp_path):
        """inspect <path> auto-mounts + auto-syncs + produces injection block."""
        folder = tmp_path / "source"
        folder.mkdir()
        (folder / "api.md").write_text("# API\n\nEndpoint docs.\n\nDetails.")
        r = run(["inspect", str(folder), "--db", db, "-q"])
        assert r.returncode == 0
        assert "## Structure (Injected)" in r.stdout
        assert "Total files:" in r.stdout

    def test_inspect_with_path_json(self, db, tmp_path):
        """inspect <path> --json includes orchestration keys."""
        folder = tmp_path / "source"
        folder.mkdir()
        (folder / "guide.md").write_text("# Guide\n\nContent.\n\nMore.")
        r = run(["inspect", str(folder), "--json", "--db", db, "-q"])
        assert r.returncode == 0
        data = json.loads(r.stdout)
        assert "total_files" in data
        assert "was_mounted" in data
        assert "was_synced" in data
        assert data["total_files"] >= 1

    def test_inspect_with_path_no_sync(self, db, tmp_path):
        """inspect <path> --no-sync skips sync even when stale."""
        folder = tmp_path / "source"
        folder.mkdir()
        (folder / "guide.md").write_text("# Guide\n\nContent.")
        r = run(["inspect", str(folder), "--no-sync", "--json", "--db", db, "-q"])
        assert r.returncode == 0
        data = json.loads(r.stdout)
        assert data["was_synced"] is False
        assert data["total_files"] == 0  # never synced

    def test_inspect_with_path_ephemeral(self, db, tmp_path):
        """inspect <path> --mount-mode=ephemeral cleans up mount."""
        folder = tmp_path / "source"
        folder.mkdir()
        (folder / "guide.md").write_text("# Guide\n\nContent.")
        r = run(["inspect", str(folder), "--mount-mode", "ephemeral",
                 "--json", "--db", db, "-q"])
        assert r.returncode == 0
        data = json.loads(r.stdout)
        assert data["was_ephemeral"] is True
        # Verify mount is gone
        r2 = run(["mount", "--list", "--json", "--db", db, "-q"])
        mounts = json.loads(r2.stdout)
        assert not any(m["mount_id"] == data["mount_id"] for m in mounts)


# ---------------------------------------------------------------------------
# chat
# ---------------------------------------------------------------------------


class TestChatCLI:
    """Subprocess tests for `memctl chat`."""

    def test_chat_help(self):
        """chat --help shows expected flags."""
        r = run(["chat", "--help"])
        assert r.returncode == 0
        for flag in ["--llm", "--session", "--store", "--session-budget",
                      "--protocol", "--history-turns"]:
            assert flag in r.stdout, f"Missing flag {flag} in help output"

    def test_chat_scripted_session(self, populated_db, tmp_path):
        """Scripted stdin session with echo returns deterministic output."""
        # Use 'echo' as a trivial LLM: it just echoes stdin back
        # chat_turn sends the full prompt to the LLM, so stdout will
        # contain whatever echo produces.
        # Pipe a single question then EOF.
        r = subprocess.run(
            CLI + ["chat", "--llm", "cat", "--protocol", "passive",
                   "--db", populated_db, "-q"],
            input="What is the architecture?\n",
            capture_output=True,
            text=True,
            timeout=30,
        )
        # cat echoes the full prompt (context + question) as the answer
        # The key test: exit code 0 and non-empty stdout
        assert r.returncode == 0
        assert len(r.stdout.strip()) > 0


# ===========================================================================
# TestAskCLI
# ===========================================================================


class TestAskCLI:
    """Subprocess tests for `memctl ask`."""

    def test_ask_help(self):
        """ask --help shows expected flags."""
        r = run(["ask", "--help"])
        assert r.returncode == 0
        for flag in ["--llm", "--inspect-cap", "--sync", "--mount-mode",
                      "--protocol", "--budget"]:
            assert flag in r.stdout, f"Missing flag {flag} in help output"
        # Positional args documented
        assert "path" in r.stdout
        assert "question" in r.stdout

    def test_ask_basic(self, tmp_path):
        """ask with cat LLM produces non-empty answer."""
        # Create a mini corpus
        corpus = tmp_path / "docs"
        corpus.mkdir()
        (corpus / "test.md").write_text("# Test\n\nThis is a test document.\n")
        db = str(tmp_path / "test.db")

        r = subprocess.run(
            CLI + ["ask", str(corpus), "What is this?",
                   "--llm", "cat", "--protocol", "passive",
                   "--db", db, "-q"],
            capture_output=True,
            text=True,
            timeout=30,
        )
        assert r.returncode == 0
        assert len(r.stdout.strip()) > 0


class TestExportImportCLI:
    """Subprocess tests for `memctl export` and `memctl import`."""

    def test_export_help(self):
        """export --help shows expected flags."""
        r = run(["export", "--help"])
        assert r.returncode == 0
        for flag in ["--tier", "--type", "--include-archived"]:
            assert flag in r.stdout, f"Missing flag {flag} in help output"

    def test_import_help(self):
        """import --help shows expected flags."""
        r = run(["import", "--help"])
        assert r.returncode == 0
        for flag in ["--preserve-ids", "--dry-run"]:
            assert flag in r.stdout, f"Missing flag {flag} in help output"

    def test_roundtrip(self, populated_db, tmp_path):
        """Export from populated DB, import into fresh DB, verify item count."""
        # Export
        r = run(["export", "--db", populated_db, "-q"])
        assert r.returncode == 0
        lines = [l for l in r.stdout.strip().split("\n") if l.strip()]
        assert len(lines) >= 1

        # Write to file
        export_file = str(tmp_path / "backup.jsonl")
        with open(export_file, "w") as f:
            f.write(r.stdout)

        # Import into fresh DB
        fresh_db = str(tmp_path / "fresh" / "memory.db")
        run(["init", str(tmp_path / "fresh"), "--db", fresh_db, "-q"])
        r2 = run(["import", export_file, "--db", fresh_db, "-q"])
        assert r2.returncode == 0

        # Verify items exist
        r3 = run(["stats", "--db", fresh_db, "--json"])
        assert r3.returncode == 0
        stats = json.loads(r3.stdout)
        assert stats["total_items"] >= 1

    def test_export_empty_db(self, db):
        """Export from empty DB produces no JSONL lines."""
        r = run(["export", "--db", db, "-q"])
        assert r.returncode == 0
        # stdout should be empty (no items)
        assert r.stdout.strip() == ""


class TestInitConfigJSON:
    """Tests for JSON config in init command."""

    def test_init_creates_config_json(self, tmp_path):
        """memctl init creates config.json (not config.yaml)."""
        target = str(tmp_path / "workspace")
        r = run(["init", target, "-q"])
        assert r.returncode == 0

        config_path = tmp_path / "workspace" / "config.json"
        assert config_path.exists()
        data = json.loads(config_path.read_text())
        assert "store" in data
        assert "inspect" in data
        assert "chat" in data


# ---------------------------------------------------------------------------
# pull — JSON stdin (v0.14)
# ---------------------------------------------------------------------------


class TestPullJsonStdin:
    """Tests for memctl pull with raw JSON array on stdin."""

    def test_pull_json_array_stores_structured(self, db):
        """CL1: JSON array on stdin → structured proposals, not flat note."""
        proposals = json.dumps([{
            "type": "fact",
            "title": "Event sourcing decision",
            "content": "We use event sourcing for state management.",
            "tags": ["architecture", "events"],
        }])
        r = run(["pull", "--db", db, "-q"], stdin=proposals)
        assert r.returncode == 0

        # Verify it was stored with the correct title (structured, not note)
        r2 = run(["search", "event sourcing", "--db", db, "--json", "-q"])
        assert r2.returncode == 0
        results = json.loads(r2.stdout)
        assert any(
            "Event sourcing decision" in item.get("title", "")
            for item in results
        ), f"Expected structured title, got: {results}"

    def test_pull_json_with_tags(self, db):
        """CL2: JSON stdin + --tags merges tags from both sources."""
        proposals = json.dumps([{
            "content": "PostgreSQL for persistence.",
            "tags": ["database"],
        }])
        r = run(
            ["pull", "--db", db, "--tags", "infra,decision", "-q"],
            stdin=proposals,
        )
        assert r.returncode == 0

    def test_pull_json_multiple_items(self, db):
        """Multiple JSON proposals stored as separate items."""
        proposals = json.dumps([
            {"content": "First observation.", "type": "fact", "title": "Obs 1"},
            {"content": "Second observation.", "type": "note", "title": "Obs 2"},
        ])
        r = run(["pull", "--db", db, "-q"], stdin=proposals)
        assert r.returncode == 0

        # Both should be searchable
        r2 = run(["search", "observation", "--db", db, "--json", "-q"])
        assert r2.returncode == 0
        results = json.loads(r2.stdout)
        assert len(results) >= 2


# ---------------------------------------------------------------------------
# reindex — eco config update (v0.14)
# ---------------------------------------------------------------------------


class TestReindexEcoConfig:
    """Tests for tokenizer mismatch fix in cmd_reindex."""

    def test_reindex_updates_eco_config(self, db, tmp_path):
        """CL6: reindex --tokenizer en updates .claude/eco/config.json."""
        # Create the eco config file in the expected location (relative to CWD)
        eco_dir = tmp_path / ".claude" / "eco"
        eco_dir.mkdir(parents=True)
        eco_config = eco_dir / "config.json"
        eco_config.write_text(json.dumps({
            "db_path": db,
            "version": "0.14.0",
        }))

        # Run reindex with cwd=tmp_path so it finds .claude/eco/config.json.
        # PYTHONPATH ensures memctl is importable even when cwd != project root.
        project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        r = run(
            ["reindex", "--db", db, "--tokenizer", "en", "-q"],
            cwd=str(tmp_path),
            env={"PYTHONPATH": project_root},
        )
        assert r.returncode == 0

        # Verify eco config was updated
        updated = json.loads(eco_config.read_text())
        assert "fts_tokenizer" in updated
        assert "porter" in updated["fts_tokenizer"]


# ---------------------------------------------------------------------------
# status — eco flag relocation (F1-T1, F1-T2)
# ---------------------------------------------------------------------------


class TestStatusEcoFlag:
    """Tests for eco disabled flag at .memory/.eco-disabled (v0.15.1)."""

    # Project root needed in PYTHONPATH when cwd changes away from it.
    _PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    def test_f1_t1_new_flag_reports_disabled(self, tmp_path):
        """F1-T1: .memory/.eco-disabled → status reports 'disabled'."""
        db = str(tmp_path / ".memory" / "memory.db")
        run(["init", str(tmp_path / ".memory")])
        # Create the new-location flag
        flag = tmp_path / ".memory" / ".eco-disabled"
        flag.touch()
        # Also create eco config so eco would be "active" without the flag
        eco_dir = tmp_path / ".claude" / "eco"
        eco_dir.mkdir(parents=True, exist_ok=True)
        (eco_dir / "config.json").write_text('{"db_path": "x"}')
        r = run(["status", "--db", db, "--json"], cwd=str(tmp_path),
                env={"PYTHONPATH": self._PROJECT_ROOT})
        assert r.returncode == 0
        data = json.loads(r.stdout)
        assert data["eco_mode"] == "disabled"

    def test_f1_t2_old_flag_migrated(self, tmp_path):
        """F1-T2: Old .claude/eco/.disabled migrates to .memory/.eco-disabled."""
        db = str(tmp_path / ".memory" / "memory.db")
        run(["init", str(tmp_path / ".memory")])
        # Create old-location flag
        old_dir = tmp_path / ".claude" / "eco"
        old_dir.mkdir(parents=True, exist_ok=True)
        (old_dir / ".disabled").touch()
        (old_dir / "config.json").write_text('{"db_path": "x"}')
        new_flag = tmp_path / ".memory" / ".eco-disabled"
        assert not new_flag.exists()
        r = run(["status", "--db", db, "--json"], cwd=str(tmp_path),
                env={"PYTHONPATH": self._PROJECT_ROOT})
        assert r.returncode == 0
        data = json.loads(r.stdout)
        assert data["eco_mode"] == "disabled"
        # Old flag should be gone, new flag should exist
        assert new_flag.exists()
        assert not (old_dir / ".disabled").exists()


# ---------------------------------------------------------------------------
# eco (E5–E8)
# ---------------------------------------------------------------------------


class TestEcoCLI:
    """Tests for memctl eco command (v0.16)."""

    _PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    def test_e5_eco_status_default(self, tmp_path):
        """E5: memctl eco (no arg) → reports status."""
        r = run(["eco", "--json"], cwd=str(tmp_path),
                env={"PYTHONPATH": self._PROJECT_ROOT})
        assert r.returncode == 0
        data = json.loads(r.stdout)
        assert data["eco_mode"] == "not installed"

    def test_e6_eco_off_creates_flag(self, tmp_path):
        """E6: memctl eco off → creates .memory/.eco-disabled."""
        (tmp_path / ".memory").mkdir()
        r = run(["eco", "off"], cwd=str(tmp_path),
                env={"PYTHONPATH": self._PROJECT_ROOT})
        assert r.returncode == 0
        assert (tmp_path / ".memory" / ".eco-disabled").exists()
        assert "disabled" in r.stdout.lower()

    def test_e7_eco_on_removes_flag(self, tmp_path):
        """E7: memctl eco on → removes flag when config exists."""
        mem_dir = tmp_path / ".memory"
        mem_dir.mkdir()
        (mem_dir / ".eco-disabled").touch()
        eco_dir = tmp_path / ".claude" / "eco"
        eco_dir.mkdir(parents=True)
        (eco_dir / "config.json").write_text('{"db_path": "x"}')
        r = run(["eco", "on"], cwd=str(tmp_path),
                env={"PYTHONPATH": self._PROJECT_ROOT})
        assert r.returncode == 0
        assert not (mem_dir / ".eco-disabled").exists()
        assert "enabled" in r.stdout.lower()

    def test_e8_eco_on_not_installed(self, tmp_path):
        """E8: memctl eco on without config → exit 1."""
        r = run(["eco", "on"], cwd=str(tmp_path),
                env={"PYTHONPATH": self._PROJECT_ROOT})
        assert r.returncode == 1
        assert "not installed" in r.stderr.lower()


# ---------------------------------------------------------------------------
# diff (D15–D19)
# ---------------------------------------------------------------------------


class TestDiffCLI:
    """Tests for memctl diff command (v0.15)."""

    def _write_two_items(self, db):
        """Helper: write two items via pull, return their IDs."""
        items = [
            {"content": "Alpha item content.", "type": "fact", "title": "Alpha"},
            {"content": "Beta item content.", "type": "note", "title": "Beta"},
        ]
        r = run(["pull", "--db", db, "-q"], stdin=json.dumps(items))
        assert r.returncode == 0
        # Extract IDs from stats
        r2 = run(["search", "Alpha", "--db", db, "--json", "-q"])
        assert r2.returncode == 0
        results = json.loads(r2.stdout)
        id1 = results[0]["id"]
        r3 = run(["search", "Beta", "--db", db, "--json", "-q"])
        assert r3.returncode == 0
        results2 = json.loads(r3.stdout)
        id2 = results2[0]["id"]
        return id1, id2

    def test_d15_diff_two_items(self, db):
        """D15: memctl diff ID1 ID2 → exit 0, human output."""
        id1, id2 = self._write_two_items(db)
        r = run(["diff", id1, id2, "--db", db, "-q"])
        assert r.returncode == 0
        assert "Diff:" in r.stdout or "identical" in r.stdout

    def test_d16_diff_json_output(self, db):
        """D16: memctl diff ID1 ID2 --json → valid JSON."""
        id1, id2 = self._write_two_items(db)
        r = run(["diff", id1, id2, "--db", db, "--json", "-q"])
        assert r.returncode == 0
        data = json.loads(r.stdout)
        assert data["status"] == "ok"
        assert "similarity_score" in data
        assert "content_diff" in data

    def test_d17_diff_missing_items(self, db):
        """D17: memctl diff MEM-nope MEM-nope → exit 1."""
        r = run(["diff", "MEM-nope", "MEM-nope2", "--db", db, "-q"])
        assert r.returncode == 1

    def test_d18_diff_same_item(self, db):
        """D18: memctl diff ID1 ID1 → shows 'identical'."""
        id1, _ = self._write_two_items(db)
        r = run(["diff", id1, id1, "--db", db, "-q"])
        assert r.returncode == 0
        assert "identical" in r.stdout.lower()

    def test_d19_diff_latest_revision(self, db):
        """D19: Write + update item, memctl diff ID --latest → shows diff."""
        # Write an item
        items = [{"content": "original content v1", "type": "fact", "title": "Evolving"}]
        r = run(["pull", "--db", db, "-q"], stdin=json.dumps(items))
        assert r.returncode == 0

        # Find it
        r2 = run(["search", "Evolving", "--db", db, "--json", "-q"])
        results = json.loads(r2.stdout)
        item_id = results[0]["id"]

        # Update it (write again with same title but different content via pull)
        # Use the store directly for update — use Python subprocess to ensure revision
        update_script = (
            f"import sys; sys.path.insert(0, '.'); "
            f"from memctl.store import MemoryStore; "
            f"s = MemoryStore(db_path='{db}'); "
            f"s.update_item('{item_id}', {{'content': 'modified content v2'}}); "
            f"s.close()"
        )
        r3 = subprocess.run(
            [sys.executable, "-c", update_script],
            capture_output=True, text=True,
        )
        assert r3.returncode == 0, f"update failed: {r3.stderr}"

        # Now diff --latest
        r4 = run(["diff", item_id, "--latest", "--db", db, "-q"])
        assert r4.returncode == 0
        assert "original" in r4.stdout or "modified" in r4.stdout or "Diff:" in r4.stdout


# ======================================================================
# Doctor
# ======================================================================


class TestDoctor:
    """Tests for memctl doctor — environment health check."""

    def test_doctor_pass(self, populated_db):
        """Healthy populated DB → all checks pass or warn → exit 0."""
        r = run(["doctor", "--db", populated_db, "-q"])
        assert r.returncode == 0

    def test_doctor_json(self, populated_db):
        """JSON output has 'status' + 'checks' array."""
        r = run(["doctor", "--json", "--db", populated_db, "-q"])
        assert r.returncode == 0
        data = json.loads(r.stdout)
        assert "status" in data
        assert "checks" in data
        assert isinstance(data["checks"], list)
        assert data["status"] in ("ok", "warn")

    def test_doctor_no_db(self, tmp_path):
        """Nonexistent DB → warns but exit 0 (no fail)."""
        fake_db = str(tmp_path / "nonexistent" / "memory.db")
        r = run(["doctor", "--json", "--db", fake_db, "-q"])
        assert r.returncode == 0
        data = json.loads(r.stdout)
        assert data["status"] in ("ok", "warn")
        # db_exists should be warn
        db_check = [c for c in data["checks"] if c["name"] == "db_exists"]
        assert len(db_check) == 1
        assert db_check[0]["status"] == "warn"

    def test_doctor_check_names(self, populated_db):
        """All 10 check names present in JSON output."""
        r = run(["doctor", "--json", "--db", populated_db, "-q"])
        assert r.returncode == 0
        data = json.loads(r.stdout)
        names = {c["name"] for c in data["checks"]}
        expected = {
            "python_version", "sqlite3_module", "fts5_support",
            "db_exists", "wal_mode", "schema_version",
            "integrity_check", "policy_patterns", "mcp_server",
            "eco_config",
        }
        assert names == expected

    def test_doctor_schema_version(self, populated_db):
        """Schema version check reports correct value."""
        from memctl.store import SCHEMA_VERSION
        r = run(["doctor", "--json", "--db", populated_db, "-q"])
        data = json.loads(r.stdout)
        sv = [c for c in data["checks"] if c["name"] == "schema_version"]
        assert len(sv) == 1
        assert sv[0]["status"] == "pass"
        assert sv[0]["detail"] == str(SCHEMA_VERSION)

    def test_doctor_exit_code(self, populated_db):
        """Healthy environment → exit code 0."""
        r = run(["doctor", "--db", populated_db, "-q"])
        assert r.returncode == 0
