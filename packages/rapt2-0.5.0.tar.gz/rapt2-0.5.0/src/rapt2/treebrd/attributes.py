import itertools
from collections.abc import Iterator, Sequence
from typing import Any, NamedTuple

from .errors import AttributeReferenceError, InputError


class Attribute(NamedTuple):
    """
    An Attribute is a relational algebra attribute. Attributes have optional
    prefixes which reference the relation they belong to.
    """

    name: str
    prefix: str | None

    @property
    def prefixed(self) -> str:
        """Return the attribute in 'prefix.name' form, or just 'name' if no prefix."""
        if self.prefix:
            return "{pr}.{nm}".format(pr=self.prefix, nm=self.name)
        else:
            return self.name

    def __eq__(self, other: object) -> bool:
        if type(self) is type(other):
            return self.prefixed == other.prefixed  # type: ignore[union-attr]
        return False

    def __ne__(self, other: object) -> bool:
        return not self.__eq__(other)

    def __hash__(self) -> int:
        return hash(self.prefixed)


class AttributeList:
    """
    A AttributeList is an ordered collection of relational algebra attributes.

    Attributes can have a prefix, which reference the relation they belong to.
    """

    @classmethod
    def merge(cls, first: "AttributeList", second: "AttributeList") -> "AttributeList":
        """
        Return an AttributeList that is the result of merging first with second.
        """
        merged = AttributeList([], None)

        if not isinstance(first, AttributeList):
            raise TypeError(f"first must be AttributeList, got {type(first).__name__}")
        if not isinstance(second, AttributeList):
            raise TypeError(
                f"second must be AttributeList, got {type(second).__name__}"
            )
        merged._contents = first._contents[:]
        merged._contents += second._contents[:]

        return merged

    @staticmethod
    def has_duplicates(collection: Sequence[Any]) -> bool:
        """
        Return True if the collection has duplicate elements.
        """
        return len(set(collection)) != len(collection)

    def __init__(self, names: list[str], prefix: str | None) -> None:
        """
        :param names: a list of attribute name strings.
        :param prefix: the relation prefix for all attributes, or None.
        """
        self._contents: list[Attribute] = []
        self.extend(names, prefix)

    def __str__(self) -> str:
        """
        Return a comma delimitted string of prefixed attribute names.
        """
        return ", ".join(self.to_list())

    def __len__(self) -> int:
        return len(self._contents)

    def __eq__(self, other: object) -> bool:
        if type(self) is type(other):
            return self.to_list() == other.to_list()  # type: ignore[union-attr]
        return False

    def __ne__(self, other: object) -> bool:
        return not self.__eq__(other)

    def __iter__(self) -> Iterator[Attribute]:
        return iter(self._contents)

    @property
    def contents(self) -> list[Attribute]:
        """
        Return a list of the Attributes in the AttributeList.
        """
        return self._contents

    @property
    def names(self) -> list[str]:
        """
        Return a list of the names of the Attributes in the AttributeList.
        """
        return [name for name, _ in self._contents]

    def validate(self, references: list[str]) -> None:
        """
        Check if all references exist and are unambiguous.
        """
        for reference in references:
            self.get_attribute(reference)

    def to_list(self) -> list[str]:
        """
        Return a list of attributes. If an attribute has a prefix, return a
        prefixed attribute of the form: prefix.attribute.
        """
        return [attribute.prefixed for attribute in self._contents]

    def get_attribute(self, reference: str) -> Attribute:
        """
        Return the attribute that matches the reference.

        Lookup rules:
        - "name" matches any attribute with that name regardless of prefix.
        - "prefix.name" requires an exact prefix match.

        Raises AttributeReferenceError if zero or multiple attributes match.
        """
        prefix, _, name = reference.rpartition(".")

        match = None
        for attribute in self._contents:
            if name == attribute.name and (not prefix or prefix == attribute.prefix):
                if match:
                    raise AttributeReferenceError(
                        "Ambiguous attribute reference: {}.".format(attribute.name)
                    )
                else:
                    match = attribute

        if match:
            return match
        raise AttributeReferenceError("Attribute does not exist: {}".format(reference))

    def extend(self, attributes: list[str], prefix: str | None) -> None:
        """
        Add the attributes with the specified prefix to the end of the attribute
        list.
        """

        self._contents += [Attribute(attr, prefix) for attr in attributes]

    def trim(self, restriction_list: list[str]) -> None:
        """
        Trim and reorder the attributes to the specifications in a restriction
        list.
        """
        replacement = []
        for reference in restriction_list:
            replacement.append(self.get_attribute(reference))

        if self.has_duplicates(replacement):
            raise AttributeReferenceError("Duplicate attribute reference.")
        self._contents = replacement

    def rename(self, names: list[str], prefix: str | None) -> None:
        """
        Rename the Attributes' names, prefixes, or both. If names or prefix
        evaluates to None, the old version is used.
        Resulting names must be unambiguous.
        :param names: A list of new names for each attribute or an empty list.
        :param prefix: A new prefix for the name or None
        """
        if names:
            if len(names) != len(self._contents):
                raise InputError("Attribute count mismatch.")
            if self.has_duplicates(names):
                raise InputError("Attributes are ambiguous.")
        else:
            # If the attributes are not renamed, but the relation / prefix is,
            # there is a risk of creating two or more attributes with the
            # same name and prefix.
            if prefix and self.has_duplicates(self.names):
                raise AttributeReferenceError("Attributes are ambiguous.")

        replacement = []
        for old, name in itertools.zip_longest(self._contents, names):
            new_name = name or old.name
            new_prefix = prefix or old.prefix
            replacement.append(Attribute(new_name, new_prefix))
        self._contents = replacement
