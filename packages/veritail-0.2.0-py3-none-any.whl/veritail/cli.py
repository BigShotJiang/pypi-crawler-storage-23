"""CLI interface for veritail."""

from __future__ import annotations

import json
import logging
import re
import threading
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import click
from dotenv import find_dotenv, load_dotenv
from rich.console import Console

from veritail.adapter import load_adapter
from veritail.backends import create_backend
from veritail.checks.custom import CustomCheckFn, load_checks
from veritail.llm.client import create_llm_client
from veritail.logging import configure_logging
from veritail.pipeline import (
    run_batch_evaluation,
    run_dual_batch_evaluation,
    run_dual_evaluation,
    run_evaluation,
)
from veritail.queries import load_queries
from veritail.reporting.comparison import generate_comparison_report
from veritail.reporting.single import generate_single_report
from veritail.scaffold import (
    DEFAULT_ADAPTER_FILENAME,
    DEFAULT_QUERIES_FILENAME,
    scaffold_project,
)
from veritail.types import ExperimentConfig, VerticalContext

logger = logging.getLogger(__name__)

console = Console()

# Load environment variables from .env file if it exists
# Search in current directory, then parent directories
load_dotenv(
    find_dotenv(usecwd=True, raise_error_if_not_found=False),
    verbose=False,
    override=False,
)


def _slugify_name(raw: str) -> str:
    """Create a filesystem-safe slug for generated config names."""
    slug = re.sub(r"[^a-z0-9]+", "-", raw.lower()).strip("-")
    return slug or "config"


def _generate_config_names(adapters: tuple[str, ...]) -> tuple[str, ...]:
    """Generate readable, unique config names from adapter paths."""
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    seen: dict[str, int] = {}
    generated: list[str] = []

    for adapter in adapters:
        base = _slugify_name(Path(adapter).stem)
        seen[base] = seen.get(base, 0) + 1
        suffix = f"-{seen[base]}" if seen[base] > 1 else ""
        generated.append(f"{base}{suffix}-{timestamp}")

    return tuple(generated)


def _build_run_metadata(
    *,
    llm_model: str | None = None,
    vertical: str | None = None,
    top_k: int,
    sample: int | None = None,
    total_queries: int | None = None,
    adapter_path: str | None = None,
    adapter_path_a: str | None = None,
    adapter_path_b: str | None = None,
) -> dict[str, object]:
    """Build provenance metadata for report rendering."""
    metadata: dict[str, object] = {
        "generated_at_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "top_k": top_k,
    }
    if llm_model is not None:
        metadata["llm_model"] = llm_model
    if vertical:
        metadata["vertical"] = vertical
    if sample is not None and total_queries is not None:
        metadata["sample"] = f"{sample} of {total_queries}"
    if adapter_path is not None:
        metadata["adapter_path"] = adapter_path
    if adapter_path_a is not None:
        metadata["adapter_path_a"] = adapter_path_a
    if adapter_path_b is not None:
        metadata["adapter_path_b"] = adapter_path_b
    return metadata


_KNOWN_MODEL_PREFIXES = ("claude", "gemini", "gpt-", "o1", "o3", "o4")


def _run_search_pipeline(  # noqa: PLR0913
    *,
    queries_path: str,
    adapters: tuple[str, ...],
    config_names: tuple[str, ...],
    llm_model: str,
    llm_base_url: str | None,
    llm_api_key: str | None,
    backend_type: str,
    output_dir: str,
    backend_url: str | None,
    top_k: int,
    context: str | None,
    vertical_context: VerticalContext | None,
    vertical_raw: str | None,
    check_modules: tuple[str, ...],
    sample: int | None,
    use_batch: bool,
    use_resume: bool,
    search_sibling: str | None,
    cancel_event: threading.Event | None = None,
) -> list[Path]:
    """Run the search evaluation pipeline. Returns list of HTML report paths."""
    logger.debug(
        "search pipeline: model=%s, top_k=%d, backend=%s, batch=%s",
        llm_model,
        top_k,
        backend_type,
        use_batch,
    )
    query_entries = load_queries(queries_path)
    total_queries = len(query_entries)

    if sample is not None and sample < total_queries:
        import random

        rng = random.Random(42)
        query_entries = rng.sample(query_entries, sample)
        console.print(
            f"Sampled {sample} of {total_queries} queries from {queries_path}"
        )
    else:
        console.print(f"Loaded {len(query_entries)} queries from {queries_path}")

    custom_check_fns: list[CustomCheckFn] | None = None
    if check_modules:
        custom_check_fns = []
        for check_path in check_modules:
            loaded = load_checks(check_path)
            custom_check_fns.extend(loaded)
            console.print(
                f"[dim]Loaded {len(loaded)} custom check(s) from {check_path}[/dim]"
            )

    _warn_custom_model(llm_model, llm_base_url)
    llm_client = create_llm_client(
        llm_model, base_url=llm_base_url, api_key=llm_api_key
    )

    try:
        llm_client.preflight_check()
    except RuntimeError as exc:
        raise click.ClickException(str(exc)) from exc

    if use_batch:
        if llm_base_url is not None:
            raise click.UsageError(
                "--batch cannot be used with --llm-base-url. "
                "Batch APIs are only available for cloud providers "
                "(OpenAI, Anthropic, Gemini)."
            )
        if not llm_client.supports_batch():
            raise click.UsageError(
                f"The model '{llm_model}' does not support batch operations."
            )

    backend_kwargs: dict[str, str] = {}
    if backend_type == "file":
        backend_kwargs["output_dir"] = output_dir
    elif backend_type == "langfuse":
        if backend_url:
            backend_kwargs["url"] = backend_url

    backend = create_backend(backend_type, **backend_kwargs)

    html_paths: list[Path] = []

    if len(adapters) == 1:
        # Single configuration
        config = ExperimentConfig(
            name=config_names[0],
            adapter_path=adapters[0],
            llm_model=llm_model,
            top_k=top_k,
        )
        adapter_fn = load_adapter(adapters[0])

        pipeline_fn = run_batch_evaluation if use_batch else run_evaluation
        batch_kwargs: dict[str, Any] = {}
        if use_batch and cancel_event is not None:
            batch_kwargs["cancel_event"] = cancel_event
        judgments, checks, metrics, correction_judgments = pipeline_fn(
            query_entries,
            adapter_fn,
            config,
            llm_client,
            backend,
            context=context,
            vertical=vertical_context,
            custom_checks=custom_check_fns,
            resume=use_resume,
            output_dir=output_dir,
            **batch_kwargs,
        )
        run_metadata = _build_run_metadata(
            llm_model=llm_model,
            vertical=vertical_raw,
            top_k=top_k,
            sample=sample,
            total_queries=total_queries,
            adapter_path=adapters[0],
        )

        report = generate_single_report(
            metrics,
            checks,
            run_metadata=run_metadata,
            correction_judgments=correction_judgments or None,
        )
        console.print(report)

        exp_dir = Path(output_dir) / config_names[0]
        exp_dir.mkdir(parents=True, exist_ok=True)

        metrics_path = exp_dir / "metrics.json"
        metrics_path.write_text(
            json.dumps(
                [asdict(m) for m in metrics],
                indent=2,
                default=str,
            ),
            encoding="utf-8",
        )

        if correction_judgments:
            corrections_path = exp_dir / "corrections.jsonl"
            corrections_path.write_text(
                "\n".join(
                    json.dumps(asdict(cj), default=str) for cj in correction_judgments
                )
                + "\n",
                encoding="utf-8",
            )

        html = generate_single_report(
            metrics,
            checks,
            judgments=judgments,
            format="html",
            run_metadata=run_metadata,
            correction_judgments=correction_judgments or None,
            sibling_report=search_sibling,
        )
        html_path = exp_dir / "report.html"
        html_path.write_text(html, encoding="utf-8")
        console.print(f"[dim]HTML report -> {html_path}[/dim]")
        html_paths.append(html_path)

    else:
        # Dual configuration
        config_a = ExperimentConfig(
            name=config_names[0],
            adapter_path=adapters[0],
            llm_model=llm_model,
            top_k=top_k,
        )
        config_b = ExperimentConfig(
            name=config_names[1],
            adapter_path=adapters[1],
            llm_model=llm_model,
            top_k=top_k,
        )
        adapter_a = load_adapter(adapters[0])
        adapter_b = load_adapter(adapters[1])

        dual_fn = run_dual_batch_evaluation if use_batch else run_dual_evaluation
        dual_batch_kwargs: dict[str, Any] = {}
        if use_batch and cancel_event is not None:
            dual_batch_kwargs["cancel_event"] = cancel_event
        (
            judgments_a,
            judgments_b,
            checks_a,
            checks_b,
            metrics_a,
            metrics_b,
            comparison_checks,
            corrections_a,
            corrections_b,
        ) = dual_fn(
            query_entries,
            adapter_a,
            config_a,
            adapter_b,
            config_b,
            llm_client,
            backend,
            context=context,
            vertical=vertical_context,
            custom_checks=custom_check_fns,
            resume=use_resume,
            output_dir=output_dir,
            **dual_batch_kwargs,
        )
        run_metadata = _build_run_metadata(
            llm_model=llm_model,
            vertical=vertical_raw,
            top_k=top_k,
            sample=sample,
            total_queries=total_queries,
            adapter_path_a=adapters[0],
            adapter_path_b=adapters[1],
        )

        report = generate_comparison_report(
            metrics_a,
            metrics_b,
            comparison_checks,
            config_names[0],
            config_names[1],
            run_metadata=run_metadata,
            correction_judgments_a=corrections_a or None,
            correction_judgments_b=corrections_b or None,
            judgments_a=judgments_a,
            judgments_b=judgments_b,
            checks_a=checks_a,
            checks_b=checks_b,
        )
        console.print(report)

        configs_and_data = [
            (config_names[0], metrics_a, corrections_a),
            (config_names[1], metrics_b, corrections_b),
        ]
        for cfg_name, cfg_metrics, cfg_corrections in configs_and_data:
            exp_dir = Path(output_dir) / cfg_name
            exp_dir.mkdir(parents=True, exist_ok=True)
            metrics_path = exp_dir / "metrics.json"
            metrics_path.write_text(
                json.dumps(
                    [asdict(m) for m in cfg_metrics],
                    indent=2,
                    default=str,
                ),
                encoding="utf-8",
            )
            if cfg_corrections:
                corrections_path = exp_dir / "corrections.jsonl"
                corrections_path.write_text(
                    "\n".join(
                        json.dumps(asdict(cj), default=str) for cj in cfg_corrections
                    )
                    + "\n",
                    encoding="utf-8",
                )

        html = generate_comparison_report(
            metrics_a,
            metrics_b,
            comparison_checks,
            config_names[0],
            config_names[1],
            format="html",
            run_metadata=run_metadata,
            correction_judgments_a=corrections_a or None,
            correction_judgments_b=corrections_b or None,
            sibling_report=search_sibling,
            judgments_a=judgments_a,
            judgments_b=judgments_b,
            checks_a=checks_a,
            checks_b=checks_b,
        )
        cmp_dir = f"{config_names[0]}_vs_{config_names[1]}"
        html_path = Path(output_dir) / cmp_dir / "report.html"
        html_path.parent.mkdir(parents=True, exist_ok=True)
        html_path.write_text(html, encoding="utf-8")
        console.print(f"[dim]HTML report -> {html_path}[/dim]")
        html_paths.append(html_path)

    return html_paths


def _run_autocomplete_pipeline(  # noqa: PLR0913
    *,
    autocomplete_prefixes: str,
    adapters: tuple[str, ...],
    config_names: tuple[str, ...],
    llm_model: str,
    llm_base_url: str | None,
    llm_api_key: str | None,
    backend_type: str,
    backend_url: str | None,
    output_dir: str,
    top_k: int,
    context: str | None,
    vertical_context: VerticalContext | None,
    autocomplete_check_modules: tuple[str, ...],
    sample: int | None,
    use_batch: bool,
    use_resume: bool,
    ac_sibling: str | None,
    cancel_event: threading.Event | None = None,
) -> list[Path]:
    """Run the autocomplete evaluation pipeline. Returns list of HTML report paths."""
    logger.debug(
        "autocomplete pipeline: model=%s, top_k=%d, backend=%s, batch=%s",
        llm_model,
        top_k,
        backend_type,
        use_batch,
    )
    from veritail.autocomplete.adapter import load_suggest_adapter
    from veritail.autocomplete.pipeline import (
        run_autocomplete_evaluation,
        run_dual_autocomplete_evaluation,
    )
    from veritail.autocomplete.queries import load_prefixes
    from veritail.autocomplete.reporting import (
        generate_autocomplete_comparison_report,
        generate_autocomplete_report,
    )
    from veritail.types import AutocompleteConfig

    prefix_entries = load_prefixes(autocomplete_prefixes)
    total_prefixes = len(prefix_entries)

    if sample is not None and sample < total_prefixes:
        import random

        rng = random.Random(42)
        prefix_entries = rng.sample(prefix_entries, sample)
        console.print(
            f"Sampled {sample} of {total_prefixes} prefixes from "
            f"{autocomplete_prefixes}"
        )
    else:
        console.print(
            f"Loaded {len(prefix_entries)} prefixes from {autocomplete_prefixes}"
        )

    # Load autocomplete-specific custom checks
    ac_custom_check_fns = None
    if autocomplete_check_modules:
        import importlib.util

        ac_custom_check_fns = []
        for check_path in autocomplete_check_modules:
            spec = importlib.util.spec_from_file_location(
                "ac_custom_checks", check_path
            )
            if spec is None or spec.loader is None:
                raise click.ClickException(
                    f"Could not load check module from: {check_path}"
                )
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            found = 0
            for name in sorted(dir(mod)):
                if name.startswith("check_") and callable(getattr(mod, name)):
                    ac_custom_check_fns.append(getattr(mod, name))
                    found += 1
            if found == 0:
                raise click.ClickException(
                    f"Check module '{check_path}' has no check_* functions."
                )
            console.print(
                f"[dim]Loaded {found} autocomplete check(s) from {check_path}[/dim]"
            )

    ac_run_metadata = _build_run_metadata(
        top_k=top_k,
        sample=sample,
        total_queries=total_prefixes,
        adapter_path=adapters[0] if len(adapters) == 1 else None,
        adapter_path_a=adapters[0] if len(adapters) == 2 else None,
        adapter_path_b=adapters[1] if len(adapters) == 2 else None,
    )

    html_paths: list[Path] = []

    backend_kwargs: dict[str, str] = {}
    if backend_type == "file":
        backend_kwargs["output_dir"] = output_dir
    elif backend_type == "langfuse":
        if backend_url:
            backend_kwargs["url"] = backend_url
    backend = create_backend(backend_type, **backend_kwargs)

    if len(adapters) == 1:
        ac_run_metadata["llm_model"] = llm_model
        ac_config = AutocompleteConfig(
            name=config_names[0],
            adapter_path=adapters[0],
            top_k=top_k,
        )
        suggest_fn = load_suggest_adapter(adapters[0])

        backend.log_experiment(
            config_names[0],
            {
                "adapter_path": adapters[0],
                "llm_model": llm_model,
                "top_k": top_k,
                "type": "autocomplete",
            },
        )

        ac_checks, ac_responses = run_autocomplete_evaluation(
            prefix_entries,
            suggest_fn,
            ac_config,
            custom_checks=ac_custom_check_fns,
        )

        # ---- LLM suggestion evaluation ----
        from veritail.autocomplete.judge import (
            SUGGESTION_SYSTEM_PROMPT,
            SuggestionJudge,
        )
        from veritail.autocomplete.pipeline import (
            run_autocomplete_llm_evaluation,
        )

        # Create own LLM client
        _warn_custom_model(llm_model, llm_base_url)
        llm_client = create_llm_client(
            llm_model, base_url=llm_base_url, api_key=llm_api_key
        )
        try:
            llm_client.preflight_check()
        except RuntimeError as exc:
            raise click.ClickException(str(exc)) from exc

        if use_batch:
            if llm_base_url is not None:
                raise click.UsageError(
                    "--batch cannot be used with --llm-base-url. "
                    "Batch APIs are only available for cloud providers "
                    "(OpenAI, Anthropic, Gemini)."
                )
            if not llm_client.supports_batch():
                raise click.UsageError(
                    f"The model '{llm_model}' does not support batch operations."
                )

        # Build system prompt with vertical/context prefix
        ac_system_prompt = SUGGESTION_SYSTEM_PROMPT
        prefix_parts: list[str] = []
        if vertical_context:
            prefix_parts.append(f"## Store Vertical\n{vertical_context.core}")
        if context:
            prefix_parts.append(f"## Business Context\n{context}")
        if prefix_parts:
            ac_system_prompt = "\n\n".join(prefix_parts) + "\n\n" + ac_system_prompt

        ac_judge = SuggestionJudge(llm_client, ac_system_prompt, config_names[0])
        if use_batch:
            from veritail.autocomplete.pipeline import (
                run_autocomplete_batch_llm_evaluation,
            )

            ac_suggestion_judgments = run_autocomplete_batch_llm_evaluation(
                prefix_entries,
                ac_responses,
                ac_judge,
                ac_config,
                llm_client,
                poll_interval=60,
                resume=use_resume,
                output_dir=output_dir,
                cancel_event=cancel_event,
            )
        else:
            ac_suggestion_judgments = run_autocomplete_llm_evaluation(
                prefix_entries, ac_responses, ac_judge, ac_config
            )

        # Write suggestion-judgments.jsonl
        exp_dir = Path(output_dir) / config_names[0]
        exp_dir.mkdir(parents=True, exist_ok=True)
        sj_path = exp_dir / "suggestion-judgments.jsonl"
        from dataclasses import asdict as _asdict

        sj_path.write_text(
            "\n".join(
                json.dumps(_asdict(sj), default=str) for sj in ac_suggestion_judgments
            )
            + "\n",
            encoding="utf-8",
        )

        for sj in ac_suggestion_judgments:
            try:
                backend.log_suggestion_judgment(sj)
            except Exception as e:
                console.print(
                    f"[yellow]Warning: failed to log suggestion judgment "
                    f"to backend: {e}[/yellow]"
                )

        ac_report = generate_autocomplete_report(
            ac_checks,
            responses_by_prefix=ac_responses,
            prefixes=prefix_entries,
            suggestion_judgments=ac_suggestion_judgments,
        )
        console.print(ac_report)

        exp_dir = Path(output_dir) / config_names[0]
        exp_dir.mkdir(parents=True, exist_ok=True)

        ac_html = generate_autocomplete_report(
            ac_checks,
            format="html",
            responses_by_prefix=ac_responses,
            prefixes=prefix_entries,
            run_metadata=ac_run_metadata,
            sibling_report=ac_sibling,
            suggestion_judgments=ac_suggestion_judgments,
        )
        ac_html_path = exp_dir / "autocomplete-report.html"
        ac_html_path.write_text(ac_html, encoding="utf-8")
        console.print(f"[dim]Autocomplete HTML report -> {ac_html_path}[/dim]")
        html_paths.append(ac_html_path)

    else:
        ac_config_a = AutocompleteConfig(
            name=config_names[0],
            adapter_path=adapters[0],
            top_k=top_k,
        )
        ac_config_b = AutocompleteConfig(
            name=config_names[1],
            adapter_path=adapters[1],
            top_k=top_k,
        )
        suggest_a = load_suggest_adapter(adapters[0])
        suggest_b = load_suggest_adapter(adapters[1])

        ac_checks_a, ac_checks_b, ac_comparison_checks = (
            run_dual_autocomplete_evaluation(
                prefix_entries,
                suggest_a,
                ac_config_a,
                suggest_b,
                ac_config_b,
                custom_checks=ac_custom_check_fns,
            )
        )

        ac_report = generate_autocomplete_comparison_report(
            ac_checks_a,
            ac_checks_b,
            ac_comparison_checks,
            config_names[0],
            config_names[1],
        )
        console.print(ac_report)

        ac_html = generate_autocomplete_comparison_report(
            ac_checks_a,
            ac_checks_b,
            ac_comparison_checks,
            config_names[0],
            config_names[1],
            format="html",
            run_metadata=ac_run_metadata,
            sibling_report=ac_sibling,
        )
        cmp_dir = f"{config_names[0]}_vs_{config_names[1]}"
        ac_html_path = Path(output_dir) / cmp_dir / "autocomplete-report.html"
        ac_html_path.parent.mkdir(parents=True, exist_ok=True)
        ac_html_path.write_text(ac_html, encoding="utf-8")
        console.print(f"[dim]Autocomplete HTML report -> {ac_html_path}[/dim]")
        html_paths.append(ac_html_path)

    return html_paths


def _warn_custom_model(model: str, base_url: str | None) -> None:
    """Emit a warning when the model name is unrecognized."""
    if any(model.startswith(p) for p in _KNOWN_MODEL_PREFIXES):
        return
    if base_url:
        console.print(
            f"[yellow]Using custom endpoint ({base_url}) with model '{model}'. "
            "Evaluation quality depends on model capability — "
            "for reliable metrics, 70B+ parameter models are recommended.[/yellow]"
        )
    else:
        console.print(
            f"[yellow]Model '{model}' is not a recognized cloud model. "
            "If you are using a local model server, pass --llm-base-url to "
            "specify the endpoint (e.g. --llm-base-url http://localhost:11434/v1).[/yellow]"
        )


@click.group()
@click.version_option(package_name="veritail")
def main() -> None:
    """veritail: Ecommerce search relevance evaluation tool."""


@main.command()
@click.option(
    "--dir",
    "target_dir",
    default=".",
    type=click.Path(file_okay=False, path_type=Path),
    help="Directory where starter files should be created.",
)
@click.option(
    "--adapter-name",
    default=DEFAULT_ADAPTER_FILENAME,
    show_default=True,
    help="Filename for the generated adapter module.",
)
@click.option(
    "--queries-name",
    default=DEFAULT_QUERIES_FILENAME,
    show_default=True,
    help="Filename for the generated query CSV.",
)
@click.option(
    "--force",
    is_flag=True,
    default=False,
    help="Overwrite existing files if they already exist.",
)
def init(
    target_dir: Path,
    adapter_name: str,
    queries_name: str,
    force: bool,
) -> None:
    """Scaffold starter adapter, query, and prefix files."""
    try:
        created = scaffold_project(
            target_dir=target_dir,
            adapter_name=adapter_name,
            queries_name=queries_name,
            force=force,
        )
    except FileExistsError as exc:
        raise click.ClickException(str(exc)) from exc
    except ValueError as exc:
        raise click.UsageError(str(exc)) from exc

    for p in created:
        console.print(f"[green]Created[/green] {p}")
    adapter = created[0].name
    queries = created[1].name
    prefixes = created[2].name
    console.print("\n[dim]Next steps:[/dim]")
    console.print(
        f"[dim]  Search evaluation:[/dim]\n"
        f"[dim]    veritail run --queries {queries} "
        f"--adapter {adapter} --llm-model <model>[/dim]"
    )
    console.print(
        f"[dim]  Autocomplete evaluation:[/dim]\n"
        f"[dim]    veritail run --autocomplete {prefixes} "
        f"--adapter {adapter} --llm-model <model>[/dim]"
    )
    console.print(
        f"[dim]  Both:[/dim]\n"
        f"[dim]    veritail run --queries {queries} "
        f"--autocomplete {prefixes} "
        f"--adapter {adapter} --llm-model <model>[/dim]"
    )
    console.print(
        "\n[dim]Tip: add eval-results/ to .gitignore to avoid committing "
        "catalog data to version control.[/dim]"
    )


@main.group()
def vertical() -> None:
    """Inspect built-in vertical prompts."""
    pass


@vertical.command("list")
def vertical_list() -> None:
    """List all built-in verticals."""
    from veritail.verticals import list_verticals

    for name in list_verticals():
        console.print(name)


@vertical.command("show")
@click.argument("name")
def vertical_show(name: str) -> None:
    """Print the full text of a built-in vertical.

    Use this to inspect a vertical before customizing it, or to copy one
    as a starting point for your own:

        veritail vertical show home-improvement > my_vertical.txt
    """
    from veritail.verticals import load_vertical

    try:
        vc = load_vertical(name)
    except FileNotFoundError as exc:
        raise click.ClickException(str(exc)) from exc

    click.echo(vc.core)


@main.command("generate-queries")
@click.option(
    "--output",
    required=True,
    type=str,
    help="Output CSV path (must end with .csv).",
)
@click.option(
    "--count",
    default=25,
    type=int,
    help=(
        "Target number of queries to generate (approximate — LLMs may "
        "return slightly fewer). Max 50."
    ),
)
@click.option(
    "--vertical",
    default=None,
    type=str,
    help=(
        "Vertical for domain-specific query generation "
        "(built-in name or path to text file)."
    ),
)
@click.option(
    "--context",
    default=None,
    type=str,
    help="Business context string or path to a text file.",
)
@click.option(
    "--llm-model",
    required=True,
    help=(
        "LLM model to use for generation "
        "(e.g. gpt-4o, claude-sonnet-4-5, gemini-2.5-flash)."
    ),
)
@click.option(
    "--llm-base-url",
    default=None,
    help=(
        "Base URL for an OpenAI-compatible API endpoint. "
        "Use this to connect to local model servers "
        "(e.g. http://localhost:11434/v1 for Ollama)."
    ),
)
@click.option(
    "--llm-api-key",
    default=None,
    help="API key override (useful for non-OpenAI endpoints that ignore keys).",
)
@click.option(
    "-v",
    "--verbose",
    is_flag=True,
    default=False,
    help="Enable debug logging to stderr.",
)
def generate_queries_cmd(
    output: str,
    count: int,
    vertical: str | None,
    context: str | None,
    llm_model: str,
    llm_base_url: str | None,
    llm_api_key: str | None,
    verbose: bool,
) -> None:
    """Generate evaluation queries with an LLM and save to CSV."""
    configure_logging(verbose=verbose)
    if count < 1:
        raise click.UsageError("--count must be >= 1.")

    if count > 50:
        raise click.UsageError(
            "--count must be <= 50. For larger query sets, "
            "run the command multiple times or curate queries manually."
        )

    if not output.endswith(".csv"):
        raise click.UsageError("--output must end with .csv.")

    if not vertical and not context:
        raise click.UsageError("At least one of --vertical or --context is required.")

    _warn_custom_model(llm_model, llm_base_url)
    llm_client = create_llm_client(
        llm_model, base_url=llm_base_url, api_key=llm_api_key
    )

    try:
        llm_client.preflight_check()
    except RuntimeError as exc:
        raise click.ClickException(str(exc)) from exc

    from veritail.querygen import generate_queries

    output_path = Path(output)
    try:
        queries = generate_queries(
            llm_client=llm_client,
            output_path=output_path,
            count=count,
            vertical=vertical,
            context=context,
        )
    except (ValueError, FileNotFoundError) as exc:
        raise click.ClickException(str(exc)) from exc

    if len(queries) != count:
        console.print(
            f"[green]Generated {len(queries)} queries[/green] "
            f"[yellow](requested {count})[/yellow] -> {output_path}"
        )
    else:
        console.print(
            f"[green]Generated {len(queries)} queries[/green] -> {output_path}"
        )
    console.print("\n[dim]Next step:[/dim]")
    console.print(
        f"[dim]  veritail run --queries {output_path} "
        f"--adapter <your_adapter.py> --llm-model <model>[/dim]"
    )


@main.command()
@click.option(
    "--queries",
    required=False,
    default=None,
    type=click.Path(exists=True),
    help="Path to query set (CSV or JSON)",
)
@click.option(
    "--adapter",
    "adapters",
    required=False,
    multiple=True,
    type=click.Path(exists=True),
    help="Path to search adapter module(s)",
)
@click.option(
    "--config-name",
    "config_names",
    multiple=True,
    help=(
        "Optional name for each configuration. "
        "Provide one per adapter, or omit to auto-generate names."
    ),
)
@click.option(
    "--autocomplete",
    "autocomplete_prefixes",
    required=False,
    default=None,
    type=click.Path(exists=True),
    help="Path to autocomplete prefix set (CSV or JSON)",
)
@click.option(
    "--llm-model",
    required=False,
    default=None,
    help=(
        "LLM model to use for judgments "
        "(e.g. gpt-4o, claude-sonnet-4-5, gemini-2.5-flash). "
        "Required when --queries is provided."
    ),
)
@click.option(
    "--llm-base-url",
    default=None,
    help=(
        "Base URL for an OpenAI-compatible API endpoint. "
        "Use this to connect to local model servers "
        "(e.g. http://localhost:11434/v1 for Ollama)."
    ),
)
@click.option(
    "--llm-api-key",
    default=None,
    help="API key override (useful for non-OpenAI endpoints that ignore keys).",
)
@click.option(
    "--backend",
    "backend_type",
    default="file",
    type=click.Choice(["file", "langfuse"]),
    help="Evaluation backend",
)
@click.option(
    "--output-dir",
    default="./eval-results",
    help="Output directory (file backend)",
)
@click.option(
    "--backend-url",
    default=None,
    help="Backend URL (langfuse backend)",
)
@click.option(
    "--top-k",
    default=10,
    type=int,
    help="Max results to evaluate per query",
)
@click.option(
    "--open",
    "open_browser",
    is_flag=True,
    default=False,
    help="Open the HTML report in the browser when complete.",
)
@click.option(
    "--context",
    default=None,
    type=str,
    help=(
        "Business context for the LLM judge — describes your business, "
        "customer base, and how queries should be interpreted. "
        "Can include enterprise-specific evaluation guidance such as brand "
        "priorities, certification requirements, or domain jargon. "
        "Accepts a string or a path to a text file."
    ),
)
@click.option(
    "--vertical",
    default=None,
    type=str,
    help=(
        "Vertical for domain-specific scoring guidance "
        "(built-in: automotive, beauty, electronics, fashion, "
        "foodservice, furniture, groceries, home-improvement, "
        "industrial, marketplace, medical, office-supplies, "
        "pet-supplies, sporting-goods, case-insensitive; "
        "or path to a text file)."
    ),
)
@click.option(
    "--checks",
    "check_modules",
    multiple=True,
    type=click.Path(exists=True),
    help="Path to custom check module(s) with check_* functions.",
)
@click.option(
    "--autocomplete-checks",
    "autocomplete_check_modules",
    multiple=True,
    type=click.Path(exists=True),
    help="Path to custom autocomplete check module(s) with check_* functions.",
)
@click.option(
    "--sample",
    default=None,
    type=int,
    help="Randomly sample N queries from the query set for a faster evaluation.",
)
@click.option(
    "--batch",
    "use_batch",
    is_flag=True,
    default=False,
    help="Use provider batch API for LLM calls (50%% cheaper, slower).",
)
@click.option(
    "--resume",
    "use_resume",
    is_flag=True,
    default=False,
    help=(
        "Resume a previously interrupted run. Requires --config-name "
        "to identify the previous run."
    ),
)
@click.option(
    "-v",
    "--verbose",
    is_flag=True,
    default=False,
    help="Enable debug logging to stderr.",
)
def run(
    queries: str | None,
    autocomplete_prefixes: str | None,
    adapters: tuple[str, ...],
    config_names: tuple[str, ...],
    llm_model: str | None,
    llm_base_url: str | None,
    llm_api_key: str | None,
    backend_type: str,
    output_dir: str,
    backend_url: str | None,
    top_k: int,
    open_browser: bool,
    context: str | None,
    vertical: str | None,
    check_modules: tuple[str, ...],
    autocomplete_check_modules: tuple[str, ...],
    sample: int | None,
    use_batch: bool,
    use_resume: bool,
    verbose: bool,
) -> None:
    """Run evaluation (single or dual configuration)."""
    configure_logging(verbose=verbose)
    if not queries and not autocomplete_prefixes:
        raise click.UsageError(
            "Provide --queries, --autocomplete, or both.\n\n"
            "Option 1 - scaffold starter files (adapter + sample queries):\n"
            "  veritail init\n\n"
            "Option 2 - generate domain-aware queries with an LLM:\n"
            "  veritail generate-queries --vertical <vertical> "
            "--output queries.csv --llm-model <model>\n\n"
            "Then run:\n"
            "  veritail run --queries queries.csv "
            "--adapter adapter.py --llm-model <model>"
        )

    if queries and not llm_model:
        raise click.UsageError("--llm-model is required when --queries is provided.")

    if not adapters:
        raise click.UsageError(
            "--adapter is required.\n\n"
            "To scaffold a starter adapter:\n"
            "  veritail init\n\n"
            "Then run:\n"
            "  veritail run --queries queries.csv "
            "--adapter adapter.py --llm-model <model>"
        )

    if config_names and len(adapters) != len(config_names):
        raise click.UsageError(
            "Each --adapter must have a matching "
            "--config-name when names are provided. "
            f"Got {len(adapters)} adapter(s) and "
            f"{len(config_names)} config name(s). "
            "Or omit --config-name to auto-generate names."
        )

    for cn in config_names:
        if "/" in cn or "\\" in cn or ".." in cn:
            raise click.UsageError(
                f"--config-name '{cn}' contains invalid characters. "
                "Config names must not contain path separators or parent references."
            )

    if len(adapters) > 2:
        raise click.UsageError("At most 2 adapter/config-name pairs are supported.")

    if top_k < 1:
        raise click.UsageError("--top-k must be >= 1.")

    if autocomplete_prefixes and len(adapters) == 1 and not llm_model:
        raise click.UsageError("--llm-model is required for autocomplete evaluation.")

    if use_resume and backend_type == "langfuse":
        raise click.UsageError(
            "--resume is not supported with --backend langfuse. "
            "The Langfuse backend is write-only and cannot retrieve "
            "previous judgments. Use --backend file for resumable runs."
        )

    if use_resume and not config_names:
        raise click.UsageError(
            "--resume requires --config-name to identify the previous run."
        )

    if not config_names:
        config_names = _generate_config_names(adapters)
        console.print(
            "[dim]No --config-name provided. Using generated names: "
            f"{', '.join(config_names)}[/dim]",
        )

    if sample is not None and sample < 1:
        raise click.UsageError("--sample must be >= 1.")

    if use_resume:
        # Verify experiment directory exists for each config
        for cn in config_names:
            exp_dir = Path(output_dir) / cn
            if not exp_dir.exists():
                raise click.UsageError(
                    f"--resume: experiment directory '{exp_dir}' does not exist. "
                    "Cannot resume a run that never started."
                )
            # Config mismatch detection
            config_file = exp_dir / "config.json"
            if config_file.exists():
                with open(config_file, encoding="utf-8") as f:
                    saved = json.load(f)
                mismatches: list[str] = []
                if saved.get("llm_model") != llm_model:
                    mismatches.append(
                        f"  llm_model: saved={saved.get('llm_model')!r}, "
                        f"current={llm_model!r}"
                    )
                if saved.get("top_k") != top_k:
                    mismatches.append(
                        f"  top_k: saved={saved.get('top_k')!r}, current={top_k!r}"
                    )
                if mismatches:
                    detail = "\n".join(mismatches)
                    raise click.UsageError(
                        f"--resume: config mismatch for '{cn}':\n{detail}\n"
                        "Drop --resume to start a fresh run, or fix the "
                        "arguments to match the previous run."
                    )

    # ---- Validate suggest adapter availability if autocomplete requested ----
    if autocomplete_prefixes:
        from veritail.autocomplete.adapter import load_suggest_adapter

        for adapter_path in adapters:
            try:
                load_suggest_adapter(adapter_path)
            except AttributeError:
                raise click.UsageError(
                    f"--autocomplete requires a suggest() function in adapter "
                    f"'{adapter_path}', but none was found."
                )

    # ---- Determine cross-link siblings ----
    # When both search and autocomplete run, their HTML reports link to each other.
    search_sibling = "autocomplete-report.html" if autocomplete_prefixes else None
    ac_sibling = "report.html" if queries else None

    # ---- Resolve context and vertical (shared by search and autocomplete) ----
    if context and Path(context).is_file():
        context = Path(context).read_text(encoding="utf-8").rstrip()
        logger.debug("loaded context from file (%d chars)", len(context))

    vertical_context: VerticalContext | None = None
    if vertical:
        from veritail.verticals import load_vertical

        vertical_context = load_vertical(vertical)
        overlays = vertical_context.overlays
        overlay_count = len(overlays) if overlays else 0
        logger.debug(
            "vertical loaded: %s, core=%d chars, overlays=%d",
            vertical,
            len(vertical_context.core),
            overlay_count,
        )

    # ---- Run evaluations ----
    modes = []
    if queries:
        modes.append("search")
    if autocomplete_prefixes:
        modes.append("autocomplete")
    dual = len(adapters) == 2
    logger.debug(
        "evaluation mode: %s, %s, %s",
        "+".join(modes),
        "batch" if use_batch else "sync",
        "dual" if dual else "single",
    )
    output_dir_is_new = backend_type == "file" and not Path(output_dir).exists()
    html_paths: list[Path] = []
    cancel_event: threading.Event | None = None

    def _do_search() -> list[Path]:
        assert queries is not None
        assert llm_model is not None
        return _run_search_pipeline(
            queries_path=queries,
            adapters=adapters,
            config_names=config_names,
            llm_model=llm_model,
            llm_base_url=llm_base_url,
            llm_api_key=llm_api_key,
            backend_type=backend_type,
            output_dir=output_dir,
            backend_url=backend_url,
            top_k=top_k,
            context=context,
            vertical_context=vertical_context,
            vertical_raw=vertical,
            check_modules=check_modules,
            sample=sample,
            use_batch=use_batch,
            use_resume=use_resume,
            search_sibling=search_sibling,
            cancel_event=cancel_event,
        )

    def _do_autocomplete() -> list[Path]:
        assert autocomplete_prefixes is not None
        assert llm_model is not None
        return _run_autocomplete_pipeline(
            autocomplete_prefixes=autocomplete_prefixes,
            adapters=adapters,
            config_names=config_names,
            llm_model=llm_model,
            llm_base_url=llm_base_url,
            llm_api_key=llm_api_key,
            backend_type=backend_type,
            backend_url=backend_url,
            output_dir=output_dir,
            top_k=top_k,
            context=context,
            vertical_context=vertical_context,
            autocomplete_check_modules=autocomplete_check_modules,
            sample=sample,
            use_batch=use_batch,
            use_resume=use_resume,
            ac_sibling=ac_sibling,
            cancel_event=cancel_event,
        )

    # Concurrent path: both search and autocomplete in batch mode
    if queries and autocomplete_prefixes and use_batch:
        from concurrent.futures import ThreadPoolExecutor, as_completed

        from veritail.batch_utils import BatchCancelledError

        cancel_event = threading.Event()

        with ThreadPoolExecutor(max_workers=2) as executor:
            search_future = executor.submit(_do_search)
            ac_future = executor.submit(_do_autocomplete)

            errors: list[Exception] = []
            for future in as_completed([search_future, ac_future]):
                try:
                    future.result()
                except BatchCancelledError:
                    pass  # Side effect of the other thread's real failure
                except Exception as exc:
                    errors.append(exc)
                    cancel_event.set()  # Signal the other thread to stop

        if errors:
            msg = "; ".join(str(e) for e in errors)
            raise click.ClickException(msg)

        html_paths = search_future.result() + ac_future.result()

    else:
        # Sequential path
        if queries:
            html_paths.extend(_do_search())

        if autocomplete_prefixes:
            html_paths.extend(_do_autocomplete())

    # ---- Open report in browser ----
    if open_browser and html_paths:
        import webbrowser

        # Open only the first (primary) report — the cross-link banner
        # lets the user navigate to the sibling report from within it.
        webbrowser.open(html_paths[0].resolve().as_uri())
    elif html_paths:
        console.print(
            "\n  [bold]Tip:[/bold] use [cyan]--open[/cyan] "
            "to view the report in your browser\n"
        )

    if output_dir_is_new:
        console.print(
            f"  [bold]Tip:[/bold] add [cyan]{output_dir}/[/cyan] to "
            "[cyan].gitignore[/cyan] to avoid committing catalog data.\n"
        )


if __name__ == "__main__":
    main()
