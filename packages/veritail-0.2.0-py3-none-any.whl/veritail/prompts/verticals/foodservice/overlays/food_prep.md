### Food Prep — Scoring Guidance

This query involves powered food preparation equipment.

**Critical distinctions to enforce:**

- **Machine type**: Mixer vs food processor vs slicer vs chopper are different categories.
- **Capacity and size**: Quart capacity, bowl size, blade diameter, and throughput are hard constraints when specified.
- **Voltage and phase**: Many larger machines require 208/240V or three-phase.
