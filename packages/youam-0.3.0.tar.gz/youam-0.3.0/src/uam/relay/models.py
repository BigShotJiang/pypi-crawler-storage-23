"""Pydantic request/response models for the relay REST API."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class RegisterRequest(BaseModel):
    agent_name: str
    public_key: str
    webhook_url: str | None = None


class RegisterResponse(BaseModel):
    address: str
    token: str
    relay: str


class SendRequest(BaseModel):
    envelope: dict[str, Any]


class SendResponse(BaseModel):
    message_id: str
    delivered: bool


class InboxResponse(BaseModel):
    address: str
    messages: list[dict[str, Any]]
    count: int


class PublicKeyResponse(BaseModel):
    address: str
    public_key: str
    tier: int = 1
    verified_domain: str | None = None


class HealthResponse(BaseModel):
    status: str
    agents_online: int
    version: str


# ---------------------------------------------------------------------------
# Demo widget models
# ---------------------------------------------------------------------------


class CreateSessionResponse(BaseModel):
    session_id: str
    address: str


class DemoSendRequest(BaseModel):
    session_id: str
    to_address: str
    message: str


class DemoSendResponse(BaseModel):
    message_id: str


class DemoMessage(BaseModel):
    from_address: str
    content: str
    timestamp: str
    message_id: str


class DemoInboxResponse(BaseModel):
    messages: list[DemoMessage]


# ---------------------------------------------------------------------------
# Domain verification models (DNS-04)
# ---------------------------------------------------------------------------


class VerifyDomainRequest(BaseModel):
    domain: str


class VerifyDomainResponse(BaseModel):
    status: str  # "verified" | "failed"
    domain: str
    tier: int
    detail: str | None = None


# ---------------------------------------------------------------------------
# Webhook delivery models (HOOK-01, HOOK-06)
# ---------------------------------------------------------------------------


class WebhookUrlRequest(BaseModel):
    webhook_url: str


class WebhookUrlResponse(BaseModel):
    address: str
    webhook_url: str | None


class WebhookDeliveryRecord(BaseModel):
    id: int
    message_id: str
    status: str
    attempt_count: int
    last_status_code: int | None = None
    last_error: str | None = None
    created_at: str
    completed_at: str | None = None


class WebhookDeliveryListResponse(BaseModel):
    address: str
    deliveries: list[WebhookDeliveryRecord]
    count: int


# ---------------------------------------------------------------------------
# Admin / spam defense models (SPAM-05)
# ---------------------------------------------------------------------------


class BlocklistRequest(BaseModel):
    pattern: str  # "spammer::evil.com" or "*::evil.com"
    reason: str | None = None


class BlocklistEntry(BaseModel):
    id: int
    pattern: str
    reason: str | None = None
    created_at: str


class BlocklistListResponse(BaseModel):
    entries: list[BlocklistEntry]
    count: int


class AllowlistRequest(BaseModel):
    pattern: str
    reason: str | None = None


class AllowlistEntry(BaseModel):
    id: int
    pattern: str
    reason: str | None = None
    created_at: str


class AllowlistListResponse(BaseModel):
    entries: list[AllowlistEntry]
    count: int


class ReputationResponse(BaseModel):
    address: str
    score: int
    tier: str
    messages_sent: int
    messages_rejected: int
    created_at: str
    updated_at: str


class SetReputationRequest(BaseModel):
    score: int  # 0-100


# ---------------------------------------------------------------------------
# Presence models (PRES-01)
# ---------------------------------------------------------------------------


class PresenceResponse(BaseModel):
    address: str
    online: bool
    last_seen: str | None = None


# ---------------------------------------------------------------------------
# Federation models (FED-01)
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Agent management models (RELAY-08, RELAY-09, RELAY-15)
# ---------------------------------------------------------------------------


class UpdateAgentRequest(BaseModel):
    display_name: str | None = None
    contact_card: dict[str, Any] | None = None
    public_key: str | None = None


class AgentResponse(BaseModel):
    address: str
    public_key: str
    status: str
    display_name: str | None = None
    webhook_url: str | None = None
    last_seen: str | None = None
    created_at: str


# ---------------------------------------------------------------------------
# Thread / receipt models (RELAY-10, RELAY-16)
# ---------------------------------------------------------------------------


class ThreadResponse(BaseModel):
    thread_id: str
    messages: list[dict[str, Any]]
    count: int


class ReceiptRequest(BaseModel):
    type: str  # e.g. "receipt.read"
    timestamp: str | None = None


class ReceiptResponse(BaseModel):
    status: str
    message_id: str


# ---------------------------------------------------------------------------
# Handshake models (RELAY-11)
# ---------------------------------------------------------------------------


class HandshakeSendRequest(BaseModel):
    to_address: str
    contact_card: dict[str, Any] | None = None


class HandshakeResponse(BaseModel):
    id: int
    status: str
    from_addr: str
    to_addr: str


class HandshakeRespondRequest(BaseModel):
    response: str  # "approved" | "denied"


class HandshakeListResponse(BaseModel):
    handshakes: list[HandshakeResponse]
    count: int


# ---------------------------------------------------------------------------
# Expanded admin models (RELAY-12)
# ---------------------------------------------------------------------------


class AdminAgentResponse(BaseModel):
    address: str
    public_key: str
    status: str
    display_name: str | None = None
    webhook_url: str | None = None
    last_seen: str | None = None
    created_at: str
    updated_at: str
    deleted_at: str | None = None


class AdminAgentListResponse(BaseModel):
    agents: list[AdminAgentResponse]
    count: int


class AuditLogEntry(BaseModel):
    id: int
    action: str
    entity_type: str
    entity_id: str
    actor_address: str | None = None
    timestamp: str
    details: dict[str, Any] | None = None
    ip_address: str | None = None


class AuditLogResponse(BaseModel):
    entries: list[AuditLogEntry]
    count: int


class PurgeExpiredResponse(BaseModel):
    purged: int


class AdminHealthResponse(BaseModel):
    status: str  # "healthy" or "degraded"
    db_ok: bool
    queue_depth: int
    ws_connections: int
    uptime_seconds: float
    migration_version: str | None = None


# ---------------------------------------------------------------------------
# Federation models (FED-01)
# ---------------------------------------------------------------------------


class FederationDeliverRequest(BaseModel):
    envelope: dict[str, Any]
    via: list[str] = []
    hop_count: int = 0
    timestamp: str
    from_relay: str


class FederationDeliverResponse(BaseModel):
    status: str  # "delivered" | "queued" | "rejected"
    detail: str | None = None


class WellKnownRelayResponse(BaseModel):
    relay_domain: str
    federation_endpoint: str
    public_key: str
    version: str = "0.1"
