"""MCP tool definitions — 25 tools across 7 categories.

Categories: Discovery (2), Creation (5), Lifecycle (3), Query (6), Graph (5),
Session (2), Analysis (2).
Each tool has a ``_<name>_impl`` function testable without the mcp package.
``register_tools()`` wraps them with FastMCP decorators.
(DESIGN.md Section 16)
"""

from __future__ import annotations

from typing import Any

from ztlctl.services.contracts import (
    AgentContextFallbackData,
    AgentContextResultData,
    dump_validated,
)
from ztlctl.services.result import ServiceResult

_TOOL_CATALOG: tuple[dict[str, str], ...] = (
    {
        "name": "discover_tools",
        "category": "discovery",
        "description": "List available MCP tools grouped by category.",
    },
    {
        "name": "list_tags",
        "category": "discovery",
        "description": "List known tags with usage counts.",
    },
    {"name": "create_note", "category": "creation", "description": "Create a new note."},
    {
        "name": "create_reference",
        "category": "creation",
        "description": "Create a new reference.",
    },
    {"name": "create_task", "category": "creation", "description": "Create a new task."},
    {"name": "create_log", "category": "creation", "description": "Start a new session."},
    {
        "name": "update_content",
        "category": "lifecycle",
        "description": "Update a content item.",
    },
    {
        "name": "close_content",
        "category": "lifecycle",
        "description": "Archive/close a content item.",
    },
    {
        "name": "reweave",
        "category": "lifecycle",
        "description": "Run reweave on content.",
    },
    {"name": "search", "category": "query", "description": "Full-text search."},
    {
        "name": "get_document",
        "category": "query",
        "description": "Get a document by ID.",
    },
    {
        "name": "get_related",
        "category": "query",
        "description": "Get related content via graph traversal.",
    },
    {
        "name": "agent_context",
        "category": "query",
        "description": "Build agent context from vault state.",
    },
    {
        "name": "session_close",
        "category": "session",
        "description": "Close the active session.",
    },
    {
        "name": "session_status",
        "category": "session",
        "description": "Get the active session, if any.",
    },
    # --- Tier 1 additions ---
    {
        "name": "list_items",
        "category": "query",
        "description": "List vault items with filtering by type/status/tag/topic/maturity.",
    },
    {
        "name": "work_queue",
        "category": "query",
        "description": "Get prioritized actionable tasks.",
    },
    {
        "name": "decision_support",
        "category": "analysis",
        "description": "Aggregate decision context for a topic.",
    },
    {
        "name": "vault_review",
        "category": "analysis",
        "description": "Build a review-ready vault health snapshot.",
    },
    {
        "name": "graph_themes",
        "category": "graph",
        "description": "Detect knowledge communities via graph clustering.",
    },
    {
        "name": "graph_rank",
        "category": "graph",
        "description": "Rank content by importance via PageRank.",
    },
    {
        "name": "graph_path",
        "category": "graph",
        "description": "Find connection path between two items.",
    },
    {
        "name": "graph_gaps",
        "category": "graph",
        "description": "Identify structural holes in the knowledge graph.",
    },
    {
        "name": "graph_bridges",
        "category": "graph",
        "description": "Find bridge notes via betweenness centrality.",
    },
    {
        "name": "garden_seed",
        "category": "creation",
        "description": "Quick-capture a seed note with minimal ceremony.",
    },
)


def tool_catalog() -> tuple[dict[str, str], ...]:
    """Return the MCP tool catalog for validation and docs."""
    return _TOOL_CATALOG


def _to_mcp_response(result: ServiceResult) -> dict[str, Any]:
    """Convert a ServiceResult to an MCP-friendly dict."""
    response: dict[str, Any] = {
        "ok": result.ok,
        "op": result.op,
        "data": result.data,
    }
    if result.warnings:
        response["warnings"] = result.warnings
    if result.error is not None:
        response["error"] = {
            "code": result.error.code,
            "message": result.error.message,
        }
    return response


# ---------------------------------------------------------------------------
# Discovery tools (2)
# ---------------------------------------------------------------------------


def discover_tools_impl(_vault: Any, *, category: str | None = None) -> dict[str, Any]:
    """List available MCP tools grouped by category.

    If *category* is provided, only tools in that category are returned.
    """
    selected_category = category.lower().strip() if category else None

    selected = [
        tool
        for tool in _TOOL_CATALOG
        if selected_category is None or tool["category"] == selected_category
    ]

    grouped: dict[str, list[dict[str, str]]] = {}
    for tool in selected:
        grouped.setdefault(tool["category"], []).append(
            {
                "name": tool["name"],
                "description": tool["description"],
            }
        )

    grouped_items: list[tuple[str, list[dict[str, str]]]] = sorted(
        grouped.items(), key=lambda item: item[0]
    )
    categories: list[dict[str, Any]] = []
    for cat, tools in grouped_items:
        categories.append({"name": cat, "tools": sorted(tools, key=_tool_name_key)})
    return {
        "ok": True,
        "op": "discover_tools",
        "data": {
            "count": len(selected),
            "total_count": len(_TOOL_CATALOG),
            "categories": categories,
        },
    }


def _tool_name_key(tool: dict[str, str]) -> str:
    """Sort MCP catalog entries by tool name."""
    return tool["name"]


def list_tags_impl(
    vault: Any,
    *,
    prefix: str | None = None,
    limit: int = 100,
) -> dict[str, Any]:
    """List active tags with usage counts."""
    from ztlctl.services.query import QueryService

    result = QueryService(vault).list_tags(prefix=prefix, limit=limit)
    return _to_mcp_response(result)


# ---------------------------------------------------------------------------
# Creation tools (5)
# ---------------------------------------------------------------------------


def create_note_impl(
    vault: Any,
    title: str,
    *,
    subtype: str | None = None,
    tags: list[str] | None = None,
    topic: str | None = None,
    body: str | None = None,
    key_points: list[str] | None = None,
    links: dict[str, list[str]] | None = None,
    aliases: list[str] | None = None,
) -> dict[str, Any]:
    """Create a new note."""
    from ztlctl.services.create import CreateService

    result = CreateService(vault).create_note(
        title,
        subtype=subtype,
        tags=tags,
        topic=topic,
        body=body,
        key_points=key_points,
        links=links,
        aliases=aliases,
    )
    return _to_mcp_response(result)


def create_reference_impl(
    vault: Any,
    title: str,
    *,
    url: str | None = None,
    subtype: str | None = None,
    tags: list[str] | None = None,
    topic: str | None = None,
) -> dict[str, Any]:
    """Create a new reference."""
    from ztlctl.services.create import CreateService

    result = CreateService(vault).create_reference(
        title,
        url=url,
        subtype=subtype,
        tags=tags,
        topic=topic,
    )
    return _to_mcp_response(result)


def create_task_impl(
    vault: Any,
    title: str,
    *,
    priority: str = "medium",
    impact: str = "medium",
    effort: str = "medium",
    tags: list[str] | None = None,
) -> dict[str, Any]:
    """Create a new task."""
    from ztlctl.services.create import CreateService

    result = CreateService(vault).create_task(
        title, priority=priority, impact=impact, effort=effort, tags=tags
    )
    return _to_mcp_response(result)


def create_log_impl(vault: Any, topic: str) -> dict[str, Any]:
    """Start a new session (creates a log entry)."""
    from ztlctl.services.session import SessionService

    result = SessionService(vault).start(topic)
    return _to_mcp_response(result)


def garden_seed_impl(
    vault: Any,
    title: str,
    *,
    tags: list[str] | None = None,
    topic: str | None = None,
) -> dict[str, Any]:
    """Quick-capture a seed note with minimal ceremony."""
    from ztlctl.services.create import CreateService

    result = CreateService(vault).create_note(title, maturity="seed", tags=tags, topic=topic)
    return _to_mcp_response(result)


# ---------------------------------------------------------------------------
# Lifecycle tools (3)
# ---------------------------------------------------------------------------


def update_content_impl(
    vault: Any,
    content_id: str,
    *,
    changes: dict[str, Any],
) -> dict[str, Any]:
    """Update a content item."""
    from ztlctl.services.update import UpdateService

    result = UpdateService(vault).update(content_id, changes=changes)
    return _to_mcp_response(result)


def close_content_impl(vault: Any, content_id: str) -> dict[str, Any]:
    """Archive/close a content item."""
    from ztlctl.services.update import UpdateService

    result = UpdateService(vault).archive(content_id)
    return _to_mcp_response(result)


def reweave_impl(
    vault: Any,
    *,
    content_id: str | None = None,
    dry_run: bool = False,
) -> dict[str, Any]:
    """Run reweave on a content item."""
    from ztlctl.services.reweave import ReweaveService

    result = ReweaveService(vault).reweave(content_id=content_id, dry_run=dry_run)
    return _to_mcp_response(result)


# ---------------------------------------------------------------------------
# Query tools (6)
# ---------------------------------------------------------------------------


def search_impl(
    vault: Any,
    query: str,
    *,
    content_type: str | None = None,
    tag: str | None = None,
    space: str | None = None,
    rank_by: str = "relevance",
    limit: int = 20,
) -> dict[str, Any]:
    """Full-text search."""
    from ztlctl.services.query import QueryService

    result = QueryService(vault).search(
        query, content_type=content_type, tag=tag, space=space, rank_by=rank_by, limit=limit
    )
    return _to_mcp_response(result)


def get_document_impl(vault: Any, content_id: str) -> dict[str, Any]:
    """Get a single document by ID."""
    from ztlctl.services.query import QueryService

    result = QueryService(vault).get(content_id)
    return _to_mcp_response(result)


def get_related_impl(
    vault: Any,
    content_id: str,
    *,
    depth: int = 2,
    top: int = 20,
) -> dict[str, Any]:
    """Get related content via graph traversal."""
    from ztlctl.services.graph import GraphService

    result = GraphService(vault).related(content_id, depth=depth, top=top)
    return _to_mcp_response(result)


def agent_context_impl(
    vault: Any,
    *,
    query: str | None = None,
    limit: int = 5,
) -> dict[str, Any]:
    """Build agent context from vault state.

    Delegates to SessionService.context() when a session is active.
    Falls back to QueryService-based context when no session is open.
    """
    from ztlctl.services.session import SessionService

    # Try session-based context first
    result = SessionService(vault).context(topic=query)
    if result.ok:
        payload = dump_validated(AgentContextResultData, result.data)
        return {"ok": True, "op": "agent_context", "data": payload}

    # Fallback: no active session — use QueryService directly
    from ztlctl.services.query import QueryService

    svc = QueryService(vault)

    context: dict[str, Any] = {}

    # Overview: counts by type
    count_result = svc.count_items()
    if count_result.ok:
        context["total_items"] = count_result.data.get("count", 0)

    # Recent items
    recent = svc.list_items(sort="recency", limit=limit)
    if recent.ok:
        context["recent"] = recent.data.get("items", [])

    # Search results if query provided
    if query:
        search_result = svc.search(query, limit=limit)
        if search_result.ok:
            context["search_results"] = search_result.data.get("items", [])

    # Work queue
    work_result = svc.work_queue()
    if work_result.ok:
        context["work_queue"] = work_result.data.get("items", [])

    payload = dump_validated(AgentContextFallbackData, context)
    return {"ok": True, "op": "agent_context", "data": payload}


def list_items_impl(
    vault: Any,
    *,
    content_type: str | None = None,
    status: str | None = None,
    tag: str | None = None,
    topic: str | None = None,
    subtype: str | None = None,
    maturity: str | None = None,
    space: str | None = None,
    since: str | None = None,
    include_archived: bool = False,
    sort: str = "recency",
    limit: int = 20,
) -> dict[str, Any]:
    """List vault items with filtering."""
    from ztlctl.services.query import QueryService

    result = QueryService(vault).list_items(
        content_type=content_type,
        status=status,
        tag=tag,
        topic=topic,
        subtype=subtype,
        maturity=maturity,
        space=space,
        since=since,
        include_archived=include_archived,
        sort=sort,
        limit=limit,
    )
    return _to_mcp_response(result)


def work_queue_impl(
    vault: Any,
    *,
    space: str | None = None,
) -> dict[str, Any]:
    """Get prioritized actionable tasks."""
    from ztlctl.services.query import QueryService

    result = QueryService(vault).work_queue(space=space)
    return _to_mcp_response(result)


def decision_support_impl(
    vault: Any,
    *,
    topic: str | None = None,
    space: str | None = None,
) -> dict[str, Any]:
    """Aggregate decision context for a topic."""
    from ztlctl.services.query import QueryService

    result = QueryService(vault).decision_support(topic=topic, space=space)
    return _to_mcp_response(result)


def vault_review_impl(
    vault: Any,
    *,
    top: int = 10,
    stale_days: int = 7,
) -> dict[str, Any]:
    """Aggregate a review-ready vault snapshot."""
    from ztlctl.services.query import QueryService

    result = QueryService(vault).vault_review(top=top, stale_days=stale_days)
    return _to_mcp_response(result)


# ---------------------------------------------------------------------------
# Graph tools (5)
# ---------------------------------------------------------------------------


def graph_themes_impl(vault: Any) -> dict[str, Any]:
    """Detect knowledge communities via graph clustering."""
    from ztlctl.services.graph import GraphService

    result = GraphService(vault).themes()
    return _to_mcp_response(result)


def graph_rank_impl(vault: Any, *, top: int = 20) -> dict[str, Any]:
    """Rank content by importance via PageRank."""
    from ztlctl.services.graph import GraphService

    result = GraphService(vault).rank(top=top)
    return _to_mcp_response(result)


def graph_path_impl(
    vault: Any,
    source_id: str,
    target_id: str,
) -> dict[str, Any]:
    """Find connection path between two items."""
    from ztlctl.services.graph import GraphService

    result = GraphService(vault).path(source_id, target_id)
    return _to_mcp_response(result)


def graph_gaps_impl(vault: Any, *, top: int = 20) -> dict[str, Any]:
    """Identify structural holes in the knowledge graph."""
    from ztlctl.services.graph import GraphService

    result = GraphService(vault).gaps(top=top)
    return _to_mcp_response(result)


def graph_bridges_impl(vault: Any, *, top: int = 20) -> dict[str, Any]:
    """Find bridge notes via betweenness centrality."""
    from ztlctl.services.graph import GraphService

    result = GraphService(vault).bridges(top=top)
    return _to_mcp_response(result)


# ---------------------------------------------------------------------------
# Session tools (2)
# ---------------------------------------------------------------------------


def session_close_impl(vault: Any, *, summary: str | None = None) -> dict[str, Any]:
    """Close the active session."""
    from ztlctl.services.session import SessionService

    result = SessionService(vault).close(summary=summary)
    return _to_mcp_response(result)


def session_status_impl(vault: Any) -> dict[str, Any]:
    """Get the active session, if any."""
    from ztlctl.services.session import SessionService

    result = SessionService(vault).status()
    return _to_mcp_response(result)


# ---------------------------------------------------------------------------
# Registration — wraps _impl functions with FastMCP decorators
# ---------------------------------------------------------------------------


def register_tools(server: Any, vault: Any) -> None:
    """Register all MCP tools on the FastMCP server."""

    @server.tool()  # type: ignore[untyped-decorator]
    def discover_tools(category: str | None = None) -> dict[str, Any]:
        """List available MCP tools grouped by category."""
        return discover_tools_impl(vault, category=category)

    @server.tool()  # type: ignore[untyped-decorator]
    def list_tags(prefix: str | None = None, limit: int = 100) -> dict[str, Any]:
        """List known tags with usage counts."""
        return list_tags_impl(vault, prefix=prefix, limit=limit)

    @server.tool()  # type: ignore[untyped-decorator]
    def create_note(
        title: str,
        subtype: str | None = None,
        tags: list[str] | None = None,
        topic: str | None = None,
        body: str | None = None,
        key_points: list[str] | None = None,
        links: dict[str, list[str]] | None = None,
        aliases: list[str] | None = None,
    ) -> dict[str, Any]:
        """Create a new note in the vault."""
        return create_note_impl(
            vault,
            title,
            subtype=subtype,
            tags=tags,
            topic=topic,
            body=body,
            key_points=key_points,
            links=links,
            aliases=aliases,
        )

    @server.tool()  # type: ignore[untyped-decorator]
    def create_reference(
        title: str,
        url: str | None = None,
        subtype: str | None = None,
        tags: list[str] | None = None,
        topic: str | None = None,
    ) -> dict[str, Any]:
        """Create a new reference to an external source."""
        return create_reference_impl(
            vault,
            title,
            url=url,
            subtype=subtype,
            tags=tags,
            topic=topic,
        )

    @server.tool()  # type: ignore[untyped-decorator]
    def create_task(
        title: str,
        priority: str = "medium",
        impact: str = "medium",
        effort: str = "medium",
        tags: list[str] | None = None,
    ) -> dict[str, Any]:
        """Create a new task with priority/impact/effort matrix."""
        return create_task_impl(
            vault, title, priority=priority, impact=impact, effort=effort, tags=tags
        )

    @server.tool()  # type: ignore[untyped-decorator]
    def create_log(topic: str) -> dict[str, Any]:
        """Start a new session (creates a log entry)."""
        return create_log_impl(vault, topic)

    @server.tool()  # type: ignore[untyped-decorator]
    def garden_seed(
        title: str,
        tags: list[str] | None = None,
        topic: str | None = None,
    ) -> dict[str, Any]:
        """Quick-capture a seed note with minimal ceremony."""
        return garden_seed_impl(vault, title, tags=tags, topic=topic)

    @server.tool()  # type: ignore[untyped-decorator]
    def update_content(content_id: str, changes: dict[str, Any]) -> dict[str, Any]:
        """Update a content item's fields."""
        return update_content_impl(vault, content_id, changes=changes)

    @server.tool()  # type: ignore[untyped-decorator]
    def close_content(content_id: str) -> dict[str, Any]:
        """Archive/close a content item."""
        return close_content_impl(vault, content_id)

    @server.tool()  # type: ignore[untyped-decorator]
    def reweave(
        content_id: str | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Run link suggestion and creation on a content item."""
        return reweave_impl(vault, content_id=content_id, dry_run=dry_run)

    @server.tool()  # type: ignore[untyped-decorator]
    def search(
        query: str,
        content_type: str | None = None,
        tag: str | None = None,
        space: str | None = None,
        rank_by: str = "relevance",
        limit: int = 20,
    ) -> dict[str, Any]:
        """Full-text search across the vault."""
        return search_impl(
            vault,
            query,
            content_type=content_type,
            tag=tag,
            space=space,
            rank_by=rank_by,
            limit=limit,
        )

    @server.tool()  # type: ignore[untyped-decorator]
    def get_document(content_id: str) -> dict[str, Any]:
        """Get a single document by its ID."""
        return get_document_impl(vault, content_id)

    @server.tool()  # type: ignore[untyped-decorator]
    def get_related(
        content_id: str,
        depth: int = 2,
        top: int = 20,
    ) -> dict[str, Any]:
        """Get related content via graph traversal."""
        return get_related_impl(vault, content_id, depth=depth, top=top)

    @server.tool()  # type: ignore[untyped-decorator]
    def agent_context(
        query: str | None = None,
        limit: int = 5,
    ) -> dict[str, Any]:
        """Build agent context from vault state."""
        return agent_context_impl(vault, query=query, limit=limit)

    @server.tool()  # type: ignore[untyped-decorator]
    def session_close(summary: str | None = None) -> dict[str, Any]:
        """Close the active session with optional summary."""
        return session_close_impl(vault, summary=summary)

    @server.tool()  # type: ignore[untyped-decorator]
    def session_status() -> dict[str, Any]:
        """Get the active session, if any."""
        return session_status_impl(vault)

    @server.tool()  # type: ignore[untyped-decorator]
    def list_items(
        content_type: str | None = None,
        status: str | None = None,
        tag: str | None = None,
        topic: str | None = None,
        subtype: str | None = None,
        maturity: str | None = None,
        space: str | None = None,
        since: str | None = None,
        include_archived: bool = False,
        sort: str = "recency",
        limit: int = 20,
    ) -> dict[str, Any]:
        """List vault items with filtering by type/status/tag/topic/maturity."""
        return list_items_impl(
            vault,
            content_type=content_type,
            status=status,
            tag=tag,
            topic=topic,
            subtype=subtype,
            maturity=maturity,
            space=space,
            since=since,
            include_archived=include_archived,
            sort=sort,
            limit=limit,
        )

    @server.tool()  # type: ignore[untyped-decorator]
    def work_queue(space: str | None = None) -> dict[str, Any]:
        """Get prioritized actionable tasks."""
        return work_queue_impl(vault, space=space)

    @server.tool()  # type: ignore[untyped-decorator]
    def decision_support(
        topic: str | None = None,
        space: str | None = None,
    ) -> dict[str, Any]:
        """Aggregate decision context for a topic."""
        return decision_support_impl(vault, topic=topic, space=space)

    @server.tool()  # type: ignore[untyped-decorator]
    def vault_review(top: int = 10, stale_days: int = 7) -> dict[str, Any]:
        """Build a review-ready vault health snapshot."""
        return vault_review_impl(vault, top=top, stale_days=stale_days)

    @server.tool()  # type: ignore[untyped-decorator]
    def graph_themes() -> dict[str, Any]:
        """Detect knowledge communities via graph clustering."""
        return graph_themes_impl(vault)

    @server.tool()  # type: ignore[untyped-decorator]
    def graph_rank(top: int = 20) -> dict[str, Any]:
        """Rank content by importance via PageRank."""
        return graph_rank_impl(vault, top=top)

    @server.tool()  # type: ignore[untyped-decorator]
    def graph_path(source_id: str, target_id: str) -> dict[str, Any]:
        """Find connection path between two items."""
        return graph_path_impl(vault, source_id, target_id)

    @server.tool()  # type: ignore[untyped-decorator]
    def graph_gaps(top: int = 20) -> dict[str, Any]:
        """Identify structural holes in the knowledge graph."""
        return graph_gaps_impl(vault, top=top)

    @server.tool()  # type: ignore[untyped-decorator]
    def graph_bridges(top: int = 20) -> dict[str, Any]:
        """Find bridge notes via betweenness centrality."""
        return graph_bridges_impl(vault, top=top)
