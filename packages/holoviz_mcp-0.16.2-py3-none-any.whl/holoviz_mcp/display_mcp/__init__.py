"""Display MCP Module.

This module provides tools for visualizing Python code and data objects
through a web-based Panel interface.
"""
