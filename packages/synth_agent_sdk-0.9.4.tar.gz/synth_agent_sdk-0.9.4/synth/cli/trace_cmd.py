"""``synth trace`` command — open stored trace in browser."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import click

from synth.tracing.trace import Trace, TraceSpan


def show_trace(run_id: str) -> None:
    """Open the stored trace for *run_id* in the browser."""
    # Search for trace files matching the run_id
    trace_file = _find_trace_file(run_id)
    if trace_file is None:
        click.echo(
            click.style(f"No trace found for run_id '{run_id}'.", fg="red"),
            err=True,
        )
        sys.exit(1)

    click.echo(f"Opening trace: {trace_file}")

    # Load and display
    data = json.loads(trace_file.read_text(encoding="utf-8"))
    trace = Trace(total_latency_ms=0.0)
    trace.show()


def _find_trace_file(run_id: str) -> Path | None:
    """Search for a trace JSON file matching *run_id*."""
    cwd = Path(".")
    for f in cwd.glob(f"*{run_id}*.json"):
        return f
    for f in cwd.glob("synth_trace_*.json"):
        return f
    return None
