"""Deployment: AgentCore adapter, packager."""

from synth.deploy.packager import package

__all__ = ["package"]
