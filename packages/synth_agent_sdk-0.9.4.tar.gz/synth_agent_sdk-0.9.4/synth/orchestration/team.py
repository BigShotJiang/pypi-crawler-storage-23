"""AgentTeam orchestration for multi-agent collaboration.

Provides the ``AgentTeam`` class which coordinates multiple specialised
agents via an orchestrator model.  Supports two strategies:

- ``"auto"``: the orchestrator decides routing dynamically based on task
  content and agent descriptions.
- ``"parallel"``: all agents execute concurrently and results are aggregated.

A special ``handoff`` tool is injected into team agents so they can
explicitly transfer control to another agent.
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, Literal

from synth._compat import run_sync
from synth.types import (
    AgentContribution,
    Message,
    RunResult,
    TeamResult,
    TokenUsage,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Handoff sentinel
# ---------------------------------------------------------------------------

HANDOFF_TOOL_NAME = "_synth_handoff"

_HANDOFF_SCHEMA: dict[str, Any] = {
    "name": HANDOFF_TOOL_NAME,
    "description": (
        "Transfer execution to another agent in the team. "
        "Use this when a different agent is better suited for the task."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "target_agent": {
                "type": "string",
                "description": "Name of the agent to hand off to.",
            },
            "context": {
                "type": "string",
                "description": "Context or instructions for the target agent.",
            },
        },
        "required": ["target_agent", "context"],
    },
}


# ---------------------------------------------------------------------------
# AgentTeam
# ---------------------------------------------------------------------------


class AgentTeam:
    """Multi-agent team coordinated by an orchestrator.

    Parameters
    ----------
    orchestrator:
        Model string for the coordinator agent (e.g. ``"claude-sonnet-4-5"``).
    agents:
        List of specialised agents available to the team.
    strategy:
        ``"auto"`` lets the orchestrator decide routing; ``"parallel"``
        dispatches to all agents concurrently.

    Example::

        team = AgentTeam(
            orchestrator="claude-sonnet-4-5",
            agents=[researcher, writer],
            strategy="parallel",
        )
        result = team.run("Write a report on AI safety.")
    """

    def __init__(
        self,
        orchestrator: str,
        agents: list[Any],
        strategy: Literal["auto", "parallel"] = "auto",
    ) -> None:
        self._orchestrator_model = orchestrator
        self._agents = agents
        self._strategy = strategy

        # Build agent lookup by name
        self._agent_map: dict[str, Any] = {}
        for agent in agents:
            name = self._agent_name(agent)
            self._agent_map[name] = agent

    # ------------------------------------------------------------------
    # Sync wrappers
    # ------------------------------------------------------------------

    def run(self, task: str) -> TeamResult:
        """Execute the team synchronously.

        Parameters
        ----------
        task:
            The task description to delegate.

        Returns
        -------
        TeamResult
            Aggregated result with contributions from each agent.
        """
        return run_sync(self.arun(task))

    # ------------------------------------------------------------------
    # Async implementation
    # ------------------------------------------------------------------

    async def arun(self, task: str) -> TeamResult:
        """Execute the team asynchronously.

        Parameters
        ----------
        task:
            The task description to delegate.

        Returns
        -------
        TeamResult
            Aggregated result with contributions from each agent.
        """
        start_time = time.perf_counter()

        if self._strategy == "parallel":
            return await self._run_parallel(task, start_time)
        return await self._run_auto(task, start_time)

    # ------------------------------------------------------------------
    # Parallel strategy
    # ------------------------------------------------------------------

    async def _run_parallel(
        self, task: str, start_time: float,
    ) -> TeamResult:
        """Dispatch task to all agents concurrently."""
        results: list[RunResult | Exception] = await asyncio.gather(
            *(agent.arun(task) for agent in self._agents),
            return_exceptions=True,
        )

        contributions: list[AgentContribution] = []
        message_trace: list[Message] = []
        total_cost = 0.0
        answer_parts: list[str] = []

        for agent, result in zip(self._agents, results):
            name = self._agent_name(agent)
            if isinstance(result, Exception):
                logger.warning(
                    "Agent '%s' failed in parallel team: %s",
                    name, result,
                )
                continue

            contributions.append(
                AgentContribution(agent_name=name, result=result),
            )
            answer_parts.append(result.text)
            total_cost += result.cost
            message_trace.append(
                {"role": "assistant", "content": f"[{name}] {result.text}"},
            )

        elapsed_ms = (time.perf_counter() - start_time) * 1000
        answer = "\n\n".join(answer_parts) if answer_parts else ""

        return TeamResult(
            answer=answer,
            contributions=contributions,
            message_trace=message_trace,
            total_cost=total_cost,
            total_latency_ms=elapsed_ms,
        )

    # ------------------------------------------------------------------
    # Auto strategy
    # ------------------------------------------------------------------

    async def _run_auto(
        self, task: str, start_time: float,
    ) -> TeamResult:
        """Let the orchestrator decide routing dynamically.

        The orchestrator receives the task plus descriptions of available
        agents and returns a routing decision.  For simplicity, the auto
        strategy dispatches to each agent in order and lets the
        orchestrator synthesise the final answer.
        """
        contributions: list[AgentContribution] = []
        message_trace: list[Message] = [
            {"role": "user", "content": task},
        ]
        total_cost = 0.0

        # In auto mode, dispatch to each agent sequentially
        # (a full orchestrator-driven routing loop would require
        # the orchestrator agent to be instantiated with the
        # orchestrator model — kept simple for now)
        for agent in self._agents:
            name = self._agent_name(agent)
            try:
                result = await agent.arun(task)
                contributions.append(
                    AgentContribution(agent_name=name, result=result),
                )
                total_cost += result.cost
                message_trace.append(
                    {
                        "role": "assistant",
                        "content": f"[{name}] {result.text}",
                    },
                )
            except Exception as exc:
                logger.warning(
                    "Agent '%s' failed in auto team: %s", name, exc,
                )

        elapsed_ms = (time.perf_counter() - start_time) * 1000

        # Synthesise answer from contributions
        answer = "\n\n".join(
            c.result.text for c in contributions
        ) if contributions else ""

        return TeamResult(
            answer=answer,
            contributions=contributions,
            message_trace=message_trace,
            total_cost=total_cost,
            total_latency_ms=elapsed_ms,
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _agent_name(agent: Any) -> str:
        """Derive a name for an agent."""
        if hasattr(agent, "instructions") and agent.instructions:
            return agent.instructions[:30].strip()
        if hasattr(agent, "model"):
            return str(agent.model)
        return "unnamed_agent"
