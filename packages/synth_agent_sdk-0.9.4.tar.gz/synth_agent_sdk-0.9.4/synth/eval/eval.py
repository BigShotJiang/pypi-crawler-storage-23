"""Eval class for structured agent evaluation.

Provides case management, execution against a live agent, and scoring
via configurable scorers.
"""

from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from synth._compat import run_sync
from synth.eval.report import EvalCaseResult, EvalReport
from synth.eval.scorers import CustomScorer, ExactMatchScorer


# ---------------------------------------------------------------------------
# EvalCase
# ---------------------------------------------------------------------------


@dataclass
class _EvalCase:
    """Internal representation of a single eval case."""

    input: str
    expected: Any
    checker: Callable[[str, Any], float] | None = None


# ---------------------------------------------------------------------------
# Eval
# ---------------------------------------------------------------------------


class Eval:
    """Structured evaluation runner for agents.

    Parameters
    ----------
    agent:
        The agent to evaluate.
    pass_threshold:
        Minimum score (0.0–1.0) for a case to be considered passing.
        Defaults to 0.5.

    Example::

        eval = Eval(agent=my_agent)
        eval.add_case("What is 2+2?", "4")
        report = eval.run()
        print(report.overall_score)
    """

    def __init__(
        self,
        agent: Any,
        pass_threshold: float = 0.5,
    ) -> None:
        self._agent = agent
        self._cases: list[_EvalCase] = []
        self._pass_threshold = pass_threshold
        self._default_scorer = ExactMatchScorer()

    def add_case(
        self,
        input: str,
        expected: Any,
        checker: Callable[[str, Any], float] | None = None,
    ) -> None:
        """Add an evaluation case.

        Parameters
        ----------
        input:
            The prompt to send to the agent.
        expected:
            The expected output value.
        checker:
            Optional custom scorer function ``(output, expected) -> float``.
        """
        self._cases.append(_EvalCase(
            input=input, expected=expected, checker=checker,
        ))

    def run(self) -> EvalReport:
        """Execute all cases synchronously.

        Returns
        -------
        EvalReport
            Report with per-case results and overall score.
        """
        return run_sync(self.arun())

    async def arun(self) -> EvalReport:
        """Execute all cases asynchronously.

        Returns
        -------
        EvalReport
            Report with per-case results and overall score.
        """
        results: list[EvalCaseResult] = []

        for case in self._cases:
            start = time.perf_counter()
            run_result = await self._agent.arun(case.input)
            elapsed_ms = (time.perf_counter() - start) * 1000

            # Score
            if case.checker is not None:
                scorer = CustomScorer(case.checker)
            else:
                scorer = self._default_scorer

            score = scorer.score(run_result.text, case.expected)

            results.append(EvalCaseResult(
                input=case.input,
                expected=case.expected,
                actual=run_result.text,
                score=score,
                passed=score >= self._pass_threshold,
                latency_ms=elapsed_ms,
                cost=run_result.cost,
            ))

        overall = (
            sum(r.score for r in results) / len(results)
            if results else 0.0
        )
        total_cost = sum(r.cost for r in results)
        total_latency = sum(r.latency_ms for r in results)

        return EvalReport(
            cases=results,
            overall_score=overall,
            total_cost=total_cost,
            total_latency_ms=total_latency,
        )
