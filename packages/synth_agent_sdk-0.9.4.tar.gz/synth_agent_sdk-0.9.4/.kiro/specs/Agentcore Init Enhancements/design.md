# Design Document: AgentCore Init Enhancements

## Overview

This document describes the technical design for four enhancements to the Synth SDK's
AgentCore init and deployment workflow, plus two supporting features (Edit Wizard and
Doctor checks). The changes span `synth/cli/`, `synth/deploy/agentcore/`, and a new
`synth/deploy/agentcore/credentials.py` module.

The design follows the existing CLI patterns: `click`-based commands, `[  OK  ]` / `[FAIL]`
status output, lazy imports for optional dependencies, and `SynthError` subclasses for all
error conditions.

---

## Architecture

```mermaid
graph TD
    A[synth init / synth create agent] --> B{Provider = agentcore?}
    B -- yes --> C[Credential_Resolver]
    C --> D[Region + Model Selection]
    D --> E[Tool Wizard optional]
    E --> F[MCP Wizard optional]
    F --> G[Generate project files]

    H[synth deploy --target agentcore] --> I[Deploy_Wizard]
    I --> J[Stage: Credential validation]
    J --> K[Stage: Dependency check]
    K --> L[Stage: Agent file validation]
    L --> M[Stage: Manifest generation]
    M --> N[Stage: Artifact packaging]
    N --> O[Stage: AgentCore API submission]

    P[synth edit agent file] --> Q[Edit_Wizard]
    Q --> R[Read agent.py + agentcore.yaml]
    R --> S[Present edit menu]

    T[synth doctor] --> U{agentcore.yaml present?}
    U -- yes --> V[AgentCore Doctor checks]
```

### New and Modified Modules

| Module | Status | Responsibility |
|---|---|---|
| `synth/deploy/agentcore/credentials.py` | **New** | `Credential_Resolver` — detect, validate, and surface AWS credentials |
| `synth/deploy/agentcore/model_catalog.py` | **New** | `Model_Catalog` and `Region_Validator` — model/region/CRIS data and filtering |
| `synth/cli/init_cmd.py` | **Modified** | Add credential detection, region/model selection, tool wizard, MCP wizard |
| `synth/cli/create_cmd.py` | **Modified** | Apply same region/model flow for `synth create agent --provider agentcore` |
| `synth/cli/deploy_cmd.py` | **Modified** | Replace thin wrapper with full `Deploy_Wizard` stage runner |
| `synth/cli/edit_cmd.py` | **New** | `Edit_Wizard` for modifying existing agent configurations |
| `synth/cli/doctor.py` | **Modified** | Add AgentCore-specific checks when `agentcore.yaml` is present |
| `synth/cli/main.py` | **Modified** | Register `synth edit agent` command |
| `synth/deploy/packager.py` | **Modified** | Add credential pattern scan before packaging |

---

## Components and Interfaces

### Credential_Resolver (`synth/deploy/agentcore/credentials.py`)

```python
@dataclass
class ResolvedCredentials:
    source: str          # "env", "aws_file", "aws_toolkit", "profile:<name>"
    account_id: str      # raw account ID (never logged)
    profile_name: str | None

class CredentialResolver:
    def resolve(self) -> ResolvedCredentials | None: ...
    def resolve_profile(self, profile_name: str) -> ResolvedCredentials | None: ...
    def mask_account_id(self, account_id: str) -> str: ...  # returns "****1234"
```

Resolution order (per Requirement 1.1):
1. `AWS_ACCESS_KEY_ID` / `AWS_SECRET_ACCESS_KEY` environment variables
2. `~/.aws/credentials` default profile
3. AWS Toolkit VS Code extension credential profiles (read from `~/.aws/sso/cache/` and
   VS Code extension state files)

Each source is tried in a `try/except`; exceptions are logged at `DEBUG` level only and
the resolver continues to the next source (Requirement 1.5 / 8.6).

Credential values are **never** stored as instance attributes. `ResolvedCredentials` stores
only the `source` string and `account_id` for display — the actual boto3 session is created
at call time and not retained.

### Model_Catalog (`synth/deploy/agentcore/model_catalog.py`)

```python
@dataclass
class ModelEntry:
    model_id: str           # base model ID
    display_name: str       # human-readable name
    native_regions: list[str]
    cris_regions: list[str]  # regions where CRIS profile is needed
    cris_profile_id: str    # e.g. "us.anthropic.claude-sonnet-4-5-..."

class ModelCatalog:
    MODELS: list[ModelEntry]  # bundled static data

class RegionValidator:
    def __init__(self, catalog: ModelCatalog): ...
    def models_for_region(self, region: str) -> list[ModelEntry]: ...
    def requires_cris(self, model_id: str, region: str) -> bool: ...
    def effective_model_id(self, model_id: str, region: str) -> str: ...
```

The catalog is bundled as static data (no network call at init time). It includes at
minimum the models listed in Requirement 4.5. If a region is unknown to the catalog,
`models_for_region` returns all models and sets a warning flag (Requirement 4.8).

### Deploy_Wizard (`synth/cli/deploy_cmd.py`)

The wizard runs six sequential stages. Each stage is a callable that returns
`(success: bool, message: str, suggestion: str | None)`. The runner prints
`[  OK  ]` or `[FAIL]` after each stage and halts on failure.

```python
@dataclass
class StageResult:
    success: bool
    message: str
    suggestion: str | None = None

Stage = Callable[[], StageResult]

def run_deploy_wizard(file: str, dry_run: bool) -> None: ...
```

Stages:
1. `_stage_credentials()` — calls `CredentialResolver.resolve()`; prompts if missing
2. `_stage_dependencies()` — checks `synth[agentcore]` is installed
3. `_stage_validate_file()` — loads and validates the agent file
4. `_stage_manifest()` — calls `generate_manifest()`
5. `_stage_package()` — calls `packager.package()` (skipped in dry-run)
6. `_stage_submit()` — submits to AgentCore API (skipped in dry-run)

### Edit_Wizard (`synth/cli/edit_cmd.py`)

```python
def run_edit_agent(file: str) -> None: ...
```

Reads `agent.py` and `agentcore.yaml` (if present), presents a menu, collects changes,
shows a diff summary, and writes atomically via `tempfile` + `os.replace()`.

### Tool and MCP Wizards (inline in `synth/cli/init_cmd.py`)

```python
def _run_tool_wizard(project_dir: str, provider: str) -> ToolWizardResult: ...
def _run_mcp_wizard(project_dir: str) -> McpWizardResult: ...

@dataclass
class ToolWizardResult:
    tools_code: str          # content for tools.py
    agent_imports: list[str] # import lines to add to agent.py
    agent_tool_names: list[str]  # names for tools=[...] list

@dataclass
class McpWizardResult:
    server_dir: str
    server_code: str
    agent_mcp_registration: str  # code snippet for agent.py
```

---

## Data Models

### `agentcore.yaml` schema (extended)

```yaml
agent_name: my-agent
agent_description: "..."

# New fields added by this feature
aws_region: us-east-1          # Requirement 4.7
model_id: anthropic.claude-... # base or CRIS profile ID
cris_enabled: false            # true when CRIS profile ID is used
aws_profile: my-profile        # optional, Requirement 7.1

# Existing fields
permissions:
  - "bedrock:InvokeModel"
runtime:
  memory_mb: 512
  timeout_seconds: 300
environment:
  SYNTH_NO_BANNER: "1"
```

### Pre-built Tool Catalog (bundled in `init_cmd.py`)

```python
_TOOL_CATALOG: list[dict] = [
    {"key": "web_search",  "display": "Web search",    "code": "..."},
    {"key": "calculator",  "display": "Calculator",    "code": "..."},
    {"key": "file_reader", "display": "File reader",   "code": "..."},
    {"key": "http_fetch",  "display": "HTTP fetch",    "code": "..."},
    {"key": "datetime",    "display": "Date/time",     "code": "..."},
]
```

### Pre-built MCP Catalog (bundled in `init_cmd.py`)

```python
_MCP_CATALOG: list[dict] = [
    {"key": "filesystem", "display": "Filesystem MCP", "server_code": "..."},
    {"key": "github",     "display": "GitHub MCP",     "server_code": "..."},
    {"key": "slack",      "display": "Slack MCP",      "server_code": "..."},
    {"key": "database",   "display": "Database MCP",   "server_code": "..."},
]
```

---

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid
executions of a system — essentially, a formal statement about what the system should do.
Properties serve as the bridge between human-readable specifications and
machine-verifiable correctness guarantees.*

### Property 1: Credential resolution priority order

*For any* combination of credential sources (env vars, aws file, toolkit profiles), the
`Credential_Resolver` should always return the highest-priority available source, never
a lower-priority source when a higher-priority one is present.

**Validates: Requirements 1.1, 7.2**

---

### Property 2: Account ID masking

*For any* AWS account ID string (12-digit numeric), the `mask_account_id` function should
return a string that ends with the last 4 characters of the input and contains no other
digits from the original account ID.

**Validates: Requirements 1.2**

---

### Property 3: Credential resolver fault tolerance

*For any* exception type raised by a credential source reader, the `Credential_Resolver`
should not propagate the exception and should continue checking remaining sources.

**Validates: Requirements 1.5, 8.6**

---

### Property 4: Credential redaction in all outputs

*For any* string that contains a pattern matching an AWS access key (20-char uppercase
alphanumeric starting with `AKIA` or `ASIA`) or secret key (40-char base64-like string),
the redaction function should replace the key value so that the output contains no
recognizable credential pattern.

**Validates: Requirements 1.6, 7.4, 7.5, 8.2, 8.3**

---

### Property 5: Deploy stage output formatting

*For any* stage name and result (success or failure), the `Deploy_Wizard` output formatter
should produce a line prefixed with exactly `[  OK  ]` on success or `[FAIL]` on failure,
and a failure result should include a non-empty suggestion string.

**Validates: Requirements 2.2, 2.3**

---

### Property 6: Deploy stage halts on failure

*For any* sequence of stages where stage N fails, stages N+1 through the end should not
be executed.

**Validates: Requirements 2.3**

---

### Property 7: Catalog rendering completeness

*For any* Tool_Catalog or MCP_Catalog contents, the rendered selection list should contain
exactly one entry per catalog item plus exactly one "Create custom scaffolding" entry, with
no duplicates.

**Validates: Requirements 3.2, 3.6**

---

### Property 8: Pre-built selection generates correct files

*For any* selection of pre-built tools from the Tool_Catalog, the generated `tools.py`
should contain an implementation for each selected tool, and the generated `agent.py`
should import and register each selected tool in the `tools=[...]` list. The same holds
for MCP server selections and `agent.py` MCP registration.

**Validates: Requirements 3.3, 3.7**

---

### Property 9: Custom scaffolding generates stubs for all named items

*For any* list of tool names (up to 3) provided to the custom tool scaffolding wizard,
the generated `tools.py` should contain exactly one `@tool`-decorated stub function per
name. For any list of MCP tool names, the generated `server.py` should contain exactly
one `@mcp.tool()`-decorated stub per name.

**Validates: Requirements 3.4, 3.8**

---

### Property 10: Confirmation summary lists all files

*For any* combination of selected features (tools, MCP, eval, deploy), the confirmation
summary displayed before file generation should list every file that will be written to
disk, with no omissions.

**Validates: Requirements 3.10**

---

### Property 11: Region filtering correctness

*For any* AWS region string, `Region_Validator.models_for_region()` should return only
models whose `native_regions` or `cris_regions` list includes that region. No model
outside those lists should appear in the result.

**Validates: Requirements 4.2**

---

### Property 12: Model ID written correctly based on CRIS requirement

*For any* (model, region) pair where the model is in the catalog, the effective model ID
written to `agentcore.yaml` and `agent.py` should be the base model ID when the model is
natively available in the region, and the CRIS profile ID when CRIS is required. The
`cris_enabled` field should be `true` if and only if the CRIS profile ID was used.

**Validates: Requirements 4.3, 4.4, 4.7**

---

### Property 13: agentcore.yaml round-trip persistence

*For any* (region, model_id, cris_enabled, aws_profile) tuple written to `agentcore.yaml`,
reading the file back and parsing it should produce the same values with no data loss or
type coercion.

**Validates: Requirements 4.7, 7.1**

---

### Property 14: Edit_Wizard always shows diff before writing

*For any* set of pending changes to an agent file, the `Edit_Wizard` should always display
a diff summary and request confirmation before writing any bytes to disk.

**Validates: Requirements 5.9**

---

### Property 15: Packager credential scan rejects credential patterns

*For any* `agentcore.yaml` content that contains a string matching an AWS access key or
secret key pattern, the `Packager` should raise a `SynthConfigError` and not produce a
deployment artifact.

**Validates: Requirements 7.6, 8.4**

---

### Property 16: Doctor status output correctness

*For any* `agentcore.yaml` configuration, the `Doctor` should print `[  OK  ]` for each
field that is valid and `[FAIL]` for each field that is invalid or misconfigured, with no
field silently skipped when `agentcore.yaml` is present.

**Validates: Requirements 6.1, 6.2, 6.3, 6.5**

---

## Error Handling

All errors follow the existing `SynthError` hierarchy:

| Condition | Exception | `component` |
|---|---|---|
| No AWS credentials found | `SynthConfigError` | `"CredentialResolver"` |
| Invalid AWS profile name | `SynthConfigError` | `"CredentialResolver"` |
| Model not available in region | `SynthConfigError` | `"RegionValidator"` |
| Credential pattern found in artifact | `SynthConfigError` | `"Packager"` |
| Agent file not found (edit) | `SynthConfigError` | `"EditWizard"` |
| Deploy stage failure | `SynthConfigError` | `"DeployWizard"` |

Error messages follow the rule: informative for developers, no internal state or
credential fragments leaked to users (Requirement 8.1, Security Framework §11).

---

## Testing Strategy

### Unit Tests (`tests/unit/`)

- `test_credentials.py` — `CredentialResolver` source priority, masking, fault tolerance
- `test_model_catalog.py` — `ModelCatalog` contents, `RegionValidator` filtering, CRIS detection
- `test_deploy_wizard.py` — stage runner ordering, `[  OK  ]`/`[FAIL]` formatting, dry-run mode
- `test_init_wizard.py` — tool wizard, MCP wizard, file generation, confirmation summary
- `test_edit_wizard.py` — config reading, diff display, atomic write, missing file error
- `test_doctor_agentcore.py` — agentcore.yaml validation checks, profile existence check
- `test_packager_security.py` — credential pattern scan, `.env` exclusion

Unit tests use `pytest`, `unittest.mock.patch` for filesystem and boto3 calls, and
`click.testing.CliRunner` for CLI interaction tests.

### Property-Based Tests (`tests/property/`)

Uses Hypothesis with `@settings(max_examples=100)`.

- `test_prop_credentials.py` — Properties 1, 2, 3, 4
- `test_prop_model_catalog.py` — Properties 11, 12, 13
- `test_prop_deploy_wizard.py` — Properties 5, 6
- `test_prop_init_wizard.py` — Properties 7, 8, 9, 10
- `test_prop_packager.py` — Property 15
- `test_prop_doctor.py` — Property 16
- `test_prop_edit_wizard.py` — Property 14

Each property test file docstring references the property number and requirement using
the format: `**Property N: <name>** / **Validates: Requirements X.Y**`.

Each property test is tagged with:
`# Feature: agentcore-init-enhancements, Property N: <property_text>`

### Property-Based Testing Library

**Hypothesis** (`hypothesis`) is used for all property tests, consistent with the
existing `tests/property/` directory and `pyproject.toml` configuration.
Minimum 100 iterations per property (`@settings(max_examples=100)`).

### Dual Testing Approach

- Unit tests cover specific examples, edge cases (unknown region, empty tool list,
  missing yaml fields), and error conditions.
- Property tests verify universal correctness across randomized inputs (arbitrary
  account IDs, region strings, model selections, credential patterns).
- Together they provide comprehensive coverage without redundancy.
