# Requirements Document

## Introduction

This feature extends the `synth init` CLI command to support multi-agent workflows. Currently, `synth init` scaffolds a single-agent project. This extension adds an early fork in the init flow where the user chooses between a single-agent project (existing flow) or a multi-agent project. The multi-agent path guides the user through defining multiple agents (each with its own name, description, provider, model, instructions, tools, and MCP servers), selecting and configuring an orchestration pattern (Pipeline, Graph, AgentTeam, or Human-in-the-Loop as a Graph modifier), and generating a working project with individual agent files plus a main orchestration file. Deployment iterates over each agent using the existing single-agent deploy mechanism.

## Glossary

- **Init_Wizard**: The interactive CLI flow started by `synth init`, implemented in `run_init()` within `synth/cli/init_cmd.py`.
- **Agent_Config**: A data structure holding a single agent's configuration: name, description, provider, model, instructions, tool wizard result, and MCP wizard result.
- **Orchestration_Selector**: The interactive step where the user picks an orchestration pattern and configures its parameters.
- **Pipeline**: A linear sequential orchestration pattern where agents execute in order, each receiving the previous agent's output as input. Defined in `synth/orchestration/pipeline.py`.
- **Graph**: A directed-graph orchestration pattern with conditional edges, branching, loops, and concurrent node execution. Defined in `synth/orchestration/graph.py`.
- **AgentTeam**: A multi-agent coordination pattern with `"auto"` (orchestrator-driven routing) or `"parallel"` (all agents run concurrently) strategies. Defined in `synth/orchestration/team.py`.
- **Human_in_the_Loop**: A modifier on Graph that pauses execution at specified nodes for human review, with configurable timeout and fallback. Defined via `graph.with_human_in_the_loop()`.
- **Orchestration_Config**: A data structure holding the selected orchestration pattern and its pattern-specific configuration parameters.
- **Project_Generator**: The component responsible for writing all project files to disk, including individual agent files and the main orchestration file.

---

## Requirements

### Requirement 1: Single vs. Multi-Agent Fork

**User Story:** As a developer running `synth init`, I want to choose between creating a single-agent or multi-agent project early in the flow, so that I get the appropriate scaffolding experience for my use case.

#### Acceptance Criteria

1. WHEN the Init_Wizard starts, THE Init_Wizard SHALL prompt the user to choose between "Single agent" and "Multiple agents" immediately after the welcome banner.
2. WHEN the user selects "Single agent", THE Init_Wizard SHALL proceed with the existing single-agent init flow without modification.
3. WHEN the user selects "Multiple agents", THE Init_Wizard SHALL enter the multi-agent configuration flow.

---

### Requirement 2: Multi-Agent Project Identity

**User Story:** As a developer creating a multi-agent project, I want to provide a project name and description, so that the generated project has a clear identity.

#### Acceptance Criteria

1. WHEN the multi-agent flow begins, THE Init_Wizard SHALL prompt for a project name with a sensible default derived from the current directory name.
2. WHEN the multi-agent flow begins, THE Init_Wizard SHALL prompt for a project description with a default of "A multi-agent project built with SynthAgentSDK".

---

### Requirement 3: Individual Agent Configuration

**User Story:** As a developer, I want to configure each agent individually with its own provider, model, instructions, tools, and MCP servers, so that each agent in my multi-agent project is specialized for its role.

#### Acceptance Criteria

1. THE Init_Wizard SHALL prompt the user for the number of agents to create, requiring a minimum of two agents.
2. WHEN configuring each agent, THE Init_Wizard SHALL prompt for the agent's name (unique, non-empty string).
3. WHEN configuring each agent, THE Init_Wizard SHALL prompt for the agent's description (a short summary of the agent's role).
4. WHEN configuring each agent, THE Init_Wizard SHALL run the provider selection step, allowing each agent to use a different provider.
5. WHEN configuring each agent, THE Init_Wizard SHALL run the model selection step using `_run_model_selection()` for the chosen provider.
6. WHEN configuring each agent, THE Init_Wizard SHALL prompt for agent instructions with a default value.
7. WHEN configuring each agent, THE Init_Wizard SHALL run the tool wizard via `_run_tool_wizard()` for that agent.
8. WHEN configuring each agent, THE Init_Wizard SHALL run the MCP wizard via `_run_mcp_wizard()` for that agent.
9. WHEN all agents are configured, THE Init_Wizard SHALL store each agent's configuration in an Agent_Config data structure.
10. IF the user provides a duplicate agent name, THEN THE Init_Wizard SHALL reject the name and prompt again.

---

### Requirement 4: Orchestration Pattern Selection

**User Story:** As a developer, I want to choose an orchestration pattern for my multi-agent project, so that my agents collaborate using the coordination strategy that fits my use case.

#### Acceptance Criteria

1. WHEN agent configuration is complete, THE Orchestration_Selector SHALL present the available orchestration patterns: Pipeline, Graph, AgentTeam, and Human-in-the-Loop (as a Graph modifier).
2. WHEN presenting each pattern, THE Orchestration_Selector SHALL display a description explaining the pattern's purpose and behavior.
3. THE Orchestration_Selector SHALL display the Pipeline description as: "Linear sequential chaining — each agent receives the previous agent's output as input. Use for step-by-step processing workflows."
4. THE Orchestration_Selector SHALL display the Graph description as: "Directed graph with conditional edges, branching, and loops. Use for complex workflows with decision points."
5. THE Orchestration_Selector SHALL display the AgentTeam description as: "Multi-agent coordination — an orchestrator routes tasks to specialized agents. Supports auto (orchestrator decides) and parallel (all agents run concurrently) strategies."
6. THE Orchestration_Selector SHALL display the Human-in-the-Loop description as: "Graph with human review checkpoints — pauses execution at specified nodes for human input before continuing. Adds pause/resume capability to a Graph workflow."
7. WHEN the user selects a pattern, THE Orchestration_Selector SHALL proceed to the pattern-specific configuration step.

---

### Requirement 5: Pipeline Configuration

**User Story:** As a developer who selected Pipeline orchestration, I want to define the order in which my agents execute, so that the generated pipeline processes data through agents in the correct sequence.

#### Acceptance Criteria

1. WHEN the user selects Pipeline, THE Orchestration_Selector SHALL display the list of configured agent names.
2. THE Orchestration_Selector SHALL prompt the user to define the execution order by arranging agent names in sequence.
3. THE Orchestration_Selector SHALL default the execution order to the order in which agents were configured.
4. WHEN the pipeline order is confirmed, THE Orchestration_Selector SHALL store the ordered agent list in the Orchestration_Config.

---

### Requirement 6: Graph Configuration

**User Story:** As a developer who selected Graph orchestration, I want to define nodes, edges, and conditions for my graph, so that the generated project implements the correct control flow between agents.

#### Acceptance Criteria

1. WHEN the user selects Graph, THE Orchestration_Selector SHALL assign each configured agent as a graph node.
2. THE Orchestration_Selector SHALL prompt the user to define the entry node by selecting from the list of agent names.
3. THE Orchestration_Selector SHALL prompt the user to define edges between nodes, specifying source and target for each edge.
4. THE Orchestration_Selector SHALL allow the user to specify `Graph.END` as an edge target to indicate termination.
5. THE Orchestration_Selector SHALL prompt the user to optionally add a condition description for each edge.
6. WHEN all edges are defined, THE Orchestration_Selector SHALL store the node list, entry node, and edge definitions in the Orchestration_Config.

---

### Requirement 7: AgentTeam Configuration

**User Story:** As a developer who selected AgentTeam orchestration, I want to choose a strategy and configure the orchestrator, so that the generated project coordinates agents according to my preferred collaboration model.

#### Acceptance Criteria

1. WHEN the user selects AgentTeam, THE Orchestration_Selector SHALL prompt the user to choose a strategy: "auto" or "parallel".
2. WHEN presenting the strategy options, THE Orchestration_Selector SHALL describe "auto" as: "The orchestrator decides which agent to route tasks to based on task content and agent descriptions."
3. WHEN presenting the strategy options, THE Orchestration_Selector SHALL describe "parallel" as: "All agents receive the task concurrently and results are aggregated."
4. THE Orchestration_Selector SHALL prompt the user to select an orchestrator model from the available providers and models.
5. WHEN the team configuration is confirmed, THE Orchestration_Selector SHALL store the strategy and orchestrator model in the Orchestration_Config.

---

### Requirement 8: Human-in-the-Loop Configuration

**User Story:** As a developer who selected Human-in-the-Loop orchestration, I want to define pause nodes, timeout, and fallback behavior, so that the generated graph pauses at the right points for human review.

#### Acceptance Criteria

1. WHEN the user selects Human-in-the-Loop, THE Orchestration_Selector SHALL first run the Graph configuration flow (Requirement 6).
2. THE Orchestration_Selector SHALL then prompt the user to select one or more nodes as pause points from the list of configured agent names.
3. THE Orchestration_Selector SHALL prompt the user for an optional timeout value in seconds (default: no timeout).
4. THE Orchestration_Selector SHALL prompt the user for an optional fallback node to route to on timeout (default: abort).
5. WHEN the Human-in-the-Loop configuration is confirmed, THE Orchestration_Selector SHALL store the pause nodes, timeout, and fallback in the Orchestration_Config alongside the Graph configuration.

---

### Requirement 9: Feature Selection for Multi-Agent Projects

**User Story:** As a developer creating a multi-agent project, I want to select project-level features like memory, guards, and evaluation, so that the generated project includes the capabilities I need.

#### Acceptance Criteria

1. WHEN orchestration configuration is complete, THE Init_Wizard SHALL present the feature selection step with the same feature options as the single-agent flow (memory, guards, structured output, eval, deploy).
2. THE Init_Wizard SHALL apply selected features to all agents in the project uniformly.
3. WHEN the provider for any agent is AgentCore, THE Init_Wizard SHALL run the credential check via `_run_credential_check()`.

---

### Requirement 10: Multi-Agent Summary and Confirmation

**User Story:** As a developer, I want to review a summary of my entire multi-agent project configuration before generation, so that I can confirm or cancel before files are written.

#### Acceptance Criteria

1. WHEN feature selection is complete, THE Init_Wizard SHALL display a summary showing: project name, number of agents, each agent's name and provider/model, the selected orchestration pattern, and selected features.
2. THE Init_Wizard SHALL prompt the user to confirm project creation.
3. WHEN the user declines confirmation, THE Init_Wizard SHALL cancel without creating any files.

---

### Requirement 11: Multi-Agent Project Generation

**User Story:** As a developer, I want the init flow to generate a complete, working multi-agent project, so that I can run the orchestrated agents immediately after setup.

#### Acceptance Criteria

1. WHEN the user confirms project creation, THE Project_Generator SHALL create the project directory.
2. THE Project_Generator SHALL generate one Python file per agent (e.g., `agent_researcher.py`, `agent_writer.py`), each containing a configured `Agent` instance.
3. THE Project_Generator SHALL generate a main orchestration file (`main.py`) that imports all agents and wires them together using the selected orchestration pattern's API.
4. WHEN the orchestration pattern is Pipeline, THE Project_Generator SHALL generate `main.py` with a `Pipeline([...])` call using the configured agent order.
5. WHEN the orchestration pattern is Graph, THE Project_Generator SHALL generate `main.py` with `Graph()` construction, `@node` decorators or `add_node()` calls, `add_edge()` calls, and `set_entry()` matching the configured graph topology.
6. WHEN the orchestration pattern is AgentTeam, THE Project_Generator SHALL generate `main.py` with an `AgentTeam(orchestrator=..., agents=[...], strategy=...)` call matching the configured team settings.
7. WHEN the orchestration pattern is Human-in-the-Loop, THE Project_Generator SHALL generate `main.py` with Graph construction plus a `with_human_in_the_loop(pause_at=[...], timeout=..., fallback=...)` call matching the configured pause settings.
8. THE Project_Generator SHALL generate a `README.md` describing the project, its agents, and the orchestration pattern.
9. THE Project_Generator SHALL generate a `synth.toml` configuration file.
10. THE Project_Generator SHALL generate tool files and MCP server directories for each agent that configured them.
11. IF any agent uses the AgentCore provider, THEN THE Project_Generator SHALL generate `agentcore.yaml` and `.env.template` files.

---

### Requirement 12: Multi-Agent Deployment

**User Story:** As a developer with AgentCore agents, I want to deploy all agents after project generation, so that I can go from init to deployment in a single session.

#### Acceptance Criteria

1. WHEN any agent uses the AgentCore provider and project generation completes, THE Init_Wizard SHALL prompt the user with a "Deploy now?" confirmation.
2. WHEN the user confirms deployment, THE Init_Wizard SHALL invoke the existing deploy flow for each agent file that uses the AgentCore provider.
3. WHEN the user declines deployment, THE Init_Wizard SHALL print a message indicating the user can deploy each agent later with `synth deploy --target agentcore <agent_file>`.
4. WHEN no agent uses the AgentCore provider, THE Init_Wizard SHALL skip the deployment prompt.

---

### Requirement 13: Preserve Single-Agent Flow

**User Story:** As a developer maintaining the Synth SDK, I want the multi-agent extension to leave the existing single-agent init flow unchanged, so that the new feature is additive and does not break existing behavior.

#### Acceptance Criteria

1. THE Init_Wizard SHALL preserve the existing `run_init()` single-agent flow when the user selects "Single agent" at the fork.
2. THE Init_Wizard SHALL reuse existing helper functions (`_run_tool_wizard()`, `_run_mcp_wizard()`, `_run_model_selection()`, `_run_credential_check()`, `_check_provider_deps()`) without modifying their signatures or behavior.
3. THE Init_Wizard SHALL not modify the existing `_generate_project()` or `_build_agent_code()` functions.
