# Design Document: Multi-Agent Init Flow

## Overview

This design extends the `synth init` CLI command to support multi-agent project scaffolding. The extension introduces an early fork after the welcome banner where users choose between single-agent (existing flow) and multi-agent paths. The multi-agent path guides users through configuring multiple agents individually, selecting and configuring an orchestration pattern, and generating a complete working project.

The design reuses existing helper functions (`_run_tool_wizard`, `_run_mcp_wizard`, `_run_model_selection`, `_run_credential_check`) without modification. New code is additive — a new `_run_multi_agent_init()` function handles the multi-agent path, new dataclasses hold agent and orchestration configuration, and new code generation functions produce the multi-agent project files.

## Architecture

The multi-agent init flow is structured as a linear wizard with these phases:

```mermaid
flowchart TD
    A[Welcome Banner] --> B{Single or Multiple agents?}
    B -->|Single| C[Existing run_init flow]
    B -->|Multiple| D[Project Identity]
    D --> E[Agent Count]
    E --> F[Agent Configuration Loop]
    F --> G[Orchestration Selection]
    G --> H[Pattern-Specific Configuration]
    H --> I[Feature Selection]
    I --> J[Credential Check if AgentCore]
    J --> K[Summary + Confirm]
    K --> L[Project Generation]
    L --> M{Any AgentCore agents?}
    M -->|Yes| N[Deploy Prompt]
    M -->|No| O[Done]
    N --> O
```

All new code lives in `synth/cli/init_cmd.py` alongside the existing init flow. The fork is inserted at the top of `run_init()`, which either continues with the existing single-agent logic or delegates to `_run_multi_agent_init()`.

## Components and Interfaces

### Modified Function: `run_init()`

The existing `run_init()` is modified minimally — after the welcome banner, it prompts for single vs. multi-agent and branches:

```python
def run_init() -> None:
    # ... existing banner ...
    mode = click.prompt(
        click.style("  Project type", fg="cyan"),
        type=click.Choice(["single", "multi"], case_sensitive=False),
        default="single",
    )
    if mode == "multi":
        _run_multi_agent_init()
        return
    # ... existing single-agent flow unchanged ...
```

### New Function: `_run_multi_agent_init()`

Orchestrates the entire multi-agent wizard flow:

```python
def _run_multi_agent_init() -> None:
    """Run the multi-agent interactive project initializer."""
    # 1. Project identity (name, description)
    # 2. Agent count
    # 3. Agent configuration loop -> list[AgentConfig]
    # 4. Orchestration selection + configuration -> OrchestrationConfig
    # 5. Feature selection
    # 6. Credential check (if any agent is AgentCore)
    # 7. Summary + confirm
    # 8. Project generation
    # 9. Deploy prompt (if any agent is AgentCore)
```

### New Function: `_configure_agent(index: int, existing_names: list[str]) -> AgentConfig`

Runs the configuration wizard for a single agent, reusing existing helpers:

```python
def _configure_agent(index: int, existing_names: list[str]) -> AgentConfig:
    """Configure a single agent interactively.
    
    Parameters
    ----------
    index:
        The 1-based agent number (for display).
    existing_names:
        Names already taken by previously configured agents.
    
    Returns
    -------
    AgentConfig
        The completed agent configuration.
    """
```

### New Function: `_select_orchestration(agents: list[AgentConfig]) -> OrchestrationConfig`

Presents orchestration pattern choices and delegates to pattern-specific configuration:

```python
def _select_orchestration(agents: list[AgentConfig]) -> OrchestrationConfig:
    """Select and configure an orchestration pattern.
    
    Parameters
    ----------
    agents:
        The list of configured agents.
    
    Returns
    -------
    OrchestrationConfig
        The selected pattern and its configuration.
    """
```

### New Functions: Pattern-Specific Configurators

```python
def _configure_pipeline(agents: list[AgentConfig]) -> PipelineConfig:
    """Configure Pipeline orchestration — agent execution order."""

def _configure_graph(agents: list[AgentConfig]) -> GraphConfig:
    """Configure Graph orchestration — entry node, edges, conditions."""

def _configure_agent_team(agents: list[AgentConfig]) -> AgentTeamConfig:
    """Configure AgentTeam orchestration — strategy and orchestrator model."""

def _configure_human_in_loop(agents: list[AgentConfig]) -> HumanInLoopConfig:
    """Configure Human-in-the-Loop — graph config + pause nodes, timeout, fallback."""
```

### New Function: `_generate_multi_agent_project(...)`

Generates the complete multi-agent project directory:

```python
def _generate_multi_agent_project(
    name: str,
    description: str,
    agents: list[AgentConfig],
    orchestration: OrchestrationConfig,
    features: list[str],
    agentcore_creds: dict[str, Any] | None,
) -> None:
    """Generate a multi-agent project directory with all files."""
```

### New Functions: Code Generation Helpers

```python
def _build_multi_agent_code(agent: AgentConfig, features: list[str]) -> str:
    """Build the Python source for a single agent file in a multi-agent project."""

def _build_orchestration_code(
    agents: list[AgentConfig],
    orchestration: OrchestrationConfig,
    features: list[str],
) -> str:
    """Build the main.py orchestration source code."""

def _build_pipeline_code(agents: list[AgentConfig], config: PipelineConfig) -> str:
    """Generate Pipeline orchestration code."""

def _build_graph_code(agents: list[AgentConfig], config: GraphConfig) -> str:
    """Generate Graph orchestration code."""

def _build_team_code(agents: list[AgentConfig], config: AgentTeamConfig) -> str:
    """Generate AgentTeam orchestration code."""

def _build_human_in_loop_code(agents: list[AgentConfig], config: HumanInLoopConfig) -> str:
    """Generate Human-in-the-Loop Graph orchestration code."""
```

## Data Models

All new data models use `@dataclass` following SDK conventions.

```python
from __future__ import annotations
from dataclasses import dataclass, field

@dataclass
class AgentConfig:
    """Configuration for a single agent in a multi-agent project."""
    name: str
    description: str
    provider: str
    provider_cfg: dict[str, str]
    model: str
    instructions: str
    tool_result: ToolWizardResult
    mcp_result: McpWizardResult


@dataclass
class PipelineConfig:
    """Pipeline-specific orchestration configuration."""
    agent_order: list[str]  # Agent names in execution order


@dataclass
class EdgeConfig:
    """A single edge in a Graph configuration."""
    source: str
    target: str  # Agent name or "END"
    condition: str | None = None  # Optional condition description


@dataclass
class GraphConfig:
    """Graph-specific orchestration configuration."""
    entry_node: str
    edges: list[EdgeConfig] = field(default_factory=list)


@dataclass
class AgentTeamConfig:
    """AgentTeam-specific orchestration configuration."""
    strategy: str  # "auto" or "parallel"
    orchestrator_model: str  # e.g. "claude-sonnet-4-5"


@dataclass
class HumanInLoopConfig:
    """Human-in-the-Loop configuration (extends GraphConfig)."""
    graph: GraphConfig
    pause_nodes: list[str]
    timeout: float | None = None
    fallback_node: str | None = None


@dataclass
class OrchestrationConfig:
    """Top-level orchestration configuration."""
    pattern: str  # "pipeline", "graph", "agent_team", "human_in_loop"
    pipeline: PipelineConfig | None = None
    graph: GraphConfig | None = None
    agent_team: AgentTeamConfig | None = None
    human_in_loop: HumanInLoopConfig | None = None
```

