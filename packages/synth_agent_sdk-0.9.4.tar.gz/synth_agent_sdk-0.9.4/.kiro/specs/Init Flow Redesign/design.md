# Design Document: Init Flow Redesign

## Overview

This design covers the refactoring of `synth/cli/init_cmd.py` to fix two bugs and reorder the `synth init` wizard steps. All changes are scoped to a single file. The existing helper functions (`_generate_project`, `_run_tool_wizard`, `_run_mcp_wizard`, `_build_agent_code`, `_build_agentcore_yaml`) remain unchanged.

The core changes are:

1. Split `_run_agentcore_setup()` into `_run_model_selection(provider, cfg)` and `_run_credential_check()`.
2. Fix the `bedrock/` prefix bug inside `_run_model_selection()`.
3. Rewrite `run_init()` with the new step order.
4. Add a "Deploy now?" prompt after project generation for AgentCore projects.

## Architecture

The architecture stays flat — everything lives in `init_cmd.py`. The refactoring replaces one monolithic function with two focused ones and reorders calls in `run_init()`.

```mermaid
flowchart TD
    A[run_init] --> B[1. Project name]
    B --> C[2. Description]
    C --> D[3. Provider selection]
    D --> E["4. _run_model_selection(provider, cfg)"]
    E --> F[5. Agent instructions]
    F --> G["6. _run_tool_wizard()"]
    G --> H["7. _run_mcp_wizard()"]
    H --> I["8. Feature selection (no 'tools')"]
    I --> J{AgentCore?}
    J -->|Yes| K["9. _run_credential_check()"]
    J -->|No| L[10. Summary + confirm]
    K --> L
    L --> M["11. _generate_project()"]
    M --> N{AgentCore?}
    N -->|Yes| O["12. Deploy now? prompt"]
    N -->|No| P[Done]
    O --> P
```

## Components and Interfaces

### `_run_model_selection(provider: str, cfg: dict[str, str]) -> str`

Replaces the model-selection portion of `_run_agentcore_setup()`. Handles model picking for all providers.

```python
def _run_model_selection(provider: str, cfg: dict[str, str]) -> str:
    """Select the model ID for the given provider.

    Parameters
    ----------
    provider:
        Provider key (e.g. ``"agentcore"``, ``"anthropic"``).
    cfg:
        Provider config dict from ``_PROVIDERS``.

    Returns
    -------
    str
        The selected model ID string. For AgentCore, this includes
        the ``bedrock/`` prefix.
    """
```

**AgentCore path:**
1. Prompt for target AWS region (default: `us-east-1`).
2. Call `RegionValidator.models_for_region(region)` to get available models.
3. Display numbered model list with `[CRIS]` annotations.
4. Prompt user to select a model number.
5. Call `RegionValidator.effective_model_id(model_id, region)` to get the raw Bedrock ID.
6. Prepend `bedrock/` if the effective ID does not already start with `bedrock/`.
7. Store `aws_region` and `cris_enabled` on a module-level or returned dict for later use.
8. Return the `bedrock/`-prefixed model ID string.

**Non-AgentCore path:**
1. Return `cfg["model"]` directly (no prompting needed).

**Return value note:** For AgentCore, the function also needs to communicate `aws_region` and `cris_enabled` back to `run_init()`. Rather than returning a tuple, the function returns the model ID string and stores region/CRIS data in a mutable dict passed as an additional parameter:

```python
def _run_model_selection(
    provider: str,
    cfg: dict[str, str],
    agentcore_state: dict[str, Any] | None = None,
) -> str:
```

When `provider == "agentcore"`, the function writes `aws_region` and `cris_enabled` into `agentcore_state`. For other providers, `agentcore_state` is ignored.

### `_run_credential_check() -> dict[str, Any]`

Replaces the credential-detection portion of `_run_agentcore_setup()`. Called only for AgentCore projects, at step 9 (after features).

```python
def _run_credential_check() -> dict[str, Any]:
    """Detect and validate AWS credentials.

    Returns
    -------
    dict
        Keys: ``aws_profile`` (str | None).
    """
```

**Logic** (extracted directly from the existing credential section of `_run_agentcore_setup()`):
1. Import `CredentialResolver` lazily.
2. Call `resolver.resolve()` wrapped in `try/except`.
3. If credentials found: display source + masked account ID, prompt to confirm or enter a different profile.
4. If no credentials found: display warning with `aws configure` instructions, prompt for profile name.
5. Return `{"aws_profile": aws_profile}`.

### Changes to `run_init()`

The function is rewritten with the new step order. Key differences from current code:

| Step | Current | New |
|------|---------|-----|
| 3a | `_run_agentcore_setup()` (creds + region + model) | Removed |
| 4 | Feature selection | `_run_model_selection()` (all providers) |
| 5 | Agent instructions | Agent instructions (moved up) |
| 5a | Tool wizard | Tool wizard (now step 6) |
| 5b | MCP wizard | MCP wizard (now step 7) |
| — | — | Feature selection at step 8 (without "tools") |
| — | — | `_run_credential_check()` at step 9 (AgentCore only) |
| — | — | "Deploy now?" at step 12 (AgentCore only) |

The `agentcore_setup` dict passed to `_generate_project()` is assembled from:
- `aws_region` and `cris_enabled` from `agentcore_state` (populated by `_run_model_selection`)
- `aws_profile` from `_run_credential_check()`
- `model_id` from the return value of `_run_model_selection()` (the `bedrock/`-prefixed string)

### Changes to `_FEATURES`

The `"tools"` key is removed from `_FEATURES` since tool configuration is now handled by the tool wizard at step 6. The remaining features are: `memory`, `guards`, `structured`, `eval`, `deploy`.

### "Deploy now?" Prompt

After `_generate_project()` returns, if the provider is AgentCore:
1. Prompt: `"Deploy now?"` (default: no).
2. If yes: call `run_deploy(target="agentcore", dry_run=False, file=os.path.join(name, "agent.py"))`.
3. If no: print `"You can deploy later with: synth deploy --target agentcore agent.py"`.

The import of `run_deploy` from `synth.cli.deploy_cmd` is done lazily inside the conditional block.

## Data Models

No new dataclasses or data models are introduced. The existing data structures are reused:

- `ToolWizardResult` — unchanged, returned by `_run_tool_wizard()`.
- `McpWizardResult` — unchanged, returned by `_run_mcp_wizard()`.
- `agentcore_setup: dict[str, Any]` — same shape as before (`aws_region`, `model_id`, `cris_enabled`, `aws_profile`), assembled from the two new functions instead of one.
- `cfg: dict[str, str]` — the provider config dict from `_PROVIDERS`, mutated to update `model` key with the selected model ID.

### Data Flow

```mermaid
flowchart LR
    MS["_run_model_selection()"] -->|model_id str| RI[run_init]
    MS -->|aws_region, cris_enabled| AS[agentcore_state dict]
    CC["_run_credential_check()"] -->|aws_profile| RI
    AS --> RI
    RI -->|agentcore_setup dict| GP["_generate_project()"]
```

The `agentcore_setup` dict assembled in `run_init()`:
```python
agentcore_setup = {
    "aws_region": agentcore_state.get("aws_region", "us-east-1"),
    "model_id": model_id,  # bedrock/-prefixed
    "cris_enabled": agentcore_state.get("cris_enabled", False),
    "aws_profile": cred_result.get("aws_profile"),
}
```


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Bedrock prefix correctness

*For any* effective model ID string returned by `RegionValidator.effective_model_id()`, when `_run_model_selection()` is called with `provider="agentcore"`, the returned model ID string SHALL start with `"bedrock/"` and SHALL NOT contain a double prefix `"bedrock/bedrock/"`.

**Validates: Requirements 1.1, 1.3, 2.3**

Reasoning: Requirement 1.1 states the prefix must be prepended. Requirement 1.3 states no double-prefixing. These are two sides of the same invariant: the output always starts with exactly one `bedrock/` prefix. The generator should produce model IDs both with and without an existing `bedrock/` prefix to cover the edge case. This subsumes 2.3 which is the same rule stated from the function's perspective.

### Property 2: Non-AgentCore model passthrough

*For any* provider name that is not `"agentcore"` and any provider config dict `cfg` containing a `"model"` key, `_run_model_selection(provider, cfg)` SHALL return exactly `cfg["model"]` without modification.

**Validates: Requirements 2.4**

Reasoning: For non-AgentCore providers, the model ID comes directly from the static `_PROVIDERS` config. No transformation, no prompting. The function is a pure passthrough. We can generate random provider names (excluding "agentcore") and random model strings to verify this invariant.

## Error Handling

All error handling follows the existing patterns in `init_cmd.py` and the SDK coding standards:

1. **Lazy imports fail**: `CredentialResolver`, `ModelCatalog`, and `RegionValidator` are imported lazily inside `_run_model_selection()` and `_run_credential_check()`. If `synth[agentcore]` is not installed, the `ImportError` is caught and a `SynthConfigError` is raised with a `pip install` suggestion (matching existing behavior in `_run_agentcore_setup()`).

2. **Credential resolution fails**: `_run_credential_check()` wraps `resolver.resolve()` in `try/except Exception` (matching existing behavior). Failures are non-fatal — the user is warned and prompted to enter a profile name manually.

3. **Deploy invocation fails**: If the user says "yes" to "Deploy now?" and `run_deploy()` raises, the error propagates naturally. Since the project files are already written to disk, no rollback is needed.

4. **Invalid model selection**: `click.IntRange(1, len(models))` already validates the model number input. No additional error handling needed.

## Testing Strategy

### Unit Tests

Unit tests verify specific examples and integration points using mocked CLI prompts:

- **Step order verification**: Mock all `click.prompt` and `click.confirm` calls, run `run_init()`, and verify the call order matches the specified sequence (Requirements 3.1–3.5).
- **Feature list excludes tools**: Assert `"tools"` is not in the feature selection options presented at step 8 (Requirement 3.2).
- **Deploy prompt shown for AgentCore only**: Mock the flow for both AgentCore and non-AgentCore providers, verify `"Deploy now?"` appears only for AgentCore (Requirements 4.1, 4.4).
- **Deploy invocation**: Mock `run_deploy` and verify it's called with the correct arguments when the user confirms (Requirement 4.2).
- **Deploy decline message**: Verify the "deploy later" message is printed when the user declines (Requirement 4.3).
- **Generated agent.py model ID**: Run `_build_agent_code` with an AgentCore cfg containing a `bedrock/`-prefixed model ID and verify the output contains the correct `model=` string (Requirement 1.2).
- **agentcore_setup dict shape**: Verify the dict passed to `_generate_project` contains all expected keys with correct values (Requirement 5.5).

Test file: `tests/unit/test_init_flow_redesign.py`

### Property-Based Tests

Property tests use **Hypothesis** (`@settings(max_examples=100)`) to verify universal properties:

- **Property 1** (Bedrock prefix correctness): Generate random model ID strings (with and without existing `bedrock/` prefix), call the prefix logic, assert the result starts with `"bedrock/"` and does not start with `"bedrock/bedrock/"`.
  - Tag: `Feature: init-flow-redesign, Property 1: Bedrock prefix correctness`
- **Property 2** (Non-AgentCore model passthrough): Generate random provider names (excluding `"agentcore"`) and random model strings, call `_run_model_selection`, assert the return value equals the input model string.
  - Tag: `Feature: init-flow-redesign, Property 2: Non-AgentCore model passthrough`

Test file: `tests/property/test_prop_init_flow_redesign.py`

Both unit and property tests are complementary — unit tests catch specific integration bugs, property tests verify the invariants hold across all inputs.
