---
inclusion: always
---

# Coding Standards for the Synth SDK

These standards reflect the conventions already established in the codebase. Follow them
for all new and modified code.

## Python Version and Imports

- Target Python 3.10+. Use `from __future__ import annotations` at the top of every module
  to enable PEP 604 union syntax (`X | None`) in annotations while maintaining 3.10 compat.
- Use `typing.get_type_hints()` instead of inspecting `__annotations__` directly, so that
  string annotations from `__future__` are resolved correctly.
- Prefer `from __future__ import annotations` over `typing.Optional` / `typing.Union` in
  new code. Existing code using `Optional[X]` is acceptable.
- Import order: stdlib → third-party → `synth.*` (local). Separate each group with a blank
  line. Use absolute imports (`from synth.errors import ...`), not relative imports.

## Module Structure

- Every module MUST start with a module-level docstring explaining its purpose.
- Use comment banners (`# ---...---`) to separate logical sections within a file, matching
  the style in `types.py` and `test_tools.py`.
- Keep modules focused. One primary abstraction per file (e.g., `decorator.py` owns `@tool`,
  `executor.py` owns `ToolExecutor`).
- Each package MUST have an `__init__.py`. Use it for public re-exports only, not logic.

## Naming Conventions

- Classes: `PascalCase` (e.g., `ToolExecutor`, `RunResult`, `BaseProvider`).
- Functions and methods: `snake_case` (e.g., `get_schemas`, `add_edge`).
- Constants: `UPPER_SNAKE_CASE` (e.g., `_PYTHON_TO_JSON_SCHEMA`, `PROVIDER_MAP`).
- Private/internal names: prefix with a single underscore (`_build_schema`, `_tools`).
- Type aliases: `PascalCase` for public (`StreamEvent`), `PascalCase` or descriptive for
  internal (`ToolFunction`).
- ABCs: prefix with `Base` (e.g., `BaseProvider`, `BaseMemory`, `BaseGuard`,
  `BaseCheckpointStore`).

## Type Annotations

- All public function signatures MUST have full type annotations, including return types.
- Use `dict[str, Any]` over `Dict[str, Any]` (lowercase generics, Python 3.10+).
- Use `list[X]` over `List[X]`.
- Use `X | None` over `Optional[X]` in new code.
- Use `Any` sparingly. Prefer concrete types or generics where the type is knowable.
- For union types used as public API, define a named type alias
  (e.g., `StreamEvent = Union[TokenEvent, ...]`).

## Dataclasses and Data Models

- Use `@dataclass` for simple value objects (events, results, records).
- Use `field(default_factory=list)` for mutable defaults, never bare `[]` or `{}`.
- Use Pydantic `BaseModel` only for user-facing schema validation (structured output,
  graph state). Internal SDK types use dataclasses.
- Keep dataclass fields ordered: required fields first, optional/defaulted fields last.

## Error Handling

- All SDK exceptions MUST inherit from `SynthError`.
- Every `SynthError` subclass MUST accept `component` and `suggestion` keyword arguments.
- Error messages MUST be actionable: state what went wrong, which component raised it,
  and how to fix it.
- Use specific exception subclasses (`ToolExecutionError`, `GraphRoutingError`, etc.)
  rather than bare `SynthError`.
- Chain exceptions with `raise ... from exc` to preserve the original traceback.
- Never catch `Exception` silently. If catching broadly, always re-raise as a typed
  `SynthError` subclass.

## Async Patterns

- The primary implementation of any I/O-bound method MUST be async (`arun`, `astream`).
- Sync wrappers (`run`, `stream`) delegate to async via `_compat.run_sync()`.
- Use `asyncio.gather()` for concurrent execution (parallel pipeline stages, concurrent
  graph nodes).
- Async tool functions MUST be detected with `asyncio.iscoroutine()` and awaited.
- Never call `asyncio.run()` directly in library code. Use the `_compat` bridge.

## Docstrings

- Use Google-style or NumPy-style docstrings consistently. The codebase uses a mix;
  prefer NumPy-style (`Parameters`, `Returns`, `Raises` sections) for classes and
  complex functions, and single-line docstrings for simple helpers.
- Every public class, method, and function MUST have a docstring.
- Include at least one usage example in docstrings for top-level public API symbols
  (`Agent`, `tool`, `Graph`, `Pipeline`).
- Docstrings on `@tool`-decorated functions are user-facing (sent to the LLM as tool
  descriptions). Keep them concise and descriptive.

## Testing

- Test files live in `tests/unit/` for unit tests and `tests/property/` for
  property-based tests.
- Test file naming: `test_<module>.py` (e.g., `test_tools.py`, `test_errors.py`).
- Use `pytest` as the test runner. Use `@pytest.mark.asyncio` for async tests.
- Use `pytest.raises` for exception assertions, always checking the match pattern or
  inspecting error attributes.
- Use `@pytest.mark.parametrize` for testing multiple inputs against the same logic.
- Group related tests into classes (e.g., `TestSynthError`, `TestToolExecutionError`).
- Use descriptive test names: `test_<what>_<condition>_<expected>` or plain English
  (e.g., `test_optional_param_not_in_required`).
- Use `warnings.catch_warnings(record=True)` to assert on emitted warnings.
- Shared fixtures go in `tests/conftest.py`.
- Target 90%+ line coverage as configured in `pyproject.toml`.

## Provider Implementation

- All providers MUST subclass `BaseProvider` and implement `complete()` and `stream()`.
- Provider SDKs MUST be lazily imported inside the provider class, not at module level.
  Guard with try/except and raise `SynthConfigError` with the `pip install` command.
- Provider responses MUST be normalized into `ProviderResponse` / `ProviderEvent` types.
  Never leak provider-specific types into the Agent layer.
- The `raw` field on `ProviderResponse` carries the original SDK response for debugging
  but MUST NOT be relied upon by any SDK logic outside the provider module.

## Guard Implementation

- Guards MUST subclass `BaseGuard` and implement `async check()`.
- Guards are evaluated in declaration order. First violation stops evaluation.
- Guard checks MUST be side-effect-free. They inspect content but do not modify it.

## Configuration and Environment

- Credentials MUST be read from environment variables, never hardcoded.
- Use `SYNTH_` prefix for SDK-specific env vars (e.g., `SYNTH_TRACE_ENDPOINT`,
  `SYNTH_NO_BANNER`).
- Provider-specific env vars follow provider conventions (e.g., `ANTHROPIC_API_KEY`,
  `OPENAI_API_KEY`).
- Configuration errors MUST raise `SynthConfigError` with the expected env var name
  and a link or instruction to obtain the value.

## Dependencies

- Core runtime dependencies MUST stay under 7 (currently: pydantic, httpx, click,
  typing-extensions, rich, prompt-toolkit).
- Provider SDKs are optional extras defined in `pyproject.toml`. Never add a provider
  SDK to core dependencies.
- Use `hatchling` as the build backend. Follow semantic versioning.

## Code Style

- No trailing whitespace. End files with a single newline.
- Use 4-space indentation (standard Python).
- Line length: follow PEP 8 (79 for code is ideal, up to 99 is acceptable for
  readability).
- Prefer f-strings over `.format()` or `%` formatting.
- Use `# noqa: XXXX` comments only when the violation is intentional and justified.
- Use `# type: ignore[...]` with specific error codes, not bare `# type: ignore`.
