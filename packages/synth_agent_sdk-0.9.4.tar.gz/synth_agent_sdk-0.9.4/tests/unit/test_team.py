"""Unit tests for the AgentTeam orchestration module.

Covers parallel and auto strategies, agent naming, error handling,
sync wrappers, cost aggregation, message trace construction, and
edge cases (all agents failing, empty answer).
"""

from __future__ import annotations

import logging
from unittest.mock import patch

import pytest

from synth.agent import Agent
from synth.orchestration.team import (
    HANDOFF_TOOL_NAME,
    AgentTeam,
    _HANDOFF_SCHEMA,
)
from synth.providers.base import ProviderResponse
from synth.types import TokenUsage
from tests.conftest import MockProvider


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_USAGE = TokenUsage(input_tokens=5, output_tokens=10, total_tokens=15)


def _make_agent(text: str, instructions: str = "") -> Agent:
    """Create an Agent backed by a MockProvider returning *text*."""
    provider = MockProvider(
        responses=[ProviderResponse(text=text, usage=_USAGE)],
    )
    with patch("synth.agent.ProviderRouter.resolve", return_value=provider):
        return Agent(instructions=instructions or text)


def _make_failing_agent(exc: Exception, instructions: str = "failing") -> Agent:
    """Create an Agent whose provider raises *exc*."""
    provider = MockProvider(error=exc)
    with patch("synth.agent.ProviderRouter.resolve", return_value=provider):
        return Agent(instructions=instructions)


# ---------------------------------------------------------------------------
# Construction and agent naming
# ---------------------------------------------------------------------------


class TestAgentTeamConstruction:
    """Tests for AgentTeam initialisation and _agent_name."""

    def test_default_strategy_is_auto(self):
        """Strategy defaults to 'auto' when not specified."""
        agent = _make_agent("a", "researcher")
        team = AgentTeam(orchestrator="claude-sonnet-4-5", agents=[agent])
        assert team._strategy == "auto"

    def test_agent_map_built_from_agents(self):
        """_agent_map is populated with one entry per agent."""
        agents = [_make_agent("a", "alpha"), _make_agent("b", "beta")]
        team = AgentTeam(
            orchestrator="claude-sonnet-4-5", agents=agents,
        )
        assert len(team._agent_map) == 2

    def test_agent_name_from_instructions(self):
        """_agent_name uses first 30 chars of instructions."""
        agent = _make_agent("x", "short name")
        assert AgentTeam._agent_name(agent) == "short name"

    def test_agent_name_truncates_long_instructions(self):
        """_agent_name truncates instructions longer than 30 chars."""
        long = "a" * 50
        agent = _make_agent("x", long)
        name = AgentTeam._agent_name(agent)
        assert len(name) <= 30

    def test_agent_name_falls_back_to_model(self):
        """_agent_name uses model string when instructions are empty."""
        agent = _make_agent("x", "")
        agent.instructions = ""
        name = AgentTeam._agent_name(agent)
        # Should fall back to str(agent.model)
        assert name != ""
        assert name != "unnamed_agent"

    def test_agent_name_unnamed_fallback(self):
        """_agent_name returns 'unnamed_agent' for bare objects."""

        class Bare:
            pass

        assert AgentTeam._agent_name(Bare()) == "unnamed_agent"

    def test_agent_name_empty_instructions_attr(self):
        """_agent_name skips empty instructions and uses model."""

        class FakeAgent:
            instructions = ""
            model = "gpt-4o"

        assert AgentTeam._agent_name(FakeAgent()) == "gpt-4o"


# ---------------------------------------------------------------------------
# Parallel strategy
# ---------------------------------------------------------------------------


class TestParallelStrategy:
    """Tests for strategy='parallel' execution."""

    @pytest.mark.asyncio
    async def test_parallel_runs_all_agents(self):
        """All agents are invoked and contribute to the result."""
        agents = [_make_agent(f"out-{i}", f"agent-{i}") for i in range(3)]
        team = AgentTeam(
            orchestrator="claude-sonnet-4-5",
            agents=agents,
            strategy="parallel",
        )
        result = await team.arun("task")
        assert len(result.contributions) == 3

    @pytest.mark.asyncio
    async def test_parallel_answer_joins_outputs(self):
        """Answer is the outputs joined with double newlines."""
        agents = [_make_agent("alpha", "a"), _make_agent("beta", "b")]
        team = AgentTeam(
            orchestrator="claude-sonnet-4-5",
            agents=agents,
            strategy="parallel",
        )
        result = await team.arun("task")
        assert result.answer == "alpha\n\nbeta"

    @pytest.mark.asyncio
    async def test_parallel_cost_is_sum(self):
        """Total cost is the sum of individual agent costs."""
        agents = [_make_agent("a", "x"), _make_agent("b", "y")]
        team = AgentTeam(
            orchestrator="claude-sonnet-4-5",
            agents=agents,
            strategy="parallel",
        )
        result = await team.arun("task")
        # Each agent has cost from MockProvider; sum should be >= 0
        assert result.total_cost >= 0

    @pytest.mark.asyncio
    async def test_parallel_latency_is_positive(self):
        """Total latency is a positive number."""
        agents = [_make_agent("a", "x")]
        team = AgentTeam(
            orchestrator="claude-sonnet-4-5",
            agents=agents,
            strategy="parallel",
        )
        result = await team.arun("task")
        assert result.total_latency_ms > 0

    @pytest.mark.asyncio
    async def test_parallel_message_trace_has_entries(self):
        """Message trace contains one entry per successful agent."""
        agents = [_make_agent("a", "agent_a"), _make_agent("b", "agent_b")]
        team = AgentTeam(
            orchestrator="claude-sonnet-4-5",
            agents=agents,
            strategy="parallel",
        )
        result = await team.arun("task")
        assert len(result.message_trace) == 2
        assert all(m["role"] == "assistant" for m in result.message_trace)

    @pytest.mark.asyncio
    async def test_parallel_skips_failed_agents(self, caplog):
        """Failed agents are logged and excluded from contributions."""
        good = _make_agent("ok", "good_agent")
        bad = _make_failing_agent(RuntimeError("boom"), "bad_agent")
        team = AgentTeam(
            orchestrator="claude-sonnet-4-5",
            agents=[good, bad],
            strategy="parallel",
        )

        with caplog.at_level(logging.WARNING):
            result = await team.arun("task")

        assert len(result.contributions) == 1
        assert result.contributions[0].result.text == "ok"
        assert "failed in parallel team" in caplog.text

    @pytest.mark.asyncio
    async def test_parallel_all_fail_empty_answer(self, caplog):
        """When all agents fail, answer is empty and contributions empty."""
        bad_a = _make_failing_agent(RuntimeError("a"), "bad_a")
        bad_b = _make_failing_agent(RuntimeError("b"), "bad_b")
        team = AgentTeam(
            orchestrator="claude-sonnet-4-5",
            agents=[bad_a, bad_b],
            strategy="parallel",
        )

        with caplog.at_level(logging.WARNING):
            result = await team.arun("task")

        assert result.answer == ""
        assert result.contributions == []
        assert result.message_trace == []


# ---------------------------------------------------------------------------
# Auto strategy
# ---------------------------------------------------------------------------


class TestAutoStrategy:
    """Tests for strategy='auto' execution."""

    @pytest.mark.asyncio
    async def test_auto_dispatches_sequentially(self):
        """Auto mode dispatches to each agent in order."""
        agents = [_make_agent(f"out-{i}", f"agent-{i}") for i in range(3)]
        team = AgentTeam(
            orchestrator="claude-sonnet-4-5",
            agents=agents,
            strategy="auto",
        )
        result = await team.arun("task")
        assert len(result.contributions) == 3
        for i, contrib in enumerate(result.contributions):
            assert contrib.result.text == f"out-{i}"

    @pytest.mark.asyncio
    async def test_auto_answer_joins_outputs(self):
        """Auto mode joins outputs with double newlines."""
        agents = [_make_agent("first", "a"), _make_agent("second", "b")]
        team = AgentTeam(
            orchestrator="claude-sonnet-4-5",
            agents=agents,
            strategy="auto",
        )
        result = await team.arun("task")
        assert result.answer == "first\n\nsecond"

    @pytest.mark.asyncio
    async def test_auto_message_trace_starts_with_user(self):
        """Auto mode message trace starts with the user task."""
        agents = [_make_agent("reply", "helper")]
        team = AgentTeam(
            orchestrator="claude-sonnet-4-5",
            agents=agents,
            strategy="auto",
        )
        result = await team.arun("my task")
        assert result.message_trace[0] == {
            "role": "user",
            "content": "my task",
        }

    @pytest.mark.asyncio
    async def test_auto_message_trace_includes_agent_labels(self):
        """Auto mode labels each agent's contribution in the trace."""
        agents = [_make_agent("hello", "greeter")]
        team = AgentTeam(
            orchestrator="claude-sonnet-4-5",
            agents=agents,
            strategy="auto",
        )
        result = await team.arun("task")
        # Second entry should be the agent's labelled response
        assert len(result.message_trace) >= 2
        assert "[greeter]" in result.message_trace[1]["content"]

    @pytest.mark.asyncio
    async def test_auto_skips_failed_agents(self, caplog):
        """Failed agents in auto mode are logged and skipped."""
        good = _make_agent("ok", "good")
        bad = _make_failing_agent(RuntimeError("fail"), "bad")
        team = AgentTeam(
            orchestrator="claude-sonnet-4-5",
            agents=[bad, good],
            strategy="auto",
        )

        with caplog.at_level(logging.WARNING):
            result = await team.arun("task")

        assert len(result.contributions) == 1
        assert result.contributions[0].result.text == "ok"
        assert "failed in auto team" in caplog.text

    @pytest.mark.asyncio
    async def test_auto_all_fail_empty_answer(self, caplog):
        """When all agents fail in auto mode, answer is empty."""
        bad = _make_failing_agent(RuntimeError("nope"), "bad")
        team = AgentTeam(
            orchestrator="claude-sonnet-4-5",
            agents=[bad],
            strategy="auto",
        )

        with caplog.at_level(logging.WARNING):
            result = await team.arun("task")

        assert result.answer == ""
        assert result.contributions == []

    @pytest.mark.asyncio
    async def test_auto_cost_accumulates(self):
        """Auto mode sums cost across all successful agents."""
        agents = [_make_agent("a", "x"), _make_agent("b", "y")]
        team = AgentTeam(
            orchestrator="claude-sonnet-4-5",
            agents=agents,
            strategy="auto",
        )
        result = await team.arun("task")
        assert result.total_cost >= 0


# ---------------------------------------------------------------------------
# Sync wrapper
# ---------------------------------------------------------------------------


class TestSyncRun:
    """Tests for the synchronous run() wrapper."""

    def test_sync_run_returns_team_result(self):
        """run() returns a TeamResult synchronously."""
        agents = [_make_agent("sync-out", "sync-agent")]
        team = AgentTeam(
            orchestrator="claude-sonnet-4-5",
            agents=agents,
            strategy="parallel",
        )
        result = team.run("task")
        assert result.answer == "sync-out"
        assert len(result.contributions) == 1

    def test_sync_run_auto_strategy(self):
        """run() works with auto strategy."""
        agents = [_make_agent("auto-out", "auto-agent")]
        team = AgentTeam(
            orchestrator="claude-sonnet-4-5",
            agents=agents,
            strategy="auto",
        )
        result = team.run("task")
        assert result.answer == "auto-out"


# ---------------------------------------------------------------------------
# Handoff schema
# ---------------------------------------------------------------------------


class TestHandoffSchema:
    """Tests for the handoff tool schema constants."""

    def test_handoff_tool_name(self):
        """HANDOFF_TOOL_NAME is the expected sentinel string."""
        assert HANDOFF_TOOL_NAME == "_synth_handoff"

    def test_handoff_schema_has_required_fields(self):
        """_HANDOFF_SCHEMA declares target_agent and context as required."""
        assert _HANDOFF_SCHEMA["name"] == HANDOFF_TOOL_NAME
        params = _HANDOFF_SCHEMA["parameters"]
        assert "target_agent" in params["properties"]
        assert "context" in params["properties"]
        assert set(params["required"]) == {"target_agent", "context"}


# ---------------------------------------------------------------------------
# Contribution details
# ---------------------------------------------------------------------------


class TestContributionDetails:
    """Tests for AgentContribution content within TeamResult."""

    @pytest.mark.asyncio
    async def test_contribution_agent_name_matches(self):
        """Each contribution's agent_name matches the agent's derived name."""
        agents = [_make_agent("r1", "researcher"), _make_agent("r2", "writer")]
        team = AgentTeam(
            orchestrator="claude-sonnet-4-5",
            agents=agents,
            strategy="parallel",
        )
        result = await team.arun("task")
        names = [c.agent_name for c in result.contributions]
        assert "researcher" in names
        assert "writer" in names

    @pytest.mark.asyncio
    async def test_contribution_result_text_preserved(self):
        """Each contribution preserves the agent's RunResult text."""
        agents = [_make_agent("output-A", "a"), _make_agent("output-B", "b")]
        team = AgentTeam(
            orchestrator="claude-sonnet-4-5",
            agents=agents,
            strategy="parallel",
        )
        result = await team.arun("task")
        texts = {c.result.text for c in result.contributions}
        assert texts == {"output-A", "output-B"}
