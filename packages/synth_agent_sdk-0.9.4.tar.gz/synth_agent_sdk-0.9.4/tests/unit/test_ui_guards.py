"""Unit tests for guard evaluation visibility in server.py.

Covers task 3.2: guard result emission for the testing UI.

**Property 9: Guard results completeness**
**Validates: Requirements 8.1**

**Property 10: Guard event ordering in SSE**
**Validates: Requirements 8.4**
"""

from __future__ import annotations

import asyncio
import json
import sys
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# Helpers — import server module with mocked StaticFiles
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _patch_static_files():
    """Patch StaticFiles to avoid directory check during server import."""
    with patch("starlette.staticfiles.StaticFiles.__init__", return_value=None):
        mod_name = "synth.cli._ui_assets.server"
        if mod_name in sys.modules:
            del sys.modules[mod_name]
        yield
        if mod_name in sys.modules:
            del sys.modules[mod_name]


def _get_server():
    """Import the server module for direct state inspection."""
    import synth.cli._ui_assets.server as srv
    return srv


def _make_mock_guard(
    name: str,
    guard_type: str = "CustomGuard",
    passed: bool = True,
    violation_message: str | None = None,
) -> MagicMock:
    """Build a mock guard with an async check() that returns a GuardResult."""
    guard = MagicMock()
    guard.name = name
    type(guard).__name__ = guard_type

    result = MagicMock()
    result.passed = passed
    result.violation_message = violation_message
    guard.check = AsyncMock(return_value=result)
    return guard


def _make_mock_agent_with_guards(
    guards: list[MagicMock],
) -> MagicMock:
    """Build a mock agent with a guards list."""
    agent = MagicMock()
    agent.guards = guards
    agent.model = "claude-sonnet-4-5"
    agent.instructions = "Be helpful."
    agent._registered_tools = {}
    return agent


_REQUIRED_FIELDS = {"name", "guard_type", "passed", "duration_ms", "violation_message"}


# ---------------------------------------------------------------------------
# Property 9: Guard results completeness
# ---------------------------------------------------------------------------


class TestGuardResultsCompleteness:
    """Property 9: For N guards, response contains N results with all fields.

    Validates: Requirements 8.1
    """

    def _setup(self, guards: list[MagicMock]) -> None:
        srv = _get_server()
        self.srv = srv
        agent = _make_mock_agent_with_guards(guards)
        srv._agent = agent

    async def test_zero_guards_returns_empty_list(self) -> None:
        """With no guards configured, _evaluate_guards_for_ui returns []."""
        self._setup([])
        results = await self.srv._evaluate_guards_for_ui("hello", [])
        assert results == []

    async def test_one_passing_guard_returns_one_result(self) -> None:
        """A single passing guard produces exactly one result with passed=True."""
        guard = _make_mock_guard("pii_check", "PIIGuard", passed=True)
        self._setup([guard])

        results = await self.srv._evaluate_guards_for_ui("hello", [])

        assert len(results) == 1
        assert results[0]["passed"] is True
        assert results[0]["name"] == "pii_check"
        assert results[0]["guard_type"] == "PIIGuard"
        assert results[0]["violation_message"] is None

    async def test_one_failing_guard_returns_one_result_with_violation(self) -> None:
        """A single failing guard produces a result with passed=False and a message."""
        guard = _make_mock_guard(
            "cost_limit", "CostGuard",
            passed=False, violation_message="Cost limit exceeded",
        )
        self._setup([guard])

        results = await self.srv._evaluate_guards_for_ui("hello", [])

        assert len(results) == 1
        assert results[0]["passed"] is False
        assert results[0]["violation_message"] == "Cost limit exceeded"

    async def test_three_guards_returns_three_results(self) -> None:
        """Three guards produce exactly three results, each with all fields."""
        guards = [
            _make_mock_guard("pii", "PIIGuard", passed=True),
            _make_mock_guard("cost", "CostGuard", passed=False,
                             violation_message="Over budget"),
            _make_mock_guard("tools", "ToolFilterGuard", passed=True),
        ]
        self._setup(guards)

        results = await self.srv._evaluate_guards_for_ui("hello", [])

        assert len(results) == 3
        for result in results:
            assert _REQUIRED_FIELDS == set(result.keys())

    async def test_all_results_have_required_fields(self) -> None:
        """Every result dict contains name, guard_type, passed, duration_ms,
        and violation_message."""
        guards = [
            _make_mock_guard("g1", "PIIGuard", passed=True),
            _make_mock_guard("g2", "CostGuard", passed=False,
                             violation_message="fail"),
        ]
        self._setup(guards)

        results = await self.srv._evaluate_guards_for_ui("test text", [])

        for result in results:
            assert isinstance(result["name"], str)
            assert isinstance(result["guard_type"], str)
            assert isinstance(result["passed"], bool)
            assert isinstance(result["duration_ms"], (int, float))
            assert result["duration_ms"] >= 0
            assert (result["violation_message"] is None
                    or isinstance(result["violation_message"], str))

    async def test_guard_exception_returns_failed_result(self) -> None:
        """A guard that raises an exception produces passed=False with the
        exception message as violation_message."""
        guard = _make_mock_guard("broken", "CustomGuard")
        guard.check = AsyncMock(side_effect=RuntimeError("guard crashed"))
        self._setup([guard])

        results = await self.srv._evaluate_guards_for_ui("hello", [])

        assert len(results) == 1
        assert results[0]["passed"] is False
        assert "guard crashed" in results[0]["violation_message"]
        assert results[0]["name"] == "broken"

    async def test_no_agent_returns_empty_list(self) -> None:
        """When no agent is loaded, returns an empty list."""
        srv = _get_server()
        srv._agent = None

        results = await srv._evaluate_guards_for_ui("hello", [])
        assert results == []

    async def test_agent_without_guards_attr_returns_empty(self) -> None:
        """An agent with no guards attribute returns an empty list."""
        srv = _get_server()
        srv._agent = MagicMock(spec=[])  # no guards attribute

        results = await srv._evaluate_guards_for_ui("hello", [])
        assert results == []

    async def test_duration_ms_is_non_negative(self) -> None:
        """All duration_ms values are non-negative numbers."""
        guards = [
            _make_mock_guard("fast", "PIIGuard", passed=True),
            _make_mock_guard("slow", "CostGuard", passed=True),
        ]
        self._setup(guards)

        results = await self.srv._evaluate_guards_for_ui("text", [])

        for result in results:
            assert result["duration_ms"] >= 0


# ---------------------------------------------------------------------------
# Property 10: Guard event ordering in SSE
# ---------------------------------------------------------------------------


class TestGuardEventOrdering:
    """Property 10: guard_result event appears before done in SSE stream.

    Validates: Requirements 8.4
    """

    def _setup_server(self) -> None:
        self.srv = _get_server()

    def _make_streaming_agent(
        self,
        response_text: str = "Hello!",
        guards: list[MagicMock] | None = None,
    ) -> MagicMock:
        """Build a mock agent whose stream() yields token + done events."""
        agent = MagicMock()
        agent.model = "claude-sonnet-4-5"
        agent.instructions = "Be helpful."
        agent._registered_tools = {}
        agent.guards = guards or []

        # Build mock events
        token_event = MagicMock()
        type(token_event).__name__ = "TokenEvent"
        token_event.text = response_text

        done_result = MagicMock()
        done_result.text = response_text
        done_result.output = None
        done_result.usage = MagicMock()
        done_result.usage.input_tokens = 10
        done_result.usage.output_tokens = 5
        done_result.cost = 0.001
        done_result.trace = None

        done_event = MagicMock()
        type(done_event).__name__ = "DoneEvent"
        done_event.result = done_result

        agent.stream = MagicMock(return_value=[token_event, done_event])
        return agent

    async def _collect_sse_events(
        self, response: Any,
    ) -> list[dict[str, Any]]:
        """Consume a StreamingResponse and parse SSE data lines."""
        events: list[dict[str, Any]] = []
        async for chunk in response.body_iterator:
            text = chunk if isinstance(chunk, str) else chunk.decode()
            for line in text.strip().split("\n"):
                if line.startswith("data: "):
                    data = json.loads(line[6:])
                    events.append(data)
        return events

    async def test_guard_result_before_done_with_guards(self) -> None:
        """When guards are configured, guard_result event precedes the final
        message event in the SSE stream."""
        self._setup_server()
        guard = _make_mock_guard("pii", "PIIGuard", passed=True)
        agent = self._make_streaming_agent(guards=[guard])
        self.srv._agent = agent

        # Build a mock request
        request = MagicMock()
        request.json = AsyncMock(return_value={
            "prompt": "hello",
            "conversation": "test-conv",
        })

        response = await self.srv.chat_stream(request)
        events = await self._collect_sse_events(response)

        # Find event type indices
        event_types = [e.get("type") for e in events]

        assert "guard_result" in event_types, (
            "guard_result event should be present when guards are configured"
        )

        guard_idx = event_types.index("guard_result")
        # The final event is the message (no explicit 'type' or type='done')
        # It's the last event in the stream — after guard_result
        assert guard_idx < len(events) - 1, (
            "guard_result must appear before the final message event"
        )

    async def test_no_guard_result_when_no_guards(self) -> None:
        """When no guards are configured, no guard_result event is emitted."""
        self._setup_server()
        agent = self._make_streaming_agent(guards=[])
        self.srv._agent = agent

        request = MagicMock()
        request.json = AsyncMock(return_value={
            "prompt": "hello",
            "conversation": "test-conv",
        })

        response = await self.srv.chat_stream(request)
        events = await self._collect_sse_events(response)

        event_types = [e.get("type") for e in events]
        assert "guard_result" not in event_types

    async def test_guard_result_contains_all_guard_entries(self) -> None:
        """The guard_result event's guards array has one entry per guard."""
        self._setup_server()
        guards = [
            _make_mock_guard("pii", "PIIGuard", passed=True),
            _make_mock_guard("cost", "CostGuard", passed=False,
                             violation_message="Over limit"),
        ]
        agent = self._make_streaming_agent(guards=guards)
        self.srv._agent = agent

        request = MagicMock()
        request.json = AsyncMock(return_value={
            "prompt": "hello",
            "conversation": "test-conv",
        })

        response = await self.srv.chat_stream(request)
        events = await self._collect_sse_events(response)

        guard_events = [e for e in events if e.get("type") == "guard_result"]
        assert len(guard_events) == 1

        guard_data = guard_events[0]["guards"]
        assert len(guard_data) == 2
        names = [g["name"] for g in guard_data]
        assert "pii" in names
        assert "cost" in names

    async def test_guard_result_event_has_correct_structure(self) -> None:
        """The guard_result SSE event has type='guard_result' and a guards array
        where each entry has all required fields."""
        self._setup_server()
        guard = _make_mock_guard(
            "my_guard", "CustomGuard",
            passed=False, violation_message="bad content",
        )
        agent = self._make_streaming_agent(guards=[guard])
        self.srv._agent = agent

        request = MagicMock()
        request.json = AsyncMock(return_value={
            "prompt": "test",
            "conversation": "test-conv",
        })

        response = await self.srv.chat_stream(request)
        events = await self._collect_sse_events(response)

        guard_events = [e for e in events if e.get("type") == "guard_result"]
        assert len(guard_events) == 1

        event = guard_events[0]
        assert event["type"] == "guard_result"
        assert isinstance(event["guards"], list)

        entry = event["guards"][0]
        assert _REQUIRED_FIELDS == set(entry.keys())
        assert entry["name"] == "my_guard"
        assert entry["passed"] is False
        assert entry["violation_message"] == "bad content"

    async def test_token_events_precede_guard_result(self) -> None:
        """Token events appear before guard_result in the SSE stream."""
        self._setup_server()
        guard = _make_mock_guard("check", "PIIGuard", passed=True)
        agent = self._make_streaming_agent(
            response_text="Hi there", guards=[guard],
        )
        self.srv._agent = agent

        request = MagicMock()
        request.json = AsyncMock(return_value={
            "prompt": "hello",
            "conversation": "test-conv",
        })

        response = await self.srv.chat_stream(request)
        events = await self._collect_sse_events(response)

        event_types = [e.get("type") for e in events]
        token_indices = [i for i, t in enumerate(event_types) if t == "token"]
        guard_idx = event_types.index("guard_result")

        assert all(ti < guard_idx for ti in token_indices), (
            "All token events should precede guard_result"
        )
