"""Unit tests for the StructuredOutputHandler.

Verifies system message generation, JSON parsing, retry behaviour with
corrective prompts, and SynthParseError after exhausting retries.
"""

from __future__ import annotations

import json

import pytest
from pydantic import BaseModel

from synth.errors import SynthParseError
from synth.providers.base import ProviderResponse
from synth.structured.output import StructuredOutputHandler
from synth.types import TokenUsage


# ---------------------------------------------------------------------------
# Test schemas
# ---------------------------------------------------------------------------


class UserProfile(BaseModel):
    name: str
    age: int


class Address(BaseModel):
    street: str
    city: str
    zip_code: str


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_USAGE = TokenUsage(input_tokens=5, output_tokens=10, total_tokens=15)


# ---------------------------------------------------------------------------
# TestGetSystemMessage
# ---------------------------------------------------------------------------


class TestGetSystemMessage:
    """Tests for ``get_system_message()``."""

    def test_includes_json_schema(self) -> None:
        handler = StructuredOutputHandler(schema=UserProfile)
        msg = handler.get_system_message()
        schema = UserProfile.model_json_schema()
        assert json.dumps(schema, indent=2) in msg

    def test_includes_json_only_instruction(self) -> None:
        handler = StructuredOutputHandler(schema=UserProfile)
        msg = handler.get_system_message()
        assert "Output ONLY the JSON" in msg

    def test_includes_schema_properties(self) -> None:
        handler = StructuredOutputHandler(schema=Address)
        msg = handler.get_system_message()
        assert "street" in msg
        assert "city" in msg
        assert "zip_code" in msg


# ---------------------------------------------------------------------------
# TestParse
# ---------------------------------------------------------------------------


class TestParse:
    """Tests for the synchronous ``parse()`` method."""

    def test_valid_json_returns_model_instance(self) -> None:
        handler = StructuredOutputHandler(schema=UserProfile)
        result = handler.parse('{"name": "Alice", "age": 30}')
        assert isinstance(result, UserProfile)
        assert result.name == "Alice"
        assert result.age == 30

    def test_invalid_json_raises_json_error(self) -> None:
        handler = StructuredOutputHandler(schema=UserProfile)
        with pytest.raises(json.JSONDecodeError):
            handler.parse("not json at all")

    def test_valid_json_wrong_schema_raises_validation_error(self) -> None:
        handler = StructuredOutputHandler(schema=UserProfile)
        from pydantic import ValidationError

        with pytest.raises(ValidationError):
            handler.parse('{"name": "Alice"}')  # missing required 'age'

    def test_parse_with_extra_fields_succeeds(self) -> None:
        handler = StructuredOutputHandler(schema=UserProfile)
        result = handler.parse('{"name": "Bob", "age": 25, "extra": true}')
        assert isinstance(result, UserProfile)
        assert result.name == "Bob"


# ---------------------------------------------------------------------------
# TestParseAndValidate
# ---------------------------------------------------------------------------


class TestParseAndValidate:
    """Tests for ``parse_and_validate()`` with retry logic."""

    @pytest.mark.asyncio
    async def test_successful_parse_on_first_attempt(self) -> None:
        handler = StructuredOutputHandler(schema=UserProfile)
        # Provider should not be called when the first attempt succeeds.
        from tests.conftest import MockProvider

        provider = MockProvider()
        messages: list[dict[str, str]] = []

        result = await handler.parse_and_validate(
            '{"name": "Alice", "age": 30}', provider, messages
        )

        assert isinstance(result, UserProfile)
        assert result.name == "Alice"
        assert len(provider.call_history) == 0

    @pytest.mark.asyncio
    async def test_retries_on_invalid_json_then_succeeds(self) -> None:
        from tests.conftest import MockProvider

        valid_json = '{"name": "Bob", "age": 42}'
        provider = MockProvider(
            responses=[ProviderResponse(text=valid_json, usage=_USAGE)]
        )
        handler = StructuredOutputHandler(schema=UserProfile, max_retries=2)
        messages: list[dict[str, str]] = []

        result = await handler.parse_and_validate(
            "bad json", provider, messages
        )

        assert isinstance(result, UserProfile)
        assert result.name == "Bob"
        assert len(provider.call_history) == 1

    @pytest.mark.asyncio
    async def test_retries_on_validation_error_then_succeeds(self) -> None:
        from tests.conftest import MockProvider

        valid_json = '{"name": "Carol", "age": 28}'
        provider = MockProvider(
            responses=[ProviderResponse(text=valid_json, usage=_USAGE)]
        )
        handler = StructuredOutputHandler(schema=UserProfile, max_retries=2)
        messages: list[dict[str, str]] = []

        # Missing 'age' triggers ValidationError on first attempt
        result = await handler.parse_and_validate(
            '{"name": "Carol"}', provider, messages
        )

        assert isinstance(result, UserProfile)
        assert result.age == 28
        assert len(provider.call_history) == 1

    @pytest.mark.asyncio
    async def test_corrective_messages_appended_on_retry(self) -> None:
        from tests.conftest import MockProvider

        valid_json = '{"name": "Dan", "age": 35}'
        provider = MockProvider(
            responses=[ProviderResponse(text=valid_json, usage=_USAGE)]
        )
        handler = StructuredOutputHandler(schema=UserProfile, max_retries=2)
        messages: list[dict[str, str]] = []

        await handler.parse_and_validate("not json", provider, messages)

        # Should have appended assistant + user corrective messages
        assert len(messages) == 2
        assert messages[0]["role"] == "assistant"
        assert messages[0]["content"] == "not json"
        assert messages[1]["role"] == "user"
        assert "not valid JSON" in messages[1]["content"]

    @pytest.mark.asyncio
    async def test_raises_synth_parse_error_after_max_retries(self) -> None:
        from tests.conftest import MockProvider

        # Provider always returns invalid JSON
        provider = MockProvider(
            responses=[ProviderResponse(text="still bad", usage=_USAGE)]
        )
        handler = StructuredOutputHandler(schema=UserProfile, max_retries=2)
        messages: list[dict[str, str]] = []

        with pytest.raises(SynthParseError, match="after 2 retries") as exc_info:
            await handler.parse_and_validate("bad", provider, messages)

        err = exc_info.value
        assert err.component == "StructuredOutputHandler"
        assert "UserProfile" in err.suggestion

    @pytest.mark.asyncio
    async def test_max_retries_zero_raises_immediately(self) -> None:
        from tests.conftest import MockProvider

        provider = MockProvider()
        handler = StructuredOutputHandler(schema=UserProfile, max_retries=0)
        messages: list[dict[str, str]] = []

        with pytest.raises(SynthParseError, match="after 0 retries"):
            await handler.parse_and_validate("bad json", provider, messages)

        # No provider calls should have been made
        assert len(provider.call_history) == 0

    @pytest.mark.asyncio
    async def test_multiple_retries_before_success(self) -> None:
        from tests.conftest import MockProvider

        # First retry returns bad JSON, second retry returns valid JSON
        provider = MockProvider(
            responses=[
                ProviderResponse(text="still bad", usage=_USAGE),
                ProviderResponse(
                    text='{"name": "Eve", "age": 22}', usage=_USAGE
                ),
            ]
        )
        handler = StructuredOutputHandler(schema=UserProfile, max_retries=3)
        messages: list[dict[str, str]] = []

        result = await handler.parse_and_validate("bad", provider, messages)

        assert isinstance(result, UserProfile)
        assert result.name == "Eve"
        assert len(provider.call_history) == 2

    @pytest.mark.asyncio
    async def test_parse_error_chains_original_exception(self) -> None:
        from tests.conftest import MockProvider

        provider = MockProvider(
            responses=[ProviderResponse(text="nope", usage=_USAGE)]
        )
        handler = StructuredOutputHandler(schema=UserProfile, max_retries=1)
        messages: list[dict[str, str]] = []

        with pytest.raises(SynthParseError) as exc_info:
            await handler.parse_and_validate("bad", provider, messages)

        assert exc_info.value.__cause__ is not None
