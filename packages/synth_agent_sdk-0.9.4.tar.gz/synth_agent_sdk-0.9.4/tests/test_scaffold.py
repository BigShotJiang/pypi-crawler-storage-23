"""Verify Task 1.1: package structure, pyproject.toml, and imports."""
import tomllib
from pathlib import Path


def test_pyproject_core_deps():
    with open("pyproject.toml", "rb") as f:
        config = tomllib.load(f)
    deps = config["project"]["dependencies"]
    assert len(deps) == 6, f"Expected 6 core deps, got {len(deps)}"
    dep_names = [d.split(">=")[0].split(">")[0].split("<")[0] for d in deps]
    assert "pydantic" in dep_names
    assert "httpx" in dep_names
    assert "click" in dep_names
    assert "typing-extensions" in dep_names
    assert "rich" in dep_names
    assert "prompt-toolkit" in dep_names


def test_pyproject_extras():
    with open("pyproject.toml", "rb") as f:
        config = tomllib.load(f)
    extras = config["project"]["optional-dependencies"]
    assert "anthropic" in extras
    assert "openai" in extras
    assert "bedrock" in extras
    assert "agentcore" in extras
    assert "all" in extras
    assert "google" in extras
    assert "ollama" in extras


def test_pyproject_python_version():
    with open("pyproject.toml", "rb") as f:
        config = tomllib.load(f)
    assert config["project"]["requires-python"] == ">=3.10"


def test_pyproject_cli_entry():
    with open("pyproject.toml", "rb") as f:
        config = tomllib.load(f)
    assert config["project"]["scripts"]["synth"] == "synth.cli.main:cli"


def test_synth_package_imports():
    import synth
    assert synth.__version__ == "0.9.4"
    assert len(synth.__all__) > 0


def test_package_structure():
    """Verify all expected directories and __init__.py files exist."""
    expected_packages = [
        "synth",
        "synth/tools",
        "synth/providers",
        "synth/memory",
        "synth/orchestration",
        "synth/guards",
        "synth/tracing",
        "synth/checkpointing",
        "synth/eval",
        "synth/structured",
        "synth/deploy",
        "synth/deploy/agentcore",
        "synth/cli",
    ]
    for pkg in expected_packages:
        init = Path(pkg) / "__init__.py"
        assert init.exists(), f"Missing {init}"


def test_expected_modules_exist():
    """Verify all expected module files exist."""
    expected_modules = [
        "synth/agent.py",
        "synth/types.py",
        "synth/errors.py",
        "synth/_compat.py",
        "synth/tools/decorator.py",
        "synth/tools/toolkit.py",
        "synth/tools/executor.py",
        "synth/providers/router.py",
        "synth/providers/base.py",
        "synth/providers/anthropic.py",
        "synth/providers/openai.py",
        "synth/providers/google.py",
        "synth/providers/ollama.py",
        "synth/providers/bedrock.py",
        "synth/providers/retry.py",
        "synth/memory/base.py",
        "synth/memory/thread.py",
        "synth/memory/persistent.py",
        "synth/memory/semantic.py",
        "synth/orchestration/pipeline.py",
        "synth/orchestration/graph.py",
        "synth/orchestration/team.py",
        "synth/orchestration/human_in_loop.py",
        "synth/guards/base.py",
        "synth/guards/pii.py",
        "synth/guards/cost.py",
        "synth/guards/tool_filter.py",
        "synth/guards/custom.py",
        "synth/tracing/trace.py",
        "synth/tracing/exporter.py",
        "synth/tracing/integrations.py",
        "synth/checkpointing/base.py",
        "synth/checkpointing/local.py",
        "synth/checkpointing/redis.py",
        "synth/eval/eval.py",
        "synth/eval/scorers.py",
        "synth/eval/report.py",
        "synth/structured/output.py",
        "synth/deploy/packager.py",
        "synth/deploy/agentcore/adapter.py",
        "synth/deploy/agentcore/handler.py",
        "synth/deploy/agentcore/manifest.py",
        "synth/deploy/agentcore/memory.py",
        "synth/cli/main.py",
        "synth/cli/dev.py",
        "synth/cli/run_cmd.py",
        "synth/cli/eval_cmd.py",
        "synth/cli/trace_cmd.py",
        "synth/cli/deploy_cmd.py",
        "synth/cli/doctor.py",
        "synth/cli/banner.py",
        "synth/cli/help_cmd.py",
        "synth/cli/init_cmd.py",
        "synth/cli/bench_cmd.py",
    ]
    for mod in expected_modules:
        assert Path(mod).exists(), f"Missing {mod}"


def test_test_directory_structure():
    """Verify test directories exist."""
    assert Path("tests/conftest.py").exists()
    assert Path("tests/unit/__init__.py").exists()
    assert Path("tests/property/__init__.py").exists()


def test_extras_isolation():
    """Each provider extra should only install its own SDK (Req 18.3)."""
    with open("pyproject.toml", "rb") as f:
        config = tomllib.load(f)
    extras = config["project"]["optional-dependencies"]
    # anthropic extra should only have anthropic
    assert len(extras["anthropic"]) == 1
    assert "anthropic" in extras["anthropic"][0]
    # openai extra should only have openai
    assert len(extras["openai"]) == 1
    assert "openai" in extras["openai"][0]
    # bedrock extra should only have boto3
    assert len(extras["bedrock"]) == 1
    assert "boto3" in extras["bedrock"][0]
