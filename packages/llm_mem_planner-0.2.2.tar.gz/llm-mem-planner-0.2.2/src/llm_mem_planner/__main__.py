# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

from llm_mem_planner.cli import main


if __name__ == "__main__":
    main()

