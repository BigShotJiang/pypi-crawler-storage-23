# aioairctrl

Library and commandline utilities for controlling Philips air purifiers (using encrypted CoAP)
