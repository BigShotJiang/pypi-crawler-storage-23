from aioairctrl.coap.client import Client as CoAPClient
