from aioairctrl.coap.client import Client
