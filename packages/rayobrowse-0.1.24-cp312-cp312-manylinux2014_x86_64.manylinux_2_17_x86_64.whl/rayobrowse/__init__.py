"""
Rayobyte Stealth Browser SDK

Lightweight client for the rayobrowse Docker daemon.
Talks to the daemon over HTTP — no local Chromium or fonts needed.

Usage:
    from rayobrowse import create_browser
    ws_url = create_browser(headless=False, target_os="windows")
"""

import logging
import os

logger = logging.getLogger(__name__)

from importlib.metadata import version as _get_version
try:
    __version__ = _get_version("rayobrowse")
except Exception:
    __version__ = "0.0.0"

from .daemon.client import create_browser

__all__ = ["create_browser"]

try:
    from .config import configure_logging
    configure_logging(context="client")
except Exception:
    pass

def _check_sdk_version():
    """Background check for newer SDK versions (non-blocking)."""
    try:
        if os.environ.get("STEALTH_BROWSER_CHROME_EXECUTABLE", "").strip():
            return
        from .config import MANIFEST_URL
        import requests
        resp = requests.get(MANIFEST_URL, timeout=5)
        latest = resp.json().get("latest_versions", {}).get("sdk")
        if latest and latest != __version__ and __version__ != "0.0.0":
            logger.warning(
                "A newer rayobrowse SDK is available: v%s (you have v%s). "
                "Update with: pip install --upgrade rayobrowse",
                latest, __version__,
            )
    except Exception:
        pass

import threading
threading.Thread(target=_check_sdk_version, daemon=True).start()
