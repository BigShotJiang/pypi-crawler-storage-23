# QuranPro

Professional Quran API for Python

## Installation

```bash
pip install quranpro
```

## Usage

```
from quranpro import Quran
from quranpro.core import load_quran

Quran = Quran()
load_quran(Quran)

# Get any ayah from the Quran by surah and ayah number
ayah = Quran.get_ayah(1,1)

# Get translations in 9 languages. (Try Quran.get_metadata() for available recitations and translations )
ayah.get_translation(langugage='uz')

# Get recitation for the ayah 
ayah.get_recitation(reciter='alafasy') # Reciter is optional. By default it is Mishary Rashid Alafasy

# Get ayah metadata: The number of ayah, text length, number of words and weather it is sajda ayah or not.
ayah.get_metadata()

```
