RECITER_AUDIO_FORMAT_MAP = {
   "sudais": "Abdurrahmaan_As-Sudais_192kbps",
    "alafasy": "Alafasy_128kbps",
    "abdulsamad": "AbdulSamad_64kbps_QuranExplorer.Com",
    "husary": "Husary_128kbps",
    "muaiqly": "MaherALMuaiqly128kbps",
}

AVAILABLE_TRANSLATIONS = {
    "en": "English",
    "de": "German",
    "fr": "French",
    "es": "Spanish",
    "ur": "Urdu",
    "ug": "Uyghur",
    "uz": "Uzbek",
}

AVAILABLE_RECITERS = {
    "sudais": "Sheikh Abdul Rahman Al-Sudais",
    "alafasy": "Sheikh Mishary Rashid Alafasy",
    "abdulsamad": "Qari Abdul Basit Abdul Samad",
    "husary": "Sheikh Mahmoud Khalil Al-Hussary",
    "muaiqly": "Sheikh Maher Al-Muaiqly",
}