import json

quran_dict = {}

with open("ug.saleh.txt", "r", encoding="utf-8") as f:
    
    for line in f:
        line = line.strip()
        if not line:
            continue
    
        parts = line.split("|")
        if not parts or len(parts) < 3:
            print(f"Skipping malformed line: {line}")
            continue

        surah_number, ayah_number, ayah_text = parts
        surah_key = str(surah_number)
        ayah_key = str(ayah_number)

        if surah_key not in quran_dict:
            quran_dict[surah_key] = {}

        quran_dict[surah_key][ayah_key] = ayah_text
    

with open("ug.saleh.json", "w", encoding="utf-8") as f:
    json.dump(quran_dict, f, ensure_ascii=False, indent=4)