from .utils import RECITER_AUDIO_FORMAT_MAP, AVAILABLE_TRANSLATIONS, AVAILABLE_RECITERS


class _Ayah:
    def __init__(self, number: str, text: str, translations: dict) -> None:
        self._number = int(number)
        self._text = text
        self._translations = translations
        self._surah = None
    
    def __str__(self) -> str:
        """Returns a string representation of the Ayah."""
        return f"Ayah {self.number}: {self.text}"
    
    @property
    def number(self) -> int:
        """Returns the Ayah number."""
        return self._number
    
    @property
    def text(self) -> str:
        """Returns the Arabic text of the Ayah."""
        return self._text
    
    @property
    def translations(self) -> dict:
        """Returns a dictionary of translations for the Ayah."""
        return self._translations
    
    @property
    def surah(self):
        """Returns the Surah object that the Ayah belongs to."""
        return self._surah

    @surah.setter
    def surah(self, value):
        """Sets the Surah object that the Ayah belongs to."""
        self._surah = value
    
    def get_recitation(self, reciter='alafasy') -> str:
        """Returns a string representing the audio for the Ayah recited by the specified reciter.""" 
        reciter_str = RECITER_AUDIO_FORMAT_MAP.get(reciter)

        if not reciter_str:
            return f"Audio format for reciter: {reciter} not found."

        base_url = "https://everyayah.com/data"
        surah_str = f"{self.surah.number:03d}"
        ayah_str = f"{self.number:03d}"

        return f"{base_url}/{reciter_str}/{surah_str}{ayah_str}.mp3"

    def get_translation(self, language: str) -> str:
        """Returns a string representing the translation of the Ayah in the specified language."""
        translation = self.translations.get(language)
        if not translation:
            raise ValueError(f"Given translations is not available. Available translations: {AVAILABLE_TRANSLATIONS}")
        return translation
          
    
    def get_metadata(self) -> dict:
        """Returns a dictionary containing metadata about the Ayah."""
        return {
            "number": self.number,
            "text_length": len(self.text),
            "word_count": len(self.text.split()),
            "is_sajda_ayah": self.check_if_sajda()
        }

    def check_if_sajda(self) -> bool:
        """Checks if the Ayah is a Sajda Ayah."""
        sajda_ayah_map = {7:206, 13:15, 16:50, 17:109, 19:58, 22:18, 22:77, 25:60, 27:26, 32:15, 38:24, 41:38, 53:62, 84:21, 96:19 }
        return self.surah.number in sajda_ayah_map.keys() and sajda_ayah_map[self.surah.number] == self.number


class _Surah:
    def __init__(self, number: str, aya_count: int, start: int, name: str, tname: str, ename: str, type: str) -> None:
        self._number = int(number)
        self._aya_count = aya_count
        self._start = start
        self._name = name
        self._tname = tname
        self._ename = ename
        self._type = type
        self.ayahs = {}

    def __str__(self):
        """Returns a string representation of the Surah."""
        return f"Surah {self.number}: {self.name} with {len(self.ayahs)} Ayahs"

    @property
    def number(self) -> int:
        """Returns the Surah number."""
        return self._number

    @property
    def aya_count(self) -> int:
        """Returns the number of Ayahs in the Surah."""
        return self._aya_count

    @property
    def start(self) -> int:
        """Returns the starting Ayah number of the Surah."""
        return self._start

    @property
    def name(self) -> str:
        """Returns the name of the Surah."""
        return self._name

    @property
    def tname(self) -> str:
        """Returns the transliteration name of the Surah."""
        return self._tname

    @property
    def ename(self) -> str:
        """Returns the English name of the Surah."""
        return self._ename

    @property
    def type(self) -> str:
        """Returns the type of the Surah (Meccan or Medinan)."""
        return self._type

    def _add_ayah(self, ayah: _Ayah):
        """Adds an Ayah to the Surah."""
        ayah.surah = self
        self.ayahs[str(ayah._number)] = ayah
        
    def get_ayah(self, number: int) -> _Ayah:
        """Returns the Ayah with the specified number."""
        ayah = self.ayahs.get(str(number))
        if ayah:
            return ayah
        raise ValueError(f"Ayah with number {number} not found in Surah {self.number}.")
    
    def get_metadata(self) -> dict:
        """Returns a dictionary containing metadata about the Surah."""
        return {
            "number": self.number,
            "start": self.start,
            "name": self.name,
            "tname": self.tname,
            "ename": self.ename,
            "type": self.type,
            "ayah_count": self.aya_count
        }
    
class Quran:
    def __init__(self, riwayah = "hafs") -> None:
        self._riwayah = riwayah
        self.surahs = {}

    def __str__(self) -> str:
        """Returns a string representation of the Quran object. """
        return (f"Quran with translations and audio.\nRiwayah: {self.riwayah}.\nAvailable translations: {AVAILABLE_TRANSLATIONS}.\nAvailable reciters: {AVAILABLE_RECITERS}.")
    
    @property
    def riwayah(self) -> str:
        """Returns the riwayah of the Quran."""
        return self._riwayah

    def _add_surah(self, surah: _Surah):
        """Adds a Surah to the Quran."""
        self.surahs[str(surah.number)] = surah

    def get_surah(self, number: int) -> _Surah:
        """Returns the Surah with the specified number."""
        return self.surahs.get(str(number), None)
    
    def get_ayah(self, surah_number: int, ayah_number: int) -> _Ayah:
        """Returns the Ayah with the specified Surah and Ayah number."""
        surah = self.get_surah(str(surah_number))
        if surah:
            return surah.get_ayah(str(ayah_number))
        raise ValueError(f"Surah with number {surah_number} not found in the Quran.")

    def get_metadata(self) -> dict:
        """Returns metadata for Quran object"""
        return {
            "riwayah": self.riwayah,
            "translations": AVAILABLE_TRANSLATIONS,
            "reciters": list(RECITER_AUDIO_FORMAT_MAP.keys())
        }
    