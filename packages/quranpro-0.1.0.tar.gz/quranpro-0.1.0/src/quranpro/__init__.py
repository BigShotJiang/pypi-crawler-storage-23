from .models import Quran

__all__ = ['Quran']

__version__ = '0.1.0'