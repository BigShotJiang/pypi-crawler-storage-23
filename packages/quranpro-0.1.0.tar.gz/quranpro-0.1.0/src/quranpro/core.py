import json
from importlib import resources

from .models import Quran, _Surah, _Ayah


def load_json(file_name: str) -> dict:
    """Load a JSON file from the package resources."""
    with resources.open_text('quranpro.data', file_name, encoding='utf-8') as f:
        return json.load(f)


def load_quran(q: Quran) -> Quran:
    """Load the Quran data from the JSON file and return a Quran object."""
    metadata = load_json('quran_metadata.json')
    arabic = load_json('arabic.json')
    translations = load_json('translations.json')

    for surah_number in metadata.keys():

        number, aya_count, start, name, tname, ename, type, rukus, order = metadata[surah_number].values() 
        surah = _Surah(number, aya_count, start, name, tname, ename, type)

        for ayah_number, ayah_text in arabic[surah_number].items():
            translation_dict = {}
            for lang in translations.keys():
                translation_dict[lang] = translations[lang][surah_number][ayah_number]

            ayah = _Ayah(ayah_number, ayah_text, translation_dict)
            surah._add_ayah(ayah)
        
        
        q._add_surah(surah)
        
    return q

q = Quran('hafs')
load_quran(q)