"""
Process template loading, validation, and creation.

Templates define the steps, dependencies, and checks for a process.
"""

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class Step:
    """A single process step."""

    id: str
    name: str
    check: str  # Shell command to run
    dependencies: list[str] = field(default_factory=list)
    critical: bool = False
    timeout_seconds: int = 30
    intent: str = ""
    on_failure: str = ""  # Optional remediation command

    @classmethod
    def from_dict(cls, data: dict) -> "Step":
        return cls(
            id=data["id"],
            name=data["name"],
            check=data["check"],
            dependencies=data.get("dependencies", []),
            critical=data.get("critical", False),
            timeout_seconds=data.get("timeout_seconds", 30),
            intent=data.get("intent", ""),
            on_failure=data.get("on_failure", ""),
        )

    def to_dict(self) -> dict:
        d = {
            "id": self.id,
            "name": self.name,
            "check": self.check,
            "dependencies": self.dependencies,
            "critical": self.critical,
        }
        if self.timeout_seconds != 30:
            d["timeout_seconds"] = self.timeout_seconds
        if self.intent:
            d["intent"] = self.intent
        if self.on_failure:
            d["on_failure"] = self.on_failure
        return d


@dataclass
class ProcessTemplate:
    """A complete process template."""

    process_id: str
    name: str
    version: str
    steps: list[Step]
    description: str = ""
    success_criteria: dict = field(default_factory=dict)
    alerts: dict = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict) -> "ProcessTemplate":
        return cls(
            process_id=data["process_id"],
            name=data["name"],
            version=data.get("version", "1.0.0"),
            steps=[Step.from_dict(s) for s in data["steps"]],
            description=data.get("description", ""),
            success_criteria=data.get("success_criteria", {}),
            alerts=data.get("alerts", {}),
        )

    def to_dict(self) -> dict:
        d = {
            "process_id": self.process_id,
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "steps": [s.to_dict() for s in self.steps],
        }
        if self.success_criteria:
            d["success_criteria"] = self.success_criteria
        if self.alerts:
            d["alerts"] = self.alerts
        return d

    @property
    def step_ids(self) -> set[str]:
        return {s.id for s in self.steps}

    @property
    def critical_steps(self) -> list[Step]:
        return [s for s in self.steps if s.critical]


def load_template(path: str | Path) -> ProcessTemplate:
    """Load a process template from JSON file."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Template not found: {path}")

    with open(path) as f:
        data = json.load(f)

    template = ProcessTemplate.from_dict(data)
    errors = validate_template(template)
    if errors:
        raise ValueError(f"Invalid template: {'; '.join(errors)}")

    return template


def validate_template(template: ProcessTemplate) -> list[str]:
    """Validate a process template. Returns list of errors (empty = valid)."""
    errors = []

    if not template.process_id:
        errors.append("process_id is required")
    if not template.name:
        errors.append("name is required")
    if not template.steps:
        errors.append("at least one step is required")

    step_ids = set()
    for step in template.steps:
        if step.id in step_ids:
            errors.append(f"duplicate step id: {step.id}")
        step_ids.add(step.id)

        if not step.check:
            errors.append(f"step {step.id}: check command is required")

        for dep in step.dependencies:
            if dep not in template.step_ids:
                errors.append(f"step {step.id}: unknown dependency '{dep}'")

    # Check for circular dependencies
    if not errors:
        visited = set()
        path = set()

        def has_cycle(step_id: str) -> bool:
            if step_id in path:
                return True
            if step_id in visited:
                return False
            visited.add(step_id)
            path.add(step_id)
            step = next(s for s in template.steps if s.id == step_id)
            for dep in step.dependencies:
                if has_cycle(dep):
                    return True
            path.discard(step_id)
            return False

        for step in template.steps:
            if has_cycle(step.id):
                errors.append(f"circular dependency detected involving '{step.id}'")
                break

    return errors


def create_template(
    process_id: str,
    name: str,
    steps: list[dict],
    *,
    description: str = "",
    version: str = "1.0.0",
) -> ProcessTemplate:
    """Create a new process template programmatically."""
    return ProcessTemplate(
        process_id=process_id,
        name=name,
        version=version,
        description=description,
        steps=[Step.from_dict(s) for s in steps],
    )
