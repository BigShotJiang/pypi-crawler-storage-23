"""
tibet-pol — Process Integrity Checker
======================================

Every step a TIBET token. Every deviation an alert.
"Pol kan nooit meer vergeten een knop in te drukken."

Usage::

    from tibet_pol import ProcessChecker, load_template

    template = load_template("my_deploy.json")
    checker = ProcessChecker()
    results = checker.run(template)
    print(results.summary)

CLI::

    tibet-pol check deploy.json
    tibet-pol check --json ci_pipeline.json | jq .summary
    tibet-pol init my_process.json
    tibet-pol diff run1.json run2.json
    tibet-pol watch deploy.json --interval 300

Authors: J. van de Meent & R. AI (Root AI)
License: MIT — Humotica AI Lab 2025-2026
"""

from .checker import ProcessChecker, ProcessResult, StepResult
from .template import load_template, validate_template, create_template
from .provenance import ProcessProvenance

__version__ = "0.1.0"

__all__ = [
    "ProcessChecker",
    "ProcessResult",
    "StepResult",
    "ProcessProvenance",
    "load_template",
    "validate_template",
    "create_template",
]
