"""
tibet-pol CLI — Process Integrity Checker from the command line.

Usage::

    tibet-pol check deploy.json
    tibet-pol check --json ci_pipeline.json | jq .summary
    tibet-pol init my_process.json
    tibet-pol diff run1.json run2.json
    tibet-pol watch deploy.json --interval 300
    tibet-pol report run_result.json
"""

import argparse
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

from .checker import ProcessChecker, ProcessResult
from .template import load_template, ProcessTemplate


def print_report(result: ProcessResult) -> None:
    """Print a formatted integrity report."""
    summary = result.summary
    status_mark = "✅" if summary["status"] == "COMPLETE" else "⚠️"

    print()
    print("=" * 55)
    print("📋 TIBET-POL PROCESS INTEGRITY REPORT")
    print(f"   Process: {result.process_name}")
    print(f"   Started: {result.started_at}")
    print("=" * 55)

    print(f"\n{status_mark} Status: {summary['status']}")
    print(f"   Checksum: {summary['checksum']} ({summary['percentage']}%)")
    print(f"   ├── Success: {summary['success']}")
    print(f"   ├── Failed:  {summary['failed']}")
    print(f"   ├── Blocked: {summary['blocked']}")
    print(f"   └── Skipped: {summary['skipped']}")

    if summary["failed"] > 0 or summary["blocked"] > 0:
        print("\n⚠️  ISSUES:")
        for step in result.steps:
            if step.status in ("FAILED", "BLOCKED"):
                print(f"   • {step.step_name}: {step.status}")
                if step.error:
                    print(f"     └─ {step.error[:80]}")

    print()
    print("=" * 55)


def cmd_check(args: argparse.Namespace) -> int:
    """Run a process check."""
    template = load_template(args.template)

    if not args.quiet and not args.json:
        print(f"\n🔍 tibet-pol: Checking '{template.name}'...\n")

    checker = ProcessChecker(
        verbose=not args.quiet and not args.json,
    )
    result = checker.run(template)

    if args.json:
        print(json.dumps(result.to_dict(), indent=2))
    elif not args.quiet:
        print_report(result)

    # Save if requested
    if args.save:
        output_dir = Path(args.save_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        filepath = output_dir / f"{result.process_id}_{ts}.json"
        with open(filepath, "w") as f:
            json.dump(result.to_dict(), f, indent=2)
        if not args.quiet:
            print(f"💾 Saved to: {filepath}")

    return 0 if result.summary["status"] == "COMPLETE" else 1


def cmd_init(args: argparse.Namespace) -> int:
    """Create a new process template interactively."""
    output = Path(args.output)

    template = {
        "process_id": output.stem,
        "name": input("Process name: ") if not args.name else args.name,
        "version": "1.0.0",
        "description": "",
        "steps": [
            {
                "id": "step_1",
                "name": "First Step",
                "check": "echo 'replace with your check command'",
                "dependencies": [],
                "critical": True,
            },
            {
                "id": "step_2",
                "name": "Second Step",
                "check": "echo 'replace with your check command'",
                "dependencies": ["step_1"],
                "critical": False,
            },
        ],
        "success_criteria": {
            "all_critical": True,
            "min_percentage": 80,
        },
    }

    with open(output, "w") as f:
        json.dump(template, f, indent=2)

    print(f"✅ Template created: {output}")
    print(f"   Edit the steps and run: tibet-pol check {output}")
    return 0


def cmd_diff(args: argparse.Namespace) -> int:
    """Compare two run results."""
    with open(args.run1) as f:
        run1 = json.load(f)
    with open(args.run2) as f:
        run2 = json.load(f)

    print()
    print("=" * 55)
    print("📊 TIBET-POL DIFF")
    print(f"   Run 1: {run1.get('started_at', '?')}")
    print(f"   Run 2: {run2.get('started_at', '?')}")
    print("=" * 55)

    s1 = run1.get("summary", {})
    s2 = run2.get("summary", {})

    print(f"\n   Checksum: {s1.get('checksum', '?')} → {s2.get('checksum', '?')}")
    print(f"   Status:   {s1.get('status', '?')} → {s2.get('status', '?')}")

    # Step-level diff
    steps1 = {s["step_id"]: s for s in run1.get("steps", [])}
    steps2 = {s["step_id"]: s for s in run2.get("steps", [])}
    all_ids = sorted(set(steps1.keys()) | set(steps2.keys()))

    changes = []
    for sid in all_ids:
        st1 = steps1.get(sid, {}).get("status", "ABSENT")
        st2 = steps2.get(sid, {}).get("status", "ABSENT")
        if st1 != st2:
            name = steps2.get(sid, steps1.get(sid, {})).get("step_name", sid)
            changes.append((name, st1, st2))

    if changes:
        print("\n   Changes:")
        for name, old, new in changes:
            print(f"   • {name}: {old} → {new}")
    else:
        print("\n   No changes between runs.")

    print()
    return 0


def cmd_watch(args: argparse.Namespace) -> int:
    """Continuously monitor a process."""
    template = load_template(args.template)
    interval = args.interval

    print(f"👁️  tibet-pol watch: '{template.name}' every {interval}s")
    print("   Press Ctrl+C to stop.\n")

    checker = ProcessChecker()
    run_count = 0

    try:
        while True:
            run_count += 1
            result = checker.run(template)
            s = result.summary
            ts = datetime.now(timezone.utc).strftime("%H:%M:%S")
            mark = "✅" if s["status"] == "COMPLETE" else "⚠️"
            print(
                f"   [{ts}] Run #{run_count}: {mark} "
                f"{s['checksum']} ({s['percentage']}%)"
            )

            if s["status"] != "COMPLETE":
                for step in result.steps:
                    if step.status in ("FAILED", "BLOCKED"):
                        print(f"           └─ {step.step_name}: {step.status}")

            time.sleep(interval)
    except KeyboardInterrupt:
        print(f"\n\n   Stopped after {run_count} runs.")
        return 0


def cmd_report(args: argparse.Namespace) -> int:
    """Generate an HTML report from a run result."""
    with open(args.input) as f:
        data = json.load(f)

    s = data.get("summary", {})
    steps_html = ""
    for step in data.get("steps", []):
        color = {
            "SUCCESS": "#22c55e",
            "FAILED": "#ef4444",
            "BLOCKED": "#f59e0b",
        }.get(step.get("status", ""), "#6b7280")

        steps_html += f"""
        <tr>
            <td>{step.get('step_name', '?')}</td>
            <td style="color: {color}; font-weight: bold">{step.get('status', '?')}</td>
            <td>{step.get('duration_ms', 0)}ms</td>
            <td><code>{step.get('error', '') or step.get('output', '')[:60]}</code></td>
        </tr>"""

    html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8">
<title>tibet-pol Report — {data.get('process_name', '?')}</title>
<style>
  body {{ font-family: system-ui, sans-serif; max-width: 800px; margin: 2rem auto; padding: 0 1rem; }}
  table {{ width: 100%; border-collapse: collapse; margin: 1rem 0; }}
  th, td {{ padding: 0.5rem; text-align: left; border-bottom: 1px solid #e5e7eb; }}
  th {{ background: #f9fafb; }}
  .checksum {{ font-size: 2rem; font-weight: bold; }}
  .complete {{ color: #22c55e; }} .incomplete {{ color: #ef4444; }}
  footer {{ margin-top: 2rem; color: #9ca3af; font-size: 0.85rem; }}
</style></head>
<body>
<h1>📋 tibet-pol Report</h1>
<p><strong>Process:</strong> {data.get('process_name', '?')}<br>
<strong>Run:</strong> {data.get('started_at', '?')}</p>
<p class="checksum {s.get('status', '').lower()}">{s.get('checksum', '?')} ({s.get('percentage', 0)}%)</p>
<table>
<tr><th>Step</th><th>Status</th><th>Duration</th><th>Details</th></tr>
{steps_html}
</table>
<h2>TIBET Tokens</h2>
<p>{len(data.get('tokens', []))} tokens in chain</p>
<details><summary>Raw token chain (JSON)</summary>
<pre>{json.dumps(data.get('tokens', []), indent=2)}</pre>
</details>
<footer>Generated by tibet-pol v0.1.0 — Humotica AI Lab<br>
TIBET Protocol: <a href="https://pypi.org/project/tibet-core/">tibet-core</a></footer>
</body></html>"""

    output = Path(args.output) if args.output else Path(f"{data.get('process_id', 'report')}.html")
    with open(output, "w") as f:
        f.write(html)

    print(f"📊 Report saved to: {output}")
    return 0


def main() -> None:
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="tibet-pol",
        description="Process Integrity Checker — every step a TIBET token",
    )
    sub = parser.add_subparsers(dest="command", help="Available commands")

    # check
    p_check = sub.add_parser("check", help="Run a process check")
    p_check.add_argument("template", help="Path to process template JSON")
    p_check.add_argument("-q", "--quiet", action="store_true")
    p_check.add_argument("-j", "--json", action="store_true", help="Output raw JSON")
    p_check.add_argument("-s", "--save", action="store_true", help="Save results")
    p_check.add_argument(
        "--save-dir", default="./tibet-pol-logs", help="Directory for saved results"
    )

    # init
    p_init = sub.add_parser("init", help="Create a new process template")
    p_init.add_argument("output", help="Output file path")
    p_init.add_argument("-n", "--name", help="Process name")

    # diff
    p_diff = sub.add_parser("diff", help="Compare two run results")
    p_diff.add_argument("run1", help="First run result JSON")
    p_diff.add_argument("run2", help="Second run result JSON")

    # watch
    p_watch = sub.add_parser("watch", help="Continuously monitor a process")
    p_watch.add_argument("template", help="Path to process template JSON")
    p_watch.add_argument(
        "-i", "--interval", type=int, default=300, help="Seconds between runs"
    )

    # report
    p_report = sub.add_parser("report", help="Generate HTML report from run result")
    p_report.add_argument("input", help="Run result JSON file")
    p_report.add_argument("-o", "--output", help="Output HTML file")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(0)

    commands = {
        "check": cmd_check,
        "init": cmd_init,
        "diff": cmd_diff,
        "watch": cmd_watch,
        "report": cmd_report,
    }

    exit_code = commands[args.command](args)
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
