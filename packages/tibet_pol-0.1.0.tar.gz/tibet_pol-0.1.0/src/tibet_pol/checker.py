"""
Process Integrity Checker — the core engine.

Runs process templates, tracks steps via TIBET tokens,
and produces integrity reports with checksums.
"""

import subprocess
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

from .provenance import ProcessProvenance, ProcessToken
from .template import ProcessTemplate, Step, load_template


@dataclass
class StepResult:
    """Result of a single step execution."""

    step_id: str
    step_name: str
    status: str  # SUCCESS, FAILED, BLOCKED, SKIPPED
    output: str = ""
    error: str = ""
    duration_ms: int = 0
    token: Optional[ProcessToken] = None


@dataclass
class ProcessResult:
    """Complete result of a process check."""

    process_id: str
    process_name: str
    started_at: str
    completed_at: str = ""
    steps: list[StepResult] = field(default_factory=list)
    tokens: list[dict] = field(default_factory=list)

    @property
    def summary(self) -> dict:
        total = len(self.steps)
        by_status = {}
        for s in self.steps:
            by_status[s.status] = by_status.get(s.status, 0) + 1

        success = by_status.get("SUCCESS", 0)
        return {
            "total": total,
            "success": success,
            "failed": by_status.get("FAILED", 0),
            "blocked": by_status.get("BLOCKED", 0),
            "skipped": by_status.get("SKIPPED", 0),
            "checksum": f"{success}/{total}",
            "percentage": round(success / total * 100) if total > 0 else 0,
            "status": "COMPLETE" if success == total else "INCOMPLETE",
        }

    def to_dict(self) -> dict:
        return {
            "process_id": self.process_id,
            "process_name": self.process_name,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "summary": self.summary,
            "steps": [
                {
                    "step_id": s.step_id,
                    "step_name": s.step_name,
                    "status": s.status,
                    "output": s.output,
                    "error": s.error,
                    "duration_ms": s.duration_ms,
                }
                for s in self.steps
            ],
            "tokens": self.tokens,
        }


class ProcessChecker:
    """
    Process Integrity Checker.

    Runs a process template step by step, respecting dependencies
    (topological sort), creating TIBET tokens for every step,
    and producing a checksum report.

    Usage::

        checker = ProcessChecker()
        result = checker.run(template)
        print(result.summary)
    """

    def __init__(self, actor: str = "tibet-pol", verbose: bool = False):
        self.actor = actor
        self.verbose = verbose

    def run(self, template: ProcessTemplate | str) -> ProcessResult:
        """
        Run all checks in a process template.

        Args:
            template: A ProcessTemplate or path to a JSON template file.

        Returns:
            ProcessResult with checksum, step results, and TIBET tokens.
        """
        if isinstance(template, str):
            template = load_template(template)

        provenance = ProcessProvenance(template.process_id, actor=self.actor)
        now = datetime.now(timezone.utc).isoformat()

        result = ProcessResult(
            process_id=template.process_id,
            process_name=template.name,
            started_at=now,
        )

        completed: set[str] = set()
        failed: set[str] = set()
        pending = list(template.steps)
        prev_token_id: str | None = None

        max_iterations = len(template.steps) * 2
        iteration = 0

        while pending and iteration < max_iterations:
            iteration += 1
            progress = False

            for step in pending[:]:
                # Check if any dependency failed → BLOCKED
                if any(dep in failed for dep in step.dependencies):
                    sr, token = self._block_step(
                        step, provenance, prev_token_id
                    )
                    result.steps.append(sr)
                    failed.add(step.id)
                    pending.remove(step)
                    prev_token_id = token.token_id
                    progress = True
                    continue

                # Check if all dependencies are met
                if not all(dep in completed for dep in step.dependencies):
                    continue

                # Run the step
                sr, token = self._run_step(step, provenance, prev_token_id)
                result.steps.append(sr)
                prev_token_id = token.token_id

                if sr.status == "SUCCESS":
                    completed.add(step.id)
                else:
                    failed.add(step.id)

                pending.remove(step)
                progress = True

            if not progress:
                # Remaining steps are stuck (circular dep or unmet)
                for step in pending:
                    sr, token = self._block_step(
                        step, provenance, prev_token_id,
                        reason="unresolvable_dependency",
                    )
                    result.steps.append(sr)
                    prev_token_id = token.token_id
                break

        result.completed_at = datetime.now(timezone.utc).isoformat()
        result.tokens = provenance.chain()

        return result

    def _run_step(
        self,
        step: Step,
        provenance: ProcessProvenance,
        parent_id: str | None,
    ) -> tuple[StepResult, ProcessToken]:
        """Execute a single step and create its TIBET token."""

        if self.verbose:
            print(f"  🔍 Checking: {step.name}...", end=" ", flush=True)

        start = datetime.now(timezone.utc)
        success, output = self._execute(step.check, step.timeout_seconds)
        elapsed = int(
            (datetime.now(timezone.utc) - start).total_seconds() * 1000
        )

        status = "SUCCESS" if success else "FAILED"

        token = provenance.create_token(
            step_id=step.id,
            step_name=step.name,
            status=status,
            output=output if success else "",
            error="" if success else output,
            dependencies_met=step.dependencies,
            critical=step.critical,
            intent=step.intent,
            parent_id=parent_id,
        )

        if self.verbose:
            if success:
                print("✓")
            else:
                print("✗ FAILED")
                if output:
                    print(f"      └─ {output[:100]}")

        return (
            StepResult(
                step_id=step.id,
                step_name=step.name,
                status=status,
                output=output if success else "",
                error="" if success else output,
                duration_ms=elapsed,
                token=token,
            ),
            token,
        )

    def _block_step(
        self,
        step: Step,
        provenance: ProcessProvenance,
        parent_id: str | None,
        reason: str = "dependency_failed",
    ) -> tuple[StepResult, ProcessToken]:
        """Mark a step as blocked."""

        if self.verbose:
            print(f"  ⏸️  {step.name}: BLOCKED ({reason})")

        token = provenance.create_token(
            step_id=step.id,
            step_name=step.name,
            status="BLOCKED",
            error=reason,
            critical=step.critical,
            intent=step.intent,
            parent_id=parent_id,
        )

        return (
            StepResult(
                step_id=step.id,
                step_name=step.name,
                status="BLOCKED",
                error=reason,
                token=token,
            ),
            token,
        )

    @staticmethod
    def _execute(command: str, timeout: int = 30) -> tuple[bool, str]:
        """Run a shell command and return (success, output)."""
        try:
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=timeout,
            )
            output = (result.stdout + result.stderr).strip()
            return result.returncode == 0, output
        except subprocess.TimeoutExpired:
            return False, f"TIMEOUT after {timeout}s"
        except Exception as e:
            return False, str(e)
