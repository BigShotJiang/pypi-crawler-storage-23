"""
TIBET provenance layer for process integrity tokens.

Every process step generates a TIBET token with full provenance:
- ERIN:     What happened (step ID, status, output)
- ERAAN:    What it depends on (dependencies, parent tokens)
- EROMHEEN: Context (machine, timestamp, user, environment)
- ERACHTER: Intent (why this step exists, part of which process)
"""

import hashlib
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional


@dataclass
class ProcessToken:
    """A TIBET token representing one process step execution."""

    token_id: str
    timestamp: str
    step_id: str
    step_name: str
    status: str  # SUCCESS, FAILED, BLOCKED, SKIPPED
    process_id: str

    # TIBET provenance
    erin: dict = field(default_factory=dict)
    eraan: dict = field(default_factory=dict)
    eromheen: dict = field(default_factory=dict)
    erachter: dict = field(default_factory=dict)

    # Chain
    parent_id: Optional[str] = None
    content_hash: str = ""

    def to_dict(self) -> dict:
        return {
            "token_id": self.token_id,
            "timestamp": self.timestamp,
            "type": "process_step",
            "step_id": self.step_id,
            "step_name": self.step_name,
            "status": self.status,
            "process_id": self.process_id,
            "erin": self.erin,
            "eraan": self.eraan,
            "eromheen": self.eromheen,
            "erachter": self.erachter,
            "parent_id": self.parent_id,
            "content_hash": self.content_hash,
        }


class ProcessProvenance:
    """Creates and manages TIBET tokens for process steps."""

    def __init__(self, process_id: str, actor: str = "tibet-pol"):
        self.process_id = process_id
        self.actor = actor
        self.tokens: list[ProcessToken] = []
        self._provider = None

        # Try to use tibet-core Provider if available
        try:
            from tibet.provider import Provider
            self._provider = Provider(actor=actor)
        except ImportError:
            pass

    def create_token(
        self,
        step_id: str,
        step_name: str,
        status: str,
        *,
        output: str = "",
        error: str = "",
        dependencies_met: list[str] | None = None,
        critical: bool = False,
        intent: str = "",
        parent_id: str | None = None,
    ) -> ProcessToken:
        """Create a TIBET token for a process step."""

        now = datetime.now(timezone.utc)
        timestamp = now.isoformat()

        # Build TIBET layers
        erin = {
            "step_id": step_id,
            "step_name": step_name,
            "status": status,
            "output": output[:500] if output else "",
            "error": error[:500] if error else "",
            "critical": critical,
        }

        eraan = {
            "process_id": self.process_id,
            "dependencies_met": dependencies_met or [],
            "parent_token": parent_id,
        }

        eromheen = {
            "machine": os.uname().nodename,
            "timestamp": timestamp,
            "user": os.environ.get("USER", "system"),
            "pid": os.getpid(),
        }

        erachter = {
            "intent": intent or f"Verify {step_name} is operational",
            "part_of": self.process_id,
            "actor": self.actor,
        }

        # Generate token ID
        content = f"{self.process_id}:{step_id}:{status}:{timestamp}"
        token_id = hashlib.sha256(content.encode()).hexdigest()[:16]

        # Content hash for integrity
        import json
        hash_input = json.dumps({"erin": erin, "eraan": eraan}, sort_keys=True)
        content_hash = hashlib.sha256(hash_input.encode()).hexdigest()[:32]

        token = ProcessToken(
            token_id=token_id,
            timestamp=timestamp,
            step_id=step_id,
            step_name=step_name,
            status=status,
            process_id=self.process_id,
            erin=erin,
            eraan=eraan,
            eromheen=eromheen,
            erachter=erachter,
            parent_id=parent_id,
            content_hash=content_hash,
        )

        self.tokens.append(token)

        # Also create via tibet-core if available
        if self._provider:
            try:
                self._provider.create_token(
                    type="process_step",
                    erin=erin,
                    eraan=eraan,
                    eromheen=eromheen,
                    erachter=erachter,
                )
            except Exception:
                pass  # Standalone mode fallback

        return token

    def chain(self) -> list[dict]:
        """Return the full token chain as dicts."""
        return [t.to_dict() for t in self.tokens]

    @property
    def stats(self) -> dict:
        """Token statistics."""
        statuses = {}
        for t in self.tokens:
            statuses[t.status] = statuses.get(t.status, 0) + 1
        return {"total": len(self.tokens), "by_status": statuses}
