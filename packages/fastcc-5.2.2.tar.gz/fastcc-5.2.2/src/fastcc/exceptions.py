"""Exceptions raised inside FastCC."""

import http

ErrorCode = http.HTTPStatus


class FastCCError(Exception):
    """Base exception class for FastCC-related errors."""


class MessagingError(FastCCError):
    """Exception raised for messaging operation errors.

    This includes publish, subscribe, and unsubscribe
    operations.
    """


class RouteError(FastCCError):
    """Exception raised for errors in route handling."""


class RouteConflictError(RouteError):
    """Exception raised for route conflicts.

    Raised during route registration when a topic is already registered.
    """


class RouteValidationError(RouteError):
    """Exception raised for errors in route validation."""


class RequestError(RouteError):
    """Exception raised for errors in request/stream handling.

    Parameters
    ----------
    details
        Human-readable error description.
    error_code
        HTTP status code sent back to the client.
        FastCC uses HTTP status codes as they are well-known, widely
        used and cover a wide range of error scenarios. Of course, it
        only makes sense to use 4xx or 5xx error codes, but FastCC does
        not enforce this.
    """

    def __init__(self, details: str, error_code: ErrorCode) -> None:
        self.error_code = error_code
        super().__init__(details)
