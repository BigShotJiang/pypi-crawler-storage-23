"""Immutable values used across the codebase."""

import datetime
import re
import typing

#: Default host of the MQTT broker to connect to.
DEFAULT_MQTT_HOST: typing.Final[str] = "localhost"

#: Default port of the MQTT broker to connect to.
DEFAULT_MQTT_PORT: typing.Final[int] = 1883

#: Default topic prefix for responses from the server.
DEFAULT_RESPONSE_TOPIC_PREFIX: typing.Final[str] = "fastcc/responses"

#: Default timeout for messaging operations (publish, subscribe, unsubscribe).
DEFAULT_MESSAGING_TIMEOUT: typing.Final[datetime.timedelta] = (
    datetime.timedelta(seconds=5)
)

#: Separator used in MQTT topics.
TOPIC_SEPARATOR: typing.Final[str] = "/"

#: MQTT wildcard for matching multiple levels of topics.
MULTI_LEVEL_WILDCARD: typing.Final[str] = "#"

#: MQTT wildcard for matching exactly one level of topics.
SINGLE_LEVEL_WILDCARD: typing.Final[str] = "+"

#: Regular expression pattern for extracting path parameters
#: from topic patterns.
PATH_PARAM_PATTERN: typing.Final[re.Pattern[str]] = re.compile(r"\{(\w+)\}")

#: Reserved name for the multi-level wildcard parameter.
WILDCARD_PARAM_NAME: typing.Final[str] = "wildcard"

#: Maximum allowed payload size for deserialization (1 MB).
MAX_PAYLOAD_SIZE: typing.Final[int] = 1_048_576

#: Maximum topic depth (number of segments).
MAX_TOPIC_DEPTH: typing.Final[int] = 128

#: Pattern for invalid characters in topic segments.
INVALID_TOPIC_CHARS: typing.Final[re.Pattern[str]] = re.compile(
    r"[\x00-\x1f\x7f]",
)
