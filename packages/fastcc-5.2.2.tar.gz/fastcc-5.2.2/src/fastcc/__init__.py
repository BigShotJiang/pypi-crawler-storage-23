"""
Framework for component communication.

FastCC is a lightweight, efficient and developer-friendly framework for
component communication. By leveraging MQTT [1]_ for messaging and
Protocol Buffers [2]_ for data serialization, this framework ensures
fast, reliable, and bandwidth-efficient communication. Its simplicity
in setup and development makes it ideal for both small-scale and
enterprise-level applications.

References
----------
.. [1] https://mqtt.org
.. [2] https://protobuf.dev/
"""

from fastcc.app import Application
from fastcc.client import Client
from fastcc.exceptions import ErrorCode, RequestError
from fastcc.qos import QoS
from fastcc.router import Router

__all__ = [
    "Application",
    "Client",
    "ErrorCode",
    "QoS",
    "RequestError",
    "Router",
]
