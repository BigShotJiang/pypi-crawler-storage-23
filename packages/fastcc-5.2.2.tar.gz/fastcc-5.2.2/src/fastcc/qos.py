"""Quality of Service levels for MQTT messages."""
import enum


class QoS(enum.IntEnum):
    """Quality of Service levels for MQTT messages [1]_.

    Attributes
    ----------
    AT_MOST_ONCE
        The message is delivered at most once, or it is not delivered at all.
    AT_LEAST_ONCE
        The message is always delivered at least once.
    EXACTLY_ONCE
        The message is always delivered exactly once.

    References
    ----------
    .. [1] https://docs.oasis-open.org/mqtt/mqtt/v5.0/os/mqtt-v5.0-os.html#_Toc3901234
    """

    AT_MOST_ONCE = 0
    AT_LEAST_ONCE = 1
    EXACTLY_ONCE = 2
