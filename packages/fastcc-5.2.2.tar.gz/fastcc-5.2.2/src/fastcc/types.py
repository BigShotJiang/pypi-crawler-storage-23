"""Type definitions for FastCC."""

import typing

if typing.TYPE_CHECKING:
    from collections.abc import Callable

    from google.protobuf.message import Message

    type Packet = bytes | str | int | float | Message
    type AnyCallable = Callable[..., typing.Any]
