# dnsight

[![CI](https://github.com/dnsight/dnsight/actions/workflows/ci.yaml/badge.svg)](https://github.com/dnsight/dnsight/actions/workflows/ci.yaml)
[![PyPI version](https://img.shields.io/pypi/v/dnsight)](https://pypi.org/project/dnsight/)
[![Python versions](https://img.shields.io/pypi/pyversions/dnsight)](https://pypi.org/project/dnsight/)
[![codecov](https://codecov.io/github/dnsight/dnsight/graph/badge.svg?token=B4BKEX1G8O)](https://codecov.io/github/dnsight/dnsight)
[![Quality Gate Status](https://sonarcloud.io/api/project_badges/measure?project=dnsight_dnsight&metric=alert_status&token=479932a2a9cce01e25841c72ae83c300d5534029)](https://sonarcloud.io/summary/new_code?id=dnsight_dnsight)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

> DNS, email, and web security hygiene SDK and CLI for DevOps and security engineers.

## Installation

```bash
# CLI
pipx install dnsight

# SDK only
pip install dnsight

# With uv
uv add dnsight
```

## Usage

```bash
dnsight --help
dnsight --version
```

## License

MIT
