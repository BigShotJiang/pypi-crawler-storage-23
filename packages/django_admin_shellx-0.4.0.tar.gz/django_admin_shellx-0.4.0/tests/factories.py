from collections.abc import Sequence
from typing import Any

from django.contrib.auth import get_user_model
from factory import Faker, SubFactory, post_generation
from factory.django import DjangoModelFactory

from django_admin_shellx.models import TerminalCommand


class UserFactory(DjangoModelFactory):
    username = Faker("user_name")
    email = Faker("email")
    first_name = Faker("name")
    last_name = Faker("name")

    @post_generation
    def password(self, _create: bool, extracted: Sequence[Any], **kwargs):
        password = (
            extracted
            if extracted
            else Faker(
                "password",
                length=42,
                special_chars=True,
                digits=True,
                upper_case=True,
                lower_case=True,
            ).evaluate(None, None, extra={"locale": None})
        )
        self.set_password(password)

    class Meta:
        model = get_user_model()
        django_get_or_create = ["username"]


class TerminalCommandFactory(DjangoModelFactory):
    command = Faker("word")
    prompt = "django-shell"
    favorite = False
    created_by = SubFactory(UserFactory)

    class Meta:
        model = TerminalCommand
