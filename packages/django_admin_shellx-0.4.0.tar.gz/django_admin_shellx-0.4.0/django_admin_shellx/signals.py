# from django_admin_shellx import models
