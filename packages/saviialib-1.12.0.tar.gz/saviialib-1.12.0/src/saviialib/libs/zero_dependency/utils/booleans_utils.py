def boolean_to_emoji(boolean: bool) -> str:
    return "✅" if boolean else "❌"
