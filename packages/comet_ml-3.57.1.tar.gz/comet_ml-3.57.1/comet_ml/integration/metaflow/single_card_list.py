# -*- coding: utf-8 -*-
# *******************************************************
#   ____                     _               _
#  / ___|___  _ __ ___   ___| |_   _ __ ___ | |
# | |   / _ \| '_ ` _ \ / _ \ __| | '_ ` _ \| |
# | |__| (_) | | | | | |  __/ |_ _| | | | | | |
#  \____\___/|_| |_| |_|\___|\__(_)_| |_| |_|_|
#
#  Sign up for free at http://www.comet.ml
#  Copyright (C) 2015-2022 Comet ML INC
#  This source code is licensed under the MIT license.
# *******************************************************

from metaflow.plugins.cards import card_decorator


class SingleCardList(list):
    def append(self, thing):

        classes = [type(decorator) for decorator in self]
        if type(thing) is card_decorator.CardDecorator:
            if classes.count(card_decorator.CardDecorator) > 0:
                return
        return super().append(thing)
