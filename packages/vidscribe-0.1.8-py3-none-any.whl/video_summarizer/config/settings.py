"""Configuration management using Pydantic."""

import os
from pathlib import Path

from dotenv import load_dotenv
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

from video_summarizer.utils.types import AudioQuality, SummaryStyle

# Environment variable names for MoviePy
_MOVIEPY_ENV_VAR = "FFMPEG_BINARY"
_MOVIEPY_ATTR = "ffmpeg_binary"


def _resolve_moviepy_env_vars() -> None:
    """Resolve ffmpeg-imageio option to actual binary paths.

    This must happen BEFORE any imports that trigger MoviePy imports,
    as MoviePy reads these environment variables at import time.

    Loads .env file first to ensure configuration values are available.
    """
    load_dotenv()

    try:
        import imageio_ffmpeg
    except ImportError:
        imageio_ffmpeg = None

    if imageio_ffmpeg is None:
        return

    if os.environ.get(_MOVIEPY_ENV_VAR) == "ffmpeg-imageio":
        os.environ[_MOVIEPY_ENV_VAR] = imageio_ffmpeg.get_ffmpeg_exe()


# Resolve at module import time, before any MoviePy imports
_resolve_moviepy_env_vars()

# Now we can safely import from transcriber (which imports MoviePy)
from video_summarizer.transcriber.backend import TranscriptionBackend  # noqa: E402


def _get_default_temp_dir() -> Path:
    """Get default temporary directory for downloads."""
    return Path("/tmp/vidscribe")


def _get_default_output_dir() -> Path:
    """Get default output directory for summaries."""
    return Path("./summaries")


class SpeachesConfig(BaseSettings):
    """Configuration for Speaches Docker backend."""

    container_name: str = "speaches"
    container_port: int = 8000
    container_image: str = "ghcr.io/speaches-ai/speaches:latest-cpu"
    use_gpu: bool = False
    gpu_container_image: str = "ghcr.io/speaches-ai/speaches:latest-cuda"
    model: str = "Systran/faster-distil-whisper-small.en"
    auto_start_container: bool = True

    def get_container_image(self) -> str:
        """Get the appropriate container image based on GPU setting.

        Returns:
            GPU image if use_gpu is True, otherwise CPU image
        """
        return self.gpu_container_image if self.use_gpu else self.container_image

    model_config = SettingsConfigDict(
        env_prefix="SPEACHES_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )


class NativeConfig(BaseSettings):
    """Configuration for native faster-whisper backend."""

    # Model: tiny, base, small, medium, large-v1, large-v2, large-v3
    model: str = "small"
    device: str = "auto"  # auto, cpu, cuda
    compute_type: str = "default"  # default, float16, int8, int8_float16
    word_timestamps: bool = False
    model_dir: str = "./.faster-whisper-model"  # Default to CWD

    model_config = SettingsConfigDict(
        env_prefix="NATIVE_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )


class TranscriberConfig(BaseSettings):
    """Configuration for audio transcriber."""

    # Backend selection (TRANSCRIPTION_BACKEND env var)
    backend: TranscriptionBackend = Field(
        default=TranscriptionBackend.NATIVE,
        alias="TRANSCRIPTION_BACKEND",
    )

    # Backend-specific configs
    speaches: SpeachesConfig = Field(default_factory=SpeachesConfig)
    native: NativeConfig = Field(default_factory=NativeConfig)

    # Shared transcription parameters
    response_format: str = "verbose_json"
    vad_filter: bool = False
    language: str | None = None
    chunk_duration_sec: int = 60
    chunk_duration_threshold: int = 120
    chunk_overlap_sec: int = 0

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        populate_by_name=True,
    )

    # Legacy field mapping for backward compatibility
    @property
    def container_name(self) -> str:
        """Legacy property for backward compatibility."""
        return self.speaches.container_name

    @property
    def container_port(self) -> int:
        """Legacy property for backward compatibility."""
        return self.speaches.container_port

    @property
    def model(self) -> str:
        """Legacy property for backward compatibility."""
        return self.speaches.model


class MoviePyConfig(BaseSettings):
    """Configuration for MoviePy audio/video processing."""

    ffmpeg_binary: str = "ffmpeg-imageio"

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )


class SummarizerConfig(BaseSettings):
    """Configuration for transcript summarizer."""

    api_base: str = "https://api.openai.com/v1"
    api_key: str = Field(default="")
    model: str = "gpt-4o"
    max_tokens: int = 2000
    temperature: float = 0.7
    summary_style: SummaryStyle = SummaryStyle.CONCISE
    custom_prompt: str = Field(default="")
    max_transcript_length: int = 128000

    model_config = SettingsConfigDict(
        env_prefix="OPENAI_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )


class ScraperConfig(BaseSettings):
    """Configuration for video scraper."""

    output_format: str = "wav"
    audio_quality: AudioQuality = AudioQuality.MEDIUM
    temp_dir: Path = Field(default_factory=_get_default_temp_dir)

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )


class OutputConfig(BaseSettings):
    """Configuration for output settings."""

    save_transcript: bool = False
    save_summary: bool = True
    summary_format: str = "markdown"
    output_dir: Path = Field(default_factory=_get_default_output_dir)

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )


class LoggingConfig(BaseSettings):
    """Configuration for logging."""

    log_level: str = "INFO"
    log_file: str | None = None

    model_config = SettingsConfigDict(
        env_prefix="LOG_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )


class Settings:
    """Main settings class that aggregates all configs."""

    def __init__(self, config_file: Path | None = None) -> None:
        """Initialize settings.

        Args:
            config_file: Optional path to config file
        """
        env_file = str(config_file) if config_file else ".env"

        self.transcriber = TranscriberConfig(_env_file=env_file)  # type: ignore
        self.summarizer = SummarizerConfig(_env_file=env_file)  # type: ignore
        self.scraper = ScraperConfig(_env_file=env_file)  # type: ignore
        self.output = OutputConfig(_env_file=env_file)  # type: ignore
        self.logging = LoggingConfig(_env_file=env_file)  # type: ignore
        self.moviepy = MoviePyConfig(_env_file=env_file)  # type: ignore

        self._apply_moviepy_env_vars()

    def _apply_moviepy_env_vars(self) -> None:
        """Set MoviePy environment variables, resolving special values."""
        try:
            import imageio_ffmpeg
        except ImportError:
            imageio_ffmpeg = None

        value = getattr(self.moviepy, _MOVIEPY_ATTR)
        if value == "ffmpeg-imageio" and imageio_ffmpeg is not None:
            value = imageio_ffmpeg.get_ffmpeg_exe()
        os.environ[_MOVIEPY_ENV_VAR] = value
