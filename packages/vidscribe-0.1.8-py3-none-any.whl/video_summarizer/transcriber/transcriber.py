"""Speech-to-text transcription using Speaches."""

import logging
import mimetypes
from pathlib import Path

import httpx

from video_summarizer.core.base import Transcriber
from video_summarizer.transcriber.audio_utils import get_audio_duration
from video_summarizer.transcriber.chunking import (
    AudioChunker,
    JsonChunkMerger,
    cleanup_chunk_directory,
)
from video_summarizer.utils.errors import AudioExtractionError, TranscriptionError
from video_summarizer.utils.types import Transcript

logger = logging.getLogger(__name__)


class SpeachesTranscriber(Transcriber):
    """Transcribe audio using Speaches Whisper API (Docker-based)."""

    def __init__(
        self,
        api_base: str = "http://localhost:8000/v1",
        model: str = "Systran/faster-distil-whisper-small.en",
        timeout: int = 600,
        chunk_duration_sec: int = 60,
        chunk_overlap_sec: int = 0,
        chunk_duration_threshold: int = 120,
        response_format: str = "verbose_json",
        vad_filter: bool = False,
        language: str | None = None,
    ) -> None:
        """Initialize Speaches transcriber.

        Args:
            api_base: Base URL for Speaches API
            model: Whisper model to use
            timeout: Request timeout in seconds
            chunk_duration_sec: Duration of each audio chunk in seconds
            chunk_overlap_sec: Overlap between chunks in seconds
            chunk_duration_threshold: Duration threshold for using chunked transcription
            response_format: API response format (verbose_json, json, text, srt, vtt)
            vad_filter: Enable voice activity detection filter
            language: Language code (e.g., "en", "zh")
        """
        self.api_base = api_base.rstrip("/")
        self.model = model
        self.timeout = timeout
        self.chunk_duration_sec = chunk_duration_sec
        self.chunk_overlap_sec = chunk_overlap_sec
        self.chunk_duration_threshold = chunk_duration_threshold
        self.response_format = response_format
        self.vad_filter = vad_filter
        self.language = language
        self.client = httpx.Client(timeout=timeout)
        self._chunker = AudioChunker(chunk_duration_sec)

    def transcribe(self, audio_path: Path) -> Transcript:
        """Transcribe audio file to text.

        Args:
            audio_path: Path to audio file

        Returns:
            Transcript object

        Raises:
            TranscriptionError: If transcription fails
        """
        if not audio_path.exists():
            raise TranscriptionError(f"Audio file does not exist: {audio_path}")

        duration = get_audio_duration(audio_path)
        logger.info(f"Detected audio duration: {duration}")

        return self._route_transcription(audio_path, duration)

    def _route_transcription(self, audio_path: Path, duration: float) -> Transcript:
        """Route to appropriate transcription method based on duration.

        Args:
            audio_path: Path to audio file
            duration: Detected audio duration in seconds

        Returns:
            Transcript object
        """
        if duration > self.chunk_duration_threshold:
            logger.info(
                f"Audio duration {duration:.1f}s exceeds {self.chunk_duration_threshold}s, "
                "using chunked transcription"
            )
            return self._transcribe_chunked(audio_path, duration)

        logger.info(f"Audio duration {duration:.1f}s, using single-request transcription")
        return self._transcribe_single(audio_path)

    def _transcribe_single(self, audio_path: Path) -> Transcript:
        """Transcribe audio in a single API request.

        Args:
            audio_path: Path to audio file

        Returns:
            Transcript object
        """
        url = f"{self.api_base}/audio/transcriptions"
        content_type = mimetypes.guess_type(audio_path)[0] or "audio/mpeg"

        try:
            with open(audio_path, "rb") as audio_file:
                files = {"file": (audio_path.name, audio_file, content_type)}
                data = self._build_request_data()

                response = self.client.post(url, files=files, data=data)
                response.raise_for_status()

                return self._parse_response(response, audio_path)

        except httpx.HTTPStatusError as e:
            raise TranscriptionError(f"API request failed: {e.response.status_code}") from e
        except httpx.RequestError as e:
            raise TranscriptionError(f"Request failed: {e}") from e

    def _build_request_data(self) -> dict:
        """Build request data for API call.

        Returns:
            Dictionary with request parameters
        """
        data = {"model": self.model}

        if self.response_format:
            data["response_format"] = self.response_format
        if self.vad_filter:
            data["vad_filter"] = "true"
        if self.language:
            data["language"] = self.language

        return data

    def _parse_response(self, response: httpx.Response, audio_path: Path) -> Transcript:
        """Parse API response based on format.

        Args:
            response: HTTP response from API
            audio_path: Original audio path for duration fallback

        Returns:
            Transcript object
        """
        if self.response_format in ("verbose_json", "json"):
            return self._parse_json_response(response)
        return self._parse_text_response(response, audio_path)

    def _parse_json_response(self, response: httpx.Response) -> Transcript:
        """Parse JSON response from API.

        Args:
            response: HTTP response

        Returns:
            Transcript object
        """
        result = response.json()

        if "text" not in result:
            raise TranscriptionError("API response missing 'text' field")

        logger.info(
            f"Transcription completed: {len(result.get('text', ''))} chars, "
            f"duration={result.get('duration', 0):.1f}s"
        )

        return Transcript(
            text=result.get("text", ""),
            duration=result.get("duration", 0.0),
            language=result.get("language"),
            confidence=None,
            raw_response=result,
            response_format=self.response_format,
        )

    def _parse_text_response(self, response: httpx.Response, audio_path: Path) -> Transcript:
        """Parse text/srt/vtt response from API.

        Args:
            response: HTTP response
            audio_path: Original audio path for duration fallback

        Returns:
            Transcript object
        """
        result = response.text
        try:
            duration = get_audio_duration(audio_path)
        except AudioExtractionError:
            logger.warning("Could not detect audio duration for logging")
            duration = 0.0

        logger.info(f"Transcription completed: {len(result)} chars, duration={duration:.1f}s")

        return Transcript(
            text=result,
            duration=duration,
            language=self.language,
            confidence=None,
            raw_response=result,
            response_format=self.response_format,
        )

    def _transcribe_chunked(self, audio_path: Path, total_duration: float) -> Transcript:
        """Transcribe audio by splitting into chunks.

        Args:
            audio_path: Path to audio file
            total_duration: Total audio duration in seconds

        Returns:
            Transcript object with combined results
        """
        chunks = self._chunker.split_audio(audio_path)

        try:
            if self.response_format in ("verbose_json", "json"):
                return self._merge_chunked_json_responses(chunks, total_duration)
            return self._merge_chunked_text_responses(chunks, total_duration)
        finally:
            cleanup_chunk_directory(chunks)

    def _merge_chunked_json_responses(
        self, chunks: list[Path], total_duration: float
    ) -> Transcript:
        """Merge chunked JSON responses with timestamp adjustment.

        Adjusts segment and word timestamps based on chunk position.
        Only called when response_format is verbose_json or json.

        Args:
            chunks: List of chunk file paths
            total_duration: Total audio duration in seconds

        Returns:
            Transcript object with merged JSON response
        """
        self._log_chunk_info(chunks, total_duration)

        merger = JsonChunkMerger(self.chunk_duration_sec)
        merger.process_chunks(chunks, self._transcribe_single)

        if merger.successful_chunks == 0:
            logger.error("All chunks failed to transcribe")
            return self._create_error_transcript(total_duration)

        merged_response = merger.build_response(total_duration)
        logger.info(
            f"Chunked JSON merge complete: {len(merger.all_text)} chars, "
            f"{merger.successful_chunks}/{len(chunks)} chunks, "
            f"{len(merger.combined_segments)} segments, "
            f"{len(merger.combined_words)} words"
        )

        return Transcript(
            text=" ".join(merger.all_text),
            duration=total_duration,
            language=merger.detected_language,
            confidence=None,
            raw_response=merged_response,
            response_format=self.response_format,
        )

    def _log_chunk_info(self, chunks: list[Path], total_duration: float) -> None:
        """Log information about audio chunks.

        Args:
            chunks: List of chunk file paths
            total_duration: Total audio duration in seconds
        """
        logger.info(f"Created {len(chunks)} chunks for {total_duration:.1f}s audio")
        for chunk in chunks:
            logger.debug(f"  Chunk: {chunk.name} ({chunk.stat().st_size / 1024:.1f} KB)")

    def _create_error_transcript(self, total_duration: float) -> Transcript:
        """Create an error transcript when all chunks fail.

        Args:
            total_duration: Total audio duration in seconds

        Returns:
            Transcript object with error information
        """
        return Transcript(
            text="",
            duration=total_duration,
            language=None,
            confidence=None,
            raw_response={"error": "All transcription chunks failed"},
            response_format=self.response_format,
        )

    def _merge_chunked_text_responses(
        self, chunks: list[Path], total_duration: float
    ) -> Transcript:
        """Merge chunked text responses.

        Used for text, srt, vtt formats where JSON merging is not applicable.

        Args:
            chunks: List of chunk file paths
            total_duration: Total audio duration in seconds

        Returns:
            Transcript object with combined text
        """
        self._log_chunk_info(chunks, total_duration)

        all_text = []

        for i, chunk_path in enumerate(chunks, 1):
            logger.info(f"Transcribing chunk {i}/{len(chunks)}: {chunk_path.name}")

            try:
                transcript = self._transcribe_single(chunk_path)
                logger.debug(f"  Chunk {i} transcript: {transcript.text[:100]}...")
                all_text.append(transcript.text)
            except Exception as e:
                logger.error(f"Failed to transcribe chunk {i}: {e}")
                all_text.append(f"[Chunk {i} transcription failed]")

        combined_text = " ".join(all_text)

        logger.info(
            f"Chunked transcription complete: {len(combined_text)} chars from {len(chunks)} chunks"
        )

        return Transcript(
            text=combined_text,
            duration=total_duration,
            language=None,
            confidence=None,
            raw_response=None,
            response_format=None,
        )

    def is_available(self) -> bool:
        """Check if Speaches API is available.

        Returns:
            True if API is reachable
        """
        try:
            response = self.client.get(f"{self.api_base}/models")
            return bool(response.status_code == 200)
        except Exception:
            return False

    def __del__(self) -> None:
        """Cleanup HTTP client."""
        if hasattr(self, "client"):
            self.client.close()
