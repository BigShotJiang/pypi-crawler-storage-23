"""Transcription backend configuration."""

from enum import Enum


class TranscriptionBackend(str, Enum):
    """Available transcription backends.

    This enum defines the supported transcription backends.

    - SPEACHES: Docker-based Speaches container
    - NATIVE: Native faster-whisper Python package

    The architecture supports pluggable backends for future extensibility.
    See DESIGN.md for guidance on implementing new backends.
    """

    SPEACHES = "speaches"  # Speaches container (Docker-based)
    NATIVE = "native"  # Native faster-whisper (Python package)

    def __str__(self) -> str:
        return self.value
