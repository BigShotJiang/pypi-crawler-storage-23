"""Audio chunking and transcript merging utilities."""

import logging
import shutil
import tempfile
from collections.abc import Callable
from pathlib import Path

from video_summarizer.utils.types import Transcript

logger = logging.getLogger(__name__)


class AudioChunker:
    """Handles audio file splitting for long transcriptions."""

    def __init__(self, chunk_duration_sec: int = 60) -> None:
        """Initialize chunker.

        Args:
            chunk_duration_sec: Duration of each chunk in seconds
        """
        self.chunk_duration_sec = chunk_duration_sec

    def split_audio(self, audio_path: Path) -> list[Path]:
        """Split audio file into chunks using ffmpeg.

        Args:
            audio_path: Path to audio file

        Returns:
            List of paths to audio chunks

        Raises:
            TranscriptionError: If splitting fails
        """
        from video_summarizer.transcriber.audio_utils import get_ffmpeg_path, run_subprocess
        from video_summarizer.utils.errors import TranscriptionError

        chunk_dir = tempfile.mkdtemp(prefix="video_summarizer_chunks_")
        chunk_pattern = str(Path(chunk_dir) / "chunk_%03d.mp3")

        ffmpeg_path = get_ffmpeg_path()
        cmd = [
            ffmpeg_path,
            "-i",
            str(audio_path),
            "-f",
            "segment",
            "-segment_time",
            str(self.chunk_duration_sec),
            "-c",
            "copy",
            "-map",
            "0:a",  # Only copy audio stream
            chunk_pattern,
        ]

        result = run_subprocess(cmd)
        if result.returncode != 0:
            raise TranscriptionError(f"Failed to split audio: {result.stderr}")

        chunks = sorted(Path(chunk_dir).glob("chunk_*.mp3"))
        logger.info(f"Split audio into {len(chunks)} chunks")
        for i, chunk in enumerate(chunks):
            logger.debug(f"  Chunk {i}: {chunk.name} ({chunk.stat().st_size / 1024:.1f} KB)")

        return chunks


class JsonChunkMerger:
    """Merges JSON transcript chunks with timestamp adjustment."""

    def __init__(self, chunk_duration_sec: int) -> None:
        """Initialize merger.

        Args:
            chunk_duration_sec: Duration of each chunk in seconds
        """
        self.chunk_duration_sec = chunk_duration_sec
        self.all_text: list[str] = []
        self.combined_segments: list[dict] = []
        self.combined_words: list[dict] = []
        self.segment_id_counter = 0
        self.detected_language: str | None = None
        self.successful_chunks = 0

    def process_chunks(
        self,
        chunks: list[Path],
        transcribe_func: Callable[[Path], Transcript],
    ) -> None:
        """Process all chunks and merge results.

        Args:
            chunks: List of chunk file paths
            transcribe_func: Function to transcribe a single chunk
        """
        for i, chunk_path in enumerate(chunks):
            time_offset = i * self.chunk_duration_sec
            logger.info(f"Transcribing chunk {i + 1}/{len(chunks)}: {chunk_path.name}")

            try:
                transcript = transcribe_func(chunk_path)
                if isinstance(transcript.raw_response, dict):
                    self._merge_chunk_data(transcript.raw_response, transcript.text, time_offset, i)
                self.successful_chunks += 1
            except Exception as e:
                logger.error(f"Failed to transcribe chunk {i}: {e}")

    def _merge_chunk_data(
        self, chunk_data: dict, text: str, time_offset: float, chunk_index: int
    ) -> None:
        """Merge data from a single chunk.

        Args:
            chunk_data: Raw response data from API
            text: Transcribed text
            time_offset: Time offset for this chunk
            chunk_index: Index of the chunk
        """
        if not isinstance(chunk_data, dict):
            logger.warning(f"Chunk {chunk_index}: raw_response is not dict, skipping in merge")
            return

        self.all_text.append(text)

        if self.detected_language is None:
            self.detected_language = chunk_data.get("language")

        self._merge_segments(chunk_data, time_offset)
        self._merge_words(chunk_data, time_offset)

        logger.debug(
            f"  Chunk {chunk_index}: {len(text)} chars, "
            f"{len(chunk_data.get('segments', []))} segments"
        )

    def _merge_segments(self, chunk_data: dict, time_offset: float) -> None:
        """Merge and adjust segment timestamps.

        Args:
            chunk_data: Chunk data dictionary
            time_offset: Time offset to add to timestamps
        """
        segments = chunk_data.get("segments")
        if not isinstance(segments, list):
            return

        for segment in segments:
            adjusted_segment = segment.copy()
            adjusted_segment["id"] = self.segment_id_counter
            adjusted_segment["start"] = segment["start"] + time_offset
            adjusted_segment["end"] = segment["end"] + time_offset
            self.combined_segments.append(adjusted_segment)
            self.segment_id_counter += 1

    def _merge_words(self, chunk_data: dict, time_offset: float) -> None:
        """Merge and adjust word timestamps.

        Args:
            chunk_data: Chunk data dictionary
            time_offset: Time offset to add to timestamps
        """
        words = chunk_data.get("words")
        if not isinstance(words, list):
            return

        for word in words:
            adjusted_word = word.copy()
            adjusted_word["start"] = word["start"] + time_offset
            adjusted_word["end"] = word["end"] + time_offset
            self.combined_words.append(adjusted_word)

    def build_response(self, total_duration: float) -> dict:
        """Build the final merged response.

        Args:
            total_duration: Total audio duration

        Returns:
            Merged response dictionary
        """
        merged_response = {
            "text": " ".join(self.all_text),
            "duration": total_duration,
            "language": self.detected_language,
            "segments": self.combined_segments,
        }

        if self.combined_words:
            merged_response["words"] = self.combined_words

        return merged_response


def cleanup_chunk_directory(chunks: list[Path]) -> None:
    """Clean up temporary chunk directory.

    Args:
        chunks: List of chunk file paths
    """
    chunk_dir = chunks[0].parent if chunks else None
    if chunk_dir and chunk_dir.exists():
        shutil.rmtree(chunk_dir, ignore_errors=True)
