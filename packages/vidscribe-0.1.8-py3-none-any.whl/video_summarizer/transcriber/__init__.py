"""Audio transcriber module."""

from video_summarizer.transcriber.backend import TranscriptionBackend
from video_summarizer.transcriber.container import SpeachesContainerManager
from video_summarizer.transcriber.extractor import MoviePyAudioExtractor
from video_summarizer.transcriber.factory import create_transcriber
from video_summarizer.transcriber.native import NativeFasterWhisperTranscriber
from video_summarizer.transcriber.stats_monitor import NetworkStats, NetworkStatsMonitor
from video_summarizer.transcriber.transcriber import SpeachesTranscriber

__all__ = [
    "TranscriptionBackend",
    "create_transcriber",
    "SpeachesContainerManager",
    "MoviePyAudioExtractor",
    "NetworkStats",
    "NetworkStatsMonitor",
    "SpeachesTranscriber",
    "NativeFasterWhisperTranscriber",
]
