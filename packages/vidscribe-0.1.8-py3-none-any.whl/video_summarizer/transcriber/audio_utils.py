"""Audio processing utilities for transcription."""

import logging
import os
import subprocess
from pathlib import Path

import imageio_ffmpeg

from video_summarizer.utils.errors import AudioExtractionError

logger = logging.getLogger(__name__)


def get_ffmpeg_path() -> str:
    """Get ffmpeg path from environment or default.

    Returns:
        Path to ffmpeg binary
    """
    ffmpeg_path = os.environ.get("FFMPEG_BINARY", "auto-detect")
    if ffmpeg_path == "auto-detect":
        return "ffmpeg"
    if ffmpeg_path == "ffmpeg-imageio":
        return str(imageio_ffmpeg.get_ffmpeg_exe())
    return ffmpeg_path


def run_subprocess(cmd: list[str], timeout: int = 10) -> subprocess.CompletedProcess[str]:
    """Run subprocess command and return result.

    Args:
        cmd: Command and arguments
        timeout: Timeout in seconds

    Returns:
        subprocess.CompletedProcess result with text output
    """
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)


def get_duration_via_mutagen(audio_path: Path) -> float | None:
    """Get audio duration using mutagen library.

    Args:
        audio_path: Path to audio file

    Returns:
        Duration in seconds or None if detection fails
    """
    try:
        from mutagen import File

        audio_file = File(audio_path)
        if audio_file and audio_file.info.length:
            duration: float = audio_file.info.length
            logger.info(f"Got duration from mutagen: {duration:.1f}s")
            return duration
    except ImportError:
        logger.debug("mutagen not available for duration detection")
    except Exception as e:
        logger.debug(f"mutagen duration detection failed: {e}")
    return None


def get_duration_via_ffprobe(audio_path: Path) -> float | None:
    """Get audio duration using ffprobe (most accurate).

    Args:
        audio_path: Path to audio file

    Returns:
        Duration in seconds or None if detection fails

    Note: Uses 'ffprobe' from system PATH. If not available, duration
    detection falls back to mutagen library.
    """
    cmd = [
        "ffprobe",
        "-i",
        str(audio_path),
        "-show_entries",
        "format=duration",
        "-v",
        "quiet",
        "-of",
        "csv=p=0",
    ]
    try:
        result = run_subprocess(cmd)
        if result.returncode == 0:
            duration_str = result.stdout.strip()
            if duration_str:
                return float(duration_str)
    except Exception as e:
        logger.debug(f"ffprobe duration detection failed: {e}")
    return None


def get_audio_duration(audio_path: Path) -> float:
    """Get audio duration using multiple methods in order of preference.

    Tries:
    1. mutagen library (Python dependency, always available)
    2. ffprobe from system PATH (more accurate if available)

    Args:
        audio_path: Path to audio file

    Returns:
        Duration in seconds

    Raises:
        AudioExtractionError: If both detection methods fail
    """
    duration = get_duration_via_mutagen(audio_path)
    if duration is not None:
        return duration

    duration = get_duration_via_ffprobe(audio_path)
    if duration is not None:
        return duration

    raise AudioExtractionError(
        "Could not detect audio duration. Ensure the audio file is valid and not corrupted."
    )
