"""Factory for creating transcription backend instances."""

from typing import TYPE_CHECKING

from video_summarizer.core.base import Transcriber
from video_summarizer.transcriber.backend import TranscriptionBackend
from video_summarizer.transcriber.native import NativeFasterWhisperTranscriber
from video_summarizer.transcriber.transcriber import SpeachesTranscriber

if TYPE_CHECKING:
    from video_summarizer.config.settings import TranscriberConfig


def create_transcriber(config: "TranscriberConfig") -> Transcriber:
    """Create a transcriber instance based on configuration.

    Args:
        config: TranscriberConfig instance

    Returns:
        Transcriber instance

    Raises:
        ValueError: If backend is not supported
    """
    backend = config.backend

    if backend == TranscriptionBackend.SPEACHES:
        return SpeachesTranscriber(
            api_base=f"http://localhost:{config.speaches.container_port}/v1",
            model=config.speaches.model,
            chunk_duration_sec=config.chunk_duration_sec,
            chunk_overlap_sec=config.chunk_overlap_sec,
            chunk_duration_threshold=config.chunk_duration_threshold,
            response_format=config.response_format,
            vad_filter=config.vad_filter,
            language=config.language,
        )
    elif backend == TranscriptionBackend.NATIVE:
        return NativeFasterWhisperTranscriber(
            model=config.native.model,
            device=config.native.device,
            compute_type=config.native.compute_type,
            language=config.language,
            word_timestamps=config.native.word_timestamps,
            vad_filter=config.vad_filter,
            model_dir=config.native.model_dir,
        )
    else:
        raise ValueError(f"Unsupported transcription backend: {backend}")
