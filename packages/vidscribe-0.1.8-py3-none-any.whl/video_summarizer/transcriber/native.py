"""Native speech-to-text transcription using faster-whisper."""

import importlib.util
import logging
from pathlib import Path
from typing import Any

from video_summarizer.core.base import Transcriber
from video_summarizer.transcriber.audio_utils import get_audio_duration
from video_summarizer.utils.errors import AudioExtractionError, TranscriptionError
from video_summarizer.utils.types import Transcript

logger = logging.getLogger(__name__)


class NativeFasterWhisperTranscriber(Transcriber):
    """Transcribe audio using faster-whisper (native Python implementation)."""

    def __init__(
        self,
        model: str = "small",
        device: str = "auto",
        compute_type: str = "default",
        language: str | None = None,
        word_timestamps: bool = False,
        vad_filter: bool = False,
        model_dir: str = "./.faster-whisper-model",
        **kwargs: object,
    ) -> None:
        """Initialize native faster-whisper transcriber.

        Args:
            model: Whisper model size (tiny, base, small, medium, large-v1, large-v2, large-v3)
            device: Device to use (auto, cpu, cuda)
            compute_type: Compute type (default, float16, int8, int8_float16)
            language: Language code (e.g., "en", "zh") or None for auto-detect
            word_timestamps: Whether to include word-level timestamps
            vad_filter: Enable voice activity detection filter
            model_dir: Directory to store/download models
            **kwargs: Additional arguments passed to WhisperModel
        """
        self.model = model
        self.device = device
        self.compute_type = compute_type
        self.language = language
        self.word_timestamps = word_timestamps
        self.vad_filter = vad_filter
        self.model_dir = model_dir
        self._model: Any = None
        self._model_initialized = False
        self._model_path: str | None = None

    def _is_model_cached(self) -> bool:
        """Check if the model is already cached locally."""
        model_repos = {
            "tiny": "guillaumekln/faster-whisper-tiny",
            "base": "guillaumekln/faster-whisper-base",
            "small": "guillaumekln/faster-whisper-small",
            "medium": "guillaumekln/faster-whisper-medium",
            "large-v1": "guillaumekln/faster-whisper-large-v1",
            "large-v2": "guillaumekln/faster-whisper-large-v2",
            "large-v3": "guillaumekln/faster-whisper-large-v3",
        }

        repo_id = model_repos.get(self.model)
        if not repo_id:
            return False

        # Check if model files exist in the cache directory
        cache_path = Path(self.model_dir) / repo_id.replace("/", "--")
        return cache_path.exists() and any(cache_path.iterdir())

    def _set_model_path(self, model_path: str) -> None:
        """Set the path to a downloaded model.

        Args:
            model_path: Path to the downloaded model directory
        """
        self._model_path = model_path

    def _ensure_model_loaded(self) -> None:
        """Lazy-load the WhisperModel on first use."""
        if self._model_initialized:
            return

        try:
            from faster_whisper import WhisperModel

            # Use the downloaded model path if available, otherwise use model name
            model_to_load = self._model_path if self._model_path else self.model

            logger.info(
                f"Loading faster-whisper model '{self.model}' "
                f"on device '{self.device}' with compute_type '{self.compute_type}'"
            )
            self._model = WhisperModel(
                model_to_load,
                device=self.device,
                compute_type=self.compute_type,
                download_root=self.model_dir,
                local_files_only=True if self._model_path else False,
            )
            self._model_initialized = True
            logger.info("Model loaded successfully")
        except ImportError as e:
            raise TranscriptionError(
                "faster-whisper package is not installed. "
                "Install it with: pip install faster-whisper"
            ) from e
        except Exception as e:
            raise TranscriptionError(f"Failed to load WhisperModel: {e}") from e

    def transcribe(self, audio_path: Path) -> Transcript:
        """Transcribe audio file to text.

        Args:
            audio_path: Path to audio file

        Returns:
            Transcript object

        Raises:
            TranscriptionError: If transcription fails
        """
        if not audio_path.exists():
            raise TranscriptionError(f"Audio file does not exist: {audio_path}")

        self._ensure_model_loaded()

        duration = self._get_audio_duration(audio_path)
        logger.info(f"Transcribing audio file: {audio_path} (duration: {duration:.1f}s)")

        try:
            return self._transcribe_with_faster_whisper(audio_path, duration)
        except Exception as e:
            raise TranscriptionError(f"Transcription failed: {e}") from e

    def _get_audio_duration(self, audio_path: Path) -> float:
        """Get audio duration for metadata.

        Args:
            audio_path: Path to audio file

        Returns:
            Duration in seconds, or 0.0 if detection fails
        """
        try:
            return get_audio_duration(audio_path)
        except AudioExtractionError:
            logger.warning("Could not detect audio duration for metadata")
            return 0.0

    def _transcribe_with_faster_whisper(self, audio_path: Path, duration: float) -> Transcript:
        """Run transcription using faster-whisper.

        Args:
            audio_path: Path to audio file
            duration: Audio duration in seconds

        Returns:
            Transcript object
        """
        transcribe_kwargs = self._build_transcribe_kwargs()
        segments_generator, info = self._model.transcribe(str(audio_path), **transcribe_kwargs)

        segments_list = list(segments_generator)
        text = " ".join(segment.text for segment in segments_list)

        logger.info(
            f"Transcription completed: {len(text)} chars, "
            f"detected language: {info.language}, "
            f"language probability: {info.language_probability:.2f}"
        )

        raw_response = self._build_openai_response(segments_list, info, duration, text)

        return Transcript(
            text=text.strip(),
            duration=duration,
            language=info.language,
            confidence=info.language_probability,
            raw_response=raw_response,
            response_format="verbose_json",
        )

    def _build_transcribe_kwargs(self) -> dict[str, Any]:
        """Build transcription kwargs, filtering out None values.

        Returns:
            Dictionary of transcription parameters
        """
        kwargs = {
            "language": self.language,
            "vad_filter": self.vad_filter,
            "word_timestamps": self.word_timestamps,
        }
        return {k: v for k, v in kwargs.items() if v is not None}

    def _build_openai_response(
        self, segments: list[Any], info: Any, duration: float, text: str
    ) -> dict:
        """Build OpenAI-compatible JSON response.

        Args:
            segments: List of segments from faster-whisper
            info: TranscriptionInfo object
            duration: Audio duration
            text: Full transcript text

        Returns:
            OpenAI-compatible response dictionary
        """
        segments_data = []
        words_data = []

        for segment in segments:
            segments_data.append(self._build_segment_dict(segment))
            if hasattr(segment, "words") and segment.words:
                words_data.extend(self._build_word_data(segment.words))

        response = {
            "text": text.strip(),
            "duration": duration,
            "language": info.language,
            "segments": segments_data,
        }

        if words_data:
            response["words"] = words_data

        return response

    def _build_segment_dict(self, segment: Any) -> dict:
        """Build segment dictionary.

        Args:
            segment: Segment from faster-whisper

        Returns:
            Segment dictionary
        """
        return {
            "id": segment.id,
            "seek": segment.seek,
            "start": segment.start,
            "end": segment.end,
            "text": segment.text.strip(),
            "tokens": segment.tokens,
            "temperature": segment.temperature,
            "avg_logprob": segment.avg_logprob,
            "compression_ratio": segment.compression_ratio,
            "no_speech_prob": segment.no_speech_prob,
        }

    def _build_word_data(self, words: list[Any]) -> list[dict]:
        """Build word timestamp data.

        Args:
            words: List of word objects from segment

        Returns:
            List of word dictionaries
        """
        return [
            {
                "word": word.word,
                "start": word.start,
                "end": word.end,
                "probability": word.probability,
            }
            for word in words
        ]

    def is_available(self) -> bool:
        """Check if faster-whisper is available and functional.

        Returns:
            True if faster-whisper is installed and model can be loaded
        """
        return importlib.util.find_spec("faster_whisper") is not None
