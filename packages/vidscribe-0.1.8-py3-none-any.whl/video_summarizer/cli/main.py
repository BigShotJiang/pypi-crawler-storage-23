"""Main CLI application for video summarizer."""

import signal
import sys
import threading
import time
from collections.abc import Iterator
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

import httpx
import rich_click as click
from rich.console import Console
from rich.live import Live
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.style import Style
from rich.text import Text

from video_summarizer import __version__
from video_summarizer.config.settings import OutputConfig, Settings
from video_summarizer.scraper.downloader import YtDlpDownloader
from video_summarizer.scraper.validator import VideoURLValidator
from video_summarizer.summarizer.preprocessor import TranscriptPreprocessor
from video_summarizer.summarizer.summarizer import OpenAISummarizer
from video_summarizer.transcriber.backend import TranscriptionBackend
from video_summarizer.transcriber.container import SpeachesContainerManager
from video_summarizer.transcriber.extractor import MoviePyAudioExtractor
from video_summarizer.transcriber.factory import create_transcriber
from video_summarizer.transcriber.native import NativeFasterWhisperTranscriber
from video_summarizer.utils.errors import VideoSummarizerError
from video_summarizer.utils.gpu_checker import GPUAvailability, check_gpu_availability, get_gpu_info
from video_summarizer.utils.logging import setup_logging
from video_summarizer.utils.types import Summary, Transcript

if TYPE_CHECKING:
    pass

console = Console(force_terminal=True, legacy_windows=False)


class RichTqdm:
    """A tqdm-compatible wrapper that integrates with Rich Progress."""

    _progress: Any = None
    _task_id: Any | None = None
    _lock: threading.Lock = threading.Lock()

    @classmethod
    def set_progress_context(cls, progress: Any, task_id: Any | None) -> None:
        """Set the progress context for all instances."""
        with cls._lock:
            cls._progress = progress
            cls._task_id = task_id

    @classmethod
    def clear_progress_context(cls) -> None:
        """Clear the progress context."""
        with cls._lock:
            cls._progress = None
            cls._task_id = None

    @classmethod
    def get_lock(cls) -> threading.Lock:
        """Return a thread-safe lock for tqdm compatibility."""
        return cls._lock

    @classmethod
    def set_lock(cls, lock: threading.Lock) -> None:
        """Set the global lock for tqdm compatibility."""
        cls._lock = lock

    def __init__(
        self,
        iterable: Any = None,
        desc: str | None = None,
        total: int | None = None,
        unit: str | None = None,
        disable: bool = False,
        **kwargs: Any,
    ) -> None:
        self.iterable = iterable
        self.desc = desc or "Progress"
        self.total = total
        self.unit = unit or "it"
        self.disable = disable
        self.n = 0
        self.start_time = time.time()
        self.last_update: float = 0.0

    def __iter__(self) -> Iterator[Any]:
        if self.iterable is None:
            raise TypeError("iterable must be specified")
        return self._iter()

    def _iter(self) -> Iterator[Any]:
        for item in self.iterable:
            self.update(1)
            yield item

    def update(self, n: int = 1) -> None:
        """Update progress by n items."""
        self.n += n
        current_time = time.time()
        if current_time - self.last_update > 0.1:
            with self._lock:
                if self._progress is not None and self._task_id is not None:
                    self._progress.update(self._task_id, completed=self.n)
            self.last_update = current_time

    def set_description(self, desc: str) -> None:
        """Update the progress description."""
        self.desc = desc

    def refresh(self, nolock: bool = False, lock_args: tuple[Any, ...] | None = None) -> bool:
        """Force refresh the display of this bar.

        Parameters
        ----------
        nolock  : bool, optional
            If `True`, does not lock.
            If [default: `False`]: calls `acquire()` on internal lock.
        lock_args  : tuple, optional
            Passed to internal lock's `acquire()`.
            If specified, will only `display()` if `acquire()` returns `True`.
        """
        if self.disable:
            return False

        if not nolock:
            if lock_args:
                if not self._lock.acquire(*lock_args):
                    return False
            else:
                self._lock.acquire()

        with self._lock:
            if self._progress is not None and self._task_id is not None:
                self._progress.update(self._task_id, completed=self.n)

        if not nolock:
            self._lock.release()
        return True

    def close(self) -> None:
        """Cleanup and close the progress bar."""
        self.disable = True


def _check_gpu_if_requested(use_gpu: bool) -> None:
    """Check GPU availability if requested and warn if unavailable.

    Args:
        use_gpu: Whether GPU was requested

    Raises:
        click.ClickException: If GPU requested but not available
    """
    if not use_gpu:
        return

    gpu_check = check_gpu_availability()

    if not gpu_check.available:
        _print_gpu_unavailable_message(gpu_check)
        raise click.ClickException("GPU support requested but not available")

    _print_gpu_available_message()


def _print_gpu_unavailable_message(gpu_check: GPUAvailability) -> None:
    """Print GPU unavailability error with suggested solutions.

    Args:
        gpu_check: GPU availability check results
    """
    console.print("[bold red]✗[/bold red] GPU support requested but not available:\n")
    console.print(f"  [red]{gpu_check.error_message}[/red]\n")
    console.print("[yellow]Solutions:[/yellow]")

    if not gpu_check.nvidia_installed:
        console.print("  1. Install NVIDIA GPU drivers for your system")
        console.print("  2. Verify installation: nvidia-smi")
    elif not gpu_check.nvidia_docker_available:
        console.print("  1. Install NVIDIA Container Toolkit:")
        console.print(
            "     https://docs.nvidia.com/datacenter/cloud-native/container-toolkit/install-guide.html"
        )
        console.print("  2. Restart Docker after installation")
        console.print(
            "  3. Verify: docker run --rm --gpus all nvidia/cuda:11.0.3-base-ubuntu20.04 nvidia-smi"
        )

    console.print("\n[dim]Or use CPU mode (remove --gpu flag)[/dim]")


def _print_gpu_available_message() -> None:
    """Print GPU availability information."""
    gpu_info = get_gpu_info()
    gpus = gpu_info.get("gpus")

    if not gpus or not isinstance(gpus, list):
        return

    console.print(f"[green]✓[/green] GPU available: {gpu_info['count']} GPU(s) detected")
    for gpu in gpus:
        console.print(f"  [dim]{gpu}[/dim]")


def _get_ffmpeg_location(settings: Settings) -> str | None:
    """Get ffmpeg location from settings, resolving ffmpeg-imageio if needed."""
    if settings.moviepy.ffmpeg_binary == "auto-detect":
        return None
    if settings.moviepy.ffmpeg_binary == "ffmpeg-imageio":
        try:
            import imageio_ffmpeg

            return str(imageio_ffmpeg.get_ffmpeg_exe())
        except ImportError:
            return None
    return settings.moviepy.ffmpeg_binary


def _ensure_container_running(settings: Settings) -> SpeachesContainerManager:
    """Ensure the Speaches container is running and return the manager."""
    console.print("[cyan]Ensuring Speaches container is running...[/cyan]")
    container_mgr = SpeachesContainerManager(
        container_name=settings.transcriber.container_name,
        container_port=settings.transcriber.container_port,
        container_image=settings.transcriber.speaches.get_container_image(),
        use_gpu=settings.transcriber.speaches.use_gpu,
    )

    if not container_mgr.is_running():
        gpu_msg = " (GPU)" if settings.transcriber.speaches.use_gpu else " (CPU)"
        with console.status(f"[bold green]Starting Speaches container{gpu_msg}..."):
            container_mgr.start()
        console.print("[green]✓[/green] Container started")

    return container_mgr


def _download_model_with_progress(
    container_mgr: SpeachesContainerManager,
    model: str,
) -> dict:
    """Download model with live progress display."""
    console.print(f"[cyan]Ensuring Whisper model is available: {model}[/cyan]")
    status_text = Text.from_markup("[bold green]Initializing download...[/bold green]")

    def progress_callback(stats: dict) -> None:
        mb_downloaded = stats["bytes_downloaded"] / (1024 * 1024)
        speed = stats["speed_mbps"]
        elapsed = stats["elapsed_seconds"]

        status_text.plain = (
            f"Downloading {model}\n"
            f"  Downloaded: {mb_downloaded:.1f} MB\n"
            f"  Speed: {speed:.2f} MB/s\n"
            f"  Elapsed: {elapsed:.0f}s"
        )
        status_text.stylize(Style(bold=True, color="green"), 0, len(f"Downloading {model}"))

    with Live(status_text, console=console, refresh_per_second=2) as live:

        def update_display(stats: dict) -> None:
            progress_callback(stats)
            live.update(status_text)

        result = container_mgr.ensure_model(model, progress_callback=update_display)

    return result


def _download_native_model_with_progress(model_name: str, model_dir: str) -> str:
    """Download faster-whisper model with progress display.

    Uses tqdm for progress (instead of Rich Progress) because:
    1. Rich Progress blocks KeyboardInterrupt signals, preventing CTRL+C from working
    2. The custom RichTqdm wrapper is incompatible with huggingface_hub
    """
    from huggingface_hub import snapshot_download

    model_repos = {
        "tiny": "guillaumekln/faster-whisper-tiny",
        "base": "guillaumekln/faster-whisper-base",
        "small": "guillaumekln/faster-whisper-small",
        "medium": "guillaumekln/faster-whisper-medium",
        "large-v1": "guillaumekln/faster-whisper-large-v1",
        "large-v2": "guillaumekln/faster-whisper-large-v2",
        "large-v3": "guillaumekln/faster-whisper-large-v3",
    }

    repo_id = model_repos.get(model_name)
    if not repo_id:
        raise ValueError(f"Unknown model: {model_name}")

    console.print(f"[cyan]Downloading model '{model_name}'...[/cyan]")

    original_sigint_handler = signal.getsignal(signal.SIGINT)

    def handle_sigint(signum: int, frame: Any) -> None:
        console.print("\n[yellow]Download interrupted by user (CTRL+C)[/yellow]")
        sys.exit(130)

    signal.signal(signal.SIGINT, handle_sigint)

    try:
        model_path = snapshot_download(
            repo_id=repo_id,
            cache_dir=model_dir,
        )
        console.print(f"[green]✓[/green] Model downloaded to: {model_path}")
        return cast(str, model_path)
    except KeyboardInterrupt:
        console.print("\n[yellow]Download interrupted by user (CTRL+C)[/yellow]")
        sys.exit(130)
    except Exception as e:
        console.print(f"[red]Error downloading model: {e}[/red]")
        raise
    finally:
        signal.signal(signal.SIGINT, original_sigint_handler)


def _print_download_result(result: dict) -> None:
    """Print the result of a model download operation.

    Args:
        result: Dictionary with download status and statistics
    """
    status = result.get("status")

    if status == "complete":
        elapsed = result.get("elapsed_seconds", 0)
        mb_downloaded = result.get("bytes_downloaded", 0) / (1024 * 1024)
        if mb_downloaded > 0:
            console.print(
                f"[green]✓[/green] Model ready ({mb_downloaded:.1f} MB in {elapsed:.0f}s)"
            )
            return

    console.print("[green]✓[/green] Model ready")


def _save_outputs(
    summary: Summary | None,
    transcript: Transcript,
    input_path: str,
    output: Path | None,
    settings: Settings,
    save_transcript: bool,
) -> None:
    """Save summary and transcript outputs to files.

    Args:
        summary: Summary result to save (None if summarization was skipped)
        transcript: Transcript result to save
        input_path: Original input path for deriving output filenames
        output: Optional user-specified output path
        settings: Application settings
        save_transcript: Whether to save transcript
    """
    base_name = Path(input_path).stem

    if summary and (output or settings.output.save_summary):
        _save_summary(summary, output, settings.output, base_name)

    if save_transcript or settings.output.save_transcript:
        _save_transcript(transcript, settings.output, base_name)


def _print_missing_api_key_message() -> None:
    """Print helpful message when API key is not configured."""
    console.print()
    console.print("[yellow]⚠[/yellow] [bold yellow]API key not configured[/bold yellow]")
    console.print()
    console.print("The transcript was generated successfully, but summarization was skipped.")
    console.print()
    console.print("[bold]To enable summarization, set your OpenAI API key:[/bold]")
    console.print()
    console.print("  [dim]1. Edit your .env file[/dim]")
    console.print("  [dim]2. Set: OPENAI_API_KEY=your-actual-api-key-here[/dim]")
    console.print("  [dim]3. Run this command again[/dim]")
    console.print()
    console.print("[dim]Get your API key from: https://platform.openai.com/api-keys[/dim]")
    console.print()


def _save_summary(
    summary: Summary, output: Path | None, output_config: OutputConfig, base_name: str
) -> None:
    """Save summary to file.

    Args:
        summary: Summary result to save
        output: Optional user-specified output path
        output_config: Output configuration settings
        base_name: Base name for the output file
    """
    output_path = Path(output or output_config.output_dir / f"{base_name}_summary.md")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(summary.text, encoding="utf-8")
    console.print(f"[green]✓[/green] Saved to: {output_path}")


def _save_transcript(transcript: Transcript, output_config: OutputConfig, base_name: str) -> None:
    """Save transcript to file.

    Args:
        transcript: Transcript result to save
        output_config: Output configuration settings
        base_name: Base name for the output file
    """
    response_format = transcript.response_format or "txt"
    extension = _get_transcript_extension(response_format)
    transcript_path = output_config.output_dir / f"{base_name}_transcript.{extension}"
    transcript_path.parent.mkdir(parents=True, exist_ok=True)

    _write_transcript_file(transcript_path, transcript, response_format)
    console.print(f"[green]✓[/green] Transcript saved to: {transcript_path}")


def _get_transcript_extension(response_format: str) -> str:
    """Map response format to file extension.

    Args:
        response_format: API response format

    Returns:
        File extension for the format
    """
    extension_map = {
        "verbose_json": "json",
        "json": "json",
        "text": "txt",
        "srt": "srt",
        "vtt": "vtt",
    }
    return extension_map.get(response_format, "txt")


def _write_transcript_file(
    transcript_path: Path, transcript: Transcript, response_format: str
) -> None:
    """Write transcript content to file based on format.

    Args:
        transcript_path: Path to write the transcript
        transcript: Transcript data
        response_format: Format type (verbose_json, json, text, srt, vtt)
    """
    if response_format in ("verbose_json", "json"):
        import json

        with open(transcript_path, "w", encoding="utf-8") as f:
            json.dump(transcript.raw_response, f, indent=2, ensure_ascii=False)
    else:
        transcript_path.write_text(str(transcript.raw_response), encoding="utf-8")


@click.group()
@click.version_option(version=__version__)
@click.option("--config", type=click.Path(exists=True), help="Path to config file")
@click.option("--verbose", is_flag=True, help="Enable verbose logging")
@click.pass_context
def cli(ctx: click.Context, config: Path | None, verbose: bool) -> None:
    """Vidscribe - Automatically summarize video content."""
    settings = Settings(config_file=config)

    log_level = "DEBUG" if verbose else settings.logging.log_level
    setup_logging(level=log_level, log_file=settings.logging.log_file)

    ctx.ensure_object(dict)
    ctx.obj["settings"] = settings


@cli.command()
@click.argument("input", type=click.STRING)
@click.option("--output", "-o", type=click.Path(), help="Output file path")
@click.option(
    "--summary-style",
    type=click.Choice(["brief", "detailed", "bullet-points", "concise"]),
    help="Summary style",
)
@click.option("--model", help="LLM model to use")
@click.option("--save-transcript", is_flag=True, help="Save raw transcript")
@click.pass_context
def summarize(
    ctx: click.Context,
    input: str,
    output: Path | None,
    summary_style: str | None,
    model: str | None,
    save_transcript: bool,
) -> None:
    """Summarize a video file or URL."""
    settings = ctx.obj["settings"]

    try:
        audio_path = _get_audio(input, settings)

        if settings.transcriber.backend == TranscriptionBackend.SPEACHES:
            container_mgr = _ensure_container_running(settings)
            result = _download_model_with_progress(container_mgr, settings.transcriber.model)
            _print_download_result(result)

        transcript = _transcribe_audio(audio_path, settings)

        if not settings.summarizer.api_key or settings.summarizer.api_key.strip() == "":
            _print_missing_api_key_message()
            _save_outputs(
                summary=None,
                transcript=transcript,
                input_path=input,
                output=output,
                settings=settings,
                save_transcript=save_transcript,
            )
            return

        summary = _generate_summary(transcript, summary_style, model, settings)

        console.print("[green]✓[/green] Summary complete!")
        console.print()
        console.print("[bold]Summary:[/bold]")
        console.print(summary.text)

        _save_outputs(summary, transcript, input, output, settings, save_transcript)

    except VideoSummarizerError as e:
        console.print(f"[red]Error: {e}[/red]")
        raise click.Abort() from e


def _get_audio(input: str, settings: Settings) -> Path:
    """Get audio from URL or local file."""
    validator = VideoURLValidator()

    if validator.is_valid_url(input):
        return _download_audio(input, settings)

    return _extract_audio(input)


def _download_audio(url: str, settings: Settings) -> Path:
    """Download audio from URL."""
    console.print(f"[cyan]Downloading audio from: {url}[/cyan]")
    downloader = YtDlpDownloader(
        temp_dir=settings.scraper.temp_dir,
        ffmpeg_location=_get_ffmpeg_location(settings),
    )

    with console.status("[bold green]Downloading audio..."):
        audio_path = downloader.download_audio(
            url,
            settings.scraper.temp_dir,
            settings.scraper.audio_quality.value,
        )
    console.print(f"[green]✓[/green] Downloaded to: {audio_path}")
    return audio_path


def _extract_audio(input_path: str) -> Path:
    """Extract audio from local file."""
    video_path = Path(input_path)
    if not video_path.exists():
        console.print(f"[red]Error: File not found: {input_path}[/red]")
        raise click.Abort()

    console.print(f"[cyan]Extracting audio from: {input_path}[/cyan]")
    extractor = MoviePyAudioExtractor()

    with console.status("[bold green]Extracting audio..."):
        audio_path = extractor.extract_audio(video_path)
    console.print(f"[green]✓[/green] Extracted to: {audio_path}")
    return audio_path


def _transcribe_audio(audio_path: Path, settings: Settings) -> Transcript:
    """Transcribe audio file."""
    transcriber = create_transcriber(settings.transcriber)

    if settings.transcriber.backend == TranscriptionBackend.NATIVE:
        native_transcriber = cast(NativeFasterWhisperTranscriber, transcriber)
        model_dir = settings.transcriber.native.model_dir
        if not native_transcriber._is_model_cached():
            console.print("\n[bold cyan]Model not found locally. Downloading...[/bold cyan]")
            model_path = _download_native_model_with_progress(
                settings.transcriber.native.model, model_dir
            )
            native_transcriber._set_model_path(model_path)

    console.print("[cyan]Transcribing audio...[/cyan]")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        progress.add_task("[bold green]Transcribing...", total=None)
        transcript: Transcript = transcriber.transcribe(audio_path)

    console.print(f"[green]✓[/green] Transcription complete ({len(transcript.text)} characters)")
    return transcript


def _generate_summary(
    transcript: Transcript,
    summary_style: str | None,
    model: str | None,
    settings: Settings,
) -> Summary:
    """Generate summary from transcript."""
    console.print("[cyan]Generating summary...[/cyan]")

    preprocessor = TranscriptPreprocessor()
    clean_text = preprocessor.clean(transcript)

    summarizer = OpenAISummarizer(
        api_key=settings.summarizer.api_key,
        base_url=settings.summarizer.api_base,
        model=model or settings.summarizer.model,
        max_tokens=settings.summarizer.max_tokens,
        temperature=settings.summarizer.temperature,
    )

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        progress.add_task("[bold green]Summarizing...", total=None)
        summary = summarizer.summarize(
            Transcript(text=clean_text, duration=transcript.duration),
            style=summary_style or settings.summarizer.summary_style.value,
            custom_prompt=settings.summarizer.custom_prompt,
        )

    return summary


@cli.command()
@click.pass_context
def container_start(ctx: click.Context) -> None:
    """Start the Speaches container."""
    settings = ctx.obj["settings"]

    container_mgr = SpeachesContainerManager(
        container_name=settings.transcriber.container_name,
        container_port=settings.transcriber.container_port,
        container_image=settings.transcriber.speaches.get_container_image(),
        use_gpu=settings.transcriber.speaches.use_gpu,
    )

    gpu_msg = " (GPU)" if settings.transcriber.speaches.use_gpu else " (CPU)"
    console.print(f"[cyan]Starting Speaches container{gpu_msg}...[/cyan]")
    container_mgr.start()
    console.print("[green]✓[/green] Container started")


@cli.command()
@click.pass_context
def container_stop(ctx: click.Context) -> None:
    """Stop the Speaches container."""
    settings = ctx.obj["settings"]
    container_mgr = SpeachesContainerManager(
        container_name=settings.transcriber.container_name,
    )

    console.print("[cyan]Stopping Speaches container...[/cyan]")
    container_mgr.stop()
    console.print("[green]✓[/green] Container stopped")


@cli.command()
@click.pass_context
def container_status(ctx: click.Context) -> None:
    """Check Speaches container status."""
    settings = ctx.obj["settings"]
    container_mgr = SpeachesContainerManager(
        container_name=settings.transcriber.container_name,
    )

    status = container_mgr.get_status()

    console.print("[bold]Container Status:[/bold]")
    console.print(f"  Name: {status['name']}")
    console.print(f"  Status: {status['status']}")
    console.print(f"  Image: {status['image']}")
    console.print(f"  Port: {status['port']}")


@cli.command(name="list-models")
@click.pass_context
def list_models(ctx: click.Context) -> None:
    """List downloaded Whisper models in the Speaches container."""
    settings = ctx.obj["settings"]

    _ensure_container_running(settings)

    response = httpx.get(f"http://localhost:{settings.transcriber.container_port}/v1/models")
    response.raise_for_status()

    models = response.json().get("data", [])
    if not models:
        console.print("[yellow]No models currently downloaded[/yellow]")
        return

    console.print("[bold]Downloaded Models:[/bold]")
    for model in models:
        console.print(f"  • {model.get('id', 'unknown')}")


@cli.command()
@click.pass_context
def getenv(ctx: click.Context) -> None:
    """Create a .env configuration file from the template."""
    import importlib.resources

    env_path = Path(".env")

    if env_path.exists():
        if not click.confirm(".env already exists. Overwrite?"):
            console.print("[yellow]Operation cancelled[/yellow]")
            return

    try:
        template = importlib.resources.files("video_summarizer.resources").joinpath(".env.example")
        with template.open("r", encoding="utf-8") as f:
            content = f.read()
        env_path.write_text(content, encoding="utf-8")
        console.print("[green]✓[/green] .env file created successfully")
    except FileNotFoundError:
        console.print("[red]Error: Could not find .env.example template[/red]")
        raise click.Abort() from None
