# Changelog

All notable changes to the MisoClient SDK will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [4.7.2] - 2026-03-06

### Added

- **Validate client token API** - New public interface to validate application (`x-client-token`) via `POST /api/v1/auth/validate-client-token`. AuthApi `validate_client_token()`, AuthService/MisoClient delegation, Pydantic types (`ValidateClientTokenResponse`, `ValidateClientTokenResponseData`, `ValidateClientTokenApplication`). Token can be sent as header or body; one-off request so SDK client token is not sent.
- **Client token validation cache** - Redis/in-memory caching for successful client-token validation by token hash; cache key via `get_client_token_validation_cache_key()`, TTL from config; AuthService checks cache before calling controller and caches on success (401/400 not cached).

### Changed

- **Client token policy** - Documented and hardened that only the client token endpoint may receive `x-client-id`/`x-client-secret`; all other APIs use `x-client-token` only. Updated `.cursorrules`, project rules, and `docs/backend-client-token.md`.

### Technical

- **Validation baseline** - Release validation passed via `make validate` (ruff, black, isort, pytest).

## [4.7.0] - 2026-03-04

### Added

- **Auth strategy regression coverage** - Added tests for auth-header merge behavior and whitespace normalization in auth-strategy configuration parsing.
- **Logger precedence regression coverage** - Added tests validating option-level precedence for `application` and `environment` in log entry construction.

### Changed

- **Core utility maintainability** - Refactored `internal_http_client`, `logger_helpers`, and `config_loader` into smaller helper-driven units while preserving public contracts.
- **Type-safety hardening** - Strengthened typing across runtime utilities and client internals, including strict-mode compatibility improvements.
- **Release version alignment** - Bumped to `4.7.0` to align release numbering with the parallel TypeScript SDK track.
- **Release workflow resilience** - Improved publish workflow behavior for already-published versions and existing tags.

### Fixed

- **Traceability serialization stability** - Improved `applicationId` and related trace field normalization/propagation consistency across logging paths.
- **Auth strategy request handling** - Fixed typed auth-method handling and preserved caller headers during auth strategy request construction.

### Technical

- **Validation baseline** - Release validation passed via `make validate` (ruff, black, isort, pytest).
- **Strict typing verification** - Additional strict type-check pass completed with `mypy --check-untyped-defs`.
- **Test baseline maintained** - Full test suite passing with 93% coverage.

## [4.6.1] - 2026-03-04

### Added

- **Auth strategy regression coverage** - Added tests for auth-header merge behavior and whitespace normalization in auth-strategy configuration parsing.
- **Logger precedence regression coverage** - Added tests validating option-level precedence for `application` and `environment` in log entry construction.

### Changed

- **Core utility maintainability** - Refactored `internal_http_client`, `logger_helpers`, and `config_loader` into smaller helper-driven units while preserving public contracts.
- **Type-safety hardening** - Strengthened typing across runtime utilities and client internals, including strict-mode compatibility improvements.
- **Release workflow resilience** - Improved publish workflow behavior for already-published versions and existing tags.

### Fixed

- **Traceability serialization stability** - Improved `applicationId` and related trace field normalization/propagation consistency across logging paths.
- **Auth strategy request handling** - Fixed typed auth-method handling and preserved caller headers during auth strategy request construction.

### Technical

- **Validation baseline** - Release validation passed via `make validate` (ruff, black, isort, pytest).
- **Strict typing verification** - Additional strict type-check pass completed with `mypy --check-untyped-defs`.
- **Test baseline maintained** - Full test suite passing with 93% coverage.

## [4.6.0] - 2026-02-27

### Added

- **HTTP client runtime helper module** - Added `http_client_runtime_helpers.py` to isolate logging-task lifecycle and correlation-header enrichment logic while keeping behavior unchanged.
- **Reliability and audit regression coverage** - Added/expanded unit tests for 429/503 handling, timeout mapping, audit skip policy, audit-disable behavior, and debug-log level gating.

### Changed

- **ISO-aligned traceability hardening** - Strengthened correlation propagation and status-code extraction through `HttpClient` logging pipeline, including response/error-aware status handling and correlation enrichment in debug/audit paths.
- **HTTP client structure** - Refactored `HttpClient` internals to reduce file size below guideline threshold and improve maintainability.
- **Validation and plan evidence** - Updated implementation validation artifacts for logging/audit/reliability execution completion.

### Fixed

- **Structured error trace context** - Ensured correlation ID context is consistently captured in `encryption` and `redis` service error logging paths.
- **Audit/logging edge cases** - Fixed logging behavior around skipped endpoints and non-debug log-level execution paths with explicit regression tests.

### Technical

- **Release validation baseline** - Verified release readiness with format/lint/tests (`black`, `isort`, `ruff`, `pytest`) prior to version bump.
- **Coverage baseline maintained** - Full test suite passing with 93% total coverage in release validation run.

## [4.5.1] - 2026-02-27

### Fixed

- **Minimal logs responses** - Normalize batch log responses when the controller returns minimal formats: `{"data": {"processed": N, "failed": M}}`, `{"processed": N, "failed": M}`, or `{"data": null}`. Ensures `BatchLogResponse` parsing succeeds without errors.

## [4.5.0] - 2026-02-19

### Added

- **Warn helper test coverage** - Added dedicated unit tests for `logger_request_helpers` to validate warn-level behavior in request helper pathways.
- **Shared log level contract** - Added exported `LogLevel` type alias to keep logger level contracts synchronized across model and service layers.

### Changed

- **Warn logging parity** - Restored `warn` as a first-class log level across `LoggerService`, `UnifiedLogger`, `LoggerChain`, and logger request/helper pathways.
- **Unified warn behavior** - `UnifiedLogger.warn()` now uses native warn logging and no longer remaps warnings to `info` with message prefixing.
- **Public API exports** - Updated top-level exports to include the shared `LogLevel` type.

### Fixed

- **Log level contract mismatch** - Fixed inconsistency where `MisoClientConfig.log_level` accepted `warn` but `LogEntry` and helper/service type annotations excluded it.
- **Warn transport preservation** - Ensured warn level is preserved unchanged in `transform_log_entry_to_request` payload flow and related regression tests.

### Technical

- **Validation baseline** - Release preparation validated with format/lint/type-check/tests (`black`, `isort`, `ruff`, `mypy`, `pytest`) before version bump.
- **Regression safeguards** - Expanded warn-focused unit coverage across logger service, chain, unified logger, and helper modules to prevent warn-to-info regressions.

## [4.4.4] - 2026-02-09

### Added

- **Regression tests** - Added coverage for environment/application preservation in audit logging paths.

### Changed

- **Docs** - Updated backend client-token documentation and integration test requirements.
- **Integration tests** - Added encryption integration coverage.

### Fixed

- **Audit logging** - Preserve top-level `environment` and `application` for single and batch audit logs.

## [4.4.3] - 2026-02-14

### Changed

- **Makefile** - Enhanced help command
- **Miso Test Integration** - Updated builder/miso-test README

### Removed

- **builder/miso-test/variables.yaml** - Removed deprecated file; replaced by application.yaml

### Technical

- Integration tests: added conftest.py and test_client_token.py

## [4.4.1] - 2026-02-09


### Added

- **Application status and URLs** - Server-side SDK support for updating and fetching application status
  - `MisoClient.update_my_application_status(body, env_key=None, auth_strategy=None)` - Update own application status/URLs via POST self/status
  - `MisoClient.get_application_status(env_key, app_key, auth_strategy=None)` - Fetch any application's status/URLs (no configuration)
  - New types: `UpdateSelfStatusRequest`, `UpdateSelfStatusResponse`, `ApplicationStatusResponse`
  - `ApplicationsApi` in API layer with `update_self_status` and `get_application_status`
  - When `env_key`/`app_key` omitted, uses `ApplicationContextService` for current app context

### Removed

- **Makefile.ps1** - Removed PowerShell Makefile; use `make` commands for all platforms (Windows users can use Git Bash or WSL)

### Technical

- **Circular import fix** - API package uses lazy imports so `api.types.applications_types` can be imported without pulling in `HttpClient` (fixes import cycle with services/logger).


## [4.4.0] - 2026-02-04

### Changed

- **Logging public API (breaking)** - Removed auto-computable parameters from public logging methods and `ClientLoggingOptions`
  - `LoggerService`: removed token-based helper methods; rely on request/context extraction
  - `LoggerChain`: removed `add_user`, `add_application`, `add_correlation`, `add_session`, `with_token`, and `with_application_id`
  - `ClientLoggingOptions`: removed auto-computable fields (user/session/correlation/request, IP/UA, token, requestSize)
- **Context flow** - Auto-computable fields are now promoted from request/contextvars instead of public params
- **Docs** - Updated usage examples and added async context propagation notes

### Technical

- Updated logger helpers and request helpers to split/promote auto fields from context
- Updated unit tests for new logging API and context handling

## [4.3.1] - 2026-02-01

### Fixed

- **HTTP client body params** - `post()` and `put()` no longer pass body parameters twice to httpx
  - `InternalHttpClient`: Body-related kwargs (`json`, `content`, `data`, `files`) are popped and passed to httpx at most once, avoiding "got multiple values for keyword argument 'json'" when callers pass both positional `data` and `json=` in kwargs
  - `HttpClient`: Docstrings updated to document that callers may pass `json=` in kwargs and body params are forwarded without duplication

### Technical

- Added unit tests for post/put with `json` kwarg (no duplicate body params)

## [4.3.0] - 2026-01-27

### Added

- **AuthMethod Error Tracking** - Added `authMethod` field to track authentication method on 401 errors
  - New `authMethod` field in `ErrorResponse` model (Literal: "bearer", "client-token", "client-credentials", "api-key")
  - New `auth_method` property in `MisoClientError` exception
  - New `detect_auth_method_from_headers()` utility for client-side fallback detection
  - New `AuthMethod` type export from `miso_client`
  - Helps identify which authentication mechanism failed (bearer token, client token, client credentials, or API key)

### Changed

- **Error Response Enhancement** - `ErrorResponse` now includes optional `authMethod` field for 401 errors
- **MisoClientError Enhancement** - Exception now exposes `auth_method` property extracted from error response or fallback detection
- **InternalHttpClient** - Added centralized `_create_error_from_http_status()` method for consistent 401 error handling
- **ClientTokenManager** - Now includes `auth_method="client-credentials"` when raising `AuthenticationError`

### Technical

- Added 28 new unit tests in `test_http_error_handler.py` for auth method detection and error parsing
- Added 10 new unit tests in `test_errors.py` for auth_method functionality
- Improved docstring formatting across all modules (742 style fixes)
- Fixed 21 line-too-long errors in source code
- Fixed 17 line-too-long errors in test files
- All 1270 unit tests pass with 93% coverage

## [4.2.0] - 2026-01-26

### Added

- **User Info Caching** - Added caching for `get_user_info()` API calls to reduce controller load
  - Results cached using userId from JWT token with configurable TTL (default 5 minutes)
  - Added `user_ttl` configuration option in `MisoClientConfig` (default: 300 seconds)
  - Added `clear_user_cache()` method to manually clear cached user info
  - Cache automatically cleared on logout
- **Auth Token Cache Helpers** - Extracted token validation caching to `auth_token_cache.py`
  - `check_cache_for_token()` - Check cache for validation result
  - `cache_validation_result()` - Cache successful validation
- **Auth User Cache Helpers** - Extracted user info caching to `auth_user_cache.py`
  - `get_user_cache_key()` - Generate cache key for user info
  - `check_user_info_cache()` - Check cache for user info
  - `cache_user_info()` - Cache user info result
  - `clear_user_cache()` - Clear cached user info
- **LogsStatsApi** - Extracted log statistics and export endpoints to `logs_stats_api.py`
  - `get_stats_summary()`, `get_stats_errors()`, `get_stats_users()`, `get_stats_applications()`
  - `export_logs()` - Export logs in CSV or JSON format
- **ApplicationContextMixin** - Added mixin for shared application context logic
  - `_get_app_context_service()` - Get or create application context service
  - `_get_environment_from_context()` - Get environment from cached context

### Changed

- **Code Organization** - Refactored large files to comply with 500-line limit
  - `auth.py` reduced from 538 to 489 lines (extracted caching helpers)
  - `logs_api.py` reduced from 671 to 482 lines (extracted stats API)
  - `role.py` and `permission.py` now use `ApplicationContextMixin` (removed duplicate methods)

### Technical

- Added 16 new unit tests for user info caching (`test_auth_service_caching.py`)
- All 1234 unit tests pass with 93% coverage
- Improved code maintainability by extracting shared functionality into mixins and helpers

## [4.1.2] - 2026-01-21

### Changed

- **CI/CD Workflow Simplified** - Updated `publish.yml` to trigger on tag push
  - Workflow now triggers automatically when a version tag (v*) is pushed
  - Removed dependency on GitHub Release creation
  - Streamlined release process: commit → tag → push → auto-publish

## [4.1.1] - 2026-01-21

### Changed

- **CI/CD Workflow Improvements** - Updated `publish.yml` to prevent duplicate PyPI uploads
  - Removed auto-trigger on push to main branch
  - Added pre-publish check to verify version doesn't already exist on PyPI
  - Added build verification and publication confirmation steps
  - Release now triggers only on GitHub Release publish or manual workflow dispatch

### Added

- New `/tag-and-push-release` Cursor command for streamlined release process
  - Automatically creates git tag from version in `pyproject.toml`
  - Extracts release notes from CHANGELOG.md
  - Creates GitHub Release with extracted notes
  - Triggers PyPI publish workflow

## [4.1.0] - 2026-01-21

### Changed

- **Encryption Key Required** - `encryptionKey` is now a required parameter for encryption operations
  - Load from `MISO_ENCRYPTION_KEY` environment variable
  - Or provide `encryption_key` in `MisoClientConfig`
  - Throws `ENCRYPTION_KEY_REQUIRED` error if not configured when calling encrypt/decrypt
  - Provides two-level authorization: client credentials + encryption key
  - `encryptionKey` is never logged (added to sensitive fields config)

### Added

- `ENCRYPTION_KEY_REQUIRED` error code for missing encryption key
- `encryption_key` field to `MisoClientConfig`
- `MISO_ENCRYPTION_KEY` environment variable support in config loader
- `encryptionKey` to sensitive fields config for data masking

### Fixed

- `ACCESS_DENIED` error now also maps from 401 status (in addition to 403)

### Technical

- Extracted `transform_log_entry_to_request` to `logger_helpers.py` to reduce `logger.py` file size
- Updated encryption service tests with new fixtures and validation test cases
- Updated config loader tests for `MISO_ENCRYPTION_KEY` environment variable

## [4.0.2] - 2026-01-20

### Fixed

- **Caching Performance**: Fixed caching to avoid unnecessary controller calls on cache hits
  - Added synchronous `get_application_context_sync()` method to `ApplicationContextService` that uses cached client token without triggering token refresh
  - Updated `PermissionService.get_permissions()` and `PermissionService.refresh_permissions()` to use synchronous application context
  - Updated `RoleService.get_roles()` and `RoleService.refresh_roles()` to use synchronous application context
  - Application context is now cached and reused, preventing unnecessary controller calls when fetching roles/permissions from cache
  - Matches TypeScript implementation behavior where `getApplicationContext()` is synchronous and doesn't trigger controller calls

### Added

- **API Test Coverage**: Added comprehensive integration tests for all API methods
  - Added integration tests for `AuthApi.refresh_token()`, `AuthApi.initiate_device_code()`, `AuthApi.poll_device_code_token()`, and `AuthApi.refresh_device_code_token()`
  - Added integration tests for `LogsApi.get_job_log()` and `LogsApi.export_logs()` (CSV and JSON formats)
  - Refactored existing LogsApi tests to use API layer (`api_client.logs.*`) instead of direct HTTP calls
  - Created `test_api_validation.py` script to validate API method test coverage
  - All 27 API methods now have integration tests with 100% API layer coverage

### Technical

- Added 8 new unit tests for cache behavior validation
- All tests use API layer methods instead of direct HTTP client calls
- Improved test organization and maintainability

## [4.0.1] - 2026-01-20

### Fixed

- **Roles and Permissions API Context Parameters**: Updated RoleService and PermissionService to extract and pass both `environment` and `application` parameters from ApplicationContextService to API calls
  - `RoleService.get_roles()`: Now extracts and passes both `environment` and `application` to `RolesApi.get_roles()`
  - `RoleService.refresh_roles()`: Now extracts and passes both `environment` and `application` to `RolesApi.refresh_roles()`
  - `PermissionService.get_permissions()`: Now extracts and passes both `environment` and `application` to `PermissionsApi.get_permissions()`
  - `PermissionService.refresh_permissions()`: Now extracts and passes both `environment` and `application` to `PermissionsApi.refresh_permissions()`
  - Both services now properly extract `application` from `ApplicationContext` (previously only extracted `environment`)
  - HttpClient fallback methods now build params dictionary with both `environment` and `application` when available

## [4.0.0] - 2026-01-20

### Breaking Changes

- **Encryption Service Rewrite**: Local Fernet encryption replaced with server-side encryption via miso-controller
  - `encrypt()` now async: `await client.encryption.encrypt(plaintext, parameter_name)`
  - `decrypt()` now async: `await client.encryption.decrypt(value, parameter_name)`
  - `encrypt()` returns `EncryptResult` object (with `value` and `storage` fields) instead of string
  - Both methods now require `parameter_name` argument (1-128 chars, alphanumeric with ._-)
  - `ENCRYPTION_KEY` environment variable no longer used
  - `cryptography` dependency no longer required for encryption (still used elsewhere in SDK)

### Added

- `EncryptionError` exception with error codes for better error handling:
  - `INVALID_PARAMETER_NAME` - Parameter name doesn't match pattern
  - `ENCRYPTION_FAILED` - Controller encryption failed
  - `DECRYPTION_FAILED` - Controller decryption failed
  - `ACCESS_DENIED` - App doesn't have access to parameter
  - `PARAMETER_NOT_FOUND` - Parameter doesn't exist (Key Vault mode)
- `EncryptResult` model with `value` and `storage` fields
- `StorageType` type alias for storage backends (`"keyvault"` | `"local"`)
- `docs/encryption.md` - Comprehensive encryption service documentation

### Changed

- `EncryptionService` now receives `HttpClient` as constructor argument (instead of optional `encryption_key`)
- Encryption service is always available (no longer optional based on `ENCRYPTION_KEY`)

### Removed

- Local Fernet encryption implementation
- `ENCRYPTION_KEY` environment variable support for encryption
- Old `test_encryption.py` unit tests (replaced with `test_encryption_service.py`)

### Migration Guide

**Before (v3.x):**

```python
# Required ENCRYPTION_KEY environment variable
client = MisoClient(config)
encrypted = client.encrypt("secret")  # Sync, returns string
decrypted = client.decrypt(encrypted)  # Sync
```

**After (v4.0.0):**

```python
# No ENCRYPTION_KEY needed - controller handles encryption
client = MisoClient(config)
await client.initialize()

result = await client.encryption.encrypt("secret", "my-param")
# result.value: "kv://my-param" or "enc://v1:..."
# result.storage: "keyvault" or "local"

decrypted = await client.encryption.decrypt(result.value, "my-param")
```

## [3.9.4] - 2026-01-20

### Fixed

- **Auth API Type Alignment with OpenAPI Spec**: Updated all Auth API response types to match controller OpenAPI specification
  - Removed extraneous `success` and `timestamp` fields from response types (controller returns `{"data": {...}}` format)
  - `LoginResponse`: Removed `success` and `timestamp` fields, now only contains `data`
  - `ValidateTokenResponse`: Removed wrapper fields, added `environment` and `application` to `ValidateTokenResponseData`
  - `GetUserResponse`: Removed wrapper fields, made `user` field optional in `GetUserResponseData`
  - `LogoutResponse`: Updated to match spec with `data` field containing optional `LogoutResponseData`
  - `RefreshTokenResponse`: Removed wrapper fields
  - `DeviceCodeResponseWrapper`: Removed `success` and `timestamp` fields
  - `DeviceCodeTokenPollResponse`: Removed `timestamp` field
  - `GetRolesResponse`, `RefreshRolesResponse`: Removed wrapper fields, made `roles` use `default_factory`
  - `GetPermissionsResponse`, `RefreshPermissionsResponse`: Removed wrapper fields, made `permissions` use `default_factory`

- **AuthService Response Handling**: Updated service methods to align with simplified response types
  - `validate_token_with_api_client()`: Returns data without `success`/`timestamp` wrapper
  - `login()`: Returns data without wrapper fields
  - `logout()`: Fixed unused `response` variable linting error

- **Test Suite Updates**: Simplified test mocks to match new response format
  - Updated `test_auth_api.py` with streamlined mock responses
  - Updated `test_auth_utils.py` to use simplified response structures
  - Updated `test_miso_client.py` with corrected response format

### Technical

- **Code Cleanup**: Removed 88 lines of redundant code across 6 files
- **Type Safety**: All response types now strictly match OpenAPI specification
- **Test Coverage**: All 1025 tests passing with 89% code coverage

## [3.9.2] - 2026-01-19

### Added

- **LogsApi Extended Endpoints**: Complete Logs API implementation with all listing, statistics, and export endpoints
  - `list_general_logs()`: GET /api/v1/logs/general - List general logs with pagination and filters
  - `list_audit_logs()`: GET /api/v1/logs/audit - List audit logs with pagination and filters
  - `list_job_logs()`: GET /api/v1/logs/jobs - List job logs with pagination and filters
  - `get_job_log()`: GET /api/v1/logs/jobs/{id} - Get single job log entry
  - `get_stats_summary()`: GET /api/v1/logs/stats/summary - Get aggregated log statistics
  - `get_stats_errors()`: GET /api/v1/logs/stats/errors - Get top error statistics
  - `get_stats_users()`: GET /api/v1/logs/stats/users - Get user activity statistics
  - `get_stats_applications()`: GET /api/v1/logs/stats/applications - Get application statistics
  - `export_logs()`: GET /api/v1/logs/export - Export logs in CSV or JSON format

- **Logs Type Models**: Comprehensive Pydantic models for all new Logs API endpoints
  - `GeneralLogEntry`, `AuditLogEntry`, `JobLogEntry`: Log entry models for list responses
  - `ListGeneralLogsResponse`, `ListAuditLogsResponse`, `ListJobLogsResponse`: Paginated list responses
  - `GetJobLogResponse`: Single job log entry response
  - `LogStatsSummaryResponse`, `LogStatsErrorsResponse`: Statistics response models
  - `LogStatsUsersResponse`, `LogStatsApplicationsResponse`: User and application statistics
  - `LogExportResponse`, `LogExportMeta`: Export response models
  - `ForeignKeyReference`, `PaginationLinks`: Supporting type models
  - `TopError`, `TopUser`, `ApplicationStats`: Statistics data models

- **Extended Integration Tests**: Comprehensive integration tests for new API endpoints
  - Tests for all new Logs API endpoints (list, stats, export)
  - Tests for Auth cache endpoints (stats, performance, efficiency)
  - Tests for negative scenarios (invalid tokens, error handling)
  - Tests for login diagnostics endpoint

### Technical

- **LogsApi**: Extended from 121 to 659 lines with all new endpoints
- **logs_types.py**: Extended from 71 to 297 lines with all new type models
- **types/__init__.py**: Added exports for all new type models (25 new exports)
- **test_api_endpoints.py**: Extended from 458 to 869 lines with comprehensive integration tests
- All new endpoints follow existing patterns with proper authentication and error handling

## [3.9.1] - 2026-01-18

### Added

- **Pagination Utilities**: Added snake_case `parse_pagination_params()` function
  - New `parse_pagination_params()` function that returns tuple `(page, page_size)` 
  - Matches the pattern of `parse_filter_params` and `parse_sort_params` (snake_case naming)
  - Provides Pythonic tuple return type alongside existing `parsePaginationParams()` (camelCase dict return)
  - Both functions coexist for backward compatibility
  - Comprehensive test coverage with 13 test cases covering edge cases

### Technical

- **Code Quality**: Import ordering improvements in filter utilities
- **Documentation**: Updated README.md with examples for both `parsePaginationParams` and `parse_pagination_params`

## [3.9.0] - 2026-01-15

### Added

- **Enhanced Filter System with Schema Validation**: Comprehensive filter validation and SQL compilation utilities
  - New `FilterSchema` and `FilterFieldDefinition` models for defining filterable fields with type constraints
  - Schema-based validation with `validate_filter()` and `validate_filters()` functions
  - Type coercion utilities supporting string, number, boolean, UUID, timestamp, and enum types
  - PostgreSQL SQL compilation with `compile_filter()` and `compile_filters()` functions
  - Support for `ilike` operator (case-insensitive LIKE) for string filtering
  - `DEFAULT_OPERATORS_BY_TYPE` constant for default operators per field type
  - `create_filter_schema()` helper function for creating schemas with default operators
  - RFC 7807 compliant error responses for filter validation errors
  - New `filter_schema.py` module with validation and compilation utilities
  - New `filter_coercion.py` module with type coercion functions

- **Code Organization Improvements**: Refactored large files to improve maintainability
  - New `logger_request_helpers.py` module with request context extraction helpers
  - New `http_client_auth_helpers.py` module with authentication and token refresh helpers
  - New `auth_cache_helpers.py` module with token validation cache utilities
  - Extracted helper functions to reduce file sizes and improve code organization

### Changed

- **Filter Schema**: Enhanced filter system with schema-based validation
  - `filter_schema.py` reduced from 556 to 394 lines (under 500-line limit)
  - Improved code organization with separated coercion functions
  - Better error handling with RFC 7807 compliant error responses

- **Code Organization**: Refactored large files to meet code size guidelines
  - `logger.py` reduced from 659 to 544 lines (extracted request helpers)
  - `http_client.py` reduced from 609 to 591 lines (extracted auth helpers)
  - `auth.py` reduced from 569 to 552 lines (extracted cache helpers)
  - Improved maintainability through better separation of concerns

### Technical

- **New modules**: 
  - `miso_client/models/filter_schema.py` - Filter schema type definitions
  - `miso_client/utils/filter_schema.py` - Schema validation and SQL compilation
  - `miso_client/utils/filter_coercion.py` - Type coercion functions
  - `miso_client/utils/logger_request_helpers.py` - Logger request helpers
  - `miso_client/utils/http_client_auth_helpers.py` - HTTP client auth helpers
  - `miso_client/utils/auth_cache_helpers.py` - Auth cache helpers
- **Enhanced exports**: New filter schema utilities exported from `miso_client/__init__.py`
- **Test coverage**: Comprehensive test suite for filter schema functionality (59 tests)
- **Code quality**: All files pass linting and formatting checks

## [3.8.1] - 2026-01-10

### Added

- **Unified Application Context Service**: New `ApplicationContextService` for consistent application context extraction
  - Extracts `application`, `applicationId`, and `environment` with consistent fallback logic
  - Extracts from client token first (if available), then falls back to parsing `MISO_CLIENTID` format: `miso-controller-{environment}-{application}`
  - Supports overwriting application context for dataplane use cases where external applications need logging on their behalf
  - Caches parsed results to avoid repeated extraction
  - Integrated with `LoggerService` for automatic context extraction in log entries

- **Application Context Overwrites**: Enhanced `ClientLoggingOptions` with overwrite support
  - Added `application` field for overriding application name (for dataplane logging)
  - Added `environment` field for overriding environment name (for dataplane logging)
  - Existing `applicationId` field can be used to override application ID
  - Overwrites take highest priority when provided, allowing dataplane services to log on behalf of external applications

- **LoggerService Integration**: Enhanced logger service with application context extraction
  - `LoggerService` now uses `ApplicationContextService` for consistent context extraction
  - Automatic fallback logic: overwrites → application context service → JWT token context → defaults
  - Improved consistency across all logging methods

### Changed

- **LoggerService**: Updated to use `ApplicationContextService` for application context extraction
  - Consistent fallback logic across all logging methods
  - Better support for dataplane logging scenarios
  - Improved context extraction from client tokens and clientId format

- **Logger Helpers**: Enhanced `build_log_entry()` to support application context parameter
  - Accepts optional `application_context` parameter for explicit context
  - Priority order: overwrites → application context → JWT context → defaults

### Technical

- **New service**: `miso_client/services/application_context.py` - ApplicationContextService implementation
- **Enhanced models**: `ClientLoggingOptions` - Added `application` and `environment` fields for overwrites
- **Code organization**: Improved separation of concerns with dedicated application context service

## [3.8.0] - 2026-01-10

### Added
- **Unified Logging Interface**: New minimal API with automatic context extraction
  - `get_logger()` factory function for automatic context detection from contextvars
  - `set_logger_context()` and `clear_logger_context()` for manual context management
  - `logger_context_middleware` FastAPI/Flask middleware helpers for automatic context extraction
  - contextvars-based context propagation across async boundaries
  - Simplified API: `logger.info(message)`, `logger.error(message, error?)`, `logger.audit(action, resource, entity_id?, old_values?, new_values?)`
  - Automatic context extraction from contextvars (no need to pass Request objects)
  - `UnifiedLogger` service class wrapping `LoggerService` with minimal interface
  - `LoggerContextStorage` utility for contextvars-based context management

### Documentation
- Added unified logging examples and guides to README.md
- Updated FastAPI/Flask middleware examples with unified logging pattern
- Added background job logging examples with unified interface
- Comprehensive API reference for UnifiedLogger interface

## [3.7.2] - 2026-01-10

### Added

- **Comprehensive Integration Tests** - Integration test suite for all Auth and Logs API endpoints
  - New `tests/integration/test_api_endpoints.py` with comprehensive endpoint testing
  - Tests all Auth API endpoints: client token generation, user info, token validation, login, logout, roles, permissions
  - Tests all Logs API endpoints: error logs, general logs, audit logs, batch logs
  - Tests against real controller using credentials from `.env` file
  - Fast failure with 500ms timeout when controller is unavailable
  - Graceful skipping when required environment variables are not set
  - Ensures API validation catches real issues before release

### Fixed

- **Client Token Status Code** - Updated to accept both 200 and 201 status codes
  - `/api/v1/auth/token` endpoint returns 201 (Created) per OpenAPI spec
  - Client token manager now accepts both 200 and 201 for backward compatibility
  - Prevents authentication failures when controller returns 201 instead of 200

## [3.7.0] - 2026-01-09

### Added

- **Enhanced Error Logging with Correlation IDs** - Automatic correlation ID extraction and propagation
  - New `extract_correlation_id_from_error()` utility function to extract correlation IDs from exceptions
  - Correlation IDs automatically extracted from HTTP response headers and included in error responses
  - Service methods now automatically extract and include correlation IDs in error logs
  - HTTP client audit logging includes correlation IDs from error responses
  - Improved traceability from API errors to log entries for easier debugging
  - Public logger methods return `LogEntry` objects with auto-extracted context for custom logger tables

- **Unified JSON Filter Model** - Consistent filtering API for both query strings and JSON bodies
  - New `JsonFilter` model for unified filter representation in JSON format
  - New `FilterGroup` model supporting complex AND/OR logic in filters
  - Support for null check operators (`isNull`, `isNotNull`) for checking null/not-null field values
  - Conversion utilities between query string format and JSON format
  - `FilterQuery` now supports JSON serialization/deserialization
  - New `post_with_filters()` method in HttpClient for JSON body filtering
  - Filter validation when deserializing from JSON
  - Support for nested filter groups with AND/OR operators

- **Redis-Backed Caching for Token Validation** - Improved performance for token validation
  - Token validation results are now cached in Redis with configurable TTL
  - Reduces redundant API calls to controller for token validation
  - Automatic cache invalidation on token expiration
  - Graceful fallback to controller when Redis is unavailable

- **HTTP Client Query Helpers** - Extracted helper utilities for better code organization
  - New `http_client_query_helpers.py` module with filter and pagination utilities
  - Improved code organization and maintainability
  - Better separation of concerns in HTTP client

- **Filter Conversion Utilities** - Enhanced filter manipulation capabilities
  - New utilities for converting between `FilterQuery`, `JsonFilter`, and query strings
  - `filter_query_to_json()` and `json_to_filter_query()` conversion functions
  - `json_filter_to_query_string()` and `query_string_to_json_filter()` utilities
  - Support for bidirectional conversion between formats

### Changed

- **HTTP Client Architecture** - Improved code organization and maintainability
  - Extracted logging helpers to `http_client_logging_helpers.py` module
  - Extracted query helpers to `http_client_query_helpers.py` module
  - Reduced `http_client.py` file size to comply with code size guidelines
  - Better separation of concerns and improved testability

- **Authorization Services** - Code quality improvements and reduced duplication
  - Extracted shared `validate_token_request()` utility to `auth_utils.py`
  - Eliminated code duplication between `RoleService` and `PermissionService`
  - Improved error handling with correlation ID extraction
  - Better code reuse and maintainability

- **Authentication Service** - Enhanced error handling and logging
  - Improved error logging with correlation ID extraction
  - Better integration with error utilities
  - Enhanced token validation error handling

- **Logger Service** - Enhanced logging capabilities
  - Improved error logging with correlation ID extraction
  - Public methods return `LogEntry` objects with auto-extracted context
  - Better support for projects using custom logger tables
  - Enhanced structured logging with correlation IDs

- **Filter Utilities** - Enhanced filter model and validation
  - `FilterQuery` now supports JSON serialization/deserialization
  - Added filter validation utilities
  - Improved filter group support with AND/OR operators
  - Better error messages for invalid filter structures

- **Internal HTTP Client** - Improved error handling
  - Enhanced error response parsing with correlation ID extraction
  - Better integration with error utilities
  - Improved error message generation

- **HTTP Client Logging** - Enhanced audit logging
  - Correlation IDs automatically extracted from error responses
  - Improved error context in audit logs
  - Better traceability for debugging

### Fixed

- **Code Quality** - Fixed linting issues
  - Removed unused imports across multiple files
  - Fixed code style violations
  - Improved code consistency

- **Filter Validation** - Enhanced validation and error handling
  - Better validation for filter structure when deserializing from JSON
  - Improved error messages for invalid filters
  - Better handling of edge cases in filter parsing

### Technical

- **New utility files**:
  - `miso_client/utils/http_client_query_helpers.py` - Filter and pagination query helpers
  - `miso_client/utils/http_client_logging_helpers.py` - HTTP client logging helpers
  - `miso_client/utils/filter_applier.py` - Filter application utilities
  - `miso_client/utils/filter_parser.py` - Filter parsing utilities

- **Enhanced models**:
  - `FilterQuery` - Added JSON serialization/deserialization support
  - `JsonFilter` - New unified JSON filter model
  - `FilterGroup` - New filter group model for complex AND/OR logic

- **Code organization improvements**:
  - Reduced file sizes to comply with code size guidelines
  - Better separation of concerns
  - Improved maintainability and testability

- **Test coverage improvements**:
  - Enhanced test coverage for filter utilities
  - Improved test coverage for logger service
  - Better test organization and structure

## [3.3.0] - 2025-12-23

### Added

- **Centralized API Layer with Typed Interfaces** - New architecture for controller API communication
  - New `ApiClient` class providing centralized access to all controller APIs
  - Domain-specific API classes: `AuthApi`, `RolesApi`, `PermissionsApi`, `LogsApi`
  - Typed request/response models in `miso_client/api/types/` for type safety
  - All API methods use camelCase naming convention for consistency
  - Services now use API layer internally for better separation of concerns
  - Improved maintainability and testability with clear API boundaries

- **User Token Refresh Manager** - Automatic user token refresh with proactive expiration handling
  - New `UserTokenRefreshManager` class for managing user Bearer token refresh
  - Supports multiple refresh mechanisms: callback functions, stored refresh tokens, JWT refresh tokens
  - Proactive token refresh before expiration to prevent 401 errors
  - Automatic retry on 401 errors with token refresh
  - Thread-safe concurrent refresh handling with per-user locks
  - Integrated with `AuthService` for seamless token refresh endpoint calls
  - Exported from main module for advanced use cases

- **Request Context Extraction Utilities** - Standardized request context extraction for HTTP frameworks
  - New `RequestContext` class for structured request metadata
  - New `extract_request_context()` function supporting multiple frameworks
  - Supports FastAPI/Starlette, Flask, and generic dict-like request objects
  - Extracts IP address, correlation ID, HTTP method, path, and user information
  - Handles various header formats and proxy configurations
  - Useful for audit logging and request tracing
  - Exported from main module for framework integration

- **Logging Helpers** - Enhanced logging utilities for structured logging
  - New `miso_client/utils/logging_helpers.py` with helper functions
  - Improved integration with request context for audit logging
  - Better support for correlation IDs and request tracing

- **Enhanced Logger Chain** - Improved fluent API for logging
  - Enhanced `LoggerChain` class with additional context methods
  - Better integration with request context extraction
  - Improved error handling and context propagation

### Changed

- **Service Layer Architecture** - Services now use centralized API layer
  - `AuthService`, `RoleService`, `PermissionService` now use `ApiClient` internally
  - Better separation between service logic and API communication
  - Improved type safety with typed API interfaces
  - Maintains backward compatibility with existing service methods

- **MisoClient Initialization** - Enhanced client initialization
  - `MisoClient` now creates `ApiClient` instance for API access
  - Services receive `ApiClient` instead of direct `HttpClient` access
  - Improved architecture with clear API boundaries

- **Logger Service** - Enhanced logging capabilities
  - Better integration with request context extraction
  - Improved structured logging with indexed fields
  - Enhanced error handling and context propagation

### Technical

- **New API layer files**:
  - `miso_client/api/__init__.py` - API client factory
  - `miso_client/api/auth_api.py` - Authentication API interface
  - `miso_client/api/roles_api.py` - Roles API interface
  - `miso_client/api/permissions_api.py` - Permissions API interface
  - `miso_client/api/logs_api.py` - Logs API interface
  - `miso_client/api/types/` - Typed request/response models

- **New utility files**:
  - `miso_client/utils/user_token_refresh.py` - User token refresh manager
  - `miso_client/utils/request_context.py` - Request context extraction
  - `miso_client/utils/logging_helpers.py` - Logging helper functions

- **New test files**:
  - `tests/unit/test_api_client.py` - API client tests
  - `tests/unit/test_auth_api.py` - Auth API tests
  - `tests/unit/test_roles_api.py` - Roles API tests
  - `tests/unit/test_permissions_api.py` - Permissions API tests
  - `tests/unit/test_logs_api.py` - Logs API tests
  - `tests/unit/test_request_context.py` - Request context tests
  - `tests/unit/test_user_token_refresh.py` - User token refresh tests
  - `tests/unit/test_logging_helpers.py` - Logging helpers tests

- **Exports updated**:
  - `miso_client/__init__.py` - Exports `ApiClient`, `UserTokenRefreshManager`, `RequestContext`, `extract_request_context`
  - Public API maintains snake_case naming convention for functions

- **Package structure**:
  - New `miso_client/api/` package for API layer
  - New `miso_client/api/types/` package for typed interfaces
  - Enhanced service layer with API integration

## [3.2.0] - 2025-12-22

### Added

- **Circuit breaker for HTTP logging** - Prevents infinite retry loops when logging service is unavailable
  - Added circuit breaker pattern to `LoggerService` and `AuditLogQueue`
  - Automatically disables HTTP logging after 3 consecutive failures
  - Circuit breaker opens for 60 seconds after failures, then resets
  - Prevents performance degradation when controller logging endpoint is unavailable
  - Gracefully handles network errors and server unavailability
  - Configurable via `AuditConfig.circuitBreaker` with `failureThreshold` and `resetTimeout`

- **Client token expiration checking** - Enhanced token validation with JWT expiration support
  - Improved `_fetch_client_token()` to check JWT expiration claims when expiration timestamp is missing
  - Decodes JWT tokens to extract `exp` claim for expiration validation
  - Better logging for debugging token expiration issues
  - Handles missing expiration timestamps gracefully
  - Automatically removes expired tokens from cache

- **Controller URL validation utility** - Exported URL validation function
  - `validate_url()` function now exported from `url_validator.py`
  - Validates HTTP/HTTPS URLs with comprehensive checks
  - Rejects dangerous protocols (`javascript:`, `data:`, `file:`, etc.)
  - Useful for validating URLs before use in application code
  - Exported from `miso_client` module for public use

- **Public and Private Controller URL Support** - Separate URLs for browser and server environments
  - New `controllerPublicUrl` configuration option for browser/public environments (accessible from internet)
  - New `controllerPrivateUrl` configuration option for server environments (internal network access)
  - New `resolve_controller_url()` utility function that automatically detects environment and selects appropriate URL
  - New `is_browser()` utility function for environment detection (always returns False for Python SDK)
  - Environment variable support: `MISO_WEB_SERVER_URL` (maps to `controllerPublicUrl` for browser)
  - Environment variable support: `MISO_CONTROLLER_URL` (maps to `controllerPrivateUrl` for server, maintains backward compatibility)
  - Automatic URL resolution based on environment:
    - Server environment: Uses `controllerPrivateUrl` → falls back to `controller_url`
  - URL validation ensures resolved URLs are valid HTTP/HTTPS URLs
  - Clear error messages when no URL is configured
  - `InternalHttpClient` and `AuthService` now use resolved URLs automatically

- **Flask/FastAPI Client Token Endpoint Utilities** - Server-side route handlers for client token endpoints
  - New `create_flask_client_token_endpoint()` function for Flask applications
  - New `create_fastapi_client_token_endpoint()` function for FastAPI applications
  - Automatically enriches response with DataClient configuration including `controllerPublicUrl`
  - Uses `get_environment_token()` with origin validation for security
  - Returns client token + DataClient config to frontend clients
  - Handles errors appropriately: 503 (not initialized), 403 (origin validation), 500 (other errors)
  - Supports optional configuration via `ClientTokenEndpointOptions`
  - Zero-config server-side setup for DataClient initialization
  - Flask and FastAPI are optional peer dependencies (graceful import handling)

### Changed

- **InternalHttpClient** - Now uses `resolve_controller_url()` for automatic URL resolution
  - Constructor uses resolved URL instead of hardcoded `config.controller_url`
  - Client token fetch uses resolved URL for temporary httpx instance
  - Maintains backward compatibility with existing `controller_url` configuration

- **Config Loader** - Enhanced environment variable parsing
  - `MISO_WEB_SERVER_URL` loads into `controllerPublicUrl` (browser/public)
  - `MISO_CONTROLLER_URL` loads into `controllerPrivateUrl` (server/private) and `controller_url` (backward compatibility)
  - Maintains existing behavior for applications using `MISO_CONTROLLER_URL`

- **LoggerService** - Integrated circuit breaker for HTTP logging
  - Checks circuit breaker state before attempting HTTP logging
  - Records success/failure in circuit breaker
  - Skips HTTP logging when circuit is OPEN to prevent infinite retry loops

- **AuditLogQueue** - Integrated circuit breaker for batch logging
  - Checks circuit breaker state before attempting HTTP batch logging
  - Records success/failure in circuit breaker
  - Skips HTTP logging when circuit is OPEN

### Technical

- **New utility files**:
  - `miso_client/utils/circuit_breaker.py` - Circuit breaker implementation
  - `miso_client/utils/url_validator.py` - URL validation utility
  - `miso_client/utils/controller_url_resolver.py` - URL resolution with environment detection
  - `miso_client/utils/flask_endpoints.py` - Flask route handler utilities
  - `miso_client/utils/fastapi_endpoints.py` - FastAPI route handler utilities

- **New test files**:
  - `tests/unit/test_circuit_breaker.py` - Circuit breaker tests
  - `tests/unit/test_url_validator.py` - URL validation tests
  - `tests/unit/test_controller_url_resolver.py` - URL resolution tests
  - `tests/unit/test_flask_endpoints.py` - Flask endpoint tests
  - `tests/unit/test_fastapi_endpoints.py` - FastAPI endpoint tests

- **Exports updated**:
  - `miso_client/__init__.py` - Exports `validate_url`, `resolve_controller_url`, `is_browser`, `create_flask_client_token_endpoint`, `create_fastapi_client_token_endpoint`
  - Public API maintains snake_case naming convention for functions

- **Configuration models updated**:
  - `AuditConfig` - Added `circuitBreaker` field (camelCase)
  - `MisoClientConfig` - Added `controllerPublicUrl` and `controllerPrivateUrl` fields (camelCase)
  - New models: `CircuitBreakerConfig`, `DataClientConfigResponse`, `ClientTokenEndpointResponse`, `ClientTokenEndpointOptions`

- **Package dependencies**:
  - Added optional dependencies: `flask>=2.0.0`, `fastapi>=0.100.0`
  - Flask and FastAPI are peer dependencies (not required unless using endpoint utilities)

## [3.0.1] - 2025-12-14

### Added

- **Server-Side Environment Token Utility**: New `get_environment_token()` function for secure server-side token fetching
  - Validates request origin against configured `allowedOrigins` before fetching token
  - Includes ISO 27001 compliant audit logging with automatic data masking
  - Raises `AuthenticationError` if origin validation fails
  - Supports various request header formats (dict, FastAPI, Flask, Starlette)
  - Exported from main module for easy integration

- **Origin Validation Utility**: New `validate_origin()` function for CORS security
  - Validates request origin against allowed origins list
  - Checks `origin` header first, falls back to `referer` header
  - Supports wildcard port matching (e.g., `http://localhost:*` matches any port)
  - Returns validation result with error message if invalid
  - Handles various request header object types (dict, FastAPI, Flask, Starlette)
  - Exported from main module for reuse in custom middleware

- **Client Token Info Extraction**: New `extract_client_token_info()` function for token introspection
  - Extracts application and environment information from client JWT tokens
  - Decodes JWT without verification (no secret available)
  - Supports multiple field name variations (`application`, `applicationId`, `environment`, `clientId`)
  - Returns dictionary with optional fields for flexible integration
  - Exported from main module for token analysis utilities

- **Configuration Enhancements**: Enhanced `MisoClientConfig` with origin validation support
  - Added `allowedOrigins` configuration field for CORS origin validation
  - Supports wildcard port matching in origin URLs
  - Backward compatible - validation is optional if `allowedOrigins` is not configured

### Changed

- **Internal HTTP Client**: Enhanced `InternalHttpClient` with environment token method
  - Added `get_environment_token()` method for fetching client tokens
  - Integrates with existing client token management infrastructure

- **HTTP Client**: Enhanced `HttpClient` with environment token access
  - Added `get_environment_token()` method delegating to internal client
  - Maintains consistent API surface for token operations

- **MisoClient**: Enhanced main client with environment token access
  - Added `get_environment_token()` method for convenient token access
  - Delegates to `AuthService` for consistent behavior

### Testing

- Added comprehensive unit tests for all new utilities
  - Tests for `get_environment_token()` with origin validation scenarios
  - Tests for `validate_origin()` with various header formats and wildcard matching
  - Tests for `extract_client_token_info()` with different token formats
  - All tests follow existing test patterns with proper mocking

### Technical

- **New Utility Modules**: Added three new utility modules for server-side security
  - `miso_client/utils/environment_token.py`: Server-side token wrapper with audit logging
  - `miso_client/utils/origin_validator.py`: CORS origin validation utility
  - `miso_client/utils/token_utils.py`: Client token introspection utilities

- **Module Exports**: All new utilities exported from main `miso_client` module
  - `get_environment_token`: Server-side token fetching with origin validation
  - `validate_origin`: CORS origin validation utility
  - `extract_client_token_info`: Client token information extraction

## [2.1.2] - 2025-12-11

### Added

- **Login Endpoint Support**: Implemented async `login()` method in `AuthService` and `MisoClient`
  - Makes GET request to `/api/v1/auth/login` with `redirect` (required) and optional `state` query parameters
  - Returns response dictionary with `success`, `data` (containing `loginUrl` and `state`), and `timestamp`
  - Supports CSRF protection via optional `state` parameter
  - Follows service method pattern: returns empty dict `{}` on errors
  - Client token is automatically handled via HTTP client interceptors

- **Logout Endpoint Support**: Enhanced `logout()` method in `AuthService` and `MisoClient`
  - Now accepts `token` parameter (required) for user token invalidation
  - Makes POST request to `/api/v1/auth/logout` with token in request body: `{"token": token}`
  - Uses `authenticated_request()` since it requires user token (Bearer authentication)
  - Returns response dictionary with `success`, `message`, and `timestamp`
  - Follows service method pattern: returns empty dict `{}` on errors

### Changed

- **Breaking Change: AuthService.login()**: Changed from synchronous URL builder to async HTTP request
  - Old: `def login(self, redirect_uri: str) -> str` (synchronous, returns URL string)
  - New: `async def login(self, redirect: str, state: Optional[str] = None) -> Dict[str, Any]` (async, returns response dict)
  - Now makes actual HTTP request to controller instead of just building URL
  - Parameter renamed from `redirect_uri` to `redirect` for consistency with API

- **Breaking Change: AuthService.logout()**: Now requires token parameter
  - Old: `async def logout(self) -> None` (no parameters, backend extracted from client token)
  - New: `async def logout(self, token: str) -> Dict[str, Any]` (requires token, returns response dict)
  - Now sends token in request body for explicit token invalidation
  - Returns response dictionary instead of None

- **Breaking Change: MisoClient.login()**: Updated to match new async signature
  - Old: `def login(self, redirect_uri: str) -> str`
  - New: `async def login(self, redirect: str, state: Optional[str] = None) -> Dict[str, Any]`

- **Breaking Change: MisoClient.logout()**: Updated to require token parameter
  - Old: `async def logout(self) -> None`
  - New: `async def logout(self, token: str) -> Dict[str, Any]`

### Testing

- Added comprehensive unit tests for login and logout methods
  - Test login with state parameter
  - Test login without state parameter (auto-generated by backend)
  - Test login error handling
  - Test logout success scenario
  - Test logout error handling
  - All tests follow existing test patterns with proper mocking

### Migration Guide

**For users upgrading from 2.0.0 or earlier:**

1. **Update login() calls**: Change from synchronous to async and update return value handling

   ```python
   # Old
   login_url = client.login("http://localhost:3000/auth/callback")
   window.location.href = login_url
   
   # New
   response = await client.login(redirect="http://localhost:3000/auth/callback", state="abc123")
   if response.get("success"):
       login_url = response["data"]["loginUrl"]
       state = response["data"]["state"]
       window.location.href = login_url
   ```

2. **Update logout() calls**: Add token parameter and handle response

   ```python
   # Old
   await client.logout()
   
   # New
   token = get_token_from_storage()  # Get user's access token
   response = await client.logout(token=token)
   if response.get("success"):
       print("Logout successful")
   ```

---

## [2.0.0] - 2025-11-24

### Changed

- **Major Version Release**: Version 2.0.0 marks a significant milestone in the MisoClient SDK
  - Improved stability and performance across all services
  - Enhanced error handling and logging capabilities
  - Better integration with Miso Controller API v1 endpoints

---

## [1.9.2] - 2025-11-24

### Changed

- **API Endpoint Versioning**: Updated all API endpoints from `/api/*` to `/api/v1/*` to match the latest Miso Controller API version
  - `/api/auth/login` → `/api/v1/auth/login`
  - `/api/auth/logout` → `/api/v1/auth/logout`
  - `/api/auth/validate` → `/api/v1/auth/validate`
  - `/api/auth/user` → `/api/v1/auth/user`
  - `/api/auth/token` → `/api/v1/auth/token`
  - `/api/auth/roles` → `/api/v1/auth/roles`
  - `/api/auth/roles/refresh` → `/api/v1/auth/roles/refresh`
  - `/api/auth/permissions` → `/api/v1/auth/permissions`
  - `/api/auth/permissions/refresh` → `/api/v1/auth/permissions/refresh`
  - `/api/logs` → `/api/v1/logs`
  - All endpoints now use the `/api/v1/` prefix for consistency with the OpenAPI specification

- **Code Refactoring**: Added `_validate_token_request()` helper method in `AuthService`, `RoleService`, and `PermissionService`
  - Reduces code duplication across services
  - Ensures consistent request body format for token validation
  - Properly sends `{"token": token}` in request body for `/api/v1/auth/validate` endpoint

- **Documentation Updates**: Enhanced `.cursorrules` documentation
  - Improved formatting and structure
  - Updated API endpoint documentation to reflect `/api/v1/*` paths
  - Better code examples and patterns

### Fixed

- **Token Validation Request Body**: Fixed `/api/v1/auth/validate` endpoint to properly send token in request body
  - Previously: Token was sent only in Authorization header
  - Now: Token is sent in both Authorization header and request body `{"token": token}` as required by the API specification

### Added

- **API Validation Tool**: Added `tests/integration/validate_api_calls.py` script and `VALIDATION_REPORT.md`
  - Validates all API calls in the codebase against OpenAPI specification
  - Reports any endpoints used in code but not found in the OpenAPI spec
  - Helps ensure API compatibility before releases
  - Can be run as part of CI/CD pipeline for continuous validation

---

## [1.9.1] - 2025-11-21

### Added

- **camelCase Utility Functions**: camelCase function names for consistency with TypeScript SDK
  - `parsePaginationParams()`: Returns dictionary with `currentPage` and `pageSize` keys
  - `createMetaObject()`: Creates `Meta` objects with camelCase fields
  - `applyPaginationToArray()`: Applies pagination to arrays
  - `createPaginatedListResponse()`: Creates paginated list responses
  - `transformError()`: Transforms error dictionaries to `ErrorResponse` objects
  - `handleApiError()`: Creates `ApiErrorException` from API error responses
  - `ApiErrorException`: New exception class for API errors (extends `MisoClientError`)

- **Audit Logging Queue**: New `AuditLogQueue` class for batch logging of audit events
  - Queues audit logs and flushes them in batches to Redis or HTTP batch endpoint
  - Configurable batch size and flush interval via `AuditConfig`
  - Automatic batching reduces HTTP overhead for high-volume logging
  - Integrated with `LoggerService` for automatic audit log queuing

- **Audit Configuration**: New `AuditConfig` model for fine-grained audit logging control
  - `enabled`: Enable/disable audit logging (default: `true`)
  - `level`: Audit detail level - `minimal`, `standard`, `detailed`, `full` (default: `detailed`)
  - `maxResponseSize`: Truncate responses larger than this size in bytes (default: `10000`)
  - `maxMaskingSize`: Skip masking for objects larger than this size in bytes (default: `50000`)
  - `batchSize`: Batch size for queued logs (default: `10`)
  - `batchInterval`: Flush interval in milliseconds (default: `100`)
  - `skipEndpoints`: Array of endpoint patterns to exclude from audit logging

- **Audit Logging Performance Optimizations**:
  - Response body truncation based on `maxResponseSize` configuration
  - Size-based masking skip for large objects (prevents performance degradation)
  - Configurable audit levels (minimal, standard, detailed, full)
  - Minimal level: Only metadata, no masking
  - Standard level: Metadata + basic context
  - Detailed level: Full context with request/response sizes
  - Full level: Complete audit trail with all available data

### Changed

- **Pagination Default**: Changed default `pageSize` from `25` to `20` to match TypeScript implementation
  - `parsePaginationParams()` now returns `{"currentPage": 1, "pageSize": 20}` by default

- **Error Handling**: Enhanced error handling with new `ApiErrorException` class
  - `handleApiError()` returns `ApiErrorException` with structured error response support
  - `ApiErrorException` extends `MisoClientError` with structured error response support

- **HTTP Client Logging**: Improved async logging task management
  - Added `_wait_for_logging_tasks()` helper method for proper async task synchronization
  - Better task tracking and error handling for background logging tasks
  - Improved reliability of audit logging in test environments

- **Audit Log Context**: Enhanced audit context preparation
  - Proper handling of `AuditConfig` objects vs dictionaries
  - Better integration with audit level configurations
  - Improved response body truncation in debug logs based on `maxResponseSize`

### Fixed

- **Audit Logging**: Fixed audit logging not being called in some scenarios
  - Fixed `should_skip_logging()` to properly handle `None` configs
  - Fixed audit config access in `log_http_request_audit()` (was accessing `.level` on dict instead of `AuditConfig` object)
  - Fixed async task completion in tests by adding proper task waiting mechanisms

- **Test Suite**: Fixed all failing tests (19 failures → 0 failures)
  - Updated pagination tests to use new default `pageSize` of 20
  - Fixed HTTP client tests to properly wait for async logging tasks
  - Updated response body truncation test to use `maxResponseSize` from audit config
  - Fixed size calculation tests to use audit level configuration instead of debug mode

### Technical Improvements

- **Type Safety**: Enhanced type hints for all camelCase functions
- **Test Coverage**: All 409 tests passing with 86% code coverage
- **Code Quality**: All linting checks passing

### Migration Guide

**For users upgrading from 1.8.1:**

1. **Use camelCase Functions**: Use camelCase function names for consistency with TypeScript SDK
   - `parsePaginationParams(params)` - Returns dict with `currentPage` and `pageSize` keys
   - `createMetaObject(...)` - Creates `Meta` objects with camelCase fields
   - `transformError(...)` - Transforms error dictionaries to `ErrorResponse` objects
   - `handleApiError(...)` - Creates `ApiErrorException` from API error responses

2. **Configure Audit Logging** (optional): You can now configure audit logging behavior

   ```python
   from miso_client.models.config import AuditConfig, MisoClientConfig
   
   config = MisoClientConfig(
       controller_url="https://controller.example.com",
       client_id="your-client-id",
       client_secret="your-secret",
       audit=AuditConfig(
           enabled=True,
           level="detailed",
           maxResponseSize=5000,
           batchSize=20,
           batchInterval=200
       )
   )
   ```

3. **Handle Exception Type**: `handleApiError()` returns `ApiErrorException`
   - `error = handleApiError(...)` → `ApiErrorException` (extends `MisoClientError`)
   - `ApiErrorException` provides structured error information with camelCase fields

### Testing

- All 409 unit tests passing
- 86% code coverage
- Comprehensive test coverage for all new camelCase functions
- Test coverage for `AuditLogQueue` and audit configuration options
- All audit logging optimizations tested

---

## [1.8.1] - 2025-11-02

### Changed

- **Breaking Change: All Outgoing Data Now Uses camelCase Naming Convention**
  - All Pydantic model fields sent to API now use camelCase (e.g., `pageSize`, `totalItems`, `currentPage`, `userId`, `statusCode`, `correlationId`)
  - All JSON request bodies now use camelCase field names
  - All query parameters now use camelCase (e.g., `pageSize` instead of `page_size`)
  - All response data from API is expected in camelCase format
  - Python code conventions remain snake_case (functions, methods, variables, parameters)

- **Model Field Updates**:
  - `FilterQuery`: Changed `page_size` → `pageSize`
  - `Meta`: Changed `total_items` → `totalItems`, `current_page` → `currentPage`, `page_size` → `pageSize`
  - `ErrorResponse`: Changed `request_key` → `correlationId`, removed `status_code` alias (now only `statusCode`)
  - `LogEntry`: Removed all aliases (already camelCase): `applicationId`, `userId`, `correlationId`, `requestId`, `sessionId`, `stackTrace`, `ipAddress`, `userAgent`
  - `UserInfo`: Removed `first_name`/`last_name` aliases (now only `firstName`/`lastName`)
  - `RoleResult`: Removed `user_id` alias (now only `userId`)
  - `PermissionResult`: Removed `user_id` alias (now only `userId`)
  - `ClientTokenResponse`: Removed `expires_in`/`expires_at` aliases (now only `expiresIn`/`expiresAt`)
  - `PerformanceMetrics`: Removed `start_time`/`end_time`/`memory_usage` aliases (now only `startTime`/`endTime`/`memoryUsage`)
  - `ClientLoggingOptions`: Removed all aliases (already camelCase): `applicationId`, `userId`, `correlationId`, `requestId`, `sessionId`, `maskSensitiveData`, `performanceMetrics`

- **Query Parameter Updates**:
  - `build_query_string()`: Generates `pageSize` in query strings (camelCase)
  - `_add_pagination_params()`: Adds `pageSize` to request parameters (camelCase)
  - `parsePaginationParams()`: Parses `page` and `pageSize` query parameters (camelCase)

- **Utility Function Updates**:
  - `createMetaObject()`: Creates `Meta` objects with camelCase field names (`totalItems`, `currentPage`, `pageSize`)
  - `error_utils.py`: Handles only camelCase error responses
  - `transformError()`: Transforms error dictionaries to `ErrorResponse` objects (camelCase)
  - `handleApiError()`: Creates `ApiErrorException` from API error responses (camelCase)

- **Backward Compatibility Removed**:
  - Removed all `populate_by_name` configs from Pydantic models
  - Removed all snake_case property accessors (e.g., `status_code`, `totalItems`, `currentPage`, `pageSize` properties)
  - Removed all Field aliases that supported snake_case input

### Documentation

- Updated `.cursorrules` with "API Data Conventions (camelCase)" section documenting camelCase requirements
- Updated all test files to use camelCase field names when creating models and accessing fields
- Updated all docstrings and examples to reflect camelCase naming convention

### Migration Guide

**For users upgrading from previous versions:**

1. **Update model field references**: Change all snake_case field access to camelCase
   - Old: `response.meta.total_items` → New: `response.meta.totalItems`
   - Old: `response.meta.current_page` → New: `response.meta.currentPage`
   - Old: `response.meta.page_size` → New: `response.meta.pageSize`
   - Old: `error_response.status_code` → New: `error_response.statusCode`
   - Old: `error_response.request_key` → New: `error_response.correlationId`

2. **Update model instantiation**: Use camelCase field names when creating models
   - Old: `FilterQuery(page_size=25)` → New: `FilterQuery(pageSize=25)`
   - Old: `Meta(total_items=120, current_page=1, page_size=25)` → New: `Meta(totalItems=120, currentPage=1, pageSize=25)`

3. **Update query parameters**: Query strings now use camelCase
   - Old: `?page=1&page_size=25` → New: `?page=1&pageSize=25`

4. **Update JSON request bodies**: All outgoing JSON must use camelCase
   - Old: `{"user_id": "123", "application_id": "app-1"}` → New: `{"userId": "123", "applicationId": "app-1"}`

5. **API responses**: All API responses are expected in camelCase format

### Testing

- Updated all 409 unit tests to use camelCase field names
- All tests passing with 91% code coverage
- Comprehensive test coverage for all model field changes

---

## [0.5.0] - 2025-11-02

### Added

- **Pagination Utilities**: Complete pagination support for list responses
  - `Meta` and `PaginatedListResponse` Pydantic models for standardized paginated responses
  - `parsePaginationParams()` function to parse `page` and `pageSize` query parameters
  - `createMetaObject()` function to construct pagination metadata objects
  - `applyPaginationToArray()` function for local pagination in tests/mocks
  - `createPaginatedListResponse()` function to wrap data with pagination metadata
  - camelCase field names (`totalItems`, `currentPage`, `pageSize`) for consistency with TypeScript SDK
  - Full type safety with Pydantic models and generic type support

- **Filtering Utilities**: Comprehensive filtering support for API queries
  - `FilterOption`, `FilterQuery`, and `FilterBuilder` classes for building filter queries
  - `FilterOperator` type supporting: `eq`, `neq`, `in`, `nin`, `gt`, `lt`, `gte`, `lte`, `contains`, `like`
  - `parse_filter_params()` function to parse `filter=field:op:value` query parameters
  - `build_query_string()` function to convert `FilterQuery` objects to URL query strings
  - `apply_filters()` function for local filtering in tests/mocks
  - `FilterBuilder` class with fluent API for method chaining (e.g., `FilterBuilder().add('status', 'eq', 'active').add('region', 'in', ['eu', 'us'])`)
  - URL encoding support for field names and values (comma separators preserved for array values)
  - Integration with `/metadata/filter` endpoint through `FilterBuilder` compatibility with `AccessFieldFilter`

- **Sorting Utilities**: Sort parameter parsing and building
  - `SortOption` Pydantic model with `field` and `order` (asc/desc) properties
  - `parse_sort_params()` function to parse `sort=-field` query parameters
  - `build_sort_string()` function to convert `SortOption` lists to query string format
  - Support for multiple sort fields with ascending/descending order
  - URL encoding for field names with special characters

- **Error Handling Utilities**: Enhanced error response transformation and handling
  - `transformError()` function for converting error dictionaries to `ErrorResponse` objects
  - `handleApiError()` function for creating `ApiErrorException` from API error responses
  - camelCase field names for consistency with TypeScript SDK
  - Automatic parameter overriding (instance and status_code parameters override response data)
  - Graceful handling of missing optional fields (title, instance, correlationId)

- **HTTP Client Enhancements**: New helper methods for filtered and paginated requests
  - `get_with_filters()` method for making GET requests with `FilterBuilder` support
  - `get_paginated()` method for making GET requests with pagination parameters
  - Automatic query string building from filter/sort/pagination options
  - Flexible response parsing (returns `PaginatedListResponse` when format matches, raw response otherwise)

- **ErrorResponse Model Enhancements**:
  - Added `request_key` field for error tracking (supports both `request_key` and `correlationId` aliases)
  - Made `title` field optional (defaults to `None`) for graceful handling of missing titles
  - Added `status_code` property getter for snake_case access (complements `statusCode` camelCase field)
  - Full support for both snake_case and camelCase attribute access

- **Model Exports**: All models and utilities exported from main module
  - Pagination: `Meta`, `PaginatedListResponse`, `parsePaginationParams`, `createMetaObject`, `applyPaginationToArray`, `createPaginatedListResponse`
  - Filtering: `FilterOperator`, `FilterOption`, `FilterQuery`, `FilterBuilder`, `parse_filter_params`, `build_query_string`, `apply_filters`
  - Sorting: `SortOption`, `parse_sort_params`, `build_sort_string`
  - Error: `transformError`, `handleApiError`, `ApiErrorException`
  - Pagination and error utilities use camelCase naming convention matching TypeScript SDK

### Changed

- **ErrorResponse Model**: Made `title` field optional to support APIs that don't provide titles
  - Old: `title: str = Field(..., description="Human-readable error title")`
  - New: `title: Optional[str] = Field(default=None, description="Human-readable error title")`
  - Backward compatible - existing code with required titles still works

- **handleApiError Function**: Enhanced parameter override behavior
  - `instance` parameter overrides instance in response_data
  - `status_code` parameter always overrides statusCode in response_data
  - Better error message generation when title is missing

### Technical Improvements

- **Type Safety**: Full type hints throughout all new utilities and models
- **Pydantic Models**: All new data structures use Pydantic for validation and serialization
- **Property Getters**: Added property getters to support both snake_case and camelCase attribute access in models
- **URL Encoding**: Smart encoding that preserves comma delimiters in array filter values
- **Comprehensive Tests**: 123 unit tests covering all utilities with 100% coverage for models and utilities
- **Documentation**: Complete README documentation with usage examples for all utilities
- **Snake_case Convention**: All utilities follow Python snake_case naming to match Miso/Dataplane API conventions

### Documentation

- Added comprehensive README section for pagination, filtering, and sorting utilities
- Usage examples for all utilities including combined usage patterns
- Integration examples with `/metadata/filter` endpoint
- Type hints and docstrings for all public APIs

---

## [0.4.0] - 2025-11-02

### Added

- **ISO 27001 Compliant HTTP Client with Automatic Audit and Debug Logging**: New public `HttpClient` class that wraps `InternalHttpClient` with automatic ISO 27001 compliant audit and debug logging
  - Automatic audit logging for all HTTP requests (`http.request.{METHOD}` format)
  - Debug logging when `log_level === 'debug'` with detailed request/response information
  - Automatic data masking using `DataMasker` before logging (ISO 27001 compliant)
  - All request headers are masked (Authorization, x-client-token, Cookie, etc.)
  - All request bodies are recursively masked for sensitive fields (password, token, secret, SSN, etc.)
  - All response bodies are masked (limited to first 1000 characters)
  - Query parameters are automatically masked
  - Error messages are masked if they contain sensitive data
  - Sensitive endpoints (`/api/logs`, `/api/auth/token`) are excluded from audit logging to prevent infinite loops
  - JWT user ID extraction from Authorization headers for audit context
  - Request duration tracking for performance monitoring
  - Request/response size tracking for observability

- **JSON Configuration Support for DataMasker**: Enhanced `DataMasker` with JSON configuration file support for sensitive fields
  - New `sensitive_fields_config.json` file with default ISO 27001 compliant sensitive fields
  - Categories: authentication, pii, security
  - Support for custom configuration path via `MISO_SENSITIVE_FIELDS_CONFIG` environment variable
  - `DataMasker.set_config_path()` method for programmatic configuration
  - Automatic merging of JSON fields with hardcoded defaults (fallback if JSON cannot be loaded)
  - Backward compatible - existing hardcoded fields still work as fallback

- **New InternalHttpClient Class**: Separated core HTTP functionality into `InternalHttpClient` class
  - Pure HTTP functionality with automatic client token management (no logging)
  - Used internally by public `HttpClient` for actual HTTP requests
  - Used by `LoggerService` for sending logs to prevent circular dependencies
  - Not exported in public API (internal use only)

- **New sensitive_fields_loader Module**: Utility module for loading and merging sensitive fields configuration
  - `load_sensitive_fields_config()` function for loading JSON configuration
  - `get_sensitive_fields_array()` function for flattened sensitive fields list
  - `get_field_patterns()` function for pattern matching rules
  - Support for custom configuration paths via environment variables

### Changed

- **Breaking Change: HttpClient Constructor**: Public `HttpClient` constructor now requires `logger` parameter
  - Old: `HttpClient(config)`
  - New: `HttpClient(config, logger)`
  - This is handled automatically when using `MisoClient` - no changes needed for typical usage
  - Only affects code that directly instantiates `HttpClient`

- **Breaking Change: LoggerService Constructor**: `LoggerService` constructor now uses `InternalHttpClient` instead of `HttpClient`
  - Old: `LoggerService(http_client: HttpClient, redis: RedisService)`
  - New: `LoggerService(internal_http_client: InternalHttpClient, redis: RedisService)`
  - This is handled automatically when using `MisoClient` - no changes needed for typical usage
  - Prevents circular dependency (LoggerService uses InternalHttpClient for log sending)

- **MisoClient Architecture**: Updated `MisoClient` constructor to use new HttpClient architecture
  - Creates `InternalHttpClient` first (pure HTTP functionality)
  - Creates `LoggerService` with `InternalHttpClient` (prevents circular dependency)
  - Creates public `HttpClient` wrapping `InternalHttpClient` with logger (adds audit/debug logging)
  - All services now use public `HttpClient` with automatic audit logging

- **DataMasker Enhancement**: Updated `DataMasker` to load sensitive fields from JSON configuration
  - Maintains backward compatibility with hardcoded fields as fallback
  - Automatic loading on first use with caching
  - Support for custom configuration paths

### ISO 27001 Compliance Features

- **Automatic Data Masking**: All sensitive data is automatically masked before logging
  - Request headers: Authorization, x-client-token, Cookie, Set-Cookie, and any header containing sensitive keywords
  - Request bodies: Recursively masks password, token, secret, SSN, creditcard, CVV, PIN, OTP, API keys, etc.
  - Response bodies: Especially important for error responses that might contain sensitive data
  - Query parameters: Automatically extracted and masked
  - Error messages: Masked if containing sensitive data

- **Audit Log Structure**: Standardized audit log format for all HTTP requests
  - Action: `http.request.{METHOD}` (e.g., `http.request.GET`, `http.request.POST`)
  - Resource: Request URL path
  - Context: method, url, statusCode, duration, userId, requestSize, responseSize, error (all sensitive data masked)

- **Debug Log Structure**: Detailed debug logging when `log_level === 'debug'`
  - All audit context fields plus: requestHeaders, responseHeaders, requestBody, responseBody (all masked)
  - Additional context: baseURL, timeout, queryParams (all sensitive data masked)

### Technical Improvements

- Improved error handling: Logging errors never break HTTP requests (all errors caught and swallowed)
- Performance: Async logging that doesn't block request/response flow
- Safety: Sensitive endpoints excluded from audit logging to prevent infinite loops
- Flexibility: Configurable sensitive fields via JSON configuration file

---

## [0.3.0] - 2025-11-01

### Added

- **Structured Error Response Interface**: Added generic `ErrorResponse` model following RFC 7807-style format for consistent error handling across applications
  - `ErrorResponse` Pydantic model with fields: `errors`, `type`, `title`, `statusCode`, `instance`
  - Automatic parsing of structured error responses from HTTP responses in `HttpClient`
  - Support for both camelCase (`statusCode`) and snake_case (`status_code`) field names
  - `MisoClientError` now includes optional `error_response` field with structured error information
  - Enhanced error messages automatically generated from structured error responses
  - Instance URI automatically extracted from request URL when not provided in response
  - Backward compatible - falls back to traditional `error_body` dict when structured format is not available
  - Export `ErrorResponse` from main module for reuse in other applications
  - Comprehensive test coverage for error response parsing and fallback behavior
  - Full type safety with Pydantic models

### Changed

- **Error Handling**: `MisoClientError` now prioritizes structured error information when available
  - Error messages are automatically enhanced from structured error responses
  - Status codes are extracted from structured responses when provided

---

## [0.2.0] - 2025-10-31

### Added

- **API_KEY Support for Testing**: Added optional `API_KEY` environment variable that allows bypassing OAuth2 authentication for testing purposes
  - When `API_KEY` is set in environment, bearer tokens matching the key will automatically validate without OAuth2
  - `validate_token()` returns `True` for matching API_KEY tokens without calling controller
  - `get_user()` and `get_user_info()` return `None` when using API_KEY (by design for testing scenarios)
  - Configuration supports `api_key` field in `MisoClientConfig`
  - Comprehensive test coverage for API_KEY authentication flows
  - Useful for testing without requiring Keycloak setup

- **PowerShell Makefile**: Added `Makefile.ps1` with all development commands for Windows PowerShell users
  - Replaces `dev.bat` and `dev.ps1` scripts with unified PowerShell Makefile
  - Supports all standard development commands (install, test, lint, format, build, etc.)
  - Consistent interface with Unix Makefile

- **Validate Command**: Added new `validate` target to both Makefile and Makefile.ps1
  - Runs lint + format + test in sequence
  - Useful for pre-commit validation and CI/CD pipelines
  - Usage: `make validate` or `.\Makefile.ps1 validate`

### Changed

- **Development Scripts**: Replaced `dev.bat` and `dev.ps1` with `Makefile.ps1` for better consistency
  - All development commands now available through Makefile interface
  - Improved cross-platform compatibility

### Testing

- Added comprehensive test suite for API_KEY functionality
  - Tests for `validate_token()` with API_KEY matching and non-matching scenarios
  - Tests for `get_user()` and `get_user_info()` with API_KEY
  - Tests for config loader API_KEY loading
  - All tests verify OAuth2 fallback behavior when API_KEY doesn't match

---

## [0.1.0] - 2025-10-30

### Added

- **Automatic Client Token Management in HttpClient**: Client tokens are now automatically fetched, cached, and refreshed by the HttpClient
  - Proactive token refresh when < 60 seconds until expiry (30 second buffer before actual expiration)
  - Automatic `x-client-token` header injection for all requests
  - Concurrent token fetch prevention using async locks
  - Automatic token clearing on 401 responses to force refresh
  
- **New Data Models**:
  - `ClientTokenResponse`: Response model for client token requests with expiration tracking
  - `PerformanceMetrics`: Performance metrics model for logging (start time, end time, duration, memory usage)
  - `ClientLoggingOptions`: Advanced logging options with JWT context extraction, correlation IDs, data masking, and performance metrics support
  
- **RedisConfig Enhancement**:
  - Added `db` field to specify Redis database number (default: 0)
  - Supports multi-database Redis deployments

### Changed

- **Module Structure**: Moved type definitions from `miso_client.types.config` to `miso_client.models.config` for better organization
  - All imports now use `from miso_client.models.config import ...`
  - Previous compatibility layer (`types_backup_test`) removed as no longer needed

- **HttpClient Improvements**:
  - Client token management is now fully automatic - no manual token handling required
  - Better error handling with automatic token refresh on authentication failures
  - All HTTP methods (GET, POST, PUT, DELETE) now automatically include client token header

### Technical Improvements

- Improved token expiration handling with proactive refresh mechanism
- Reduced API calls through intelligent token caching
- Better concurrency handling with async locks for token operations
- Enhanced error recovery with automatic token clearing on 401 responses

---

## [0.1.0] - 2025-10-01

### Added

- **Initial Release**: Complete MisoClient SDK implementation
- **Authentication**: JWT token validation and user management
- **Authorization**: Role-based access control (RBAC) with Redis caching
- **Permissions**: Fine-grained permission management with caching
- **Logging**: Structured logging with Redis queuing and HTTP fallback
- **Redis Integration**: Optional Redis caching for improved performance
- **Async Support**: Full async/await support for modern Python applications
- **Type Safety**: Complete type hints and Pydantic models
- **Graceful Degradation**: Works with or without Redis
- **Comprehensive Documentation**: Complete API reference and integration guides
- **Unit Tests**: Full test coverage mirroring TypeScript implementation
- **Package Distribution**: Ready for PyPI distribution with setup.py and pyproject.toml

### Features

#### Core Client

- `MisoClient` main class with initialization and lifecycle management
- Configuration management with `MisoClientConfig` and `RedisConfig`
- Connection state tracking and graceful fallback

#### Authentication Service

- Token validation with controller integration
- User information retrieval
- Login URL generation for web applications
- Logout functionality

#### Role Service

- Role retrieval with Redis caching (15-minute TTL)
- Role checking methods: `has_role`, `has_any_role`, `has_all_roles`
- Role refresh functionality to bypass cache
- Cache key management with user/environment/application scoping

#### Permission Service

- Permission retrieval with Redis caching (15-minute TTL)
- Permission checking methods: `has_permission`, `has_any_permission`, `has_all_permissions`
- Permission refresh functionality to bypass cache
- Cache clearing functionality
- Cache key management with user/environment/application scoping

#### Logger Service

- Structured logging with multiple levels: `info`, `error`, `audit`, `debug`
- Redis queue integration for log batching
- HTTP fallback when Redis is unavailable
- Context-aware logging with metadata support

#### HTTP Client

- Async HTTP client wrapper using httpx
- Automatic header injection (X-Environment, X-Application)
- Authenticated request support with Bearer token
- Error handling and status code management

#### Redis Service

- Async Redis integration using redis.asyncio
- Graceful degradation when Redis is unavailable
- Connection state tracking
- Key prefix support for multi-tenant environments

### Data Models

- `UserInfo`: User information from token validation
- `AuthResult`: Authentication result structure
- `LogEntry`: Structured log entry format
- `RoleResult`: Role query result
- `PermissionResult`: Permission query result
- `MisoClientConfig`: Main client configuration
- `RedisConfig`: Redis connection configuration

### Integration Examples

- **FastAPI**: Complete integration with dependencies and middleware
- **Django**: Middleware, decorators, and view integration
- **Flask**: Decorator-based authentication and authorization
- **Custom Applications**: Dependency injection and service patterns

### Documentation

- **README.md**: Comprehensive SDK documentation with quick start guide
- **API Reference**: Detailed method signatures and parameter descriptions
- **Integration Guide**: Framework-specific integration examples
- **Changelog**: Version history and feature tracking

### Testing

- **Unit Tests**: Comprehensive test coverage for all services
- **Mock Support**: Mock implementations for testing
- **Error Handling**: Test coverage for error scenarios and edge cases
- **Performance Tests**: Concurrent operation testing

### Package Management

- **setup.py**: Traditional Python package configuration
- **pyproject.toml**: Modern Python packaging (PEP 518)
- **Dependencies**: httpx, redis[hiredis], pydantic, pydantic-settings, structlog
- **Development Dependencies**: pytest, black, isort, mypy
- **Python Support**: Python 3.8+ compatibility

### Security

- **Token Handling**: Secure JWT token processing
- **Redis Security**: Password and key prefix support
- **Logging Security**: Careful handling of sensitive information
- **Error Handling**: Graceful error handling without information leakage

### Performance

- **Caching**: Redis-based caching for roles and permissions
- **Connection Pooling**: Efficient HTTP and Redis connection management
- **Async Operations**: Non-blocking async/await throughout
- **Batch Operations**: Support for concurrent operations

### Compatibility

- **Python Versions**: 3.8, 3.9, 3.10, 3.11, 3.12
- **Framework Support**: FastAPI, Django, Flask, and custom applications
- **Redis Versions**: Compatible with Redis 5.0+
- **HTTP Clients**: Uses httpx for modern async HTTP support

### Migration

- **From Keycloak**: Seamless migration from direct Keycloak integration
- **Backward Compatibility**: Maintains existing API patterns
- **Configuration**: Simple configuration migration
- **Testing**: Comprehensive migration testing support

---

## Future Releases

### Planned Features

- **WebSocket Support**: Real-time authentication updates
- **Metrics Integration**: Prometheus and OpenTelemetry support
- **Advanced Caching**: Cache invalidation strategies
- **Multi-Controller Support**: Load balancing across multiple controllers
- **SDK Extensions**: Framework-specific SDK extensions

### Roadmap

- **v1.1.0**: WebSocket support and real-time updates
- **v1.2.0**: Advanced metrics and monitoring
- **v2.0.0**: Multi-controller support and load balancing
- **v2.1.0**: Framework-specific SDK extensions

---

For more information about the MisoClient SDK, visit:

- [Documentation](https://docs.aifabrix.ai/miso-client-python)
- [GitHub Repository](https://github.com/aifabrix/miso-client-python)
- [Issue Tracker](https://github.com/aifabrix/miso-client-python/issues)
