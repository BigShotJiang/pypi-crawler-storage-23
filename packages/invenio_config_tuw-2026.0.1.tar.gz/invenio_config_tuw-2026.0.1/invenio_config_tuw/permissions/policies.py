# -*- coding: utf-8 -*-
#
# Copyright (C) 2020-2026 TU Wien.
#
# Invenio-Config-TUW is free software; you can redistribute it and/or modify
# it under the terms of the MIT License; see LICENSE file for more details.

"""Permission policies to be used at TU Wien."""

from invenio_communities.generators import CommunityCurators
from invenio_communities.permissions import CommunityPermissionPolicy
from invenio_curations.services.generators import (
    IfCurationRequestAccepted,
    IfRequestTypes,
)
from invenio_damap.services.permissions import InvenioDAMAPPermissionPolicy
from invenio_rdm_records.requests.community_submission import CommunitySubmission
from invenio_rdm_records.services.generators import (
    AccessGrant,
    RecordCommunitiesAction,
    SubmissionReviewer,
)
from invenio_records_permissions.generators import (
    SystemProcess,
)
from invenio_requests.services.generators import Creator, Receiver, Status

from .future import RDMRecordPermissionPolicy, RDMRequestsPermissionPolicy, SameAs
from .generators import CurationModeratorsIfRequestExists as CurationReviewers
from .generators import (
    TISSUsers,
    TrustedRecordOwners,
    TrustedUsers,
)


class TUWRecordPermissionPolicy(RDMRecordPermissionPolicy):
    """Customized record permission policy of TU Wien.

    We tighten the permissions so that having an account in the system does not
    immediately give users permission to create records; they need the "trusted-user"
    role to do that.
    Also, we give our curation reviewers permissions on records under review.

    Note that replacing ``RecordOwners`` with ``TrustedRecordOwners`` in ``can_manage``
    also means that users without the  ``trusted-users`` role will not have access
    to management features (e.g. access sharing) of their own records.
    While this may be unexpected from a UX perspective, it is beneficial from the
    security perspective.

    Based on Invenio-RDM-Records v19.6.3
    """

    # record management: require trusted user role
    can_manage = [
        TrustedRecordOwners(),
        RecordCommunitiesAction("curate"),
        SystemProcess(),
        AccessGrant("manage"),
    ]

    # base for many read/write operations on drafts: add curation reviewers
    # (note: publishing is handled via a service component, not via permissions)
    can_review = SameAs("can_curate") + [SubmissionReviewer(), CurationReviewers()]

    # create records: require trusted user
    can_create = [TrustedUsers(), SystemProcess()]

    # remove community from a record: require *trusted* record owner
    # (the trailing underscore in the name is intentional, see base policy)
    can_remove_community_ = [
        TrustedRecordOwners(),
        CommunityCurators(),
        SystemProcess(),
    ]


class TUWRequestsPermissionPolicy(RDMRequestsPermissionPolicy):
    """Requests permission policy of TU Wien.

    Based on Invenio-RDM-Records v19.6.3
    """

    can_read = RDMRequestsPermissionPolicy.can_read + [
        Status(["review", "critiqued", "resubmitted"], [Creator(), Receiver()]),
    ]

    # "rdm-curation" requests have precedence over "community-submission" requests
    can_action_accept = [
        IfRequestTypes(
            request_types=[CommunitySubmission],
            then_=[
                IfCurationRequestAccepted(
                    then_=RDMRequestsPermissionPolicy.can_action_accept, else_=[]
                )
            ],
            else_=RDMRequestsPermissionPolicy.can_action_accept,
        ),
    ]

    # custom actions for curation request actions
    can_action_review = SameAs("can_action_accept")
    can_action_critique = SameAs("can_action_accept")
    can_action_resubmit = SameAs("can_action_submit")


class TUWCommunityPermissionPolicy(CommunityPermissionPolicy):
    """Communities permission policy of TU Wien.

    We restrict the creation of communities to admins only.

    Based on Invenio-Communities v14.0.0
    """

    can_create = [SystemProcess()]


class TUWInvenioDAMAPPermissionPolicy(InvenioDAMAPPermissionPolicy):
    """Invenio-DAMAP permission policy restricted to TU Wien users.

    In our current setup, we can only identify users across sytems using the TISS ID.
    Users without this shouldn't have access to the functionality.
    """

    can_read = [SystemProcess(), TISSUsers()]
    can_create = [SystemProcess(), TISSUsers()]
    can_get = [SystemProcess(), TISSUsers()]
