# -*- coding: utf-8 -*-
#
# Copyright (C) 2026 TU Wien.
#
# Invenio-Config-TUW is free software; you can redistribute it and/or modify
# it under the terms of the MIT License; see LICENSE file for more details.

"""Tests for permission generators, policies, and other related things."""

from io import BytesIO

import pytest
from flask_principal import AnonymousIdentity, Identity, Need, RoleNeed, UserNeed
from invenio_access.permissions import any_user, system_identity
from invenio_curations.proxies import current_curations_service as curations_service
from invenio_curations.services.errors import CurationRequestNotAcceptedError
from invenio_rdm_records.proxies import current_rdm_records_service as records_service
from invenio_records_resources.services.errors import PermissionDenied
from invenio_requests.proxies import current_requests_service as requests_service

trusted_user_need = RoleNeed("trusted-user")


def identity_for(user):
    """Simple identity fixture."""
    i = Identity(user.id)
    i.provides.add(UserNeed(user.id))
    i.provides.add(Need(method="system_role", value="any_user"))
    i.provides.add(Need(method="system_role", value="authenticated_user"))
    return i


@pytest.fixture
def record_data(example_record_data, resource_types, files_locs):
    """Example record data with relevant other fixtures."""
    return example_record_data


@pytest.fixture
def temp_trust_user(app, users, roles):
    """Temporarily make sure that the first user is trusted.

    NOTE: It could be possible to rework the TrustedRecordOwners generator
    in a way that this fixture isn't necessary, and we can go purely by
    faked identities in the tests.
    """
    u, *_ = users
    r, *_ = [r for r in roles if r.id == "trusted-user"]
    datastore = app.extensions["security"].datastore
    was_trusted = not datastore.add_role_to_user(u, r)
    yield u

    if not was_trusted:
        datastore.remove_role_from_user(u, r)


def test_record_creation(users, record_data):
    """Test creation of records for trusted and untrusted users."""
    user, *_ = users
    identity = identity_for(user)

    # not being a trusted user should prevent record creation
    assert trusted_user_need not in identity.provides
    with pytest.raises(PermissionDenied):
        records_service.create(identity, record_data)

    # making a user trusted should fix the creation
    identity.provides.add(trusted_user_need)
    draft = records_service.create(identity, record_data)
    assert draft is not None
    assert draft.id is not None


def test_record_publication(users, roles, record_data, temp_trust_user):
    """Test record publication with and without curation reviews."""
    user, *_ = users
    identity = identity_for(user)
    identity.provides.add(trusted_user_need)
    draft = records_service.create(identity, record_data)

    # a record cannot be published without curation request
    with pytest.raises(CurationRequestNotAcceptedError):
        records_service.publish(identity, draft.id)

    # simply having a curation request is not enough; it needs to be accepted
    request = curations_service.create(identity, {"topic": {"record": draft.id}})
    with pytest.raises(CurationRequestNotAcceptedError):
        records_service.publish(identity, draft.id)

    # having a started review is also not enough
    requests_service.execute_action(system_identity, request.id, "review")
    with pytest.raises(CurationRequestNotAcceptedError):
        records_service.publish(identity, draft.id)

    # having changes requested of course doesn't do the trick either x_x
    requests_service.execute_action(system_identity, request.id, "critique")
    with pytest.raises(CurationRequestNotAcceptedError):
        records_service.publish(identity, draft.id)

    # resubmitting doesn't do it either...
    requests_service.execute_action(system_identity, request.id, "resubmit")
    with pytest.raises(CurationRequestNotAcceptedError):
        records_service.publish(identity, draft.id)

    # ... it has to be accepted
    requests_service.execute_action(system_identity, request.id, "review")
    requests_service.execute_action(system_identity, request.id, "accept")
    record = records_service.publish(identity, draft.id)
    assert record is not None
    assert record.id == draft.id


def test_record_publication_with_disabled_curations(
    users, roles, record_data, temp_trust_user, disabled_curations
):
    """Test record publication with disabled curations."""
    user, *_ = users
    identity = identity_for(user)
    identity.provides.add(trusted_user_need)
    draft = records_service.create(identity, record_data)
    record = records_service.publish(identity, draft.id)
    assert record is not None
    assert record.id == draft.id


def test_access_to_records(users, temp_trust_user, record_data, disabled_curations):
    """Test access to restricted records."""
    record_data["access"]["record"] = "restricted"
    record_data["access"]["files"] = "restricted"
    record_data["files"]["enabled"] = True
    u1, u2 = users
    identity = identity_for(u1)
    identity.provides.add(trusted_user_need)

    # create a draft with files, and publish it
    draft = records_service.create(identity, record_data)
    records_service.draft_files.init_files(
        system_identity, draft.id, [{"key": "test.txt"}]
    )
    records_service.draft_files.set_file_content(
        system_identity,
        draft.id,
        "test.txt",
        BytesIO(b"Hello, this is a test!"),
    )
    records_service.draft_files.commit_file(system_identity, draft.id, "test.txt")
    record = records_service.publish(identity, draft.id)

    # the record owner can read everything
    draft = records_service.read(identity, record.id)
    assert draft is not None
    assert draft.id is not None
    result = records_service.files.list_files(identity, record.id)
    assert result is not None
    assert len(result.to_dict()["entries"]) == 1
    assert result.to_dict()["entries"][0]["key"] == "test.txt"
    result = records_service.files.get_file_content(identity, record.id, "test.txt")
    assert result.file_id == "test.txt"

    # the record owner can read everything
    draft = records_service.read(identity, record.id)
    assert draft is not None
    assert draft.id is not None
    result = records_service.files.list_files(identity, record.id)
    assert result is not None
    assert len(result.to_dict()["entries"]) == 1
    assert result.to_dict()["entries"][0]["key"] == "test.txt"
    result = records_service.files.get_file_content(identity, record.id, "test.txt")
    assert result.file_id == "test.txt"

    # anonymous users cannot read anything
    anonymous = AnonymousIdentity()
    anonymous.provides.add(any_user)
    with pytest.raises(PermissionDenied):
        records_service.read(anonymous, record.id)
    with pytest.raises(PermissionDenied):
        records_service.files.list_files(anonymous, record.id)
    with pytest.raises(PermissionDenied):
        records_service.files.get_file_content(anonymous, record.id, "test.txt")

    # random users also cannot read anything
    other_identity = identity_for(u2)
    with pytest.raises(PermissionDenied):
        records_service.read(other_identity, record.id)
    with pytest.raises(PermissionDenied):
        records_service.files.list_files(other_identity, record.id)
    with pytest.raises(PermissionDenied):
        records_service.files.get_file_content(other_identity, record.id, "test.txt")

    # after sharing access, the other user can access everything
    # (system identity for sharing access to avoid issues with user visibility settings)
    records_service.access.bulk_create_grants(
        system_identity,
        record.id,
        {
            "grants": [
                {"permission": "view", "subject": {"type": "user", "id": str(u2.id)}}
            ]
        },
    )
    draft = records_service.read(other_identity, record.id)
    assert draft is not None
    assert draft.id is not None
    result = records_service.files.list_files(other_identity, record.id)
    assert result is not None
    assert len(result.to_dict()["entries"]) == 1
    assert result.to_dict()["entries"][0]["key"] == "test.txt"
    result = records_service.files.get_file_content(
        other_identity, record.id, "test.txt"
    )
    assert result.file_id == "test.txt"
