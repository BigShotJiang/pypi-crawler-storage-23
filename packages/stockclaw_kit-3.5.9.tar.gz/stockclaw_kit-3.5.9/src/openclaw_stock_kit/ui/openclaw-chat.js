// StockClaw Kit — OpenClaw AI Chat Panel (iframe embed)

(async function ocInit() {
    const panel = document.getElementById('panel-openclaw-chat');
    if (!panel) return;

    // 기존 패널 내용을 iframe으로 교체
    const container = panel.querySelector('.panel-body') || panel;

    // OpenClaw 엔드포인트 자동 감지
    let ocUrl;
    if (location.hostname === 'localhost' || location.hostname === '127.0.0.1') {
        ocUrl = window.location.origin;
    } else {
        ocUrl = location.protocol + '//' + location.host + '/openclaw/';
    }

    // VPS 배포: 게이트웨이 토큰 자동 로드
    if (location.hostname !== 'localhost' && location.hostname !== '127.0.0.1') {
        try {
            const cfgResp = await fetch('/owner-config.json');
            if (cfgResp.ok) {
                const cfg = await cfgResp.json();
                if (cfg.gatewayToken) {
                    ocUrl += '?token=' + encodeURIComponent(cfg.gatewayToken);
                }
            }
        } catch (e) { /* owner-config.json 없으면 무시 */ }
    }

    // 기존 내용 모두 제거
    // panel-header는 유지하고 나머지만 교체
    const header = container.querySelector('.panel-header');
    const existingContent = container.querySelectorAll(':scope > :not(.panel-header)');
    existingContent.forEach(el => el.remove());

    // iframe 컨테이너 생성
    const iframeWrapper = document.createElement('div');
    iframeWrapper.style.cssText = 'flex: 1; display: flex; flex-direction: column; height: 100%; overflow: hidden;';

    // 상태 바
    const statusBar = document.createElement('div');
    statusBar.style.cssText = 'padding: 8px 16px; background: var(--surface2); border-bottom: 1px solid var(--border); display: flex; align-items: center; gap: 8px; font-size: 12px;';
    statusBar.innerHTML = '<span class="status-dot connected" style="width:8px;height:8px;border-radius:50%;background:var(--success);display:inline-block;"></span><span style="color:var(--text-muted);">OpenClaw AI</span><a href="' + ocUrl + '" target="_blank" style="margin-left:auto;color:var(--accent);text-decoration:none;font-size:11px;"><i class="fas fa-external-link-alt"></i> 새 창</a>';

    // iframe
    const iframe = document.createElement('iframe');
    iframe.src = ocUrl;
    iframe.style.cssText = 'flex: 1; width: 100%; border: none; background: var(--bg-dark);';
    iframe.setAttribute('allow', 'clipboard-write');
    iframe.id = 'ocIframe';

    // 로딩 상태
    iframe.onload = () => {
        statusBar.querySelector('.status-dot').style.background = 'var(--success)';
        statusBar.querySelector('span:nth-child(2)').textContent = 'OpenClaw AI — 연결됨';
    };
    iframe.onerror = () => {
        statusBar.querySelector('.status-dot').style.background = 'var(--danger)';
        statusBar.querySelector('span:nth-child(2)').textContent = 'OpenClaw AI — 연결 실패';
    };

    iframeWrapper.appendChild(statusBar);
    iframeWrapper.appendChild(iframe);
    container.appendChild(iframeWrapper);
})();
