#!/usr/bin/env python3
"""StockClaw Kit — 진입점

stockclaw-kit                → 브라우저 설정 페이지 (기본)
stockclaw-kit -p 9000        → 포트 지정
stockclaw-kit run list      → 사용 가능한 도구 목록
stockclaw-kit run gateway_status  → 도구 직접 호출

JSON 방식 (기존):
stockclaw-kit run datakit_call '{"function":"get_price","ticker":"005930"}'
stockclaw-kit run kiwoom_call_api '{"api_code":"ka10001","payload_json":"{\"stk_cd\":\"005930\"}"}'

Flat key=value 방식 (신규):
stockclaw-kit run datakit_call function=get_price ticker=005930
stockclaw-kit run kiwoom_call_api api_code=ka10001 stk_cd=005930
stockclaw-kit run kiwoom_call_api --no-save api_code=ka10001 stk_cd=005930

stockclaw-kit watch start    → 실시간 감시 데몬 시작
stockclaw-kit watch run-once → 감시 1회 실행 (테스트)
stockclaw-kit watch init     → 샘플 watchlist.json 생성
stockclaw-kit briefing morning       → 오전장 브리핑 생성
stockclaw-kit briefing closing       → 장 마감 브리핑 생성
stockclaw-kit setup                → 전체 설치
stockclaw-kit setup claude-code    → Claude Code 플러그인만
stockclaw-kit setup openclaw       → OpenClaw 스킬만
stockclaw-kit setup antigravity    → Antigravity만

DB 이력 조회:
stockclaw-kit db info        → 저장 통계
stockclaw-kit db history     → 최근 호출 목록
stockclaw-kit db history --tool kiwoom_call_api
stockclaw-kit db query "SELECT * FROM api_calls ORDER BY ts DESC LIMIT 5"
"""

import argparse
import json
import logging
import os
import sys
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(name)s | %(message)s")
logger = logging.getLogger("stock-kit")

# ─── 키 저장 디렉토리 ───
CONFIG_DIR = Path(os.getenv(
    "OPENCLAW_STOCK_KIT_HOME",
    Path.home() / ".stockclaw-kit"
))
ENV_FILE = CONFIG_DIR / ".env"
_LEGACY_JSON = CONFIG_DIR / "api_keys.json"


def _ensure_config_dir():
    """설정 디렉토리 생성 + 권한 700"""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    try:
        CONFIG_DIR.chmod(0o700)
    except OSError:
        pass  # Windows에서는 chmod 무시


def _migrate_json_to_env():
    """api_keys.json → .env 마이그레이션"""
    if not _LEGACY_JSON.exists():
        return
    try:
        with open(_LEGACY_JSON, encoding="utf-8") as f:
            keys = json.load(f)
        if keys:
            save_keys(keys)
            logger.info(f"[Keys] api_keys.json → .env 마이그레이션 완료 ({len(keys)}개)")
        _LEGACY_JSON.unlink()
    except Exception as e:
        logger.warning(f"[Keys] JSON 마이그레이션 실패: {e}")


def load_saved_keys():
    """.env 파일에서 저장된 키를 환경변수로 로딩 (기존 환경변수 우선)"""
    _migrate_json_to_env()
    if not ENV_FILE.exists():
        return {}
    try:
        from dotenv import dotenv_values
        keys = dotenv_values(ENV_FILE)
        applied = 0
        for k, v in keys.items():
            if v and k not in os.environ:
                os.environ[k] = str(v)
                applied += 1
        if applied:
            logger.info(f"[Keys] {applied}개 키 로딩 ({ENV_FILE})")
        return dict(keys)
    except Exception as e:
        logger.warning(f"[Keys] 로딩 실패: {e}")
        return {}


def save_keys(keys: dict):
    """키를 .env 파일에 저장 (권한 600)"""
    _ensure_config_dir()
    lines = [f"{k}={v}" for k, v in keys.items() if v]
    ENV_FILE.write_text("\n".join(lines) + "\n", encoding="utf-8")
    try:
        ENV_FILE.chmod(0o600)
    except OSError:
        pass  # Windows
    # 환경변수에 즉시 반영
    for k, v in keys.items():
        if v:
            os.environ[k] = str(v)


def _build_registry():
    """도구 레지스트리 생성 + 모듈 로딩"""
    from openclaw_stock_kit.tool_registry import ToolRegistry

    registry = ToolRegistry("StockClaw Kit")
    modules_status = {}

    # ── 모듈 로딩 (실패 격리) ──
    def _load(name, fn, desc, extra=None):
        try:
            fn()
            info = {"ok": True, "description": desc}
            if extra:
                info.update(extra)
            modules_status[name] = info
            logger.info(f"[OK] {name}: {desc}")
        except Exception as e:
            modules_status[name] = {"ok": False, "description": desc, "error": str(e)}
            logger.warning(f"[SKIP] {name}: {e}")

    # 모듈 import 경로 설정 (패키지 내부)
    _pkg_dir = Path(__file__).parent
    sys.path.insert(0, str(_pkg_dir))

    # 1) Stock Data Kit (PyKRX, DART, ECOS, 환율, 지배구조)
    def _load_datakit():
        from pykrx_server import register_tools as reg
        reg(registry)

    _load("datakit", _load_datakit, "Stock Data Kit (PyKRX, DART, ECOS)", {
        "tools": ["datakit_call", "datakit_list_functions", "datakit_get_env_info"],
    })

    # 2) Kiwoom REST API
    def _load_kiwoom():
        from kiwoom_server import register_tools as reg
        reg(registry)

    _load("kiwoom", _load_kiwoom, "Kiwoom REST API (185 APIs)", {
        "tools": ["kiwoom_call_api", "kiwoom_list_apis", "kiwoom_get_env_info", "kiwoom_api_spec"],
    })

    # 3) KIS 한국투자증권 (네이티브, Docker 불필요)
    def _load_kis():
        from kis_server import register_tools as reg
        reg(registry)

    _load("kis", _load_kis, "KIS Trading (166 APIs, Docker-free)", {
        "tools": ["kis_domestic_stock", "kis_overseas_stock", "kis_auth", "kis_get_env_info"],
    })

    # 4) News & Telegram (Naver API + Telethon)
    def _load_news():
        from news_server import register_tools as reg
        reg(registry)

    _load("news", _load_news, "News & Telegram (Naver API, Telegram)", {
        "tools": ["news_search", "news_search_stock", "telegram_auth",
                  "telegram_get_channels", "telegram_get_messages",
                  "telegram_send_message", "telegram_send_alert",
                  "news_get_env_info"],
    })

    # 5) Premium (라이선스 키 있을 때만 활성)
    def _load_premium():
        from openclaw_stock_kit.premium import register_premium_tools
        tools = register_premium_tools(registry)
        return tools

    _load("premium", _load_premium, "Premium Features (briefing, excel, backtest, course)", {
        "tools": ["premium_call", "premium_list_functions"],
    })

    # 6) 멤버십 Data Feed
    def _load_membership():
        from membership_server import register_tools as reg
        reg(registry)

    _load("membership", _load_membership, "멤버십 Data Feed (8 APIs)", {
        "tools": ["membership_call", "membership_list_functions", "membership_get_env_info"],
    })

    # ── 피드 카탈로그 도구 ──
    @registry.tool()
    def list_feeds() -> dict:
        """피드 카탈로그 조회 — 구독 가능한 뉴스/분석 피드 목록

        Hub에서 제공하는 텔레그램 피드 카탈로그를 반환합니다.
        무료 피드는 stock-kit 사용자도 수신 가능하며,
        유료 피드는 SimpleClaw 구독이 필요합니다.
        """
        catalog_path = Path(__file__).parent / "data" / "feeds_catalog.json"
        try:
            data = json.loads(catalog_path.read_text("utf-8"))
        except FileNotFoundError:
            return {"success": False, "error": "feeds_catalog.json not found"}
        feeds = data.get("feeds", [])
        free = [f for f in feeds if f.get("tier") == "free"]
        paid = [f for f in feeds if f.get("tier") == "paid"]
        return {
            "success": True,
            "total": len(feeds),
            "free_feeds": free,
            "paid_feeds": paid,
            "subscribe_info": "무료 피드는 텔레그램으로 수신됩니다. 유료 피드는 SimpleClaw 구독이 필요합니다.",
        }

    # ── Gateway 메타 도구 ──
    @registry.tool()
    def gateway_status() -> dict:
        """OpenClaw Stock Kit 전체 상태 + 도구 선택 가이드

        첫 호출 시 이 도구를 사용하면 활성 모듈 확인 + 최적 도구 선택법을 안내받습니다.
        """
        active = sum(1 for m in modules_status.values() if m.get("ok"))
        total_tools = sum(
            len(m.get("tools", []))
            for m in modules_status.values()
            if m.get("ok")
        ) + 1

        # 활성 모듈 기반 라우팅 가이드 생성
        guide = {
            "how_to_choose": "아래 시나리오별 권장 도구를 참고하세요",
            "scenarios": [],
        }

        if modules_status.get("datakit", {}).get("ok"):
            guide["scenarios"].append({
                "when": "과거 주가/시세/거래량/시총/지수 조회 (무료, 키 불필요)",
                "tool": "datakit_call",
                "examples": ["get_price", "get_ohlcv", "get_market_cap", "get_index", "search_stock"],
                "note": "PyKRX 기반. 15분 지연. 과거 데이터/분석에 최적",
            })
            guide["scenarios"].append({
                "when": "DART 공시, ECOS 거시지표, 환율, 지배구조 조회",
                "tool": "datakit_call",
                "examples": ["dart_disclosures", "ecos_indicator", "exchange_rate", "governance_majority"],
                "note": "DART/ECOS/EXIM API 키 필요",
            })

        if modules_status.get("kiwoom", {}).get("ok"):
            guide["scenarios"].append({
                "when": "실시간 현재가/호가/체결/순위 + 매매 주문 (키움 계좌 필요)",
                "tool": "kiwoom_call_api",
                "examples": ["ka10001 (현재가)", "ka10004 (호가)", "kt10000 (매수주문)"],
                "note": "키움 REST API. 실시간 데이터 + 주문. 인증 필요",
            })

        if modules_status.get("kis", {}).get("ok"):
            guide["scenarios"].append({
                "when": "한국투자증권 시세/매매/분석 (KIS 계좌 필요)",
                "tool": "kis_domestic_stock / kis_overseas_stock",
                "examples": ["inquire_price (현재가)", "inquire_balance (잔고)", "order (주문)"],
                "note": "166 APIs. find_api_detail로 파라미터 확인 후 호출",
            })

        if modules_status.get("news", {}).get("ok"):
            guide["scenarios"].append({
                "when": "주식 뉴스 검색, 종목별 뉴스, 텔레그램 채널 메시지",
                "tool": "news_search / news_search_stock / telegram_get_messages",
                "examples": ["삼성전자 뉴스 7일", "텔레그램 @channel 최신 20개"],
                "note": "Naver API 키 필요. 텔레그램 공개채널은 키 없이 가능",
            })

        if modules_status.get("membership", {}).get("ok"):
            guide["scenarios"].append({
                "when": "AI 시장 요약, 종목 뉴스 매칭, 테마별 이벤트, 뉴욕증시, 주도주시황, 장전뉴스",
                "tool": "membership_call",
                "examples": ["ka-006 (AI 일일 요약)", "ka-002 (종목 뉴스 매칭)", "ka-009 (장전뉴스)"],
                "note": "readinginvestor.com 데이터 피드. MEMBERSHIP_API_KEY 필요",
            })

        guide["decision_tree"] = [
            "1. 뉴스/소식 → news_search_stock 또는 telegram_get_messages",
            "2. 과거 주가/차트/시총 → datakit_call (무료, 즉시 사용)",
            "3. 실시간 현재가/호가 → kiwoom_call_api 또는 kis_domestic_stock",
            "4. 매매 주문 → kiwoom_call_api 또는 kis_domestic_stock",
            "5. 공시/거시지표 → datakit_call (DART/ECOS)",
            "6. 종목코드 모를 때 → datakit_call(function='search_stock')",
            "7. 모듈 상태 확인 → gateway_status (이 도구)",
        ]

        return {
            "success": True,
            "data": {
                "gateway": "OpenClaw Stock Kit",
                "active_modules": f"{active}/{len(modules_status)}",
                "total_tools": total_tools,
                "config_dir": str(CONFIG_DIR),
                "db_backend": "sqlite",
            },
            "modules": modules_status,
            "tool_guide": guide,
        }

    return registry, modules_status


def _run_serve(args):
    """설정 웹 서버 실행 (API 키 관리 페이지)"""
    # 저장된 키 로딩
    _ensure_config_dir()
    load_saved_keys()

    # 도구 레지스트리 빌드
    registry, modules_status = _build_registry()

    active = sum(1 for m in modules_status.values() if m.get("ok"))
    total_tools = sum(
        len(m.get("tools", []))
        for m in modules_status.values()
        if m.get("ok")
    ) + 1

    print()
    print("  +--------------------------------------------------+")
    print("  |        StockClaw Kit 설정 서버 시작됨             |")
    print("  +--------------------------------------------------+")
    print(f"  |  모듈: {active}/{len(modules_status)}  |  도구: {total_tools}개")
    print(f"  |  설정 페이지: http://localhost:{args.port}")
    print("  |  처음 사용하시면 위 URL을 브라우저에서 열어주세요")
    print("  +--------------------------------------------------+")
    print()

    import uvicorn
    from openclaw_stock_kit.http_server import create_app
    app = create_app(registry, modules_status, CONFIG_DIR, ENV_FILE)
    uvicorn.run(app, host="0.0.0.0", port=args.port)


def _auto_type(value: str):
    """key=value 파싱 시 숫자/불리언/null을 자동 변환.
    
    "5" → 5, "0.5" → 0.5, "true" → True, "null" → None
    선행 0이 있는 숫자("005930")는 종목코드 등이므로 문자열 유지.
    """
    # 선행 0이 있는 숫자는 코드/식별자이므로 변환하지 않음 (예: 005930)
    if len(value) > 1 and value.startswith('0') and value[1:].isdigit():
        return value
    if value.isdigit() or (value.startswith('-') and value[1:].isdigit()):
        return int(value)
    try:
        return float(value)
    except ValueError:
        pass
    low = value.lower()
    if low == 'true':
        return True
    if low == 'false':
        return False
    if low == 'null' or low == 'none':
        return None
    return value


def _run_call(args):
    """도구 직접 호출 (CLI에서 바로 실행)"""
    # run 모드: 로딩 로그를 stderr로, stdout은 순수 JSON만
    logging.basicConfig(level=logging.WARNING, format="%(name)s | %(message)s",
                        stream=sys.stderr, force=True)
    # Windows cp949 인코딩 문제 방지
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")

    _ensure_config_dir()
    load_saved_keys()
    registry, modules_status = _build_registry()

    tool_name = args.tool_name

    # list: 사용 가능한 도구 목록
    if tool_name == "list":
        print(json.dumps(registry.list_tools(), ensure_ascii=False, indent=2))
        return

    # 파라미터 파싱: JSON 문자열 또는 key=value 목록
    params = {}
    if args.params:
        raw = args.params  # nargs="*" 이므로 리스트
        if len(raw) == 1 and raw[0].startswith('{'):
            # 레거시 JSON 모드
            params = json.loads(raw[0])
        else:
            # Flat key=value 모드
            flat_params = {}
            for item in raw:
                if '=' not in item:
                    continue
                key, _, value = item.partition('=')
                flat_params[key] = _auto_type(value)

            # kiwoom_call_api 전용: api_code + 나머지 → payload_json 자동 구성
            if tool_name == 'kiwoom_call_api' and 'payload_json' not in flat_params:
                api_code = flat_params.pop('api_code', '')
                if flat_params:
                    payload = json.dumps(flat_params, ensure_ascii=False)
                    params = {'api_code': api_code, 'payload_json': payload}
                else:
                    params = {'api_code': api_code, 'payload_json': '{}'}

            # datakit_call 전용: function + 나머지 → params_json 자동 구성
            elif tool_name == 'datakit_call' and 'params_json' not in flat_params:
                function = flat_params.pop('function', '')
                if flat_params:
                    params_json = json.dumps(flat_params, ensure_ascii=False)
                    params = {'function': function, 'params_json': params_json}
                else:
                    params = {'function': function, 'params_json': '{}'}

            else:
                params = flat_params

    # DB 저장소 초기화 (import 실패 시 None)
    db = None
    no_save = getattr(args, 'no_save', False)
    if not no_save:
        try:
            from openclaw_stock_kit.db_store import DBStore
            db = DBStore(CONFIG_DIR / "market.db")
        except Exception:
            pass  # DBStore 없으면 자동저장 건너뜀

    # 도구 호출
    try:
        output = registry.call(tool_name, params)
        print(output)

        # 자동 저장 (실패해도 출력에 영향 없음)
        if db is not None:
            try:
                db.save(tool_name, params, output)
            except Exception:
                pass

    except KeyError:
        available = [t["name"] for t in registry.list_tools()]
        print(json.dumps({
            "error": f"Tool '{tool_name}' not found",
            "available_tools": available,
        }, ensure_ascii=False, indent=2))
        sys.exit(1)
    finally:
        if db is not None:
            try:
                db.close()
            except Exception:
                pass


def _run_db(args, db_parser):
    """DB 이력 조회"""
    logging.basicConfig(level=logging.WARNING, format="%(name)s | %(message)s",
                        stream=sys.stderr, force=True)
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")

    _ensure_config_dir()

    try:
        from openclaw_stock_kit.db_store import DBStore
    except ImportError:
        print(json.dumps({"error": "DBStore not available. Update openclaw_stock_kit."}, ensure_ascii=False, indent=2))
        sys.exit(1)

    db = DBStore(CONFIG_DIR / "market.db")
    try:
        if args.db_action == "info":
            print(json.dumps(db.get_stats(), ensure_ascii=False, indent=2))
        elif args.db_action == "history":
            tool_filter = getattr(args, 'tool', None)
            rows = db.get_history(tool_filter)
            print(json.dumps(rows, ensure_ascii=False, indent=2))
        elif args.db_action == "query":
            rows = db.query(args.sql)
            print(json.dumps(rows, ensure_ascii=False, indent=2))
        else:
            db_parser.print_help()
    finally:
        db.close()


def _run_watch(args):
    """Watch 데몬 실행"""
    _ensure_config_dir()
    load_saved_keys()

    action = args.watch_action

    if action == "init":
        from openclaw_stock_kit.watch_engine import create_sample_config
        out = CONFIG_DIR / "watchlist.json"
        create_sample_config(str(out))
        print(f"Sample watchlist created: {out}")
        print("Edit the file, then: stockclaw-kit watch start")
        return

    # start / run-once need config + registry
    config_path = args.config or str(CONFIG_DIR / "watchlist.json")
    if not Path(config_path).exists():
        print(f"Config not found: {config_path}")
        print("Run: stockclaw-kit watch init")
        sys.exit(1)

    registry, _ = _build_registry()
    from openclaw_stock_kit.watch_engine import WatchEngine
    engine = WatchEngine.from_file(config_path, registry)

    if action == "run-once":
        results = engine.run_once()
        print(json.dumps(results, ensure_ascii=False, indent=2))
    else:
        # start (foreground — use PM2 for background)
        engine.run_loop()


def _run_briefing(args):
    """자동 브리핑 실행"""
    logging.basicConfig(level=logging.WARNING, format="%(name)s | %(message)s",
                        stream=sys.stderr, force=True)
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")

    _ensure_config_dir()
    load_saved_keys()
    registry, _ = _build_registry()

    from openclaw_stock_kit.briefing import BriefingRunner
    runner = BriefingRunner(registry)
    output = runner.run(mode=args.briefing_mode,
                        output_format=args.format or "text")
    print(output)

    # Optional telegram send
    if args.send_telegram:
        try:
            registry.call("telegram_send_message", {
                "target": args.send_telegram,
                "text": output,
            })
            print(f"\n(Telegram sent → {args.send_telegram})", file=sys.stderr)
        except Exception as e:
            print(f"\n(Telegram send failed: {e})", file=sys.stderr)


def _run_setup(args):
    """통합 설치 실행"""
    from openclaw_stock_kit.setup import run_setup
    target = getattr(args, "target", None)
    sys.exit(run_setup(target))


def main():
    parser = argparse.ArgumentParser(
        prog="stockclaw-kit",
        description="Korean stock market data & trading toolkit — CLI direct run + settings server",
    )

    subparsers = parser.add_subparsers(dest="command")

    # serve (기본 — 서브커맨드 생략 시)
    serve_parser = subparsers.add_parser(
        "serve", help="Run settings web server (default)",
    )
    serve_parser.add_argument(
        "-p", "--port", type=int, default=8200,
        help="Port for settings page (default: 8200)",
    )

    # run (도구 직접 호출)
    run_parser = subparsers.add_parser(
        "run", help="Run a tool directly",
    )
    run_parser.add_argument(
        "tool_name",
        help="Tool name to run (use 'list' to see available tools)",
    )
    run_parser.add_argument(
        "params", nargs="*", default=None,
        help=(
            "Parameters: JSON string or key=value pairs. "
            "e.g. '{\"function\":\"get_price\"}' or function=get_price ticker=005930 "
            "or (kiwoom) api_code=ka10001 stk_cd=005930"
        ),
    )
    run_parser.add_argument(
        "--no-save", dest="no_save", action="store_true", default=False,
        help="Skip auto-saving result to SQLite history",
    )

    # watch (실시간 감시 데몬)
    watch_parser = subparsers.add_parser(
        "watch", help="Real-time market watch daemon",
    )
    watch_parser.add_argument(
        "watch_action", choices=["start", "run-once", "init"],
        help="start: run daemon, run-once: single cycle, init: create sample config",
    )
    watch_parser.add_argument(
        "--config", "-c", default=None,
        help="Path to watchlist.json (default: ~/.stockclaw-kit/watchlist.json)",
    )

    # briefing (시장 브리핑)
    briefing_parser = subparsers.add_parser(
        "briefing", help="Generate market briefing",
    )
    briefing_parser.add_argument(
        "briefing_mode", choices=["morning", "closing"],
        help="morning: pre-market briefing, closing: end-of-day briefing",
    )
    briefing_parser.add_argument(
        "--format", "-f", choices=["text", "json"], default="text",
        help="Output format (default: text)",
    )
    briefing_parser.add_argument(
        "--send-telegram", default=None,
        help="Send briefing to Telegram target (@channel, ID, or 'me')",
    )

    # setup
    setup_parser = subparsers.add_parser(
        "setup", help="Install Claude Code plugin and/or OpenClaw skill",
    )
    setup_parser.add_argument(
        "target", nargs="?", default=None,
        choices=["claude-code", "openclaw", "antigravity"],
        help="Install target (default: all)",
    )

    # db (API 호출 이력 조회)
    db_parser = subparsers.add_parser(
        "db", help="Query saved API call history",
    )
    db_sub = db_parser.add_subparsers(dest="db_action")
    db_sub.add_parser("info", help="Show database stats")
    db_history_parser = db_sub.add_parser("history", help="Show recent API calls")
    db_history_parser.add_argument(
        "--tool", default=None,
        help="Filter by tool name (e.g. kiwoom_call_api)",
    )
    db_query_parser = db_sub.add_parser("query", help="Run SQL SELECT query")
    db_query_parser.add_argument(
        "sql",
        help="SQL SELECT query (e.g. \"SELECT * FROM api_calls LIMIT 10\")",
    )

    # 하위호환: 서브커맨드 없이 -p 사용 가능
    parser.add_argument(
        "-p", "--port", type=int, default=8200,
        help=argparse.SUPPRESS,
    )

    args = parser.parse_args()

    if args.command == "run":
        _run_call(args)
    elif args.command == "watch":
        _run_watch(args)
    elif args.command == "briefing":
        _run_briefing(args)
    elif args.command == "setup":
        _run_setup(args)
    elif args.command == "db":
        _run_db(args, db_parser)
    else:
        # serve (명시적) 또는 서브커맨드 없음 (하위호환)
        _run_serve(args)


if __name__ == "__main__":
    main()
