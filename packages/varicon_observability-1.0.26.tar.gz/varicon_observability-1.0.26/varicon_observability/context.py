import contextvars

# Context variables for request-scoped log injection
tenant_context = contextvars.ContextVar("tenant_id", default="unknown-tenant")
username_context = contextvars.ContextVar("username", default="")
request_id_context = contextvars.ContextVar("request_id", default="")
client_type_context = contextvars.ContextVar("client_type", default="")
