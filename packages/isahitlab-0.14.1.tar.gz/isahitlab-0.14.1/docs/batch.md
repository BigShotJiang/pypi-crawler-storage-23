# Batch module

::: isahitlab.actions.batch