"""Type definitions for the Discovery SDK."""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class FileInfo:
    """Information about an uploaded file."""

    file_path: str  # GCS path
    file_hash: str
    file_size: int
    mime_type: str


@dataclass
class TimeseriesGroup:
    """Timeseries column group metadata."""

    base_name: str
    columns: List[str]
    num_timesteps: int
    pattern_matched: str
    dtype: str  # "numeric" or "categorical"


@dataclass
class PatternCitation:
    """Academic citation for a pattern."""

    url: str
    title: Optional[str] = None
    doi: Optional[str] = None
    authors: Optional[List[str]] = None
    year: Optional[str] = None
    journal: Optional[str] = None
    volume: Optional[str] = None
    issue: Optional[str] = None
    pages: Optional[str] = None


@dataclass
class Pattern:
    """A discovered pattern in the data."""

    id: str
    task: str  # regression, binary_classification, multiclass_classification
    target_column: str
    target_change_direction: str  # "min" or "max"
    p_value: float  # FDR-adjusted p-value
    conditions: List[Dict[str, Any]]
    abs_target_change: float
    support_count: int
    support_percentage: float
    novelty_type: str  # "novel" or "confirmatory"
    target_score: float
    description: str
    novelty_explanation: str
    target_class: Optional[str] = None
    target_mean: Optional[float] = None
    target_std: Optional[float] = None
    citations: List[Dict[str, Any]] = field(default_factory=list)
    p_value_raw: Optional[float] = None  # Raw p-value before FDR adjustment


# Column/Feature types


@dataclass
class Column:
    """Information about a dataset column/feature."""

    id: str
    name: str
    display_name: str
    type: str  # "continuous" or "categorical"
    data_type: str  # "int", "float", "string", "boolean", "datetime"
    enabled: bool
    description: Optional[str] = None

    # Statistics
    mean: Optional[float] = None
    median: Optional[float] = None
    std: Optional[float] = None
    min: Optional[float] = None
    max: Optional[float] = None
    iqr_min: Optional[float] = None
    iqr_max: Optional[float] = None
    mode: Optional[str] = None
    approx_unique: Optional[int] = None
    null_percentage: Optional[float] = None

    # Feature importance
    feature_importance_score: Optional[float] = None


@dataclass
class PatternGroup:
    """A group of patterns with explanation."""

    pattern_ids: List[str]
    explanation: str


@dataclass
class Summary:
    """LLM-generated summary of the analysis."""

    overview: str
    key_insights: List[str]
    novel_patterns: PatternGroup
    selected_pattern_id: Optional[str] = None


# Feature importance types


@dataclass
class FeatureImportanceScore:
    """A single feature importance score.

    Scores are computed using Hierarchical Perturbation (HiPe), an ablation-based method.
    Scores are SIGNED to indicate direction of effect:

    - For regression: positive means the feature increases the prediction,
      negative means it decreases the prediction.
    - For classification: positive means the feature supports the model's predicted class,
      negative means it works against the prediction.

    Higher absolute values indicate more influential features.
    """

    feature: str  # Feature/column name
    score: float  # Signed importance score


@dataclass
class FeatureImportance:
    """Global feature importance information.

    Feature importance is computed using Hierarchical Perturbation (HiPe),
    which measures how much each feature affects the model's predictions
    by replacing feature values with their mean (continuous) or mode (categorical).

    Scores are signed to indicate direction:
    - Positive: feature increases prediction / supports predicted class
    - Negative: feature decreases prediction / works against predicted class
    """

    kind: str  # "global" or "local"
    baseline: float  # Expected model output (mean prediction)
    scores: List[FeatureImportanceScore]  # Per-feature importance scores


# Correlation matrix types


@dataclass
class CorrelationEntry:
    """A single correlation matrix entry."""

    feature_x: str
    feature_y: str
    value: float


# Main result type


@dataclass
class EngineResult:
    """Complete result of an engine run."""

    # Identifiers
    run_id: str
    report_id: Optional[str] = None
    status: str = "pending"  # pending, processing, completed, failed

    # Dataset metadata
    dataset_title: Optional[str] = None
    dataset_description: Optional[str] = None
    total_rows: Optional[int] = None
    target_column: Optional[str] = None
    task: Optional[str] = None  # regression, binary_classification, multiclass_classification

    # LLM-generated summary
    summary: Optional[Summary] = None

    # Discovered patterns
    patterns: List[Pattern] = field(default_factory=list)

    # Column/feature information with stats and importance
    columns: List[Column] = field(default_factory=list)

    # Correlation matrix
    correlation_matrix: List[CorrelationEntry] = field(default_factory=list)

    # Global feature importance
    feature_importance: Optional[FeatureImportance] = None

    # Job tracking
    job_id: Optional[str] = None
    job_status: Optional[str] = None
    error_message: Optional[str] = None


@dataclass
class RunStatus:
    """Status of a run."""

    run_id: str
    status: str
    job_id: Optional[str] = None
    job_status: Optional[str] = None
    error_message: Optional[str] = None
