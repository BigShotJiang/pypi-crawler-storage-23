import os
import shutil

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import zarr
from loguru import logger


def _ensure_parent_dir(path):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)


def _ensure_array(value):
    arr = np.asarray(value)
    if arr.ndim == 0:
        arr = arr.reshape((1,))
    return arr


def _is_dynamic(results):
    for stream in results.values():
        time_series = stream.get("time")
        if isinstance(time_series, (list, tuple, np.ndarray)):
            return True
    return False


def _store_stream(stream_group, stream_data):
    for key, value in stream_data.items():
        if key == "z" and isinstance(value, dict):
            comp_group = stream_group.create_group("__composition__")
            for comp, comp_values in sorted(value.items()):
                comp_arr = _ensure_array(comp_values)
                comp_group.create_dataset(comp, data=comp_arr, shape=comp_arr.shape)
            continue
        arr = _ensure_array(value)
        stream_group.create_dataset(key, data=arr, shape=arr.shape)


def save_results_zarr(results, fname="results.zarr"):
    """Persist simulation results in a Zarr directory."""
    store_path = os.path.abspath(fname)
    if os.path.exists(store_path):
        if os.path.isdir(store_path):
            shutil.rmtree(store_path)
        else:
            os.remove(store_path)
    _ensure_parent_dir(store_path)
    store = zarr.storage.LocalStore(store_path)
    root = zarr.group(store=store)
    mode = "dynamic" if _is_dynamic(results) else "steady"
    root.attrs["mode"] = mode
    for stream_name, stream_data in results.items():
        stream_group = root.create_group(stream_name)
        _store_stream(stream_group, stream_data)
    logger.info(f"Saved Zarr results to {store_path}")
    return store_path


def upload_zarr_to_s3(local_zarr_path):
    """Upload a local Zarr directory store to a pre-configured S3 bucket.

    Reads connection details from environment variables:
        S3_BUCKET_NAME, S3_ENDPOINT_URL, S3_REGION_NAME,
        S3_ACCESS_KEY, S3_SECRET_KEY

    Deletes the local Zarr directory after a successful upload.
    Returns the S3 URI of the uploaded store.
    """
    try:
        import boto3
    except ImportError:
        raise ImportError(
            "boto3 is required for S3 upload. "
            "Install it with: pip install processforge[s3]"
        )

    bucket = os.environ.get("S3_BUCKET_NAME")
    if not bucket:
        logger.warning(
            "S3_BUCKET_NAME is not set — skipping S3 upload. "
            f"Zarr results remain at: {local_zarr_path}"
        )
        return None
    endpoint_url = os.environ.get("S3_ENDPOINT_URL")
    region_name = os.environ.get("S3_REGION_NAME")
    access_key = os.environ.get("S3_ACCESS_KEY")
    secret_key = os.environ.get("S3_SECRET_KEY")
    missing = [v for v, k in [("S3_ACCESS_KEY", access_key), ("S3_SECRET_KEY", secret_key)] if not k]
    if missing:
        logger.warning(
            f"Missing required S3 env var(s): {', '.join(missing)} — skipping S3 upload. "
            f"Zarr results remain at: {local_zarr_path}"
        )
        return None

    s3 = boto3.client(
        "s3",
        endpoint_url=endpoint_url,
        region_name=region_name,
        aws_access_key_id=access_key,
        aws_secret_access_key=secret_key,
    )

    store_name = os.path.basename(local_zarr_path)
    for root_dir, _, files in os.walk(local_zarr_path):
        for file in files:
            local_file = os.path.join(root_dir, file)
            relative_path = os.path.relpath(local_file, local_zarr_path)
            s3_key = store_name + "/" + relative_path.replace("\\", "/")
            s3.upload_file(local_file, bucket, s3_key)

    shutil.rmtree(local_zarr_path)
    s3_uri = f"s3://{bucket}/{store_name}"
    logger.info(f"Uploaded Zarr store to {s3_uri} and removed local copy")
    return s3_uri


def upload_log_to_s3(local_log_path):
    """Upload a log file to the pre-configured S3 bucket.

    Reads connection details from the same env vars as upload_zarr_to_s3.
    Deletes the local log file after a successful upload.
    Returns the S3 URI of the uploaded file.
    """
    try:
        import boto3
    except ImportError:
        raise ImportError(
            "boto3 is required for S3 upload. "
            "Install it with: pip install processforge[s3]"
        )

    bucket = os.environ.get("S3_BUCKET_NAME")
    if not bucket:
        logger.warning(
            "S3_BUCKET_NAME is not set — skipping log upload. "
            f"Log remains at: {local_log_path}"
        )
        return None

    access_key = os.environ.get("S3_ACCESS_KEY")
    secret_key = os.environ.get("S3_SECRET_KEY")
    missing = [v for v, k in [("S3_ACCESS_KEY", access_key), ("S3_SECRET_KEY", secret_key)] if not k]
    if missing:
        logger.warning(
            f"Missing required S3 env var(s): {', '.join(missing)} — skipping log upload. "
            f"Log remains at: {local_log_path}"
        )
        return None

    s3 = boto3.client(
        "s3",
        endpoint_url=os.environ.get("S3_ENDPOINT_URL"),
        region_name=os.environ.get("S3_REGION_NAME"),
        aws_access_key_id=access_key,
        aws_secret_access_key=secret_key,
    )

    s3_key = os.path.basename(local_log_path)
    s3.upload_file(local_log_path, bucket, s3_key)
    os.remove(local_log_path)
    s3_uri = f"s3://{bucket}/{s3_key}"
    logger.info(f"Uploaded log to {s3_uri} and removed local copy")
    return s3_uri


def plot_results(results, fname="results.png"):
    os.makedirs("outputs", exist_ok=True)
    streams = list(results.keys())
    temp_values = [_scalar_from_sequence(results[s].get("T")) or 0.0 for s in streams]

    plt.figure(figsize=(8, 4))
    plt.bar(streams, temp_values, color="skyblue")
    plt.ylabel("Temperature [K]")
    plt.title("Stream Temperatures (Steady State)")
    plt.tight_layout()
    plt.savefig(os.path.join("outputs", "temps_" + fname))
    plt.close()

    comps = set()
    for s in results.values():
        comps.update(s.get("z", {}).keys())
    comps = sorted(comps)

    bottom = [0.0] * len(streams)
    plt.figure(figsize=(8, 4))
    for comp in comps:
        vals = [
            _scalar_from_sequence(results[s].get("z", {}).get(comp, 0.0)) or 0.0
            for s in streams
        ]
        plt.bar(streams, vals, bottom=bottom, label=comp)
        bottom = [bottom[i] + vals[i] for i in range(len(vals))]
    plt.ylabel("Mole Fraction")
    plt.title("Stream Compositions (Steady State)")
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join("outputs", "comps_" + fname))
    plt.close()


def plot_timeseries(results, fname="timeseries.png"):
    os.makedirs("outputs", exist_ok=True)
    streams = sorted(results.keys())
    if not streams:
        return

    times = results[streams[0]].get("time", [])
    if not times:
        return

    plt.figure(figsize=(8, 5))
    for s_name in streams:
        if "T" in results[s_name]:
            plt.plot(times, results[s_name]["T"], label=s_name)
    plt.xlabel("Time [s]")
    plt.ylabel("Temperature [K]")
    plt.title("Stream Temperatures vs Time")
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join("outputs", "temps_" + fname))
    plt.close()

    comps = set()
    for s_data in results.values():
        if "z" in s_data and isinstance(s_data["z"], dict):
            comps.update(s_data["z"].keys())
    comps = sorted(comps)

    for s_name in streams:
        if "z" not in results[s_name]:
            continue
        plt.figure(figsize=(8, 5))
        for comp in comps:
            if comp in results[s_name]["z"]:
                plt.plot(times, results[s_name]["z"][comp], label=comp)
        plt.xlabel("Time [s]")
        plt.ylabel("Mole Fraction")
        plt.title(f"Compositions vs Time ({s_name})")
        plt.legend()
        plt.tight_layout()
        plt.savefig(os.path.join("outputs", f"comps_{s_name}_" + fname))
        plt.close()


def _convert_value(value):
    if isinstance(value, np.ndarray):
        if value.size == 0:
            return ""
        return _convert_value(value.item())
    if isinstance(value, np.generic):
        return value.item()
    return value


def _scalar_from_sequence(value):
    if value is None:
        return None
    if isinstance(value, (list, tuple, np.ndarray)):
        arr = np.asarray(value)
        if arr.size == 0:
            return None
        candidate = arr[-1]
    else:
        candidate = value
    return _convert_value(candidate)


def _get_zarr_value(dataset, idx):
    if dataset is None:
        return ""
    length = dataset.shape[0]
    if length == 0:
        return ""
    position = min(idx, length - 1)
    return _convert_value(dataset[position])


def _build_dataframe_row(group, stream_name, idx, comp_names, include_time):
    row = {"stream": stream_name}
    if include_time and "time" in group:
        row["time"] = _get_zarr_value(group.get("time"), idx)
    row["T [K]"] = _get_zarr_value(group.get("T"), idx)
    row["P [Pa]"] = _get_zarr_value(group.get("P"), idx)
    row["Phase"] = _get_zarr_value(group.get("phase"), idx)
    row["VaporFrac"] = _get_zarr_value(group.get("beta"), idx)
    row["flowrate"] = _get_zarr_value(group.get("flowrate"), idx)
    comp_group = group.get("__composition__")
    if comp_group is not None:
        for comp in comp_names:
            row[comp] = _get_zarr_value(comp_group.get(comp), idx)
    return row


def _load_dataframe_from_zarr(store_path):
    store = zarr.storage.LocalStore(store_path)
    root = zarr.open(store=store, mode="r")
    streams = sorted(root.group_keys())
    rows = []
    components = set()
    mode = root.attrs.get("mode", "steady")
    for stream in streams:
        group = root[stream]
        comp_group = group.get("__composition__")
        comp_names = sorted(comp_group.keys()) if comp_group is not None else []
        components.update(comp_names)
        has_time = "time" in group and mode == "dynamic"
        length = group["time"].shape[0] if has_time else 1
        for idx in range(length):
            rows.append(_build_dataframe_row(group, stream, idx, comp_names, has_time))
    df = pd.DataFrame(rows)
    for comp in sorted(components):
        if comp in df:
            df[comp] = df[comp].fillna(0.0)
        else:
            df[comp] = 0.0
    return df


def generate_validation_excel(data_source, output_filename):
    """
    Generate a multi-sheet Excel validation report from simulation results.

    data_source: path to a Zarr store, CSV file, or pandas DataFrame.
    output_filename: path for the output .xlsx file.
    """
    if isinstance(data_source, str) and os.path.isdir(data_source):
        df = _load_dataframe_from_zarr(data_source)
    elif isinstance(data_source, str):
        df = pd.read_csv(data_source)
    else:
        df = data_source.copy()

    if "Stream" in df.columns and "stream" not in df.columns:
        df.rename(columns={"Stream": "stream"}, inplace=True)

    known_cols = {
        "time",
        "stream",
        "T [K]",
        "P [Pa]",
        "Phase",
        "VaporFrac",
        "flowrate",
    }
    comp_cols = [c for c in df.columns if c not in known_cols]
    numeric_comp = (
        df[comp_cols].apply(pd.to_numeric, errors="coerce")
        if comp_cols
        else pd.DataFrame()
    )
    if not numeric_comp.empty:
        df["Total_Fraction"] = numeric_comp.sum(axis=1)
        df["Composition_Alert"] = np.where(
            np.isclose(df["Total_Fraction"], 1.0, atol=1e-5),
            "OK",
            "MASS LEAK",
        )
    else:
        df["Total_Fraction"] = ""
        df["Composition_Alert"] = ""
    mass_ok = (df["Composition_Alert"] == "OK").all()

    pump_check = pd.DataFrame()
    pump_ok = True
    temp_ok = True

    if "stream" in df.columns and "time" in df.columns:
        stream_names = df["stream"].unique()
        pump_ins = sorted([s for s in stream_names if "before_pump" in str(s)])
        pump_outs = sorted([s for s in stream_names if "after_pump" in str(s)])

        for p_in, p_out in zip(pump_ins, pump_outs):
            df_in = df[df["stream"] == p_in].set_index("time")
            df_out = df[df["stream"] == p_out].set_index("time")
            common_idx = df_in.index.intersection(df_out.index)
            if common_idx.empty:
                continue
            pc = pd.DataFrame(index=common_idx)
            pc["Pump"] = f"{p_in} -> {p_out}"
            pc["Pressure_Gain_Pa"] = (
                df_out.loc[common_idx, "P [Pa]"].values
                - df_in.loc[common_idx, "P [Pa]"].values
            )
            pc["Temp_Rise_K"] = (
                df_out.loc[common_idx, "T [K]"].values
                - df_in.loc[common_idx, "T [K]"].values
            )
            pc["Pump_Status"] = np.where(
                pc["Pressure_Gain_Pa"] > 0,
                "Functional",
                "Broken",
            )
            pump_check = pd.concat([pump_check, pc])

        if not pump_check.empty:
            pump_ok = (pump_check["Pump_Status"] == "Functional").all()
            temp_ok = (pump_check["Temp_Rise_K"] >= 0).all()

    summary_rows = [
        {
            "Physical Law": "Conservation of Mass",
            "Logic": "Do chemical fractions add to 1.0?",
            "Status": "PASS" if mass_ok else "FAIL",
        }
    ]
    if not pump_check.empty:
        summary_rows.append(
            {
                "Physical Law": "Pump Work (Pressure)",
                "Logic": "Does the pump increase pressure?",
                "Status": "PASS" if pump_ok else "FAIL",
            }
        )
        summary_rows.append(
            {
                "Physical Law": "Thermal Direction",
                "Logic": "Is the outlet temperature >= inlet?",
                "Status": "PASS" if temp_ok else "WARNING",
            }
        )
    summary_df = pd.DataFrame(summary_rows)

    _ensure_parent_dir(output_filename)
    with pd.ExcelWriter(output_filename, engine="openpyxl") as writer:
        summary_df.to_excel(writer, sheet_name="1_EXECUTIVE_SUMMARY", index=False)
        if not pump_check.empty:
            pump_check.to_excel(writer, sheet_name="2_PUMP_PERFORMANCE")
        df.to_excel(writer, sheet_name="3_RAW_DATA_CHECKED", index=False)

    logger.info(f"Validation Report Generated: {output_filename}")
