"""Bundled JSON schemas for processforge validation."""
