"""C99 code emitter — generates portable C99 source for inference.

Output guarantees:
- No dynamic memory allocation
- No recursion
- No floating-point unless target supports it
- No standard library dependencies beyond <stdint.h> and <string.h>
- Deterministic execution time
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from timber.ir.model import (
    LinearStage,
    Objective,
    PrecisionMode,
    SVMStage,
    TimberIR,
    TreeEnsembleStage,
)

# ---------------------------------------------------------------------------
# Predefined embedded target profiles
# ---------------------------------------------------------------------------
EMBEDDED_PROFILES: dict[str, dict] = {
    "cortex-m4": {
        "arch": "cortex-m4",
        "os": "baremetal",
        "abi": "eabi",
        "cross_prefix": "arm-none-eabi-",
        "cpu_flags": "-mcpu=cortex-m4 -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb",
        "extra_flags": "--specs=nosys.specs",
    },
    "cortex-m33": {
        "arch": "cortex-m33",
        "os": "baremetal",
        "abi": "eabi",
        "cross_prefix": "arm-none-eabi-",
        "cpu_flags": "-mcpu=cortex-m33 -mfpu=fpv5-sp-d16 -mfloat-abi=hard -mthumb",
        "extra_flags": "--specs=nosys.specs",
    },
    "rv32imf": {
        "arch": "rv32imf",
        "os": "baremetal",
        "abi": "ilp32f",
        "cross_prefix": "riscv32-unknown-elf-",
        "cpu_flags": "-march=rv32imf -mabi=ilp32f",
        "extra_flags": "",
    },
    "rv64gc": {
        "arch": "rv64gc",
        "os": "linux",
        "abi": "lp64d",
        "cross_prefix": "riscv64-unknown-linux-gnu-",
        "cpu_flags": "-march=rv64gc -mabi=lp64d",
        "extra_flags": "",
    },
}


@dataclass
class TargetSpec:
    """Hardware target specification for code generation."""
    arch: str = "x86_64"
    features: list[str] = field(default_factory=list)
    os: str = "linux"
    abi: str = "systemv"
    precision: PrecisionMode = PrecisionMode.FLOAT32
    output_format: str = "c_source"
    strip_symbols: bool = False
    # Embedded cross-compilation fields
    cross_prefix: str = ""      # e.g. "arm-none-eabi-"
    cpu_flags: str = ""         # e.g. "-mcpu=cortex-m4 -mfpu=fpv4-sp-d16 ..."
    extra_flags: str = ""       # e.g. "--specs=nosys.specs"
    embedded: bool = False      # True disables shared-lib targets

    @classmethod
    def for_embedded(cls, profile: str, **kwargs) -> "TargetSpec":
        """Create a TargetSpec for a named embedded profile."""
        if profile not in EMBEDDED_PROFILES:
            raise ValueError(
                f"Unknown embedded profile '{profile}'. "
                f"Available: {', '.join(EMBEDDED_PROFILES)}"
            )
        p = EMBEDDED_PROFILES[profile]
        return cls(
            arch=p["arch"],
            os=p["os"],
            abi=p["abi"],
            cross_prefix=p["cross_prefix"],
            cpu_flags=p["cpu_flags"],
            extra_flags=p["extra_flags"],
            embedded=True,
            **kwargs,
        )


@dataclass
class C99Output:
    """The generated C99 source package."""
    model_c: str
    model_h: str
    model_data_c: str
    cmakelists: str
    makefile: str

    def write(self, output_dir: str | Path) -> list[str]:
        """Write all files to the output directory. Returns list of written paths."""
        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)

        files = {
            "model.c": self.model_c,
            "model.h": self.model_h,
            "model_data.c": self.model_data_c,
            "CMakeLists.txt": self.cmakelists,
            "Makefile": self.makefile,
        }

        written = []
        for name, content in files.items():
            path = out / name
            path.write_text(content, encoding="utf-8")
            written.append(str(path))

        return written


class C99Emitter:
    """Emits C99 source code from optimized Timber IR."""

    def __init__(self, target: Optional[TargetSpec] = None):
        self.target = target or TargetSpec()

    def emit(self, ir: TimberIR) -> C99Output:
        """Generate the full C99 source package from the IR.

        Dispatches to the appropriate emitter based on the primary stage type:
          - TreeEnsembleStage  → tree traversal inference
          - LinearStage        → dot-product + activation inference
          - SVMStage           → kernel machine inference
        """
        # Find primary stage (skip preprocessing stages)
        primary = None
        for stage in ir.pipeline:
            if isinstance(stage, (TreeEnsembleStage, LinearStage, SVMStage)):
                primary = stage
                break

        if primary is None:
            raise ValueError(
                "No supported primary stage found in IR pipeline. "
                "Expected TreeEnsembleStage, LinearStage, or SVMStage."
            )

        if isinstance(primary, LinearStage):
            model_h = self._emit_header_linear(ir, primary)
            model_data_c = self._emit_data_linear(ir, primary)
            model_c = self._emit_inference_linear(ir, primary)
        elif isinstance(primary, SVMStage):
            model_h = self._emit_header_svm(ir, primary)
            model_data_c = self._emit_data_svm(ir, primary)
            model_c = self._emit_inference_svm(ir, primary)
        else:
            model_h = self._emit_header(ir, primary)
            model_data_c = self._emit_data(ir, primary)
            model_c = self._emit_inference(ir, primary)

        cmakelists = self._emit_cmake(ir)
        makefile = self._emit_makefile(ir)

        return C99Output(
            model_c=model_c,
            model_h=model_h,
            model_data_c=model_data_c,
            cmakelists=cmakelists,
            makefile=makefile,
        )

    def _emit_header(self, ir: TimberIR, ensemble: TreeEnsembleStage) -> str:
        """Generate model.h — the public C header."""
        n_features = ensemble.n_features
        n_outputs = 1 if ensemble.n_classes <= 2 else ensemble.n_classes
        float_type = self._float_type()

        lines = [
            "/* model.h — Timber compiled model inference header */",
            "/* Generated by Timber v0.1 — DO NOT EDIT */",
            "",
            "#ifndef TIMBER_MODEL_H",
            "#define TIMBER_MODEL_H",
            "",
            "#include <stdint.h>",
            "#include <stddef.h>",
            "",
            "#ifdef __cplusplus",
            'extern "C" {',
            "#endif",
            "",
            "/* ABI version — bump on breaking changes to the public API. */",
            "#define TIMBER_ABI_VERSION  1",
            '#define TIMBER_VERSION     "0.1.0"',
            "",
            f"#define TIMBER_N_FEATURES {n_features}",
            f"#define TIMBER_N_OUTPUTS  {n_outputs}",
            f"#define TIMBER_N_TREES    {ensemble.n_trees}",
            f"#define TIMBER_MAX_DEPTH  {ensemble.max_depth}",
            "",
            "/* Opaque context — holds compiled model state. */",
            "/* Read-only after init; thread-safe for concurrent inference. */",
            "typedef struct TimberCtx TimberCtx;",
            "",
            "/* Error codes */",
            "#define TIMBER_OK          0",
            "#define TIMBER_ERR_NULL   -1",
            "#define TIMBER_ERR_INIT   -2",
            "#define TIMBER_ERR_BOUNDS -3",
            "",
            "/* Initialize the model context. Call once at startup. */",
            "/* Returns TIMBER_OK on success, negative error code on failure. */",
            "int timber_init(TimberCtx** ctx);",
            "",
            "/* Return the ABI version this library was compiled with. */",
            "int timber_abi_version(void);",
            "",
            "/* Optional logging callback. Set to NULL to disable. */",
            "/* Signature: void my_logger(int level, const char* msg) */",
            "/* Levels: 0=error, 1=warn, 2=info, 3=debug */",
            "typedef void (*timber_log_fn)(int level, const char* msg);",
            "void timber_set_log_callback(timber_log_fn fn);",
            "",
            "/* Return a human-readable string for an error code. */",
            "const char* timber_strerror(int code);",
            "",
            "/* Free the model context. */",
            "void timber_free(TimberCtx* ctx);",
            "",
            "/* Run inference on a batch of samples. */",
            "/*",
            f" *  inputs:    input feature matrix, row-major, shape [n_samples x {n_features}]",
            " *  n_samples: number of samples in the batch",
            f" *  outputs:   output buffer, pre-allocated, shape [n_samples x {n_outputs}]",
            " *  ctx:       model context from timber_init",
            " *",
            " *  Returns 0 on success, non-zero on error.",
            " */",
            "int timber_infer(",
            f"    const {float_type}*  inputs,",
            "    int                  n_samples,",
            f"    {float_type}*        outputs,",
            "    const TimberCtx*     ctx",
            ");",
            "",
            "/* Single-sample inference convenience wrapper. */",
            "int timber_infer_single(",
            f"    const {float_type}  inputs[TIMBER_N_FEATURES],",
            f"    {float_type}        outputs[TIMBER_N_OUTPUTS],",
            "    const TimberCtx*    ctx",
            ");",
            "",
            "#ifdef __cplusplus",
            "}",
            "#endif",
            "",
            "#endif /* TIMBER_MODEL_H */",
        ]
        return "\n".join(lines) + "\n"

    def _emit_data(self, ir: TimberIR, ensemble: TreeEnsembleStage) -> str:
        """Generate model_data.c — static const arrays for tree data."""
        float_type = self._float_type()
        lines = [
            "/* model_data.c — Timber compiled model data */",
            "/* Generated by Timber v0.1 — DO NOT EDIT */",
            "",
            '#include "model.h"',
            "#include <math.h>",
            "",
        ]

        # Emit node data as flat arrays per tree
        # For each tree: feature_indices, thresholds, left_children, right_children, leaf_values
        for tree in ensemble.trees:
            tid = tree.tree_id
            n_nodes = len(tree.nodes)

            # Feature indices
            feat_vals = ", ".join(str(n.feature_index) for n in tree.nodes)
            lines.append(f"static const int32_t tree_{tid}_features[{n_nodes}] = {{{feat_vals}}};")

            # Thresholds
            thresh_vals = ", ".join(self._format_float(n.threshold) for n in tree.nodes)
            lines.append(f"static const {float_type} tree_{tid}_thresholds[{n_nodes}] = {{{thresh_vals}}};")

            # Left children
            left_vals = ", ".join(str(n.left_child) for n in tree.nodes)
            lines.append(f"static const int32_t tree_{tid}_left[{n_nodes}] = {{{left_vals}}};")

            # Right children
            right_vals = ", ".join(str(n.right_child) for n in tree.nodes)
            lines.append(f"static const int32_t tree_{tid}_right[{n_nodes}] = {{{right_vals}}};")

            # Leaf values
            leaf_vals = ", ".join(self._format_float(n.leaf_value) for n in tree.nodes)
            lines.append(f"static const {float_type} tree_{tid}_leaves[{n_nodes}] = {{{leaf_vals}}};")

            # Is-leaf flags
            is_leaf_vals = ", ".join("1" if n.is_leaf else "0" for n in tree.nodes)
            lines.append(f"static const int8_t tree_{tid}_is_leaf[{n_nodes}] = {{{is_leaf_vals}}};")

            # Default-left flags
            def_left_vals = ", ".join("1" if n.default_left else "0" for n in tree.nodes)
            lines.append(f"static const int8_t tree_{tid}_default_left[{n_nodes}] = {{{def_left_vals}}};")

            lines.append(f"#define TREE_{tid}_N_NODES {n_nodes}")
            lines.append("")

        # Base score
        lines.append(f"static const {float_type} TIMBER_BASE_SCORE = {self._format_float(ensemble.base_score)};")

        # Per-class base scores for multiclass models (XGBoost 3.1+ stores per-class vectors)
        if ensemble.objective == Objective.MULTICLASS_CLASSIFICATION and ensemble.n_classes > 2:
            pcbs = ensemble.per_class_base_scores
            if len(pcbs) == ensemble.n_classes:
                bs_vals = ", ".join(self._format_float(v) for v in pcbs)
            else:
                bs_vals = ", ".join("0.0" for _ in range(ensemble.n_classes))
            lines.append(f"static const double TIMBER_CLASS_BASE_SCORES[{ensemble.n_classes}] = {{{bs_vals}}};")

        lines.append("")

        return "\n".join(lines) + "\n"

    def _emit_inference(self, ir: TimberIR, ensemble: TreeEnsembleStage) -> str:
        """Generate model.c — the compiled inference logic."""
        float_type = self._float_type()
        n_features = ensemble.n_features
        n_outputs = 1 if ensemble.n_classes <= 2 else ensemble.n_classes
        n_trees = ensemble.n_trees

        lines = [
            "/* model.c — Timber compiled inference logic */",
            "/* Generated by Timber v0.1 — DO NOT EDIT */",
            "",
            '#include "model.h"',
            "#include <stdint.h>",
            "#include <stddef.h>",
            "#include <string.h>",
            "#include <math.h>",
            "",
        ]

        # Include the data file
        lines.append('#include "model_data.c"')
        lines.append("")

        # Context struct
        lines.extend([
            "/* Context structure — trivial for static models */",
            "struct TimberCtx {",
            "    int initialized;",
            "};",
            "",
            "static struct TimberCtx _default_ctx = {1};",
            "",
        ])

        # Logging, strerror, init, free, ABI
        lines.extend([
            "/* --- Logging --- */",
            "static timber_log_fn _timber_log_cb = NULL;",
            "",
            "void timber_set_log_callback(timber_log_fn fn) { _timber_log_cb = fn; }",
            "",
            "static void timber_log(int level, const char* msg) {",
            "    if (_timber_log_cb) _timber_log_cb(level, msg);",
            "}",
            "",
            "const char* timber_strerror(int code) {",
            '    switch (code) {',
            '        case  0: return "TIMBER_OK";',
            '        case -1: return "TIMBER_ERR_NULL: null pointer argument";',
            '        case -2: return "TIMBER_ERR_INIT: context not initialized";',
            '        case -3: return "TIMBER_ERR_BOUNDS: argument out of bounds";',
            '        default: return "TIMBER_ERR_UNKNOWN";',
            "    }",
            "}",
            "",
            "int timber_abi_version(void) { return TIMBER_ABI_VERSION; }",
            "",
            "int timber_init(TimberCtx** ctx) {",
            "    if (ctx == NULL) {",
            '        timber_log(0, "timber_init: ctx is NULL");',
            "        return TIMBER_ERR_NULL;",
            "    }",
            "    *ctx = &_default_ctx;",
            '    timber_log(2, "timber_init: OK");',
            "    return TIMBER_OK;",
            "}",
            "",
            "void timber_free(TimberCtx* ctx) {",
            "    (void)ctx; /* static allocation, nothing to free */",
            "}",
            "",
        ])

        # Single-tree traversal function
        lines.extend([
            f"static {float_type} traverse_tree(",
            f"    const {float_type}* input,",
            "    const int32_t* features,",
            f"    const {float_type}* thresholds,",
            "    const int32_t* left_children,",
            "    const int32_t* right_children,",
            f"    const {float_type}* leaf_values,",
            "    const int8_t* is_leaf,",
            "    const int8_t* default_left,",
            "    int n_nodes",
            ") {",
            "    int node = 0;",
            f"    int max_iter = {ensemble.max_depth + 2};",
            "    while (max_iter-- > 0) {",
            "        if (node < 0 || node >= n_nodes) return 0.0f;",
            "        if (is_leaf[node]) return leaf_values[node];",
            "",
            "        int feat = features[node];",
            f"        {float_type} val = input[feat];",
            "",
            "        /* NaN handling: follow default direction */",
            "        if (val != val) { /* NaN check */",
            "            node = default_left[node] ? left_children[node] : right_children[node];",
            "        } else if (val < thresholds[node]) {",
            "            node = left_children[node];",
            "        } else {",
            "            node = right_children[node];",
            "        }",
            "    }",
            "    return 0.0f;",
            "}",
            "",
        ])


        # (softmax is inlined in double precision in timber_infer_single)

        # Single-sample inference (unrolled tree calls)
        lines.extend([
            "int timber_infer_single(",
            f"    const {float_type}  inputs[TIMBER_N_FEATURES],",
            f"    {float_type}        outputs[TIMBER_N_OUTPUTS],",
            "    const TimberCtx*    ctx",
            ") {",
            "    (void)ctx;",
        ])

        if ensemble.objective == Objective.MULTICLASS_CLASSIFICATION and ensemble.n_classes > 2:
            # Multi-class: accumulate per-class scores with double precision
            lines.append(f"    double scores[{ensemble.n_classes}];")
            lines.append("    int c;")
            lines.append(f"    for (c = 0; c < {ensemble.n_classes}; c++) scores[c] = TIMBER_CLASS_BASE_SCORES[c];")
            lines.append("")
            lines.append("")

            # Trees are interleaved: tree i contributes to class (i % n_classes)
            for i, tree in enumerate(ensemble.trees):
                cls_idx = i % ensemble.n_classes
                lines.append(
                    f"    scores[{cls_idx}] += (double)traverse_tree(inputs, "
                    f"tree_{tree.tree_id}_features, tree_{tree.tree_id}_thresholds, "
                    f"tree_{tree.tree_id}_left, tree_{tree.tree_id}_right, "
                    f"tree_{tree.tree_id}_leaves, tree_{tree.tree_id}_is_leaf, "
                    f"tree_{tree.tree_id}_default_left, TREE_{tree.tree_id}_N_NODES);"
                )

            # Softmax in double precision
            lines.append("")
            lines.append("    { /* softmax */")
            lines.append("        double max_val = scores[0];")
            lines.append(f"        for (c = 1; c < {ensemble.n_classes}; c++)")
            lines.append("            if (scores[c] > max_val) max_val = scores[c];")
            lines.append("        double denom = 0.0;")
            lines.append(f"        for (c = 0; c < {ensemble.n_classes}; c++) {{")
            lines.append("            scores[c] = exp(scores[c] - max_val);")
            lines.append("            denom += scores[c];")
            lines.append("        }")
            lines.append(f"        for (c = 0; c < {ensemble.n_classes}; c++)")
            lines.append(f"            outputs[c] = ({float_type})(scores[c] / denom);")
            lines.append("    }")
        else:
            # Binary classification or regression: use double accumulator for precision
            lines.append("    double sum = (double)TIMBER_BASE_SCORE;")
            lines.append("")

            for tree in ensemble.trees:
                lines.append(
                    f"    sum += (double)traverse_tree(inputs, "
                    f"tree_{tree.tree_id}_features, tree_{tree.tree_id}_thresholds, "
                    f"tree_{tree.tree_id}_left, tree_{tree.tree_id}_right, "
                    f"tree_{tree.tree_id}_leaves, tree_{tree.tree_id}_is_leaf, "
                    f"tree_{tree.tree_id}_default_left, TREE_{tree.tree_id}_N_NODES);"
                )

            lines.append("")

            if ensemble.objective in (Objective.BINARY_CLASSIFICATION, Objective.REGRESSION_LOGISTIC):
                lines.append(f"    outputs[0] = ({float_type})(1.0 / (1.0 + exp(-sum)));")
            else:
                lines.append(f"    outputs[0] = ({float_type})sum;")

        lines.extend([
            "",
            "    return 0;",
            "}",
            "",
        ])

        # Batched inference
        lines.extend([
            "int timber_infer(",
            f"    const {float_type}*  inputs,",
            "    int                  n_samples,",
            f"    {float_type}*        outputs,",
            "    const TimberCtx*     ctx",
            ") {",
            "    int i;",
            "    if (inputs == NULL || outputs == NULL) return TIMBER_ERR_NULL;",
            "    if (n_samples <= 0) return TIMBER_ERR_BOUNDS;",
            "",
            "    for (i = 0; i < n_samples; i++) {",
            "        int rc = timber_infer_single(",
            "            inputs + i * TIMBER_N_FEATURES,",
            "            outputs + i * TIMBER_N_OUTPUTS,",
            "            ctx",
            "        );",
            "        if (rc != 0) return rc;",
            "    }",
            "    return 0;",
            "}",
        ])

        return "\n".join(lines) + "\n"

    # ------------------------------------------------------------------
    # Linear model emission
    # ------------------------------------------------------------------

    def _emit_header_linear(self, ir: TimberIR, stage: "LinearStage") -> str:
        """Generate model.h for a linear model."""
        n_features = len(stage.weights) // max(stage.n_classes, 1) if stage.multi_weights else len(stage.weights)
        n_outputs = 1 if stage.n_classes <= 2 else stage.n_classes
        float_type = self._float_type()
        lines = self._common_header_prefix(n_features, n_outputs, extra_defines={
            "TIMBER_N_CLASSES": str(max(stage.n_classes, 1)),
        })
        return "\n".join(lines) + "\n"

    def _emit_data_linear(self, ir: TimberIR, stage: "LinearStage") -> str:
        """Generate model_data.c for a linear model."""
        float_type = self._float_type()
        lines = [
            "/* model_data.c — Timber linear model data */",
            "/* Generated by Timber — DO NOT EDIT */",
            "",
            '#include "model.h"',
            "",
        ]
        n_features = len(stage.weights) // max(stage.n_classes, 1) if stage.multi_weights else len(stage.weights)

        if stage.multi_weights:
            n_cls = stage.n_classes
            n_w = len(stage.weights)
            w_str = ", ".join(self._format_float(w) for w in stage.weights)
            lines.append(f"static const {float_type} TIMBER_WEIGHTS[{n_w}] = {{{w_str}}};")
            if stage.biases:
                b_str = ", ".join(self._format_float(b) for b in stage.biases)
                lines.append(f"static const {float_type} TIMBER_BIASES[{n_cls}] = {{{b_str}}};")
            else:
                lines.append(f"static const {float_type} TIMBER_BIASES[{n_cls}] = {{{', '.join(['0.0f']*n_cls)}}};")
        else:
            n_w = len(stage.weights)
            w_str = ", ".join(self._format_float(w) for w in stage.weights)
            lines.append(f"static const {float_type} TIMBER_WEIGHTS[{n_w}] = {{{w_str}}};")
            lines.append(f"static const {float_type} TIMBER_BIAS = {self._format_float(stage.bias)};")
        lines.append("")
        return "\n".join(lines) + "\n"

    def _emit_inference_linear(self, ir: TimberIR, stage: "LinearStage") -> str:
        """Generate model.c for a linear model."""
        float_type = self._float_type()
        n_features = len(stage.weights) // max(stage.n_classes, 1) if stage.multi_weights else len(stage.weights)
        n_outputs = 1 if stage.n_classes <= 2 else stage.n_classes

        lines = [
            "/* model.c — Timber linear model inference */",
            "/* Generated by Timber — DO NOT EDIT */",
            "",
            '#include "model.h"',
            "#include <stdint.h>",
            "#include <stddef.h>",
            "#include <math.h>",
            "",
            '#include "model_data.c"',
            "",
            "struct TimberCtx { int initialized; };",
            "static struct TimberCtx _default_ctx = {1};",
            "",
        ]
        lines += self._common_runtime_fns()
        lines += [
            "int timber_infer_single(",
            f"    const {float_type}  inputs[TIMBER_N_FEATURES],",
            f"    {float_type}        outputs[TIMBER_N_OUTPUTS],",
            "    const TimberCtx*    ctx",
            ") {",
            "    (void)ctx;",
            "    int i;",
        ]

        if stage.multi_weights:
            n_cls = stage.n_classes
            # n_outputs caps writes to the declared output buffer size
            lines.append(f"    double scores[{n_cls}];")
            lines.append(f"    for (i = 0; i < {n_cls}; i++) {{")
            lines.append("        int j;")
            lines.append("        scores[i] = (double)TIMBER_BIASES[i];")
            lines.append(f"        for (j = 0; j < {n_features}; j++)")
            lines.append(f"            scores[i] += (double)TIMBER_WEIGHTS[i * {n_features} + j] * (double)inputs[j];")
            lines.append("    }")
            if stage.activation == "softmax":
                lines += [
                    "    { /* softmax */",
                    "        double max_v = scores[0]; int c;",
                    f"        for (c = 1; c < {n_cls}; c++) if (scores[c] > max_v) max_v = scores[c];",
                    "        double denom = 0.0;",
                    f"        for (c = 0; c < {n_cls}; c++) {{ scores[c] = exp(scores[c] - max_v); denom += scores[c]; }}",
                    f"        for (c = 0; c < {n_outputs}; c++) outputs[c] = ({float_type})(scores[c] / denom);",
                    "    }",
                ]
            else:
                lines.append(f"    for (i = 0; i < {n_outputs}; i++) outputs[i] = ({float_type})scores[i];")
        else:
            lines.append("    double sum = (double)TIMBER_BIAS;")
            lines.append(f"    for (i = 0; i < {n_features}; i++)")
            lines.append("        sum += (double)TIMBER_WEIGHTS[i] * (double)inputs[i];")
            if stage.activation in ("sigmoid", "logistic"):
                lines.append(f"    outputs[0] = ({float_type})(1.0 / (1.0 + exp(-sum)));")
            else:
                lines.append(f"    outputs[0] = ({float_type})sum;")

        lines += ["    return 0;", "}", ""]
        lines += self._batched_infer_fn(float_type)
        return "\n".join(lines) + "\n"

    # ------------------------------------------------------------------
    # SVM emission
    # ------------------------------------------------------------------

    def _emit_header_svm(self, ir: TimberIR, stage: "SVMStage") -> str:
        """Generate model.h for an SVM model."""
        n_outputs = 1 if stage.n_classes <= 2 else stage.n_classes
        lines = self._common_header_prefix(stage.n_features, n_outputs, extra_defines={
            "TIMBER_N_SV": str(stage.n_sv),
            "TIMBER_N_CLASSES": str(stage.n_classes),
        })
        return "\n".join(lines) + "\n"

    def _emit_data_svm(self, ir: TimberIR, stage: "SVMStage") -> str:
        """Generate model_data.c for an SVM model."""
        float_type = self._float_type()
        n_sv = stage.n_sv
        n_features = stage.n_features

        lines = [
            "/* model_data.c — Timber SVM model data */",
            "/* Generated by Timber — DO NOT EDIT */",
            "",
            '#include "model.h"',
            "",
        ]

        # Support vectors — row-major [n_sv x n_features]
        sv_flat = [v for sv in stage.support_vectors for v in sv]
        sv_str = ", ".join(self._format_float(v) for v in sv_flat)
        lines.append(f"static const {float_type} TIMBER_SV[{n_sv * n_features}] = {{{sv_str}}};")

        # Dual coefficients
        dc_str = ", ".join(self._format_float(v) for v in stage.dual_coef)
        lines.append(f"static const {float_type} TIMBER_DUAL_COEF[{len(stage.dual_coef)}] = {{{dc_str}}};")

        # Rho (bias)
        rho_str = ", ".join(self._format_float(v) for v in stage.rho)
        n_rho = max(len(stage.rho), 1)
        lines.append(f"static const {float_type} TIMBER_RHO[{n_rho}] = {{{rho_str or '0.0f'}}};")

        # Kernel parameters
        lines.append(f"static const {float_type} TIMBER_GAMMA = {self._format_float(stage.gamma)};")
        lines.append(f"static const {float_type} TIMBER_COEF0 = {self._format_float(stage.coef0)};")
        lines.append(f"static const int32_t TIMBER_DEGREE = {stage.degree};")
        lines.append("")
        return "\n".join(lines) + "\n"

    def _emit_inference_svm(self, ir: TimberIR, stage: "SVMStage") -> str:
        """Generate model.c for an SVM model."""
        float_type = self._float_type()
        n_sv = stage.n_sv
        n_features = stage.n_features
        n_outputs = 1 if stage.n_classes <= 2 else stage.n_classes
        kernel = stage.kernel_type.lower()

        lines = [
            "/* model.c — Timber SVM inference */",
            "/* Generated by Timber — DO NOT EDIT */",
            "",
            '#include "model.h"',
            "#include <stdint.h>",
            "#include <stddef.h>",
            "#include <math.h>",
            "",
            '#include "model_data.c"',
            "",
            "struct TimberCtx { int initialized; };",
            "static struct TimberCtx _default_ctx = {1};",
            "",
        ]
        lines += self._common_runtime_fns()

        # Kernel function
        lines += [
            f"static double timber_kernel(const {float_type}* x, const {float_type}* sv, int n) {{",
            "    int i;",
        ]
        if kernel == "rbf":
            lines += [
                "    double dist = 0.0;",
                "    for (i = 0; i < n; i++) {",
                "        double d = (double)x[i] - (double)sv[i];",
                "        dist += d * d;",
                "    }",
                "    return exp(-(double)TIMBER_GAMMA * dist);",
            ]
        elif kernel == "linear":
            lines += [
                "    double dot = 0.0;",
                "    for (i = 0; i < n; i++) dot += (double)x[i] * (double)sv[i];",
                "    return dot;",
            ]
        elif kernel == "poly":
            lines += [
                "    double dot = 0.0;",
                "    for (i = 0; i < n; i++) dot += (double)x[i] * (double)sv[i];",
                "    double base = (double)TIMBER_GAMMA * dot + (double)TIMBER_COEF0;",
                "    double result = 1.0; int d;",
                "    for (d = 0; d < TIMBER_DEGREE; d++) result *= base;",
                "    return result;",
            ]
        else:  # sigmoid
            lines += [
                "    double dot = 0.0;",
                "    for (i = 0; i < n; i++) dot += (double)x[i] * (double)sv[i];",
                "    return tanh((double)TIMBER_GAMMA * dot + (double)TIMBER_COEF0);",
            ]
        lines += ["}", ""]

        # Inference function
        lines += [
            "int timber_infer_single(",
            f"    const {float_type}  inputs[TIMBER_N_FEATURES],",
            f"    {float_type}        outputs[TIMBER_N_OUTPUTS],",
            "    const TimberCtx*    ctx",
            ") {",
            "    (void)ctx;",
            "    int sv;",
            "    double decision = (double)TIMBER_RHO[0];",
            f"    for (sv = 0; sv < {n_sv}; sv++) {{",
            f"        decision += (double)TIMBER_DUAL_COEF[sv] * timber_kernel(inputs, TIMBER_SV + sv * {n_features}, {n_features});",
            "    }",
        ]
        if stage.post_transform == "logistic":
            lines.append(f"    outputs[0] = ({float_type})(1.0 / (1.0 + exp(-decision)));")
        else:
            lines.append(f"    outputs[0] = ({float_type})decision;")
        lines += ["    return 0;", "}", ""]
        lines += self._batched_infer_fn(float_type)
        return "\n".join(lines) + "\n"

    # ------------------------------------------------------------------
    # Shared helpers for header / runtime
    # ------------------------------------------------------------------

    def _common_header_prefix(
        self, n_features: int, n_outputs: int, extra_defines: dict | None = None
    ) -> list:
        """Return common header lines shared by tree/linear/SVM headers."""
        float_type = self._float_type()
        lines = [
            "/* model.h — Timber compiled model inference header */",
            "/* Generated by Timber — DO NOT EDIT */",
            "",
            "#ifndef TIMBER_MODEL_H",
            "#define TIMBER_MODEL_H",
            "",
            "#include <stdint.h>",
            "#include <stddef.h>",
            "",
            "#ifdef __cplusplus",
            'extern "C" {',
            "#endif",
            "",
            "#define TIMBER_ABI_VERSION  1",
            '#define TIMBER_VERSION     "0.1.0"',
            "",
            f"#define TIMBER_N_FEATURES {n_features}",
            f"#define TIMBER_N_OUTPUTS  {n_outputs}",
        ]
        if extra_defines:
            for k, v in extra_defines.items():
                lines.append(f"#define {k} {v}")
        lines += [
            "",
            "typedef struct TimberCtx TimberCtx;",
            "",
            "#define TIMBER_OK          0",
            "#define TIMBER_ERR_NULL   -1",
            "#define TIMBER_ERR_INIT   -2",
            "#define TIMBER_ERR_BOUNDS -3",
            "",
            "int timber_init(TimberCtx** ctx);",
            "int timber_abi_version(void);",
            "typedef void (*timber_log_fn)(int level, const char* msg);",
            "void timber_set_log_callback(timber_log_fn fn);",
            "const char* timber_strerror(int code);",
            "void timber_free(TimberCtx* ctx);",
            "",
            "int timber_infer(",
            f"    const {float_type}*  inputs,",
            "    int                  n_samples,",
            f"    {float_type}*        outputs,",
            "    const TimberCtx*     ctx",
            ");",
            "",
            "int timber_infer_single(",
            f"    const {float_type}  inputs[TIMBER_N_FEATURES],",
            f"    {float_type}        outputs[TIMBER_N_OUTPUTS],",
            "    const TimberCtx*    ctx",
            ");",
            "",
            "#ifdef __cplusplus",
            "}",
            "#endif",
            "",
            "#endif /* TIMBER_MODEL_H */",
        ]
        return lines

    def _common_runtime_fns(self) -> list:
        """Return shared runtime (logging, init, free, strerror) lines."""
        return [
            "static timber_log_fn _timber_log_cb = NULL;",
            "void timber_set_log_callback(timber_log_fn fn) { _timber_log_cb = fn; }",
            "static void timber_log(int level, const char* msg) {",
            "    if (_timber_log_cb) _timber_log_cb(level, msg);",
            "}",
            "const char* timber_strerror(int code) {",
            "    switch (code) {",
            '        case  0: return "TIMBER_OK";',
            '        case -1: return "TIMBER_ERR_NULL: null pointer argument";',
            '        case -2: return "TIMBER_ERR_INIT: context not initialized";',
            '        case -3: return "TIMBER_ERR_BOUNDS: argument out of bounds";',
            '        default: return "TIMBER_ERR_UNKNOWN";',
            "    }",
            "}",
            "int timber_abi_version(void) { return TIMBER_ABI_VERSION; }",
            "int timber_init(TimberCtx** ctx) {",
            "    if (ctx == NULL) return TIMBER_ERR_NULL;",
            "    *ctx = &_default_ctx;",
            "    timber_log(2, \"timber_init: OK\");",
            "    return TIMBER_OK;",
            "}",
            "void timber_free(TimberCtx* ctx) { (void)ctx; }",
            "",
        ]

    def _batched_infer_fn(self, float_type: str) -> list:
        """Return the batched timber_infer function lines."""
        return [
            "int timber_infer(",
            f"    const {float_type}*  inputs,",
            "    int                  n_samples,",
            f"    {float_type}*        outputs,",
            "    const TimberCtx*     ctx",
            ") {",
            "    int i;",
            "    if (inputs == NULL || outputs == NULL) return TIMBER_ERR_NULL;",
            "    if (n_samples <= 0) return TIMBER_ERR_BOUNDS;",
            "    for (i = 0; i < n_samples; i++) {",
            "        int rc = timber_infer_single(",
            "            inputs + i * TIMBER_N_FEATURES,",
            "            outputs + i * TIMBER_N_OUTPUTS,",
            "            ctx",
            "        );",
            "        if (rc != 0) return rc;",
            "    }",
            "    return 0;",
            "}",
        ]

    def _emit_cmake(self, ir: TimberIR) -> str:
        """Generate CMakeLists.txt for the compiled model."""
        lines = [
            "# CMakeLists.txt — Timber compiled model",
            "# Generated by Timber v0.1",
            "",
            "cmake_minimum_required(VERSION 3.10)",
            "project(timber_model C)",
            "",
            "set(CMAKE_C_STANDARD 99)",
            "set(CMAKE_C_STANDARD_REQUIRED ON)",
            "",
            "# Shared library",
            "add_library(timber_model SHARED model.c)",
            "target_include_directories(timber_model PUBLIC ${CMAKE_CURRENT_SOURCE_DIR})",
            "",
            "# Static library",
            "add_library(timber_model_static STATIC model.c)",
            "target_include_directories(timber_model_static PUBLIC ${CMAKE_CURRENT_SOURCE_DIR})",
            "set_target_properties(timber_model_static PROPERTIES OUTPUT_NAME timber_model)",
            "",
        ]

        # Add architecture-specific flags
        if "avx512f" in self.target.features:
            lines.append('target_compile_options(timber_model PRIVATE "-mavx512f" "-mavx512bw")')
            lines.append('target_compile_options(timber_model_static PRIVATE "-mavx512f" "-mavx512bw")')
        elif "avx2" in self.target.features:
            lines.append('target_compile_options(timber_model PRIVATE "-mavx2" "-mfma")')
            lines.append('target_compile_options(timber_model_static PRIVATE "-mavx2" "-mfma")')

        lines.extend([
            "",
            "# Optimization flags",
            'target_compile_options(timber_model PRIVATE "-O3" "-DNDEBUG")',
            'target_compile_options(timber_model_static PRIVATE "-O3" "-DNDEBUG")',
        ])

        return "\n".join(lines) + "\n"

    def _emit_makefile(self, ir: TimberIR) -> str:
        """Generate Makefile supporting both host and embedded cross-compilation."""
        t = self.target

        # Architecture-specific SIMD flags (host only)
        simd_flags = ""
        if not t.embedded:
            if "avx512f" in t.features:
                simd_flags = "-mavx512f -mavx512bw"
            elif "avx2" in t.features:
                simd_flags = "-mavx2 -mfma"

        cc = f"{t.cross_prefix}gcc" if t.cross_prefix else "gcc"
        ar = f"{t.cross_prefix}ar" if t.cross_prefix else "ar"

        cpu_flags = t.cpu_flags or simd_flags
        extra = t.extra_flags or ""

        base_cflags = f"-std=c99 -O2 -DNDEBUG -Wall -Wextra {cpu_flags} {extra}".strip()

        if t.embedded:
            lines = [
                "# Makefile — Timber compiled model (embedded target)",
                f"# Target: {t.arch}  ABI: {t.abi}",
                "# Generated by Timber — DO NOT EDIT",
                "",
                f"CC  = {cc}",
                f"AR  = {ar}",
                f"CFLAGS = {base_cflags}",
                "",
                ".PHONY: all clean",
                "",
                "all: libtimber_model.a timber_model.o",
                "",
                "timber_model.o: model.c model_data.c model.h",
                "\t$(CC) $(CFLAGS) -c -o $@ model.c",
                "",
                "libtimber_model.a: timber_model.o",
                "\t$(AR) rcs $@ timber_model.o",
                "",
                "clean:",
                "\trm -f *.o *.a",
            ]
        else:
            fpic = "-fPIC"
            lines = [
                "# Makefile — Timber compiled model",
                "# Generated by Timber — DO NOT EDIT",
                "",
                "CC ?= gcc",
                f"CFLAGS = -std=c99 -O3 -DNDEBUG {fpic} -Wall -Wextra {cpu_flags}".strip(),
                "",
                ".PHONY: all clean",
                "",
                "all: libtimber_model.so libtimber_model.a",
                "",
                "libtimber_model.so: model.c model_data.c model.h",
                "\t$(CC) $(CFLAGS) -shared -o $@ model.c -lm",
                "",
                "libtimber_model.a: model.c model_data.c model.h",
                "\t$(CC) $(CFLAGS) -c -o model.o model.c",
                "\tar rcs $@ model.o",
                "",
                "clean:",
                "\trm -f *.o *.so *.a",
            ]

        return "\n".join(lines) + "\n"

    def _float_type(self) -> str:
        if self.target.precision == PrecisionMode.FLOAT16:
            return "_Float16"
        return "float"

    @staticmethod
    def _format_float(value: float) -> str:
        if value == 0.0:
            return "0.0f"
        s = f"{value:.10g}"
        # Ensure there's a decimal point so the 'f' suffix is valid C
        if "." not in s and "e" not in s and "E" not in s:
            s += ".0"
        return s + "f"
