import UserModel from '@girder/core/models/UserModel';

import extendModel from './extendModel';

extendModel(UserModel, 'user');
