"""FlaskSpark views package."""
