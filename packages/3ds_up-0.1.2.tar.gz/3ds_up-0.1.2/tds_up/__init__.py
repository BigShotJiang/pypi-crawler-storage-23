"""3ds-up: Safe updater for Nintendo 3DS on macOS."""

__version__ = "0.1.2"
