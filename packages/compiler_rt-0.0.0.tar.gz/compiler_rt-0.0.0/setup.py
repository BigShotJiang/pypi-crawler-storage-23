"""
Empty setup.py for compiler-rt
Target: HackerOne Bug Bounty - Meta (Facebook)
"""
from setuptools import setup

setup(
    name="compiler-rt",
    version="0.0.0",
    description="Empty placeholder package - reserved for Meta (Facebook)",
    author="Package Protector",
    author_email="protector@example.com",
    py_modules=[],
)
