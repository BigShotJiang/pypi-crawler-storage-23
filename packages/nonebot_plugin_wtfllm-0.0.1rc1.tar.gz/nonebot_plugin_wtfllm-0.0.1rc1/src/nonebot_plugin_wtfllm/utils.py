__all__ = [
    "logger",
    "DATABASE_DATA_DIR",
    "APP_CONFIG",
    "VECTOR_DATABASE_DIR",
    "MEMES_DIR",
    "MODELS_DIR",
    "MEDIA_DIR",
    "RESOURCES_DIR",
    "JSON_DIR",
    "SCHEDULED_CACHE_DIR",
    "get_agent_id_from_bot",
    "get_bot_by_agent_id",
    "build_min_target",
    "ensure_msgid_from_receipt",
    "get_http_client",
    "init_http_client",
    "shutdown_http_client",
    "count_tokens",
    "extract_session_info",
]
import uuid
from pathlib import Path
from importlib import resources
from typing import Final, TypedDict

import httpx
import tiktoken

from nonebot import logger, get_bot, get_bots
from nonebot.adapters import Bot
from nonebot_plugin_uninfo import Session
from nonebot_plugin_alconna import Target
from nonebot_plugin_alconna.uniseg import Receipt
from nonebot_plugin_localstore import get_plugin_data_dir, get_plugin_cache_dir

from .config import APP_CONFIG

_tiktoken_encoding = tiktoken.get_encoding("cl100k_base")


BASE_DATABASE_DIR: Final[Path] = get_plugin_data_dir() / "database"
DATABASE_DATA_DIR: Final[Path] = BASE_DATABASE_DIR / "db"
VECTOR_DATABASE_DIR: Final[Path] = BASE_DATABASE_DIR / "vector_db"
JSON_DIR: Final[Path] = get_plugin_data_dir() / "json"
MEMES_DIR: Final[Path] = get_plugin_data_dir() / "memes"
MEDIA_DIR: Final[Path] = get_plugin_data_dir() / "media"
SCHEDULED_CACHE_DIR: Final[Path] = get_plugin_cache_dir() / "schedule"


MODELS_DIR: Final[Path] = get_plugin_data_dir() / "models"  # 无用。Qdrant只能读默认路径
RESOURCES_DIR: Final[Path] = (
    Path(str(resources.files(__package__).joinpath("resources")))
    if __package__
    else Path(__file__).parent / "resources"
)

_paths = [
    BASE_DATABASE_DIR,
    DATABASE_DATA_DIR,
    VECTOR_DATABASE_DIR,
    JSON_DIR,
    MEMES_DIR,
    SCHEDULED_CACHE_DIR,
    MEDIA_DIR,
    # MODELS_DIR,
]


for path in _paths:
    path.mkdir(parents=True, exist_ok=True)

_bots_cache: dict[str, Bot] = {}


def get_agent_id_from_bot(bot_or_session: Bot | Session) -> str:
    """从 Bot ID 中提取 Agent ID"""
    new_bot_id = bot_or_session.self_id.removeprefix("llonebot:").removeprefix(
        "napcat:"
    )
    _bots_cache[new_bot_id] = get_bot(bot_or_session.self_id)
    return new_bot_id


def get_bot_by_agent_id(agent_id: str) -> Bot:
    """根据 Agent ID 获取 Bot 实例"""
    if agent_id in _bots_cache:
        return _bots_cache[agent_id]
    else:
        for bot in get_bots().values():
            if get_agent_id_from_bot(bot) == agent_id:
                return bot
        raise ValueError(f"No bot found for agent_id: {agent_id}")


def build_min_target(
    agent_id: str | None, group_id: str | None = None, user_id: str | None = None
) -> Target:
    raw_bot_id = get_bot_by_agent_id(agent_id).self_id if agent_id is not None else None
    if group_id:
        return Target(id=group_id, private=False, self_id=raw_bot_id)
    elif user_id:
        return Target(id=user_id, private=True, self_id=raw_bot_id)
    raise ValueError("Must provide one of group_id or user_id")


def ensure_msgid_from_receipt(
    receipt: Receipt, session: Session | None = None
) -> str:  # session备用
    """从发送回执中提取消息 ID, 不保证返回真实消息 ID"""
    reply = receipt.get_reply(-1)
    if reply is None:
        msg_id = f"fake_{uuid.uuid4().hex}"
    else:
        msg_id = reply.id
    # 无奈了，milky 根本没提供真实消息 ID
    return msg_id


_http_client: httpx.AsyncClient | None = None


def get_http_client() -> httpx.AsyncClient:
    """获取全局 HTTP 客户端"""
    if _http_client is None:
        raise RuntimeError(
            "HTTP client is not initialized. Ensure init_http_client() was called on startup."
        )
    return _http_client


async def init_http_client() -> None:
    """初始化全局 HTTP 客户端"""
    global _http_client
    _http_client = httpx.AsyncClient(follow_redirects=True, timeout=60)


async def shutdown_http_client() -> None:
    """关闭全局 HTTP 客户端"""
    global _http_client
    if _http_client is not None:
        await _http_client.aclose()
        _http_client = None


def count_tokens(text: str) -> int:
    """计算文本的 token 数"""
    return len(_tiktoken_encoding.encode(text))


class SessionInfo(TypedDict):
    user_id: str
    group_id: str | None


def extract_session_info(session: Session) -> SessionInfo:
    """从 Session 中提取 ID"""
    # guild 和 channel 的专门支持还是洗洗睡吧，多少有点折磨
    is_private = False
    if "private" in session.scene_path:  # llob下satori行为，私聊会给 group_id
        is_private = True
    if session.scene.is_private or is_private:
        return SessionInfo(user_id=session.user.id, group_id=None)
    else:
        return SessionInfo(user_id=session.user.id, group_id=session.scene_path)
