export const SUPPORTED_IMAGE_TYPES = [
  "image/png",
  "image/jpeg",
  "image/gif",
  "image/webp",
] as const;

export const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB

export type AttachedFile = {
  id: string;
  file: File;
  preview: string; // object URL for thumbnail
  base64: string; // data URI for API
  mimeType: string;
};

export function validateFile(file: File): string | null {
  if (!SUPPORTED_IMAGE_TYPES.includes(file.type as (typeof SUPPORTED_IMAGE_TYPES)[number])) {
    return `지원하지 않는 파일 형식입니다: ${file.type || "unknown"}. PNG, JPG, GIF, WebP만 가능합니다.`;
  }
  if (file.size > MAX_FILE_SIZE) {
    return `파일 크기가 10MB를 초과합니다: ${(file.size / 1024 / 1024).toFixed(1)}MB`;
  }
  return null;
}

export function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error("파일 읽기에 실패했습니다."));
    reader.readAsDataURL(file);
  });
}
