import json
import logging
from typing import List, Dict, Any, AsyncGenerator

from nexus_agent.core.llm import llm_client
from nexus_agent.core.mcp_manager import mcp_manager, parse_namespaced_tool
from nexus_agent.core.memory_manager import memory_manager
from nexus_agent.core.skill_manager import skill_manager, SKILL_TOOL_NAMES
from nexus_agent.core.workspace_tools import (
    WORKSPACE_TOOL_NAMES,
    get_workspace_tools,
    handle_workspace_tool_call,
    get_workspace_system_prompt,
)

logger = logging.getLogger(__name__)

MAX_TOOL_ROUNDS = 10

SKILL_SYSTEM_PROMPT = """당신은 Nexus Agent 플랫폼의 AI 어시스턴트입니다.
아래 등록된 스킬을 활용하여 사용자를 도울 수 있습니다.

## 스킬 사용 방법
1. 사용자의 요청을 분석하여 관련 스킬이 있는지 확인합니다
2. 관련 스킬이 있으면 read_skill 도구로 전체 지시사항을 읽고 따릅니다
3. 스킬의 scripts/ 디렉토리에 실행 스크립트가 있으면 run_skill_script로 활용합니다
4. references/ 디렉토리의 참조 문서가 필요하면 read_skill_reference로 로드합니다

## 스킬 자동 생성
유용한 워크플로우나 도구 로직을 발견하면 create_skill과 add_skill_script로 스킬을 생성하여 재사용하세요.
예: 문서 변환(pptx→텍스트), 데이터 분석 파이프라인, 반복 작업 자동화 등.
사용자가 "이걸 스킬로 만들어줘" 또는 "이 로직을 저장해줘"라고 요청하면 적극적으로 스킬을 생성하세요.

{available_skills_xml}"""


class AgentOrchestrator:
    def __init__(self):
        self.llm = llm_client

    def _build_system_prompt(self) -> str | None:
        parts = []

        # 사용자 커스텀 시스템 프롬프트
        custom = self.llm.get_system_prompt()
        if custom:
            parts.append(custom)

        # 장기 기억 주입
        memory_prompt = memory_manager.build_memory_prompt()
        if memory_prompt:
            parts.append(memory_prompt)

        # 스킬 시스템 프롬프트 (스킬이 없어도 create_skill 안내를 위해 항상 포함)
        skills_xml = skill_manager.generate_skills_xml()
        parts.append(SKILL_SYSTEM_PROMPT.format(available_skills_xml=skills_xml))

        # 워크스페이스 시스템 프롬프트
        workspace_prompt = get_workspace_system_prompt()
        if workspace_prompt:
            parts.append(workspace_prompt)

        return "\n\n".join(parts) if parts else None

    async def _execute_tool_call(self, tool_call: Dict[str, Any]) -> str:
        """단일 도구 호출 실행 및 결과 반환"""
        function_name = tool_call["function"]["name"]
        arguments_str = tool_call["function"]["arguments"]

        args = json.loads(arguments_str) if isinstance(arguments_str, str) else arguments_str

        if function_name in SKILL_TOOL_NAMES:
            return await skill_manager.handle_tool_call(function_name, args)
        elif function_name in WORKSPACE_TOOL_NAMES:
            return await handle_workspace_tool_call(function_name, args)
        else:
            try:
                server_name, tool_name = parse_namespaced_tool(function_name)
                return await mcp_manager.call_tool(server_name, tool_name, args)
            except ValueError:
                return f"Error: Invalid tool name format '{function_name}'"

    async def run(self, messages: List[Dict[str, Any]]) -> Dict[str, Any]:
        # Shallow copy to avoid mutating the caller's list
        messages = list(messages)

        # Inject system prompt with skill metadata
        system_prompt = self._build_system_prompt()
        if system_prompt:
            messages = [{"role": "system", "content": system_prompt}] + messages

        # Merge MCP tools + skill tools + workspace tools
        active_tools = await mcp_manager.get_all_tools()
        skill_tools = skill_manager.get_skill_tools()
        workspace_tools = get_workspace_tools()
        all_tools = active_tools + skill_tools + workspace_tools

        # Multi-round tool call loop
        for round_num in range(MAX_TOOL_ROUNDS + 1):
            response = await self.llm.chat_completion(
                messages, tools=all_tools if all_tools else None
            )

            message = response["choices"][0]["message"]

            # No tool calls — return final response
            if not message.get("tool_calls"):
                return response

            # Safety: max rounds reached
            if round_num >= MAX_TOOL_ROUNDS:
                logger.warning("Max tool call rounds (%d) reached, returning last response", MAX_TOOL_ROUNDS)
                return response

            # Process tool calls
            tool_calls = message["tool_calls"]
            messages.append(message)

            for tool_call in tool_calls:
                function_name = tool_call["function"]["name"]
                tool_call_id = tool_call["id"]

                try:
                    result = await self._execute_tool_call(tool_call)
                except Exception as e:
                    logger.error("Tool call error (%s): %s", function_name, e)
                    result = f"Error: {e}"

                messages.append({
                    "role": "tool",
                    "tool_call_id": tool_call_id,
                    "name": function_name,
                    "content": str(result),
                })

            logger.debug("Tool round %d complete, %d tool(s) executed", round_num + 1, len(tool_calls))

        return response

    async def run_stream(self, messages: List[Dict[str, Any]]) -> AsyncGenerator[Dict[str, Any], None]:
        """run()과 동일한 로직이지만 각 단계를 SSE 이벤트로 yield하는 제너레이터."""
        messages = list(messages)

        system_prompt = self._build_system_prompt()
        if system_prompt:
            messages = [{"role": "system", "content": system_prompt}] + messages

        active_tools = await mcp_manager.get_all_tools()
        skill_tools = skill_manager.get_skill_tools()
        workspace_tools = get_workspace_tools()
        all_tools = active_tools + skill_tools + workspace_tools

        for round_num in range(MAX_TOOL_ROUNDS + 1):
            yield {"type": "thinking", "content": f"LLM 호출 중... (라운드 {round_num + 1})"}

            response = await self.llm.chat_completion(
                messages, tools=all_tools if all_tools else None
            )

            message = response["choices"][0]["message"]

            if not message.get("tool_calls"):
                yield {"type": "content", "content": message.get("content", "")}
                yield {"type": "done", "full_response": response}
                return

            if round_num >= MAX_TOOL_ROUNDS:
                logger.warning("Max tool call rounds (%d) reached, returning last response", MAX_TOOL_ROUNDS)
                yield {"type": "content", "content": message.get("content", "")}
                yield {"type": "done", "full_response": response}
                return

            tool_calls = message["tool_calls"]
            messages.append(message)

            for tool_call in tool_calls:
                function_name = tool_call["function"]["name"]
                tool_call_id = tool_call["id"]

                yield {
                    "type": "tool_call",
                    "name": function_name,
                    "arguments": tool_call["function"]["arguments"],
                }

                try:
                    result = await self._execute_tool_call(tool_call)
                except Exception as e:
                    logger.error("Tool call error (%s): %s", function_name, e)
                    result = f"Error: {e}"

                messages.append({
                    "role": "tool",
                    "tool_call_id": tool_call_id,
                    "name": function_name,
                    "content": str(result),
                })

                yield {
                    "type": "tool_result",
                    "name": function_name,
                    "result": str(result)[:200],
                }

            logger.debug("Tool round %d complete, %d tool(s) executed", round_num + 1, len(tool_calls))


orchestrator = AgentOrchestrator()
