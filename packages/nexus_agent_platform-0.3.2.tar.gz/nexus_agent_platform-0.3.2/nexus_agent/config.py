import json
from pathlib import Path


def get_data_dir() -> Path:
    """~/.nexus-agent/ 데이터 디렉토리 반환, 없으면 생성"""
    data_dir = Path.home() / ".nexus-agent"
    data_dir.mkdir(parents=True, exist_ok=True)
    return data_dir


def get_config_path(filename: str) -> Path:
    return get_data_dir() / filename


def get_pages_dir() -> Path:
    d = get_data_dir() / "pages"
    d.mkdir(parents=True, exist_ok=True)
    return d


def get_skills_dir() -> Path:
    d = get_data_dir() / "skills"
    d.mkdir(parents=True, exist_ok=True)
    return d


def get_sessions_dir() -> Path:
    d = get_data_dir() / "sessions"
    d.mkdir(parents=True, exist_ok=True)
    return d


def init_data_dir() -> Path:
    """초기 설정 파일 생성. 이미 존재하는 파일은 건드리지 않음."""
    data_dir = get_data_dir()

    defaults = {
        "mcp.json": {"mcpServers": {}},
        "settings.json": {"llm": {
            "model": "gemini/gemini-2.0-flash",
            "temperature": 0.7,
            "max_tokens": 4096,
            "system_prompt": "",
        }},
        "skills.json": {"disabled": []},
        "pages.json": {"pages": {}},
        "sessions.json": {"sessions": {}},
        "memories.json": {"memories": []},
        "workspaces.json": {"workspaces": {}},
    }

    for filename, content in defaults.items():
        path = data_dir / filename
        if not path.exists():
            path.write_text(json.dumps(content, indent=2, ensure_ascii=False) + "\n")

    # .env 템플릿
    env_path = data_dir / ".env"
    if not env_path.exists():
        env_path.write_text(
            "# 사용할 LLM 프로바이더의 API 키를 설정하세요\n"
            "# GOOGLE_API_KEY=your-google-api-key\n"
            "# OPENAI_API_KEY=your-openai-api-key\n"
            "# ANTHROPIC_API_KEY=your-anthropic-api-key\n"
            "# XAI_API_KEY=your-xai-api-key\n"
        )

    # 디렉토리 생성
    get_pages_dir()
    get_skills_dir()
    get_sessions_dir()

    return data_dir
