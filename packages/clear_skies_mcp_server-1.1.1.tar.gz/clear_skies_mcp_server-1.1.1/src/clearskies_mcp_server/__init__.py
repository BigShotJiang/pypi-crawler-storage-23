"""clearskies MCP server - provides code generation, documentation, and scaffolding tools for the clearskies framework."""

from clearskies_mcp_server.server import main

__all__ = ["main"]
