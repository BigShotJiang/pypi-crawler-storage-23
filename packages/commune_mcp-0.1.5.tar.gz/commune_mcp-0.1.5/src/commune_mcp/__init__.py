"""Commune MCP Server — email infrastructure tools for AI agents."""

from commune_mcp.server import mcp, main

__all__ = ["mcp", "main"]
