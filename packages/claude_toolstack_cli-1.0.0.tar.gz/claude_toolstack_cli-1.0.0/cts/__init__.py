"""cts — Claude Toolstack CLI client."""

__version__ = "1.0.0"
