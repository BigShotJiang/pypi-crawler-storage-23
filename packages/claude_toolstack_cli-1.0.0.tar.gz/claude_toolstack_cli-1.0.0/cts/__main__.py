"""Entry point: python -m cts."""

from cts.cli import main

main()
