"""
tools.py — Full tool suite for BySalim v2.

New in v2:
  • Media CRUD: images, videos, audio, documents — create, read, rename, delete, convert
  • Image tools: resize, rotate, crop, convert format, get metadata (EXIF)
  • Audio tools: get metadata (artist/album/duration), convert, trim
  • Video tools: get metadata (duration/resolution/codec), extract thumbnail
  • File send: upload any file back to Telegram
  • App launcher: open apps cross-platform (xdg-open / open / start)
  • Fixes: screenshot fallback chain, volume Linux fix, proper async everywhere
  • Auto-installs optional libs at runtime if missing

Rules:
  • Each tool is an async function accepting **kwargs, returning dict.
  • Tools NEVER raise to the caller — all errors become {"error": "..."}.
  • TOOLS registry maps name → {fn, description, danger, send_file}.
  • run_tool(name, args) is the single dispatch entry point.
"""
from __future__ import annotations

import asyncio
import datetime
import json
import mimetypes
import os
import platform
import re
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Callable, Coroutine

import psutil

from .config import TOOL_TIMEOUT
from .logger import get_logger, log_task

log = get_logger("tools")

SYS = platform.system()  # "Darwin" | "Linux" | "Windows"

# ---------------------------------------------------------------------------
# Telegram send-file callback
# ---------------------------------------------------------------------------

_send_callbacks: list[Callable[[str], Coroutine]] = []
_send_file_callbacks: list[Callable[[str, str, str], Coroutine]] = []


def register_send_callback(fn: Callable[[str], Coroutine]) -> None:
    _send_callbacks.append(fn)


def register_send_file_callback(fn: Callable[[str, str, str], Coroutine]) -> None:
    """Register callback(path, caption, file_type) where file_type in photo/audio/video/document."""
    _send_file_callbacks.append(fn)


async def _push(message: str) -> None:
    for cb in _send_callbacks:
        try:
            await cb(message)
        except Exception as exc:
            log.warning("Send callback failed: %s", exc)


async def _push_file(path: str, caption: str = "", file_type: str = "document") -> None:
    for cb in _send_file_callbacks:
        try:
            await cb(path, caption, file_type)
        except Exception as exc:
            log.warning("Send-file callback failed: %s", exc)


# ---------------------------------------------------------------------------
# Lazy import helpers — auto-install on first use
# ---------------------------------------------------------------------------

def _ensure_package(package: str, import_name: str | None = None) -> Any:
    """Import *package*, installing it via pip if missing. Returns the module."""
    name = import_name or package
    try:
        return __import__(name)
    except ImportError:
        log.info("Auto-installing %s…", package)
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "--quiet",
             "--break-system-packages", package],
            check=True, capture_output=True,
        )
        return __import__(name)


def _PIL():
    return _ensure_package("Pillow", "PIL")


def _mutagen():
    return _ensure_package("mutagen")


def _hachoir_parser():
    _ensure_package("hachoir")
    from hachoir.parser import createParser
    return createParser


def _hachoir_meta():
    _ensure_package("hachoir")
    from hachoir.metadata import extractMetadata
    return extractMetadata


def _filetype():
    return _ensure_package("filetype")


def _send2trash():
    return _ensure_package("send2trash")


# ---------------------------------------------------------------------------
# Low-level helpers
# ---------------------------------------------------------------------------

def _run_subprocess(
    cmd: list[str] | str,
    timeout: float = TOOL_TIMEOUT,
    shell: bool = False,
    cwd: str | None = None,
    input_data: bytes | None = None,
) -> dict:
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            shell=shell,
            cwd=cwd,
            input=input_data.decode() if input_data else None,
        )
        return {
            "exit_code": result.returncode,
            "stdout": result.stdout.strip(),
            "stderr": result.stderr.strip(),
        }
    except subprocess.TimeoutExpired:
        return {"error": f"Command timed out after {timeout:.0f}s"}
    except FileNotFoundError as exc:
        return {"error": f"Command not found: {exc}"}
    except PermissionError as exc:
        return {"error": f"Permission denied: {exc}"}
    except Exception as exc:
        return {"error": f"Subprocess error: {exc}"}


def _clamp(value: Any, lo: float, hi: float) -> float:
    return max(lo, min(hi, float(value)))


def _human_size(size_bytes: int) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size_bytes < 1024.0:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.1f} PB"


def _guess_media_type(path: str) -> str:
    """Return 'image'|'video'|'audio'|'document' based on extension + filetype sniffing."""
    p = Path(path)
    ext = p.suffix.lower()
    image_exts = {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".tiff", ".tif", ".heic", ".heif", ".svg", ".ico", ".avif"}
    video_exts = {".mp4", ".mkv", ".avi", ".mov", ".wmv", ".flv", ".webm", ".m4v", ".3gp", ".ts", ".mts"}
    audio_exts = {".mp3", ".flac", ".wav", ".aac", ".ogg", ".m4a", ".wma", ".opus", ".aiff", ".alac"}
    if ext in image_exts:
        return "image"
    if ext in video_exts:
        return "video"
    if ext in audio_exts:
        return "audio"
    try:
        ft = _filetype()
        kind = ft.guess(path)
        if kind:
            if kind.mime.startswith("image/"):
                return "image"
            if kind.mime.startswith("video/"):
                return "video"
            if kind.mime.startswith("audio/"):
                return "audio"
    except Exception:
        pass
    return "document"


def _resolve(path: str) -> Path:
    return Path(path).expanduser().resolve()


# ===========================================================================
# SYSTEM TOOLS (kept + fixed)
# ===========================================================================

async def tool_system_health(**kwargs) -> dict:
    try:
        loop = asyncio.get_event_loop()
        cpu = await loop.run_in_executor(None, psutil.cpu_percent, 1)
        mem = psutil.virtual_memory()
        disk = psutil.disk_usage("/")
        swap = psutil.swap_memory()
        all_procs = list(psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent"]))
        procs = []
        for p in all_procs:
            try:
                info = p.info
                procs.append({
                    "pid": info["pid"],
                    "name": info.get("name") or "?",
                    "cpu_pct": round(info.get("cpu_percent") or 0.0, 1),
                    "mem_pct": round(info.get("memory_percent") or 0.0, 1),
                })
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        top = sorted(procs, key=lambda x: x["cpu_pct"], reverse=True)[:5]
        return {
            "cpu_percent": round(cpu, 1),
            "cpu_count": psutil.cpu_count(logical=True),
            "ram_total_gb": round(mem.total / 1e9, 2),
            "ram_used_gb": round(mem.used / 1e9, 2),
            "ram_percent": round(mem.percent, 1),
            "swap_total_gb": round(swap.total / 1e9, 2),
            "swap_used_gb": round(swap.used / 1e9, 2),
            "disk_total_gb": round(disk.total / 1e9, 2),
            "disk_used_gb": round(disk.used / 1e9, 2),
            "disk_percent": round(disk.percent, 1),
            "top_processes": top,
        }
    except Exception as exc:
        return {"error": f"system_health failed: {exc}"}


async def tool_uptime(**kwargs) -> dict:
    try:
        boot_ts = psutil.boot_time()
        delta = datetime.timedelta(seconds=time.time() - boot_ts)
        days = delta.days
        hours, rem = divmod(delta.seconds, 3600)
        minutes, seconds = divmod(rem, 60)
        return {
            "uptime": f"{days}d {hours}h {minutes}m {seconds}s",
            "boot_time": datetime.datetime.fromtimestamp(boot_ts).strftime("%Y-%m-%d %H:%M:%S"),
            "uptime_seconds": int(time.time() - boot_ts),
        }
    except Exception as exc:
        return {"error": f"uptime failed: {exc}"}


async def tool_battery(**kwargs) -> dict:
    try:
        bat = psutil.sensors_battery()
        if bat is None:
            return {"error": "No battery detected"}
        secs = bat.secsleft
        if secs == psutil.POWER_TIME_UNLIMITED:
            time_left = "unlimited (charging)"
        elif secs == psutil.POWER_TIME_UNKNOWN or secs < 0:
            time_left = "unknown"
        else:
            h, m = divmod(secs // 60, 60)
            time_left = f"{h}h {m}m"
        return {"percent": round(bat.percent, 1), "plugged_in": bool(bat.power_plugged), "time_left": time_left}
    except Exception as exc:
        return {"error": f"battery failed: {exc}"}


async def tool_network_stats(**kwargs) -> dict:
    try:
        counters = psutil.net_io_counters()
        ifaces: dict[str, str] = {}
        for name, addrs in psutil.net_if_addrs().items():
            for a in addrs:
                family_name = getattr(a.family, "name", str(a.family))
                if family_name in ("AF_INET", "AF_INET6") and not a.address.startswith("127."):
                    ifaces[name] = a.address
                    break
        try:
            conn_count = len(psutil.net_connections())
        except Exception:
            conn_count = -1
        return {
            "bytes_sent_mb": round(counters.bytes_sent / 1e6, 3),
            "bytes_recv_mb": round(counters.bytes_recv / 1e6, 3),
            "packets_sent": counters.packets_sent,
            "packets_recv": counters.packets_recv,
            "active_connections": conn_count,
            "interfaces": ifaces,
        }
    except Exception as exc:
        return {"error": f"network_stats failed: {exc}"}


async def tool_run_shell(command: str = "", timeout: float = 30.0, **kwargs) -> dict:
    if not command or not command.strip():
        return {"error": "No command provided"}
    timeout = _clamp(timeout, 1.0, 120.0)
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, lambda: _run_subprocess(command, shell=True, timeout=timeout))


async def tool_kill_process(pid: int = 0, name: str = "", signal_num: int = 15, **kwargs) -> dict:
    import signal as _signal
    killed: list[str] = []
    try:
        if pid and pid > 0:
            proc = psutil.Process(int(pid))
            pname = proc.name()
            proc.send_signal(signal_num)
            killed.append(f"PID {pid} ({pname})")
        elif name:
            matched = False
            for p in psutil.process_iter(["pid", "name"]):
                try:
                    if name.lower() in (p.info.get("name") or "").lower():
                        p.send_signal(signal_num)
                        killed.append(f"PID {p.info['pid']} ({p.info['name']})")
                        matched = True
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
            if not matched:
                return {"error": f"No process matched name='{name}'"}
        else:
            return {"error": "Provide pid (int) or name (str)"}
    except psutil.NoSuchProcess:
        return {"error": f"Process not found: pid={pid} name={name}"}
    except psutil.AccessDenied:
        return {"error": "Access denied — try running as root"}
    except Exception as exc:
        return {"error": f"kill_process failed: {exc}"}
    if not killed:
        return {"error": "No processes were killed"}
    return {"killed": killed}


async def tool_list_processes(sort_by: str = "cpu", limit: int = 50, **kwargs) -> dict:
    try:
        procs: list[dict] = []
        for p in psutil.process_iter(["pid", "name", "status", "cpu_percent", "memory_percent", "username"]):
            try:
                info = p.info
                procs.append({
                    "pid": info["pid"],
                    "name": info.get("name") or "?",
                    "status": info.get("status", "?"),
                    "cpu_pct": round(info.get("cpu_percent") or 0.0, 1),
                    "mem_pct": round(info.get("memory_percent") or 0.0, 2),
                    "user": info.get("username", "?"),
                })
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        sort_key = "mem_pct" if sort_by.startswith("mem") else "cpu_pct"
        procs.sort(key=lambda x: x[sort_key], reverse=True)
        return {"processes": procs[:int(_clamp(limit, 1, 200))], "total": len(procs)}
    except Exception as exc:
        return {"error": f"list_processes failed: {exc}"}


# ===========================================================================
# FILE SYSTEM CRUD (enhanced)
# ===========================================================================

async def tool_list_directory(path: str = "~", show_hidden: bool = False, **kwargs) -> dict:
    try:
        p = _resolve(path)
        if not p.exists():
            return {"error": f"Path does not exist: {path}"}
        if not p.is_dir():
            return {"error": f"Not a directory: {p}"}
        items: list[dict] = []
        try:
            entries = sorted(p.iterdir(), key=lambda e: (e.is_file(), e.name.lower()))
        except PermissionError:
            return {"error": f"Permission denied reading: {p}"}
        for entry in entries:
            if not show_hidden and entry.name.startswith("."):
                continue
            try:
                st = entry.stat()
                media_type = _guess_media_type(str(entry)) if entry.is_file() else None
                items.append({
                    "name": entry.name,
                    "type": "file" if entry.is_file() else "dir",
                    "media_type": media_type,
                    "size_bytes": st.st_size if entry.is_file() else None,
                    "size_human": _human_size(st.st_size) if entry.is_file() else None,
                    "modified": datetime.datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M"),
                    "readable": os.access(entry, os.R_OK),
                })
            except (PermissionError, OSError):
                items.append({"name": entry.name, "type": "unknown"})
        return {"path": str(p), "items": items, "count": len(items)}
    except Exception as exc:
        return {"error": f"list_directory failed: {exc}"}


async def tool_read_file(path: str = "", max_lines: int = 150, encoding: str = "utf-8", **kwargs) -> dict:
    if not path:
        return {"error": "No path provided"}
    try:
        p = _resolve(path)
        if not p.exists():
            return {"error": f"File not found: {path}"}
        if not p.is_file():
            return {"error": f"Not a file: {p}"}
        size = p.stat().st_size
        if size > 2_000_000:
            return {"error": f"File too large ({_human_size(size)}). Use a more specific read."}
        text = p.read_text(encoding=encoding, errors="replace")
        lines = text.splitlines()
        max_lines = int(_clamp(max_lines, 1, 1000))
        return {
            "path": str(p),
            "lines": len(lines),
            "content": "\n".join(lines[:max_lines]),
            "truncated": len(lines) > max_lines,
            "size_bytes": size,
            "size_human": _human_size(size),
        }
    except Exception as exc:
        return {"error": f"read_file failed: {exc}"}


async def tool_write_file(path: str = "", content: str = "", append: bool = False, encoding: str = "utf-8", **kwargs) -> dict:
    if not path:
        return {"error": "No path provided"}
    try:
        p = _resolve(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        mode = "a" if append else "w"
        with open(p, mode, encoding=encoding) as f:
            f.write(content)
        return {
            "path": str(p),
            "bytes_written": len(content.encode(encoding)),
            "mode": "append" if append else "overwrite",
        }
    except PermissionError as exc:
        return {"error": f"Permission denied: {exc}"}
    except Exception as exc:
        return {"error": f"write_file failed: {exc}"}


async def tool_delete_file(path: str = "", force: bool = False, trash: bool = True, **kwargs) -> dict:
    """Delete a file or directory. Uses trash by default (recoverable), force=True for permanent."""
    if not path:
        return {"error": "No path provided"}
    try:
        p = _resolve(path)
        if not p.exists():
            return {"error": f"Path does not exist: {path}"}
        if trash and not force:
            try:
                s2t = _send2trash()
                s2t.send2trash(str(p))
                return {"deleted": str(p), "type": "file" if p.is_file() else "directory", "method": "trash"}
            except Exception as exc:
                log.warning("send2trash failed (%s), falling back to permanent delete", exc)
        # Permanent
        if p.is_file() or p.is_symlink():
            p.unlink(missing_ok=True)
            return {"deleted": str(p), "type": "file", "method": "permanent"}
        elif p.is_dir():
            shutil.rmtree(p)
            return {"deleted": str(p), "type": "directory", "method": "permanent"}
        return {"error": f"Unknown path type: {p}"}
    except PermissionError as exc:
        return {"error": f"Permission denied: {exc}"}
    except Exception as exc:
        return {"error": f"delete_file failed: {exc}"}


async def tool_copy_file(src: str = "", dst: str = "", **kwargs) -> dict:
    if not src or not dst:
        return {"error": "Provide both src and dst paths"}
    try:
        s = _resolve(src)
        d = _resolve(dst)
        if not s.exists():
            return {"error": f"Source not found: {src}"}
        d.parent.mkdir(parents=True, exist_ok=True)
        if s.is_file():
            shutil.copy2(s, d)
        elif s.is_dir():
            if d.exists():
                shutil.rmtree(d)
            shutil.copytree(s, d)
        else:
            return {"error": f"Cannot copy: {s}"}
        return {"copied": str(s), "to": str(d)}
    except PermissionError as exc:
        return {"error": f"Permission denied: {exc}"}
    except Exception as exc:
        return {"error": f"copy_file failed: {exc}"}


async def tool_move_file(src: str = "", dst: str = "", **kwargs) -> dict:
    if not src or not dst:
        return {"error": "Provide both src and dst paths"}
    try:
        s = _resolve(src)
        d = _resolve(dst)
        if not s.exists():
            return {"error": f"Source not found: {src}"}
        d.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(s), str(d))
        return {"moved": str(s), "to": str(d)}
    except PermissionError as exc:
        return {"error": f"Permission denied: {exc}"}
    except Exception as exc:
        return {"error": f"move_file failed: {exc}"}


async def tool_rename_file(path: str = "", new_name: str = "", **kwargs) -> dict:
    """Rename a file or folder (keeps it in the same directory)."""
    if not path or not new_name:
        return {"error": "Provide path and new_name"}
    try:
        p = _resolve(path)
        if not p.exists():
            return {"error": f"Path not found: {path}"}
        dest = p.parent / new_name
        if dest.exists():
            return {"error": f"Destination already exists: {dest}"}
        p.rename(dest)
        return {"renamed": str(p), "to": str(dest)}
    except PermissionError as exc:
        return {"error": f"Permission denied: {exc}"}
    except Exception as exc:
        return {"error": f"rename_file failed: {exc}"}


async def tool_search_files(query: str = "", path: str = "~", extension: str = "", max_results: int = 50, **kwargs) -> dict:
    if not query and not extension:
        return {"error": "Provide query or extension"}
    try:
        root = _resolve(path)
        if not root.exists():
            return {"error": f"Search path not found: {path}"}
        if extension and not extension.startswith("."):
            extension = f".{extension}"
        glob_pattern = f"*{query}*" if query else "*"
        matches: list[dict] = []
        max_results = int(_clamp(max_results, 1, 200))
        try:
            for p in root.rglob(glob_pattern):
                if extension and p.suffix.lower() != extension.lower():
                    continue
                try:
                    matches.append({
                        "path": str(p),
                        "type": "file" if p.is_file() else "dir",
                        "media_type": _guess_media_type(str(p)) if p.is_file() else None,
                        "size_bytes": p.stat().st_size if p.is_file() else None,
                        "modified": datetime.datetime.fromtimestamp(p.stat().st_mtime).strftime("%Y-%m-%d %H:%M"),
                    })
                except (PermissionError, OSError):
                    pass
                if len(matches) >= max_results:
                    break
        except PermissionError:
            pass
        return {"matches": matches, "count": len(matches), "root": str(root), "pattern": glob_pattern}
    except Exception as exc:
        return {"error": f"search_files failed: {exc}"}


async def tool_create_directory(path: str = "", **kwargs) -> dict:
    if not path:
        return {"error": "No path provided"}
    try:
        p = _resolve(path)
        p.mkdir(parents=True, exist_ok=True)
        return {"created": str(p)}
    except PermissionError as exc:
        return {"error": f"Permission denied: {exc}"}
    except Exception as exc:
        return {"error": f"create_directory failed: {exc}"}


async def tool_disk_usage(path: str = "/", **kwargs) -> dict:
    try:
        p = _resolve(path)
        if not p.exists():
            return {"error": f"Path not found: {path}"}
        usage = shutil.disk_usage(p)
        used_pct = round(usage.used / usage.total * 100, 1) if usage.total > 0 else 0
        return {
            "path": str(p),
            "total_gb": round(usage.total / 1e9, 3),
            "used_gb": round(usage.used / 1e9, 3),
            "free_gb": round(usage.free / 1e9, 3),
            "used_percent": used_pct,
        }
    except Exception as exc:
        return {"error": f"disk_usage failed: {exc}"}


# ===========================================================================
# MEDIA TOOLS — IMAGE CRUD
# ===========================================================================

async def tool_image_info(path: str = "", **kwargs) -> dict:
    """Get detailed metadata of an image file: dimensions, format, EXIF, file size."""
    if not path:
        return {"error": "No path provided"}
    try:
        p = _resolve(path)
        if not p.exists():
            return {"error": f"File not found: {path}"}
        from PIL import Image
        import PIL.ExifTags as ExifTags
        loop = asyncio.get_event_loop()

        def _read():
            with Image.open(str(p)) as img:
                info: dict[str, Any] = {
                    "path": str(p),
                    "format": img.format,
                    "mode": img.mode,
                    "width": img.width,
                    "height": img.height,
                    "megapixels": round(img.width * img.height / 1_000_000, 2),
                    "size_bytes": p.stat().st_size,
                    "size_human": _human_size(p.stat().st_size),
                }
                # EXIF
                exif_data: dict[str, Any] = {}
                try:
                    raw_exif = img._getexif()
                    if raw_exif:
                        for tag_id, value in raw_exif.items():
                            tag = ExifTags.TAGS.get(tag_id, str(tag_id))
                            if isinstance(value, bytes):
                                continue
                            exif_data[tag] = str(value)[:80]
                except Exception:
                    pass
                if exif_data:
                    info["exif"] = exif_data
                return info
        return await loop.run_in_executor(None, _read)
    except ImportError:
        _ensure_package("Pillow", "PIL")
        return {"error": "Pillow installed — please retry"}
    except Exception as exc:
        return {"error": f"image_info failed: {exc}"}


async def tool_image_resize(path: str = "", width: int = 0, height: int = 0, output: str = "", keep_aspect: bool = True, **kwargs) -> dict:
    """Resize an image. Saves to output path (or overwrites if not specified)."""
    if not path:
        return {"error": "No path provided"}
    if not width and not height:
        return {"error": "Provide width and/or height"}
    try:
        from PIL import Image
        p = _resolve(path)
        if not p.exists():
            return {"error": f"File not found: {path}"}
        out = _resolve(output) if output else p
        loop = asyncio.get_event_loop()

        def _do():
            with Image.open(str(p)) as img:
                orig_w, orig_h = img.size
                if keep_aspect:
                    if width and height:
                        img.thumbnail((width, height), Image.LANCZOS)
                    elif width:
                        ratio = width / orig_w
                        img = img.resize((width, int(orig_h * ratio)), Image.LANCZOS)
                    else:
                        ratio = height / orig_h
                        img = img.resize((int(orig_w * ratio), height), Image.LANCZOS)
                else:
                    target_w = width or orig_w
                    target_h = height or orig_h
                    img = img.resize((target_w, target_h), Image.LANCZOS)
                out.parent.mkdir(parents=True, exist_ok=True)
                fmt = img.format or p.suffix.lstrip(".").upper() or "PNG"
                img.save(str(out), format=fmt)
                return {"resized": str(out), "new_width": img.width, "new_height": img.height,
                        "orig_width": orig_w, "orig_height": orig_h, "size_bytes": out.stat().st_size}
        return await loop.run_in_executor(None, _do)
    except Exception as exc:
        return {"error": f"image_resize failed: {exc}"}


async def tool_image_rotate(path: str = "", angle: float = 90, output: str = "", expand: bool = True, **kwargs) -> dict:
    """Rotate an image by angle degrees (90, 180, 270, etc.)."""
    if not path:
        return {"error": "No path provided"}
    try:
        from PIL import Image
        p = _resolve(path)
        if not p.exists():
            return {"error": f"File not found: {path}"}
        out = _resolve(output) if output else p
        loop = asyncio.get_event_loop()

        def _do():
            with Image.open(str(p)) as img:
                rotated = img.rotate(float(angle), expand=expand)
                out.parent.mkdir(parents=True, exist_ok=True)
                rotated.save(str(out))
                return {"rotated": str(out), "angle": angle, "width": rotated.width, "height": rotated.height}
        return await loop.run_in_executor(None, _do)
    except Exception as exc:
        return {"error": f"image_rotate failed: {exc}"}


async def tool_image_crop(path: str = "", left: int = 0, top: int = 0, right: int = 0, bottom: int = 0, output: str = "", **kwargs) -> dict:
    """Crop an image to the given box (left, top, right, bottom pixels)."""
    if not path:
        return {"error": "No path provided"}
    if not any([left, top, right, bottom]):
        return {"error": "Provide crop box: left, top, right, bottom (pixels)"}
    try:
        from PIL import Image
        p = _resolve(path)
        if not p.exists():
            return {"error": f"File not found: {path}"}
        out = _resolve(output) if output else p
        loop = asyncio.get_event_loop()

        def _do():
            with Image.open(str(p)) as img:
                w, h = img.size
                r = right if right > 0 else w
                b = bottom if bottom > 0 else h
                cropped = img.crop((left, top, r, b))
                out.parent.mkdir(parents=True, exist_ok=True)
                cropped.save(str(out))
                return {"cropped": str(out), "box": [left, top, r, b],
                        "width": cropped.width, "height": cropped.height}
        return await loop.run_in_executor(None, _do)
    except Exception as exc:
        return {"error": f"image_crop failed: {exc}"}


async def tool_image_convert(path: str = "", format: str = "", output: str = "", quality: int = 90, **kwargs) -> dict:
    """Convert image to another format: jpg, png, webp, bmp, gif, tiff."""
    if not path:
        return {"error": "No path provided"}
    if not format and not output:
        return {"error": "Provide target format (e.g. 'jpg') or output path"}
    try:
        from PIL import Image
        p = _resolve(path)
        if not p.exists():
            return {"error": f"File not found: {path}"}
        if output:
            out = _resolve(output)
            fmt = out.suffix.lstrip(".").upper() or format.upper()
        else:
            fmt = format.upper().replace("JPG", "JPEG")
            ext = fmt.lower().replace("jpeg", "jpg")
            out = p.with_suffix(f".{ext}")
        fmt = fmt.replace("JPG", "JPEG")
        loop = asyncio.get_event_loop()

        def _do():
            with Image.open(str(p)) as img:
                if img.mode in ("RGBA", "P") and fmt == "JPEG":
                    img = img.convert("RGB")
                out.parent.mkdir(parents=True, exist_ok=True)
                save_kwargs: dict = {"format": fmt}
                if fmt in ("JPEG", "WEBP"):
                    save_kwargs["quality"] = quality
                img.save(str(out), **save_kwargs)
                return {"converted": str(out), "format": fmt,
                        "size_bytes": out.stat().st_size, "size_human": _human_size(out.stat().st_size)}
        return await loop.run_in_executor(None, _do)
    except Exception as exc:
        return {"error": f"image_convert failed: {exc}"}


async def tool_send_file(path: str = "", caption: str = "", **kwargs) -> dict:
    """Send any file (image/audio/video/document) back to the user via Telegram."""
    if not path:
        return {"error": "No path provided"}
    try:
        p = _resolve(path)
        if not p.exists():
            return {"error": f"File not found: {path}"}
        if not p.is_file():
            return {"error": f"Not a file: {p}"}
        media_type = _guess_media_type(str(p))
        size = p.stat().st_size
        if size > 50 * 1024 * 1024:
            return {"error": f"File too large to send ({_human_size(size)}). Telegram limit is 50 MB."}
        cap = caption or f"📎 {p.name} ({_human_size(size)})"
        await _push_file(str(p), cap, media_type)
        return {"sent": str(p), "media_type": media_type, "size_human": _human_size(size)}
    except Exception as exc:
        return {"error": f"send_file failed: {exc}"}


# ===========================================================================
# MEDIA TOOLS — AUDIO
# ===========================================================================

async def tool_audio_info(path: str = "", **kwargs) -> dict:
    """Get metadata of an audio file: title, artist, album, duration, bitrate, format."""
    if not path:
        return {"error": "No path provided"}
    try:
        from mutagen import File as MFile
        p = _resolve(path)
        if not p.exists():
            return {"error": f"File not found: {path}"}
        loop = asyncio.get_event_loop()

        def _do():
            f = MFile(str(p), easy=True)
            info: dict[str, Any] = {
                "path": str(p),
                "size_bytes": p.stat().st_size,
                "size_human": _human_size(p.stat().st_size),
                "format": p.suffix.upper().lstrip("."),
            }
            if f is None:
                info["error"] = "Could not parse audio file"
                return info
            if f.info:
                info["duration_seconds"] = round(getattr(f.info, "length", 0), 2)
                mins, secs = divmod(int(info["duration_seconds"]), 60)
                info["duration"] = f"{mins}:{secs:02d}"
                info["bitrate_kbps"] = round(getattr(f.info, "bitrate", 0) / 1000, 1)
                info["sample_rate_hz"] = getattr(f.info, "sample_rate", None)
                info["channels"] = getattr(f.info, "channels", None)
            for tag in ("title", "artist", "album", "date", "genre", "tracknumber"):
                val = f.get(tag)
                if val:
                    info[tag] = str(val[0]) if isinstance(val, list) else str(val)
            return info
        return await loop.run_in_executor(None, _do)
    except ImportError:
        _ensure_package("mutagen")
        return {"error": "mutagen installed — please retry"}
    except Exception as exc:
        return {"error": f"audio_info failed: {exc}"}


async def tool_audio_convert(path: str = "", format: str = "mp3", output: str = "", **kwargs) -> dict:
    """Convert audio to another format using ffmpeg. Requires ffmpeg installed."""
    if not path:
        return {"error": "No path provided"}
    if not shutil.which("ffmpeg"):
        return {"error": "ffmpeg not found. Install it: sudo apt install ffmpeg (Linux) or brew install ffmpeg (Mac)"}
    try:
        p = _resolve(path)
        if not p.exists():
            return {"error": f"File not found: {path}"}
        fmt = format.lower().lstrip(".")
        out = _resolve(output) if output else p.with_suffix(f".{fmt}")
        out.parent.mkdir(parents=True, exist_ok=True)
        loop = asyncio.get_event_loop()
        res = await loop.run_in_executor(
            None,
            lambda: _run_subprocess(
                ["ffmpeg", "-y", "-i", str(p), str(out)], timeout=120
            )
        )
        if "error" in res or (res.get("exit_code", 1) != 0 and not out.exists()):
            return {"error": f"ffmpeg failed: {res.get('stderr', '')[:300]}"}
        return {"converted": str(out), "format": fmt, "size_bytes": out.stat().st_size,
                "size_human": _human_size(out.stat().st_size)}
    except Exception as exc:
        return {"error": f"audio_convert failed: {exc}"}


async def tool_audio_trim(path: str = "", start: float = 0, duration: float = 0, output: str = "", **kwargs) -> dict:
    """Trim audio file. start = seconds from beginning, duration = seconds to keep."""
    if not path:
        return {"error": "No path provided"}
    if not shutil.which("ffmpeg"):
        return {"error": "ffmpeg not found. Install: sudo apt install ffmpeg"}
    if not duration:
        return {"error": "Provide duration (seconds to keep)"}
    try:
        p = _resolve(path)
        if not p.exists():
            return {"error": f"File not found: {path}"}
        out = _resolve(output) if output else p.with_stem(p.stem + "_trimmed")
        out.parent.mkdir(parents=True, exist_ok=True)
        cmd = ["ffmpeg", "-y", "-i", str(p), "-ss", str(start), "-t", str(duration), str(out)]
        loop = asyncio.get_event_loop()
        res = await loop.run_in_executor(None, lambda: _run_subprocess(cmd, timeout=120))
        if res.get("exit_code", 1) != 0 and not out.exists():
            return {"error": f"ffmpeg failed: {res.get('stderr', '')[:300]}"}
        return {"trimmed": str(out), "start_sec": start, "duration_sec": duration,
                "size_bytes": out.stat().st_size}
    except Exception as exc:
        return {"error": f"audio_trim failed: {exc}"}


# ===========================================================================
# MEDIA TOOLS — VIDEO
# ===========================================================================

async def tool_video_info(path: str = "", **kwargs) -> dict:
    """Get metadata of a video: duration, resolution, codec, framerate, file size."""
    if not path:
        return {"error": "No path provided"}
    try:
        p = _resolve(path)
        if not p.exists():
            return {"error": f"File not found: {path}"}

        # Try ffprobe first (most reliable)
        if shutil.which("ffprobe"):
            loop = asyncio.get_event_loop()
            def _ffprobe():
                cmd = [
                    "ffprobe", "-v", "quiet", "-print_format", "json",
                    "-show_streams", "-show_format", str(p)
                ]
                res = _run_subprocess(cmd, timeout=15)
                if "error" in res:
                    return res
                try:
                    data = json.loads(res["stdout"])
                    fmt = data.get("format", {})
                    info: dict[str, Any] = {
                        "path": str(p),
                        "size_bytes": p.stat().st_size,
                        "size_human": _human_size(p.stat().st_size),
                        "duration_seconds": round(float(fmt.get("duration", 0)), 2),
                        "format_name": fmt.get("format_name", ""),
                        "bit_rate_kbps": round(int(fmt.get("bit_rate", 0)) / 1000, 1),
                    }
                    mins, secs = divmod(int(info["duration_seconds"]), 60)
                    hrs, mins = divmod(mins, 60)
                    info["duration"] = f"{hrs}:{mins:02d}:{secs:02d}" if hrs else f"{mins}:{secs:02d}"
                    # Parse streams
                    for stream in data.get("streams", []):
                        if stream.get("codec_type") == "video" and "width" not in info:
                            info["width"] = stream.get("width")
                            info["height"] = stream.get("height")
                            info["resolution"] = f"{stream.get('width')}x{stream.get('height')}"
                            info["video_codec"] = stream.get("codec_name")
                            r_frame = stream.get("r_frame_rate", "0/1")
                            try:
                                n, d = r_frame.split("/")
                                info["fps"] = round(int(n) / int(d), 2) if int(d) else 0
                            except Exception:
                                info["fps"] = r_frame
                        if stream.get("codec_type") == "audio" and "audio_codec" not in info:
                            info["audio_codec"] = stream.get("codec_name")
                            info["audio_channels"] = stream.get("channels")
                            info["audio_sample_rate"] = stream.get("sample_rate")
                    return info
                except Exception as exc:
                    return {"error": f"ffprobe parse error: {exc}"}
            return await loop.run_in_executor(None, _ffprobe)

        # Fallback: hachoir (pure Python)
        try:
            loop = asyncio.get_event_loop()
            def _hachoir():
                createParser = _hachoir_parser()
                extractMetadata = _hachoir_meta()
                parser = createParser(str(p))
                if not parser:
                    return {"error": "Could not parse video file (no ffprobe, hachoir also failed)"}
                metadata = extractMetadata(parser)
                if not metadata:
                    return {"error": "No metadata found"}
                info: dict[str, Any] = {
                    "path": str(p),
                    "size_bytes": p.stat().st_size,
                    "size_human": _human_size(p.stat().st_size),
                }
                for item in metadata.exportPlaintext():
                    if "Duration" in item:
                        info["duration"] = item.split(":")[-1].strip()
                    if "Image width" in item:
                        try:
                            info["width"] = int(item.split(":")[-1].strip().split()[0])
                        except Exception:
                            pass
                    if "Image height" in item:
                        try:
                            info["height"] = int(item.split(":")[-1].strip().split()[0])
                        except Exception:
                            pass
                if "width" in info and "height" in info:
                    info["resolution"] = f"{info['width']}x{info['height']}"
                return info
            return await loop.run_in_executor(None, _hachoir)
        except Exception as exc:
            return {"error": f"video_info failed (no ffprobe): {exc}. Install ffprobe: sudo apt install ffmpeg"}
    except Exception as exc:
        return {"error": f"video_info failed: {exc}"}


async def tool_video_thumbnail(path: str = "", time_sec: float = 1.0, output: str = "", **kwargs) -> dict:
    """Extract a thumbnail from a video at a given timestamp. Requires ffmpeg."""
    if not path:
        return {"error": "No path provided"}
    if not shutil.which("ffmpeg"):
        return {"error": "ffmpeg not found. Install: sudo apt install ffmpeg"}
    try:
        p = _resolve(path)
        if not p.exists():
            return {"error": f"File not found: {path}"}
        out = _resolve(output) if output else p.with_suffix(".thumb.jpg")
        out.parent.mkdir(parents=True, exist_ok=True)
        cmd = ["ffmpeg", "-y", "-ss", str(time_sec), "-i", str(p),
               "-vframes", "1", "-q:v", "2", str(out)]
        loop = asyncio.get_event_loop()
        res = await loop.run_in_executor(None, lambda: _run_subprocess(cmd, timeout=30))
        if not out.exists():
            return {"error": f"Thumbnail extraction failed: {res.get('stderr', '')[:200]}"}
        return {"thumbnail": str(out), "at_sec": time_sec,
                "size_bytes": out.stat().st_size, "size_human": _human_size(out.stat().st_size)}
    except Exception as exc:
        return {"error": f"video_thumbnail failed: {exc}"}


async def tool_video_convert(path: str = "", format: str = "mp4", output: str = "", **kwargs) -> dict:
    """Convert video to another format using ffmpeg."""
    if not path:
        return {"error": "No path provided"}
    if not shutil.which("ffmpeg"):
        return {"error": "ffmpeg not found. Install: sudo apt install ffmpeg"}
    try:
        p = _resolve(path)
        if not p.exists():
            return {"error": f"File not found: {path}"}
        fmt = format.lower().lstrip(".")
        out = _resolve(output) if output else p.with_suffix(f".{fmt}")
        out.parent.mkdir(parents=True, exist_ok=True)
        cmd = ["ffmpeg", "-y", "-i", str(p), str(out)]
        loop = asyncio.get_event_loop()
        res = await loop.run_in_executor(None, lambda: _run_subprocess(cmd, timeout=300))
        if res.get("exit_code", 1) != 0 and not out.exists():
            return {"error": f"ffmpeg failed: {res.get('stderr', '')[:400]}"}
        return {"converted": str(out), "format": fmt, "size_human": _human_size(out.stat().st_size)}
    except Exception as exc:
        return {"error": f"video_convert failed: {exc}"}


async def tool_video_trim(path: str = "", start: float = 0, duration: float = 0, output: str = "", **kwargs) -> dict:
    """Trim video: start=seconds from beginning, duration=seconds to keep."""
    if not path:
        return {"error": "No path provided"}
    if not shutil.which("ffmpeg"):
        return {"error": "ffmpeg not found. Install: sudo apt install ffmpeg"}
    if not duration:
        return {"error": "Provide duration (seconds)"}
    try:
        p = _resolve(path)
        if not p.exists():
            return {"error": f"File not found: {path}"}
        out = _resolve(output) if output else p.with_stem(p.stem + "_trimmed")
        out.parent.mkdir(parents=True, exist_ok=True)
        cmd = ["ffmpeg", "-y", "-i", str(p), "-ss", str(start), "-t", str(duration),
               "-c", "copy", str(out)]
        loop = asyncio.get_event_loop()
        res = await loop.run_in_executor(None, lambda: _run_subprocess(cmd, timeout=300))
        if res.get("exit_code", 1) != 0 and not out.exists():
            return {"error": f"ffmpeg failed: {res.get('stderr', '')[:400]}"}
        return {"trimmed": str(out), "start_sec": start, "duration_sec": duration,
                "size_human": _human_size(out.stat().st_size)}
    except Exception as exc:
        return {"error": f"video_trim failed: {exc}"}


# ===========================================================================
# APP LAUNCHER (cross-platform, real implementation)
# ===========================================================================

# Common app name aliases → actual binary / bundle
_APP_ALIASES: dict[str, dict[str, str]] = {
    "chrome":     {"Linux": "google-chrome",    "Darwin": "Google Chrome",     "Windows": "chrome"},
    "chromium":   {"Linux": "chromium-browser",  "Darwin": "Chromium",          "Windows": "chromium"},
    "firefox":    {"Linux": "firefox",           "Darwin": "Firefox",           "Windows": "firefox"},
    "safari":     {"Linux": "",                  "Darwin": "Safari",            "Windows": ""},
    "edge":       {"Linux": "microsoft-edge",    "Darwin": "Microsoft Edge",    "Windows": "msedge"},
    "vscode":     {"Linux": "code",              "Darwin": "Visual Studio Code","Windows": "code"},
    "vs code":    {"Linux": "code",              "Darwin": "Visual Studio Code","Windows": "code"},
    "terminal":   {"Linux": "x-terminal-emulator","Darwin": "Terminal",         "Windows": "cmd"},
    "calculator": {"Linux": "gnome-calculator",  "Darwin": "Calculator",        "Windows": "calc"},
    "vlc":        {"Linux": "vlc",               "Darwin": "VLC",               "Windows": "vlc"},
    "spotify":    {"Linux": "spotify",           "Darwin": "Spotify",           "Windows": "spotify"},
    "slack":      {"Linux": "slack",             "Darwin": "Slack",             "Windows": "slack"},
    "zoom":       {"Linux": "zoom",              "Darwin": "zoom.us",           "Windows": "zoom"},
    "discord":    {"Linux": "discord",           "Darwin": "Discord",           "Windows": "discord"},
    "telegram":   {"Linux": "telegram-desktop",  "Darwin": "Telegram",          "Windows": "telegram"},
    "files":      {"Linux": "nautilus",          "Darwin": "Finder",            "Windows": "explorer"},
    "finder":     {"Linux": "nautilus",          "Darwin": "Finder",            "Windows": "explorer"},
    "nautilus":   {"Linux": "nautilus",          "Darwin": "Finder",            "Windows": "explorer"},
    "gimp":       {"Linux": "gimp",              "Darwin": "GIMP",              "Windows": "gimp"},
    "notepad":    {"Linux": "gedit",             "Darwin": "TextEdit",          "Windows": "notepad"},
    "textedit":   {"Linux": "gedit",             "Darwin": "TextEdit",          "Windows": "notepad"},
    "gedit":      {"Linux": "gedit",             "Darwin": "TextEdit",          "Windows": "notepad"},
}


async def tool_open_application(name: str = "", file_path: str = "", **kwargs) -> dict:
    """
    Launch any application by name, or open a file with its default app.
    Supports aliases like 'chrome', 'vscode', 'terminal', 'vlc', etc.
    Optionally pass file_path to open a specific file with the app.
    """
    if not name and not file_path:
        return {"error": "Provide app name or file_path to open"}
    try:
        # If file_path given without app name → open with default app
        if file_path and not name:
            fp = _resolve(file_path)
            if not fp.exists():
                return {"error": f"File not found: {file_path}"}
            return await _open_with_default(str(fp))

        name_lower = name.strip().lower()
        # Resolve alias
        app_name = name.strip()
        if name_lower in _APP_ALIASES:
            app_name = _APP_ALIASES[name_lower].get(SYS, name.strip()) or name.strip()

        args_list = [str(_resolve(file_path))] if file_path else []

        if SYS == "Darwin":
            return await _launch_macos(app_name, args_list)
        elif SYS == "Windows":
            return await _launch_windows(app_name, args_list)
        else:
            return await _launch_linux(app_name, name.strip(), args_list)

    except Exception as exc:
        return {"error": f"open_application failed: {exc}"}


async def _open_with_default(path: str) -> dict:
    """Open a file with the OS default application."""
    try:
        if SYS == "Darwin":
            subprocess.Popen(["open", path], start_new_session=True)
        elif SYS == "Windows":
            os.startfile(path)  # type: ignore[attr-defined]
        else:
            # Linux
            for opener in ("xdg-open", "gio open", "mimeopen"):
                cmd = opener.split() + [path]
                if shutil.which(cmd[0]):
                    subprocess.Popen(cmd, start_new_session=True)
                    break
            else:
                return {"error": "No file opener found. Install xdg-utils: sudo apt install xdg-utils"}
        return {"opened_file": path}
    except Exception as exc:
        return {"error": f"open_with_default failed: {exc}"}


async def _launch_macos(app_name: str, args: list) -> dict:
    # Try 'open -a AppName' first
    cmd = ["open", "-a", app_name]
    if args:
        cmd += ["--args"] + args
    res = _run_subprocess(cmd, timeout=15)
    if res.get("exit_code") == 0:
        return {"launched": app_name}
    # Try direct binary
    if shutil.which(app_name.lower()):
        subprocess.Popen([app_name.lower()] + args, start_new_session=True)
        return {"launched": app_name}
    return {"error": f"Could not launch '{app_name}' on macOS. {res.get('stderr', '')}"}


async def _launch_windows(app_name: str, args: list) -> dict:
    if shutil.which(app_name):
        subprocess.Popen([app_name] + args, start_new_session=True)
        return {"launched": app_name}
    # Use 'start' shell command
    cmd = f'start "" "{app_name}"'
    if args:
        cmd += " " + " ".join(f'"{a}"' for a in args)
    subprocess.Popen(cmd, shell=True, start_new_session=True)
    return {"launched": app_name}


async def _launch_linux(app_name: str, original_name: str, args: list) -> dict:
    # 1. Direct binary match
    for candidate in [app_name, app_name.lower(), original_name, original_name.lower()]:
        if shutil.which(candidate):
            subprocess.Popen([candidate] + args, start_new_session=True)
            return {"launched": candidate}

    # 2. Search .desktop files
    desktop_dirs = [
        Path("/usr/share/applications"),
        Path("/usr/local/share/applications"),
        Path.home() / ".local/share/applications",
        Path("/var/lib/flatpak/exports/share/applications"),
        Path.home() / ".local/share/flatpak/exports/share/applications",
    ]
    search_name = app_name.lower().replace(" ", "")
    for ddir in desktop_dirs:
        if not ddir.exists():
            continue
        for df in ddir.glob("*.desktop"):
            if search_name in df.stem.lower():
                # Parse Exec= line
                try:
                    text = df.read_text(errors="replace")
                    for line in text.splitlines():
                        if line.startswith("Exec="):
                            exec_cmd = line[5:].strip()
                            exec_cmd = re.sub(r"%[A-Za-z]", "", exec_cmd).strip()
                            exec_parts = exec_cmd.split()
                            subprocess.Popen(exec_parts + args, start_new_session=True)
                            return {"launched": app_name, "via": ".desktop", "exec": exec_cmd}
                except Exception:
                    pass

    # 3. Try xdg-open as last resort
    if shutil.which("xdg-open"):
        subprocess.Popen(["xdg-open", app_name] + args, start_new_session=True)
        return {"launched": app_name, "via": "xdg-open"}

    return {"error": f"Application '{app_name}' not found. Check spelling or install it."}


async def tool_open_url(url: str = "", **kwargs) -> dict:
    """Open a URL in the default browser."""
    if not url:
        return {"error": "No URL provided"}
    url = url.strip()
    if not re.match(r"^https?://", url, re.IGNORECASE):
        url = f"https://{url}"
    import webbrowser
    loop = asyncio.get_event_loop()
    try:
        success = await loop.run_in_executor(None, webbrowser.open, url)
        if not success:
            return {"error": f"Browser could not open: {url}"}
        return {"opened": url}
    except Exception as exc:
        return {"error": f"open_url failed: {exc}"}


# ===========================================================================
# SCREENSHOT (fixed — full cross-platform fallback chain)
# ===========================================================================

async def tool_screenshot(quality: int = 90, **kwargs) -> dict:
    """Take a screenshot of the primary display."""
    try:
        out = Path(tempfile.mktemp(suffix=".png", prefix="bysalim_screenshot_"))

        if SYS == "Darwin":
            res = _run_subprocess(["screencapture", "-x", "-t", "png", str(out)])
            if "error" in res or not out.exists():
                return {"error": f"screencapture failed: {res.get('error', res.get('stderr', 'unknown'))}"}

        elif SYS == "Windows":
            ps_script = (
                "Add-Type -AssemblyName System.Windows.Forms;"
                "Add-Type -AssemblyName System.Drawing;"
                "$screen = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds;"
                "$bmp = New-Object System.Drawing.Bitmap($screen.Width, $screen.Height);"
                "$g = [System.Drawing.Graphics]::FromImage($bmp);"
                "$g.CopyFromScreen($screen.Location, [System.Drawing.Point]::Empty, $screen.Size);"
                f"$bmp.Save('{out}', [System.Drawing.Imaging.ImageFormat]::Png);"
                "$g.Dispose(); $bmp.Dispose()"
            )
            res = _run_subprocess(["powershell", "-NonInteractive", "-Command", ps_script], timeout=30)
            if not out.exists():
                return {"error": f"Windows screenshot failed: {res.get('stderr', '')}"}

        else:
            # Linux — try tools in order, then Pillow+Xlib fallback
            took = False
            for tool_cmd in [
                ["scrot", "-z", str(out)],
                ["maim", str(out)],
                ["gnome-screenshot", "-f", str(out)],
                ["import", "-window", "root", str(out)],
                ["grim", str(out)],                    # Wayland
                ["spectacle", "-b", "-n", "-o", str(out)],  # KDE
            ]:
                if not shutil.which(tool_cmd[0]):
                    continue
                res = _run_subprocess(tool_cmd, timeout=20)
                if out.exists() and out.stat().st_size > 0:
                    took = True
                    break

            if not took:
                # Pillow + Xlib fallback (headless-safe)
                try:
                    from PIL import ImageGrab
                    loop = asyncio.get_event_loop()
                    def _grab():
                        img = ImageGrab.grab()
                        img.save(str(out))
                    await loop.run_in_executor(None, _grab)
                    took = out.exists() and out.stat().st_size > 0
                except Exception:
                    pass

            if not took:
                return {
                    "error": (
                        "No screenshot tool available. Install one:\n"
                        "  sudo apt install scrot   # X11\n"
                        "  sudo apt install grim    # Wayland"
                    )
                }

        if not out.exists() or out.stat().st_size == 0:
            return {"error": "Screenshot file empty or missing"}

        size = out.stat().st_size
        return {"path": str(out), "size_bytes": size, "size_kb": round(size / 1024, 1)}
    except Exception as exc:
        return {"error": f"screenshot failed: {exc}"}


# ===========================================================================
# VOLUME (fixed Linux detection)
# ===========================================================================

async def tool_get_volume(**kwargs) -> dict:
    try:
        if SYS == "Darwin":
            res = _run_subprocess(["osascript", "-e", "output volume of (get volume settings)"])
            if "error" in res:
                return res
            return {"volume": int(res["stdout"].strip().split("\n")[0].strip())}
        elif SYS == "Windows":
            ps = "(New-Object -com WScript.Shell).SendKeys('');[int]((New-Object -COM WScript.Shell).RegRead('HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Applets\\Volume\\Volume'))"
            res = _run_subprocess(["powershell", "-NonInteractive", "-Command",
                                   "[int][math]::Round((Get-Volume).SizeRemaining)"])
            return {"error": "Windows volume reading requires nircmd or VB scripting", "hint": "Use nircmd.exe sndvol"}
        else:
            # Linux — pactl first, then amixer, then wpctl
            for cmd, parser in [
                (["pactl", "get-sink-volume", "@DEFAULT_SINK@"],
                 lambda out: int(re.search(r"(\d+)%", out).group(1)) if re.search(r"(\d+)%", out) else None),
                (["amixer", "-D", "pulse", "get", "Master"],
                 lambda out: int(re.search(r"\[(\d+)%\]", out).group(1)) if re.search(r"\[(\d+)%\]", out) else None),
                (["wpctl", "get-volume", "@DEFAULT_AUDIO_SINK@"],
                 lambda out: int(float(re.search(r"[\d.]+", out).group(0)) * 100) if re.search(r"[\d.]+", out) else None),
            ]:
                if not shutil.which(cmd[0]):
                    continue
                res = _run_subprocess(cmd)
                if "error" not in res:
                    vol = parser(res.get("stdout", ""))
                    if vol is not None:
                        return {"volume": vol}
            return {"error": "No volume control found. Install: sudo apt install pulseaudio-utils"}
    except Exception as exc:
        return {"error": f"get_volume failed: {exc}"}


async def tool_set_volume(level: int = 50, **kwargs) -> dict:
    level = int(_clamp(int(level), 0, 100))
    try:
        if SYS == "Darwin":
            res = _run_subprocess(["osascript", "-e", f"set volume output volume {level}"])
        elif SYS == "Windows":
            if shutil.which("nircmd"):
                res = _run_subprocess(["nircmd", "setsysvolume", str(int(level * 655.35))])
            else:
                return {"error": "Set volume on Windows requires nircmd. Download from nirsoft.net."}
        else:
            for cmd in [
                (["pactl", "set-sink-volume", "@DEFAULT_AUDIO_SINK@", f"{level}%"], "pactl"),
                (["amixer", "-D", "pulse", "sset", "Master", f"{level}%"], "amixer"),
                (["wpctl", "set-volume", "@DEFAULT_AUDIO_SINK@", f"{level/100:.2f}"], "wpctl"),
            ]:
                if shutil.which(cmd[0][0]):
                    res = _run_subprocess(cmd[0])
                    if "error" not in res:
                        return {"volume_set": level}
            return {"error": "No volume control found. Install pulseaudio-utils."}
        if "error" in res:
            return res
        return {"volume_set": level}
    except Exception as exc:
        return {"error": f"set_volume failed: {exc}"}


async def tool_mute_volume(**kwargs) -> dict:
    try:
        if SYS == "Darwin":
            res = _run_subprocess(["osascript", "-e", "set volume with output muted"])
        elif SYS == "Windows":
            res = _run_subprocess(["powershell", "-NonInteractive", "-Command",
                                   "(New-Object -ComObject WScript.Shell).SendKeys([char]173)"])
        else:
            for cmd in [
                ["pactl", "set-sink-mute", "@DEFAULT_AUDIO_SINK@", "1"],
                ["amixer", "-D", "pulse", "sset", "Master", "mute"],
                ["wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@", "1"],
            ]:
                if shutil.which(cmd[0]):
                    res = _run_subprocess(cmd)
                    if "error" not in res:
                        return {"muted": True}
            return {"error": "No volume control found."}
        if "error" in res:
            return res
        return {"muted": True}
    except Exception as exc:
        return {"error": f"mute_volume failed: {exc}"}


# ===========================================================================
# CLIPBOARD, WEATHER, PING, INTERNET, TIME, REMINDER (carried over unchanged)
# ===========================================================================

async def tool_get_clipboard(**kwargs) -> dict:
    try:
        if SYS == "Darwin":
            res = _run_subprocess(["pbpaste"])
        elif SYS == "Windows":
            res = _run_subprocess(["powershell", "-NonInteractive", "-Command", "Get-Clipboard"])
        else:
            for tool, args in [
                ("xclip", ["xclip", "-selection", "clipboard", "-o"]),
                ("xsel",  ["xsel", "--clipboard", "--output"]),
                ("wl-paste", ["wl-paste"]),
            ]:
                if shutil.which(tool):
                    res = _run_subprocess(args)
                    break
            else:
                return {"error": "No clipboard tool. Install: sudo apt install xclip"}
        if "error" in res:
            return res
        content = res.get("stdout", "")
        return {"clipboard": content, "length": len(content)}
    except Exception as exc:
        return {"error": f"get_clipboard failed: {exc}"}


async def tool_set_clipboard(text: str = "", **kwargs) -> dict:
    if text is None:
        return {"error": "No text provided"}
    try:
        encoded = text.encode("utf-8")
        if SYS == "Darwin":
            subprocess.run(["pbcopy"], input=encoded, capture_output=True, timeout=10)
        elif SYS == "Windows":
            subprocess.run(["powershell", "-NonInteractive", "-Command",
                            f'Set-Clipboard -Value "{text}"'], capture_output=True, timeout=10)
        else:
            for tool, args in [
                ("xclip", ["xclip", "-selection", "clipboard"]),
                ("xsel",  ["xsel", "--clipboard", "--input"]),
                ("wl-copy", ["wl-copy"]),
            ]:
                if shutil.which(tool):
                    subprocess.run(args, input=encoded, capture_output=True, timeout=10)
                    break
            else:
                return {"error": "No clipboard tool. Install: sudo apt install xclip"}
        preview = text[:80] + ("…" if len(text) > 80 else "")
        return {"clipboard_set": preview, "length": len(text)}
    except Exception as exc:
        return {"error": f"set_clipboard failed: {exc}"}


async def tool_weather(city: str = "", lat: float = 0.0, lon: float = 0.0, **kwargs) -> dict:
    try:
        loop = asyncio.get_event_loop()
        if city and not (lat and lon):
            geo_url = ("https://geocoding-api.open-meteo.com/v1/search?"
                       + urllib.parse.urlencode({"name": city.strip(), "count": 1, "language": "en", "format": "json"}))
            def _geo():
                req = urllib.request.Request(geo_url, headers={"User-Agent": "BySalim/2.0"})
                with urllib.request.urlopen(req, timeout=15) as r:
                    return json.loads(r.read())
            geo_data = await loop.run_in_executor(None, _geo)
            results = geo_data.get("results")
            if not results:
                return {"error": f"City not found: '{city}'"}
            lat = float(results[0]["latitude"])
            lon = float(results[0]["longitude"])
            city = results[0].get("name", city)
            country = results[0].get("country", "")
            if country:
                city = f"{city}, {country}"
        if not (lat and lon):
            return {"error": "Provide city name or lat/lon"}
        wx_url = ("https://api.open-meteo.com/v1/forecast?"
                  + urllib.parse.urlencode({"latitude": round(lat, 4), "longitude": round(lon, 4),
                                            "current_weather": True, "hourly": "relativehumidity_2m,apparent_temperature",
                                            "forecast_days": 1}))
        def _wx():
            req = urllib.request.Request(wx_url, headers={"User-Agent": "BySalim/2.0"})
            with urllib.request.urlopen(req, timeout=15) as r:
                return json.loads(r.read())
        wx = await loop.run_in_executor(None, _wx)
        cw = wx.get("current_weather", {})
        wmo = {0: "Clear ☀️", 1: "Mainly clear 🌤️", 2: "Partly cloudy ⛅", 3: "Overcast ☁️",
               45: "Fog 🌫️", 51: "Drizzle 🌦️", 61: "Rain 🌧️", 71: "Snow ❄️",
               80: "Showers 🌦️", 95: "Thunderstorm ⛈️"}
        hourly = wx.get("hourly", {})
        humidity = (hourly.get("relativehumidity_2m") or [None])[0]
        feels_like = (hourly.get("apparent_temperature") or [None])[0]
        return {"city": city, "temperature_c": cw.get("temperature"), "feels_like_c": feels_like,
                "windspeed_kmh": cw.get("windspeed"), "conditions": wmo.get(cw.get("weathercode", -1), "?"),
                "humidity_percent": humidity, "is_day": bool(cw.get("is_day", 1))}
    except Exception as exc:
        return {"error": f"weather failed: {exc}"}


async def tool_reminder(message: str = "", delay_seconds: int = 0, delay_minutes: int = 0, delay_hours: int = 0, **kwargs) -> dict:
    if not message:
        return {"error": "No reminder message provided"}
    total_secs = int(delay_seconds) + int(delay_minutes) * 60 + int(delay_hours) * 3600
    if total_secs <= 0:
        return {"error": "Provide a positive delay"}
    if total_secs > 86400 * 7:
        return {"error": "Maximum reminder delay is 7 days"}
    async def _fire():
        await asyncio.sleep(total_secs)
        await _push(f"⏰ *Reminder:* {message}")
    asyncio.ensure_future(_fire())
    eta = datetime.datetime.now() + datetime.timedelta(seconds=total_secs)
    h, rem = divmod(total_secs, 3600)
    m, s = divmod(rem, 60)
    human = f"{h}h {m}m {s}s" if h else (f"{m}m {s}s" if m else f"{s}s")
    return {"reminder_set": message.strip(), "fires_at": eta.strftime("%H:%M:%S"),
            "fires_at_full": eta.strftime("%Y-%m-%d %H:%M:%S"), "delay_human": human, "delay_seconds": total_secs}


async def tool_ping(host: str = "8.8.8.8", count: int = 4, **kwargs) -> dict:
    if not host:
        return {"error": "No host provided"}
    host = host.strip()
    count = int(_clamp(int(count), 1, 20))
    try:
        cmd = ["ping", "-n" if SYS == "Windows" else "-c", str(count), host]
        loop = asyncio.get_event_loop()
        res = await loop.run_in_executor(None, lambda: _run_subprocess(cmd, timeout=count * 5 + 10))
        if "error" in res:
            return res
        stdout = res.get("stdout", "")
        avg = None
        for pattern in [r"(?:avg|mean)[^=]+=\s*[\d.]+/([\d.]+)", r"Average\s*=\s*([\d.]+)\s*ms", r"time[<=]([\d.]+)\s*ms"]:
            m = re.search(pattern, stdout, re.IGNORECASE)
            if m:
                avg = float(m.group(1))
                break
        loss = None
        m2 = re.search(r"(\d+(?:\.\d+)?)\s*%\s*packet loss", stdout, re.IGNORECASE)
        if m2:
            loss = m2.group(1) + "%"
        return {"host": host, "packets": count, "avg_ms": avg, "packet_loss": loss,
                "reachable": res.get("exit_code", 1) == 0}
    except Exception as exc:
        return {"error": f"ping failed: {exc}"}


async def tool_internet_speed(**kwargs) -> dict:
    results: dict = {}
    loop = asyncio.get_event_loop()
    endpoints = [("google.com", "https://www.google.com"), ("cloudflare", "https://1.1.1.1"), ("github.com", "https://github.com")]
    async def _check(name, url):
        start = time.monotonic()
        try:
            def _req():
                req = urllib.request.Request(url, method="HEAD", headers={"User-Agent": "BySalim/2.0"})
                with urllib.request.urlopen(req, timeout=8): pass
            await loop.run_in_executor(None, _req)
            results[name] = {"reachable": True, "latency_ms": round((time.monotonic() - start) * 1000, 1)}
        except Exception as exc:
            results[name] = {"reachable": False, "error": str(exc)[:80]}
    await asyncio.gather(*[_check(n, u) for n, u in endpoints])
    return {"connectivity": results}


async def tool_datetime(**kwargs) -> dict:
    now = datetime.datetime.now()
    utc = datetime.datetime.utcnow()
    return {"local": now.isoformat(timespec="seconds"), "utc": utc.isoformat(timespec="seconds"),
            "date": now.strftime("%A, %B %d %Y"), "time": now.strftime("%H:%M:%S"),
            "timestamp": int(time.time()), "timezone": time.tzname[0],
            "utc_offset_hours": round(-time.timezone / 3600, 1),
            "week_number": now.isocalendar()[1], "day_of_year": now.timetuple().tm_yday}


async def tool_python_info(**kwargs) -> dict:
    try:
        loop = asyncio.get_event_loop()
        res = await loop.run_in_executor(None, lambda: _run_subprocess([sys.executable, "-m", "pip", "list", "--format=json"], timeout=30))
        pkgs: list = []
        if "error" not in res and res.get("stdout"):
            try:
                pkgs = json.loads(res["stdout"])
            except Exception:
                pass
        return {"python_version": sys.version, "executable": sys.executable, "platform": sys.platform,
                "implementation": platform.python_implementation(), "packages_installed": len(pkgs),
                "packages_sample": [p["name"] for p in pkgs[:10]]}
    except Exception as exc:
        return {"error": f"python_info failed: {exc}"}


async def tool_env_vars(filter_key: str = "", **kwargs) -> dict:
    _SENSITIVE = {"key", "secret", "token", "password", "passwd", "pwd", "api", "auth", "cred"}
    safe: dict = {}
    for k, v in os.environ.items():
        k_low = k.lower()
        safe[k] = "***REDACTED***" if any(s in k_low for s in _SENSITIVE) else v
    if filter_key:
        safe = {k: v for k, v in safe.items() if filter_key.lower() in k.lower()}
    return {"env": safe, "count": len(safe)}


async def tool_git_status(path: str = ".", **kwargs) -> dict:
    try:
        p = _resolve(path)
        if not p.exists():
            return {"error": f"Path not found: {path}"}
        loop = asyncio.get_event_loop()
        res = await loop.run_in_executor(None, lambda: _run_subprocess(["git", "status", "--short", "--branch"], cwd=str(p), timeout=15))
        if "error" in res:
            return res
        if res.get("exit_code", 1) != 0:
            stderr = res.get("stderr", "")
            return {"error": "Not a git repository" if "not a git" in stderr.lower() else stderr}
        return {"path": str(p), "status": res["stdout"] or "(clean)"}
    except Exception as exc:
        return {"error": f"git_status failed: {exc}"}


async def tool_git_log(path: str = ".", count: int = 10, **kwargs) -> dict:
    try:
        p = _resolve(path)
        count = int(_clamp(count, 1, 50))
        loop = asyncio.get_event_loop()
        res = await loop.run_in_executor(None, lambda: _run_subprocess(
            ["git", "log", f"--max-count={count}", "--oneline", "--no-color", "--pretty=format:%h\t%s\t%cr\t%an"],
            cwd=str(p), timeout=15))
        if "error" in res:
            return res
        commits = []
        for line in res["stdout"].splitlines():
            parts = line.split("\t", 3)
            if len(parts) >= 2:
                commits.append({"hash": parts[0], "message": parts[1],
                                "when": parts[2] if len(parts) > 2 else "", "author": parts[3] if len(parts) > 3 else ""})
        return {"commits": commits, "path": str(p)}
    except Exception as exc:
        return {"error": f"git_log failed: {exc}"}


async def tool_pip_install(package: str = "", **kwargs) -> dict:
    if not package:
        return {"error": "No package name provided"}
    if re.search(r"[;&|`$()]", package):
        return {"error": f"Invalid package name: '{package}'"}
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, lambda: _run_subprocess(
        [sys.executable, "-m", "pip", "install", "--break-system-packages", package.strip()], timeout=120))


async def tool_pip_list(**kwargs) -> dict:
    loop = asyncio.get_event_loop()
    res = await loop.run_in_executor(None, lambda: _run_subprocess([sys.executable, "-m", "pip", "list", "--format=json"], timeout=30))
    if "error" in res:
        return res
    try:
        pkgs = json.loads(res["stdout"])
        return {"packages": pkgs, "count": len(pkgs)}
    except Exception:
        return {"error": "Could not parse pip list output"}


_MATH_GLOBALS: dict = {"__builtins__": {}, "abs": abs, "round": round, "min": min, "max": max, "pow": pow, "sum": sum}
try:
    import math as _math
    _MATH_GLOBALS.update({"sqrt": _math.sqrt, "floor": _math.floor, "ceil": _math.ceil,
                           "log": _math.log, "log10": _math.log10, "log2": _math.log2,
                           "sin": _math.sin, "cos": _math.cos, "tan": _math.tan,
                           "pi": _math.pi, "e": _math.e, "inf": _math.inf})
except ImportError:
    pass


async def tool_calculate(expression: str = "", **kwargs) -> dict:
    if not expression:
        return {"error": "No expression provided"}
    clean = expression.strip().replace("^", "**")
    stripped = re.sub(r"[\d\s\+\-\*\/\(\)\.\%]|sqrt|floor|ceil|log10|log2|log|sin|cos|tan|pi|abs|round|min|max|pow|sum|inf\b|\be\b", "", clean)
    if stripped.strip():
        return {"error": f"Disallowed characters: '{stripped.strip()}'"}
    try:
        result = eval(clean, _MATH_GLOBALS)  # noqa: S307
        if isinstance(result, float) and result == int(result) and abs(result) < 1e15:
            result = int(result)
        elif isinstance(result, float):
            result = round(result, 10)
        return {"expression": expression, "result": result}
    except ZeroDivisionError:
        return {"error": "Division by zero"}
    except Exception as exc:
        return {"error": f"Could not evaluate '{expression}': {exc}"}


async def tool_word_count(text: str = "", path: str = "", **kwargs) -> dict:
    try:
        if path:
            p = _resolve(path)
            if not p.exists():
                return {"error": f"File not found: {path}"}
            text = p.read_text(encoding="utf-8", errors="replace")
        lines = text.splitlines()
        words = text.split()
        sentences = len([s for s in re.split(r"[.!?]+", text) if s.strip()])
        paragraphs = len([p for p in text.split("\n\n") if p.strip()])
        return {"characters": len(text), "characters_no_spaces": len(text.replace(" ", "").replace("\n", "")),
                "words": len(words), "lines": len(lines), "sentences": sentences, "paragraphs": paragraphs}
    except Exception as exc:
        return {"error": f"word_count failed: {exc}"}


async def tool_clarify(message: str = "", **kwargs) -> dict:
    return {"clarify": (message.strip() or "I didn't understand. Could you rephrase?")}


# ===========================================================================
# TOOL REGISTRY
# ===========================================================================

TOOLS: dict[str, dict] = {
    # System
    "system_health":      {"fn": tool_system_health,      "description": "CPU, RAM, disk, swap and top processes",                          "danger": False},
    "uptime":             {"fn": tool_uptime,              "description": "System uptime and boot time",                                     "danger": False},
    "battery":            {"fn": tool_battery,             "description": "Battery percentage, charging status, time remaining",              "danger": False},
    "network_stats":      {"fn": tool_network_stats,       "description": "Network I/O, interfaces, active connections",                     "danger": False},
    "list_processes":     {"fn": tool_list_processes,      "description": "List running processes with CPU/memory usage",                    "danger": False},
    "kill_process":       {"fn": tool_kill_process,        "description": "Terminate a process by PID or name",                             "danger": True},
    "run_shell":          {"fn": tool_run_shell,           "description": "Execute an arbitrary shell command",                              "danger": True},

    # File system CRUD
    "list_directory":     {"fn": tool_list_directory,      "description": "List files in a directory (shows media type for each file)",      "danger": False},
    "read_file":          {"fn": tool_read_file,           "description": "Read contents of a text file",                                   "danger": False},
    "write_file":         {"fn": tool_write_file,          "description": "Write or append text to a file (creates if not exists)",         "danger": True},
    "delete_file":        {"fn": tool_delete_file,         "description": "Delete a file or directory (moves to trash by default)",         "danger": True},
    "copy_file":          {"fn": tool_copy_file,           "description": "Copy a file or directory tree",                                  "danger": False},
    "move_file":          {"fn": tool_move_file,           "description": "Move or rename a file or directory",                             "danger": True},
    "rename_file":        {"fn": tool_rename_file,         "description": "Rename a file or folder (keeps same directory)",                 "danger": False},
    "search_files":       {"fn": tool_search_files,        "description": "Search for files by name pattern, showing media type",           "danger": False},
    "create_directory":   {"fn": tool_create_directory,    "description": "Create a directory and all parent directories",                  "danger": False},
    "disk_usage":         {"fn": tool_disk_usage,          "description": "Disk space usage for a given path",                              "danger": False},
    "send_file":          {"fn": tool_send_file,           "description": "Send any file (image/audio/video/document) to Telegram",        "danger": False, "send_file": True},

    # Image CRUD
    "image_info":         {"fn": tool_image_info,          "description": "Get image metadata: dimensions, format, file size, EXIF data",   "danger": False},
    "image_resize":       {"fn": tool_image_resize,        "description": "Resize an image to given width/height (aspect ratio kept)",      "danger": False},
    "image_rotate":       {"fn": tool_image_rotate,        "description": "Rotate an image by angle degrees (90, 180, 270, etc.)",          "danger": False},
    "image_crop":         {"fn": tool_image_crop,          "description": "Crop an image to box: left, top, right, bottom pixels",          "danger": False},
    "image_convert":      {"fn": tool_image_convert,       "description": "Convert image format: jpg, png, webp, bmp, gif, tiff",           "danger": False},

    # Audio CRUD
    "audio_info":         {"fn": tool_audio_info,          "description": "Get audio metadata: title, artist, album, duration, bitrate",    "danger": False},
    "audio_convert":      {"fn": tool_audio_convert,       "description": "Convert audio format using ffmpeg (mp3, flac, wav, ogg, etc.)",  "danger": False},
    "audio_trim":         {"fn": tool_audio_trim,          "description": "Trim audio: start=seconds from beginning, duration=seconds",     "danger": False},

    # Video CRUD
    "video_info":         {"fn": tool_video_info,          "description": "Get video metadata: duration, resolution, codec, fps, file size","danger": False},
    "video_thumbnail":    {"fn": tool_video_thumbnail,     "description": "Extract a thumbnail from a video at given timestamp (ffmpeg)",    "danger": False},
    "video_convert":      {"fn": tool_video_convert,       "description": "Convert video format using ffmpeg (mp4, mkv, webm, avi, etc.)",  "danger": False},
    "video_trim":         {"fn": tool_video_trim,          "description": "Trim video: start=seconds, duration=seconds (ffmpeg)",           "danger": False},

    # Screen/audio
    "screenshot":         {"fn": tool_screenshot,          "description": "Take a screenshot of the display",                               "danger": False},
    "get_volume":         {"fn": tool_get_volume,          "description": "Get current system volume (0–100)",                              "danger": False},
    "set_volume":         {"fn": tool_set_volume,          "description": "Set system volume to level (0–100)",                             "danger": False},
    "mute_volume":        {"fn": tool_mute_volume,         "description": "Mute system audio",                                              "danger": False},

    # Clipboard
    "get_clipboard":      {"fn": tool_get_clipboard,       "description": "Read current clipboard text",                                    "danger": False},
    "set_clipboard":      {"fn": tool_set_clipboard,       "description": "Copy text to clipboard",                                         "danger": False},

    # Apps & browser
    "open_url":           {"fn": tool_open_url,            "description": "Open a URL in the default browser",                              "danger": False},
    "open_application":   {"fn": tool_open_application,    "description": "Launch any app by name or open a file with its default app",     "danger": False},

    # Internet
    "weather":            {"fn": tool_weather,             "description": "Current weather for a city (no API key needed)",                 "danger": False},
    "ping":               {"fn": tool_ping,                "description": "Ping a host and report latency/packet loss",                     "danger": False},
    "internet_speed":     {"fn": tool_internet_speed,      "description": "Check internet connectivity to multiple endpoints",              "danger": False},

    # Time
    "datetime":           {"fn": tool_datetime,            "description": "Current date, time, timezone, week number",                      "danger": False},
    "reminder":           {"fn": tool_reminder,            "description": "Set a timed reminder that fires via Telegram",                   "danger": False},

    # Dev
    "python_info":        {"fn": tool_python_info,         "description": "Python version, executable, installed packages",                 "danger": False},
    "env_vars":           {"fn": tool_env_vars,            "description": "List environment variables (sensitive ones redacted)",           "danger": False},
    "git_status":         {"fn": tool_git_status,          "description": "git status for a repository",                                    "danger": False},
    "git_log":            {"fn": tool_git_log,             "description": "Recent git commits with author and time",                        "danger": False},
    "pip_install":        {"fn": tool_pip_install,         "description": "Install a Python package via pip",                               "danger": True},
    "pip_list":           {"fn": tool_pip_list,            "description": "List all installed Python packages",                             "danger": False},

    # Math/text
    "calculate":          {"fn": tool_calculate,           "description": "Evaluate a mathematical expression safely",                      "danger": False},
    "word_count":         {"fn": tool_word_count,          "description": "Count words, lines, characters in text or file",                 "danger": False},

    # Fallback
    "clarify":            {"fn": tool_clarify,             "description": "Ask the user to clarify their request",                          "danger": False},
}


# ===========================================================================
# DISPATCHER
# ===========================================================================

async def run_tool(name: str, args: dict) -> dict:
    if not isinstance(args, dict):
        args = {}
    entry = TOOLS.get(name)
    if entry is None:
        return {"error": f"Unknown tool: '{name}'. Available: {', '.join(sorted(TOOLS.keys()))}"}
    fn = entry["fn"]
    t_start = time.monotonic()
    result: dict
    try:
        result = await asyncio.wait_for(fn(**args), timeout=TOOL_TIMEOUT + 15)
    except asyncio.TimeoutError:
        result = {"error": f"Tool '{name}' timed out after {TOOL_TIMEOUT:.0f}s"}
    except TypeError as exc:
        result = {"error": f"Wrong arguments for tool '{name}': {exc}"}
    except Exception as exc:
        log.exception("Tool '%s' crashed", name)
        result = {"error": f"Tool '{name}' crashed: {exc}"}
    duration_ms = (time.monotonic() - t_start) * 1000
    log_task(name, args, result, duration_ms)
    if "error" in result:
        log.warning("Tool '%s' error (%.1fms): %s", name, duration_ms, result["error"])
    else:
        log.debug("Tool '%s' ok (%.1fms)", name, duration_ms)
    return result


def tool_list_for_prompt() -> str:
    lines: list[str] = []
    for name, entry in TOOLS.items():
        danger = " ⚠️ DANGEROUS — requires confirm=true" if entry["danger"] else ""
        lines.append(f"  {name}: {entry['description']}{danger}")
    return "\n".join(lines)
