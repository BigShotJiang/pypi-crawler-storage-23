"""prlens: AI-powered GitHub PR code reviewer for teams."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("prlens")
except PackageNotFoundError:
    __version__ = "unknown"
