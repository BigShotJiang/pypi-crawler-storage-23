from abc import ABC, abstractmethod


class BaseReviewer(ABC):
    @abstractmethod
    def review(
        self,
        description: str,
        file_name: str,
        diff_patch: str,
        file_content: str,
        guidelines: str,
    ) -> list[dict]:
        """
        Review a file diff and return a list of inline comments.

        Returns:
            List of dicts: [{"line": int, "comment": str}, ...]
        """
