"""Tests for diff position calculation — critical for correct GitHub comment placement."""

from prlens.reviewer import get_diff_positions


def test_single_hunk():
    patch = """\
@@ -1,3 +1,4 @@
 line one
+line two added
 line three
 line four"""
    positions = get_diff_positions(patch)
    # @@ is not counted; " line one" = pos 1, "+line two added" = pos 2
    assert positions[2] == 2  # new file line 2 is at diff position 2


def test_position_is_cumulative_across_hunks():
    """diff_position must NOT reset between hunks — GitHub API requires cumulative positions."""
    patch = """\
@@ -1,2 +1,3 @@
 context a
+added in hunk 1
 context b
@@ -10,2 +11,3 @@
 context c
+added in hunk 2
 context d"""
    positions = get_diff_positions(patch)
    # Hunk 1: " context a" = pos 1, "+added in hunk 1" = pos 2 → file line 2
    assert positions[2] == 2
    # Hunk 2 (positions are cumulative, @@ not counted):
    # pos 3=" context b", pos 4=" context c", pos 5="+added in hunk 2" → file line 12
    assert positions[12] == 5


def test_removed_lines_do_not_increment_new_file_line():
    patch = """\
@@ -1,3 +1,2 @@
 context
-removed line
+added line"""
    positions = get_diff_positions(patch)
    # " context" = pos 1 (file line 1), "-removed" = pos 2 (no new file line)
    # "+added line" = pos 3 → file line 2
    assert positions[2] == 3


def test_empty_patch():
    assert get_diff_positions("") == {}


def test_no_added_lines():
    patch = """\
@@ -1,2 +1,1 @@
 context line
-removed line"""
    positions = get_diff_positions(patch)
    assert positions == {}
