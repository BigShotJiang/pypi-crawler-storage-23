from .main import main

def start():
    """Launch the Platypus Music Player."""
    try:
        app = main()
        app.main_loop()
    except Exception as e:
        print(f"Error launching Platypus Player: {e}")