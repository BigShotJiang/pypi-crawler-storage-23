import toga
import os
import json
import pygame
import random
from toga.style.pack import CENTER, COLUMN, ROW, Pack
import tkinter as tk
from tkinter import filedialog
from pathlib import Path
from mutagen.mp3 import MP3
from mutagen.easyid3 import EasyID3
from playsound import playsound # type: ignore



class Graze(toga.App):
    def startup(self):
        pygame.mixer.init()
        self.playing = 0
        self.on = 0
        self.selected = 1
        self.filename = ""
        self.platypus_data = {}
        self.songs=[]
        self.realsongs = []
        self.number=0
        self.added = 0
        self.main_window = toga.MainWindow()
        self.home = toga.Box(
            children=[     
                toga.Box(
                    children=[
                        toga.Button(
                            "import",
                            on_press=self.load,
                            style=Pack(margin_left=5),
                        ),
                        toga.Button(
                            "add",
                            on_press=self.add,
                            style=Pack(margin_left=5),
                        ),
                        toga.Button(
                            "new",
                            on_press=self.new,
                            style=Pack(margin_left=5),
                        ),
                        toga.Box(
                            children=[
                                toga.Button(
                                    "⏯︎",
                                    on_press=self.pause
                                )
                            ]
                        )
                    ],
                    style=Pack(
                        direction=ROW,
                        align_items=CENTER,
                        margin=5,
                    ),
                ),
            ],
            style=Pack(
                direction=COLUMN,
                
                margin=5,
            ),
        )
        self.main = toga.Box(
            children=[
            ],
            style=Pack(direction=COLUMN),
        )
        
        self.main_window.content=self.main
        self.main_window.show()
        self.main.add(self.home)
        
    async def load(self, widget):
            
        selected_file = await widget.window.open_file_dialog(
            title="Select your .platypus file",
            file_types=["platypus"]
        )
            
        if selected_file is not None:
           
            self.load_platypus(selected_file)


    def load_platypus(self, filename):
        self.filename = filename
        print(f"normal:{filename}")
        print(f"self:{self.filename}")
        global platypus_data
        if os.path.exists(filename):
            with open(filename, 'r') as f:
                self.platypus_data = json.load(f)
        else:
            self.platypus_data = {}
        self.show()

    def add_data(self, name, data):
    
        self.platypus_data[name] = data
    def read_data(self, name):
    
        return self.platypus_data.get(name)
    def delete_from_data_list(self, name, item_to_remove):
        # Check if the name exists and if it is actually a list
        if name in self.platypus_data and isinstance(self.platypus_data[name], list):
            if item_to_remove in self.platypus_data[name]:
                self.platypus_data[name].remove(item_to_remove)
                print(f"Removed {item_to_remove} from {name}")
    def save_platypus(self):
        
        with open(self.filename, 'w') as f:
            json.dump(self.platypus_data, f, indent=4)

    

    def delete_data(self,name):
        """Removes a specific entry from your data."""
        if name in self.platypus_data:
            del self.platypus_data[name]
            print(f"xx Deleted '{name}' from the platypus.")
        else:
            print(f"?? Could not find '{name}' to delete.")
    def get_mp3_songs(self):
        
        root = tk.Tk()
        root.withdraw()
        
        
        file_paths = filedialog.askopenfilenames(
            title="Select MP3 Files",
            filetypes=[("Audio Files", "*.mp3")]
        )
        
        
        songs = list(file_paths)
        
        
        print(f"Added {len(songs)} songs to the list.")
        
        return songs
    
    def add(self,widget):
        self.newsongs = self.get_mp3_songs()
        songs = []
        for song in self.read_data("songs"):
            
            songs.append(song)
        for song in self.newsongs:
            songs.append(song)
        self.songs = songs
        self.delete_data("songs")
        self.add_data("songs", songs)
        self.save_platypus()
        self.update()
    def create_data_file(self):
        
        root = tk.Tk()
        root.withdraw()
        file_path = filedialog.asksaveasfilename(
            initialfile='data.platypus',
            defaultextension=".platypus",
            filetypes=[("Platypus Files", "*.platypus"), ("All Files", "*.*")],
            title="Choose where to save your data file"
        )

        
        if file_path:
            
            with open(file_path, 'w') as f:
                f.write("") 
            
            print(f"File created at: {file_path}")
            return file_path
        else:
            print("Save operation cancelled.")
            return None
    def new(self,widget):
        self.filename = self.create_data_file()
        self.add_data("songs",[])
        self.add_data("playlists",[])

    def get_mp3_title(self,file_path):
        try:
            # Use EasyID3 for a simpler key/value interface to common tags
            audio = EasyID3(file_path)
            # The 'title' key holds the song name
            if 'title' in audio:
                return audio['title'][0]
            else:
                return "Title not found in ID3 tags"
        except Exception as e:
            # Fallback to the general MP3 object if EasyID3 fails or tags are missing
            try:
                audio = MP3(file_path)
                if 'TIT2' in audio:
                    # 'TIT2' is the standard ID3v2 tag for the song title
                    return audio['TIT2'].text[0]
                else:
                    return "Title not found in ID3 tags"
            except Exception as e:
                return f"Error reading file metadata: {e}"
    def play(self,widget):
        if widget.id is not None:
            song = self.songs[int(widget.id)-1]
            pygame.mixer.music.load(song)
        else:
            song = random.choice(self.songs)
            pygame.mixer.music.load(song)
        pygame.mixer.music.play()
        self.selected = 1
        self.on = 1

    def pause(self,widget):
        print("D:")
        if self.on == 0:
            if self.selected == 0:
                print("random")
                self.play()
            else:
                print("unpause")
                self.on = 1
                pygame.mixer.music.unpause()
        else:
            print("pause")
            self.on = 0
            pygame.mixer.music.pause()



    def make(self,name):
        lable = toga.Label(name)
        button = toga.Button("▶", id=self.number, on_press=self.play)
        box = toga.Box(
            children=[
                lable,
                button
            ]
        )
        return box




    def show(self):
        self.songs = self.read_data("songs")
        for song in self.songs:
            self.number += 1
            songname = self.get_mp3_title(song)
            
            self.home.add(self.make(songname))

    def update(self):
        print(f"self:{self.number}")
        if self.added == 0:
            number = self.number
        else:
            number = self.number - 1
        print(f"new:{number}")
        new = self.songs[number:]
        print(f"songs:{new}")
        for song in new:
            print(song)
            self.number += 1
            songname = self.get_mp3_title(song)
            self.home.add(self.make(songname))
            



def main():
    return Graze("Bean Browser", "org.beeware.toga.examples.tutorial")

if __name__ == "__main__":
    # This is the standard way to launch on Windows
    app = main()
    app.main_loop()