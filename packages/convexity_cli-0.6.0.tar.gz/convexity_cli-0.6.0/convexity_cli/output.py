"""Output formatting utilities for Convexity CLI.

All output is JSON formatted for easy parsing and scripting.
"""

from datetime import datetime
from enum import Enum
import json
import sys
from typing import Any

from pydantic import BaseModel


class JSONEncoder(json.JSONEncoder):
    """Custom JSON encoder that handles Pydantic models and other types."""

    def default(self, o: Any) -> Any:
        if isinstance(o, BaseModel):
            return o.model_dump(mode="json")
        if isinstance(o, datetime):
            return o.isoformat()
        if isinstance(o, Enum):
            return o.value
        if hasattr(o, "__dict__"):
            return o.__dict__
        return super().default(o)


def output_json(data: Any, indent: int = 2) -> None:
    """Output data as formatted JSON to stdout.

    Args:
        data: Data to output (dict, list, Pydantic model, etc.)
        indent: Indentation level for pretty printing
    """
    if isinstance(data, BaseModel):
        # Use Pydantic's built-in JSON serialization
        print(data.model_dump_json(indent=indent))
    else:
        print(json.dumps(data, indent=indent, cls=JSONEncoder))


def output_error(error: dict[str, Any] | str, exit_code: int = 1) -> None:
    """Output an error as JSON to stderr.

    Args:
        error: Error message or dict with error details
        exit_code: Exit code to use (not actually exits, just includes in output)
    """
    if isinstance(error, str):
        error_obj = {"error": error, "exit_code": exit_code}
    else:
        error_obj = {"error": error, "exit_code": exit_code}

    print(json.dumps(error_obj, indent=2, cls=JSONEncoder), file=sys.stderr)


def output_success(message: str, data: Any | None = None) -> None:
    """Output a success message as JSON.

    Args:
        message: Success message
        data: Optional additional data to include
    """
    result: dict[str, Any] = {"success": True, "message": message}
    if data is not None:
        result["data"] = data
    output_json(result)


def output_list(
    items: list[Any],
    total: int | None = None,
    page: int | None = None,
    page_size: int | None = None,
) -> None:
    """Output a list of items as JSON.

    Args:
        items: List of items to output
        total: Total number of items (for pagination)
        page: Current page number
        page_size: Number of items per page
    """
    result: dict[str, Any] = {"items": items, "count": len(items)}

    if total is not None:
        result["total"] = total
    if page is not None:
        result["page"] = page
    if page_size is not None:
        result["page_size"] = page_size

    output_json(result)


def format_resource_id(resource_id: str, max_display: int = 12) -> str:
    """Format a resource ID for display (masked for security).

    Args:
        resource_id: The full resource ID
        max_display: Maximum characters to show

    Returns:
        Masked resource ID (e.g., "proj_abc...xyz")
    """
    if len(resource_id) <= max_display:
        return resource_id

    prefix_len = max_display // 2
    suffix_len = max_display - prefix_len - 3  # -3 for "..."

    return f"{resource_id[:prefix_len]}...{resource_id[-suffix_len:]}"


def format_api_key(api_key: str) -> str:
    """Format an API key for display (masked for security).

    Args:
        api_key: The full API key

    Returns:
        Masked API key (e.g., "cvx_xxx...xxx")
    """
    if len(api_key) <= 12:
        return api_key[:4] + "..." + api_key[-4:] if len(api_key) > 8 else "***"

    return f"{api_key[:7]}...{api_key[-4:]}"


def format_datetime(dt: datetime | str | None) -> str | None:
    """Format a datetime for JSON output.

    Args:
        dt: Datetime to format

    Returns:
        ISO formatted datetime string or None
    """
    if dt is None:
        return None
    if isinstance(dt, str):
        return dt
    return dt.isoformat()
