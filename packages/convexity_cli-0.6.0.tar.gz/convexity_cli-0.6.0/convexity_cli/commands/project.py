"""Project management commands for Convexity CLI.

Commands:
    list   - List all projects in an organization
    create - Create a new project
    delete - Delete a project
    pull   - Pull remote project to local folder
    push   - Push local project to remote
"""

from pathlib import Path
import shutil
from typing import Annotated, Any

from convexity_api_client.api.v1 import (
    create_dashboard_v1_dashboards_post,
    create_dataset_v1_datasets_post,
    create_project_v1_projects_post,
    create_task_v1_tasks_post,
    delete_connection_v1_connections_connection_id_delete,
    delete_dashboard_v1_dashboards_dashboard_id_delete,
    delete_dataset_v1_datasets_dataset_id_delete,
    delete_project_v1_projects_project_id_delete,
    delete_task_v1_tasks_task_id_delete,
    get_project_v1_projects_project_id_get,
    list_connections_v1_connections_get,
    list_dashboards_v1_dashboards_get,
    list_datasets_v1_datasets_get,
    list_organization_projects_v1_organizations_organization_id_projects_get,
    list_tasks_v1_tasks_get,
    list_user_projects_v1_projects_get,
    update_connection_v1_connections_connection_id_patch,
    update_dashboard_v1_dashboards_dashboard_id_patch,
    update_dataset_v1_datasets_dataset_id_patch,
    update_task_v1_tasks_task_id_patch,
)
from convexity_api_client.models import (
    ConnectionListResponse,
    CreateDashboardRequest,
    CreateDatasetRequest,
    CreateProjectRequest,
    CreateTaskRequest,
    DashboardDefinition,
    DashboardListResponse,
    DatasetDefinition,
    DatasetListResponse,
    ProjectListResponse,
    ProjectResponse,
    TaskListResponse,
    TaskModel,
    TaskScenario,
    UpdateConnectionRequest,
    UpdateDashboardRequest,
    UpdateDatasetRequest,
    UpdateTaskRequest,
)
from convexity_api_client.types import UNSET
import typer
import yaml

from convexity_cli.commands.utils import get_authenticated_client
from convexity_cli.config import get_config_manager
from convexity_cli.exceptions import APIError, ProjectError
from convexity_cli.output import output_json, output_list, output_success

app = typer.Typer(
    name="project",
    help="Manage projects within an organization.",
    no_args_is_help=True,
    rich_markup_mode=None,
)


# =============================================================================
# Helper functions for local project view
# =============================================================================


def get_openapi_path() -> Path:
    """Get the path to the openapi.json file in the Convexity installation."""
    # Try to find openapi.json relative to this file
    cli_path = Path(__file__).parent.parent.parent.parent
    openapi_path = cli_path / "openapi.json"
    if openapi_path.exists():
        return openapi_path

    # Fallback: check current working directory
    cwd_path = Path.cwd() / "openapi.json"
    if cwd_path.exists():
        return cwd_path

    raise ProjectError("Could not find openapi.json. Please ensure Convexity is properly installed.")


def create_project_folder(output_dir: Path) -> None:
    """Create the project folder structure."""
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / ".schemas").mkdir(exist_ok=True)
    (output_dir / "connections").mkdir(exist_ok=True)
    (output_dir / "tasks").mkdir(exist_ok=True)
    (output_dir / "datasets").mkdir(exist_ok=True)
    (output_dir / "dashboards").mkdir(exist_ok=True)


def copy_openapi_schema(output_dir: Path) -> None:
    """Copy openapi.json to the project's .schemas folder."""
    try:
        openapi_source = get_openapi_path()
        schema_dest = output_dir / ".schemas" / "openapi.json"
        shutil.copy2(openapi_source, schema_dest)
    except Exception as e:
        # Non-fatal: warn but continue
        typer.echo(f"Warning: Could not copy schema files: {e}", err=True)


def write_yaml_file(path: Path, data: dict[str, Any], schema_ref: str | None = None) -> None:
    """Write a YAML file with optional schema reference."""
    content = ""
    if schema_ref:
        content = f"# yaml-language-server: $schema={schema_ref}\n"

    content += yaml.dump(data, default_flow_style=False, sort_keys=False, allow_unicode=True)

    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)


def read_yaml_file(path: Path) -> dict[str, Any]:
    """Read a YAML file and return its contents."""
    with open(path, encoding="utf-8") as f:
        content = yaml.safe_load(f)
    return content or {}


def sanitize_filename(name: str) -> str:
    """Convert a name to a safe filename."""
    # Replace spaces and special characters with hyphens
    safe = "".join(c if c.isalnum() or c in "-_" else "-" for c in name.lower())
    # Remove multiple consecutive hyphens
    while "--" in safe:
        safe = safe.replace("--", "-")
    return safe.strip("-")


# =============================================================================
# Push helper functions
# =============================================================================


class PushResult:
    """Track the results of a push operation."""

    def __init__(self) -> None:
        self.created: list[dict[str, Any]] = []
        self.updated: list[dict[str, Any]] = []
        self.deleted: list[dict[str, Any]] = []
        self.skipped: list[dict[str, Any]] = []
        self.errors: list[dict[str, Any]] = []
        # Track ID mappings: (resource_type, old_id_or_name) -> new_id
        self.id_mappings: dict[tuple[str, str], str] = {}

    def add_created(self, resource_type: str, name: str, resource_id: str, old_id: str | None = None) -> None:
        self.created.append({"type": resource_type, "name": name, "id": resource_id})
        # Track mapping by both name and old_id (if present) to new_id
        self.id_mappings[(resource_type, name)] = resource_id
        if old_id:
            self.id_mappings[(resource_type, old_id)] = resource_id

    def add_updated(self, resource_type: str, name: str, resource_id: str) -> None:
        self.updated.append({"type": resource_type, "name": name, "id": resource_id})

    def add_deleted(self, resource_type: str, name: str, resource_id: str) -> None:
        self.deleted.append({"type": resource_type, "name": name, "id": resource_id})

    def add_skipped(self, resource_type: str, name: str, reason: str) -> None:
        self.skipped.append({"type": resource_type, "name": name, "reason": reason})

    def add_error(self, resource_type: str, name: str, error: str) -> None:
        self.errors.append({"type": resource_type, "name": name, "error": error})

    def resolve_id(self, resource_type: str, id_or_name: str | None) -> str | None:
        """Resolve an ID or name to the current remote ID using mappings."""
        if not id_or_name:
            return None
        # Check if we have a mapping for this ID/name
        key = (resource_type, id_or_name)
        return self.id_mappings.get(key, id_or_name)

    def to_dict(self) -> dict[str, Any]:
        return {
            "created": self.created,
            "updated": self.updated,
            "deleted": self.deleted,
            "skipped": self.skipped,
            "errors": self.errors,
            "summary": {
                "created_count": len(self.created),
                "updated_count": len(self.updated),
                "deleted_count": len(self.deleted),
                "skipped_count": len(self.skipped),
                "error_count": len(self.errors),
            },
        }


def update_dashboard_references(directory: Path, result: PushResult) -> None:
    """Update dashboard widget references after resources are created.

    This fixes references to datasets, tasks, and connections that received
    new IDs during the push operation.
    """
    dashboards_dir = directory / "dashboards"
    if not dashboards_dir.exists():
        return

    for yaml_file in dashboards_dir.glob("*.yaml"):
        dash_data = read_yaml_file(yaml_file)
        updated = False

        # Update widget references
        widgets = dash_data.get("widgets", [])
        if widgets:
            for widget in widgets:
                # Update dataset_id reference
                if "dataset_id" in widget and widget["dataset_id"]:
                    new_id = result.resolve_id("dataset", widget["dataset_id"])
                    if new_id and new_id != widget["dataset_id"]:
                        widget["dataset_id"] = new_id
                        updated = True

                # Update task_id reference
                if "task_id" in widget and widget["task_id"]:
                    new_id = result.resolve_id("task", widget["task_id"])
                    if new_id and new_id != widget["task_id"]:
                        widget["task_id"] = new_id
                        updated = True

                # Update connection_id reference
                if "connection_id" in widget and widget["connection_id"]:
                    new_id = result.resolve_id("connection", widget["connection_id"])
                    if new_id and new_id != widget["connection_id"]:
                        widget["connection_id"] = new_id
                        updated = True

        if updated:
            write_yaml_file(
                yaml_file,
                dash_data,
                schema_ref="../.schemas/openapi.json#/components/schemas/DashboardDefinition",
            )


def push_tasks(
    client: Any,
    project_id: str,
    directory: Path,
    remote_tasks: list[Any],
    result: PushResult,
    delete_missing: bool = False,
) -> None:
    """Push local tasks to remote."""
    tasks_dir = directory / "tasks"

    # Build a map of remote tasks by ID for quick lookup
    remote_task_map: dict[str, Any] = {}
    for task in remote_tasks:
        task_dict = task.to_dict()
        remote_task_map[task_dict.get("id", "")] = task_dict

    # Collect local task IDs
    local_task_ids: set[str] = set()

    if tasks_dir.exists():
        for task_subdir in tasks_dir.iterdir():
            if not task_subdir.is_dir():
                continue

            task_yaml = task_subdir / "task.yaml"
            if not task_yaml.exists():
                continue

            task_data = read_yaml_file(task_yaml)
            task_id = task_data.get("id")
            task_name = task_data.get("name", task_subdir.name)

            if task_id:
                local_task_ids.add(task_id)

            # Note: Task code sync (code.py) is reserved for future notebook sync support

            try:
                if task_id and task_id in remote_task_map:
                    # Update existing task
                    update_request = UpdateTaskRequest(
                        name=task_data.get("name"),
                        description=task_data.get("description"),
                    )

                    response = update_task_v1_tasks_task_id_patch.sync_detailed(
                        task_id=task_id,
                        client=client,
                        body=update_request,
                    )

                    if response.status_code == 200 and isinstance(response.parsed, TaskModel):
                        result.add_updated("task", task_name, task_id)
                    else:
                        result.add_error("task", task_name, f"Update failed: {response.status_code}")
                else:
                    # Create new task
                    scenario_str = task_data.get("scenario", "OPTIMIZATION")
                    try:
                        scenario = TaskScenario(scenario_str.upper())
                    except ValueError:
                        scenario = TaskScenario.OPTIMIZATION

                    create_request = CreateTaskRequest(
                        name=task_name,
                        project_id=project_id,
                        scenario=scenario,
                        description=task_data.get("description"),
                    )

                    response = create_task_v1_tasks_post.sync_detailed(
                        client=client,
                        body=create_request,
                        project_id=project_id,
                    )

                    if response.status_code == 201 and isinstance(response.parsed, TaskModel):
                        new_id = response.parsed.id
                        if new_id and not isinstance(new_id, type(UNSET)):
                            result.add_created("task", task_name, new_id, old_id=task_id)
                            local_task_ids.add(new_id)

                            # Update local YAML with new ID
                            task_data["id"] = new_id
                        write_yaml_file(
                            task_yaml,
                            task_data,
                            schema_ref="../../.schemas/openapi.json#/components/schemas/TaskModel",
                        )
                    else:
                        result.add_error("task", task_name, f"Create failed: {response.status_code}")
            except Exception as e:
                result.add_error("task", task_name, str(e))

    # Delete remote tasks that don't exist locally
    if delete_missing:
        for remote_id, remote_task in remote_task_map.items():
            if remote_id and remote_id not in local_task_ids:
                task_name = remote_task.get("name", remote_id)
                try:
                    response = delete_task_v1_tasks_task_id_delete.sync_detailed(
                        task_id=remote_id,
                        client=client,
                    )
                    if response.status_code in (200, 204):
                        result.add_deleted("task", task_name, remote_id)
                    else:
                        result.add_error("task", task_name, f"Delete failed: {response.status_code}")
                except Exception as e:
                    result.add_error("task", task_name, str(e))


def push_datasets(
    client: Any,
    project_id: str,
    directory: Path,
    remote_datasets: list[DatasetDefinition],
    result: PushResult,
    delete_missing: bool = False,
) -> None:
    """Push local datasets to remote."""
    datasets_dir = directory / "datasets"

    # Build a map of remote datasets by ID
    remote_dataset_map: dict[str, DatasetDefinition] = {}
    for ds in remote_datasets:
        ds_dict = ds.to_dict()
        remote_dataset_map[ds_dict.get("id", "")] = ds

    # Collect local dataset IDs
    local_dataset_ids: set[str] = set()

    if datasets_dir.exists():
        for yaml_file in datasets_dir.glob("*.yaml"):
            ds_data = read_yaml_file(yaml_file)
            ds_id = ds_data.get("id")
            ds_name = ds_data.get("name", yaml_file.stem)

            if ds_id:
                local_dataset_ids.add(ds_id)

            try:
                if ds_id and ds_id in remote_dataset_map:
                    # Update existing dataset
                    update_request = UpdateDatasetRequest(
                        name=ds_data.get("name"),
                        description=ds_data.get("description"),
                    )

                    response = update_dataset_v1_datasets_dataset_id_patch.sync_detailed(
                        dataset_id=ds_id,
                        client=client,
                        body=update_request,
                    )

                    if response.status_code == 200 and isinstance(response.parsed, DatasetDefinition):
                        result.add_updated("dataset", ds_name, ds_id)
                    else:
                        result.add_error("dataset", ds_name, f"Update failed: {response.status_code}")
                else:
                    # Create new dataset - requires type and config
                    ds_type = ds_data.get("type")
                    ds_config = ds_data.get("config")

                    if not ds_type or not ds_config:
                        result.add_skipped("dataset", ds_name, "Missing required type or config")
                        continue

                    # Import dataset types
                    from convexity_api_client.models import DatasetConfig, DatasetType

                    try:
                        dataset_type = DatasetType(ds_type.upper())
                    except ValueError:
                        result.add_skipped("dataset", ds_name, f"Invalid dataset type: {ds_type}")
                        continue

                    # Try to construct config
                    try:
                        config = DatasetConfig.from_dict(ds_config)
                    except Exception as config_err:
                        result.add_error("dataset", ds_name, f"Invalid config: {config_err}")
                        continue

                    create_request = CreateDatasetRequest(
                        project_id=project_id,
                        name=ds_name,
                        type_=dataset_type,
                        config=config,
                        description=ds_data.get("description"),
                    )

                    response = create_dataset_v1_datasets_post.sync_detailed(
                        client=client,
                        body=create_request,
                        project_id=project_id,
                    )

                    if response.status_code == 201 and isinstance(response.parsed, DatasetDefinition):
                        new_id = response.parsed.id
                        result.add_created("dataset", ds_name, new_id, old_id=ds_id)
                        local_dataset_ids.add(new_id)

                        # Update local YAML with new ID
                        ds_data["id"] = new_id
                        write_yaml_file(
                            yaml_file,
                            ds_data,
                            schema_ref="../.schemas/openapi.json#/components/schemas/DatasetDefinition",
                        )
                    else:
                        result.add_error("dataset", ds_name, f"Create failed: {response.status_code}")
            except Exception as e:
                result.add_error("dataset", ds_name, str(e))

    # Delete remote datasets that don't exist locally
    if delete_missing:
        for remote_id, remote_ds in remote_dataset_map.items():
            if remote_id and remote_id not in local_dataset_ids:
                ds_name = remote_ds.name
                try:
                    response = delete_dataset_v1_datasets_dataset_id_delete.sync_detailed(
                        dataset_id=remote_id,
                        client=client,
                    )
                    if response.status_code in (200, 204):
                        result.add_deleted("dataset", ds_name, remote_id)
                    else:
                        result.add_error("dataset", ds_name, f"Delete failed: {response.status_code}")
                except Exception as e:
                    result.add_error("dataset", ds_name, str(e))


def push_dashboards(
    client: Any,
    project_id: str,
    directory: Path,
    remote_dashboards: list[Any],
    result: PushResult,
    delete_missing: bool = False,
) -> None:
    """Push local dashboards to remote."""
    dashboards_dir = directory / "dashboards"

    # Build a map of remote dashboards by ID
    remote_dashboard_map: dict[str, Any] = {}
    for dash in remote_dashboards:
        dash_dict = dash.to_dict()
        remote_dashboard_map[dash_dict.get("id", "")] = dash_dict

    # Collect local dashboard IDs
    local_dashboard_ids: set[str] = set()

    if dashboards_dir.exists():
        for yaml_file in dashboards_dir.glob("*.yaml"):
            dash_data = read_yaml_file(yaml_file)
            dash_id = dash_data.get("id")
            dash_name = dash_data.get("name", yaml_file.stem)

            if dash_id:
                local_dashboard_ids.add(dash_id)

            try:
                if dash_id and dash_id in remote_dashboard_map:
                    # Update existing dashboard
                    from convexity_api_client.models import DashboardLayout

                    update_request = UpdateDashboardRequest(
                        name=dash_data.get("name"),
                        description=dash_data.get("description"),
                    )

                    # Handle widgets if present
                    if "widgets" in dash_data and dash_data["widgets"]:
                        try:
                            from convexity_api_client.models import (
                                DashboardChartWidget,
                                DashboardDateFilterWidget,
                                DashboardDateRangeFilterWidget,
                                DashboardEChartWidget,
                                DashboardMultiSelectFilterWidget,
                                DashboardNumberFilterWidget,
                                DashboardNumberRangeFilterWidget,
                                DashboardS3ObjectWidget,
                                DashboardSelectFilterWidget,
                                DashboardSqlChartWidget,
                                DashboardTableWidget,
                                DashboardTaskWidget,
                                DashboardTextFilterWidget,
                                DashboardTextWidget,
                            )

                            widget_type_map = {
                                "chart": DashboardChartWidget,
                                "sqlchart": DashboardSqlChartWidget,
                                "task": DashboardTaskWidget,
                                "s3object": DashboardS3ObjectWidget,
                                "echart": DashboardEChartWidget,
                                "table": DashboardTableWidget,
                                "text": DashboardTextWidget,
                                "select_filter": DashboardSelectFilterWidget,
                                "multi_filter": DashboardMultiSelectFilterWidget,
                                "date_filter": DashboardDateFilterWidget,
                                "daterange_filter": DashboardDateRangeFilterWidget,
                                "text_filter": DashboardTextFilterWidget,
                                "number_filter": DashboardNumberFilterWidget,
                                "numberrange_filter": DashboardNumberRangeFilterWidget,
                            }

                            widgets_list = []
                            for w in dash_data["widgets"]:
                                w_type = w.get("type")
                                if w_type in widget_type_map:
                                    widget_class = widget_type_map[w_type]
                                    widgets_list.append(widget_class.from_dict(w))
                            update_request.widgets = widgets_list
                        except Exception:
                            pass  # Skip widgets if parsing fails

                    # Handle layout if present
                    if "layout" in dash_data and dash_data["layout"]:
                        try:
                            layout = DashboardLayout.from_dict(dash_data["layout"])
                            update_request.layout = layout
                        except Exception:
                            pass  # Skip layout if parsing fails

                    response = update_dashboard_v1_dashboards_dashboard_id_patch.sync_detailed(
                        dashboard_id=dash_id,
                        client=client,
                        body=update_request,
                    )

                    if response.status_code == 200 and isinstance(response.parsed, DashboardDefinition):
                        result.add_updated("dashboard", dash_name, dash_id)
                    else:
                        result.add_error("dashboard", dash_name, f"Update failed: {response.status_code}")
                else:
                    # Create new dashboard with widgets and layout if present
                    from convexity_api_client.models import DashboardLayout

                    # Parse widgets if present
                    widgets_list = None
                    if "widgets" in dash_data and dash_data["widgets"]:
                        try:
                            # Import all widget types for parsing
                            from convexity_api_client.models import (
                                DashboardChartWidget,
                                DashboardDateFilterWidget,
                                DashboardDateRangeFilterWidget,
                                DashboardEChartWidget,
                                DashboardMultiSelectFilterWidget,
                                DashboardNumberFilterWidget,
                                DashboardNumberRangeFilterWidget,
                                DashboardS3ObjectWidget,
                                DashboardSelectFilterWidget,
                                DashboardSqlChartWidget,
                                DashboardTableWidget,
                                DashboardTaskWidget,
                                DashboardTextFilterWidget,
                                DashboardTextWidget,
                            )

                            widget_type_map = {
                                "chart": DashboardChartWidget,
                                "sqlchart": DashboardSqlChartWidget,
                                "task": DashboardTaskWidget,
                                "s3object": DashboardS3ObjectWidget,
                                "echart": DashboardEChartWidget,
                                "table": DashboardTableWidget,
                                "text": DashboardTextWidget,
                                "select_filter": DashboardSelectFilterWidget,
                                "multi_filter": DashboardMultiSelectFilterWidget,
                                "date_filter": DashboardDateFilterWidget,
                                "daterange_filter": DashboardDateRangeFilterWidget,
                                "text_filter": DashboardTextFilterWidget,
                                "number_filter": DashboardNumberFilterWidget,
                                "numberrange_filter": DashboardNumberRangeFilterWidget,
                            }

                            widgets_list = []
                            for w in dash_data["widgets"]:
                                w_type = w.get("type")
                                if w_type in widget_type_map:
                                    widget_class = widget_type_map[w_type]
                                    widgets_list.append(widget_class.from_dict(w))
                        except Exception as widget_err:
                            # Log but continue without widgets
                            result.add_skipped("dashboard", f"{dash_name} (widgets)", f"Widget parsing failed: {widget_err}")
                            widgets_list = None

                    # Parse layout if present
                    layout = None
                    if "layout" in dash_data and dash_data["layout"]:
                        try:
                            layout = DashboardLayout.from_dict(dash_data["layout"])
                        except Exception:
                            pass  # Skip layout if parsing fails

                    create_request = CreateDashboardRequest(
                        name=dash_name,
                        project_id=project_id,
                        description=dash_data.get("description"),
                        widgets=widgets_list,
                        layout=layout,
                    )

                    response = create_dashboard_v1_dashboards_post.sync_detailed(
                        client=client,
                        body=create_request,
                        project_id=project_id,
                    )

                    if response.status_code == 201 and isinstance(response.parsed, DashboardDefinition):
                        new_id = response.parsed.id
                        result.add_created("dashboard", dash_name, new_id, old_id=dash_id)
                        local_dashboard_ids.add(new_id)

                        # Update local YAML with new ID
                        dash_data["id"] = new_id
                        write_yaml_file(
                            yaml_file,
                            dash_data,
                            schema_ref="../.schemas/openapi.json#/components/schemas/DashboardDefinition",
                        )
                    else:
                        result.add_error("dashboard", dash_name, f"Create failed: {response.status_code}")
            except Exception as e:
                result.add_error("dashboard", dash_name, str(e))

    # Delete remote dashboards that don't exist locally
    if delete_missing:
        for remote_id, remote_dash in remote_dashboard_map.items():
            if remote_id and remote_id not in local_dashboard_ids:
                dash_name = remote_dash.get("name", remote_id)
                try:
                    response = delete_dashboard_v1_dashboards_dashboard_id_delete.sync_detailed(
                        dashboard_id=remote_id,
                        client=client,
                    )
                    if response.status_code in (200, 204):
                        result.add_deleted("dashboard", dash_name, remote_id)
                    else:
                        result.add_error("dashboard", dash_name, f"Delete failed: {response.status_code}")
                except Exception as e:
                    result.add_error("dashboard", dash_name, str(e))


def push_connections(
    client: Any,
    project_id: str,
    directory: Path,
    remote_connections: list[Any],
    result: PushResult,
    delete_missing: bool = False,
) -> None:
    """Push local connections to remote.

    Note: Connection creation requires knowing the connection type and using
    the appropriate type-specific endpoint. For now, we only support updating
    existing connections (by skipping creation of new ones).
    """
    connections_dir = directory / "connections"

    # Build a map of remote connections by ID
    remote_conn_map: dict[str, Any] = {}
    for conn in remote_connections:
        conn_dict = conn.to_dict()
        remote_conn_map[conn_dict.get("id", "")] = conn_dict

    # Collect local connection IDs
    local_conn_ids: set[str] = set()

    if connections_dir.exists():
        for yaml_file in connections_dir.glob("*.yaml"):
            conn_data = read_yaml_file(yaml_file)
            conn_id = conn_data.get("id")
            conn_name = conn_data.get("name", yaml_file.stem)

            if conn_id:
                local_conn_ids.add(conn_id)

            try:
                if conn_id and conn_id in remote_conn_map:
                    # Update existing connection (basic fields only)
                    update_request = UpdateConnectionRequest(
                        name=conn_data.get("name"),
                        description=conn_data.get("description"),
                    )

                    response = update_connection_v1_connections_connection_id_patch.sync_detailed(
                        connection_id=conn_id,
                        client=client,
                        body=update_request,
                        project_id=project_id,
                    )

                    if response.status_code == 200:
                        result.add_updated("connection", conn_name, conn_id)
                    else:
                        result.add_error("connection", conn_name, f"Update failed: {response.status_code}")
                else:
                    # Skip creation of new connections - requires type-specific endpoints
                    result.add_skipped("connection", conn_name, "Connection creation requires using type-specific commands")
            except Exception as e:
                result.add_error("connection", conn_name, str(e))

    # Delete remote connections that don't exist locally
    if delete_missing:
        for remote_id, remote_conn in remote_conn_map.items():
            if remote_id and remote_id not in local_conn_ids:
                conn_name = remote_conn.get("name", remote_id)
                try:
                    response = delete_connection_v1_connections_connection_id_delete.sync_detailed(
                        connection_id=remote_id,
                        project_id=project_id,
                        client=client,
                    )
                    if response.status_code in (200, 204):
                        result.add_deleted("connection", conn_name, remote_id)
                    else:
                        result.add_error("connection", conn_name, f"Delete failed: {response.status_code}")
                except Exception as e:
                    result.add_error("connection", conn_name, str(e))


# =============================================================================
# Commands
# =============================================================================


@app.command("list")
def list_projects(
    org_id: Annotated[
        str | None,
        typer.Option("--org", "-o", help="Organization ID"),
    ] = None,
) -> None:
    """List all projects in an organization."""
    with get_authenticated_client() as client:
        if org_id:
            # List projects for specific organization
            response = list_organization_projects_v1_organizations_organization_id_projects_get.sync_detailed(
                organization_id=org_id,
                client=client,
            )
        else:
            # Check if default org is set
            config = get_config_manager().load()
            default_org = config.current_profile.default_org
            if default_org:
                response = list_organization_projects_v1_organizations_organization_id_projects_get.sync_detailed(
                    organization_id=default_org,
                    client=client,
                )
            else:
                # List all projects accessible to user
                response = list_user_projects_v1_projects_get.sync_detailed(client=client)

        if response.status_code == 200 and response.parsed and isinstance(response.parsed, ProjectListResponse):
            projects = [proj.to_dict() for proj in response.parsed.projects]
            output_list(projects)
        else:
            raise APIError(f"Failed to list projects: {response.status_code}")


@app.command("create")
def create_project(
    name: Annotated[str, typer.Argument(help="Project name")],
    org_id: Annotated[
        str,
        typer.Option("--org", "-o", help="Organization ID", prompt=True),
    ],
    slug: Annotated[
        str | None,
        typer.Option("--slug", "-s", help="Project slug (URL-friendly identifier)"),
    ] = None,
    description: Annotated[
        str | None,
        typer.Option("--description", "-d", help="Project description"),
    ] = None,
) -> None:
    """Create a new project in an organization."""
    with get_authenticated_client() as client:
        # Generate slug from name if not provided
        project_slug = slug or sanitize_filename(name)

        request = CreateProjectRequest(
            name=name,
            slug=project_slug,
            organization_id=org_id,
            description=description,
        )

        response = create_project_v1_projects_post.sync_detailed(
            client=client,
            body=request,
        )

        if response.status_code == 201 and response.parsed:
            output_json(response.parsed.to_dict())
        else:
            raise APIError(f"Failed to create project: {response.status_code}")


@app.command("delete")
def delete_project(
    project_id: Annotated[str, typer.Argument(help="Project ID to delete")],
    force: Annotated[
        bool,
        typer.Option("--force", "-f", help="Skip confirmation prompt"),
    ] = False,
) -> None:
    """Delete a project."""
    if not force:
        confirm = typer.confirm(f"Are you sure you want to delete project '{project_id}'? This cannot be undone.")
        if not confirm:
            raise typer.Abort()

    with get_authenticated_client() as client:
        response = delete_project_v1_projects_project_id_delete.sync_detailed(
            project_id=project_id,
            client=client,
        )

        if response.status_code in (200, 204):
            output_success(f"Project '{project_id}' deleted successfully")
        else:
            raise APIError(f"Failed to delete project: {response.status_code}")


@app.command("show")
def show_project(
    project_id: Annotated[str, typer.Argument(help="Project ID")],
) -> None:
    """Show details of a project."""
    with get_authenticated_client() as client:
        response = get_project_v1_projects_project_id_get.sync_detailed(
            project_id=project_id,
            client=client,
        )

        if response.status_code == 200 and response.parsed:
            output_json(response.parsed.to_dict())
        else:
            raise APIError(f"Failed to get project: {response.status_code}")


@app.command("pull")
def pull_project(
    project_id: Annotated[
        str,
        typer.Option("--project", "-p", help="Project ID to pull"),
    ],
    output: Annotated[
        Path | None,
        typer.Option("--output", "-o", help="Output directory (defaults to project slug)"),
    ] = None,
) -> None:
    """Pull a remote project to a local folder.

    Downloads the project configuration, connections, tasks, datasets,
    and dashboards to a local folder for editing.
    """
    with get_authenticated_client() as client:
        # Fetch project details
        project_response = get_project_v1_projects_project_id_get.sync_detailed(
            project_id=project_id,
            client=client,
        )

        if project_response.status_code != 200 or not project_response.parsed or not isinstance(project_response.parsed, ProjectResponse):
            raise APIError(f"Failed to get project: {project_response.status_code}")

        project = project_response.parsed
        project_name = project.name
        project_slug = project.slug or sanitize_filename(project_name)

        # Determine output directory
        output_dir = output or Path(project_slug)

        if output_dir.exists() and any(output_dir.iterdir()):
            # Check for existing convexity.yaml
            if (output_dir / "convexity.yaml").exists():
                confirm = typer.confirm(f"Directory '{output_dir}' already contains a project. Overwrite?")
                if not confirm:
                    raise typer.Abort()
            else:
                raise ProjectError(f"Directory '{output_dir}' exists and is not empty. Use --output to specify a different directory.")

        # Create folder structure
        create_project_folder(output_dir)

        # Copy OpenAPI schema
        copy_openapi_schema(output_dir)

        # Write project manifest (as Project model)
        manifest = project.to_dict()
        write_yaml_file(
            output_dir / "convexity.yaml",
            manifest,
            schema_ref="./.schemas/openapi.json#/components/schemas/Project",
        )

        # Fetch and write connections
        connections_response = list_connections_v1_connections_get.sync_detailed(
            project_id=project_id,
            client=client,
        )
        connections: list[Any] = []
        if connections_response.status_code == 200 and connections_response.parsed and isinstance(connections_response.parsed, ConnectionListResponse):
            connections = connections_response.parsed.connections
        for conn in connections:
            conn_dict = conn.to_dict()
            conn_name = sanitize_filename(conn_dict.get("name", conn_dict.get("id", "connection")))
            # Save as ConnectionDTO model directly
            write_yaml_file(
                output_dir / "connections" / f"{conn_name}.yaml",
                conn_dict,
                schema_ref="../.schemas/openapi.json#/components/schemas/Connection",
            )

        # Fetch and write tasks
        tasks_response = list_tasks_v1_tasks_get.sync_detailed(
            project_id=project_id,
            client=client,
        )
        tasks: list[Any] = []
        if tasks_response.status_code == 200 and tasks_response.parsed and isinstance(tasks_response.parsed, TaskListResponse):
            tasks = tasks_response.parsed.tasks
        for task in tasks:
            task_dict = task.to_dict()
            task_name = sanitize_filename(task_dict.get("name", task_dict.get("id", "task")))
            task_dir = output_dir / "tasks" / task_name
            task_dir.mkdir(parents=True, exist_ok=True)

            # Extract code to separate file if present
            task_code = task_dict.pop("code", None)

            # Save as TaskDTO model directly
            write_yaml_file(
                task_dir / "task.yaml",
                task_dict,
                schema_ref="../../.schemas/openapi.json#/components/schemas/TaskModel",
            )

            # Write task code if present
            if task_code:
                with open(task_dir / "code.py", "w", encoding="utf-8") as f:
                    f.write(task_code)

        # Fetch and write datasets
        datasets_response = list_datasets_v1_datasets_get.sync_detailed(
            project_id=project_id,
            client=client,
        )
        datasets: list[Any] = []
        if datasets_response.status_code == 200 and datasets_response.parsed and isinstance(datasets_response.parsed, DatasetListResponse):
            ds_list = datasets_response.parsed.datasets
            if not isinstance(ds_list, type(UNSET)):
                datasets = ds_list
        for dataset in datasets:
            dataset_dict = dataset.to_dict()
            ds_name = sanitize_filename(dataset_dict.get("name", dataset_dict.get("id", "dataset")))
            # Save as DatasetDefinition model directly
            write_yaml_file(
                output_dir / "datasets" / f"{ds_name}.yaml",
                dataset_dict,
                schema_ref="../.schemas/openapi.json#/components/schemas/DatasetDefinition",
            )

        # Fetch and write dashboards
        dashboards_response = list_dashboards_v1_dashboards_get.sync_detailed(
            project_id=project_id,
            client=client,
        )
        dashboards: list[Any] = []
        if dashboards_response.status_code == 200 and dashboards_response.parsed and isinstance(dashboards_response.parsed, DashboardListResponse):
            dashboards = dashboards_response.parsed.dashboards
        for dashboard in dashboards:
            dashboard_dict = dashboard.to_dict()
            dash_name = sanitize_filename(dashboard_dict.get("name", dashboard_dict.get("id", "dashboard")))
            # Save as DashboardDefinition model directly
            write_yaml_file(
                output_dir / "dashboards" / f"{dash_name}.yaml",
                dashboard_dict,
                schema_ref="../.schemas/openapi.json#/components/schemas/DashboardDefinition",
            )

        output_success(
            f"Project pulled to '{output_dir}'",
            data={
                "project_id": project_id,
                "output_dir": str(output_dir),
                "connections": len(connections),
                "tasks": len(tasks),
                "datasets": len(datasets),
                "dashboards": len(dashboards),
            },
        )


@app.command("push")
def push_project(
    project_id: Annotated[
        str | None,
        typer.Option("--project", "-p", help="Project ID to push to (reads from convexity.yaml if not specified)"),
    ] = None,
    directory: Annotated[
        Path,
        typer.Option("--dir", "-d", help="Project directory (defaults to current directory)"),
    ] = Path("."),
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="Show what would be pushed without making changes"),
    ] = False,
    delete: Annotated[
        bool,
        typer.Option("--delete", help="Delete remote resources that don't exist locally"),
    ] = False,
) -> None:
    """Push local project changes to remote.

    Reads the local project folder and syncs changes to the remote server.
    Creates new resources, updates existing ones, and optionally deletes removed ones.
    """
    # Find and validate convexity.yaml
    manifest_path = directory / "convexity.yaml"
    if not manifest_path.exists():
        raise ProjectError(f"No convexity.yaml found in '{directory}'. Make sure you're in a Convexity project directory.")

    manifest = read_yaml_file(manifest_path)

    # Get project ID from manifest or CLI option
    if project_id is None:
        # Try both direct id field and nested metadata.id
        project_id = manifest.get("id") or manifest.get("metadata", {}).get("id")
        if not project_id:
            raise ProjectError("No project ID specified. Use --project or ensure convexity.yaml has id set.")

    if dry_run:
        # Collect local resources for dry run preview
        changes: dict[str, Any] = {
            "connections": {"create": [], "update": [], "delete": []},
            "tasks": {"create": [], "update": [], "delete": []},
            "datasets": {"create": [], "update": [], "delete": []},
            "dashboards": {"create": [], "update": [], "delete": []},
        }

        # Collect local IDs for delete comparison
        local_conn_ids: set[str] = set()
        local_task_ids: set[str] = set()
        local_dataset_ids: set[str] = set()
        local_dashboard_ids: set[str] = set()

        # Scan connections
        connections_dir = directory / "connections"
        if connections_dir.exists():
            for yaml_file in connections_dir.glob("*.yaml"):
                conn_data = read_yaml_file(yaml_file)
                conn_id = conn_data.get("id")
                conn_name = conn_data.get("name", yaml_file.stem)
                if conn_id:
                    local_conn_ids.add(conn_id)
                    changes["connections"]["update"].append({"id": conn_id, "name": conn_name})
                else:
                    changes["connections"]["create"].append({"name": conn_name})

        # Scan tasks
        tasks_dir = directory / "tasks"
        if tasks_dir.exists():
            for task_subdir in tasks_dir.iterdir():
                if task_subdir.is_dir():
                    task_yaml = task_subdir / "task.yaml"
                    if task_yaml.exists():
                        task_data = read_yaml_file(task_yaml)
                        task_id = task_data.get("id")
                        task_name = task_data.get("name", task_subdir.name)
                        if task_id:
                            local_task_ids.add(task_id)
                            changes["tasks"]["update"].append({"id": task_id, "name": task_name})
                        else:
                            changes["tasks"]["create"].append({"name": task_name})

        # Scan datasets
        datasets_dir = directory / "datasets"
        if datasets_dir.exists():
            for yaml_file in datasets_dir.glob("*.yaml"):
                ds_data = read_yaml_file(yaml_file)
                ds_id = ds_data.get("id")
                ds_name = ds_data.get("name", yaml_file.stem)
                if ds_id:
                    local_dataset_ids.add(ds_id)
                    changes["datasets"]["update"].append({"id": ds_id, "name": ds_name})
                else:
                    changes["datasets"]["create"].append({"name": ds_name})

        # Scan dashboards
        dashboards_dir = directory / "dashboards"
        if dashboards_dir.exists():
            for yaml_file in dashboards_dir.glob("*.yaml"):
                dash_data = read_yaml_file(yaml_file)
                dash_id = dash_data.get("id")
                dash_name = dash_data.get("name", yaml_file.stem)
                if dash_id:
                    local_dashboard_ids.add(dash_id)
                    changes["dashboards"]["update"].append({"id": dash_id, "name": dash_name})
                else:
                    changes["dashboards"]["create"].append({"name": dash_name})

        # If --delete flag is set, fetch remote state to determine what would be deleted
        if delete:
            with get_authenticated_client() as client:
                # Check remote connections
                connections_response = list_connections_v1_connections_get.sync_detailed(
                    project_id=project_id,
                    client=client,
                )
                if connections_response.status_code == 200 and connections_response.parsed and isinstance(connections_response.parsed, ConnectionListResponse):
                    for conn in connections_response.parsed.connections:
                        conn_dict = conn.to_dict()
                        conn_id = conn_dict.get("id", "")
                        if conn_id and conn_id not in local_conn_ids:
                            changes["connections"]["delete"].append({"id": conn_id, "name": conn_dict.get("name", conn_id)})

                # Check remote tasks
                tasks_response = list_tasks_v1_tasks_get.sync_detailed(
                    project_id=project_id,
                    client=client,
                )
                if tasks_response.status_code == 200 and tasks_response.parsed and isinstance(tasks_response.parsed, TaskListResponse):
                    for task in tasks_response.parsed.tasks:
                        task_dict = task.to_dict()
                        task_id = task_dict.get("id", "")
                        if task_id and task_id not in local_task_ids:
                            changes["tasks"]["delete"].append({"id": task_id, "name": task_dict.get("name", task_id)})

                # Check remote datasets
                datasets_response = list_datasets_v1_datasets_get.sync_detailed(
                    project_id=project_id,
                    client=client,
                )
                if datasets_response.status_code == 200 and datasets_response.parsed and isinstance(datasets_response.parsed, DatasetListResponse):
                    ds_list = datasets_response.parsed.datasets
                    if not isinstance(ds_list, type(UNSET)):
                        for ds in ds_list:
                            ds_dict = ds.to_dict()
                            ds_id = ds_dict.get("id", "")
                            if ds_id and ds_id not in local_dataset_ids:
                                changes["datasets"]["delete"].append({"id": ds_id, "name": ds_dict.get("name", ds_id)})

                # Check remote dashboards
                dashboards_response = list_dashboards_v1_dashboards_get.sync_detailed(
                    project_id=project_id,
                    client=client,
                )
                if dashboards_response.status_code == 200 and dashboards_response.parsed and isinstance(dashboards_response.parsed, DashboardListResponse):
                    for dash in dashboards_response.parsed.dashboards:
                        dash_dict = dash.to_dict()
                        dash_id = dash_dict.get("id", "")
                        if dash_id and dash_id not in local_dashboard_ids:
                            changes["dashboards"]["delete"].append({"id": dash_id, "name": dash_dict.get("name", dash_id)})

        output_json(
            {
                "dry_run": True,
                "project_id": project_id,
                "delete_enabled": delete,
                "changes": changes,
            }
        )
        return

    # Perform actual push
    with get_authenticated_client() as client:
        result = PushResult()

        # Fetch current remote state for comparison
        # Get remote tasks
        remote_tasks: list[Any] = []
        tasks_response = list_tasks_v1_tasks_get.sync_detailed(
            project_id=project_id,
            client=client,
        )
        if tasks_response.status_code == 200 and tasks_response.parsed and isinstance(tasks_response.parsed, TaskListResponse):
            remote_tasks = tasks_response.parsed.tasks

        # Get remote datasets
        remote_datasets: list[Any] = []
        datasets_response = list_datasets_v1_datasets_get.sync_detailed(
            project_id=project_id,
            client=client,
        )
        if datasets_response.status_code == 200 and datasets_response.parsed and isinstance(datasets_response.parsed, DatasetListResponse):
            ds_list = datasets_response.parsed.datasets
            if not isinstance(ds_list, type(UNSET)):
                remote_datasets = ds_list

        # Get remote dashboards
        remote_dashboards: list[Any] = []
        dashboards_response = list_dashboards_v1_dashboards_get.sync_detailed(
            project_id=project_id,
            client=client,
        )
        if dashboards_response.status_code == 200 and dashboards_response.parsed and isinstance(dashboards_response.parsed, DashboardListResponse):
            remote_dashboards = dashboards_response.parsed.dashboards

        # Get remote connections
        remote_connections: list[Any] = []
        connections_response = list_connections_v1_connections_get.sync_detailed(
            project_id=project_id,
            client=client,
        )
        if connections_response.status_code == 200 and connections_response.parsed and isinstance(connections_response.parsed, ConnectionListResponse):
            remote_connections = connections_response.parsed.connections

        # Push each resource type in dependency order:
        # 1. Connections (no dependencies)
        # 2. Tasks (may depend on connections)
        # 3. Datasets (may depend on connections)
        # 4. Update dashboard references to use new IDs from created resources
        # 5. Dashboards (depend on tasks, datasets, connections)
        push_connections(client, project_id, directory, remote_connections, result, delete_missing=delete)
        push_tasks(client, project_id, directory, remote_tasks, result, delete_missing=delete)
        push_datasets(client, project_id, directory, remote_datasets, result, delete_missing=delete)

        # Update dashboard widget references before pushing dashboards
        # This ensures newly created resources have their IDs updated in dashboard widgets
        if result.id_mappings:
            update_dashboard_references(directory, result)

        push_dashboards(client, project_id, directory, remote_dashboards, result, delete_missing=delete)

        # Output results
        push_result = result.to_dict()
        push_result["project_id"] = project_id

        if result.errors:
            output_json(push_result)
            raise APIError(f"Push completed with {len(result.errors)} error(s)")
        else:
            output_success(
                f"Push completed: {len(result.created)} created, {len(result.updated)} updated, {len(result.deleted)} deleted, {len(result.skipped)} skipped",
                data=push_result,
            )
