__author__ = "adriaal"


class StdDiff(object):
    pass
