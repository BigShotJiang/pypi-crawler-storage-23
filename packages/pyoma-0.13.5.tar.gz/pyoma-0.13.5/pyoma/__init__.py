__author__ = "Adrian Altenhoff"
__version__ = "0.13.5"


def version():
    """returns the current library version of pyoma"""
    return __version__
