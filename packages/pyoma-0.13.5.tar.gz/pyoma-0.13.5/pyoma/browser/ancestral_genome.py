class AncestralGenome:
    def __init__(self, node):
        self.h5_node = node
