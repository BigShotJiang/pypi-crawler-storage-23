# @omlish-lite
# @omlish-amalg ../../../../omdev/scripts/lib/formats/goyaml.py
from .decoding import yaml_decode  # noqa


##
