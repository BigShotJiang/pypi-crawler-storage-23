import unittest
from unittest.mock import Mock, patch, MagicMock

# Mock transaction.atomic as a pass-through decorator BEFORE importing
def mock_atomic(func):
    """Mock decorator that just returns the function unchanged"""
    return func

# Patch before import
with patch('django.db.transaction.atomic', mock_atomic):
    from laibon import activity, common, db, exception, accessor


class TestWriteDataActivity(unittest.TestCase):
    
    def setUp(self):
        self.activity = activity.WriteDataActivity()
        self.container = common.Container()
    
    def test_no_changes(self):
        """Test process with no changes to write"""
        result = self.activity.process(self.container)
        self.assertEqual(result, common.goto_next())
    
    def test_create_entity_success(self):
        """Test successful entity creation"""
        mock_adapter = Mock(spec=db.Adapter)
        mock_model = Mock()
        mock_adapter.to_model.return_value = mock_model
        
        result = self.activity.create_entity(mock_adapter)
        
        mock_adapter.to_model.assert_called_once()
        mock_model.save.assert_called_once()
        self.assertEqual(result, mock_model)
    
    def test_create_entity_failure(self):
        """Test entity creation failure raises PersistenceException"""
        mock_adapter = Mock(spec=db.Adapter)
        mock_adapter.to_model.side_effect = Exception("DB error")
        
        with self.assertRaises(exception.PersistenceException):
            self.activity.create_entity(mock_adapter)
    
    def test_update_entity_success(self):
        """Test successful entity update"""
        mock_adapter = Mock(spec=db.Adapter)
        mock_adapter.id = "test-id"
        mock_model_class = Mock()
        mock_existing = Mock()
        mock_updated = Mock()
        mock_model_class.objects.get.return_value = mock_existing
        mock_adapter.get_model_class.return_value = mock_model_class
        mock_adapter.to_model.return_value = mock_updated
        
        self.activity.update_entity(mock_adapter)
        
        mock_model_class.objects.get.assert_called_once_with(id="test-id")
        mock_adapter.to_model.assert_called_once_with(mock_existing)
        mock_updated.save.assert_called_once()
    
    def test_update_entity_failure(self):
        """Test entity update failure raises PersistenceException"""
        mock_adapter = Mock(spec=db.Adapter)
        mock_adapter.id = "test-id"
        mock_model_class = Mock()
        mock_model_class.objects.get.side_effect = Exception("Not found")
        mock_adapter.get_model_class.return_value = mock_model_class
        
        with self.assertRaises(exception.PersistenceException):
            self.activity.update_entity(mock_adapter)
    
    def test_delete_entity_success(self):
        """Test successful entity deletion"""
        mock_adapter = Mock(spec=db.Adapter)
        mock_adapter.id = "test-id"
        mock_model_class = Mock()
        mock_existing = Mock()
        mock_existing.delete.return_value = (1, {})
        mock_model_class.objects.get.return_value = mock_existing
        mock_adapter.get_model_class.return_value = mock_model_class
        
        result = self.activity.delete_entity(mock_adapter)
        
        mock_model_class.objects.get.assert_called_once_with(id="test-id")
        mock_existing.delete.assert_called_once()
        self.assertEqual(result, (1, {}))
    
    def test_delete_entity_failure(self):
        """Test entity deletion failure raises PersistenceException"""
        mock_adapter = Mock(spec=db.Adapter)
        mock_adapter.id = "test-id"
        mock_model_class = Mock()
        mock_model_class.objects.get.side_effect = Exception("Not found")
        mock_adapter.get_model_class.return_value = mock_model_class
        
        with self.assertRaises(exception.PersistenceException):
            self.activity.delete_entity(mock_adapter)
    
    def test_write_changes_with_create(self):
        """Test writing changes with CREATE operation"""
        mock_adapter = Mock(spec=db.Adapter)
        create_change = db.CreateChange(mock_adapter)
        
        mock_changes = db.PersistentData()
        mock_changes.add(create_change)
        
        with patch.object(self.activity, 'create_entity') as mock_create:
            self.activity._write_changes(mock_changes)
            mock_create.assert_called_once_with(mock_adapter)
    
    def test_write_changes_with_update(self):
        """Test writing changes with UPDATE operation"""
        mock_adapter = Mock(spec=db.Adapter)
        update_change = db.UpdateChange(mock_adapter)
        
        mock_changes = db.PersistentData()
        mock_changes.add(update_change)
        
        with patch.object(self.activity, 'update_entity') as mock_update:
            self.activity._write_changes(mock_changes)
            mock_update.assert_called_once_with(mock_adapter)
    
    def test_write_changes_with_delete(self):
        """Test writing changes with DELETE operation"""
        mock_adapter = Mock(spec=db.Adapter)
        delete_change = db.DeleteChange(mock_adapter)
        
        mock_changes = db.PersistentData()
        mock_changes.add(delete_change)
        
        with patch.object(self.activity, 'delete_entity') as mock_delete:
            self.activity._write_changes(mock_changes)
            mock_delete.assert_called_once_with(mock_adapter)
    
    def test_write_changes_with_invalid_change(self):
        """Test writing changes with invalid change raises exception"""
        mock_adapter = Mock(spec=db.Adapter)
        
        class InvalidChange(db.PersistentChange):
            def is_valid(self):
                return False
            def get_change_type(self):
                return db.PersistentChange.ChangeType.CREATE
        
        invalid_change = InvalidChange(mock_adapter)
        mock_changes = db.PersistentData()
        mock_changes.add(invalid_change)
        
        with self.assertRaises(exception.PersistenceException):
            self.activity._write_changes(mock_changes)
    
    def test_handle_exception(self):
        """Test exception handling sets exception and returns error result"""
        test_exception = exception.PersistenceException("Test error")
        
        result = self.activity.handle_exception(test_exception, self.container)
        
        self.assertEqual(result, activity.WriteDataActivity.Result.WRITE_ERROR)
        stored_exception = accessor.DelayedExceptionAccessor.get(self.container)
        self.assertEqual(stored_exception, test_exception)
    
    def test_process_with_changes_success(self):
        """Test process with successful changes"""
        mock_adapter = Mock(spec=db.Adapter)
        create_change = db.CreateChange(mock_adapter)
        
        persistent_data = activity.PersistentDataAccessor.get(self.container)
        persistent_data.add(create_change)
        
        with patch.object(self.activity, 'create_entity'):
            result = self.activity.process(self.container)
            self.assertEqual(result, common.goto_next())
    
    def test_process_with_exception(self):
        """Test process handles exceptions properly"""
        mock_adapter = Mock(spec=db.Adapter)
        create_change = db.CreateChange(mock_adapter)
        
        persistent_data = activity.PersistentDataAccessor.get(self.container)
        persistent_data.add(create_change)
        
        with patch.object(self.activity, 'create_entity', side_effect=exception.PersistenceException("Error")):
            result = self.activity.process(self.container)
            self.assertEqual(result, activity.WriteDataActivity.Result.WRITE_ERROR)


if __name__ == '__main__':
    unittest.main()
