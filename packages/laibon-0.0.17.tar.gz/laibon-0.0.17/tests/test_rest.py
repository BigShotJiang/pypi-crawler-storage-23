import unittest


class TestRest(unittest.TestCase):
    def test_valid_json(self):
        pass
