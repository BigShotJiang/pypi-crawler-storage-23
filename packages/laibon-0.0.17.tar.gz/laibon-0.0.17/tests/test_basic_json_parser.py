import unittest
import json
import tempfile
import os
from unittest.mock import Mock, patch
import django
from django.conf import settings
from django.core.cache import cache
from django.http import request as django_request

os.environ.setdefault('RESOURCES_PATH', '/tmp')

if not settings.configured:
    settings.configure(
        CACHES={
            'default': {
                'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
            }
        },
        USE_TZ=True,
    )
    django.setup()

from laibon import rest, common


class TestBasicJsonRequestParserActivity(unittest.TestCase):
    
    def setUp(self):
        cache.clear()
        self.temp_dir = tempfile.mkdtemp()
        self.schema = {
            "type": "object",
            "properties": {"name": {"type": "string"}},
            "required": ["name"]
        }
        self.schema_file = os.path.join(self.temp_dir, "test_schema.json")
        with open(self.schema_file, 'w') as f:
            json.dump(self.schema, f)
    
    def tearDown(self):
        if os.path.exists(self.schema_file):
            os.remove(self.schema_file)
        os.rmdir(self.temp_dir)
        cache.clear()
    
    def test_valid_request(self):
        """Test successful parsing of valid JSON request"""
        mock_request = Mock(spec=django_request.HttpRequest)
        mock_request.body = json.dumps({"name": "test"}).encode()
        
        container = rest.DataContainer(mock_request, [])
        
        class TestRequest(rest.JsonRequest):
            def __init__(self, http_request, uri_params, parsed_json):
                # Skip parent validation for testing
                common.FlowRequest.__init__(self)
                self._request = http_request
                self._uri_params = uri_params
                self.parsed_json = parsed_json
            
            def is_valid(self):
                return True
        
        activity = rest.BasicJsonRequestParserActivity(TestRequest, self.schema_file)
        result = activity.process(container)
        
        self.assertEqual(result, common.goto_next())
        self.assertIsNotNone(container.get(rest.DataContainer.FLOW_REQUEST_KEY))
    
    def test_invalid_json_schema(self):
        """Test handling of JSON that doesn't match schema"""
        mock_request = Mock()
        mock_request.body = json.dumps({"age": 30}).encode()  # missing required 'name'
        
        container = rest.DataContainer(mock_request, [])
        
        class TestRequest(rest.JsonRequest):
            pass
        
        activity = rest.BasicJsonRequestParserActivity(TestRequest, self.schema_file)
        result = activity.process(container)
        
        self.assertEqual(result, rest.BasicJsonRequestParserActivity.Result.VALIDATION_ERROR)
    
    def test_malformed_json(self):
        """Test handling of malformed JSON"""
        mock_request = Mock()
        mock_request.body = b"not valid json"
        
        container = rest.DataContainer(mock_request, [])
        
        class TestRequest(rest.JsonRequest):
            pass
        
        activity = rest.BasicJsonRequestParserActivity(TestRequest, self.schema_file)
        result = activity.process(container)
        
        self.assertEqual(result, rest.BasicJsonRequestParserActivity.Result.INVALID_SCHEMA)
    
    def test_missing_schema_file(self):
        """Test handling of missing schema file"""
        mock_request = Mock()
        mock_request.body = json.dumps({"name": "test"}).encode()
        
        container = rest.DataContainer(mock_request, [])
        
        class TestRequest(rest.JsonRequest):
            pass
        
        activity = rest.BasicJsonRequestParserActivity(TestRequest, "nonexistent.json")
        result = activity.process(container)
        
        self.assertEqual(result, rest.BasicJsonRequestParserActivity.Result.INVALID_SCHEMA)
    
    def test_invalid_request_validation(self):
        """Test handling when request.is_valid() returns False"""
        mock_request = Mock(spec=django_request.HttpRequest)
        mock_request.body = json.dumps({"name": "test"}).encode()
        
        container = rest.DataContainer(mock_request, [])
        
        class TestRequest(rest.JsonRequest):
            def __init__(self, http_request, uri_params, parsed_json):
                # Skip parent validation for testing
                common.FlowRequest.__init__(self)
                self._request = http_request
                self._uri_params = uri_params
            def is_valid(self):
                return False
        
        activity = rest.BasicJsonRequestParserActivity(TestRequest, self.schema_file)
        result = activity.process(container)
        
        self.assertEqual(result, rest.BasicJsonRequestParserActivity.Result.INVALID_REQUEST)


if __name__ == '__main__':
    unittest.main()
