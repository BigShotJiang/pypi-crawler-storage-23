#  Copyright (c) 2023 Wenceslaus Mumala

from laibon import common


class PerformanceMetrics:
    """Stores performance metrics for flow execution"""
    
    def __init__(self):
        self.activity_times = {}
        self.total_time = 0
    
    def add_activity_time(self, activity_name: str, elapsed_time: float):
        """Record time taken by an activity"""
        self.activity_times[activity_name] = elapsed_time
    
    def set_total_time(self, total_time: float):
        """Record total flow execution time"""
        self.total_time = total_time
    
    def get_activity_time(self, activity_name: str) -> float:
        """Get time taken by specific activity"""
        return self.activity_times.get(activity_name, 0.0)
    
    def get_summary(self) -> dict:
        """Get summary of all metrics"""
        return {
            "total_time": self.total_time,
            "activity_times": self.activity_times,
            "activity_count": len(self.activity_times)
        }


class PerformanceMetricsAccessor:
    """Accessor for PerformanceMetrics in container"""
    _KEY = common.ContainerKey("PerformanceMetrics")
    
    @staticmethod
    def get(data_container: common.Container) -> PerformanceMetrics:
        """Get or create PerformanceMetrics from container"""
        perf_metrics = data_container.get(PerformanceMetricsAccessor._KEY)
        if perf_metrics is None:
            perf_metrics = PerformanceMetrics()
            data_container.put(PerformanceMetricsAccessor._KEY, perf_metrics)
        return perf_metrics

