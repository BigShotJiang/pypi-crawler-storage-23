# Copyright Wenceslaus Mumala 2023. See LICENSE file.

import json
import logging
import os
from abc import abstractmethod, ABC

import jsonschema
from jsonschema import RefResolver
from django.core.cache import cache
from django.http import request as django_request

from laibon import common
from laibon import exception

logger = logging.getLogger(__name__)


class JSONValidationException(exception.BaseException):
    def __init__(self, msg="Validation for request against schema failed", cause=None):
        super().__init__(msg, cause)

class JSONSchemaException(exception.BaseException):
    def __init__(self, msg="Error in schema", cause=None):
        super().__init__(msg, cause)

class RequestNotValidException(exception.BaseException):
    def __init__(self, msg="Error in schema", cause=None):
        super().__init__(msg, cause)

RESOURCE_PATH = os.environ.get('RESOURCES_PATH', '/tmp')


class JSONSchemaValidator:
    """Thread-safe JSON schema validator with Django caching.
    
    Validates JSON input against schemas stored in the filesystem.
    Schemas are cached for performance and thread safety.
    
    Environment Variables:
        RESOURCES_PATH: Directory containing schema files (defaults to /tmp)
    
    Example:
        # Validate request data against schema
        try:
            JSONSchemaValidator.validate_schema(
                {"name": "John", "age": 30}, 
                "user/create_request.json"
            )
        except JSONValidationException as e:
            # Handle validation error
            pass
    """

    @staticmethod
    def _get_schema_with_base(json_schema):
        """Load schema and resolve base directory, with caching"""
        cache_key = f"schema:{json_schema}"
        cached = cache.get(cache_key)
        
        if cached:
            return cached  # Returns (schema_json, base_dir)
        
        # Resolve path
        if os.path.exists(json_schema):
            request_schema = json_schema
            base_dir = os.path.dirname(os.path.abspath(json_schema))
        else:
            request_schema = os.path.join(RESOURCE_PATH, json_schema)
            base_dir = RESOURCE_PATH
        
        # Load schema
        try:
            with open(request_schema, "r") as f:
                schema_json = json.load(f)
        except Exception as e:
            raise JSONSchemaException(f"Could not read schema file: {e}")
        
        result = (schema_json, base_dir)
        cache.set(cache_key, result, timeout=3600)  # Cache for 1 hour
        return result

    @staticmethod
    def validate_schema(input_json, json_schema):
        schema_json, base_dir = JSONSchemaValidator._get_schema_with_base(json_schema)

        # Create resolver for local schema references
        base_uri = f"file://{base_dir}/"
        resolver = RefResolver(base_uri=base_uri, referrer=schema_json)

        try:
            jsonschema.validate(input_json, schema_json, resolver=resolver)
        except jsonschema.exceptions.ValidationError as e:
            logger.error("Error validating request: %s", str(e))
            raise JSONValidationException("Validation for request against schema failed.", e)
        except jsonschema.SchemaError as e:
            # Schema itself is invalid
            raise JSONSchemaException("Schema is invalid", e)
        except jsonschema.RefResolutionError as e:
            # Can't resolve $ref in schema
            raise JSONSchemaException("Reference error in schema", e)


class RestRequest(common.FlowRequest):
    def __init__(self, http_request: django_request.HttpRequest, uri_params):
        super().__init__()
        if not isinstance(http_request, django_request.HttpRequest):
            raise exception.InvalidArgumentException()

        self._request = http_request
        self._uri_params = [] if uri_params is None else uri_params

    def get_request_body(self):
        return self._request.body if self._request else None

    def get_query_params(self) -> django_request.QueryDict:
        """Returns the query params e.g name in ?name=blah"""
        return self._request.GET if self._request else django_request.QueryDict()

    def get_uri_params(self):  # Users should take note of the order of occurrence
        """Returns the params configured in the URI in urls.py"""
        return self._uri_params

    def get_host(self):
        return self._request.get_host()

    def get_scheme(self):
        """ Whether request is http or https """
        return self._request.scheme

    def get_headers(self) -> django_request.HttpHeaders:
        return self._request.headers if self._request else None

    def get_header_value(self, header_key, default_value=None):
        headers = self.get_headers()
        return headers.get(header_key, default_value) if headers else default_value

    def get_session_data(self, session_key):
        return self._request.COOKIES.get(session_key) if self._request else None

    def get_query_parameter(self, key, def_value=None):
        return self.get_query_params().get(key, def_value)

    def get_session_id(self):
        return self.get_session_data('sessionid')

    def get_interface_http_request(self):
        """Should be used only for authentication purposes."""
        return self._request

    def is_valid(self):
        return True

    def validate(self):
        """
        Provides for additional valition - e.g after schema to check for properties
        that by design are not constrained in the schema, Can be userd to validate url
        or query parameters or even ensure necessary headers are set in the http request
        """
        pass


class TrafficRequest(RestRequest):
    def __init__(self, http_request: django_request.HttpRequest, uri_params):
        super().__init__(http_request, uri_params)


class JsonRequest(TrafficRequest):
    """Request with json payload"""

    def __init__(self, http_request: django_request.HttpRequest, uri_params, parsed_json):
        super().__init__(http_request, uri_params)


class DataContainer(common.Container):
    """Container purposed for Rest requests"""
    FLOW_REQUEST_KEY = "FlowRequest"
    FLOW_EXCEPTION_KEY = "DelayedException"
    FLOW_RESPONSE = "FlowResponse"

    def __init__(self, http_request: django_request.HttpRequest, uri_params):
        super().__init__()
        self._request = http_request
        self._uri_params = [] if uri_params is None else uri_params

    def get_raw_request(self):
        """External django http request object"""
        return self._request

    def get_uri_params(self):
        """Uri params from external rest request"""
        return self._uri_params

    def get_or_raise(self, key):
        v = self.get(key)
        if v is None:
            raise exception.MissingContainerValueException()
        return v

    def get_request(self) -> common.FlowRequest:
        return self.get_or_raise(self.FLOW_REQUEST_KEY)

    def set_request(self, flow_request):
        if isinstance(flow_request, common.FlowRequest) is False:
            raise exception.InvalidArgumentException()

        existing = self.get(self.FLOW_REQUEST_KEY)
        if not existing:
            self.put(self.FLOW_REQUEST_KEY, flow_request)

    def set_exception(self, e):
        existing = self.get(self.FLOW_EXCEPTION_KEY)
        if not existing:
            self.put(self.FLOW_EXCEPTION_KEY, e)


CACHED_SCHEMA_LOCATIONS = {}


class ParsedJSON(common.JSONObject):
    def __init__(self, dict_):
        self.__dict__.update(dict_)

    @staticmethod
    def parseJSON(d):
        return json.loads(json.dumps(d), object_hook=ParsedJSON)


class BasicJsonRequestParserActivity(common.Activity):
    """
    Provides base functionality for parsing a json request and deserializing to a request class
    The class must be extended and proper error handling implemented

    No support for schema info in the header. Schema versions should be handled via url paths
    """
    LOGGER = logging.getLogger(__name__)

    def __init__(self, request_class: type, schema_file: str = None):
        super().__init__()
        self._schema_file = schema_file
        self._request_class = request_class

    class Result(common.ActivityResult):
        INVALID_REQUEST = "InvalidRequest"
        VALIDATION_ERROR = "ValidationError"
        INVALID_SCHEMA = "InvalidSchema"
        UNEXPECTED_ERROR= "UnexpectedError"

    def get_result_codes(self):
        return [self.Result.INVALID_REQUEST, self.Result.VALIDATION_ERROR, self.Result.INVALID_SCHEMA, self.Result.UNEXPECTED_ERROR]

    def _validate_schema(self, original_request):
        schema_loc = self._schema_file
        if schema_loc is not None:
            try:
                raw_body = original_request.body
                body = json.loads(raw_body)
                JSONSchemaValidator.validate_schema(body, schema_loc)
                return ParsedJSON.parseJSON(body)
            except JSONValidationException as e:
                self.LOGGER.error(f"Schema validation failed for {schema_loc}")
                self.LOGGER.debug("Error validating request.", exc_info=True)
                raise e
            except Exception as e:
                self.LOGGER.debug("Unexpected error while validating request.", exc_info=True)
                error = e
                if not isinstance(e, JSONValidationException):
                     error = JSONSchemaException(cause=e)
                raise error
        else:
            raise JSONSchemaException("Schema file not found")

    def handle_request(self, data_container: DataContainer):
        """
        Main functionality for validating the request schema and deserialization
        raises:
         JSONSchemaException - If the schema itself has errors or cannot be read
         JSONValidationException - if the request does not conform to the schema or there is an error in the request
         RequestNotValidException - if the additional request from the newly created instance fails
        """
        original_request = data_container.get_raw_request()
        parsed_json = self._validate_schema(original_request)

        request_instance: JsonRequest = (
            self._request_class(original_request, data_container.get_uri_params(), parsed_json))
        if not request_instance.is_valid():
            raise RequestNotValidException("Request validator failed.")
        data_container.set_request(request_instance)

    def process(self, data_container: DataContainer):
        """Default method that should be overridden to better handle exceptions and map to meaningful error codes"""
        try:
            self.handle_request(data_container)
            return common.goto_next()
        except Exception as e:
            return self.handle_exception(e, data_container)

    def handle_exception(self, e, data_container: DataContainer)->common.ActivityResult:
        """
        Called if an exception is thrown while validating a request against a schema
        Can be used to set the exception on the container
        """
        data_container.set_exception(e)
        self.LOGGER.error(f"Error in creating request from json because of {str(e)}")
        self.LOGGER.debug("Error in Parsing json to request", exc_info=True)
        if isinstance(e, JSONSchemaException):
            return self.Result.INVALID_SCHEMA
        elif isinstance(e, JSONValidationException):
            return self.Result.VALIDATION_ERROR
        elif isinstance(e, RequestNotValidException):
            return self.Result.INVALID_REQUEST
        else:
            return self.Result.UNEXPECTED_ERROR



class ParseJsonRequestActivity(common.Activity):
    """Reads json request, parses it into expected request and sets result on container"""
    LOGGER = logging.getLogger(__name__)
    SCHEMA_HTTP_HEADER = "scheme"

    class ParsedJSON(common.JSONObject):
        def __init__(self, dict_):
            self.__dict__.update(dict_)

        @staticmethod
        def parseJSON(d):
            return json.loads(json.dumps(d), object_hook=ParseJsonRequestActivity.ParsedJSON)

    def __init__(self, request_class: type, schema_file: str = None):
        super().__init__()
        self._schema_file = schema_file
        self._request_class = request_class

    def get_schema_path(self, request: django_request.HttpRequest):
        # TODO
        headers = request.headers if request else None
        req_location: str = headers.get(ParseJsonRequestActivity.SCHEMA_HTTP_HEADER, None) if headers else None
        if not req_location:
            return None

        cached = CACHED_SCHEMA_LOCATIONS.get(req_location)
        if cached:
            return cached

        scheme = request.scheme
        host = request.get_host()
        host_part = scheme + "//" + host
        if req_location.startswith(host_part) is False:
            raise exception.InvalidArgumentException("Schema path is invalid")
        loc = req_location.partition(host_part)[2]
        if not loc:
            raise exception.InvalidArgumentException("Problem determining schema path")
        CACHED_SCHEMA_LOCATIONS[req_location] = loc
        return loc

    class Result(common.ActivityResult):
        VALIDATION_ERROR = "ValidationError"
        INVALID_REQUEST = "InvalidRequest"

    def get_result_codes(self):
        return [self.Result.VALIDATION_ERROR, self.Result.INVALID_REQUEST]

    def process(self, data_container: DataContainer):
        self.LOGGER.debug("Validating and parsing request.")
        original_request = data_container.get_raw_request()

        schema_loc = self._schema_file if self._schema_file else self.get_schema_path(original_request)
        parsed_json = None
        if schema_loc is not None:
            try:
                raw_body = original_request.body
                body = json.loads(raw_body)
                JSONSchemaValidator.validate_schema(body, schema_loc)
                parsed_json = self.ParsedJSON.parseJSON(body)
            except JSONValidationException as e:
                self.LOGGER.error("Error validating request.", exc_info=True)
                data_container.set_exception(e)
                return self.Result.VALIDATION_ERROR
            except Exception as e:
                self.LOGGER.error("Unexpected error while validating request.", exc_info=True)
                data_container.set_exception(e)
                return self.Result.VALIDATION_ERROR
        # Create request
        try:
            request_instance: JsonRequest = (
                self._request_class(original_request, data_container.get_uri_params(), parsed_json))
            data_container.set_request(request_instance)
            self.LOGGER.debug("Successfully parsed request.")
        except Exception:
            self.LOGGER.error("Error parsing external request into internal.", exc_info=True)
            error = exception.ProcessingException()
            data_container.set_exception(error)
            return self.Result.INVALID_REQUEST
        return common.goto_next()

class SetupContentFreeRequestActivity(common.Activity):
    """Prepares request for GET or DELETE operations"""
    LOGGER = logging.getLogger(__name__)

    def __init__(self, request_class: type, schema_file: str = None):
        super().__init__()
        self._schema_file = schema_file
        self._request_class = request_class

    class Result(common.ActivityResult):
        INVALID_REQUEST = "InvalidRequest"

    def get_result_codes(self):
        return [self.Result.INVALID_REQUEST]

    def process(self, data_container: DataContainer):
        self.LOGGER.debug("Validating and parsing request.")
        original_request = data_container.get_raw_request()
        try:
            request_instance: TrafficRequest = (self._request_class(original_request, data_container.get_uri_params()))
            request_instance.validate()
            data_container.set_request(request_instance)
            self.LOGGER.debug("Successfully parsed request.")
        except Exception as e:
            self.LOGGER.error("Error parsing external request: %s", str(e), exc_info=True)
            error = exception.ProcessingException(cause=e)
            data_container.set_exception(error)
            return self.Result.INVALID_REQUEST
        return common.goto_next()
