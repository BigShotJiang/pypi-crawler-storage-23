import numpy as np
from numpy.typing import NDArray

from sage.common.components.sage_embedding.sagellm import (
    initialize_sagellm_client,
    sagellm_embed_batch_sync,
)


async def instructor_embed(
    texts: list[str], model: str = "hkunlp/instructor-large"
) -> NDArray[np.float32]:  # type: ignore[return]
    client_cfg = initialize_sagellm_client(model)
    vectors = sagellm_embed_batch_sync(texts, tokenizer=model, embed_model=client_cfg)
    return np.asarray(vectors, dtype=np.float32)
