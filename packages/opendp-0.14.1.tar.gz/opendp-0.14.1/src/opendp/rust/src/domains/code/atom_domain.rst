>>> dp.atom_domain(T=float, nan=False)
AtomDomain(T=f64)