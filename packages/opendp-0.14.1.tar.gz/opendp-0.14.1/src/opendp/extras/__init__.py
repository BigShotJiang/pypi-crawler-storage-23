'''
The ``extras`` module contains pure-python DP tools.
These are not yet supported by the Rust or R bindings.
Some tools require extra, optional Python dependencies, and are grouped under corresponding namespaces.
'''
