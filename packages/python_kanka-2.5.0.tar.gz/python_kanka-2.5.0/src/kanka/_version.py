"""Version information for python-kanka."""

__version__ = "2.5.0"
