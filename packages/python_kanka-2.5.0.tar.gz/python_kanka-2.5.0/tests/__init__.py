"""Test suite for python-kanka SDK."""
