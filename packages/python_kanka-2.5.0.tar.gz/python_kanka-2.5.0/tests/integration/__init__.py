"""
Integration tests for the python-kanka SDK.

These tests interact with the real Kanka API and require valid credentials.
"""
