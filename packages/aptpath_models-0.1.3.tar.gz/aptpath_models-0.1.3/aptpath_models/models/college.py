"""College and associated college models."""
import uuid

from django.db import models
from django.utils import timezone

from .base import BaseModelProfile, BaseModelAdmin


class College(BaseModelProfile):
    name = models.CharField(max_length=255, null=True, blank=True)
    address = models.TextField(max_length=255, null=True, blank=True)
    city = models.CharField(max_length=100, null=True, blank=True)
    state = models.CharField(max_length=100, null=True, blank=True)
    pincode = models.CharField(max_length=20, null=True, blank=True)
    official_contact_number = models.CharField(max_length=20, null=True, blank=True)
    official_email_address = models.EmailField(
        unique=True, verbose_name='Email', max_length=50, null=True, blank=True)
    affiliation_number = models.CharField(max_length=50, null=True, blank=True)
    registration_number = models.CharField(max_length=50, null=True, blank=True)
    gst_number = models.CharField(max_length=100, null=True, blank=True)
    college_banner = models.FileField(blank=True, null=True)
    college_logo = models.FileField(blank=True, null=True)
    about_college = models.CharField(max_length=250, null=True, blank=True)
    is_verified = models.BooleanField(default=False)

    def __str__(self):
        return self.name or 'Unnamed College'

    class Meta:
        db_table = 'college'


class CollegeInvitation(BaseModelProfile):
    EMAIL_STATUS_CHOICES = (
        ('Success', 'Success'),
        ('Failed', 'Failed'),
    )
    INVITATION_TYPE_CHOICES = (
        ('email', 'Email'),
        ('qrcode', 'Qrcode'),
    )

    email = models.EmailField()
    invitation_code = models.UUIDField(unique=True, default=uuid.uuid4)
    college = models.ForeignKey(College, on_delete=models.CASCADE, null=True, blank=True)
    email_status = models.CharField(
        max_length=20, choices=EMAIL_STATUS_CHOICES, null=True, blank=True)
    message = models.TextField(blank=True)
    invitation_type = models.CharField(
        max_length=20, choices=INVITATION_TYPE_CHOICES, default='email')

    class Meta:
        db_table = 'college_invitation'


class CollegeDepartment(BaseModelProfile):
    name = models.CharField(null=True, blank=True, max_length=100)
    college = models.ForeignKey(College, on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return f"{self.name}"

    class Meta:
        db_table = 'college_department'


class CollegeDegree(BaseModelProfile):
    name = models.CharField(null=True, blank=True, max_length=100)
    college = models.ForeignKey(College, on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return self.name

    class Meta:
        db_table = 'college_degree'


class CollegeAdmin(BaseModelProfile):
    profile = models.ManyToManyField('aptpath_models.Profile', null=True, blank=True)
    college = models.ForeignKey(College, on_delete=models.CASCADE, null=True, blank=True)
    powerbi_url = models.URLField(max_length=2000, null=True, blank=True)

    def __str__(self):
        return f"{self.college.name} - {self.profile}"

    class Meta:
        db_table = 'college_admin'


class CollegeAdminInvitation(BaseModelAdmin):
    STATUS_CHOICES = (
        ('invited', 'Invited'),
        ('accepted', 'Accepted'),
        ('rejected', 'Rejected'),
    )

    email = models.EmailField()
    college = models.ForeignKey(College, on_delete=models.CASCADE, null=True, blank=True)
    invitation_code = models.UUIDField(unique=True, default=uuid.uuid4)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='invited')
    is_invitation_code_used = models.BooleanField(default=False)

    class Meta:
        db_table = 'college_admin_invitation'


class AssociatedCollege(BaseModelProfile):
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('accepted', 'Accepted'),
        ('rejected', 'Rejected'),
    )

    college = models.ForeignKey(College, on_delete=models.SET_NULL, null=True)
    department = models.ForeignKey(
        CollegeDepartment, on_delete=models.CASCADE, null=True, blank=True)
    degree = models.ForeignKey(
        CollegeDegree, on_delete=models.CASCADE, null=True, blank=True)
    year_of_start = models.DateField(null=True, blank=True)
    course_start_date = models.DateField(null=True, blank=True)
    course_end_date = models.DateField(null=True, blank=True)
    country = models.CharField(max_length=150, null=True, blank=True)
    state = models.CharField(max_length=150, null=True, blank=True)
    city = models.CharField(max_length=150, null=True, blank=True)
    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    present = models.BooleanField(default=False, null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    is_invited = models.BooleanField(default=False)

    class Meta:
        db_table = 'associated_college'


class OtherCollege(BaseModelProfile):
    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    college = models.CharField(max_length=150, null=True, blank=True)
    pincode = models.CharField(max_length=20, null=True, blank=True)
    state = models.CharField(max_length=100, null=True, blank=True)
    city = models.CharField(max_length=100, null=True, blank=True)

    class Meta:
        db_table = 'other_college'
