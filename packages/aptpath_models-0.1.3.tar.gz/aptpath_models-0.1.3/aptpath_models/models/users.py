from django.db import models
from django.contrib.auth.models import (
    AbstractBaseUser, BaseUserManager, PermissionsMixin, Group,
)
from django.contrib.contenttypes.models import ContentType
from django.contrib.contenttypes.fields import GenericForeignKey
from django.db import transaction
from django.db.models import Max
from random import randint
import uuid

from .base import BaseModel, BaseModelEmployer, BaseModelProfile, BaseModelAdmin


# ---------------------------------------------------------------------------
# Custom manager for MongoUser
# ---------------------------------------------------------------------------

class CustomUserManager(BaseUserManager):
    def create_user(self, email, password=None):
        if not email:
            raise ValueError("Email field is required.")
        user = self.model(email=self.normalize_email(email))
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_aptpath_user(
        self, email, password=None, account_id=None,
        signin_type=None, user_details_id=None,
        password_set=False, email_verified=False,
    ):
        user = self.create_user(email=email, password=password)
        user.is_staff = False
        user.is_superuser = False
        user.account_id = account_id
        user.signin_type = signin_type
        user.user_details_id = user_details_id
        user.password_set = password_set
        user.email_verified = email_verified
        user.passcode = str(randint(1000, 9999))
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None):
        user = self.create_user(email=email, password=password)
        user.is_staff = True
        user.is_superuser = True
        user.save(using=self._db)
        return user


# ---------------------------------------------------------------------------
# MongoUser  (primary learner / end-user account)
# ---------------------------------------------------------------------------

class MongoUser(AbstractBaseUser, PermissionsMixin):
    GENDER_CHOICES = (
        ('Male', 'male'),
        ('Female', 'female'),
        ('Other', 'other'),
    )

    email = models.EmailField(unique=True, verbose_name='Email', max_length=255)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    is_verified = models.BooleanField(default=True)
    account_id = models.IntegerField(default=1)
    user_first_login = models.BooleanField(default=False)
    email_verified = models.BooleanField(default=False)
    password_editable = models.BooleanField(default=False)
    registered_date = models.CharField(max_length=10, null=True, blank=True)
    signin_type = models.CharField(max_length=15, default='password')
    password_set = models.BooleanField(default=False)
    username = models.CharField(max_length=50, null=True, blank=True)
    passcode = models.CharField(max_length=4, default='0000')
    first_name = models.CharField(max_length=150, null=True, blank=True)
    last_name = models.CharField(max_length=150, null=True, blank=True)
    phone_no = models.CharField(max_length=20, null=True, blank=True)
    company_name = models.CharField(max_length=150, null=True, blank=True)
    role_name = models.CharField(max_length=150, null=True, blank=True)
    about_company = models.CharField(max_length=250, null=True, blank=True)
    photo_url = models.FileField(blank=True)
    company_banner = models.FileField(blank=True)
    about_me = models.CharField(max_length=250, null=True, blank=True)
    firebase_id = models.CharField(max_length=100, verbose_name='Firebase ID', null=True, blank=True)
    category_choice = models.ManyToManyField('aptpath_models.MongoCategories', blank=True)
    technical_skills = models.ManyToManyField('aptpath_models.MongoSkill', blank=True)
    companies_suggestion = models.ManyToManyField('aptpath_models.Company', blank=True)
    education = models.ManyToManyField('aptpath_models.UserEducation', blank=True)
    experience = models.ManyToManyField('aptpath_models.UserExperience', blank=True)
    certifications = models.ManyToManyField('aptpath_models.UserCertificate', blank=True)
    courses_liked = models.ManyToManyField(
        'aptpath_models.MongoCourse', related_name='courses_liked', blank=True)
    jobs_liked = models.ManyToManyField('aptpath_models.Jobs', blank=True)
    courses_enrolled = models.ManyToManyField(
        'aptpath_models.MongoCourse', related_name='courses_enrolled', blank=True)
    linkedin_url = models.URLField(null=True, blank=True)
    languages = models.ManyToManyField('aptpath_models.Language', blank=True)
    address = models.CharField(max_length=150, null=True, blank=True)
    country = models.CharField(max_length=150, null=True, blank=True, default='IN')
    state = models.CharField(max_length=150, null=True, blank=True)
    city = models.CharField(max_length=150, null=True, blank=True)
    dob = models.CharField(max_length=150, null=True, blank=True)
    designation = models.CharField(max_length=150, null=True, blank=True)
    resume = models.FileField(blank=True, null=True)
    points = models.IntegerField(default=0)
    test_assessments = models.IntegerField(default=0)
    last_assessment_rank = models.IntegerField(default=0)
    best_assessment_rank = models.IntegerField(default=0)
    group = models.ForeignKey(
        Group, on_delete=models.SET_NULL,
        verbose_name='Group', related_name='learners',
        null=True, blank=True,
    )
    gender = models.CharField(max_length=100, choices=GENDER_CHOICES, default='Other')
    moodle_enabled = models.BooleanField(default=True)
    udemy_enabled = models.BooleanField(default=False)
    persepio_enabled = models.BooleanField(default=False)
    created_date = models.DateTimeField(auto_now_add=True)
    modified_date = models.DateTimeField(auto_now_add=True)

    objects = CustomUserManager()

    USERNAME_FIELD = 'email'
    EMAIL_FIELD = 'email'
    REQUIRED_FIELDS = []

    def __str__(self):
        return self.email

    def has_perm(self, perm, obj=None):
        return True

    def has_module_perms(self, app_label):
        return True

    def get_full_name(self):
        return self.email

    def get_short_name(self):
        return self.email

    class Meta:
        db_table = 'users'


class MongoUserDetail(models.Model):
    """Placeholder model for future user detail fields."""

    class Meta:
        db_table = 'user_detail'


# ---------------------------------------------------------------------------
# MongoEmployer
# ---------------------------------------------------------------------------

class MongoEmployer(BaseModelEmployer):
    GENDER_CHOICES = (
        ('Male', 'male'),
        ('Female', 'female'),
        ('Other', 'other'),
    )

    email = models.EmailField(unique=True, verbose_name='Email', max_length=255)
    about = models.CharField(max_length=250, null=True, blank=True)
    photo_url = models.FileField(blank=True)
    linkedin_url = models.URLField(null=True, blank=True)
    group = models.ManyToManyField(Group, blank=True)
    phone_no = models.CharField(max_length=20, null=True, blank=True)
    first_name = models.CharField(max_length=150, null=True, blank=True)
    last_name = models.CharField(max_length=150, null=True, blank=True)
    employee_id = models.CharField(max_length=20, null=True, blank=True)
    department = models.CharField(max_length=100, null=True, blank=True)
    gender = models.CharField(max_length=100, choices=GENDER_CHOICES, default='Other')
    is_verified = models.BooleanField(default=False)
    module_priority = models.JSONField(default=list, blank=True)
    hiring_needs = models.TextField(max_length=3000, null=True, blank=True)

    @property
    def is_authenticated(self):
        return True

    @property
    def is_anonymous(self):
        return False

    def __str__(self):
        return f"{self.id} - {self.email}"

    class Meta:
        db_table = 'employer'


# ---------------------------------------------------------------------------
# AptPathAdmin
# ---------------------------------------------------------------------------

class AptPathAdmin(BaseModelAdmin):
    email = models.EmailField(unique=True, verbose_name='Email', max_length=255)
    first_name = models.CharField(max_length=150, null=True, blank=True)
    last_name = models.CharField(max_length=150, null=True, blank=True)
    photo_url = models.FileField(blank=True)
    password = models.CharField(max_length=128)

    @property
    def is_authenticated(self):
        return True

    def __str__(self):
        return self.email

    class Meta:
        db_table = 'aptpath-admin'


# ---------------------------------------------------------------------------
# Profile  (unified identity across all user types)
# ---------------------------------------------------------------------------

class Profile(BaseModelProfile):
    USER_TYPE_CHOICES = [
        ('aptpath', 'AptPath'),
        ('aicerts', 'AICerts'),
    ]

    email = models.EmailField(unique=True, verbose_name='Email', max_length=255)
    phone_no = models.CharField(max_length=20, null=True, blank=True)
    about = models.CharField(max_length=250, null=True, blank=True)
    photo_url = models.FileField(blank=True)
    banner_url = models.FileField(blank=True, null=True)
    group = models.ForeignKey(
        Group, on_delete=models.SET_NULL,
        verbose_name='Group', related_name='Profile',
        null=True, blank=True,
    )
    first_name = models.CharField(max_length=150, null=True, blank=True)
    last_name = models.CharField(max_length=150, null=True, blank=True)
    address = models.CharField(max_length=500, null=True, blank=True)
    state = models.CharField(max_length=150, null=True, blank=True)
    city = models.CharField(max_length=150, null=True, blank=True)
    country = models.CharField(max_length=150, null=True, blank=True)
    dob = models.CharField(max_length=150, null=True, blank=True)
    resume = models.FileField(blank=True, null=True)
    technical_skills = models.ManyToManyField('aptpath_models.MongoSkill', blank=True)
    user_type = models.CharField(
        max_length=20, choices=USER_TYPE_CHOICES,
        default='aptpath', verbose_name='User Type',
    )
    password = models.CharField(max_length=500, null=True, blank=True)

    def __str__(self):
        return self.email

    def get_full_name(self):
        parts = filter(None, [self.first_name, self.last_name])
        return ' '.join(parts) or self.email

    def save(self, *args, **kwargs):
        if self._state.adding and self.id is None:
            with transaction.atomic():
                agg = (
                    self.__class__.objects
                    .select_for_update()
                    .aggregate(max_id=Max('id'))
                )
                self.id = (agg['max_id'] or 0) + 1
        super().save(*args, **kwargs)

    class Meta:
        db_table = 'profile'


# ---------------------------------------------------------------------------
# Permissions  (generic object-level permission mapping)
# ---------------------------------------------------------------------------

class Permissions(models.Model):
    profile = models.ForeignKey(Profile, on_delete=models.SET_NULL, null=True)
    group = models.ForeignKey(
        Group, on_delete=models.SET_NULL,
        verbose_name='Group', related_name='Permissions',
        null=True, blank=True,
    )
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE, null=True)
    object_id = models.PositiveIntegerField(null=True)
    role_object = GenericForeignKey('content_type', 'object_id')

    def __str__(self):
        if self.profile:
            return f"{self.profile.email} - {self.group.name}"
        return ''

    class Meta:
        db_table = 'permissions'


# ---------------------------------------------------------------------------
# UserInvitation  (email verification / onboarding invitation for learners)
# ---------------------------------------------------------------------------

class UserInvitation(BaseModel):
    profile = models.ForeignKey(Profile, on_delete=models.SET_NULL, null=True)
    invitation_code = models.UUIDField(unique=True, default=uuid.uuid4)
    invitation_verified = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.profile} - {self.invitation_code}"

    class Meta:
        db_table = 'user_invitation'
