"""Tests for glreview.gitlab module."""

from __future__ import annotations

import os
from unittest.mock import MagicMock, patch

import pytest

from glreview.gitlab import (
    GitLabComment,
    GitLabConfig,
    GitLabIssue,
    GitLabMember,
    GitLabMergeRequest,
    add_issue_comment,
    close_issue,
    create_issue,
    create_merge_request,
    find_claude_review_comment,
    get_compare_url,
    get_gitlab_client,
    get_issue,
    get_issue_comments,
    get_project_members,
    gitlab_available,
    update_issue_review_label,
)


class TestGitLabConfig:
    """Tests for GitLabConfig dataclass."""

    def test_default_values(self):
        """Default values are correct."""
        config = GitLabConfig(url="https://gitlab.com")
        assert config.url == "https://gitlab.com"
        assert config.private_token is None
        assert config.job_token is None
        assert config.oauth_token is None

    def test_is_authenticated_with_private_token(self):
        """is_authenticated returns True with private token."""
        config = GitLabConfig(url="https://gitlab.com", private_token="token")
        assert config.is_authenticated is True

    def test_is_authenticated_with_job_token(self):
        """is_authenticated returns True with job token."""
        config = GitLabConfig(url="https://gitlab.com", job_token="token")
        assert config.is_authenticated is True

    def test_is_authenticated_with_oauth_token(self):
        """is_authenticated returns True with oauth token."""
        config = GitLabConfig(url="https://gitlab.com", oauth_token="token")
        assert config.is_authenticated is True

    def test_is_authenticated_without_token(self):
        """is_authenticated returns False without tokens."""
        config = GitLabConfig(url="https://gitlab.com")
        assert config.is_authenticated is False

    def test_from_environment_default(self, monkeypatch):
        """from_environment uses defaults without env vars."""
        monkeypatch.delenv("GITLAB_URL", raising=False)
        monkeypatch.delenv("GITLAB_PRIVATE_TOKEN", raising=False)
        monkeypatch.delenv("GITLAB_TOKEN", raising=False)
        monkeypatch.delenv("CI_JOB_TOKEN", raising=False)
        monkeypatch.delenv("GITLAB_OAUTH_TOKEN", raising=False)

        config = GitLabConfig.from_environment()
        assert config.url == "https://gitlab.com"
        assert config.is_authenticated is False

    def test_from_environment_with_host(self, monkeypatch):
        """from_environment uses provided host."""
        monkeypatch.delenv("GITLAB_URL", raising=False)

        config = GitLabConfig.from_environment(host="git.ligo.org")
        assert config.url == "https://git.ligo.org"

    def test_from_environment_with_env_url(self, monkeypatch):
        """from_environment uses GITLAB_URL env var."""
        monkeypatch.setenv("GITLAB_URL", "https://custom.gitlab.com")

        config = GitLabConfig.from_environment()
        assert config.url == "https://custom.gitlab.com"

    def test_from_environment_ci_job_token(self, monkeypatch):
        """from_environment reads CI_JOB_TOKEN."""
        monkeypatch.setenv("CI_JOB_TOKEN", "job-token-123")

        config = GitLabConfig.from_environment()
        assert config.job_token == "job-token-123"

    def test_from_environment_private_token(self, monkeypatch):
        """from_environment reads GITLAB_PRIVATE_TOKEN."""
        monkeypatch.setenv("GITLAB_PRIVATE_TOKEN", "private-token-123")

        config = GitLabConfig.from_environment()
        assert config.private_token == "private-token-123"

    def test_from_environment_gitlab_token_alias(self, monkeypatch):
        """from_environment reads GITLAB_TOKEN alias."""
        monkeypatch.setenv("GITLAB_TOKEN", "alias-token-123")

        config = GitLabConfig.from_environment()
        assert config.private_token == "alias-token-123"


class TestGitLabIssue:
    """Tests for GitLabIssue dataclass."""

    def test_from_api_response(self):
        """Creates GitLabIssue from API response."""
        mock_issue = MagicMock()
        mock_issue.iid = 42
        mock_issue.web_url = "https://gitlab.com/org/project/-/issues/42"
        mock_issue.title = "Test Issue"
        mock_issue.state = "opened"
        mock_issue.assignees = [{"username": "alice"}, {"username": "bob"}]
        mock_issue.labels = ["review", "high-priority"]

        issue = GitLabIssue.from_api_response(mock_issue)

        assert issue.number == "42"
        assert issue.url == "https://gitlab.com/org/project/-/issues/42"
        assert issue.title == "Test Issue"
        assert issue.state == "opened"
        assert issue.assignees == ["alice", "bob"]
        assert issue.labels == ["review", "high-priority"]

    def test_from_api_response_no_assignees(self):
        """Handles None assignees."""
        mock_issue = MagicMock()
        mock_issue.iid = 42
        mock_issue.web_url = "https://gitlab.com/org/project/-/issues/42"
        mock_issue.title = "Test Issue"
        mock_issue.state = "opened"
        mock_issue.assignees = None
        mock_issue.labels = []

        issue = GitLabIssue.from_api_response(mock_issue)
        assert issue.assignees == []


class TestGitLabMember:
    """Tests for GitLabMember dataclass."""

    def test_from_api_response(self):
        """Creates GitLabMember from API response."""
        mock_member = MagicMock()
        mock_member.username = "alice"
        mock_member.name = "Alice Smith"
        mock_member.access_level = 40

        member = GitLabMember.from_api_response(mock_member)

        assert member.username == "alice"
        assert member.name == "Alice Smith"
        assert member.access_level == 40

    def test_access_level_name(self):
        """access_level_name returns human-readable name."""
        assert GitLabMember("u", "n", 50).access_level_name == "Owner"
        assert GitLabMember("u", "n", 40).access_level_name == "Maintainer"
        assert GitLabMember("u", "n", 30).access_level_name == "Developer"
        assert GitLabMember("u", "n", 20).access_level_name == "Reporter"
        assert GitLabMember("u", "n", 10).access_level_name == "Guest"
        assert GitLabMember("u", "n", 99).access_level_name == "Level 99"


class TestGetGitlabClient:
    """Tests for get_gitlab_client function."""

    @patch("glreview.gitlab._get_gitlab_client")
    def test_returns_none_without_auth(self, mock_get_client, monkeypatch):
        """Returns None when not authenticated."""
        monkeypatch.delenv("GITLAB_PRIVATE_TOKEN", raising=False)
        monkeypatch.delenv("GITLAB_TOKEN", raising=False)
        monkeypatch.delenv("CI_JOB_TOKEN", raising=False)
        monkeypatch.delenv("GITLAB_OAUTH_TOKEN", raising=False)

        client = get_gitlab_client()
        assert client is None
        mock_get_client.assert_not_called()

    @patch("glreview.gitlab._get_gitlab_client")
    def test_returns_client_with_auth(self, mock_get_client):
        """Returns client when authenticated."""
        mock_gl = MagicMock()
        mock_get_client.return_value = mock_gl

        config = GitLabConfig(url="https://gitlab.com", private_token="token")
        client = get_gitlab_client(config)

        assert client == mock_gl
        mock_gl.auth.assert_called_once()


class TestGitlabAvailable:
    """Tests for gitlab_available function."""

    @patch("glreview.gitlab.get_gitlab_client")
    def test_returns_true_when_authenticated(self, mock_get_client, monkeypatch):
        """Returns True when client authenticates."""
        # Must have token in env for is_authenticated to be True
        monkeypatch.setenv("GITLAB_PRIVATE_TOKEN", "test-token")
        mock_get_client.return_value = MagicMock()

        result = gitlab_available()
        assert result is True

    def test_returns_false_without_token(self, monkeypatch):
        """Returns False without token."""
        monkeypatch.delenv("GITLAB_PRIVATE_TOKEN", raising=False)
        monkeypatch.delenv("GITLAB_TOKEN", raising=False)
        monkeypatch.delenv("CI_JOB_TOKEN", raising=False)
        monkeypatch.delenv("GITLAB_OAUTH_TOKEN", raising=False)

        result = gitlab_available()
        assert result is False


class TestCreateIssue:
    """Tests for create_issue function."""

    @patch("glreview.gitlab.get_gitlab_client")
    @patch("glreview.gitlab._get_project")
    def test_creates_issue(self, mock_get_project, mock_get_client):
        """Creates issue successfully."""
        mock_gl = MagicMock()
        mock_get_client.return_value = mock_gl

        mock_project = MagicMock()
        mock_get_project.return_value = mock_project

        mock_issue = MagicMock()
        mock_issue.iid = 42
        mock_issue.web_url = "https://gitlab.com/org/project/-/issues/42"
        mock_issue.title = "Review: module.py"
        mock_issue.state = "opened"
        mock_issue.assignees = []
        mock_issue.labels = ["review"]
        mock_project.issues.create.return_value = mock_issue

        result = create_issue(
            title="Review: module.py",
            description="Please review this module",
            project_path="org/project",
            labels=["review"],
        )

        assert result is not None
        assert result.number == "42"
        mock_project.issues.create.assert_called_once()

    def test_returns_none_without_project_path(self):
        """Returns None when project_path is None."""
        result = create_issue(
            title="Test",
            description="Test",
            project_path=None,
        )
        assert result is None

    @patch("glreview.gitlab.get_gitlab_client")
    def test_returns_none_without_client(self, mock_get_client):
        """Returns None when client is None."""
        mock_get_client.return_value = None

        result = create_issue(
            title="Test",
            description="Test",
            project_path="org/project",
        )
        assert result is None


class TestGetIssue:
    """Tests for get_issue function."""

    @patch("glreview.gitlab.get_gitlab_client")
    @patch("glreview.gitlab._get_project")
    def test_gets_issue(self, mock_get_project, mock_get_client):
        """Gets issue details."""
        mock_gl = MagicMock()
        mock_get_client.return_value = mock_gl

        mock_project = MagicMock()
        mock_get_project.return_value = mock_project

        mock_issue = MagicMock()
        mock_issue.iid = 42
        mock_issue.web_url = "https://gitlab.com/org/project/-/issues/42"
        mock_issue.title = "Test Issue"
        mock_issue.state = "closed"
        mock_issue.assignees = [{"username": "alice"}]
        mock_issue.labels = []
        mock_project.issues.get.return_value = mock_issue

        result = get_issue("42", project_path="org/project")

        assert result is not None
        assert result.number == "42"
        assert result.state == "closed"

    def test_returns_none_without_project_path(self):
        """Returns None when project_path is None."""
        result = get_issue("42", project_path=None)
        assert result is None


class TestCloseIssue:
    """Tests for close_issue function."""

    @patch("glreview.gitlab.get_gitlab_client")
    @patch("glreview.gitlab._get_project")
    def test_closes_issue(self, mock_get_project, mock_get_client):
        """Closes issue successfully."""
        mock_gl = MagicMock()
        mock_get_client.return_value = mock_gl

        mock_project = MagicMock()
        mock_get_project.return_value = mock_project

        mock_issue = MagicMock()
        mock_project.issues.get.return_value = mock_issue

        result = close_issue("42", project_path="org/project")

        assert result is True
        mock_issue.save.assert_called_once()
        assert mock_issue.state_event == "close"

    @patch("glreview.gitlab.get_gitlab_client")
    @patch("glreview.gitlab._get_project")
    def test_closes_with_comment(self, mock_get_project, mock_get_client):
        """Closes issue with comment."""
        mock_gl = MagicMock()
        mock_get_client.return_value = mock_gl

        mock_project = MagicMock()
        mock_get_project.return_value = mock_project

        mock_issue = MagicMock()
        mock_project.issues.get.return_value = mock_issue

        result = close_issue("42", project_path="org/project", comment="Done!")

        assert result is True
        mock_issue.notes.create.assert_called_once_with({"body": "Done!"})

    def test_returns_false_without_project_path(self):
        """Returns False when project_path is None."""
        result = close_issue("42", project_path=None)
        assert result is False


class TestAddIssueComment:
    """Tests for add_issue_comment function."""

    @patch("glreview.gitlab.get_gitlab_client")
    @patch("glreview.gitlab._get_project")
    def test_adds_comment(self, mock_get_project, mock_get_client):
        """Adds comment successfully."""
        mock_gl = MagicMock()
        mock_get_client.return_value = mock_gl

        mock_project = MagicMock()
        mock_get_project.return_value = mock_project

        mock_issue = MagicMock()
        mock_project.issues.get.return_value = mock_issue

        result = add_issue_comment("42", project_path="org/project", comment="LGTM!")

        assert result is True
        mock_issue.notes.create.assert_called_once_with({"body": "LGTM!"})

    def test_returns_false_without_project_path(self):
        """Returns False when project_path is None."""
        result = add_issue_comment("42", project_path=None, comment="Test")
        assert result is False


class TestGetProjectMembers:
    """Tests for get_project_members function."""

    @patch("glreview.gitlab.get_gitlab_client")
    @patch("glreview.gitlab._get_project")
    def test_gets_members(self, mock_get_project, mock_get_client):
        """Gets project members."""
        mock_gl = MagicMock()
        mock_get_client.return_value = mock_gl

        mock_project = MagicMock()
        mock_get_project.return_value = mock_project

        mock_member = MagicMock()
        mock_member.username = "alice"
        mock_member.name = "Alice Smith"
        mock_member.access_level = 40
        mock_project.members_all.list.return_value = [mock_member]

        result = get_project_members(project_path="org/project")

        assert len(result) == 1
        assert result[0].username == "alice"

    def test_returns_empty_without_project_path(self):
        """Returns empty list when project_path is None."""
        result = get_project_members(project_path=None)
        assert result == []


class TestGetCompareUrl:
    """Tests for get_compare_url function."""

    def test_generates_url(self):
        """Generates correct compare URL."""
        url = get_compare_url(
            project="org/project",
            host="gitlab.com",
            from_commit="abc123",
            to_commit="def456",
        )
        assert url == (
            "https://gitlab.com/org/project/-/compare/"
            "abc123...def456?from_project_id=&straight=false"
        )

    def test_returns_empty_without_project(self):
        """Returns empty string when project is None."""
        url = get_compare_url(
            project=None,
            host="gitlab.com",
            from_commit="abc123",
            to_commit="def456",
        )
        assert url == ""


class TestGetGitlabClientInternal:
    """Tests for _get_gitlab_client internal function."""

    @patch("glreview.gitlab.gitlab.Gitlab")
    def test_job_token_path(self, mock_gitlab):
        """Creates client with job token when provided."""
        from glreview.gitlab import _get_gitlab_client

        _get_gitlab_client.cache_clear()
        _get_gitlab_client("https://gitlab.com", None, "job-token-123")
        mock_gitlab.assert_called_with("https://gitlab.com", job_token="job-token-123")

    @patch("glreview.gitlab.gitlab.Gitlab")
    def test_private_token_path(self, mock_gitlab):
        """Creates client with private token when provided."""
        from glreview.gitlab import _get_gitlab_client

        _get_gitlab_client.cache_clear()
        _get_gitlab_client("https://gitlab.com", "private-token-123", None)
        mock_gitlab.assert_called_with(
            "https://gitlab.com", private_token="private-token-123"
        )

    @patch("glreview.gitlab.gitlab.Gitlab")
    def test_no_token_path(self, mock_gitlab):
        """Creates client without token when none provided."""
        from glreview.gitlab import _get_gitlab_client

        _get_gitlab_client.cache_clear()
        _get_gitlab_client("https://gitlab.com", None, None)
        mock_gitlab.assert_called_with("https://gitlab.com")


class TestGetGitlabClientAuthError:
    """Tests for get_gitlab_client authentication error handling."""

    @patch("glreview.gitlab._get_gitlab_client")
    def test_returns_none_on_auth_error(self, mock_get_client, monkeypatch):
        """Returns None when authentication fails."""
        from gitlab.exceptions import GitlabAuthenticationError

        monkeypatch.setenv("GITLAB_PRIVATE_TOKEN", "bad-token")
        mock_gl = MagicMock()
        mock_gl.auth.side_effect = GitlabAuthenticationError()
        mock_get_client.return_value = mock_gl

        client = get_gitlab_client()
        assert client is None


class TestGetProject:
    """Tests for _get_project internal function."""

    @patch("glreview.gitlab.gitlab.Gitlab")
    def test_returns_none_on_error(self, mock_gitlab_class):
        """Returns None when project fetch fails."""
        from gitlab.exceptions import GitlabGetError

        from glreview.gitlab import _get_project

        mock_gl = MagicMock()
        mock_gl.projects.get.side_effect = GitlabGetError()

        result = _get_project(mock_gl, "nonexistent/project")
        assert result is None


class TestCreateIssueEdgeCases:
    """Additional edge case tests for create_issue."""

    @patch("glreview.gitlab.get_gitlab_client")
    @patch("glreview.gitlab._get_project")
    def test_returns_none_when_project_not_found(
        self, mock_get_project, mock_get_client
    ):
        """Returns None when project doesn't exist."""
        mock_get_client.return_value = MagicMock()
        mock_get_project.return_value = None

        result = create_issue(
            title="Test",
            description="Test",
            project_path="org/project",
        )
        assert result is None

    @patch("glreview.gitlab.get_gitlab_client")
    @patch("glreview.gitlab._get_project")
    def test_handles_user_lookup_success(self, mock_get_project, mock_get_client):
        """Assigns issue to user when lookup succeeds."""
        mock_gl = MagicMock()
        mock_get_client.return_value = mock_gl

        # Mock successful user lookup
        mock_user = MagicMock()
        mock_user.id = 123
        mock_gl.users.list.return_value = [mock_user]

        mock_project = MagicMock()
        mock_get_project.return_value = mock_project

        mock_issue = MagicMock()
        mock_issue.iid = 42
        mock_issue.web_url = "https://gitlab.com/org/project/-/issues/42"
        mock_issue.title = "Test"
        mock_issue.state = "opened"
        mock_issue.assignees = [MagicMock(username="alice")]
        mock_issue.labels = []
        mock_project.issues.create.return_value = mock_issue

        result = create_issue(
            title="Test",
            description="Test",
            project_path="org/project",
            assignee="@alice",
        )

        assert result is not None
        # Verify that assignee_ids was set in the call
        call_args = mock_project.issues.create.call_args
        assert call_args[0][0].get("assignee_ids") == [123]

    @patch("glreview.gitlab.get_gitlab_client")
    @patch("glreview.gitlab._get_project")
    def test_handles_user_lookup_failure(self, mock_get_project, mock_get_client):
        """Continues without assignee when user lookup fails."""
        mock_gl = MagicMock()
        mock_get_client.return_value = mock_gl
        mock_gl.users.list.side_effect = Exception("Lookup failed")

        mock_project = MagicMock()
        mock_get_project.return_value = mock_project

        mock_issue = MagicMock()
        mock_issue.iid = 42
        mock_issue.web_url = "https://gitlab.com/org/project/-/issues/42"
        mock_issue.title = "Test"
        mock_issue.state = "opened"
        mock_issue.assignees = []
        mock_issue.labels = []
        mock_project.issues.create.return_value = mock_issue

        result = create_issue(
            title="Test",
            description="Test",
            project_path="org/project",
            assignee="@alice",
        )

        assert result is not None
        # Should have called issues.create even without assignee

    @patch("glreview.gitlab.get_gitlab_client")
    @patch("glreview.gitlab._get_project")
    def test_returns_none_on_create_exception(self, mock_get_project, mock_get_client):
        """Returns None when issue creation fails."""
        mock_gl = MagicMock()
        mock_get_client.return_value = mock_gl

        mock_project = MagicMock()
        mock_get_project.return_value = mock_project
        mock_project.issues.create.side_effect = Exception("API Error")

        result = create_issue(
            title="Test",
            description="Test",
            project_path="org/project",
        )

        assert result is None


class TestGetIssueEdgeCases:
    """Additional edge case tests for get_issue."""

    @patch("glreview.gitlab.get_gitlab_client")
    def test_returns_none_when_client_unavailable(self, mock_get_client):
        """Returns None when client is None."""
        mock_get_client.return_value = None

        result = get_issue("42", project_path="org/project")
        assert result is None

    @patch("glreview.gitlab.get_gitlab_client")
    @patch("glreview.gitlab._get_project")
    def test_returns_none_when_project_not_found(
        self, mock_get_project, mock_get_client
    ):
        """Returns None when project doesn't exist."""
        mock_get_client.return_value = MagicMock()
        mock_get_project.return_value = None

        result = get_issue("42", project_path="org/project")
        assert result is None

    @patch("glreview.gitlab.get_gitlab_client")
    @patch("glreview.gitlab._get_project")
    def test_returns_none_on_get_exception(self, mock_get_project, mock_get_client):
        """Returns None when get fails."""
        mock_gl = MagicMock()
        mock_get_client.return_value = mock_gl

        mock_project = MagicMock()
        mock_get_project.return_value = mock_project
        mock_project.issues.get.side_effect = Exception("Not found")

        result = get_issue("42", project_path="org/project")
        assert result is None


class TestGetProjectMembersEdgeCases:
    """Additional edge case tests for get_project_members."""

    @patch("glreview.gitlab.get_gitlab_client")
    def test_returns_empty_when_client_unavailable(self, mock_get_client):
        """Returns empty list when client is None."""
        mock_get_client.return_value = None

        result = get_project_members(project_path="org/project")
        assert result == []

    @patch("glreview.gitlab.get_gitlab_client")
    @patch("glreview.gitlab._get_project")
    def test_returns_empty_when_project_not_found(
        self, mock_get_project, mock_get_client
    ):
        """Returns empty list when project doesn't exist."""
        mock_get_client.return_value = MagicMock()
        mock_get_project.return_value = None

        result = get_project_members(project_path="org/project")
        assert result == []

    @patch("glreview.gitlab.get_gitlab_client")
    @patch("glreview.gitlab._get_project")
    def test_returns_empty_on_list_exception(self, mock_get_project, mock_get_client):
        """Returns empty list when list fails."""
        mock_gl = MagicMock()
        mock_get_client.return_value = mock_gl

        mock_project = MagicMock()
        mock_get_project.return_value = mock_project
        mock_project.members_all.list.side_effect = Exception("API Error")

        result = get_project_members(project_path="org/project")
        assert result == []


class TestCloseIssueEdgeCases:
    """Additional edge case tests for close_issue."""

    @patch("glreview.gitlab.get_gitlab_client")
    def test_returns_false_when_client_unavailable(self, mock_get_client):
        """Returns False when client is None."""
        mock_get_client.return_value = None

        result = close_issue("42", project_path="org/project")
        assert result is False

    @patch("glreview.gitlab.get_gitlab_client")
    @patch("glreview.gitlab._get_project")
    def test_returns_false_when_project_not_found(
        self, mock_get_project, mock_get_client
    ):
        """Returns False when project doesn't exist."""
        mock_get_client.return_value = MagicMock()
        mock_get_project.return_value = None

        result = close_issue("42", project_path="org/project")
        assert result is False

    @patch("glreview.gitlab.get_gitlab_client")
    @patch("glreview.gitlab._get_project")
    def test_returns_false_on_close_exception(self, mock_get_project, mock_get_client):
        """Returns False when close fails."""
        mock_gl = MagicMock()
        mock_get_client.return_value = mock_gl

        mock_project = MagicMock()
        mock_get_project.return_value = mock_project
        mock_project.issues.get.side_effect = Exception("Not found")

        result = close_issue("42", project_path="org/project")
        assert result is False


class TestAddIssueCommentEdgeCases:
    """Additional edge case tests for add_issue_comment."""

    @patch("glreview.gitlab.get_gitlab_client")
    def test_returns_false_when_client_unavailable(self, mock_get_client):
        """Returns False when client is None."""
        mock_get_client.return_value = None

        result = add_issue_comment("42", project_path="org/project", comment="Test")
        assert result is False

    @patch("glreview.gitlab.get_gitlab_client")
    @patch("glreview.gitlab._get_project")
    def test_returns_false_when_project_not_found(
        self, mock_get_project, mock_get_client
    ):
        """Returns False when project doesn't exist."""
        mock_get_client.return_value = MagicMock()
        mock_get_project.return_value = None

        result = add_issue_comment("42", project_path="org/project", comment="Test")
        assert result is False

    @patch("glreview.gitlab.get_gitlab_client")
    @patch("glreview.gitlab._get_project")
    def test_returns_false_on_comment_exception(self, mock_get_project, mock_get_client):
        """Returns False when comment creation fails."""
        mock_gl = MagicMock()
        mock_get_client.return_value = mock_gl

        mock_project = MagicMock()
        mock_get_project.return_value = mock_project
        mock_project.issues.get.side_effect = Exception("Not found")

        result = add_issue_comment("42", project_path="org/project", comment="Test")
        assert result is False


class TestGitLabMergeRequest:
    """Tests for GitLabMergeRequest dataclass."""

    def test_from_api_response(self):
        """Creates GitLabMergeRequest from API response."""
        mock_mr = MagicMock()
        mock_mr.iid = 10
        mock_mr.web_url = "https://gitlab.com/org/project/-/merge_requests/10"
        mock_mr.title = "Fix review findings"
        mock_mr.state = "opened"
        mock_mr.source_branch = "fix/review-main-42"
        mock_mr.target_branch = "main"

        mr = GitLabMergeRequest.from_api_response(mock_mr)

        assert mr.iid == 10
        assert mr.url == "https://gitlab.com/org/project/-/merge_requests/10"
        assert mr.title == "Fix review findings"
        assert mr.state == "opened"
        assert mr.source_branch == "fix/review-main-42"
        assert mr.target_branch == "main"


class TestCreateMergeRequest:
    """Tests for create_merge_request function."""

    @patch("glreview.gitlab.get_gitlab_client")
    @patch("glreview.gitlab._get_project")
    def test_creates_mr(self, mock_get_project, mock_get_client):
        """Creates merge request successfully."""
        mock_gl = MagicMock()
        mock_get_client.return_value = mock_gl

        mock_project = MagicMock()
        mock_get_project.return_value = mock_project

        mock_mr = MagicMock()
        mock_mr.iid = 10
        mock_mr.web_url = "https://gitlab.com/org/project/-/merge_requests/10"
        mock_mr.title = "Automated Fix: src/main.py"
        mock_mr.state = "opened"
        mock_mr.source_branch = "fix/review-main-42"
        mock_mr.target_branch = "main"
        mock_project.mergerequests.create.return_value = mock_mr

        result = create_merge_request(
            title="Automated Fix: src/main.py",
            description="Fix description",
            source_branch="fix/review-main-42",
            target_branch="main",
            project_path="org/project",
            labels=["review"],
        )

        assert result is not None
        assert result.iid == 10
        assert result.url == "https://gitlab.com/org/project/-/merge_requests/10"
        mock_project.mergerequests.create.assert_called_once()

        # Verify the data passed
        call_args = mock_project.mergerequests.create.call_args[0][0]
        assert call_args["title"] == "Automated Fix: src/main.py"
        assert call_args["source_branch"] == "fix/review-main-42"
        assert call_args["target_branch"] == "main"
        assert call_args["remove_source_branch"] is True
        assert call_args["labels"] == ["review"]

    def test_returns_none_without_project_path(self):
        """Returns None when project_path is None."""
        result = create_merge_request(
            title="Test",
            description="Test",
            source_branch="src",
            target_branch="main",
            project_path=None,
        )
        assert result is None

    @patch("glreview.gitlab.get_gitlab_client")
    def test_returns_none_without_client(self, mock_get_client):
        """Returns None when client is None."""
        mock_get_client.return_value = None

        result = create_merge_request(
            title="Test",
            description="Test",
            source_branch="src",
            target_branch="main",
            project_path="org/project",
        )
        assert result is None

    @patch("glreview.gitlab.get_gitlab_client")
    @patch("glreview.gitlab._get_project")
    def test_returns_none_on_api_error(self, mock_get_project, mock_get_client):
        """Returns None when API call fails."""
        mock_gl = MagicMock()
        mock_get_client.return_value = mock_gl

        mock_project = MagicMock()
        mock_get_project.return_value = mock_project
        mock_project.mergerequests.create.side_effect = Exception("API Error")

        result = create_merge_request(
            title="Test",
            description="Test",
            source_branch="src",
            target_branch="main",
            project_path="org/project",
        )
        assert result is None

    @patch("glreview.gitlab.get_gitlab_client")
    @patch("glreview.gitlab._get_project")
    def test_handles_assignee(self, mock_get_project, mock_get_client):
        """Assigns MR to user when lookup succeeds."""
        mock_gl = MagicMock()
        mock_get_client.return_value = mock_gl

        mock_user = MagicMock()
        mock_user.id = 123
        mock_gl.users.list.return_value = [mock_user]

        mock_project = MagicMock()
        mock_get_project.return_value = mock_project

        mock_mr = MagicMock()
        mock_mr.iid = 10
        mock_mr.web_url = "https://gitlab.com/org/project/-/merge_requests/10"
        mock_mr.title = "Test"
        mock_mr.state = "opened"
        mock_mr.source_branch = "src"
        mock_mr.target_branch = "main"
        mock_project.mergerequests.create.return_value = mock_mr

        result = create_merge_request(
            title="Test",
            description="Test",
            source_branch="src",
            target_branch="main",
            project_path="org/project",
            assignee="@alice",
        )

        assert result is not None
        call_args = mock_project.mergerequests.create.call_args[0][0]
        assert call_args.get("assignee_ids") == [123]


class TestCreateMergeRequestAssigneeFailure:
    """Tests for MR assignee lookup failure path (lines 471-472)."""

    @patch("glreview.gitlab.get_gitlab_client")
    @patch("glreview.gitlab._get_project")
    def test_mr_created_when_assignee_lookup_fails(
        self, mock_get_project, mock_get_client
    ):
        """MR is still created when user lookup raises an exception."""
        mock_gl = MagicMock()
        mock_get_client.return_value = mock_gl
        mock_gl.users.list.side_effect = Exception("User service unavailable")

        mock_project = MagicMock()
        mock_get_project.return_value = mock_project

        mock_mr = MagicMock()
        mock_mr.iid = 15
        mock_mr.web_url = "https://gitlab.com/org/project/-/merge_requests/15"
        mock_mr.title = "Fix things"
        mock_mr.state = "opened"
        mock_mr.source_branch = "fix/branch"
        mock_mr.target_branch = "main"
        mock_project.mergerequests.create.return_value = mock_mr

        result = create_merge_request(
            title="Fix things",
            description="Description",
            source_branch="fix/branch",
            target_branch="main",
            project_path="org/project",
            assignee="@alice",
        )

        assert result is not None
        assert result.iid == 15
        # Verify MR was created without assignee_ids
        call_args = mock_project.mergerequests.create.call_args[0][0]
        assert "assignee_ids" not in call_args
        mock_project.mergerequests.create.assert_called_once()

    @patch("glreview.gitlab.get_gitlab_client")
    @patch("glreview.gitlab._get_project")
    def test_mr_assignee_lookup_strips_at_sign(
        self, mock_get_project, mock_get_client
    ):
        """Assignee lookup strips leading @ before calling users.list."""
        mock_gl = MagicMock()
        mock_get_client.return_value = mock_gl
        mock_gl.users.list.side_effect = Exception("Lookup failed")

        mock_project = MagicMock()
        mock_get_project.return_value = mock_project

        mock_mr = MagicMock()
        mock_mr.iid = 20
        mock_mr.web_url = "https://gitlab.com/org/project/-/merge_requests/20"
        mock_mr.title = "Test"
        mock_mr.state = "opened"
        mock_mr.source_branch = "src"
        mock_mr.target_branch = "main"
        mock_project.mergerequests.create.return_value = mock_mr

        create_merge_request(
            title="Test",
            description="Test",
            source_branch="src",
            target_branch="main",
            project_path="org/project",
            assignee="@bob",
        )

        mock_gl.users.list.assert_called_once_with(username="bob")


class TestUpdateIssueReviewLabel:
    """Tests for update_issue_review_label function (lines 528-552)."""

    @patch("glreview.gitlab.get_gitlab_client")
    @patch("glreview.gitlab._get_project")
    def test_updates_label_successfully(self, mock_get_project, mock_get_client):
        """Replaces review:: labels with new status label."""
        mock_gl = MagicMock()
        mock_get_client.return_value = mock_gl

        mock_project = MagicMock()
        mock_get_project.return_value = mock_project

        mock_issue = MagicMock()
        mock_issue.labels = ["bug", "review::pending", "priority::high"]
        mock_project.issues.get.return_value = mock_issue

        result = update_issue_review_label(
            issue_number="42",
            project_path="org/project",
            new_status="ok",
        )

        assert result is True
        assert mock_issue.labels == ["bug", "priority::high", "review::ok"]
        mock_issue.save.assert_called_once()

    @patch("glreview.gitlab.get_gitlab_client")
    @patch("glreview.gitlab._get_project")
    def test_adds_label_when_no_existing_review_labels(
        self, mock_get_project, mock_get_client
    ):
        """Adds review label even when no review:: labels exist yet."""
        mock_gl = MagicMock()
        mock_get_client.return_value = mock_gl

        mock_project = MagicMock()
        mock_get_project.return_value = mock_project

        mock_issue = MagicMock()
        mock_issue.labels = ["bug"]
        mock_project.issues.get.return_value = mock_issue

        result = update_issue_review_label(
            issue_number="10",
            project_path="org/project",
            new_status="pending",
        )

        assert result is True
        assert mock_issue.labels == ["bug", "review::pending"]
        mock_issue.save.assert_called_once()

    @patch("glreview.gitlab.get_gitlab_client")
    @patch("glreview.gitlab._get_project")
    def test_handles_none_labels(self, mock_get_project, mock_get_client):
        """Handles issue with None labels."""
        mock_gl = MagicMock()
        mock_get_client.return_value = mock_gl

        mock_project = MagicMock()
        mock_get_project.return_value = mock_project

        mock_issue = MagicMock()
        mock_issue.labels = None
        mock_project.issues.get.return_value = mock_issue

        result = update_issue_review_label(
            issue_number="5",
            project_path="org/project",
            new_status="required",
        )

        assert result is True
        assert mock_issue.labels == ["review::required"]

    def test_returns_false_without_project_path(self):
        """Returns False when project_path is None."""
        result = update_issue_review_label(
            issue_number="42",
            project_path=None,
            new_status="ok",
        )
        assert result is False

    @patch("glreview.gitlab.get_gitlab_client")
    @patch("glreview.gitlab._get_project")
    def test_returns_false_on_exception(self, mock_get_project, mock_get_client):
        """Returns False when an exception occurs."""
        mock_gl = MagicMock()
        mock_get_client.return_value = mock_gl

        mock_project = MagicMock()
        mock_get_project.return_value = mock_project
        mock_project.issues.get.side_effect = Exception("API Error")

        result = update_issue_review_label(
            issue_number="42",
            project_path="org/project",
            new_status="ok",
        )

        assert result is False


class TestGitLabComment:
    """Tests for GitLabComment dataclass (line 567)."""

    def test_from_api_response(self):
        """Creates GitLabComment from a gitlab note object."""
        mock_note = MagicMock()
        mock_note.id = 100
        mock_note.body = "Looks good to me!"
        mock_note.author = {"username": "alice", "name": "Alice Smith"}
        mock_note.created_at = "2025-01-15T10:30:00Z"

        comment = GitLabComment.from_api_response(mock_note)

        assert comment.id == 100
        assert comment.body == "Looks good to me!"
        assert comment.author == "alice"
        assert comment.created_at == "2025-01-15T10:30:00Z"

    def test_from_api_response_no_author(self):
        """Uses 'unknown' when author is None."""
        mock_note = MagicMock()
        mock_note.id = 101
        mock_note.body = "System comment"
        mock_note.author = None
        mock_note.created_at = "2025-01-15T11:00:00Z"

        comment = GitLabComment.from_api_response(mock_note)

        assert comment.author == "unknown"

    def test_from_api_response_author_without_username(self):
        """Uses 'unknown' when author dict has no username key."""
        mock_note = MagicMock()
        mock_note.id = 102
        mock_note.body = "Another comment"
        mock_note.author = {"name": "Bot"}
        mock_note.created_at = "2025-01-15T12:00:00Z"

        comment = GitLabComment.from_api_response(mock_note)

        assert comment.author == "unknown"


class TestGetIssueComments:
    """Tests for get_issue_comments function (lines 590-605)."""

    @patch("glreview.gitlab.get_gitlab_client")
    @patch("glreview.gitlab._get_project")
    def test_returns_comments(self, mock_get_project, mock_get_client):
        """Returns list of GitLabComment objects from issue notes."""
        mock_gl = MagicMock()
        mock_get_client.return_value = mock_gl

        mock_project = MagicMock()
        mock_get_project.return_value = mock_project

        note1 = MagicMock()
        note1.id = 1
        note1.body = "First comment"
        note1.author = {"username": "alice"}
        note1.created_at = "2025-01-01T00:00:00Z"

        note2 = MagicMock()
        note2.id = 2
        note2.body = "Second comment"
        note2.author = {"username": "bob"}
        note2.created_at = "2025-01-02T00:00:00Z"

        mock_issue = MagicMock()
        mock_issue.notes.list.return_value = [note1, note2]
        mock_project.issues.get.return_value = mock_issue

        result = get_issue_comments("42", project_path="org/project")

        assert len(result) == 2
        assert result[0].id == 1
        assert result[0].body == "First comment"
        assert result[0].author == "alice"
        assert result[1].id == 2
        assert result[1].body == "Second comment"
        mock_issue.notes.list.assert_called_once_with(all=True)

    def test_returns_empty_without_project_path(self):
        """Returns empty list when project_path is None."""
        result = get_issue_comments("42", project_path=None)
        assert result == []

    @patch("glreview.gitlab.get_gitlab_client")
    @patch("glreview.gitlab._get_project")
    def test_returns_empty_on_exception(self, mock_get_project, mock_get_client):
        """Returns empty list when an exception occurs."""
        mock_gl = MagicMock()
        mock_get_client.return_value = mock_gl

        mock_project = MagicMock()
        mock_get_project.return_value = mock_project
        mock_project.issues.get.side_effect = Exception("Not found")

        result = get_issue_comments("99", project_path="org/project")

        assert result == []


class TestFindClaudeReviewComment:
    """Tests for find_claude_review_comment function (lines 625-632)."""

    @patch("glreview.gitlab.get_issue_comments")
    def test_finds_claude_code_review_marker(self, mock_get_comments):
        """Returns body of comment containing 'Claude Code Review'."""
        mock_get_comments.return_value = [
            GitLabComment(id=1, body="Regular comment", author="alice", created_at="t1"),
            GitLabComment(
                id=2,
                body="## Claude Code Review\nAll good!",
                author="bot",
                created_at="t2",
            ),
        ]

        result = find_claude_review_comment("42", project_path="org/project")

        assert result == "## Claude Code Review\nAll good!"

    @patch("glreview.gitlab.get_issue_comments")
    def test_finds_review_summary_marker(self, mock_get_comments):
        """Returns body of comment containing '## Review Summary'."""
        mock_get_comments.return_value = [
            GitLabComment(
                id=1,
                body="## Review Summary\nNeeds changes",
                author="bot",
                created_at="t1",
            ),
        ]

        result = find_claude_review_comment("42", project_path="org/project")

        assert result == "## Review Summary\nNeeds changes"

    @patch("glreview.gitlab.get_issue_comments")
    def test_returns_most_recent_match(self, mock_get_comments):
        """Returns the most recent matching comment (reversed iteration)."""
        mock_get_comments.return_value = [
            GitLabComment(
                id=1,
                body="## Claude Code Review\nOld review",
                author="bot",
                created_at="t1",
            ),
            GitLabComment(id=2, body="Unrelated note", author="alice", created_at="t2"),
            GitLabComment(
                id=3,
                body="## Claude Code Review\nLatest review",
                author="bot",
                created_at="t3",
            ),
        ]

        result = find_claude_review_comment("42", project_path="org/project")

        assert result == "## Claude Code Review\nLatest review"

    @patch("glreview.gitlab.get_issue_comments")
    def test_returns_none_when_no_match(self, mock_get_comments):
        """Returns None when no comment matches."""
        mock_get_comments.return_value = [
            GitLabComment(id=1, body="Just a normal comment", author="alice", created_at="t1"),
            GitLabComment(id=2, body="Another normal comment", author="bob", created_at="t2"),
        ]

        result = find_claude_review_comment("42", project_path="org/project")

        assert result is None

    @patch("glreview.gitlab.get_issue_comments")
    def test_returns_none_when_no_comments(self, mock_get_comments):
        """Returns None when there are no comments at all."""
        mock_get_comments.return_value = []

        result = find_claude_review_comment("42", project_path="org/project")

        assert result is None
