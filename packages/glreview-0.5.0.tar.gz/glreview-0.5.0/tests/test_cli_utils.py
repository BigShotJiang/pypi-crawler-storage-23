"""Tests for glreview.cli_utils module."""

from __future__ import annotations

import pytest

from glreview.cli_utils import require_module
from glreview.registry import ModuleStatus, Registry


class TestRequireModule:
    """Tests for require_module function."""

    def test_returns_module_when_found(self):
        """Returns the module when it exists in registry."""
        reg = Registry()
        reg.set(ModuleStatus(path="src/main.py", status="needs_review"))
        result = require_module("src/main.py", reg)
        assert result.path == "src/main.py"

    def test_exits_when_not_found(self):
        """Exits with code 1 when module not found."""
        reg = Registry()
        reg.set(ModuleStatus(path="src/main.py", status="needs_review"))
        with pytest.raises(SystemExit) as exc_info:
            require_module("nonexistent.py", reg)
        assert exc_info.value.code == 1

    def test_shows_more_than_10_modules(self, capsys):
        """Shows '... and N more' when registry has > 10 modules."""
        reg = Registry()
        for i in range(15):
            reg.set(ModuleStatus(path=f"src/mod{i:02d}.py", status="needs_review"))

        with pytest.raises(SystemExit):
            require_module("nonexistent.py", reg)

        captured = capsys.readouterr()
        assert "... and 5 more" in captured.out
