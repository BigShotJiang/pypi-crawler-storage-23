"""Constants used throughout glreview."""

# Token estimation for Claude
CHARS_PER_TOKEN = 4
MAX_TOKENS = 100000  # Leave room for prompt and response
MAX_SOURCE_CHARS = MAX_TOKENS * CHARS_PER_TOKEN

# File truncation limits
MAX_TEST_FILE_CHARS = 15000
MAX_CONTENT_CHARS = 10000

# Display settings
PROGRESS_BAR_WIDTH = 20
DEFAULT_MAX_SAMPLES = 10
DEFAULT_MAX_DISPLAY_ITEMS = 8

# Claude CLI
CLAUDE_REVIEW_TIMEOUT = 300  # 5 minutes in seconds
CLAUDE_INSTALL_URL = "https://claude.ai/code"
