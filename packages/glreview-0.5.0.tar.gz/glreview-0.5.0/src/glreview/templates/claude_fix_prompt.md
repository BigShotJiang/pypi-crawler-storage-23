You are fixing issues identified in a code review. Your task is to address the issues while maintaining code quality and following project conventions.

## Module Information

**Module:** `{{ path }}`

## Source Code

```python
{{ source_code }}
```
{% if project_context %}

## Project Context

{{ project_context }}
{% endif %}
{% if test_files %}

## Associated Test Files

{% for test_file in test_files %}
### {{ test_file.path }}

```python
{{ test_file.content }}
```
{% endfor %}
{% endif %}

## Review Findings to Address

{% if required_items %}
### REQUIRED (must fix)

{% for item in required_items %}
{{ loop.index }}. **{{ item.criterion }}**: {{ item.description }}
{% endfor %}
{% endif %}
{% if suggested_items %}

### SUGGESTED (optional improvements)

{% for item in suggested_items %}
{{ loop.index }}. **{{ item.criterion }}**: {{ item.description }}
{% endfor %}
{% endif %}

## Instructions

{% if fix_all %}
Address ALL issues listed above (both REQUIRED and SUGGESTED).
{% else %}
Address only the REQUIRED issues listed above.
{% endif %}

For each fix:
1. Make the minimal change necessary to address the issue
2. Follow existing code style and project conventions
3. Maintain or improve code quality (DRY, clear naming, appropriate abstractions)
4. Update tests if the fix changes behavior
5. Do not introduce new issues or break existing functionality

{% if custom_instructions %}

## Additional Instructions

{{ custom_instructions }}
{% endif %}

After making changes, briefly explain what you fixed and why.
