You are updating the project context for a code review system. The project has changed since the context was last generated.

## Current Project Context

```json
{{ current_context }}
```

## Changes Since Last Sync

**Previous commit:** `{{ previous_commit }}`
**Current commit:** `{{ current_commit }}`

### Files Changed
{% for path in changed_files %}
- `{{ path }}`
{% endfor %}

### Files Added
{% for path in added_files %}
- `{{ path }}`
{% endfor %}

### Files Removed
{% for path in removed_files %}
- `{{ path }}`
{% endfor %}

## Updated Source Code

Below is the current content of changed/added modules:

{% for sample in samples %}
### {{ sample.path }}

```python
{{ sample.content }}
```

{% endfor %}

## Your Task

Update the project context to reflect these changes. Produce a complete updated JSON response with the same structure:

```json
{
  "project": {
    "description": "...",
    "conventions": "...",
    "architecture": "...",
    "test_patterns": "..."
  },
  "modules": {
    "path/to/module.py": {
      "purpose": "...",
      "test_files": [...],
      "imports_from": [...],
      "imported_by": [...],
      "related_files": [...],
      "notes": "..."
    }
  }
}
```

## Guidelines

1. **Preserve unchanged context** - Keep existing module context for files that haven't changed
2. **Update changed modules** - Revise context for modified files based on new content
3. **Add new modules** - Create context entries for newly added files
4. **Remove deleted modules** - Remove context entries for deleted files
5. **Update relationships** - If imports changed, update `imports_from` and `imported_by` across affected modules
6. **Update project-level context** - If the changes affect overall architecture or conventions, update those too

Respond ONLY with the complete updated JSON object, no additional text.
