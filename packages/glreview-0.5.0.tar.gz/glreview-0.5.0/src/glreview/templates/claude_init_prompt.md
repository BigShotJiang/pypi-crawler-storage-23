You are analyzing a software project to build context that will help with future code reviews. Your task is to understand the project structure, conventions, and relationships between modules.

## Project Information

**Root:** `{{ root }}`
**Total Modules:** {{ module_count }}

## All Source Modules

{% for path in module_paths %}
- `{{ path }}`
{% endfor %}

## All Other Files (tests, configs, docs, etc.)

{% for path in other_files %}
- `{{ path }}`
{% endfor %}

## Sample Source Code

Below are samples from key modules to help you understand the project's style and patterns.

{% for sample in samples %}
### {{ sample.path }}

```python
{{ sample.content }}
```

{% endfor %}

## Your Task

Analyze this project and produce a JSON response with the following structure:

```json
{
  "project": {
    "description": "Brief description of what this project does (1-2 sentences)",
    "conventions": "Key coding conventions observed (naming, structure, patterns used)",
    "architecture": "High-level architecture description (layers, main components, data flow)",
    "test_patterns": "How tests are organized and named in this project"
  },
  "modules": {
    "path/to/module.py": {
      "purpose": "What this module does (1 sentence)",
      "test_files": ["path/to/test_file.py"],
      "imports_from": ["path/to/other_module.py"],
      "imported_by": ["path/to/dependent.py"],
      "related_files": ["path/to/config.py", "docs/module.md"],
      "notes": "Any special considerations for reviewing this module"
    }
  }
}
```

## Guidelines

1. **Be accurate** - Only include relationships you can verify from the code samples and file names
2. **Be concise** - Keep descriptions brief and actionable
3. **Focus on review value** - What would help a reviewer understand this module?
4. **Test file matching** - Use your judgment to match test files to modules even if naming isn't exact
5. **Import relationships** - Note which project modules import from each other (not external packages)
6. **Related files** - Include configs, docs, or other files that are relevant to understanding a module

For modules you don't have sample code for, infer what you can from:
- File names and paths
- Import statements in other modules
- Test file names
- Project structure patterns

Respond ONLY with the JSON object, no additional text.
