"""Adapters for loading recordings from different formats."""

from openadapt_ml.segmentation.adapters.capture_adapter import CaptureAdapter

__all__ = ["CaptureAdapter"]
