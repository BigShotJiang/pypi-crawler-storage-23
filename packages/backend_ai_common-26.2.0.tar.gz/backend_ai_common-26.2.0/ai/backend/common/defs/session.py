from typing import Final

SESSION_PRIORITY_DEFAULT: Final[int] = 10
SESSION_PRIORITY_MIN: Final[int] = 0
SESSION_PRIORITY_MAX: Final[int] = 100
