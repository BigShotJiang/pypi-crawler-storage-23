from .abc.queue import AbstractMessageQueue

__all__ = ("AbstractMessageQueue",)
