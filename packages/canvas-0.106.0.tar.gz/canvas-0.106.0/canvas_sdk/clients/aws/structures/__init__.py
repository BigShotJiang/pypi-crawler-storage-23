from canvas_sdk.clients.aws.structures.credentials import Credentials
from canvas_sdk.clients.aws.structures.s3_item import S3Item

__all__ = __exports__ = (
    "Credentials",
    "S3Item",
)
