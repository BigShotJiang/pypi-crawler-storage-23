"""
pypet - A command-line snippet manager inspired by pet
"""

__version__ = "0.4.0"
