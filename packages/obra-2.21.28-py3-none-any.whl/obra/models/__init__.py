"""Data models for Obra runtime state and metadata."""
