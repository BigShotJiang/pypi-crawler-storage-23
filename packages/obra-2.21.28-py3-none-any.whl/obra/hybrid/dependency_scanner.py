"""Dependency scanner implementing Step 1 (DETECT) of the resolution protocol."""

from __future__ import annotations

import json
import logging
import shutil
import tomllib
from datetime import datetime
from pathlib import Path
from typing import Any

from obra.hybrid.dependency_manifest import (
    BLOCKING_POLICY,
    DependencyEntry,
    DependencyManifest,
    EnvironmentDetail,
    normalize_ecosystem,
)
from obra.hybrid.dependency_verifier import DependencyVerifier
from obra.hybrid.install_target import InstallTargetManager

logger = logging.getLogger(__name__)

# Runtime identifiers — scoped to ecosystems with full scanner/verifier/command-builder support
RUNTIME_IDS: frozenset[str] = frozenset({
    "python",
    "python3",
    "node",
    "nodejs",
    "go",
    "rust",
    "cargo",
    "ruby",
})

# Schema version for cached manifest invalidation.
# Bump this integer whenever classification logic changes (RUNTIME_IDS,
# kind assignment rules, dedup policy, blocking policy).
SCANNER_SCHEMA_VERSION: int = 5

# Mapping from ecosystem to runtime binary for probe
_RUNTIME_BINARIES: dict[str, str] = {
    "python": "python3",
    "node": "node",
    "rust": "rustc",
    "go": "go",
    "ruby": "ruby",
}

# Manifest file names per ecosystem
_MANIFEST_FILES: dict[str, list[str]] = {
    "python": ["requirements.txt", "pyproject.toml", "Pipfile"],
    "node": ["package.json"],
    "rust": ["Cargo.toml"],
    "go": ["go.mod"],
    "ruby": ["Gemfile"],
}

_RUNTIME_SUFFIX_HINTS: tuple[str, ...] = (
    "_runtime",
    "_interpreter",
)
_RUNTIME_PREFIX_HINTS: tuple[str, ...] = (
    "runtime_",
    "interpreter_",
)


class DependencyScanner:
    """Scan project dependencies from multiple sources and build a manifest."""

    def __init__(
        self,
        working_dir: Path,
        config: dict[str, Any],
        install_target: InstallTargetManager,
    ) -> None:
        self._working_dir = Path(working_dir)
        self._config = config
        self._install_target = install_target
        self._story0_config = dict(config.get("story0", {}))
        self._depres_config = dict(
            self._story0_config.get("dependency_resolution", {})
        )

    def detect(
        self,
        prerequisites: list[dict[str, Any]],
    ) -> DependencyManifest:
        """Build a DependencyManifest from environment probes, LLM prereqs, and manifests."""
        # Step 1a: Detect toolchains and populate environment_info
        toolchains = self._install_target.detect_toolchain(self._working_dir)
        environment_info = self._build_environment_info(toolchains)
        ecosystems_detected = list(toolchains.keys())

        # Step 1b: Create venv if Python detected and no venv exists
        if "python" in toolchains or self._has_python_indicators():
            python_info = environment_info.get("python")
            if python_info is None or python_info.venv_path is None:
                self._create_python_environment(environment_info)
                # Re-read toolchains after environment creation
                toolchains = self._install_target.detect_toolchain(self._working_dir)
                environment_info = self._build_environment_info(toolchains)
                if "python" not in ecosystems_detected:
                    ecosystems_detected.append("python")

        # Step 1c: Create runtime entries from environment probes
        runtime_entries = self._build_runtime_entries(toolchains)

        # Step 1d: Scan LLM prerequisites (AUTO and AUTO_CONFIRM only)
        llm_entries = self._scan_llm_prerequisites(prerequisites)

        # Step 1e: Scan manifest files
        manifest_entries = self._scan_manifests()

        # Step 1f: Deduplicate
        merged = self._deduplicate(runtime_entries, llm_entries, manifest_entries)

        manifest = DependencyManifest(
            entries=merged,
            scan_timestamp=datetime.now().isoformat(),
            working_dir=str(self._working_dir),
            ecosystems_detected=ecosystems_detected,
            environment_info=environment_info,
            scanner_schema_version=SCANNER_SCHEMA_VERSION,
        )

        # Step 1g: Pre-verify to detect already-installed packages
        self._pre_verify(manifest)

        # Step 1h: Propose install commands (after verification so status is known)
        self._propose_commands(merged, environment_info)

        return manifest

    def _pre_verify(self, manifest: DependencyManifest) -> None:
        """Run verifier probes on 'unknown' entries to detect already-installed packages.

        This avoids prompting the user to install packages that are already present.
        Entries whose status is not 'unknown' (e.g. runtime entries already marked
        'installed' or 'missing' from toolchain detection) are left untouched.
        """
        verifier = DependencyVerifier()
        for entry in manifest.entries:
            if entry.status != "unknown":
                continue
            try:
                verifier.verify_entry(entry, manifest)
            except Exception:
                logger.debug(
                    "Pre-verify probe failed for %s/%s: %s — keeping 'unknown'",
                    entry.ecosystem,
                    entry.kind,
                    entry.name,
                    exc_info=True,
                )

    def _build_environment_info(
        self,
        toolchains: dict[str, Any],
    ) -> dict[str, EnvironmentDetail]:
        """Convert toolchain detection results to EnvironmentDetail map."""
        info: dict[str, EnvironmentDetail] = {}
        for eco, tc in toolchains.items():
            info[eco] = EnvironmentDetail(
                venv_path=str(tc.env_path) if tc.env_path else None,
                created_by=tc.manager if tc.env_path else None,
                manager=tc.manager,
            )
        return info

    def _has_python_indicators(self) -> bool:
        """Check if the project has Python indicators without existing venv."""
        python_files = ["pyproject.toml", "requirements.txt", "setup.py", "Pipfile"]
        return any((self._working_dir / f).exists() for f in python_files)

    def _create_python_environment(
        self,
        environment_info: dict[str, EnvironmentDetail],
    ) -> None:
        """Create a Python virtual environment using InstallTargetManager."""
        policy = self._depres_config.get(
            "env_creation",
            self._story0_config.get("env_creation", "when_missing"),
        )
        manager_preference = (
            self._story0_config.get("package_manager_preference", {})
            .get("python", "auto")
        )
        try:
            env_path = self._install_target.create_environment(
                ecosystem="python",
                working_dir=self._working_dir,
                policy=policy,
                manager_preference=manager_preference,
            )
            if env_path:
                created_by = "uv" if manager_preference == "uv" else None
                if manager_preference == "auto":
                    created_by = "uv" if shutil.which("uv") else "venv"
                environment_info["python"] = EnvironmentDetail(
                    venv_path=str(env_path),
                    created_by=created_by,
                    manager=created_by,
                )
        except Exception:
            logger.warning(
                "Failed to create Python environment in %s",
                self._working_dir,
                exc_info=True,
            )

    def _build_runtime_entries(
        self,
        toolchains: dict[str, Any],
    ) -> list[DependencyEntry]:
        """Create runtime entries from detected toolchains."""
        entries: list[DependencyEntry] = []
        for eco, tc in toolchains.items():
            binary = _RUNTIME_BINARIES.get(eco)
            if binary:
                found = shutil.which(binary)
                status = "installed" if found else "missing"
            else:
                status = "unknown"

            entries.append(DependencyEntry(
                dependency_id=DependencyEntry.compute_id(eco, eco),
                name=eco,
                ecosystem=eco,
                kind="runtime",
                status=status,
                proposed_command=None,
                override_command=None,
                requires_elevation=False,
                source="scan",
                blocking=BLOCKING_POLICY.get("runtime", True),
                detail=f"Runtime detected via toolchain scan (binary: {binary})",
                version_constraint=None,
                install_key=eco,
                verify_key=eco,
                attempt_budget=int(
                    self._depres_config.get("max_attempts_per_dependency", 3)
                ),
            ))
        return entries

    def _scan_llm_prerequisites(
        self,
        prerequisites: list[dict[str, Any]],
    ) -> list[DependencyEntry]:
        """Convert AUTO/AUTO_CONFIRM LLM prerequisites to DependencyEntry list."""
        entries: list[DependencyEntry] = []
        auto_categories = {"AUTO", "AUTO_CONFIRM"}
        runtime_hints: set[str] = set()
        explicit_ecosystem_hints: set[str] = set()

        # Build ecosystem hints first so package entries with missing ecosystem can
        # still be resolved when runtime prerequisites are present in the same batch.
        for prereq in prerequisites:
            category = str(prereq.get("category", "")).upper()
            if category not in auto_categories:
                continue

            prereq_id = str(prereq.get("id", "")).strip().lower()
            prereq_name = str(prereq.get("name", "")).strip()
            runtime_name = self._resolve_runtime_name(prereq_id, prereq_name)
            if runtime_name is not None:
                runtime_ecosystem = normalize_ecosystem(runtime_name)
                if runtime_ecosystem != "unknown":
                    runtime_hints.add(runtime_ecosystem)

            explicit_ecosystem = normalize_ecosystem(prereq.get("ecosystem"))
            if explicit_ecosystem != "unknown":
                explicit_ecosystem_hints.add(explicit_ecosystem)

        default_package_ecosystem = self._resolve_default_package_ecosystem(
            runtime_hints,
            explicit_ecosystem_hints,
        )

        for prereq in prerequisites:
            category = str(prereq.get("category", "")).upper()
            if category not in auto_categories:
                continue

            raw_name = str(prereq.get("name", "")).strip()
            if not raw_name:
                continue

            normalized_name = self._install_target.normalize_inferred_package_name(
                raw_name
            )
            if not normalized_name:
                continue

            ecosystem = normalize_ecosystem(prereq.get("ecosystem"))

            # Determine kind: runtime if matches known runtime IDs.
            # Check prereq["id"] first — LLMs often set id="python" but
            # name="Python runtime" which normalize_inferred_package_name
            # preserves with spaces (no match in RUNTIME_IDS).
            prereq_id = str(prereq.get("id", "")).strip().lower()
            if (
                prereq_id
                and " " in normalized_name
                and self._is_identifier_like(prereq_id)
            ):
                # Prefer stable machine ids over descriptive labels for package names.
                normalized_name = prereq_id

            kind = "package"
            runtime_name = self._resolve_runtime_name(prereq_id, normalized_name)
            if runtime_name is not None:
                kind = "runtime"
                normalized_name = runtime_name  # Canonical runtime name for dedup

            # Runtime entries must carry a canonical ecosystem so verifier probes
            # route correctly across all supported stacks (python/node/go/rust/ruby).
            if kind == "runtime" and ecosystem == "unknown":
                runtime_ecosystem = normalize_ecosystem(normalized_name)
                if runtime_ecosystem == "unknown" and prereq_id:
                    runtime_ecosystem = normalize_ecosystem(prereq_id)
                ecosystem = runtime_ecosystem
            elif kind == "package" and ecosystem == "unknown":
                ecosystem = self._infer_package_ecosystem(
                    prereq_id=prereq_id,
                    normalized_name=normalized_name,
                    default_ecosystem=default_package_ecosystem,
                )

            # System-ecosystem entries are OS-level tools, not language packages.
            if ecosystem == "system":
                kind = "tool"

            # Compute identity keys for the install mission engine
            install_key = self._install_target.normalize_inferred_package_name(
                raw_name
            ) or normalized_name.lower().strip()
            verify_key = self._compute_verify_key(normalized_name, ecosystem)

            entries.append(DependencyEntry(
                dependency_id=DependencyEntry.compute_id(normalized_name, ecosystem),
                name=normalized_name,
                ecosystem=ecosystem,
                kind=kind,
                status="unknown",
                proposed_command=None,
                override_command=None,
                requires_elevation=False,
                source="llm_inferred",
                blocking=BLOCKING_POLICY.get(kind, False),
                detail=prereq.get("reason", ""),
                version_constraint=None,
                install_key=install_key,
                verify_key=verify_key,
                attempt_budget=int(
                    self._depres_config.get("max_attempts_per_dependency", 3)
                ),
            ))
        return entries

    @staticmethod
    def _is_identifier_like(value: str) -> bool:
        """Return True when value looks like a stable dependency identifier."""
        stripped = value.replace("-", "").replace("_", "").replace(".", "")
        return bool(stripped) and stripped.isalnum()

    @staticmethod
    def _resolve_default_package_ecosystem(
        runtime_hints: set[str],
        explicit_ecosystem_hints: set[str],
    ) -> str | None:
        """Return an unambiguous default package ecosystem, if any."""
        candidates = {
            ecosystem
            for ecosystem in runtime_hints.union(explicit_ecosystem_hints)
            if ecosystem in _MANIFEST_FILES
        }
        if len(candidates) == 1:
            return next(iter(candidates))
        return None

    @staticmethod
    def _infer_package_ecosystem(
        prereq_id: str,
        normalized_name: str,
        default_ecosystem: str | None,
    ) -> str:
        """Infer package ecosystem for entries where LLM omitted ecosystem."""
        for candidate in (prereq_id, normalized_name):
            inferred = normalize_ecosystem(candidate)
            if inferred != "unknown":
                return inferred
        return default_ecosystem or "unknown"

    @classmethod
    def _resolve_runtime_name(
        cls,
        prereq_id: str,
        normalized_name: str,
    ) -> str | None:
        """Resolve runtime prerequisites to canonical ecosystem runtime names."""
        for candidate in (prereq_id, normalized_name):
            alias = cls._parse_runtime_alias(candidate)
            if alias is not None:
                return alias
        return None

    @staticmethod
    def _parse_runtime_alias(raw: str) -> str | None:
        """Parse a runtime-like string to canonical ecosystem alias."""
        if not raw:
            return None
        cleaned = raw.strip().lower()
        if not cleaned:
            return None
        canonical = normalize_ecosystem(cleaned)
        if canonical != "unknown":
            return canonical

        if cleaned in RUNTIME_IDS:
            # Keep explicit runtime ids (e.g. cargo) as runtime markers even if
            # no ecosystem alias is currently defined for them.
            return cleaned

        normalized = cleaned.replace("-", "_").replace(" ", "_")
        canonical = normalize_ecosystem(normalized)
        if canonical != "unknown":
            return canonical

        for suffix in _RUNTIME_SUFFIX_HINTS:
            if normalized.endswith(suffix):
                canonical = normalize_ecosystem(normalized[: -len(suffix)])
                if canonical != "unknown":
                    return canonical

        for prefix in _RUNTIME_PREFIX_HINTS:
            if normalized.startswith(prefix):
                canonical = normalize_ecosystem(normalized[len(prefix):])
                if canonical != "unknown":
                    return canonical
        return None

    @staticmethod
    def _compute_verify_key(name: str, ecosystem: str) -> str:
        """Compute the canonical verification key for a dependency.

        For Python packages, converts hyphens to underscores for import compatibility.
        For Node packages, uses the package name as-is.
        For others, lowercases the name.
        """
        if ecosystem == "python":
            return name.lower().replace("-", "_")
        if ecosystem == "node":
            return name
        return name.lower()

    def _scan_manifests(self) -> list[DependencyEntry]:
        """Parse manifest files and create entries for discovered packages."""
        entries: list[DependencyEntry] = []
        for ecosystem, filenames in _MANIFEST_FILES.items():
            for filename in filenames:
                path = self._working_dir / filename
                if not path.exists():
                    continue
                try:
                    parsed = self._parse_manifest(path, ecosystem)
                    entries.extend(parsed)
                except Exception:
                    logger.warning(
                        "Failed to parse manifest %s for %s ecosystem",
                        path,
                        ecosystem,
                        exc_info=True,
                    )
        return entries

    def _parse_manifest(
        self,
        path: Path,
        ecosystem: str,
    ) -> list[DependencyEntry]:
        """Parse a single manifest file into DependencyEntry list."""
        if path.name == "requirements.txt":
            return self._parse_requirements_txt(path, ecosystem)
        if path.name == "pyproject.toml":
            return self._parse_pyproject_toml(path, ecosystem)
        if path.name == "package.json":
            return self._parse_package_json(path, ecosystem)
        if path.name == "Cargo.toml":
            return self._parse_cargo_toml(path, ecosystem)
        if path.name == "go.mod":
            return self._parse_go_mod(path, ecosystem)
        if path.name == "Gemfile":
            return self._parse_gemfile(path, ecosystem)
        if path.name == "Pipfile":
            return self._parse_pipfile(path, ecosystem)
        return []

    def _make_manifest_entry(
        self,
        name: str,
        ecosystem: str,
        version_constraint: str | None = None,
    ) -> DependencyEntry:
        """Helper to create a manifest-sourced DependencyEntry."""
        return DependencyEntry(
            dependency_id=DependencyEntry.compute_id(name, ecosystem),
            name=name,
            ecosystem=ecosystem,
            kind="package",
            status="unknown",
            proposed_command=None,
            override_command=None,
            requires_elevation=False,
            source="manifest",
            blocking=BLOCKING_POLICY.get("package", False),
            detail="From manifest",
            version_constraint=version_constraint,
            install_key=name,
            verify_key=self._compute_verify_key(name, ecosystem),
            attempt_budget=int(
                self._depres_config.get("max_attempts_per_dependency", 3)
            ),
        )

    def _parse_requirements_txt(
        self,
        path: Path,
        ecosystem: str,
    ) -> list[DependencyEntry]:
        entries: list[DependencyEntry] = []
        content = path.read_text(encoding="utf-8")
        for line in content.splitlines():
            line = line.strip()
            if not line or line.startswith("#") or line.startswith("-"):
                continue
            # Strip version specifiers
            name = self._install_target.normalize_inferred_package_name(line)
            if name:
                # Extract version constraint from original line
                version = None
                for token in ["==", ">=", "<=", "~=", "!=", ">", "<"]:
                    if token in line:
                        version = line[line.index(token):]
                        break
                entries.append(self._make_manifest_entry(name, ecosystem, version))
        return entries

    def _parse_pyproject_toml(
        self,
        path: Path,
        ecosystem: str,
    ) -> list[DependencyEntry]:
        entries: list[DependencyEntry] = []
        content = path.read_bytes()
        data = tomllib.loads(content.decode("utf-8"))
        # PEP 621 dependencies
        deps = data.get("project", {}).get("dependencies", [])
        for dep in deps:
            name = self._install_target.normalize_inferred_package_name(str(dep))
            if name:
                entries.append(self._make_manifest_entry(name, ecosystem))
        # Optional dependencies
        optional = data.get("project", {}).get("optional-dependencies", {})
        for group_deps in optional.values():
            for dep in group_deps:
                name = self._install_target.normalize_inferred_package_name(str(dep))
                if name:
                    entries.append(self._make_manifest_entry(name, ecosystem))
        return entries

    def _parse_package_json(
        self,
        path: Path,
        ecosystem: str,
    ) -> list[DependencyEntry]:
        entries: list[DependencyEntry] = []
        data = json.loads(path.read_text(encoding="utf-8"))
        for section in ["dependencies", "devDependencies"]:
            deps = data.get(section, {})
            for name, version in deps.items():
                entries.append(
                    self._make_manifest_entry(name, ecosystem, str(version))
                )
        return entries

    def _parse_cargo_toml(
        self,
        path: Path,
        ecosystem: str,
    ) -> list[DependencyEntry]:
        entries: list[DependencyEntry] = []
        content = path.read_bytes()
        data = tomllib.loads(content.decode("utf-8"))
        for section in ["dependencies", "dev-dependencies"]:
            deps = data.get(section, {})
            for name, spec in deps.items():
                version = None
                if isinstance(spec, str):
                    version = spec
                elif isinstance(spec, dict):
                    version = spec.get("version")
                entries.append(self._make_manifest_entry(name, ecosystem, version))
        return entries

    def _parse_go_mod(
        self,
        path: Path,
        ecosystem: str,
    ) -> list[DependencyEntry]:
        entries: list[DependencyEntry] = []
        content = path.read_text(encoding="utf-8")
        in_require = False
        for line in content.splitlines():
            stripped = line.strip()
            if stripped.startswith("require ("):
                in_require = True
                continue
            if in_require and stripped == ")":
                in_require = False
                continue
            if in_require and stripped:
                parts = stripped.split()
                if parts:
                    name = parts[0]
                    version = parts[1] if len(parts) > 1 else None
                    entries.append(
                        self._make_manifest_entry(name, ecosystem, version)
                    )
        return entries

    def _parse_gemfile(
        self,
        path: Path,
        ecosystem: str,
    ) -> list[DependencyEntry]:
        entries: list[DependencyEntry] = []
        content = path.read_text(encoding="utf-8")
        for line in content.splitlines():
            stripped = line.strip()
            if not stripped.startswith("gem "):
                continue
            # Extract gem name from: gem 'name' or gem "name"
            parts = stripped[4:].strip().split(",")
            if parts:
                name = parts[0].strip().strip("'\"")
                version = parts[1].strip().strip("'\" ") if len(parts) > 1 else None
                entries.append(self._make_manifest_entry(name, ecosystem, version))
        return entries

    def _parse_pipfile(
        self,
        path: Path,
        ecosystem: str,
    ) -> list[DependencyEntry]:
        entries: list[DependencyEntry] = []
        content = path.read_text(encoding="utf-8")
        in_packages = False
        for line in content.splitlines():
            stripped = line.strip()
            if stripped in ("[packages]", "[dev-packages]"):
                in_packages = True
                continue
            if stripped.startswith("["):
                in_packages = False
                continue
            if in_packages and "=" in stripped:
                name = stripped.split("=")[0].strip()
                if name:
                    entries.append(self._make_manifest_entry(name, ecosystem))
        return entries

    def _deduplicate(
        self,
        runtime_entries: list[DependencyEntry],
        llm_entries: list[DependencyEntry],
        manifest_entries: list[DependencyEntry],
    ) -> list[DependencyEntry]:
        """Merge entries from all sources, deduplicating by dependency_id."""
        by_id: dict[str, DependencyEntry] = {}

        # Runtime entries first (highest priority — have verified status)
        for entry in runtime_entries:
            by_id[entry.dependency_id] = entry

        # Manifest entries next
        for entry in manifest_entries:
            if entry.dependency_id not in by_id:
                by_id[entry.dependency_id] = entry

        # LLM entries last — merge with existing if overlap
        for entry in llm_entries:
            if entry.dependency_id in by_id:
                existing = by_id[entry.dependency_id]
                # Check if it's a runtime entry from probe — keep probe entry
                if existing.source == "scan":
                    continue
                # Merge manifest + LLM
                if existing.source == "manifest":
                    existing.source = "manifest+llm_inferred"
                    # Manifest version constraint wins
            else:
                by_id[entry.dependency_id] = entry

        return list(by_id.values())

    def _propose_commands(
        self,
        entries: list[DependencyEntry],
        environment_info: dict[str, EnvironmentDetail],
    ) -> None:
        """Set proposed_command on each entry using InstallTargetManager."""
        for entry in entries:
            # Skip entries already verified as present
            if entry.status == "installed":
                continue
            # Skip entries not suitable for auto-install via package manager
            if entry.kind in ("runtime", "service", "tool"):
                continue

            eco_info = environment_info.get(entry.ecosystem)
            env_path = Path(eco_info.venv_path) if eco_info and eco_info.venv_path else None
            manager = eco_info.manager if eco_info else "auto"

            if manager == "auto" or manager is None:
                manager = self._install_target.get_package_manager(
                    entry.ecosystem,
                    "auto",
                    self._working_dir,
                )

            target = self._story0_config.get("install_target", "project_local")

            try:
                command = self._install_target.build_install_command(
                    ecosystem=entry.ecosystem,
                    packages=[entry.name],
                    target=target,
                    manager=manager,
                    env_path=env_path,
                )
            except Exception:
                logger.warning(
                    "Failed to build install command for %s",
                    entry.name,
                    exc_info=True,
                )
                entry.detail = "Failed to build install command"
                continue

            if self._depres_config.get("verify_executables", True):
                is_ok, detail = self._install_target.verify_command_executable(command)
                if not is_ok:
                    entry.proposed_command = None
                    entry.detail = detail
                    continue

            entry.proposed_command = command
