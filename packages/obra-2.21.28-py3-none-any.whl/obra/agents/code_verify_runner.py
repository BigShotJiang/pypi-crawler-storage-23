"""CodeVerify verification runner using template-edit pipeline execution."""

from __future__ import annotations

import json
import logging
import re
from collections.abc import Callable
from pathlib import Path
from typing import Any

from obra.hybrid.template_edit_pipeline import TemplateEditPipeline
from obra.llm.subprocess_runner import LLMSubprocessConfig, run_llm_subprocess

logger = logging.getLogger(__name__)

_DEFAULT_ALLOWED_TOOLS = ["Read", "Grep", "Glob"]
_VALID_DISPOSITIONS = {"VERIFIED", "HAS_GAPS", "WILL_FAIL"}


class VerificationSessionRunner:
    """Run a single CodeVerify verification session."""

    def __init__(
        self,
        working_dir: Path,
        llm_config: dict[str, Any],
        log_event: Callable[..., None] | None = None,
        trace_id: str | None = None,
    ) -> None:
        self._working_dir = working_dir
        self._llm_config = dict(llm_config or {})
        self._log_event = log_event
        self._trace_id = trace_id

    def run_session(
        self,
        prompt: str,
        timeout_s: int,
        allowed_tools: list[str] | None = None,
    ) -> dict[str, Any]:
        """Run a verification pass with read-only tools.

        Parameter Contracts (ADR-042):
            - prompt: non-empty string
            - timeout_s: positive integer

        Primary path uses TemplateEditPipeline. If template-edit execution fails,
        a degraded subprocess path is used with JSON extraction from stdout.
        """
        resolved_tools = (
            list(allowed_tools) if allowed_tools is not None else list(_DEFAULT_ALLOWED_TOOLS)
        )
        enriched_llm_config = {
            **self._llm_config,
            "allowed_tools": resolved_tools,
            "mode": "execute",
        }

        pipeline = TemplateEditPipeline(
            working_dir=self._working_dir,
            action_name="code_verify",
            log_event=self._log_event,
        )
        template_content = {
            "disposition": "",
            "findings": [],
            "verification_summary": {},
            "_instructions": "Populate this template with your verification results.",
        }

        def validator(data: dict | str) -> tuple[bool, str | None]:
            if not isinstance(data, dict):
                return False, "Template result must be a JSON object"
            required_keys = {"disposition", "findings", "verification_summary"}
            missing = sorted(required_keys - set(data.keys()))
            if missing:
                return False, f"Missing required keys: {', '.join(missing)}"
            if data.get("disposition") not in _VALID_DISPOSITIONS:
                return False, "Invalid disposition"
            if not isinstance(data.get("findings"), list):
                return False, "findings must be a list"
            if not isinstance(data.get("verification_summary"), dict):
                return False, "verification_summary must be an object"
            return True, None

        def fallback_fn() -> dict[str, Any]:
            return {
                "disposition": "HAS_GAPS",
                "findings": [],
                "verification_summary": {},
            }

        try:
            result, _meta = pipeline.execute(
                base_prompt=prompt,
                template_content=template_content,
                validator=validator,
                fallback_fn=fallback_fn,
                llm_config=enriched_llm_config,
                timeout_s=timeout_s,
            )
            return self._normalize_result(result)
        except Exception as exc:
            self._emit_log_event(
                "code_verify_runner_degraded",
                warning=str(exc),
                trace_id=self._trace_id,
            )
            logger.warning(
                "TemplateEditPipeline failed for code_verify; using degraded subprocess path: %s",
                exc,
            )
            return self._run_degraded(prompt, timeout_s, resolved_tools)

    def _run_degraded(
        self,
        prompt: str,
        timeout_s: int,
        allowed_tools: list[str],
    ) -> dict[str, Any]:
        reasoning_level = str(
            self._llm_config.get("reasoning_level", "off")
        )
        auth_method = str(self._llm_config.get("auth", self._llm_config.get("auth_method", "oauth")))

        config = LLMSubprocessConfig(
            prompt=prompt,
            cwd=self._working_dir,
            provider=str(self._llm_config.get("provider", "anthropic")),
            model=str(self._llm_config.get("model", "default")),
            reasoning_level=reasoning_level,
            auth_method=auth_method,
            timeout_s=timeout_s,
            mode="execute",
            response_format="text",
            trace_id=self._trace_id,
            log_event=self._log_event,
            allowed_tools=allowed_tools,
        )
        result = run_llm_subprocess(config)

        if not result.success:
            error_text = result.error or "Verification subprocess failed"
            status = "timeout" if "timed out" in error_text.lower() else "error"
            return {
                "status": status,
                "error": error_text,
                "disposition": "HAS_GAPS",
                "findings": [],
                "verification_summary": {},
            }

        payload = self._extract_json_payload(result.output)
        if payload is None:
            return {
                "status": "error",
                "error": "Failed to parse verification JSON from subprocess output",
                "disposition": "HAS_GAPS",
                "findings": [],
                "verification_summary": {},
            }

        return self._normalize_result(payload)

    def _extract_json_payload(self, text: str) -> dict[str, Any] | None:
        stripped = text.strip()
        if not stripped:
            return None

        try:
            data = json.loads(stripped)
            return data if isinstance(data, dict) else None
        except json.JSONDecodeError:
            pass

        match = re.search(r"\{[\s\S]*\}", stripped)
        if not match:
            return None

        try:
            data = json.loads(match.group(0))
            return data if isinstance(data, dict) else None
        except json.JSONDecodeError:
            return None

    def _normalize_result(self, payload: Any) -> dict[str, Any]:
        if not isinstance(payload, dict):
            return {
                "status": "error",
                "error": "Verification payload is not a JSON object",
                "disposition": "HAS_GAPS",
                "findings": [],
                "verification_summary": {},
            }

        normalized = {
            "disposition": payload.get("disposition", "HAS_GAPS"),
            "findings": payload.get("findings", []),
            "verification_summary": payload.get("verification_summary", {}),
        }
        if normalized["disposition"] not in _VALID_DISPOSITIONS:
            normalized["disposition"] = "HAS_GAPS"
        if not isinstance(normalized["findings"], list):
            normalized["findings"] = []
        if not isinstance(normalized["verification_summary"], dict):
            normalized["verification_summary"] = {}
        return normalized

    def _emit_log_event(self, event: str, **kwargs: Any) -> None:
        if self._log_event is None:
            return
        try:
            self._log_event(event, **kwargs)
        except Exception:
            logger.debug("code_verify runner log_event callback failed", exc_info=True)
