"""Pipeline visualization for Obra console output.

This module provides a visual pipeline banner that shows users their position
in the Obra orchestration workflow, with positioned sub-stages under the
active stage.

Pipeline Stages:
    Enrich → Plan → Setup → Execute → Review → Fix

Visual States:
    [ STAGE ]  - Currently active stage
    ✓ Stage    - Completed stage
    Stage      - Pending stage

Example Output:
    ═══════════════════════════════════════════════════════════════
      ✓ Enrich  ·  [ PLAN ]  ·  Execute  ·  Review  ·  Fix
                       │
                       ├─ ✓ derive
                       ├─ ▶ examine
                       └─   revise
    ═══════════════════════════════════════════════════════════════
"""

from dataclasses import dataclass, field
from enum import Enum

from rich.console import Console

from obra.display.charset import get_unicode_support


class StageState(Enum):
    """State of a pipeline stage or sub-stage."""

    PENDING = "pending"
    ACTIVE = "active"
    COMPLETED = "completed"


@dataclass
class PipelineStage:
    """Definition of a pipeline stage with optional sub-stages."""

    name: str
    substages: list[str] = field(default_factory=list)


# Pipeline definition matching Obra orchestration workflow
PIPELINE_STAGES: list[PipelineStage] = [
    PipelineStage("Enrich", ["assumptions", "analogues", "brief"]),
    PipelineStage("Plan", ["derive", "examine", "revise"]),
    PipelineStage("Setup", ["dependencies", "prerequisites"]),
    PipelineStage("Execute", []),  # Single stage, no tree needed
    PipelineStage("Review", []),  # Single stage
    PipelineStage("Fix", []),  # Iterative, shown differently
]

# Map internal stage/action names to pipeline stages
STAGE_TO_PIPELINE: dict[str, str] = {
    # Enrich sub-stages
    "assumptions": "Enrich",
    "analogues": "Enrich",
    "brief": "Enrich",
    # Plan sub-stages
    "derive": "Plan",
    "examine": "Plan",
    "revise": "Plan",
    # Setup sub-stages
    "dependencies": "Setup",
    "prerequisites": "Setup",
    # Other stages
    "execute": "Execute",
    "review": "Review",
    "fix": "Fix",
}

# Map internal phase names to pipeline stages
# Note: DERIVATION is intentionally not mapped here. The DERIVATION phase contains
# both enrichment (assumptions/analogues/brief) and planning (derive/examine/revise).
# Stage-level events via planning_stage_started() handle the Enrich→Plan transition
# correctly. Mapping DERIVATION→Plan here would trigger Plan banner before Enrich runs.
# STORY0 maps to Setup for the environment preparation phase (dependency scanning,
# prerequisite installation).
PHASE_TO_PIPELINE: dict[str, str] = {
    "USERPLAN_GENERATION": "Enrich",
    "REFINEMENT": "Plan",
    "STORY0": "Setup",
    "EXECUTION": "Execute",
    "REVIEW": "Review",
}

# Visual constants
BANNER_WIDTH = 63
SEPARATOR = "  ·  "


class PipelineRenderer:
    """Renders pipeline banner with positioned sub-stages.

    This class maintains state about completed stages and sub-stages,
    and renders a visual pipeline banner showing the current position
    in the Obra orchestration workflow.
    """

    # Derive step names for display
    DERIVE_STEPS = [
        ("1/3", "identify epics"),
        ("2/3", "expand stories"),
        ("3/3", "serialize"),
    ]

    def __init__(self, console: Console) -> None:
        """Initialize the pipeline renderer.

        Args:
            console: Rich Console instance for output
        """
        self._console = console
        self._completed_stages: set[str] = set()
        self._completed_substages: set[str] = set()
        self._current_stage: str | None = None
        self._current_substage: str | None = None
        self._last_rendered_stage: str | None = None
        # Derive substep tracking (1-indexed: 1, 2, 3)
        self._derive_current_step: int | None = None
        self._derive_completed_steps: set[int] = set()

    def _get_glyphs(self) -> dict[str, str]:
        """Get appropriate glyphs based on terminal Unicode support."""
        if get_unicode_support():
            return {
                "banner_char": "═",
                "check": "✓",
                "arrow": "▶",
                "vline": "│",
                "branch": "├─",
                "corner": "└─",
                "dot": "·",
            }
        return {
            "banner_char": "=",
            "check": "[ok]",
            "arrow": ">",
            "vline": "|",
            "branch": "|--",
            "corner": "`--",
            "dot": "-",
        }

    def render_banner(
        self,
        active_stage: str,
        active_substage: str | None = None,
        iteration: int | None = None,
        max_iterations: int | None = None,
    ) -> None:
        """Render full pipeline banner with sub-stages if applicable.

        Args:
            active_stage: Currently active pipeline stage name
            active_substage: Currently active sub-stage (if any)
            iteration: Current iteration number (for Review/Fix cycles)
            max_iterations: Maximum iterations (for Review/Fix cycles)
        """
        glyphs = self._get_glyphs()

        # Build pipeline line and get offset to active stage
        pipeline_line, stage_offset = self._build_pipeline_line(active_stage)

        # Get stage configuration
        stage_config = self._get_stage_config(active_stage)

        # Render banner
        self._print(glyphs["banner_char"] * BANNER_WIDTH)
        self._print(pipeline_line)

        # Render sub-stages if this stage has them
        if stage_config and stage_config.substages:
            self._render_substage_tree(
                stage_config.substages,
                stage_offset,
                active_substage,
            )
        elif iteration is not None:
            # Show iteration indicator for Review/Fix cycles
            self._render_iteration_indicator(stage_offset, iteration, max_iterations)

        self._print(glyphs["banner_char"] * BANNER_WIDTH)
        self._last_rendered_stage = active_stage

    def _build_pipeline_line(self, active_stage: str) -> tuple[str, int]:
        """Build pipeline line and calculate offset to active stage.

        Args:
            active_stage: Currently active stage name

        Returns:
            Tuple of (formatted pipeline line, character offset to active stage center)
        """
        glyphs = self._get_glyphs()
        parts: list[str] = []
        active_offset = 0
        current_pos = 2  # Initial indent "  "

        for i, stage in enumerate(PIPELINE_STAGES):
            stage_name = stage.name

            if stage_name.lower() == active_stage.lower():
                # Active stage - record offset to center of stage name
                formatted = f"[ {stage_name.upper()} ]"
                # Offset points to under the stage name (after "[ ")
                active_offset = current_pos + 2 + len(stage_name) // 2
            elif stage_name.lower() in self._completed_stages:
                formatted = f"{glyphs['check']} {stage_name}"
            else:
                formatted = stage_name

            parts.append(formatted)
            current_pos += len(formatted)

            if i < len(PIPELINE_STAGES) - 1:
                current_pos += len(SEPARATOR)

        line = "  " + SEPARATOR.join(parts)
        return line, active_offset

    def _render_substage_tree(
        self,
        substages: list[str],
        offset: int,
        active_substage: str | None,
    ) -> None:
        """Render sub-stage tree positioned under active stage.

        Args:
            substages: List of sub-stage names
            offset: Character offset for positioning
            active_substage: Currently active sub-stage (if any)
        """
        glyphs = self._get_glyphs()
        prefix = " " * offset

        # Vertical connector from stage
        self._print(f"{prefix}{glyphs['vline']}")

        for i, substage in enumerate(substages):
            is_last = i == len(substages) - 1
            connector = glyphs["corner"] if is_last else glyphs["branch"]

            if substage.lower() in self._completed_substages:
                indicator = glyphs["check"]
            elif active_substage and substage.lower() == active_substage.lower():
                indicator = glyphs["arrow"]
            else:
                indicator = " "

            # Pad indicator to consistent width (for alignment)
            indicator_padded = f"{indicator} " if len(indicator) == 1 else f"{indicator}"
            self._print(f"{prefix}{connector} {indicator_padded}{substage}")

            # Show derive substeps if this is derive and we have step tracking active
            is_derive_active = (
                substage.lower() == "derive"
                and active_substage
                and active_substage.lower() == "derive"
                and (self._derive_current_step or self._derive_completed_steps)
            )
            if is_derive_active:
                self._render_derive_substeps(prefix, is_last)

    def _render_derive_substeps(self, base_prefix: str, derive_is_last: bool) -> None:
        """Render nested derive substeps (1/3, 2/3, 3/3).

        Args:
            base_prefix: Base prefix for alignment
            derive_is_last: Whether derive is the last substage (affects connector)
        """
        glyphs = self._get_glyphs()
        # If derive is not the last substage, we need a vertical line continuation
        # Otherwise just use spaces
        derive_continuation = " " if derive_is_last else glyphs["vline"]
        # Additional indent for nested items (after "├─ ▶ derive")
        nested_prefix = f"{base_prefix}{derive_continuation}     "

        for i, (step_num, step_desc) in enumerate(self.DERIVE_STEPS):
            step_idx = i + 1  # 1-indexed
            is_last = i == len(self.DERIVE_STEPS) - 1
            connector = glyphs["corner"] if is_last else glyphs["branch"]

            if step_idx in self._derive_completed_steps:
                indicator = glyphs["check"]
            elif self._derive_current_step == step_idx:
                indicator = glyphs["arrow"]
            else:
                indicator = " "

            indicator_padded = f"{indicator} " if len(indicator) == 1 else f"{indicator}"
            self._print(f"{nested_prefix}{connector} {indicator_padded}{step_num} {step_desc}")

    def _render_iteration_indicator(
        self,
        offset: int,
        iteration: int,
        max_iterations: int | None = None,
    ) -> None:
        """Render iteration count for Review/Fix cycles.

        Args:
            offset: Character offset for positioning
            iteration: Current iteration number
            max_iterations: Maximum iterations (if known)
        """
        glyphs = self._get_glyphs()
        prefix = " " * offset

        self._print(f"{prefix}{glyphs['vline']}")

        if max_iterations:
            self._print(f"{prefix}{glyphs['corner']} iteration {iteration} of {max_iterations}")
        else:
            self._print(f"{prefix}{glyphs['corner']} iteration {iteration}")

    def _get_stage_config(self, stage_name: str) -> PipelineStage | None:
        """Get stage configuration by name.

        Args:
            stage_name: Name of the stage to look up

        Returns:
            PipelineStage configuration or None if not found
        """
        for stage in PIPELINE_STAGES:
            if stage.name.lower() == stage_name.lower():
                return stage
        return None

    def stage_transition(
        self,
        new_stage: str,
        substage: str | None = None,
        iteration: int | None = None,
        max_iterations: int | None = None,
    ) -> None:
        """Handle transition to a new stage.

        Marks the previous stage as complete and renders the banner
        for the new stage.

        Args:
            new_stage: Name of the new active stage
            substage: Currently active sub-stage (if any)
            iteration: Current iteration number (for Review/Fix)
            max_iterations: Maximum iterations (for Review/Fix)
        """
        # Mark previous stage as complete if transitioning to a different stage
        if self._current_stage and self._current_stage.lower() != new_stage.lower():
            self._completed_stages.add(self._current_stage.lower())
            # Clear substage completions for the previous stage
            # (new stage starts fresh)

        self._current_stage = new_stage
        self._current_substage = substage

        self.render_banner(
            active_stage=new_stage,
            active_substage=substage,
            iteration=iteration,
            max_iterations=max_iterations,
        )

    def substage_started(self, substage: str) -> None:
        """Mark a sub-stage as started.

        Args:
            substage: Name of the sub-stage that started
        """
        # Mark previous substage as complete
        if self._current_substage:
            self._completed_substages.add(self._current_substage.lower())
            # Clear derive steps when transitioning away from derive
            if self._current_substage.lower() == "derive" and substage.lower() != "derive":
                self.clear_derive_steps()

        self._current_substage = substage
        # If restarting a previously completed substage (e.g. assumptions
        # multi-pass loop), remove from completed so banner shows it active
        self._completed_substages.discard(substage.lower())

    def substage_completed(self, substage: str) -> None:
        """Mark a sub-stage as completed.

        Args:
            substage: Name of the completed sub-stage
        """
        self._completed_substages.add(substage.lower())
        if self._current_substage and self._current_substage.lower() == substage.lower():
            self._current_substage = None

    def mark_stage_complete(self, stage: str) -> None:
        """Explicitly mark a stage as completed.

        Args:
            stage: Name of the completed stage
        """
        self._completed_stages.add(stage.lower())

    def mark_substage_complete(self, substage: str) -> None:
        """Explicitly mark a sub-stage as completed.

        Args:
            substage: Name of the completed sub-stage
        """
        self._completed_substages.add(substage.lower())

    def derive_step_started(self, step: int) -> None:
        """Mark a derive substep as started.

        Args:
            step: Step number (1, 2, or 3)
        """
        # Mark previous step as complete
        if self._derive_current_step:
            self._derive_completed_steps.add(self._derive_current_step)
        self._derive_current_step = step

    def derive_step_completed(self, step: int) -> None:
        """Mark a derive substep as completed.

        Args:
            step: Step number (1, 2, or 3)
        """
        self._derive_completed_steps.add(step)
        if self._derive_current_step == step:
            self._derive_current_step = None

    def clear_derive_steps(self) -> None:
        """Clear derive substep tracking (called when moving to next substage)."""
        self._derive_current_step = None
        self._derive_completed_steps.clear()

    def reset(self) -> None:
        """Reset all state for a new session."""
        self._completed_stages.clear()
        self._completed_substages.clear()
        self._current_stage = None
        self._current_substage = None
        self._last_rendered_stage = None
        self._derive_current_step = None
        self._derive_completed_steps.clear()

    def get_pipeline_stage(self, internal_name: str) -> str | None:
        """Map an internal stage/action name to a pipeline stage.

        Args:
            internal_name: Internal stage name (e.g., "derive", "assumptions")

        Returns:
            Pipeline stage name or None if not mapped
        """
        return STAGE_TO_PIPELINE.get(internal_name.lower())

    def get_pipeline_stage_from_phase(self, phase: str) -> str | None:
        """Map an internal phase name to a pipeline stage.

        Args:
            phase: Internal phase name (e.g., "DERIVATION", "EXECUTION")

        Returns:
            Pipeline stage name or None if not mapped
        """
        return PHASE_TO_PIPELINE.get(phase.upper())

    def should_render_banner(self, stage: str) -> bool:
        """Check if banner should be rendered for this stage.

        Avoids rendering duplicate banners for the same stage.

        Args:
            stage: Stage name to check

        Returns:
            True if banner should be rendered
        """
        return (
            self._last_rendered_stage is None or self._last_rendered_stage.lower() != stage.lower()
        )

    def _print(self, text: str, style: str | None = None) -> None:
        """Print to console with optional styling.

        Args:
            text: Text to print
            style: Optional Rich style string
        """
        if style:
            self._console.print(text, style=style)
        else:
            self._console.print(text)
