"""Shared Ollama runtime error taxonomy and messaging.

This module provides a single normalization contract for Ollama runtime
failures across:
- codex-backed preflight/runtime checks (semantic provider `ollama`)
- direct Ollama HTTP API invocation (`LLMInvoker` + `OllamaProvider`)
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class OllamaRuntimeErrorClass(str, Enum):
    """Canonical Ollama runtime failure classes."""

    RUNTIME_MISSING = "runtime_missing"
    ENDPOINT_UNREACHABLE = "endpoint_unreachable"
    MODEL_UNAVAILABLE = "model_unavailable"
    REQUEST_TIMEOUT = "request_timeout"
    PROVIDER_EXECUTION_ERROR = "provider_execution_error"
    UNKNOWN = "unknown"


@dataclass(frozen=True)
class OllamaRuntimeIssue:
    """Normalized Ollama runtime issue payload."""

    source: str
    error_class: OllamaRuntimeErrorClass
    summary: str
    detail: str
    actionable_message: str
    suggested_fix_steps: tuple[str, ...]
    endpoint: str | None = None
    model: str | None = None


_SUMMARY_BY_CLASS: dict[OllamaRuntimeErrorClass, str] = {
    OllamaRuntimeErrorClass.RUNTIME_MISSING: "Codex runtime binary is unavailable for Ollama.",
    OllamaRuntimeErrorClass.ENDPOINT_UNREACHABLE: "Ollama endpoint is unreachable.",
    OllamaRuntimeErrorClass.MODEL_UNAVAILABLE: "Ollama model tag is unavailable.",
    OllamaRuntimeErrorClass.REQUEST_TIMEOUT: "Ollama request timed out.",
    OllamaRuntimeErrorClass.PROVIDER_EXECUTION_ERROR: "Ollama runtime execution failed.",
    OllamaRuntimeErrorClass.UNKNOWN: "Ollama runtime failed with an unknown error.",
}


def classify_ollama_runtime_error(detail: str) -> OllamaRuntimeErrorClass:
    """Classify raw error detail into canonical Ollama runtime classes."""
    text = str(detail or "").strip().lower()
    if not text:
        return OllamaRuntimeErrorClass.UNKNOWN

    if ("codex" in text and "not found" in text) or "not found in path" in text:
        return OllamaRuntimeErrorClass.RUNTIME_MISSING

    if (
        "endpoint is not reachable" in text
        or "endpoint check failed" in text
        or "cannot connect to ollama" in text
        or "connection refused" in text
        or ("ollama" in text and "not reachable" in text)
    ):
        return OllamaRuntimeErrorClass.ENDPOINT_UNREACHABLE

    if (
        "model_not_found" in text
        or ("requested model" in text and "does not exist" in text)
        or "try pulling it first" in text
        or ("model" in text and "not found" in text)
        or "model tag is unavailable" in text
    ):
        return OllamaRuntimeErrorClass.MODEL_UNAVAILABLE

    if "timed out" in text or "timeout" in text:
        return OllamaRuntimeErrorClass.REQUEST_TIMEOUT

    if "exited with code" in text or "codex cli failed" in text:
        return OllamaRuntimeErrorClass.PROVIDER_EXECUTION_ERROR

    return OllamaRuntimeErrorClass.UNKNOWN


def normalize_ollama_runtime_issue(
    detail: str,
    *,
    source: str,
    endpoint: str | None = None,
    model: str | None = None,
) -> OllamaRuntimeIssue:
    """Normalize raw Ollama runtime errors into shared operator-facing contract."""
    cleaned_detail = str(detail or "").strip() or "Unknown error."
    error_class = classify_ollama_runtime_error(cleaned_detail)
    summary = _SUMMARY_BY_CLASS[error_class]
    fix_steps = _build_fix_steps(error_class, endpoint=endpoint, model=model)

    lines = [
        f"Ollama runtime error [{error_class.value}]: {summary}",
    ]
    if fix_steps:
        lines.append("Next steps:")
        lines.extend([f"- {step}" for step in fix_steps])
    lines.append(f"Detail: {cleaned_detail}")
    actionable_message = "\n".join(lines)

    return OllamaRuntimeIssue(
        source=source,
        error_class=error_class,
        summary=summary,
        detail=cleaned_detail,
        actionable_message=actionable_message,
        suggested_fix_steps=fix_steps,
        endpoint=endpoint,
        model=model,
    )


def _build_fix_steps(
    error_class: OllamaRuntimeErrorClass,
    *,
    endpoint: str | None,
    model: str | None,
) -> tuple[str, ...]:
    """Build canonical remediation steps for normalized issue classes."""
    if error_class == OllamaRuntimeErrorClass.RUNTIME_MISSING:
        return (
            "Install Codex CLI (`npm install -g @openai/codex`).",
            "Ensure `codex` is available on PATH.",
            "Start Ollama (`ollama serve`) before running preflight.",
        )

    if error_class == OllamaRuntimeErrorClass.ENDPOINT_UNREACHABLE:
        endpoint_text = endpoint or "configured Ollama endpoint"
        return (
            "Start Ollama (`ollama serve`).",
            f"Verify endpoint reachability: {endpoint_text}",
            "Confirm llm.ollama.endpoint / OLLAMA_HOST settings.",
        )

    if error_class == OllamaRuntimeErrorClass.MODEL_UNAVAILABLE:
        model_hint = model or "<model-tag>"
        return (
            f"Pull the model tag (`ollama pull {model_hint}`).",
            "Update llm.*.model to an installed tag or `default`.",
            "Re-run provider:model preflight.",
        )

    if error_class == OllamaRuntimeErrorClass.REQUEST_TIMEOUT:
        return (
            "Retry after confirming Ollama service health.",
            "Use a smaller local model or reduce prompt scope.",
            "Increase timeout settings if this is expected workload latency.",
        )

    if error_class == OllamaRuntimeErrorClass.PROVIDER_EXECUTION_ERROR:
        return (
            "Inspect codex stderr/detail output in logs.",
            "Confirm codex and ollama versions are compatible.",
            "Re-run preflight to isolate CLI vs model availability issues.",
        )

    return (
        "Inspect the detailed error text and runtime logs.",
        "Re-run provider preflight to isolate runtime prerequisites.",
    )


__all__ = [
    "OllamaRuntimeErrorClass",
    "OllamaRuntimeIssue",
    "classify_ollama_runtime_error",
    "normalize_ollama_runtime_issue",
]
