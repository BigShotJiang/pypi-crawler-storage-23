"""WebSocket protocol frame types for the gateway server.

Defines a JSON-framed bidirectional protocol inspired by the OpenClaw pattern.
Clients send RequestFrames, server replies with ResponseFrames and pushes EventFrames.
"""

from __future__ import annotations

import json
from typing import Any, Literal

from pydantic import BaseModel, ValidationError

# Supported WebSocket methods
WS_METHOD = Literal[
    "create_session",
    "list_sessions",
    "get_session",
    "cancel_session",
    "subscribe",
    "unsubscribe",
    "escalation_decision",
]

_SUPPORTED_METHODS: list[str] = [
    "create_session",
    "list_sessions",
    "get_session",
    "cancel_session",
    "subscribe",
    "unsubscribe",
    "escalation_decision",
]


class RequestFrame(BaseModel):
    """Client-to-server request frame.

    Attributes:
        type: Always 'req'.
        id: Client-generated request identifier for correlation.
        method: The method to invoke.
        params: Method parameters.
    """

    type: Literal["req"] = "req"
    id: str
    method: WS_METHOD
    params: dict[str, Any] = {}


class ResponseFrame(BaseModel):
    """Server-to-client response frame.

    Attributes:
        type: Always 'res'.
        id: Matches the request id.
        ok: Whether the request succeeded.
        payload: Response data on success.
        error: Error message on failure.
    """

    type: Literal["res"] = "res"
    id: str
    ok: bool
    payload: dict[str, Any] = {}
    error: str | None = None


class EventFrame(BaseModel):
    """Server-to-client push event frame.

    Attributes:
        type: Always 'event'.
        event: Event type name (e.g. 'progress', 'stream', 'escalation_notice').
        payload: Event data.
        session_id: Session this event belongs to.
        seq: Sequence number for ordering.
    """

    type: Literal["event"] = "event"
    event: str
    payload: dict[str, Any]
    session_id: str | None = None
    seq: int = 0


class HelloFrame(BaseModel):
    """Server greeting sent after successful authentication.

    Attributes:
        type: Always 'hello'.
        server_version: Obra gateway version string.
        methods: List of supported method names.
        sessions: Snapshot of current sessions.
    """

    type: Literal["hello"] = "hello"
    server_version: str
    methods: list[str]
    sessions: list[dict[str, Any]]


def parse_frame(data: str) -> RequestFrame:
    """Parse a raw JSON string into a RequestFrame.

    Args:
        data: Raw JSON string from the WebSocket client.

    Returns:
        Validated RequestFrame.

    Raises:
        ValueError: If JSON is invalid or doesn't conform to RequestFrame schema.
    """
    try:
        parsed = json.loads(data)
    except json.JSONDecodeError as exc:
        msg = f"Invalid JSON: {exc}"
        raise ValueError(msg) from exc

    if not isinstance(parsed, dict):
        msg = "Frame must be a JSON object"
        raise ValueError(msg)

    try:
        return RequestFrame.model_validate(parsed)
    except ValidationError as exc:
        msg = f"Invalid request frame: {exc}"
        raise ValueError(msg) from exc


def serialize_frame(frame: ResponseFrame | EventFrame | HelloFrame) -> str:
    """Serialize a frame to JSON string.

    Args:
        frame: The frame to serialize.

    Returns:
        JSON string representation.
    """
    return frame.model_dump_json()
