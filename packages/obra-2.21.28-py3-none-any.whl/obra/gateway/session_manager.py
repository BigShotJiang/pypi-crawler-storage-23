"""Session lifecycle manager — thread-per-session model for HybridOrchestrator."""

from __future__ import annotations

import logging
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal

from obra.api.protocol import CompletionNotice
from obra.core.interrupts import GracefulInterrupt, clear_interrupt_request, request_interrupt
from obra.gateway.bridge import OrchestratorBridge
from obra.gateway.event_bus import SessionEventBus

logger = logging.getLogger(__name__)


class SessionLimitError(Exception):
    """Raised when max concurrent sessions exceeded."""

    def __init__(self, max_sessions: int) -> None:
        self.max_sessions = max_sessions
        super().__init__(f"Session limit reached: maximum {max_sessions} concurrent sessions")


class SessionNotFoundError(Exception):
    """Raised when a session ID is not found."""

    def __init__(self, session_id: str) -> None:
        self.session_id = session_id
        super().__init__(f"Session not found: {session_id}")


@dataclass
class SessionRecord:
    """Tracks state of a single orchestration session."""

    session_id: str
    thread: threading.Thread
    event_bus: SessionEventBus
    status: Literal["running", "completed", "failed", "cancelled"] = "running"
    created_at: datetime = field(default_factory=lambda: datetime.now(tz=timezone.utc))
    objective: str = ""
    project_id: str = ""
    completion_notice: CompletionNotice | None = None
    error: str | None = None


class SessionManager:
    """Manages orchestration sessions with thread-per-session model.

    Each session runs HybridOrchestrator.derive() in its own thread, bridged
    to async consumers via SessionEventBus.

    Note on cancellation: request_interrupt() uses a module-global singleton.
    Cancelling one session may affect others. Best-effort isolation is achieved
    by calling clear_interrupt_request() at the start of each session thread.

    Args:
        max_sessions: Maximum concurrent running sessions.
        escalation_timeout_s: Timeout for escalation decisions.
    """

    def __init__(
        self, max_sessions: int = 5, escalation_timeout_s: float = 300.0
    ) -> None:
        self._max_sessions = max_sessions
        self._escalation_timeout_s = escalation_timeout_s
        self._sessions: dict[str, SessionRecord] = {}
        self._lock = threading.Lock()

    def create_session(
        self,
        objective: str,
        project_id: str,
        working_dir: str,
    ) -> str:
        """Create and start a new orchestration session.

        Args:
            objective: The objective to derive.
            project_id: Project identifier.
            working_dir: Working directory path for the orchestrator.

        Returns:
            Session ID string.

        Raises:
            SessionLimitError: If max concurrent sessions exceeded.
        """
        with self._lock:
            running = sum(
                1 for s in self._sessions.values() if s.status == "running"
            )
            if running >= self._max_sessions:
                raise SessionLimitError(self._max_sessions)

            session_id = uuid.uuid4().hex[:12]
            event_bus = SessionEventBus(
                session_id, escalation_timeout_s=self._escalation_timeout_s
            )
            bridge = OrchestratorBridge(event_bus)

            thread = threading.Thread(
                target=self._run_session,
                args=(session_id, objective, project_id, working_dir, bridge),
                name=f"gateway-session-{session_id}",
                daemon=True,
            )

            record = SessionRecord(
                session_id=session_id,
                thread=thread,
                event_bus=event_bus,
                objective=objective,
                project_id=project_id,
            )
            self._sessions[session_id] = record

        thread.start()
        return session_id

    def _run_session(
        self,
        session_id: str,
        objective: str,
        project_id: str,
        working_dir: str,
        bridge: OrchestratorBridge,
    ) -> None:
        """Run orchestration in a dedicated thread."""
        record = self._sessions[session_id]
        try:
            # Best-effort isolation from prior session cancels
            clear_interrupt_request()

            wd = Path(working_dir)

            # Each thread needs its own APIClient (requests.Session is NOT thread-safe)
            from obra.api import APIClient

            APIClient.from_config()  # Validates auth — the client instance is created inside from_config()

            # Use from_config() — resolves LLM config, runs model probe, handles auth
            from obra.hybrid.orchestrator import HybridOrchestrator

            orchestrator = HybridOrchestrator.from_config(
                working_dir=wd,
                on_progress=bridge.on_progress,
                on_stream=bridge.on_stream,
                on_escalation=bridge.on_escalation,
            )

            completion = orchestrator.derive(
                objective=objective, project_id=project_id
            )

            record.completion_notice = completion
            record.status = "completed"
            record.event_bus.push_event("session_completed", {
                "session_id": session_id,
                "summary": completion.session_summary if completion else "",
            })

        except GracefulInterrupt:
            record.status = "cancelled"
            logger.info("Session %s cancelled via interrupt", session_id)

        except Exception as exc:
            record.status = "failed"
            record.error = str(exc)
            record.event_bus.push_event("session_error", {
                "session_id": session_id,
                "error": str(exc),
            })
            logger.exception("Session %s failed", session_id)

        finally:
            record.event_bus.close()

    def get_session(self, session_id: str) -> SessionRecord:
        """Get session record by ID.

        Raises:
            SessionNotFoundError: If session not found.
        """
        with self._lock:
            if session_id not in self._sessions:
                raise SessionNotFoundError(session_id)
            return self._sessions[session_id]

    def list_sessions(self) -> list[SessionRecord]:
        """Return all session records."""
        with self._lock:
            return list(self._sessions.values())

    def cancel_session(self, session_id: str) -> None:
        """Request cancellation of a running session.

        Note: request_interrupt() is module-global. Cancelling one session may
        affect others. Best-effort isolation via clear_interrupt_request() at
        each thread start.

        Raises:
            SessionNotFoundError: If session not found.
        """
        with self._lock:
            if session_id not in self._sessions:
                raise SessionNotFoundError(session_id)
        request_interrupt("gateway_cancel")

    def get_event_bus(self, session_id: str) -> SessionEventBus:
        """Get the event bus for a session (for transport layers to subscribe).

        Raises:
            SessionNotFoundError: If session not found.
        """
        record = self.get_session(session_id)
        return record.event_bus
