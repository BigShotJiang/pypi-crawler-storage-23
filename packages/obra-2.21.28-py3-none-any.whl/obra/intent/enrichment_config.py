"""Intent enrichment configuration loading.

Loads defaults from config/default_config.yaml and merges layered overrides
from ~/.obra/config-layers (user/project/session). All intent enrichment
values are config-driven (no hardcoded fallbacks).
"""

from __future__ import annotations

import logging
from copy import deepcopy
from importlib import resources
from pathlib import Path
from typing import Any

import yaml

from obra.exceptions import ConfigurationError

logger = logging.getLogger(__name__)

ENRICHMENT_CONFIG_PATH = ("planning", "enrichment")


def load_enrichment_config(project_path: Path) -> dict[str, Any]:
    """Load intent enrichment configuration for a project.

    Args:
        project_path: Project root (repo root or working directory)

    Returns:
        Merged enrichment configuration dict
    """
    defaults = _load_default_enrichment_config()
    overrides = _load_project_enrichment_config(project_path)
    return _deep_merge(defaults, overrides)


def _load_default_enrichment_config() -> dict[str, Any]:
    try:
        config_resource = resources.files("obra.config").joinpath("default_config.yaml")
        content = config_resource.read_text(encoding="utf-8")
        data = yaml.safe_load(content) or {}
    except Exception as exc:
        config_path = _find_default_config_fallback()
        try:
            content = config_path.read_text(encoding="utf-8")
            data = yaml.safe_load(content) or {}
        except (OSError, yaml.YAMLError) as fallback_exc:
            msg = f"Failed to read default config at {config_path}: {fallback_exc}"
            raise ConfigurationError(
                msg,
                "Verify config/default_config.yaml exists and is valid YAML.",
            ) from fallback_exc
        logger.debug(
            "Loaded default_config.yaml from repo fallback after packaged load failed: %s",
            exc,
        )

    enrichment = _extract_enrichment_section(data)
    if enrichment is None:
        msg = "Default config missing planning.enrichment section."
        raise ConfigurationError(
            msg,
            "Add planning.enrichment defaults to config/default_config.yaml.",
        )
    return enrichment


def _load_project_enrichment_config(project_path: Path) -> dict[str, Any]:
    from obra.config.loaders import load_layered_config
    from obra.intent.storage import IntentStorage

    project_id = IntentStorage().get_project_id(project_path)
    data, _, warnings = load_layered_config(project_id=project_id)
    if warnings:
        logger.warning("Config layer warning(s) for enrichment config: %s", warnings)

    try:
        enrichment = _extract_enrichment_section(data)
    except ConfigurationError as exc:
        logger.warning(
            "Invalid planning.enrichment config in layered config (using defaults): %s",
            exc,
        )
        return {}
    return enrichment or {}


def _extract_enrichment_section(data: dict[str, Any]) -> dict[str, Any] | None:
    planning = data.get("planning")
    if planning is None:
        return None
    if not isinstance(planning, dict):
        msg = "planning section must be a mapping."
        raise ConfigurationError(
            msg,
            "Set planning: { enrichment: { ... } } in config.",
        )
    enrichment = planning.get("enrichment")
    if enrichment is None:
        return None
    if not isinstance(enrichment, dict):
        msg = "planning.enrichment must be a mapping."
        raise ConfigurationError(
            msg,
            "Set planning.enrichment to a mapping of enrichment settings.",
        )
    return enrichment


def _find_default_config_fallback() -> Path:
    start = Path(__file__).resolve()
    for parent in start.parents:
        candidate = parent / "config" / "default_config.yaml"
        if candidate.exists():
            return candidate
    msg = "Unable to locate config/default_config.yaml for enrichment defaults."
    raise ConfigurationError(
        msg,
        "Ensure the repository includes config/default_config.yaml.",
    )


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    result = deepcopy(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result
