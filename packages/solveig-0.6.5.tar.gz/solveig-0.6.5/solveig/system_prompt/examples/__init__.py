from . import joke, long

__all__ = [
    "joke",
    "long",
]
