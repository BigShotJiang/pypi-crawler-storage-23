"""Referral module configuration and global singleton access."""

from __future__ import annotations

from referral.models import ReferralConfig


_config: ReferralConfig | None = None


def init_referral(config: ReferralConfig | None = None) -> ReferralConfig:
    """Initialize the referral module with the given configuration.

    If no config is provided a default ``ReferralConfig`` is created.

    Returns:
        The active configuration instance.
    """
    global _config
    _config = config or ReferralConfig()
    return _config


def get_referral() -> ReferralConfig:
    """Return the current referral configuration.

    Raises:
        RuntimeError: If ``init_referral()`` has not been called yet.
    """
    if _config is None:
        raise RuntimeError("Referral module not initialized. Call init_referral() first.")
    return _config


def set_config(config: ReferralConfig) -> None:
    """Override the global configuration (useful for testing)."""
    global _config
    _config = config


def reset_config() -> None:
    """Clear the global configuration (useful for test teardown)."""
    global _config
    _config = None
