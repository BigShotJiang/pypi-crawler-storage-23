"""Shared fixtures for referral module tests."""

from __future__ import annotations

import pytest

import referral.config as cfg
from referral.config import init_referral
from referral.models import ReferralConfig, RewardType
from referral.rewards import RewardEngine
from referral.service import ReferralService
from referral.store import InMemoryReferralStore


@pytest.fixture(autouse=True)
def _reset_config():
    """Reset the global config before and after each test."""
    cfg._config = None
    yield
    cfg._config = None


@pytest.fixture()
def referral_config() -> ReferralConfig:
    """Return a standard test configuration."""
    return ReferralConfig(
        reward_type=RewardType.CREDIT,
        reward_amount=10.0,
        max_referrals_per_user=50,
        default_code_max_uses=10,
        expiry_days=90,
        double_sided=True,
    )


@pytest.fixture()
def single_sided_config() -> ReferralConfig:
    """Return a configuration with double_sided disabled."""
    return ReferralConfig(
        reward_type=RewardType.DISCOUNT,
        reward_amount=5.0,
        max_referrals_per_user=5,
        default_code_max_uses=3,
        expiry_days=30,
        double_sided=False,
    )


@pytest.fixture()
def initialized_config(referral_config: ReferralConfig) -> ReferralConfig:
    """Initialize the global config and return it."""
    init_referral(referral_config)
    return referral_config


@pytest.fixture()
def store() -> InMemoryReferralStore:
    """Return a fresh in-memory store."""
    return InMemoryReferralStore()


@pytest.fixture()
def service(store: InMemoryReferralStore, initialized_config: ReferralConfig) -> ReferralService:
    """Return a ReferralService wired to the in-memory store."""
    return ReferralService(store)


@pytest.fixture()
def reward_engine(store: InMemoryReferralStore, initialized_config: ReferralConfig) -> RewardEngine:
    """Return a RewardEngine wired to the in-memory store."""
    return RewardEngine(store)
