# mcpzoo-file-info

> 文件信息 — 获取文件的大小修改时间等元信息

## Installation

```bash
uvx mcpzoo-file-info
```

## uvx JSON

```json
{
  "mcpServers": {
    "file-info": {
      "args": ["mcpzoo-file-info"],
      "command": "uvx"
    }
  }
}
```
