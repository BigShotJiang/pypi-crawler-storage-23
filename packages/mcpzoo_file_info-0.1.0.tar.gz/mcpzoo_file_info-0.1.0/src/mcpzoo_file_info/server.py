import os
import datetime
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("file-info")

@mcp.tool()
def get_file_info(path: str) -> str:
    """获取文件的大小、权限、修改时间等元信息。"""
    if not os.path.exists(path):
        return f"文件不存在: {path}"
        
    try:
        stat = os.stat(path)
        is_dir = os.path.isdir(path)
        
        info = [
            f"路径: {os.path.abspath(path)}",
            f"类型: {'目录' if is_dir else '文件'}",
            f"大小: {stat.st_size} 字节",
            f"权限: {oct(stat.st_mode)[-3:]}",
            f"创建时间: {datetime.datetime.fromtimestamp(stat.st_ctime)}",
            f"修改时间: {datetime.datetime.fromtimestamp(stat.st_mtime)}",
            f"访问时间: {datetime.datetime.fromtimestamp(stat.st_atime)}"
        ]
        return "\n".join(info)
    except Exception as e:
        return f"获取失败: {e}"

def main():
    mcp.run()

if __name__ == "__main__":
    main()
