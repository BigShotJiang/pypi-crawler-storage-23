console.log('This log is from the file global/static/js/main.js')
