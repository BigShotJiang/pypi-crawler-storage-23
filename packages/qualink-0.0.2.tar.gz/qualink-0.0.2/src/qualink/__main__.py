from qualink.cli import main

main()
