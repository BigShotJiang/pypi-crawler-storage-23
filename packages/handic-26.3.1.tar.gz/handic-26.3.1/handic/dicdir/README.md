# HanDic

HanDic is a dictionary for morphological analysis of Korean languages with the morphological analysis engine MeCab. It consists of over 120,000 entries and was trained and built with data centered on written language, such as newspapers, news, novels, and textbooks.

For more information, please refer to [HanDic](https://github.com/okikirmui/handic).

HanDic is copyright Yoshinori Sugai and distributed under the BSD-3-Clause license.
