"""Sherpa transform annotations to categories processor"""

__version__ = "0.6.3"
