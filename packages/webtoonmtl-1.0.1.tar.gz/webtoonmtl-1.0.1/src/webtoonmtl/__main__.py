if __name__ == "__main__":
    from webtoonmtl.cli import cli

    cli()
