# Catppuccin Mocha color scheme
COLORS = {
    "base": "#1e1e2e",
    "text": "#cdd6f4",
    "overlay": "#6c7086",
    "blue": "#89b4fa",
    "red": "#f38ba8",
    "pink": "#f5c2e7",
    "mauve": "#cba6f7",
    "surface0": "#313244",
    "surface1": "#45475a",
    "surface2": "#585b70",
}
