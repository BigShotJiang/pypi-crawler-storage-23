"""Tests for policy compiler system."""
