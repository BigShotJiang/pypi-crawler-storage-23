"""Agent Corral - Multi-agent orchestration for AI coding agents."""

__version__ = "0.1.1"
