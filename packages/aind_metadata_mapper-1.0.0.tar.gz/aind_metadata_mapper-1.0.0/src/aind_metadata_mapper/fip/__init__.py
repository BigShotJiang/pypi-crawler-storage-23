"""FIP (Fiber Photometry) mapper module."""
