=============
API Reference
=============

oemof.datapackage.datapackage package
=====================================

.. automodule:: oemof.datapackage.datapackage
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

oemof.datapackage.datapackage.aggregation module
------------------------------------------------

.. automodule:: oemof.datapackage.datapackage.aggregation
    :members:
    :undoc-members:
    :show-inheritance:

oemof.datapackage.datapackage.building module
---------------------------------------------

.. automodule:: oemof.datapackage.datapackage.building
    :members:
    :undoc-members:
    :show-inheritance:

oemof.datapackage.datapackage.processing module
-----------------------------------------------

.. automodule:: oemof.datapackage.datapackage.processing
    :members:
    :undoc-members:
    :show-inheritance:

oemof.datapackage.datapackage.reading module
--------------------------------------------

.. automodule:: oemof.datapackage.datapackage.reading
    :members:
    :undoc-members:
    :show-inheritance:

oemof.datapackage.tools package
===============================

.. automodule:: oemof.datapackage.tools
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

oemof.datapackage.tools.geometry module
---------------------------------------

.. automodule:: oemof.datapackage.tools.geometry
    :members:
    :undoc-members:
    :show-inheritance:
