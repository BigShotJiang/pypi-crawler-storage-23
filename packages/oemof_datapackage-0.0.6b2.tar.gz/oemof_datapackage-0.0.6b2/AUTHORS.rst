
Authors
=======

* Stephan Günther - https://oemof.org
* Simon Hilpert
* Martin Söthe
* Cord Kaldemeyer
* Jann Launer
* Hendrik Huyskens
* Monika Orlowski
* Francesco Witte
* Sarah Berendes
* Marie-Claire Gering
* Julian Endres
* Felix Maurer
* Pierre-Francois Duc
* Sabine Haas
