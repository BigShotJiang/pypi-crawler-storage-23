supported_oemof_datapackage_versions = [
    None,
    "0.0.1",
    "0.0.2",
    "0.0.3",
    "0.0.4",
    "0.0.5",
    "v0.0.6b2",
]
