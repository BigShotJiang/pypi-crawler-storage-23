"""Allow running as `python -m emovi_mcp`."""

from emovi_mcp.main import main

main()
