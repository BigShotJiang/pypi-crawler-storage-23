"""emovi-mcp: MCP server for ESRU-EMOVI 2023 social mobility survey."""

__version__ = "0.2.0"
