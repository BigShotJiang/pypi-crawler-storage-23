# Security Policy

## Supported versions

Only the latest minor release is supported with security fixes.

## Reporting a vulnerability

Please report vulnerabilities privately by opening a GitHub Security Advisory
or contacting repository maintainers through private channels.

Do not disclose vulnerabilities publicly until maintainers confirm remediation.
