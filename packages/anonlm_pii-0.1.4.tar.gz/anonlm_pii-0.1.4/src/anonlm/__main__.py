from anonlm.cli import main

raise SystemExit(main())
