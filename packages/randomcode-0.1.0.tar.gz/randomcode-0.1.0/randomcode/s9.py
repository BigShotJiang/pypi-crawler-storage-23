# Genetic Algorithm- I 

import random

POP_SIZE = 6
CHROM_LEN = 5
GENERATIONS = 10
MUT_RATE = 0.1

population = [[random.randint(0,1) for _ in range(CHROM_LEN)]
              for _ in range(POP_SIZE)]

def decode(chrom):
    return int("".join(map(str, chrom)), 2)

for gen in range(GENERATIONS):

    values = [decode(c) for c in population]
    fitness = [x**2 for x in values]

    best_index = fitness.index(max(fitness))
    print("Generation", gen+1,
          "Best x =", values[best_index],
          "Fitness =", fitness[best_index])

    total = sum(fitness)
    probs = [f/total for f in fitness]

    new_pop = []
    while len(new_pop) < POP_SIZE:
        p1 = population[random.choices(range(POP_SIZE), probs)[0]]
        p2 = population[random.choices(range(POP_SIZE), probs)[0]]

        point = random.randint(1, CHROM_LEN-1)
        c1 = p1[:point] + p2[point:]
        c2 = p2[:point] + p1[point:]

        new_pop.extend([c1, c2])

    for chrom in new_pop:
        for i in range(CHROM_LEN):
            if random.random() < MUT_RATE:
                chrom[i] ^= 1

    population = new_pop[:POP_SIZE]