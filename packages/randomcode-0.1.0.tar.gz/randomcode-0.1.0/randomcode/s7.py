% Generation of ANDNOT function using McCulloch-Pitts neural net 

clc;
clear;

disp('Enter weights');
w1 = input('w1 = ');
w2 = input('w2 = ');

disp('Enter threshold');
theta = input('theta = ');

x1 = [0 0 1 1];
x2 = [0 1 0 1];
target = [0 0 1 0];  

while 1
    zin = x1*w1 + x2*w2;
    y = zeros(1,4);

    for i = 1:4
        if zin(i) >= theta
            y(i) = 1;
        else
            y(i) = 0;
        end
    end

    disp('Output = ');
    disp(y);

    if isequal(y, target)
        break;
    else
        disp('Wrong weights. Enter again.');
        w1 = input('w1 = ');
        w2 = input('w2 = ');
        theta = input('theta = ');
    end
end

disp('McCulloch Pitts Net for ANDNOT');
disp('Weights:');
disp([w1 w2]);
disp('Threshold:');
disp(theta);