%Implementation of De Morgan’s Law 

clc;
clear;

u = input('Enter the membership values of first fuzzy set: ');
v = input('Enter the membership values of second fuzzy set: ');

if length(u) ~= length(v)
    error('Both fuzzy sets must have the same number');
end

w = max(u, v);
p = min(u, v);
q1 = 1 - u;
q2 = 1 - v;

x1 = 1 - w;
x2 = min(q1, q2);

y1 = 1 - p;
y2 = max(q1, q2);

disp('Union of two fuzzy sets (max operation)');
disp(w);

disp('Intersection of two fuzzy sets (min operation)');
disp(p);

disp('Complement of first fuzzy set');
disp(q1);

disp('Complement of second fuzzy set');
disp(q2);

disp('De Morgan Law Verification');

disp('1) Complement of Maximum = Minimum of Complements');
disp('LHS:');
disp(x1);
disp('RHS:');
disp(x2);

disp('2) Complement of Minimum = Maximum of Complements');
disp('LHS:');
disp(y1);
disp('RHS:');
disp(y2);

