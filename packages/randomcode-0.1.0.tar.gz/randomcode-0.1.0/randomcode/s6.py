% Simple Fuzzy Set Operations 

clc;
clear;

a = input('Enter the fuzzy set A: ');
b = input('Enter the fuzzy set B: ');

if length(a) ~= length(b)
    error('Both fuzzy sets must have the same number of elements');
end

c = a + b;
d = a .* b;

as = c - d;
e = 1 - b;
ad = a .* e;

f = a - b;

bs = min(1, c);
bd = max(0, f);

g = c - 1;
bp = max(0, g);

disp('The algebraic sum:');
disp(as);

disp('The algebraic difference:');
disp(ad);

disp('The algebraic product:');
disp(d);

disp('The bounded sum:');
disp(bs);

disp('The bounded difference:');
disp(bd);

disp('The bounded product:');
disp(bp);