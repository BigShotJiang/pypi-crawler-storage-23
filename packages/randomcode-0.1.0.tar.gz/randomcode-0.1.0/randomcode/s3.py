% Plotting Various Membership Functions 

clc;
clear;
close all;

figure;

x = 0:1:10;
y1 = trimf(x, [1 3 5]);

subplot(3,1,1);
plot(x, y1, 'LineWidth', 2);
title('Triangular Membership Function');
xlabel('x');
ylabel('Membership Value');
grid on;

x = 0:1:10;
y2 = trapmf(x, [1 3 5 7]);

subplot(3,1,2);
plot(x, y2, 'LineWidth', 2);
title('Trapezoidal Membership Function');
xlabel('x');
ylabel('Membership Value');
grid on;

x = 0:0.2:10;
y3 = gbellmf(x, [3 5 7]);

subplot(3,1,3);
plot(x, y3, 'LineWidth', 2);
title('Bell Shaped Membership Function');
xlabel('x');
ylabel('Membership Value');
grid on;