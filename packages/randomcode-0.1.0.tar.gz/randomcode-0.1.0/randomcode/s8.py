% Perceptron neural network 

clc;
clear;

x = [ 1  1 -1 -1;
      1 -1  1 -1 ];

t = [1 -1 -1 -1];

w = [0 0];    
b = 0;      

alpha = input('Enter learning rate = ');
theta = input('Enter threshold = ');

epoch = 0;

while true
    error_flag = 0;

    for i = 1:4
        yin = b + w * x(:,i);

        if yin > theta
            y = 1;
        elseif yin < -theta
            y = -1;
        else
            y = 0;
        end

        if y ~= t(i)
            w = w + alpha * t(i) * x(:,i)';
            b = b + alpha * t(i);
            error_flag = 1;
        end
    end

    epoch = epoch + 1;

    if error_flag == 0
        break;
    end
end

disp('Perceptron for AND Function');
disp('Final Weights:');
disp(w);
disp('Final Bias:');
disp(b);
disp('Epochs:');
disp(epoch);