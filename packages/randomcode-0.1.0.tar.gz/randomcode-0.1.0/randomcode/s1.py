%Performing Union, Intersection and Complement Operations 

clc;
clear;

u = input('Enter the membership values of First Fuzzy set: ');
v = input('Enter the membership values of Second Fuzzy set: ');

if length(u) ~= length(v)
    error('Both fuzzy sets must have the same number');
end

w = max(u, v);
p = min(u, v);
q1 = 1 - u;
q2 = 1 - v;

disp('Union of Two Fuzzy sets:');
disp(w);

disp('Intersection of Two Fuzzy sets:');
disp(p);

disp('Complement of First Fuzzy set:');
disp(q1);

disp('Complement of Second Fuzzy set:');
disp(q2);