% Using Fuzzy toolbox to model tips value

Quality: {not good, satisfying, delightful}
Service: {poor, average, good}


Type fuzzy in MATLAB to open FIS Editor.

Add two inputs:
Quality: not_good, satisfied, delicious
Service: poor, average, good

Add one output:

Tip: less, medium, high (Range 10–100)
Assign triangular (trimf) membership functions for all variables.
Create rules in Rules Editor.
View results in Rule Viewer and test the system.
Save and exit.