% Implementation of Fuzzy Inference System

# INPUTS 

Temperature: {Freeze, Cool, Warm and Hot}
Cloud Cover: {Sunny, Partly Cloudy and Overcast}

#rules

Sunny (Cover) and Warm (Temp) -> Fast (Speed) 
Cloudy (Cover) and Cool (Temp) -> Slow (Speed)


Type fuzzy in MATLAB.

Add inputs:
Temperature: Freezing, Cool, Warm, Hot
Cloud Cover: Sunny, Partly Cloudy, Overcast

Add output:
Speed: Slow, Fast

Assign appropriate trimf/trapmf membership functions.
Add rules:

Sunny & Warm → Fast
Overcast & Cool → Slow
View in Rule Viewer and save.