"""Allow running as python -m agent_company_ai."""

from agent_company_ai.cli.app import app

app()
