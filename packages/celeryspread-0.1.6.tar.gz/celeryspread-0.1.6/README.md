# CelerySpread
Different workers like different spreads - but they all like it on celery, that's for sure
