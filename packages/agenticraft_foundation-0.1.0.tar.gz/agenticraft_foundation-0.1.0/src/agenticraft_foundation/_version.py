"""Version information for agenticraft-foundation."""

__version__ = "0.1.0"
