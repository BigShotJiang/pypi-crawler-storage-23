"""Tests for MPST (Multiparty Session Types) module."""
