"""Tests for formal verification integration adapters."""
