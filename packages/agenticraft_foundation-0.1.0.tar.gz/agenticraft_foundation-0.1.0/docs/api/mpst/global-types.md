# agenticraft_foundation.mpst.global_types

Global type specification — bird's-eye view of multi-party protocols.

::: agenticraft_foundation.mpst.global_types
    options:
      show_root_heading: false
      members_order: source
