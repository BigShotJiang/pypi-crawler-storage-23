# agenticraft_foundation.mpst.patterns

4 communication patterns built from session types: request-response, pipeline, scatter-gather, consensus.

::: agenticraft_foundation.mpst.patterns
    options:
      show_root_heading: false
      members_order: source
