# agenticraft_foundation.mpst.local_types

Local type projection — per-role views derived from global types.

::: agenticraft_foundation.mpst.local_types
    options:
      show_root_heading: false
      members_order: source
