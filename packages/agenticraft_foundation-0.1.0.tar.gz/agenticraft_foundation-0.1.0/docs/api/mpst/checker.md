# agenticraft_foundation.mpst.checker

Well-formedness checking for session types — validates protocol structure and properties.

::: agenticraft_foundation.mpst.checker
    options:
      show_root_heading: false
      members_order: source
