# agenticraft_foundation.mpst.types

Session type definitions — base types for global and local session specifications.

::: agenticraft_foundation.mpst.types
    options:
      show_root_heading: false
      members_order: source
