# agenticraft_foundation.protocols.workflow

Protocol workflow model $W = (T, \prec, \rho)$ — task definitions, precedence ordering, protocol assignment, validation, and optimal assignment.

::: agenticraft_foundation.protocols.workflow
    options:
      show_root_heading: false
      members_order: source
