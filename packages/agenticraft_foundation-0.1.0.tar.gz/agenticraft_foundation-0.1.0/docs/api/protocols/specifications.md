# agenticraft_foundation.protocols.specifications

Formal protocol specifications — property definitions for protocol verification.

::: agenticraft_foundation.protocols.specifications
    options:
      show_root_heading: false
      members_order: source
