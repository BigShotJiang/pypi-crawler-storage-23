# agenticraft_foundation.protocols.graph

Protocol graph representation — agent nodes, protocol edges, and the formal model $G = (V, E, P, \Phi, \Gamma)$.

::: agenticraft_foundation.protocols.graph
    options:
      show_root_heading: false
      members_order: source
