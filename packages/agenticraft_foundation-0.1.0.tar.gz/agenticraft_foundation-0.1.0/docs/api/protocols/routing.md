# agenticraft_foundation.protocols.routing

Protocol-aware routing algorithms — Dijkstra (minimum-cost), BFS (minimum-hop), and resilient routing with failover.

::: agenticraft_foundation.protocols.routing
    options:
      show_root_heading: false
      members_order: source
