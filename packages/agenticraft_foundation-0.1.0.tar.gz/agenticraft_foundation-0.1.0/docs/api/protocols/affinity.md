# agenticraft_foundation.protocols.affinity

Protocol affinity scoring — measures how well an agent supports a given protocol.

::: agenticraft_foundation.protocols.affinity
    options:
      show_root_heading: false
      members_order: source
