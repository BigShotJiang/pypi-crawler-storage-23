# agenticraft_foundation.protocols.semantic_routing

Semantic routing using capability embeddings and protocol affinity scoring.

::: agenticraft_foundation.protocols.semantic_routing
    options:
      show_root_heading: false
      members_order: source
