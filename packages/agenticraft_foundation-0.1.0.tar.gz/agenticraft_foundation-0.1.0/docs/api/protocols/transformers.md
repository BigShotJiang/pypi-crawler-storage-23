# agenticraft_foundation.protocols.transformers

Composable protocol message transformers $T: M_p \to M_{p'} \cup \{\bot\}$ with lossless, lossy, and destructive classification.

::: agenticraft_foundation.protocols.transformers
    options:
      show_root_heading: false
      members_order: source
