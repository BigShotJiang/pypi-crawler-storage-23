# agenticraft_foundation.protocols.semantic

Semantic routing implementations for capability-based agent discovery.

::: agenticraft_foundation.protocols.semantic
    options:
      show_root_heading: false
      members_order: source
