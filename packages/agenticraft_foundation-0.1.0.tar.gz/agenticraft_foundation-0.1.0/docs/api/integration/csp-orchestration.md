# agenticraft_foundation.integration.csp_orchestration

CSP orchestration adapter — converts workflow DAGs to CSP processes for deadlock freedom, liveness analysis, and refinement checking.

::: agenticraft_foundation.integration.csp_orchestration
    options:
      show_root_heading: false
      members_order: source
