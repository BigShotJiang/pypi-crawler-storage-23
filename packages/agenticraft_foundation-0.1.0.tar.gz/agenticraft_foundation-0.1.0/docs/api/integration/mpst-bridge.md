# agenticraft_foundation.integration.mpst_bridge

MPST bridge adapter — maps MCP and A2A protocol interactions to multiparty session types for protocol-verified communication.

::: agenticraft_foundation.integration.mpst_bridge
    options:
      show_root_heading: false
      members_order: source
