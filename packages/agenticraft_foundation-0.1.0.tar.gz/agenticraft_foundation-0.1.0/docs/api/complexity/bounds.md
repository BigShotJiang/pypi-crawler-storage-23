# agenticraft_foundation.complexity.bounds

30+ catalogued complexity bounds across distributed algorithm categories, fault models (4 classical + 4 LLM-specific), and impossibility results.

::: agenticraft_foundation.complexity.bounds
    options:
      show_root_heading: false
      members_order: source
