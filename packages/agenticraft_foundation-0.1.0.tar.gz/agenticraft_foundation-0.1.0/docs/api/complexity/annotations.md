# agenticraft_foundation.complexity.annotations

Complexity annotations — decorator-based tracking for algorithmic complexity classification.

::: agenticraft_foundation.complexity.annotations
    options:
      show_root_heading: false
      members_order: source
