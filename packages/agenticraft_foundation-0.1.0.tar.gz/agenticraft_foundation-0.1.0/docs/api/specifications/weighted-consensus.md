# agenticraft_foundation.specifications.weighted_consensus_spec

Weighted quorum consensus — quality-weighted agents with $2W/3$ quorum threshold for agreement, validity, and quorum intersection.

::: agenticraft_foundation.specifications.weighted_consensus_spec
    options:
      show_root_heading: false
      members_order: source
