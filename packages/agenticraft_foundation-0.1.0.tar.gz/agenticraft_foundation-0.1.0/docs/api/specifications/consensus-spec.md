# agenticraft_foundation.specifications.consensus_spec

Formal consensus properties — Agreement, Validity, Integrity, and Termination.

::: agenticraft_foundation.specifications.consensus_spec
    options:
      show_root_heading: false
      members_order: source
