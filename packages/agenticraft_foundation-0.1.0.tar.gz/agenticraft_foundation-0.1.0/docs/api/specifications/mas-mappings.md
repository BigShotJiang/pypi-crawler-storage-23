# agenticraft_foundation.specifications.mas_mappings

Bidirectional MAS theory mappings — BDI, Joint Intentions, SharedPlans, and Contract Net with formal property preservation.

::: agenticraft_foundation.specifications.mas_mappings
    options:
      show_root_heading: false
      members_order: source
