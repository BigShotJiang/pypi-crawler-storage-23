# agenticraft_foundation.types

Shared type definitions used across all modules.

::: agenticraft_foundation.types
    options:
      show_root_heading: false
      members_order: source
