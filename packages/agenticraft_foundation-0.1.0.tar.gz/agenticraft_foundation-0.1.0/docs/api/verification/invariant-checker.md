# agenticraft_foundation.verification.invariant_checker

Runtime invariant checker — register invariants, check state transitions, track violations.

::: agenticraft_foundation.verification.invariant_checker
    options:
      show_root_heading: false
      members_order: source
