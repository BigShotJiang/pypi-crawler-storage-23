# agenticraft_foundation.topology.laplacian

Laplacian matrix analysis — spectral decomposition, algebraic connectivity ($\lambda_2$), and consensus convergence bounds.

::: agenticraft_foundation.topology.laplacian
    options:
      show_root_heading: false
      members_order: source
