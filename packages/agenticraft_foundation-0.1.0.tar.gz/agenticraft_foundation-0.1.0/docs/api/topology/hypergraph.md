# agenticraft_foundation.topology.hypergraph

Hypergraph topology for group coordination — incidence matrices, hypergraph Laplacian $L_H = D_v - H W D_e^{-1} H^T$, and group coordination metrics.

::: agenticraft_foundation.topology.hypergraph
    options:
      show_root_heading: false
      members_order: source
