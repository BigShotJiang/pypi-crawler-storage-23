# agenticraft_foundation.algebra.refinement

Refinement checking — trace refinement, failures refinement, and failures-divergence refinement.

::: agenticraft_foundation.algebra.refinement
    options:
      show_root_heading: false
      members_order: source
