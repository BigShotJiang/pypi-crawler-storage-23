# agenticraft_foundation.algebra.semantics

Operational semantics — LTS construction, trace extraction, deadlock detection, and liveness analysis.

::: agenticraft_foundation.algebra.semantics
    options:
      show_root_heading: false
      members_order: source
