# agenticraft_foundation.algebra.csp

CSP process definitions — 13 operators implementing the full `Process` contract.

::: agenticraft_foundation.algebra.csp
    options:
      show_root_heading: false
      members_order: source
