# agenticraft_foundation.algebra.patterns

6 coordination patterns built from CSP primitives: request-response, pipeline, scatter-gather, barrier, mutex, producer-consumer.

::: agenticraft_foundation.algebra.patterns
    options:
      show_root_heading: false
      members_order: source

::: agenticraft_foundation.algebra.patterns.coordination
    options:
      show_root_heading: true
      members_order: source
