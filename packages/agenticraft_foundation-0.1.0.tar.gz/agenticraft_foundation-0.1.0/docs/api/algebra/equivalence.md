# agenticraft_foundation.algebra.equivalence

Process equivalence checking — trace equivalence, strong/weak bisimulation, and failures equivalence.

::: agenticraft_foundation.algebra.equivalence
    options:
      show_root_heading: false
      members_order: source
