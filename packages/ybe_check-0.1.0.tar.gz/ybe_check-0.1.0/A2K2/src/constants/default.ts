/**
 * © 2025 ArpitStack. Distributed under Apache-2.0 License.
 * See http://www.apache.org/licenses/LICENSE-2.0 for details.
 */

/** Max log entries kept in memory to avoid bloat. */
export const MAX_LOG_CACHE = 100;

/** Log file name for scan output (under .ybe-check). */
export const LOG_FILE_NAME = 'ybe-check-result';
