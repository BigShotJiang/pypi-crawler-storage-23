"""
Ybe Check MCP Server — exposes scan tools to MCP clients.
Run with: python -m ybe_check.mcp_server
"""

import json
from pathlib import Path
from typing import Optional

from mcp.server.fastmcp import FastMCP

from .core import filter_findings, load_report, run_scan

mcp = FastMCP(
    "ybe-check",
    json_response=True,
)


@mcp.tool(name="ybe.scan_repo")
def scan_repo(
    path: str,
    modules: Optional[list[str]] = None,
    categories: Optional[list[str]] = None,
) -> str:
    """
    Scan a repository for security and production-readiness issues.

    Args:
        path: Absolute or relative path to the repository directory.
        modules: Optional list of module names to run (e.g. secrets, dependencies).
                 Omit to run all modules.
        categories: Optional list of categories: static, dynamic, infra.
                    Omit to run all.

    Returns:
        Full JSON report with findings, scores, and module results.
    """
    report = run_scan(path, modules=modules, categories=categories)
    return json.dumps(report, indent=2)


@mcp.tool(name="ybe.list_findings")
def list_findings(
    path: str,
    severity: Optional[str] = None,
    category: Optional[str] = None,
    report_file: Optional[str] = None,
) -> str:
    """
    List findings from a scan. Runs a fresh scan if no report file is provided,
    or loads from the given report file.

    Args:
        path: Path to the repository (used for scan if report_file is omitted).
        severity: Filter by severity: info, low, medium, high, critical.
        category: Filter by category: static, dynamic, infra.
        report_file: Path to existing ybe-report.json. If provided, loads from
                     file instead of running a new scan.

    Returns:
        JSON array of filtered findings.
    """
    if report_file and Path(report_file).exists():
        report = load_report(report_file)
    else:
        report = run_scan(path)

    findings = filter_findings(report, severity=severity, category=category)
    return json.dumps(findings, indent=2)


@mcp.tool(name="ybe.get_remediation")
def get_remediation(
    path: str,
    finding_id: str,
    report_file: Optional[str] = None,
) -> str:
    """
    Get remediation guidance for a specific finding.

    Args:
        path: Path to the repository (used for scan if report_file is omitted).
        finding_id: The finding ID (e.g. secrets:0, deps:3).
        report_file: Path to existing ybe-report.json. If provided, loads from
                     file instead of running a new scan.

    Returns:
        JSON with impact and remediation (stub/template for now).
    """
    if report_file and Path(report_file).exists():
        report = load_report(report_file)
    else:
        report = run_scan(path)

    findings = report.get("findings", [])
    match = next((f for f in findings if f.get("id") == finding_id), None)

    if not match:
        return json.dumps({
            "error": f"Finding '{finding_id}' not found.",
            "impact": None,
            "remediation": None,
        })

    # Stub: use summary as basis for simple remediation template
    summary = match.get("summary", "")
    source = match.get("source", "")
    severity = match.get("severity", "medium")

    remediation = (
        f"Address the {source} finding: {summary[:200]}. "
        f"Severity: {severity}. "
        "Review the file/location and apply the recommended fix. "
        "For production, ensure no secrets are committed and dependencies are pinned."
    )

    return json.dumps({
        "finding_id": finding_id,
        "impact": f"This {severity}-severity finding may affect production readiness.",
        "remediation": remediation,
        "ai_analysis": match.get("ai_analysis"),
    }, indent=2)


def main() -> None:
    """Run the MCP server over stdio (default for CLI/spawned servers)."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
