"""Ybe Check — Production-readiness gatekeeper for vibe-coded apps."""

__version__ = "0.1.0"
