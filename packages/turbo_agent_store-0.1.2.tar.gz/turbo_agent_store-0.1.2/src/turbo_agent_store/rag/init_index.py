from json import tool
import pandas as pd
import json
from tqdm import tqdm
from urllib import parse
import time
from dotenv import load_dotenv
import hashlib
import dateutil.parser
from loguru import logger
import os
import tempfile
import shutil
from prisma.models import ToolCallRecord,Tool,ToolVersion,User,Agent,Agent,KnowledgeResource
from prisma.enums import ToolCallStatus,ToolType
from typing import List
from datetime import datetime
from turbo_agent_store.rag.schema import UserInfo, KnowledgeChunk,ToolRecordChunk, ChunkFieldType, ToolVersionInfo, AgentInfo
from turbo_agent_store.settings import settings
from turbo_agent_store.utils.cos_access import download_file_from_cos
from enum import Enum
from turbo_agent_store.utils.rag_chunk import chunk_data_on_schema,string_chunking,document_chunking
from turbo_agent_store.utils.docling_client import DoclingClient
from docling_core.types import DoclingDocument
import requests

USE_MANTICORE = True

"""Unified indexing module now always using Manticore Search.

Meilisearch code is retained (commented or unreachable) for reference/migration,
but environment flag switching has been removed.
"""

from turbo_agent_store.utils.search_migration import validate_embedding_configuration

from turbo_agent_store.utils.manticore_search import (
    ManticoreSearchClient as SearchClient,
    wait_task,
    wait_tasks,
    IndexNotFoundError,
    ManticoreApiError as SearchApiError
)

logger.info("Forcing use of Manticore Search backend (Meilisearch code retained but inactive)")
if not validate_embedding_configuration():
    logger.error("Manticore Search embedding configuration is invalid!")

def check_tasks():
    client = SearchClient(settings.MANTICORE_HOST, settings.MANTICORE_API_KEY)
    res = client.get_tasks()
    for result in res.results:
        logger.info(result)

def wait_tasks(tasks):
    for task in tasks:
        wait_task(task)

def wait_task(task_info):
    logger.info(task_info)
    # Manticore operations are synchronous
    return {"task_uid": task_info.get("task_uid"), "status": "succeeded", "error": None}

def initial_index(
        index_id,primary_key,
        documentTemplate="",        
        searchable_attributes=[],
        filterable_attributes =[]
    ):
    client = SearchClient(settings.MANTICORE_HOST, settings.MANTICORE_API_KEY)
    try:
        index = client.get_index(index_id)
        if index:
            if searchable_attributes:
                client.set_searchable_attributes(index_id, searchable_attributes)
            if documentTemplate:
                client.set_template(index_id, documentTemplate)
            return index
    except IndexNotFoundError:
        logger.info(f"Index {index_id} not exists, creating a new one")
        schema = _get_manticore_schema(index_id, searchable_attributes, filterable_attributes)
        task_info = client.create_index(index_id, schema)
        wait_task(task_info)
        index = client.index(index_id)
    # Register runtime metadata
    if searchable_attributes:
        client.set_searchable_attributes(index_id, searchable_attributes)
    if documentTemplate:
        client.set_template(index_id, documentTemplate)
    # Compatibility no-ops
    wait_task(index.update_searchable_attributes(searchable_attributes))
    wait_task(index.update_filterable_attributes(filterable_attributes))
    wait_task(index.update_pagination_settings({'maxTotalHits': 20000}))
    return index


def _get_manticore_schema(index_id: str, searchable_attributes: List[str], filterable_attributes: List[str]) -> dict:
    """Generate Manticore schema based on index type and attributes"""
    
    # Common fields for all indices
    base_schema = {
        'id': {'type': 'string'},
        'content': {'type': 'text'},
        'content_vector': {'type': 'vector', 'dimension': 1536},  # For embeddings
        'created_at': {'type': 'integer'},
        'updated_at': {'type': 'integer'},
    }
    
    # Action index specific fields
    if 'action' in index_id.lower():
        base_schema.update({
            'type': {'type': 'string'},
            'tool_call_record_id': {'type': 'string'},
            'tool_info': {'type': 'json'},
            'agent_info': {'type': 'json'},
            'root_caller': {'type': 'json'},
            'status': {'type': 'string'},
            'intent': {'type': 'text'},
            'chunk_index': {'type': 'integer'},
            'error': {'type': 'text'},
            'tags': {'type': 'json'},
            'workset_ids': {'type': 'json'},
            'message_action_ids': {'type': 'json'},
            'next_record_ids': {'type': 'json'},
            'pre_record_ids': {'type': 'json'},
            'metadata': {'type': 'json'},
        })
    
    # Knowledge index specific fields
    elif 'knowledge' in index_id.lower():
        base_schema.update({
            'type': {'type': 'string'},
            'mime_type': {'type': 'string'},
            'file_type': {'type': 'string'},
            'name': {'type': 'text'},
            'filename': {'type': 'string'},
            'tags': {'type': 'json'},
            'knowledge_id': {'type': 'string'},
            'chunk_index': {'type': 'integer'},
            'projects': {'type': 'json'},
            'settings': {'type': 'json'},
            'worksets': {'type': 'json'},
            'user_ids': {'type': 'json'},
            'creatorId': {'type': 'string'},
            'metadata': {'type': 'json'},
            'setting_ids': {'type': 'json'},
            'project_ids': {'type': 'json'},
            'workset_ids': {'type': 'json'},
        })
    
    return base_schema


def init_action_index():
    """
    初始化工具调用记录索引，基于 ToolRecordChunk 结构
    """
    index_id = getattr(settings, 'MANTICORE_ACTION_INDEX', 'turboagent_action')
    # client = meilisearch.Client(settings.MEILISEARCH_URL, settings.MEILISEARCH_API_KEY)
    # if reset:
    #     client.delete_index(index_id)
    documentTemplate = (
        "【工具名称】{{doc.tool_info.name}}\n"
        "【工具类型】{{doc.tool_info.type}}\n"
        "【记录字段】{{doc.type}}\n"
        "【调用意图】{{doc.intent}}\n"
        "【分块内容】{{doc.content}}\n"
        "【错误信息】{{doc.error}}\n"
        "【标签】{{doc.tags}}\n"
    )
    searchable_attributes = [
        "content", "error", "tags", "intent", "tool_info.name",
        "agent_info.name", "agent_info.name_en", "root_caller.username","root_caller.firstname","root_caller.lastname"
    ]
    filterable_attributes = [
        "type", "tool_call_record_id", "tool_info.name_id", "tool_info.version_id", 
        "tool_info.project_id", "tool_info.type", "agent_info.id", "agent_info.project_id",
        "root_caller.id","root_caller.username", "status", "chunk_index", "tags", "workset_ids", 
        "message_action_ids","next_record_ids", "created_at", "updated_at"
    ]
    index = initial_index(
        index_id=index_id,
        primary_key="id",
        documentTemplate=documentTemplate,
        searchable_attributes=searchable_attributes,
        filterable_attributes=filterable_attributes
    )
    return index

def init_knowledge_index():
    """
    初始化知识索引，基于 KnowledgeChunk 结构
    """
    index_id = getattr(settings, 'MANTICORE_KNOWLEDGE_INDEX', 'turboagent_knowledge')
    documentTemplate = (
        "【文件名称】{{doc.name}}\n"
        "【文件部分内容】{{doc.content}}\n"
        "【知识类型】{{doc.type}}\n"
        "【标签】{{doc.tags}}\n"
        "【文件类型】{{doc.type}}\n"
    )
    searchable_attributes = [
        "content", "tags", "filename", "name", "projects", "settings", "worksets", "type"
    ]
    filterable_attributes = [
        "type", "mime_type","file_type","tags", "knowledge_id", "chunk_index", "projects", "settings", "worksets","user_ids",
        "creatorId", "created_at", "updated_at"
    ]
    index = initial_index(
        index_id=index_id,
        primary_key="id",
        # 文档模板，基于 KnowledgeChunk 结构
        documentTemplate=documentTemplate,
        searchable_attributes=searchable_attributes,
        filterable_attributes=filterable_attributes
    )
    return index

class IndexType(str,Enum):
    KNOWLEDGE = "KNOWLEDGE"
    WORKSET = "WORKSET"
    ACTION = "ACTION"

def get_index(indexType:IndexType):
    """
    获取指定类型的索引，如果不存在则创建。
    :param indexType: 索引类型
    :return: Search Index 对象 (Meilisearch 或 Manticore)
    """
    if indexType == IndexType.ACTION:
        index_id = getattr(settings, 'MANTICORE_ACTION_INDEX', 'turboagent_action')
    elif indexType == IndexType.KNOWLEDGE:
        index_id = getattr(settings, 'MANTICORE_KNOWLEDGE_INDEX', 'turboagent_knowledge')
    else:
        raise ValueError("Unsupported index type")
    client = SearchClient(settings.MANTICORE_HOST, settings.MANTICORE_API_KEY)
    try:
        return client.get_index(index_id)
    except IndexNotFoundError:
        logger.info(f"Index {index_id} not found, creating a new one.")
        if indexType == IndexType.ACTION:
            return init_action_index()
        if indexType == IndexType.KNOWLEDGE:
            return init_knowledge_index()
        raise

def update_action_record_index(record_id, workset_ids: list[str], message_ids: list[str]):
    """
    在索引中更新动作记录的工作集和消息ID
    """
    return
    tool_record_index = get_index(IndexType.ACTION)
    res = tool_record_index.search("*", {"filter": [f'tool_call_record_id = "{record_id}"']})
    if "hits" in res and len(res['hits'])>0:
        docs = res["hits"]
        task = tool_record_index.update_documents([
            {
                "id": doc["id"],
                "workset_ids": list(set(doc["workset_ids"] + workset_ids)),
                "message_action_ids": list(set(doc["message_action_ids"] + message_ids))
            }
            for doc in docs
        ])
        wait_task(task)

def parse_file(knowledge_resource: KnowledgeResource) -> DoclingDocument:
    file_id = knowledge_resource.id
    file_uri = knowledge_resource.uri
    file_content = knowledge_resource.content
    tempfile = download_file_from_cos(file_uri,private=True)
    client = DoclingClient()
    task_info = client.convert_files_async(file_paths=[tempfile], timeout=20)
    logger.info(f"Docling task started: {task_info}")
    for doc in client.wait_task():
        docling_doc = DoclingDocument.model_validate_json(json.dumps(doc["json_content"]))
        return docling_doc
    return None

def index_knowledge_file(knowledge_resource:KnowledgeResource,docling_doc:DoclingDocument):
    return {}
    # file_id = knowledge_resource.id
    # file_uri = knowledge_resource.uri
    # file_content = knowledge_resource.content
    # try:
    #     # 保存上传文件到本地临时文件
        
    #     knowledge_index = get_index(IndexType.KNOWLEDGE)
    #     options = {
    #         'limit': top_k,
    #     }
    #     if query_filters:
    #         options['filter'] = query_filters
    #     if prompt:
    #         options['knn'] = {
    #             'var_field': 'content_vector',
    #             'k': top_k
    #         }
    #     logger.info(f"Manticore unified search prompt={prompt} options={options}")
    #     res = knowledge_index.search(prompt, options)
    #     return res.get('hits', [])
    #                 user_ids=[user.userId for user in knowledge_resource.users ] if knowledge_resource.users else [],
    #                 created_at=int(knowledge_resource.createdAt.timestamp()),
    #                 updated_at=int(knowledge_resource.updatedAt.timestamp()),
    #                 creatorId=knowledge_resource.creatorId
    #             )
    #             chunks.append(chunk)
    #     tool_record_index = get_index(IndexType.KNOWLEDGE)
    #     # logger.debug(f"Indexing {} knowledge chunks for knowledge ID {knowledge_resource.id}")
    #     #添加至索引
    #     task = tool_record_index.add_documents([chunk.model_dump() for chunk in chunks])
    #     wait_task(task)

    #     return {"indexed":chunks}

    # except Exception as e:
    #     logger.error(f"Error indexing knowledge file: {file_id}")
    #     logger.exception(e)
    #     return {"error": str(e)}


def update_knowledge_file_index(knowledge_id, setting_ids: list[str]=[], project_ids: list[str]=[], workset_ids: list[str]=[]):
    """
    在索引中更新知识文件的设置ID、项目ID和工作集ID
    """
    return
    knowledge_index = get_index(IndexType.KNOWLEDGE)
    res = knowledge_index.search("*", {"filter":f'knowledge_id = "{knowledge_id}"'})
    if "hits" in res and len(res['hits'])>0:
        docs = res["hits"]
        task = knowledge_index.update_documents([
            {
                "id": doc["id"],
                "worksets": list(set(doc["workset_ids"] + workset_ids)),
                "settings": list(set(doc["setting_ids"] + setting_ids)),
                "projects": list(set(doc["project_ids"] + project_ids))
            }
            for doc in docs
        ])
        wait_task(task)
    else:
        logger.warning(f"No knowledge chunks found for knowledge_id {knowledge_id} to update.")
    

def unbind_knowledge_file(knowledge_id: str, setting_ids: list[str] = [], project_ids: list[str] = [], workset_ids: list[str] = []):
    """
    在索引中解绑知识文件的设置ID、项目ID和工作集ID
    """
    return
    knowledge_index = get_index(IndexType.KNOWLEDGE)
    res = knowledge_index.search("*", {"filter": f'knowledge_id = "{knowledge_id}"'})
    if "hits" in res and len(res['hits']) > 0:
        docs = res["hits"]
        task = knowledge_index.update_documents([
            {
                "id": doc["id"],
                "worksets": list(set(doc["workset_ids"])-set(workset_ids)),
                "settings": list(set(doc["setting_ids"])-set(setting_ids)),
                "projects": list(set(doc["project_ids"])-set(project_ids))
            }
            for doc in docs
        ])
        wait_task(task)
    else:
        logger.warning(f"No knowledge chunks found for knowledge_id {knowledge_id} to unbind.")


def index_action_record_attention(
        intent:str,
        summary: str,
        workset_ids: list[str],
        record: ToolCallRecord) -> ToolRecordChunk:
    """
    解析单个工具调用记录的摘要，转换为 ToolRecordChunk（摘要类型）。
    :param summary: 工具调用记录的摘要 127.0.0.1:7710
    :return: ToolRecordChunk 实例
    """
    return
    root_caller_info = record.rootCaller
    agent_caller_info = record.agentCaller
    # 构建工具版本信息
    tool_info = ToolVersionInfo(
        name_id=record.toolNameId or "",
        name=record.tool.name,
        version_id=record.toolVersionId or "",
        project_id=record.toolProjectId or "",
        type=record.tool.type
    )
    
    # 构建Agent信息
    agent_info = AgentInfo(
        id=record.agentCallerId or None,
        name_en=agent_caller_info.name_id if agent_caller_info else None,
        name=agent_caller_info.name if agent_caller_info else None,
        project_id=record.agentProjectId or None
    ) if agent_caller_info else None
    root_caller_info = UserInfo(
        id=record.rootUserId or None,
        username=record.rootCaller.username if record.rootCaller else None,
        email=record.rootCaller.email if record.rootCaller else None,
        firstname=record.rootCaller.first_name if record.rootCaller else None,
        lastname=record.rootCaller.last_name if record.rootCaller else None
    ) if root_caller_info else None
    chunks = []
    time_str = str(int(time.time()))
    for index, node in enumerate(string_chunking(summary)):
        chunk = ToolRecordChunk(
            id=f"{record.id}_{ChunkFieldType.ATTENTION.value}_{time_str}_{index}",
            type=ChunkFieldType.ATTENTION,  # 摘要类型
            tool_call_record_id=record.id,  # tool_call_record_id 就是记录本身的ID
            tool_info=tool_info,
            agent_info=agent_info,
            root_caller=root_caller_info,
            status=ToolCallStatus(record.status),
            intent=intent,  # 使用实际的 intent 字段
            chunk_sub_field_paths=[],
            chunk_index=index,  # 输出的索引为1
            content=node.get_content(),
            error=None,
            tags=[],
            workset_ids=workset_ids if workset_ids else [],
            message_action_ids=[],
            next_record_ids=[],
            pre_record_ids=[],
            metadata={},
            created_at=int(time_str),
            updated_at=int(time_str)
        )
        chunks.append(chunk)
    
    
    # 将chunk转为json并post至索引
    #获取工具记录索引
    tool_record_index = get_index(IndexType.ACTION)
    logger.debug(f"Indexing {[chunk.model_dump() for chunk in chunks]} attention chunks for ToolCallRecord ID {record.id}")
    #添加至索引
    task = tool_record_index.add_documents([chunk.model_dump() for chunk in chunks])
    wait_task(task)

    return chunks

def query_knowledge_record(prompt:str,setting_ids:List[str]=[],project_ids:List[str]=[],workset_ids:List[str]=[],top_k:int=5):
    """
    查询知识记录的工具。支持 Meilisearch 和 Manticore Search 两种后端
    """
    if USE_MANTICORE:
        from manticoresearch import Configuration, ApiClient
        from manticoresearch.api import search_api
        from manticoresearch.models.search_request import SearchRequest
        # Build Manticore filter/query
        table = getattr(settings, 'MANTICORE_KNOWLEDGE_INDEX', 'turboagent_knowledge')
        query_filters = []
        if setting_ids:
            query_filters.append({"equals": {"settings": setting_ids}})
        if project_ids:
            query_filters.append({"equals": {"projects": project_ids}})
        if workset_ids:
            query_filters.append({"equals": {"worksets": workset_ids}})
            knowledge_index = get_index(IndexType.KNOWLEDGE)
            options = {
                'limit': top_k,
            }
            if query_filters:
                options['filter'] = query_filters
            # Allow KNN semantic if requested via parameter (keeping parity with old 'hybrid')
            if prompt:
                options['knn'] = {
                    'var_field': 'content_vector',
                    'k': top_k
                }
            logger.info(f"Manticore unified search prompt={prompt} options={options}")
            res = knowledge_index.search(prompt, options)
            return res.get('hits', [])
    else:
        # Meilisearch with external embedder
        filters = []
        if setting_ids:
            filters.extend([f"settings = '{id}'" for id in setting_ids])
        if project_ids:
            filters.extend([f"projects = '{id}'" for id in project_ids])
        if workset_ids:
            filters.extend([f"worksets = '{id}'" for id in workset_ids])
        filter_str = " OR ".join(filters) if filters else ""
        options = {
            "hybrid": {
                "semanticRatio": 1,
                "embedder": "default"
            },
            "hitsPerPage": top_k,
            "filter": filter_str if filter_str else None
        }
        options = {k: v for k, v in options.items() if v is not None}
        logger.info(f"Querying knowledge with prompt: {prompt}, options: {options}")
        knowledge_index = get_index(IndexType.KNOWLEDGE)
        res = knowledge_index.search(prompt, options)
        logger.debug(f"Knowledge query response: {res}")
        if "hits" in res and len(res['hits']) > 0:
            docs = res["hits"]
            return docs
        else:
            return []

def index_action_record(
        record: ToolCallRecord,
        fieldtype: ChunkFieldType,
        tool_name: str,
        tool_type: ToolType,
        data_schema: dict|None =None
        ) -> ToolRecordChunk:
    """
    解析单个工具调用记录，转换为 ToolRecordChunk（输出类型）。
    :param record: ToolCallRecord 实例
    :param tool_version: ToolVersion 实例 (可选)
    :param tool: Tool 实例 (可选)
    :param root_caller_info: User 实例 (可选)
    :param agent_caller_info: Agent 实例 (可选)
    :return: ToolRecordChunk 实例
    """
    return
    root_caller_info = record.rootCaller
    agent_caller_info = record.agentCaller
    # 构建工具版本信息
    tool_info = ToolVersionInfo(
        name_id=record.toolNameId or "",
        name=tool_name,
        version_id=record.toolVersionId or "",
        project_id=record.toolProjectId or "",
        type=tool_type.value
    )
    
    # 构建Agent信息
    agent_info = AgentInfo(
        id=record.agentCallerId or None,
        name_en=agent_caller_info.name_id if agent_caller_info else None,
        name=agent_caller_info.name if agent_caller_info else None,
        project_id=record.agentProjectId or None
    ) if agent_caller_info else None
    root_caller_info = UserInfo(
        id=record.rootUserId or None,
        username=record.rootCaller.username if record.rootCaller else None,
        email=record.rootCaller.email if record.rootCaller else None,
        firstname=record.rootCaller.first_name if record.rootCaller else None,
        lastname=record.rootCaller.last_name if record.rootCaller else None
    ) if root_caller_info else None
    chunks = []
    if fieldtype == ChunkFieldType.OUTPUT:
        if record.error_message:
            chunk = ToolRecordChunk(
                id=f"{record.id}_{ChunkFieldType.ERROR.value}_0_0",
                type=ChunkFieldType.ERROR,  # 输出类型
                tool_call_record_id=record.id,  # tool_call_record_id 就是记录本身的ID
                tool_info=tool_info,
                agent_info=agent_info,
                root_caller=root_caller_info,
                status=ToolCallStatus(record.status),
                intent=record.intent or "",  # 使用实际的 intent 字段
                chunk_sub_field_paths=[],
                chunk_index=0,  
                content=None,
                error=json.dumps(record.error_message, ensure_ascii=False) if record.error_message else None,
                tags=[],  # ToolCallRecord 模型中没有 tags 字段
                workset_ids=[],  # 需要从 embeddedInWorksets 关系中获取
                message_action_ids=[],  # 需要从 relatedMessageAction 关系中获取
                next_record_ids=[],
                metadata={
                    "title": record.title,
                    "summary": record.summary,
                    "time_cost": record.time_cost,
                    "user_caller_id": record.userCallerId,
                },
                created_at=int(record.createdAt.timestamp()),
                updated_at=int(record.updatedAt.timestamp())
            )
            chunks = [chunk]
        else:
            data = record.result
            if not data_schema:
                raise ValueError("data_schema is required when indexing output records without error_message.")
            for index, node in enumerate(chunk_data_on_schema(data, data_schema)):
                chunk = ToolRecordChunk(
                    id=f"{record.id}_{ChunkFieldType.OUTPUT.value}_0_{index}",
                    type=ChunkFieldType.OUTPUT,  # 输出类型
                    tool_call_record_id=record.id,  # tool_call_record_id 就是记录本身的ID
                    tool_info=tool_info,
                    agent_info=agent_info,
                    root_caller=root_caller_info,
                    status=ToolCallStatus(record.status),
                    intent=record.intent or "",  # 使用实际的 intent 字段
                    chunk_sub_field_paths=[],
                    chunk_index=index,  # 输出的索引为1
                    content=node.get_content(),
                    error=json.dumps(record.error_message, ensure_ascii=False) if record.error_message else None,
                    tags=[],  # ToolCallRecord 模型中没有 tags 字段
                    workset_ids=[],  # 需要从 embeddedInWorksets 关系中获取
                    message_action_ids=[],  # 需要从 relatedMessageAction 关系中获取
                    next_record_ids=[],
                    pre_record_ids=[],
                    metadata={},
                    created_at=int(record.createdAt.timestamp()),
                    updated_at=int(record.updatedAt.timestamp())
                )
                chunks.append(chunk)
    elif fieldtype == ChunkFieldType.INPUT:
        data = record.input
        if not data_schema:
            raise ValueError("data_schema is required when indexing input records.")
        for index, node in enumerate(chunk_data_on_schema(data, data_schema)):
            chunk = ToolRecordChunk(
                id=f"{record.id}_{ChunkFieldType.INPUT.value}_0_{index}",
                type=ChunkFieldType.INPUT,  # 输入类型
                tool_call_record_id=record.id,  # tool_call_record_id 就是记录本身的ID
                tool_info=tool_info,
                agent_info=agent_info,
                root_caller=root_caller_info,
                status=ToolCallStatus(record.status),
                intent=record.intent or "",  # 使用实际的 intent 字段
                chunk_sub_field_paths=[],
                chunk_index=index,  # 输入的索引为0
                content=node.get_content(),
                error= None,
                tags=[],  # ToolCallRecord 模型中没有 tags 字段
                workset_ids=[],  # 需要从 embeddedInWorksets 关系中获取
                message_action_ids=[],  # 需要从 relatedMessageAction 关系中获取
                next_record_ids=[],
                pre_record_ids=[],
                metadata={},
                created_at=int(record.createdAt.timestamp()),
                updated_at=int(record.updatedAt.timestamp())
            )
            chunks.append(chunk)
    elif fieldtype == ChunkFieldType.ERROR:
        if record.error_message:
            chunk = ToolRecordChunk(
                id=f"{record.id}_{ChunkFieldType.ERROR.value}_0_0",
                type=ChunkFieldType.ERROR,  # 输出类型
                tool_call_record_id=record.id,  # tool_call_record_id 就是记录本身的ID
                tool_info=tool_info,
                agent_info=agent_info,
                root_caller=root_caller_info,
                status=ToolCallStatus(record.status),
                intent=record.intent or "",  # 使用实际的 intent 字段
                chunk_sub_field_paths=[],
                chunk_index=0,  
                content=None,
                error=json.dumps(record.error_message, ensure_ascii=False) if record.error_message else None,
                tags=[],  # ToolCallRecord 模型中没有 tags 字段
                workset_ids=[],  # 需要从 embeddedInWorksets 关系中获取
                message_action_ids=[],  # 需要从 relatedMessageAction 关系中获取
                next_record_ids=[],
                metadata={
                    "title": record.title,
                    "summary": record.summary,
                    "time_cost": record.time_cost,
                    "user_caller_id": record.userCallerId,
                },
                created_at=int(record.createdAt.timestamp()),
                updated_at=int(record.updatedAt.timestamp())
            )
            chunks = [chunk]
    #获取工具记录索引
    tool_record_index = get_index(IndexType.ACTION)
    logger.debug(f"Indexing {[chunk.model_dump() for chunk in chunks]} attention chunks for ToolCallRecord ID {record.id}")
    #添加至索引
    task = tool_record_index.add_documents([chunk.model_dump() for chunk in chunks])
    wait_task(task)
    return chunks

# ========== 统一搜索索引初始化 ========== #
def init_meilisearch_indices():
    """
    使用 initial_index 方法初始化 meilisearch 相关索引，如不存在则创建。
    保持向后兼容性的函数名
    """
    return init_search_indices()


def init_search_indices():
    """
    统一的搜索索引初始化方法，支持 Meilisearch 和 Manticore Search
    """
    backend_name = "Manticore Search" if USE_MANTICORE else "Meilisearch"
    logger.info(f"Initializing {backend_name} indices...")
    
    try:
        if USE_MANTICORE:
            # 验证 embedding 配置
            if not validate_embedding_configuration():
                logger.error("Cannot initialize Manticore Search - embedding configuration is invalid")
                return False
        
        # 初始化索引
        init_action_index()
        init_knowledge_index()
        
        logger.info(f"{backend_name} indices initialization completed successfully")
        return True
        
    except Exception as e:
        logger.error(f"Error initializing {backend_name} indices: {e}")
        return False


if __name__ == "__main__":
    # 初始化搜索索引（支持 Meilisearch 和 Manticore Search）
    success = init_search_indices()
    if success:
        print("✅ Search indices initialized successfully")
    else:
        print("❌ Search indices initialization failed")
