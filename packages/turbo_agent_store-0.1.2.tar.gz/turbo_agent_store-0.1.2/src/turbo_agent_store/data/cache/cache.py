"""
Memory Cache Store 实现

用途：运行时内存缓存，不持久化
场景：单测、调试、临时缓存
"""

from typing import Optional, Any, Dict
from datetime import datetime, timedelta

from turbo_agent_core.store.cache import BaseCacheStore


class InMemoryCacheStore(BaseCacheStore):
    """内存缓存实现（用于单测/调试/临时缓存）。
    
    说明：
    - 数据仅保存在内存中，进程重启后丢失
    - 支持 TTL 过期机制
    - 线程不安全（基于 asyncio 单线程假设）
    """
    
    def __init__(self):
        self._data: Dict[str, Any] = {}
        self._expires: Dict[str, Optional[datetime]] = {}
    
    async def get(self, key: str) -> Optional[Any]:
        """获取缓存值，如果过期则返回 None。"""
        expire_at = self._expires.get(key)
        if expire_at is not None and datetime.now() > expire_at:
            # 已过期，清理
            self._data.pop(key, None)
            self._expires.pop(key, None)
            return None
        return self._data.get(key)
    
    async def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        """设置缓存值，可选 TTL（秒）。"""
        self._data[key] = value
        if ttl is not None:
            self._expires[key] = datetime.now() + timedelta(seconds=ttl)
        else:
            self._expires[key] = None
    
    async def delete(self, key: str) -> None:
        """删除缓存值。"""
        self._data.pop(key, None)
        self._expires.pop(key, None)
    
    async def clear(self) -> None:
        """清空所有缓存（主要用于测试）。"""
        self._data.clear()
        self._expires.clear()
