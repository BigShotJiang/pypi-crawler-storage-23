"""
YAML Config Store 实现

用途：基于 core schema 的结构化导出/导入
场景：数据在不同业务线产品间的流转

注意：
- 不是持久化存储后端
- 用于配置导出、备份、跨系统迁移
- 保持与 core schema 的一致性
"""

import os
import yaml
from typing import Optional, List, Any, Dict
from pathlib import Path

from turbo_agent_core.store.config import BaseConfigStore
from turbo_agent_core.schema.agents import Agent, Tool, Character, LLMModel
from turbo_agent_core.schema.jobs import Job
from turbo_agent_core.schema.states import JobTask
from turbo_agent_core.schema.resources import Project, KnowledgeResource
from turbo_agent_core.schema.external import Platform, Secret
from turbo_agent_core.schema.basic import ModelInstance


class YAMLConfigStore(BaseConfigStore):
    """YAML 配置存储实现。
    
    用于将核心实体导出为 YAML 格式，实现：
    - 配置备份与恢复
    - 跨环境数据迁移
    - 版本控制友好的配置管理
    
    注意：此实现是单向导出导向的，不支持完整的 CRUD 操作。
    """
    
    def __init__(self, base_path: str):
        self.base_path = Path(base_path)
        self.base_path.mkdir(parents=True, exist_ok=True)
    
    def _get_path(self, entity_type: str, entity_id: str) -> Path:
        """获取实体文件路径。"""
        dir_path = self.base_path / entity_type
        dir_path.mkdir(exist_ok=True)
        return dir_path / f"{entity_id}.yaml"
    
    def _save_entity(self, entity: Any, entity_type: str, entity_id: str) -> str:
        """将实体保存为 YAML 文件。"""
        file_path = self._get_path(entity_type, entity_id)
        data = entity.model_dump(mode="json")
        with open(file_path, 'w', encoding='utf-8') as f:
            yaml.dump(data, f, allow_unicode=True, sort_keys=False)
        return str(file_path)
    
    async def get_agent(self, agent_id: str, version: Optional[str] = None, **kwargs) -> Optional[Agent]:
        """从 YAML 文件加载 Agent。"""
        file_path = self._get_path("agents", agent_id)
        if not file_path.exists():
            return None
        with open(file_path, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
        return Agent.model_validate(data)
    
    async def save_agent(self, agent: Agent, **kwargs) -> str:
        """将 Agent 保存为 YAML 文件。"""
        return self._save_entity(agent, "agents", agent.id)
    
    async def list_agents(self, skip: int = 0, limit: int = 20, **kwargs) -> List[Agent]:
        """列出所有已保存的 Agents。"""
        agents_dir = self.base_path / "agents"
        if not agents_dir.exists():
            return []
        agents = []
        for file_path in sorted(agents_dir.glob("*.yaml"))[skip:skip+limit]:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
            agents.append(Agent.model_validate(data))
        return agents
    
    async def delete_agent(self, agent_id: str, **kwargs) -> bool:
        """删除 Agent YAML 文件。"""
        file_path = self._get_path("agents", agent_id)
        if file_path.exists():
            file_path.unlink()
            return True
        return False
    
    async def get_tool(self, tool_id: str, version: Optional[str] = None, **kwargs) -> Optional[Tool]:
        file_path = self._get_path("tools", tool_id)
        if not file_path.exists():
            return None
        with open(file_path, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
        return Tool.model_validate(data)
    
    async def save_tool(self, tool: Tool, **kwargs) -> str:
        return self._save_entity(tool, "tools", tool.id)
    
    async def list_tools(self, skip: int = 0, limit: int = 20, **kwargs) -> List[Tool]:
        tools_dir = self.base_path / "tools"
        if not tools_dir.exists():
            return []
        tools = []
        for file_path in sorted(tools_dir.glob("*.yaml"))[skip:skip+limit]:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
            tools.append(Tool.model_validate(data))
        return tools
    
    async def delete_tool(self, tool_id: str, **kwargs) -> bool:
        file_path = self._get_path("tools", tool_id)
        if file_path.exists():
            file_path.unlink()
            return True
        return False
    
    async def get_character(self, character_id: str, version: Optional[str] = None, **kwargs) -> Optional[Character]:
        file_path = self._get_path("characters", character_id)
        if not file_path.exists():
            return None
        with open(file_path, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
        return Character.model_validate(data)
    
    async def save_character(self, character: Character, **kwargs) -> str:
        return self._save_entity(character, "characters", character.id)
    
    async def list_characters(self, skip: int = 0, limit: int = 20, **kwargs) -> List[Character]:
        chars_dir = self.base_path / "characters"
        if not chars_dir.exists():
            return []
        characters = []
        for file_path in sorted(chars_dir.glob("*.yaml"))[skip:skip+limit]:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
            characters.append(Character.model_validate(data))
        return characters
    
    async def delete_character(self, character_id: str, **kwargs) -> bool:
        file_path = self._get_path("characters", character_id)
        if file_path.exists():
            file_path.unlink()
            return True
        return False
    
    async def get_job(self, job_id: str, version: Optional[str] = None, **kwargs) -> Optional[Job]:
        file_path = self._get_path("jobs", job_id)
        if not file_path.exists():
            return None
        with open(file_path, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
        return Job.model_validate(data)
    
    async def save_job(self, job: Job, **kwargs) -> str:
        return self._save_entity(job, "jobs", job.id)
    
    async def list_jobs(self, skip: int = 0, limit: int = 20, **kwargs) -> List[Job]:
        jobs_dir = self.base_path / "jobs"
        if not jobs_dir.exists():
            return []
        jobs = []
        for file_path in sorted(jobs_dir.glob("*.yaml"))[skip:skip+limit]:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
            jobs.append(Job.model_validate(data))
        return jobs
    
    async def delete_job(self, job_id: str, **kwargs) -> bool:
        file_path = self._get_path("jobs", job_id)
        if file_path.exists():
            file_path.unlink()
            return True
        return False
    
    async def get_model(self, model_id: str, version: Optional[str] = None, **kwargs) -> Optional[LLMModel]:
        file_path = self._get_path("models", model_id)
        if not file_path.exists():
            return None
        with open(file_path, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
        return LLMModel.model_validate(data)
    
    async def save_model(self, model: LLMModel, **kwargs) -> str:
        return self._save_entity(model, "models", model.id)
    
    async def list_models(self, skip: int = 0, limit: int = 20, **kwargs) -> List[LLMModel]:
        models_dir = self.base_path / "models"
        if not models_dir.exists():
            return []
        models = []
        for file_path in sorted(models_dir.glob("*.yaml"))[skip:skip+limit]:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
            models.append(LLMModel.model_validate(data))
        return models
    
    async def delete_model(self, model_id: str, **kwargs) -> bool:
        file_path = self._get_path("models", model_id)
        if file_path.exists():
            file_path.unlink()
            return True
        return False
    
    async def get_platform(self, platform_id: str, **kwargs) -> Optional[Platform]:
        file_path = self._get_path("platforms", platform_id)
        if not file_path.exists():
            return None
        with open(file_path, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
        return Platform.model_validate(data)
    
    async def save_platform(self, platform: Platform, **kwargs) -> str:
        return self._save_entity(platform, "platforms", platform.id)
    
    async def list_platforms(self, skip: int = 0, limit: int = 20, **kwargs) -> List[Platform]:
        platforms_dir = self.base_path / "platforms"
        if not platforms_dir.exists():
            return []
        platforms = []
        for file_path in sorted(platforms_dir.glob("*.yaml"))[skip:skip+limit]:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
            platforms.append(Platform.model_validate(data))
        return platforms
    
    async def delete_platform(self, platform_id: str, **kwargs) -> bool:
        file_path = self._get_path("platforms", platform_id)
        if file_path.exists():
            file_path.unlink()
            return True
        return False
    
    # ===== 以下方法暂不实现（需要业务 DTOs）=====
    
    async def get_project(self, project_id: str, **kwargs) -> Optional[Project]:
        raise NotImplementedError("YAMLConfigStore 不支持 Project 存储")
    
    async def get_job_task(self, task_id: str, **kwargs) -> Optional[JobTask]:
        raise NotImplementedError("YAMLConfigStore 不支持 JobTask 存储")
    
    async def save_job_task(self, task: JobTask, **kwargs) -> str:
        raise NotImplementedError("YAMLConfigStore 不支持 JobTask 存储")
    
    async def list_job_tasks(self, job_id: Optional[str] = None, status: Optional[str] = None, skip: int = 0, limit: int = 20, **kwargs) -> List[JobTask]:
        raise NotImplementedError("YAMLConfigStore 不支持 JobTask 存储")
    
    async def find_job_task(self, job_id: str, expected_start_time: Any, **kwargs) -> Optional[JobTask]:
        raise NotImplementedError("YAMLConfigStore 不支持 JobTask 存储")
    
    async def list_due_job_tasks(self, limit: int = 50, **kwargs) -> List[JobTask]:
        raise NotImplementedError("YAMLConfigStore 不支持 JobTask 存储")
    
    async def update_job_task_status(self, task_id: str, status: str, **kwargs) -> bool:
        raise NotImplementedError("YAMLConfigStore 不支持 JobTask 存储")
    
    async def save_model_instance(self, instance: ModelInstance, model_id: str, **kwargs) -> str:
        raise NotImplementedError("YAMLConfigStore 不支持 ModelInstance 存储")
    
    async def delete_model_instance(self, instance_id: str, **kwargs) -> bool:
        raise NotImplementedError("YAMLConfigStore 不支持 ModelInstance 存储")
    
    async def get_secret(self, secret_id: str, **kwargs) -> Optional[Secret]:
        raise NotImplementedError("YAMLConfigStore 不支持 Secret 存储")
    
    async def save_secret(self, secret: Secret, **kwargs) -> str:
        raise NotImplementedError("YAMLConfigStore 不支持 Secret 存储")
    
    async def list_secrets(self, platform_id: Optional[str] = None, skip: int = 0, limit: int = 20, **kwargs) -> List[Secret]:
        raise NotImplementedError("YAMLConfigStore 不支持 Secret 存储")
    
    async def delete_secret(self, secret_id: str, **kwargs) -> bool:
        raise NotImplementedError("YAMLConfigStore 不支持 Secret 存储")
    
    async def get_knowledge_resource(self, resource_id: str, **kwargs) -> Optional[KnowledgeResource]:
        raise NotImplementedError("YAMLConfigStore 不支持 KnowledgeResource 存储")
    
    async def save_knowledge_resource(self, resource: KnowledgeResource, **kwargs) -> str:
        raise NotImplementedError("YAMLConfigStore 不支持 KnowledgeResource 存储")
    
    async def list_knowledge_resources(self, project_id: Optional[str] = None, skip: int = 0, limit: int = 20, **kwargs) -> List[KnowledgeResource]:
        raise NotImplementedError("YAMLConfigStore 不支持 KnowledgeResource 存储")
    
    async def delete_knowledge_resource(self, resource_id: str, **kwargs) -> bool:
        raise NotImplementedError("YAMLConfigStore 不支持 KnowledgeResource 存储")
