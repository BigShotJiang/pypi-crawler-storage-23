"""
YAML 实现层

用于基于 core schema 的结构化导出/导入。
适用于：
- 配置备份与恢复
- 跨环境数据迁移
- 版本控制友好的配置管理

注意：不是持久化存储后端，而是数据流转格式。
"""

from .config import YAMLConfigStore

__all__ = ["YAMLConfigStore"]
