"""
Worker 环境构建器

负责为 Worker 准备执行环境，包括：
1. 创建工作目录
2. 下载 KnowledgeResource 文件（只读）
3. 检出 Workspace 文件（可读写）
4. 生成环境配置

使用场景：
- Job Worker 执行任务前准备环境
- CharacterRuntime 初始化
"""

import json
import shutil
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Optional, Callable, Dict

from turbo_agent_core.store.resource import ResourceStore
from turbo_agent_core.store.workspace import WorkspaceStore


@dataclass
class ResourceRef:
    """资源文件引用"""
    resource_id: str
    user_id: str
    context_id: str
    filename: str
    path: str  # 存储路径


@dataclass
class WorkspaceRef:
    """工作区引用"""
    workspace_id: str
    user_id: str
    ref: str = "HEAD"  # 版本引用
    files: Optional[List[str]] = None  # 指定文件，None 表示全部


@dataclass
class WorkerEnvironment:
    """
    Worker 执行环境。
    
    目录结构:
        {base_path}/
        ├── resources/           # KnowledgeResource 文件（只读）
        │   └── {resource_id}/
        │       └── {filename}
        ├── workspace/           # Workspace 文件（可读写）
        │   ├── .git/            # Git 版本控制
        │   └── files/           # 工作文件
        │       ├── main.py
        │       └── config.yaml
        ├── output/              # 输出目录
        └── manifest.json        # 环境清单
    """
    task_id: str
    base_path: Path
    resources_path: Path
    workspace_path: Path
    output_path: Path
    manifest: dict
    
    def __post_init__(self):
        # 确保目录存在
        self.resources_path.mkdir(parents=True, exist_ok=True)
        self.workspace_path.mkdir(parents=True, exist_ok=True)
        self.output_path.mkdir(parents=True, exist_ok=True)
    
    def to_dict(self) -> dict:
        """转换为字典。"""
        return {
            "task_id": self.task_id,
            "base_path": str(self.base_path),
            "resources_path": str(self.resources_path),
            "workspace_path": str(self.workspace_path),
            "output_path": str(self.output_path),
            "manifest": self.manifest
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "WorkerEnvironment":
        """从字典创建。"""
        return cls(
            task_id=data["task_id"],
            base_path=Path(data["base_path"]),
            resources_path=Path(data["resources_path"]),
            workspace_path=Path(data["workspace_path"]),
            output_path=Path(data["output_path"]),
            manifest=data["manifest"]
        )


class WorkerEnvironmentBuilder:
    """
    Worker 环境构建器。
    
    负责准备和清理 Worker 执行环境。
    
    Example:
        >>> builder = WorkerEnvironmentBuilder(
        ...     resource_store=LocalResourceStore(),
        ...     workspace_store_factory=lambda wid, uid: LocalGitWorkspaceStore(wid, uid)
        ... )
        >>> 
        >>> # 准备环境
        >>> env = await builder.prepare(
        ...     task_id="task_001",
        ...     resource_refs=[ResourceRef(...)],
        ...     workspace_ref=WorkspaceRef(...)
        ... )
        >>> 
        >>> # 使用环境执行...
        >>> 
        >>> # 清理环境
        >>> await builder.cleanup(env)
    """
    
    def __init__(
        self,
        resource_store: ResourceStore,
        workspace_store_factory: Callable[[str, str], WorkspaceStore],
        base_path: str = "/tmp/turbo_agent/worker_envs",
        keep_resources: bool = False  # 是否保留资源目录用于调试
    ):
        """
        Args:
            resource_store: 资源存储（用于下载 KnowledgeResource）
            workspace_store_factory: 工作区存储工厂函数
            base_path: 基础工作目录
            keep_resources: 调试模式：保留资源不删除
        """
        self.resource_store = resource_store
        self.workspace_store_factory = workspace_store_factory
        self.base_path = Path(base_path)
        self.keep_resources = keep_resources
    
    async def prepare(
        self,
        task_id: str,
        resource_refs: List[ResourceRef],
        workspace_ref: Optional[WorkspaceRef] = None,
        extra_config: Optional[dict] = None
    ) -> WorkerEnvironment:
        """
        准备 Worker 执行环境。
        
        Args:
            task_id: 任务ID
            resource_refs: 资源文件引用列表
            workspace_ref: 工作区引用（可选）
            extra_config: 额外配置（写入 manifest）
            
        Returns:
            WorkerEnvironment 实例
        """
        # 1. 创建工作目录
        work_dir = self.base_path / task_id
        work_dir.mkdir(parents=True, exist_ok=True)
        
        resources_path = work_dir / "resources"
        workspace_path = work_dir / "workspace"
        output_path = work_dir / "output"
        
        # 2. 下载资源文件（KnowledgeResource - 只读）
        downloaded_resources = []
        for ref in resource_refs:
            try:
                # 下载文件
                data = await self.resource_store.download(ref.path)
                
                # 保存到 resources 目录
                resource_dir = resources_path / ref.resource_id
                resource_dir.mkdir(parents=True, exist_ok=True)
                
                file_path = resource_dir / ref.filename
                file_path.write_bytes(data)
                
                downloaded_resources.append({
                    "resource_id": ref.resource_id,
                    "filename": ref.filename,
                    "path": str(file_path.relative_to(work_dir)),
                    "size": len(data)
                })
            except Exception as e:
                # 记录错误但继续处理其他资源
                downloaded_resources.append({
                    "resource_id": ref.resource_id,
                    "filename": ref.filename,
                    "error": str(e)
                })
        
        # 3. 检出工作区文件（Workspace - 可读写）
        workspace_files = []
        if workspace_ref:
            workspace_store = self.workspace_store_factory(
                workspace_ref.workspace_id,
                workspace_ref.user_id
            )
            
            # 检出指定文件或全部
            if workspace_ref.files:
                for file_path in workspace_ref.files:
                    try:
                        content = await workspace_store.read_file(
                            file_path,
                            ref=workspace_ref.ref
                        )
                        
                        # 保存到 workspace 目录
                        target_path = workspace_path / "files" / file_path
                        target_path.parent.mkdir(parents=True, exist_ok=True)
                        target_path.write_bytes(content)
                        
                        workspace_files.append({
                            "path": file_path,
                            "size": len(content),
                            "ref": workspace_ref.ref
                        })
                    except Exception as e:
                        workspace_files.append({
                            "path": file_path,
                            "error": str(e),
                            "ref": workspace_ref.ref
                        })
            else:
                # 检出所有文件
                files = await workspace_store.list_files(
                    path="",
                    ref=workspace_ref.ref,
                    recursive=True
                )
                
                for file_info in files:
                    if not file_info.is_file:
                        continue
                    
                    try:
                        content = await workspace_store.read_file(
                            file_info.path,
                            ref=workspace_ref.ref
                        )
                        
                        target_path = workspace_path / "files" / file_info.path
                        target_path.parent.mkdir(parents=True, exist_ok=True)
                        target_path.write_bytes(content)
                        
                        workspace_files.append({
                            "path": file_info.path,
                            "size": len(content),
                            "ref": workspace_ref.ref
                        })
                    except Exception as e:
                        workspace_files.append({
                            "path": file_info.path,
                            "error": str(e),
                            "ref": workspace_ref.ref
                        })
        
        # 4. 生成 manifest
        manifest = {
            "task_id": task_id,
            "resources": downloaded_resources,
            "workspace": {
                "workspace_id": workspace_ref.workspace_id if workspace_ref else None,
                "user_id": workspace_ref.user_id if workspace_ref else None,
                "ref": workspace_ref.ref if workspace_ref else None,
                "files": workspace_files
            },
            "config": extra_config or {}
        }
        
        # 写入 manifest.json
        manifest_path = work_dir / "manifest.json"
        manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
        
        # 5. 创建环境变量文件
        env_path = work_dir / ".env"
        env_content = self._generate_env_file(manifest)
        env_path.write_text(env_content, encoding="utf-8")
        
        return WorkerEnvironment(
            task_id=task_id,
            base_path=work_dir,
            resources_path=resources_path,
            workspace_path=workspace_path / "files",
            output_path=output_path,
            manifest=manifest
        )
    
    def _generate_env_file(self, manifest: dict) -> str:
        """生成环境变量文件。"""
        lines = [
            "# Worker Environment Variables",
            f"TASK_ID={manifest['task_id']}",
            f"RESOURCES_PATH=./resources",
            f"WORKSPACE_PATH=./workspace/files",
            f"OUTPUT_PATH=./output",
            ""
        ]
        
        # 添加资源路径变量
        if manifest["resources"]:
            lines.append("# Resource files")
            for res in manifest["resources"]:
                if "error" not in res:
                    var_name = f"RESOURCE_{res['resource_id'].upper()}"
                    lines.append(f'{var_name}={res["path"]}')
            lines.append("")
        
        return "\n".join(lines)
    
    async def cleanup(self, env: WorkerEnvironment, keep: bool = False):
        """
        清理 Worker 环境。
        
        Args:
            env: WorkerEnvironment 实例
            keep: 是否保留目录（用于调试）
        """
        if keep or self.keep_resources:
            return
        
        if env.base_path.exists():
            shutil.rmtree(env.base_path)
    
    async def archive_output(
        self,
        env: WorkerEnvironment,
        workspace_store: Optional[WorkspaceStore] = None
    ) -> dict:
        """
        归档输出文件。
        
        将 output/ 目录的内容提交到 Workspace（如果提供了 workspace_store）。
        
        Args:
            env: WorkerEnvironment 实例
            workspace_store: 用于提交输出的工作区存储
            
        Returns:
            归档结果
        """
        result = {
            "archived": False,
            "files": [],
            "commit_hash": None
        }
        
        if not env.output_path.exists():
            return result
        
        # 收集输出文件
        output_files = []
        for file_path in env.output_path.rglob("*"):
            if file_path.is_file():
                rel_path = str(file_path.relative_to(env.output_path))
                output_files.append({
                    "path": rel_path,
                    "size": file_path.stat().st_size
                })
        
        result["files"] = output_files
        
        # 提交到 Workspace
        if workspace_store and output_files:
            # 复制输出文件到 workspace
            for file_info in output_files:
                src_path = env.output_path / file_info["path"]
                
                # 保存到 output/ 子目录
                content = src_path.read_bytes()
                await workspace_store.write_file(
                    path=f"output/{file_info['path']}",
                    content=content,
                    commit_msg=f"Worker output: {file_info['path']}"
                )
            
            # 统一提交
            commit_hash = await workspace_store.commit(
                message=f"Archive worker output for task {env.task_id}",
                files=[f"output/{f['path']}" for f in output_files]
            )
            
            result["archived"] = True
            result["commit_hash"] = commit_hash
        
        return result


class WorkerEnvironmentContext:
    """
    Worker 环境上下文管理器。
    
    使用 async with 语法自动管理环境生命周期。
    
    Example:
        >>> async with WorkerEnvironmentContext(builder, task_spec) as env:
        ...     # 环境已准备好
        ...     result = await runtime.execute(env)
        ... # 环境自动清理
    """
    
    def __init__(
        self,
        builder: WorkerEnvironmentBuilder,
        task_id: str,
        resource_refs: List[ResourceRef],
        workspace_ref: Optional[WorkspaceRef] = None,
        extra_config: Optional[dict] = None,
        keep: bool = False
    ):
        self.builder = builder
        self.task_id = task_id
        self.resource_refs = resource_refs
        self.workspace_ref = workspace_ref
        self.extra_config = extra_config
        self.keep = keep
        self.env: Optional[WorkerEnvironment] = None
    
    async def __aenter__(self) -> WorkerEnvironment:
        self.env = await self.builder.prepare(
            task_id=self.task_id,
            resource_refs=self.resource_refs,
            workspace_ref=self.workspace_ref,
            extra_config=self.extra_config
        )
        return self.env
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.env:
            await self.builder.cleanup(self.env, keep=self.keep)
