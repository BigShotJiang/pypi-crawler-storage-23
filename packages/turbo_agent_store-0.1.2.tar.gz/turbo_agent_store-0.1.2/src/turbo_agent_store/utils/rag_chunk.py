import jieba
from llama_index.core.node_parser.text.token import TokenTextSplitter
from llama_index.core.node_parser import (
    SentenceSplitter,
    SemanticSplitterNodeParser,
)
from llama_index.core.schema import Document,BaseNode, TextNode, MetadataMode
from llama_index.embeddings.openai import OpenAIEmbedding
from typing import List
import os
import time
from turbo_agent_store.settings import settings
from loguru import logger


def jieba_tokenizer(text):
    return list(jieba.cut(text))

def large_node_chunk(content:str,chunklimit:int=3000,overlap:int=100,depth=0) -> List[TextNode]:
    # Initialize the embedding model
    embed_model = OpenAIEmbedding(
        api_key=settings.CHUNCK_MODEL_API_KEY,
        api_base=settings.CHUNCK_MODEL_API_URL,
        model_name=settings.CHUNCK_MODEL,
        embed_batch_size=16,
    )
    chinese_token_splitter = TokenTextSplitter(
        chunk_size=500,
        chunk_overlap=overlap,
        separator="\n",
        backup_separators=["\n", "。", "？", "！",  ". ", "?", "!"],
        tokenizer=jieba_tokenizer,
        keep_whitespaces=True
    )
    document = Document(text=content, metadata={})
    splitter = SemanticSplitterNodeParser(
        buffer_size=0, breakpoint_percentile_threshold=70, embed_model=embed_model,sentence_splitter=chinese_token_splitter.split_text,
    )
    nodes = splitter.get_nodes_from_documents([document])
    final_nodes = []
    for node  in nodes:
        logger.debug(f"  large_node_chunk level n : {len(node.get_content())}")
        if len(node.get_content()) >chunklimit and depth <3:
            temp_nodes = large_node_chunk(node.get_content(),overlap=overlap,depth=depth+1)
            for i, n in enumerate(temp_nodes):
                logger.debug(f"  large_node_chunk level n+1-{i}: {len(n.get_content())}")
            final_nodes += temp_nodes
        else:
            final_nodes.append(node)
    return final_nodes


def chunk_data_on_schema(data: dict, data_schema: dict) -> List[BaseNode]:
    """
    基于给定的data schema深度遍历数据，按照 key + key的含义 + data值 的方式进行拼接。
    :param data: 数据实例
    :param data_schema: 数据的JSON schema
    :return: BaseNode 列表
    """
    def extract_all_values(obj, schema, path="", parent_desc=""):
        """
        递归遍历数据对象，提取所有字段的值并格式化为 key + 含义 + 值 的形式
        :param obj: 当前遍历的数据对象
        :param schema: 当前对象对应的schema
        :param path: 当前属性路径
        :param parent_desc: 父级描述
        :return: 提取的字符串列表
        """
        extracted_strings = []
        
        if not isinstance(schema, dict):
            return extracted_strings
            
        # 处理对象类型
        if isinstance(obj, dict) and schema.get("type") == "object":
            properties = schema.get("properties", {})
            for key, value in obj.items():
                if key in properties:
                    prop_schema = properties[key]
                    current_path = f"{path}.{key}" if path else key
                    key_desc = prop_schema.get("description", key)
                    
                    # 处理基本类型：string, integer, number, boolean
                    if prop_schema.get("type") in ["string", "integer", "number", "boolean"]:
                        if value is not None:
                            extracted_strings.append(f"{key}({key_desc}): {value}")
                    
                    # 处理enum类型
                    elif "enum" in prop_schema:
                        if value is not None:
                            extracted_strings.append(f"{key}({key_desc}): {value}")
                    
                    # 递归处理对象类型
                    elif prop_schema.get("type") == "object":
                        if isinstance(value, dict):
                            # 添加对象的标题
                            extracted_strings.append(f"=== {key}({key_desc}) ===")
                            extracted_strings.extend(
                                extract_all_values(value, prop_schema, current_path, key_desc)
                            )
                    # 递归处理数组类型
                    elif prop_schema.get("type") == "array":
                        if isinstance(value, list) and len(value) > 0:
                            # 添加数组的标题
                            extracted_strings.append(f"=== {key}({key_desc}) ===")
                            extracted_strings.extend(
                                extract_all_values(value, prop_schema, current_path, key_desc)
                            )
        # 处理数组类型
        elif isinstance(obj, list) and schema.get("type") == "array":
            items_schema = schema.get("items", {})
            for idx, item in enumerate(obj):
                current_path = f"{path}[{idx}]" if path else f"[{idx}]"
                
                # 处理数组元素为基本类型
                if items_schema.get("type") in ["string", "integer", "number", "boolean"]:
                    if item is not None:
                        extracted_strings.append(f"第{idx+1}项: {item}")
                
                # 处理数组元素为enum类型
                elif "enum" in items_schema:
                    if item is not None:
                        extracted_strings.append(f"第{idx+1}项: {item}")
                
                # 递归处理数组元素为对象类型
                elif items_schema.get("type") == "object":
                    if isinstance(item, dict):
                        extracted_strings.append(f"--- 第{idx+1}项 ---")
                        extracted_strings.extend(
                            extract_all_values(item, items_schema, current_path, f"{parent_desc}第{idx+1}项")
                        )
                
                # 递归处理嵌套数组
                elif items_schema.get("type") == "array":
                    if isinstance(item, list):
                        extracted_strings.append(f"--- 第{idx+1}项 ---")
                        extracted_strings.extend(
                            extract_all_values(item, items_schema, current_path, f"{parent_desc}第{idx+1}项")
                        )
        
        return extracted_strings
    
    # 提取所有字段的值
    extracted_values = extract_all_values(data, data_schema)
    
    # 将提取的值组合成最终字符串
    final_content = "\n".join(extracted_values)
    
    # 根据长度决定是否进行分块
    if len(final_content) > 4000:
        logger.info(f"Content length {len(final_content)} > 4000, using string_chunking")
        return string_chunking(final_content)
    else:
        logger.info(f"Content length {len(final_content)} <= 4000, creating single BaseNode")
        # 创建单个BaseNode
        node = TextNode(
            text=final_content,
            metadata={
                "content_length": len(final_content),
                "chunk_type": "single_node",
                "extracted_fields_count": len(extracted_values)
            }
        )
        return [node]

def string_chunking(file_content:str, chunk_limit:int=4000) -> List[BaseNode]:
    """
    对字符串进行分块处理
    :param file_content: 文件内容
    :param chunk_limit: 每个块的大小限制
    :return: BaseNode 列表
    """
    start_time = time.time()  
    documents = [Document(text=file_content, metadata={})]
    embed_model = OpenAIEmbedding(
        api_key=settings.CHUNCK_MODEL_API_KEY,
        api_base=settings.CHUNCK_MODEL_API_URL,
        model_name=settings.CHUNCK_MODEL,
        embed_batch_size=16,
    )
    chinese_token_splitter = TokenTextSplitter(
        chunk_size=1000,
        chunk_overlap=100,
        separator="\n",
        backup_separators=["\n", "。", "？", "！",  ". ", "?", "!"],
        tokenizer=jieba_tokenizer,
    )
    splitter = SemanticSplitterNodeParser(
        buffer_size=0, breakpoint_percentile_threshold=80, embed_model=embed_model,sentence_splitter=chinese_token_splitter.split_text,
    )
    nodes = splitter.get_nodes_from_documents(documents)
    final_nodes = []
    for idx,node in enumerate(nodes):
        logger.debug(f"level1: {len(node.get_content())}")
        if len(node.get_content()) >chunk_limit:
            temp_nodes = large_node_chunk(node.get_content())
            for i, n in enumerate(temp_nodes):
                logger.debug(f"level2-{i}: {len(n.get_content())}")
            final_nodes += temp_nodes
        else:
            final_nodes.append(node)
    end_time = time.time()  # End the timer
    logger.info(f"string Total chunking time: {end_time - start_time:.2f} seconds, final node length:{len(final_nodes)}")

    return final_nodes

def document_chunking(file_path:str, chunk_limit:int=4000, overlap:int=100) -> List[BaseNode]:
    start_time = time.time()  # Start the timer

    with open(file_path, "r", encoding="utf-8") as f:
        md_content = f.read()
        # logger.info(f"Document {file_path} converted, text length: {md_content}")
    documents = []
    document = Document(text=md_content, metadata={"source": file_path, "file_name": os.path.basename(file_path)})
    documents.append(document)
    # Initialize the embedding model
    embed_model = OpenAIEmbedding(
        api_key=settings.CHUNCK_MODEL_API_KEY,
        api_base=settings.CHUNCK_MODEL_API_URL,
        model_name=settings.CHUNCK_MODEL,
        embed_batch_size=16,
    )
    chinese_token_splitter = TokenTextSplitter(
        chunk_size=1000,
        chunk_overlap=overlap,
        separator="\n",
        backup_separators=["\n", "。", "？", "！",  ". ", "?", "!"],
        tokenizer=jieba_tokenizer,
        keep_whitespaces=True
    )
    splitter = SemanticSplitterNodeParser(
        buffer_size=0, breakpoint_percentile_threshold=80, embed_model=embed_model,sentence_splitter=chinese_token_splitter.split_text,
    )
    nodes = splitter.get_nodes_from_documents(documents)
    final_nodes = []
    for idx,node in enumerate(nodes):
        logger.debug(f"level1: {len(node.get_content())}")
        if len(node.get_content()) >chunk_limit:
            temp_nodes = large_node_chunk(node.get_content(),overlap=0)
            for i, n in enumerate(temp_nodes):
                logger.debug(f"level2-{i}: {len(n.get_content())}")
            final_nodes += temp_nodes
        else:
            final_nodes.append(node)
    end_time = time.time()  # End the timer
    logger.info(f"{file_path} Total chunking time: {end_time - start_time:.2f} seconds, final node length:{len(final_nodes)}")

    return final_nodes

if __name__ == "__main__":
    # 复杂的嵌套数据结构示例
    complex_schema = {
        "type": "object",
        "properties": {
            "tool_name": {"type": "string", "description": "工具名称"},
            "tool_type": {"enum": ["api", "function", "service"], "description": "工具类型"},
            "status": {"enum": ["success", "failed", "pending"], "description": "执行状态"},
            "created_at": {"type": "integer", "description": "创建时间戳"},
            "execution_time": {"type": "number", "description": "执行耗时"},
            "description": {"type": "string", "description": "详细描述"},
            "metadata": {
                "type": "object",
                "description": "元数据信息",
                "properties": {
                    "version": {"type": "string", "description": "版本号"},
                    "environment": {"enum": ["dev", "test", "prod"], "description": "运行环境"},
                    "config": {
                        "type": "object",
                        "description": "配置信息",
                        "properties": {
                            "timeout": {"type": "integer", "description": "超时时间"},
                            "retry_count": {"type": "integer", "description": "重试次数"},
                            "debug_mode": {"type": "boolean", "description": "调试模式"}
                        }
                    }
                }
            },
            "execution_records": {
                "type": "array",
                "description": "执行记录",
                "items": {
                    "type": "object",
                    "properties": {
                        "record_id": {"type": "string", "description": "记录ID"},
                        "timestamp": {"type": "integer", "description": "执行时间"},
                        "status": {"enum": ["started", "running", "completed", "failed"], "description": "记录状态"},
                        "input_data": {"type": "string", "description": "输入数据"},
                        "output_data": {"type": "string", "description": "输出数据"},
                        "error_message": {"type": "string", "description": "错误信息"},
                        "performance_metrics": {
                            "type": "object",
                            "description": "性能指标",
                            "properties": {
                                "cpu_usage": {"type": "number", "description": "CPU使用率"},
                                "memory_usage": {"type": "number", "description": "内存使用率"},
                                "duration_ms": {"type": "integer", "description": "执行时长毫秒"}
                            }
                        },
                        "tags": {
                            "type": "array",
                            "description": "标签列表",
                            "items": {"type": "string"}
                        },
                        "sub_tasks": {
                            "type": "array",
                            "description": "子任务",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "task_name": {"type": "string", "description": "任务名称"},
                                    "task_type": {"enum": ["preprocessing", "processing", "postprocessing"], "description": "任务类型"},
                                    "result": {"type": "string", "description": "任务结果"},
                                    "details": {"type": "string", "description": "详细信息"}
                                }
                            }
                        }
                    }
                }
            },
            "user_feedback": {
                "type": "array",
                "description": "用户反馈",
                "items": {
                    "type": "object",
                    "properties": {
                        "feedback_id": {"type": "string", "description": "反馈ID"},
                        "user_id": {"type": "string", "description": "用户ID"},
                        "rating": {"enum": ["excellent", "good", "fair", "poor"], "description": "评分"},
                        "comment": {"type": "string", "description": "评论内容"},
                        "suggestions": {
                            "type": "array",
                            "description": "改进建议",
                            "items": {"type": "string"}
                        }
                    }
                }
            }
        }
    }
    
    complex_data = {
        "tool_name": "智能数据分析工具",
        "tool_type": "api",
        "status": "success",
        "created_at": 1672531200,
        "execution_time": 45.67,
        "description": "这是一个功能强大的数据分析工具，能够处理大规模数据集，提供实时分析能力，支持多种数据格式包括CSV、JSON、XML等。该工具采用先进的机器学习算法，能够自动识别数据模式，生成可视化报表，并提供预测分析功能。工具具有高度可配置性，用户可以根据具体需求调整分析参数，设置数据过滤条件，自定义输出格式。",
        "metadata": {
            "version": "2.1.3",
            "environment": "prod",
            "config": {
                "timeout": 30000,
                "retry_count": 3,
                "debug_mode": False
            }
        },
        "execution_records": [
            {
                "record_id": "exec_001",
                "timestamp": 1672531250,
                "status": "completed",
                "input_data": "包含10万条用户行为数据的大型数据集，字段包括用户ID、行为类型、时间戳、设备信息、地理位置等详细信息。数据覆盖了过去6个月的用户活动轨迹，为分析用户行为模式提供了丰富的基础数据。",
                "output_data": "生成了详细的用户行为分析报告，包括用户活跃度趋势图、热点功能使用统计、用户留存率分析、设备分布情况、地域使用特征等多维度分析结果。报告显示用户活跃度在周末达到峰值，移动端使用占比达到78%，一线城市用户占总用户数的45%。",
                "error_message": "",
                "performance_metrics": {
                    "cpu_usage": 65.2,
                    "memory_usage": 78.9,
                    "duration_ms": 45670
                },
                "tags": ["数据分析", "用户行为", "统计报告", "性能优化"],
                "sub_tasks": [
                    {
                        "task_name": "数据预处理",
                        "task_type": "preprocessing", 
                        "result": "数据清洗完成，去除无效记录1250条，标准化时间格式，统一编码方式",
                        "details": "对原始数据进行了全面的预处理操作，包括缺失值填充、异常值检测、数据类型转换、重复记录去除等步骤，确保数据质量满足分析要求。"
                    },
                    {
                        "task_name": "特征工程",
                        "task_type": "processing",
                        "result": "提取关键特征300个，构建用户画像模型",
                        "details": "基于用户行为数据提取了多维度特征，包括时间特征、频次特征、偏好特征等，并使用主成分分析降维，构建了用户行为画像模型。"
                    },
                    {
                        "task_name": "结果可视化",
                        "task_type": "postprocessing",
                        "result": "生成交互式图表15个，包括趋势图、热力图、散点图等",
                        "details": "使用先进的可视化技术生成了多种类型的图表，支持交互式操作，用户可以通过筛选、缩放等方式深入探索数据。"
                    }
                ]
            },
            {
                "record_id": "exec_002", 
                "timestamp": 1672531800,
                "status": "failed",
                "input_data": "包含异常格式的CSV文件，部分字段存在编码问题",
                "output_data": "",
                "error_message": "数据格式解析失败：检测到非UTF-8编码字符，第1245行存在格式错误，建议检查数据源并重新上传",
                "performance_metrics": {
                    "cpu_usage": 25.1,
                    "memory_usage": 32.4,
                    "duration_ms": 8950
                },
                "tags": ["错误处理", "数据格式", "编码问题"],
                "sub_tasks": [
                    {
                        "task_name": "格式验证",
                        "task_type": "preprocessing",
                        "result": "发现格式错误，终止处理",
                        "details": "在数据预处理阶段检测到文件格式不符合规范，存在编码问题和结构异常，为保证数据质量，系统自动终止了处理流程。"
                    }
                ]
            }
        ],
        "user_feedback": [
            {
                "feedback_id": "fb_001",
                "user_id": "user_12345", 
                "rating": "excellent",
                "comment": "工具非常好用，分析结果准确，可视化效果优秀。处理速度比预期快很多，生成的报告格式专业，内容详实。特别喜欢交互式图表功能，可以灵活查看不同维度的数据。希望能增加更多的图表类型和自定义选项。",
                "suggestions": ["增加更多图表类型", "支持自定义报告模板", "添加数据导出功能", "优化移动端显示效果"]
            },
            {
                "feedback_id": "fb_002",
                "user_id": "user_67890",
                "rating": "good", 
                "comment": "整体使用体验不错，功能丰富，操作相对简单。分析结果基本符合预期，可视化图表清晰易懂。不过在处理大数据量时偶尔会出现卡顿现象，希望能进一步优化性能。",
                "suggestions": ["提升大数据处理性能", "增加进度提示", "优化用户界面"]
            }
        ]
    }
    
    # 测试复杂数据结构的分块处理
    logger.info("开始测试复杂数据结构的分块处理...")
    nodes = chunk_data_on_schema(complex_data, complex_schema)
    logger.info(f"生成的节点数量: {len(nodes)}")
    
    for idx, node in enumerate(nodes):
        content = node.get_content()
        logger.info(f"节点 {idx+1} 长度: {len(content)}")
        logger.info(f"节点 {idx+1} 内容预览: {content[:200]}...")
        logger.info("=" * 50)
    
    # 原有的文档分块测试（注释掉）
    # nodes = document_chunking(["/home/developerlmt/projects/test_scripts/2025年06月18日台湾新闻.docx"])
    # logger.info(len(nodes))
    # for idx,node in enumerate(nodes):
    #     logger.info(len(node.get_content()))
    #     logger.info("-----")