from collections.abc import Mapping, Sequence
import json

def _repair_str(s: str) -> str:
    # 把 UTF-16 代理对合并成真实的 Unicode 字符；孤立代理会抛错 -> 用 replace
    try:
        return s.encode("utf-16-le", "surrogatepass").decode("utf-16-le", "strict")
    except UnicodeDecodeError:
        # 兜底：把任何仍然存在的代理码位替换掉（避免再触发 httpx 的错误）
        return "".join(ch if not (0xD800 <= ord(ch) <= 0xDFFF) else "\uFFFD" for ch in s)

def repair_surrogates(obj):
    if isinstance(obj, str):
        return _repair_str(obj)
    if isinstance(obj, Mapping):
        # 注意：OpenAI 的 function/tool 调用里，键和值都可能是字符串
        return {repair_surrogates(k): repair_surrogates(v) for k, v in obj.items()}
    if isinstance(obj, Sequence) and not isinstance(obj, (bytes, bytearray)):
        return [repair_surrogates(x) for x in obj]
    return obj

def has_surrogates(s: str) -> bool:
    return any(0xD800 <= ord(ch) <= 0xDFFF for ch in s)

