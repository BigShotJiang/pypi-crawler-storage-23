from typing import Dict, Any, Type, Optional,List
from pydantic import BaseModel, Field, create_model
from enum import Enum

def __json_schema_to_base_model(schema: dict[str, Any], class_name:str=None) -> Type[BaseModel]:
    type_mapping: dict[str, type] = {
        "string": str,
        "str": str,
        "integer": int,
        "number": float,
        "boolean": bool,
        "array": list,
        "object": dict,
    }

    properties = schema.get("properties", {})
    required_fields = schema.get("required", [])
    model_fields = {}

    def process_field(field_name: str, field_props: dict[str, Any]) -> tuple:
        # print("field_props:",field_props)
        """Recursively processes a field and returns its type and Field instance."""
        json_type = field_props.get("type", "string")
        enum_values = field_props.get("enum")

        # Handle Enums
        if enum_values:
            enum_name: str = f"{field_name.capitalize()}Enum"
            field_type = Enum(enum_name, {v: v for v in enum_values})
        # Handle Nested Objects
        elif json_type == "object" and "properties" in field_props:
            field_type = __json_schema_to_base_model(
                field_props,field_name
            )  # Recursively create submodel
        # Handle Arrays with Nested Objects
        elif json_type == "array" and "items" in field_props:
            item_props = field_props["items"]
            if item_props.get("type") == "object":
                item_type: type[BaseModel] = __json_schema_to_base_model(item_props,field_name)
            elif item_props.get("type") == "string" and "enum" in item_props:
                item_type = Enum(f"{field_name.capitalize()}Enum", {v: v for v in item_props["enum"]})
            else:
                item_type: type = type_mapping.get(item_props.get("type"), Any)
            field_type = List[item_type]
        else:
            field_type = type_mapping.get(json_type, Any)

        # Handle default values and optionality
        default_value = field_props.get("default", ...)
        nullable = field_props.get("nullable", False)
        description = field_props.get("description", "")

        if nullable:
            field_type = Optional[field_type]

        if field_name not in required_fields:
            default_value = field_props.get("default", None)
        
        # if sig_type=="input" and is_root:
        #     return field_type, InputField(default = default_value, description=description)
        # elif sig_type=="output" and is_root:
        #     return field_type, OutputField(default = default_value, description=description)
        # else:
        return field_type, Field(default=default_value, description=description)
        

    # Process each field
    for field_name, field_props in properties.items():
        # print(field_name,field_props)
        model_fields[field_name] = process_field(field_name, field_props)

    # Get schema-level description
    schema_description = schema.get("description", "")
    model_config = {}
    if schema_description:
        model_config["__doc__"] = schema_description

    # if is_root:
    #     return model_fields
    if class_name:
        model = create_model(class_name, **model_fields)
    else:
        model = create_model(schema.get("title", "DynamicModel"), **model_fields)
    
    # Add schema description as class docstring if available
    if schema_description:
        model.__doc__ = schema_description
    
    return model

def json_schema_to_pydantic_model(schema):
    return __json_schema_to_base_model(schema,None)

def json_schema_to_signature(input_schema,output_schema,instructions):
    class DynamicSignature():
            # user:User=InputField(descriptions="学生信息")
            # scores: List[Score] = InputField(descriptions="各学科成绩")
            # result: Result = OutputField(descriptions="评价")
            pass
        

    # print(json_schema_to_base_model(input_schema,"input",True))
    for name, field in __json_schema_to_base_model(input_schema,None,"input",True).items():
        DynamicSignature = DynamicSignature.insert(index=-1,name=name,field=field[1],type_=field[0])
    for name, field in __json_schema_to_base_model(output_schema,None,"output",True).items():
        DynamicSignature = DynamicSignature.insert(index=-1,name=name,field=field[1],type_=field[0])
    
    DynamicSignature = DynamicSignature.with_instructions(instructions=instructions)

    return DynamicSignature