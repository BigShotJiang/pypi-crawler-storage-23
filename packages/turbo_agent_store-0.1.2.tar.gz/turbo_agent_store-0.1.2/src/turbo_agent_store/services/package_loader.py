import zipfile
import yaml
import json
import os
from typing import Dict, List, Any, Type, Optional, Set, Union
from loguru import logger

from turbo_agent_core.schema.agents import (
    Agent, Tool, Character, LLMModel, APITool, LLMTool, AgentTool, BasicAgent
)
from turbo_agent_core.schema.external import Platform, Secret
from turbo_agent_core.schema.resources import Project
from turbo_agent_core.schema.basic import TurboEntity

class PackageLoader:
    """
    负责从 Zip 包中加载 TurboEntity 对象，并重建对象间的依赖关系。
    """

    def __init__(self):
        self._entity_map: Dict[str, TurboEntity] = {}
        self._raw_data_map: Dict[str, Dict[str, Any]] = {}

    def load(self, zip_path: str) -> List[TurboEntity]:
        """
        从 Zip 包加载所有实体。
        """
        if not os.path.exists(zip_path):
            raise FileNotFoundError(f"Package file not found: {zip_path}")

        with zipfile.ZipFile(zip_path, 'r') as zf:
            namelist = zf.namelist()

            def _pick_file_path(filename: str) -> Optional[str]:
                if filename in namelist:
                    return filename
                candidates = [p for p in namelist if p.endswith(f"/{filename}")]
                if not candidates:
                    return None
                # 选择“最靠近根目录”的那个（路径最短）
                candidates.sort(key=lambda p: (p.count('/'), len(p)))
                return candidates[0]

            # 1. 读取 export.yaml（兼容 zip 顶层带目录前缀的情况）
            export_yaml_path = _pick_file_path('export.yaml')
            if not export_yaml_path:
                raise ValueError("Invalid package: export.yaml missing")

            package_root_prefix = os.path.dirname(export_yaml_path)
            with zf.open(export_yaml_path) as f:
                export_data = yaml.safe_load(f)

            # 2. 读取 metadata.json (可选)
            metadata = {}
            metadata_path = _pick_file_path('metadata.json')
            if (not metadata_path) and package_root_prefix:
                candidate = f"{package_root_prefix}/metadata.json"
                if candidate in namelist:
                    metadata_path = candidate
            if metadata_path:
                with zf.open(metadata_path) as f:
                    metadata = json.load(f)

            # 3. 解析并实例化所有对象 (Pass 1)
            self._instantiate_entities(export_data)

            # 4. 组装依赖关系 (Pass 2)
            self._hydrate_dependencies()

        return list(self._entity_map.values())

    def _instantiate_entities(self, data: Dict[str, Any]):
        """
        第一遍扫描：创建对象实例，暂不填充引用字段。
        """
        # 按照依赖层级的大致顺序处理，虽然两遍扫描可以忽略顺序，但为了逻辑清晰
        # Projects -> Platforms -> Models -> Tools -> Characters -> Agents

        if 'projects' in data:
            for item in data['projects']:
                self._create_instance(item, Project)
        
        if 'platforms' in data:
            for item in data['platforms']:
                self._create_instance(item, Platform)
        
        if 'secrets' in data:
            for item in data['secrets']:
                self._create_instance(item, Secret)

        if 'models' in data:
            for item in data['models']:
                self._create_instance(item, LLMModel)

        if 'tools' in data:
            for item in data['tools']:
                # Tool 可能是 APITool, LLMTool, AgentTool 或 基础 Tool
                # 这里需要根据字段特征判断具体类型，或者 export.yaml 里有 type 字段？
                # Pydantic model_dump 通常包含 run_type，但不一定包含具体类名
                # 我们根据字段特征推断
                tool_cls = self._infer_tool_class(item)
                self._create_instance(item, tool_cls)

        if 'characters' in data:
            for item in data['characters']:
                self._create_instance(item, Character)

        if 'agents' in data:
            for item in data['agents']:
                self._create_instance(item, Agent)

    def _infer_tool_class(self, data: Dict[str, Any]) -> Type[Tool]:
        """
        根据数据字段特征推断 Tool 的具体子类。
        推断规则:
        1. 若包含 backendAgent 字段 -> AgentTool
        2. 若包含 model 字段 (且非 AgentTool) -> LLMTool
        3. 若包含 url_path_template 或 platform 字段 -> APITool
        4. 默认 -> Tool
        """
        # 1. AgentTool
        if 'backendAgent' in data:
            return AgentTool
            
        # 2. LLMTool
        # 增加 modelParameter 判断，防止 model=None 且被 exclude 时的漏判
        if 'model' in data or 'modelParameter' in data:
            return LLMTool
            
        # 3. APITool
        if 'url_path_template' in data or 'platform' in data:
            return APITool
            
        # 4. 基础 Tool
        return Tool

        # Secret: platform is Optional (by ID in schema?)
        # Secret schema defines platformId: Optional[str].
        # But if we want to hydrate it to object (if base model allows), we need check.
        # Looking at schema/external.py, Secret only has platformId (string).
        # So we might not need hydration for Secret.platformId unless we changed Core schema.
        # But wait, Secret model in `schema/external.py` says `platformId: Optional[str] = None`.
        # It does NOT have a `platform` object field.
        # So we don't need hydration for Secret.
        pass

    def _create_instance(self, data: Dict[str, Any], cls: Type[Union[TurboEntity, Platform, Secret]]):
        entity_id = data.get('id')
        if not entity_id:
            logger.warning(f"Skipping entity without ID: {data}")
            return

        # 保存原始数据用于第二遍 hydration
        self._raw_data_map[entity_id] = data

        clean_data = data.copy()
        self._prepare_data_for_validation(clean_data, cls)

        try:
            # 尝试实例化
            instance = cls.model_validate(clean_data)
            self._entity_map[entity_id] = instance
        except Exception as e:
            logger.error(f"Failed to instantiate {cls.__name__} (ID: {entity_id}): {e}")
            # 也可以选择抛出异常

    def _prepare_data_for_validation(self, data: Dict[str, Any], cls: Type[Union[TurboEntity, Platform, Secret]]):
        """
        准备数据以通过 Pydantic 校验。
        对于必须的引用字段 (如 APITool.platform)，尝试立即解析。
        对于可选的引用字段 (如 Agent.model)，如果无法解析则移除 (使用默认值 None)。
        """
        
        # APITool: platform is Required
        if issubclass(cls, APITool):
            pid = data.get('platform')
            if pid and isinstance(pid, str):
                if pid in self._entity_map:
                    data['platform'] = self._entity_map[pid]
                else:
                    # 如果找不到 Platform，校验必挂。但我们按顺序加载，理论上应该有。
                    pass

        # Agent / LLMTool: model is Optional
        if issubclass(cls, (BasicAgent, Character, Agent, LLMTool)):
            # model
            mid = data.get('model')
            if mid:
                # 尝试解析，如果解析不了就移除 (变为 None)
                if isinstance(mid, str) and mid in self._entity_map:
                    data['model'] = self._entity_map[mid]
                else:
                    del data['model']
            
            # tools: List, default []
            # 列表比较复杂，建议先移除，在 hydrate 阶段填充
            if 'tools' in data:
                del data['tools']
        
        if issubclass(cls, Agent):
            if 'actAsCharacters' in data: del data['actAsCharacters']
            if 'assistantAgents' in data: del data['assistantAgents']
            if 'accountSecrets' in data: del data['accountSecrets']
            
        if issubclass(cls, AgentTool):
            if 'backendAgent' in data: del data['backendAgent']

        if issubclass(cls, Platform):
            if 'secrets' in data: del data['secrets']

    def _hydrate_dependencies(self):
        """
        第二遍扫描：填充引用字段。
        """
        for entity_id, instance in self._entity_map.items():
            raw_data = self._raw_data_map.get(entity_id)
            if not raw_data:
                continue

            if isinstance(instance, (BasicAgent, Character, Agent, LLMTool)):
                # model
                model_id = raw_data.get('model')
                if model_id and isinstance(model_id, str):
                    model_instance = self._entity_map.get(model_id)
                    if model_instance and isinstance(model_instance, LLMModel):
                        instance.model = model_instance
                    else:
                        logger.warning(f"Missing or invalid model ref '{model_id}' for entity {entity_id}")

                # tools (List)
                tool_ids = raw_data.get('tools')
                if tool_ids and isinstance(tool_ids, list):
                    tools = []
                    for tid in tool_ids:
                        t = self._entity_map.get(tid)
                        if t and isinstance(t, Tool):
                            tools.append(t)
                        else:
                            logger.warning(f"Missing tool ref '{tid}' for entity {entity_id}")
                    instance.tools = tools

            if isinstance(instance, Agent):
                # actAsCharacters
                char_ids = raw_data.get('actAsCharacters')
                if char_ids and isinstance(char_ids, list):
                    chars = []
                    for cid in char_ids:
                        c = self._entity_map.get(cid)
                        if c and isinstance(c, Character):
                            chars.append(c)
                        else:
                            logger.warning(f"Missing character ref '{cid}' for entity {entity_id}")
                    instance.actAsCharacters = chars

                # assistantAgents
                agent_ids = raw_data.get('assistantAgents')
                if agent_ids and isinstance(agent_ids, list):
                    agents = []
                    for aid in agent_ids:
                        a = self._entity_map.get(aid)
                        if a and isinstance(a, Agent):
                            agents.append(a)
                        else:
                            logger.warning(f"Missing assistant agent ref '{aid}' for entity {entity_id}")
                    instance.assistantAgents = agents

                # accountSecrets
                secret_ids = raw_data.get('accountSecrets')
                if secret_ids and isinstance(secret_ids, list):
                    secrets = []
                    for sid in secret_ids:
                        s = self._entity_map.get(sid)
                        if s and isinstance(s, Secret):
                            secrets.append(s)
                        else:
                            logger.warning(f"Missing secret ref '{sid}' for entity {entity_id}")
                    instance.accountSecrets = secrets

            if isinstance(instance, APITool):
                # platform
                platform_id = raw_data.get('platform')
                if platform_id and isinstance(platform_id, str):
                    p = self._entity_map.get(platform_id)
                    if p and isinstance(p, Platform):
                        instance.platform = p
                    else:
                        logger.warning(f"Missing platform ref '{platform_id}' for entity {entity_id}")

            if isinstance(instance, AgentTool):
                # backendAgent
                agent_id = raw_data.get('backendAgent')
                if agent_id and isinstance(agent_id, str):
                    a = self._entity_map.get(agent_id)
                    if a and isinstance(a, BasicAgent):
                        instance.backendAgent = a
                    else:
                        logger.warning(f"Missing backend agent ref '{agent_id}' for entity {entity_id}")

            if isinstance(instance, Platform):
                # secrets
                secret_ids = raw_data.get('secrets')
                if secret_ids and isinstance(secret_ids, list):
                    secrets = []
                    for sid in secret_ids:
                        s = self._entity_map.get(sid)
                        if s and isinstance(s, Secret):
                            secrets.append(s)
                        else:
                            logger.warning(f"Missing secret ref '{sid}' for platform {entity_id}")
                    instance.secrets = secrets


