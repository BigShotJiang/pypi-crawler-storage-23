# coding=utf-8
from __future__ import annotations

from typing import Optional

from loguru import logger

from turbo_agent_core.schema.events import BaseEvent


class ExecutionEventArchiver:
    """事件归档器（最小实现）。

    说明：
    - 设计文档要求：Store Worker 基于事件流落库 ExecutionStore。
    - 当前仓库 ExecutionStore 落库逻辑尚未完整实现，因此这里先提供“接口桩”，
      以打通：Consumer -> Archiver 的调用链路。

    下一步：
    - 将不同 event.type 映射到 Message/ToolCallRecord/Action 等 Prisma 模型写入。
    """

    def __init__(self, dry_run: bool = True):
        self.dry_run = dry_run

    async def apply_event(self, event: BaseEvent) -> None:
        if self.dry_run:
            if str(event.type).startswith("run.lifecycle"):
                status = str(event.type).split(".")[-1] if str(event.type).startswith("run.lifecycle.") else str(event.type)
                logger.info(
                    "[归档预览] run.lifecycle：trace_id={}, status={}, executor_type={}",
                    event.trace_id,
                    status,
                    event.executor_type,
                )
            else:
                logger.debug(
                    "[归档预览] event：type={}, trace_id={}, executor_type={}",
                    event.type,
                    event.trace_id,
                    event.executor_type,
                )
            return

        # TODO: 真正落库逻辑（ExecutionStore.apply_event）
        raise NotImplementedError("ExecutionEventArchiver 的真实落库尚未实现")
