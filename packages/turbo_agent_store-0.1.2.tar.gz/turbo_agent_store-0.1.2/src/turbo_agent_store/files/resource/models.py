"""
知识资源数据模型

使用 turbo_agent_core.schema 中的基础定义
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional, List, Dict, Any
from pathlib import Path

# 从 core 模块导入已定义的枚举和模型
from turbo_agent_core.schema.enums import (
    KnowledgeType,
    FileType,
    ResourceStatus,
)
from turbo_agent_core.schema.resources import KnowledgeResource


class AnalysisStatus(str, Enum):
    """解析状态"""
    PENDING = "pending"      # 待解析
    PROCESSING = "processing"  # 解析中
    COMPLETED = "completed"   # 完成
    FAILED = "failed"        # 失败


@dataclass
class AnalysisJob:
    """解析工作任务"""
    method: str                          # 解析方法，如 "docling", "markdown", "ocr"
    status: AnalysisStatus = AnalysisStatus.PENDING
    result_path: Optional[str] = None    # 解析结果文件路径（在 MinIO 中）
    result_md5: Optional[str] = None     # 解析结果文件 MD5
    error_message: Optional[str] = None  # 错误信息
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "method": self.method,
            "status": self.status.value,
            "result_path": self.result_path,
            "result_md5": self.result_md5,
            "error_message": self.error_message,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AnalysisJob":
        return cls(
            method=data["method"],
            status=AnalysisStatus(data.get("status", "pending")),
            result_path=data.get("result_path"),
            result_md5=data.get("result_md5"),
            error_message=data.get("error_message"),
            started_at=datetime.fromisoformat(data["started_at"]) if data.get("started_at") else None,
            completed_at=datetime.fromisoformat(data["completed_at"]) if data.get("completed_at") else None,
        )


@dataclass
class ResourceMetadata:
    """
    知识资源元数据（扩展 KnowledgeResource）
    
    包含 KnowledgeResource 的所有字段，额外增加：
    - 上传信息
    - 文件信息（MD5、大小等）
    - 绑定关系
    - 解析任务列表
    """
    # 基本信息（对应 KnowledgeResource）- 必填字段
    resource_id: str                     # 知识资源 ID
    name: str                            # 资源名称（同 filename）
    filename: str                        # 原始文件名
    type: KnowledgeType                 # 知识资源类型
    status: ResourceStatus              # 资源状态
    uploaded_at: datetime               # 上传时间
    uploaded_by: str                    # 上传用户名
    user_id: str                        # 用户 ID
    original_file_path: str             # 原文件在 MinIO 中的路径
    file_size: int                      # 文件大小（字节）
    file_md5: str                       # 文件 MD5 校验码
    
    # 可选字段（有默认值）
    fileType: Optional[FileType] = None # 文件类型
    url: Optional[str] = None           # 访问 URL
    uri: Optional[str] = None           # 存储 URI（MinIO 路径）
    content: Optional[str] = None       # 文本内容（如果已提取）
    mime_type: Optional[str] = None     # MIME 类型
    workset_id: Optional[str] = None    # 绑定的 Workset ID
    conversation_id: Optional[str] = None  # 绑定的对话 ID
    setting_id: Optional[str] = None    # 绑定的 Setting ID
    org_project_id: Optional[str] = None  # 绑定的 OrgProject ID
    analysis_jobs: List[AnalysisJob] = field(default_factory=list)  # 解析任务列表
    tags: List[str] = field(default_factory=list)  # 标签
    
    def to_knowledge_resource(self) -> KnowledgeResource:
        """转换为 KnowledgeResource（用于数据库写入）"""
        return KnowledgeResource(
            id=self.resource_id,
            name=self.name,
            type=self.type,
            status=self.status,
            fileType=self.fileType,
            filename=self.filename,
            url=self.url,
            uri=self.uri,
            content=self.content,
            mime_type=self.mime_type,
            tags=self.tags,
        )
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "resource_id": self.resource_id,
            "name": self.name,
            "filename": self.filename,
            "type": self.type.value,
            "status": self.status.value,
            "fileType": self.fileType.value if self.fileType else None,
            "url": self.url,
            "uri": self.uri,
            "content": self.content,
            "mime_type": self.mime_type,
            "uploaded_at": self.uploaded_at.isoformat(),
            "uploaded_by": self.uploaded_by,
            "user_id": self.user_id,
            "original_file_path": self.original_file_path,
            "file_size": self.file_size,
            "file_md5": self.file_md5,
            "workset_id": self.workset_id,
            "conversation_id": self.conversation_id,
            "setting_id": self.setting_id,
            "org_project_id": self.org_project_id,
            "analysis_jobs": [job.to_dict() for job in self.analysis_jobs],
            "tags": self.tags,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ResourceMetadata":
        return cls(
            resource_id=data["resource_id"],
            name=data.get("name", data.get("filename", "")),
            filename=data["filename"],
            type=KnowledgeType(data["type"]),
            status=ResourceStatus(data.get("status", "pending")),
            fileType=FileType(data["fileType"]) if data.get("fileType") else None,
            url=data.get("url"),
            uri=data.get("uri"),
            content=data.get("content"),
            mime_type=data.get("mime_type"),
            uploaded_at=datetime.fromisoformat(data["uploaded_at"]),
            uploaded_by=data["uploaded_by"],
            user_id=data["user_id"],
            original_file_path=data["original_file_path"],
            file_size=data["file_size"],
            file_md5=data["file_md5"],
            workset_id=data.get("workset_id"),
            conversation_id=data.get("conversation_id"),
            setting_id=data.get("setting_id"),
            org_project_id=data.get("org_project_id"),
            analysis_jobs=[AnalysisJob.from_dict(job) for job in data.get("analysis_jobs", [])],
            tags=data.get("tags", []),
        )


@dataclass
class KnowledgeResourceUploadRequest:
    """知识资源上传请求"""
    # 文件信息
    local_file_path: str                 # 本地文件路径
    resource_id: str                     # 知识资源 ID（业务方生成）
    filename: str                        # 文件名
    file_type: FileType                  # 文件类型
    knowledge_type: KnowledgeType        # 知识资源类型
    
    # 用户信息
    user_id: str                         # 用户 ID
    username: str                        # 用户名
    
    # 绑定关系（可选）
    workset_id: Optional[str] = None
    conversation_id: Optional[str] = None
    setting_id: Optional[str] = None
    org_project_id: Optional[str] = None
    
    # 解析配置
    enable_docling: bool = True          # 是否启用 docling 解析
    enable_markdown: bool = False        # 是否启用 markdown 转换
    
    def validate(self) -> None:
        """验证请求"""
        path = Path(self.local_file_path)
        if not path.exists():
            raise FileNotFoundError(f"文件不存在: {self.local_file_path}")
        if not path.is_file():
            raise ValueError(f"路径不是文件: {self.local_file_path}")
