"""知识资源管理

提供知识资源上传、管理和解析功能。
"""

# 数据模型（使用 core 模块定义）
from turbo_agent_core.schema.enums import (
    KnowledgeType,
    FileType,
    ResourceStatus,
)

# 本地定义的模型
from .models import (
    AnalysisStatus,
    AnalysisJob,
    ResourceMetadata,
    KnowledgeResourceUploadRequest,
)

# 管理器
from .manager import KnowledgeResourceManager

# Worker
from .worker import (
    AnalysisWorker,
    process_knowledge_resource_analysis,
)

__all__ = [
    # Core 枚举
    "KnowledgeType",
    "FileType",
    "ResourceStatus",
    # 本地模型
    "AnalysisStatus",
    "AnalysisJob",
    "ResourceMetadata",
    "KnowledgeResourceUploadRequest",
    # 管理器
    "KnowledgeResourceManager",
    # Worker
    "AnalysisWorker",
    "process_knowledge_resource_analysis",
]
