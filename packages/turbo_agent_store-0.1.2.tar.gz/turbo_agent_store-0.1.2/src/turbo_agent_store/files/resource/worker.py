"""
知识资源解析 Worker

基于 dramatiq 的异步任务处理
"""

import hashlib
import json
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Optional

import dramatiq
from loguru import logger

from turbo_agent_core.schema.enums import ResourceStatus
from turbo_agent_core.store.resource import ResourceStore

from .models import AnalysisStatus, ResourceMetadata


class AnalysisWorker:
    """
    知识资源解析 Worker。
    
    处理以下解析任务：
    1. Docling 解析（优先）
    2. Markdown 转换（备选）
    """
    
    def __init__(
        self,
        resource_store: ResourceStore,
        docling_enabled: bool = True,
        docling_server_url: Optional[str] = None,
        docling_api_key: Optional[str] = None,
    ):
        self.store = resource_store
        self.docling_enabled = docling_enabled
        self.docling_server_url = docling_server_url
        self.docling_api_key = docling_api_key
    
    async def process(self, task_payload: dict) -> None:
        """
        处理解析任务。
        
        Args:
            task_payload: 任务数据
                {
                    "resource_id": str,
                    "user_id": str,
                    "context_id": str,
                    "method": str,  # "docling" | "markdown"
                    "file_path": str,  # MinIO 中的路径
                    "file_type": str,
                    "knowledge_type": str,
                    "mime_type": str,
                }
        """
        resource_id = task_payload["resource_id"]
        user_id = task_payload["user_id"]
        context_id = task_payload["context_id"]
        method = task_payload["method"]
        file_path = task_payload["file_path"]
        
        logger.info(f"开始解析任务: {resource_id}, method: {method}")
        
        try:
            # 更新状态为处理中
            await self._update_job_status(
                user_id=user_id,
                context_id=context_id,
                resource_id=resource_id,
                method=method,
                status=AnalysisStatus.PROCESSING,
            )
            
            # 下载原文件
            file_data = await self.store.download(file_path)
            
            # 根据方法进行解析
            if method == "docling":
                result_path, result_md5 = await self._process_docling(
                    user_id=user_id,
                    context_id=context_id,
                    resource_id=resource_id,
                    file_data=file_data,
                    file_type=task_payload.get("file_type"),
                    mime_type=task_payload.get("mime_type"),
                )
            elif method == "markdown":
                result_path, result_md5 = await self._process_markdown(
                    user_id=user_id,
                    context_id=context_id,
                    resource_id=resource_id,
                    file_data=file_data,
                    file_type=task_payload.get("file_type"),
                )
            else:
                raise ValueError(f"未知的解析方法: {method}")
            
            # 更新状态为完成
            await self._update_job_status(
                user_id=user_id,
                context_id=context_id,
                resource_id=resource_id,
                method=method,
                status=AnalysisStatus.COMPLETED,
                result_path=result_path,
                result_md5=result_md5,
            )
            
            logger.info(f"解析任务完成: {resource_id}, method: {method}, result: {result_path}")
            
        except Exception as e:
            logger.error(f"解析任务失败: {resource_id}, method: {method}, error: {e}")
            await self._update_job_status(
                user_id=user_id,
                context_id=context_id,
                resource_id=resource_id,
                method=method,
                status=AnalysisStatus.FAILED,
                error_message=str(e),
            )
    
    async def _process_docling(
        self,
        user_id: str,
        context_id: str,
        resource_id: str,
        file_data: bytes,
        file_type: Optional[str],
        mime_type: Optional[str],
    ) -> tuple[str, str]:
        """
        使用 Docling 服务解析文件。
        
        Returns:
            (result_path, result_md5)
        """
        if not self.docling_enabled:
            raise RuntimeError("Docling 服务未启用")
        
        # 导入 DoclingClient
        try:
            from turbo_agent_store.utils.docling_client import DoclingClient
        except ImportError:
            raise RuntimeError("DoclingClient 未安装")
        
        # 创建临时文件
        suffix = Path(file_type).suffix if file_type else ".bin"
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            tmp.write(file_data)
            tmp_path = tmp.name
        
        try:
            # 调用 Docling 服务
            client = DoclingClient()
            task_info = client.convert_files_async(
                file_paths=[tmp_path],
                timeout=300,
                do_formula_enrichment=True,
                do_code_enrichment=True,
                image_export_mode="embedded",
            )
            
            # 等待结果
            documents = list(client.wait_task(interval=2.0, timeout=600))
            
            if not documents:
                raise RuntimeError("Docling 解析未返回结果")
            
            # 处理结果
            doc = documents[0]
            
            # 提取 JSON 内容
            json_content = doc.get("json_content") or doc.get("json") or doc
            if isinstance(json_content, str):
                result_data = json_content.encode("utf-8")
            else:
                result_data = json.dumps(json_content, ensure_ascii=False, indent=2).encode("utf-8")
            
            # 上传到 MinIO（作为 parsed 内容）
            result_path = await self.store.save_parsed(
                user_id=user_id,
                context_id=context_id,
                resource_id=resource_id,
                data=result_data,
                format="docling.json",
            )
            
            # 计算 MD5
            result_md5 = hashlib.md5(result_data).hexdigest()
            
            return result_path, result_md5
            
        finally:
            # 清理临时文件
            Path(tmp_path).unlink(missing_ok=True)
    
    async def _process_markdown(
        self,
        user_id: str,
        context_id: str,
        resource_id: str,
        file_data: bytes,
        file_type: Optional[str],
    ) -> tuple[str, str]:
        """
        将文件转换为 Markdown（备选方案）。
        
        Returns:
            (result_path, result_md5)
        """
        # 尝试解码为文本
        try:
            text_content = file_data.decode("utf-8")
        except UnicodeDecodeError:
            try:
                text_content = file_data.decode("gbk")
            except UnicodeDecodeError:
                text_content = f"[Binary file: {file_type}, cannot convert to markdown]"
        
        # 包装为 markdown
        markdown_content = f"""# Document Content

```
{text_content}
```
"""
        
        result_data = markdown_content.encode("utf-8")
        
        # 上传到 MinIO（作为 parsed 内容）
        result_path = await self.store.save_parsed(
            user_id=user_id,
            context_id=context_id,
            resource_id=resource_id,
            data=result_data,
            format="markdown",
        )
        
        # 计算 MD5
        result_md5 = hashlib.md5(result_data).hexdigest()
        
        return result_path, result_md5
    
    async def _update_job_status(
        self,
        user_id: str,
        context_id: str,
        resource_id: str,
        method: str,
        status: AnalysisStatus,
        result_path: Optional[str] = None,
        result_md5: Optional[str] = None,
        error_message: Optional[str] = None,
    ) -> None:
        """更新解析任务状态"""
        from .manager import KnowledgeResourceManager
        
        # 创建临时 manager 实例
        manager = KnowledgeResourceManager(self.store, None)
        
        await manager.update_analysis_status(
            user_id=user_id,
            context_id=context_id,
            resource_id=resource_id,
            method=method,
            status=status,
            result_path=result_path,
            result_md5=result_md5,
            error_message=error_message,
        )


# dramatiq actor 定义
@dramatiq.actor(max_retries=3, time_limit=600000)  # 10 分钟超时
def process_knowledge_resource_analysis(task_payload: dict):
    """
    dramatiq actor：处理知识资源解析任务。
    
    使用方法:
        process_knowledge_resource_analysis.send({
            "resource_id": "res-123",
            "user_id": "user-456",
            "context_id": "workset_xxx",
            "method": "docling",
            "file_path": "user-456/workset_xxx/res-123/original/document.pdf",
            ...
        })
    """
    import asyncio
    
    # 创建 worker 实例
    from turbo_agent_cloud.store.resource.minio import MinIOResourceStore
    
    store = MinIOResourceStore(
        endpoint="localhost:9000",
        access_key="minioadmin",
        secret_key="minioadmin",
        bucket="turbo-agent",
    )
    
    worker = AnalysisWorker(
        resource_store=store,
        docling_enabled=True,
    )
    
    # 运行异步处理
    asyncio.run(worker.process(task_payload))
