"""
LocalGitWorkspaceStore - 本地 Git 实现的 WorkspaceStore

管理 Git 工作区，提供版本控制功能。

仓库结构:
    {base_path}/{user_id}/{workspace_id}/
    ├── .git/                       # Git 版本控制
    ├── files/                      # 工作文件（Git 跟踪）
    │   ├── main.py
    │   └── config.yaml
    └── .meta/                      # 元数据
        └── manifest.json
"""

import os
import shutil
import zipfile
import io
from pathlib import Path
from datetime import datetime
from typing import Optional, List

from turbo_agent_core.store.workspace import (
    WorkspaceStore, FileInfo, CommitInfo, TagInfo
)


class LocalGitWorkspaceStore(WorkspaceStore):
    """
    本地 Git 实现的 WorkspaceStore。
    
    Args:
        workspace_id: 工作区ID
        user_id: 用户ID
        base_path: 基础存储路径
        auto_commit: 是否自动提交（默认 True）
    """
    
    def __init__(
        self,
        workspace_id: str,
        user_id: str,
        base_path: str = "/tmp/turbo_agent/workspaces",
        auto_commit: bool = True
    ):
        super().__init__(workspace_id, user_id)
        self.base_path = Path(base_path)
        self.workspace_path = self.base_path / user_id / workspace_id
        self.files_path = self.workspace_path / "files"
        self.auto_commit = auto_commit
        self._repo = None
    
    def _get_repo(self):
        """延迟初始化 Git 仓库。"""
        if self._repo is None:
            try:
                from git import Repo
            except ImportError:
                raise ImportError(
                    "LocalGitWorkspaceStore 需要 GitPython，"
                    "请安装: pip install GitPython"
                )
            
            git_dir = self.workspace_path / ".git"
            if git_dir.exists():
                self._repo = Repo(self.workspace_path)
            else:
                # 初始化新仓库
                self.workspace_path.mkdir(parents=True, exist_ok=True)
                self.files_path.mkdir(exist_ok=True)
                self._repo = Repo.init(self.workspace_path)
                
                # 配置 Git
                with self._repo.config_writer() as config:
                    config.set_value("user", "name", f"User-{self.user_id}")
                    config.set_value("user", "email", f"{self.user_id}@turbo.agent")
                
                # 初始提交
                if self.auto_commit:
                    self._repo.git.add(".")
                    self._repo.git.commit(
                        m="Initialize workspace",
                        allow_empty=True
                    )
        
        return self._repo
    
    def _resolve_path(self, path: str) -> Path:
        """解析相对路径为绝对路径（在 files 目录下）。"""
        # 去除前导斜杠
        path = path.lstrip("/")
        
        # 构建完整路径
        full_path = (self.files_path / path).resolve()
        
        # 安全检查：确保路径在 files 目录内
        if not str(full_path).startswith(str(self.files_path.resolve())):
            raise ValueError(f"Invalid path: {path}")
        
        return full_path
    
    # ===== 文件操作 =====
    
    async def read_file(self, path: str, ref: str = "HEAD") -> bytes:
        """读取文件内容。"""
        if ref == "HEAD":
            # 读取工作目录文件
            file_path = self._resolve_path(path)
            if not file_path.exists():
                raise FileNotFoundError(f"File not found: {path}")
            return file_path.read_bytes()
        else:
            # 读取历史版本
            repo = self._get_repo()
            try:
                blob = repo.git.show(f"{ref}:{path}")
                return blob.encode('utf-8') if isinstance(blob, str) else blob
            except Exception as e:
                raise FileNotFoundError(f"File not found in {ref}: {path}") from e
    
    async def write_file(
        self,
        path: str,
        content: bytes,
        commit_msg: Optional[str] = None
    ) -> str:
        """写入文件。"""
        file_path = self._resolve_path(path)
        file_path.parent.mkdir(parents=True, exist_ok=True)
        
        # 写入内容
        file_path.write_bytes(content)
        
        commit_hash = ""
        
        # 自动提交
        if self.auto_commit or commit_msg:
            repo = self._get_repo()
            repo.git.add(str(file_path.relative_to(self.workspace_path)))
            
            msg = commit_msg or f"Update {path}"
            try:
                result = repo.git.commit(m=msg)
                # 提取 commit hash
                commit_hash = repo.head.commit.hexsha
            except Exception:
                # 无变化时忽略
                pass
        
        return commit_hash
    
    async def delete_file(
        self,
        path: str,
        commit_msg: Optional[str] = None
    ) -> bool:
        """删除文件。"""
        file_path = self._resolve_path(path)
        
        if not file_path.exists():
            return False
        
        file_path.unlink()
        
        # 自动提交
        if self.auto_commit or commit_msg:
            repo = self._get_repo()
            try:
                repo.git.rm(str(file_path.relative_to(self.workspace_path)))
                msg = commit_msg or f"Delete {path}"
                repo.git.commit(m=msg)
            except Exception:
                pass
        
        return True
    
    async def exists(self, path: str, ref: str = "HEAD") -> bool:
        """检查文件是否存在。"""
        if ref == "HEAD":
            file_path = self._resolve_path(path)
            return file_path.exists()
        else:
            # 检查历史版本中是否存在
            try:
                repo = self._get_repo()
                repo.git.cat_file("-e", f"{ref}:{path}")
                return True
            except Exception:
                return False
    
    # ===== 目录操作 =====
    
    async def list_files(
        self,
        path: str = "",
        ref: str = "HEAD",
        recursive: bool = False
    ) -> List[FileInfo]:
        """列出目录文件。"""
        if ref != "HEAD":
            # 列出历史版本的文件
            return await self._list_files_from_ref(path, ref, recursive)
        
        dir_path = self._resolve_path(path) if path else self.files_path
        
        if not dir_path.exists():
            return []
        
        files = []
        
        if recursive:
            for item in dir_path.rglob("*"):
                rel_path = str(item.relative_to(self.files_path))
                files.append(self._create_file_info(item, rel_path))
        else:
            for item in dir_path.iterdir():
                rel_path = str(item.relative_to(self.files_path))
                files.append(self._create_file_info(item, rel_path))
        
        return sorted(files, key=lambda x: x.path)
    
    def _create_file_info(self, path: Path, rel_path: str) -> FileInfo:
        """创建 FileInfo 对象。"""
        stat = path.stat()
        
        # 获取最近的 commit 信息
        commit_hash = None
        commit_message = None
        try:
            repo = self._get_repo()
            # 获取该文件最近的 commit
            commits = list(repo.iter_commits(paths=rel_path, max_count=1))
            if commits:
                commit_hash = commits[0].hexsha[:8]
                commit_message = commits[0].message.strip()
        except Exception:
            pass
        
        return FileInfo(
            path=rel_path,
            is_file=path.is_file(),
            size=stat.st_size if path.is_file() else 0,
            modified=datetime.fromtimestamp(stat.st_mtime),
            commit_hash=commit_hash,
            commit_message=commit_message
        )
    
    async def _list_files_from_ref(
        self,
        path: str,
        ref: str,
        recursive: bool
    ) -> List[FileInfo]:
        """从 Git 历史版本列出文件。"""
        repo = self._get_repo()
        files = []
        
        try:
            tree = repo.tree(ref)
            prefix = path + "/" if path else ""
            
            for item in tree.traverse():
                if not recursive and item.path.count("/") > (path.count("/") + (1 if path else 0)):
                    continue
                
                if item.path.startswith(prefix) or not path:
                    rel_path = item.path[len(prefix):] if prefix else item.path
                    if rel_path or not path:
                        files.append(FileInfo(
                            path=item.path,
                            is_file=item.type == "blob",
                            size=item.size if item.type == "blob" else 0,
                            modified=datetime.now(),  # Git tree 不保留时间
                            commit_hash=None,
                            commit_message=None
                        ))
        except Exception:
            pass
        
        return files
    
    async def create_directory(self, path: str) -> bool:
        """创建目录。"""
        dir_path = self._resolve_path(path)
        dir_path.mkdir(parents=True, exist_ok=True)
        return True
    
    async def delete_directory(
        self,
        path: str,
        recursive: bool = False
    ) -> bool:
        """删除目录。"""
        dir_path = self._resolve_path(path)
        
        if not dir_path.exists():
            return False
        
        if recursive:
            shutil.rmtree(dir_path)
        else:
            dir_path.rmdir()  # 只能删除空目录
        
        # 提交更改
        if self.auto_commit:
            repo = self._get_repo()
            try:
                repo.git.add("-A")
                repo.git.commit(m=f"Delete directory {path}")
            except Exception:
                pass
        
        return True
    
    # ===== 版本管理 =====
    
    async def commit(self, message: str, files: Optional[List[str]] = None) -> str:
        """提交更改。"""
        repo = self._get_repo()
        
        if files:
            for f in files:
                file_path = self._resolve_path(f)
                repo.git.add(str(file_path.relative_to(self.workspace_path)))
        else:
            repo.git.add("-A")
        
        result = repo.git.commit(m=message)
        return repo.head.commit.hexsha
    
    async def log(
        self,
        path: Optional[str] = None,
        n: int = 20
    ) -> List[CommitInfo]:
        """查看提交历史。"""
        repo = self._get_repo()
        commits = []
        
        kwargs = {"max_count": n}
        if path:
            kwargs["paths"] = path
        
        for commit in repo.iter_commits(**kwargs):
            commits.append(CommitInfo(
                hash=commit.hexsha,
                message=commit.message.strip(),
                author=commit.author.name,
                email=commit.author.email,
                timestamp=datetime.fromtimestamp(commit.committed_date),
                files_changed=list(commit.stats.files.keys())
            ))
        
        return commits
    
    async def diff(
        self,
        path: Optional[str] = None,
        from_ref: str = "HEAD~1",
        to_ref: str = "HEAD"
    ) -> str:
        """对比版本差异。"""
        repo = self._get_repo()
        
        diff_args = [f"{from_ref}..{to_ref}"]
        if path:
            diff_args.append("--")
            diff_args.append(path)
        
        return repo.git.diff(*diff_args)
    
    async def rollback(self, path: str, commit_hash: str) -> bool:
        """回退文件到指定版本。"""
        repo = self._get_repo()
        file_path = self._resolve_path(path)
        
        try:
            # 从指定版本检出文件
            content = repo.git.show(f"{commit_hash}:{path}")
            file_path.write_text(content) if isinstance(content, str) else file_path.write_bytes(content)
            
            # 提交回退
            if self.auto_commit:
                repo.git.add(str(file_path.relative_to(self.workspace_path)))
                repo.git.commit(m=f"Rollback {path} to {commit_hash[:8]}")
            
            return True
        except Exception as e:
            raise RuntimeError(f"Failed to rollback {path}: {e}") from e
    
    async def reset(self, commit_hash: str, hard: bool = False) -> bool:
        """重置整个工作区。"""
        repo = self._get_repo()
        
        try:
            if hard:
                repo.git.reset("--hard", commit_hash)
            else:
                repo.git.reset("--soft", commit_hash)
            return True
        except Exception as e:
            raise RuntimeError(f"Failed to reset to {commit_hash}: {e}") from e
    
    # ===== 分支/标签 =====
    
    async def create_branch(self, branch: str, from_ref: str = "HEAD") -> bool:
        """创建分支。"""
        repo = self._get_repo()
        
        try:
            new_branch = repo.create_head(branch, from_ref)
            return True
        except Exception as e:
            raise RuntimeError(f"Failed to create branch {branch}: {e}") from e
    
    async def switch_branch(self, branch: str) -> bool:
        """切换分支。"""
        repo = self._get_repo()
        
        try:
            repo.git.checkout(branch)
            return True
        except Exception as e:
            raise RuntimeError(f"Failed to switch to branch {branch}: {e}") from e
    
    async def list_branches(self) -> List[str]:
        """列出所有分支。"""
        repo = self._get_repo()
        return [b.name for b in repo.branches]
    
    async def current_branch(self) -> str:
        """获取当前分支。"""
        repo = self._get_repo()
        return repo.active_branch.name
    
    async def tag(
        self,
        name: str,
        commit_hash: Optional[str] = None,
        message: Optional[str] = None
    ) -> bool:
        """创建标签。"""
        repo = self._get_repo()
        
        try:
            if message:
                repo.create_tag(name, ref=commit_hash or "HEAD", message=message)
            else:
                repo.create_tag(name, ref=commit_hash or "HEAD")
            return True
        except Exception as e:
            raise RuntimeError(f"Failed to create tag {name}: {e}") from e
    
    async def list_tags(self) -> List[TagInfo]:
        """列出所有标签。"""
        repo = self._get_repo()
        tags = []
        
        for tag in repo.tags:
            tags.append(TagInfo(
                name=tag.name,
                commit_hash=tag.commit.hexsha,
                message=tag.tag.message if tag.tag else None,
                created_at=datetime.fromtimestamp(tag.tag.tagged_date) if tag.tag else None
            ))
        
        return tags
    
    async def delete_tag(self, name: str) -> bool:
        """删除标签。"""
        repo = self._get_repo()
        
        try:
            repo.delete_tag(name)
            return True
        except Exception as e:
            raise RuntimeError(f"Failed to delete tag {name}: {e}") from e
    
    # ===== 工作区操作 =====
    
    async def upload_workspace(
        self,
        zip_data: bytes,
        commit_msg: Optional[str] = None
    ) -> str:
        """上传整个工作区（zip 包）。"""
        # 解压 zip 到工作目录
        with zipfile.ZipFile(io.BytesIO(zip_data), 'r') as zf:
            # 清空现有文件（保留 .git）
            for item in self.files_path.iterdir():
                if item.name != ".git":
                    if item.is_dir():
                        shutil.rmtree(item)
                    else:
                        item.unlink()
            
            # 解压
            zf.extractall(self.files_path)
        
        # 提交
        if self.auto_commit or commit_msg:
            repo = self._get_repo()
            repo.git.add("-A")
            msg = commit_msg or "Upload workspace"
            repo.git.commit(m=msg)
            return repo.head.commit.hexsha
        
        return ""
    
    async def download_workspace(
        self,
        ref: str = "HEAD",
        format: str = "zip"
    ) -> bytes:
        """打包下载整个工作区。"""
        if format != "zip":
            raise ValueError(f"Unsupported format: {format}")
        
        buffer = io.BytesIO()
        
        with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED) as zf:
            if ref == "HEAD":
                # 打包工作目录
                for file_path in self.files_path.rglob("*"):
                    if file_path.is_file():
                        arcname = str(file_path.relative_to(self.files_path))
                        zf.write(file_path, arcname)
            else:
                # 从历史版本打包
                repo = self._get_repo()
                tree = repo.tree(ref)
                
                for item in tree.traverse():
                    if item.type == "blob":
                        content = repo.git.show(f"{ref}:{item.path}")
                        zf.writestr(item.path, content)
        
        buffer.seek(0)
        return buffer.read()
    
    async def delete_workspace(self) -> bool:
        """删除整个工作区。"""
        if self.workspace_path.exists():
            shutil.rmtree(self.workspace_path)
            return True
        return False
    
    async def get_status(self) -> dict:
        """获取工作区状态。"""
        repo = self._get_repo()
        
        status = {
            "modified": [],
            "added": [],
            "deleted": [],
            "untracked": []
        }
        
        # 获取 Git 状态
        git_status = repo.git.status(porcelain=True)
        
        for line in git_status.split('\n'):
            if not line:
                continue
            
            status_code = line[:2]
            file_path = line[3:].strip()
            
            if status_code[0] == 'M' or status_code[1] == 'M':
                status["modified"].append(file_path)
            elif status_code[0] == 'A':
                status["added"].append(file_path)
            elif status_code[0] == 'D' or status_code[1] == 'D':
                status["deleted"].append(file_path)
            elif status_code == '??':
                status["untracked"].append(file_path)
        
        return status
    
    # ===== 额外方法 =====
    
    def get_workspace_path(self) -> Path:
        """获取工作区根路径。"""
        return self.workspace_path
    
    def get_files_path(self) -> Path:
        """获取文件目录路径。"""
        return self.files_path
