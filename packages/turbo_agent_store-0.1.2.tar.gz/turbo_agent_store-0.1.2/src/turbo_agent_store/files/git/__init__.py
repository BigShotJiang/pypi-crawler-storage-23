"""
Git 文件存储实现

用途：Agent 工作空间文件的版本管理
场景：代码/文件的版本控制，支持协作

注意：
- 不是系统数据存储
- 用于 Agent 工作空间的文件管理
- 支持版本历史和协作
"""

from .file import GitFileStore

__all__ = ["GitFileStore"]
