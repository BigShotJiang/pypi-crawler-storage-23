"""
Git File Store 实现

用途：Agent 工作空间文件的版本管理
场景：代码/文件的版本控制，支持协作

依赖：GitPython (pip install GitPython)
"""

import os
from typing import Optional, AsyncGenerator
from pathlib import Path

from turbo_agent_core.store.file import BaseFileStore


class GitFileStore(BaseFileStore):
    """Git 文件存储实现。
    
    用于 Agent 工作空间的文件版本管理：
    - 文件的版本控制
    - 支持分支和合并
    - 协作场景下的文件同步
    
    注意：此实现专注于工作空间文件，不是系统数据存储。
    """
    
    def __init__(self, repo_path: str, auto_commit: bool = True, committer_name: str = "TurboAgent", committer_email: str = "agent@turbo.local"):
        """
        Args:
            repo_path: Git 仓库路径
            auto_commit: 是否自动提交更改
            committer_name: 提交者名称
            committer_email: 提交者邮箱
        """
        self.repo_path = Path(repo_path)
        self.auto_commit = auto_commit
        self.committer_name = committer_name
        self.committer_email = committer_email
        self._repo = None
    
    def _get_repo(self):
        """延迟初始化 Git 仓库。"""
        if self._repo is None:
            try:
                from git import Repo
            except ImportError:
                raise ImportError("GitFileStore 需要 GitPython，请安装: pip install GitPython")
            
            if (self.repo_path / ".git").exists():
                self._repo = Repo(self.repo_path)
            else:
                self.repo_path.mkdir(parents=True, exist_ok=True)
                self._repo = Repo.init(self.repo_path)
                # 初始提交
                if self.auto_commit:
                    self._repo.config_writer().set_value("user", "name", self.committer_name).release()
                    self._repo.config_writer().set_value("user", "email", self.committer_email).release()
        return self._repo
    
    def _get_full_path(self, path: str) -> Path:
        """获取文件的完整路径。"""
        # 确保安全：路径必须在 repo_path 内
        full_path = (self.repo_path / path).resolve()
        if not str(full_path).startswith(str(self.repo_path.resolve())):
            raise ValueError(f"非法路径: {path}")
        return full_path
    
    async def save_file(self, path: str, content: bytes) -> str:
        """保存文件并可选择自动提交。"""
        full_path = self._get_full_path(path)
        full_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(full_path, 'wb') as f:
            f.write(content)
        
        if self.auto_commit:
            repo = self._get_repo()
            repo.git.add(str(full_path.relative_to(self.repo_path)))
            try:
                repo.git.commit(m=f"Update {path}", author=f"{self.committer_name} <{self.committer_email}>")
            except Exception:
                # 没有变化时忽略提交错误
                pass
        
        return str(full_path)
    
    async def get_file(self, path: str) -> Optional[bytes]:
        """获取文件内容。"""
        full_path = self._get_full_path(path)
        if not full_path.exists():
            return None
        with open(full_path, 'rb') as f:
            return f.read()
    
    async def get_file_stream(self, path: str) -> AsyncGenerator[bytes, None]:
        """流式获取文件内容。"""
        full_path = self._get_full_path(path)
        if not full_path.exists():
            return
        with open(full_path, 'rb') as f:
            while chunk := f.read(8192):
                yield chunk
    
    async def delete_file(self, path: str) -> bool:
        """删除文件。"""
        full_path = self._get_full_path(path)
        if not full_path.exists():
            return False
        
        full_path.unlink()
        
        if self.auto_commit:
            repo = self._get_repo()
            try:
                repo.git.rm(str(full_path.relative_to(self.repo_path)))
                repo.git.commit(m=f"Delete {path}", author=f"{self.committer_name} <{self.committer_email}>")
            except Exception:
                pass
        
        return True
    
    async def list_files(self, directory: str = "") -> list[str]:
        """列出目录中的文件。"""
        full_path = self._get_full_path(directory) if directory else self.repo_path
        if not full_path.exists():
            return []
        
        files = []
        for item in full_path.rglob("*"):
            if item.is_file() and ".git" not in str(item.relative_to(self.repo_path)):
                files.append(str(item.relative_to(self.repo_path)))
        return sorted(files)
    
    # ===== Git 特有方法 =====
    
    async def get_history(self, path: str, limit: int = 10) -> list[dict]:
        """获取文件的历史提交记录。"""
        repo = self._get_repo()
        full_path = self._get_full_path(path)
        
        if not full_path.exists():
            return []
        
        try:
            commits = list(repo.iter_commits(
                paths=str(full_path.relative_to(self.repo_path)),
                max_count=limit
            ))
            return [
                {
                    "hash": commit.hexsha,
                    "message": commit.message.strip(),
                    "author": commit.author.name,
                    "date": commit.committed_datetime.isoformat(),
                }
                for commit in commits
            ]
        except Exception:
            return []
    
    async def checkout(self, ref: str):
        """切换到指定分支或提交。"""
        repo = self._get_repo()
        repo.git.checkout(ref)
    
    async def create_branch(self, branch_name: str, checkout: bool = False):
        """创建新分支。"""
        repo = self._get_repo()
        new_branch = repo.create_head(branch_name)
        if checkout:
            new_branch.checkout()
    
    async def get_current_branch(self) -> str:
        """获取当前分支名称。"""
        repo = self._get_repo()
        return repo.active_branch.name
