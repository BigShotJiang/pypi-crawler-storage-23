# coding=utf-8
from __future__ import annotations

import asyncio
import json

import pytest

from turbo_agent_core.schema.events import RunLifecycleEvent, RunLifecyclePayload
from turbo_agent_store.decorators import RuntimeMonitor
from turbo_agent_store.event_constants import GLOBAL_LIFECYCLE_STREAM_KEY, trace_lifecycle_stream_key


class FakeRedis:
    def __init__(self):
        self.calls = []

    async def xadd(self, stream, fields):
        self.calls.append((stream, fields))
        return b"0-1"


@pytest.mark.asyncio
async def test_runtime_monitor_writes_trace_and_global_for_lifecycle():
    r = FakeRedis()
    m = RuntimeMonitor(r)

    event = RunLifecycleEvent(
        trace_id="trace_1",
        run_id="run_1",
        payload=RunLifecyclePayload(status="created", input_data={"conversation_id": "c1"}),
    )

    m.write(event)
    await asyncio.sleep(0.05)

    streams = [c[0] for c in r.calls]
    assert trace_lifecycle_stream_key("trace_1") in streams
    assert GLOBAL_LIFECYCLE_STREAM_KEY in streams
    await m.close()


@pytest.mark.asyncio
async def test_runtime_monitor_monitor_stream_yields_same_events():
    r = FakeRedis()
    m = RuntimeMonitor(r)

    async def source():
        yield RunLifecycleEvent(
            trace_id="t",
            run_id="r",
            payload=RunLifecyclePayload(status="created", input_data={"conversation_id": "c"}),
        )

    wrapped = m.monitor_stream(lambda: source())
    got = []
    async for e in wrapped():
        got.append(e)

    assert len(got) == 1
    assert got[0].type == "run.lifecycle"
    await m.close()
