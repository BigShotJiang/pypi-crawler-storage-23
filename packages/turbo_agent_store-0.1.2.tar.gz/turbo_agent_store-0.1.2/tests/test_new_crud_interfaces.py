# coding=utf-8
"""
测试新的CRUD接口是否正确实现

注意：此测试文件测试的是 cloud 模块的 Prisma 实现，
因为 Prisma 实现已经从 store 模块移动到 cloud 模块。
"""
import asyncio
import sys
from typing import Optional

# 添加src到路径
sys.path.insert(0, '/home/developerlmt/projects/turbo-agent/backend/packages/turbo-agent-core/src')
sys.path.insert(0, '/home/developerlmt/projects/turbo-agent/backend/packages/turbo-agent-cloud/src')

def test_imports():
    """测试所有新接口可以正确导入"""
    print("测试导入...")
    
    # 测试 DTOs 导入 - 从 cloud 模块导入
    from turbo_agent_cloud.store.dtos import (
        UserInfo, OrganizationInfo, ProjectInfo,
        CreateUserInput, CreateOrganizationInput, CreateProjectInput,
        UpdateUserInput, UpdateOrganizationInput, UpdateProjectInput,
        ExportUser, ExportOrganization, ExportProject
    )
    print("✓ DTOs 导入成功")
    
    # 测试 BaseConfigStore 导入
    from turbo_agent_core.store.config import BaseConfigStore
    print("✓ BaseConfigStore 导入成功")
    
    # 测试接口方法存在
    methods = [
        'create_user', 'update_user', 'delete_user', 'list_users',
        'create_organization', 'update_organization', 'delete_organization', 'list_organizations',
        'add_org_member', 'remove_org_member',
        'create_project', 'update_project', 'delete_project', 'list_projects',
        'add_project_member', 'remove_project_member',
        'get_model', 'save_model', 'list_models', 'delete_model',
        'save_model_instance', 'delete_model_instance',
        'get_platform', 'save_platform', 'list_platforms', 'delete_platform',
        'get_secret', 'save_secret', 'list_secrets', 'delete_secret',
        'get_knowledge_resource', 'save_knowledge_resource', 
        'list_knowledge_resources', 'delete_knowledge_resource',
    ]
    
    for method in methods:
        assert hasattr(BaseConfigStore, method), f"缺少方法: {method}"
    print(f"✓ 所有 {len(methods)} 个新接口方法已定义")
    
    # 测试 PrismaConfigStore 导入 - 从 cloud 模块
    from turbo_agent_cloud.store import PrismaConfigStore
    print("✓ PrismaConfigStore 导入成功 (from turbo_agent_cloud.store)")
    
    # 验证 PrismaConfigStore 实现了所有方法
    for method in methods:
        assert hasattr(PrismaConfigStore, method), f"PrismaConfigStore 缺少方法: {method}"
    print(f"✓ PrismaConfigStore 实现了所有 {len(methods)} 个新方法")
    
    print("\n所有导入测试通过!")
    return True

def test_dtos():
    """测试DTOs可以正确创建"""
    print("\n测试 DTOs 创建...")
    # 测试 DTOs 创建
    from turbo_agent_cloud.store.dtos import (
        CreateUserInput, CreateOrganizationInput, CreateProjectInput,
        UpdateUserInput, UpdateOrganizationInput, UpdateProjectInput
    )
    
    # 测试创建输入
    user_input = CreateUserInput(
        username="test_user",
        email="test@example.com",
        password="password123"
    )
    assert user_input.username == "test_user"
    print("✓ CreateUserInput 创建成功")
    
    org_input = CreateOrganizationInput(
        name="测试机构",
        name_en="test_org",
        description="这是一个测试机构"
    )
    assert org_input.name_en == "test_org"
    print("✓ CreateOrganizationInput 创建成功")
    
    project_input = CreateProjectInput(
        name="测试项目",
        name_en="test_project",
        org_id="org_123",
        member_ids=["user_1", "user_2"]
    )
    assert project_input.name_en == "test_project"
    print("✓ CreateProjectInput 创建成功")
    
    # 测试更新输入
    update_user = UpdateUserInput(email="new@example.com")
    assert update_user.email == "new@example.com"
    assert update_user.username is None
    print("✓ UpdateUserInput 创建成功")
    
    print("\n所有 DTOs 测试通过!")
    return True

async def test_prisma_config_store_signature():
    """测试 PrismaConfigStore 方法签名"""
    print("\n测试 PrismaConfigStore 方法签名...")
    
    from turbo_agent_cloud.store import PrismaConfigStore
    import inspect
    
    # 检查关键方法的参数
    methods_to_check = [
        'create_user',
        'create_organization', 
        'create_project',
        'save_platform',
        'save_secret',
        'save_knowledge_resource'
    ]
    
    for method_name in methods_to_check:
        method = getattr(PrismaConfigStore, method_name)
        sig = inspect.signature(method)
        print(f"  {method_name}{sig}")
    
    print("\n✓ 所有方法签名检查通过!")
    return True

def test_store_module_imports():
    """测试 store 模块的独立实现"""
    print("\n测试 store 模块独立实现...")
    
    # 测试 Memory 实现可以从 store 模块导入
    sys.path.insert(0, '/home/developerlmt/projects/turbo-agent/backend/packages/turbo-agent-store/src')
    
    from turbo_agent_store import (
        InMemoryCacheStore,
        InMemoryExecutionStore,
        MemoryQueueEventBroker,
        YAMLConfigStore,
        GitFileStore,
    )
    print("✓ Memory 实现导入成功 (from turbo_agent_store)")
    print("✓ YAML 实现导入成功 (from turbo_agent_store)")
    print("✓ Git 实现导入成功 (from turbo_agent_store)")
    
    print("\n✓ Store 模块独立实现测试通过!")
    return True

def main():
    """运行所有测试"""
    print("=" * 60)
    print("测试新的 CRUD 接口")
    print("=" * 60)
    
    try:
        test_imports()
        test_dtos()
        asyncio.run(test_prisma_config_store_signature())
        test_store_module_imports()
        
        print("\n" + "=" * 60)
        print("所有测试通过!")
        print("=" * 60)
        return 0
    except Exception as e:
        print(f"\n测试失败: {e}")
        import traceback
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    sys.exit(main())
