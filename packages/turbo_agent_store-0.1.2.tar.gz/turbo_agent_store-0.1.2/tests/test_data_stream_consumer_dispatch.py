# coding=utf-8
from __future__ import annotations

import pytest

from turbo_agent_core.schema.events import (
    ContentActionDeltaEvent,
    ContentActionDeltaPayload,
    ContentActionEndEvent,
    ContentActionEndPayload,
    ContentActionResultEndEvent,
    ContentActionResultEndPayload,
    ContentActionResultStartEvent,
    ContentActionResultStartPayload,
    ContentActionStartEvent,
    ContentActionStartPayload,
    ContentTextDeltaEvent,
    ContentTextDeltaPayload,
    ContentTextEndEvent,
    ContentTextEndPayload,
    ContentTextStartEvent,
    ContentTextStartPayload,
    RunLifecycleEvent,
    RunLifecyclePayload,
)

from turbo_agent_store.event_consumer import DataStreamConsumer
from turbo_agent_store.impl.memory.execution import InMemoryExecutionStore


@pytest.mark.asyncio
async def test_data_stream_consumer_dispatch_to_execution_store():
    store = InMemoryExecutionStore()
    created = RunLifecycleEvent(
        trace_id="t1",
        run_id="r1",
        payload=RunLifecyclePayload(status="created", input_data={"conversation_id": "c1"}),
    )

    consumer = DataStreamConsumer(
        redis=None,  # type: ignore[arg-type]
        trace_id="t1",
        execution_store=store,
        initial_created=created,
        start_stream_id=None,
    )

    await consumer.handle_event(created)
    await consumer.flush_now()
    assert "c1" in store.conversations

    await consumer.handle_event(
        ContentTextStartEvent(trace_id="t1", run_id="r1", payload=ContentTextStartPayload(mode="text"))
    )
    await consumer.handle_event(
        ContentTextDeltaEvent(trace_id="t1", run_id="r1", payload=ContentTextDeltaPayload(delta="你"))
    )
    await consumer.handle_event(
        ContentTextDeltaEvent(trace_id="t1", run_id="r1", payload=ContentTextDeltaPayload(delta="好"))
    )
    await consumer.handle_event(
        ContentTextEndEvent(trace_id="t1", run_id="r1", payload=ContentTextEndPayload(full_text="你好"))
    )

    assert "t1" in store.messages
    assert store.messages["t1"].content == "你好"

    # Action
    await consumer.handle_event(
        ContentActionStartEvent(
            trace_id="t1",
            run_id="r1",
            payload=ContentActionStartPayload(action_id="a1", index=0, name="search", is_client=False),
        )
    )
    await consumer.handle_event(
        ContentActionDeltaEvent(
            trace_id="t1",
            run_id="r1",
            payload=ContentActionDeltaPayload(action_id="a1", part="args", delta="{\"q\":\"x\"}"),
        )
    )
    await consumer.handle_event(
        ContentActionEndEvent(
            trace_id="t1",
            run_id="r1",
            payload=ContentActionEndPayload(action_id="a1", full_arguments={"q": "x"}),
        )
    )

    assert "a1" in store.actions
    assert store.actions["a1"].full_arguments == {"q": "x"}

    # Action result
    await consumer.handle_event(
        ContentActionResultStartEvent(
            trace_id="t1",
            run_id="r1",
            payload=ContentActionResultStartPayload(action_id="a1", status="success"),
        )
    )
    await consumer.handle_event(
        ContentActionResultEndEvent(
            trace_id="t1",
            run_id="r1",
            payload=ContentActionResultEndPayload(action_id="a1", full_result={"ok": True}),
        )
    )

    assert store.actions["a1"].full_result == {"ok": True}
