import json
import logging
import time

from bruin._connection import GCPConnection, get_connection
from bruin.exceptions import ConnectionNotFoundError, ConnectionTypeError, QueryError

logger = logging.getLogger("bruin")

# Connection types that use the generic PEP 249 (DBAPI) cursor path.
_DBAPI_TYPES = frozenset((
    "postgres", "redshift", "mssql", "synapse", "fabric", "mysql",
    "athena", "trino", "sqlite", "oracle", "db2", "hana", "spanner", "vertica",
))

# Subset of _DBAPI_TYPES that require an explicit commit() for DDL/DML.
_TRANSACTIONAL = frozenset((
    "postgres", "redshift", "mssql", "synapse", "fabric", "mysql",
    "sqlite", "oracle", "db2", "hana", "spanner", "vertica",
))


def _annotate_sql(sql: str) -> str:
    """Prepend a ``@bruin.config`` comment so queries are traceable."""
    from bruin._context import context

    meta = {
        "asset": context.asset_name or "",
        "type": "python_query",
        "pipeline": context.pipeline or "",
    }
    return f"-- @bruin.config: {json.dumps(meta, separators=(',', ':'))}\n{sql}"


def _run_query(conn, sql: str):
    """Core query execution shared by ``query()`` and ``Connection.query()``."""
    if conn.type == "generic":
        raise ConnectionTypeError(
            f"Cannot run queries against generic connection '{conn.name}'."
        )

    annotated = _annotate_sql(sql)

    logger.debug(
        "Executing query on '%s' (%s, %d chars)",
        conn.name, conn.type, len(sql),
    )

    t0 = time.monotonic()
    try:
        result = _execute(conn, annotated)
    except ConnectionTypeError:
        raise
    except Exception as exc:
        raise QueryError(
            f"Query failed on connection '{conn.name}' ({conn.type}): {exc}"
        ) from exc

    elapsed = time.monotonic() - t0
    if result is not None:
        logger.debug(
            "Query on '%s' complete → %d rows x %d cols in %.2fs",
            conn.name, len(result), len(result.columns), elapsed,
        )
    else:
        logger.debug("Query on '%s' complete (no result set) in %.2fs", conn.name, elapsed)

    return result


def query(sql: str, connection: str | None = None) -> "pd.DataFrame | None":
    """Execute *sql* against a Bruin-managed connection.

    Parameters
    ----------
    sql : str
        The SQL statement to execute.
    connection : str, optional
        Connection name.  When *None*, falls back to the asset's default
        connection (``BRUIN_CONNECTION`` env var).

    Returns
    -------
    pandas.DataFrame or None
        A DataFrame for data-returning statements (SELECT, WITH, ...),
        ``None`` for DDL / DML (CREATE, INSERT, UPDATE, DELETE, ...).
    """
    if connection is None:
        from bruin._context import context
        connection = context.connection
        if connection is None:
            raise ConnectionNotFoundError(
                "No connection specified and no default connection set "
                "(BRUIN_CONNECTION env var is missing). "
                "Pass a connection name explicitly: query(sql, 'my_connection')"
            )

    conn = get_connection(connection)
    return _run_query(conn, sql)


def _execute(conn, sql: str):
    if isinstance(conn, GCPConnection):
        client = conn.bigquery()
        job = client.query(sql)
        rows = job.result()
        if rows.schema:
            return rows.to_dataframe()
        return None

    if conn.type == "snowflake":
        cur = conn.client.cursor()
        try:
            cur.execute(sql)
            if cur.description:
                return cur.fetch_pandas_all()
            return None
        finally:
            cur.close()

    if conn.type in _DBAPI_TYPES:
        import pandas as pd
        client = conn.client
        cur = client.cursor()
        try:
            cur.execute(sql)
            if cur.description:
                cols = [desc[0] for desc in cur.description]
                return pd.DataFrame(cur.fetchall(), columns=cols)
            if conn.type in _TRANSACTIONAL:
                client.commit()
            return None
        finally:
            cur.close()

    if conn.type in ("duckdb", "motherduck"):
        result = conn.client.execute(sql)
        if result.description:
            return result.fetchdf()
        return None

    if conn.type == "databricks":
        cur = conn.client.cursor()
        try:
            cur.execute(sql)
            if cur.description:
                import pandas as pd
                cols = [desc[0] for desc in cur.description]
                return pd.DataFrame(cur.fetchall(), columns=cols)
            return None
        finally:
            cur.close()

    if conn.type == "clickhouse":
        result = conn.client.query(sql)
        if result.column_names:
            import pandas as pd
            return pd.DataFrame(
                result.result_rows,
                columns=result.column_names,
            )
        return None

    raise ConnectionTypeError(
        f"query() does not support connection type '{conn.type}'."
    )
