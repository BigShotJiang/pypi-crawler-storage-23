# Rubycond_OF
Tool for opening data files in the most common formats

<img width="1153" height="774" alt="Full_plot" src="https://github.com/user-attachments/assets/d9587bbf-2398-4baa-8dc4-288be1ef7866" />


  
# Manual


<img width="276" height="50" alt="1_Black" src="https://github.com/user-attachments/assets/c28534c4-8723-4766-b2f5-60668a92380c" />

  - **Show plain text**  
    - Opens a file as text to check the syntax
<img width="279" height="174" alt="2_green" src="https://github.com/user-attachments/assets/dcd0d3b3-509f-402e-b1c9-b28bac5795c1" />

  - **Decimal separator**
    - Select point or comma
  - **Commented lines (ch)**
    - The characters or list of characters used to indicate the start of a comment
  - **Columns delimiter**
    - Available options: space, tab, comma if decimal separator is point, point if decimal separator is comma, semicolon
  - **Skip first (n) lines**
    - Skip the first skiprows lines, including comments
  - **Open**
    - Select the file
<img width="276" height="49" alt="3_green" src="https://github.com/user-attachments/assets/a2c539b1-924b-4063-b2e4-56af277087dd" />

  - **Open numpy (npy)**
    - Load arrays from .npy files
<img width="278" height="143" alt="4_blue" src="https://github.com/user-attachments/assets/c8caffdd-3f8e-47a5-8504-430261a6988c" />

  - **Plot**
    - Use the **Plot** command to add new graphs from the selected X and Y columns in the **Plot** tab. Use the **Delete** button to remove them
<img width="278" height="83" alt="5_blue" src="https://github.com/user-attachments/assets/5c192700-2da0-486f-afd3-33d17fe6a029" />

  - **Accept**
    - Click Accept to send selected X and Y data to the main program
  - **Cancel**
    - Cancel
  
# Install
Use pip to install the program **within a virtual environment (strongly recommended).**  
[Here's a short tutorial on installing a virtual environment.](https://github.com/CelluleProjet/Install/tree/main?tab=readme-ov-file#install-virtual-environment)
```bash
pip install rubycond_OF
```
# About
## Author

**Yiuri Garino**  

## Contacts

**Yiuri Garino**  
- yiuri.garino@cnrs.fr
   
**Silvia Boccato**
- silvia.boccato@cnrs.fr
  
<img src="https://github.com/CelluleProjet/Rubycond/assets/83216683/b728fe64-2752-4ecd-843b-09d335cf4f93" width="100" height="100">
<img src="https://github.com/CelluleProjet/Rubycond/assets/83216683/0a81ce1f-089f-49d8-ae65-d19af8078492" width="100" height="100">


[Cellule Projet](http://impmc.sorbonne-universite.fr/fr/plateformes-et-equipements/cellule-projet.html) @ [IMPMC](http://impmc.sorbonne-universite.fr/en/index.html)


## License
**Rubycond_OF**: Tool for opening data files in the most common formats

Copyright (c) 2022-2026 Yiuri Garino

**Rubycond_OF** is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.

## Release notes

Version 0.2.0 Release 260301: First release  
