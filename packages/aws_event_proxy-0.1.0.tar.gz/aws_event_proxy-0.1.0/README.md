# aws-event-proxy

An AWS Lambda handler that proxies events to a configurable HTTP endpoint.

Forwards events from any AWS source (SQS, SNS, S3, DynamoDB Streams, etc.) to an external HTTP endpoint via POST, including Lambda execution context in the request headers.

## Installation

```bash
pip install aws-event-proxy
```

## Configuration

Set the `PROXY_TARGET_URL` environment variable in your Lambda function to the URL you want events forwarded to.

## Usage

Set your Lambda handler to:

```
aws_event_proxy.handler
```

### What it does

- POSTs the raw Lambda event as JSON to `PROXY_TARGET_URL`
- Attaches Lambda context metadata as the `X-Lambda-Context` request header
- Returns the parsed JSON response body from the target
- Logs proxy activity and re-raises errors to the Lambda runtime

## Development

```bash
make setup        # install dependencies and create .venv
poetry run pytest # run tests
make build        # build package
```

## Publishing

```bash
poetry publish --build
```
