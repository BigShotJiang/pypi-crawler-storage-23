import json
import os
import urllib.request
import urllib.error


def _context_to_dict(context):
    try:
        attrs = vars(context)
    except TypeError:
        attrs = {}

    result = {}
    for key, value in attrs.items():
        if key.startswith("_"):
            continue
        try:
            json.dumps(value)
            result[key] = value
        except (TypeError, ValueError):
            pass

    try:
        result["remaining_time_in_millis"] = context.get_remaining_time_in_millis()
    except AttributeError:
        pass

    return result


def handler(event, context):
    target_url = os.environ.get("PROXY_TARGET_URL")
    if not target_url:
        raise ValueError("PROXY_TARGET_URL environment variable not set")

    event_source = event.get("eventSource") or (
        event.get("Records", [{}])[0].get("eventSource") if event.get("Records") else "unknown"
    )
    print(f"proxy: target={target_url} source={event_source} records={len(event.get('Records', []))}")

    payload = json.dumps(event).encode("utf-8")
    req = urllib.request.Request(
        target_url,
        data=payload,
        headers={
            "Content-Type": "application/json",
            "X-Lambda-Context": json.dumps(_context_to_dict(context)),
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=25) as response:
            body = response.read().decode("utf-8")
            print(f"proxy: response status={response.status}")
            try:
                return json.loads(body)
            except json.JSONDecodeError:
                return {"statusCode": response.status, "body": body}
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8")
        print(f"proxy: HTTP {e.code} from {target_url}: {body}")
        raise
    except urllib.error.URLError as e:
        print(f"proxy: failed to reach {target_url}: {e.reason} (errno={getattr(e.reason, 'errno', 'n/a')})")
        raise
