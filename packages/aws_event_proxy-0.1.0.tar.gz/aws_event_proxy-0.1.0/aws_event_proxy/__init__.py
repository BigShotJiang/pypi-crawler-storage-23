from aws_event_proxy.handler import handler

__all__ = ["handler"]
