from ..kawa_base_e2e_test import KawaBaseTest


class TestReporting(KawaBaseTest):

    def test_workspace_member_reporting(self):
        r = self.kawa.reporting().generate_workspace_member_list_report()
        self.assertListEqual(list(r.columns), [
            'workspace',
            'name',
            'email',
            'unique_id',
            'is_admin',
            'can_see_all_data',
            'can_manage_security',
            'can_manage_users',
            'workspace_permissions'
        ])

    def test_principal_reporting(self):
        r = self.kawa.reporting().generate_user_list_report()
        print(list(r.columns))
        self.assertListEqual(list(r.columns), [
            'internal_id',
            'email',
            'name',
            'unique_id',
            'forbidden_data_source_types',
            'is_admin',
            'status',
            'global_permissions'
        ])

    def test_team_member_reporting(self):
        teams = self.kawa.reporting().generate_team_member_list_report()
        self.assertIsInstance(teams, list)

        team = teams[0]
        # validate team
        self.assertIn('id', team)
        self.assertIn('name', team)
        self.assertIn('description', team)
        self.assertIn('team_type', team)
        self.assertIn('is_everyone', team)
        self.assertIn('security_alias', team)
        self.assertIn('members', team)
        self.assertIn('member_teams', team)
        self.assertIsInstance(team['members'], list)
        self.assertIsInstance(team['member_teams'], list)

        # Validate member
        everyone_team = next((t for t in teams if t['is_everyone']), None)
        self.assertIsNotNone(everyone_team)
        member = everyone_team['members'][0]
        self.assertIn('id', member)
        self.assertIn('email', member)
        self.assertIn('name', member)
        self.assertIn('unique_id', member)
        self.assertIn('status', member)
        self.assertIn('role', member)
        self.assertIn('is_team_admin', member)
