# coderace Benchmark Results

Generated: 2026-02-27 15:37 UTC

Benchmark ID: `bench-20260227-153601`

| Task | claude | codex |
|------|------|------|
| fibonacci | 35.0 (34s) | 35.0 (62s) |
|------|------|------|
| **TOTAL** | **35.0** | **35.0** |
| **Win Rate** | 100% | 100% |
| **Avg Time** | 33.6s | 61.6s |
| **Total Cost** | $0.0218 | - |

## Task Insights

| Task | Best Agent | Best Score | Avg Score | Fastest Agent |
|------|-----------|-----------|----------|--------------|
| fibonacci | claude | 35.0 | 35.0 | claude (34s) |
