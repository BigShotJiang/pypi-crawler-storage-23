# coderace Benchmark Results

Generated: 2026-02-27 15:55 UTC

Benchmark ID: `bench-20260227-154647`

| Task | claude | codex |
|------|------|------|
| binary-search-tree | 100.0 (47s) | 100.0 (33s) |
| csv-analyzer | 100.0 (71s) | 100.0 (137s) |
| http-server | 100.0 (64s) | 100.0 (185s) |
|------|------|------|
| **TOTAL** | **300.0** | **300.0** |
| **Win Rate** | 100% | 100% |
| **Avg Time** | 60.8s | 118.2s |
| **Total Cost** | $0.1669 | - |

## Task Insights

| Task | Best Agent | Best Score | Avg Score | Fastest Agent |
|------|-----------|-----------|----------|--------------|
| binary-search-tree | claude | 100.0 | 100.0 | codex (33s) |
| csv-analyzer | claude | 100.0 | 100.0 | claude (71s) |
| http-server | claude | 100.0 | 100.0 | claude (64s) |
