# coderace Benchmark Results

Generated: 2026-02-27 15:46 UTC

Benchmark ID: `bench-20260227-154058`

| Task | claude | codex |
|------|------|------|
| fibonacci | 100.0 (25s) | 100.0 (71s) |
| json-parser | 100.0 (66s) | 100.0 (42s) |
| markdown-to-html | 100.0 (74s) | 100.0 (48s) |
|------|------|------|
| **TOTAL** | **300.0** | **300.0** |
| **Win Rate** | 100% | 100% |
| **Avg Time** | 55.1s | 53.5s |
| **Total Cost** | $0.1471 | - |

## Task Insights

| Task | Best Agent | Best Score | Avg Score | Fastest Agent |
|------|-----------|-----------|----------|--------------|
| fibonacci | claude | 100.0 | 100.0 | claude (25s) |
| json-parser | claude | 100.0 | 100.0 | codex (42s) |
| markdown-to-html | claude | 100.0 | 100.0 | codex (48s) |
