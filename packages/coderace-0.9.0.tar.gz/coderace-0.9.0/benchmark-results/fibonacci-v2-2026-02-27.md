# coderace Benchmark Results

Generated: 2026-02-27 15:40 UTC

Benchmark ID: `bench-20260227-153946`

| Task | claude | codex |
|------|------|------|
| fibonacci | 100.0 (34s) | 100.0 (26s) |
|------|------|------|
| **TOTAL** | **100.0** | **100.0** |
| **Win Rate** | 100% | 100% |
| **Avg Time** | 33.7s | 25.9s |
| **Total Cost** | $0.0173 | - |

## Task Insights

| Task | Best Agent | Best Score | Avg Score | Fastest Agent |
|------|-----------|-----------|----------|--------------|
| fibonacci | claude | 100.0 | 100.0 | codex (26s) |
