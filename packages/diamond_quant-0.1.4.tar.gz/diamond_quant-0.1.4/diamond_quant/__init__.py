"""
Diamond Quant - MLB MCMC Prediction Tool
"""

__version__ = "0.1.2"
