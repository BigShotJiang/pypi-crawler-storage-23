"""
CLI for Diamond Quant
"""

import click
import subprocess
import sys
import os
import threading
import time
import signal
from pathlib import Path
from .config import get_api_key, save_api_key
from .auth import validate_api_key


@click.group()
def cli():
    """Diamond Quant - MLB MCMC Prediction Tool"""
    pass


def get_package_root():
    """Get the root directory of the installed package"""
    return Path(__file__).parent


def start_backend(api_dir: Path, port: int = 8000):
    """Start the FastAPI backend server"""
    import uvicorn
    import sys
    
    # Add API directory to Python path so "main" can be imported
    if str(api_dir) not in sys.path:
        sys.path.insert(0, str(api_dir))
    
    # Add parent directory so "from api.tier_system import ..." works
    parent_dir = str(api_dir.parent)
    if parent_dir not in sys.path:
        sys.path.insert(0, parent_dir)
    
    # Change to API directory
    original_cwd = os.getcwd()
    os.chdir(api_dir)
    
    try:
        # Set environment variable for API port
        os.environ['API_PORT'] = str(port)
        
        # Start uvicorn
        uvicorn.run(
            "main:app",
            host="0.0.0.0",
            port=port,
            reload=False,
            log_level="info"
        )
    finally:
        os.chdir(original_cwd)


def start_frontend(frontend_dir: Path, port: int = 3000, api_url: str = "http://localhost:8000"):
    """Start the Next.js frontend server"""
    # Set environment variables
    env = os.environ.copy()
    env['NEXT_PUBLIC_API_URL'] = api_url
    env['PORT'] = str(port)
    
    # Install dependencies if node_modules is missing
    if not (frontend_dir / "node_modules").exists():
        click.echo("Installing frontend dependencies...")
        subprocess.run(["npm", "install"], cwd=frontend_dir, check=True)
    
    # Build if .next directory doesn't exist
    if not (frontend_dir / ".next").exists():
        click.echo("Building frontend...")
        subprocess.run(["npm", "run", "build"], cwd=frontend_dir, check=True)
    
    # Start Next.js server
    subprocess.run(
        ["npm", "start"],
        cwd=frontend_dir,
        env=env,
        check=True
    )


def resolve_tier(api_key: str) -> str:
    """
    Resolve the user's tier from their API key.
    Checks against the remote Supabase api_keys table.
    Returns tier string or None on failure.
    """
    import hashlib
    
    try:
        import psycopg2
        from dotenv import load_dotenv
        
        # Try to load DATABASE_URL for tier resolution
        load_env()
        database_url = os.getenv('DATABASE_URL')
        
        if not database_url:
            # No DB access - can't resolve tier remotely
            # Fall back to local config if available
            return _get_cached_tier()
        
        key_hash = hashlib.sha256(api_key.encode()).hexdigest()
        conn = psycopg2.connect(database_url)
        cur = conn.cursor()
        
        cur.execute("""
            SELECT COALESCE(tier, 'BASE') as tier, is_active, expires_at
            FROM api_keys
            WHERE key_hash = %s
            LIMIT 1
        """, (key_hash,))
        
        row = cur.fetchone()
        conn.close()
        
        if not row:
            return None
        
        tier, is_active, expires_at = row
        if not is_active:
            return None
        
        # Cache the tier locally
        _cache_tier(tier)
        return tier
        
    except Exception as e:
        # If remote check fails, use cached tier
        cached = _get_cached_tier()
        if cached:
            return cached
        return "BASE"


def _get_cached_tier() -> str:
    """Get cached tier from local config."""
    import json
    config_file = Path.home() / ".diamond-quant" / "config.json"
    if config_file.exists():
        try:
            with open(config_file, 'r') as f:
                config = json.load(f)
                return config.get('tier', 'BASE')
        except:
            pass
    return "BASE"


def _cache_tier(tier: str):
    """Cache tier in local config."""
    import json
    config_dir = Path.home() / ".diamond-quant"
    config_dir.mkdir(parents=True, exist_ok=True)
    config_file = config_dir / "config.json"
    
    config = {}
    if config_file.exists():
        try:
            with open(config_file, 'r') as f:
                config = json.load(f)
        except:
            pass
    
    config['tier'] = tier
    with open(config_file, 'w') as f:
        json.dump(config, f)


def load_env():
    """Load .env from common locations (in priority order)"""
    from dotenv import load_dotenv
    
    env_locations = [
        Path.cwd() / ".env",                        # current directory
        Path.home() / ".diamond-quant" / ".env",     # user config dir
        get_package_root().parent / ".env",           # repo root (dev mode)
    ]
    
    for env_path in env_locations:
        if env_path.exists():
            load_dotenv(env_path)
            return str(env_path)
    
    return None


@cli.command()
@click.option('--frontend-port', default=3000, help='Port for frontend server')
@click.option('--backend-port', default=8000, help='Port for backend API server')
@click.option('--skip-auth', is_flag=True, help='Skip API key authentication check')
@click.option('--api-url', default=None, help='Backend API URL (defaults to http://localhost:{backend-port})')
@click.option('--env-file', default=None, type=click.Path(exists=True), help='Path to .env file')
def start(frontend_port: int, backend_port: int, skip_auth: bool, api_url: str, env_file: str):
    """Start Diamond Quant application (frontend + backend)"""
    click.echo("Starting Diamond Quant...")
    click.echo("")
    
    # Load environment variables
    if env_file:
        from dotenv import load_dotenv
        load_dotenv(env_file)
        click.echo(f"Loaded env from: {env_file}")
    else:
        loaded_from = load_env()
        if loaded_from:
            click.echo(f"Loaded env from: {loaded_from}")
        else:
            click.echo("[WARN] No .env file found")
            click.echo("Place a .env file in one of:")
            click.echo(f"   - {Path.cwd() / '.env'}")
            click.echo(f"   - {Path.home() / '.diamond-quant' / '.env'}")
    
    # Get package directories
    package_root = get_package_root()
    frontend_dir = package_root / "static" / "frontend"
    api_dir = package_root / "static" / "api"
    
    # Check if directories exist
    if not frontend_dir.exists():
        click.echo("[ERROR] Frontend directory not found in package")
        click.echo("Make sure the package was built correctly")
        sys.exit(1)
    
    if not api_dir.exists():
        click.echo("[ERROR] API directory not found in package")
        click.echo("Make sure the package was built correctly")
        sys.exit(1)
    
    # Set API URL
    if api_url is None:
        api_url = f"http://localhost:{backend_port}"
    
    # Resolve API key and tier
    user_tier = "BASE"
    api_key = get_api_key()
    
    if not skip_auth:
        if api_key:
            click.echo("Found API key, resolving tier...")
            tier_result = resolve_tier(api_key)
            if tier_result:
                user_tier = tier_result
                click.echo(f"Tier: {user_tier}")
            else:
                click.echo("[WARN] Could not resolve tier, defaulting to BASE")
        else:
            click.echo("[WARN] No API key found")
            click.echo("Run 'diamond-quant auth' to set an API key")
            click.echo("   Or use --skip-auth to proceed without authentication")
            if not click.confirm("Continue without API key?"):
                sys.exit(1)
    
    # Set tier and API key as env vars so backend can pick them up
    os.environ['DIAMOND_QUANT_TIER'] = user_tier
    if api_key:
        os.environ['DIAMOND_QUANT_API_KEY'] = api_key
    
    # Determine database mode
    if user_tier == "ENDBOSS":
        db_url = os.getenv('DATABASE_URL')
        if db_url:
            click.echo("Central DB mode: Supabase PostgreSQL")
        else:
            click.echo("[WARN] No DATABASE_URL found, falling back to local SQLite")
            os.environ['DIAMOND_QUANT_TIER'] = 'BASE'
    else:
        from pathlib import Path as P
        click.echo(f"{user_tier} mode: Local SQLite (~/.diamond-quant/data.db)")
    
    click.echo("")
    click.echo(f"Starting frontend on port {frontend_port}...")
    click.echo(f"Starting backend API on port {backend_port}...")
    click.echo(f"Frontend will connect to: {api_url}")
    click.echo("")
    click.echo("Press Ctrl+C to stop both servers")
    click.echo("")
    
    # Start backend in a separate thread
    backend_thread = threading.Thread(
        target=start_backend,
        args=(api_dir, backend_port),
        daemon=True
    )
    backend_thread.start()
    
    # Give backend time to start
    time.sleep(2)
    
    try:
        # Start frontend (this will block)
        start_frontend(frontend_dir, frontend_port, api_url)
    except KeyboardInterrupt:
        click.echo("\nShutting down...")
        sys.exit(0)
    except subprocess.CalledProcessError as e:
        click.echo(f"[ERROR] Error starting server: {e}")
        sys.exit(1)


@cli.command()
@click.option('--api-url', default='http://localhost:8000', help='Backend API URL')
def auth(api_url: str):
    """Set or update API key"""
    click.echo("API Key Configuration")
    click.echo("")
    
    current_key = get_api_key()
    if current_key:
        click.echo(f"Current API key: {current_key[:8]}...{current_key[-4:]}")
        if not click.confirm("Update API key?"):
            return
    
    api_key = click.prompt("Enter API key", hide_input=True)
    
    if not api_key.strip():
        click.echo("[ERROR] API key cannot be empty")
        sys.exit(1)
    
    # Validate key
    click.echo("Validating API key...")
    is_valid, error = validate_api_key(api_key, api_url)
    
    if is_valid:
        if save_api_key(api_key):
            click.echo("API key saved successfully")
        else:
            click.echo("[ERROR] Failed to save API key")
            sys.exit(1)
    else:
        click.echo(f"[WARN] Validation failed: {error}")
        if click.confirm("Save anyway?"):
            save_api_key(api_key)
            click.echo("API key saved (not validated)")
        else:
            sys.exit(1)


@cli.command()
@click.option('--api-url', default='http://localhost:8000', help='Backend API URL for validation')
def status(api_url: str):
    """Check authentication status"""
    api_key = get_api_key()
    
    if api_key:
        click.echo(f"API key configured: {api_key[:8]}...{api_key[-4:]}")
        click.echo("")
        click.echo("Validating...")
        is_valid, error = validate_api_key(api_key, api_url)
        if is_valid:
            click.echo("API key is valid")
        else:
            if "Cannot connect" in error or "timed out" in error:
                click.echo(f"[WARN] Cannot validate (server may not be running): {error}")
            else:
                click.echo(f"[ERROR] API key is invalid: {error}")
    else:
        click.echo("[ERROR] No API key configured")
        click.echo("Run 'diamond-quant auth' to set an API key")


def main():
    cli()


if __name__ == "__main__":
    main()
