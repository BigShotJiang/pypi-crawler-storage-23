"""
Dual-mode database manager for Diamond Quant.

ENDBOSS tier → Supabase PostgreSQL (Joe's central DB)
All other tiers → Local SQLite (~/.diamond-quant/data.db)

Both backends expose the same interface so the API layer doesn't care.

KEY DESIGN: The SQLite wrapper transparently converts PostgreSQL-style SQL
(%s placeholders, PG functions) so that NONE of the 40+ endpoint functions
need to change their queries.
"""

import os
import sqlite3
import re
import json
import logging
from pathlib import Path
from typing import Optional, Any, List, Tuple
from contextlib import contextmanager

logger = logging.getLogger(__name__)

# Where local users store their data
LOCAL_DATA_DIR = Path.home() / ".diamond-quant"
LOCAL_DB_PATH = LOCAL_DATA_DIR / "data.db"


# ============================================================================
# SQLite wrappers that transparently handle PostgreSQL → SQLite translation
# This means ALL existing endpoint code (40+ psycopg2.connect calls) can be
# replaced with get_db().get_connection() with ZERO SQL changes.
# ============================================================================

def pg_to_sqlite(sql: str) -> str:
    """
    Convert PostgreSQL SQL to SQLite-compatible SQL.
    Handles the most common differences.
    """
    result = sql
    
    # %s → ? (parameter placeholder)
    result = result.replace("%s", "?")
    
    # ILIKE → LIKE (SQLite is case-insensitive by default for ASCII)
    result = re.sub(r'\bILIKE\b', 'LIKE', result, flags=re.IGNORECASE)
    
    # TIMESTAMPTZ → TEXT
    result = re.sub(r'\bTIMESTAMPTZ\b', 'TEXT', result, flags=re.IGNORECASE)
    
    # BIGSERIAL → INTEGER
    result = re.sub(r'\bBIGSERIAL\b', 'INTEGER', result, flags=re.IGNORECASE)
    
    # SERIAL → INTEGER  
    result = re.sub(r'\bSERIAL\b', 'INTEGER', result, flags=re.IGNORECASE)
    
    # JSONB / JSON → TEXT (store as JSON string)
    result = re.sub(r'\bJSONB\b', 'TEXT', result, flags=re.IGNORECASE)
    
    # NOW() → datetime('now')
    result = re.sub(r'\bNOW\(\)', "datetime('now')", result, flags=re.IGNORECASE)
    
    # CURRENT_DATE stays the same (both support it)
    
    # DATE_TRUNC('day', col) → date(col)
    result = re.sub(
        r"DATE_TRUNC\s*\(\s*'day'\s*,\s*([^)]+)\)",
        r"date(\1)",
        result,
        flags=re.IGNORECASE
    )
    
    # DATE_TRUNC('month', NOW()) → strftime('%Y-%m-01', 'now')
    result = re.sub(
        r"DATE_TRUNC\s*\(\s*'month'\s*,\s*NOW\(\)\s*\)",
        "strftime('%Y-%m-01', 'now')",
        result,
        flags=re.IGNORECASE
    )
    
    # DATE_TRUNC('month', col) → strftime('%Y-%m-01', col)
    result = re.sub(
        r"DATE_TRUNC\s*\(\s*'month'\s*,\s*([^)]+)\)",
        r"strftime('%Y-%m-01', \1)",
        result,
        flags=re.IGNORECASE
    )
    
    # DATE_TRUNC('week', col) → strftime('%Y-W%W', col)  (groups by ISO week)
    result = re.sub(
        r"DATE_TRUNC\s*\(\s*'week'\s*,\s*([^)]+)\)",
        r"strftime('%Y-W%W', \1)",
        result,
        flags=re.IGNORECASE
    )
    
    # datetime('now') +/- INTERVAL '1 month' → datetime('now', '+1 month')
    # Handle + INTERVAL
    result = re.sub(
        r"datetime\('now'\)\s*\+\s*INTERVAL\s+'(\d+)\s+(month|day|hour|minute|year|second)s?'",
        r"datetime('now', '+\1 \2')",
        result,
        flags=re.IGNORECASE
    )
    # Handle - INTERVAL
    result = re.sub(
        r"datetime\('now'\)\s*-\s*INTERVAL\s+'(\d+)\s+(month|day|hour|minute|year|second)s?'",
        r"datetime('now', '-\1 \2')",
        result,
        flags=re.IGNORECASE
    )
    # Generic + INTERVAL (not preceded by datetime) — for compound date arithmetic
    result = re.sub(
        r"\+\s*INTERVAL\s+'(\d+)\s+(month|day|hour|minute|year|second)s?'",
        r", '+\1 \2'",
        result,
        flags=re.IGNORECASE
    )
    
    # CONCAT(a, b, c) → (a || b || c)
    def _concat_replace(m):
        args = m.group(1)
        parts = [p.strip() for p in args.split(',')]
        return '(' + ' || '.join(parts) + ')'
    result = re.sub(r'\bCONCAT\s*\(([^)]+)\)', _concat_replace, result, flags=re.IGNORECASE)
    
    # FILTER (WHERE condition) in aggregates → rewrite to CASE WHEN
    # COUNT(*) FILTER (WHERE x) → SUM(CASE WHEN x THEN 1 ELSE 0 END)
    result = re.sub(
        r'COUNT\s*\(\s*\*\s*\)\s*FILTER\s*\(\s*WHERE\s+([^)]+)\)',
        r'SUM(CASE WHEN \1 THEN 1 ELSE 0 END)',
        result,
        flags=re.IGNORECASE
    )
    # SUM(col) FILTER (WHERE x) → SUM(CASE WHEN x THEN col ELSE 0 END)
    result = re.sub(
        r'SUM\s*\(([^)]+)\)\s*FILTER\s*\(\s*WHERE\s+([^)]+)\)',
        r'SUM(CASE WHEN \2 THEN \1 ELSE 0 END)',
        result,
        flags=re.IGNORECASE
    )
    # AVG(col) FILTER (WHERE x) → AVG(CASE WHEN x THEN col ELSE NULL END)
    result = re.sub(
        r'AVG\s*\(([^)]+)\)\s*FILTER\s*\(\s*WHERE\s+([^)]+)\)',
        r'AVG(CASE WHEN \2 THEN \1 ELSE NULL END)',
        result,
        flags=re.IGNORECASE
    )
    
    # PERCENTILE_CONT(n) WITHIN GROUP (ORDER BY col) → just use AVG(col) as approximation
    result = re.sub(
        r'PERCENTILE_CONT\s*\([^)]*\)\s*WITHIN\s+GROUP\s*\(\s*ORDER\s+BY\s+(\w+)\s*\)',
        r'AVG(\1)',
        result,
        flags=re.IGNORECASE
    )
    
    # ::date, ::text, ::integer, ::float etc (PG cast) → nothing (SQLite is dynamically typed)
    result = re.sub(r'::\w+', '', result)
    
    # VARCHAR(N) → TEXT
    result = re.sub(r'VARCHAR\(\d+\)', 'TEXT', result, flags=re.IGNORECASE)
    
    # RETURNING id → RETURNING id (SQLite 3.35+ supports this)
    # No change needed
    
    # COALESCE, ON CONFLICT ... DO UPDATE → both supported
    # No change needed
    
    # FLOOR(expr) → CAST(expr AS INTEGER) (SQLite doesn't have FLOOR)
    # Use a function to find matching parens
    def _replace_floor(s):
        idx = 0
        out = []
        lower = s.lower()
        while idx < len(s):
            if lower[idx:idx+5] == 'floor' and idx + 5 < len(s):
                # check for FLOOR(
                j = idx + 5
                while j < len(s) and s[j] == ' ':
                    j += 1
                if j < len(s) and s[j] == '(':
                    # Find matching close paren
                    depth = 1
                    k = j + 1
                    while k < len(s) and depth > 0:
                        if s[k] == '(': depth += 1
                        elif s[k] == ')': depth -= 1
                        k += 1
                    inner = s[j+1:k-1]
                    out.append(f'CAST({inner} AS INTEGER)')
                    idx = k
                    continue
            out.append(s[idx])
            idx += 1
        return ''.join(out)
    result = _replace_floor(result)
    
    # TRUE/FALSE → 1/0
    result = re.sub(r'\bTRUE\b', '1', result)
    result = re.sub(r'\bFALSE\b', '0', result)
    
    return result


class SQLiteCursorWrapper:
    """
    Wraps a sqlite3 cursor so that:
    - PostgreSQL %s placeholders are translated to ? on the fly
    - PostgreSQL-specific syntax is translated
    - Results look like psycopg2 results (tuples, not sqlite3.Row)
    """
    
    def __init__(self, cursor):
        self._cursor = cursor
    
    def execute(self, sql, params=None):
        translated = pg_to_sqlite(sql)
        if params:
            # psycopg2 uses tuples, sqlite3 also takes tuples - compatible
            return self._cursor.execute(translated, params)
        return self._cursor.execute(translated)
    
    def executemany(self, sql, params_list):
        translated = pg_to_sqlite(sql)
        return self._cursor.executemany(translated, params_list)
    
    def fetchone(self):
        row = self._cursor.fetchone()
        if row is None:
            return None
        # Return as tuple (like psycopg2) so existing dict(zip(columns, row)) works
        if isinstance(row, sqlite3.Row):
            return tuple(row)
        return row
    
    def fetchall(self):
        rows = self._cursor.fetchall()
        # Return as list of tuples (like psycopg2)
        return [tuple(r) if isinstance(r, sqlite3.Row) else r for r in rows]
    
    def fetchmany(self, size=None):
        rows = self._cursor.fetchmany(size) if size else self._cursor.fetchmany()
        return [tuple(r) if isinstance(r, sqlite3.Row) else r for r in rows]
    
    @property
    def description(self):
        return self._cursor.description
    
    @property
    def rowcount(self):
        return self._cursor.rowcount
    
    @property
    def lastrowid(self):
        return self._cursor.lastrowid
    
    def close(self):
        self._cursor.close()


class SQLiteConnectionWrapper:
    """
    Wraps a sqlite3 connection to look like a psycopg2 connection.
    All cursors returned are SQLiteCursorWrapper instances.
    """
    
    def __init__(self, conn):
        self._conn = conn
    
    def cursor(self):
        return SQLiteCursorWrapper(self._conn.cursor())
    
    def commit(self):
        self._conn.commit()
    
    def rollback(self):
        self._conn.rollback()
    
    def close(self):
        self._conn.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type:
            self._conn.rollback()
        self._conn.close()
        return False


class DatabaseManager:
    """
    Dual-mode database manager.
    
    Usage:
        db = DatabaseManager(tier="ENDBOSS", database_url="postgresql://...")
        # or
        db = DatabaseManager(tier="GOLD")  # uses local SQLite
        
        # Drop-in replacement for psycopg2.connect(database_url):
        conn = db.get_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM games WHERE game_pk = %s", (746854,))
        # ^^^ Works identically for both PostgreSQL AND SQLite!
    """
    
    def __init__(self, tier: str = "BASE", database_url: Optional[str] = None):
        self.tier = tier.upper()
        # ONLY ENDBOSS connects to Supabase. All other tiers (including MASTER)
        # use local SQLite. MASTER has the same permissions as ENDBOSS but stores locally.
        self.is_endboss = self.tier == "ENDBOSS"
        self.database_url = database_url
        
        if self.is_endboss:
            if not database_url:
                raise ValueError("ENDBOSS tier requires DATABASE_URL")
            logger.info("Database mode: Supabase PostgreSQL (ENDBOSS)")
        else:
            LOCAL_DATA_DIR.mkdir(parents=True, exist_ok=True)
            self._init_sqlite()
            logger.info(f"Database mode: Local SQLite ({LOCAL_DB_PATH})")
    
    def _init_sqlite(self):
        """Initialize SQLite database with schema if it doesn't exist."""
        conn = sqlite3.connect(str(LOCAL_DB_PATH))
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        
        # Create all tables
        for stmt in SQLITE_SCHEMA:
            try:
                conn.execute(stmt)
            except sqlite3.OperationalError as e:
                if "already exists" not in str(e):
                    logger.warning(f"Schema warning: {e}")
        
        conn.commit()
        conn.close()
    
    def get_connection(self):
        """
        Get a database connection.
        
        ENDBOSS → raw psycopg2 connection (unchanged behavior)
        Others  → SQLiteConnectionWrapper (translates PG SQL on the fly)
        
        This is a DROP-IN replacement for psycopg2.connect(database_url).
        All existing SQL with %s placeholders works unchanged.
        """
        if self.is_endboss:
            import psycopg2
            return psycopg2.connect(self.database_url)
        else:
            conn = sqlite3.connect(str(LOCAL_DB_PATH))
            conn.execute("PRAGMA foreign_keys=ON")
            conn.row_factory = sqlite3.Row
            return SQLiteConnectionWrapper(conn)
    
    @contextmanager
    def connect(self):
        """
        Context-managed version. Use for new code:
        
            with db.connect() as conn:
                cur = conn.cursor()
                cur.execute("SELECT * FROM games WHERE game_pk = %s", (123,))
        """
        conn = self.get_connection()
        try:
            yield conn
        finally:
            conn.close()


# ============================================================================
# SQLITE SCHEMA
# Mirrors the Supabase PostgreSQL schema for local users
# ============================================================================

SQLITE_SCHEMA = [
    # --- Core tables ---
    """
    CREATE TABLE IF NOT EXISTS teams (
        team_id INTEGER PRIMARY KEY,
        name TEXT,
        abbreviation TEXT,
        team_code TEXT,
        location_name TEXT,
        franchise_name TEXT,
        league_id INTEGER,
        league_name TEXT,
        division_id INTEGER,
        division_name TEXT,
        active BOOLEAN DEFAULT 1,
        primary_color TEXT,
        secondary_color TEXT,
        logo_url TEXT,
        stadium_name TEXT
    )
    """,
    
    """
    CREATE TABLE IF NOT EXISTS venues (
        venue_id INTEGER PRIMARY KEY,
        name TEXT,
        location_city TEXT,
        location_state TEXT,
        location_country TEXT,
        timezone_id TEXT,
        timezone_tz TEXT,
        field_info_capacity INTEGER,
        field_info_turf_type TEXT,
        field_info_roof_type TEXT,
        link TEXT,
        season TEXT,
        active BOOLEAN DEFAULT 1,
        elevation FLOAT
    )
    """,
    
    """
    CREATE TABLE IF NOT EXISTS players (
        player_id INTEGER PRIMARY KEY,
        full_name TEXT,
        first_name TEXT,
        last_name TEXT,
        primary_number TEXT,
        birth_date TEXT,
        current_age INTEGER,
        birth_city TEXT,
        birth_country TEXT,
        height TEXT,
        weight INTEGER,
        active BOOLEAN DEFAULT 1,
        bat_side_code TEXT,
        pitch_hand_code TEXT,
        primary_position_code TEXT,
        primary_position_name TEXT,
        current_team_id INTEGER,
        mlb_debut_date TEXT,
        headshot_url TEXT,
        FOREIGN KEY (current_team_id) REFERENCES teams(team_id)
    )
    """,
    
    """
    CREATE TABLE IF NOT EXISTS games (
        game_pk INTEGER PRIMARY KEY,
        season TEXT,
        game_date TEXT,
        game_type TEXT,
        date_time TEXT,
        venue_id INTEGER,
        venue_name TEXT,
        status_abstract TEXT,
        status_detailed TEXT,
        status_code TEXT,
        home_team_id INTEGER,
        away_team_id INTEGER,
        home_pitcher_id INTEGER,
        away_pitcher_id INTEGER,
        home_score INTEGER,
        away_score INTEGER,
        game_time_et TEXT,
        weather_temp TEXT,
        weather_condition TEXT,
        wind_speed TEXT,
        wind_direction TEXT,
        attendance INTEGER,
        game_info_attendance TEXT,
        game_info_game_duration_minutes TEXT,
        weather TEXT,
        wind TEXT,
        scraped_at TEXT,
        FOREIGN KEY (venue_id) REFERENCES venues(venue_id),
        FOREIGN KEY (home_team_id) REFERENCES teams(team_id),
        FOREIGN KEY (away_team_id) REFERENCES teams(team_id)
    )
    """,
    
    """
    CREATE TABLE IF NOT EXISTS plays (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        game_pk INTEGER NOT NULL,
        at_bat_index INTEGER,
        inning INTEGER,
        half_inning TEXT,
        batter_id INTEGER,
        pitcher_id INTEGER,
        event_type TEXT,
        description TEXT,
        rbi INTEGER DEFAULT 0,
        away_score INTEGER,
        home_score INTEGER,
        is_scoring_play BOOLEAN DEFAULT 0,
        pitch_number INTEGER,
        pitch_type TEXT,
        pitch_speed FLOAT,
        pitch_zone INTEGER,
        pitch_call TEXT,
        hit_type TEXT,
        hit_distance FLOAT,
        hit_launch_speed FLOAT,
        hit_launch_angle FLOAT,
        is_hit BOOLEAN DEFAULT 0,
        is_at_bat BOOLEAN DEFAULT 0,
        is_plate_appearance BOOLEAN DEFAULT 0,
        balls INTEGER,
        strikes INTEGER,
        outs INTEGER,
        FOREIGN KEY (game_pk) REFERENCES games(game_pk) ON DELETE CASCADE
    )
    """,
    
    # --- Roster & history ---
    """
    CREATE TABLE IF NOT EXISTS game_rosters (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        game_pk INTEGER NOT NULL,
        team_id INTEGER NOT NULL,
        player_id INTEGER NOT NULL,
        position_code TEXT,
        batting_order INTEGER,
        is_starter BOOLEAN DEFAULT 0,
        entered_inning INTEGER,
        plate_appearances INTEGER DEFAULT 0,
        at_bats INTEGER DEFAULT 0,
        innings_pitched FLOAT,
        pitches_thrown INTEGER,
        created_at TEXT DEFAULT (datetime('now')),
        FOREIGN KEY (game_pk) REFERENCES games(game_pk) ON DELETE CASCADE,
        FOREIGN KEY (team_id) REFERENCES teams(team_id),
        FOREIGN KEY (player_id) REFERENCES players(player_id),
        UNIQUE (game_pk, team_id, player_id)
    )
    """,
    
    """
    CREATE TABLE IF NOT EXISTS player_team_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        player_id INTEGER NOT NULL,
        team_id INTEGER NOT NULL,
        season INTEGER NOT NULL,
        start_date TEXT NOT NULL,
        end_date TEXT,
        transaction_type TEXT,
        notes TEXT,
        created_at TEXT DEFAULT (datetime('now')),
        FOREIGN KEY (player_id) REFERENCES players(player_id) ON DELETE CASCADE,
        FOREIGN KEY (team_id) REFERENCES teams(team_id) ON DELETE CASCADE
    )
    """,
    
    # --- Aggregated stats ---
    """
    CREATE TABLE IF NOT EXISTS player_season_stats (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        player_id INTEGER NOT NULL,
        season INTEGER NOT NULL,
        team_id INTEGER,
        player_type TEXT NOT NULL,
        games_played INTEGER DEFAULT 0,
        plate_appearances INTEGER DEFAULT 0,
        at_bats INTEGER DEFAULT 0,
        hits INTEGER DEFAULT 0,
        singles INTEGER DEFAULT 0,
        doubles INTEGER DEFAULT 0,
        triples INTEGER DEFAULT 0,
        home_runs INTEGER DEFAULT 0,
        runs INTEGER DEFAULT 0,
        rbi INTEGER DEFAULT 0,
        walks INTEGER DEFAULT 0,
        strikeouts INTEGER DEFAULT 0,
        hbp INTEGER DEFAULT 0,
        batting_avg FLOAT,
        obp FLOAT,
        slg FLOAT,
        ops FLOAT,
        stolen_bases INTEGER DEFAULT 0,
        caught_stealing INTEGER DEFAULT 0,
        games_pitched INTEGER DEFAULT 0,
        games_started INTEGER DEFAULT 0,
        innings_pitched FLOAT DEFAULT 0,
        wins INTEGER DEFAULT 0,
        losses INTEGER DEFAULT 0,
        saves INTEGER DEFAULT 0,
        earned_runs INTEGER DEFAULT 0,
        era FLOAT,
        hits_allowed INTEGER DEFAULT 0,
        walks_allowed INTEGER DEFAULT 0,
        strikeouts_pitched INTEGER DEFAULT 0,
        k_per_9 FLOAT,
        bb_per_9 FLOAT,
        whip FLOAT,
        home_runs_allowed INTEGER DEFAULT 0,
        batters_faced INTEGER DEFAULT 0,
        last_game_date TEXT,
        updated_at TEXT DEFAULT (datetime('now')),
        FOREIGN KEY (player_id) REFERENCES players(player_id) ON DELETE CASCADE,
        FOREIGN KEY (team_id) REFERENCES teams(team_id) ON DELETE SET NULL,
        UNIQUE (player_id, season, player_type)
    )
    """,
    
    """
    CREATE TABLE IF NOT EXISTS player_hierarchical_stats (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        player_id INTEGER NOT NULL,
        season INTEGER NOT NULL,
        player_type TEXT NOT NULL,
        player_hier_era FLOAT,
        player_hier_whip FLOAT,
        player_hier_k_per_9 FLOAT,
        player_hier_bb_per_9 FLOAT,
        player_hier_hr_per_9 FLOAT,
        team_effect_era FLOAT,
        team_effect_k_per_9 FLOAT,
        shrinkage_weight_era FLOAT,
        league_diff_era FLOAT,
        player_hier_avg FLOAT,
        player_hier_obp FLOAT,
        player_hier_slg FLOAT,
        player_hier_ops FLOAT,
        team_effect_batting_avg FLOAT,
        team_effect_ops FLOAT,
        shrinkage_weight_batting_avg FLOAT,
        league_diff_batting_avg FLOAT,
        calculated_at TEXT DEFAULT (datetime('now')),
        FOREIGN KEY (player_id) REFERENCES players(player_id) ON DELETE CASCADE,
        UNIQUE (player_id, season, player_type)
    )
    """,
    
    """
    CREATE TABLE IF NOT EXISTS team_season_stats (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        team_id INTEGER NOT NULL,
        season INTEGER NOT NULL,
        wins INTEGER DEFAULT 0,
        losses INTEGER DEFAULT 0,
        ties INTEGER DEFAULT 0,
        runs_scored INTEGER DEFAULT 0,
        runs_allowed INTEGER DEFAULT 0,
        run_differential INTEGER DEFAULT 0,
        team_era FLOAT,
        team_batting_avg FLOAT,
        team_ops FLOAT,
        team_k_per_9 FLOAT,
        home_wins INTEGER DEFAULT 0,
        home_losses INTEGER DEFAULT 0,
        away_wins INTEGER DEFAULT 0,
        away_losses INTEGER DEFAULT 0,
        updated_at TEXT DEFAULT (datetime('now')),
        FOREIGN KEY (team_id) REFERENCES teams(team_id) ON DELETE CASCADE,
        UNIQUE (team_id, season)
    )
    """,
    
    """
    CREATE TABLE IF NOT EXISTS league_statistics (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        season INTEGER NOT NULL,
        stat_type TEXT NOT NULL,
        league_era FLOAT,
        league_k_per_9 FLOAT,
        league_bb_per_9 FLOAT,
        league_hr_per_9 FLOAT,
        league_whip FLOAT,
        std_era FLOAT,
        std_k_per_9 FLOAT,
        n_pitchers INTEGER,
        total_innings FLOAT,
        league_avg FLOAT,
        league_obp FLOAT,
        league_slg FLOAT,
        league_ops FLOAT,
        league_k_rate FLOAT,
        league_bb_rate FLOAT,
        std_avg FLOAT,
        std_ops FLOAT,
        n_batters INTEGER,
        total_pa INTEGER,
        calculated_at TEXT DEFAULT (datetime('now')),
        UNIQUE (season, stat_type)
    )
    """,
    
    # --- Predictions & odds ---
    """
    CREATE TABLE IF NOT EXISTS predictions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        game_pk INTEGER NOT NULL,
        team_id INTEGER,
        player_id INTEGER,
        market_type TEXT,
        side TEXT,
        strike FLOAT,
        probability FLOAT,
        num_simulations INTEGER,
        model_version TEXT,
        result TEXT,
        created_at TEXT DEFAULT (datetime('now')),
        updated_at TEXT DEFAULT (datetime('now')),
        FOREIGN KEY (game_pk) REFERENCES games(game_pk) ON DELETE CASCADE,
        UNIQUE (game_pk, team_id, player_id, market_type, side, strike)
    )
    """,
    
    """
    CREATE TABLE IF NOT EXISTS game_predictions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        game_pk INTEGER NOT NULL,
        model_version_id INTEGER,
        home_win_prob FLOAT NOT NULL,
        away_win_prob FLOAT NOT NULL,
        predicted_home_score FLOAT,
        predicted_away_score FLOAT,
        over_under_line FLOAT,
        over_prob FLOAT,
        num_simulations INTEGER DEFAULT 10000,
        simulation_time_seconds FLOAT,
        predicted_at TEXT DEFAULT (datetime('now')),
        FOREIGN KEY (game_pk) REFERENCES games(game_pk) ON DELETE CASCADE,
        UNIQUE (game_pk, model_version_id)
    )
    """,
    
    """
    CREATE TABLE IF NOT EXISTS sportsbook_odds (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        game_pk INTEGER NOT NULL,
        book_name TEXT NOT NULL,
        home_ml INTEGER,
        away_ml INTEGER,
        spread_line FLOAT,
        home_spread_odds INTEGER,
        away_spread_odds INTEGER,
        total_line FLOAT,
        over_odds INTEGER,
        under_odds INTEGER,
        fetched_at TEXT DEFAULT (datetime('now')),
        is_opening_line BOOLEAN DEFAULT 0,
        is_closing_line BOOLEAN DEFAULT 0,
        FOREIGN KEY (game_pk) REFERENCES games(game_pk) ON DELETE CASCADE
    )
    """,
    
    """
    CREATE TABLE IF NOT EXISTS model_versions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        model_name TEXT NOT NULL,
        version TEXT NOT NULL,
        trained_at TEXT NOT NULL,
        training_data_start TEXT,
        training_data_end TEXT,
        num_training_samples INTEGER,
        validation_accuracy FLOAT,
        validation_log_loss FLOAT,
        model_file_path TEXT,
        lookup_table_path TEXT,
        notes TEXT,
        is_active BOOLEAN DEFAULT 1,
        created_at TEXT DEFAULT (datetime('now')),
        UNIQUE (model_name, version)
    )
    """,
    
    # --- API keys (only used locally for caching tier info) ---
    """
    CREATE TABLE IF NOT EXISTS api_keys (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        key_hash TEXT UNIQUE NOT NULL,
        user_id TEXT,
        tier TEXT DEFAULT 'BASE',
        permissions TEXT DEFAULT '{}',
        created_at TEXT DEFAULT (datetime('now')),
        expires_at TEXT,
        is_active BOOLEAN DEFAULT 1,
        last_used_at TEXT,
        ai_chat_requests_this_month INTEGER DEFAULT 0,
        ai_chat_month_reset_at TEXT
    )
    """,
    
    # --- Lineups (Rotowire / projected) ---
    """
    CREATE TABLE IF NOT EXISTS projected_lineups (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        game_pk INTEGER,
        game_date TEXT NOT NULL,
        team_id INTEGER NOT NULL,
        team_abbr TEXT,
        player_id INTEGER,
        player_name TEXT,
        batting_order INTEGER,
        position TEXT,
        is_confirmed BOOLEAN DEFAULT 0,
        source TEXT DEFAULT 'rotowire',
        fetched_at TEXT DEFAULT (datetime('now')),
        UNIQUE (game_date, team_id, batting_order)
    )
    """,
    
    """
    CREATE TABLE IF NOT EXISTS projected_pitchers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        game_pk INTEGER,
        game_date TEXT NOT NULL,
        team_id INTEGER NOT NULL,
        team_abbr TEXT,
        player_id INTEGER,
        player_name TEXT,
        is_confirmed BOOLEAN DEFAULT 0,
        source TEXT DEFAULT 'rotowire',
        fetched_at TEXT DEFAULT (datetime('now')),
        UNIQUE (game_date, team_id)
    )
    """,
    
    # --- Chat history (local) ---
    """
    CREATE TABLE IF NOT EXISTS chat_sessions (
        id TEXT PRIMARY KEY,
        title TEXT,
        created_at TEXT DEFAULT (datetime('now')),
        updated_at TEXT DEFAULT (datetime('now'))
    )
    """,
    
    """
    CREATE TABLE IF NOT EXISTS chat_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id TEXT NOT NULL,
        role TEXT NOT NULL,
        content TEXT NOT NULL,
        created_at TEXT DEFAULT (datetime('now')),
        FOREIGN KEY (session_id) REFERENCES chat_sessions(id) ON DELETE CASCADE
    )
    """,
    
    # --- Pybaseball cache ---
    """
    CREATE TABLE IF NOT EXISTS pybaseball_cache (
        cache_key TEXT PRIMARY KEY,
        query_type TEXT NOT NULL,
        query_params TEXT,
        results TEXT,
        created_at TEXT DEFAULT (datetime('now')),
        expires_at TEXT NOT NULL
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_pybaseball_cache_expires ON pybaseball_cache(expires_at)",
    
    # --- User Bets (performance tracking) ---
    """
    CREATE TABLE IF NOT EXISTS user_bets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        game_pk INTEGER NOT NULL,
        game_date TEXT NOT NULL,
        market_type TEXT NOT NULL,
        selection TEXT NOT NULL,
        side TEXT NOT NULL,
        strike REAL,
        player_name TEXT,
        mcmc_probability REAL NOT NULL,
        market_probability REAL,
        edge REAL,
        american_odds INTEGER NOT NULL,
        decimal_odds REAL,
        stake REAL NOT NULL DEFAULT 100,
        potential_payout REAL,
        kelly_fraction TEXT,
        entry_pinnacle_odds INTEGER,
        entry_pinnacle_prob REAL,
        entry_fd_odds INTEGER,
        entry_fd_prob REAL,
        result TEXT,
        profit_loss REAL,
        settled_at TEXT,
        closing_odds INTEGER,
        closing_probability REAL,
        clv_cents REAL,
        notes TEXT,
        tags TEXT,
        is_parlay INTEGER DEFAULT 0,
        parlay_id INTEGER,
        created_at TEXT DEFAULT (datetime('now')),
        updated_at TEXT DEFAULT (datetime('now')),
        FOREIGN KEY (game_pk) REFERENCES games(game_pk)
    )
    """,
    
    # --- User Notes (performance dashboard) ---
    """
    CREATE TABLE IF NOT EXISTS user_notes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        content TEXT NOT NULL,
        author TEXT DEFAULT 'user',
        created_at TEXT DEFAULT (datetime('now')),
        updated_at TEXT DEFAULT (datetime('now'))
    )
    """,
    
    # --- Sportsbooks ---
    """
    CREATE TABLE IF NOT EXISTS sportsbooks (
        sportsbook_id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        short_name TEXT,
        api_key_name TEXT,
        api_endpoint TEXT,
        is_active INTEGER DEFAULT 1,
        supports_mlb INTEGER DEFAULT 1,
        website_url TEXT,
        notes TEXT,
        created_at TEXT DEFAULT (datetime('now'))
    )
    """,
    
    # --- Sportsbook Markets (odds tracking) ---
    """
    CREATE TABLE IF NOT EXISTS sportsbook_markets (
        market_id INTEGER PRIMARY KEY AUTOINCREMENT,
        sportsbook_id INTEGER NOT NULL,
        game_pk INTEGER NOT NULL,
        player_id INTEGER,
        market_type TEXT NOT NULL,
        outcome_side TEXT NOT NULL,
        strike_price REAL,
        american_odds INTEGER,
        decimal_odds REAL,
        implied_probability REAL,
        max_bet_amount REAL,
        is_available INTEGER DEFAULT 1,
        odds_updated_at TEXT NOT NULL,
        odds_api_event_id TEXT,
        player_name TEXT,
        team_side TEXT,
        created_at TEXT DEFAULT (datetime('now')),
        FOREIGN KEY (sportsbook_id) REFERENCES sportsbooks(sportsbook_id),
        FOREIGN KEY (game_pk) REFERENCES games(game_pk)
    )
    """,
    
    # --- Sportsbook Odds History ---
    """
    CREATE TABLE IF NOT EXISTS sportsbook_odds_history (
        history_id INTEGER PRIMARY KEY AUTOINCREMENT,
        market_id INTEGER NOT NULL,
        american_odds INTEGER NOT NULL,
        decimal_odds REAL NOT NULL,
        implied_probability REAL NOT NULL,
        recorded_at TEXT DEFAULT (datetime('now')),
        odds_movement REAL,
        is_steam_move INTEGER DEFAULT 0,
        FOREIGN KEY (market_id) REFERENCES sportsbook_markets(market_id) ON DELETE CASCADE
    )
    """,
    
    # --- Odds API Event Mapping ---
    """
    CREATE TABLE IF NOT EXISTS odds_api_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        odds_api_event_id TEXT NOT NULL UNIQUE,
        game_pk INTEGER NOT NULL,
        sport_key TEXT DEFAULT 'baseball_mlb',
        home_team_name TEXT,
        away_team_name TEXT,
        commence_time TEXT,
        created_at TEXT DEFAULT (datetime('now')),
        updated_at TEXT DEFAULT (datetime('now')),
        FOREIGN KEY (game_pk) REFERENCES games(game_pk)
    )
    """,
    
    # --- EV Tracking ---
    """
    CREATE TABLE IF NOT EXISTS ev_tracking (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        game_pk INTEGER NOT NULL,
        market_type TEXT NOT NULL,
        outcome_side TEXT NOT NULL,
        strike_price REAL,
        player_id INTEGER,
        player_name TEXT,
        mcmc_probability REAL,
        diamond_fair_probability REAL,
        sportsbook_id INTEGER NOT NULL,
        american_odds INTEGER NOT NULL,
        implied_probability REAL NOT NULL,
        no_vig_probability REAL,
        edge REAL,
        expected_value REAL,
        hours_to_game REAL,
        recorded_at TEXT DEFAULT (datetime('now')),
        actual_result TEXT,
        FOREIGN KEY (sportsbook_id) REFERENCES sportsbooks(sportsbook_id)
    )
    """,
    
    # --- Indexes ---
    "CREATE INDEX IF NOT EXISTS idx_user_bets_game ON user_bets(game_pk)",
    "CREATE INDEX IF NOT EXISTS idx_user_bets_date ON user_bets(game_date)",
    "CREATE INDEX IF NOT EXISTS idx_user_bets_market ON user_bets(market_type)",
    "CREATE INDEX IF NOT EXISTS idx_user_bets_result ON user_bets(result)",
    "CREATE INDEX IF NOT EXISTS idx_user_bets_created ON user_bets(created_at)",
    "CREATE INDEX IF NOT EXISTS idx_user_notes_created ON user_notes(created_at)",
    "CREATE INDEX IF NOT EXISTS idx_sportsbook_markets_game ON sportsbook_markets(game_pk)",
    "CREATE INDEX IF NOT EXISTS idx_sportsbook_markets_type ON sportsbook_markets(market_type)",
    "CREATE INDEX IF NOT EXISTS idx_sportsbook_markets_event_id ON sportsbook_markets(odds_api_event_id)",
    "CREATE INDEX IF NOT EXISTS idx_odds_history_market ON sportsbook_odds_history(market_id)",
    "CREATE INDEX IF NOT EXISTS idx_odds_events_game_pk ON odds_api_events(game_pk)",
    "CREATE INDEX IF NOT EXISTS idx_ev_tracking_game ON ev_tracking(game_pk)",
    "CREATE INDEX IF NOT EXISTS idx_ev_tracking_market ON ev_tracking(market_type)",
    "CREATE INDEX IF NOT EXISTS idx_games_date ON games(game_date)",
    "CREATE INDEX IF NOT EXISTS idx_games_season ON games(season)",
    "CREATE INDEX IF NOT EXISTS idx_games_teams ON games(home_team_id, away_team_id)",
    "CREATE INDEX IF NOT EXISTS idx_plays_game ON plays(game_pk)",
    "CREATE INDEX IF NOT EXISTS idx_plays_batter ON plays(batter_id)",
    "CREATE INDEX IF NOT EXISTS idx_plays_pitcher ON plays(pitcher_id)",
    "CREATE INDEX IF NOT EXISTS idx_game_rosters_game ON game_rosters(game_pk)",
    "CREATE INDEX IF NOT EXISTS idx_game_rosters_player ON game_rosters(player_id)",
    "CREATE INDEX IF NOT EXISTS idx_player_season_lookup ON player_season_stats(season, player_id, player_type)",
    "CREATE INDEX IF NOT EXISTS idx_player_hier_lookup ON player_hierarchical_stats(season, player_id, player_type)",
    "CREATE INDEX IF NOT EXISTS idx_team_season_lookup ON team_season_stats(season, team_id)",
    "CREATE INDEX IF NOT EXISTS idx_league_stats_lookup ON league_statistics(season, stat_type)",
    "CREATE INDEX IF NOT EXISTS idx_predictions_game ON predictions(game_pk)",
    "CREATE INDEX IF NOT EXISTS idx_odds_game ON sportsbook_odds(game_pk)",
    "CREATE INDEX IF NOT EXISTS idx_odds_fetched ON sportsbook_odds(fetched_at)",
    "CREATE INDEX IF NOT EXISTS idx_player_history_player ON player_team_history(player_id, season)",
    "CREATE INDEX IF NOT EXISTS idx_player_history_team ON player_team_history(team_id, season)",
    "CREATE INDEX IF NOT EXISTS idx_projected_lineups_date ON projected_lineups(game_date)",
    "CREATE INDEX IF NOT EXISTS idx_projected_pitchers_date ON projected_pitchers(game_date)",
]


# Singleton instance - set during app startup
_db_instance: Optional[DatabaseManager] = None


def init_database(tier: str, database_url: Optional[str] = None) -> DatabaseManager:
    """Initialize the global database manager."""
    global _db_instance
    _db_instance = DatabaseManager(tier=tier, database_url=database_url)
    return _db_instance


def get_db() -> DatabaseManager:
    """Get the global database manager instance."""
    if _db_instance is None:
        raise RuntimeError(
            "Database not initialized. Call init_database() first."
        )
    return _db_instance
