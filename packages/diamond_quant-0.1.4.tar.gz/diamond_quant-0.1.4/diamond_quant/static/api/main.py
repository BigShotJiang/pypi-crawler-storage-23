"""
MLB MCMC Backend API
FastAPI server that exposes data collection, model training, and simulation endpoints
"""

from contextlib import asynccontextmanager
from fastapi import FastAPI, BackgroundTasks, HTTPException, Query, Request, Depends, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
from typing import Optional, List, Dict, Any, Tuple
from datetime import datetime, timedelta, date, timezone
import subprocess
import sys
import json
import os
import re
from pathlib import Path
from decimal import Decimal
import hashlib
from dotenv import load_dotenv

# Handle imports for both local dev (api/ directory) and package structure
try:
    from api.tier_system import (
        get_tier_limits, can_access_models, get_max_sims_per_game,
        get_rate_limit_per_minute, get_ai_chat_monthly_limit, get_ai_chat_per_minute_limit
    )
except ImportError:
    # Running from api/ directory directly - use relative import
    from tier_system import (
        get_tier_limits, can_access_models, get_max_sims_per_game,
        get_rate_limit_per_minute, get_ai_chat_monthly_limit, get_ai_chat_per_minute_limit
    )

# Load environment variables before reading REQUIRE_API_KEY
PROJECT_ROOT = Path(__file__).parent.parent
load_dotenv(PROJECT_ROOT / ".env")

# ── Database Connection ──────────────────────────────────────────────────────
import psycopg2

_DB_CONNECT_KWARGS = dict(
    connect_timeout=5,
    options='-c statement_timeout=30000',
    keepalives=1,
    keepalives_idle=30,
    keepalives_interval=10,
    keepalives_count=5,
)


def _get_db_conn():
    """
    Get a fresh database connection with retry logic.

    Dual-mode:
      - Package mode (PyPI): Uses DatabaseManager
      - Dev mode: Opens a direct psycopg2 connection to Supabase
    """
    try:
        from diamond_quant.database import get_db
        return get_db().get_connection()
    except (ImportError, RuntimeError):
        import time as _t
        database_url = os.getenv('DATABASE_URL')
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        last_err = None
        for attempt in range(3):
            try:
                conn = psycopg2.connect(database_url, **_DB_CONNECT_KWARGS)
                return conn
            except Exception as e:
                last_err = e
                if attempt < 2:
                    _t.sleep(1 * (attempt + 1))
        raise HTTPException(503, f"Database temporarily unavailable: {last_err}")


# ── Odds utility helpers (avoids importing from scripts/) ─────────────────
def _american_to_decimal(american: int) -> float:
    if american > 0:
        return 1 + (american / 100)
    elif american < 0:
        return 1 + (100 / abs(american))
    return 2.0

def _american_to_prob(american: int) -> float:
    dec = _american_to_decimal(american)
    return 1.0 / dec if dec > 0 else 0

def devig_two_way(odds_a: int, odds_b: int) -> tuple:
    """Remove vig from a two-way market. Returns (fair_prob_a, fair_prob_b) summing to 1.0."""
    imp_a = _american_to_prob(odds_a)
    imp_b = _american_to_prob(odds_b)
    total = imp_a + imp_b
    if total <= 0:
        return (0.5, 0.5)
    return (imp_a / total, imp_b / total)


_grading_shutdown = __import__('threading').Event()

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Create performance tables on startup, auto-start persistent services,
    and run background prediction grading."""
    import asyncio
    import threading
    import time as _time

    def _init_tables():
        try:
            _ensure_performance_tables()
        except Exception as e:
            print(f"[API] Startup table init deferred: {e}")

    def _background_grading_loop():
        """Periodically check for finished games and grade predictions.
        Runs in a daemon thread — all DB calls are synchronous, never blocks event loop."""
        _time.sleep(30)  # Wait for startup to settle
        while not _grading_shutdown.is_set():
            conn = None
            try:
                conn = _get_db_conn()
                cur = conn.cursor()

                cur.execute("""
                    SELECT DISTINCT p.game_pk
                    FROM predictions p
                    JOIN games g ON p.game_pk = g.game_pk
                    WHERE p.result IS NULL
                      AND g.game_date >= (CURRENT_DATE - INTERVAL '7 days')
                      AND g.game_date <= CURRENT_DATE
                """)
                game_pks = [r[0] for r in cur.fetchall()]

                if game_pks:
                    total_graded = 0
                    for gpk in game_pks:
                        game_result = _fetch_game_results(gpk)
                        if game_result is None:
                            continue

                        cur.execute("""
                            UPDATE games SET
                                home_score = %s, away_score = %s,
                                status_abstract = 'Final',
                                status_detailed = %s
                            WHERE game_pk = %s
                        """, (game_result["home_score"], game_result["away_score"],
                              game_result["status_detailed"], gpk))

                        cur.execute("SELECT home_team_id, away_team_id FROM games WHERE game_pk = %s", (gpk,))
                        home_tid, away_tid = cur.fetchone()

                        cur.execute("""
                            SELECT id, market_type, side, strike, team_id, player_id
                            FROM predictions WHERE game_pk = %s AND result IS NULL
                        """, (gpk,))
                        for row in cur.fetchall():
                            pred_id, mt, side, strike, team_id, player_id = row
                            result = _grade_prediction(
                                {"market_type": mt, "side": side, "strike": strike,
                                 "team_id": team_id, "player_id": player_id},
                                game_result, home_tid, away_tid)
                            if result is not None:
                                cur.execute("UPDATE predictions SET result = %s, updated_at = NOW() WHERE id = %s",
                                            (result, pred_id))
                                total_graded += 1

                    if total_graded > 0:
                        conn.commit()
                        print(f"[GRADER] Auto-graded {total_graded} predictions")
                    else:
                        conn.rollback()
            except Exception as e:
                print(f"[GRADER] Background grading error: {e}")
            finally:
                if conn is not None:
                    try:
                        conn.close()
                    except Exception:
                        pass

            # Wait 5 minutes (or until shutdown requested)
            _grading_shutdown.wait(timeout=300)

    # Start table init and background grading in daemon threads
    threading.Thread(target=_init_tables, daemon=True).start()
    threading.Thread(target=_background_grading_loop, daemon=True).start()

    # ── Auto-recover or auto-start odds feed ────────────────────────
    if _recover_odds_process():
        print("[API] Recovered running odds feed from previous session")
    elif _odds_autostart_is_set():
        print("[API] Auto-start flag set — starting odds feed...")
        result = _start_odds_process()
        print(f"[API] Odds auto-start: {result['status']} — {result['message']}")

    # ── Start odds watchdog (restarts feed if it dies while autostart is on)
    watchdog_task = asyncio.create_task(_odds_watchdog())

    yield

    # ── Cleanup ─────────────────────────────────────────────────────
    _grading_shutdown.set()
    watchdog_task.cancel()
    try:
        await watchdog_task
    except asyncio.CancelledError:
        pass


app = FastAPI(title="MLB MCMC API", version="1.0.0", lifespan=lifespan)

# CORS for Next.js frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# API Key Security (optional - can be disabled for local dev)
security = HTTPBearer(auto_error=False)
REQUIRE_API_KEY = os.getenv("REQUIRE_API_KEY", "false").lower() == "true"


# Project root (already set above)

# ============================================================================
# MODELS
# ============================================================================

class DataCollectionRequest(BaseModel):
    start_date: str  # YYYY-MM-DD
    end_date: str    # YYYY-MM-DD
    dry_run: bool = False

class AggregationRequest(BaseModel):
    years: Optional[List[int]] = None

class DataCollectionStatus(BaseModel):
    status: str
    games_processed: int
    games_failed: int
    message: str

class ModelTrainingRequest(BaseModel):
    model_type: str  # "pitch_outcome", "hit_type", "pitch_type"
    use_hierarchical: bool = True

class RetrainModelRequest(BaseModel):
    model_id: str  # Model ID from inventory

class TrainingJobStatus(BaseModel):
    job_id: int
    model_id: str
    model_name: str
    status: str
    progress_percent: int
    current_step: str
    error_message: Optional[str]
    started_at: Optional[str]
    completed_at: Optional[str]
    duration_seconds: Optional[int]

class SimulationRequest(BaseModel):
    game_date: str  # YYYY-MM-DD
    num_sims: int = 10000

class PredictionResponse(BaseModel):
    game_id: int
    away_team: str
    home_team: str
    away_pitcher: str
    home_pitcher: str
    mcmc_home_win_prob: float
    start_time: str

class TopPlayersBatchRequest(BaseModel):
    game_pks: List[int]

# ============================================================================
# API KEY VALIDATION
# ============================================================================

def hash_api_key(api_key: str) -> str:
    """Hash API key using SHA-256"""
    return hashlib.sha256(api_key.encode()).hexdigest()


async def verify_api_key(
    request: Request,
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security)
) -> Optional[Tuple[str, Optional[str]]]:
    """
    Verify API key from either Authorization header or X-API-Key header.
    Returns (api_key, tier) if valid, None if not required, raises HTTPException if invalid.
    
    If REQUIRE_API_KEY env var is false, this always returns None (no auth required).
    """
    # If API key not required, allow all requests (local dev mode)
    if not REQUIRE_API_KEY:
        return None
    
    # Get API key from header or Authorization bearer token
    api_key = None
    x_api_key = request.headers.get("X-API-Key")
    if x_api_key:
        api_key = x_api_key
    elif credentials and credentials.credentials:
        api_key = credentials.credentials
    
    if not api_key:
        raise HTTPException(
            status_code=401,
            detail="API key required. Provide via X-API-Key header or Authorization: Bearer <key>"
        )
    
    # Validate API key against database
    try:
        import psycopg2
        from dotenv import load_dotenv
        
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        
        if not database_url:
            # If no database, allow if in local dev mode
            if not REQUIRE_API_KEY:
                return None
            raise HTTPException(500, "Database not configured")
        
        conn = _get_db_conn()
        cur = conn.cursor()
        
        # Check if api_keys table exists, create if not (with tier column)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS api_keys (
                id SERIAL PRIMARY KEY,
                key_hash VARCHAR(255) UNIQUE NOT NULL,
                user_id VARCHAR(100),
                tier VARCHAR(20) DEFAULT 'BASE' CHECK (tier IN ('ENDBOSS', 'DIAMOND', 'GOLD', 'SILVER', 'BRONZE', 'BASE')),
                permissions JSONB DEFAULT '{}',
                created_at TIMESTAMPTZ DEFAULT NOW(),
                expires_at TIMESTAMPTZ,
                is_active BOOLEAN DEFAULT TRUE,
                last_used_at TIMESTAMPTZ,
                ai_chat_requests_this_month INTEGER DEFAULT 0,
                ai_chat_month_reset_at TIMESTAMPTZ DEFAULT (DATE_TRUNC('month', NOW()) + INTERVAL '1 month')
            )
        """)
        
        # Add tier column if it doesn't exist (for existing tables)
        cur.execute("""
            DO $$ 
            BEGIN
                IF NOT EXISTS (
                    SELECT 1 FROM information_schema.columns 
                    WHERE table_name = 'api_keys' AND column_name = 'tier'
                ) THEN
                    ALTER TABLE api_keys ADD COLUMN tier VARCHAR(20) DEFAULT 'BASE';
                    ALTER TABLE api_keys ADD CONSTRAINT check_tier 
                        CHECK (tier IN ('ENDBOSS', 'DIAMOND', 'GOLD', 'SILVER', 'BRONZE', 'BASE'));
                END IF;
            END $$;
        """)
        
        # Hash the provided key
        key_hash = hash_api_key(api_key)
        
        # Check if key exists and is valid (include tier)
        cur.execute("""
            SELECT id, user_id, permissions, expires_at, is_active, COALESCE(tier, 'BASE') as tier
            FROM api_keys
            WHERE key_hash = %s
            LIMIT 1
        """, (key_hash,))
        
        row = cur.fetchone()
        
        if not row:
            conn.close()
            raise HTTPException(status_code=401, detail="Invalid API key")
        
        key_id, user_id, permissions, expires_at, is_active, tier = row
        
        # Check if key is active
        if not is_active:
            conn.close()
            raise HTTPException(status_code=401, detail="API key is inactive")
        
        # Check if key has expired
        if expires_at and expires_at < datetime.now(expires_at.tzinfo):
            conn.close()
            raise HTTPException(status_code=401, detail="API key has expired")
        
        # Update last_used_at
        cur.execute("""
            UPDATE api_keys
            SET last_used_at = NOW()
            WHERE id = %s
        """, (key_id,))
        
        conn.commit()
        conn.close()
        
        return (api_key, tier)
        
    except HTTPException:
        raise
    except Exception as e:
        # If validation fails due to DB error, allow in local dev mode
        if not REQUIRE_API_KEY:
            return None
        raise HTTPException(500, f"Error validating API key: {str(e)}")


async def get_api_key_info(
    request: Request,
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security)
) -> Optional[Dict[str, Any]]:
    """
    Get API key information including tier and limits.
    Returns None if API key not required (local dev).
    """
    result = await verify_api_key(request, credentials)
    if result is None:
        return None
    
    api_key, tier = result
    limits = get_tier_limits(tier)
    
    return {
        "tier": tier,
        "can_access_models": limits.get("can_access_models", False),
        "max_sims_per_game": limits.get("max_sims_per_game"),
        "rate_limit_per_minute": limits.get("rate_limit_per_minute"),
        "ai_chat_requests_per_month": limits.get("ai_chat_requests_per_month"),
        "ai_chat_requests_per_minute": limits.get("ai_chat_requests_per_minute"),
    }


@app.post("/api/auth/validate")
async def validate_api_key_endpoint(request: Request):
    """
    Validate an API key. Used by frontend to check if key is valid.
    Returns tier information if valid.
    """
    try:
        body = await request.json()
        api_key = body.get("api_key")
        
        if not api_key:
            return {"valid": False, "error": "API key not provided"}
        
        # Use the same verification logic
        try:
            # We'll validate directly here instead of calling verify_api_key
            # to avoid circular dependency
            if not REQUIRE_API_KEY:
                return {"valid": True, "tier": "ENDBOSS", "can_access_models": True}
            
            # Validate against database
            import psycopg2
            from dotenv import load_dotenv
            
            load_dotenv(PROJECT_ROOT / ".env")
            database_url = os.getenv('DATABASE_URL')
            
            if not database_url:
                return {"valid": True, "tier": "ENDBOSS", "can_access_models": True}  # Allow if no DB in local dev
            
            conn = _get_db_conn()
            cur = conn.cursor()
            
            cur.execute("""
                CREATE TABLE IF NOT EXISTS api_keys (
                    id SERIAL PRIMARY KEY,
                    key_hash VARCHAR(255) UNIQUE NOT NULL,
                    user_id VARCHAR(100),
                    tier VARCHAR(20) DEFAULT 'BASE' CHECK (tier IN ('ENDBOSS', 'DIAMOND', 'GOLD', 'SILVER', 'BRONZE', 'BASE')),
                    permissions JSONB DEFAULT '{}',
                    created_at TIMESTAMPTZ DEFAULT NOW(),
                    expires_at TIMESTAMPTZ,
                    is_active BOOLEAN DEFAULT TRUE,
                    last_used_at TIMESTAMPTZ,
                    ai_chat_requests_this_month INTEGER DEFAULT 0,
                    ai_chat_month_reset_at TIMESTAMPTZ DEFAULT (DATE_TRUNC('month', NOW()) + INTERVAL '1 month')
                )
            """)
            
            # Add tier column if it doesn't exist
            cur.execute("""
                DO $$ 
                BEGIN
                    IF NOT EXISTS (
                        SELECT 1 FROM information_schema.columns 
                        WHERE table_name = 'api_keys' AND column_name = 'tier'
                    ) THEN
                        ALTER TABLE api_keys ADD COLUMN tier VARCHAR(20) DEFAULT 'BASE';
                        ALTER TABLE api_keys ADD CONSTRAINT check_tier 
                            CHECK (tier IN ('ENDBOSS', 'DIAMOND', 'GOLD', 'SILVER', 'BRONZE', 'BASE'));
                    END IF;
                END $$;
            """)
            
            key_hash = hash_api_key(api_key)
            cur.execute("""
                SELECT id, expires_at, is_active, COALESCE(tier, 'BASE') as tier
                FROM api_keys
                WHERE key_hash = %s AND is_active = TRUE
                LIMIT 1
            """, (key_hash,))
            
            row = cur.fetchone()
            
            if row and (not row[1] or row[1] > datetime.now(row[1].tzinfo)):
                tier = row[3] if len(row) > 3 else "BASE"
                limits = get_tier_limits(tier)
                conn.close()
                return {
                    "valid": True,
                    "tier": tier,
                    "can_access_models": limits.get("can_access_models", False),
                    "max_sims_per_game": limits.get("max_sims_per_game"),
                }
            else:
                conn.close()
                return {"valid": False, "error": "Invalid API key"}
        except HTTPException as e:
            # If REQUIRE_API_KEY is false, always return valid
            if not REQUIRE_API_KEY:
                return {"valid": True, "tier": "ENDBOSS", "can_access_models": True}
            return {"valid": False, "error": e.detail}
            
    except Exception as e:
        # If validation fails, allow if not required
        if not REQUIRE_API_KEY:
            return {"valid": True, "tier": "ENDBOSS", "can_access_models": True}
        return {"valid": False, "error": str(e)}


@app.get("/api/auth/tier")
async def get_tier_info(request: Request):
    """
    Get current API key tier information.
    """
    key_info = await get_api_key_info(request)
    if key_info is None:
        # Local dev mode - return ENDBOSS tier
        return {
            "tier": "ENDBOSS",
            "can_access_models": True,
            "max_sims_per_game": None,
            "rate_limit_per_minute": None,
            "ai_chat_requests_per_month": None,
            "ai_chat_requests_per_minute": None,
        }
    return key_info


# ============================================================================
# DATA COLLECTION ENDPOINTS
# ============================================================================

@app.get("/")
async def root():
    return {
        "name": "MLB MCMC API",
        "version": "1.0.0",
        "status": "running",
        "api_key_required": REQUIRE_API_KEY
    }

@app.post("/api/data/pipeline/run")
async def run_game_pipeline(background_tasks: BackgroundTasks):
    """
    Run the complete game pipeline:
    - Pulls games from most recent game_date to today
    - Populates games and plays tables
    - Updates players, teams, venues, game_rosters
    """
    try:
        import psycopg2
        from dotenv import load_dotenv
        
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        # Query most recent game_date from database
        conn = _get_db_conn()
        cur = conn.cursor()
        cur.execute("SELECT MAX(game_date) FROM games WHERE game_date IS NOT NULL")
        result = cur.fetchone()
        conn.close()
        
        if result and result[0]:
            # Start from day after most recent game
            latest_date = result[0]
            start_date = (latest_date + timedelta(days=1)).strftime('%Y-%m-%d')
        else:
            # No games in DB, start from 30 days ago
            start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
        
        end_date = datetime.now().strftime('%Y-%m-%d')
        
        # Calculate days to process
        start_dt = datetime.strptime(start_date, '%Y-%m-%d')
        end_dt = datetime.strptime(end_date, '%Y-%m-%d')
        days = (end_dt - start_dt).days + 1
        
        if days <= 0:
            return {
                "status": "up_to_date",
                "message": "Database is already up to date",
                "latest_game_date": str(latest_date) if result and result[0] else None
            }
        
        # Build command for complete_game_pipeline.py
        script_path = PROJECT_ROOT / "scripts" / "data_collection" / "complete_game_pipeline.py"
        cmd = [
            "python3",
            str(script_path),
            "--start", start_date,
            "--end", end_date,
            "--skip-existing"
        ]
        
        # Run in background
        background_tasks.add_task(run_pipeline_task, cmd, start_date, end_date)
        
        return {
            "status": "started",
            "start_date": start_date,
            "end_date": end_date,
            "days": days,
            "message": f"Pipeline started for {days} days ({start_date} to {end_date})"
        }
        
    except Exception as e:
        raise HTTPException(500, f"Error starting pipeline: {e}")

@app.post("/api/data/aggregations/compute")
async def compute_aggregations(request: AggregationRequest, background_tasks: BackgroundTasks):
    """
    Compute aggregated statistics for specified years (or current year if not specified):
    - player_season_stats
    - team_season_stats  
    - league_statistics
    - player_hierarchical_stats
    
    Note: player_team_history is already populated by the pipeline
    
    Request body: Optional JSON with years array, e.g. {"years": [2024, 2025]}
    """
    try:
        years = request.years
        if not years:
            # Default to current year
            years = [datetime.now().year]
        
        # Build command for build_remaining_tables.py
        script_path = PROJECT_ROOT / "scripts" / "build_remaining_tables.py"
        cmd = [
            "python3",
            str(script_path),
            "--all",
            "--years"
        ] + [str(year) for year in years]
        
        # Run in background
        background_tasks.add_task(run_aggregation_task, cmd, years)
        
        return {
            "status": "started",
            "years": years,
            "message": f"Computing aggregations for years: {', '.join(map(str, years))}"
        }
        
    except Exception as e:
        raise HTTPException(500, f"Error starting aggregations: {e}")

def run_pipeline_task(cmd: List[str], start_date: str, end_date: str):
    """Background task to run complete game pipeline"""
    import time
    start_time = time.time()
    print(f"[{datetime.now()}] Starting pipeline: {start_date} to {end_date}")
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, cwd=PROJECT_ROOT)
        
        elapsed = time.time() - start_time
        print(f"[{datetime.now()}] Pipeline completed in {elapsed:.1f}s")
        print(f"Exit code: {result.returncode}")
        
        if result.returncode != 0:
            print(f"[ERROR] Pipeline FAILED with code {result.returncode}")
            if result.stderr:
                print(f"Error: {result.stderr[-1000:]}")  # Last 1000 chars
        else:
            print(f"[OK] Pipeline completed successfully")
            
    except Exception as e:
        print(f"[ERROR] Error in pipeline: {e}")
        import traceback
        traceback.print_exc()

def run_aggregation_task(cmd: List[str], years: List[int]):
    """Background task to run aggregation computations.
    
    Runs in order:
    1. build_all_tables_from_plays.py (player_season_stats) 
    2. build_remaining_tables.py (team_season_stats, league_statistics, player_hierarchical_stats)
    3. update_rust_lookups_from_db.py (Rust lookup JSONs with temporal hierarchical stats)
    """
    import time
    start_time = time.time()
    print(f"[{datetime.now()}] Starting aggregations for years: {years}")
    
    try:
        # Step 1: Build player_season_stats from plays table (one year at a time)
        print(f"[{datetime.now()}] Step 1/3: Building player_season_stats...")
        player_stats_script = PROJECT_ROOT / "scripts" / "build_all_tables_from_plays.py"
        
        for year in years:
            player_stats_cmd = ["python3", str(player_stats_script), "--table", "player_season_stats", "--year", str(year)]
            result1 = subprocess.run(player_stats_cmd, capture_output=True, text=True, cwd=PROJECT_ROOT)
            if result1.returncode != 0:
                print(f"[ERROR] player_season_stats for {year} FAILED: {result1.stderr[-300:] if result1.stderr else 'No error'}")
            else:
                print(f"[OK] player_season_stats for {year} built")
        
        # Step 2: Build remaining tables (depends on player_season_stats)
        print(f"[{datetime.now()}] Step 2/3: Building remaining tables...")
        result2 = subprocess.run(cmd, capture_output=True, text=True, cwd=PROJECT_ROOT)
        if result2.returncode != 0:
            print(f"[ERROR] remaining tables FAILED: {result2.stderr[-500:] if result2.stderr else 'No error'}")
        else:
            print(f"[OK] remaining tables built")
        
        # Step 3: Update Rust lookup JSONs from DB (temporal hierarchical stats)
        print(f"[{datetime.now()}] Step 3/3: Updating Rust lookup JSONs...")
        lookup_script = PROJECT_ROOT / "scripts" / "update_rust_lookups_from_db.py"
        if lookup_script.exists():
            lookup_cmd = ["python3", str(lookup_script), "--years"] + [str(y) for y in years]
            result3 = subprocess.run(lookup_cmd, capture_output=True, text=True, cwd=PROJECT_ROOT)
            if result3.returncode != 0:
                print(f"[WARN] Rust lookups update skipped or failed: {result3.stderr[-500:] if result3.stderr else 'No error'}")
            else:
                print(f"[OK] Rust lookups updated with temporal hierarchical stats")
        else:
            print(f"[WARN] Rust lookups script not found, skipping")
        
        elapsed = time.time() - start_time
        print(f"[{datetime.now()}] All aggregations completed in {elapsed:.1f}s")
            
    except Exception as e:
        print(f"[ERROR] Error in aggregations: {e}")
        import traceback
        traceback.print_exc()

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}

@app.get("/api/models/{model_id}/distribution")
async def get_model_distribution(model_id: str, http_request: Request):
    """
    Get probability distribution data for a specific model.
    Returns aggregated statistics suitable for visualization.
    
    ENDBOSS tier only.
    """
    key_info = await get_api_key_info(http_request)
    if key_info and not key_info.get("can_access_models", False):
        raise HTTPException(403, detail="MODELS tab access is restricted to ENDBOSS tier only.")
    try:
        models_dir = PROJECT_ROOT / "models" / "production" / "rust_lookups_v2"
        
        # Map model_id to file name patterns
        file_patterns = {
            "pitch_type": ["pitch_type.json"],
            "pitch_outcome_hierarchical": ["pitch_outcome_hierarchical.json"],
            "hit_outcome_hierarchical": ["hit_outcome_hierarchical.json"],
            "steal_attempt_2nd": ["steal_attempt_2nd.json", "steal_attempt_hierarchical.json"],
            "steal_attempt_3rd": ["steal_attempt_3rd.json", "steal_attempt_3rd_hierarchical.json"],
            "steal_success_2nd": ["steal_success_2nd.json", "steal_success_2nd_hierarchical.json"],
            "steal_success_3rd": ["steal_success_3rd.json", "steal_success_3rd_hierarchical.json"],
            "pickoff_attempt": ["pickoff_attempt.json", "pickoff_attempt_hierarchical.json"],
            "pickoff_success": ["pickoff_success.json", "pickoff_success_hierarchical.json"],
            "pitcher_substitution": ["pitcher_sub.json", "pitcher_sub_hierarchical.json"],
            "delay": ["delay.json", "delay_hierarchical.json"],
            "rolling_team_priors": ["rolling_team_priors.json"],
            "team_pitching_quality": ["team_pitching_quality.json"],
            "pitcher_quality_factors": ["pitcher_quality_factors.json"],
        }
        
        patterns = file_patterns.get(model_id, [f"{model_id}.json"])
        
        # Find the file
        model_file = None
        for pattern in patterns:
            potential_path = models_dir / pattern
            if potential_path.exists():
                model_file = potential_path
                break
        
        if not model_file:
            raise HTTPException(404, f"Model file not found for {model_id}")
        
        with open(model_file, 'r') as f:
            data = json.load(f)
        
        # Process based on model type
        result = {
            "model_id": model_id,
            "file_path": str(model_file.relative_to(PROJECT_ROOT)),
            "distribution_type": "unknown",
            "summary": {},
            "charts": []
        }
        
        # PITCH TYPE MODEL - multinomial with count states
        if model_id == "pitch_type":
            result["distribution_type"] = "multinomial"
            
            # Get default distribution
            default_dist = data.get("default", {})
            result["summary"]["default_distribution"] = default_dist
            
            # Map raw categories to model output categories
            # Model outputs: FASTBALL, BREAKING, OFFSPEED, SPECIALTY
            category_mapping = {
                "fastball": "FASTBALL",
                "slider": "BREAKING", 
                "curveball": "BREAKING",
                "changeup": "OFFSPEED",
                "other": "SPECIALTY"
            }
            
            # Aggregate into output categories
            output_dist = {}
            for raw_cat, prob in default_dist.items():
                output_cat = category_mapping.get(raw_cat, raw_cat.upper())
                if output_cat not in output_dist:
                    output_dist[output_cat] = 0
                output_dist[output_cat] += prob
            
            # Create chart with proper output category order
            category_order = ["FASTBALL", "BREAKING", "OFFSPEED", "SPECIALTY"]
            if output_dist:
                result["charts"].append({
                    "title": "Pitch Type Distribution",
                    "type": "bar",
                    "labels": category_order,
                    "values": [round(output_dist.get(cat, 0) * 100, 1) for cat in category_order],
                    "unit": "%"
                })
            
            result["summary"]["total_states"] = len(data)
        
        # PITCH OUTCOME / HIT OUTCOME - player-based hierarchical
        elif model_id in ["pitch_outcome_hierarchical", "hit_outcome_hierarchical"]:
            result["distribution_type"] = "hierarchical_multinomial"
            
            # Define category mappings to match model output classes
            if model_id == "pitch_outcome_hierarchical":
                # Model outputs: strike, ball, in_play_out, hit, hit_by_pitch
                # Raw categories: ball, called_strike, foul, hit_by_pitch, hit_into_play, swinging_strike
                category_mapping = {
                    "called_strike": "STRIKE",
                    "foul": "STRIKE", 
                    "swinging_strike": "STRIKE",
                    "ball": "BALL",
                    "hit_into_play": "IN_PLAY",
                    "hit_by_pitch": "HIT_BY_PITCH"
                }
                category_order = ["BALL", "STRIKE", "IN_PLAY", "HIT_BY_PITCH"]
            else:  # hit_outcome_hierarchical
                # Model outputs: single, double, triple, home_run (plus outs)
                # Raw: out, single, double, triple, home_run, double_play, sacrifice, error, fielders_choice
                category_mapping = {
                    "out": "OUT",
                    "double_play": "OUT",
                    "sacrifice": "OUT",
                    "fielders_choice": "OUT",
                    "error": "REACHED_ON_ERROR",
                    "single": "SINGLE",
                    "double": "DOUBLE",
                    "triple": "TRIPLE",
                    "home_run": "HOME_RUN"
                }
                category_order = ["OUT", "SINGLE", "DOUBLE", "TRIPLE", "HOME_RUN", "REACHED_ON_ERROR"]
            
            # Check for new hierarchical structure with league/pitchers keys
            if "league" in data:
                league_dist = data.get("league", {})
                
                # Aggregate into output categories
                output_dist = {}
                for raw_cat, prob in league_dist.items():
                    output_cat = category_mapping.get(raw_cat, raw_cat.upper())
                    if output_cat not in output_dist:
                        output_dist[output_cat] = 0
                    output_dist[output_cat] += prob
                
                result["summary"]["league_distribution"] = output_dist
                
                # Count pitchers
                pitchers_data = data.get("pitchers", {})
                result["summary"]["player_count"] = len(pitchers_data)
                result["summary"]["weight_threshold"] = data.get("weight_threshold", 0)
                
                # Create chart with proper category order
                if output_dist:
                    # Filter to only categories that exist
                    labels = [c for c in category_order if c in output_dist]
                    values = [round(output_dist.get(c, 0) * 100, 1) for c in labels]
                    result["charts"].append({
                        "title": "League Average Distribution",
                        "type": "bar",
                        "labels": labels,
                        "values": values,
                        "unit": "%"
                    })
            else:
                # Old structure: direct player IDs with dist/ip
                outcome_totals = {}
                total_weight = 0
                player_count = 0
                
                for key, value in data.items():
                    if key == "weight_threshold":
                        continue
                    if isinstance(value, dict) and "dist" in value:
                        player_count += 1
                        weight = value.get("ip", 1)
                        total_weight += weight
                        for outcome, prob in value["dist"].items():
                            output_cat = category_mapping.get(outcome, outcome.upper())
                            if output_cat not in outcome_totals:
                                outcome_totals[output_cat] = 0
                            outcome_totals[output_cat] += prob * weight
                
                # Normalize
                if total_weight > 0:
                    avg_distribution = {k: v / total_weight for k, v in outcome_totals.items()}
                else:
                    avg_distribution = outcome_totals
                
                result["summary"]["player_count"] = player_count
                result["summary"]["total_innings"] = round(total_weight, 1)
                result["summary"]["average_distribution"] = avg_distribution
                
                if avg_distribution:
                    labels = [c for c in category_order if c in avg_distribution]
                    values = [round(avg_distribution.get(c, 0) * 100, 1) for c in labels]
                    result["charts"].append({
                        "title": "Average Outcome Distribution",
                        "type": "bar",
                        "labels": labels,
                        "values": values,
                        "unit": "%"
                    })
        
        # BERNOULLI MODELS (steal, pickoff, etc.)
        elif model_id in ["steal_attempt_2nd", "steal_attempt_3rd", "steal_success_2nd", 
                          "steal_success_3rd", "pickoff_attempt", "pickoff_success", 
                          "pitcher_substitution", "delay"]:
            result["distribution_type"] = "bernoulli"
            
            # Define output classes for each model
            output_classes = {
                "steal_attempt_2nd": ["NO_STEAL", "STEAL_ATTEMPT"],
                "steal_attempt_3rd": ["NO_STEAL", "STEAL_ATTEMPT"],
                "steal_success_2nd": ["CAUGHT", "SAFE"],
                "steal_success_3rd": ["CAUGHT", "SAFE"],
                "pickoff_attempt": ["NO_PICKOFF", "PICKOFF_ATTEMPT"],
                "pickoff_success": ["SAFE", "OUT"],
                "pitcher_substitution": ["STAY", "SUBSTITUTE"],
                "delay": ["NO_DELAY", "DELAY"],
            }
            result["summary"]["output_classes"] = output_classes.get(model_id, [])
            
            # Check if this is a hierarchical model with league/situation structure
            if "league" in data and isinstance(data["league"], (int, float)):
                # Hierarchical structure
                league_prob = data["league"]
                result["summary"]["league_average"] = round(league_prob, 4)
                result["summary"]["league_average_pct"] = round(league_prob * 100, 2)
                
                # Create a bar chart showing the two outcomes
                classes = output_classes.get(model_id, ["NO", "YES"])
                result["charts"].append({
                    "title": "League Average Probability",
                    "type": "bar",
                    "labels": classes,
                    "values": [round((1 - league_prob) * 100, 1), round(league_prob * 100, 1)],
                    "unit": "%"
                })
                
                # Get runner adjustments if available
                runner_adj = data.get("runner_adjustments", {})
                if runner_adj:
                    result["summary"]["runner_count"] = len(runner_adj)
                
                # Get pitcher adjustments if available
                pitcher_adj = data.get("pitcher_adjustments", {})
                if pitcher_adj:
                    result["summary"]["pitcher_count"] = len(pitcher_adj)
                
            else:
                # Simple key-value structure - collect all probabilities
                probabilities = []
                for key, value in data.items():
                    if isinstance(value, (int, float)):
                        probabilities.append(value)
                
                if probabilities:
                    import statistics
                    mean_prob = statistics.mean(probabilities)
                    result["summary"]["state_count"] = len(probabilities)
                    result["summary"]["mean_probability"] = round(mean_prob, 4)
                    result["summary"]["median_probability"] = round(statistics.median(probabilities), 4)
                    result["summary"]["min_probability"] = round(min(probabilities), 4)
                    result["summary"]["max_probability"] = round(max(probabilities), 4)
                    result["summary"]["std_dev"] = round(statistics.stdev(probabilities), 4) if len(probabilities) > 1 else 0
                    
                    # Create a bar chart showing mean outcome probabilities
                    classes = output_classes.get(model_id, ["NO", "YES"])
                    result["charts"].append({
                        "title": "Mean Outcome Probability",
                        "type": "bar",
                        "labels": classes,
                        "values": [round((1 - mean_prob) * 100, 1), round(mean_prob * 100, 1)],
                        "unit": "%"
                    })
                    
                    # Also add histogram
                    buckets = [0, 0.02, 0.04, 0.06, 0.08, 0.1, 0.15, 0.2, 0.3, 0.5, 1.0]
                    histogram = [0] * (len(buckets) - 1)
                    for p in probabilities:
                        for i in range(len(buckets) - 1):
                            if buckets[i] <= p < buckets[i + 1]:
                                histogram[i] += 1
                                break
                    
                    bucket_labels = [f"{int(buckets[i]*100)}-{int(buckets[i+1]*100)}%" for i in range(len(buckets) - 1)]
                    
                    result["charts"].append({
                        "title": "Probability Distribution Across States",
                        "type": "histogram",
                        "labels": bucket_labels,
                        "values": histogram,
                        "unit": "states"
                    })
        
        # CONTINUOUS FACTORS (team quality, pitcher quality)
        elif model_id in ["rolling_team_priors", "team_pitching_quality", "pitcher_quality_factors"]:
            result["distribution_type"] = "continuous"
            
            # Extract values
            values = []
            for key, value in data.items():
                if isinstance(value, (int, float)):
                    values.append(value)
                elif isinstance(value, dict):
                    for v in value.values():
                        if isinstance(v, (int, float)):
                            values.append(v)
            
            if values:
                import statistics
                result["summary"]["entity_count"] = len(values)
                result["summary"]["mean"] = round(statistics.mean(values), 4)
                result["summary"]["median"] = round(statistics.median(values), 4)
                result["summary"]["min"] = round(min(values), 4)
                result["summary"]["max"] = round(max(values), 4)
                result["summary"]["std_dev"] = round(statistics.stdev(values), 4) if len(values) > 1 else 0
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(500, f"Error getting model distribution: {e}")

@app.get("/api/test/connection")
async def test_connection():
    """
    Test endpoint to verify:
    1. Database connection works
    2. Scripts exist and are accessible
    3. Environment is configured correctly
    """
    import psycopg2
    from dotenv import load_dotenv
    
    results = {
        "database": {"status": "unknown", "details": None},
        "scripts": {"status": "unknown", "details": {}},
        "environment": {"status": "unknown", "details": {}},
    }
    
    # Test 1: Database connection (quick test only)
    try:
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        
        if not database_url:
            results["database"] = {
                "status": "error",
                "details": "DATABASE_URL not set in .env"
            }
        else:
            # Just test connection with a simple query
            conn = _get_db_conn()
            cur = conn.cursor()
            cur.execute("SELECT 1")  # Quick connection test
            cur.fetchone()
            conn.close()
            
            results["database"] = {
                "status": "connected",
                "details": "Database connection successful"
            }
    except Exception as e:
        results["database"] = {
            "status": "error",
            "details": str(e)
        }
    
    # Test 2: Script existence
    pipeline_script = PROJECT_ROOT / "scripts" / "data_collection" / "complete_game_pipeline.py"
    aggregation_script = PROJECT_ROOT / "scripts" / "build_remaining_tables.py"
    
    results["scripts"] = {
        "status": "ok" if pipeline_script.exists() and aggregation_script.exists() else "error",
        "details": {
            "pipeline_script": {
                "path": str(pipeline_script),
                "exists": pipeline_script.exists()
            },
            "aggregation_script": {
                "path": str(aggregation_script),
                "exists": aggregation_script.exists()
            }
        }
    }
    
    # Test 3: Environment
    load_dotenv(PROJECT_ROOT / ".env")
    results["environment"] = {
        "status": "ok",
        "details": {
            "project_root": str(PROJECT_ROOT),
            "python_version": os.popen("python3 --version").read().strip(),
            "database_url_set": bool(os.getenv('DATABASE_URL'))
        }
    }
    
    # Overall status
    overall_status = "ok"
    if results["database"]["status"] == "error" or results["scripts"]["status"] == "error":
        overall_status = "error"
    
    return {
        "overall_status": overall_status,
        "timestamp": datetime.now().isoformat(),
        "tests": results
    }

@app.post("/api/data/collect")
async def collect_data(request: DataCollectionRequest, background_tasks: BackgroundTasks):
    """
    Trigger data collection for a date range
    Uses the pull_date_range.py script
    """
    try:
        # Validate dates
        start = datetime.strptime(request.start_date, "%Y-%m-%d")
        end = datetime.strptime(request.end_date, "%Y-%m-%d")
        
        if start > end:
            raise HTTPException(400, "start_date must be before end_date")
        
        # Calculate days to collect
        days = (end - start).days + 1
        
        # Build command
        script_path = PROJECT_ROOT / "scripts" / "data_collection" / "pull_date_range.py"
        cmd = [
            "python3",
            str(script_path),
            "--start", request.start_date,
            "--end", request.end_date,
        ]
        
        if request.dry_run:
            cmd.append("--dry-run")
        
        # Run in background
        background_tasks.add_task(run_data_collection, cmd)
        
        return {
            "status": "started",
            "start_date": request.start_date,
            "end_date": request.end_date,
            "days": days,
            "message": f"Data collection started for {days} days ({request.start_date} to {request.end_date})"
        }
        
    except ValueError as e:
        raise HTTPException(400, f"Invalid date format: {e}")
    except Exception as e:
        raise HTTPException(500, f"Error starting data collection: {e}")

def run_data_collection(cmd: List[str]):
    """Background task to run data collection"""
    import time
    start_time = time.time()
    print(f"[{datetime.now()}] Starting data collection with command: {' '.join(cmd)}")
    
    try:
        # Run the command and capture output
        result = subprocess.run(cmd, capture_output=True, text=True, cwd=PROJECT_ROOT)
        
        elapsed = time.time() - start_time
        print(f"[{datetime.now()}] Data collection completed in {elapsed:.1f}s")
        print(f"Exit code: {result.returncode}")
        
        if result.stdout:
            print(f"=== STDOUT ===\n{result.stdout[:1000]}")  # First 1000 chars
        
        if result.stderr:
            print(f"=== STDERR ===\n{result.stderr[:1000]}")  # First 1000 chars
            
        if result.returncode != 0:
            print(f"[ERROR] Data collection FAILED with code {result.returncode}")
        else:
            print(f"[OK] Data collection completed successfully")
            
    except Exception as e:
        print(f"[ERROR] Error in data collection: {e}")
        import traceback
        traceback.print_exc()

@app.get("/api/data/status")
async def get_data_status():
    """
    Get current data collection status
    Checks logs and data files
    """
    try:
        # Check latest data files
        data_dir = PROJECT_ROOT / "data" / "mlb_models"
        
        training_file = data_dir / "training_plays_with_hierarchical_v2.parquet"
        validation_file = data_dir / "validation_plays_with_hierarchical_v2.parquet"
        
        status = {
            "training_data_exists": training_file.exists(),
            "validation_data_exists": validation_file.exists(),
            "last_update": None
        }
        
        if training_file.exists():
            stat = training_file.stat()
            status["last_update"] = datetime.fromtimestamp(stat.st_mtime).isoformat()
            status["training_size_mb"] = round(stat.st_size / 1024 / 1024, 2)
        
        return status
        
    except Exception as e:
        raise HTTPException(500, f"Error checking data status: {e}")

@app.get("/api/data/games/summary")
async def get_games_summary():
    """
    Get summary of games in the database (optimized for large datasets)
    """
    try:
        import psycopg2
        from dotenv import load_dotenv
        
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        conn = _get_db_conn()
        cur = conn.cursor()
        
        # Single optimized query to get all stats at once
        cur.execute("""
            SELECT 
                COUNT(DISTINCT g.game_pk) as total_games,
                MIN(g.game_date) as min_date,
                MAX(g.game_date) as max_date,
                COUNT(DISTINCT CASE WHEN p.game_pk IS NOT NULL THEN g.game_pk END) as games_with_plays
            FROM games g
            LEFT JOIN (SELECT DISTINCT game_pk FROM plays LIMIT 1000000) p ON g.game_pk = p.game_pk
            WHERE g.game_date IS NOT NULL
        """)
        row = cur.fetchone()
        total_games, min_date, max_date, games_with_plays = row
        
        # Get most recent 10 games (simplified)
        cur.execute("""
            SELECT g.game_date, g.game_pk
            FROM games g
            WHERE g.game_date IS NOT NULL
            ORDER BY g.game_date DESC, g.game_pk DESC
            LIMIT 10
        """)
        recent_games = [
            {
                'game_date': str(row[0]),
                'game_pk': row[1],
                'play_count': 0  # Skip counting plays for speed
            }
            for row in cur.fetchall()
        ]
        
        conn.close()
        
        return {
            "total_games": total_games,
            "games_with_plays": games_with_plays,
            "games_missing_plays": total_games - games_with_plays,
            "total_plays": 0,  # Skip for speed
            "date_range": {
                "earliest": str(min_date) if min_date else None,
                "latest": str(max_date) if max_date else None
            },
            "recent_games": recent_games
        }
        
    except Exception as e:
        raise HTTPException(500, f"Error reading games data: {e}")

# ============================================================================
# MODEL TRAINING ENDPOINTS
# ============================================================================

@app.post("/api/models/train")
async def train_model(request: ModelTrainingRequest, background_tasks: BackgroundTasks, http_request: Request):
    """
    Trigger model training (legacy endpoint)
    
    ENDBOSS tier only.
    """
    key_info = await get_api_key_info(http_request)
    if key_info and not key_info.get("can_access_models", False):
        raise HTTPException(403, detail="MODELS tab access is restricted to ENDBOSS tier only.")
    try:
        valid_models = ["pitch_outcome", "hit_type", "pitch_type"]
        if request.model_type not in valid_models:
            raise HTTPException(400, f"Invalid model_type. Must be one of: {valid_models}")
        
        # Find appropriate training script
        script_name = f"train_{request.model_type}_model.py"
        if request.use_hierarchical:
            script_name = "train_hierarchical_v2_models.py"
        
        script_path = PROJECT_ROOT / "scripts" / "training" / script_name
        
        if not script_path.exists():
            raise HTTPException(404, f"Training script not found: {script_name}")
        
        cmd = ["python", str(script_path)]
        
        background_tasks.add_task(run_model_training, cmd, request.model_type)
        
        return {
            "status": "started",
            "model_type": request.model_type,
            "hierarchical": request.use_hierarchical,
            "message": f"Training {request.model_type} model"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Error starting model training: {e}")

@app.post("/api/models/retrain")
async def retrain_model(request: RetrainModelRequest, background_tasks: BackgroundTasks, http_request: Request):
    """
    Retrain a model with automated workflow:
    1. Uses data from 2018 to today
    2. Trains the model
    3. Updates submodel_registry
    4. Links to production model version
    
    ENDBOSS tier only.
    """
    key_info = await get_api_key_info(http_request)
    if key_info and not key_info.get("can_access_models", False):
        raise HTTPException(403, detail="MODELS tab access is restricted to ENDBOSS tier only.")
    import psycopg2
    from dotenv import load_dotenv
    
    try:
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        # Get model info from inventory
        conn = _get_db_conn()
        cur = conn.cursor()
        
        # Try to get model name from submodel_registry
        cur.execute("""
            SELECT submodel_name FROM submodel_registry 
            WHERE submodel_name = %s OR submodel_id::text = %s
            LIMIT 1
        """, (request.model_id, request.model_id))
        
        result = cur.fetchone()
        model_name = result[0] if result else request.model_id
        
        # Create training job
        from datetime import date
        cur.execute("""
            INSERT INTO training_jobs (
                model_id, model_name, status, progress_percent,
                training_start_date, training_end_date, use_hierarchical
            ) VALUES (%s, %s, 'pending', 0, %s, %s, TRUE)
            RETURNING job_id
        """, (request.model_id, model_name, date(2018, 1, 1), date.today()))
        
        job_id = cur.fetchone()[0]
        conn.commit()
        cur.close()
        conn.close()
        
        # Start training in background
        background_tasks.add_task(run_automated_retraining, request.model_id, job_id)
        
        return {
            "status": "started",
            "job_id": job_id,
            "model_id": request.model_id,
            "message": f"Started retraining {model_name}"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Error starting model retraining: {e}")

@app.get("/api/models/training/status/{job_id}")
async def get_training_status(job_id: int, http_request: Request):
    """
    Get training job status for polling
    
    ENDBOSS tier only.
    """
    key_info = await get_api_key_info(http_request)
    if key_info and not key_info.get("can_access_models", False):
        raise HTTPException(403, detail="MODELS tab access is restricted to ENDBOSS tier only.")
    import psycopg2
    from dotenv import load_dotenv
    
    try:
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        conn = _get_db_conn()
        cur = conn.cursor()
        
        cur.execute("""
            SELECT job_id, model_id, model_name, status, progress_percent,
                   current_step, error_message, started_at, completed_at, duration_seconds
            FROM training_jobs
            WHERE job_id = %s
        """, (job_id,))
        
        result = cur.fetchone()
        cur.close()
        conn.close()
        
        if not result:
            raise HTTPException(404, f"Training job {job_id} not found")
        
        return {
            "job_id": result[0],
            "model_id": result[1],
            "model_name": result[2],
            "status": result[3],
            "progress_percent": result[4] or 0,
            "current_step": result[5],
            "error_message": result[6],
            "started_at": str(result[7]) if result[7] else None,
            "completed_at": str(result[8]) if result[8] else None,
            "duration_seconds": result[9]
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Error getting training status: {e}")

@app.get("/api/models/training/status")
async def get_all_training_status():
    """
    Get status of all recent training jobs
    """
    import psycopg2
    from dotenv import load_dotenv
    
    try:
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        conn = _get_db_conn()
        cur = conn.cursor()
        
        cur.execute("""
            SELECT job_id, model_id, model_name, status, progress_percent,
                   current_step, error_message, started_at, completed_at
            FROM training_jobs
            ORDER BY created_at DESC
            LIMIT 20
        """)
        
        jobs = []
        for row in cur.fetchall():
            jobs.append({
                "job_id": row[0],
                "model_id": row[1],
                "model_name": row[2],
                "status": row[3],
                "progress_percent": row[4] or 0,
                "current_step": row[5],
                "error_message": row[6],
                "started_at": str(row[7]) if row[7] else None,
                "completed_at": str(row[8]) if row[8] else None,
            })
        
        cur.close()
        conn.close()
        
        return {"jobs": jobs}
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Error getting training status: {e}")

def run_automated_retraining(model_id: str, job_id: int):
    """Background task to run automated retraining"""
    import subprocess
    
    try:
        script_path = PROJECT_ROOT / "scripts" / "training" / "retrain_model_automated.py"
        cmd = [
            "python", str(script_path),
            "--model-id", model_id,
            "--job-id", str(job_id),
            "--start-date", "2018-01-01",
            "--end-date", date.today().isoformat()
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, cwd=PROJECT_ROOT)
        
        if result.returncode != 0:
            print(f"Retraining failed for {model_id} (job {job_id}): {result.stderr}")
        else:
            print(f"Retraining completed for {model_id} (job {job_id})")
            print(f"Output: {result.stdout}")
            
    except Exception as e:
        print(f"Error in automated retraining: {e}")
        import traceback
        traceback.print_exc()

def run_model_training(cmd: List[str], model_type: str):
    """Background task to run model training"""
    try:
        result = subprocess.run(cmd, capture_output=True, text=True)
        print(f"Model training completed for {model_type}: {result.returncode}")
        print(f"Output: {result.stdout}")
        if result.stderr:
            print(f"Errors: {result.stderr}")
    except Exception as e:
        print(f"Error in model training: {e}")

@app.get("/api/models/status")
async def get_model_status():
    """
    Get status of trained models
    """
    try:
        models_dir = PROJECT_ROOT / "models" / "production"
        
        status = {
            "hierarchical_v2": {
                "pitch_outcome": (models_dir / "hierarchical_v2" / "pitch_outcome_xgb_hierarchical_v2.json").exists(),
                "hit_type": (models_dir / "hierarchical_v2" / "hit_type_xgb_hierarchical_v2.json").exists(),
            },
            "fast_simulation": {
                "pitch_outcome_lookup": (models_dir / "fast_simulation" / "pitch_outcome_lookup_hierarchical_v2_simple.json").exists(),
                "hit_type_lookup": (models_dir / "fast_simulation" / "hit_type_lookup_hierarchical_v2_simple.json").exists(),
            }
        }
        
        return status
        
    except Exception as e:
        raise HTTPException(500, f"Error checking model status: {e}")

@app.get("/api/models/inventory")
async def get_model_inventory(http_request: Request):
    """
    Get detailed inventory of all MCMC production models with metadata.
    Fetches submodels from the database's submodel_registry table linked
    to the current production MCMC version (v2.2).
    
    ENDBOSS tier only.
    """
    # Check if user has access to models
    key_info = await get_api_key_info(http_request)
    if key_info and not key_info.get("can_access_models", False):
        raise HTTPException(403, detail="MODELS tab access is restricted to ENDBOSS tier only.")
    
    import psycopg2
    from dotenv import load_dotenv
    
    try:
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        
        models = []
        model_version_info = None
        
        # Try to fetch from database
        if database_url:
            try:
                conn = _get_db_conn()
                cur = conn.cursor()
                
                # Get the current production model version
                cur.execute("""
                    SELECT version_id, version_name, version_tag, model_type, 
                           hyperparameters, market_performance, status, 
                           deployed_at, description, notes, calibration_score
                    FROM model_versions 
                    WHERE is_primary = TRUE AND status = 'production'
                    ORDER BY version_id DESC
                    LIMIT 1
                """)
                version_row = cur.fetchone()
                
                if version_row:
                    model_version_info = {
                        "version_id": version_row[0],
                        "version_name": version_row[1],
                        "version_tag": version_row[2],
                        "model_type": version_row[3],
                        "hyperparameters": version_row[4],
                        "market_performance": version_row[5],
                        "status": version_row[6],
                        "deployed_at": str(version_row[7]) if version_row[7] else None,
                        "description": version_row[8],
                        "calibration_score": float(version_row[10]) if version_row[10] else None
                    }
                    
                    # Get all submodels for this version
                    cur.execute("""
                        SELECT submodel_id, submodel_name, submodel_type, version,
                               model_file_path, trained_on_date, training_samples,
                               validation_metrics, is_active, created_at
                        FROM submodel_registry
                        WHERE model_version_id = %s AND is_active = TRUE
                        ORDER BY submodel_name
                    """, (version_row[0],))
                    
                    submodel_rows = cur.fetchall()
                    
                    # Define metadata for each submodel type
                    submodel_metadata = {
                        "pitch_type": {
                            "display_name": "Pitch Type Model",
                            "category": "primary",
                            "stage": 1,
                            "description": "Predicts pitch type (FASTBALL, BREAKING, OFFSPEED, SPECIALTY) based on count and game state",
                            "distribution": {"type": "Multinomial", "classes": ["FASTBALL", "BREAKING", "OFFSPEED", "SPECIALTY"]},
                            "priority": "critical"
                        },
                        "pitch_outcome_hierarchical": {
                            "display_name": "Pitch Outcome Model",
                            "category": "primary",
                            "stage": 2,
                            "description": "Predicts pitch outcome (strike, ball, in_play_out, hit, HBP) using hierarchical player effects",
                            "distribution": {"type": "Dirichlet-Multinomial", "classes": ["BALL", "STRIKE", "IN_PLAY", "HIT_BY_PITCH"]},
                            "priority": "critical"
                        },
                        "hit_outcome_hierarchical": {
                            "display_name": "Hit Type Model",
                            "category": "primary",
                            "stage": 3,
                            "description": "Predicts hit type (single, double, triple, home_run) when contact results in a hit",
                            "distribution": {"type": "Dirichlet-Multinomial", "classes": ["OUT", "SINGLE", "DOUBLE", "TRIPLE", "HOME_RUN"]},
                            "priority": "critical"
                        },
                        "steal_attempt_2nd": {
                            "display_name": "Steal Attempt (2nd Base)",
                            "category": "baserunning",
                            "stage": None,
                            "description": "Predicts when runner on 1st will attempt to steal 2nd base",
                            "distribution": {"type": "Bernoulli", "classes": ["NO_STEAL", "STEAL_ATTEMPT"]},
                            "priority": "important"
                        },
                        "steal_attempt_3rd": {
                            "display_name": "Steal Attempt (3rd Base)",
                            "category": "baserunning",
                            "stage": None,
                            "description": "Predicts when runner on 2nd will attempt to steal 3rd base",
                            "distribution": {"type": "Bernoulli", "classes": ["NO_STEAL", "STEAL_ATTEMPT"]},
                            "priority": "important"
                        },
                        "steal_success_2nd": {
                            "display_name": "Steal Success (2nd Base)",
                            "category": "baserunning",
                            "stage": None,
                            "description": "Predicts if steal attempt to 2nd base succeeds",
                            "distribution": {"type": "Bernoulli", "classes": ["CAUGHT", "SAFE"]},
                            "priority": "important"
                        },
                        "steal_success_3rd": {
                            "display_name": "Steal Success (3rd Base)",
                            "category": "baserunning",
                            "stage": None,
                            "description": "Predicts if steal attempt to 3rd base succeeds",
                            "distribution": {"type": "Bernoulli", "classes": ["CAUGHT", "SAFE"]},
                            "priority": "important"
                        },
                        "pickoff_attempt": {
                            "display_name": "Pickoff Attempt Model",
                            "category": "baserunning",
                            "stage": None,
                            "description": "Predicts when pitcher will attempt pickoff throw",
                            "distribution": {"type": "Bernoulli", "classes": ["NO_PICKOFF", "PICKOFF_ATTEMPT"]},
                            "priority": "optional"
                        },
                        "pickoff_success": {
                            "display_name": "Pickoff Success Model",
                            "category": "baserunning",
                            "stage": None,
                            "description": "Predicts if pickoff attempt results in out",
                            "distribution": {"type": "Bernoulli", "classes": ["SAFE", "OUT"]},
                            "priority": "optional"
                        },
                        "pitcher_substitution": {
                            "display_name": "Pitcher Substitution Model",
                            "category": "secondary",
                            "stage": None,
                            "description": "Predicts when manager will substitute the pitcher based on pitch count and fatigue",
                            "distribution": {"type": "Bernoulli", "classes": ["STAY", "SUBSTITUTE"]},
                            "priority": "important"
                        },
                        "delay": {
                            "display_name": "Game Delay Model",
                            "category": "environment",
                            "stage": None,
                            "description": "Predicts probability of game delay (rain, weather)",
                            "distribution": {"type": "Bernoulli", "classes": ["NO_DELAY", "DELAY"]},
                            "priority": "optional"
                        },
                        "rolling_team_priors": {
                            "display_name": "Rolling Team Priors",
                            "category": "computed",
                            "stage": None,
                            "description": "Computed team win rate priors based on recent performance",
                            "distribution": {"type": "Beta", "classes": ["win_prob"]},
                            "priority": "important"
                        },
                        "team_pitching_quality": {
                            "display_name": "Team Pitching Quality",
                            "category": "computed",
                            "stage": None,
                            "description": "Computed factors for overall team pitching quality",
                            "distribution": {"type": "Continuous", "classes": ["quality_factor"]},
                            "priority": "optional"
                        },
                        "pitcher_quality_factors": {
                            "display_name": "Pitcher Quality Factors",
                            "category": "computed",
                            "stage": None,
                            "description": "Individual pitcher quality adjustments based on stats",
                            "distribution": {"type": "Continuous", "classes": ["quality_factor"]},
                            "priority": "optional"
                        },
                    }
                    
                    for row in submodel_rows:
                        submodel_name = row[1]
                        submodel_type = row[2]
                        version = row[3]
                        file_path = row[4]
                        trained_date = row[5]
                        training_samples = row[6]
                        validation_metrics = row[7]
                        is_active = row[8]
                        created_at = row[9]
                        
                        # Get metadata for this submodel
                        meta = submodel_metadata.get(submodel_name, {
                            "display_name": submodel_name.replace("_", " ").title(),
                            "category": "other",
                            "stage": None,
                            "description": f"Submodel: {submodel_name}",
                            "distribution": {"type": "Unknown", "classes": []},
                            "priority": "optional"
                        })
                        
                        # Check if file exists
                        file_exists = (PROJECT_ROOT / file_path).exists() if file_path else False
                        
                        models.append({
                            "id": submodel_name,
                            "name": meta["display_name"],
                            "category": meta["category"],
                            "stage": meta["stage"],
                            "description": meta["description"],
                            "model_type": submodel_type or "empirical_lookup",
                            "distribution": meta["distribution"],
                            "status": "ready" if file_exists else "missing",
                            "version": version,
                            "trained_at": str(trained_date) if trained_date else str(created_at)[:10] if created_at else None,
                            "file_path": file_path,
                            "training_samples": training_samples,
                            "metrics": validation_metrics,
                            "priority": meta["priority"],
                            "is_active": is_active
                        })
                    
                conn.close()
                
            except Exception as db_error:
                print(f"Database error, falling back to file-based detection: {db_error}")
                # Fall back to file-based detection below
        
        # If no models from database, use file-based detection as fallback
        if not models:
            models_dir = PROJECT_ROOT / "models" / "production" / "rust_lookups_v2"
            
            if models_dir.exists():
                # Define the v2.2 submodels based on files
                v22_submodels = [
                    ("pitch_type", "Pitch Type Model", "primary", 1, "Predicts pitch type", {"type": "Multinomial", "classes": ["FASTBALL", "BREAKING", "OFFSPEED", "SPECIALTY"]}, "critical"),
                    ("pitch_outcome_hierarchical", "Pitch Outcome Model", "primary", 2, "Predicts pitch outcome", {"type": "Dirichlet-Multinomial", "classes": ["strike", "ball", "in_play_out", "hit", "hit_by_pitch"]}, "critical"),
                    ("hit_outcome_hierarchical", "Hit Type Model", "primary", 3, "Predicts hit type", {"type": "Dirichlet-Multinomial", "classes": ["single", "double", "triple", "home_run"]}, "critical"),
                    ("steal_attempt_2nd", "Steal Attempt (2nd)", "baserunning", None, "Predicts steal attempts to 2nd", {"type": "Bernoulli", "classes": ["NO_STEAL", "STEAL_ATTEMPT"]}, "important"),
                    ("steal_attempt_3rd", "Steal Attempt (3rd)", "baserunning", None, "Predicts steal attempts to 3rd", {"type": "Bernoulli", "classes": ["NO_STEAL", "STEAL_ATTEMPT"]}, "important"),
                    ("steal_success_2nd", "Steal Success (2nd)", "baserunning", None, "Predicts steal success to 2nd", {"type": "Bernoulli", "classes": ["CAUGHT", "SAFE"]}, "important"),
                    ("steal_success_3rd", "Steal Success (3rd)", "baserunning", None, "Predicts steal success to 3rd", {"type": "Bernoulli", "classes": ["CAUGHT", "SAFE"]}, "important"),
                    ("pickoff_attempt", "Pickoff Attempt", "baserunning", None, "Predicts pickoff attempts", {"type": "Bernoulli", "classes": ["NO_PICKOFF", "PICKOFF_ATTEMPT"]}, "optional"),
                    ("pickoff_success", "Pickoff Success", "baserunning", None, "Predicts pickoff success", {"type": "Bernoulli", "classes": ["SAFE", "OUT"]}, "optional"),
                    ("pitcher_sub", "Pitcher Substitution", "secondary", None, "Predicts pitcher changes", {"type": "Bernoulli", "classes": ["STAY", "SUBSTITUTE"]}, "important"),
                    ("delay", "Game Delay", "environment", None, "Predicts game delays", {"type": "Bernoulli", "classes": ["NO_DELAY", "DELAY"]}, "optional"),
                    ("rolling_team_priors", "Rolling Team Priors", "computed", None, "Team win rate priors", {"type": "Beta", "classes": ["win_prob"]}, "important"),
                    ("team_pitching_quality", "Team Pitching Quality", "computed", None, "Team pitching factors", {"type": "Continuous", "classes": ["quality_factor"]}, "optional"),
                    ("pitcher_quality_factors", "Pitcher Quality Factors", "computed", None, "Pitcher quality factors", {"type": "Continuous", "classes": ["quality_factor"]}, "optional"),
                ]
                
                for submodel_id, name, category, stage, desc, dist, priority in v22_submodels:
                    # Try different file name patterns
                    file_patterns = [
                        f"{submodel_id}.json",
                        f"{submodel_id}_hierarchical.json",
                    ]
                    
                    file_exists = any((models_dir / pattern).exists() for pattern in file_patterns)
                    
                    models.append({
                        "id": submodel_id,
                        "name": name,
                        "category": category,
                        "stage": stage,
                        "description": desc,
                        "model_type": "empirical_lookup",
                        "distribution": dist,
                        "status": "ready" if file_exists else "missing",
                        "version": "v2.2",
                        "trained_at": None,
                        "priority": priority
                    })
        
        # Calculate summary stats
        total_models = len(models)
        ready_models = sum(1 for m in models if m["status"] == "ready")
        critical_ready = sum(1 for m in models if m["status"] == "ready" and m.get("priority") == "critical")
        critical_total = sum(1 for m in models if m.get("priority") == "critical")
        
        # Get unique categories
        categories = {}
        for m in models:
            cat = m.get("category", "other")
            categories[cat] = categories.get(cat, 0) + 1
        
        return {
            "model_version": model_version_info,
            "models": models,
            "summary": {
                "total": total_models,
                "ready": ready_models,
                "missing": total_models - ready_models,
                "critical_ready": critical_ready,
                "critical_total": critical_total,
                "categories": categories
            }
        }
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(500, f"Error getting model inventory: {e}")

# ============================================================================
# SIMULATION ENDPOINTS
# ============================================================================

@app.post("/api/simulate/run")
async def run_simulation(request: SimulationRequest, background_tasks: BackgroundTasks):
    """
    Run MCMC simulations for a specific date
    """
    try:
        # Validate date
        game_date = datetime.strptime(request.game_date, "%Y-%m-%d")
        
        # Build Rust simulation command
        cmd = [
            "cargo", "run", "--release", "--bin", "batch_simulate_august1"
        ]
        
        background_tasks.add_task(run_rust_simulation, cmd, request.num_sims)
        
        return {
            "status": "started",
            "game_date": request.game_date,
            "num_sims": request.num_sims,
            "message": f"Simulation started with {request.num_sims} iterations"
        }
        
    except ValueError as e:
        raise HTTPException(400, f"Invalid date format: {e}")
    except Exception as e:
        raise HTTPException(500, f"Error starting simulation: {e}")

def run_rust_simulation(cmd: List[str], num_sims: int):
    """Background task to run Rust simulation"""
    try:
        # Run from project root
        result = subprocess.run(
            cmd,
            cwd=PROJECT_ROOT,
            capture_output=True,
            text=True
        )
        print(f"Simulation completed with {num_sims} sims: {result.returncode}")
        print(f"Output: {result.stdout[:1000]}")  # First 1000 chars
        if result.stderr:
            print(f"Errors: {result.stderr[:1000]}")
    except Exception as e:
        print(f"Error in simulation: {e}")

@app.get("/api/simulate/results")
async def get_simulation_results():
    """
    Get latest simulation results
    """
    try:
        # Check for results file
        results_dir = PROJECT_ROOT / "results"
        
        # Look for latest results
        latest_file = None
        latest_time = None
        
        for file in results_dir.glob("*.txt"):
            mtime = file.stat().st_mtime
            if latest_time is None or mtime > latest_time:
                latest_time = mtime
                latest_file = file
        
        if not latest_file:
            return {"status": "no_results", "message": "No simulation results found"}
        
        # Parse results (simplified - you'd want more robust parsing)
        with open(latest_file, 'r') as f:
            content = f.read()
        
        return {
            "status": "available",
            "file": latest_file.name,
            "last_updated": datetime.fromtimestamp(latest_time).isoformat(),
            "preview": content[:500]
        }
        
    except Exception as e:
        raise HTTPException(500, f"Error getting simulation results: {e}")

# ============================================================================
# PREDICTIONS ENDPOINTS
# ============================================================================

class GameSimulationRequest(BaseModel):
    """Request to run simulation for a specific game"""
    game_pk: int
    num_simulations: int = 10000
    
class LineupPlayer(BaseModel):
    name: str
    position: str
    player_id: int
    hierarchical_stats: Optional[Dict[str, float]] = None

class PitcherInfo(BaseModel):
    name: str
    player_id: int
    stats: Optional[Dict[str, float]] = None

class GameDataRequest(BaseModel):
    """Full game data for simulation"""
    game_pk: int
    game_date: str
    home_team_id: int
    away_team_id: int
    home_lineup: Dict[str, LineupPlayer]
    away_lineup: Dict[str, LineupPlayer]
    home_pitcher: PitcherInfo
    away_pitcher: PitcherInfo
    num_simulations: int = 10000

@app.post("/api/predictions/simulate")
async def simulate_game(request: GameDataRequest, http_request: Request):
    """
    Run fast_json_sim for a game and return betting predictions.
    
    This is the MAIN simulation endpoint for the Predictions tab.
    Takes game lineup/pitcher data and returns win probabilities, props, etc.
    """
    # Check tier limits for simulations
    key_info = await get_api_key_info(http_request)
    if key_info:
        max_sims = key_info.get("max_sims_per_game")
        if max_sims is not None and request.num_simulations > max_sims:
            raise HTTPException(
                403,
                detail=f"Simulation limit exceeded. Your tier allows up to {max_sims:,} sims per game, but you requested {request.num_simulations:,}."
            )
    
    import tempfile
    
    try:
        # Convert request to JSON format expected by fast_json_sim
        game_data = {
            "game_pk": request.game_pk,
            "game_date": request.game_date,
            "home_team_id": request.home_team_id,
            "away_team_id": request.away_team_id,
            "home_lineup": {k: v.model_dump() for k, v in request.home_lineup.items()},
            "away_lineup": {k: v.model_dump() for k, v in request.away_lineup.items()},
            "home_pitcher": request.home_pitcher.model_dump(),
            "away_pitcher": request.away_pitcher.model_dump(),
        }
        
        # Write to temp file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(game_data, f)
            temp_path = f.name
        
        try:
            # Run fast_json_sim
            sim_binary = PROJECT_ROOT / "target" / "release" / "fast_json_sim"
            
            if not sim_binary.exists():
                raise HTTPException(500, "Simulation binary not found. Run: cargo build --release")
            
            cmd = [
                str(sim_binary),
                temp_path,
                str(request.num_simulations),
                "--json",
                "--sgp"  # Include SGP cache for instant same-game parlay calculations
            ]
            
            result = subprocess.run(
                cmd,
                cwd=PROJECT_ROOT,
                capture_output=True,
                text=True,
                timeout=600  # 10 minute timeout for 500k sims
            )
            
            if result.returncode != 0:
                raise HTTPException(500, f"Simulation failed: {result.stderr[:500]}")
            
            # Parse JSON output
            sim_results = json.loads(result.stdout)
            
            return {
                "status": "success",
                "game_pk": request.game_pk,
                "num_simulations": request.num_simulations,
                "results": sim_results
            }
            
        finally:
            # Clean up temp file
            os.unlink(temp_path)
            
    except json.JSONDecodeError as e:
        raise HTTPException(500, f"Failed to parse simulation output: {e}")
    except subprocess.TimeoutExpired:
        raise HTTPException(500, "Simulation timed out")
    except Exception as e:
        raise HTTPException(500, f"Simulation error: {e}")

@app.get("/api/predictions/today")
async def get_today_predictions():
    """
    Get games scheduled for today with any cached predictions
    """
    import psycopg2
    from dotenv import load_dotenv
    
    try:
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        today = datetime.now().strftime("%Y-%m-%d")
        
        conn = _get_db_conn()
        cur = conn.cursor()
        
        # Get today's games with team info
        cur.execute("""
            SELECT 
                g.game_pk,
                g.game_date,
                g.game_type,
                g.home_team_id,
                g.away_team_id,
                g.game_time_et,
                g.status_detailed,
                t1.abbreviation as away_abbr,
                t1.name as away_name,
                t2.abbreviation as home_abbr,
                t2.name as home_name,
                g.venue_name
            FROM games g
            LEFT JOIN teams t1 ON g.away_team_id = t1.team_id
            LEFT JOIN teams t2 ON g.home_team_id = t2.team_id
            WHERE g.game_date = %s
              AND g.game_type IN ('R', 'S', 'E')
            ORDER BY g.game_time_et NULLS LAST
        """, (today,))
        
        games = []
        for row in cur.fetchall():
            game_time = None
            if row[5]:
                try:
                    from datetime import time as dt_time
                    if isinstance(row[5], dt_time):
                        game_time = row[5].strftime('%H:%M')
                except:
                    pass
            
            games.append({
                'game_pk': row[0],
                'game_date': str(row[1]),
                'game_type': row[2],
                'home_team_id': row[3],
                'away_team_id': row[4],
                'game_time': game_time,
                'status': row[6],
                'away_abbr': row[7] or 'UNK',
                'away_name': row[8],
                'home_abbr': row[9] or 'UNK',
                'home_name': row[10],
                'venue': row[11],
                'simulation_status': 'pending',  # TODO: Check if we have cached results
                'prediction': None  # TODO: Load from cache if exists
            })
        
        conn.close()
        
        return {
            "date": today,
            "total_games": len(games),
            "games": games
        }
        
    except Exception as e:
        raise HTTPException(500, f"Error fetching predictions: {e}")

@app.get("/api/predictions/date/{date}")
async def get_predictions_by_date(date: str):
    """
    Get games and predictions for a specific date
    """
    import psycopg2
    from dotenv import load_dotenv
    
    try:
        # Validate date
        game_date = datetime.strptime(date, "%Y-%m-%d")
        
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        conn = _get_db_conn()
        cur = conn.cursor()
        
        # Get games for this date
        cur.execute("""
            SELECT 
                g.game_pk,
                g.game_date,
                g.game_type,
                g.home_team_id,
                g.away_team_id,
                g.game_time_et,
                g.status_detailed,
                t1.abbreviation as away_abbr,
                t2.abbreviation as home_abbr,
                g.home_score,
                g.away_score
            FROM games g
            LEFT JOIN teams t1 ON g.away_team_id = t1.team_id
            LEFT JOIN teams t2 ON g.home_team_id = t2.team_id
            WHERE g.game_date = %s
              AND g.game_type IN ('R', 'S', 'E')
            ORDER BY g.game_time_et NULLS LAST
        """, (date,))
        
        games = []
        for row in cur.fetchall():
            games.append({
                'game_pk': row[0],
                'game_date': str(row[1]),
                'home_team_id': row[3],
                'away_team_id': row[4],
                'away_abbr': row[7] or 'UNK',
                'home_abbr': row[8] or 'UNK',
                'home_score': row[9],
                'away_score': row[10],
                'status': row[6],
                'simulation_status': 'pending',
                'prediction': None
            })
        
        conn.close()
        
        return {
            "date": date,
            "total_games": len(games),
            "games": games
        }
        
    except ValueError as e:
        raise HTTPException(400, f"Invalid date format: {e}")
    except Exception as e:
        raise HTTPException(500, f"Error fetching predictions: {e}")

@app.get("/api/lineups/{game_pk}")
async def get_pregame_lineup(game_pk: int):
    """
    Get pregame lineup for a specific game from the pregame_lineups table.
    
    Returns batting order (1-9) for each team plus starting pitchers.
    """
    import psycopg2
    from dotenv import load_dotenv
    
    try:
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        conn = _get_db_conn()
        cur = conn.cursor()
        
        # Get game info first (needed for fallback)
        cur.execute("""
            SELECT g.game_date, g.away_team_id, g.home_team_id,
                   t1.abbreviation as away_abbr, t2.abbreviation as home_abbr
            FROM games g
            LEFT JOIN teams t1 ON g.away_team_id = t1.team_id
            LEFT JOIN teams t2 ON g.home_team_id = t2.team_id
            WHERE g.game_pk = %s
            LIMIT 1
        """, (game_pk,))
        
        game_row = cur.fetchone()
        if not game_row:
            conn.close()
            raise HTTPException(404, f"Game {game_pk} not found")
        
        game_date = game_row[0]
        away_team_id = game_row[1]
        home_team_id = game_row[2]
        away_abbr = game_row[3]
        home_abbr = game_row[4]
        
        # Check per-team whether we have real (non-default) lineup/pitcher data
        # After gap-fill, default rows exist in pregame_lineups/pregame_pitchers
        # with source='rotowire_default'. We need to distinguish real vs default PER TEAM.
        
        # Count real batters per team
        cur.execute("""
            SELECT team_id, COUNT(*) 
            FROM pregame_lineups 
            WHERE game_pk = %s AND source IS DISTINCT FROM 'rotowire_default'
            GROUP BY team_id
        """, (game_pk,))
        real_batters_by_team = dict(cur.fetchall())
        away_real_batters = real_batters_by_team.get(away_team_id, 0)
        home_real_batters = real_batters_by_team.get(home_team_id, 0)
        has_real_batters = (away_real_batters + home_real_batters) > 0
        
        # Check real pitchers per team
        cur.execute("""
            SELECT team_id, COUNT(*) 
            FROM pregame_pitchers 
            WHERE game_pk = %s AND source IS DISTINCT FROM 'rotowire_default'
            GROUP BY team_id
        """, (game_pk,))
        real_pitchers_by_team = dict(cur.fetchall())
        away_real_pitcher = real_pitchers_by_team.get(away_team_id, 0) > 0
        home_real_pitcher = real_pitchers_by_team.get(home_team_id, 0) > 0
        has_real_pitchers = away_real_pitcher or home_real_pitcher
        
        # Per-team "fully announced" = has real batters AND a real pitcher
        # CONFIRMED only when EVERY part of BOTH teams' lineups is real (non-default)
        away_fully_announced = away_real_batters > 0 and away_real_pitcher
        home_fully_announced = home_real_batters > 0 and home_real_pitcher
        both_fully_announced = away_fully_announced and home_fully_announced
        
        # Also check if any rows exist at all (including defaults from gap-fill)
        cur.execute("SELECT COUNT(*) FROM pregame_lineups WHERE game_pk = %s", (game_pk,))
        has_any_batters = cur.fetchone()[0] > 0
        cur.execute("SELECT COUNT(*) FROM pregame_pitchers WHERE game_pk = %s", (game_pk,))
        has_any_pitchers = cur.fetchone()[0] > 0
        
        # PARTIAL = ANY part of the lineup data is real/confirmed while the rest is defaults.
        # Catches: only SPs confirmed, only one team announced, one pitcher + other team's batters, etc.
        is_partial = (has_real_batters or has_real_pitchers) and not both_fully_announced
        use_defaults = not has_real_batters and not has_real_pitchers
        
        # For the query logic below, use the "any" flags so we still read the rows
        has_game_batters = has_any_batters
        has_game_pitchers = has_any_pitchers
        
        # --- Fetch lineups ---
        # After gap-fill, pregame_lineups has rows for both teams (real + gap-filled).
        # Use those when available; only fall back to rotowire_default_lineups if empty.
        if has_any_batters:
            # Game-specific lineups (includes both real and gap-filled default rows)
            cur.execute("""
                SELECT 
                    pl.team_id,
                    pl.batting_order,
                    pl.player_id,
                    pl.position,
                    COALESCE(p.full_name, 'Unknown Player') as player_name,
                    COALESCE(pl.source, 'mlb_api') as source,
                    COALESCE(pl.lineup_status, 'confirmed') as lineup_status
                FROM pregame_lineups pl
                LEFT JOIN players p ON pl.player_id = p.player_id
                WHERE pl.game_pk = %s
                ORDER BY pl.team_id, pl.batting_order
                LIMIT 18
            """, (game_pk,))
            lineup_rows = cur.fetchall()
        else:
            # No pregame_lineups rows at all — use rotowire_default_lineups directly
            cur.execute("""
                SELECT 
                    rdl.team_id,
                    rdl.batting_order,
                    rdl.player_id,
                    rdl.position,
                    COALESCE(p.full_name, 'Unknown Player') as player_name,
                    'rotowire_default' as source,
                    'projected' as lineup_status
                FROM rotowire_default_lineups rdl
                LEFT JOIN players p ON rdl.player_id = p.player_id
                WHERE rdl.team_id IN (%s, %s)
                  AND rdl.lineup_type = 'vs_rhp'
                ORDER BY rdl.team_id, rdl.batting_order
            """, (away_team_id, home_team_id))
            lineup_rows = cur.fetchall()
            # Fallback to vs_lhp if vs_rhp didn't have enough
            if len(lineup_rows) < 18:
                cur.execute("""
                    SELECT 
                        rdl.team_id,
                        rdl.batting_order,
                        rdl.player_id,
                        rdl.position,
                        COALESCE(p.full_name, 'Unknown Player') as player_name,
                        'rotowire_default' as source,
                        'projected' as lineup_status
                    FROM rotowire_default_lineups rdl
                    LEFT JOIN players p ON rdl.player_id = p.player_id
                    WHERE rdl.team_id IN (%s, %s)
                      AND rdl.lineup_type = 'vs_lhp'
                    ORDER BY rdl.team_id, rdl.batting_order
                """, (away_team_id, home_team_id))
                lineup_rows = cur.fetchall()
        
        # --- Fetch pitchers ---
        if has_any_pitchers:
            # Game-specific pitchers (includes both real and gap-filled default rows)
            cur.execute("""
                SELECT 
                    pp.team_id,
                    pp.player_id,
                    COALESCE(pp.throws, COALESCE(p.pitch_hand_code, 'R')) as throws,
                    COALESCE(p.full_name, 'Unknown Pitcher') as player_name,
                    COALESCE(pp.source, 'mlb_api') as source,
                    COALESCE(pp.lineup_status, 'confirmed') as lineup_status
                FROM pregame_pitchers pp
                LEFT JOIN players p ON pp.player_id = p.player_id
                WHERE pp.game_pk = %s
                LIMIT 2
            """, (game_pk,))
            pitcher_rows = cur.fetchall()
        else:
            # No pregame_pitchers rows — use rotowire_default_pitchers
            cur.execute("""
                SELECT 
                    rdp.team_id,
                    rdp.player_id,
                    COALESCE(p.pitch_hand_code, 'R') as throws,
                    COALESCE(p.full_name, 'Unknown Pitcher') as player_name,
                    'rotowire_default' as source,
                    'projected' as lineup_status
                FROM rotowire_default_pitchers rdp
                LEFT JOIN players p ON rdp.player_id = p.player_id
                WHERE rdp.team_id IN (%s, %s)
                  AND rdp.rotation_spot = 1
                  AND (p.primary_position_code::text = '1' OR p.primary_position_code::integer = 1)
            """, (away_team_id, home_team_id))
            pitcher_rows = cur.fetchall()
        
        # If we tried defaults but got nothing for lineups AND no pitchers, raise 404
        # Partial case (SP but no batters) is still OK — we have pitchers + default batters
        if use_defaults and not lineup_rows and not pitcher_rows:
            conn.close()
            raise HTTPException(404, f"No lineup found for game {game_pk} (defaults not available)")
        
        # If we have game-specific data but it's incomplete, that's OK (will show INCOMPLETE)
        if not use_defaults and not lineup_rows and not pitcher_rows:
            conn.close()
            raise HTTPException(404, f"No lineup found for game {game_pk}")
        
        # Build response
        home_lineup = {}
        away_lineup = {}
        home_pitcher = None
        away_pitcher = None
        lineup_sources = set()
        lineup_statuses = set()
        
        for team_id, batting_order, player_id, position, player_name, source, lineup_status in lineup_rows:
            lineup_entry = {
                "player_id": player_id,
                "name": player_name,
                "position": position
            }
            lineup_sources.add(source)
            lineup_statuses.add(lineup_status)
            if team_id == home_team_id:
                home_lineup[str(batting_order)] = lineup_entry
            else:
                away_lineup[str(batting_order)] = lineup_entry
        
        # Fill missing batting order slots (1-9) with default placeholder players
        POS_CODE_MAP = {1: 'P', 2: 'C', 3: '1B', 4: '2B', 5: '3B', 6: 'SS', 7: 'LF', 8: 'CF', 9: 'RF', 10: 'DH'}
        
        # Helper function to find a placeholder player for a team
        def find_placeholder_player(team_id):
            # Try current_team_id first
            cur.execute("""
                SELECT player_id, full_name, primary_position_code
                FROM players
                WHERE current_team_id = %s
                  AND primary_position_code::text NOT IN ('1', '1.0')
                ORDER BY player_id
                LIMIT 1
            """, (team_id,))
            row = cur.fetchone()
            
            if row:
                return row
            
            # Fallback: use player_team_history (most recent season)
            cur.execute("""
                SELECT p.player_id, p.full_name, p.primary_position_code
                FROM players p
                JOIN player_team_history pth ON p.player_id = pth.player_id
                WHERE pth.team_id = %s
                  AND p.primary_position_code::text NOT IN ('1', '1.0')
                ORDER BY pth.season DESC, p.player_id
                LIMIT 1
            """, (team_id,))
            row = cur.fetchone()
            
            return row
        
        # Fill missing slots for home team
        for order in range(1, 10):
            if str(order) not in home_lineup:
                placeholder_row = find_placeholder_player(home_team_id)
                
                if placeholder_row:
                    placeholder_id, placeholder_name, pos_code = placeholder_row
                    pos_int = int(pos_code) if pos_code and str(pos_code).isdigit() else None
                    placeholder_pos = POS_CODE_MAP.get(pos_int, 'DH') if pos_int else 'DH'
                    
                    home_lineup[str(order)] = {
                        "player_id": placeholder_id,
                        "name": placeholder_name,
                        "position": placeholder_pos
                    }
                    lineup_sources.add('rotowire_default')
                    lineup_statuses.add('projected')
                else:
                    # Last resort: use a generic placeholder
                    home_lineup[str(order)] = {
                        "player_id": None,
                        "name": "TBD",
                        "position": "DH"
                    }
                    lineup_sources.add('rotowire_default')
                    lineup_statuses.add('projected')
        
        # Fill missing slots for away team
        for order in range(1, 10):
            if str(order) not in away_lineup:
                placeholder_row = find_placeholder_player(away_team_id)
                
                if placeholder_row:
                    placeholder_id, placeholder_name, pos_code = placeholder_row
                    pos_int = int(pos_code) if pos_code and str(pos_code).isdigit() else None
                    placeholder_pos = POS_CODE_MAP.get(pos_int, 'DH') if pos_int else 'DH'
                    
                    away_lineup[str(order)] = {
                        "player_id": placeholder_id,
                        "name": placeholder_name,
                        "position": placeholder_pos
                    }
                    lineup_sources.add('rotowire_default')
                    lineup_statuses.add('projected')
                else:
                    # Last resort: use a generic placeholder
                    away_lineup[str(order)] = {
                        "player_id": None,
                        "name": "TBD",
                        "position": "DH"
                    }
                    lineup_sources.add('rotowire_default')
                    lineup_statuses.add('projected')
        
        for team_id, player_id, throws, player_name, source, lineup_status in pitcher_rows:
            pitcher_entry = {
                "player_id": player_id,
                "name": player_name,
                "throws": throws or 'R'
            }
            lineup_sources.add(source)
            lineup_statuses.add(lineup_status)
            if team_id == home_team_id:
                home_pitcher = pitcher_entry
            else:
                away_pitcher = pitcher_entry
        
        # Close connection after all DB queries are done
        conn.close()
        
        # Determine overall lineup status
        # CONFIRMED = EVERY part of BOTH teams' lineups is real (batters + pitcher each)
        # PARTIAL = ANY part is real/confirmed, everything else is defaults
        # PROJECTED = RotoWire projected (not yet confirmed)
        # DEFAULT = everything from cached defaults (zero real data)
        if both_fully_announced and 'confirmed' in lineup_statuses:
            overall_status = 'confirmed'
        elif is_partial:
            overall_status = 'partial'
        elif both_fully_announced and 'projected' in lineup_statuses:
            # Both teams projected (e.g. RotoWire expected but not confirmed)
            overall_status = 'projected'
        elif 'projected' in lineup_statuses and not use_defaults:
            overall_status = 'projected'
        elif use_defaults:
            overall_status = 'projected'  # Will show as DEFAULT on frontend via lineup_source check
        else:
            overall_status = 'unknown'
        
        return {
            "game_pk": game_pk,
            "game_date": str(game_date) if game_date else None,
            "home_team_id": home_team_id,
            "away_team_id": away_team_id,
            "home_abbr": home_abbr,
            "away_abbr": away_abbr,
            "home_lineup": home_lineup,
            "away_lineup": away_lineup,
            "home_pitcher": home_pitcher,
            "away_pitcher": away_pitcher,
            "lineup_complete": bool(len(home_lineup) == 9 and len(away_lineup) == 9 and home_pitcher and away_pitcher),
            "lineup_source": list(lineup_sources),
            "lineup_status": overall_status,
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Error fetching lineup: {e}")

@app.get("/api/lineups/by-teams/{away_abbr}/{home_abbr}")
async def get_pregame_lineup_by_teams(away_abbr: str, home_abbr: str, date: Optional[str] = None):
    """
    Get pregame lineup by team abbreviations (useful when game_pk is unknown).
    Optionally filter by date.
    """
    import psycopg2
    from dotenv import load_dotenv
    
    try:
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        conn = _get_db_conn()
        cur = conn.cursor()
        
        # Get team IDs
        cur.execute("SELECT team_id FROM teams WHERE abbreviation = %s", (away_abbr.upper(),))
        away_row = cur.fetchone()
        cur.execute("SELECT team_id FROM teams WHERE abbreviation = %s", (home_abbr.upper(),))
        home_row = cur.fetchone()
        
        if not away_row or not home_row:
            conn.close()
            raise HTTPException(404, f"Team not found: {away_abbr} or {home_abbr}")
        
        away_team_id = away_row[0]
        home_team_id = home_row[0]
        
        # Find game_pk for this matchup
        query = """
            SELECT DISTINCT pl.game_pk
            FROM pregame_lineups pl
            WHERE pl.team_id IN (%s, %s)
            GROUP BY pl.game_pk
            HAVING COUNT(DISTINCT pl.team_id) = 2
        """
        params = [away_team_id, home_team_id]
        
        # If date provided, also check games table
        if date:
            query = """
                SELECT g.game_pk
                FROM games g
                WHERE g.away_team_id = %s AND g.home_team_id = %s AND g.game_date = %s
                UNION
                SELECT DISTINCT pl.game_pk
                FROM pregame_lineups pl
                WHERE pl.team_id IN (%s, %s)
                GROUP BY pl.game_pk
                HAVING COUNT(DISTINCT pl.team_id) = 2
            """
            params = [away_team_id, home_team_id, date, away_team_id, home_team_id]
        
        cur.execute(query, params)
        game_pk_row = cur.fetchone()
        
        conn.close()
        
        if not game_pk_row:
            raise HTTPException(404, f"No lineup found for {away_abbr} @ {home_abbr}")
        
        # Use the other endpoint to get full lineup
        return await get_pregame_lineup(game_pk_row[0])
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Error fetching lineup: {e}")

@app.get("/api/calendar/games")
async def get_calendar_games(year: int, month: int):
    """
    Get all games for a specific month to populate calendar
    
    Args:
        year: Year (e.g., 2026)
        month: Month (1-12)
        
    Returns:
        Dict with dates as keys and game info as values
    """
    import psycopg2
    from dotenv import load_dotenv
    from calendar import monthrange
    
    try:
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        conn = _get_db_conn()
        cur = conn.cursor()
        
        # Get first and last day of month
        _, last_day = monthrange(year, month)
        start_date = f"{year}-{month:02d}-01"
        end_date = f"{year}-{month:02d}-{last_day:02d}"
        
        # Query games for this month
        cur.execute("""
            SELECT 
                g.game_date,
                g.game_type,
                COUNT(*) as game_count
            FROM games g
            WHERE g.game_date >= %s 
              AND g.game_date <= %s
            GROUP BY g.game_date, g.game_type
            ORDER BY g.game_date
        """, (start_date, end_date))
        
        # Build response with dates and game types
        games_by_date = {}
        for row in cur.fetchall():
            date_str = str(row[0])
            game_type_raw = row[1]
            count = row[2]
            
            # Normalize game_type (strip whitespace, handle None)
            game_type = None
            if game_type_raw:
                game_type = str(game_type_raw).strip().upper()
            
            if date_str not in games_by_date:
                games_by_date[date_str] = {
                    'spring': 0,
                    'regular': 0,
                    'postseason': 0,
                    'exhibition': 0,  # E type
                    'total': 0
                }
            
            # Categorize game types
            if game_type in ['S', 'E']:  # Spring Training or Exhibition
                games_by_date[date_str]['spring'] += count
                if game_type == 'E':
                    games_by_date[date_str]['exhibition'] += count
            elif game_type == 'R':  # Regular Season
                games_by_date[date_str]['regular'] += count
            elif game_type in ['P', 'F', 'D', 'L', 'W']:  # Postseason types
                games_by_date[date_str]['postseason'] += count
            elif game_type:  # Unknown game type - default to regular season
                games_by_date[date_str]['regular'] += count
            
            games_by_date[date_str]['total'] += count
        
        conn.close()
        
        return {
            'year': year,
            'month': month,
            'games': games_by_date
        }
        
    except Exception as e:
        raise HTTPException(500, f"Error fetching calendar games: {e}")

@app.get("/api/calendar/games/{date}")
async def get_games_for_date(date: str):
    """
    Get detailed game information for a specific date
    
    Args:
        date: Date in YYYY-MM-DD format
        
    Returns:
        List of games for that date
    """
    import psycopg2
    from dotenv import load_dotenv
    
    try:
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        conn = _get_db_conn()
        cur = conn.cursor()
        
        # Optimized query - fetch all data at once
        cur.execute("""
            SELECT 
                g.game_pk,
                g.game_date,
                g.game_type,
                g.home_team_id,
                g.away_team_id,
                g.venue_name,
                g.status_detailed,
                g.game_time_et,
                g.home_score,
                g.away_score,
                t1.abbreviation as away_abbr,
                t1.name as away_name,
                t2.abbreviation as home_abbr,
                t2.name as home_name
            FROM games g
            LEFT JOIN teams t1 ON g.away_team_id = t1.team_id
            LEFT JOIN teams t2 ON g.home_team_id = t2.team_id
            WHERE g.game_date = %s
            ORDER BY g.game_time_et NULLS LAST, g.game_pk
        """, (date,))
        
        from datetime import datetime, time
        rows = cur.fetchall()
        
        # Build games list more efficiently
        games = []
        for row in rows:
            # Format time for display (simplified, faster)
            game_time_display = None
            if row[7]:  # game_time_et
                try:
                    time_value = row[7]
                    if isinstance(time_value, time):
                        hour = time_value.hour
                        if 10 <= hour <= 23:
                            dt = datetime.combine(datetime.today(), time_value)
                            game_time_display = dt.strftime('%-I:%M %p ET')
                    elif isinstance(time_value, str):
                        time_obj = datetime.strptime(time_value, '%H:%M:%S')
                        hour = time_obj.hour
                        if 10 <= hour <= 23:
                            game_time_display = time_obj.strftime('%-I:%M %p ET')
                except:
                    pass  # Leave as None on any error
            
            games.append({
                'game_pk': row[0],
                'game_date': str(row[1]),
                'game_type': row[2],
                'home_team_id': row[3],
                'away_team_id': row[4],
                'venue_name': row[5],
                'status': row[6],
                'game_time': game_time_display,
                'home_score': row[8],
                'away_score': row[9],
                'away_team': row[10],
                'away_team_name': row[11],
                'home_team': row[12],
                'home_team_name': row[13]
            })
        
        conn.close()
        
        return {
            'date': date,
            'games': games,
            'total': len(games)
        }
        
    except Exception as e:
        raise HTTPException(500, f"Error fetching games for date: {e}")

# ============================================================================
# ODDS API ENDPOINTS
# ============================================================================

# ── Static odds routes MUST come before /api/odds/{game_pk} ──────────────
import signal as _signal

_odds_poll_process: Optional[subprocess.Popen] = None
_odds_poll_started_at: Optional[datetime] = None

# Persistent file paths for odds feed survival across API restarts
_ODDS_PID_FILE = PROJECT_ROOT / "logs" / "odds_poll.pid"
_ODDS_AUTOSTART_FILE = PROJECT_ROOT / "logs" / "odds_poll.autostart"
_ODDS_WATCHDOG_INTERVAL = 60  # Check every 60 seconds


def _odds_pid_file_read() -> Optional[int]:
    """Read PID from the PID file, or None if missing/invalid."""
    try:
        if _ODDS_PID_FILE.exists():
            pid = int(_ODDS_PID_FILE.read_text().strip())
            return pid
    except (ValueError, OSError):
        pass
    return None


def _odds_pid_file_write(pid: int):
    """Write PID to the PID file."""
    _ODDS_PID_FILE.parent.mkdir(exist_ok=True)
    _ODDS_PID_FILE.write_text(str(pid))


def _odds_pid_file_remove():
    """Remove the PID file."""
    try:
        _ODDS_PID_FILE.unlink(missing_ok=True)
    except OSError:
        pass


def _odds_autostart_set():
    """Mark that the odds feed should auto-start on API boot."""
    _ODDS_AUTOSTART_FILE.parent.mkdir(exist_ok=True)
    _ODDS_AUTOSTART_FILE.write_text(datetime.now(timezone.utc).isoformat())


def _odds_autostart_clear():
    """Remove the auto-start flag."""
    try:
        _ODDS_AUTOSTART_FILE.unlink(missing_ok=True)
    except OSError:
        pass


def _odds_autostart_is_set() -> bool:
    """Check if auto-start flag is set."""
    return _ODDS_AUTOSTART_FILE.exists()


def _is_process_alive(pid: int) -> bool:
    """Check if a process with the given PID is alive."""
    try:
        os.kill(pid, 0)  # Signal 0 = existence check, no actual signal sent
        return True
    except (ProcessLookupError, PermissionError, OSError):
        return False


def _recover_odds_process():
    """Try to recover an existing odds polling process from the PID file.
    Called on API startup and when status reports no in-memory process."""
    global _odds_poll_process, _odds_poll_started_at

    if _odds_poll_process is not None and _odds_poll_process.poll() is None:
        return True  # Already have a live process

    pid = _odds_pid_file_read()
    if pid is not None and _is_process_alive(pid):
        # Process is running but we lost the reference (API restarted)
        # We can't get a Popen handle for an existing process, but we can
        # track it by PID for status checks and termination.
        _odds_poll_process = None  # No Popen handle, but PID file tracks it
        if _odds_poll_started_at is None:
            # Use PID file mtime as approximate start time
            try:
                mtime = _ODDS_PID_FILE.stat().st_mtime
                _odds_poll_started_at = datetime.fromtimestamp(mtime, tz=timezone.utc)
            except OSError:
                _odds_poll_started_at = datetime.now(timezone.utc)
        return True
    else:
        # PID file stale or missing
        _odds_pid_file_remove()
        return False


def _start_odds_process() -> dict:
    """Internal: start the odds polling subprocess. Returns status dict."""
    global _odds_poll_process, _odds_poll_started_at

    odds_api_key = os.getenv('ODDS_API_KEY')
    if not odds_api_key:
        return {"status": "error", "message": "ODDS_API_KEY not configured in .env"}

    cmd = [
        sys.executable,
        str(PROJECT_ROOT / "scripts" / "odds_api_ingestion.py"),
        "--poll",
    ]

    try:
        log_path = PROJECT_ROOT / "logs"
        log_path.mkdir(exist_ok=True)
        odds_log = open(log_path / "odds_poll.log", "a")
        _odds_poll_process = subprocess.Popen(
            cmd,
            env={**os.environ, 'ODDS_API_KEY': odds_api_key},
            stdout=odds_log,
            stderr=odds_log,
        )
        _odds_poll_started_at = datetime.now(timezone.utc)
        _odds_pid_file_write(_odds_poll_process.pid)
        _odds_autostart_set()
        print(f"[ODDS] Feed started — PID {_odds_poll_process.pid}")
        return {"status": "started", "message": "ODDS FEED STARTED", "pid": _odds_poll_process.pid}
    except Exception as e:
        return {"status": "error", "message": f"Failed to start polling: {e}"}


def _stop_odds_process():
    """Internal: stop the odds polling subprocess and clean up."""
    global _odds_poll_process, _odds_poll_started_at

    killed = False

    # Try via Popen handle first
    if _odds_poll_process is not None:
        try:
            if _odds_poll_process.poll() is None:
                _odds_poll_process.send_signal(_signal.SIGTERM)
                _odds_poll_process.wait(timeout=10)
                killed = True
        except subprocess.TimeoutExpired:
            _odds_poll_process.kill()
            killed = True
        except Exception:
            pass

    # Also try via PID file (in case we lost the Popen handle)
    if not killed:
        pid = _odds_pid_file_read()
        if pid is not None and _is_process_alive(pid):
            try:
                os.kill(pid, _signal.SIGTERM)
                # Wait briefly for it to die
                import time as _time
                for _ in range(20):
                    if not _is_process_alive(pid):
                        break
                    _time.sleep(0.5)
                else:
                    os.kill(pid, _signal.SIGKILL)
            except (ProcessLookupError, PermissionError, OSError):
                pass

    _odds_poll_process = None
    _odds_poll_started_at = None
    _odds_pid_file_remove()
    _odds_autostart_clear()
    print("[ODDS] Feed stopped and autostart cleared")


def _is_odds_feed_alive() -> bool:
    """Check if the odds feed is alive (via Popen handle or PID file)."""
    global _odds_poll_process

    # Check Popen handle
    if _odds_poll_process is not None:
        if _odds_poll_process.poll() is None:
            return True
        else:
            _odds_poll_process = None

    # Fallback: check PID file
    pid = _odds_pid_file_read()
    if pid is not None and _is_process_alive(pid):
        return True

    return False


async def _odds_watchdog():
    """Background watchdog: if autostart is set but the process died, restart it."""
    import asyncio
    while True:
        await asyncio.sleep(_ODDS_WATCHDOG_INTERVAL)
        try:
            if _odds_autostart_is_set() and not _is_odds_feed_alive():
                print("[ODDS WATCHDOG] Feed died but autostart is set — restarting...")
                result = _start_odds_process()
                print(f"[ODDS WATCHDOG] Restart result: {result['status']} — {result['message']}")
        except Exception as e:
            print(f"[ODDS WATCHDOG] Error: {e}")


@app.get("/api/odds/status")
async def get_odds_status():
    """Return whether the odds polling feed is running and when odds were last updated."""
    import psycopg2
    from dotenv import load_dotenv

    global _odds_poll_process, _odds_poll_started_at

    is_active = _is_odds_feed_alive()

    # If not active via handles, try recovery from PID file
    if not is_active:
        is_active = _recover_odds_process()

    # Query most recent odds update timestamp
    last_updated = None
    try:
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        if database_url:
            conn = _get_db_conn()
            cur = conn.cursor()
            cur.execute("SELECT MAX(odds_updated_at) FROM sportsbook_markets WHERE is_available = TRUE")
            row = cur.fetchone()
            if row and row[0]:
                ts = row[0]
                # Ensure the timestamp has UTC timezone info so the frontend can convert
                if ts.tzinfo is None:
                    ts = ts.replace(tzinfo=timezone.utc)
                last_updated = ts.isoformat()
            conn.close()
    except Exception:
        pass

    return {
        "active": is_active,
        "autostart": _odds_autostart_is_set(),
        "started_at": _odds_poll_started_at.isoformat() if _odds_poll_started_at else None,
        "last_updated": last_updated,
    }


@app.post("/api/odds/start-polling")
async def start_odds_polling():
    """Start the odds polling background process (persistent — survives API restarts)."""
    global _odds_poll_process, _odds_poll_started_at

    # Check if already running (via handle or PID file)
    if _is_odds_feed_alive():
        return {"status": "already_running", "message": "ODDS FEED ALREADY RUNNING"}

    odds_api_key = os.getenv('ODDS_API_KEY')
    if not odds_api_key:
        raise HTTPException(400, "ODDS_API_KEY not configured in .env")

    result = _start_odds_process()
    if result["status"] == "error":
        raise HTTPException(500, result["message"])
    return result


@app.post("/api/odds/stop-polling")
async def stop_odds_polling():
    """Stop the odds polling background process and disable auto-start."""
    global _odds_poll_process, _odds_poll_started_at

    if not _is_odds_feed_alive():
        _odds_poll_process = None
        _odds_poll_started_at = None
        _odds_pid_file_remove()
        _odds_autostart_clear()
        return {"status": "not_running", "message": "ODDS FEED NOT RUNNING"}

    _stop_odds_process()
    return {"status": "stopped", "message": "ODDS FEED STOPPED"}


@app.post("/api/odds/fetch")
async def trigger_odds_fetch(background_tasks: BackgroundTasks,
                              feed: str = "both"):
    """
    Manually trigger an odds fetch from The Odds API.
    Runs in the background so the request returns immediately.
    
    feed: "both" (default), "pinnacle", or "us"
    """
    odds_api_key = os.getenv('ODDS_API_KEY')
    if not odds_api_key:
        raise HTTPException(400, "ODDS_API_KEY not configured in .env")
    
    cmd = [
        sys.executable, 
        str(PROJECT_ROOT / "scripts" / "odds_api_ingestion.py"),
        "--once",
    ]
    if feed == "pinnacle":
        cmd.append("--pinnacle")
    elif feed == "us":
        cmd.append("--us")
    # default = --once with no filter = both feeds
    
    def run_fetch():
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=300,
                                  env={**os.environ, 'ODDS_API_KEY': odds_api_key})
            if result.returncode != 0:
                print(f"[ODDS FETCH] Error: {result.stderr}")
            else:
                print(f"[ODDS FETCH] Success: {result.stdout[-500:]}")
        except Exception as e:
            print(f"[ODDS FETCH] Failed: {e}")
    
    background_tasks.add_task(run_fetch)
    
    return {
        "status": "fetching",
        "message": f"Odds fetch ({feed}) started in background. Check /api/odds/date/{{date}} for results.",
        "feed": feed
    }


# ── Dynamic odds routes (game_pk path param) ─────────────────────────────

@app.get("/api/odds/{game_pk}")
async def get_odds_for_game(game_pk: int):
    """
    Get current sportsbook odds for a specific game.
    Returns odds from all tracked sportsbooks, organized by market type.
    """
    import psycopg2
    from dotenv import load_dotenv
    
    try:
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        conn = _get_db_conn()
        cur = conn.cursor()
        
        cur.execute("""
            SELECT 
                sm.market_type, sm.outcome_side, sm.strike_price,
                sm.american_odds, sm.decimal_odds, sm.implied_probability,
                sm.player_name, sm.player_id, sm.team_side,
                sb.short_name as book, sb.api_key_name as book_key,
                sb.name as book_name,
                sm.odds_updated_at
            FROM sportsbook_markets sm
            JOIN sportsbooks sb ON sm.sportsbook_id = sb.sportsbook_id
            WHERE sm.game_pk = %s AND sm.is_available = TRUE
            ORDER BY sm.market_type, sm.outcome_side, sm.strike_price, sb.short_name
        """, (game_pk,))
        
        columns = [desc[0] for desc in cur.description]
        rows = [dict(zip(columns, row)) for row in cur.fetchall()]
        
        # Organize by market type
        markets = {}
        for row in rows:
            mt = row['market_type']
            if mt not in markets:
                markets[mt] = []
            
            # Serialize datetime
            if row.get('odds_updated_at'):
                row['odds_updated_at'] = row['odds_updated_at'].isoformat()
            if row.get('strike_price'):
                row['strike_price'] = float(row['strike_price'])
            if row.get('implied_probability'):
                row['implied_probability'] = float(row['implied_probability'])
            if row.get('decimal_odds'):
                row['decimal_odds'] = float(row['decimal_odds'])
            
            markets[mt].append(row)
        
        conn.close()
        
        return {
            "game_pk": game_pk,
            "markets": markets,
            "total_lines": len(rows),
            "books": list(set(r['book'] for r in rows))
        }
        
    except Exception as e:
        raise HTTPException(500, f"Error fetching odds: {e}")


@app.get("/api/odds/date/{date}")
async def get_odds_for_date(date: str):
    """
    Get current sportsbook odds for ALL games on a specific date.
    Returns a dict keyed by game_pk, each containing:
      - main_markets: MONEYLINE, SPREAD, TOTAL, ALT_SPREAD, ALT_TOTAL lines
      - props: batter props (HITS, HOME_RUNS, etc.) with sportsbook lines
      - pinnacle_fair: de-vigged Pinnacle probabilities for each 2-way market
      - books: list of sportsbook short_names present
    """
    import psycopg2
    from dotenv import load_dotenv
    
    try:
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        conn = _get_db_conn()
        cur = conn.cursor()
        
        # Get all game_pks for this date
        cur.execute("""
            SELECT game_pk FROM games WHERE game_date = %s AND game_type IN ('R', 'S', 'E')
        """, (date,))
        game_pks = [row[0] for row in cur.fetchall()]
        
        if not game_pks:
            conn.close()
            return {"date": date, "games": {}, "total_games": 0}
        
        # Fetch all odds for these games
        cur.execute("""
            SELECT 
                sm.game_pk,
                sm.market_type, sm.outcome_side, sm.strike_price,
                sm.american_odds, sm.implied_probability,
                sm.player_name, sm.player_id, sm.team_side,
                sb.short_name as book, sb.api_key_name as book_key
            FROM sportsbook_markets sm
            JOIN sportsbooks sb ON sm.sportsbook_id = sb.sportsbook_id
            WHERE sm.game_pk = ANY(%s) AND sm.is_available = TRUE
            ORDER BY sm.game_pk, sm.market_type, sm.outcome_side, sb.short_name
        """, (game_pks,))
        
        columns = [desc[0] for desc in cur.description]
        rows = [dict(zip(columns, row)) for row in cur.fetchall()]
        
        # Market types that are "main" (game-level)
        MAIN_TYPES = {
            'MONEYLINE', 'SPREAD', 'TOTAL', 'ALT_SPREAD', 'ALT_TOTAL',
            'F5_H2H', 'F5_MONEYLINE', 'F5_SPREAD', 'F5_TOTAL',
            'F5_ALT_SPREAD', 'F5_ALT_TOTAL',
            'TEAM_TOTAL', 'ALT_TEAM_TOTAL',
        }
        
        # Organize by game_pk -> structured markets
        games = {}
        for row in rows:
            gpk = row['game_pk']
            if gpk not in games:
                games[gpk] = {
                    'game_pk': gpk,
                    'main_markets': {},
                    'props': {},
                    'books': set(),
                }
            
            games[gpk]['books'].add(row['book'])
            
            mt = row['market_type']
            side = row['outcome_side']
            strike = float(row['strike_price']) if row['strike_price'] else None
            odds = row['american_odds']
            book = row['book']
            prob = float(row['implied_probability']) if row['implied_probability'] else None
            
            if mt in MAIN_TYPES:
                key = f"{mt}_{side}"
                if strike is not None:
                    key += f"_{strike}"
                
                if key not in games[gpk]['main_markets']:
                    games[gpk]['main_markets'][key] = {
                        'market_type': mt,
                        'outcome_side': side,
                        'strike_price': strike,
                        'team_side': row.get('team_side'),
                        'books': {}
                    }
                games[gpk]['main_markets'][key]['books'][book] = {
                    'odds': odds,
                    'implied_prob': prob,
                }
            
            # Props (anything not in MAIN_TYPES)
            else:
                player = row.get('player_name', 'Unknown')
                prop_key = f"{player}_{mt}_{side}_{strike}"
                
                if prop_key not in games[gpk]['props']:
                    games[gpk]['props'][prop_key] = {
                        'market_type': mt,
                        'player_name': player,
                        'player_id': row.get('player_id'),
                        'outcome_side': side,
                        'strike_price': strike,
                        'books': {}
                    }
                games[gpk]['props'][prop_key]['books'][book] = {
                    'odds': odds,
                    'implied_prob': prob,
                }
        
        # Compute de-vigged Pinnacle fair prices for each game
        # This saves the frontend from having to make separate pinnacle-fair calls
        
        for gpk_str, game_data in games.items():
            pinnacle_fair = {}
            
            # Group Pinnacle lines into pairs (home/away, over/under)
            # For spreads, use abs(strike) so -1.5 (home) and +1.5 (away) pair together
            SPREAD_TYPES = {'SPREAD', 'ALT_SPREAD', 'F5_SPREAD', 'F5_ALT_SPREAD'}
            pin_pairs = {}  # key -> { side: odds }
            for mkt in game_data['main_markets'].values():
                pin_odds = mkt['books'].get('PIN', {}).get('odds')
                if pin_odds is None:
                    continue
                mt = mkt['market_type']
                strike = mkt['strike_price']
                if mt in SPREAD_TYPES and strike is not None:
                    pair_key = f"{mt}_{abs(strike)}"
                elif strike is not None:
                    pair_key = f"{mt}_{strike}"
                else:
                    pair_key = mt
                if pair_key not in pin_pairs:
                    pin_pairs[pair_key] = {'market_type': mt, 'strike': strike}
                pin_pairs[pair_key][mkt['outcome_side']] = pin_odds
            
            for pair_key, pair in pin_pairs.items():
                mt = pair['market_type']
                strike = pair.get('strike')
                if mt == 'MONEYLINE':
                    if 'home' in pair and 'away' in pair:
                        h, a = devig_two_way(pair['home'], pair['away'])
                        pinnacle_fair['MONEYLINE'] = {
                            'home': round(h * 100, 2),
                            'away': round(a * 100, 2),
                        }
                elif mt in ('SPREAD', 'ALT_SPREAD'):
                    if 'home' in pair and 'away' in pair:
                        h, a = devig_two_way(pair['home'], pair['away'])
                        key = f"{mt}_{abs(strike)}" if strike is not None else mt
                        pinnacle_fair[key] = {
                            'home': round(h * 100, 2),
                            'away': round(a * 100, 2),
                            'strike': abs(strike) if strike is not None else strike,
                        }
                elif mt in ('TOTAL', 'ALT_TOTAL', 'F5_TOTAL', 'F5_ALT_TOTAL'):
                    if 'over' in pair and 'under' in pair:
                        o, u = devig_two_way(pair['over'], pair['under'])
                        key = f"{mt}_{strike}" if strike else mt
                        pinnacle_fair[key] = {
                            'over': round(o * 100, 2),
                            'under': round(u * 100, 2),
                            'strike': strike,
                        }
                elif mt in ('F5_H2H', 'F5_MONEYLINE'):
                    if 'home' in pair and 'away' in pair:
                        if 'draw' in pair:
                            # 3-way: skip de-vig (can't easily de-vig 3-way)
                            # Just store raw implied probs
                            pinnacle_fair[mt] = {
                                'home': round(pair['home'], 2) if pair['home'] > 0 else round(pair['home'], 2),
                                'away': round(pair['away'], 2) if pair['away'] > 0 else round(pair['away'], 2),
                            }
                        else:
                            h, a = devig_two_way(pair['home'], pair['away'])
                            pinnacle_fair[mt] = {
                                'home': round(h * 100, 2),
                                'away': round(a * 100, 2),
                            }
                elif mt in ('F5_SPREAD', 'F5_ALT_SPREAD'):
                    if 'home' in pair and 'away' in pair:
                        h, a = devig_two_way(pair['home'], pair['away'])
                        key = f"{mt}_{abs(strike)}" if strike is not None else mt
                        pinnacle_fair[key] = {
                            'home': round(h * 100, 2),
                            'away': round(a * 100, 2),
                            'strike': abs(strike) if strike is not None else strike,
                        }
                elif mt in ('TEAM_TOTAL', 'ALT_TEAM_TOTAL'):
                    if 'over' in pair and 'under' in pair:
                        o, u = devig_two_way(pair['over'], pair['under'])
                        key = f"{mt}_{strike}" if strike else mt
                        pinnacle_fair[key] = {
                            'over': round(o * 100, 2),
                            'under': round(u * 100, 2),
                            'strike': strike,
                        }
            
            # De-vig Pinnacle props too
            prop_pairs = {}
            for prop in game_data['props'].values():
                pin_odds = prop['books'].get('PIN', {}).get('odds')
                if pin_odds is None:
                    continue
                player = prop.get('player_name', 'Unknown')
                mt = prop['market_type']
                strike = prop['strike_price']
                pk = f"{player}_{mt}_{strike}"
                if pk not in prop_pairs:
                    prop_pairs[pk] = {'market_type': mt, 'player_name': player, 'strike': strike}
                prop_pairs[pk][prop['outcome_side']] = pin_odds
            
            for pk, pair in prop_pairs.items():
                if 'over' in pair and 'under' in pair:
                    o, u = devig_two_way(pair['over'], pair['under'])
                    pinnacle_fair[pk] = {
                        'market_type': pair['market_type'],
                        'player_name': pair['player_name'],
                        'strike': pair['strike'],
                        'over': round(o * 100, 2),
                        'under': round(u * 100, 2),
                    }
            
            # Fallback: if Pinnacle fair is empty, de-vig from any available book
            if not pinnacle_fair:
                fallback_pairs = {}
                for mkt in game_data['main_markets'].values():
                    # Pick any book's odds
                    for book_key, book_data in mkt['books'].items():
                        odds_val = book_data.get('odds')
                        if odds_val is None:
                            continue
                        mt = mkt['market_type']
                        strike = mkt['strike_price']
                        if mt in SPREAD_TYPES and strike is not None:
                            pair_key = f"{mt}_{abs(strike)}"
                        elif strike is not None:
                            pair_key = f"{mt}_{strike}"
                        else:
                            pair_key = mt
                        if pair_key not in fallback_pairs:
                            fallback_pairs[pair_key] = {'market_type': mt, 'strike': strike, '_book': book_key}
                        fallback_pairs[pair_key][mkt['outcome_side']] = odds_val
                        break  # just need one book per side

                for pair_key, pair in fallback_pairs.items():
                    mt = pair['market_type']
                    strike = pair.get('strike')
                    book = pair.get('_book', '?')
                    if mt == 'MONEYLINE':
                        if 'home' in pair and 'away' in pair:
                            h, a = devig_two_way(pair['home'], pair['away'])
                            pinnacle_fair['MONEYLINE'] = {
                                'home': round(h * 100, 2),
                                'away': round(a * 100, 2),
                                '_source': book,
                            }
                    elif mt in ('SPREAD', 'ALT_SPREAD'):
                        if 'home' in pair and 'away' in pair:
                            h, a = devig_two_way(pair['home'], pair['away'])
                            key = f"{mt}_{abs(strike)}" if strike is not None else mt
                            pinnacle_fair[key] = {
                                'home': round(h * 100, 2),
                                'away': round(a * 100, 2),
                                'strike': abs(strike) if strike is not None else strike,
                                '_source': book,
                            }
                    elif mt in ('TOTAL', 'ALT_TOTAL'):
                        if 'over' in pair and 'under' in pair:
                            o, u = devig_two_way(pair['over'], pair['under'])
                            key = f"{mt}_{strike}" if strike else mt
                            pinnacle_fair[key] = {
                                'over': round(o * 100, 2),
                                'under': round(u * 100, 2),
                                'strike': strike,
                                '_source': book,
                            }

            game_data['pinnacle_fair'] = pinnacle_fair
        
        # Convert sets/dicts to lists for JSON serialization
        for gpk in games:
            games[gpk]['books'] = list(games[gpk]['books'])
            games[gpk]['main_markets'] = list(games[gpk]['main_markets'].values())
            games[gpk]['props'] = list(games[gpk]['props'].values())
        
        conn.close()
        
        return {
            "date": date,
            "games": games,
            "total_games": len(games)
        }
        
    except Exception as e:
        raise HTTPException(500, f"Error fetching odds for date: {e}")


@app.get("/api/odds/{game_pk}/history")
async def get_odds_history(game_pk: int, market_type: Optional[str] = None,
                           hours: int = 48):
    """
    Get odds movement history for a game.
    Used for EV tracking and progression charts.
    
    Args:
        game_pk: Game identifier
        market_type: Optional filter (MONEYLINE, SPREAD, TOTAL, etc.)
        hours: How many hours back to look (default 48)
    """
    import psycopg2
    from dotenv import load_dotenv
    
    try:
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        conn = _get_db_conn()
        cur = conn.cursor()
        
        query = """
            SELECT 
                sm.market_type, sm.outcome_side, sm.strike_price,
                sm.team_side, sm.player_name,
                sb.short_name as book,
                oh.american_odds, oh.decimal_odds, oh.implied_probability,
                oh.odds_movement, oh.is_steam_move,
                oh.recorded_at
            FROM sportsbook_odds_history oh
            JOIN sportsbook_markets sm ON oh.market_id = sm.market_id
            JOIN sportsbooks sb ON sm.sportsbook_id = sb.sportsbook_id
            WHERE sm.game_pk = %s
              AND oh.recorded_at > NOW() - INTERVAL '%s hours'
        """
        params = [game_pk, hours]
        
        if market_type:
            query += " AND sm.market_type = %s"
            params.append(market_type)
        
        query += " ORDER BY oh.recorded_at ASC"
        
        cur.execute(query, params)
        
        columns = [desc[0] for desc in cur.description]
        rows = []
        for row in cur.fetchall():
            d = dict(zip(columns, row))
            # Serialize
            if d.get('recorded_at'):
                d['recorded_at'] = d['recorded_at'].isoformat()
            if d.get('strike_price'):
                d['strike_price'] = float(d['strike_price'])
            if d.get('implied_probability'):
                d['implied_probability'] = float(d['implied_probability'])
            if d.get('decimal_odds'):
                d['decimal_odds'] = float(d['decimal_odds'])
            if d.get('odds_movement'):
                d['odds_movement'] = float(d['odds_movement'])
            rows.append(d)
        
        conn.close()
        
        return {
            "game_pk": game_pk,
            "history": rows,
            "total_snapshots": len(rows)
        }
        
    except Exception as e:
        raise HTTPException(500, f"Error fetching odds history: {e}")


@app.get("/api/odds/{game_pk}/pinnacle-fair")
async def get_pinnacle_fair(game_pk: int):
    """
    Get de-vigged Pinnacle fair odds for a game.
    This is the 'MKT FAIR' reference used by the predictions table.
    
    Returns Pinnacle odds de-vigged into fair probabilities for each market.
    """
    import psycopg2
    from dotenv import load_dotenv
    
    try:
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        conn = _get_db_conn()
        cur = conn.cursor()
        
        # Get Pinnacle sportsbook_id
        cur.execute("SELECT sportsbook_id FROM sportsbooks WHERE api_key_name = 'pinnacle'")
        pin_row = cur.fetchone()
        if not pin_row:
            conn.close()
            return {"game_pk": game_pk, "error": "Pinnacle not found in sportsbooks", "markets": {}}
        pinnacle_id = pin_row[0]
        
        # Get Pinnacle odds for this game
        cur.execute("""
            SELECT market_type, outcome_side, strike_price, american_odds, team_side, player_name
            FROM sportsbook_markets
            WHERE game_pk = %s AND sportsbook_id = %s AND is_available = TRUE
            ORDER BY market_type, outcome_side
        """, (game_pk, pinnacle_id))
        
        raw_odds = {}
        for row in cur.fetchall():
            mt, side, strike, odds, team_side, player = row
            strike_f = float(strike) if strike else None
            key = (mt, strike_f, player)
            if key not in raw_odds:
                raw_odds[key] = {}
            raw_odds[key][side] = odds
        
        # De-vig each two-way market
        fair_markets = {}
        for (mt, strike, player), sides in raw_odds.items():
            if mt == 'MONEYLINE':
                home_odds = sides.get('home')
                away_odds = sides.get('away')
                if home_odds and away_odds:
                    home_fair, away_fair = devig_two_way(home_odds, away_odds)
                    fair_markets['MONEYLINE'] = {
                        'home': {'raw_odds': home_odds, 'fair_prob': round(home_fair * 100, 2)},
                        'away': {'raw_odds': away_odds, 'fair_prob': round(away_fair * 100, 2)},
                    }
            elif mt == 'SPREAD':
                home_odds = sides.get('home')
                away_odds = sides.get('away')
                if home_odds and away_odds:
                    home_fair, away_fair = devig_two_way(home_odds, away_odds)
                    key_str = f"SPREAD_{strike}"
                    fair_markets[key_str] = {
                        'strike': strike,
                        'home': {'raw_odds': home_odds, 'fair_prob': round(home_fair * 100, 2)},
                        'away': {'raw_odds': away_odds, 'fair_prob': round(away_fair * 100, 2)},
                    }
            elif mt == 'TOTAL':
                over_odds = sides.get('over')
                under_odds = sides.get('under')
                if over_odds and under_odds:
                    over_fair, under_fair = devig_two_way(over_odds, under_odds)
                    key_str = f"TOTAL_{strike}"
                    fair_markets[key_str] = {
                        'strike': strike,
                        'over': {'raw_odds': over_odds, 'fair_prob': round(over_fair * 100, 2)},
                        'under': {'raw_odds': under_odds, 'fair_prob': round(under_fair * 100, 2)},
                    }
            else:
                # Props
                over_odds = sides.get('over')
                under_odds = sides.get('under')
                if over_odds and under_odds:
                    over_fair, under_fair = devig_two_way(over_odds, under_odds)
                    key_str = f"{mt}_{player}_{strike}"
                    fair_markets[key_str] = {
                        'market_type': mt,
                        'player_name': player,
                        'strike': strike,
                        'over': {'raw_odds': over_odds, 'fair_prob': round(over_fair * 100, 2)},
                        'under': {'raw_odds': under_odds, 'fair_prob': round(under_fair * 100, 2)},
                    }
        
        # Also get best available odds across all books
        cur.execute("""
            SELECT market_type, outcome_side, strike_price, 
                   MAX(american_odds) as best_odds,
                   sb.short_name as best_book
            FROM sportsbook_markets sm
            JOIN sportsbooks sb ON sm.sportsbook_id = sb.sportsbook_id
            WHERE sm.game_pk = %s AND sm.is_available = TRUE
            GROUP BY market_type, outcome_side, strike_price, sb.short_name
            ORDER BY market_type, outcome_side
        """, (game_pk,))
        
        # Best odds per market (highest american odds = best for bettor)
        best_odds = {}
        for row in cur.fetchall():
            mt, side, strike, odds, book = row
            strike_f = float(strike) if strike else None
            key = f"{mt}_{side}_{strike_f}"
            if key not in best_odds or odds > best_odds[key]['odds']:
                best_odds[key] = {'odds': odds, 'book': book}
        
        conn.close()
        
        return {
            "game_pk": game_pk,
            "fair_markets": fair_markets,
            "best_odds": best_odds
        }
        
    except Exception as e:
        raise HTTPException(500, f"Error fetching Pinnacle fair: {e}")


# ── Lineup fetch for today ────────────────────────────────────────────────

def _refresh_defaults_background(python_cmd: str, scripts_dir: Path):
    """Background task: refresh RotoWire default batting orders & depth charts.
    
    Runs AFTER the response is sent so the user doesn't wait.
    Updates the rotowire_default_lineups and rotowire_default_pitchers cache tables.
    """
    import subprocess as _sp
    
    try:
        # Depth charts (1 page, all teams — takes ~2s with optimized script)
        _sp.run(
            [python_cmd, str(scripts_dir / "fetch_rotowire_depth_charts.py")],
            capture_output=True, text=True, timeout=60
        )
        print("[BG] Depth charts refreshed")
    except Exception as e:
        print(f"[BG] Depth charts refresh failed: {e}")
    
    try:
        # Default batting orders (30 team pages — takes ~20s with 0.5s delay)
        _sp.run(
            [python_cmd, str(scripts_dir / "fetch_rotowire_batting_orders.py")],
            capture_output=True, text=True, timeout=120
        )
        print("[BG] Default batting orders refreshed")
    except Exception as e:
        print(f"[BG] Default batting orders refresh failed: {e}")


@app.post("/api/lineups/fetch-today")
async def fetch_lineups_today(
    date: Optional[str] = Query(None),
    background_tasks: BackgroundTasks = None,
):
    """
    Fetch pregame lineups — fast optimized strategy (~5-10s):
    
    Phase 1 (parallel — all run simultaneously):
      - RotoWire daily lineups (today's projected + confirmed)
      - MLB API official lineups
      - RotoWire injury report
    
    Phase 2 (instant SQL gap-fill — uses cached defaults already in DB):
      - INSERT...SELECT from rotowire_default_lineups for teams missing lineups
      - INSERT...SELECT from rotowire_default_pitchers for teams missing pitchers
      - No HTTP requests — pure DB operations (~50ms)
    
    Background (after response sent):
      - Refresh default batting orders cache (30 team pages)
      - Refresh depth charts cache (1 page)
    
    Args:
        date: Date to fetch lineups for (YYYY-MM-DD). Defaults to today.
    
    Returns summary of sources and coverage.
    """
    import asyncio
    import time as _time
    
    t_start = _time.monotonic()
    target_date = date or datetime.now().strftime('%Y-%m-%d')
    scripts_dir = PROJECT_ROOT / "scripts" / "data_collection"
    
    results = {
        "date": target_date,
        "sources": {},
        "total_games": 0,
        "games_with_lineups": 0,
    }
    
    # Use venv Python if available, otherwise use sys.executable
    venv_python = PROJECT_ROOT / ".venv" / "bin" / "python3"
    python_cmd = str(venv_python) if venv_python.exists() else sys.executable
    
    # ── Helper: run a subprocess asynchronously ──────────────────────────
    async def run_script(cmd: list, timeout: int = 60) -> tuple:
        """Run a script asynchronously, return (stdout+stderr, returncode)."""
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            try:
                stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
                output = (stdout or b"").decode() + (stderr or b"").decode()
                return output, proc.returncode
            except asyncio.TimeoutError:
                proc.kill()
                await proc.communicate()
                return "", -1  # -1 = timeout
        except Exception as e:
            return f"Error: {e}", -2  # -2 = launch failure
    
    try:
        # ══════════════════════════════════════════════════════════════════
        # PHASE 1: Parallel — fetch from all live sources simultaneously
        # ══════════════════════════════════════════════════════════════════
        
        rw_lineups_cmd = [
            python_cmd,
            str(scripts_dir / "fetch_rotowire_lineups.py"),
            "--date", target_date,
        ]
        mlb_cmd = [
            python_cmd,
            str(scripts_dir / "fetch_pregame_lineups.py"),
            "--date", target_date,
        ]
        injury_cmd = [
            python_cmd,
            str(scripts_dir / "fetch_rotowire_injuries.py"),
        ]
        
        # Run all 3 in parallel (depth charts moved to background)
        print(f"[LINEUPS] Phase 1: launching 3 parallel scripts for {target_date}...")
        
        async def timed_run(name, cmd, timeout):
            t0 = _time.monotonic()
            output, rc = await run_script(cmd, timeout)
            elapsed = round(_time.monotonic() - t0, 1)
            print(f"[LINEUPS]   {name} finished in {elapsed}s (rc={rc})")
            return output, rc
        
        (rw_output, rw_rc), (mlb_output, mlb_rc), (inj_output, inj_rc) = \
            await asyncio.gather(
                timed_run("RotoWire lineups", rw_lineups_cmd, timeout=180),
                timed_run("MLB API", mlb_cmd, timeout=60),
                timed_run("Injuries", injury_cmd, timeout=30),
            )
        
        t_phase1 = round(_time.monotonic() - t_start, 1)
        print(f"[LINEUPS] Phase 1 done in {t_phase1}s (rw={rw_rc}, mlb={mlb_rc}, inj={inj_rc})")
        
        # ── Parse RotoWire daily lineups result ──────────────────────────
        if rw_rc == -1:
            results["sources"]["rotowire_lineups"] = {"status": "timeout"}
        elif rw_rc == -2:
            results["sources"]["rotowire_lineups"] = {"status": "error", "message": rw_output[:200]}
        else:
            if rw_rc != 0:
                print(f"[WARN] RotoWire lineups error (code {rw_rc}):")
                print(rw_output[-500:])
            
            rw_confirmed = rw_output.lower().count('[confirmed]')
            rw_projected = rw_output.lower().count('[projected]')
            rw_partial = rw_output.lower().count('[partial')
            rw_total = rw_confirmed + rw_projected
            
            results["sources"]["rotowire_lineups"] = {
                "status": "success" if rw_rc == 0 else "partial",
                "confirmed": rw_confirmed,
                "projected": rw_projected,
                "partial": rw_partial,
                "total": rw_total,
            }
        
        # ── Parse MLB API result ─────────────────────────────────────────
        if mlb_rc == -1:
            results["sources"]["mlb_api"] = {"status": "timeout"}
        elif mlb_rc == -2:
            results["sources"]["mlb_api"] = {"status": "error", "message": mlb_output[:200]}
        else:
            if mlb_rc != 0:
                print(f"[WARN] MLB API error (code {mlb_rc}):")
                print(mlb_output[-500:])
            
            total_games = 0
            mlb_lineups_found = 0
            for line in mlb_output.split('\n'):
                if 'games for' in line.lower():
                    parts = line.split()
                    for i, p in enumerate(parts):
                        if p.lower() == 'found' and i + 1 < len(parts):
                            try:
                                total_games = int(parts[i + 1])
                            except ValueError:
                                pass
                if 'saving away lineup' in line.lower() or 'saving home lineup' in line.lower():
                    mlb_lineups_found += 1
            
            games_with_mlb = mlb_lineups_found // 2
            results["total_games"] = total_games
            
            results["sources"]["mlb_api"] = {
                "status": "success" if mlb_rc == 0 else "partial",
                "games_with_lineups": games_with_mlb,
                "total_games": total_games,
            }
        
        # ── Parse injuries result ────────────────────────────────────────
        if inj_rc == -1:
            results["sources"]["rotowire_injuries"] = {"status": "timeout"}
        elif inj_rc == -2:
            results["sources"]["rotowire_injuries"] = {"status": "error", "message": inj_output[:200]}
        else:
            saved_count = 0
            for line in inj_output.split('\n'):
                if 'saved to db:' in line.lower():
                    match_obj = re.search(r'Saved to DB:\s*(\d+)', line, re.IGNORECASE)
                    if match_obj:
                        saved_count = int(match_obj.group(1))
            
            results["sources"]["rotowire_injuries"] = {
                "status": "success" if inj_rc == 0 else "partial",
                "injuries_saved": saved_count,
            }
        
        # ══════════════════════════════════════════════════════════════════
        # PHASE 2: Instant SQL gap-fill from cached defaults in DB
        # No HTTP requests — just INSERT...SELECT from rotowire_default_*
        # ══════════════════════════════════════════════════════════════════
        t_phase2_start = _time.monotonic()
        
        try:
            import psycopg2 as pg2
            load_dotenv(PROJECT_ROOT / ".env")
            database_url = os.getenv('DATABASE_URL')
            conn = _get_db_conn()
            cur = conn.cursor()
            
            # Fill missing batting lineups from cached defaults (vs_rhp preferred)
            cur.execute("""
                INSERT INTO pregame_lineups 
                    (game_pk, team_id, batting_order, player_id, position, source, lineup_status)
                SELECT 
                    g.game_pk,
                    rdl.team_id,
                    rdl.batting_order,
                    rdl.player_id,
                    rdl.position,
                    'rotowire_default',
                    'projected'
                FROM games g
                JOIN rotowire_default_lineups rdl 
                    ON rdl.team_id IN (g.away_team_id, g.home_team_id)
                WHERE g.game_date = %s
                  AND rdl.lineup_type = 'vs_rhp'
                  AND NOT EXISTS (
                    SELECT 1 FROM pregame_lineups pl 
                    WHERE pl.game_pk = g.game_pk 
                      AND pl.team_id = rdl.team_id
                  )
                ON CONFLICT (game_pk, team_id, batting_order) DO NOTHING
            """, (target_date,))
            lineups_filled = cur.rowcount
            
            # Fill missing pitchers from cached depth charts
            cur.execute("""
                INSERT INTO pregame_pitchers 
                    (game_pk, team_id, player_id, source, lineup_status)
                SELECT 
                    g.game_pk,
                    rdp.team_id,
                    rdp.player_id,
                    'rotowire_default',
                    'projected'
                FROM games g
                JOIN rotowire_default_pitchers rdp 
                    ON rdp.team_id IN (g.away_team_id, g.home_team_id)
                WHERE g.game_date = %s
                  AND rdp.rotation_spot = 1
                  AND NOT EXISTS (
                    SELECT 1 FROM pregame_pitchers pp 
                    WHERE pp.game_pk = g.game_pk 
                      AND pp.team_id = rdp.team_id
                  )
                ON CONFLICT (game_pk, team_id) DO NOTHING
            """, (target_date,))
            pitchers_filled = cur.rowcount
            
            conn.commit()
            
            # Check if defaults cache is stale (> 18 hours old)
            cur.execute("""
                SELECT MAX(updated_at) FROM rotowire_default_lineups
            """)
            last_update = cur.fetchone()[0]
            defaults_stale = True
            if last_update:
                from datetime import timezone
                age_hours = (datetime.now(timezone.utc) - last_update).total_seconds() / 3600
                defaults_stale = age_hours > 18
            
            t_phase2 = round(_time.monotonic() - t_phase2_start, 2)
            print(f"[LINEUPS] Phase 2 gap-fill done in {t_phase2}s (lineups={lineups_filled}, pitchers={pitchers_filled})")
            
            results["sources"]["defaults_gap_fill"] = {
                "status": "success",
                "lineups_filled": lineups_filled,
                "pitchers_filled": pitchers_filled,
                "defaults_cache_stale": defaults_stale,
            }
            
            # ── Count final lineup coverage ──────────────────────────────
            cur.execute("""
                SELECT COUNT(DISTINCT g.game_pk)
                FROM games g
                WHERE g.game_date = %s
            """, (target_date,))
            total = cur.fetchone()[0]
            
            cur.execute("""
                SELECT COUNT(DISTINCT game_pk) FROM (
                    SELECT pl.game_pk FROM pregame_lineups pl
                    JOIN games g ON pl.game_pk = g.game_pk
                    WHERE g.game_date = %s
                    UNION
                    SELECT pp.game_pk FROM pregame_pitchers pp
                    JOIN games g ON pp.game_pk = g.game_pk
                    WHERE g.game_date = %s
                ) combined
            """, (target_date, target_date))
            with_lineups = cur.fetchone()[0]
            
            results["total_games"] = total
            results["games_with_lineups"] = with_lineups
            
            conn.close()
        except Exception as e:
            print(f"[WARN] Gap-fill from defaults failed: {e}")
            results["sources"]["defaults_gap_fill"] = {
                "status": "error", 
                "message": str(e),
            }
            defaults_stale = True
        
        # ══════════════════════════════════════════════════════════════════
        # BACKGROUND: Schedule defaults cache refresh (runs after response)
        # Only if the cache is stale (> 18h old) — otherwise skip
        # ══════════════════════════════════════════════════════════════════
        if background_tasks and defaults_stale:
            background_tasks.add_task(
                _refresh_defaults_background, python_cmd, scripts_dir
            )
            results["sources"]["defaults_refresh"] = {"status": "scheduled_background"}
        
        # Build message
        total = results["total_games"]
        covered = results["games_with_lineups"]
        elapsed = round(_time.monotonic() - t_start, 1)
        
        if covered == 0 and total == 0:
            results["status"] = "success"
            results["message"] = f"NO GAMES TODAY ({elapsed}s)"
        elif covered >= total and total > 0:
            results["status"] = "success"
            results["message"] = f"LINEUPS LOADED — {covered}/{total} GAMES ({elapsed}s)"
        elif covered > 0:
            results["status"] = "partial"
            results["message"] = f"LINEUPS — {covered}/{total} GAMES ({elapsed}s)"
        else:
            results["status"] = "partial"
            results["message"] = f"LINEUPS — 0/{total} GAMES ({elapsed}s)"
        
        print(f"[LINEUPS] Total: {elapsed}s — {covered}/{total} games covered")
        results["elapsed_seconds"] = elapsed
        results["phase1_seconds"] = t_phase1
        return results
        
    except Exception as e:
        raise HTTPException(500, f"Lineup fetch failed: {e}")


# ── Injuries endpoint ────────────────────────────────────────────────────

@app.get("/api/injuries")
async def get_injuries(team_abbr: Optional[str] = None):
    """Get current injury report from player_injuries table."""
    import psycopg2 as pg2
    
    try:
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        conn = _get_db_conn()
        cur = conn.cursor()
        
        if team_abbr:
            team_id_val = TEAM_ABBR_TO_MLB_ID.get(team_abbr.upper())
            if not team_id_val:
                conn.close()
                raise HTTPException(404, f"Unknown team: {team_abbr}")
            
            cur.execute("""
                SELECT pi.player_id, p.full_name, pi.injury_status, 
                       pi.injury_description, pi.expected_return, pi.updated_at,
                       t.abbreviation
                FROM player_injuries pi
                JOIN players p ON pi.player_id = p.player_id
                LEFT JOIN teams t ON pi.team_id = t.team_id
                WHERE pi.team_id = %s
                ORDER BY pi.injury_status, p.full_name
            """, (team_id_val,))
        else:
            cur.execute("""
                SELECT pi.player_id, p.full_name, pi.injury_status,
                       pi.injury_description, pi.expected_return, pi.updated_at,
                       t.abbreviation
                FROM player_injuries pi
                JOIN players p ON pi.player_id = p.player_id
                LEFT JOIN teams t ON pi.team_id = t.team_id
                ORDER BY t.abbreviation, pi.injury_status, p.full_name
            """)
        
        rows = cur.fetchall()
        conn.close()
        
        injuries = []
        for row in rows:
            injuries.append({
                "player_id": row[0],
                "player_name": row[1],
                "status": row[2],
                "description": row[3],
                "expected_return": row[4],
                "updated_at": str(row[5]) if row[5] else None,
                "team": row[6],
            })
        
        return {"injuries": injuries, "count": len(injuries)}
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Error fetching injuries: {e}")


@app.get("/api/ev/{game_pk}")
async def get_ev_progression(game_pk: int, market_type: Optional[str] = None):
    """
    Get EV progression data for a specific game.
    Shows how our MCMC edge vs sportsbook odds evolved over time.
    
    Returns time-series data: edge, EV, odds, MCMC prob at each snapshot.
    """
    import psycopg2
    from dotenv import load_dotenv
    
    try:
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        conn = _get_db_conn()
        cur = conn.cursor()
        
        query = """
            SELECT ev.market_type, ev.outcome_side, ev.strike_price,
                   ev.player_name, ev.mcmc_probability, ev.diamond_fair_probability,
                   ev.american_odds, ev.implied_probability, ev.no_vig_probability,
                   ev.edge, ev.expected_value, ev.hours_to_game,
                   ev.recorded_at, ev.actual_result,
                   sb.short_name as book
            FROM ev_tracking ev
            JOIN sportsbooks sb ON ev.sportsbook_id = sb.sportsbook_id
            WHERE ev.game_pk = %s
        """
        params = [game_pk]
        
        if market_type:
            query += " AND ev.market_type = %s"
            params.append(market_type)
        
        query += " ORDER BY ev.market_type, ev.outcome_side, ev.strike_price, ev.recorded_at"
        
        cur.execute(query, params)
        columns = [desc[0] for desc in cur.description]
        rows = [dict(zip(columns, row)) for row in cur.fetchall()]
        
        # Group by market line for easy charting
        from collections import defaultdict
        grouped = defaultdict(list)
        for row in rows:
            mt = row['market_type']
            side = row['outcome_side']
            strike = row['strike_price']
            player = row['player_name']
            key = f"{mt}_{side}"
            if strike is not None:
                key += f"_{strike}"
            if player:
                key += f"_{player}"
            
            grouped[key].append({
                'recorded_at': row['recorded_at'].isoformat() if row['recorded_at'] else None,
                'hours_to_game': float(row['hours_to_game']) if row['hours_to_game'] else None,
                'mcmc_prob': float(row['mcmc_probability']) if row['mcmc_probability'] else None,
                'diamond_fair_prob': float(row['diamond_fair_probability']) if row['diamond_fair_probability'] else None,
                'american_odds': row['american_odds'],
                'implied_prob': float(row['implied_probability']) if row['implied_probability'] else None,
                'no_vig_prob': float(row['no_vig_probability']) if row['no_vig_probability'] else None,
                'edge': float(row['edge']) if row['edge'] else None,
                'ev': float(row['expected_value']) if row['expected_value'] else None,
                'book': row['book'],
                'result': row['actual_result'],
            })
        
        conn.close()
        
        return {
            "game_pk": game_pk,
            "markets": dict(grouped),
            "total_snapshots": len(rows)
        }
        
    except Exception as e:
        raise HTTPException(500, f"Error fetching EV progression: {e}")


@app.get("/api/ev/summary/{date}")
async def get_ev_summary(date: str, min_edge: float = 0.03):
    """
    Get a summary of all +EV opportunities for a given date.
    Useful for a dashboard showing where we have edge.
    """
    import psycopg2
    from dotenv import load_dotenv
    
    try:
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        conn = _get_db_conn()
        cur = conn.cursor()
        
        # Get game_pks for this date (include Spring Training + Exhibition)
        cur.execute("SELECT game_pk FROM games WHERE game_date = %s AND game_type IN ('R', 'S', 'E')", (date,))
        game_pks = [row[0] for row in cur.fetchall()]
        
        if not game_pks:
            conn.close()
            return {"date": date, "opportunities": [], "total": 0}
        
        # Get the LATEST EV snapshot per market line per game (most recent recorded_at)
        cur.execute("""
            SELECT DISTINCT ON (ev.game_pk, ev.market_type, ev.outcome_side, ev.strike_price, ev.player_name)
                   ev.game_pk, ev.market_type, ev.outcome_side, ev.strike_price,
                   ev.player_name, ev.mcmc_probability,
                   ev.american_odds, ev.implied_probability,
                   ev.edge, ev.expected_value, ev.hours_to_game,
                   ev.recorded_at, sb.short_name as book
            FROM ev_tracking ev
            JOIN sportsbooks sb ON ev.sportsbook_id = sb.sportsbook_id
            WHERE ev.game_pk = ANY(%s)
              AND ev.edge >= %s
            ORDER BY ev.game_pk, ev.market_type, ev.outcome_side, ev.strike_price, ev.player_name,
                     ev.recorded_at DESC
        """, (game_pks, min_edge))
        
        columns = [desc[0] for desc in cur.description]
        rows = [dict(zip(columns, row)) for row in cur.fetchall()]
        
        opportunities = []
        for row in rows:
            opportunities.append({
                'game_pk': row['game_pk'],
                'market_type': row['market_type'],
                'outcome_side': row['outcome_side'],
                'strike_price': float(row['strike_price']) if row['strike_price'] else None,
                'player_name': row['player_name'],
                'mcmc_prob': float(row['mcmc_probability']) if row['mcmc_probability'] else None,
                'american_odds': row['american_odds'],
                'implied_prob': float(row['implied_probability']) if row['implied_probability'] else None,
                'edge': float(row['edge']) if row['edge'] else None,
                'ev': float(row['expected_value']) if row['expected_value'] else None,
                'hours_to_game': float(row['hours_to_game']) if row['hours_to_game'] else None,
                'book': row['book'],
                'recorded_at': row['recorded_at'].isoformat() if row['recorded_at'] else None,
            })
        
        # Sort by edge descending
        opportunities.sort(key=lambda x: x.get('edge', 0) or 0, reverse=True)
        
        conn.close()
        
        return {
            "date": date,
            "opportunities": opportunities,
            "total": len(opportunities),
            "min_edge_filter": min_edge,
        }
        
    except Exception as e:
        raise HTTPException(500, f"Error fetching EV summary: {e}")


@app.post("/api/games/backfill-scores")
async def backfill_game_scores(game_pk: Optional[int] = None):
    """
    Backfill missing game scores from the plays table
    
    Args:
        game_pk: Specific game to backfill (if None, backfills all games missing scores)
        
    Returns:
        Number of games updated
    """
    import psycopg2
    from dotenv import load_dotenv
    
    try:
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        conn = _get_db_conn()
        cur = conn.cursor()
        
        if game_pk:
            # Get final scores from plays - use the maximum result_home_runs and result_away_runs
            # These should be the final scores if the game has play-by-play data
            # First check if plays exist
            cur.execute("SELECT COUNT(*) FROM plays WHERE game_pk = %s", (game_pk,))
            total_plays = cur.fetchone()[0]
            
            if total_plays == 0:
                conn.close()
                return {
                    'updated': 0,
                    'message': f'Game {game_pk} has no plays data',
                    'has_plays': False,
                    'found_scores': False
                }
            
            # Try to get scores from result columns
            cur.execute("""
                SELECT 
                    MAX(p.result_home_runs) as max_home_runs,
                    MAX(p.result_away_runs) as max_away_runs
                FROM plays p
                WHERE p.game_pk = %s
                  AND p.result_home_runs IS NOT NULL
                  AND p.result_away_runs IS NOT NULL
            """, (game_pk,))
            
            play_data = cur.fetchone()
            max_home_runs, max_away_runs = play_data
            
            # If result columns don't have data, try using the last play's pre scores + calculating runs
            if max_home_runs is None or max_away_runs is None:
                # Get the last play to see final state
                cur.execute("""
                    SELECT 
                        result_home_runs,
                        result_away_runs,
                        pre_home_runs,
                        pre_away_runs,
                        event_index
                    FROM plays
                    WHERE game_pk = %s
                    ORDER BY event_index DESC
                    LIMIT 1
                """, (game_pk,))
                last_play = cur.fetchone()
                
                if last_play:
                    # Use result scores if available, otherwise use pre scores from last play
                    # But we need to check if runs were scored in the last play itself
                    result_home = last_play[0]
                    result_away = last_play[1]
                    pre_home = last_play[2]
                    pre_away = last_play[3]
                    
                    # If result scores exist, use those (they're the scores AFTER the play)
                    # Otherwise, use pre scores (scores BEFORE the play) - but we need to check
                    # if the last play scored runs
                    if result_home is not None and result_away is not None:
                        max_home_runs = result_home
                        max_away_runs = result_away
                    elif pre_home is not None and pre_away is not None:
                        # Use pre scores - these are the scores at the start of the last play
                        # We'd need to check the result_event to see if runs scored, but
                        # for now, use pre scores as they should be close to final
                        max_home_runs = pre_home
                        max_away_runs = pre_away
            
            # Only update if we found valid scores
            if max_home_runs is not None and max_away_runs is not None:
                # Force update (don't use COALESCE to preserve existing scores)
                cur.execute("""
                    UPDATE games
                    SET 
                        home_score = %s,
                        away_score = %s
                    WHERE game_pk = %s
                      AND (home_score IS NULL OR away_score IS NULL)
                """, (int(max_home_runs), int(max_away_runs), game_pk))
                updated = cur.rowcount
                conn.commit()
                conn.close()
                return {
                    'updated': updated,
                    'message': f'Backfilled scores for game {game_pk}: Away {int(max_away_runs)} - Home {int(max_home_runs)}',
                    'home_score': int(max_home_runs),
                    'away_score': int(max_away_runs)
                }
            else:
                conn.close()
                return {
                    'updated': 0,
                    'message': f'Game {game_pk} has {total_plays} plays but could not determine final scores',
                    'has_plays': total_plays > 0,
                    'found_scores': False
                }
        else:
            # Backfill all games missing scores
            cur.execute("""
                UPDATE games g
                SET 
                    home_score = COALESCE(g.home_score, (
                        SELECT MAX(p.result_home_runs)
                        FROM plays p
                        WHERE p.game_pk = g.game_pk
                          AND p.result_home_runs IS NOT NULL
                    )),
                    away_score = COALESCE(g.away_score, (
                        SELECT MAX(p.result_away_runs)
                        FROM plays p
                        WHERE p.game_pk = g.game_pk
                          AND p.result_away_runs IS NOT NULL
                    ))
                WHERE g.game_date < CURRENT_DATE
                  AND (g.home_score IS NULL OR g.away_score IS NULL)
                  AND EXISTS (
                      SELECT 1 FROM plays p WHERE p.game_pk = g.game_pk
                  )
            """)
        
        updated = cur.rowcount
        conn.commit()
        conn.close()
        
        return {
            'updated': updated,
            'message': f'Backfilled scores for {updated} game(s)'
        }
        
    except Exception as e:
        raise HTTPException(500, f"Error backfilling scores: {e}")

@app.get("/api/games/{game_pk}/score-diagnosis")
async def diagnose_game_score(game_pk: int):
    """
    Diagnose why a game might be missing scores
    
    Args:
        game_pk: Game primary key
        
    Returns:
        Diagnostic information about the game's score data
    """
    import psycopg2
    from dotenv import load_dotenv
    
    try:
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        conn = _get_db_conn()
        cur = conn.cursor()
        
        # Get game info
        cur.execute("""
            SELECT game_pk, game_date, status_detailed, home_score, away_score
            FROM games
            WHERE game_pk = %s
        """, (game_pk,))
        game_info = cur.fetchone()
        
        if not game_info:
            conn.close()
            return {'error': f'Game {game_pk} not found'}
        
        # Check plays data
        cur.execute("""
            SELECT 
                COUNT(*) as total_plays,
                COUNT(*) FILTER (WHERE result_home_runs IS NOT NULL) as plays_with_home_runs,
                COUNT(*) FILTER (WHERE result_away_runs IS NOT NULL) as plays_with_away_runs,
                MAX(result_home_runs) as max_result_home_runs,
                MAX(result_away_runs) as max_result_away_runs,
                MAX(pre_home_runs) as max_pre_home_runs,
                MAX(pre_away_runs) as max_pre_away_runs
            FROM plays
            WHERE game_pk = %s
        """, (game_pk,))
        
        plays_info = cur.fetchone()
        
        # Get last play details
        cur.execute("""
            SELECT 
                event_index,
                result_home_runs,
                result_away_runs,
                pre_home_runs,
                pre_away_runs,
                result_event
            FROM plays
            WHERE game_pk = %s
            ORDER BY event_index DESC
            LIMIT 1
        """, (game_pk,))
        
        last_play = cur.fetchone()
        
        conn.close()
        
        return {
            'game_pk': game_pk,
            'game_date': str(game_info[1]),
            'status': game_info[2],
            'current_home_score': game_info[3],
            'current_away_score': game_info[4],
            'plays': {
                'total': plays_info[0] if plays_info else 0,
                'with_home_runs': plays_info[1] if plays_info else 0,
                'with_away_runs': plays_info[2] if plays_info else 0,
                'max_result_home_runs': plays_info[3] if plays_info else None,
                'max_result_away_runs': plays_info[4] if plays_info else None,
                'max_pre_home_runs': plays_info[5] if plays_info else None,
                'max_pre_away_runs': plays_info[6] if plays_info else None,
            },
            'last_play': {
                'event_index': last_play[0] if last_play else None,
                'result_home_runs': last_play[1] if last_play else None,
                'result_away_runs': last_play[2] if last_play else None,
                'pre_home_runs': last_play[3] if last_play else None,
                'pre_away_runs': last_play[4] if last_play else None,
                'result_event': last_play[5] if last_play else None,
            }
        }
        
    except Exception as e:
        raise HTTPException(500, f"Error diagnosing game score: {e}")

@app.get("/api/games/missing-scores")
async def get_games_missing_scores(days_back: int = 30):
    """
    Check for past games that are missing scores
    
    Args:
        days_back: How many days back to check (default 30)
        
    Returns:
        List of games missing scores
    """
    import psycopg2
    from dotenv import load_dotenv
    from datetime import datetime, timedelta
    
    try:
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        conn = _get_db_conn()
        cur = conn.cursor()
        
        cutoff_date = (datetime.now() - timedelta(days=days_back)).strftime('%Y-%m-%d')
        
        cur.execute("""
            SELECT 
                g.game_pk,
                g.game_date,
                g.game_type,
                g.status_detailed,
                g.home_team_id,
                g.away_team_id,
                t1.abbreviation as away_abbr,
                t2.abbreviation as home_abbr,
                g.home_score,
                g.away_score
            FROM games g
            LEFT JOIN teams t1 ON g.away_team_id = t1.team_id
            LEFT JOIN teams t2 ON g.home_team_id = t2.team_id
            WHERE g.game_date < CURRENT_DATE
              AND g.game_date >= %s
              AND (g.home_score IS NULL OR g.away_score IS NULL)
            ORDER BY g.game_date DESC
            LIMIT 100
        """, (cutoff_date,))
        
        games = []
        for row in cur.fetchall():
            games.append({
                'game_pk': row[0],
                'game_date': str(row[1]),
                'game_type': row[2],
                'status': row[3],
                'home_team_id': row[4],
                'away_team_id': row[5],
                'away_team': row[6],
                'home_team': row[7],
                'home_score': row[8],
                'away_score': row[9]
            })
        
        conn.close()
        
        return {
            'days_back': days_back,
            'cutoff_date': cutoff_date,
            'count': len(games),
            'games': games
        }
        
    except Exception as e:
        raise HTTPException(500, f"Error checking for missing scores: {e}")

@app.get("/api/games/{game_pk}/top-players-diagnosis")
async def diagnose_top_players(game_pk: int):
    """
    Diagnose why top players might not be showing up for a game
    
    Args:
        game_pk: Game primary key
        
    Returns:
        Diagnostic information about player data availability
    """
    import psycopg2
    from dotenv import load_dotenv
    
    try:
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        conn = _get_db_conn()
        cur = conn.cursor()
        
        # Get game info
        cur.execute("""
            SELECT game_date, home_team_id, away_team_id, season
            FROM games
            WHERE game_pk = %s
        """, (game_pk,))
        
        game_row = cur.fetchone()
        if not game_row:
            conn.close()
            return {'error': f'Game {game_pk} not found'}
        
        game_date, home_team_id, away_team_id, season = game_row
        
        # Check if player_hier_game has data for this game
        cur.execute("""
            SELECT 
                COUNT(*) as total_players,
                COUNT(*) FILTER (WHERE player_type = 'batter') as batters,
                COUNT(*) FILTER (WHERE player_type = 'pitcher') as pitchers
            FROM player_hier_game
            WHERE game_pk = %s
        """, (game_pk,))
        
        hier_game_data = cur.fetchone()
        
        # Check player_team_history for teams
        cur.execute("""
            SELECT COUNT(DISTINCT player_id)
            FROM player_team_history
            WHERE team_id IN (%s, %s)
              AND season = %s
              AND start_date <= %s
              AND (end_date IS NULL OR end_date >= %s)
        """, (away_team_id, home_team_id, season, game_date, game_date))
        
        team_history_count = cur.fetchone()[0]
        
        # Check if we can find players with the join
        cur.execute("""
            SELECT COUNT(*)
            FROM player_hier_game phg
            JOIN player_team_history pth 
                ON phg.player_id = pth.player_id 
                AND pth.team_id = %s
                AND pth.season = %s
                AND pth.start_date <= %s
                AND (pth.end_date IS NULL OR pth.end_date >= %s)
            WHERE phg.game_pk = %s
              AND phg.player_type = 'batter'
              AND phg.hier_ops IS NOT NULL
        """, (away_team_id, season, game_date, game_date, game_pk))
        
        away_batters_found = cur.fetchone()[0]
        
        cur.execute("""
            SELECT COUNT(*)
            FROM player_hier_game phg
            JOIN player_team_history pth 
                ON phg.player_id = pth.player_id 
                AND pth.team_id = %s
                AND pth.season = %s
                AND pth.start_date <= %s
                AND (pth.end_date IS NULL OR pth.end_date >= %s)
            WHERE phg.game_pk = %s
              AND phg.player_type = 'pitcher'
              AND phg.hier_era IS NOT NULL
        """, (away_team_id, season, game_date, game_date, game_pk))
        
        away_pitchers_found = cur.fetchone()[0]
        
        conn.close()
        
        return {
            'game_pk': game_pk,
            'game_date': str(game_date),
            'season': season,
            'home_team_id': home_team_id,
            'away_team_id': away_team_id,
            'player_hier_game': {
                'total_players': hier_game_data[0] if hier_game_data else 0,
                'batters': hier_game_data[1] if hier_game_data else 0,
                'pitchers': hier_game_data[2] if hier_game_data else 0,
            },
            'player_team_history': {
                'players_on_teams': team_history_count
            },
            'away_team_matches': {
                'batters': away_batters_found,
                'pitchers': away_pitchers_found
            }
        }
        
    except Exception as e:
        import traceback
        return {
            'error': str(e),
            'traceback': traceback.format_exc()
        }

@app.post("/api/games/top-players-batch")
async def get_top_players_batch(request: TopPlayersBatchRequest):
    """
    Get top players for multiple games at once (batch endpoint for performance)
    
    Args:
        game_pks: List of game primary keys
        
    Returns:
        Dict mapping game_pk to top players data
    """
    import psycopg2
    from dotenv import load_dotenv
    
    game_pks = request.game_pks
    
    if not game_pks:
        return {}
    
    try:
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        conn = _get_db_conn()
        cur = conn.cursor()
        
        # Get all game info at once
        cur.execute("""
            SELECT game_pk, game_date, home_team_id, away_team_id, season
            FROM games
            WHERE game_pk = ANY(%s)
        """, (game_pks,))
        
        games_info = {row[0]: row[1:] for row in cur.fetchall()}
        
        result = {}
        
        # Process each game
        for game_pk in game_pks:
            if game_pk not in games_info:
                result[game_pk] = {
                    'game_pk': game_pk,
                    'away_team': {'top_hitter': None, 'top_pitcher': None},
                    'home_team': {'top_hitter': None, 'top_pitcher': None}
                }
                continue
            
            game_date, home_team_id, away_team_id, season = games_info[game_pk]
            
            # Check if player_hier_game has data
            cur.execute("SELECT COUNT(*) FROM player_hier_game WHERE game_pk = %s", (game_pk,))
            has_hier_game_data = cur.fetchone()[0] > 0
            
            # Get top players for away team
            if has_hier_game_data:
                # Away hitter
                cur.execute("""
                    SELECT 
                        phg.player_id,
                        pl.full_name,
                        pl.primary_position_code,
                        phg.hier_ops,
                        phg.hier_avg,
                        phg.hier_obp,
                        phg.hier_slg
                    FROM player_hier_game phg
                    JOIN players pl ON phg.player_id = pl.player_id
                    JOIN game_rosters gr 
                        ON phg.player_id = gr.player_id 
                        AND gr.game_pk = %s
                        AND gr.team_id = %s
                    WHERE phg.game_pk = %s
                      AND phg.player_type = 'batter'
                      AND phg.hier_ops IS NOT NULL
                    ORDER BY phg.hier_ops DESC
                    LIMIT 1
                """, (game_pk, away_team_id, game_pk))
                
                hitter_row = cur.fetchone()
                away_top_hitter = None
                if hitter_row:
                    away_top_hitter = {
                        'player_id': hitter_row[0],
                        'name': hitter_row[1],
                        'position_code': hitter_row[2],
                        'hier_ops': float(hitter_row[3]) if hitter_row[3] else None,
                        'hier_avg': float(hitter_row[4]) if hitter_row[4] else None,
                        'hier_score': float(hitter_row[3]) * 100 if hitter_row[3] else None
                    }
                
                # Away pitcher
                cur.execute("""
                    SELECT 
                        phg.player_id,
                        pl.full_name,
                        pl.primary_position_code,
                        phg.hier_era,
                        phg.hier_whip,
                        phg.hier_k_per_9,
                        phg.hier_bb_per_9
                    FROM player_hier_game phg
                    JOIN players pl ON phg.player_id = pl.player_id
                    JOIN game_rosters gr 
                        ON phg.player_id = gr.player_id 
                        AND gr.game_pk = %s
                        AND gr.team_id = %s
                    WHERE phg.game_pk = %s
                      AND phg.player_type = 'pitcher'
                      AND phg.hier_era IS NOT NULL
                    ORDER BY phg.hier_era ASC
                    LIMIT 1
                """, (game_pk, away_team_id, game_pk))
                
                pitcher_row = cur.fetchone()
                away_top_pitcher = None
                if pitcher_row:
                    era = float(pitcher_row[3]) if pitcher_row[3] else None
                    whip = float(pitcher_row[4]) if pitcher_row[4] else None
                    k_per_9 = float(pitcher_row[5]) if pitcher_row[5] else None
                    bb_per_9 = float(pitcher_row[6]) if pitcher_row[6] else None
                    
                    # Calculate pitcher score using same formula as rosters endpoint
                    # ERA component (0-40 points): 40 * (1 - (ERA - 2.0) / 6.0), capped at [0, 40]
                    # WHIP component (0-30 points): 30 * (1 - (WHIP - 0.9) / 0.8), capped at [0, 30]
                    # K/9 component (0-20 points): min(20, K/9 * 2)
                    # BB/9 component (0-10 points): 10 * (1 - BB/9 / 6.0), capped at [0, 10]
                    hier_score = None
                    if any([era, whip, k_per_9, bb_per_9]):
                        hier_score = (
                            (max(0, min(40, 40 * (1 - (era - 2.0) / 6.0))) if era else 20) +
                            (max(0, min(30, 30 * (1 - (whip - 0.9) / 0.8))) if whip else 15) +
                            (min(20, k_per_9 * 2) if k_per_9 else 10) +
                            (max(0, min(10, 10 * (1 - bb_per_9 / 6.0))) if bb_per_9 else 5)
                        )
                    
                    away_top_pitcher = {
                        'player_id': pitcher_row[0],
                        'name': pitcher_row[1],
                        'position_code': pitcher_row[2],
                        'hier_era': era,
                        'hier_whip': whip,
                        'hier_k_per_9': k_per_9,
                        'hier_score': hier_score
                    }
                
                # Home hitter
                cur.execute("""
                    SELECT 
                        phg.player_id,
                        pl.full_name,
                        pl.primary_position_code,
                        phg.hier_ops,
                        phg.hier_avg,
                        phg.hier_obp,
                        phg.hier_slg
                    FROM player_hier_game phg
                    JOIN players pl ON phg.player_id = pl.player_id
                    JOIN game_rosters gr 
                        ON phg.player_id = gr.player_id 
                        AND gr.game_pk = %s
                        AND gr.team_id = %s
                    WHERE phg.game_pk = %s
                      AND phg.player_type = 'batter'
                      AND phg.hier_ops IS NOT NULL
                    ORDER BY phg.hier_ops DESC
                    LIMIT 1
                """, (game_pk, home_team_id, game_pk))
                
                hitter_row = cur.fetchone()
                home_top_hitter = None
                if hitter_row:
                    home_top_hitter = {
                        'player_id': hitter_row[0],
                        'name': hitter_row[1],
                        'position_code': hitter_row[2],
                        'hier_ops': float(hitter_row[3]) if hitter_row[3] else None,
                        'hier_avg': float(hitter_row[4]) if hitter_row[4] else None,
                        'hier_score': float(hitter_row[3]) * 100 if hitter_row[3] else None
                    }
                
                # Home pitcher
                cur.execute("""
                    SELECT 
                        phg.player_id,
                        pl.full_name,
                        pl.primary_position_code,
                        phg.hier_era,
                        phg.hier_whip,
                        phg.hier_k_per_9,
                        phg.hier_bb_per_9
                    FROM player_hier_game phg
                    JOIN players pl ON phg.player_id = pl.player_id
                    JOIN game_rosters gr 
                        ON phg.player_id = gr.player_id 
                        AND gr.game_pk = %s
                        AND gr.team_id = %s
                    WHERE phg.game_pk = %s
                      AND phg.player_type = 'pitcher'
                      AND phg.hier_era IS NOT NULL
                    ORDER BY phg.hier_era ASC
                    LIMIT 1
                """, (game_pk, home_team_id, game_pk))
                
                pitcher_row = cur.fetchone()
                home_top_pitcher = None
                if pitcher_row:
                    era = float(pitcher_row[3]) if pitcher_row[3] else None
                    whip = float(pitcher_row[4]) if pitcher_row[4] else None
                    k_per_9 = float(pitcher_row[5]) if pitcher_row[5] else None
                    bb_per_9 = float(pitcher_row[6]) if pitcher_row[6] else None
                    
                    # Calculate pitcher score using same formula as rosters endpoint
                    # ERA component (0-40 points): 40 * (1 - (ERA - 2.0) / 6.0), capped at [0, 40]
                    # WHIP component (0-30 points): 30 * (1 - (WHIP - 0.9) / 0.8), capped at [0, 30]
                    # K/9 component (0-20 points): min(20, K/9 * 2)
                    # BB/9 component (0-10 points): 10 * (1 - BB/9 / 6.0), capped at [0, 10]
                    hier_score = None
                    if any([era, whip, k_per_9, bb_per_9]):
                        hier_score = (
                            (max(0, min(40, 40 * (1 - (era - 2.0) / 6.0))) if era else 20) +
                            (max(0, min(30, 30 * (1 - (whip - 0.9) / 0.8))) if whip else 15) +
                            (min(20, k_per_9 * 2) if k_per_9 else 10) +
                            (max(0, min(10, 10 * (1 - bb_per_9 / 6.0))) if bb_per_9 else 5)
                        )
                    
                    home_top_pitcher = {
                        'player_id': pitcher_row[0],
                        'name': pitcher_row[1],
                        'position_code': pitcher_row[2],
                        'hier_era': era,
                        'hier_whip': whip,
                        'hier_k_per_9': k_per_9,
                        'hier_score': hier_score
                    }
            else:
                # Fallback logic (same as single game endpoint)
                away_top_hitter = None
                away_top_pitcher = None
                home_top_hitter = None
                home_top_pitcher = None
            
            result[game_pk] = {
                'game_pk': game_pk,
                'away_team': {
                    'top_hitter': away_top_hitter,
                    'top_pitcher': away_top_pitcher
                },
                'home_team': {
                    'top_hitter': home_top_hitter,
                    'top_pitcher': home_top_pitcher
                }
            }
        
        conn.close()
        return result
        
    except Exception as e:
        raise HTTPException(500, f"Error fetching batch top players: {e}")

@app.get("/api/games/{game_pk}/top-players")
async def get_top_players_for_game(game_pk: int):
    """
    Get top hitter and pitcher for each team in a game based on stats up to that game date
    
    Args:
        game_pk: Game primary key
        
    Returns:
        Dict with away_team and home_team, each containing top_hitter and top_pitcher
    """
    import psycopg2
    from dotenv import load_dotenv
    
    try:
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        conn = _get_db_conn()
        cur = conn.cursor()
        
        # Get game info
        cur.execute("""
            SELECT game_date, home_team_id, away_team_id, season
            FROM games
            WHERE game_pk = %s
        """, (game_pk,))
        
        game_row = cur.fetchone()
        if not game_row:
            conn.close()
            # Return empty structure instead of 404
            return {
                'game_pk': game_pk,
                'away_team': {
                    'top_hitter': None,
                    'top_pitcher': None
                },
                'home_team': {
                    'top_hitter': None,
                    'top_pitcher': None
                }
            }
        
        game_date, home_team_id, away_team_id, season = game_row
        
        # Check if player_hier_game has data for this game
        cur.execute("SELECT COUNT(*) FROM player_hier_game WHERE game_pk = %s", (game_pk,))
        has_hier_game_data = cur.fetchone()[0] > 0
        
        # Get top hitter and pitcher for away team
        # First try player_hier_game (most accurate - stats up to that game)
        # If that doesn't exist, fall back to game_rosters + player_hierarchical_stats
        away_top_hitter = None
        away_top_pitcher = None
        
        if has_hier_game_data:
            # Get top hitter for away team using player_hier_game
            # Use game_rosters to verify team membership (more reliable than player_team_history)
            cur.execute("""
                SELECT 
                    phg.player_id,
                    pl.full_name,
                    pl.primary_position_code,
                    phg.hier_ops,
                    phg.hier_avg,
                    phg.hier_obp,
                    phg.hier_slg
                FROM player_hier_game phg
                JOIN players pl ON phg.player_id = pl.player_id
                JOIN game_rosters gr 
                    ON phg.player_id = gr.player_id 
                    AND gr.game_pk = %s
                    AND gr.team_id = %s
                WHERE phg.game_pk = %s
                  AND phg.player_type = 'batter'
                  AND phg.hier_ops IS NOT NULL
                ORDER BY phg.hier_ops DESC
                LIMIT 1
            """, (game_pk, away_team_id, game_pk))
        else:
            # Fallback: Use game_rosters + player_hierarchical_stats
            cur.execute("""
                SELECT 
                    gr.player_id,
                    pl.full_name,
                    pl.primary_position_code,
                    phs.player_hier_ops,
                    phs.player_hier_avg,
                    phs.player_hier_obp,
                    phs.player_hier_slg
                FROM game_rosters gr
                JOIN players pl ON gr.player_id = pl.player_id
                LEFT JOIN player_hierarchical_stats phs 
                    ON pl.player_id = phs.player_id 
                    AND phs.season = %s
                    AND phs.player_type = 'batter'
                WHERE gr.game_pk = %s
                  AND gr.team_id = %s
                  AND pl.primary_position_code NOT IN ('1', 'P')
                  AND phs.player_hier_ops IS NOT NULL
                ORDER BY phs.player_hier_ops DESC
                LIMIT 1
            """, (season, game_pk, away_team_id))
        
        hitter_row = cur.fetchone()
        if hitter_row:
            away_top_hitter = {
                'player_id': hitter_row[0],
                'name': hitter_row[1],
                'position_code': hitter_row[2],
                'hier_ops': float(hitter_row[3]) if hitter_row[3] else None,
                'hier_avg': float(hitter_row[4]) if hitter_row[4] else None,
                'hier_score': float(hitter_row[3]) * 100 if hitter_row[3] else None
            }
        
        # Get top pitcher for away team
        if has_hier_game_data:
            cur.execute("""
                SELECT 
                    phg.player_id,
                    pl.full_name,
                    pl.primary_position_code,
                    phg.hier_era,
                    phg.hier_whip,
                    phg.hier_k_per_9,
                    phg.hier_bb_per_9
                FROM player_hier_game phg
                JOIN players pl ON phg.player_id = pl.player_id
                JOIN game_rosters gr 
                    ON phg.player_id = gr.player_id 
                    AND gr.game_pk = %s
                    AND gr.team_id = %s
                WHERE phg.game_pk = %s
                  AND phg.player_type = 'pitcher'
                  AND phg.hier_era IS NOT NULL
                ORDER BY phg.hier_era ASC
                LIMIT 1
            """, (game_pk, away_team_id, game_pk))
        else:
            # Fallback: Use game_rosters + player_hierarchical_stats
            cur.execute("""
                SELECT 
                    gr.player_id,
                    pl.full_name,
                    pl.primary_position_code,
                    phs.player_hier_era,
                    phs.player_hier_whip,
                    phs.player_hier_k_per_9,
                    phs.player_hier_bb_per_9
                FROM game_rosters gr
                JOIN players pl ON gr.player_id = pl.player_id
                LEFT JOIN player_hierarchical_stats phs 
                    ON pl.player_id = phs.player_id 
                    AND phs.season = %s
                    AND phs.player_type = 'pitcher'
                WHERE gr.game_pk = %s
                  AND gr.team_id = %s
                  AND pl.primary_position_code IN ('1', 'P')
                  AND phs.player_hier_era IS NOT NULL
                ORDER BY phs.player_hier_era ASC
                LIMIT 1
            """, (season, game_pk, away_team_id))
        
        pitcher_row = cur.fetchone()
        if pitcher_row:
            # Calculate pitcher score similar to roster endpoint
            era = float(pitcher_row[3]) if pitcher_row[3] else None
            whip = float(pitcher_row[4]) if pitcher_row[4] else None
            k_per_9 = float(pitcher_row[5]) if pitcher_row[5] else None
            bb_per_9 = float(pitcher_row[6]) if pitcher_row[6] else None
            
            hier_score = None
            if any([era, whip, k_per_9, bb_per_9]):
                hier_score = (
                    (max(0, min(40, 40 * (1 - (era - 2.0) / 6.0))) if era else 20) +
                    (max(0, min(30, 30 * (1 - (whip - 0.9) / 0.8))) if whip else 15) +
                    (min(20, k_per_9 * 2) if k_per_9 else 10) +
                    (max(0, min(10, 10 * (1 - bb_per_9 / 6.0))) if bb_per_9 else 5)
                )
            
            away_top_pitcher = {
                'player_id': pitcher_row[0],
                'name': pitcher_row[1],
                'position_code': pitcher_row[2],
                'hier_era': era,
                'hier_whip': whip,
                'hier_k_per_9': k_per_9,
                'hier_score': hier_score
            }
        
        # Get top hitter and pitcher for home team
        home_top_hitter = None
        home_top_pitcher = None
        
        if has_hier_game_data:
            cur.execute("""
                SELECT 
                    phg.player_id,
                    pl.full_name,
                    pl.primary_position_code,
                    phg.hier_ops,
                    phg.hier_avg,
                    phg.hier_obp,
                    phg.hier_slg
                FROM player_hier_game phg
                JOIN players pl ON phg.player_id = pl.player_id
                JOIN game_rosters gr 
                    ON phg.player_id = gr.player_id 
                    AND gr.game_pk = %s
                    AND gr.team_id = %s
                WHERE phg.game_pk = %s
                  AND phg.player_type = 'batter'
                  AND phg.hier_ops IS NOT NULL
                ORDER BY phg.hier_ops DESC
                LIMIT 1
            """, (game_pk, home_team_id, game_pk))
        else:
            # Fallback: Use game_rosters + player_hierarchical_stats
            cur.execute("""
                SELECT 
                    gr.player_id,
                    pl.full_name,
                    pl.primary_position_code,
                    phs.player_hier_ops,
                    phs.player_hier_avg,
                    phs.player_hier_obp,
                    phs.player_hier_slg
                FROM game_rosters gr
                JOIN players pl ON gr.player_id = pl.player_id
                LEFT JOIN player_hierarchical_stats phs 
                    ON pl.player_id = phs.player_id 
                    AND phs.season = %s
                    AND phs.player_type = 'batter'
                WHERE gr.game_pk = %s
                  AND gr.team_id = %s
                  AND pl.primary_position_code NOT IN ('1', 'P')
                  AND phs.player_hier_ops IS NOT NULL
                ORDER BY phs.player_hier_ops DESC
                LIMIT 1
            """, (season, game_pk, home_team_id))
        
        hitter_row = cur.fetchone()
        if hitter_row:
            home_top_hitter = {
                'player_id': hitter_row[0],
                'name': hitter_row[1],
                'position_code': hitter_row[2],
                'hier_ops': float(hitter_row[3]) if hitter_row[3] else None,
                'hier_avg': float(hitter_row[4]) if hitter_row[4] else None,
                'hier_score': float(hitter_row[3]) * 100 if hitter_row[3] else None
            }
        
        if has_hier_game_data:
            cur.execute("""
                SELECT 
                    phg.player_id,
                    pl.full_name,
                    pl.primary_position_code,
                    phg.hier_era,
                    phg.hier_whip,
                    phg.hier_k_per_9,
                    phg.hier_bb_per_9
                FROM player_hier_game phg
                JOIN players pl ON phg.player_id = pl.player_id
                JOIN game_rosters gr 
                    ON phg.player_id = gr.player_id 
                    AND gr.game_pk = %s
                    AND gr.team_id = %s
                WHERE phg.game_pk = %s
                  AND phg.player_type = 'pitcher'
                  AND phg.hier_era IS NOT NULL
                ORDER BY phg.hier_era ASC
                LIMIT 1
            """, (game_pk, home_team_id, game_pk))
        else:
            # Fallback: Use game_rosters + player_hierarchical_stats
            cur.execute("""
                SELECT 
                    gr.player_id,
                    pl.full_name,
                    pl.primary_position_code,
                    phs.player_hier_era,
                    phs.player_hier_whip,
                    phs.player_hier_k_per_9,
                    phs.player_hier_bb_per_9
                FROM game_rosters gr
                JOIN players pl ON gr.player_id = pl.player_id
                LEFT JOIN player_hierarchical_stats phs 
                    ON pl.player_id = phs.player_id 
                    AND phs.season = %s
                    AND phs.player_type = 'pitcher'
                WHERE gr.game_pk = %s
                  AND gr.team_id = %s
                  AND pl.primary_position_code IN ('1', 'P')
                  AND phs.player_hier_era IS NOT NULL
                ORDER BY phs.player_hier_era ASC
                LIMIT 1
            """, (season, game_pk, home_team_id))
        
        pitcher_row = cur.fetchone()
        if pitcher_row:
            era = float(pitcher_row[3]) if pitcher_row[3] else None
            whip = float(pitcher_row[4]) if pitcher_row[4] else None
            k_per_9 = float(pitcher_row[5]) if pitcher_row[5] else None
            bb_per_9 = float(pitcher_row[6]) if pitcher_row[6] else None
            
            hier_score = None
            if any([era, whip, k_per_9, bb_per_9]):
                hier_score = (
                    (max(0, min(40, 40 * (1 - (era - 2.0) / 6.0))) if era else 20) +
                    (max(0, min(30, 30 * (1 - (whip - 0.9) / 0.8))) if whip else 15) +
                    (min(20, k_per_9 * 2) if k_per_9 else 10) +
                    (max(0, min(10, 10 * (1 - bb_per_9 / 6.0))) if bb_per_9 else 5)
                )
            
            home_top_pitcher = {
                'player_id': pitcher_row[0],
                'name': pitcher_row[1],
                'position_code': pitcher_row[2],
                'hier_era': era,
                'hier_whip': whip,
                'hier_k_per_9': k_per_9,
                'hier_score': hier_score
            }
        
        conn.close()
        
        # Always return a response, even if no players found
        return {
            'game_pk': game_pk,
            'away_team': {
                'top_hitter': away_top_hitter,
                'top_pitcher': away_top_pitcher
            },
            'home_team': {
                'top_hitter': home_top_hitter,
                'top_pitcher': home_top_pitcher
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        import traceback
        error_details = traceback.format_exc()
        print(f"Error fetching top players for game {game_pk}: {e}")
        print(error_details)
        # Return empty structure on error instead of failing
        return {
            'game_pk': game_pk,
            'away_team': {
                'top_hitter': None,
                'top_pitcher': None
            },
            'home_team': {
                'top_hitter': None,
                'top_pitcher': None
            }
        }

@app.get("/api/players/search")
async def search_players(query: str, season: Optional[int] = None):
    """
    Search for players by name and return their team
    """
    import psycopg2
    from dotenv import load_dotenv
    
    try:
        if not query or len(query) < 2:
            return {"players": []}
        
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        conn = _get_db_conn()
        cur = conn.cursor()
        
        # Use most recent season that actually has game_rosters data
        if season is None:
            cur.execute("""
                SELECT MAX(EXTRACT(YEAR FROM g.game_date))
                FROM game_rosters gr
                JOIN games g ON gr.game_pk = g.game_pk
                WHERE g.game_type = 'R'
            """)
            result = cur.fetchone()
            season = int(result[0]) if result and result[0] else datetime.now().year - 1
        
        # Search for players and get their most recent team
        cur.execute("""
            WITH PlayerTeams AS (
                SELECT DISTINCT ON (gr.player_id)
                    gr.player_id,
                    gr.team_id,
                    g.game_date
                FROM game_rosters gr
                JOIN games g ON gr.game_pk = g.game_pk
                WHERE EXTRACT(YEAR FROM g.game_date) = %s
                  AND g.game_type = 'R'
                ORDER BY gr.player_id, g.game_date DESC
            )
            SELECT 
                p.player_id,
                p.full_name,
                p.primary_position_name,
                t.abbreviation,
                t.name,
                t.team_id
            FROM players p
            JOIN PlayerTeams pt ON p.player_id = pt.player_id
            JOIN teams t ON pt.team_id = t.team_id
            WHERE LOWER(p.full_name) LIKE LOWER(%s)
            ORDER BY p.full_name
            LIMIT 20
        """, (season, f'%{query}%'))
        
        players = []
        for row in cur.fetchall():
            players.append({
                "player_id": row[0],
                "name": row[1],
                "position": row[2],
                "team_abbr": row[3],
                "team_name": row[4],
                "team_id": row[5]
            })
        
        conn.close()
        
        return {"players": players, "season": season}
        
    except Exception as e:
        raise HTTPException(500, f"Error searching players: {e}")

# Helper function to map position code to position name
def _map_position_code(position_code: str) -> str:
    """Map MLB position code to position name"""
    position_map = {
        '1': 'P', 'P': 'P',
        '2': 'C',
        '3': '1B',
        '4': '2B',
        '5': '3B',
        '6': 'SS',
        '7': 'LF',
        '8': 'CF',
        '9': 'RF',
        'D': 'DH',
    }
    return position_map.get(position_code, position_code)

@app.get("/api/rosters/{team_abbr}")
async def get_team_roster(team_abbr: str, season: Optional[int] = None):
    """
    Get current roster for a team with hierarchical stats
    Uses player_team_history, players, and player_hierarchical_stats tables
    """
    import psycopg2
    from dotenv import load_dotenv
    
    try:
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        conn = _get_db_conn()
        cur = conn.cursor()
        
        # If no season specified or season has no data, use most recent available season
        if season is None:
            cur.execute("SELECT MAX(season) FROM player_team_history")
            result = cur.fetchone()
            season = result[0] if result and result[0] else datetime.now().year - 1
        else:
            # Check if requested season has data, if not use most recent
            cur.execute("SELECT COUNT(*) FROM player_team_history WHERE season = %s", (season,))
            count = cur.fetchone()[0]
            if count == 0:
                cur.execute("SELECT MAX(season) FROM player_team_history")
                result = cur.fetchone()
                season = result[0] if result and result[0] else season - 1
        
        # Get team_id from abbreviation
        cur.execute("""
            SELECT team_id, name, abbreviation 
            FROM teams 
            WHERE UPPER(abbreviation) = UPPER(%s)
            LIMIT 1
        """, (team_abbr,))
        
        team_row = cur.fetchone()
        if not team_row:
            conn.close()
            raise HTTPException(404, f"Team {team_abbr} not found")
        
        team_id, team_name, team_abbr_db = team_row
        
        # Get current roster with hierarchical stats
        # Simplified query - fetch in steps to avoid timeout
        
        # Step 1: Get CURRENT roster from game_rosters (most recent games)
        # This is more reliable than player_team_history
        cur.execute("""
            WITH MostRecentGames AS (
                SELECT DISTINCT 
                    gr.player_id,
                    gr.team_id,
                    g.game_date
                FROM game_rosters gr
                JOIN games g ON gr.game_pk = g.game_pk
                WHERE EXTRACT(YEAR FROM g.game_date) = %s
                  AND g.game_type = 'R'  -- Regular season only
            ),
            LatestTeamPerPlayer AS (
                SELECT DISTINCT ON (player_id)
                    player_id,
                    team_id,
                    game_date
                FROM MostRecentGames
                ORDER BY player_id, game_date DESC
            )
            SELECT DISTINCT player_id
            FROM LatestTeamPerPlayer
            WHERE team_id = %s
        """, (season, team_id))
        
        player_ids = [row[0] for row in cur.fetchall()]
        
        if not player_ids:
            conn.close()
            return {
                "team": {
                    "team_id": team_id,
                    "name": team_name,
                    "abbreviation": team_abbr_db
                },
                "season": season,
                "batters": [],
                "pitchers": [],
                "total_players": 0
            }
        
        # Step 2: Get player details with position name mapping
        batters = []
        pitchers = []
        
        # Process in chunks of 50 players
        chunk_size = 50
        for i in range(0, len(player_ids), chunk_size):
            chunk = player_ids[i:i + chunk_size]
            placeholders = ','.join(['%s'] * len(chunk))
            
            cur.execute(f"""
                SELECT 
                    p.player_id,
                    p.full_name,
                    p.primary_position_name,
                    p.primary_position_code,
                    p.bat_side_code,
                    p.pitch_hand_code,
                    phs_batter.player_type as batter_type,
                    phs_batter.player_hier_avg,
                    phs_batter.player_hier_obp,
                    phs_batter.player_hier_slg,
                    phs_batter.player_hier_ops,
                    phs_pitcher.player_type as pitcher_type,
                    phs_pitcher.player_hier_era,
                    phs_pitcher.player_hier_whip,
                    phs_pitcher.player_hier_k_per_9,
                    phs_pitcher.player_hier_bb_per_9,
                    phs_batter.team_effect_batting_avg,
                    phs_batter.team_effect_ops,
                    phs_pitcher.team_effect_era,
                    phs_pitcher.team_effect_k_per_9
                FROM players p
                LEFT JOIN player_hierarchical_stats phs_batter
                    ON p.player_id = phs_batter.player_id 
                    AND phs_batter.season = %s
                    AND phs_batter.player_type = 'batter'
                LEFT JOIN player_hierarchical_stats phs_pitcher
                    ON p.player_id = phs_pitcher.player_id 
                    AND phs_pitcher.season = %s
                    AND phs_pitcher.player_type = 'pitcher'
                WHERE p.player_id IN ({placeholders})
                ORDER BY 
                    CASE p.primary_position_code
                        WHEN '1' THEN 1  -- Pitcher
                        WHEN '2' THEN 2  -- Catcher
                        WHEN '3' THEN 3  -- 1B
                        WHEN '4' THEN 4  -- 2B
                        WHEN '5' THEN 5  -- 3B
                        WHEN '6' THEN 6  -- SS
                        WHEN '7' THEN 7  -- LF
                        WHEN '8' THEN 8  -- CF
                        WHEN '9' THEN 9  -- RF
                        WHEN 'D' THEN 10 -- DH
                        ELSE 11
                    END,
                    p.full_name
            """, [season, season] + chunk)
            
            for row in cur.fetchall():
                # Use position_name if available, otherwise map position_code
                position = row[2] if row[2] else _map_position_code(row[3])
                position_code = row[3]  # primary_position_code
                
                # Check if player is a TRUE two-way player:
                # Only if their PRIMARY position is pitcher (code '1' or 'P') AND they have batting stats
                # OR if position name explicitly says "Two-Way Player"
                has_batter_stats = row[6] is not None  # batter_type exists
                has_pitcher_stats = row[11] is not None  # pitcher_type exists
                is_primary_pitcher = position_code in ['1', 'P'] or position in ['P', 'SP', 'RP', 'Pitcher', 'Starting Pitcher', 'Relief Pitcher', 'Two-Way Player']
                is_explicit_two_way = position and ('Two-Way' in str(position) or 'Two Way' in str(position))
                is_two_way = (is_primary_pitcher and has_batter_stats and has_pitcher_stats) or is_explicit_two_way
                
                # Get throws for pitcher position display
                throws = row[5]  # pitch_hand_code
                
                # Create base player data with combined stats
                player_data = {
                    "player_id": row[0],
                    "name": row[1],
                    "position": position,
                    "bats": row[4],
                    "throws": throws,
                    "is_two_way": is_two_way,
                    "hierarchical_stats": {
                        "hier_avg": float(row[7]) if row[7] else None,
                        "hier_obp": float(row[8]) if row[8] else None,
                        "hier_slg": float(row[9]) if row[9] else None,
                        "hier_ops": float(row[10]) if row[10] else None,
                        "hier_era": float(row[12]) if row[12] else None,
                        "hier_whip": float(row[13]) if row[13] else None,
                        "hier_k_per_9": float(row[14]) if row[14] else None,
                        "hier_bb_per_9": float(row[15]) if row[15] else None,
                        "team_effect_batting_avg": float(row[16]) if row[16] else None,
                        "team_effect_ops": float(row[17]) if row[17] else None,
                        "team_effect_era": float(row[18]) if row[18] else None,
                        "team_effect_k_per_9": float(row[19]) if row[19] else None,
                        # Calculate hier_score from OPS for batters or composite score for pitchers
                        "hier_score": None  # Will be calculated separately for batter/pitcher views
                    }
                }
                
                # Calculate batter hier_score
                if row[10]:  # hier_ops
                    player_data["hierarchical_stats"]["hier_score"] = float(row[10]) * 100
                
                # Calculate pitcher hier_score
                if any([row[12], row[13], row[14], row[15]]):  # era, whip, k_per_9, bb_per_9
                    pitcher_score = (
                        (max(0, min(40, 40 * (1 - (float(row[12]) - 2.0) / 6.0))) if row[12] else 20) +
                        (max(0, min(30, 30 * (1 - (float(row[13]) - 0.9) / 0.8))) if row[13] else 15) +
                        (min(20, float(row[14]) * 2) if row[14] else 10) +
                        (max(0, min(10, 10 * (1 - float(row[15]) / 6.0))) if row[15] else 5)
                    )
                    # For two-way players, use pitcher score if batter score not available, otherwise keep batter score
                    if not player_data["hierarchical_stats"]["hier_score"]:
                        player_data["hierarchical_stats"]["hier_score"] = pitcher_score
                
                # Categorize players
                # Two-way players go in both lists with different positions
                if is_two_way:
                    # Calculate pitcher score for two-way players
                    pitcher_score = None
                    if any([row[12], row[13], row[14], row[15]]):
                        pitcher_score = (
                            (max(0, min(40, 40 * (1 - (float(row[12]) - 2.0) / 6.0))) if row[12] else 20) +
                            (max(0, min(30, 30 * (1 - (float(row[13]) - 0.9) / 0.8))) if row[13] else 15) +
                            (min(20, float(row[14]) * 2) if row[14] else 10) +
                            (max(0, min(10, 10 * (1 - float(row[15]) / 6.0))) if row[15] else 5)
                        )
                    
                    # Add to batters with position "Y" (two-way) and batter hier_score
                    batter_hier_stats = player_data["hierarchical_stats"].copy()
                    batter_hier_stats["hier_score"] = float(row[10]) * 100 if row[10] else None
                    batter_data = {
                        "player_id": player_data["player_id"],
                        "name": player_data["name"],
                        "position": "Y",
                        "bats": player_data["bats"],
                        "throws": player_data["throws"],
                        "is_two_way": True,
                        "hierarchical_stats": batter_hier_stats
                    }
                    batters.append(batter_data)
                    
                    # Add to pitchers with position "LHP" or "RHP" and pitcher hier_score
                    pitcher_position = "LHP" if throws == "L" else "RHP"
                    pitcher_hier_stats = player_data["hierarchical_stats"].copy()
                    pitcher_hier_stats["hier_score"] = pitcher_score
                    pitcher_data = {
                        "player_id": player_data["player_id"],
                        "name": player_data["name"],
                        "position": pitcher_position,
                        "bats": player_data["bats"],
                        "throws": player_data["throws"],
                        "is_two_way": True,
                        "hierarchical_stats": pitcher_hier_stats
                    }
                    pitchers.append(pitcher_data)
                elif position in ['P', 'SP', 'RP', 'Pitcher', 'Relief Pitcher', 'Starting Pitcher']:
                    # Pure pitcher - use pitcher score
                    if any([row[12], row[13], row[14], row[15]]):
                        player_data["hierarchical_stats"]["hier_score"] = (
                            (max(0, min(40, 40 * (1 - (float(row[12]) - 2.0) / 6.0))) if row[12] else 20) +
                            (max(0, min(30, 30 * (1 - (float(row[13]) - 0.9) / 0.8))) if row[13] else 15) +
                            (min(20, float(row[14]) * 2) if row[14] else 10) +
                            (max(0, min(10, 10 * (1 - float(row[15]) / 6.0))) if row[15] else 5)
                        )
                    pitchers.append(player_data)
                else:
                    # Pure batter - use batter score
                    if row[10]:
                        player_data["hierarchical_stats"]["hier_score"] = float(row[10]) * 100
                    batters.append(player_data)
        
        conn.close()
        
        return {
            "team": {
                "team_id": team_id,
                "name": team_name,
                "abbreviation": team_abbr_db
            },
            "season": season,
            "batters": batters,
            "pitchers": pitchers,
            "total_players": len(batters) + len(pitchers)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Error fetching roster: {e}")

# Mapping from team abbreviation to MLB Stats API team ID
TEAM_ABBR_TO_MLB_ID = {
    'ARI': 109, 'ATL': 144, 'BAL': 110, 'BOS': 111,
    'CHC': 112, 'CWS': 145, 'CIN': 113, 'CLE': 114,
    'COL': 115, 'DET': 116, 'HOU': 117, 'KC': 118,
    'LAA': 108, 'LAD': 119, 'MIA': 146, 'MIL': 158,
    'MIN': 142, 'NYM': 121, 'NYY': 147, 'OAK': 133,
    'PHI': 143, 'PIT': 134, 'SD': 135, 'SF': 137,
    'SEA': 136, 'STL': 138, 'TB': 139, 'TEX': 140,
    'TOR': 141, 'WSH': 120, 'AZ': 109,  # AZ alias for ARI
    'ATH': 133,  # Athletics (formerly OAK)
}

@app.get("/api/rosters/{team_abbr}/mlb/debug")
async def debug_mlb_roster(team_abbr: str, season: Optional[int] = None):
    """
    Debug endpoint to see what MLB API returns and how matching works
    """
    import psycopg2
    import requests
    from dotenv import load_dotenv
    
    try:
        mlb_team_id = TEAM_ABBR_TO_MLB_ID.get(team_abbr.upper())
        if not mlb_team_id:
            raise HTTPException(404, f"Team abbreviation {team_abbr} not found")
        
        if season is None:
            season = datetime.now().year
        
        mlb_api_url = f"https://statsapi.mlb.com/api/v1/teams/{mlb_team_id}/roster"
        params = {"rosterType": "active", "season": season}
        
        response = requests.get(mlb_api_url, params=params, timeout=10)
        response.raise_for_status()
        mlb_data = response.json()
        
        mlb_players = []
        if 'roster' in mlb_data:
            for person in mlb_data['roster']:
                if 'person' in person:
                    mlb_players.append({
                        'mlb_id': person['person'].get('id'),
                        'full_name': person['person'].get('fullName'),
                        'position': person.get('position', {}).get('name', ''),
                    })
        
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        conn = _get_db_conn()
        cur = conn.cursor()
        
        mlb_ids = [p['mlb_id'] for p in mlb_players if p['mlb_id']]
        matched_by_id = []
        if mlb_ids:
            placeholders = ','.join(['%s'] * len(mlb_ids))
            cur.execute(f"""
                SELECT player_id, full_name
                FROM players
                WHERE player_id IN ({placeholders})
            """, mlb_ids)
            matched_by_id = [{'player_id': row[0], 'full_name': row[1]} for row in cur.fetchall()]
        
        matched_by_name = []
        for mlb_player in mlb_players:
            if mlb_player['mlb_id'] not in [m['player_id'] for m in matched_by_id]:
                cur.execute("""
                    SELECT player_id, full_name
                    FROM players
                    WHERE LOWER(full_name) = LOWER(%s)
                    LIMIT 1
                """, (mlb_player['full_name'],))
                row = cur.fetchone()
                if row:
                    matched_by_name.append({
                        'mlb_id': mlb_player['mlb_id'],
                        'mlb_name': mlb_player['full_name'],
                        'db_player_id': row[0],
                        'db_full_name': row[1]
                    })
        
        conn.close()
        
        return {
            "team_abbr": team_abbr,
            "mlb_team_id": mlb_team_id,
            "season": season,
            "mlb_players_count": len(mlb_players),
            "mlb_ids": mlb_ids[:10],  # First 10 for debugging
            "matched_by_id_count": len(matched_by_id),
            "matched_by_id": matched_by_id[:5],  # First 5
            "matched_by_name_count": len(matched_by_name),
            "matched_by_name": matched_by_name[:5],  # First 5
        }
    except Exception as e:
        raise HTTPException(500, f"Debug error: {e}")

@app.get("/api/rosters/{team_abbr}/mlb")
async def get_team_roster_from_mlb(team_abbr: str, season: Optional[int] = None):
    """
    Get current roster for a team from MLB Stats API, enriched with hierarchical stats from our database.
    This endpoint uses MLB's official roster data as the source of truth, then matches players
    to our database to get hierarchical stats.
    
    Returns the same format as /api/rosters/{team_abbr} so the frontend doesn't need to change.
    """
    import psycopg2
    import requests
    from dotenv import load_dotenv
    
    try:
        # Get MLB team ID from abbreviation
        mlb_team_id = TEAM_ABBR_TO_MLB_ID.get(team_abbr.upper())
        if not mlb_team_id:
            raise HTTPException(404, f"Team abbreviation {team_abbr} not found")
        
        # For MLB roster, always use current year (or specified season) to get current active roster
        # But for hierarchical stats, we'll use the most recent season with data
        mlb_roster_season = season if season else datetime.now().year
        
        # Fetch roster from MLB Stats API (use current year to get current active roster)
        # Endpoint: /api/v1/teams/{teamId}/roster
        mlb_api_url = f"https://statsapi.mlb.com/api/v1/teams/{mlb_team_id}/roster"
        params = {"rosterType": "active", "season": mlb_roster_season}
        
        try:
            response = requests.get(mlb_api_url, params=params, timeout=10)
            response.raise_for_status()
            mlb_data = response.json()
        except requests.RequestException as e:
            raise HTTPException(500, f"Error fetching roster from MLB API: {e}")
        
        # Connect to our database
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        conn = _get_db_conn()
        cur = conn.cursor()
        
        # For hierarchical stats, ALWAYS use most recent season with data (not the MLB roster season)
        # This ensures we show stats even if the current year hasn't started yet
        # Even if season is provided (e.g., 2026), we want to use the most recent season with stats (e.g., 2025)
        cur.execute("SELECT MAX(season) FROM player_hierarchical_stats")
        result = cur.fetchone()
        if result and result[0]:
            stats_season = int(result[0])
        else:
            stats_season = datetime.now().year - 1  # Fall back to last year
        
        # Get team info from our database
        cur.execute("""
            SELECT team_id, name, abbreviation 
            FROM teams 
            WHERE UPPER(abbreviation) = UPPER(%s)
            LIMIT 1
        """, (team_abbr,))
        
        team_row = cur.fetchone()
        if not team_row:
            conn.close()
            raise HTTPException(404, f"Team {team_abbr} not found in database")
        
        team_id, team_name, team_abbr_db = team_row
        
        # Extract players from MLB API response
        mlb_players = []
        if 'roster' in mlb_data:
            for person in mlb_data['roster']:
                if 'person' in person:
                    mlb_id = person['person'].get('id')
                    # Ensure mlb_id is an integer
                    if mlb_id is not None:
                        try:
                            mlb_id = int(mlb_id)
                        except (ValueError, TypeError):
                            mlb_id = None
                    
                    if mlb_id:
                        mlb_players.append({
                            'mlb_id': mlb_id,
                            'full_name': person['person'].get('fullName'),
                            'position': person.get('position', {}).get('name', ''),
                            'position_code': person.get('position', {}).get('code', ''),
                            'bat_side': person.get('person', {}).get('batSide', {}).get('code', ''),
                            'pitch_hand': person.get('person', {}).get('pitchHand', {}).get('code', ''),
                        })
        
        if not mlb_players:
            conn.close()
            return {
                "team": {
                    "team_id": team_id,
                    "name": team_name,
                    "abbreviation": team_abbr_db
                },
                "season": season,
                "batters": [],
                "pitchers": [],
                "total_players": 0
            }
        
        # Match MLB players to our database
        # First try by player_id (which IS mlb_id for most players)
        mlb_ids = [p['mlb_id'] for p in mlb_players if p['mlb_id']]
        player_matches = {}  # Key: mlb_id, Value: {player_id, full_name}
        
        # First try matching by player_id (MLB ID)
        if mlb_ids:
            placeholders = ','.join(['%s'] * len(mlb_ids))
            cur.execute(f"""
                SELECT player_id, full_name
                FROM players
                WHERE player_id IN ({placeholders})
            """, mlb_ids)
            
            matched_rows = cur.fetchall()
            for row in matched_rows:
                player_id, full_name = row
                # Store by mlb_id (which equals player_id when matched by ID)
                player_matches[player_id] = {
                    'player_id': player_id,
                    'full_name': full_name
                }
        
        # Fallback: Match by name for players not matched by ID
        unmatched_mlb_players = [p for p in mlb_players if p['mlb_id'] not in player_matches]
        
        # Match by name for remaining players
        for mlb_player in unmatched_mlb_players:
            mlb_name = mlb_player['full_name']
            mlb_id = mlb_player['mlb_id']
            
            if not mlb_name:
                continue
            
            # Try exact match first (case-insensitive)
            cur.execute("""
                SELECT player_id, full_name
                FROM players
                WHERE LOWER(full_name) = LOWER(%s)
                LIMIT 1
            """, (mlb_name,))
            row = cur.fetchone()
            
            if row:
                player_id, full_name = row
                player_matches[mlb_id] = {
                    'player_id': player_id,
                    'full_name': full_name
                }
            else:
                # Try fuzzy matching - handle common name variations
                # Remove common suffixes
                name_variations = [
                    mlb_name,
                    mlb_name.replace(' Jr.', '').replace(' Sr.', '').strip(),
                    mlb_name.replace(' Jr', '').replace(' Sr', '').strip(),
                    mlb_name.replace(' II', '').replace(' III', '').strip(),
                ]
                
                # Also try first name + last name if there's a middle initial
                name_parts = mlb_name.split()
                if len(name_parts) >= 2:
                    # Try "First Last" format
                    simple_name = f"{name_parts[0]} {name_parts[-1]}"
                    name_variations.append(simple_name)
                
                for name_var in name_variations:
                    if not name_var or len(name_var) < 3:
                        continue
                    
                    cur.execute("""
                        SELECT player_id, full_name
                        FROM players
                        WHERE LOWER(full_name) LIKE LOWER(%s)
                        LIMIT 1
                    """, (f'%{name_var}%',))
                    row = cur.fetchone()
                    if row:
                        player_id, full_name = row
                        player_matches[mlb_id] = {
                            'player_id': player_id,
                            'full_name': full_name
                        }
                        break
        
        # Get hierarchical stats for matched players
        matched_player_ids = [m['player_id'] for m in player_matches.values()]
        
        # If no matches at all, return empty roster with debug info
        if not matched_player_ids:
            conn.close()
            # Return sample MLB names for debugging
            sample_mlb_names = [p['full_name'] for p in mlb_players[:5]]
            return {
                "team": {
                    "team_id": team_id,
                    "name": team_name,
                    "abbreviation": team_abbr_db
                },
                "season": season,
                "batters": [],
                "pitchers": [],
                "total_players": 0,
                "_debug": {
                    "mlb_players_count": len(mlb_players),
                    "matched_count": 0,
                    "sample_mlb_names": sample_mlb_names,
                    "error": "No players matched by name"
                }
            }
        
        # Fetch hierarchical stats for matched players
        batters = []
        pitchers = []
        
        chunk_size = 50
        for i in range(0, len(matched_player_ids), chunk_size):
            chunk = matched_player_ids[i:i + chunk_size]
            placeholders = ','.join(['%s'] * len(chunk))
            
            cur.execute(f"""
                SELECT 
                    p.player_id,
                    p.full_name,
                    p.primary_position_name,
                    p.primary_position_code,
                    p.bat_side_code,
                    p.pitch_hand_code,
                    phs_batter.player_type as batter_type,
                    phs_batter.player_hier_avg,
                    phs_batter.player_hier_obp,
                    phs_batter.player_hier_slg,
                    phs_batter.player_hier_ops,
                    phs_pitcher.player_type as pitcher_type,
                    phs_pitcher.player_hier_era,
                    phs_pitcher.player_hier_whip,
                    phs_pitcher.player_hier_k_per_9,
                    phs_pitcher.player_hier_bb_per_9,
                    phs_batter.team_effect_batting_avg,
                    phs_batter.team_effect_ops,
                    phs_pitcher.team_effect_era,
                    phs_pitcher.team_effect_k_per_9
                FROM players p
                LEFT JOIN player_hierarchical_stats phs_batter
                    ON p.player_id = phs_batter.player_id 
                    AND phs_batter.season = %s
                    AND phs_batter.player_type = 'batter'
                LEFT JOIN player_hierarchical_stats phs_pitcher
                    ON p.player_id = phs_pitcher.player_id 
                    AND phs_pitcher.season = %s
                    AND phs_pitcher.player_type = 'pitcher'
                WHERE p.player_id IN ({placeholders})
            """, [stats_season, stats_season] + chunk)
            
            db_players = {row[0]: row for row in cur.fetchall()}
            
            # Also fetch basic player info for matched players not in db_players (no hierarchical stats)
            missing_player_ids = [pid for pid in matched_player_ids if pid not in db_players]
            if missing_player_ids:
                missing_placeholders = ','.join(['%s'] * len(missing_player_ids))
                cur.execute(f"""
                    SELECT player_id, full_name, primary_position_name, primary_position_code,
                           bat_side_code, pitch_hand_code
                    FROM players
                    WHERE player_id IN ({missing_placeholders})
                """, missing_player_ids)
                
                for basic_row in cur.fetchall():
                    player_id = basic_row[0]
                    # Create a row-like structure with null stats
                    row = (
                        basic_row[0],  # player_id
                        basic_row[1],  # full_name
                        basic_row[2],  # primary_position_name
                        basic_row[3],  # primary_position_code
                        basic_row[4],  # bat_side_code
                        basic_row[5],  # pitch_hand_code
                        None,  # batter_type
                        None, None, None, None,  # batter stats
                        None,  # pitcher_type
                        None, None, None, None,  # pitcher stats
                        None, None, None, None  # team effects
                    )
                    db_players[player_id] = row
            
            # Match MLB roster players to database players
            for mlb_player in mlb_players:
                mlb_id = mlb_player['mlb_id']
                
                # Check if we matched this MLB player to our database
                # When matched by ID, player_id == mlb_id, so the key is mlb_id
                # When matched by name, the key is also mlb_id
                if mlb_id not in player_matches:
                    continue  # Skip if player not in our database
                
                # Get the actual player_id from our database
                matched_info = player_matches[mlb_id]
                player_id = matched_info['player_id']
                
                # Get player data from database (should be in db_players now)
                if player_id not in db_players:
                    continue  # Skip if player not found
                
                row = db_players[player_id]
                
                # Use MLB position if available, otherwise use DB position
                position = mlb_player['position'] if mlb_player['position'] else (row[2] if row[2] else _map_position_code(row[3]))
                position_code = mlb_player['position_code'] if mlb_player['position_code'] else row[3]
                
                # Use MLB bat/pitch side if available, otherwise use DB
                bats = mlb_player['bat_side'] if mlb_player['bat_side'] else row[4]
                throws = mlb_player['pitch_hand'] if mlb_player['pitch_hand'] else row[5]
                
                # Check if two-way player
                has_batter_stats = row[6] is not None
                has_pitcher_stats = row[11] is not None
                is_primary_pitcher = position_code in ['1', 'P'] or position in ['P', 'SP', 'RP', 'Pitcher', 'Starting Pitcher', 'Relief Pitcher', 'Two-Way Player']
                is_explicit_two_way = position and ('Two-Way' in str(position) or 'Two Way' in str(position))
                is_two_way = (is_primary_pitcher and has_batter_stats and has_pitcher_stats) or is_explicit_two_way
                
                # Create player data
                player_data = {
                    "player_id": row[0],
                    "name": row[1],
                    "position": position,
                    "bats": bats,
                    "throws": throws,
                    "is_two_way": is_two_way,
                    "hierarchical_stats": {
                        "hier_avg": float(row[7]) if row[7] else None,
                        "hier_obp": float(row[8]) if row[8] else None,
                        "hier_slg": float(row[9]) if row[9] else None,
                        "hier_ops": float(row[10]) if row[10] else None,
                        "hier_era": float(row[12]) if row[12] else None,
                        "hier_whip": float(row[13]) if row[13] else None,
                        "hier_k_per_9": float(row[14]) if row[14] else None,
                        "hier_bb_per_9": float(row[15]) if row[15] else None,
                        "team_effect_batting_avg": float(row[16]) if row[16] else None,
                        "team_effect_ops": float(row[17]) if row[17] else None,
                        "team_effect_era": float(row[18]) if row[18] else None,
                        "team_effect_k_per_9": float(row[19]) if row[19] else None,
                        "hier_score": None
                    }
                }
                
                # Calculate batter hier_score
                if row[10]:  # hier_ops
                    player_data["hierarchical_stats"]["hier_score"] = float(row[10]) * 100
                
                # Calculate pitcher hier_score
                if any([row[12], row[13], row[14], row[15]]):
                    pitcher_score = (
                        (max(0, min(40, 40 * (1 - (float(row[12]) - 2.0) / 6.0))) if row[12] else 20) +
                        (max(0, min(30, 30 * (1 - (float(row[13]) - 0.9) / 0.8))) if row[13] else 15) +
                        (min(20, float(row[14]) * 2) if row[14] else 10) +
                        (max(0, min(10, 10 * (1 - float(row[15]) / 6.0))) if row[15] else 5)
                    )
                    if not player_data["hierarchical_stats"]["hier_score"]:
                        player_data["hierarchical_stats"]["hier_score"] = pitcher_score
                
                # Categorize players (same logic as original endpoint)
                if is_two_way:
                    pitcher_score = None
                    if any([row[12], row[13], row[14], row[15]]):
                        pitcher_score = (
                            (max(0, min(40, 40 * (1 - (float(row[12]) - 2.0) / 6.0))) if row[12] else 20) +
                            (max(0, min(30, 30 * (1 - (float(row[13]) - 0.9) / 0.8))) if row[13] else 15) +
                            (min(20, float(row[14]) * 2) if row[14] else 10) +
                            (max(0, min(10, 10 * (1 - float(row[15]) / 6.0))) if row[15] else 5)
                        )
                    
                    batter_hier_stats = player_data["hierarchical_stats"].copy()
                    batter_hier_stats["hier_score"] = float(row[10]) * 100 if row[10] else None
                    batter_data = {
                        "player_id": player_data["player_id"],
                        "name": player_data["name"],
                        "position": "Y",
                        "bats": player_data["bats"],
                        "throws": player_data["throws"],
                        "is_two_way": True,
                        "hierarchical_stats": batter_hier_stats
                    }
                    batters.append(batter_data)
                    
                    pitcher_position = "LHP" if throws == "L" else "RHP"
                    pitcher_hier_stats = player_data["hierarchical_stats"].copy()
                    pitcher_hier_stats["hier_score"] = pitcher_score
                    pitcher_data = {
                        "player_id": player_data["player_id"],
                        "name": player_data["name"],
                        "position": pitcher_position,
                        "bats": player_data["bats"],
                        "throws": player_data["throws"],
                        "is_two_way": True,
                        "hierarchical_stats": pitcher_hier_stats
                    }
                    pitchers.append(pitcher_data)
                elif position in ['P', 'SP', 'RP', 'Pitcher', 'Relief Pitcher', 'Starting Pitcher']:
                    if any([row[12], row[13], row[14], row[15]]):
                        player_data["hierarchical_stats"]["hier_score"] = (
                            (max(0, min(40, 40 * (1 - (float(row[12]) - 2.0) / 6.0))) if row[12] else 20) +
                            (max(0, min(30, 30 * (1 - (float(row[13]) - 0.9) / 0.8))) if row[13] else 15) +
                            (min(20, float(row[14]) * 2) if row[14] else 10) +
                            (max(0, min(10, 10 * (1 - float(row[15]) / 6.0))) if row[15] else 5)
                        )
                    pitchers.append(player_data)
                else:
                    if row[10]:
                        player_data["hierarchical_stats"]["hier_score"] = float(row[10]) * 100
                    batters.append(player_data)
        
        conn.close()
        
        # Debug info (can be removed later)
        debug_info = {
            "mlb_players_count": len(mlb_players),
            "matched_count": len(player_matches),
            "batters_count": len(batters),
            "pitchers_count": len(pitchers),
        }
        
        return {
            "team": {
                "team_id": team_id,
                "name": team_name,
                "abbreviation": team_abbr_db
            },
            "season": mlb_roster_season,  # Return the MLB roster season (current year)
            "batters": batters,
            "pitchers": pitchers,
            "total_players": len(batters) + len(pitchers),
            "_debug": debug_info  # Remove this in production
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Error fetching roster from MLB: {e}")

# ============================================================================
# PERFORMANCE TRACKING ENDPOINTS (user_bets)
# ============================================================================

class UserBetCreate(BaseModel):
    """Create a new bet record"""
    game_pk: int
    game_date: str  # YYYY-MM-DD
    market_type: str
    selection: str
    side: str
    strike: Optional[float] = None
    player_name: Optional[str] = None
    mcmc_probability: float
    market_probability: Optional[float] = None
    edge: Optional[float] = None
    sportsbook: Optional[str] = None  # Optional — user may not care which book
    american_odds: int
    decimal_odds: Optional[float] = None
    stake: float = 100.0
    potential_payout: Optional[float] = None
    kelly_fraction: Optional[str] = None  # 'quarter', 'half', 'full', 'custom'
    # Pinnacle price at time of entry (mains)
    entry_pinnacle_odds: Optional[int] = None
    entry_pinnacle_prob: Optional[float] = None
    # FanDuel price at time of entry (props)
    entry_fd_odds: Optional[int] = None
    entry_fd_prob: Optional[float] = None
    notes: Optional[str] = None
    tags: Optional[List[str]] = None
    is_parlay: bool = False
    parlay_id: Optional[int] = None

class UserBetSettle(BaseModel):
    """Settle a bet"""
    result: str  # 'WIN', 'LOSS', 'PUSH', 'VOID'
    closing_odds: Optional[int] = None
    closing_probability: Optional[float] = None

class UserBetBulkSettle(BaseModel):
    """Settle multiple bets at once"""
    settlements: List[Dict[str, Any]]  # [{bet_id: int, result: str, closing_odds: int, ...}]


_perf_tables_ensured = False

def _ensure_performance_tables():
    """Verify performance tables exist (user_bets, user_notes, predictions)."""
    global _perf_tables_ensured
    if _perf_tables_ensured:
        return
    conn = None
    try:
        conn = _get_db_conn()
        cur = conn.cursor()
        cur.execute("""
            SELECT COUNT(*) FROM information_schema.tables 
            WHERE table_schema = 'public' 
              AND table_name IN ('user_bets', 'user_notes', 'predictions')
        """)
        count = cur.fetchone()[0]
        if count >= 3:
            _perf_tables_ensured = True
            print("[API] Performance tables verified")
        else:
            print(f"[API] Warning: only {count}/3 performance tables exist")
    except Exception as e:
        print(f"[API] Warning: Could not verify performance tables: {e}")
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass


def _american_to_decimal(american: int) -> float:
    """Convert American odds to decimal."""
    if american > 0:
        return 1.0 + american / 100.0
    else:
        return 1.0 + 100.0 / abs(american)


@app.post("/api/bets")
async def create_bet(bet: UserBetCreate):
    """Record a new bet. Auto-populates entry-time prices from Pinnacle/FanDuel."""
    try:
        conn = _get_db_conn()
        cur = conn.cursor()

        decimal_odds = bet.decimal_odds or _american_to_decimal(bet.american_odds)
        potential_payout = bet.potential_payout or round(bet.stake * decimal_odds, 2)
        edge = bet.edge
        if edge is None and bet.market_probability is not None:
            edge = round(bet.mcmc_probability - bet.market_probability, 4)

        # Auto-populate entry-time Pinnacle/FanDuel prices if not provided
        entry_pin_odds = bet.entry_pinnacle_odds
        entry_pin_prob = bet.entry_pinnacle_prob
        entry_fd_odds = bet.entry_fd_odds
        entry_fd_prob = bet.entry_fd_prob

        if entry_pin_odds is None or entry_fd_odds is None:
            try:
                cur.execute("""
                    SELECT sm.american_odds, sm.implied_probability, sb.short_name
                    FROM sportsbook_markets sm
                    JOIN sportsbooks sb ON sm.sportsbook_id = sb.sportsbook_id
                    WHERE sm.game_pk = %s
                      AND sm.market_type = %s
                      AND sm.outcome_side = %s
                      AND sm.is_available = TRUE
                      AND sb.short_name IN ('PIN', 'FD')
                      AND (sm.strike_price = %s OR (%s IS NULL AND sm.strike_price IS NULL))
                    ORDER BY sm.odds_updated_at DESC
                """, (bet.game_pk, bet.market_type.upper(), bet.side.lower(), bet.strike, bet.strike))
                for row_odds in cur.fetchall():
                    ao, ip, book = row_odds
                    if book == 'PIN' and entry_pin_odds is None:
                        entry_pin_odds = ao
                        entry_pin_prob = float(ip) * 100 if ip else None
                    elif book == 'FD' and entry_fd_odds is None:
                        entry_fd_odds = ao
                        entry_fd_prob = float(ip) * 100 if ip else None
            except Exception:
                pass  # Non-critical

        cur.execute("""
            INSERT INTO user_bets (
                game_pk, game_date, market_type, selection, side, strike, player_name,
                mcmc_probability, market_probability, edge,
                american_odds, decimal_odds,
                stake, potential_payout, kelly_fraction,
                entry_pinnacle_odds, entry_pinnacle_prob,
                entry_fd_odds, entry_fd_prob,
                notes, is_parlay, parlay_id
            ) VALUES (
                %s, %s, %s, %s, %s, %s, %s,
                %s, %s, %s,
                %s, %s,
                %s, %s, %s,
                %s, %s,
                %s, %s,
                %s, %s, %s
            )
            RETURNING id, created_at
        """, (
            bet.game_pk, bet.game_date, bet.market_type.upper(), bet.selection, bet.side.lower(),
            bet.strike, bet.player_name,
            bet.mcmc_probability, bet.market_probability, edge,
            bet.american_odds, decimal_odds,
            bet.stake, potential_payout, bet.kelly_fraction,
            entry_pin_odds, entry_pin_prob,
            entry_fd_odds, entry_fd_prob,
            bet.notes, bet.is_parlay, bet.parlay_id
        ))

        row = cur.fetchone()
        conn.commit()
        conn.close()

        return {"status": "created", "bet_id": row[0], "created_at": str(row[1])}

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Error creating bet: {e}")


@app.get("/api/bets")
async def list_bets(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    market_type: Optional[str] = None,
    sportsbook: Optional[str] = None,
    result: Optional[str] = None,
    tag: Optional[str] = None,
    player: Optional[str] = None,
    team: Optional[str] = None,
    min_edge: Optional[float] = None,
    max_edge: Optional[float] = None,
    min_clv: Optional[float] = None,
    max_clv: Optional[float] = None,
    limit: int = 200,
    offset: int = 0,
):
    """List bets with optional filters (market, team, player, edge, CLV, etc.)."""
    try:
        conn = _get_db_conn()
        cur = conn.cursor()

        conditions = []
        params: list = []

        if start_date:
            conditions.append("game_date >= %s")
            params.append(start_date)
        if end_date:
            conditions.append("game_date <= %s")
            params.append(end_date)
        if market_type:
            conditions.append("market_type = %s")
            params.append(market_type.upper())
        if sportsbook:
            conditions.append("sportsbook = %s")
            params.append(sportsbook.upper())
        if result:
            if result.upper() in ('UNSETTLED', 'PENDING'):
                conditions.append("result IS NULL")
            else:
                conditions.append("result = %s")
                params.append(result.upper())
        if tag:
            conditions.append("%s = ANY(tags)")
            params.append(tag)
        if player:
            conditions.append("player_name ILIKE %s")
            params.append(f"%{player}%")
        if team:
            conditions.append("selection ILIKE %s")
            params.append(f"%{team}%")
        if min_edge is not None:
            conditions.append("edge >= %s")
            params.append(min_edge)
        if max_edge is not None:
            conditions.append("edge <= %s")
            params.append(max_edge)
        if min_clv is not None:
            conditions.append("clv_cents >= %s")
            params.append(min_clv)
        if max_clv is not None:
            conditions.append("clv_cents <= %s")
            params.append(max_clv)

        where = ("WHERE " + " AND ".join(conditions)) if conditions else ""

        cur.execute(f"""
            SELECT id, game_pk, game_date, market_type, selection, side, strike, player_name,
                   mcmc_probability, market_probability, edge,
                   american_odds, decimal_odds,
                   stake, potential_payout, kelly_fraction,
                   entry_pinnacle_odds, entry_pinnacle_prob,
                   entry_fd_odds, entry_fd_prob,
                   result, profit_loss, settled_at,
                   closing_odds, closing_probability, clv_cents,
                   notes, is_parlay, parlay_id,
                   created_at, updated_at
            FROM user_bets
            {where}
            ORDER BY game_date DESC, created_at DESC
            LIMIT %s OFFSET %s
        """, params + [limit, offset])

        rows = cur.fetchall()
        cols = [desc[0] for desc in cur.description]

        # Get total count
        cur.execute(f"SELECT COUNT(*) FROM user_bets {where}", params)
        total = cur.fetchone()[0]

        conn.close()

        bets = []
        for row in rows:
            bet = {}
            for i, col in enumerate(cols):
                val = row[i]
                if isinstance(val, (date, datetime)):
                    val = str(val)
                elif isinstance(val, Decimal):
                    val = float(val)
                bet[col] = val
            bets.append(bet)

        return {"bets": bets, "total": total, "limit": limit, "offset": offset}

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Error listing bets: {e}")


@app.put("/api/bets/{bet_id}/settle")
async def settle_bet(bet_id: int, settlement: UserBetSettle):
    """Settle an individual bet."""
    try:
        conn = _get_db_conn()
        cur = conn.cursor()

        # Load the bet
        cur.execute("SELECT stake, american_odds, decimal_odds FROM user_bets WHERE id = %s", (bet_id,))
        row = cur.fetchone()
        if not row:
            conn.close()
            raise HTTPException(404, f"Bet {bet_id} not found")

        stake, _, decimal_odds = float(row[0]), row[1], float(row[2]) if row[2] else None

        # Calculate P&L
        res = settlement.result.upper()
        if res == 'WIN':
            profit_loss = round(stake * (decimal_odds - 1), 2) if decimal_odds else stake
        elif res == 'LOSS':
            profit_loss = -stake
        elif res == 'PUSH':
            profit_loss = 0.0
        else:  # VOID
            profit_loss = 0.0

        # Calculate CLV
        clv_cents = None
        if settlement.closing_odds is not None:
            closing_dec = _american_to_decimal(settlement.closing_odds)
            opening_dec = decimal_odds or _american_to_decimal(row[1])
            clv_cents = round((1 / opening_dec - 1 / closing_dec) * 100, 2)

        closing_prob = settlement.closing_probability
        if closing_prob is None and settlement.closing_odds is not None:
            closing_dec = _american_to_decimal(settlement.closing_odds)
            closing_prob = round(1 / closing_dec * 100, 4)

        cur.execute("""
            UPDATE user_bets
            SET result = %s,
                profit_loss = %s,
                settled_at = NOW(),
                closing_odds = %s,
                closing_probability = %s,
                clv_cents = %s
            WHERE id = %s
            RETURNING id, result, profit_loss, clv_cents
        """, (res, profit_loss, settlement.closing_odds, closing_prob, clv_cents, bet_id))

        updated = cur.fetchone()
        conn.commit()
        conn.close()

        return {
            "bet_id": updated[0],
            "result": updated[1],
            "profit_loss": float(updated[2]) if updated[2] else 0,
            "clv_cents": float(updated[3]) if updated[3] else None,
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Error settling bet: {e}")


@app.delete("/api/bets/{bet_id}")
async def delete_bet(bet_id: int):
    """Delete a bet record."""
    try:
        conn = _get_db_conn()
        cur = conn.cursor()
        cur.execute("DELETE FROM user_bets WHERE id = %s RETURNING id", (bet_id,))
        deleted = cur.fetchone()
        conn.commit()
        conn.close()
        if not deleted:
            raise HTTPException(404, f"Bet {bet_id} not found")
        return {"status": "deleted", "bet_id": bet_id}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Error deleting bet: {e}")


@app.get("/api/performance/summary")
async def performance_summary(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
):
    """
    High-level performance summary: record, ROI, units, avg edge, avg CLV.
    """
    try:
        conn = _get_db_conn()
        cur = conn.cursor()

        conditions = ["result IS NOT NULL"]
        params: list = []
        if start_date:
            conditions.append("game_date >= %s")
            params.append(start_date)
        if end_date:
            conditions.append("game_date <= %s")
            params.append(end_date)
        where = "WHERE " + " AND ".join(conditions)

        cur.execute(f"""
            SELECT
                COUNT(*) AS total_bets,
                SUM(CASE WHEN result = 'WIN' THEN 1 ELSE 0 END) AS wins,
                SUM(CASE WHEN result = 'LOSS' THEN 1 ELSE 0 END) AS losses,
                SUM(CASE WHEN result = 'PUSH' THEN 1 ELSE 0 END) AS pushes,
                SUM(stake) AS total_staked,
                SUM(profit_loss) AS total_pnl,
                AVG(edge) AS avg_edge,
                AVG(clv_cents) FILTER (WHERE clv_cents IS NOT NULL) AS avg_clv,
                AVG(clv_cents) FILTER (WHERE clv_cents > 0) AS avg_pos_clv,
                AVG(clv_cents) FILTER (WHERE clv_cents < 0) AS avg_neg_clv,
                COUNT(*) FILTER (WHERE clv_cents > 0) AS pos_clv_count,
                COUNT(*) FILTER (WHERE clv_cents < 0) AS neg_clv_count,
                AVG(mcmc_probability) AS avg_mcmc_prob,
                COUNT(*) FILTER (WHERE result = 'WIN')::FLOAT / NULLIF(COUNT(*) FILTER (WHERE result IN ('WIN','LOSS')),0) AS win_rate
            FROM user_bets
            {where}
        """, params)

        row = cur.fetchone()
        cols = [d[0] for d in cur.description]

        # Pending bets count
        pending_conds = ["result IS NULL"]
        pending_params: list = []
        if start_date:
            pending_conds.append("game_date >= %s")
            pending_params.append(start_date)
        if end_date:
            pending_conds.append("game_date <= %s")
            pending_params.append(end_date)
        cur.execute(f"SELECT COUNT(*), SUM(stake) FROM user_bets WHERE {' AND '.join(pending_conds)}", pending_params)
        pending = cur.fetchone()

        conn.close()

        summary = {}
        for i, col in enumerate(cols):
            val = row[i]
            summary[col] = float(val) if isinstance(val, Decimal) else val

        total_staked = summary.get('total_staked') or 0
        total_pnl = summary.get('total_pnl') or 0
        summary['roi'] = round(total_pnl / total_staked * 100, 2) if total_staked > 0 else 0
        summary['units'] = round(total_pnl / 100, 2)  # Assuming $100 = 1 unit
        summary['pending_bets'] = pending[0] if pending else 0
        summary['pending_stake'] = float(pending[1]) if pending and pending[1] else 0

        return summary

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Error computing performance summary: {e}")


@app.get("/api/performance/pnl")
async def performance_pnl(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    group_by: str = "day",  # 'day', 'week', 'month'
):
    """Cumulative P&L time series."""
    try:
        conn = _get_db_conn()
        cur = conn.cursor()

        conditions = ["result IS NOT NULL"]
        params: list = []
        if start_date:
            conditions.append("game_date >= %s")
            params.append(start_date)
        if end_date:
            conditions.append("game_date <= %s")
            params.append(end_date)
        where = "WHERE " + " AND ".join(conditions)

        if group_by == 'week':
            date_trunc = "DATE_TRUNC('week', game_date)"
        elif group_by == 'month':
            date_trunc = "DATE_TRUNC('month', game_date)"
        else:
            date_trunc = "game_date"

        cur.execute(f"""
            SELECT
                {date_trunc} AS period,
                COUNT(*) AS bets,
                SUM(CASE WHEN result = 'WIN' THEN 1 ELSE 0 END) AS wins,
                SUM(CASE WHEN result = 'LOSS' THEN 1 ELSE 0 END) AS losses,
                SUM(profit_loss) AS pnl,
                SUM(stake) AS staked
            FROM user_bets
            {where}
            GROUP BY {date_trunc}
            ORDER BY {date_trunc}
        """, params)

        rows = cur.fetchall()
        conn.close()

        series = []
        cumulative = 0.0
        cumulative_staked = 0.0
        for row in rows:
            pnl = float(row[4]) if row[4] else 0
            staked = float(row[5]) if row[5] else 0
            cumulative += pnl
            cumulative_staked += staked
            series.append({
                "period": str(row[0]),
                "bets": row[1],
                "wins": row[2],
                "losses": row[3],
                "pnl": round(pnl, 2),
                "cumulative_pnl": round(cumulative, 2),
                "staked": round(staked, 2),
                "cumulative_staked": round(cumulative_staked, 2),
                "roi": round(pnl / staked * 100, 2) if staked > 0 else 0,
                "cumulative_roi": round(cumulative / cumulative_staked * 100, 2) if cumulative_staked > 0 else 0,
            })

        return {"series": series, "group_by": group_by}

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Error computing P&L: {e}")


@app.get("/api/performance/roi")
async def performance_roi(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
):
    """ROI breakdown by market type, sportsbook, edge bucket."""
    try:
        conn = _get_db_conn()
        cur = conn.cursor()

        conditions = ["result IS NOT NULL"]
        params: list = []
        if start_date:
            conditions.append("game_date >= %s")
            params.append(start_date)
        if end_date:
            conditions.append("game_date <= %s")
            params.append(end_date)
        where = "WHERE " + " AND ".join(conditions)

        # By market type
        cur.execute(f"""
            SELECT market_type,
                   COUNT(*) AS bets,
                   SUM(stake) AS staked,
                   SUM(profit_loss) AS pnl,
                   SUM(CASE WHEN result='WIN' THEN 1 ELSE 0 END)::FLOAT / NULLIF(COUNT(*),0) AS win_rate
            FROM user_bets {where}
            GROUP BY market_type ORDER BY SUM(profit_loss) DESC
        """, params)
        by_market = [{"market_type": r[0], "bets": r[1], "staked": float(r[2] or 0), "pnl": float(r[3] or 0),
                       "roi": round(float(r[3] or 0)/float(r[2] or 1)*100, 2), "win_rate": round(float(r[4] or 0)*100, 1)} for r in cur.fetchall()]

        # By sportsbook (column may not exist yet on older schemas)
        by_book = []
        try:
            cur.execute(f"""
                SELECT COALESCE(sportsbook, 'Unknown') AS book,
                       COUNT(*) AS bets,
                       SUM(stake) AS staked,
                       SUM(profit_loss) AS pnl,
                       SUM(CASE WHEN result='WIN' THEN 1 ELSE 0 END)::FLOAT / NULLIF(COUNT(*),0) AS win_rate
                FROM user_bets {where}
                GROUP BY book ORDER BY SUM(profit_loss) DESC
            """, params)
            by_book = [{"sportsbook": r[0], "bets": r[1], "staked": float(r[2] or 0), "pnl": float(r[3] or 0),
                         "roi": round(float(r[3] or 0)/float(r[2] or 1)*100, 2), "win_rate": round(float(r[4] or 0)*100, 1)} for r in cur.fetchall()]
        except Exception:
            conn.rollback()

        # By edge bucket (0-2%, 2-5%, 5-10%, 10%+)
        cur.execute(f"""
            SELECT
                CASE
                    WHEN edge IS NULL THEN 'unknown'
                    WHEN edge < 2 THEN '0-2%%'
                    WHEN edge < 5 THEN '2-5%%'
                    WHEN edge < 10 THEN '5-10%%'
                    ELSE '10%%+'
                END AS edge_bucket,
                COUNT(*) AS bets,
                SUM(stake) AS staked,
                SUM(profit_loss) AS pnl,
                SUM(CASE WHEN result='WIN' THEN 1 ELSE 0 END)::FLOAT / NULLIF(COUNT(*),0) AS win_rate
            FROM user_bets {where}
            GROUP BY 1 ORDER BY 1
        """, params)
        by_edge = [{"edge_bucket": r[0], "bets": r[1], "staked": float(r[2] or 0), "pnl": float(r[3] or 0),
                     "roi": round(float(r[3] or 0)/float(r[2] or 1)*100, 2), "win_rate": round(float(r[4] or 0)*100, 1)} for r in cur.fetchall()]

        conn.close()

        return {"by_market": by_market, "by_sportsbook": by_book, "by_edge": by_edge}

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Error computing ROI breakdown: {e}")


@app.get("/api/performance/clv")
async def performance_clv(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
):
    """Closing Line Value analysis."""
    try:
        conn = _get_db_conn()
        cur = conn.cursor()

        conditions = ["result IS NOT NULL", "clv_cents IS NOT NULL"]
        params: list = []
        if start_date:
            conditions.append("game_date >= %s")
            params.append(start_date)
        if end_date:
            conditions.append("game_date <= %s")
            params.append(end_date)
        where = "WHERE " + " AND ".join(conditions)

        # Overall CLV
        cur.execute(f"""
            SELECT
                COUNT(*) AS bets_with_clv,
                AVG(clv_cents) AS avg_clv_cents,
                PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY clv_cents) AS median_clv_cents,
                SUM(CASE WHEN clv_cents > 0 THEN 1 ELSE 0 END)::FLOAT / NULLIF(COUNT(*),0) AS pct_positive_clv
            FROM user_bets {where}
        """, params)
        overall = cur.fetchone()

        # CLV by market type
        cur.execute(f"""
            SELECT market_type,
                   COUNT(*) AS bets,
                   AVG(clv_cents) AS avg_clv
            FROM user_bets {where}
            GROUP BY market_type ORDER BY AVG(clv_cents) DESC
        """, params)
        by_market = [{"market_type": r[0], "bets": r[1], "avg_clv": round(float(r[2] or 0), 2)} for r in cur.fetchall()]

        # CLV time series (daily avg)
        cur.execute(f"""
            SELECT game_date, AVG(clv_cents) AS avg_clv, COUNT(*) AS bets
            FROM user_bets {where}
            GROUP BY game_date ORDER BY game_date
        """, params)
        series = [{"date": str(r[0]), "avg_clv": round(float(r[1] or 0), 2), "bets": r[2]} for r in cur.fetchall()]

        conn.close()

        return {
            "bets_with_clv": overall[0] if overall else 0,
            "avg_clv_cents": round(float(overall[1] or 0), 2) if overall else 0,
            "median_clv_cents": round(float(overall[2] or 0), 2) if overall else 0,
            "pct_positive_clv": round(float(overall[3] or 0) * 100, 1) if overall else 0,
            "by_market": by_market,
            "series": series,
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Error computing CLV: {e}")


@app.get("/api/performance/calibration")
async def performance_calibration(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    bucket_size: int = 5,  # Probability bucket size in percentage points
):
    """
    Calibration curve: predicted probability vs actual win rate.
    Groups bets into probability buckets and computes actual hit rate.
    """
    try:
        conn = _get_db_conn()
        cur = conn.cursor()

        conditions = ["result IN ('WIN','LOSS')"]
        params: list = []
        if start_date:
            conditions.append("game_date >= %s")
            params.append(start_date)
        if end_date:
            conditions.append("game_date <= %s")
            params.append(end_date)
        where = "WHERE " + " AND ".join(conditions)

        cur.execute(f"""
            SELECT
                FLOOR(mcmc_probability / %s) * %s AS bucket_low,
                COUNT(*) AS bets,
                AVG(mcmc_probability) AS avg_predicted,
                SUM(CASE WHEN result = 'WIN' THEN 1 ELSE 0 END)::FLOAT / COUNT(*) AS actual_win_rate
            FROM user_bets
            {where}
            GROUP BY 1
            ORDER BY 1
        """, [bucket_size, bucket_size] + params)

        rows = cur.fetchall()
        conn.close()

        buckets = []
        for r in rows:
            low = float(r[0])
            buckets.append({
                "bucket": f"{low:.0f}-{low + bucket_size:.0f}%",
                "bucket_low": low,
                "bucket_high": low + bucket_size,
                "bets": r[1],
                "avg_predicted": round(float(r[2] or 0), 2),
                "actual_win_rate": round(float(r[3] or 0) * 100, 2),
            })

        return {"buckets": buckets, "bucket_size": bucket_size}

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Error computing calibration: {e}")


@app.get("/api/predictions/calibration")
async def predictions_calibration(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    bucket_size: int = 5,
):
    """
    Calibration curve from ALL model predictions (not user_bets).
    Groups graded predictions by MCMC probability bucket and computes
    actual hit rate.  Includes Brier score, log loss, and
    per-market accuracy breakdown.
    """
    try:
        conn = _get_db_conn()
        cur = conn.cursor()

        conditions = ["p.result IN ('WIN','LOSS')"]
        params: list = []
        if start_date:
            conditions.append("g.game_date >= %s")
            params.append(start_date)
        if end_date:
            conditions.append("g.game_date <= %s")
            params.append(end_date)
        where = "WHERE " + " AND ".join(conditions)

        # ── Calibration buckets ─────────────────────────────────────────
        cur.execute(f"""
            SELECT
                FLOOR(p.probability / %s) * %s AS bucket_low,
                COUNT(*) AS bets,
                AVG(p.probability) AS avg_predicted,
                SUM(CASE WHEN p.result = 'WIN' THEN 1 ELSE 0 END)::FLOAT
                    / COUNT(*) AS actual_win_rate
            FROM predictions p
            JOIN games g ON p.game_pk = g.game_pk
            {where}
            GROUP BY 1
            ORDER BY 1
        """, [bucket_size, bucket_size] + params)

        buckets = []
        for r in cur.fetchall():
            low = float(r[0])
            buckets.append({
                "bucket": f"{low:.0f}-{low + bucket_size:.0f}%",
                "bucket_low": low,
                "bucket_high": low + bucket_size,
                "bets": r[1],
                "avg_predicted": round(float(r[2] or 0), 2),
                "actual_win_rate": round(float(r[3] or 0) * 100, 2),
            })

        # ── Brier score & log loss ──────────────────────────────────────
        cur.execute(f"""
            SELECT
                p.probability / 100.0 AS prob,
                CASE WHEN p.result = 'WIN' THEN 1.0 ELSE 0.0 END AS outcome
            FROM predictions p
            JOIN games g ON p.game_pk = g.game_pk
            {where}
        """, params)
        rows = cur.fetchall()
        brier = None
        log_loss = None
        if rows:
            import math
            n = len(rows)
            brier_sum = 0.0
            ll_sum = 0.0
            eps = 1e-15  # avoid log(0)
            for prob, outcome in rows:
                p = float(prob)
                o = float(outcome)
                brier_sum += (p - o) ** 2
                p_clamped = max(eps, min(1 - eps, p))
                ll_sum += -(o * math.log(p_clamped) + (1 - o) * math.log(1 - p_clamped))
            brier = round(brier_sum / n, 4)
            log_loss = round(ll_sum / n, 4)

        # ── Per-market Brier + directional accuracy (favored side only) ──
        cur.execute(f"""
            SELECT
                p.market_type,
                COUNT(*) AS total_graded,
                AVG(POWER(p.probability / 100.0
                    - CASE WHEN p.result = 'WIN' THEN 1.0 ELSE 0.0 END, 2)) AS brier,
                COUNT(*) FILTER (WHERE p.probability > 50) AS dir_total,
                SUM(CASE WHEN p.probability > 50 AND p.result = 'WIN' THEN 1 ELSE 0 END) AS dir_wins
            FROM predictions p
            JOIN games g ON p.game_pk = g.game_pk
            {where}
            GROUP BY p.market_type
            ORDER BY COUNT(*) DESC
        """, params)
        market_accuracy = []
        for r in cur.fetchall():
            total_m = r[1]
            brier_m = float(r[2]) if r[2] is not None else None
            dir_total = r[3]
            dir_wins = r[4]
            market_accuracy.append({
                "market_type": r[0],
                "total": total_m,
                "brier": round(brier_m, 4) if brier_m is not None else None,
                "dir_total": dir_total,
                "dir_wins": dir_wins,
                "dir_accuracy": round(dir_wins / dir_total * 100, 1) if dir_total > 0 else None,
            })

        # ── Confidence tiers ────────────────────────────────────────────
        cur.execute(f"""
            SELECT
                CASE
                    WHEN p.probability >= 70 THEN 'HIGH'
                    WHEN p.probability >= 55 THEN 'MED'
                    ELSE 'LOW'
                END AS tier,
                COUNT(*) AS total,
                SUM(CASE WHEN p.result = 'WIN' THEN 1 ELSE 0 END) AS wins,
                AVG(p.probability) AS avg_prob
            FROM predictions p
            JOIN games g ON p.game_pk = g.game_pk
            {where}
            GROUP BY 1
            ORDER BY MIN(p.probability) DESC
        """, params)
        confidence_tiers = []
        for r in cur.fetchall():
            total_t = r[1]
            wins_t = r[2]
            confidence_tiers.append({
                "tier": r[0],
                "total": total_t,
                "wins": wins_t,
                "accuracy": round(wins_t / total_t * 100, 1) if total_t > 0 else 0,
                "avg_prob": round(float(r[3] or 0), 1),
            })

        conn.close()
        return {
            "buckets": buckets,
            "bucket_size": bucket_size,
            "brier_score": brier,
            "log_loss": log_loss,
            "market_accuracy": market_accuracy,
            "confidence_tiers": confidence_tiers,
            "total_graded": len(rows),
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Error computing predictions calibration: {e}")


# ============================================================================
# USER NOTES ENDPOINTS
# ============================================================================

class UserNoteCreate(BaseModel):
    content: str
    author: Optional[str] = "user"

class UserNoteUpdate(BaseModel):
    content: str

@app.post("/api/notes")
async def create_note(note: UserNoteCreate):
    """Create a new note."""
    try:
        conn = _get_db_conn()
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO user_notes (content, author) VALUES (%s, %s) RETURNING id, created_at",
            (note.content, note.author)
        )
        row = cur.fetchone()
        conn.commit()
        conn.close()
        return {"id": row[0], "created_at": str(row[1])}
    except Exception as e:
        raise HTTPException(500, f"Error creating note: {e}")


@app.get("/api/notes")
async def list_notes(limit: int = 50, offset: int = 0):
    """List notes, most recent first."""
    try:
        conn = _get_db_conn()
        cur = conn.cursor()
        cur.execute(
            "SELECT id, content, author, created_at, updated_at FROM user_notes ORDER BY created_at DESC LIMIT %s OFFSET %s",
            (limit, offset)
        )
        rows = cur.fetchall()
        cur.execute("SELECT COUNT(*) FROM user_notes")
        total = cur.fetchone()[0]
        conn.close()
        notes = []
        for r in rows:
            notes.append({
                "id": r[0], "content": r[1], "author": r[2],
                "created_at": str(r[3]), "updated_at": str(r[4])
            })
        return {"notes": notes, "total": total}
    except Exception as e:
        raise HTTPException(500, f"Error listing notes: {e}")


@app.put("/api/notes/{note_id}")
async def update_note(note_id: int, note: UserNoteUpdate):
    """Update a note."""
    try:
        conn = _get_db_conn()
        cur = conn.cursor()
        cur.execute(
            "UPDATE user_notes SET content = %s WHERE id = %s RETURNING id",
            (note.content, note_id)
        )
        row = cur.fetchone()
        conn.commit()
        conn.close()
        if not row:
            raise HTTPException(404, f"Note {note_id} not found")
        return {"id": row[0], "status": "updated"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Error updating note: {e}")


@app.delete("/api/notes/{note_id}")
async def delete_note(note_id: int):
    """Delete a note."""
    try:
        conn = _get_db_conn()
        cur = conn.cursor()
        cur.execute("DELETE FROM user_notes WHERE id = %s RETURNING id", (note_id,))
        row = cur.fetchone()
        conn.commit()
        conn.close()
        if not row:
            raise HTTPException(404, f"Note {note_id} not found")
        return {"status": "deleted", "id": note_id}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Error deleting note: {e}")


# ============================================================================
# DIAMOND QUANT AI CHAT ENDPOINTS
# ============================================================================

def _generate_smart_title(user_prompt: str, chart_type: str, x_field: Optional[str], y_field: Optional[str], colnames: List[str]) -> str:
    """
    Generate a smart, concise title from user prompt and chart context.
    Examples:
    - "Show me a scatter plot of batting average vs OPS" → "Batting Average vs. OPS"
    - "Top 10 batters by H-Score" → "Top 10 Batters by H-Score"
    - "Which players have the highest hierarchical OPS?" → "Players by Hierarchical OPS"
    """
    # Import re locally to avoid any scoping issues with nested function calls
    import re as re_module
    
    prompt_lower = user_prompt.lower()
    
    # For scatter plots, extract the two metrics
    if chart_type == "scatter" and x_field and y_field:
        # Clean up field names
        x_clean = x_field.replace('_', ' ').title()
        y_clean = y_field.replace('_', ' ').title()
        # Handle common abbreviations
        x_clean = x_clean.replace('Ops', 'OPS').replace('Avg', 'Average').replace('Rbi', 'RBI').replace('Hr', 'HR')
        y_clean = y_clean.replace('Ops', 'OPS').replace('Avg', 'Average').replace('Rbi', 'RBI').replace('Hr', 'HR')
        return f"{x_clean} vs. {y_clean}"
    
    # For rankings/top N queries
    if any(word in prompt_lower for word in ['top', 'best', 'worst', 'highest', 'lowest', 'leaders']):
        # Extract the number if present
        num_match = re_module.search(r'\b(top|best|worst)\s+(\d+)', prompt_lower)
        if num_match:
            num = num_match.group(2)
            # Find the metric
            if y_field:
                metric = y_field.replace('_', ' ').title()
                metric = metric.replace('Ops', 'OPS').replace('Avg', 'Average').replace('H Score', 'H-Score')
                # Find the category (players, teams, etc.)
                if 'player' in prompt_lower or 'batter' in prompt_lower or 'pitcher' in prompt_lower:
                    category = "Players"
                elif 'team' in prompt_lower:
                    category = "Teams"
                else:
                    category = "Top"
                return f"Top {num} {category} by {metric}"
    
    # For "which players have X" queries
    if 'which' in prompt_lower or 'who' in prompt_lower:
        if y_field:
            metric = y_field.replace('_', ' ').title()
            metric = metric.replace('Ops', 'OPS').replace('Avg', 'Average').replace('H Score', 'H-Score')
            if 'player' in prompt_lower:
                return f"Players by {metric}"
            elif 'team' in prompt_lower:
                return f"Teams by {metric}"
    
    # For violin plot queries
    if 'violin' in prompt_lower or chart_type == "violin":
        metric = y_field.replace('_', ' ').title() if y_field else 'Value'
        metric = metric.replace('Ops', 'OPS').replace('Avg', 'Average').replace('Batting Average', 'Batting Avg')
        if 'position' in prompt_lower:
            return f"{metric} by Position"
        elif 'team' in prompt_lower:
            return f"{metric} by Team"
        elif x_field:
            cat = x_field.replace('_', ' ').title()
            return f"{metric} by {cat}"
        return f"{metric} Distribution"
    
    # For distribution queries
    if 'distribution' in prompt_lower or chart_type == "histogram":
        if x_field:
            metric = x_field.replace('_', ' ').title()
            metric = metric.replace('Ops', 'OPS').replace('Avg', 'Average')
            return f"Distribution of {metric}"
    
    # Default: clean up the prompt
    title = user_prompt.strip()
    # Remove common prefixes
    title = re_module.sub(r'^(show me|give me|what are|which|who has|who had|tell me about)\s+', '', title, flags=re_module.IGNORECASE)
    # Capitalize first letter
    if title:
        title = title[0].upper() + title[1:]
    # Truncate if too long
    if len(title) > 60:
        title = title[:57] + "..."
    
    return title


def build_chartspec_from_data(data: List[Dict], user_prompt: str, colnames: List[str]) -> Dict:
    """
    Build ChartSpec deterministically from SQL query results.
    No LLM needed - just analyze the data shape and user intent.
    
    Args:
        data: List of dictionaries from SQL query
        user_prompt: Original user question (used for title)
        colnames: Column names from query
        
    Returns:
        ChartSpec dictionary ready for rendering
    """
    if not data or not colnames:
        return None
    
    # Detect chart type from data shape and user prompt
    prompt_lower = user_prompt.lower()
    
    # Check for common chart keywords in prompt
    is_bar_request = any(w in prompt_lower for w in ['bar', 'compare', 'comparison'])
    is_ranking_request = any(w in prompt_lower for w in ['top', 'ranking', 'leaderboard', 'best', 'worst', 'leaders', 'highest', 'lowest'])
    is_line_request = any(w in prompt_lower for w in ['trend', 'over time', 'timeline', 'history', 'progression', 'season by season'])
    is_scatter_request = any(w in prompt_lower for w in ['scatter', 'correlation', 'relationship', 'vs', 'versus', 'plotted'])
    is_distribution_request = any(w in prompt_lower for w in ['distribution', 'histogram', 'spread', 'how many', 'breakdown', 'across'])
    is_violin_request = any(w in prompt_lower for w in ['violin', 'violin plot'])
    is_lollipop_request = any(w in prompt_lower for w in ['lollipop', 'dot'])
    is_table_request = any(w in prompt_lower for w in ['table', 'list', 'show all', 'data'])
    
    # Analyze data to find x and y fields
    first_row = data[0]
    
    # Categorize columns
    string_cols = []
    numeric_cols = []
    id_cols = []
    
    for col in colnames:
        val = first_row.get(col)
        col_lower = col.lower()
        
        # Skip ID columns for display but keep for headshots/logos
        if col_lower.endswith('_id') or col_lower == 'id':
            id_cols.append(col)
        elif isinstance(val, (int, float)) and val is not None:
            # Check if it's really an ID masquerading as numeric
            if col_lower.endswith('_id') or col_lower == 'id':
                id_cols.append(col)
            else:
                numeric_cols.append(col)
        elif isinstance(val, str):
            string_cols.append(col)
        else:
            # Handle None and other types
            string_cols.append(col)
    
    # Determine best chart type
    chart_type = "bar"  # Default
    
    if is_table_request or len(numeric_cols) == 0:
        chart_type = "table"
    elif is_scatter_request and len(numeric_cols) >= 2:
        # Scatter takes priority (user explicitly said "scatter" or "vs")
        chart_type = "scatter"
    elif is_violin_request and len(numeric_cols) >= 1:
        # Violin plot request - needs categorical x and numeric y
        chart_type = "violin"
    elif is_distribution_request and len(numeric_cols) >= 1:
        # Distribution request - use histogram for numeric spread
        chart_type = "histogram"
    elif is_lollipop_request:
        chart_type = "lollipop"
    elif is_ranking_request and len(data) <= 15:
        # Rankings with player names look better horizontal
        chart_type = "hbar"
    elif is_line_request and len(data) > 2:
        chart_type = "line"
    elif len(data) <= 20 and len(numeric_cols) >= 1:
        chart_type = "bar"
    elif len(data) > 20:
        chart_type = "table"  # Too many for chart
    
    # Determine x and y fields
    x_field = None
    y_field = None
    
    # For scatter plots, use two numeric columns
    if chart_type == "scatter" and len(numeric_cols) >= 2:
        x_field = numeric_cols[0]
        y_field = numeric_cols[1]
    else:
        # Look for common name patterns for x-axis (categorical)
        name_patterns = ['name', 'player', 'team', 'label', 'category', 'title']
        for col in string_cols:
            col_lower = col.lower()
            if any(p in col_lower for p in name_patterns):
                x_field = col
                break
        
        # Fallback to first string column
        if not x_field and string_cols:
            x_field = string_cols[0]
    
    # Look for common metric patterns for y-axis (numeric) - skip if already set for scatter
    if not y_field:  # Skip if already set (e.g., for scatter plots)
        metric_patterns = ['score', 'h_score', 'value', 'count', 'avg', 'sum', 'total', 'rate', 'pct', 'percentage']
        for col in numeric_cols:
            col_lower = col.lower()
            if any(p in col_lower for p in metric_patterns):
                y_field = col
                break
        
        # Fallback to first numeric column
        if not y_field and numeric_cols:
            y_field = numeric_cols[0]
    
    # Build smart title from user prompt and data
    title = _generate_smart_title(user_prompt, chart_type, x_field, y_field, colnames)
    
    # Check for player_id and team_abbr for headshots/logos
    has_player_id = 'player_id' in id_cols or any('player' in c.lower() and c.lower().endswith('_id') for c in id_cols)
    has_team = any('team' in c.lower() for c in colnames)
    
    # Build the ChartSpec
    chartspec = {
        "chart_type": chart_type,
        "title": title,
        "subtitle": f"Query returned {len(data)} rows",
        "data": data,
        "x_field": x_field,
        "y_field": y_field,
        "style": {
            "theme": "bloomberg_dark",
            "show_headshots": has_player_id,
            "show_logos": has_team
        },
        "trademark": "Diamond Quant AI - Joe Leonard"
    }
    
    return chartspec


# ============================================================================
# DIAMOND QUANT - LLM HELPER FUNCTIONS
# ============================================================================

def convert_sqlserver_to_postgres(sql: str) -> str:
    """Convert SQL Server syntax to PostgreSQL syntax."""
    # Get re module explicitly to avoid any scoping issues
    import re as re_module
    
    if not sql:
        return sql
    
    # Convert SELECT TOP N to SELECT ... LIMIT N
    top_match = re_module.search(r'SELECT\s+TOP\s+(\d+)\s+', sql, re_module.IGNORECASE)
    if top_match:
        n = top_match.group(1)
        # Remove TOP N from SELECT clause
        sql = re_module.sub(r'SELECT\s+TOP\s+\d+\s+', 'SELECT ', sql, flags=re_module.IGNORECASE)
        # Add LIMIT N at the end (before semicolon if present)
        if sql.rstrip().endswith(';'):
            sql = sql.rstrip()[:-1] + f' LIMIT {n};'
        else:
            sql = sql.rstrip() + f' LIMIT {n}'
        print(f"[DEBUG] Converted SQL Server TOP to PostgreSQL LIMIT", flush=True)
    
    return sql


def extract_sql_from_response(text: str) -> Optional[str]:
    """
    Extract SQL from LLM response that may contain verbose explanations.
    Handles code blocks, raw SQL, and messy outputs.
    """
    # Get re module explicitly to avoid any scoping issues
    import re as re_module
    
    if not text:
        return None
    
    # Method 1: Extract from ```sql ... ``` code blocks
    sql_block_match = re_module.search(r'```sql\s*(.*?)\s*```', text, re_module.DOTALL | re_module.IGNORECASE)
    if sql_block_match:
        sql = sql_block_match.group(1).strip()
        if sql.upper().startswith('SELECT'):
            return convert_sqlserver_to_postgres(sql)
    
    # Method 2: Extract from ``` ... ``` code blocks without language tag
    code_block_match = re_module.search(r'```\s*(SELECT.*?)\s*```', text, re_module.DOTALL | re_module.IGNORECASE)
    if code_block_match:
        sql = code_block_match.group(1).strip()
        return convert_sqlserver_to_postgres(sql)
    
    # Method 3: Find standalone SELECT statement
    # Match SELECT ... ; or SELECT ... (end of string)
    select_match = re_module.search(
        r'(SELECT\s+[\s\S]*?FROM\s+[\s\S]*?)(?:;|\n\n|$)', 
        text, 
        re_module.IGNORECASE
    )
    if select_match:
        sql = select_match.group(1).strip()
        # Clean up: remove trailing comments and incomplete clauses
        lines = []
        for line in sql.split('\n'):
            # Stop at lines that look like explanatory text
            if line.strip().startswith('--') and len(line) > 50:
                continue
            if any(word in line.lower() for word in ['note:', 'this will', 'however', 'assuming']):
                break
            lines.append(line)
        sql = '\n'.join(lines).strip()
        if sql.upper().startswith('SELECT'):
            # Ensure it ends with semicolon
            if not sql.endswith(';'):
                sql += ';'
            # Convert SQL Server syntax to PostgreSQL
            sql = convert_sqlserver_to_postgres(sql)
            return sql
    
    return None


def extract_json_from_response(text: str) -> Optional[dict]:
    """
    Extract JSON object from LLM response that may contain verbose explanations.
    """
    # Get re module explicitly to avoid any scoping issues
    import re as re_module
    import json
    
    if not text:
        return None
    
    # Method 1: Extract from ```json ... ``` code blocks
    json_block_match = re_module.search(r'```json\s*(.*?)\s*```', text, re_module.DOTALL | re_module.IGNORECASE)
    if json_block_match:
        try:
            return json.loads(json_block_match.group(1).strip())
        except json.JSONDecodeError:
            pass
    
    # Method 2: Find { ... } JSON object
    first_brace = text.find('{')
    last_brace = text.rfind('}')
    
    if first_brace != -1 and last_brace != -1 and last_brace > first_brace:
        try:
            json_str = text[first_brace:last_brace + 1]
            return json.loads(json_str)
        except json.JSONDecodeError:
            pass
    
    return None


def call_llm_with_fallback(
    prompt: str,
    use_local_ollama: bool,
    local_client,
    local_model: str,
    api_client=None,
    api_model: str = "deepseek-chat",
    max_tokens: int = 1024,
    temperature: float = 0.0,
    extract_type: str = "sql"  # "sql" or "json"
) -> tuple[str, bool]:
    """
    Call LLM with automatic fallback from local to API.
    
    Args:
        prompt: The prompt to send
        use_local_ollama: Whether to try local first
        local_client: OpenAI client configured for local Ollama
        local_model: Model name for local Ollama
        api_client: OpenAI client configured for DeepSeek API (optional)
        api_model: Model name for DeepSeek API
        max_tokens: Max tokens for response
        temperature: Temperature for generation
        extract_type: What to extract from response - "sql" or "json"
    
    Returns:
        Tuple of (extracted_content, used_api_fallback)
    """
    import traceback
    
    messages = [{"role": "user", "content": prompt}]
    
    def extract_response(response) -> Optional[str]:
        """Extract content from various response formats."""
        if not response or not response.choices or len(response.choices) == 0:
            return None
        
        choice = response.choices[0]
        content = None
        
        # Try message.content (OpenAI/Ollama standard)
        if hasattr(choice, 'message'):
            msg = choice.message
            if hasattr(msg, 'content'):
                content = msg.content
            elif isinstance(msg, dict):
                content = msg.get('content')
            
            # DeepSeek R1: check reasoning field if content is empty
            if not content:
                if hasattr(msg, 'reasoning'):
                    content = msg.reasoning
                elif isinstance(msg, dict):
                    content = msg.get('reasoning')
        
        # Try text field (some local models)
        if not content and hasattr(choice, 'text'):
            content = choice.text
        
        # Try dict access
        if not content and isinstance(choice, dict):
            msg = choice.get('message', {})
            content = msg.get('content') or msg.get('reasoning') or choice.get('text')
        
        return content
    
    def try_call(client, model: str, source: str) -> Optional[str]:
        """Try calling LLM and extracting content."""
        try:
            print(f"[DEBUG] Calling {source} with model: {model}", flush=True)
            response = client.chat.completions.create(
                model=model,
                messages=messages,
                max_tokens=max_tokens,
                temperature=temperature,
                top_p=0.1
            )
            
            content = extract_response(response)
            if not content:
                print(f"[DEBUG] {source} returned empty content", flush=True)
                return None
            
            print(f"[DEBUG] {source} response (first 300 chars): {content[:300]}", flush=True)
            
            # Check for "chatty" responses BEFORE extraction - these indicate model refusal or explanation
            chatty_patterns = [
                'as an ai', 'i cannot', 'i can\'t', 'i\'m unable', 'text model', 'graphical content', 
                'i apologize', 'i don\'t have access', 'as a text', 'to generate', 'you would need',
                'assuming that', 'however', 'here\'s how', 'here is how', 'let me', 'first,',
                'additional information', 'assuming', 'would need to', 'you can use',
                'sure, here', 'sample query', 'here is a', 'here\'s a', 'certainly', 'of course',
                'based on your', 'i would suggest', 'below is', 'following query'
            ]
            if any(pattern in content.lower()[:300] for pattern in chatty_patterns):
                print(f"[DEBUG] {source} returned chatty/explanation response - skipping", flush=True)
                return None  # Return None to trigger fallback
            
            # Also reject responses that contain invalid SQL syntax or wrong table/column names
            invalid_sql_patterns = [
                '//', '/*', 'playerID', 'games_stats', 'games_statistics',
                'Pitchers', 'Batters', 'FROM table', 'strikeout)', 'homers',
                'pitchers.', 'batters.', '-- assumes', '-- assuming', 'your table',
                'your database', 'your criteria'
            ]
            if extract_type == "sql" and any(pattern in content for pattern in invalid_sql_patterns):
                print(f"[DEBUG] {source} returned SQL with invalid patterns - skipping", flush=True)
                return None
            
            # Extract the specific type of content
            if extract_type == "sql":
                extracted = extract_sql_from_response(content)
                if extracted:
                    print(f"[DEBUG] Extracted SQL: {extracted[:200]}", flush=True)
                    return extracted
                else:
                    print(f"[DEBUG] Could not extract SQL from response", flush=True)
                    # Return raw content as fallback
                    return content
            elif extract_type == "json":
                extracted = extract_json_from_response(content)
                if extracted:
                    import json
                    return json.dumps(extracted)
                else:
                    print(f"[DEBUG] Could not extract JSON from response", flush=True)
                    return content
            else:
                return content
                
        except Exception as e:
            print(f"[ERROR] {source} call failed: {e}", flush=True)
            traceback.print_exc()
            return None
    
    # Try local first if enabled
    local_result = None
    if use_local_ollama and local_client:
        local_result = try_call(local_client, local_model, "Local Ollama")
        if local_result:
            # Validate the result
            if extract_type == "sql" and local_result.upper().strip().startswith('SELECT'):
                return local_result, False
            elif extract_type == "json":
                try:
                    import json
                    json.loads(local_result)
                    return local_result, False
                except:
                    pass  # Fall through to API
            elif extract_type == "raw":
                return local_result, False
    
    # Fallback to API if local failed or returned invalid result
    # Try Groq first, then DeepSeek
    if api_client:
        print(f"[DEBUG] Falling back to primary API", flush=True)
        result = try_call(api_client, api_model, "Primary API (Groq)")
        if result:
            return result, True
    
    # If primary API failed (e.g., rate limit), try secondary options
    import os
    from openai import OpenAI
    
    # Try a smaller Groq model first (separate rate limit)
    groq_key = os.getenv('GROQ_API_KEY')
    if groq_key and api_model == "llama-3.3-70b-versatile":
        print(f"[DEBUG] Primary Groq model failed, trying smaller Groq model", flush=True)
        try:
            groq_small_client = OpenAI(api_key=groq_key, base_url="https://api.groq.com/openai/v1")
            result = try_call(groq_small_client, "llama-3.1-8b-instant", "Groq (llama-3.1-8b)")
            if result:
                return result, True
        except Exception as e:
            print(f"[DEBUG] Groq smaller model also failed: {e}", flush=True)
    
    # Try DeepSeek if available
    deepseek_key = os.getenv('DEEPSEEK_API_KEY')
    if deepseek_key:
        print(f"[DEBUG] Trying DeepSeek as secondary fallback", flush=True)
        try:
            ds_client = OpenAI(api_key=deepseek_key, base_url="https://api.deepseek.com")
            result = try_call(ds_client, "deepseek-chat", "DeepSeek API")
            if result:
                return result, True
        except Exception as e:
            print(f"[ERROR] DeepSeek fallback failed: {e}", flush=True)
    
    # If both APIs failed, return the local result anyway (may contain partial SQL)
    if use_local_ollama and local_client:
        result = try_call(local_client, local_model, "Local Ollama (retry)")
        if result:
            return result, False
    
    raise Exception("Both local and API LLM calls failed")


def classify_query_source(
    user_message: str,
    conversation_context: Optional[List[Dict[str, Any]]] = None,
    use_local_ollama: bool = False,
    local_client=None,
    local_model: str = "deepseek-r1:7b",
    api_client=None,
    api_model: str = "deepseek-chat"
) -> Dict[str, Any]:
    """
    Classify which data source to use for a query:
    - "database" → Local Diamond Quant database (custom stats, hierarchical models)
    - "pybaseball" → MLB Stats API via pybaseball (official MLB data, current season)
    - "statmuse" → Complex stat queries requiring multi-source data
    - "hybrid" → Combine database and pybaseball results
    
    Returns dict with: source, confidence (0.0-1.0), reasoning
    """
    classification_prompt = f"""Classify this MLB query into the best data source.

User query: "{user_message}"

Available sources:
1. DATABASE - Local Diamond Quant database
   Use for: Our custom hierarchical stats (H-Score, player_hier_ops, player_hier_era), 
            game predictions, our proprietary metrics, historical game data we've collected
   Examples: "Top 10 batters by H-Score", "ERA distribution", "Our custom metrics",
            "Top players by hierarchical OPS", "Game predictions for today"

2. PYBASEBALL - MLB Stats API (official MLB data)
   Use for: Current season stats, official MLB player/team stats, recent games,
            live rosters, official MLB records, specific player seasons
   Examples: "Aaron Judge 2024 stats", "Current season home run leaders",
            "Show me Mike Trout's career stats", "Yankees 2024 team stats",
            "Who leads the league in RBIs this year"

3. STATMUSE - Complex stat queries (multi-source)
   Use for: Historical records, comparisons between players, "most X by Y" queries,
            complex aggregations, milestone queries, cross-season comparisons
   Examples: "Most home runs by a Yankee in a season", "Compare Trout to Griffey",
            "Players with 40+ HR and 100+ RBI in same season",
            "Best single season by a Dodger", "Historical records"

4. HYBRID - Combine multiple sources
   Use for: Comparing our custom metrics to official stats, combining our predictions
            with official data, cross-referencing sources
   Examples: "Compare our H-Score to official OPS", "Our predictions vs actual results"

Respond with ONLY valid JSON (no markdown, no code blocks):
{{
    "source": "database" | "pybaseball" | "statmuse" | "hybrid",
    "confidence": 0.0-1.0,
    "reasoning": "brief explanation"
}}"""

    try:
        result_json, _ = call_llm_with_fallback(
            prompt=classification_prompt,
            use_local_ollama=use_local_ollama,
            local_client=local_client,
            local_model=local_model,
            api_client=api_client,
            api_model=api_model,
            max_tokens=256,
            temperature=0.0,
            extract_type="json"
        )
        
        import json
        classification = json.loads(result_json)
        
        # Validate and normalize
        valid_sources = ["database", "pybaseball", "statmuse", "hybrid"]
        source = classification.get("source", "database").lower()
        if source not in valid_sources:
            source = "database"  # Safe fallback
        
        confidence = float(classification.get("confidence", 0.5))
        confidence = max(0.0, min(1.0, confidence))  # Clamp to 0-1
        
        # If confidence is low, default to database (safest)
        if confidence < 0.7:
            print(f"[DEBUG] Low confidence ({confidence}), defaulting to database", flush=True)
            source = "database"
            confidence = 0.5
        
        return {
            "source": source,
            "confidence": confidence,
            "reasoning": classification.get("reasoning", "Default classification")
        }
        
    except Exception as e:
        print(f"[WARNING] Query classification failed: {e}, defaulting to database", flush=True)
        # Safe fallback to database
        return {
            "source": "database",
            "confidence": 0.5,
            "reasoning": "Classification failed, using database as fallback"
        }


def detect_statmuse_pattern(query: str) -> Dict[str, Any]:
    """
    Detect StatMuse-style query patterns:
    - "Most X by Y" (e.g., "most home runs by a Yankee")
    - "Compare X to Y" (e.g., "compare Trout to Griffey")
    - "Players with X and Y" (e.g., "players with 40+ HR and 100+ RBI")
    - Historical records and milestones
    """
    query_lower = query.lower()
    
    patterns = {
        "most_by": {
            "keywords": ["most", "by"],
            "examples": ["most home runs by", "most wins by", "most rbis by"]
        },
        "compare": {
            "keywords": ["compare", "vs", "versus", "against"],
            "examples": ["compare", "vs", "versus"]
        },
        "players_with": {
            "keywords": ["players with", "who has", "who had"],
            "examples": ["players with", "who has", "who had"]
        },
        "historical": {
            "keywords": ["record", "all-time", "history", "ever", "single season"],
            "examples": ["record", "all-time", "history"]
        }
    }
    
    detected = []
    for pattern_name, pattern_info in patterns.items():
        if any(kw in query_lower for kw in pattern_info["keywords"]):
            detected.append(pattern_name)
    
    return {
        "is_statmuse": len(detected) > 0,
        "patterns": detected,
        "confidence": min(0.9, 0.5 + len(detected) * 0.2)
    }


async def execute_statmuse_query(
    query: str,
    conversation_context: Optional[List[Dict[str, Any]]] = None,
    use_local_ollama: bool = False,
    local_client=None,
    local_model: str = "deepseek-r1:7b",
    api_client=None,
    api_model: str = "deepseek-chat"
) -> Dict[str, Any]:
    """
    Execute StatMuse-style complex queries by:
    1. Parsing query intent
    2. Querying database for our custom stats
    3. Querying pybaseball for official MLB data
    4. Combining and ranking results
    5. Generating comprehensive answer
    """
    from pybaseball_helper import PybaseballQueryHandler
    
    # Build enhanced prompt for StatMuse-style queries
    statmuse_prompt = f"""You are a comprehensive baseball statistics expert. Answer this query with detailed, insightful information.

User Query: "{query}"

Provide a thorough answer that includes:
1. **Direct Answer**: Give the specific answer with exact numbers and player names
2. **Context**: Include relevant historical context, comparisons, or interesting facts
3. **Details**: Break down the statistics (e.g., "62 home runs in 2022, breaking Roger Maris's 61-year-old record")
4. **Comparisons**: When comparing players, provide side-by-side stats for key metrics
5. **Insights**: Add brief analysis or notable achievements related to the answer

Format your response in 2-4 paragraphs. Be specific with numbers, seasons, and player names.
Make it informative and engaging, like a sports analyst explaining the answer."""

    try:
        # Call LLM to generate the answer
        answer_text, _ = call_llm_with_fallback(
            prompt=statmuse_prompt,
            use_local_ollama=use_local_ollama,
            local_client=local_client,
            local_model=local_model,
            api_client=api_client,
            api_model=api_model,
            max_tokens=600,
            temperature=0.4
        )
        
        # Try to extract specific data points for visualization
        # This is a simplified version - in production, you'd want more sophisticated extraction
        data_points = []
        
        # For "most X by Y" queries, try to get actual data
        pattern_info = detect_statmuse_pattern(query)
        if "most_by" in pattern_info["patterns"]:
            # Extract stat and team/player from query
            # This is simplified - a full implementation would use NLP
            # For now, we'll return the text answer with minimal data
            pass
        
        return {
            "text": answer_text,
            "source": "statmuse",
            "data": data_points,
            "attribution": "Powered by StatMuse-style queries | Data from MLB Stats API via Pybaseball & Diamond Quant Database"
        }
        
    except Exception as e:
        print(f"[STATMUSE ERROR] Query execution failed: {e}", flush=True)
        return {
            "text": f"I encountered an error processing your StatMuse-style query: {str(e)}. Please try rephrasing your question.",
            "source": "statmuse",
            "data": [],
            "attribution": "Powered by StatMuse-style queries"
        }


# ============================================================================
# PREDICTION / SIMULATION FROM CHAT
# ============================================================================

# Map common team names/nicknames to DB abbreviations
TEAM_ALIASES = {
    "yankees": "NYY", "new york yankees": "NYY", "bronx bombers": "NYY", "nyy": "NYY",
    "red sox": "BOS", "boston red sox": "BOS", "boston": "BOS", "redsox": "BOS", "bos": "BOS",
    "dodgers": "LAD", "los angeles dodgers": "LAD", "la dodgers": "LAD", "lad": "LAD",
    "mets": "NYM", "new york mets": "NYM", "nym": "NYM",
    "cubs": "CHC", "chicago cubs": "CHC", "chc": "CHC",
    "white sox": "CWS", "chicago white sox": "CWS", "whitesox": "CWS", "cws": "CWS",
    "braves": "ATL", "atlanta braves": "ATL", "atl": "ATL",
    "phillies": "PHI", "philadelphia phillies": "PHI", "phi": "PHI", "phils": "PHI",
    "astros": "HOU", "houston astros": "HOU", "hou": "HOU", "stros": "HOU",
    "rangers": "TEX", "texas rangers": "TEX", "tex": "TEX",
    "cardinals": "STL", "st louis cardinals": "STL", "cards": "STL", "stl": "STL", "st. louis cardinals": "STL",
    "padres": "SD", "san diego padres": "SD", "sd": "SD",
    "giants": "SF", "san francisco giants": "SF", "sf": "SF",
    "angels": "LAA", "los angeles angels": "LAA", "la angels": "LAA", "laa": "LAA", "anaheim": "LAA",
    "mariners": "SEA", "seattle mariners": "SEA", "sea": "SEA",
    "rays": "TB", "tampa bay rays": "TB", "tb": "TB", "tampa": "TB",
    "blue jays": "TOR", "toronto blue jays": "TOR", "jays": "TOR", "tor": "TOR",
    "orioles": "BAL", "baltimore orioles": "BAL", "bal": "BAL",
    "twins": "MIN", "minnesota twins": "MIN", "min": "MIN",
    "guardians": "CLE", "cleveland guardians": "CLE", "cle": "CLE",
    "tigers": "DET", "detroit tigers": "DET", "det": "DET",
    "royals": "KC", "kansas city royals": "KC", "kc": "KC",
    "brewers": "MIL", "milwaukee brewers": "MIL", "mil": "MIL", "brew crew": "MIL",
    "reds": "CIN", "cincinnati reds": "CIN", "cin": "CIN",
    "pirates": "PIT", "pittsburgh pirates": "PIT", "pit": "PIT", "bucs": "PIT",
    "rockies": "COL", "colorado rockies": "COL", "col": "COL",
    "diamondbacks": "ARI", "arizona diamondbacks": "ARI", "dbacks": "ARI", "ari": "ARI", "d-backs": "ARI",
    "nationals": "WSH", "washington nationals": "WSH", "nats": "WSH", "wsh": "WSH",
    "marlins": "MIA", "miami marlins": "MIA", "mia": "MIA",
    "athletics": "OAK", "oakland athletics": "OAK", "a's": "OAK", "oak": "OAK", "ath": "OAK",
}

TEAM_ABBR_TO_DISPLAY = {
    "NYY": "Yankees", "BOS": "Red Sox", "LAD": "Dodgers", "NYM": "Mets",
    "CHC": "Cubs", "CWS": "White Sox", "ATL": "Braves", "PHI": "Phillies",
    "HOU": "Astros", "TEX": "Rangers", "STL": "Cardinals", "SD": "Padres",
    "SF": "Giants", "LAA": "Angels", "SEA": "Mariners", "TB": "Rays",
    "TOR": "Blue Jays", "BAL": "Orioles", "MIN": "Twins", "CLE": "Guardians",
    "DET": "Tigers", "KC": "Royals", "MIL": "Brewers", "CIN": "Reds",
    "PIT": "Pirates", "COL": "Rockies", "ARI": "Diamondbacks", "WSH": "Nationals",
    "MIA": "Marlins", "OAK": "Athletics",
}

PREDICTION_PATTERNS = [
    r'\bpredict\b', r'\bprediction\b', r'\bforecast\b', r'\bproject(?:ion|ed)?\b',
    r'\bhow many\b.*\b(?:hits?|home ?runs?|hrs?|rbis?|strikeouts?|runs?|stolen bases?)\b',
    r'\b(?:hits?|home ?runs?|hrs?|rbis?|strikeouts?|runs?|stolen bases?)\b.*\bget\b',
    r'\bwill.*(?:get|have|record|score|hit)\b',
    r'\bscore\b.*(?:prediction|predict|projected|of the|of the game|between|vs|versus)',
    r'(?:vs|versus|against|playing).*(?:score|win|prediction|predict)',
    r'\bwho\s+(?:will\s+)?win\b', r'\bwin probability\b', r'\bmoneyline\b',
    r'\bover\s*/?\s*under\b', r'\bo/u\b', r'\btotal runs\b',
    r'\bgoing to (?:get|score|hit|have)\b',
    r'\bsimulat(?:e|ion)\b.*(?:game|matchup|today)',
    r'\b(?:game|matchup)\b.*\bsimulat(?:e|ion)\b',
    # Multi-game parlay / odds patterns
    r'\bodds\b.*\bwin\b', r'\bwin\b.*\bodds\b',
    r'\bparlay\b', r'\bboth\s+win\b', r'\bcombined\s+odds\b',
    r'\bodds\b.*\b(?:and|&)\b.*\b(?:win|ml|moneyline)\b',
]

STAT_KEYWORDS = {
    "hits": "hits", "hit": "hits",
    "home runs": "home_runs", "home run": "home_runs", "homers": "home_runs",
    "hr": "home_runs", "hrs": "home_runs", "dingers": "home_runs",
    "rbis": "rbis", "rbi": "rbis", "runs batted in": "rbis",
    "runs": "runs", "run": "runs", "runs scored": "runs",
    "strikeouts": "strikeouts", "strikeout": "strikeouts", "ks": "strikeouts", "k's": "strikeouts",
    "total bases": "total_bases", "tb": "total_bases",
    "stolen bases": "stolen_bases", "steals": "stolen_bases", "sb": "stolen_bases",
    "score": "score", "final score": "score", "game score": "score",
}


def is_prediction_query(message: str) -> bool:
    """Check if a chat message is asking for a game/player prediction."""
    lower = message.lower()
    has_team = any(alias in lower for alias in TEAM_ALIASES.keys() if len(alias) > 2)
    has_vs = any(kw in lower for kw in ['vs', 'versus', 'against', 'playing', 'matchup', 'game'])
    has_prediction_keyword = any(re.search(p, lower) for p in PREDICTION_PATTERNS)
    has_player_stat = bool(re.search(
        r'\b(?:how many|will|predict|project)\b.*\b(?:hits?|home ?runs?|hrs?|rbis?|strikeouts?|runs?|total bases|stolen bases)\b',
        lower
    ))
    has_parlay = any(kw in lower for kw in ['parlay', 'sgp', 'combined odds'])
    return (has_prediction_keyword and (has_team or has_vs or has_player_stat)) or (has_parlay and has_team)


def resolve_team_abbr(name: str) -> Optional[str]:
    """Resolve a team name/nickname to its abbreviation."""
    lower = name.lower().strip()
    if lower in TEAM_ALIASES:
        return TEAM_ALIASES[lower]
    for alias, abbr in TEAM_ALIASES.items():
        if alias in lower or lower in alias:
            return abbr
    return None


def parse_prediction_intent_local(message: str) -> dict:
    """Parse a prediction query locally (no LLM) using regex/keywords."""
    lower = message.lower()
    intent = {
        "type": "game",
        "teams": [],
        "player": None,
        "stat": "score",
        "date_str": "today",
    }
    
    # Extract teams (longest alias first to match multi-word names)
    found_teams = []
    sorted_aliases = sorted(TEAM_ALIASES.keys(), key=len, reverse=True)
    remaining = lower
    for alias in sorted_aliases:
        if len(alias) <= 2:
            continue
        if alias in remaining:
            abbr = TEAM_ALIASES[alias]
            if abbr not in found_teams:
                found_teams.append(abbr)
                remaining = remaining.replace(alias, '', 1)
            if len(found_teams) >= 2:
                break
    intent["teams"] = found_teams
    
    # Detect date early (needed before multi_parlay early return)
    if 'tomorrow' in lower:
        intent["date_str"] = "tomorrow"
    elif 'today' in lower or 'tonight' in lower:
        intent["date_str"] = "today"
    else:
        _dm = re.search(r'(\d{4}-\d{2}-\d{2})', lower)
        if _dm:
            intent["date_str"] = _dm.group(1)
        else:
            _dm = re.search(r'(\d{1,2}/\d{1,2}(?:/\d{2,4})?)', lower)
            if _dm:
                intent["date_str"] = _dm.group(1)
            else:
                intent["date_str"] = "next"
    
    # Detect multi-game parlay: 2+ teams, no "vs/versus/against", and parlay/odds/win keywords
    has_vs = any(kw in lower for kw in ['vs ', 'versus', 'against', 'playing', 'matchup', ' @ '])
    has_parlay_indicator = any(kw in lower for kw in ['parlay', 'both', 'combined odds', 'combined', 'sgp'])
    has_and_win = bool(re.search(r'\b(?:and|&)\b', lower) and re.search(r'\b(?:win|ml|moneyline)\b', lower))
    has_odds_win = bool(re.search(r'\bodds\b', lower) and re.search(r'\bwin\b', lower))
    if len(found_teams) >= 2 and not has_vs and (has_parlay_indicator or has_and_win or has_odds_win):
        intent["type"] = "multi_parlay"
        intent["stat"] = "win"
        return intent  # No need to parse player names etc.
    
    # Detect stat type
    for kw, stat in sorted(STAT_KEYWORDS.items(), key=lambda x: len(x[0]), reverse=True):
        if kw in lower:
            intent["stat"] = stat
            break
    
    # Detect player name
    # Stop words that should never be captured as player names
    _stop_words = {
        'the', 'a', 'an', 'is', 'are', 'will', 'going', 'to', 'get', 'have',
        'record', 'score', 'hit', 'many', 'how', 'predict', 'project', 'his',
        'her', 'their', 'next', 'game', 'today', 'tonight', 'tomorrow', 'in',
        'for', 'about', 'this', 'that', 'no', 'yes', 'does', 'do', 'can',
    }
    _common_phrases = {
        'the game', 'this game', 'today game', 'the score', 'final score',
        'total runs', 'how many', 'will get', 'going to', 'i think',
        'next game', 'his next', 'their next',
    }
    
    # Name suffixes that should keep their original casing
    _suffixes = {'jr', 'jr.', 'sr', 'sr.', 'ii', 'iii', 'iv', 'v'}
    _suffix_canonical = {
        'jr': 'Jr.', 'jr.': 'Jr.', 'sr': 'Sr.', 'sr.': 'Sr.',
        'ii': 'II', 'iii': 'III', 'iv': 'IV', 'v': 'V',
    }
    # Regex fragment for optional suffix (trailing \.? consumes period after Jr./Sr.)
    _sfx = r'(?:\s+(?:Jr\.?|Sr\.?|II|III|IV|V))?\.?'
    _sfx_ci = r'(?:\s+(?:jr\.?|sr\.?|ii|iii|iv|v))?\.?'
    
    def _clean_player_name(candidate: str) -> Optional[str]:
        """Clean and validate a candidate player name."""
        candidate = candidate.strip().rstrip('.')
        if not candidate or candidate.lower() in _common_phrases:
            return None
        # Remove leading/trailing stop words but preserve suffixes
        words = candidate.split()
        cleaned = []
        for w in words:
            wl = w.lower().rstrip('.')
            if wl in _suffixes:
                cleaned.append(_suffix_canonical.get(w.lower().rstrip('.') + ('.' if w.endswith('.') else ''),
                              _suffix_canonical.get(wl, w)))
            elif wl not in _stop_words:
                cleaned.append(w)
        if not cleaned:
            return None
        # Title-case everything except suffixes
        result_parts = []
        for w in cleaned:
            if w in _suffix_canonical.values():
                result_parts.append(w)
            else:
                result_parts.append(w.title())
        result = ' '.join(result_parts)
        if len(result) < 3:
            return None
        if resolve_team_abbr(result):
            return None
        return result
    
    player_patterns = [
        # "is Shohei Ohtani going to get" / "will Fernando Tatis Jr. get"
        r'(?:is|will)\s+((?:[A-Z][a-z]+\s+){1,2}[A-Z][a-z]+' + _sfx + r')\s+(?:going to|gonna|expected to|projected to|going|get|have)',
        # "how many hits will Shohei Ohtani get"
        r'(?:hits?|home ?runs?|hrs?|rbis?|strikeouts?|runs?|total bases|stolen bases)\s+(?:will|is|for)\s+((?:\w+\s+){1,2}\w+?' + _sfx + r')(?:\s+(?:get|have|record|going|gonna|expected|today|tonight|tomorrow|in\b))',
        # "Shohei Ohtani hits prediction" / "Ronald Acuna Jr. hits"
        r'((?:[A-Z][a-z]+\s+){1,2}[A-Z][a-z]+' + _sfx + r')(?:\'s)?\s+(?:hits?|home ?runs?|hrs?|rbis?|strikeouts?|runs?|total bases|stolen bases)',
        # "predict Shohei Ohtani" / "prediction for Fernando Tatis Jr."
        r'(?:predict|prediction|project|projection|forecast)\s+(?:for\s+)?((?:[A-Z][a-z]+\s+){1,2}[A-Z][a-z]+' + _sfx + r')',
        # Fallback: "for/about [Name]"
        r'(?:for|about)\s+((?:[A-Z][a-z]+\s+){1,2}[A-Z][a-z]+' + _sfx + r')',
    ]
    # Also try case-insensitive versions
    player_patterns_ci = [
        # "is shohei ohtani going to" / "will vlad guerrero jr get"
        r'(?:is|will)\s+(\w+(?:\s+\w+)?' + _sfx_ci + r')\s+(?:going to|gonna|expected to|projected to)\s+(?:get|have|record|score|hit)',
        # "how many [stat] will [name] get"
        r'(?:hits?|home ?runs?|hrs?|rbis?|strikeouts?|runs?|total bases|stolen bases)\s+(?:will|is|for|does)\s+(\w+(?:\s+\w+)?' + _sfx_ci + r')\s+(?:get|have|record|going|today)',
        # "[stat] [name] will get" — e.g. "hits shohei will get"
        r'(?:hits?|home ?runs?|hrs?|rbis?|strikeouts?|runs?|total bases|stolen bases)\s+(\w+(?:\s+\w+)?' + _sfx_ci + r')\s+(?:will|is going to|gonna)\s+(?:get|have|record)',
        # "[name]'s hits" / "[name] hits prediction"
        r'(\w+(?:\s+\w+)?' + _sfx_ci + r')(?:\'s)?\s+(?:hits?|home ?runs?|hrs?|rbis?|strikeouts?|runs?|total bases|stolen bases)\s*(?:prediction|projection|forecast|today|tonight)?',
        # TRUNCATED: "how many [stat] will [name]" (no trailing verb — name at end of message)
        r'(?:hits?|home ?runs?|hrs?|rbis?|strikeouts?|runs?|total bases|stolen bases)\s+(?:will|for|does|is)\s+(\w+\s+\w+' + _sfx_ci + r')\s*$',
        # TRUNCATED: "will [name] get" but also "will [name]$" (name at end)
        r'\bwill\s+(\w+\s+\w+' + _sfx_ci + r')\s*$',
        # "for/about [name]"
        r'(?:for|about)\s+(\w+(?:\s+\w+)?' + _sfx_ci + r')',
    ]
    
    # Try case-sensitive patterns first (better at finding proper names)
    found_player = None
    for pattern in player_patterns:
        match = re.search(pattern, message)
        if match:
            cleaned = _clean_player_name(match.group(1))
            if cleaned:
                found_player = cleaned
                break
    
    # Fallback to case-insensitive patterns
    if not found_player:
        for pattern in player_patterns_ci:
            match = re.search(pattern, lower)
            if match:
                cleaned = _clean_player_name(match.group(1))
                if cleaned:
                    found_player = cleaned
                    break
    
    if found_player:
        intent["type"] = "player"
        intent["player"] = found_player
    
    # Date was already detected above (before multi_parlay check)
    return intent


def find_game_for_teams(cur, team_abbrs: list, date_str: str = "today") -> Optional[dict]:
    """Find a game in the database matching the given teams and date."""
    from datetime import datetime, timedelta
    
    if not team_abbrs or len(team_abbrs) < 1:
        return None
    
    if date_str in ("today", "tonight"):
        target_date = datetime.now().strftime("%Y-%m-%d")
    elif date_str == "tomorrow":
        target_date = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
    elif date_str == "next":
        target_date = None
    else:
        try:
            if '/' in date_str:
                parts = date_str.split('/')
                if len(parts) == 2:
                    month, day = parts
                    year = datetime.now().year
                    target_date = f"{year}-{int(month):02d}-{int(day):02d}"
                else:
                    month, day, year = parts
                    if len(year) == 2:
                        year = f"20{year}"
                    target_date = f"{int(year)}-{int(month):02d}-{int(day):02d}"
            else:
                target_date = date_str
        except:
            target_date = datetime.now().strftime("%Y-%m-%d")
    
    # Resolve team IDs
    team_ids = []
    for abbr in team_abbrs[:2]:
        cur.execute("SELECT team_id, name, abbreviation FROM teams WHERE UPPER(abbreviation) = UPPER(%s) LIMIT 1", (abbr,))
        row = cur.fetchone()
        if row:
            team_ids.append({"team_id": row[0], "name": row[1], "abbr": row[2]})
    
    if len(team_ids) < 1:
        return None
    
    if len(team_ids) == 2:
        if target_date:
            cur.execute("""
                SELECT g.game_pk, g.game_date, g.home_team_id, g.away_team_id,
                       t1.abbreviation as home_abbr, t1.name as home_name,
                       t2.abbreviation as away_abbr, t2.name as away_name, g.venue_name
                FROM games g
                JOIN teams t1 ON g.home_team_id = t1.team_id
                JOIN teams t2 ON g.away_team_id = t2.team_id
                WHERE g.game_date = %s AND g.game_type IN ('R', 'S', 'E')
                  AND ((g.home_team_id = %s AND g.away_team_id = %s)
                    OR (g.home_team_id = %s AND g.away_team_id = %s))
                ORDER BY g.game_pk LIMIT 1
            """, (target_date, team_ids[0]["team_id"], team_ids[1]["team_id"],
                  team_ids[1]["team_id"], team_ids[0]["team_id"]))
        else:
            cur.execute("""
                SELECT g.game_pk, g.game_date, g.home_team_id, g.away_team_id,
                       t1.abbreviation as home_abbr, t1.name as home_name,
                       t2.abbreviation as away_abbr, t2.name as away_name, g.venue_name
                FROM games g
                JOIN teams t1 ON g.home_team_id = t1.team_id
                JOIN teams t2 ON g.away_team_id = t2.team_id
                WHERE g.game_date >= %s AND g.game_type IN ('R', 'S', 'E')
                  AND ((g.home_team_id = %s AND g.away_team_id = %s)
                    OR (g.home_team_id = %s AND g.away_team_id = %s))
                ORDER BY g.game_date ASC, g.game_pk LIMIT 1
            """, (datetime.now().strftime("%Y-%m-%d"),
                  team_ids[0]["team_id"], team_ids[1]["team_id"],
                  team_ids[1]["team_id"], team_ids[0]["team_id"]))
    else:
        tid = team_ids[0]["team_id"]
        if target_date:
            cur.execute("""
                SELECT g.game_pk, g.game_date, g.home_team_id, g.away_team_id,
                       t1.abbreviation as home_abbr, t1.name as home_name,
                       t2.abbreviation as away_abbr, t2.name as away_name, g.venue_name
                FROM games g
                JOIN teams t1 ON g.home_team_id = t1.team_id
                JOIN teams t2 ON g.away_team_id = t2.team_id
                WHERE g.game_date = %s AND g.game_type IN ('R', 'S', 'E')
                  AND (g.home_team_id = %s OR g.away_team_id = %s)
                ORDER BY g.game_pk LIMIT 1
            """, (target_date, tid, tid))
        else:
            cur.execute("""
                SELECT g.game_pk, g.game_date, g.home_team_id, g.away_team_id,
                       t1.abbreviation as home_abbr, t1.name as home_name,
                       t2.abbreviation as away_abbr, t2.name as away_name, g.venue_name
                FROM games g
                JOIN teams t1 ON g.home_team_id = t1.team_id
                JOIN teams t2 ON g.away_team_id = t2.team_id
                WHERE g.game_date >= %s AND g.game_type IN ('R', 'S', 'E')
                  AND (g.home_team_id = %s OR g.away_team_id = %s)
                ORDER BY g.game_date ASC, g.game_pk LIMIT 1
            """, (datetime.now().strftime("%Y-%m-%d"), tid, tid))
    
    row = cur.fetchone()
    if not row:
        return None
    return {
        "game_pk": row[0], "game_date": str(row[1]),
        "home_team_id": row[2], "away_team_id": row[3],
        "home_abbr": row[4], "home_name": row[5],
        "away_abbr": row[6], "away_name": row[7], "venue": row[8],
    }


def assemble_lineup_for_sim(cur, game_pk: int, home_team_id: int, away_team_id: int) -> dict:
    """Assemble lineups with fallback: confirmed → rotowire expected → rotowire defaults.
    Also handles partial lineups (SP only, batters from defaults)."""
    # Check for real (non-default) data to correctly detect partial lineups
    cur.execute("""
        SELECT COUNT(*) FROM pregame_lineups 
        WHERE game_pk = %s AND source IS DISTINCT FROM 'rotowire_default'
    """, (game_pk,))
    has_real_batters = cur.fetchone()[0] > 0
    
    cur.execute("""
        SELECT COUNT(*) FROM pregame_pitchers 
        WHERE game_pk = %s AND source IS DISTINCT FROM 'rotowire_default'
    """, (game_pk,))
    has_real_pitchers = cur.fetchone()[0] > 0
    
    # Also check if any rows exist at all (including gap-filled defaults)
    cur.execute("SELECT COUNT(*) FROM pregame_lineups WHERE game_pk = %s LIMIT 1", (game_pk,))
    has_any_batters = cur.fetchone()[0] > 0
    cur.execute("SELECT COUNT(*) FROM pregame_pitchers WHERE game_pk = %s LIMIT 1", (game_pk,))
    has_any_pitchers = cur.fetchone()[0] > 0
    
    is_partial = has_real_pitchers and not has_real_batters
    use_defaults = not has_real_batters and not has_real_pitchers
    has_game_batters = has_any_batters
    has_game_pitchers = has_any_pitchers
    lineup_source = "confirmed"
    
    if use_defaults or is_partial:
        lineup_source = "partial" if is_partial else "rotowire_default"
        # Use default batters
        cur.execute("""
            SELECT rdl.team_id, rdl.batting_order, rdl.player_id, rdl.position,
                   COALESCE(p.full_name, 'Unknown') as player_name
            FROM rotowire_default_lineups rdl
            LEFT JOIN players p ON rdl.player_id = p.player_id
            WHERE rdl.team_id IN (%s, %s) AND rdl.lineup_type = 'vs_rhp'
            ORDER BY rdl.team_id, rdl.batting_order
        """, (away_team_id, home_team_id))
        lineup_rows = cur.fetchall()
        if len(lineup_rows) < 18:
            cur.execute("""
                SELECT rdl.team_id, rdl.batting_order, rdl.player_id, rdl.position,
                       COALESCE(p.full_name, 'Unknown') as player_name
                FROM rotowire_default_lineups rdl
                LEFT JOIN players p ON rdl.player_id = p.player_id
                WHERE rdl.team_id IN (%s, %s) AND rdl.lineup_type = 'vs_lhp'
                ORDER BY rdl.team_id, rdl.batting_order
            """, (away_team_id, home_team_id))
            lineup_rows = cur.fetchall()
        # Use game-specific pitchers if available (partial), otherwise defaults
        if is_partial:
            cur.execute("""
                SELECT pp.team_id, pp.player_id,
                       COALESCE(p.full_name, 'Unknown Pitcher') as player_name
                FROM pregame_pitchers pp
                LEFT JOIN players p ON pp.player_id = p.player_id
                WHERE pp.game_pk = %s LIMIT 2
            """, (game_pk,))
            pitcher_rows = cur.fetchall()
        else:
            cur.execute("""
                SELECT rdp.team_id, rdp.player_id,
                       COALESCE(p.full_name, 'Unknown Pitcher') as player_name
                FROM rotowire_default_pitchers rdp
                LEFT JOIN players p ON rdp.player_id = p.player_id
                WHERE rdp.team_id IN (%s, %s) AND rdp.rotation_spot = 1
            """, (away_team_id, home_team_id))
            pitcher_rows = cur.fetchall()
    else:
        cur.execute("""
            SELECT DISTINCT COALESCE(source, 'mlb_api'), COALESCE(lineup_status, 'confirmed')
            FROM pregame_lineups WHERE game_pk = %s LIMIT 5
        """, (game_pk,))
        source_rows = cur.fetchall()
        statuses = set(r[1] for r in source_rows)
        sources = set(r[0] for r in source_rows)
        if 'confirmed' in statuses:
            lineup_source = "confirmed"
        elif 'rotowire' in str(sources):
            lineup_source = "rotowire_expected"
        else:
            lineup_source = "projected"
        
        cur.execute("""
            SELECT pl.team_id, pl.batting_order, pl.player_id, pl.position,
                   COALESCE(p.full_name, 'Unknown') as player_name
            FROM pregame_lineups pl
            LEFT JOIN players p ON pl.player_id = p.player_id
            WHERE pl.game_pk = %s ORDER BY pl.team_id, pl.batting_order LIMIT 18
        """, (game_pk,))
        lineup_rows = cur.fetchall()
        cur.execute("""
            SELECT pp.team_id, pp.player_id,
                   COALESCE(p.full_name, 'Unknown Pitcher') as player_name
            FROM pregame_pitchers pp
            LEFT JOIN players p ON pp.player_id = p.player_id
            WHERE pp.game_pk = %s LIMIT 2
        """, (game_pk,))
        pitcher_rows = cur.fetchall()
        if not pitcher_rows:
            cur.execute("""
                SELECT rdp.team_id, rdp.player_id,
                       COALESCE(p.full_name, 'Unknown Pitcher') as player_name
                FROM rotowire_default_pitchers rdp
                LEFT JOIN players p ON rdp.player_id = p.player_id
                WHERE rdp.team_id IN (%s, %s) AND rdp.rotation_spot = 1
            """, (away_team_id, home_team_id))
            pitcher_rows = cur.fetchall()
            if pitcher_rows:
                lineup_source += "+default_pitchers"
    
    home_lineup, away_lineup = {}, {}
    for team_id, batting_order, player_id, position, player_name in lineup_rows:
        entry = {"name": player_name, "position": position or "DH", "player_id": player_id}
        if team_id == home_team_id:
            home_lineup[str(batting_order)] = entry
        else:
            away_lineup[str(batting_order)] = entry
    
    # Rust sim REQUIRES exactly 9 batters per team (fixed [u32; 9] arrays).
    # Pad any missing slots with a placeholder batter (player_id 0).
    def _pad_lineup(lineup: dict) -> dict:
        if len(lineup) == 0:
            return {str(i): {"name": "Unknown", "position": "DH", "player_id": 0} for i in range(1, 10)}
        for slot in range(1, 10):
            if str(slot) not in lineup:
                # Copy the last known batter as a fill-in
                last_known = lineup.get(str(slot - 1)) or list(lineup.values())[-1]
                lineup[str(slot)] = {
                    "name": last_known["name"],
                    "position": "DH",
                    "player_id": last_known["player_id"],
                }
        return lineup
    
    home_lineup = _pad_lineup(home_lineup)
    away_lineup = _pad_lineup(away_lineup)
    print(f"[PREDICTION] Lineup sizes: home={len(home_lineup)}, away={len(away_lineup)}", flush=True)
    
    home_pitcher = {"name": "TBD", "player_id": 0}
    away_pitcher = {"name": "TBD", "player_id": 0}
    for team_id, player_id, player_name in pitcher_rows:
        if team_id == home_team_id:
            home_pitcher = {"name": player_name, "player_id": player_id}
        else:
            away_pitcher = {"name": player_name, "player_id": player_id}
    
    return {
        "home_lineup": home_lineup, "away_lineup": away_lineup,
        "home_pitcher": home_pitcher, "away_pitcher": away_pitcher,
        "lineup_source": lineup_source,
    }


def run_prediction_simulation(game_info: dict, lineups: dict, num_sims: int = 10000) -> Optional[dict]:
    """Run fast_json_sim for a prediction query and return parsed JSON results."""
    import tempfile
    game_data = {
        "game_pk": game_info["game_pk"], "game_date": game_info["game_date"],
        "home_team_id": game_info["home_team_id"], "away_team_id": game_info["away_team_id"],
        "home_lineup": lineups["home_lineup"], "away_lineup": lineups["away_lineup"],
        "home_pitcher": lineups["home_pitcher"], "away_pitcher": lineups["away_pitcher"],
    }
    # Validate lineups have exactly 9 batters each
    home_count = len(game_data["home_lineup"])
    away_count = len(game_data["away_lineup"])
    print(f"[PREDICTION] JSON lineup sizes: home={home_count}, away={away_count}, "
          f"home_keys={sorted(game_data['home_lineup'].keys())}, "
          f"away_keys={sorted(game_data['away_lineup'].keys())}", flush=True)
    if home_count != 9 or away_count != 9:
        print(f"[PREDICTION] ERROR: Need exactly 9 batters per team! Got home={home_count}, away={away_count}", flush=True)
        return None
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump(game_data, f)
        temp_path = f.name
    try:
        sim_binary = PROJECT_ROOT / "target" / "release" / "fast_json_sim"
        if not sim_binary.exists():
            print(f"[PREDICTION] Simulation binary not found at {sim_binary}", flush=True)
            return None
        cmd = [str(sim_binary), temp_path, str(num_sims), "--json", "--sgp"]
        print(f"[PREDICTION] Running: {' '.join(cmd)}", flush=True)
        result = subprocess.run(cmd, cwd=PROJECT_ROOT, capture_output=True, text=True, timeout=120)
        if result.returncode != 0:
            print(f"[PREDICTION] Sim failed: {result.stderr[:500]}", flush=True)
            return None
        sim_results = json.loads(result.stdout)
        print(f"[PREDICTION] Simulation complete: {num_sims} sims", flush=True)
        return sim_results
    except Exception as e:
        print(f"[PREDICTION] Error: {e}", flush=True)
        return None
    finally:
        try:
            os.unlink(temp_path)
        except:
            pass


def find_player_in_results(sim_results: dict, player_name: str) -> Optional[dict]:
    """Find a specific player in simulation results by fuzzy name match."""
    if not player_name or not sim_results:
        return None
    search = player_name.lower().strip()
    for i, batter in enumerate(sim_results.get("top_batters_home", [])):
        bname = batter.get("name", "").lower()
        if search in bname or bname in search or search.split()[-1] in bname.split():
            return {**batter, "team_side": "home", "lineup_pos": i + 1}
    for i, batter in enumerate(sim_results.get("top_batters_away", [])):
        bname = batter.get("name", "").lower()
        if search in bname or bname in search or search.split()[-1] in bname.split():
            return {**batter, "team_side": "away", "lineup_pos": i + 1}
    for key, side in [("home_starting_pitcher", "home"), ("away_starting_pitcher", "away")]:
        p = sim_results.get(key, {})
        pname = p.get("name", "").lower()
        if search in pname or (pname and pname.split()[-1] in search.split()):
            return {**p, "is_pitcher": True, "team_side": side}
    return None


def _prob_to_odds(pct: float) -> str:
    """Convert a probability percentage (0-100) to American odds string."""
    if pct <= 0:
        return "+9999"
    if pct >= 100:
        return "-9999"
    if pct >= 50:
        return f"-{round((pct / (100 - pct)) * 100)}"
    else:
        return f"+{round(((100 - pct) / pct) * 100)}"


# ─── SGP (Same-Game Parlay) Support ──────────────────────────────────
# Server-side cache: chat_id → prediction context for SGP follow-ups
_prediction_cache = {}

# Maps user-facing stat names to SGP cache array keys
_SGP_BATTER_STATS = {
    "hits": "batter_hits", "hit": "batter_hits",
    "home_runs": "batter_hrs", "hr": "batter_hrs", "hrs": "batter_hrs",
    "home run": "batter_hrs", "home runs": "batter_hrs",
    "homer": "batter_hrs", "homers": "batter_hrs",
    "dinger": "batter_hrs", "dingers": "batter_hrs",
    "total_bases": "batter_total_bases", "total bases": "batter_total_bases",
    "tb": "batter_total_bases", "tbs": "batter_total_bases",
    "rbis": "batter_rbis", "rbi": "batter_rbis",
    "runs": "batter_runs", "run": "batter_runs", "runs scored": "batter_runs",
    "strikeouts": "batter_strikeouts", "ks": "batter_strikeouts", "k": "batter_strikeouts",
    "stolen_bases": "batter_stolen_bases", "stolen bases": "batter_stolen_bases",
    "sb": "batter_stolen_bases", "steals": "batter_stolen_bases", "steal": "batter_stolen_bases",
}
_SGP_PITCHER_STATS = {
    "strikeouts": "pitcher_ks", "ks": "pitcher_ks", "k": "pitcher_ks",
    "hits_allowed": "pitcher_hits_allowed", "hits allowed": "pitcher_hits_allowed",
}

# ─── Betting slang → (stat_key, implied_line) ────────────────────────────────
# If a phrase appears with NO explicit number, we know the line.
# e.g. "to get a hit" → hits, 0.5  (means 1+)
# e.g. "go yard" → home_runs, 0.5  (means 1+ HR)
_BETTING_SLANG = {
    "go yard":       ("home_runs", 0.5),
    "goes yard":     ("home_runs", 0.5),
    "go deep":       ("home_runs", 0.5),
    "goes deep":     ("home_runs", 0.5),
    "hit a homer":   ("home_runs", 0.5),
    "hit a home run": ("home_runs", 0.5),
    "hit a dinger":  ("home_runs", 0.5),
    "any time home run": ("home_runs", 0.5),
    "anytime home run": ("home_runs", 0.5),
    "athr":          ("home_runs", 0.5),
    "steal a base":  ("stolen_bases", 0.5),
    "steals a base": ("stolen_bases", 0.5),
    "get a steal":   ("stolen_bases", 0.5),
    "drive in a run": ("rbis", 0.5),
    "drives in a run": ("rbis", 0.5),
    "get an rbi":    ("rbis", 0.5),
    "score a run":   ("runs", 0.5),
    "scores a run":  ("runs", 0.5),
    "to score":      ("runs", 0.5),
    "record a hit":  ("hits", 0.5),
    "records a hit": ("hits", 0.5),
    "get a hit":     ("hits", 0.5),
    "gets a hit":    ("hits", 0.5),
    "to get a hit":  ("hits", 0.5),
}


def _find_player_sgp_index(sim_results: dict, player_name: str) -> Optional[dict]:
    """Find a player and return their SGP cache index."""
    if not player_name or not sim_results:
        return None
    search = player_name.lower().strip()
    for i, batter in enumerate(sim_results.get("top_batters_home", [])):
        bname = batter.get("name", "").lower()
        if search in bname or bname in search or search.split()[-1] in bname.split():
            return {"name": batter["name"], "type": "batter", "sgp_idx": i, "side": "home"}
    for i, batter in enumerate(sim_results.get("top_batters_away", [])):
        bname = batter.get("name", "").lower()
        if search in bname or bname in search or search.split()[-1] in bname.split():
            return {"name": batter["name"], "type": "batter", "sgp_idx": 9 + i, "side": "away"}
    for key, side, idx in [("home_starting_pitcher", "home", 0), ("away_starting_pitcher", "away", 1)]:
        p = sim_results.get(key, {})
        pname = p.get("name", "").lower()
        if search in pname or (pname and pname.split()[-1] in search.split()):
            return {"name": p["name"], "type": "pitcher", "sgp_idx": idx, "side": side}
    return None


def _resolve_pitcher_by_team(sim_results: dict, team_hint: str) -> Optional[dict]:
    """Resolve a pitcher by team abbreviation or name."""
    if not team_hint:
        return None
    hint = team_hint.lower().strip()
    # Try to match via team abbreviation in game_info
    game_info = sim_results.get("game_info", {})
    home_p = sim_results.get("home_starting_pitcher", {})
    away_p = sim_results.get("away_starting_pitcher", {})
    
    # Check team alias resolution
    team_abbr = resolve_team_abbr(hint)
    if team_abbr:
        hint = team_abbr.lower()
    
    # Match against home/away
    home_id = str(game_info.get("home_team_id", ""))
    away_id = str(game_info.get("away_team_id", ""))
    
    # Also check pitcher names
    if home_p and hint in home_p.get("name", "").lower():
        return {"name": home_p["name"], "type": "pitcher", "sgp_idx": 0, "side": "home"}
    if away_p and hint in away_p.get("name", "").lower():
        return {"name": away_p["name"], "type": "pitcher", "sgp_idx": 1, "side": "away"}
    
    return None


def _get_default_leg(intent: dict, sim_results: dict) -> Optional[dict]:
    """Build the default leg from the initial prediction response."""
    if intent["type"] != "player" or not intent.get("player"):
        return None
    
    player_info = _find_player_sgp_index(sim_results, intent["player"])
    if not player_info:
        return None
    
    stat = intent.get("stat", "hits")
    
    if player_info["type"] == "pitcher":
        return {
            "name": player_info["name"], "type": "pitcher", "sgp_idx": player_info["sgp_idx"],
            "stat_key": "pitcher_ks", "stat_label": "K", "line": 0.5, "direction": "over",
            "display": f"{player_info['name']} O 0.5 K"
        }
    
    # Batter: default to the first prop shown (1+ of whatever stat)
    stat_to_key = {
        "hits": ("batter_hits", "H", "1+ Hits"),
        "home_runs": ("batter_hrs", "HR", "1+ HR"),
        "rbis": ("batter_rbis", "RBI", "O 0.5 RBI"),
        "runs": ("batter_runs", "R", "O 0.5 R"),
        "total_bases": ("batter_total_bases", "TB", "O 0.5 TB"),
        "strikeouts": ("batter_strikeouts", "K", "O 0.5 K"),
        "stolen_bases": ("batter_stolen_bases", "SB", "O 0.5 SB"),
    }
    sk, abbr, display = stat_to_key.get(stat, ("batter_hits", "H", "1+ Hits"))
    return {
        "name": player_info["name"], "type": "batter", "sgp_idx": player_info["sgp_idx"],
        "stat_key": sk, "stat_label": abbr, "line": 0.5, "direction": "over",
        "display": f"{player_info['name']} {display}"
    }


def _looks_like_pitcher(word: str) -> bool:
    """Check if a word is 'pitcher' or a common misspelling."""
    w = word.lower().rstrip(".'s").rstrip("'")
    if w in ('pitcher', 'pticher', 'picther', 'pitcer', 'picher', 'pitchr',
             'picthr', 'pitvher', 'pitcger', 'oitcher', 'putcher'):
        return True
    # Heuristic: starts with 'p', 5-8 chars, contains most letters from "pitcher"
    if len(w) >= 5 and len(w) <= 8 and w[0] == 'p':
        if sum(c in w for c in 'itcher') >= 4:
            return True
    return False


def _strip_correction_prefix(message: str) -> str:
    """Strip leading correction words like 'No,', 'Nah', 'Not that,', 'I meant'."""
    import re
    result = message
    # Apply repeatedly to handle chained prefixes like "Nah, I meant..."
    for _ in range(3):
        stripped = re.sub(
            r'^(?:not that[,.]?\s*|no\b[,.]?\s*|nah\b[,.]?\s*|i meant[,.]?\s*|actually[,.]?\s*)',
            '', result, flags=re.IGNORECASE
        ).strip()
        if stripped == result or not stripped:
            break
        result = stripped
    return result if result else message


def is_sgp_followup(message: str, chat_id: str) -> bool:
    """Detect if a message is a follow-up to a previous prediction."""
    if not chat_id or chat_id not in _prediction_cache:
        return False
    lower = message.lower()
    # Also try with correction prefix stripped
    stripped = _strip_correction_prefix(message).lower()
    sgp_triggers = [
        "what if", "and if", "combine", "parlay", "sgp", "same game",
        "what about", "also", "too", "plus", "add", "with",
        "along with", "paired with", "combo", "both",
        "over", "under", "1+", "2+", "3+",
        "to win", "moneyline", " ml",
        "go yard", "goes yard", "go deep", "goes deep",
        "athr", "any time home run", "anytime home run",
        "steal a base", "drive in", "score a run",
        "get a hit", "record a hit", "to get a",
    ]
    if any(t in lower for t in sgp_triggers):
        return True
    if any(t in stripped for t in sgp_triggers):
        return True
    # Check for fuzzy "pitcher" in any word
    if any(_looks_like_pitcher(w) for w in lower.split()):
        return True
    # Check if stripped message has a team + "win" or "ml" (correction like "No, Yankees win and...")
    cached = _prediction_cache.get(chat_id, {})
    if cached:
        game_info = cached.get("game_info", {})
        teams_in_game = [game_info.get("home_abbr", "").lower(), game_info.get("away_abbr", "").lower()]
        has_game_team = any(
            resolve_team_abbr(w) and resolve_team_abbr(w).lower() in [t.lower() for t in teams_in_game]
            for w in stripped.split()
            if len(w) > 2
        )
        if has_game_team and any(kw in stripped for kw in ['win', ' ml', 'hit', 'hr', 'homer']):
            return True
    return False


def _parse_ml_leg(segment: str, cached: dict) -> Optional[dict]:
    """Parse a moneyline/team-win leg: 'Yankees ML', 'NYY to win', etc."""
    import re
    lower = segment.lower().strip()
    game_info = cached["game_info"]
    home_abbr = game_info.get("home_abbr", "")
    away_abbr = game_info.get("away_abbr", "")

    # Check for "team ML" / "team to win" / "team win"
    ml_match = re.search(r'(\w[\w\s]*?)\s+(?:ml|moneyline|to win|win(?:s|ning)?)\b', lower)
    if not ml_match:
        # Reverse: "win by team"
        ml_match = re.search(r'(?:^|\b)(?:ml|moneyline|win)\s+(?:by|for|from)?\s*(\w[\w\s]*?)$', lower)
    if not ml_match:
        return None

    team_hint = ml_match.group(1).strip()
    team_abbr = resolve_team_abbr(team_hint)
    if not team_abbr:
        return None

    if team_abbr.upper() == home_abbr.upper():
        return {
            "name": home_abbr, "type": "ml", "sgp_idx": -1,
            "stat_key": "home_win", "stat_label": "ML",
            "line": 0.5, "direction": "home",
            "display": f"{home_abbr} ML",
        }
    elif team_abbr.upper() == away_abbr.upper():
        return {
            "name": away_abbr, "type": "ml", "sgp_idx": -1,
            "stat_key": "home_win", "stat_label": "ML",
            "line": 0.5, "direction": "away",
            "display": f"{away_abbr} ML",
        }
    return None


def _find_pitcher_fuzzy(lower: str, sim_results: dict, game_info: dict, cached: dict) -> Optional[dict]:
    """Find a pitcher reference, tolerant of typos like 'pticher'."""
    import re
    words = lower.split()

    # Find any word that looks like "pitcher"
    pitcher_idx = None
    for i, w in enumerate(words):
        if _looks_like_pitcher(w):
            pitcher_idx = i
            break

    if pitcher_idx is None:
        return None

    # Look for a team hint before the pitcher word (e.g., "SF pitcher", "SF's pticher")
    team_hint = None
    if pitcher_idx > 0:
        prev = words[pitcher_idx - 1].rstrip("'s").rstrip("'")
        team_hint = resolve_team_abbr(prev)
    if not team_hint and pitcher_idx > 1:
        prev2 = words[pitcher_idx - 2].rstrip("'s").rstrip("'")
        team_hint = resolve_team_abbr(prev2)

    home_abbr = game_info.get("home_abbr", "")
    away_abbr = game_info.get("away_abbr", "")

    if team_hint:
        if team_hint.upper() == home_abbr.upper():
            p = sim_results.get("home_starting_pitcher", {})
            return {"name": p.get("name", "Unknown"), "type": "pitcher", "sgp_idx": 0, "side": "home"}
        elif team_hint.upper() == away_abbr.upper():
            p = sim_results.get("away_starting_pitcher", {})
            return {"name": p.get("name", "Unknown"), "type": "pitcher", "sgp_idx": 1, "side": "away"}

    # No team hint — infer from cached context (opposing pitcher)
    cached_player = cached.get("player_info")
    if cached_player and cached_player.get("side"):
        opp_side = "away" if cached_player["side"] == "home" else "home"
        opp_key = f"{opp_side}_starting_pitcher"
        opp_p = sim_results.get(opp_key, {})
        if opp_p:
            return {"name": opp_p["name"], "type": "pitcher",
                    "sgp_idx": 0 if opp_side == "home" else 1, "side": opp_side}

    # Last resort: just use home pitcher
    p = sim_results.get("home_starting_pitcher", {})
    if p:
        return {"name": p.get("name", "Unknown"), "type": "pitcher", "sgp_idx": 0, "side": "home"}
    return None


def parse_sgp_leg(message: str, cached: dict) -> Optional[dict]:
    """
    Parse a single SGP leg from a follow-up message.

    Handles betting language:
      - "N+" → over (N - 0.5):  "1+" = O 0.5, "3+" = O 2.5
      - "over N" / "o N" → over N exactly (already half-run)
      - "to get a hit" → O 0.5 H
      - "to get 2 hits" → O 1.5 H  (whole-number → minus 0.5)
      - "go yard" / "ATHR" → O 0.5 HR
      - "Judge to get a hit and home run" → handled by parse_fresh_sgp_legs (split)
    """
    import re
    msg = _strip_correction_prefix(message)
    lower = msg.lower()
    sim_results = cached["sim_results"]
    game_info = cached["game_info"]

    # ── Try ML leg first ──
    ml_leg = _parse_ml_leg(lower, cached)
    if ml_leg:
        return ml_leg

    # ── Check slang phrases FIRST (they carry their own stat + line) ──
    slang_stat = None
    slang_line = None
    for phrase, (sk, sl) in _BETTING_SLANG.items():
        if phrase in lower:
            slang_stat = sk
            slang_line = sl
            break

    # ── Extract a numeric line ──
    # Priority 1: "N+ stat" — e.g. "2+ hits", "1+ HR"
    line_match = re.search(
        r'(\d+)\+\s*(?:strikeouts?|ks?|hits?|home ?runs?|hrs?|rbis?|runs?|total ?bases?|tbs?|stolen ?bases?|sbs?|steals?|homers?|dingers?)',
        lower)
    is_plus_notation = False
    if line_match:
        is_plus_notation = True
    else:
        # Priority 2: "over/o N" — e.g. "over 5.5", "o 1.5"
        line_match = re.search(r'(?:over|o)\s+(\d+\.?\d*)', lower)
    if not line_match:
        # Priority 3: standalone "N+" — e.g. "1+", "3+"
        line_match = re.search(r'(\d+)\+', lower)
        if line_match:
            is_plus_notation = True
    if not line_match:
        # Priority 4: "to get N stat" — e.g. "to get 2 hits"
        line_match = re.search(
            r'(?:to\s+)?(?:get|record|have|collect|rack up)\s+(\d+)\s+(?:strikeouts?|ks?|hits?|home ?runs?|hrs?|rbis?|runs?|total ?bases?|tbs?|stolen ?bases?|sbs?|steals?|homers?|dingers?)',
            lower)
        if line_match:
            is_plus_notation = True  # "get 2 hits" = 2+ = O 1.5
    if not line_match:
        # Priority 5: bare "N stat" — e.g. "Judge 1 hit", "Judge 2 HR"
        line_match = re.search(
            r'(\d+)\s+(?:strikeouts?|ks?|hits?|home ?runs?|hrs?|rbis?|runs?|total ?bases?|tbs?|stolen ?bases?|sbs?|steals?|homers?|dingers?)',
            lower)
        if line_match:
            is_plus_notation = True  # "Judge 1 hit" = 1+ = O 0.5

    line_val = None
    if line_match:
        raw = float(line_match.group(1))
        if is_plus_notation:
            # N+ means "at least N" → over (N - 0.5)
            line_val = raw - 0.5
        elif '.' in line_match.group(1):
            # Already half-run line like 5.5, 1.5
            line_val = raw
        else:
            # Bare integer with "over" → treat as whole number threshold
            # "over 5 strikeouts" = O 4.5 (at least 5)
            line_val = raw - 0.5

    # ── Determine stat (from explicit regex patterns or slang) ──
    stat_key = slang_stat  # may already be set from slang
    if not stat_key:
        for pattern, key in [
            (r'home ?runs?|hrs?\b|homers?\b|dingers?\b|athr\b|any\s*time\s*home\s*run', "home_runs"),
            (r'strikeouts?|(?<!\w)ks?\b', "strikeouts"),
            (r'total ?bases?|tbs?\b', "total_bases"),
            (r'stolen ?bases?|sbs?\b|steals?\b', "stolen_bases"),
            (r'rbis?\b|drives?\s*in|drove\s*in', "rbis"),
            (r'(?<!home\s)runs?\s*scored|(?<!home\s)(?<!stolen\s)(?<!home\s)scores?\s*a?\s*run', "runs"),
            (r'(?<!home )runs?\b(?!\s*scored)', "runs"),
            (r'hits?\b', "hits"),
        ]:
            if re.search(pattern, lower):
                stat_key = key
                break

    if not stat_key:
        return None

    # ── Apply slang line if no explicit number was given ──
    if line_val is None and slang_line is not None:
        line_val = slang_line

    # ── Find the player/pitcher (fuzzy) ──
    player_info = _find_pitcher_fuzzy(lower, sim_results, game_info, cached)

    if not player_info:
        # Try player name via full message matching
        has_pitcher_word = any(_looks_like_pitcher(w) for w in lower.split())
        if not has_pitcher_word:
            player_info = _find_player_sgp_index(sim_results, msg)
            if not player_info:
                # Try extracting name-like segments
                name_match = re.search(r'(?:if|and|plus|with|no)\s+((?:[A-Z][a-z]+\s+){1,2}[A-Z][a-z]+)', msg)
                if name_match:
                    player_info = _find_player_sgp_index(sim_results, name_match.group(1))
            if not player_info:
                # Try individual capitalized words as last names
                for word in msg.split():
                    if len(word) >= 3 and word[0].isupper() and word.lower() not in (
                        'the', 'and', 'with', 'what', 'over', 'under', 'also', 'plus',
                        'can', 'you', 'show', 'sgp', 'parlay', 'not', 'nah', 'give',
                    ):
                        player_info = _find_player_sgp_index(sim_results, word)
                        if player_info:
                            break

    if not player_info:
        return None

    # ── Build the SGP stat key ──
    if player_info["type"] == "pitcher":
        sgp_stat = _SGP_PITCHER_STATS.get(stat_key, "pitcher_ks")
        stat_abbr = "K" if "ks" in sgp_stat or "strikeout" in stat_key else "HA"
    else:
        sgp_stat = _SGP_BATTER_STATS.get(stat_key, "batter_hits")
        stat_abbr_map = {"hits": "H", "home_runs": "HR", "rbis": "RBI", "runs": "R",
                         "total_bases": "TB", "strikeouts": "K", "stolen_bases": "SB"}
        stat_abbr = stat_abbr_map.get(stat_key, "H")

    if line_val is None:
        line_val = 0.5  # default: 1+ (at least 1)

    if line_val == int(line_val):
        display = f"{player_info['name']} O {line_val:.1f} {stat_abbr}"
    else:
        display = f"{player_info['name']} O {line_val} {stat_abbr}"

    return {
        "name": player_info["name"], "type": player_info["type"],
        "sgp_idx": player_info["sgp_idx"],
        "stat_key": sgp_stat, "stat_label": stat_abbr,
        "line": line_val, "direction": "over",
        "display": display,
    }


def parse_fresh_sgp_legs(message: str, cached: dict) -> list:
    """
    Parse MULTIPLE legs from a single message for a fresh SGP/parlay.

    Handles:
      - Explicit splits: "Yankees ML and Judge 1 hit" → 2 legs
      - Same-player multi-prop: "Judge to get a hit and home run" → 2 legs
      - Comma splits: "Judge 1+ hit, Soto 1+ HR" → 2 legs
    """
    import re
    msg = _strip_correction_prefix(message)
    # Remove preamble like "Can you show me an SGP of", "What is the SGP price of", "Parlay:", etc.
    # The pattern eats everything up to and including the sgp/parlay keyword + optional filler words
    msg = re.sub(
        r'^.*?\b(?:sgp|parlay|same game parlay)\b[\w\s]*?\b(?:of|for|with|on|:)\s+',
        '', msg, flags=re.IGNORECASE
    ).strip()
    if not msg:
        # Fallback: simpler strip (just the keyword itself)
        msg = re.sub(r'^.*?\b(?:sgp|parlay|same game parlay)\s*(?:of|with|:)?\s*', '', _strip_correction_prefix(message), flags=re.IGNORECASE).strip()
    if not msg:
        msg = _strip_correction_prefix(message)

    # Split by "and", "with", "plus", "+", ","
    segments = re.split(r'\s+(?:and|with|plus|\+)\s+|,\s*', msg)
    segments = [s.strip() for s in segments if s.strip()]

    # ── Handle same-player multi-prop ──
    # If a segment is just a stat with no player (e.g., "home run" after "Judge to get a hit"),
    # we carry forward the player context from the previous segment.
    legs = []
    last_player_context = None  # player name from last successfully parsed leg

    for seg in segments:
        leg = parse_sgp_leg(seg, cached)
        if leg:
            legs.append(leg)
            if leg.get("type") != "ml":
                last_player_context = leg["name"]
        else:
            # Try ML leg
            ml = _parse_ml_leg(seg, cached)
            if ml:
                legs.append(ml)
            elif last_player_context:
                # Segment might be just a stat with no player name
                # e.g., after "Judge to get a hit", the segment is "home run"
                # Prepend the last player name and try again
                enriched = f"{last_player_context} {seg}"
                leg = parse_sgp_leg(enriched, cached)
                if leg:
                    legs.append(leg)

    return legs


def _check_leg_outcome(outcome: dict, leg: dict) -> bool:
    """Check if a single leg hits in one sim outcome. Handles ML and stat legs."""
    stat_key = leg["stat_key"]
    direction = leg["direction"]

    if stat_key == "home_win":
        # ML leg: home_win is a boolean
        hw = bool(outcome.get("home_win", False))
        return hw if direction == "home" else not hw

    # Regular stat array leg
    idx = leg["sgp_idx"]
    val = outcome.get(stat_key, [])
    if isinstance(val, list) and idx < len(val):
        v = val[idx]
    else:
        return False

    if direction == "over":
        return v > leg["line"]
    elif direction == "under":
        return v < leg["line"]
    return False


def compute_sgp(sgp_cache: list, legs: list) -> float:
    """Compute correlated probability from SGP cache. Returns percentage 0-100."""
    total = len(sgp_cache)
    if total == 0 or not legs:
        return 0.0

    hits = 0
    for outcome in sgp_cache:
        if all(_check_leg_outcome(outcome, leg) for leg in legs):
            hits += 1

    return (hits / total) * 100


def format_sgp_response(legs: list, pct: float, num_outcomes: int) -> str:
    """Format SGP result — clean parlay output."""
    lines = ["SGP"]
    for i, leg in enumerate(legs):
        prefix = "  " if i == 0 else "+ "
        lines.append(f"{prefix}{leg['display']}")
    lines.append("")
    lines.append(f"{_prob_to_odds(pct)} ({pct:.1f}%)")
    return "\n".join(lines)


# ─── Conditional Probability (follow-up "what if" without explicit parlay) ──

def compute_conditional_prop(sgp_cache: list, condition_legs: list,
                             orig_sgp_idx: int, orig_stat_key: str) -> Optional[dict]:
    """
    Filter sgp_cache by condition(s), then compute the original prop in the filtered set.
    Returns median + probability at various thresholds, or None if too few filtered sims.
    """
    filtered_values = []
    for outcome in sgp_cache:
        # Check ALL conditions using unified leg checker
        if not all(_check_leg_outcome(outcome, cleg) for cleg in condition_legs):
            continue
        # Condition met — extract original stat value
        orig_arr = outcome.get(orig_stat_key, [])
        if isinstance(orig_arr, list) and orig_sgp_idx < len(orig_arr):
            filtered_values.append(orig_arr[orig_sgp_idx])

    if len(filtered_values) < 20:
        return None  # too few sims to be meaningful

    filtered_values.sort()
    n = len(filtered_values)
    median = filtered_values[n // 2]
    probs = {}
    for t in [0.5, 1.5, 2.5, 3.5, 4.5, 5.5, 6.5]:
        pct = sum(1 for v in filtered_values if v > t) / n * 100
        probs[t] = pct
    return {"median": median, "filtered_count": n, "total_count": len(sgp_cache), "probs": probs}


def _condition_display(condition_leg: dict) -> str:
    """Build human-readable condition text: 'Logan Webb 6+ Ks' or 'NYY Win'."""
    import math
    name = condition_leg["name"]

    # ML legs: just "NYY Win" — not "NYY 1+ ML"
    if condition_leg.get("type") == "ml" or condition_leg.get("stat_key") == "home_win":
        return f"{name} Win"

    line = condition_leg["line"]
    abbr = condition_leg["stat_label"]
    abbr_to_plural = {"K": "Ks", "H": "Hits", "HR": "HRs", "RBI": "RBIs",
                      "R": "Runs", "TB": "TBs", "SB": "SBs", "HA": "Hits Allowed"}
    stat_display = abbr_to_plural.get(abbr, abbr)
    threshold = math.ceil(line)
    return f"{name} {threshold}+ {stat_display}"


def format_conditional_response(orig_intent: dict, orig_player_name: str,
                                conditions: list, cond_results: dict) -> str:
    """
    Format conditional probability:
      Aaron Judge — Home Runs (Given Logan Webb 6+ Ks)
      Projected Home Runs: 0
      1+ HR: +450 (22.1%)
    """
    stat = orig_intent.get("stat", "hits")
    stat_labels = {
        "hits": "Hits", "home_runs": "Home Runs", "rbis": "RBIs",
        "runs": "Runs", "total_bases": "Total Bases",
        "strikeouts": "Strikeouts", "stolen_bases": "Stolen Bases",
    }
    stat_label = stat_labels.get(stat, "Hits")

    cond_text = ", ".join(_condition_display(c) for c in conditions)
    header = f"{orig_player_name} — {stat_label} (Given {cond_text})"

    med = cond_results["median"]
    lines = [header, ""]
    lines.append(f"Projected {stat_label}: {int(med)}" if med == int(med) else f"Projected {stat_label}: {med:.2f}")

    # Probability thresholds per stat
    stat_prop_map = {
        "hits": [(0.5, "1+ Hits"), (1.5, "2+ Hits")],
        "home_runs": [(0.5, "1+ HR")],
        "rbis": [(0.5, "O 0.5 RBI"), (1.5, "O 1.5 RBI")],
        "runs": [(0.5, "O 0.5 R"), (1.5, "O 1.5 R")],
        "total_bases": [(0.5, "O 0.5 TB"), (1.5, "O 1.5 TB"), (2.5, "O 2.5 TB")],
        "strikeouts": [(0.5, "O 0.5 K"), (1.5, "O 1.5 K")],
        "stolen_bases": [(0.5, "O 0.5 SB")],
    }
    for threshold, label in stat_prop_map.get(stat, [(0.5, "1+")]):
        pct = cond_results["probs"].get(threshold, 0)
        if pct > 0:
            lines.append(f"{label}: {_prob_to_odds(pct)} ({pct:.1f}%)")

    return "\n".join(lines)


# ─── Multi-Game Parlay ─────────────────────────────────────────────

def format_multi_parlay_response(parlay_legs: list) -> str:
    """
    Format multi-game parlay output:
      NYY ML: -155 (60.9%)
      KC ML: -120 (54.5%)

      Parlay: +135 (42.6%)
    """
    lines = []
    combined_prob = 1.0
    for leg in parlay_legs:
        abbr = leg["team_abbr"]
        pct = leg["win_pct"]
        lines.append(f"{abbr} ML: {_prob_to_odds(pct)} ({pct:.1f}%)")
        combined_prob *= pct / 100
    combined_pct = combined_prob * 100
    lines.append("")
    lines.append(f"Parlay: {_prob_to_odds(combined_pct)} ({combined_pct:.1f}%)")
    return "\n".join(lines)


# ─── END Conditional / Multi-Parlay ─────────────────────────────────


# ─── Conversational Stat Re-Query ──────────────────────────────────
# Handles: "How about home runs", "what about his stolen bases", "and RBIs?"
# When there's a cached player prediction, swap the stat and re-format.

_STAT_REQUERY_MAP = {
    # Maps keywords found in short follow-ups to the canonical stat key
    "home run": "home_runs", "home runs": "home_runs", "homers": "home_runs",
    "hr": "home_runs", "hrs": "home_runs", "dingers": "home_runs",
    "hit": "hits", "hits": "hits",
    "rbi": "rbis", "rbis": "rbis",
    "run": "runs", "runs": "runs", "runs scored": "runs",
    "stolen base": "stolen_bases", "stolen bases": "stolen_bases",
    "steals": "stolen_bases", "sb": "stolen_bases",
    "total base": "total_bases", "total bases": "total_bases", "tb": "total_bases",
    "strikeout": "strikeouts", "strikeouts": "strikeouts", "ks": "strikeouts",
}


def detect_stat_requery(message: str, chat_id: str) -> Optional[str]:
    """
    Detect if a short follow-up message is asking about a different stat
    for the same player. Returns the new stat key, or None.

    Examples that match:
      "How about home runs" → "home_runs"
      "What about his stolen bases?" → "stolen_bases"
      "And RBIs?" → "rbis"
      "His total bases?" → "total_bases"
      "Home runs?" → "home_runs"
    """
    if not chat_id or chat_id not in _prediction_cache:
        return None

    cached = _prediction_cache[chat_id]
    orig_intent = cached.get("intent", {})
    # Only applies when previous query was a player prediction
    if orig_intent.get("type") != "player" or not cached.get("player_info"):
        return None

    lower = message.lower().strip().rstrip("?!.")

    # Must be a short message — not a full question with a player name
    if len(lower.split()) > 8:
        return None

    # Bail out if message has conditional/context signals — these are NOT simple re-queries
    # e.g. "What if the SF pitcher gets 5 strikeouts?" is a conditional, not a re-query
    import re
    _context_signals = [
        r'\bif\b',              # "what if", "if the pitcher..."
        r'\bpitcher\b',         # references a specific pitcher
        r'\d+\.\d+',            # has a line like 5.5
        r'\d+\s*\+',            # has N+ notation
        r'\bover\b',            # "over 5.5"
        r'\bunder\b',           # "under"
        r'\bparlay\b',          # parlay request
        r'\bsgp\b',             # sgp request
        r'\bget\b',             # "gets 5 strikeouts" — action verb implies a scenario
        r'\bml\b',              # moneyline
        r'\bwin\b',             # team win
    ]
    if any(re.search(sig, lower) for sig in _context_signals):
        return None

    # Also bail if a team name appears (e.g., "SF pitcher")
    for word in lower.split():
        if len(word) > 2 and resolve_team_abbr(word):
            return None

    # Strip conversational prefixes
    lower = re.sub(
        r'^(?:how about|what about|and|his|her|their|also|show me|tell me about|what\'s|whats)\s+',
        '', lower, flags=re.IGNORECASE
    ).strip()
    # Strip possessive "his"
    lower = re.sub(r'^(?:his|her|their)\s+', '', lower).strip()

    # Match against stat keywords (longest match first)
    for phrase in sorted(_STAT_REQUERY_MAP.keys(), key=len, reverse=True):
        if phrase in lower:
            new_stat = _STAT_REQUERY_MAP[phrase]
            # Don't match if it's the same stat they already asked about
            if new_stat != orig_intent.get("stat"):
                return new_stat

    return None


def format_stat_requery_response(cached: dict, new_stat: str) -> str:
    """Re-format the cached sim results with a different stat for the same player."""
    sim_results = cached["sim_results"]
    game_info = cached["game_info"]
    lineups = cached.get("lineups", {})
    orig_intent = cached["intent"]

    # Build a modified intent with the new stat
    new_intent = dict(orig_intent)
    new_intent["stat"] = new_stat

    return format_prediction_response(new_intent, sim_results, game_info, lineups)


def format_prediction_response(intent: dict, sim_results: dict, game_info: dict, lineups: dict) -> str:
    """Format simulation results — clean, minimal, only as specific as the user asked."""
    home_abbr = game_info["home_abbr"]
    away_abbr = game_info["away_abbr"]
    game_date = game_info["game_date"]
    
    # What did the user actually specify?
    user_mentioned_game = len(intent.get("teams_from_query", [])) > 0
    user_mentioned_date = intent.get("date_str", "today") not in ("today", "tonight", "next")
    
    win = sim_results.get("win_probabilities", {})
    score = sim_results.get("score_statistics", {})
    ou = sim_results.get("total_runs_over_under", {})
    med_total = score.get("median_total_runs", 0)
    
    # ── PLAYER PROP ──
    if intent["type"] == "player" and intent.get("player"):
        player = find_player_in_results(sim_results, intent["player"])
        if not player:
            if user_mentioned_game:
                return _format_game_compact(away_abbr, home_abbr, game_date, user_mentioned_date,
                                            win, score, ou, prefix=f"{intent['player']} not found in lineup.\n\n")
            else:
                return f"{intent['player']} not found in lineup for next scheduled game."
        
        stat = intent.get("stat", "hits")
        pname = player.get("name", intent["player"])
        
        if player.get("is_pitcher"):
            med_k = player.get('median_strikeouts', 0)
            lines = [f"{pname} — Strikeouts"]
            if user_mentioned_game:
                lines.append(f"{away_abbr} @ {home_abbr}" + (f" / {game_date}" if user_mentioned_date else ""))
            lines += ["", f"Projected Strikeouts: {med_k:.0f}"]
            for label, key in [("O 4.5 K", "strikeout_over_4_5_pct"), ("O 5.5 K", "strikeout_over_5_5_pct"), ("O 6.5 K", "strikeout_over_6_5_pct")]:
                pct = player.get(key, 0)
                if pct > 0:
                    lines.append(f"{label}: {_prob_to_odds(pct)} ({pct:.1f}%)")
            return "\n".join(lines)
        
        stat_map = {
            "hits": ("Hits", "median_hits", [("1+ Hits", "hit_probability"), ("2+ Hits", "multi_hit_probability")]),
            "home_runs": ("Home Runs", "median_home_runs", [("1+ HR", "home_run_probability")]),
            "rbis": ("RBIs", "median_rbis", [("O 0.5 RBI", "rbi_over_0_5_pct"), ("O 1.5 RBI", "rbi_over_1_5_pct")]),
            "runs": ("Runs", "median_runs", [("O 0.5 R", "runs_over_0_5_pct"), ("O 1.5 R", "runs_over_1_5_pct")]),
            "total_bases": ("Total Bases", "median_total_bases", [("O 0.5 TB", "total_bases_over_0_5_pct"), ("O 1.5 TB", "total_bases_over_1_5_pct"), ("O 2.5 TB", "total_bases_over_2_5_pct")]),
            "strikeouts": ("Strikeouts", "median_strikeouts", [("O 0.5 K", "strikeouts_over_0_5_pct"), ("O 1.5 K", "strikeouts_over_1_5_pct")]),
            "stolen_bases": ("Stolen Bases", "median_stolen_bases", [("O 0.5 SB", "stolen_bases_over_0_5_pct")]),
        }
        
        if stat in stat_map:
            label, median_key, props = stat_map[stat]
            med_val = player.get(median_key, 0)
            lines = [f"{pname} — {label}"]
            if user_mentioned_game:
                lines.append(f"{away_abbr} @ {home_abbr}" + (f" / {game_date}" if user_mentioned_date else ""))
            lines.append("")
            lines.append(f"Projected {label}: {med_val:.0f}" if med_val == int(med_val) else f"Projected {label}: {med_val:.2f}")
            for prop_label, prop_key in props:
                pct = player.get(prop_key, 0)
                if pct > 0:
                    lines.append(f"{prop_label}: {_prob_to_odds(pct)} ({pct:.1f}%)")
            return "\n".join(lines)
        
        # Fallback: unknown stat
        med_hits = player.get("median_hits", 0)
        lines = [f"{pname} — Hits", ""]
        lines.append(f"Projected Hits: {med_hits:.0f}")
        return "\n".join(lines)
    
    # ── GAME PREDICTION ──
    return _format_game_compact(away_abbr, home_abbr, game_date, user_mentioned_date,
                                win, score, ou)


def _format_game_compact(away_abbr, home_abbr, game_date, show_date, win, score, ou, prefix="") -> str:
    """Clean game prediction — just the numbers."""
    home_win = win.get("home_win_pct", 50)
    away_win = win.get("away_win_pct", 50)
    med_home = score.get("median_home_score", 0)
    med_away = score.get("median_away_score", 0)
    med_total = score.get("median_total_runs", 0)
    
    # Find the closest O/U line to the median total
    ou_line = round(med_total * 2) / 2  # round to nearest 0.5
    # Clamp to available lines
    available = [(6.5, "over_6_5_pct"), (7.5, "over_7_5_pct"), (8.5, "over_8_5_pct"), (9.5, "over_9_5_pct")]
    best_line, best_key = min(available, key=lambda x: abs(x[0] - ou_line))
    over_pct = ou.get(best_key, 50)
    under_pct = 100 - over_pct
    
    title = f"{away_abbr} @ {home_abbr}"
    if show_date:
        title += f" / {game_date}"
    
    lines = [
        f"{prefix}{away_abbr} {med_away:.0f} - {home_abbr} {med_home:.0f}", "",
        "Win Probability:",
        f"  {away_abbr}: {_prob_to_odds(away_win)} ({away_win:.1f}%)",
        f"  {home_abbr}: {_prob_to_odds(home_win)} ({home_win:.1f}%)", "",
        "Total:",
        f"  Over {best_line}: {_prob_to_odds(over_pct)} ({over_pct:.1f}%)",
        f"  Under {best_line}: {_prob_to_odds(under_pct)} ({under_pct:.1f}%)",
    ]
    
    return "\n".join(lines)


class ChatMessage(BaseModel):
    chat_id: Optional[str] = None
    message: str
    previous_messages: Optional[List[Dict[str, Any]]] = None

class SaveChatRequest(BaseModel):
    title: str
    messages: List[Dict[str, Any]]
    chat_id: Optional[str] = None

@app.post("/api/diamond-quant/chat")
async def diamond_quant_chat(request: ChatMessage, http_request: Request):
    """
    Chat with Diamond Quant AI to generate data visualizations.
    Uses DeepSeek to understand queries, generate SQL, and create visualizations.
    """
    # Import re locally at the very top to avoid any scoping issues
    import re as re_module
    
    # Check tier limits for AI chat
    key_info = await get_api_key_info(http_request)
    if key_info:
        # Get API key to look up usage
        result = await verify_api_key(http_request)
        if result:
            api_key, tier = result
            
            # Try to check rate limits, but gracefully handle if columns don't exist
            try:
                from diamond_quant.database import get_db
                db = get_db()
                conn = db.get_connection()
                cur = conn.cursor()
                
                # Get current usage (check if columns exist first)
                key_hash = hash_api_key(api_key)
                
                # Try to query with the new columns, fall back if they don't exist
                try:
                    cur.execute("""
                        SELECT id, ai_chat_requests_this_month, ai_chat_month_reset_at
                        FROM api_keys
                        WHERE key_hash = %s
                    """, (key_hash,))
                    row = cur.fetchone()
                    
                    if row:
                        key_id, requests_this_month, reset_at = row
                        
                        # Reset monthly counter if needed
                        if reset_at and reset_at < datetime.now():
                            cur.execute("""
                                UPDATE api_keys
                                SET ai_chat_requests_this_month = 0,
                                    ai_chat_month_reset_at = DATE_TRUNC('month', NOW()) + INTERVAL '1 month'
                                WHERE id = %s
                            """, (key_id,))
                            requests_this_month = 0
                            conn.commit()
                        
                        # Check monthly limit
                        monthly_limit = key_info.get("ai_chat_requests_per_month")
                        if monthly_limit is not None and requests_this_month >= monthly_limit:
                            conn.close()
                            raise HTTPException(
                                403,
                                detail=f"Monthly AI chat limit reached. Your tier allows {monthly_limit} requests per month."
                            )
                        
                        # Check per-minute limit (count requests in last minute)
                        per_minute_limit = key_info.get("ai_chat_requests_per_minute")
                        if per_minute_limit is not None:
                            try:
                                cur.execute("""
                                    SELECT COUNT(*) FROM api_key_chat_requests
                                    WHERE key_id = %s AND requested_at > NOW() - INTERVAL '1 minute'
                                """, (key_id,))
                                requests_last_minute = cur.fetchone()[0]
                                
                                if requests_last_minute >= per_minute_limit:
                                    conn.close()
                                    raise HTTPException(
                                        429,
                                        detail=f"Rate limit exceeded. Your tier allows {per_minute_limit} requests per minute."
                                    )
                                
                                # Record this request
                                cur.execute("""
                                    INSERT INTO api_key_chat_requests (key_id, requested_at)
                                    VALUES (%s, NOW())
                                """, (key_id,))
                            except Exception as e:
                                # Table might not exist, skip rate limiting
                                print(f"[WARNING] Rate limiting table not available: {e}", flush=True)
                        
                        # Increment monthly counter
                        cur.execute("""
                            UPDATE api_keys
                            SET ai_chat_requests_this_month = ai_chat_requests_this_month + 1
                            WHERE id = %s
                        """, (key_id,))
                        
                        conn.commit()
                        conn.close()
                except Exception as e:
                    # Columns don't exist, skip rate limiting
                    print(f"[WARNING] Rate limiting columns not available, skipping checks: {e}", flush=True)
                    conn.close()
            except Exception as e:
                # Database connection failed or rate limiting not available
                # Continue without rate limiting
                print(f"[WARNING] Rate limiting check failed, continuing anyway: {e}", flush=True)
    
    try:
        from openai import OpenAI
        import psycopg2
        from dotenv import load_dotenv
        import json
        import uuid
        from datetime import datetime
        
        # Load .env file from project root
        env_path = PROJECT_ROOT / ".env"
        load_dotenv(env_path)
        
        # Also try loading from current directory as fallback
        if not os.getenv('DEEPSEEK_API_KEY'):
            load_dotenv()
        
        database_url = os.getenv('DATABASE_URL')
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        # ─── PREDICTION FOLLOW-UP DETECTION ─────────────────────────────
        # Check if this is a follow-up to a previous prediction.
        # Four modes:
        #   0. Stat re-query: "how about home runs" → same player, different stat
        #   1. Fresh explicit parlay/sgp (all legs in one message) → parse fresh
        #   2. Incremental explicit parlay → append to cached legs
        #   3. Implicit "what if" → conditional probability (re-run original prop)
        user_message = request.message
        chat_id = request.chat_id or ""

        # ── Pronoun resolution: "he/him/his" → cached player name ──
        if chat_id and chat_id in _prediction_cache:
            _cached_player_info = _prediction_cache[chat_id].get("player_info") or {}
            _cached_player_name = _cached_player_info.get("name")
            if _cached_player_name:
                _pronoun_pattern = re.compile(
                    r'\b(he|him|his|they|them|their)\b(?!\s+(?:is|was|were|are|has|had|will|would|can|could|should)n\'t)',
                    re.IGNORECASE
                )
                _resolved = _pronoun_pattern.sub(_cached_player_name, user_message)
                if _resolved != user_message:
                    print(f"[PRONOUN] Resolved: '{user_message}' → '{_resolved}'", flush=True)
                    user_message = _resolved

        # ── Mode 0: Stat re-query ──
        _requery_stat = detect_stat_requery(user_message, chat_id)
        if _requery_stat:
            print(f"[REQUERY] Stat re-query detected: '{user_message}' → stat={_requery_stat}", flush=True)
            try:
                cached = _prediction_cache[chat_id]
                response_text = format_stat_requery_response(cached, _requery_stat)
                # Update cached intent so further follow-ups use the new stat
                cached["intent"] = dict(cached["intent"])
                cached["intent"]["stat"] = _requery_stat
                # Also rebuild the default leg for the new stat
                new_default = _get_default_leg(cached["intent"], cached["sim_results"])
                if new_default:
                    cached["legs"] = [new_default]
                    cached["conditions"] = []
                return {
                    "text": response_text,
                    "visualization": None,
                    "image": None,
                    "imageType": None,
                    "chat_id": chat_id,
                    "source": "prediction_requery",
                }
            except Exception as e:
                import traceback
                print(f"[REQUERY] Error: {e}\n{traceback.format_exc()}", flush=True)

        if is_sgp_followup(user_message, chat_id):
            print(f"[FOLLOWUP] Detected follow-up: {user_message[:80]}...", flush=True)
            try:
                cached = _prediction_cache[chat_id]
                sgp_cache = cached["sim_results"].get("sgp_cache")
                if not sgp_cache:
                    print("[FOLLOWUP] No SGP cache in stored results, falling through", flush=True)
                else:
                    _lower_msg = user_message.lower()
                    is_explicit_parlay = any(kw in _lower_msg for kw in [
                        'parlay', 'sgp', 'combined odds', 'combine',
                    ])

                    response_text = None

                    if is_explicit_parlay:
                        # ── EXPLICIT PARLAY: try parsing ALL legs fresh first ──
                        fresh_legs = parse_fresh_sgp_legs(user_message, cached)
                        if len(fresh_legs) >= 2:
                            # User defined a complete fresh parlay — ignore cached legs
                            pct = compute_sgp(sgp_cache, fresh_legs)
                            cached["legs"] = fresh_legs
                            print(f"[FOLLOWUP] Fresh SGP: {[l['display'] for l in fresh_legs]}, pct={pct:.1f}%", flush=True)
                            response_text = format_sgp_response(fresh_legs, pct, len(sgp_cache))
                        else:
                            # Explicit parlay request but only got 0-1 legs from fresh parse.
                            # Start from fresh legs (NOT stale cached legs) — the user is
                            # defining a new parlay, not adding to the previous one.
                            new_leg = fresh_legs[0] if fresh_legs else parse_sgp_leg(user_message, cached)
                            if new_leg:
                                legs = [new_leg]  # fresh start, not append to stale
                                pct = compute_sgp(sgp_cache, legs)
                                cached["legs"] = legs
                                cached["conditions"] = []
                                print(f"[FOLLOWUP] Explicit SGP (single leg so far): {[l['display'] for l in legs]}, pct={pct:.1f}%", flush=True)
                                response_text = format_sgp_response(legs, pct, len(sgp_cache))
                    else:
                        # ── NON-EXPLICIT: try conditional first ──
                        new_leg = parse_sgp_leg(user_message, cached)
                        if new_leg:
                            orig_intent = cached.get("intent", {})
                            orig_player = cached.get("player_info")
                            if orig_intent.get("type") == "player" and orig_player:
                                orig_stat = orig_intent.get("stat", "hits")
                                if orig_player.get("type") == "pitcher":
                                    orig_stat_key = _SGP_PITCHER_STATS.get(orig_stat, "pitcher_ks")
                                else:
                                    orig_stat_key = _SGP_BATTER_STATS.get(orig_stat, "batter_hits")

                                conditions = list(cached.get("conditions", []))
                                conditions.append(new_leg)
                                cached["conditions"] = conditions

                                cond_results = compute_conditional_prop(
                                    sgp_cache, conditions,
                                    orig_player["sgp_idx"], orig_stat_key
                                )
                                if cond_results:
                                    pname = orig_player.get("name", orig_intent.get("player", "Unknown"))
                                    response_text = format_conditional_response(
                                        orig_intent, pname, conditions, cond_results
                                    )
                                    print(f"[FOLLOWUP] Conditional: {pname} | conditions={[_condition_display(c) for c in conditions]}, "
                                          f"filtered={cond_results['filtered_count']}/{cond_results['total_count']}", flush=True)

                            if response_text is None:
                                # Fallback: treat as incremental SGP
                                legs = list(cached.get("legs", []))
                                legs.append(new_leg)
                                pct = compute_sgp(sgp_cache, legs)
                                cached["legs"] = legs
                                response_text = format_sgp_response(legs, pct, len(sgp_cache))

                    if response_text:
                        return {
                            "text": response_text,
                            "visualization": None,
                            "image": None,
                            "imageType": None,
                            "chat_id": chat_id,
                            "source": "prediction_followup",
                        }
                    else:
                        print(f"[FOLLOWUP] Could not parse any legs from message, falling through", flush=True)
            except Exception as e:
                import traceback
                print(f"[FOLLOWUP] Error: {e}\n{traceback.format_exc()}", flush=True)
        # ─── END PREDICTION FOLLOW-UP ───────────────────────────────────
        
        # ─── PREDICTION DETECTION ──────────────────────────────────────
        # Intercept prediction queries BEFORE the LLM classification step.
        # This avoids wasting LLM tokens on queries we can handle locally.
        if is_prediction_query(user_message):
            print(f"[PREDICTION] Detected prediction query: {user_message[:80]}...", flush=True)
            try:
                intent = parse_prediction_intent_local(user_message)
                # Save original teams from query before player lookup may add teams
                intent["teams_from_query"] = list(intent["teams"])
                print(f"[PREDICTION] Intent: type={intent['type']}, teams={intent['teams']}, player={intent.get('player')}, stat={intent['stat']}", flush=True)
                
                # ── MULTI-GAME PARLAY ──
                if intent["type"] == "multi_parlay" and len(intent["teams"]) >= 2:
                    print(f"[PARLAY] Multi-game parlay detected: {intent['teams']}", flush=True)
                    conn = _get_db_conn()
                    cur = conn.cursor()
                    parlay_data = []
                    for team_abbr in intent["teams"]:
                        gi = find_game_for_teams(cur, [team_abbr], intent["date_str"])
                        if not gi and intent["date_str"] in ("today", "tonight"):
                            gi = find_game_for_teams(cur, [team_abbr], "next")
                        if not gi:
                            print(f"[PARLAY] No game found for {team_abbr}, aborting parlay", flush=True)
                            break
                        lu = assemble_lineup_for_sim(cur, gi["game_pk"], gi["home_team_id"], gi["away_team_id"])
                        parlay_data.append({"game_info": gi, "lineups": lu, "team_abbr": team_abbr})
                    conn.close()

                    if len(parlay_data) == len(intent["teams"]):
                        parlay_legs = []
                        for pd_item in parlay_data:
                            sr = run_prediction_simulation(pd_item["game_info"], pd_item["lineups"], num_sims=10000)
                            if not sr:
                                print(f"[PARLAY] Sim failed for {pd_item['team_abbr']}", flush=True)
                                break
                            wp = sr.get("win_probabilities", {})
                            gi = pd_item["game_info"]
                            if pd_item["team_abbr"].upper() == gi["home_abbr"].upper():
                                win_pct = wp.get("home_win_pct", 50)
                            else:
                                win_pct = wp.get("away_win_pct", 50)
                            parlay_legs.append({"team_abbr": pd_item["team_abbr"], "win_pct": win_pct})

                        if len(parlay_legs) == len(intent["teams"]):
                            response_text = format_multi_parlay_response(parlay_legs)
                            return {
                                "text": response_text,
                                "visualization": None,
                                "image": None,
                                "imageType": None,
                                "chat_id": request.chat_id or str(uuid.uuid4()),
                                "source": "prediction_parlay",
                            }
                    print("[PARLAY] Multi-parlay failed, falling through", flush=True)

                # ── SINGLE-GAME / PLAYER PREDICTION ──
                if intent["teams"] or intent.get("player"):
                    conn = _get_db_conn()
                    cur = conn.cursor()
                    
                    # If we have a player but no team, try to find their team
                    if intent.get("player") and not intent["teams"]:
                        player_search = intent["player"]
                        player_row = None
                        
                        # Smart player search: prefer active players with recent stats
                        # Join with player_season_stats to prioritize players who actually played recently
                        cur.execute("""
                            SELECT p.player_id, p.full_name, t.abbreviation,
                                   COALESCE(MAX(pss.season), 0) as last_season,
                                   COALESCE(SUM(pss.games_played), 0) as total_gp
                            FROM players p
                            LEFT JOIN teams t ON p.current_team_id = t.team_id
                            LEFT JOIN player_season_stats pss ON p.player_id = pss.player_id
                            WHERE LOWER(p.full_name) LIKE %s
                            GROUP BY p.player_id, p.full_name, t.abbreviation
                            ORDER BY 
                                CASE WHEN t.abbreviation IS NOT NULL THEN 0 ELSE 1 END,
                                COALESCE(MAX(pss.season), 0) DESC,
                                COALESCE(SUM(pss.games_played), 0) DESC
                            LIMIT 1
                        """, (f"%{player_search.lower()}%",))
                        player_row = cur.fetchone()
                        
                        # If no match, try each word separately (first name or last name)
                        if not player_row:
                            for name_part in player_search.split():
                                if len(name_part) < 3:
                                    continue
                                cur.execute("""
                                    SELECT p.player_id, p.full_name, t.abbreviation,
                                           COALESCE(MAX(pss.season), 0) as last_season,
                                           COALESCE(SUM(pss.games_played), 0) as total_gp
                                    FROM players p
                                    LEFT JOIN teams t ON p.current_team_id = t.team_id
                                    LEFT JOIN player_season_stats pss ON p.player_id = pss.player_id
                                    WHERE LOWER(p.full_name) LIKE %s
                                    GROUP BY p.player_id, p.full_name, t.abbreviation
                                    ORDER BY 
                                        CASE WHEN t.abbreviation IS NOT NULL THEN 0 ELSE 1 END,
                                        COALESCE(MAX(pss.season), 0) DESC,
                                        COALESCE(SUM(pss.games_played), 0) DESC
                                    LIMIT 1
                                """, (f"%{name_part.lower()}%",))
                                player_row = cur.fetchone()
                                if player_row:
                                    break
                        
                        if player_row and player_row[2]:
                            # Have both player and team from current_team_id
                            intent["teams"] = [player_row[2]]
                            intent["player"] = player_row[1]  # Use DB full name
                            print(f"[PREDICTION] Resolved player '{player_search}' -> {player_row[1]} ({player_row[2]})", flush=True)
                        elif player_row:
                            # Player found but current_team_id is NULL — try fallbacks
                            intent["player"] = player_row[1]
                            player_id = player_row[0]
                            print(f"[PREDICTION] Found player '{player_search}' -> {player_row[1]} (no current_team_id), trying fallbacks...", flush=True)
                            
                            # Fallback 1: player_season_stats — most reliable (actual games played)
                            cur.execute("""
                                SELECT t.abbreviation
                                FROM player_season_stats pss
                                JOIN teams t ON pss.team_id = t.team_id
                                WHERE pss.player_id = %s AND pss.team_id IS NOT NULL
                                ORDER BY pss.season DESC
                                LIMIT 1
                            """, (player_id,))
                            team_row = cur.fetchone()
                            if team_row:
                                print(f"[PREDICTION] Fallback source: player_season_stats", flush=True)
                            
                            # Fallback 2: pregame_lineups — recent lineup appearance
                            if not team_row:
                                cur.execute("""
                                    SELECT t.abbreviation
                                    FROM pregame_lineups pl
                                    JOIN teams t ON pl.team_id = t.team_id
                                    WHERE pl.player_id = %s
                                    ORDER BY pl.game_pk DESC
                                    LIMIT 1
                                """, (player_id,))
                                team_row = cur.fetchone()
                                if team_row:
                                    print(f"[PREDICTION] Fallback source: pregame_lineups", flush=True)
                            
                            # Fallback 3: player_team_history — last resort (can have stale data)
                            if not team_row:
                                cur.execute("""
                                    SELECT t.abbreviation
                                    FROM player_team_history pth
                                    JOIN teams t ON pth.team_id = t.team_id
                                    WHERE pth.player_id = %s
                                    ORDER BY pth.season DESC, pth.start_date DESC
                                    LIMIT 1
                                """, (player_id,))
                                team_row = cur.fetchone()
                                if team_row:
                                    print(f"[PREDICTION] Fallback source: player_team_history", flush=True)
                            
                            if team_row and team_row[0]:
                                intent["teams"] = [team_row[0]]
                                print(f"[PREDICTION] Fallback found team for {player_row[1]}: {team_row[0]}", flush=True)
                            else:
                                print(f"[PREDICTION] Could not find team for player {player_row[1]}", flush=True)
                        else:
                            print(f"[PREDICTION] Could not find player '{player_search}' in DB", flush=True)
                    
                    # For player queries with no explicit date, use "next" to find upcoming game
                    if intent.get("player") and intent["date_str"] == "today":
                        # Try today first, fall back to "next" if no game today
                        pass  # find_game_for_teams already handles "today"
                    
                    game_info = find_game_for_teams(cur, intent["teams"], intent["date_str"])
                    
                    # If no game found for "today", try finding the next upcoming game
                    if not game_info and intent["date_str"] in ("today", "tonight"):
                        print(f"[PREDICTION] No game today for {intent['teams']}, trying next game...", flush=True)
                        game_info = find_game_for_teams(cur, intent["teams"], "next")
                    
                    if game_info:
                        print(f"[PREDICTION] Found game: {game_info['away_abbr']} @ {game_info['home_abbr']} ({game_info['game_date']})", flush=True)
                        lineups = assemble_lineup_for_sim(cur, game_info["game_pk"],
                                                         game_info["home_team_id"], game_info["away_team_id"])
                        print(f"[PREDICTION] Lineups assembled ({lineups['lineup_source']})", flush=True)
                        conn.close()
                        
                        sim_results = run_prediction_simulation(game_info, lineups, num_sims=10000)
                        if sim_results:
                            response_text = format_prediction_response(intent, sim_results, game_info, lineups)
                            chat_id = request.chat_id or str(uuid.uuid4())
                            
                            # Cache for SGP follow-ups
                            default_leg = _get_default_leg(intent, sim_results)
                            player_info = _find_player_sgp_index(sim_results, intent.get("player", "")) if intent.get("player") else None
                            _prediction_cache[chat_id] = {
                                "sim_results": sim_results,
                                "game_info": game_info,
                                "lineups": lineups,
                                "intent": intent,
                                "player_info": player_info,
                                "legs": [default_leg] if default_leg else [],
                                "conditions": [],
                            }
                            # Keep cache bounded (max 50 chats)
                            if len(_prediction_cache) > 50:
                                oldest = next(iter(_prediction_cache))
                                del _prediction_cache[oldest]
                            
                            return {
                                "text": response_text,
                                "visualization": None,
                                "image": None,
                                "imageType": None,
                                "chat_id": chat_id,
                                "source": "prediction_simulation",
                            }
                        else:
                            print("[PREDICTION] Simulation failed, falling through to SQL path", flush=True)
                    else:
                        conn.close()
                        print(f"[PREDICTION] No game found for {intent['teams']}, falling through", flush=True)
            except Exception as e:
                print(f"[PREDICTION] Error in prediction flow: {e}, falling through to SQL", flush=True)
        # ─── END PREDICTION DETECTION ──────────────────────────────────
        
        # Check if using local Ollama or DeepSeek API
        use_local_ollama = os.getenv('USE_LOCAL_OLLAMA', 'false').lower() == 'true'
        
        # Initialize clients - local Ollama and/or DeepSeek API
        local_client = None
        api_client = None
        local_model = os.getenv('OLLAMA_MODEL', 'deepseek-r1:7b')  # Larger model for better SQL
        api_model = "deepseek-chat"
        
        # Try to set up API clients for fallback (Groq first, then DeepSeek)
        deepseek_api_key = os.getenv('DEEPSEEK_API_KEY')
        groq_api_key = os.getenv('GROQ_API_KEY')
        
        # Set up multiple fallback clients (Groq primary, DeepSeek secondary)
        groq_client = None
        groq_model = "llama-3.3-70b-versatile"
        deepseek_client = None
        deepseek_model = "deepseek-chat"
        
        if groq_api_key:
            groq_client = OpenAI(
                api_key=groq_api_key,
                base_url="https://api.groq.com/openai/v1"
            )
            api_client = groq_client  # Primary fallback
            api_model = groq_model
            print(f"[DEBUG] Groq API client configured for fallback (llama-3.3-70b)", flush=True)
        
        if deepseek_api_key:
            deepseek_client = OpenAI(
                api_key=deepseek_api_key,
                base_url="https://api.deepseek.com"
            )
            if not api_client:  # Use DeepSeek as primary if no Groq
                api_client = deepseek_client
                api_model = deepseek_model
            print(f"[DEBUG] DeepSeek API client configured for fallback", flush=True)
        
        if use_local_ollama:
            # Use local Ollama (no API key needed)
            ollama_base_url = os.getenv('OLLAMA_BASE_URL', 'http://localhost:11434/v1')
            local_client = OpenAI(
                api_key="ollama",  # Ollama doesn't require a real API key
                base_url=ollama_base_url
            )
            client = local_client
            model_name = local_model
            print(f"[DEBUG] Using local Ollama with model: {model_name}", flush=True)
        else:
            # Use DeepSeek API (requires API key)
            if not deepseek_api_key:
                raise HTTPException(500, f"DEEPSEEK_API_KEY not configured. Get a free key at https://platform.deepseek.com/\nOr set USE_LOCAL_OLLAMA=true to use local Ollama.\n.env path checked: {env_path}")
            client = api_client
            model_name = api_model
            print(f"[DEBUG] Using DeepSeek API", flush=True)
        
        # ========================================================================
        # EARLY FOLLOW-UP DETECTION (before classification)
        # ========================================================================
        is_chart_only_follow_up = False
        if request.previous_messages and len(request.previous_messages) > 0:
            _last_user = None
            for msg in reversed(request.previous_messages):
                if msg.get('role') == 'user':
                    _last_user = msg.get('content', '')
                    break
            if _last_user:
                _cur = request.message.lower().strip()
                _pure = [
                    'create a bar chart', 'create a chart', 'create a graph',
                    'bar chart', 'show me a chart', 'show me a graph',
                    'show me a bar chart', 'make a chart', 'make a bar chart',
                    'make a graph', 'line chart', 'scatter plot', 'histogram',
                    'hbar', 'show it as a chart', 'chart it', 'graph it',
                    'visualize it', 'make it a chart', 'now as a chart',
                    'create a visualization', 'create a scatter plot',
                    'create a line chart', 'create a violin plot',
                ]
                is_chart_only_follow_up = (
                    _cur in _pure or
                    (len(request.message.split()) <= 6 and any(kw in _cur for kw in _pure))
                )
        
        # ========================================================================
        # QUERY CLASSIFICATION & ROUTING
        # ========================================================================
        # For chart follow-ups, skip classification — the data came from database
        if is_chart_only_follow_up:
            classification = {"source": "database", "confidence": 1.0, "reasoning": "Chart follow-up — re-using original data source"}
            print(f"[DEBUG] Chart follow-up → forced to database (skipping classification)", flush=True)
        else:
            classification = classify_query_source(
                user_message=request.message,
                conversation_context=request.previous_messages,
                use_local_ollama=use_local_ollama,
                local_client=local_client,
                local_model=local_model,
                api_client=api_client,
                api_model=api_model
            )
        
        query_source = classification.get("source", "database")
        print(f"[DEBUG] Query classified as: {query_source} (confidence: {classification.get('confidence', 0.5):.2f})", flush=True)
        
        # Route to appropriate handler based on classification
        if query_source == "pybaseball":
            from pybaseball_helper import PybaseballQueryHandler
            
            # Check tier restrictions (MASTER/DIAMOND only)
            user_tier = None
            if key_info:
                user_tier = key_info.get("tier", "BASE")
            
            if user_tier not in ["MASTER", "DIAMOND", "ENDBOSS"]:
                # Fall back to database query
                print(f"[DEBUG] Tier {user_tier} cannot access pybaseball, falling back to database", flush=True)
                query_source = "database"
            else:
                # Handle pybaseball query
                try:
                    # Simple extraction: try to get player name or stat from query
                    query_lower = request.message.lower()
                    
                    # Check for player stats query
                    if any(word in query_lower for word in ["stats", "statistics", "show me", "get"]):
                        # "career stats" or multi-season requests → fall back to database
                        # (our DB has season-by-season data; pybaseball only returns 1 season at a time)
                        is_career = any(w in query_lower for w in ["career", "all time", "all-time", "lifetime", "all seasons"])
                        if is_career:
                            print(f"[DEBUG] Career/multi-season request → falling back to database", flush=True)
                            query_source = "database"
                        else:
                            # Extract player name using LLM
                            extract_prompt = f"""Extract the player name from this query. Return ONLY the player's full name, nothing else.

Query: "{request.message}"

Player name:"""
                            
                            player_name_text, _ = call_llm_with_fallback(
                                prompt=extract_prompt,
                                use_local_ollama=use_local_ollama,
                                local_client=local_client,
                                local_model=local_model,
                                api_client=api_client,
                                api_model=api_model,
                                max_tokens=50,
                                temperature=0.0
                            )
                            player_name = player_name_text.strip().strip('"').strip("'")
                            
                            # Try to extract a specific season from the query
                            import re as re_mod
                            season_match = re_mod.search(r'\b(20\d{2})\b', request.message)
                            target_season = int(season_match.group(1)) if season_match else None
                            
                            # Get player stats
                            result = PybaseballQueryHandler.get_player_stats(player_name, season=target_season)
                            
                            if "error" in result:
                                # Fall back to database
                                query_source = "database"
                            else:
                                # Format player stats as a clean TEXT response
                                season_label = result.get('season', 'Current')
                                text_response = f"**{result.get('player_name', player_name)}** — {season_label} Season\n\n"
                                
                                batting = result.get("batting_stats")
                                if batting:
                                    text_response += "**Batting**\n"
                                    stat_fields = [
                                        ("G", "Games"), ("AB", "At Bats"), ("H", "Hits"),
                                        ("2B", "Doubles"), ("3B", "Triples"), ("HR", "Home Runs"),
                                        ("RBI", "RBI"), ("BB", "Walks"), ("SO", "Strikeouts"),
                                        ("SB", "Stolen Bases"), ("AVG", "Batting Avg"),
                                        ("OBP", "On-Base Pct"), ("SLG", "Slugging"), ("OPS", "OPS")
                                    ]
                                    for key, label in stat_fields:
                                        val = batting.get(key)
                                        if val is not None:
                                            if key in ("AVG", "OBP", "SLG", "OPS"):
                                                text_response += f"• {label}: {float(val):.3f}\n"
                                            else:
                                                text_response += f"• {label}: {val}\n"
                                
                                pitching = result.get("pitching_stats")
                                if pitching:
                                    text_response += "\n**Pitching**\n"
                                    pitch_fields = [
                                        ("W", "Wins"), ("L", "Losses"), ("ERA", "ERA"),
                                        ("G", "Games"), ("GS", "Games Started"),
                                        ("IP", "Innings Pitched"), ("SO", "Strikeouts"),
                                        ("BB", "Walks"), ("WHIP", "WHIP"), ("SV", "Saves")
                                    ]
                                    for key, label in pitch_fields:
                                        val = pitching.get(key)
                                        if val is not None:
                                            if key in ("ERA", "WHIP"):
                                                text_response += f"• {label}: {float(val):.2f}\n"
                                            else:
                                                text_response += f"• {label}: {val}\n"
                                
                                if not batting and not pitching:
                                    # No stats found for this season — fall back to database
                                    print(f"[DEBUG] Pybaseball returned no stats, falling back to database", flush=True)
                                    query_source = "database"
                                else:
                                    text_response += "\nData from Diamond Quant Database"
                                    
                                    chat_id = request.chat_id or str(uuid.uuid4())
                                    return {
                                        "text": text_response,
                                        "image": None,
                                        "imageType": None,
                                        "chat_id": chat_id,
                                        "source": "pybaseball",
                                        "attribution": "Data from MLB Stats API via Pybaseball"
                                    }
                    
                    # Check for season leaders query
                    elif any(word in query_lower for word in ["leader", "leads", "top", "best"]):
                        # Extract stat name (simplified)
                        stat_extract_prompt = f"""Extract the statistic name from this query. Return ONLY the stat name (e.g., "home runs", "RBIs", "ERA"), nothing else.

Query: "{request.message}"

Stat name:"""
                        
                        stat_name_text, _ = call_llm_with_fallback(
                            prompt=stat_extract_prompt,
                            use_local_ollama=use_local_ollama,
                            local_client=local_client,
                            local_model=local_model,
                            api_client=api_client,
                            api_model=api_model,
                            max_tokens=30,
                            temperature=0.0
                        )
                        stat_name = stat_name_text.strip().strip('"').strip("'")
                        
                        # Map common stat names to pybaseball column names
                        stat_mapping = {
                            "home runs": "HR",
                            "hr": "HR",
                            "rbis": "RBI",
                            "rbi": "RBI",
                            "batting average": "AVG",
                            "avg": "AVG",
                            "ops": "OPS",
                            "era": "ERA",
                            "wins": "W",
                            "strikeouts": "SO"
                        }
                        pybaseball_stat = stat_mapping.get(stat_name.lower(), stat_name.upper())
                        
                        leaders = PybaseballQueryHandler.get_season_leaders(pybaseball_stat, limit=10)
                        
                        if leaders:
                            chartspec = build_chartspec_from_data(leaders, request.message, list(leaders[0].keys()) if leaders else [])
                            from chart_renderer import render_chart
                            png_bytes = render_chart(chartspec, request.message)
                            import base64
                            png_base64 = base64.b64encode(png_bytes).decode('utf-8')
                            
                            chat_id = request.chat_id or str(uuid.uuid4())
                            return {
                                "text": f"Here are the current season leaders for {stat_name}:",
                                "image": png_base64,
                                "imageType": "base64",
                                "chat_id": chat_id,
                                "source": "pybaseball",
                                "attribution": "Data from MLB Stats API via Pybaseball"
                            }
                        else:
                            query_source = "database"  # Fall back
                    
                    else:
                        # Unrecognized pybaseball query pattern, fall back to database
                        query_source = "database"
                        
                except Exception as e:
                    print(f"[ERROR] Pybaseball handler failed: {e}, falling back to database", flush=True)
                    query_source = "database"
        
        elif query_source == "statmuse":
            # Check tier restrictions (MASTER/DIAMOND only)
            user_tier = None
            if key_info:
                user_tier = key_info.get("tier", "BASE")
            
            if user_tier not in ["MASTER", "DIAMOND", "ENDBOSS"]:
                # Fall back to database query
                print(f"[DEBUG] Tier {user_tier} cannot access StatMuse queries, falling back to database", flush=True)
                query_source = "database"
            else:
                # Execute StatMuse-style query
                try:
                    result = await execute_statmuse_query(
                        query=request.message,
                        conversation_context=request.previous_messages,
                        use_local_ollama=use_local_ollama,
                        local_client=local_client,
                        local_model=local_model,
                        api_client=api_client,
                        api_model=api_model
                    )
                    
                    chat_id = request.chat_id or str(uuid.uuid4())
                    
                    # Check if StatMuse result includes visualizable data
                    data_points = result.get("data", [])
                    if data_points and len(data_points) > 0:
                        # Try to create a visualization from the data
                        try:
                            chartspec = build_chartspec_from_data(data_points, request.message, list(data_points[0].keys()) if data_points else [])
                            from chart_renderer import render_chart
                            png_bytes = render_chart(chartspec, request.message)
                            import base64
                            png_base64 = base64.b64encode(png_bytes).decode('utf-8')
                            
                            return {
                                "text": result.get("text", ""),
                                "image": png_base64,
                                "imageType": "base64",
                                "chat_id": chat_id,
                                "source": "statmuse",
                                "attribution": result.get("attribution", "Powered by StatMuse-style queries")
                            }
                        except Exception as viz_error:
                            print(f"[DEBUG] StatMuse visualization failed, returning text only: {viz_error}", flush=True)
                    
                    return {
                        "text": result.get("text", ""),
                        "image": None,
                        "imageType": None,
                        "chat_id": chat_id,
                        "source": "statmuse",
                        "attribution": result.get("attribution", "Powered by StatMuse-style queries")
                    }
                except Exception as e:
                    print(f"[ERROR] StatMuse handler failed: {e}, falling back to database", flush=True)
                    query_source = "database"
        
        # If query_source is still "database" or "hybrid", continue with SQL generation
        # (hybrid queries will use database as primary source for now)
        
        # Connect to database
        conn = _get_db_conn()
        cur = conn.cursor()
        
        # Get ALL database tables
        cur.execute("""
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_schema = 'public' 
            AND table_type = 'BASE TABLE'
            ORDER BY table_name
        """)
        tables = [row[0] for row in cur.fetchall()]
        
        # Get detailed schema for ALL tables (full database access)
        schema_info = {}
        for table in tables:
            cur.execute("""
                SELECT column_name, data_type, is_nullable
                FROM information_schema.columns 
                WHERE table_schema = 'public' 
                AND table_name = %s
                ORDER BY ordinal_position
            """, (table,))
            columns = []
            for row in cur.fetchall():
                col_name, data_type, is_nullable = row
                nullable = "NULL" if is_nullable == 'YES' else "NOT NULL"
                columns.append(f"{col_name} ({data_type}, {nullable})")
            schema_info[table] = columns
        
        # Build complete schema description for ALL tables (formatted for LLM)
        schema_lines = []
        for table in tables:
            cols = schema_info.get(table, [])
            # Format: TABLE_NAME: col1 (type), col2 (type), ...
            col_list = ", ".join([c.split(' (')[0] + " (" + c.split(' (')[1].split(',')[0] + ")" for c in cols])
            schema_lines.append(f"{table}: {col_list}")
        schema_description = "\n".join(schema_lines)
        
        # Load asset knowledge base
        assets_file = PROJECT_ROOT / "DIAMOND_QUANT_ASSETS.md"
        assets_knowledge = ""
        if assets_file.exists():
            with open(assets_file, 'r') as f:
                assets_knowledge = f.read()
        
        # Build available fields list for ChartSpec
        available_fields = []
        for table, columns in schema_info.items():
            for col in columns:
                col_name = col.split(' (')[0]  # Extract column name
                available_fields.append(f"{table}.{col_name}")
        
        # Build conversation context from previous messages
        conversation_context = ""
        last_user_query = None
        is_chart_only_follow_up = False
        if request.previous_messages and len(request.previous_messages) > 0:
            # Get last user message for follow-up context
            for msg in reversed(request.previous_messages):
                if msg.get('role') == 'user':
                    last_user_query = msg.get('content', '')
                    break
            
            # Detect chart-only follow-ups: "Create a bar chart" with NO data context
            # These are VERY short messages that ONLY ask for a chart type, nothing else
            # NOT: "Violin plot of batting average by position" (has data context!)
            current_lower = request.message.lower().strip()
            
            # Only merge if the message is purely a chart type request with no data subject
            pure_chart_requests = [
                'create a bar chart', 'create a chart', 'create a graph',
                'bar chart', 'show me a chart', 'show me a graph',
                'show me a bar chart', 'make a chart', 'make a bar chart',
                'make a graph', 'line chart', 'scatter plot', 'histogram',
                'hbar', 'show it as a chart', 'chart it', 'graph it',
                'visualize it', 'make it a chart', 'now as a chart',
                'create a visualization', 'create a scatter plot',
                'create a line chart', 'create a violin plot',
            ]
            # Must be a SHORT message (<=6 words) OR an exact match to pure chart requests
            is_chart_only_follow_up = (
                last_user_query and
                (
                    current_lower in pure_chart_requests or
                    (len(request.message.split()) <= 6 and any(kw in current_lower for kw in pure_chart_requests))
                )
            )
            
            if is_chart_only_follow_up:
                # Rewrite: merge previous data question + current chart type
                original_message = request.message
                request.message = f"{last_user_query} — {original_message}"
                print(f"[DEBUG] Chart follow-up detected. Merged: '{request.message}'", flush=True)
            else:
                print(f"[DEBUG] NOT a chart follow-up (standalone query)", flush=True)
            
            # Build context with example of expected modification
            if last_user_query:
                context_lines = ["## CONVERSATION CONTEXT"]
                context_lines.append(f"Previous request: \"{last_user_query}\"")
                context_lines.append(f"Current request: \"{request.message}\"")
                context_lines.append("")
                context_lines.append("IMPORTANT: If the current request is about charting/visualizing the same data,")
                context_lines.append("re-generate the SAME SQL query as you would for the previous request.")
                context_lines.append("")
                context_lines.append("EXAMPLE: If previous was 'top 10 teams by home runs' and current is 'Create a bar chart', output:")
                context_lines.append("SELECT t.name, t.abbreviation, t.team_id, SUM(pss.home_runs) as home_runs")
                context_lines.append("FROM player_season_stats pss")
                context_lines.append("JOIN player_team_history pth ON pss.player_id = pth.player_id AND pss.season = pth.season")
                context_lines.append("JOIN teams t ON pth.team_id = t.team_id")
                context_lines.append("WHERE pss.season = 2024 AND pss.player_type = 'batter'")
                context_lines.append("GROUP BY t.team_id, t.name, t.abbreviation")
                context_lines.append("ORDER BY home_runs DESC LIMIT 10;")
                conversation_context = "\n".join(context_lines)
                print(f"[DEBUG] Conversation context provided for follow-up", flush=True)
        
        # Build pattern-completion prompt with comprehensive schema and examples
        sql_prompt = f"""You are a PostgreSQL query generator for an MLB baseball analytics database.
Generate ONLY the SQL query, no explanations.

## IMPORTANT RULES
1. Output ONLY raw SQL. No explanations, no markdown, no code blocks.
2. Use PostgreSQL syntax: use LIMIT N (NOT "TOP N" which is SQL Server)
3. If follow-up query (like "Do just 2024", "Top 5 instead"), modify the PREVIOUS query
4. Always include team_id AND abbreviation when querying teams (for logos)
5. Always include player_id when querying players (for headshots)
6. Season uses integers: WHERE season = 2024 (not '2024')
7. home_runs column is in player_season_stats, NOT a separate table

## COMPLETE DATABASE SCHEMA

### players (alias: p)
player_id (integer PK), full_name, first_name, last_name, primary_position_code, bat_side_code, pitch_hand_code, current_team_id, active (boolean)

### teams (alias: t) 
team_id (integer PK), name, abbreviation, location_name, league_name, division_name, active

### player_hierarchical_stats (alias: phs) - Bayesian hierarchical stats
id, player_id (FK), season (integer), player_type ('batter' or 'pitcher'),
BATTING: player_hier_avg, player_hier_obp, player_hier_slg, player_hier_ops, team_effect_batting_avg, team_effect_ops
PITCHING: player_hier_era, player_hier_whip, player_hier_k_per_9, player_hier_bb_per_9, team_effect_era

### player_season_stats (alias: pss) - Season totals per player
id, player_id (FK), season, team_id (FK), player_type ('batter' or 'pitcher'),
games_played, plate_appearances, at_bats, hits, doubles, triples, home_runs, rbi, walks, strikeouts,
batting_avg, obp, slg, ops, stolen_bases, caught_stealing,
games_pitched, innings_pitched, earned_runs, era, hits_allowed, walks_allowed, strikeouts_pitched, k_per_9, bb_per_9, whip

### player_team_history (alias: pth)
id, player_id (FK), team_id (FK), season, start_date, end_date

### games
game_pk (PK), season, game_type, game_date, venue_name, home_team_id, away_team_id, home_score, away_score, home_pitcher_id, away_pitcher_id

### team_season_stats
id, team_id, season, wins, losses, runs_scored, runs_allowed, team_era, team_batting_avg, team_ops

## KEY NOTES
- player_type is in phs and pss, NOT in players table. Values: 'batter' or 'pitcher'
- For team-level aggregation (e.g. "home runs by team"): JOIN player_team_history (pth) to get team_id, then JOIN teams
  Example: pss JOIN player_team_history pth ON pss.player_id = pth.player_id AND pss.season = pth.season JOIN teams t ON pth.team_id = t.team_id
- DO NOT USE player_season_stats.team_id - it is often NULL. Use player_team_history instead.
- WARNING: player_team_history has MULTIPLE rows per player per season (one per game/series).
  Do NOT join pth when querying individual player stats — it creates duplicate rows!
  For single-player queries, just use pss JOIN players p. Only join pth when you need team info.
- H-Score = player_hier_ops * 100. ONLY use h_score if user explicitly says "H-Score". If user says "OPS" or "hierarchical OPS", return player_hier_ops directly
- Column aliases cannot be used in WHERE/ORDER BY - use the actual column
- singles column does NOT exist - calculate as: hits - doubles - triples - home_runs
- Current season is 2025
- For "career stats" or "all-time" queries: do NOT add a season filter — return ALL seasons
- To find a player by name: use ILIKE '%LastName%' on p.full_name
- For SCATTER PLOTS / CORRELATION: Return raw data points (both columns), NOT CORR() aggregate
- For DISTRIBUTIONS / HISTOGRAMS: Return the individual values, not aggregates
- For VIOLIN PLOTS: Return INDIVIDUAL rows per category — do NOT use AVG() or GROUP BY.
  Example: "Violin plot of batting average by position" → return each player's batting_avg with their position code, NOT the average per position
- ALWAYS include p.player_id when selecting player data (needed for headshots)
- ALWAYS include t.abbreviation when selecting team data (needed for team colors)

## EXAMPLES

User: Top 10 batters by H-Score
SELECT p.player_id, p.full_name, phs.player_hier_ops * 100 AS h_score
FROM player_hierarchical_stats phs
JOIN players p ON phs.player_id = p.player_id
WHERE phs.player_type = 'batter' AND phs.season = 2025
ORDER BY phs.player_hier_ops DESC LIMIT 10;

User: Which players have the highest hierarchical OPS? (return raw OPS, NOT h_score)
SELECT p.player_id, p.full_name, phs.player_hier_ops
FROM player_hierarchical_stats phs
JOIN players p ON phs.player_id = p.player_id
WHERE phs.player_type = 'batter' AND phs.season = 2025
ORDER BY phs.player_hier_ops DESC LIMIT 10;

User: Singles distribution by team
SELECT t.abbreviation, SUM(pss.hits - pss.doubles - pss.triples - pss.home_runs) AS singles
FROM player_season_stats pss
JOIN player_team_history pth ON pss.player_id = pth.player_id AND pss.season = pth.season
JOIN teams t ON pth.team_id = t.team_id
WHERE pss.season = 2025 AND pss.player_type = 'batter'
GROUP BY t.team_id, t.abbreviation ORDER BY singles DESC;

User: Players with hierarchical batting average over 0.265 in 2025
SELECT p.player_id, p.full_name, phs.player_hier_avg
FROM player_hierarchical_stats phs
JOIN players p ON phs.player_id = p.player_id
WHERE phs.player_type = 'batter' AND phs.season = 2025 AND phs.player_hier_avg > 0.265
ORDER BY phs.player_hier_avg DESC;

User: Top pitchers by ERA in 2025
SELECT p.player_id, p.full_name, phs.player_hier_era
FROM player_hierarchical_stats phs JOIN players p ON phs.player_id = p.player_id
WHERE phs.player_type = 'pitcher' AND phs.season = 2025 AND phs.player_hier_era IS NOT NULL
ORDER BY phs.player_hier_era ASC LIMIT 10;

User: Mike Trout's career stats (ALL seasons, no season filter, NO pth join)
SELECT p.player_id, p.full_name, pss.season, pss.games_played, pss.at_bats, pss.hits, pss.home_runs, pss.batting_avg, pss.obp, pss.slg, pss.ops
FROM player_season_stats pss
JOIN players p ON pss.player_id = p.player_id
WHERE p.full_name ILIKE '%Trout%' AND pss.player_type = 'batter'
ORDER BY pss.season;

User: Aaron Judge's 2024 stats (single player, NO pth join)
SELECT p.player_id, p.full_name, pss.season, pss.games_played, pss.at_bats, pss.hits, pss.home_runs, pss.batting_avg, pss.obp, pss.slg, pss.ops
FROM player_season_stats pss
JOIN players p ON pss.player_id = p.player_id
WHERE p.full_name ILIKE '%Judge%' AND pss.season = 2024 AND pss.player_type = 'batter';

User: Home runs by team
SELECT t.name, t.abbreviation, SUM(pss.home_runs) AS total_hr
FROM player_season_stats pss
JOIN player_team_history pth ON pss.player_id = pth.player_id AND pss.season = pth.season
JOIN teams t ON pth.team_id = t.team_id
WHERE pss.season = 2025 AND pss.player_type = 'batter'
GROUP BY t.team_id, t.name, t.abbreviation ORDER BY total_hr DESC;

User: Correlation between home runs and strikeouts (scatter plot)
SELECT p.full_name, pss.home_runs, pss.strikeouts
FROM player_season_stats pss
JOIN players p ON pss.player_id = p.player_id
WHERE pss.season = 2025 AND pss.player_type = 'batter' AND pss.plate_appearances > 100;

User: ERA distribution for pitchers (histogram)
SELECT phs.player_hier_era
FROM player_hierarchical_stats phs
WHERE phs.player_type = 'pitcher' AND phs.season = 2025 AND phs.player_hier_era IS NOT NULL;

User: Violin plot of batting average by position
SELECT p.primary_position_code, pss.batting_avg
FROM player_season_stats pss
JOIN players p ON pss.player_id = p.player_id
WHERE pss.season = 2025 AND pss.player_type = 'batter' AND pss.plate_appearances > 50
ORDER BY p.primary_position_code;

User: Team win/loss records
SELECT t.name, t.abbreviation, t.team_id, tss.wins, tss.losses
FROM team_season_stats tss JOIN teams t ON tss.team_id = t.team_id
WHERE tss.season = 2025 ORDER BY tss.wins DESC;

User: Top 10 teams by home runs in 2024
SELECT t.name, t.abbreviation, t.team_id, SUM(pss.home_runs) as home_runs
FROM player_season_stats pss 
JOIN player_team_history pth ON pss.player_id = pth.player_id AND pss.season = pth.season
JOIN teams t ON pth.team_id = t.team_id
WHERE pss.season = 2024 AND pss.player_type = 'batter'
GROUP BY t.team_id, t.name, t.abbreviation
ORDER BY home_runs DESC LIMIT 10;

## FULL TABLE LIST
{schema_description}

{conversation_context}
Generate SQL for: {request.message}
"""
        
        # Call LLM with automatic fallback from local to API
        try:
            print(f"[DEBUG] Generating SQL query...", flush=True)
            assistant_message, used_api_fallback = call_llm_with_fallback(
                prompt=sql_prompt,
                use_local_ollama=use_local_ollama,
                local_client=local_client,
                local_model=local_model,
                api_client=api_client,
                api_model=api_model,
                max_tokens=1024,
                temperature=0.0,
                extract_type="sql"
            )
            
            if used_api_fallback:
                print(f"[DEBUG] Used DeepSeek API fallback for SQL generation", flush=True)
            
            print(f"[DEBUG] LLM response: {assistant_message[:500] if assistant_message else 'None'}", flush=True)
            
        except Exception as e:
            print(f"[ERROR] LLM SQL generation failed: {e}", flush=True)
            import traceback
            traceback.print_exc()
            raise HTTPException(500, f"LLM API call failed: {str(e)}")
        
        # Check if Groq returned an image (base64 PNG or image URL)
        image_data = None
        image_url = None
        
        # Check for base64 image data
        import base64
        # re_module is already imported at the top of the function
        
        # Look for base64 image data (data:image/png;base64,...)
        base64_pattern = r'data:image/(png|jpeg|jpg);base64,([A-Za-z0-9+/=]+)'
        base64_match = re_module.search(base64_pattern, assistant_message)
        if base64_match:
            image_data = base64_match.group(2)
            image_type = base64_match.group(1)
        
        # Look for image URLs
        url_pattern = r'https?://[^\s]+\.(png|jpg|jpeg|gif|webp)'
        url_match = re_module.search(url_pattern, assistant_message, re_module.IGNORECASE)
        if url_match:
            image_url = url_match.group(0)
        
        # If we found an image, return it directly
        if image_data or image_url:
            chat_id = request.chat_id or str(uuid.uuid4())
            conn.close()
            return {
                "text": "",
                "image": image_data or image_url,
                "imageType": "base64" if image_data else "url",
                "chat_id": chat_id
            }
        
        # Extract SQL from LLM response (helper may have already extracted it)
        sql_query = None
        visualization = None
        
        # The helper function extract_sql_from_response was already called by call_llm_with_fallback
        # If assistant_message starts with SELECT, it's already extracted SQL
        # Otherwise, try to extract it again
        if assistant_message and assistant_message.strip().upper().startswith('SELECT'):
            sql_query = assistant_message.strip()
            print(f"[DEBUG] Using pre-extracted SQL: {sql_query[:200]}", flush=True)
        else:
            # Try to extract SQL using the helper (in case raw response was returned)
            extracted = extract_sql_from_response(assistant_message)
            if extracted:
                sql_query = extracted
                print(f"[DEBUG] Extracted SQL from response: {sql_query[:200]}", flush=True)
            else:
                print(f"[WARNING] No SQL found in response. Full response: {assistant_message[:500] if assistant_message else 'None'}", flush=True)
            
        # Execute SQL query if found
        if sql_query and sql_query.upper().startswith("SELECT"):
            print(f"[DEBUG] Executing SQL query...", flush=True)
            try:
                # re_module is already imported at the top of the function
                
                # Validate SQL is read-only (basic check)
                sql_upper = sql_query.upper().strip()
                dangerous_keywords = ['INSERT', 'UPDATE', 'DELETE', 'DROP', 'ALTER', 'CREATE', 'TRUNCATE', 'EXEC', 'EXECUTE']
                if any(keyword in sql_upper for keyword in dangerous_keywords):
                    raise Exception("Only SELECT queries are allowed")
                
                # Fix common SQL errors from small local models
                
                # Fix 1: Remove incorrect 'p.' alias when only querying 'players' table without JOIN
                if re_module.search(r'\bFROM\s+players\s+LIMIT', sql_query, re_module.IGNORECASE) and 'JOIN' not in sql_query.upper():
                    sql_query = re_module.sub(r'\bp\.(\w+)', r'\1', sql_query)
                    print(f"[DEBUG] Fixed: Removed unnecessary 'p.' alias", flush=True)
                
                # Fix 2: p.player_type -> phs.player_type when joining with player_hierarchical_stats
                if 'p.player_type' in sql_query and 'player_hierarchical_stats' in sql_query:
                    sql_query = sql_query.replace('p.player_type', 'phs.player_type')
                    print(f"[DEBUG] Fixed table alias: p.player_type -> phs.player_type", flush=True)
                
                # Fix 3: Ensure proper table aliases are defined when used
                # If query uses 'p.' but doesn't have 'AS p' or 'players p', add it
                if re_module.search(r'\bp\.\w+', sql_query) and not re_module.search(r'players\s+(as\s+)?p\b', sql_query, re_module.IGNORECASE):
                    sql_query = re_module.sub(r'\bFROM\s+players\b', 'FROM players p', sql_query, flags=re_module.IGNORECASE)
                    print(f"[DEBUG] Fixed: Added missing 'p' alias to players table", flush=True)
                
                # Fix 4: Remove common hallucinated table references
                hallucinated_tables = ['playergames', 'gameresult', 'totalscore']
                for table in hallucinated_tables:
                    if table.lower() in sql_query.lower():
                        print(f"[WARNING] Query references non-existent table: {table}", flush=True)
                
                # Fix GROUP BY issues: Remove unnecessary GROUP BY with COUNT(*) if not needed
                # If query has GROUP BY but only one aggregate (COUNT), and it's a top N query, remove GROUP BY
                if 'GROUP BY' in sql_query.upper() and 'COUNT(*)' in sql_query.upper() and 'LIMIT' in sql_query.upper():
                    # Check if COUNT is the only aggregate and it's not needed
                    sql_upper = sql_query.upper()
                    aggregate_functions = ['SUM(', 'AVG(', 'MIN(', 'MAX(', 'COUNT(']
                    aggregate_count = sum(1 for func in aggregate_functions if func in sql_upper)
                    
                    # If only COUNT(*) and it's a simple top N query, remove GROUP BY and COUNT
                    if aggregate_count == 1 and 'COUNT(*)' in sql_upper:
                        # Remove COUNT(*) column
                        sql_query = re_module.sub(r',\s*COUNT\(\*\)\s+AS\s+\w+', '', sql_query, flags=re_module.IGNORECASE)
                        sql_query = re_module.sub(r'COUNT\(\*\)\s+AS\s+\w+\s*,', '', sql_query, flags=re_module.IGNORECASE)
                        # Remove GROUP BY clause
                        sql_query = re_module.sub(r'\s+GROUP\s+BY\s+[^ORDER\s]+', '', sql_query, flags=re_module.IGNORECASE)
                        print(f"[DEBUG] Removed unnecessary GROUP BY and COUNT(*)", flush=True)
                
                cur.execute(sql_query)
                rows = cur.fetchall()
                colnames = [desc[0] for desc in cur.description]
                
                # Convert to data
                data = [dict(zip(colnames, row)) for row in rows]
                
                if len(data) > 0:
                    # ============================================================
                    # SMART RESPONSE TYPE DETECTION
                    # Only visualize when user EXPLICITLY asks for a chart/plot/graph
                    # Otherwise return a well-formatted text response with offer to chart
                    # ============================================================
                    query_lower = request.message.lower()
                    
                    # EXPLICIT visualization requests - user specifically wants a chart
                    explicit_viz_keywords = [
                        'chart', 'graph', 'plot', 'visualize', 'visualization',
                        'bar chart', 'scatter', 'histogram', 'violin', 'heatmap',
                        'lollipop', 'boxplot', 'pie', 'line chart', 'draw',
                        'create a bar', 'create a chart', 'create a graph',
                        'show me a plot', 'show me a chart', 'show me a graph',
                        'make a chart', 'make a graph', 'make a plot'
                    ]
                    is_explicit_viz = any(kw in query_lower for kw in explicit_viz_keywords)
                    
                    # NON-visualization queries - user is asking a QUESTION
                    question_patterns = [
                        'which', 'who', 'what', 'how many', 'how much',
                        'tell me', 'list', 'is', 'are', 'does', 'do',
                        'highest', 'lowest', 'best', 'worst', 'most', 'least',
                        'career stats', 'stats for', 'statistics'
                    ]
                    is_question = any(kw in query_lower for kw in question_patterns)
                    
                    # Decision: visualize ONLY if user explicitly asks for a chart/plot/graph
                    # Questions like "Which players have the highest OPS?" → TEXT
                    # Requests like "Show me a violin plot of ERA by team" → CHART
                    should_visualize = is_explicit_viz
                    
                    print(f"[DEBUG] Response type: viz={should_visualize}, explicit_viz={is_explicit_viz}, question={is_question}", flush=True)
                    
                    if should_visualize:
                        # User explicitly asked for a chart/plot/graph
                        print(f"[DEBUG] Generating ChartSpec from data ({len(data)} rows)", flush=True)
                        chartspec = build_chartspec_from_data(data, request.message, colnames)
                        print(f"[DEBUG] Generated ChartSpec: chart_type={chartspec.get('chart_type')}, x={chartspec.get('x_field')}, y={chartspec.get('y_field')}", flush=True)
                        
                        from chart_renderer import render_chart
                        png_bytes = render_chart(chartspec, request.message)
                        
                        import base64
                        png_base64 = base64.b64encode(png_bytes).decode('utf-8')
                        
                        chat_id = request.chat_id or str(uuid.uuid4())
                        conn.close()
                        return {
                            "text": "",
                            "image": png_base64,
                            "imageType": "base64",
                            "chat_id": chat_id,
                            "source": query_source if query_source in ["database", "hybrid"] else "database",
                            "attribution": "Data from Diamond Quant Database" if query_source == "database" else "Data from Diamond Quant Database & MLB Stats API"
                        }
                    else:
                        # Return well-formatted TEXT response with the data
                        chat_id = request.chat_id or str(uuid.uuid4())
                        conn.close()
                        
                        # Smart formatting: detect columns
                        first_row = data[0]
                        skip_cols = {'player_id', 'team_id', 'id'}
                        display_cols = [c for c in colnames if c.lower() not in skip_cols]
                        
                        # Find the label column (name/abbreviation) and key metrics
                        name_col = None
                        season_col = None
                        numeric_cols_list = []
                        for c in display_cols:
                            val = first_row.get(c)
                            c_lower = c.lower()
                            if c_lower == 'season':
                                season_col = c
                            elif isinstance(val, str) and name_col is None:
                                name_col = c
                            elif isinstance(val, (int, float, Decimal)):
                                numeric_cols_list.append(c)
                        
                        def fmt_val(v):
                            if isinstance(v, float):
                                return f"{v:.3f}" if abs(v) < 10 else f"{v:.1f}" if abs(v) < 100 else f"{int(v):,}"
                            elif isinstance(v, int):
                                return f"{v:,}"
                            return str(v)
                        
                        # Pre-check: find columns that are all-zero so we can hide them
                        all_zero_cols = set()
                        for c in numeric_cols_list:
                            if all(row.get(c) == 0 or row.get(c) is None for row in data):
                                all_zero_cols.add(c)
                        
                        if len(data) == 1:
                            # Single result - detailed stat line
                            row = data[0]
                            label = row.get(name_col, '') if name_col else ''
                            season = row.get(season_col, '') if season_col else ''
                            header = f"**{label}**" if label else ""
                            if season:
                                header += f" — {season} Season"
                            text_response = f"{header}\n\n" if header else ""
                            for key in display_cols:
                                if key in (name_col, season_col):
                                    continue
                                if key in all_zero_cols:
                                    continue  # Skip columns that are all 0
                                value = row.get(key)
                                if value is not None:
                                    formatted_key = key.replace('_', ' ').title()
                                    text_response += f"• {formatted_key}: {fmt_val(value)}\n"
                        
                        elif len(data) <= 15:
                            text_response = ""
                            # Check if all rows have the same name (player career stats)
                            all_same_name = name_col and len(set(row.get(name_col) for row in data)) == 1
                            
                            if all_same_name and season_col:
                                # Career season-by-season data for one player
                                player_name = data[0].get(name_col, '')
                                text_response = f"**{player_name}** — Season-by-Season\n\n"
                                # Filter out all-zero columns
                                useful_cols = [c for c in numeric_cols_list if c not in all_zero_cols]
                                for row in data:
                                    season = row.get(season_col, '?')
                                    stats = []
                                    for c in useful_cols[:6]:  # Show top 6 useful stats
                                        v = row.get(c)
                                        if v is not None:
                                            stats.append(f"{c.replace('_', ' ').title()}: {fmt_val(v)}")
                                    text_response += f"**{season}** — {' | '.join(stats)}\n"
                            else:
                                # Ranked list of different players/teams
                                for i, row in enumerate(data, 1):
                                    label = row.get(name_col, f"#{i}") if name_col else f"#{i}"
                                    season = row.get(season_col, '') if season_col else ''
                                    
                                    # Show top 3 numeric stats
                                    stats = []
                                    for c in numeric_cols_list[:3]:
                                        v = row.get(c)
                                        if v is not None:
                                            stats.append(f"{fmt_val(v)} {c.replace('_', ' ').title()}")
                                    
                                    line = f"{i}. **{label}**"
                                    if season:
                                        line += f" ({season})"
                                    if stats:
                                        line += f" — {' | '.join(stats)}"
                                    text_response += line + "\n"
                        else:
                            # Large result set - summarize
                            text_response = f"Found {len(data)} results.\n\n"
                            for i, row in enumerate(data[:10], 1):
                                label = row.get(name_col, f"#{i}") if name_col else f"#{i}"
                                stats = []
                                for c in numeric_cols_list[:2]:
                                    v = row.get(c)
                                    if v is not None:
                                        stats.append(f"{fmt_val(v)} {c.replace('_', ' ').title()}")
                                line = f"{i}. **{label}**"
                                if stats:
                                    line += f" — {' | '.join(stats)}"
                                text_response += line + "\n"
                            text_response += f"\n... and {len(data) - 10} more"
                        
                        # Offer to visualize
                        text_response += "\n\nData from Diamond Quant Database"
                        
                        return {
                            "text": text_response,
                            "image": None,
                            "imageType": None,
                            "chat_id": chat_id,
                            "source": query_source if query_source in ["database", "hybrid"] else "database",
                            "attribution": "Data from Diamond Quant Database" if query_source == "database" else "Data from Diamond Quant Database & MLB Stats API"
                        }
                    
                else:
                    # No results — give a helpful response instead of a dead-end
                    assistant_message = (
                        "No data found for this query.\n\n"
                        "Try rephrasing or ask something like:\n"
                        "- Top 10 batters by H-Score\n"
                        "- Aaron Judge 2024 stats\n"
                        "- Home runs by team\n"
                        "- ERA distribution for pitchers"
                    )
                    print(f"[DEBUG] SQL returned 0 rows for query: {request.message}", flush=True)
                    
            except Exception as e:
                # SQL execution failed - try fallback to Groq API if available
                error_msg = str(e)
                print(f"[ERROR] SQL execution failed: {error_msg}", flush=True)
                print(f"[DEBUG] Failed query: {sql_query}", flush=True)
                
                # Retry with smaller Groq model (separate rate limit) when SQL fails
                if api_client:
                    print(f"[DEBUG] Retrying with smaller Groq model after SQL failure...", flush=True)
                    
                    # Rollback the failed transaction so we can try again
                    conn.rollback()
                    
                    # Build a new prompt with the error context and FULL schema
                    retry_prompt = f"""FIX THIS PostgreSQL QUERY. The error was:
{error_msg}

Failed query:
{sql_query}

RULES:
- Use PostgreSQL syntax (LIMIT N, not TOP N)
- Use correct table names from schema below
- home_runs is a COLUMN in player_season_stats, not a table
- Include team_id, abbreviation for team queries
- Include player_id for player queries

{sql_prompt}

User request: {request.message}

Output ONLY the corrected SQL starting with SELECT:"""

                    try:
                        # Use smaller model for retry (has separate rate limit)
                        groq_key = os.getenv('GROQ_API_KEY')
                        if groq_key:
                            retry_client = OpenAI(api_key=groq_key, base_url="https://api.groq.com/openai/v1")
                            retry_model = "llama-3.1-8b-instant"
                        else:
                            retry_client = api_client
                            retry_model = api_model
                            
                        retry_response = retry_client.chat.completions.create(
                            model=retry_model,
                            messages=[{"role": "user", "content": retry_prompt}],
                            max_tokens=1024,
                            temperature=0.0,
                            top_p=0.1
                        )
                        
                        retry_content = retry_response.choices[0].message.content
                        retry_sql = extract_sql_from_response(retry_content)
                        
                        if retry_sql and retry_sql.upper().startswith('SELECT'):
                            print(f"[DEBUG] Groq retry SQL: {retry_sql[:200]}", flush=True)
                            
                            # Try executing the retried query
                            cur.execute(retry_sql)
                            rows = cur.fetchall()
                            colnames = [desc[0] for desc in cur.description]
                            data = [dict(zip(colnames, row)) for row in rows]
                            
                            if len(data) > 0:
                                print(f"[DEBUG] Groq retry successful! ({len(data)} rows)", flush=True)
                                chartspec = build_chartspec_from_data(data, request.message, colnames)
                                print(f"[DEBUG] Generated ChartSpec: chart_type={chartspec.get('chart_type')}", flush=True)
                                
                                from chart_renderer import render_chart
                                png_bytes = render_chart(chartspec, request.message)
                                
                                import base64
                                png_base64 = base64.b64encode(png_bytes).decode('utf-8')
                                
                                chat_id = request.chat_id or str(uuid.uuid4())
                                conn.close()
                                return {
                                    "text": "",
                                    "image": png_base64,
                                    "imageType": "base64",
                                    "chat_id": chat_id
                                }
                            else:
                                assistant_message = "Query executed but returned no data."
                        else:
                            assistant_message = f"SQL Execution Error: {error_msg}\n\nQuery: {sql_query[:300] if sql_query else 'None'}..."
                    except Exception as retry_error:
                        print(f"[ERROR] Groq retry also failed: {retry_error}", flush=True)
                        assistant_message = f"SQL Execution Error: {error_msg}\n\nQuery: {sql_query[:300] if sql_query else 'None'}..."
                else:
                    assistant_message = f"SQL Execution Error: {error_msg}\n\nQuery: {sql_query[:300] if sql_query else 'None'}..."
        
        # Generate or get chat ID
        chat_id = request.chat_id or str(uuid.uuid4())
        
        # Close database connection
        conn.close()
        
        return {
            "text": assistant_message,
            "visualization": None,
            "image": None,
            "imageType": None,
            "chat_id": chat_id
        }
        
    except HTTPException:
        raise
    except Exception as e:
        import traceback
        error_details = traceback.format_exc()
        print(f"Diamond Quant chat error: {error_details}")
        raise HTTPException(500, f"Error in Diamond Quant chat: {str(e)}")


@app.get("/api/diamond-quant/chats")
async def get_chat_histories():
    """Get all saved chat histories"""
    try:
        import psycopg2
        from dotenv import load_dotenv
        
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        conn = _get_db_conn()
        cur = conn.cursor()
        
        # Check if table exists, create if not
        cur.execute("""
            CREATE TABLE IF NOT EXISTS diamond_quant_chats (
                id VARCHAR(255) PRIMARY KEY,
                title VARCHAR(500) NOT NULL,
                messages JSONB NOT NULL,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                updated_at TIMESTAMPTZ DEFAULT NOW()
            )
        """)
        
        cur.execute("""
            SELECT id, title, messages, created_at, updated_at
            FROM diamond_quant_chats
            ORDER BY updated_at DESC
        """)
        
        chats = []
        for row in cur.fetchall():
            chats.append({
                "id": row[0],
                "title": row[1],
                "messages": row[2],
                "created_at": row[3].isoformat() if row[3] else None,
                "updated_at": row[4].isoformat() if row[4] else None
            })
        
        conn.commit()
        conn.close()
        
        return chats
        
    except Exception as e:
        raise HTTPException(500, f"Error fetching chat histories: {str(e)}")

@app.get("/api/diamond-quant/chats/{chat_id}")
async def get_chat_history(chat_id: str):
    """Get a specific chat history"""
    try:
        import psycopg2
        from dotenv import load_dotenv
        
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        conn = _get_db_conn()
        cur = conn.cursor()
        
        cur.execute("""
            SELECT id, title, messages, created_at, updated_at
            FROM diamond_quant_chats
            WHERE id = %s
        """, (chat_id,))
        
        row = cur.fetchone()
        if not row:
            conn.close()
            raise HTTPException(404, "Chat not found")
        
        conn.close()
        
        return {
            "id": row[0],
            "title": row[1],
            "messages": row[2],
            "created_at": row[3].isoformat() if row[3] else None,
            "updated_at": row[4].isoformat() if row[4] else None
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Error fetching chat history: {str(e)}")

@app.post("/api/diamond-quant/chats")
async def save_chat_history(request: SaveChatRequest):
    """Save a chat history"""
    try:
        import psycopg2
        from dotenv import load_dotenv
        import uuid
        import json
        
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        conn = _get_db_conn()
        cur = conn.cursor()
        
        # Ensure table exists
        cur.execute("""
            CREATE TABLE IF NOT EXISTS diamond_quant_chats (
                id VARCHAR(255) PRIMARY KEY,
                title VARCHAR(500) NOT NULL,
                messages JSONB NOT NULL,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                updated_at TIMESTAMPTZ DEFAULT NOW()
            )
        """)
        
        # Use provided chat_id or generate new one
        chat_id = request.chat_id or str(uuid.uuid4())
        
        # Convert messages to JSONB format
        messages_json = json.dumps(request.messages)
        
        cur.execute("""
            INSERT INTO diamond_quant_chats (id, title, messages, updated_at)
            VALUES (%s, %s, %s::jsonb, NOW())
            ON CONFLICT (id) DO UPDATE
            SET title = EXCLUDED.title,
                messages = EXCLUDED.messages,
                updated_at = NOW()
        """, (chat_id, request.title, messages_json))
        
        conn.commit()
        conn.close()
        
        return {"chat_id": chat_id}
        
    except Exception as e:
        raise HTTPException(500, f"Error saving chat history: {str(e)}")

@app.delete("/api/diamond-quant/chats/{chat_id}")
async def delete_chat_history(chat_id: str):
    """Delete a chat history"""
    try:
        import psycopg2
        from dotenv import load_dotenv
        
        load_dotenv(PROJECT_ROOT / ".env")
        database_url = os.getenv('DATABASE_URL')
        if not database_url:
            raise HTTPException(500, "DATABASE_URL not configured")
        
        conn = _get_db_conn()
        cur = conn.cursor()
        
        cur.execute("DELETE FROM diamond_quant_chats WHERE id = %s", (chat_id,))
        
        if cur.rowcount == 0:
            conn.close()
            raise HTTPException(404, "Chat not found")
        
        conn.commit()
        conn.close()
        
        return {"success": True}
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Error deleting chat history: {str(e)}")

# =============================================================================
# PREDICTIONS PERSISTENCE ENDPOINTS
# =============================================================================

class PredictionRecord(BaseModel):
    """Single prediction outcome to save"""
    market_type: str  # 'MONEYLINE', 'SPREAD', 'TOTAL', 'HITS', 'HOME_RUNS', etc.
    side: str  # 'home', 'away', 'over', 'under'
    strike: Optional[float] = None  # The line (0.5, 1.5, -1.5, 7.5) - NULL for moneyline
    probability: float  # Stored as percentage (55.5 for 55.5%)
    team_id: Optional[int] = None  # Team being bet on (NULL for totals)
    player_id: Optional[int] = None  # For props: the player (NULL for game markets)

class SavePredictionsRequest(BaseModel):
    """Request to save simulation predictions to DB"""
    game_pk: int
    num_simulations: int
    model_version: str = "v1.0.0"
    predictions: List[PredictionRecord]

@app.post("/api/predictions/save")
async def save_predictions(request: SavePredictionsRequest):
    """
    Save or update prediction outcomes for a game.
    
    Uses UPSERT logic - will update existing predictions with same 
    (game_pk, team_id, competitor_id, market_type, side, strike) combo.
    """
    _ensure_performance_tables()
    try:
        conn = _get_db_conn()
        cur = conn.cursor()
        
        # Verify game exists (skip check if games table doesn't exist, e.g. SQLite)
        try:
            cur.execute("SELECT game_pk FROM games WHERE game_pk = %s", (request.game_pk,))
            if not cur.fetchone():
                conn.close()
                raise HTTPException(404, f"Game not found: {request.game_pk}")
        except Exception:
            pass  # games table may not exist in all setups
        
        # Prepare data for upsert
        saved_count = 0
        updated_count = 0
        
        for pred in request.predictions:
            # Use UPSERT with COALESCE to handle NULLs in unique index
            cur.execute("""
                INSERT INTO predictions (
                    game_pk, team_id, player_id, market_type, side, strike,
                    model_version, num_simulations, probability
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (game_pk, COALESCE(team_id, 0), COALESCE(player_id, 0), market_type, side, COALESCE(strike, 0))
                DO UPDATE SET
                    model_version = EXCLUDED.model_version,
                    num_simulations = EXCLUDED.num_simulations,
                    probability = EXCLUDED.probability,
                    updated_at = NOW()
                RETURNING (xmax = 0) as is_insert
            """, (
                request.game_pk,
                pred.team_id,
                pred.player_id,
                pred.market_type.upper(),
                pred.side.lower(),
                pred.strike,
                request.model_version,
                request.num_simulations,
                pred.probability
            ))
            
            result = cur.fetchone()
            if result and result[0]:
                saved_count += 1
            else:
                updated_count += 1
        
        conn.commit()
        conn.close()
        
        return {
            "status": "success",
            "game_pk": request.game_pk,
            "saved": saved_count,
            "updated": updated_count,
            "total": len(request.predictions)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Error saving predictions: {e}")

@app.get("/api/predictions/load/{game_pk}")
async def load_predictions(game_pk: int):
    """
    Load saved predictions for a game.
    
    Returns all prediction outcomes for the game, organized by market type.
    """
    _ensure_performance_tables()
    try:
        conn = _get_db_conn()
        cur = conn.cursor()
        
        # Get predictions for this game, joining with players for names
        cur.execute("""
            SELECT 
                p.id,
                p.market_type,
                p.team_id,
                p.player_id,
                p.side,
                p.strike,
                p.probability,
                p.num_simulations,
                p.model_version,
                p.result,
                p.updated_at,
                pl.full_name as player_name
            FROM predictions p
            LEFT JOIN players pl ON p.player_id = pl.player_id
            WHERE p.game_pk = %s
            ORDER BY p.market_type, p.player_id NULLS FIRST, p.strike NULLS FIRST
        """, (game_pk,))
        
        rows = cur.fetchall()
        conn.close()
        
        if not rows:
            return {
                "game_pk": game_pk,
                "has_predictions": False,
                "predictions": []
            }
        
        # Organize by market type
        predictions = []
        metadata = {
            "num_simulations": rows[0][7] if rows else None,
            "model_version": rows[0][8] if rows else None,
            "updated_at": str(rows[0][10]) if rows else None
        }
        
        for row in rows:
            predictions.append({
                "id": row[0],
                "market_type": row[1],
                "team_id": row[2],
                "player_id": row[3],
                "side": row[4],
                "strike_price": float(row[5]) if row[5] else None,
                "probability": float(row[6]) if row[6] else None,
                "result": row[9],
                "player_name": row[11]  # From players table join
            })
        
        return {
            "game_pk": game_pk,
            "has_predictions": True,
            "metadata": metadata,
            "predictions": predictions
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Error loading predictions: {e}")

@app.get("/api/odds/entry-prices/{game_pk}")
async def get_entry_prices(game_pk: int, market_type: str, side: str, strike: Optional[float] = None):
    """
    Get current Pinnacle (mains) and FanDuel (props) prices for a specific market.
    Used to auto-fill entry-time prices when logging a bet.
    """
    try:
        conn = _get_db_conn()
        cur = conn.cursor()
        cur.execute("""
            SELECT sm.american_odds, sm.decimal_odds, sm.implied_probability,
                   sb.short_name as book, sm.odds_updated_at
            FROM sportsbook_markets sm
            JOIN sportsbooks sb ON sm.sportsbook_id = sb.sportsbook_id
            WHERE sm.game_pk = %s
              AND sm.market_type = %s
              AND sm.outcome_side = %s
              AND sm.is_available = TRUE
              AND sb.short_name IN ('PIN', 'FD')
              AND (sm.strike_price = %s OR (%s IS NULL AND sm.strike_price IS NULL))
            ORDER BY sm.odds_updated_at DESC
        """, (game_pk, market_type.upper(), side.lower(), strike, strike))

        result = {"pinnacle": None, "fanduel": None}
        for row in cur.fetchall():
            ao, dec, imp, book, updated = row
            entry = {
                "american_odds": ao,
                "decimal_odds": float(dec) if dec else None,
                "implied_probability": float(imp) * 100 if imp else None,
                "updated_at": str(updated) if updated else None,
            }
            if book == 'PIN' and result["pinnacle"] is None:
                result["pinnacle"] = entry
            elif book == 'FD' and result["fanduel"] is None:
                result["fanduel"] = entry

        conn.close()
        return result

    except Exception as e:
        raise HTTPException(500, f"Error fetching entry prices: {e}")


@app.get("/api/odds/closing-line/{game_pk}")
async def get_closing_line(game_pk: int, market_type: str, side: str, strike: Optional[float] = None):
    """
    Get the closing line (last snapshot before game start) from Pinnacle (mains) / FanDuel (props).
    Searches sportsbook_odds_history for the last recorded price.
    """
    try:
        conn = _get_db_conn()
        cur = conn.cursor()

        # Get game start time
        cur.execute("SELECT game_time_et FROM games WHERE game_pk = %s", (game_pk,))
        row = cur.fetchone()
        game_time = row[0] if row else None

        # Get the last Pinnacle and FanDuel prices via odds history
        # If game_time is available, filter to snapshots before game start
        # Otherwise, just get the latest snapshot
        cur.execute("""
            SELECT h.american_odds, h.decimal_odds, h.implied_probability,
                   h.recorded_at, sb.short_name as book
            FROM sportsbook_odds_history h
            JOIN sportsbook_markets sm ON h.market_id = sm.market_id
            JOIN sportsbooks sb ON sm.sportsbook_id = sb.sportsbook_id
            WHERE sm.game_pk = %s
              AND sm.market_type = %s
              AND sm.outcome_side = %s
              AND sb.short_name IN ('PIN', 'FD')
              AND (sm.strike_price = %s OR (%s IS NULL AND sm.strike_price IS NULL))
            ORDER BY h.recorded_at DESC
        """, (game_pk, market_type.upper(), side.lower(), strike, strike))

        result = {"pinnacle_close": None, "fanduel_close": None, "game_time": str(game_time) if game_time else None}
        for row in cur.fetchall():
            ao, dec, imp, recorded, book = row
            entry = {
                "american_odds": ao,
                "decimal_odds": float(dec) if dec else None,
                "implied_probability": float(imp) * 100 if imp else None,
                "recorded_at": str(recorded) if recorded else None,
            }
            if book == 'PIN' and result["pinnacle_close"] is None:
                result["pinnacle_close"] = entry
            elif book == 'FD' and result["fanduel_close"] is None:
                result["fanduel_close"] = entry

        conn.close()
        return result

    except Exception as e:
        raise HTTPException(500, f"Error fetching closing line: {e}")


@app.get("/api/predictions/all-outcomes")
async def get_all_prediction_outcomes(
    date: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    market_type: Optional[str] = None,
    team: Optional[str] = None,
    opponent: Optional[str] = None,
    player: Optional[str] = None,
    min_edge: Optional[float] = None,
    max_edge: Optional[float] = None,
    result: Optional[str] = None,
    sort_by: Optional[str] = None,
    sort_dir: Optional[str] = None,
    limit: int = 500,
    offset: int = 0,
    bet_side_only: bool = False,
    game_type: Optional[str] = None,
):
    """
    Get ALL model predictions with their outcomes (graded W/L after game completion).
    Pairs predictions with the best available sportsbook odds and game results.
    This powers the 'ALL PREDICTIONS' strategy analysis tab.
    """
    _ensure_performance_tables()
    target_date = date

    try:
        conn = _get_db_conn()
        cur = conn.cursor()

        conditions = []
        params = []

        if target_date:
            conditions.append("g.game_date = %s")
            params.append(target_date)
        if start_date:
            conditions.append("g.game_date >= %s")
            params.append(start_date)
        if end_date:
            conditions.append("g.game_date <= %s")
            params.append(end_date)
        if game_type:
            gt = game_type.upper().strip()
            if gt == 'SPRING':
                conditions.append("g.game_type IN ('S', 'E')")
            elif gt == 'REGULAR':
                conditions.append("g.game_type = 'R'")
            elif gt == 'POST':
                conditions.append("g.game_type IN ('P', 'F', 'D', 'L', 'W')")
        if market_type:
            conditions.append("p.market_type = %s")
            params.append(market_type.upper())
        if team:
            # Match by abbreviation, name, or location (ILIKE for fuzzy matching)
            team_upper = team.upper().strip()
            conditions.append("""(
                (ta.abbreviation ILIKE %s OR th.abbreviation ILIKE %s
                 OR ta.name ILIKE %s OR th.name ILIKE %s
                 OR ta.location_name ILIKE %s OR th.location_name ILIKE %s
                 OR ta.franchise_name ILIKE %s OR th.franchise_name ILIKE %s)
                AND (
                    p.team_id IN (
                        SELECT team_id FROM teams
                        WHERE abbreviation ILIKE %s OR name ILIKE %s
                              OR location_name ILIKE %s OR franchise_name ILIKE %s
                    )
                    OR p.team_id IS NULL
                )
            )""")
            team_pat = f"%{team.strip()}%"
            # First 8 params: game involves this team (abbreviation exact or name ILIKE)
            params.extend([team_upper, team_upper,
                           team_pat, team_pat,
                           team_pat, team_pat,
                           team_pat, team_pat])
            # Next 4 params: prediction is for this team (team_id matches) or neutral
            params.extend([team_upper, team_pat, team_pat, team_pat])
        if opponent:
            # Game involves this opponent
            opp_upper = opponent.upper().strip()
            opp_pat = f"%{opponent.strip()}%"
            conditions.append("""(
                ta.abbreviation ILIKE %s OR th.abbreviation ILIKE %s
                OR ta.name ILIKE %s OR th.name ILIKE %s
                OR ta.location_name ILIKE %s OR th.location_name ILIKE %s
                OR ta.franchise_name ILIKE %s OR th.franchise_name ILIKE %s
            )""")
            params.extend([opp_upper, opp_upper,
                           opp_pat, opp_pat,
                           opp_pat, opp_pat,
                           opp_pat, opp_pat])
        if player:
            conditions.append("pl.full_name ILIKE %s")
            params.append(f"%{player}%")
        if result:
            # Only match predictions that have the specified result
            conditions.append("p.result = %s")
            params.append(result.upper())

        where_clause = "WHERE " + " AND ".join(conditions) if conditions else ""

        # Build ORDER BY: default groups complementary pairs together;
        # explicit sort_by overrides with a tiebreak for side pairing
        # Side ordering: over/away first (0), under/home second (1)
        SIDE_ORDER = "CASE p.side WHEN 'over' THEN 0 WHEN 'away' THEN 0 WHEN 'under' THEN 1 WHEN 'home' THEN 1 ELSE 2 END"
        SORT_MAP = {
            'gp': 'g.game_pk',
            'date': 'g.game_date',
            'game': "CONCAT(ta.abbreviation, ' @ ', th.abbreviation)",
            'competitor': "COALESCE(pl.full_name, pt.abbreviation, ta.abbreviation || ' @ ' || th.abbreviation)",
            'side': 'p.side',
            'strike': 'p.strike',
            'market': 'p.market_type',
            'mcmc': 'p.probability',
            'result': 'p.result',
        }
        if sort_by and sort_by in SORT_MAP:
            direction = 'ASC' if sort_dir == 'asc' else 'DESC'
            nulls = 'NULLS LAST' if direction == 'DESC' else 'NULLS FIRST'
            order_clause = f"ORDER BY {SORT_MAP[sort_by]} {direction} {nulls}, {SIDE_ORDER}"
        else:
            # Default: date desc → game → player name (for props) → market →
            #   team abbr only for TEAM_TOTAL markets → ABS(strike) → side
            # ABS(strike) pairs complementary spreads: WSH -1.5 / STL +1.5
            # TEAM_TOTAL grouping keeps each team's O/U together
            order_clause = (
                f"ORDER BY g.game_date DESC, g.game_pk, "
                f"COALESCE(pl.full_name, '') ASC, "
                f"p.market_type ASC, "
                f"CASE WHEN p.market_type IN ('TEAM_TOTAL','F5_TEAM_TOTAL') "
                f"     THEN COALESCE(pt.abbreviation, '') ELSE '' END ASC, "
                f"ABS(COALESCE(p.strike, 0)) ASC, {SIDE_ORDER}"
            )

        # Also get the team abbreviation for the prediction's team_id
        # Include g.home_team_id, g.away_team_id, p.team_id for closing line matching
        # When bet_side_only, fetch all rows (no SQL limit/offset) so we can pair+filter in Python
        if bet_side_only:
            cur.execute(f"""
                SELECT
                    p.id, p.game_pk, g.game_date, p.market_type, p.side, p.strike,
                    p.probability,
                    ta.abbreviation as away_abbr, th.abbreviation as home_abbr,
                    pl.full_name as player_name,
                    g.home_score, g.away_score, g.status_detailed,
                    p.result as prediction_result,
                    pt.abbreviation as pred_team_abbr,
                    g.home_team_id, g.away_team_id, p.team_id
                FROM predictions p
                JOIN games g ON p.game_pk = g.game_pk
                LEFT JOIN teams ta ON g.away_team_id = ta.team_id
                LEFT JOIN teams th ON g.home_team_id = th.team_id
                LEFT JOIN teams pt ON p.team_id = pt.team_id
                LEFT JOIN players pl ON p.player_id = pl.player_id
                {where_clause}
                {order_clause}
            """, params)
        else:
            cur.execute(f"""
                SELECT
                    p.id, p.game_pk, g.game_date, p.market_type, p.side, p.strike,
                    p.probability,
                    ta.abbreviation as away_abbr, th.abbreviation as home_abbr,
                    pl.full_name as player_name,
                    g.home_score, g.away_score, g.status_detailed,
                    p.result as prediction_result,
                    pt.abbreviation as pred_team_abbr,
                    g.home_team_id, g.away_team_id, p.team_id
                FROM predictions p
                JOIN games g ON p.game_pk = g.game_pk
                LEFT JOIN teams ta ON g.away_team_id = ta.team_id
                LEFT JOIN teams th ON g.home_team_id = th.team_id
                LEFT JOIN teams pt ON p.team_id = pt.team_id
                LEFT JOIN players pl ON p.player_id = pl.player_id
                {where_clause}
                {order_clause}
                LIMIT %s OFFSET %s
            """, params + [limit, offset])

        predictions = []
        for row in cur.fetchall():
            (pred_id, gpk, gdate, mt, side, strike, prob, away, home,
             pname, hs, as_, status, pred_result, pred_team,
             home_tid, away_tid, team_id) = row
            predictions.append({
                "id": pred_id, "game_pk": gpk, "game_date": str(gdate),
                "market_type": mt, "side": side, "strike": float(strike) if strike else None,
                "mcmc_probability": float(prob) if prob else None,
                "away_abbr": away, "home_abbr": home,
                "player_name": pname,
                "home_score": hs, "away_score": as_,
                "game_status": status,
                "result": pred_result,
                "label": f"{away} @ {home}",
                "pred_team_abbr": pred_team,
                # Internal fields for closing line matching (removed before response)
                "_team_id": team_id,
                "_home_team_id": home_tid,
                "_away_team_id": away_tid,
                # Will be populated below
                "entry_odds": None,     # sharp book odds at entry (American)
                "entry_prob": None,     # entry implied prob %
                "closing_odds": None,
                "closing_prob": None,   # vigged implied prob %
                "fair_prob": None,      # de-vigged fair prob %
                "closing_book": None,
                "clv": None,            # vigged_close% - entry% (beat the closing line?)
                "xroi": None,           # fair_close% - entry% (edge over fair market?)
                "edge": None,           # mcmc% - entry% (model edge at time of bet)
            })

        # ── Align SPREAD prediction convention with sportsbook ──────────
        # Predictions store home +1.5 / away -1.5 (handicap given TO the team),
        # but sportsbooks store home -1.5 / away +1.5 (the run-line convention).
        # Negate the strike and complement the probability so the prediction
        # convention matches the sportsbook, enabling direct key matching.
        _SPREAD_FLIP = {'SPREAD', 'ALT_SPREAD', 'F5_SPREAD', 'F5_ALT_SPREAD'}
        for pred in predictions:
            if pred['market_type'] in _SPREAD_FLIP and pred['strike'] is not None:
                pred['strike'] = -pred['strike']
                if pred['mcmc_probability'] is not None:
                    pred['mcmc_probability'] = round(100.0 - pred['mcmc_probability'], 3)

        # ── Batch-fetch closing odds from sportsbook_markets ──────────
        # For each prediction, find the sharpest available closing line
        # Priority: PIN → FD → DK → BOL → MGM → CZR
        TEAM_TOTAL_TYPES = ('TEAM_TOTAL', 'ALT_TEAM_TOTAL', 'F5_TEAM_TOTAL')
        PLAYER_PROP_TYPES = (
            'HOME_RUNS', 'HITS', 'TOTAL_BASES', 'RBI', 'RUNS',
            'STRIKEOUTS', 'STOLEN_BASES', 'H_R_RBI',
            'HOME_RUNS_ALT', 'HITS_ALT', 'TOTAL_BASES_ALT',
            'RBI_ALT', 'RUNS_ALT', 'STRIKEOUTS_ALT',
        )

        game_pks = list(set(p['game_pk'] for p in predictions))
        if game_pks:
            try:
                cur.execute("""
                    SELECT sm.game_pk, sm.market_type, sm.outcome_side,
                           sm.strike_price, sm.player_name, sm.team_side,
                           sm.american_odds, sm.implied_probability, sb.short_name
                    FROM sportsbook_markets sm
                    JOIN sportsbooks sb ON sm.sportsbook_id = sb.sportsbook_id
                    WHERE sm.game_pk = ANY(%s)
                      AND sm.is_available = TRUE
                      AND sb.short_name IN ('PIN', 'FD', 'DK', 'BOL', 'MGM', 'CZR')
                    ORDER BY
                        CASE sb.short_name
                            WHEN 'PIN' THEN 1 WHEN 'FD' THEN 2 WHEN 'DK' THEN 3
                            WHEN 'BOL' THEN 4 WHEN 'MGM' THEN 5 WHEN 'CZR' THEN 6
                            ELSE 7
                        END,
                        sm.odds_updated_at DESC
                """, (game_pks,))

                # Build lookup: (game_pk, market_type, side, strike, extra_key) → closing data
                # extra_key differentiates team totals (by team_side) and player props (by name)
                # Prediction strikes are already flipped to sportsbook convention above,
                # so we match directly by (side, strike) — no abs() needed.
                SPREAD_TYPES = ('SPREAD', 'ALT_SPREAD', 'F5_SPREAD', 'F5_ALT_SPREAD')

                def _build_market_key(mt, side, strike_val, pname, tside):
                    sk = round(float(strike_val), 1) if strike_val is not None else None
                    if mt in TEAM_TOTAL_TYPES:
                        extra = tside or ''
                    elif pname and mt in PLAYER_PROP_TYPES:
                        extra = pname.lower().strip()
                    else:
                        extra = ''
                    return (mt, side, sk, extra)

                closing_lookup: dict = {}
                for row in cur.fetchall():
                    gpk, mt, side, strike_val, pname, tside, ao, ip, book = row
                    mk = _build_market_key(mt, side, strike_val, pname, tside)
                    key = (gpk,) + mk
                    if key not in closing_lookup:
                        closing_lookup[key] = {
                            'american_odds': ao,
                            'implied_prob': round(float(ip) * 100, 2) if ip else None,
                            'book': book,
                        }

                # ── Build entry lookup from EARLIEST odds_history snapshot ─────
                # Entry = the first odds we saw for each market (opening line).
                # Uses the same sharp book priority and market key structure.
                entry_lookup: dict = {}
                cur.execute("""
                    SELECT sm.game_pk, sm.market_type, sm.outcome_side,
                           sm.strike_price, sm.player_name, sm.team_side,
                           h.american_odds, h.implied_probability, sb.short_name,
                           h.recorded_at
                    FROM sportsbook_odds_history h
                    JOIN sportsbook_markets sm ON h.market_id = sm.market_id
                    JOIN sportsbooks sb ON sm.sportsbook_id = sb.sportsbook_id
                    WHERE sm.game_pk = ANY(%s)
                      AND sb.short_name IN ('PIN', 'FD', 'DK', 'BOL', 'MGM', 'CZR')
                    ORDER BY
                        CASE sb.short_name
                            WHEN 'PIN' THEN 1 WHEN 'FD' THEN 2 WHEN 'DK' THEN 3
                            WHEN 'BOL' THEN 4 WHEN 'MGM' THEN 5 WHEN 'CZR' THEN 6
                            ELSE 7
                        END,
                        h.recorded_at ASC
                """, (game_pks,))
                for row in cur.fetchall():
                    gpk, mt, side, strike_val, pname, tside, ao, ip, book, _ts = row
                    mk = _build_market_key(mt, side, strike_val, pname, tside)
                    key = (gpk,) + mk
                    if key not in entry_lookup:
                        entry_lookup[key] = {
                            'american_odds': ao,
                            'implied_prob': round(float(ip) * 100, 2) if ip else None,
                            'book': book,
                        }

                # Match predictions to closing odds and de-vig for fair CLV
                def _opposite_side(s: str) -> str:
                    return {'home': 'away', 'away': 'home',
                            'over': 'under', 'under': 'over'}.get(s, s)

                for pred in predictions:
                    gpk = pred['game_pk']
                    mt = pred['market_type']
                    side = pred['side']
                    sk = round(float(pred['strike']), 1) if pred.get('strike') is not None else None
                    team_id = pred.get('_team_id')
                    player_name = pred.get('player_name')
                    home_tid = pred.get('_home_team_id')

                    if mt in TEAM_TOTAL_TYPES and team_id:
                        extra = 'home' if team_id == home_tid else 'away'
                    elif player_name and mt in PLAYER_PROP_TYPES:
                        extra = player_name.lower().strip()
                    else:
                        extra = ''

                    key = (gpk, mt, side, sk, extra)
                    closing = closing_lookup.get(key)

                    # Populate entry odds from earliest history snapshot
                    entry = entry_lookup.get(key)
                    if entry:
                        pred['entry_odds'] = entry['american_odds']
                        pred['entry_prob'] = entry['implied_prob']

                    if closing:
                        pred['closing_odds'] = closing['american_odds']
                        pred['closing_book'] = closing['book']
                        vigged_prob = closing['implied_prob']  # vigged implied %
                        pred['closing_prob'] = vigged_prob

                        # If no entry data from history, fall back to closing
                        if pred['entry_odds'] is None:
                            pred['entry_odds'] = closing['american_odds']
                            pred['entry_prob'] = vigged_prob

                        mcmc = pred.get('mcmc_probability')
                        entry_prob = pred.get('entry_prob')

                        # Edge = mcmc% - entry_implied% (model edge at time of bet)
                        if mcmc is not None and entry_prob is not None:
                            pred['edge'] = round(mcmc - entry_prob, 2)

                        # CLV = vigged_close% - entry% (did the line move towards us?)
                        if vigged_prob is not None and entry_prob is not None:
                            pred['clv'] = round(vigged_prob - entry_prob, 2)

                        # De-vig: find the opposite side and compute fair probability for xROI
                        # For spreads the sportsbook pair is (home, -1.5) / (away, +1.5)
                        # so we negate strike when flipping side.
                        opp_sk = -sk if mt in SPREAD_TYPES and sk is not None else sk
                        opp_key = (gpk, mt, _opposite_side(side), opp_sk, extra)
                        opp_closing = closing_lookup.get(opp_key)

                        if opp_closing and closing['american_odds'] is not None and opp_closing['american_odds'] is not None:
                            try:
                                fair_this, fair_opp = devig_two_way(
                                    closing['american_odds'],
                                    opp_closing['american_odds'],
                                )
                                fair_prob_pct = round(fair_this * 100, 2)
                                pred['fair_prob'] = fair_prob_pct
                                # xROI = fair_close% - entry% (expected edge vs true market at close)
                                if entry_prob is not None:
                                    pred['xroi'] = round(fair_prob_pct - entry_prob, 2)
                            except Exception:
                                # De-vig failed — fair_prob stays None, xROI unavailable
                                pass

            except Exception as e:
                print(f"[API] Warning: Could not fetch closing odds: {e}")

        # ── Bet-side-only filtering ────────────────────────────────────
        # For each market pair, pick the side where MCMC has edge over the
        # sharp book's implied probability.  Only that side is returned.
        if bet_side_only:
            from collections import defaultdict as _defaultdict

            # Group predictions into market pairs.
            # Key: (game_pk, market_type, abs_strike, extra) – same grouping
            # as the closing-odds lookup but WITHOUT the side component.
            pair_groups: dict[tuple, list[dict]] = _defaultdict(list)
            for pred in predictions:
                gpk = pred['game_pk']
                mt  = pred['market_type']
                # abs(strike) groups complementary pairs: home -1.5 / away +1.5
                sk  = round(abs(float(pred['strike'])), 1) if pred.get('strike') is not None else None

                team_id  = pred.get('_team_id')
                home_tid = pred.get('_home_team_id')
                pname    = pred.get('player_name')

                if mt in TEAM_TOTAL_TYPES and team_id:
                    extra = 'home' if team_id == home_tid else 'away'
                elif pname and mt in PLAYER_PROP_TYPES:
                    extra = pname.lower().strip()
                else:
                    extra = ''

                pair_key = (gpk, mt, sk, extra)
                pred['_pair_key'] = pair_key
                pair_groups[pair_key].append(pred)

            filtered_preds: list[dict] = []
            for pair_key, group in pair_groups.items():
                # For each side in the group, calculate edge = mcmc - entry_implied
                # entry_implied = earliest sharp book odds from history
                best_pred = None
                best_edge = -999.0
                for pred in group:
                    mcmc = pred.get('mcmc_probability')
                    entry_implied = pred.get('entry_prob')  # from earliest history snapshot

                    if mcmc is not None and entry_implied is not None:
                        edge = mcmc - entry_implied
                        if edge > best_edge:
                            best_edge = edge
                            best_pred = pred

                if best_pred is not None and best_edge > 0:
                    filtered_preds.append(best_pred)

            # Clean up temp keys
            for p in filtered_preds:
                p.pop('_pair_key', None)

            total = len(filtered_preds)

            # ── Compute aggregates across ALL filtered predictions (before pagination) ──
            _agg_graded = [p for p in filtered_preds if p.get('result')]
            _agg_edge = [p['edge'] for p in filtered_preds if p.get('edge') is not None]
            _agg_clv = [p['clv'] for p in filtered_preds if p.get('clv') is not None]
            _agg_xroi = [p['xroi'] for p in filtered_preds if p.get('xroi') is not None]
            _wins = sum(1 for p in _agg_graded if p['result'] == 'WIN')
            _losses = sum(1 for p in _agg_graded if p['result'] == 'LOSS')

            # Confidence tiers + market accuracy + Brier from graded predictions
            import math as _math
            _tiers: dict = {}
            _mkts: dict = {}
            _brier_sum = 0.0
            _ll_sum = 0.0
            _eps = 1e-15
            for p in _agg_graded:
                mcmc = p.get('mcmc_probability')
                res = p['result']
                if mcmc is None:
                    continue
                outcome = 1.0 if res == 'WIN' else 0.0
                prob = mcmc / 100.0
                _brier_sum += (prob - outcome) ** 2
                p_c = max(_eps, min(1 - _eps, prob))
                _ll_sum += -(outcome * _math.log(p_c) + (1 - outcome) * _math.log(1 - p_c))
                # Confidence tier
                tier = 'HIGH' if mcmc >= 70 else ('MED' if mcmc >= 55 else 'LOW')
                if tier not in _tiers:
                    _tiers[tier] = {'total': 0, 'wins': 0}
                _tiers[tier]['total'] += 1
                if res == 'WIN':
                    _tiers[tier]['wins'] += 1
                # Per-market Brier + directional accuracy
                mt = p['market_type']
                if mt not in _mkts:
                    _mkts[mt] = {'brier_sum': 0.0, 'total': 0, 'dir_total': 0, 'dir_wins': 0}
                _mkts[mt]['brier_sum'] += (prob - outcome) ** 2
                _mkts[mt]['total'] += 1
                if mcmc > 50:
                    _mkts[mt]['dir_total'] += 1
                    if res == 'WIN':
                        _mkts[mt]['dir_wins'] += 1

            _n_graded = len(_agg_graded)
            aggregates = {
                'wins': _wins,
                'losses': _losses,
                'pushes': sum(1 for p in _agg_graded if p['result'] == 'PUSH'),
                'graded': _n_graded,
                'avg_edge': round(sum(_agg_edge) / len(_agg_edge), 2) if _agg_edge else None,
                'avg_clv': round(sum(_agg_clv) / len(_agg_clv), 2) if _agg_clv else None,
                'pos_clv': sum(1 for v in _agg_clv if v > 0),
                'neg_clv': sum(1 for v in _agg_clv if v < 0),
                'total_clv': len(_agg_clv),
                'avg_xroi': round(sum(_agg_xroi) / len(_agg_xroi), 2) if _agg_xroi else None,
                'pos_xroi': sum(1 for v in _agg_xroi if v > 0),
                'neg_xroi': sum(1 for v in _agg_xroi if v < 0),
                'total_xroi': len(_agg_xroi),
                'total_edge': len(_agg_edge),
                'brier_score': round(_brier_sum / _n_graded, 4) if _n_graded > 0 else None,
                'log_loss': round(_ll_sum / _n_graded, 4) if _n_graded > 0 else None,
                'confidence_tiers': [
                    {'tier': t, 'total': d['total'], 'wins': d['wins'],
                     'accuracy': round(d['wins'] / d['total'] * 100, 1) if d['total'] > 0 else 0}
                    for t, d in sorted(_tiers.items(), key=lambda x: {'HIGH': 0, 'MED': 1, 'LOW': 2}.get(x[0], 3))
                ],
                'market_accuracy': [
                    {'market_type': mt, 'total': d['total'],
                     'brier': round(d['brier_sum'] / d['total'], 4) if d['total'] > 0 else None,
                     'dir_total': d['dir_total'], 'dir_wins': d['dir_wins'],
                     'dir_accuracy': round(d['dir_wins'] / d['dir_total'] * 100, 1) if d['dir_total'] > 0 else None}
                    for mt, d in sorted(_mkts.items(), key=lambda x: -x[1]['total'])
                ],
            }

            # Apply Python-level pagination
            predictions = filtered_preds[offset:offset + limit]
        else:
            # Standard path – get total count + result breakdown + Brier/tiers from DB
            cur.execute(f"""
                SELECT
                    COUNT(*),
                    COUNT(*) FILTER (WHERE p.result = 'WIN'),
                    COUNT(*) FILTER (WHERE p.result = 'LOSS'),
                    COUNT(*) FILTER (WHERE p.result = 'PUSH'),
                    COUNT(*) FILTER (WHERE p.result IS NOT NULL),
                    -- Brier score: AVG((prob - outcome)^2)
                    AVG(
                        CASE WHEN p.result IN ('WIN','LOSS') THEN
                            POWER(p.probability / 100.0
                                  - CASE WHEN p.result = 'WIN' THEN 1.0 ELSE 0.0 END, 2)
                        END
                    ),
                    -- Log loss
                    AVG(
                        CASE WHEN p.result IN ('WIN','LOSS') THEN
                            -(CASE WHEN p.result = 'WIN' THEN 1.0 ELSE 0.0 END)
                             * LN(GREATEST(p.probability / 100.0, 1e-15))
                            -(CASE WHEN p.result = 'LOSS' THEN 1.0 ELSE 0.0 END)
                             * LN(GREATEST(1.0 - p.probability / 100.0, 1e-15))
                        END
                    )
                FROM predictions p
                JOIN games g ON p.game_pk = g.game_pk
                LEFT JOIN teams ta ON g.away_team_id = ta.team_id
                LEFT JOIN teams th ON g.home_team_id = th.team_id
                LEFT JOIN teams pt ON p.team_id = pt.team_id
                LEFT JOIN players pl ON p.player_id = pl.player_id
                {where_clause}
            """, params)
            cnt_row = cur.fetchone()
            total = cnt_row[0]

            # Confidence tiers from SQL
            cur.execute(f"""
                SELECT
                    CASE
                        WHEN p.probability >= 70 THEN 'HIGH'
                        WHEN p.probability >= 55 THEN 'MED'
                        ELSE 'LOW'
                    END AS tier,
                    COUNT(*) FILTER (WHERE p.result IN ('WIN','LOSS')),
                    SUM(CASE WHEN p.result = 'WIN' THEN 1 ELSE 0 END)
                FROM predictions p
                JOIN games g ON p.game_pk = g.game_pk
                LEFT JOIN teams ta ON g.away_team_id = ta.team_id
                LEFT JOIN teams th ON g.home_team_id = th.team_id
                LEFT JOIN teams pt ON p.team_id = pt.team_id
                LEFT JOIN players pl ON p.player_id = pl.player_id
                {where_clause}
                AND p.result IN ('WIN','LOSS')
                GROUP BY 1
            """, params)
            _tier_order = {'HIGH': 0, 'MED': 1, 'LOW': 2}
            confidence_tiers = sorted([
                {'tier': r[0], 'total': r[1], 'wins': r[2],
                 'accuracy': round(r[2] / r[1] * 100, 1) if r[1] > 0 else 0}
                for r in cur.fetchall()
            ], key=lambda x: _tier_order.get(x['tier'], 3))

            # Per-market Brier + directional accuracy from SQL
            cur.execute(f"""
                SELECT
                    p.market_type,
                    COUNT(*) FILTER (WHERE p.result IN ('WIN','LOSS')),
                    AVG(
                        CASE WHEN p.result IN ('WIN','LOSS') THEN
                            POWER(p.probability / 100.0
                                  - CASE WHEN p.result = 'WIN' THEN 1.0 ELSE 0.0 END, 2)
                        END
                    ),
                    COUNT(*) FILTER (WHERE p.probability > 50 AND p.result IN ('WIN','LOSS')),
                    SUM(CASE WHEN p.probability > 50 AND p.result = 'WIN' THEN 1 ELSE 0 END)
                FROM predictions p
                JOIN games g ON p.game_pk = g.game_pk
                LEFT JOIN teams ta ON g.away_team_id = ta.team_id
                LEFT JOIN teams th ON g.home_team_id = th.team_id
                LEFT JOIN teams pt ON p.team_id = pt.team_id
                LEFT JOIN players pl ON p.player_id = pl.player_id
                {where_clause}
                GROUP BY p.market_type
                ORDER BY COUNT(*) DESC
            """, params)
            market_accuracy = [
                {'market_type': r[0], 'total': r[1],
                 'brier': round(float(r[2]), 4) if r[2] is not None else None,
                 'dir_total': r[3], 'dir_wins': r[4],
                 'dir_accuracy': round(r[4] / r[3] * 100, 1) if r[3] > 0 else None}
                for r in cur.fetchall()
            ]

            # Compute edge/CLV/xROI from the current page of predictions
            _agg_edge = [p['edge'] for p in predictions if p.get('edge') is not None]
            _agg_clv = [p['clv'] for p in predictions if p.get('clv') is not None]
            _agg_xroi = [p['xroi'] for p in predictions if p.get('xroi') is not None]
            aggregates = {
                'wins': cnt_row[1],
                'losses': cnt_row[2],
                'pushes': cnt_row[3],
                'graded': cnt_row[4],
                'avg_edge': round(sum(_agg_edge) / len(_agg_edge), 2) if _agg_edge else None,
                'avg_clv': round(sum(_agg_clv) / len(_agg_clv), 2) if _agg_clv else None,
                'pos_clv': sum(1 for v in _agg_clv if v > 0),
                'neg_clv': sum(1 for v in _agg_clv if v < 0),
                'total_clv': len(_agg_clv),
                'avg_xroi': round(sum(_agg_xroi) / len(_agg_xroi), 2) if _agg_xroi else None,
                'pos_xroi': sum(1 for v in _agg_xroi if v > 0),
                'neg_xroi': sum(1 for v in _agg_xroi if v < 0),
                'total_xroi': len(_agg_xroi),
                'total_edge': len(_agg_edge),
                'brier_score': round(float(cnt_row[5]), 4) if cnt_row[5] is not None else None,
                'log_loss': round(float(cnt_row[6]), 4) if cnt_row[6] is not None else None,
                'confidence_tiers': confidence_tiers,
                'market_accuracy': market_accuracy,
            }

        # Remove internal fields before returning
        for pred in predictions:
            pred.pop('_team_id', None)
            pred.pop('_home_team_id', None)
            pred.pop('_away_team_id', None)
            pred.pop('_pair_key', None)

        # Get all distinct market types for the filter dropdown
        cur.execute("""SELECT DISTINCT market_type FROM predictions ORDER BY market_type""")
        distinct_markets = [row[0] for row in cur.fetchall()]

        conn.close()
        return {
            "predictions": predictions,
            "total": total,
            "limit": limit,
            "offset": offset,
            "distinct_market_types": distinct_markets,
            "aggregates": aggregates,
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Error fetching prediction outcomes: {e}")


@app.get("/api/predictions/available-markets")
async def get_available_markets(date: Optional[str] = None):
    """
    Returns all available markets (from saved predictions) for games on a given date.
    Used by the Performance panel smart bet picker to auto-fill bet data.
    """
    _ensure_performance_tables()
    target_date = date or datetime.now().strftime('%Y-%m-%d')

    try:
        conn = _get_db_conn()
        cur = conn.cursor()

        cur.execute("""
            SELECT
                g.game_pk,
                g.game_date,
                ta.abbreviation as away_abbr,
                th.abbreviation as home_abbr,
                ta.name as away_name,
                th.name as home_name,
                g.game_time_et,
                p.id as prediction_id,
                p.market_type,
                p.team_id,
                p.player_id,
                p.side,
                p.strike,
                p.probability,
                p.num_simulations,
                pl.full_name as player_name
            FROM games g
            JOIN predictions p ON g.game_pk = p.game_pk
            LEFT JOIN teams ta ON g.away_team_id = ta.team_id
            LEFT JOIN teams th ON g.home_team_id = th.team_id
            LEFT JOIN players pl ON p.player_id = pl.player_id
            WHERE g.game_date = %s
            ORDER BY g.game_time_et NULLS LAST, g.game_pk, p.market_type, p.player_id NULLS FIRST, p.strike NULLS FIRST
        """, (target_date,))

        rows = cur.fetchall()
        conn.close()

        # Group by game
        games: dict = {}
        for row in rows:
            gpk = row[0]
            if gpk not in games:
                games[gpk] = {
                    "game_pk": gpk,
                    "game_date": str(row[1]),
                    "away_abbr": row[2],
                    "home_abbr": row[3],
                    "away_name": row[4],
                    "home_name": row[5],
                    "game_time": str(row[6]) if row[6] else None,
                    "label": f"{row[2]} @ {row[3]}",
                    "markets": [],
                }
            games[gpk]["markets"].append({
                "prediction_id": row[7],
                "market_type": row[8],
                "team_id": row[9],
                "player_id": row[10],
                "side": row[11],
                "strike": float(row[12]) if row[12] else None,
                "mcmc_probability": float(row[13]) if row[13] else None,
                "num_simulations": row[14],
                "player_name": row[15],
            })

        return {"date": target_date, "games": list(games.values())}

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Error fetching available markets: {e}")


# ═══════════════════════════════════════════════════════════════════════════
# PREDICTION GRADING — Fetches MLB boxscores and grades predictions
# ═══════════════════════════════════════════════════════════════════════════

def _fetch_game_results(game_pk: int) -> Optional[Dict[str, Any]]:
    """
    Fetch final game results from MLB API live feed.
    Returns a dict with scores, innings, and per-player boxscore stats,
    or None if the game isn't final yet.
    """
    import requests as _req
    try:
        resp = _req.get(
            f"https://statsapi.mlb.com/api/v1.1/game/{game_pk}/feed/live",
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json()
    except Exception as e:
        print(f"[GRADE] Failed to fetch game {game_pk}: {e}")
        return None

    status = data.get("gameData", {}).get("status", {})
    abstract = status.get("abstractGameState", "")
    detailed = status.get("detailedState", "")
    if abstract != "Final":
        return None  # game not done

    linescore = data.get("liveData", {}).get("linescore", {})
    teams_score = linescore.get("teams", {})
    home_runs = teams_score.get("home", {}).get("runs")
    away_runs = teams_score.get("away", {}).get("runs")

    # First 5 innings
    innings = linescore.get("innings", [])
    f5_home = sum(i.get("home", {}).get("runs", 0) for i in innings[:5])
    f5_away = sum(i.get("away", {}).get("runs", 0) for i in innings[:5])

    # Boxscore player stats
    boxscore = data.get("liveData", {}).get("boxscore", {})
    player_stats: Dict[int, Dict[str, Any]] = {}  # player_id → stats

    for side_key, team_side in [("away", "away"), ("home", "home")]:
        team_data = boxscore.get("teams", {}).get(side_key, {})
        players = team_data.get("players", {})
        for pid_key, pdata in players.items():
            pid = pdata.get("person", {}).get("id")
            if pid is None:
                continue
            batting = pdata.get("stats", {}).get("batting", {})
            pitching = pdata.get("stats", {}).get("pitching", {})
            player_stats[pid] = {
                "team_side": team_side,
                # Batter stats
                "hits": batting.get("hits", 0) if batting else 0,
                "home_runs": batting.get("homeRuns", 0) if batting else 0,
                "rbi": batting.get("rbi", 0) if batting else 0,
                "runs": batting.get("runs", 0) if batting else 0,
                "strikeouts": batting.get("strikeOuts", 0) if batting else 0,
                "total_bases": batting.get("totalBases", 0) if batting else 0,
                "stolen_bases": batting.get("stolenBases", 0) if batting else 0,
                # Pitcher stats
                "pitcher_strikeouts": pitching.get("strikeOuts", 0) if pitching else 0,
                "innings_pitched": float(pitching.get("inningsPitched", 0)) if pitching else 0,
            }
            # Compute H+R+RBI for HITS_RUNS_RBIS market
            player_stats[pid]["hits_runs_rbis"] = (
                player_stats[pid]["hits"]
                + player_stats[pid]["runs"]
                + player_stats[pid]["rbi"]
            )

    return {
        "game_pk": game_pk,
        "status_detailed": detailed,
        "home_score": home_runs,
        "away_score": away_runs,
        "f5_home": f5_home,
        "f5_away": f5_away,
        "total_runs": (home_runs or 0) + (away_runs or 0),
        "f5_total": f5_home + f5_away,
        "innings_played": len(innings),
        "player_stats": player_stats,
    }


# Market type → stat key for player props
_PLAYER_PROP_STAT_MAP = {
    "HITS": "hits",
    "HOME_RUNS": "home_runs",
    "RBI": "rbi",
    "RUNS": "runs",
    "STRIKEOUTS": "strikeouts",
    "TOTAL_BASES": "total_bases",
    "STOLEN_BASES": "stolen_bases",
    "HITS_RUNS_RBIS": "hits_runs_rbis",
    "PITCHER_STRIKEOUTS": "pitcher_strikeouts",
}


def _grade_prediction(
    pred: Dict[str, Any],
    game_result: Dict[str, Any],
    home_team_id: int,
    away_team_id: int,
) -> Optional[str]:
    """
    Grade a single prediction row. Returns 'WIN', 'LOSS', or 'PUSH'.
    Returns None if grading isn't possible (e.g. player didn't play).

    pred keys: market_type, side, strike, team_id, player_id
    """
    mt = pred["market_type"]
    side = pred["side"]
    strike = float(pred["strike"]) if pred["strike"] is not None else None
    team_id = pred.get("team_id")
    player_id = pred.get("player_id")

    hs = game_result["home_score"] or 0
    as_ = game_result["away_score"] or 0
    f5_hs = game_result["f5_home"]
    f5_as = game_result["f5_away"]
    total = game_result["total_runs"]
    f5_total = game_result["f5_total"]

    # ── MONEYLINE ──────────────────────────────────────────────────────
    if mt == "MONEYLINE":
        if side == "home":
            if hs > as_:
                return "WIN"
            elif hs < as_:
                return "LOSS"
            return "PUSH"
        elif side == "away":
            if as_ > hs:
                return "WIN"
            elif as_ < hs:
                return "LOSS"
            return "PUSH"

    # ── F5 MONEYLINE ──────────────────────────────────────────────────
    if mt == "F5_MONEYLINE":
        if side == "home":
            if f5_hs > f5_as:
                return "WIN"
            elif f5_hs < f5_as:
                return "LOSS"
            return "PUSH"
        elif side == "away":
            if f5_as > f5_hs:
                return "WIN"
            elif f5_as < f5_hs:
                return "LOSS"
            return "PUSH"

    # ── SPREAD ──────────────────────────────────────────────────────
    if mt == "SPREAD":
        if strike is None:
            return None
        # side = 'home' with strike = +1.5 means "home + 1.5"
        # side = 'away' with strike = -1.5 means "away − 1.5"
        if side == "home":
            adjusted = hs + strike
        else:
            adjusted = as_ + strike

        opp = as_ if side == "home" else hs
        if adjusted > opp:
            return "WIN"
        elif adjusted < opp:
            return "LOSS"
        return "PUSH"

    # ── F5 SPREAD ──────────────────────────────────────────────────────
    if mt == "F5_SPREAD":
        if strike is None:
            return None
        if side == "home":
            adjusted = f5_hs + strike
        else:
            adjusted = f5_as + strike
        opp = f5_as if side == "home" else f5_hs
        if adjusted > opp:
            return "WIN"
        elif adjusted < opp:
            return "LOSS"
        return "PUSH"

    # ── TOTAL (game) ──────────────────────────────────────────────────
    if mt == "TOTAL":
        if strike is None:
            return None
        if side == "over":
            if total > strike:
                return "WIN"
            elif total < strike:
                return "LOSS"
            return "PUSH"
        elif side == "under":
            if total < strike:
                return "WIN"
            elif total > strike:
                return "LOSS"
            return "PUSH"

    # ── F5 TOTAL ──────────────────────────────────────────────────────
    if mt == "F5_TOTAL":
        if strike is None:
            return None
        if side == "over":
            if f5_total > strike:
                return "WIN"
            elif f5_total < strike:
                return "LOSS"
            return "PUSH"
        elif side == "under":
            if f5_total < strike:
                return "WIN"
            elif f5_total > strike:
                return "LOSS"
            return "PUSH"

    # ── TEAM TOTAL ────────────────────────────────────────────────────
    if mt in ("TEAM_TOTAL", "F5_TEAM_TOTAL"):
        if strike is None or team_id is None:
            return None
        is_f5 = mt.startswith("F5_")
        if team_id == home_team_id:
            team_runs = f5_hs if is_f5 else hs
        elif team_id == away_team_id:
            team_runs = f5_as if is_f5 else as_
        else:
            return None
        if side == "over":
            if team_runs > strike:
                return "WIN"
            elif team_runs < strike:
                return "LOSS"
            return "PUSH"
        elif side == "under":
            if team_runs < strike:
                return "WIN"
            elif team_runs > strike:
                return "LOSS"
            return "PUSH"

    # ── PLAYER PROPS ──────────────────────────────────────────────────
    stat_key = _PLAYER_PROP_STAT_MAP.get(mt)
    if stat_key and player_id is not None:
        if strike is None:
            return None
        pstats = game_result["player_stats"].get(player_id)
        if pstats is None:
            return "PUSH"  # player didn't appear — voided per sportsbook convention
        actual_val = pstats.get(stat_key, 0)
        if side == "over":
            if actual_val > strike:
                return "WIN"
            elif actual_val < strike:
                return "LOSS"
            return "PUSH"
        elif side == "under":
            if actual_val < strike:
                return "WIN"
            elif actual_val > strike:
                return "LOSS"
            return "PUSH"

    # Unknown market type — can't grade
    return None


@app.post("/api/predictions/grade")
async def grade_predictions(
    game_pk: Optional[int] = None,
    date: Optional[str] = None,
):
    """
    Grade (settle) predictions for finished games.
    - If game_pk is given, grades that one game.
    - If date is given, grades all finished games on that date.
    - If neither, grades today's finished games.

    Updates the predictions table with result='WIN'/'LOSS'/'PUSH'
    and the games table with final scores.
    """
    _ensure_performance_tables()
    try:
        conn = _get_db_conn()
        cur = conn.cursor()

        # Determine which game_pks to grade
        if game_pk:
            game_pks = [game_pk]
        else:
            target_date = date or datetime.now().strftime("%Y-%m-%d")
            # Find games with ungraded predictions (regardless of local status)
            cur.execute("""
                SELECT DISTINCT p.game_pk
                FROM predictions p
                JOIN games g ON p.game_pk = g.game_pk
                WHERE g.game_date = %s AND p.result IS NULL
            """, (target_date,))
            game_pks = [r[0] for r in cur.fetchall()]

        if not game_pks:
            conn.close()
            return {"message": "No ungraded predictions found", "graded": 0, "games": []}

        results_summary = []
        total_graded = 0

        for gpk in game_pks:
            # Fetch game results from MLB API
            game_result = _fetch_game_results(gpk)
            if game_result is None:
                results_summary.append({
                    "game_pk": gpk, "status": "not_final", "graded": 0
                })
                continue

            # Update games table with final scores + status
            cur.execute("""
                UPDATE games SET
                    home_score = %s,
                    away_score = %s,
                    status_abstract = 'Final',
                    status_detailed = %s
                WHERE game_pk = %s
            """, (
                game_result["home_score"],
                game_result["away_score"],
                game_result["status_detailed"],
                gpk,
            ))

            # Get team IDs for this game
            cur.execute("""
                SELECT home_team_id, away_team_id FROM games WHERE game_pk = %s
            """, (gpk,))
            home_tid, away_tid = cur.fetchone()

            # Load all ungraded predictions for this game
            cur.execute("""
                SELECT id, market_type, side, strike, team_id, player_id
                FROM predictions
                WHERE game_pk = %s AND result IS NULL
            """, (gpk,))

            preds = cur.fetchall()
            game_graded = 0

            for row in preds:
                pred_id, mt, side, strike, team_id, player_id = row
                pred_dict = {
                    "market_type": mt,
                    "side": side,
                    "strike": strike,
                    "team_id": team_id,
                    "player_id": player_id,
                }
                result = _grade_prediction(pred_dict, game_result, home_tid, away_tid)
                if result is not None:
                    cur.execute("""
                        UPDATE predictions SET result = %s, updated_at = NOW()
                        WHERE id = %s
                    """, (result, pred_id))
                    game_graded += 1

            total_graded += game_graded
            results_summary.append({
                "game_pk": gpk,
                "status": "graded",
                "score": f"{game_result['away_score']}-{game_result['home_score']}",
                "graded": game_graded,
                "total_predictions": len(preds),
            })

        conn.commit()
        conn.close()

        return {
            "message": f"Graded {total_graded} predictions across {len(game_pks)} games",
            "graded": total_graded,
            "games": results_summary,
        }

    except HTTPException:
        raise
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(500, f"Error grading predictions: {e}")


@app.get("/api/predictions/grade-status")
async def get_grade_status(date: Optional[str] = None):
    """
    Returns how many predictions are graded vs ungraded for a date.
    Useful for the frontend to know whether to trigger grading.
    """
    target_date = date or datetime.now().strftime("%Y-%m-%d")
    try:
        conn = _get_db_conn()
        cur = conn.cursor()
        cur.execute("""
            SELECT
                COUNT(*) as total,
                SUM(CASE WHEN p.result IS NOT NULL THEN 1 ELSE 0 END) as graded,
                SUM(CASE WHEN p.result IS NULL THEN 1 ELSE 0 END) as ungraded,
                COUNT(DISTINCT CASE WHEN g.status_detailed LIKE '%%Final%%' THEN g.game_pk END) as final_games,
                COUNT(DISTINCT g.game_pk) as total_games,
                COUNT(DISTINCT CASE WHEN p.result IS NULL THEN g.game_pk END) as games_with_ungraded
            FROM predictions p
            JOIN games g ON p.game_pk = g.game_pk
            WHERE g.game_date = %s
        """, (target_date,))
        row = cur.fetchone()
        conn.close()
        return {
            "date": target_date,
            "total": row[0],
            "graded": row[1],
            "ungraded": row[2],
            "final_games": row[3],
            "total_games": row[4],
            "games_with_ungraded": row[5],
            "needs_grading": row[2] > 0,  # Always try — the grade endpoint checks MLB API
        }
    except Exception as e:
        raise HTTPException(500, f"Error checking grade status: {e}")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
