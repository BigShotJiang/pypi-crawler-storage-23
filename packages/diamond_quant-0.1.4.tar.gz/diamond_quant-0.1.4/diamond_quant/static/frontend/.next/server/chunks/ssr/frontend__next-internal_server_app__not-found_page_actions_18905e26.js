module.exports=[58921,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app__not-found_page_actions_18905e26.js.map