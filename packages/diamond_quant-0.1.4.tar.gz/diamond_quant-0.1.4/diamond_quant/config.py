"""
Configuration management for Diamond Quant
Handles API key storage and retrieval
"""

import os
import json
from pathlib import Path
from typing import Optional
import getpass

CONFIG_DIR = Path.home() / ".diamond-quant"
CONFIG_FILE = CONFIG_DIR / "config.json"
API_KEY_ENV_VAR = "DIAMOND_QUANT_API_KEY"


def ensure_config_dir():
    """Ensure config directory exists"""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    # Set restrictive permissions (owner read/write only)
    os.chmod(CONFIG_DIR, 0o700)


def get_api_key() -> Optional[str]:
    """
    Get API key from (in order of priority):
    1. Environment variable
    2. Config file
    3. None
    """
    # Check environment variable first
    env_key = os.getenv(API_KEY_ENV_VAR)
    if env_key:
        return env_key.strip()
    
    # Check config file
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                return config.get('api_key')
        except (json.JSONDecodeError, IOError):
            pass
    
    return None


def save_api_key(api_key: str) -> bool:
    """
    Save API key to config file with secure permissions
    Returns True if successful
    """
    try:
        ensure_config_dir()
        
        # Read existing config if it exists
        config = {}
        if CONFIG_FILE.exists():
            try:
                with open(CONFIG_FILE, 'r') as f:
                    config = json.load(f)
            except (json.JSONDecodeError, IOError):
                pass
        
        # Update API key
        config['api_key'] = api_key.strip()
        
        # Write config file
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f)
        
        # Set restrictive permissions (owner read/write only)
        os.chmod(CONFIG_FILE, 0o600)
        
        return True
    except (IOError, OSError) as e:
        print(f"Error saving API key: {e}")
        return False


def clear_api_key():
    """Remove API key from config file"""
    if CONFIG_FILE.exists():
        try:
            config = {}
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
            config.pop('api_key', None)
            
            if config:
                with open(CONFIG_FILE, 'w') as f:
                    json.dump(config, f)
            else:
                CONFIG_FILE.unlink()
        except (IOError, OSError):
            pass
