"""
API key validation and authentication
"""

import requests
from typing import Optional
from .config import get_api_key


def validate_api_key(api_key: str, api_url: str = "http://localhost:8000") -> tuple[bool, Optional[str]]:
    """
    Validate API key against backend
    Returns (is_valid, error_message)
    """
    try:
        response = requests.post(
            f"{api_url}/api/auth/validate",
            json={"api_key": api_key},
            headers={"Content-Type": "application/json"},
            timeout=5
        )
        
        if response.status_code == 200:
            data = response.json()
            return (data.get("valid", False), None)
        elif response.status_code == 401:
            return (False, "Invalid API key")
        elif response.status_code == 404:
            # Endpoint doesn't exist - might be local dev without auth
            return (True, None)  # Allow if endpoint doesn't exist
        else:
            return (False, f"Validation error: {response.status_code}")
    except requests.exceptions.ConnectionError:
        return (False, "Cannot connect to API server. Is it running?")
    except requests.exceptions.Timeout:
        return (False, "Request timed out")
    except Exception as e:
        return (False, f"Error: {str(e)}")


def get_validated_api_key(api_url: str = "http://localhost:8000") -> Optional[str]:
    """
    Get API key from config and validate it
    Returns API key if valid, None otherwise
    """
    api_key = get_api_key()
    if not api_key:
        return None
    
    is_valid, error = validate_api_key(api_key, api_url)
    if is_valid:
        return api_key
    
    return None
