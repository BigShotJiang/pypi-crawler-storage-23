# Changelog

## [0.3.0](https://github.com/jbussdieker/bussdcc-framework/compare/v0.2.2...v0.3.0) (2026-03-01)


### Features

* **bussdcc_framework:** update event handling and dependencies ([20ec215](https://github.com/jbussdieker/bussdcc-framework/commit/20ec2159b167c1cfeef15c05a4d6754396203958))

## [0.2.2](https://github.com/jbussdieker/bussdcc-framework/compare/v0.2.1...v0.2.2) (2026-03-01)


### Bug Fixes

* **web:** update context processor and remove abstract methods ([8825418](https://github.com/jbussdieker/bussdcc-framework/commit/882541877ccc0e905af1ea205fef45fe1571e37e))

## [0.2.1](https://github.com/jbussdieker/bussdcc-framework/compare/v0.2.0...v0.2.1) (2026-03-01)


### Bug Fixes

* **bussdcc_framework:** add py.typed file ([93501a4](https://github.com/jbussdieker/bussdcc-framework/commit/93501a40be3b83383036ef0606bf9f19586b12a9))

## [0.2.0](https://github.com/jbussdieker/bussdcc-framework/compare/v0.1.0...v0.2.0) (2026-03-01)


### Features

* **web:** enhance Flask app creation and remove templates ([c974721](https://github.com/jbussdieker/bussdcc-framework/commit/c974721c78d07f17247a25a0d23faad1cb2a566f))

## 0.1.0 (2026-03-01)


### Features

* initial commit ([0c837b7](https://github.com/jbussdieker/bussdcc-framework/commit/0c837b7021923a01c4782e17b28693d0133e6c96))
