# coding=utf-8
'''
Copyright (C) 2022-2026 Siogeen

Created on 14.11.2022

@author: Reimund Renner
'''

from threading import Thread

import webbrowser
import re
import os
#import time

os.environ["KIVY_NO_CONSOLELOG"] = "1"

from siogeen.base import IoddUtility
try:
    import kivymd
except ModuleNotFoundError as error:
    raise ModuleNotFoundError(f'{error}. Please install kivymd')
IoddUtility.checkModuleVersion(kivymd, "1.2.0")

from kivymd.app import MDApp
from kivymd.uix.button import MDFillRoundFlatButton as Button
#from kivymd.uix.tooltip.tooltip import MDTooltip
from kivymd.uix.button import MDFloatingActionButtonSpeedDial as FloatingButton
from kivymd.uix.textfield.textfield import MDTextFieldRect as TextInput
from kivymd.uix.selectioncontrol.selectioncontrol import MDCheckbox
from kivymd.uix.menu import MDDropdownMenu
from kivymd.uix.dropdownitem.dropdownitem import MDDropDownItem
#from kivymd.uix.behaviors.toggle_behavior import MDToggleButton
from kivymd.uix.label import MDLabel
#from kivy.clock import Clock
from kivymd.uix.scrollview import MDScrollView
#from kivy.properties import StringProperty
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.floatlayout import MDFloatLayout
#from kivymd.uix.stacklayout import MDStackLayout

from kivy.logger import Logger, LOG_LEVELS
from kivy.config import Config
from kivy.core.clipboard import Clipboard
from kivy.clock import Clock
from kivy.core.window import Window

from siogeen.tools import IoddComChecker

__version__ = "1.9.2"

# pylint: disable=attribute-defined-outside-init, invalid-name

class IoddComCheckerGui(MDApp):
    """IoddCom Checker GUI"""

    _g_selectIds = ('', 'usb', 'eth', 'ble')
    _g_selectNames = ('all', 'USB only', 'Ethernet and WiFi only', 'Bluetooth LE only')

    def __init__(self, address=None, auto=False, verbose=2, select=None,
                 screenMode='Dark', test=None, **kwargs):
        sel = '' if select is None else str(select).lower()
        if sel not in IoddComCheckerGui._g_selectIds:
            raise ValueError(f"Invalid selection: '{select}'")

        super().__init__(**kwargs)

        self._a_address = '' if address is None else str(address)
        self._a_auto = bool(auto)
        self._a_verbose = int(verbose)
        self._a_select = sel
        self._a_screen_mode = str(screenMode)

        if test:
            Clock.schedule_once(self.on_request_close, min(30, test))

    def build(self):
        """Build GUI"""
        self._closing = False
        Config.set('input', 'mouse', 'mouse,multitouch_on_demand')
        Logger.setLevel(LOG_LEVELS["error"])

        if __version__ == IoddComChecker.__version__:
            self.title = 'IoddComChecker ' + IoddComChecker.__version__
        else:
            self.title = f'IoddComChecker {IoddComChecker.__version__}' \
                f'  (Gui {__version__})'

        self.theme_cls.primary_palette = "Blue" # "Green"
        self.theme_cls.theme_style = self._a_screen_mode

        Window.bind(on_request_close=self.on_request_close)

        self.screenBox = MDFloatLayout()
        #self.mainBox = MDBoxLayout(orientation='horizontal', spacing=10)
        self.menuBox = MDBoxLayout(orientation='horizontal', spacing=20,
            size_hint=(0.88,None))
        self.autoBox = MDBoxLayout(orientation='horizontal', spacing=10)

        self.autoChk = MDCheckbox(active=self._a_auto, size_hint=(.1,None),
                                  height=30, pos_hint={'y':0.07})
        self.autoLabel = MDLabel(text='[ref=auto]auto ports: activate ports'
            ' for IP based masters if all are disabled (changes master port configs)[/ref]',
            size_hint=(.7,None), height=30, on_ref_press=self.cb_autoLabelPress,
            markup=True, pos_hint={'y':0.07})#, color=(184/255,240/255,1,1))

        self.selectBox = MDBoxLayout(orientation='vertical', spacing=0,
            pos_hint={'y':0.07}, size_hint=(None, None), width=130)
        self.selectLabel = MDLabel(text='select type:',
            size_hint=(None,None), height=30, pos_hint={'y':0.07})

        self.selectedId = self._a_select
        self.selectItems = [{"text": text, "on_release":
            lambda sid=sid, text=text: self.cb_selectMenuCallback(sid, text)}
            for sid, text
            in zip(IoddComCheckerGui._g_selectIds, IoddComCheckerGui._g_selectNames)]
        self.selectedItem = MDDropDownItem(id="select",
                               pos_hint={'y': 0.07},
                               on_release=self.cb_openSelectMenu)
        self.selectedItem.text = IoddComCheckerGui._g_selectNames[
            IoddComCheckerGui._g_selectIds.index(self.selectedId)]
        self.selectMenu = MDDropdownMenu(
            caller=self.selectedItem, items=self.selectItems)
        self.selectBox.add_widget(self.selectLabel)
        self.selectBox.add_widget(self.selectedItem)

        self.addr = TextInput(text=self._a_address, hint_text='Search specific addresses ...'
            ' (e.g. 10.0.2.3, 192.168.178.25, ...)',
            size_hint=(.5,None), height=30)#, background_normal='',
            #background_color=(206/255,228/255,1,1))
        self.clearBtn = Button(text='Clear', on_press=self.cb_clearAddr,
            size_hint=(.1,None), height=30)#, color=(0,0,0,1),
            #background_normal='', background_color=(206/255,228/255,1,1))
        self.scanBtn = Button(text='Scan', on_press=self.cb_scan,
            size_hint=(.1,None), height=30, text_color='black',
            md_bg_color=[.63,1,0,1])#, color=(0,0,0,1),
            #background_normal='', background_color=(161/255,1,0,1))
        self.scanText = MDLabel(height=400, size_hint_y=None, markup=True)
        self.scanText.bind(on_ref_press=self.cb_link)
        self.scrollView = MDScrollView(size_hint=(1,.84), pos_hint={'y':.14},
            bar_width=7)
        self.scrollView.add_widget(self.scanText)

        self.autoBox.add_widget(self.autoChk)
        self.autoBox.add_widget(self.autoLabel)
        self.autoBox.add_widget(self.selectBox)
        self.autoBox.add_widget(Button(text='Clear', on_press=self.cb_clearText,
            size_hint=(.1,None), height=30, pos_hint={'y':0.07}))#, color=(0,0,0,1),
            #background_normal='', background_color=(161/255,1,0,1)))
        self.autoBox.add_widget(Button(text='Copy', on_press=self.cb_copyText,
            size_hint=(.1,None), height=30, pos_hint={'y':0.07}))#, color=(0,0,0,1),
            #background_normal='', background_color=(161/255,1,0,1)))

        self.floatMenu = FloatingButton(data={
            'Contact Support': ['lifebuoy', 'on_release', self.cb_contactSupport],
            },
            icon="dots-vertical", size_hint=(0.15,None),
            bg_color_root_button="red", bg_color_stack_button="red")

        self.menuBox.add_widget(self.addr)
        self.menuBox.add_widget(self.clearBtn)
        self.menuBox.add_widget(self.scanBtn)

        self.autoBox.add_widget(self.floatMenu)

        self.screenBox.add_widget(self.scrollView)
        #self.screenBox.add_widget(self.mainBox)
        self.screenBox.add_widget(self.autoBox)
        self.screenBox.add_widget(self.menuBox)

        self.clock = None

        return self.screenBox

    def cb_openSelectMenu(self, item):
        """Open select driver menu"""
        self.selectMenu.open()

    def cb_selectMenuCallback(self, sid, text):
        """Select driver menu callback"""
        self.selectedId = sid
        self.selectedItem.text = text
        self.selectMenu.dismiss()

    def cb_contactSupport(self, *args):
        """Open contact web page"""
        webbrowser.open("https://siogeen.com/#contact")

    def cb_clearAddr(self, instance):
        """Clear search master addresses"""
        self.addr.text = ''

    def cb_autoLabelPress(self, instance, value):
        """Auto ports label pressed"""
        self.autoChk._do_press()

    def cb_clearText(self, instance):
        """Clear scan result text"""
        self.scanText.text = ''

    def cb_copyText(self, instance):
        """Copy scan result text"""
        Clipboard.copy(self.scanText.text)

    def cb_link(self, instance, value):
        """Open link in browser"""
        #webbrowser.open(instance.target)
        webbrowser.open(value)

    def print(self, text=''):
        """GUI print function"""
        if 'https' in text:
            pre, link, post = re.search(r'(.*)(https://[^\s]*)(.*)', text).groups()
            text = f'{pre}[color=#4699ff][u][ref={link}]{link}[/ref][/u][/color]{post}'
            #self.scanText.target = link
        #text = re.sub(',\n\s+', ', ', text)
        self.scanText.text += text + '\n'

    def cb_updateTextSize(self, dt):
        """Update scan result text size"""
        self.scanText.height = self.scanText.texture_size[1]
        if self.scanText.height > self.scrollView.height:
            self.scrollView.scroll_y = 0

    def on_request_close(self, *args):
        self._closing = True
        if IoddComChecker.isRunning():
            self.scanText.text += "\nclosing..."
            IoddComChecker.abort()
        else:
            self.stop()
            Window.close()
        return True # Verhindert, dass das Standard-Kivy-Schließverhalten ausgeführt wird

    def runChecker(self, *args):
        """Execute scan"""
        self.scanBtn.disabled = True
        try:
            self.clock = Clock.schedule_interval(self.cb_updateTextSize, 0.25)
            IoddComChecker.check(*args, gui=True)
        finally:
            self.scanText.text += '\n'

            self.clock.cancel()
            self.clock = None
            Clock.schedule_once(self.cb_updateTextSize, 0.25)

            self.scanBtn.disabled = False

            if self._closing:
                Clock.schedule_once(self.actually_close, 0.5)

    def actually_close(self, dt):
        self.stop()
        Window.close()

    def cb_scan(self, instance):
        """Execute scan as thread"""
        if self.scanText.text:
            self.scanText.text += '_'*80 + '\n'
        addrs = self.addr.text
        if addrs:
            addrs = addrs.split(',')
        t = Thread(target=self.runChecker, args=(addrs, self.autoChk.active,
                self.print, self._a_verbose, self.selectedId))
        t.daemon = True
        t.start()

if __name__ == '__main__':
    IoddComCheckerGui().run()
