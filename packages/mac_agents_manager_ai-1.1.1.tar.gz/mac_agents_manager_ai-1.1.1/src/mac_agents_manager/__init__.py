"""Mac Agents Manager -- A web UI for managing macOS LaunchAgents."""

__version__ = "1.1.1"
