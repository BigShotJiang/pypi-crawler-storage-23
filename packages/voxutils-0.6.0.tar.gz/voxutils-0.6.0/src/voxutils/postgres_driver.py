import traceback
from asyncio import CancelledError, Event, Task, all_tasks
from collections.abc import AsyncGenerator, Awaitable, Callable
from contextlib import asynccontextmanager
from datetime import date, datetime, time, timedelta
from decimal import Decimal
from typing import TypeAlias
from uuid import UUID

from asyncpg import Connection, Pool, Record, connect, create_pool
from asyncpg.connection import LoggedQuery
from asyncpg.exceptions import PostgresError as AsyncpgError
from asyncpg.pool import PoolConnectionProxy

from voxutils.abc import AbstractRetryTimer
from voxutils.asyncutils import run_task
from voxutils.log import INFO, TRACE, StructuredLogger
from voxutils.utils import T

PGValue: TypeAlias = (
    None
    | bool
    | int
    | float
    | str
    | bytes
    | Decimal
    | UUID
    | date
    | time
    | datetime
    | timedelta
    | list['PGValue']
    | tuple['PGValue', ...]
    | dict[str, 'PGValue']
)
PGTuple: TypeAlias = tuple[PGValue, ...]
PGList: TypeAlias = list[PGValue]
PGDict: TypeAlias = dict[str, PGValue]
Params: TypeAlias = PGTuple | PGList | PGDict

class PostgresDriver:
    def __init__(
        self,
        dsn: str,
        retry_timer: AbstractRetryTimer,
        logger: StructuredLogger,
        pool_min_size: int = 4,
        pool_max_size: int = 2,
        timeout: float = 5.0,
        command_timeout: float = 30.0,
    ) -> None:
        self._dsn: str = dsn
        self._retry_timer: AbstractRetryTimer = retry_timer
        self._logger: StructuredLogger = logger
        self._pool_min_size: int = pool_min_size
        self._pool_max_size: int = pool_max_size
        self._timeout: float = timeout
        self._command_timeout: float = command_timeout
        self._pool: Pool | None = None
        self._listener_conn: Connection | None = None
        self._ready_event = Event()
        self._rowcount: int = 0

    async def _connect(self) -> None:
        while True:
            self._ready_event.clear()

            if self._pool:
                self._logger.debug('Closing old database pool')
                try:
                    await self._pool.close()
                except Exception:
                    self._logger.exception('Error closing old pool')
                self._pool = None

            try:
                self._logger.debug('Attempting database connection')
                self._pool = await create_pool(
                    dsn=self._dsn,
                    min_size=self._pool_min_size,
                    max_size=self._pool_max_size,
                    timeout=self._timeout,
                    command_timeout=self._command_timeout,
                )
                # Quick smoke test
                async with self._pool.acquire() as conn:
                    await conn.fetchval('SELECT 1')
                self._logger.info('Database connection OK')
                self._retry_timer.reset()
                self._ready_event.set()
                return
            except AsyncpgError as err:
                self._logger.exception('Could not connect to database')
                if 'authentication failed' in str(err).lower():
                    self._logger.error('Authentication failed ? stopping retries')
                    return
            except Exception:
                self._logger.exception('Unexpected error connecting to database')
                traceback.print_exc()

            if self._logger.isEnabledFor(INFO):
                delay: float = self._retry_timer.next_delay()
                if delay > 0.0:
                    self._logger.info('Delaying next database connect attempt by %s seconds', delay)
            await self._retry_timer.wait()

    def _named_to_pos(self, query: str, params: PGDict) -> tuple[str, PGList]:
        """Simple named ? positional converter (very basic, no nesting support)"""
        pos_params: list[PGValue] = []
        for index, (key, value) in enumerate(params.items(), start=1):
            placeholder: str = f':{key}'
            if placeholder not in query:
                raise ValueError(f'Missing placeholder :{key}')
            query = query.replace(placeholder, f'${index}')
            pos_params.append(value)
        return query, pos_params

    def _parse_rowcount(self, status: str) -> int:
        try:
            return int(status.split()[-1])
        except (ValueError, IndexError):
            return 0

    def _log_query(self, record: LoggedQuery) -> None:
        # Approximate bound query for logging (not for execution!)
        if not self._logger.isEnabledFor(TRACE):
            return
        bound_query: str = record.query
        if record.args:
            escaped: str
            for i, param in enumerate(record.args, 1):
                if param is None:
                    escaped = 'NULL'
                elif isinstance(param, str):
                    # Basic escaping for strings (not perfect, but good for logs)
                    escaped = "'" + param.replace("'", "''") + "'"
                elif isinstance(param, (int, float, bool)):
                    escaped = str(param)
                elif isinstance(param, datetime):
                    escaped = f"'{param.isoformat()}'"
                elif isinstance(param, date):
                    escaped = f"'{param.isoformat()}'"
                elif isinstance(param, time):
                    escaped = f"'{param.isoformat()}'"
                elif isinstance(param, timedelta):
                    # Simple string repr for timedelta (e.g. '1 day, 2:03:04')
                    escaped = f"'{str(param)}'"
                elif isinstance(param, bytes):
                    escaped = f"b'{param.hex()}'"  # hex repr for bytes
                else:
                    # Fallback for other types (e.g. UUID, arrays, JSON)
                    escaped = repr(param)
                # Replace all occurrences of this placeholder
                bound_query = bound_query.replace(f'${i}', escaped)
        self._logger.trace(bound_query)

    @asynccontextmanager
    async def _logged_acquire(self) -> AsyncGenerator[PoolConnectionProxy]:
        """
        Acquire a connection from the pool and add/remove the query logger.

        Usage:
            async with logged_acquire(pool) as conn:
                await conn.fetch(...)
        """
        if not self._pool:
            raise RuntimeError('Database not connected')
        conn: PoolConnectionProxy = await self._pool.acquire()
        try:
            # Add the logger (it will be called for every query on this conn)
            conn.add_query_logger(self._log_query)
            yield conn
        finally:
            # Optional: remove after use (prevents accumulation if reused)
            conn.remove_query_logger(self._log_query)
            # Always release back to pool
            await self._pool.release(conn)

    async def _db_query(self, db_coro: Awaitable[T]) -> T:
        if not self._ready_event.is_set():
            raise RuntimeError('Database not ready')

        try:
            return await db_coro
        except AsyncpgError as err:
            self._ready_event.clear()
            self._logger.error('Database error: %s %s', getattr(err, 'sqlstate', '?'), str(err))
            run_task(self._connect(), 'Database connector')
            raise

    async def _db_generator(
        self,
        db_func: Callable[[str, Params], AsyncGenerator[T]],
        query: str,
        params: Params,
    ) -> AsyncGenerator[T]:
        if not self._ready_event.is_set():
            raise RuntimeError('Database not ready')
        if isinstance(params, dict):
            query, params = self._named_to_pos(query, params)
        try:
            async for item in db_func(query, params):
                yield item
        except AsyncpgError as err:
            self._ready_event.clear()
            self._logger.error('Database error: %s %s', getattr(err, 'sqlstate', '?'), str(err))
            run_task(self._connect(), 'Database connector')
            raise

    async def _exec(self, query: str, params: Params) -> None:
        async with self._logged_acquire() as conn:
            if isinstance(params, dict):
                query, params = self._named_to_pos(query, params)
            status: str = await conn.execute(query, *params)
            self._rowcount = self._parse_rowcount(status)
            if self._logger.isEnabledFor(TRACE):
                self._logger.trace('%d row(s) affected', self._rowcount)

    async def _select(self, query: str, params: Params) -> list[PGTuple]:
        async with self._logged_acquire() as conn:
            if isinstance(params, dict):
                query, params = self._named_to_pos(query, params)
            rows: list[Record] = await conn.fetch(query, *params)
            self._rowcount = len(rows)
            if self._logger.isEnabledFor(TRACE):
                self._logger.trace('%d row(s) returned', self._rowcount)
            return [tuple(r.values()) for r in rows]

    async def _select_dict(self, query: str, params: Params) -> list[PGDict]:
        async with self._logged_acquire() as conn:
            if isinstance(params, dict):
                query, params = self._named_to_pos(query, params)
            rows: list[Record] = await conn.fetch(query, *params)
            self._rowcount = len(rows)
            if self._logger.isEnabledFor(TRACE):
                self._logger.trace('%d row(s) returned', self._rowcount)
            return [dict(r) for r in rows]

    async def _yield_records(
        self,
        query: str,
        params: Params,
        as_dict: bool = False,
    ) -> AsyncGenerator[Record | PGDict]:
        self._rowcount = 0  # No accurate count for streaming without exhausting
        async with self._logged_acquire() as conn:
            if isinstance(params, dict):
                query, params = self._named_to_pos(query, params)
            async with conn.transaction():
                cursor = await conn.cursor(query, *params)
                while True:
                    batch = await cursor.fetch(100)  # Batch size - tune
                    if not batch:
                        break
                    for row in batch:
                        yield dict(row) if as_dict else row

    async def _scalar(self, query: str, params: Params) -> PGValue:
        async with self._logged_acquire() as conn:
            if isinstance(params, dict):
                query, params = self._named_to_pos(query, params)
            val = await conn.fetchval(query, *params)
            self._rowcount = 1 if val is not None else 0
            if self._logger.isEnabledFor(TRACE):
                self._logger.trace('%d row(s) affected', self._rowcount)
            return val

    async def _scalarlist(self, query: str, params: Params) -> PGTuple:
        async with self._logged_acquire() as conn:
            if isinstance(params, dict):
                query, params = self._named_to_pos(query, params)
            rows = await conn.fetch(query, *params)
            self._rowcount = len(rows)
            if self._logger.isEnabledFor(TRACE):
                self._logger.trace('%d row(s) returned', self._rowcount)
            if not rows:
                return ()
            if len(rows) == 1:
                return tuple(rows[0].values())
            return tuple(row[0] for row in rows)

    @property
    def rowcount(self) -> int:
        return self._rowcount

    @property
    def ready(self) -> Event:
        return self._ready_event

    async def start(self) -> None:
        run_task(self._connect(), 'Database connector')
        await self._ready_event.wait()

    async def stop(self) -> None:
        connect_task: Task | None = next(
            (t for t in all_tasks() if t.get_name() == 'Database connector'), None
        )
        if connect_task:
            connect_task.cancel()
            try:
                await connect_task
            except CancelledError:
                pass

        if self._listener_conn:
            try:
                await self._listener_conn.close()
            except Exception:
                self._logger.exception('Error closing listener connection')
            self._listener_conn = None

        if self._pool:
            try:
                await self._pool.close()
            except Exception:
                self._logger.exception('Error closing pool during shutdown')

    async def exec(self, query: str, params: Params = ()) -> None:
        await self._db_query(self._exec(query, params))

    async def select(self, query: str, params: Params = ()) -> list[PGTuple]:
        return await self._db_query(self._select(query, params))

    async def select_dict(self, query: str, params: Params = ()) -> list[PGDict]:
        return await self._db_query(self._select_dict(query, params))

    async def yield_tuple(self, query: str, params: Params = ()) -> AsyncGenerator[PGTuple]:
        async for row in self._db_generator(
            lambda q, p: self._yield_records(q, p, as_dict=False), query, params
        ):
            yield tuple(row.values()) if isinstance(row, Record) else tuple(row)

    async def yield_dict(self, query: str, params: Params = ()) -> AsyncGenerator[PGDict]:
        async for row in self._db_generator(
            lambda q, p: self._yield_records(q, p, as_dict=True), query, params
        ):
            yield row

    async def scalar(self, query: str, params: Params = ()) -> PGValue:
        return await self._db_query(self._scalar(query, params))

    async def scalarlist(self, query: str, params: Params = ()) -> PGTuple:
        return await self._db_query(self._scalarlist(query, params))

    # Transaction support
    @asynccontextmanager
    async def transaction(self) -> AsyncGenerator[Connection]:
        async with self._logged_acquire() as conn:
            async with conn.transaction():
                yield conn

    # LISTEN/NOTIFY support
    async def notify(self, channel: str, payload: str = '') -> None:
        async with self._logged_acquire() as conn:
            await conn.execute("SELECT pg_notify($1, $2)", channel, payload)

    async def add_listener(
        self,
        channel: str,
        callback: Callable[[Connection | PoolConnectionProxy, int, str, object], Awaitable[None]],
    ) -> None:
        if self._listener_conn is None:
            if not self._pool:
                raise RuntimeError('Database not connected')
            self._listener_conn = await connect(
                self._dsn, timeout=self._timeout, command_timeout=self._command_timeout
            )
            self._listener_conn.add_query_logger(self._log_query)
        await self._listener_conn.add_listener(channel, callback)

    async def remove_listener(
        self,
        channel: str,
        callback: Callable[[Connection | PoolConnectionProxy, int, str, object], Awaitable[None]],
    ) -> None:
        if self._listener_conn is not None:
            await self._listener_conn.remove_listener(channel, callback)
