import logging
from datetime import date, datetime, time, timedelta
from logging import CRITICAL, DEBUG, ERROR, INFO, WARNING, Formatter, Handler, Logger, StreamHandler
from types import TracebackType
from typing import TypeAlias

import orjson

TRACE: int = DEBUG - 5
BasicTypes: TypeAlias = None | bool | int | float | str
_ExcInfoType: TypeAlias = (
    None
    | bool
    | tuple[type[BaseException], BaseException, TracebackType | None]
    | tuple[None, None, None]
    | BaseException
)
# Add TRACE level to logging module
logging.addLevelName(TRACE, 'TRACE')
setattr(logging, 'TRACE', TRACE)


class StructuredLogger(Logger):
    """
    It implements a structured logger that renders logs as JSON.

    example usage:

    .. highlight:: python
    .. code-block:: python

        logger = StructuredLogger('myLogger')
        logger.log(logging.INFO, event='web_request', url='https://www.google.com/')
    """

    def __init__(
        self,
        logger_name: str,
        level: str | int = INFO,
        log_metadata: dict[str, BasicTypes] | None = None,
        handler: Handler | None = None,
        include_timestamp: bool = True,
        include_level: bool = True,
    ) -> None:
        """
        Parameters
        ----------
        logger_name: str
            Name of the logger. It should be unique per logger.
        level: Union[str, int]
            The level at which to log.
        log_metadata: Optional[dict[str, None | bool | int | float | str]]
            Metadata that will be included in all log statements.
        handler: Optional[logging.Handler]
            Logging `handler <https://docs.python.org/3/library/logging.html#logging.Handler>`_
            to be attached to this logger. By default, `logging.StreamHandler` is used.
        include_timestamp bool:
            Whether to include datetime in ISO8601 format in log entries.
        include_level: bool
            Whether to include with log level name in log entries.
        """
        super().__init__(name=logger_name, level=self._check_level(level))
        self.log_metadata: dict[str, BasicTypes] = log_metadata or {}
        self.handler: Handler = handler or StreamHandler()
        self.include_timestamp: bool = include_timestamp
        self.include_level: bool = include_level

        self.handler.setFormatter(Formatter('%(message)s'))
        self.handler.setLevel(self.level)
        self.addHandler(self.handler)
        # self.setLevel(self.level)

    def trace(self, msg: object, *args, **kwargs) -> None:
        if self.isEnabledFor(TRACE):
            self._log(TRACE, msg, args, **kwargs)

    def debug(self, msg: object, *args, **kwargs) -> None:
        if self.isEnabledFor(DEBUG):
            self._log(DEBUG, msg, args, **kwargs)

    def info(self, msg: object, *args, **kwargs) -> None:
        if self.isEnabledFor(INFO):
            self._log(INFO, msg, args, **kwargs)

    def warning(self, msg: object, *args, **kwargs) -> None:
        if self.isEnabledFor(WARNING):
            self._log(WARNING, msg, args, **kwargs)

    def error(self, msg: object, *args, **kwargs) -> None:
        if self.isEnabledFor(ERROR):
            self._log(ERROR, msg, args, **kwargs)

    def exception(self, msg: object, *args, exc_info: _ExcInfoType = True, **kwargs) -> None:
        self.error(msg, *args, exc_info=exc_info, **kwargs)

    def critical(self, msg: object, *args, **kwargs) -> None:
        if self.isEnabledFor(CRITICAL):
            self._log(CRITICAL, msg, args, **kwargs)

    def log(self, level: int, msg: object, *args, **kwargs) -> None:
        assert isinstance(level, int)
        if self.isEnabledFor(level):
            self._log(level, msg, args, **kwargs)

    def setLevel(self, level: str | int) -> None:
        int_level: int = self._check_level(level)
        super().setLevel(int_level)

    def _log(self, level: int, msg: object, *args, **kwargs) -> None:
        user_args: dict[str, BasicTypes] = {
            key: value
            for key, value in kwargs.items()
            if key not in ('exc_info', 'stack_info', 'stacklevel')
        }
        logger_args: dict[str, BasicTypes] = {
            key: value
            for key, value in kwargs.items()
            if key in ('exc_info', 'stack_info', 'stacklevel')
        }
        if self.include_timestamp:
            user_args['timestamp'] = datetime.now().isoformat()
        if self.include_level:
            user_args['log_level'] = logging.getLevelName(level)
        new_msg: str = self._process_msg(msg, **user_args)
        return super()._log(level, new_msg, *args, **logger_args)

    @staticmethod
    def _check_level(level: str | int) -> int:
        if isinstance(level, int):
            return level
        int_level: int = logging.getLevelNamesMapping().get(level.upper(), -9999)
        if int_level == -9999:
            raise ValueError(f'Unknown logging {level}.')
        return int_level

    def _process_msg(self, msg: object, **user_args: BasicTypes) -> str:
        merged_args: dict[str, BasicTypes] = {**user_args, **self.log_metadata}
        if merged_args:
            return f'{msg} >>> {self._to_json(merged_args)}'
        return str(msg)

    def _json_default(self, o: BasicTypes) -> BasicTypes:
        if isinstance(o, timedelta):
            return o.total_seconds()
        if isinstance(o, (date, time, datetime)):
            return o.isoformat()
        return o.__repr__()

    def _to_json(self, input_msg: dict[str, BasicTypes]) -> str:
        """
        Tries to convert the input message to JSON and returns it.
        If it fails, it returns the error in string (not JSON) format.
        """
        try:
            return orjson.dumps(
                input_msg, default=self._json_default, option=orjson.OPT_PASSTHROUGH_DATACLASS
            ).decode('utf-8')
        except Exception as err:  # pylint: disable=broad-except
            return f'StructuredLogger error: {repr(err)}'
