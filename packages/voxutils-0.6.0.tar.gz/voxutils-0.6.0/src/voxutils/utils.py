import re
from collections.abc import Callable
from datetime import date, datetime, time
from ipaddress import IPv4Address, IPv4Network
from socket import AF_INET
from subprocess import CalledProcessError, CompletedProcess, run
from typing import TypeAlias, TypeVar
from xml.etree.ElementTree import Element, ParseError
from xml.etree.ElementTree import parse as xmlparse
from xml.etree.ElementTree import tostring as xmltostring

from pyroute2 import NDB
from pyroute2.ndb.view import View

from .exceptions import InternalError

RT_PROTO_KERNEL: int = 2  # Indicates route was installed by kernel
RT_MAIN_TABLE: int = 254  # Main routing table

E164_RE: re.Pattern[str] = re.compile(r'^[+][1-9][0-9]{1,17}$')
PHONE_RE: re.Pattern[str] = re.compile(r'^[0-9]{1,30}$')  # Allow for international prefixes
RouteData: TypeAlias = tuple[
    set[tuple[IPv4Network, IPv4Address]], set[tuple[IPv4Network, IPv4Address]], IPv4Address
]  # Connected networks, system routes, default gateway
_route_cache: RouteData | None = None
JsonValue: TypeAlias = (
    None
    | bool
    | int
    | float
    | str
    | tuple['JsonValue', ...]
    | list['JsonValue']
    | dict[str, 'JsonValue']
)
JsonDict: TypeAlias = dict[str, JsonValue]
T = TypeVar('T')


class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'


class HashableDict(dict[str, str]):
    def __hash__(self):
        return hash((frozenset(self.keys()), frozenset(self.values())))


class XMLCombiner:
    def __init__(self, filenames: list[str]):
        if not filenames:
            raise ValueError('No XML file names provided')
        # Save all the _roots, in order, to be processed later
        try:
            roots: list[Element | None] = [xmlparse(filename).getroot() for filename in filenames]
            self._roots: list[Element] = [elem for elem in roots if elem is not None]
            if len(roots) != len(self._roots):
                raise RuntimeError(f'Error parsing XML files {",".join(filenames)}')
        except ParseError as err:
            raise RuntimeError(f'Error parsing XML files {",".join(filenames)}: {err}') from err

    def combine(self) -> str:
        first_root: Element = self._roots[0]
        for root in self._roots[1:]:
            # Combine each element with the first one, and update that
            self.combine_element(first_root, root)
        # Return a cleaned-up string representation
        xml_str = xmltostring(first_root, 'unicode')
        # Remove ns0 namespace added automatically if default namespace is not registered
        xml_str = xml_str.replace('ns0:', '').replace(':ns0', '')
        xml_str = '\n'.join([line.strip() for line in xml_str.splitlines() if line.strip()])
        return '<?xml version="1.0" encoding="UTF-8" ?>\n' + xml_str

    def combine_element(self, one: Element, other: Element) -> None:
        """
        This function recursively updates either the text or the children
        of an element if another element is found in `one`, or adds it
        from `other` if not found.
        """
        # Create a mapping from tag name to element, as that's what we are filtering with
        mapping = {HashableDict({'__tag__': elem.tag, **elem.attrib}): elem for elem in one}
        for elem in other:
            key = HashableDict({'__tag__': elem.tag, **elem.attrib})
            if len(elem) == 0:
                # Not nested
                try:
                    # Update the text
                    mapping[key].text = elem.text
                except KeyError:
                    # An element with this name is not in the mapping
                    mapping[key] = elem
                    # Add it
                    one.append(elem)
            else:
                try:
                    # Recursively process the element, and update it in the same way
                    self.combine_element(mapping[key], elem)
                except KeyError:
                    # Not in the mapping
                    mapping[key] = elem
                    # Just add it
                    one.append(elem)


def first(*args: T | None) -> T:
    # Returns first argument which is not None
    # Will raise StopIteration if all arguments are None
    return next(arg for arg in args if arg is not None)


def from_str(value: str | None, converter: Callable[..., T] | type[T]) -> T | None:
    if value is None:
        return value
    if converter is str:
        return value  # ty:ignore[invalid-return-type] ; str does not need conversion
    if converter is bool:
        return value.lower() in ('true', '1')  # ty:ignore[invalid-return-type] ; bool is special
    if converter is date:
        return date.fromisoformat(value)  # ty:ignore[invalid-return-type] ; convert from ISO
    if converter is time:
        return time.fromisoformat(value)  # ty:ignore[invalid-return-type] ; convert from ISO
    if converter is datetime:
        return datetime.fromisoformat(value)  # ty:ignore[invalid-return-type] ; convert from ISO
    if isinstance(converter, type):
        return converter(value)  # int, float
    if callable(converter):
        return converter(value)
    raise InternalError(f'Unknown converter {converter!r} for value "{value}"')


def load_file(filename: str) -> str:
    with open(filename, encoding='utf-8') as file:
        return file.read()


def get_local_ip_addresses() -> tuple[IPv4Address, ...]:
    ndb: NDB = NDB()
    addresses: View = ndb.addresses  # ty:ignore[unresolved-attribute] ; dynamic member
    return tuple(IPv4Address(addr.address) for addr in addresses.dump().filter(family=AF_INET))


def get_local_ip_routes(force: bool = False) -> RouteData:
    global _route_cache
    if not force and _route_cache:
        return _route_cache

    ndb: NDB = NDB()
    default_gw: IPv4Address = IPv4Address(0)
    system_routes: set[tuple[IPv4Network, IPv4Address]] = set()
    connected_nets: set[tuple[IPv4Network, IPv4Address]] = set()

    # Connected networks contain a tuple of connected network and IP of local interface
    # Routes contain a tuple of routed network and gateway IP

    # Always add loopback network
    connected_nets.add((IPv4Network('127.0.0.0/8'), IPv4Address('127.0.0.1')))
    routes: View = ndb.routes  # ty:ignore[unresolved-attribute] ; dynamic member
    for route in routes.dump().filter(family=AF_INET, table=RT_MAIN_TABLE):
        if route.gateway is not None:
            gateway = IPv4Address(route.gateway)
            if route.dst == '' and route.dst_len == 0:
                default_gw = gateway
            else:
                system_routes.add((IPv4Network(route.dst + '/' + str(route.dst_len)), gateway))
        elif route.proto == RT_PROTO_KERNEL:
            connected_nets.add(
                (IPv4Network(route.dst + '/' + str(route.dst_len)), IPv4Address(route.prefsrc))
            )

    route_data: RouteData = (connected_nets, system_routes, default_gw)
    _route_cache = route_data
    return route_data


def resolve_local_ip(remote_ip: IPv4Address) -> IPv4Address:
    connected_nets, routes, default_gw = get_local_ip_routes()

    local_ip: IPv4Address | None = next(
        (net[1] for net in connected_nets if remote_ip in net[0]), None
    )
    if not local_ip:
        gateway: IPv4Address | None = next((net[1] for net in routes if remote_ip in net[0]), None)
        if not gateway:
            gateway = default_gw
        if gateway:
            local_ip = next((net[1] for net in connected_nets if gateway in net[0]), None)
        if not local_ip:
            local_ip = IPv4Address('0.0.0.0')

    return local_ip


def get_duplicates(item_list: list[T]) -> set[T]:
    seen: set[T] = set()
    dupes: set[T] = set()

    for item in item_list:
        if item not in seen:
            seen.add(item)
        else:
            dupes.add(item)

    return dupes


def run_cmd(command: list[str], timeout: float | None = None) -> CompletedProcess[str]:
    try:
        return run(
            args=command,
            capture_output=True,
            check=True,
            text=True,
            encoding='utf-8',
            errors='replace',
            timeout=timeout,
        )
    except CalledProcessError as e:
        msg: str
        if e.stderr:
            msg = str(e.stderr).strip()
        elif e.stdout:
            msg = str(e.stdout).strip()
        else:
            msg = '(no output captured)'
        raise RuntimeError(f'Command failed (code {e.returncode}): {msg}') from e
    except FileNotFoundError as e:
        raise RuntimeError('Command not found') from e
    except PermissionError as e:
        raise RuntimeError('Permission denied') from e
    except Exception as e:
        raise RuntimeError(f'Unexpected error: {str(e)}') from e


def is_phone_number(phone_num: str) -> bool:
    if phone_num.startswith('+'):
        match: re.Match[str] | None = E164_RE.match(phone_num)
    else:
        match: re.Match[str] | None = PHONE_RE.match(phone_num)
    return match is not None


def str_to_bool(value: str) -> bool:
    value_lower: str = value.lower()
    if value_lower == 'true':
        return True
    if value_lower == 'false':
        return False
    raise ValueError(f'Invalid boolean value "{value}"')


def to_float(value: str | int | float) -> float | None:
    try:
        return float(value)
    except (ValueError, TypeError):
        pass
    return None


def to_int(value: str | int | float) -> int | None:
    try:
        return int(value)
    except (ValueError, TypeError):
        pass
    return None


def coerce_int(value: str | int | float) -> int:
    try:
        return int(value)
    except (ValueError, TypeError):
        pass
    return 0


def split_with_grouping(
    string: str,
    delimiter: str = ' ',
    group_start: str = '"\'',
    group_end: str = '"\'',
    keep_empty: bool = False,
) -> list[str]:
    if len(group_start) != len(group_end):
        raise ValueError('Group start and group end sequences must be of same length.')

    escape: str = '\\'
    parts: list[str] = []
    cur: str = ''
    in_group: int = -1
    escaped: bool = False
    for char in string:
        if escaped:
            escaped = False
            cur += char
        elif char == escape:
            escaped = True
        elif in_group < 0 and char == delimiter:
            if cur or keep_empty:
                parts.append(cur)
                cur = ''
        else:
            if in_group < 0:
                in_group = group_start.find(char)
            elif char == group_end[in_group]:
                in_group = -1
            cur += char
    if in_group > -1:
        raise ValueError(f'Unmatched {group_start[in_group]} character.')
    if cur or keep_empty:
        parts.append(cur)
    return parts


def caller_id_name(caller_id: str) -> str:
    if not caller_id:
        return ''
    if caller_id == '<unknown>':
        # If caller ID is not set, Asterisk sets it to '<unknown>', for whatever reason
        return ''

    parts: list[str] = caller_id.split('<', maxsplit=1)
    if len(parts) == 1:
        return caller_id  # Not in 'name <number>' format, return as-is
    name: str = parts[0].strip('" ')
    if name:
        return name  # return name if available
    return parts[1].rstrip('> ')  # Return number if name is not available


def add_anchors(regex: str) -> str:
    if not regex:
        return regex
    start_anchor: bool = regex.startswith('^')
    end_anchor: bool = regex.endswith('$')
    if not start_anchor and not end_anchor:
        return '^' + regex + '$'
    if not start_anchor:
        return '^' + regex
    if not end_anchor:
        return regex + '$'
    return regex
