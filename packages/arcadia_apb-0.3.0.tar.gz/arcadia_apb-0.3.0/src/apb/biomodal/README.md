# biomodal

This subpackage offloads GPU-heavy compute to [Modal](https://modal.com), a serverless GPU platform we use. Any work that benefits from on-demand GPU access belongs here.

## Getting set up

Install the optional `modal` dependencies:

```bash
uv sync --extra modal
# or, if installing via pip:
pip install arcadia-apb[modal]
```

You'll also need access to Arcadia's Modal workspace. If you don't have it, post in the `#software` Slack channel to get an invite.

Once you have access, authenticate with:

```bash
modal setup
```

This writes a `~/.modal.toml` file that the CLI commands check for before running anything.

## What's here

- **`esm2/`** — Runs Meta's ESM2 protein language model on Modal GPUs. Supports embedding extraction and pseudo-perplexity calculation across all ESM2 model sizes (8M to 15B parameters). Exposed via the `apb-esm` CLI.
