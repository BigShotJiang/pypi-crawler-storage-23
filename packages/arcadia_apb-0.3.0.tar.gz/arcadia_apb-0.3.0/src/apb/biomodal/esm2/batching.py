def create_length_batched_sequences(
    sequences: dict[str, str],
    batch_size: int,
) -> tuple[list[list[str]], list[list[int]]]:
    """Creates batches of sequences sorted by length while tracking original order.

    Args:
        sequences: Dictionary of sequences to batch
        batch_size: Maximum number of sequences per batch

    Returns:
        Tuple of (sequence batches, index batches) where index batches track
        the original position of each sequence
    """
    indexed_sequences = list(enumerate(sequences.values()))

    indexed_sequences.sort(key=lambda x: len(x[1]), reverse=True)

    sequence_batches = []
    indexed_batches = []
    for idx in range(0, len(indexed_sequences), batch_size):
        batch_items = indexed_sequences[idx : idx + batch_size]
        indices, seqs = zip(*batch_items, strict=False)
        sequence_batches.append(list(seqs))
        indexed_batches.append(list(indices))

    return sequence_batches, indexed_batches
