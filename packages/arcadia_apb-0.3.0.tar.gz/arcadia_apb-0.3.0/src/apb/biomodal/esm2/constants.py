import modal
from modal import Image
from rich.console import Console

MINUTES: int = 60
HOURS: int = MINUTES * 60

APP_NAME: str = "esm2"
CACHING_APP_NAME: str = "download-and-cache-models"
MODEL_STORAGE_PATH: str = "/vol"
MAX_SEQ_LENGTH: int = 1022

console: Console = Console()
volume: modal.Volume = modal.Volume.from_name("model-cache", create_if_missing=True)


image: modal.Image = (
    Image.debian_slim(python_version="3.12")
    .apt_install("libpq-dev")
    .pip_install(
        "transformers==5.2.0",
        "torch==2.5.1",
        "pyyaml==6.0.3",
        "biotite==1.6.0",
        "rich==14.3.3",
        "pandas==2.3.1",
        "typer==0.15.4",
        "huggingface_hub==1.4.1",
    )
    .add_local_python_source(
        "apb",
        copy=True,
    )
)
