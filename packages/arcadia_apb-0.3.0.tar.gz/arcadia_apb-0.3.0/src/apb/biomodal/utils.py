from pathlib import Path

MODAL_ORG = "arcadia-science"
MODAL_TOML_PATH = Path.home() / ".modal.toml"


class ModalConfigError(Exception):
    pass


def validate_modal() -> None:
    if not MODAL_TOML_PATH.exists():
        raise ModalConfigError(f"{MODAL_TOML_PATH} not found.")

    with MODAL_TOML_PATH.open("r") as fp:
        for line in fp:
            if line.strip() == f"[{MODAL_ORG}]":
                break
        else:
            raise ModalConfigError(
                f"[{MODAL_ORG}] header expected (but not found) in {MODAL_TOML_PATH}."
            )
