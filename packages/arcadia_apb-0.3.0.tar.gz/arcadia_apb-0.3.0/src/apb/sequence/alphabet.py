import pandas as pd
from biotite.sequence.alphabet import LetterAlphabet
from biotite.sequence.seqtypes import ProteinSequence

amino_acids: tuple[str, ...] = (
    "A",
    "C",
    "D",
    "E",
    "F",
    "G",
    "H",
    "I",
    "K",
    "L",
    "M",
    "N",
    "P",
    "Q",
    "R",
    "S",
    "T",
    "V",
    "W",
    "Y",
)

amino_acids_gapped: tuple[str, ...] = tuple(list(amino_acids) + ["-"])


class CanonicalProteinSequence(ProteinSequence):
    alphabet = LetterAlphabet(amino_acids)


# The 20 canonical amino acids.
aa_dtype = pd.CategoricalDtype(categories=amino_acids)

# The 20 canonical amino acids and the gap character.
aa_gapped_dtype = pd.CategoricalDtype(categories=amino_acids_gapped)
