from geonames_tagger.tagger import Location, tag_locations

__version__ = "1.0.2"

__all__ = ["tag_locations", "Location"]
