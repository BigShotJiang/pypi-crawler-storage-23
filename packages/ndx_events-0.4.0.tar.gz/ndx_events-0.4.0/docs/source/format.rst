
.. _ndx-events:

**********
ndx-events
**********

Version |release| |today|

.. .. contents::

.. include:: _format_auto_docs/format_spec_main.inc
