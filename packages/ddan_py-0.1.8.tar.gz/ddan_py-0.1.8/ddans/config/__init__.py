"""Configuration module"""

from . import config
from . import id
from . import locale
from . import time

__all__ = [
    "config",
    "id",
    "locale",
    "time",
]
