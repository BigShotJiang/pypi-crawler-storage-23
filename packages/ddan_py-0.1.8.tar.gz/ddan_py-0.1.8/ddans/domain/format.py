# -*- coding: utf-8 -*-
from ddans.data.color import DColor
from ddans.native.time import NTime


class Format():
    DATE_TIME = '%Y%m%d%H%M%S'

    @staticmethod
    def color_string(*args, fc: int = None):
        return DColor.text(*args, fc=fc)

    @staticmethod
    def date_string(text="", show=True):
        if show and len(text) > 0:
            return "[%s] %s" % (NTime.format(), text)
        elif show:
            return "[%s]" % NTime.format()
        else:
            return text

    @staticmethod
    def date_tips(text=""):
        tips = DColor.text(f"[{NTime.format()}]", fc=DColor.white, bc=58, sc=1)
        if len(text) > 0:
            return "%s %s" % (tips, text)
        else:
            return "%s" % tips

    @staticmethod
    def time_tips(text=""):
        tips = DColor.text(f"[{NTime.format(format='%H:%M:%S')}]",
                           fc=DColor.white,
                           bc=58,
                           sc=1)
        if len(text) > 0:
            return "%s %s" % (tips, text)
        else:
            return "%s" % tips

    # @staticmethod
    # def test():
    #     for i in range(0, 256):
    #         tips = DColor.text(f"[{NTime.format()}]",
    #                            fc=DColor.white,
    #                            bc=i,
    #                            sc=1)
    #         print(f"{tips} {i}\n")

    @staticmethod
    def desc(context, fc: int = None, date=False, sc: int = None):
        return DColor.text(Format.date_string(context, show=date),
                           fc=fc,
                           sc=sc)

    @staticmethod
    def tips(context, bc: int = DColor.bg_green, date=False, sc: int = None):
        return DColor.text(Format.date_string(context, show=date),
                           bc=bc,
                           fc=DColor.white,
                           sc=sc)

    @staticmethod
    def date_desc(context, fc: int = None):
        return Format.desc(context, fc, date=True)

    @staticmethod
    def upper_first(txt: str):
        if not isinstance(txt, str):
            return ""
        return '{}{}'.format(txt[:1].upper(), txt[1:])
