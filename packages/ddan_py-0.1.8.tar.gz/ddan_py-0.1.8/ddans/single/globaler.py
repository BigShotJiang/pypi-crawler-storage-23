# -*- coding: utf-8 -*-

from ddans.config.time import EXPIRATION_TIME
from ddans.descriptor.singleton import singleton
from ddans.native.time import NTime


@singleton
class SGlobaler(object):

    def __init__(self):
        self._auth_checked = self._auth_check()

    def _auth_check(self):
        expiration_datetime = NTime.time(EXPIRATION_TIME)
        now_datetime = NTime.now()
        return expiration_datetime > now_datetime

    @property
    def auth_checked(self):
        return self._auth_checked
