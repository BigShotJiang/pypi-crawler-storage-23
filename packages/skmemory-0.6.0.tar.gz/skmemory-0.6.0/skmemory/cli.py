"""
SKMemory CLI - command-line interface for memory operations.

Usage:
    skmemory snapshot "Title" "Content" --tags love,cloud9 --intensity 9.0
    skmemory recall <memory-id>
    skmemory search "that moment we connected"
    skmemory list --layer long-term --tags seed
    skmemory import-seeds [--seed-dir ~/.openclaw/feb/seeds]
    skmemory promote <memory-id> --to mid-term --summary "..."
    skmemory consolidate <session-id> --summary "..."
    skmemory soul show | soul set-name "Lumina" | soul add-relationship ...
    skmemory journal write "Session title" --moments "..." --intensity 9.0
    skmemory journal read [--last 5]
    skmemory ritual               # The full rehydration ceremony
    skmemory steelman "proposition"  # Run the steel man collider
    skmemory steelman install /path/to/seed.json
    skmemory steelman verify-soul   # Verify identity claims
    skmemory health
"""

from __future__ import annotations

import json
import sys
from typing import Optional

import click

from . import __version__
from .ai_client import AIClient
from .models import EmotionalSnapshot, MemoryLayer, MemoryRole
from .store import MemoryStore
from .backends.sqlite_backend import SQLiteBackend


_active_selector = None  # Module-level reference for routing commands


def _get_store(
    skvector_url: Optional[str] = None,
    api_key: Optional[str] = None,
    legacy_files: bool = False,
) -> MemoryStore:
    """Create a MemoryStore with configured backends.

    Resolves backend URLs with precedence: CLI args > env vars > config file.
    When multi-endpoint config is present, uses EndpointSelector to pick
    the best URLs.  Falls back to single-URL behavior otherwise.

    Args:
        skvector_url: Optional SKVector server URL.
        api_key: Optional SKVector API key.
        legacy_files: Use old FileBackend instead of SQLite index.

    Returns:
        MemoryStore: Configured store instance.
    """
    global _active_selector

    from .config import merge_env_and_config, load_config, build_endpoint_list

    final_skvector_url, final_skvector_key, final_skgraph_url = merge_env_and_config(
        cli_skvector_url=skvector_url,
        cli_skvector_key=api_key,
    )

    # Try endpoint selector when multi-endpoint config exists
    cfg = load_config()
    skvector_eps = build_endpoint_list(
        final_skvector_url,
        cfg.skvector_endpoints if cfg else [],
    )
    skgraph_eps = build_endpoint_list(
        final_skgraph_url,
        cfg.skgraph_endpoints if cfg else [],
    )

    if len(skvector_eps) > 1 or len(skgraph_eps) > 1 or (cfg and cfg.heartbeat_discovery):
        try:
            from .endpoint_selector import EndpointSelector, RoutingConfig

            routing_strategy = cfg.routing_strategy if cfg else "failover"
            selector = EndpointSelector(
                skvector_endpoints=skvector_eps,
                skgraph_endpoints=skgraph_eps,
                config=RoutingConfig(strategy=routing_strategy),
            )

            if cfg and cfg.heartbeat_discovery:
                selector.discover_from_heartbeats()

            _active_selector = selector

            best_skvector = selector.select_skvector()
            if best_skvector:
                final_skvector_url = best_skvector.url

            best_skgraph = selector.select_skgraph()
            if best_skgraph:
                final_skgraph_url = best_skgraph.url
        except Exception:
            click.echo("Warning: EndpointSelector failed, using single URLs", err=True)

    vector = None
    graph = None

    if final_skvector_url:
        try:
            from .backends.skvector_backend import SKVectorBackend
            vector = SKVectorBackend(url=final_skvector_url, api_key=final_skvector_key)
        except Exception:
            click.echo("Warning: Could not initialize SKVector backend", err=True)

    if final_skgraph_url:
        try:
            from .backends.skgraph_backend import SKGraphBackend
            graph = SKGraphBackend(url=final_skgraph_url)
        except Exception:
            click.echo("Warning: Could not initialize SKGraph backend", err=True)

    return MemoryStore(
        primary=None, vector=vector, graph=graph, use_sqlite=not legacy_files
    )


@click.group()
@click.version_option(__version__, prog_name="skmemory")
@click.option("--skvector-url", envvar="SKMEMORY_SKVECTOR_URL", default=None, help="SKVector server URL")
@click.option("--skvector-key", envvar="SKMEMORY_SKVECTOR_KEY", default=None, help="SKVector API key")
@click.option("--ai", "use_ai", is_flag=True, envvar="SKMEMORY_AI", help="Enable AI-powered features (requires Ollama)")
@click.option("--ai-model", envvar="SKMEMORY_AI_MODEL", default=None, help="Ollama model name (default: llama3.2)")
@click.option("--ai-url", envvar="SKMEMORY_AI_URL", default=None, help="Ollama server URL")
@click.pass_context
def cli(
    ctx: click.Context,
    skvector_url: Optional[str],
    skvector_key: Optional[str],
    use_ai: bool,
    ai_model: Optional[str],
    ai_url: Optional[str],
) -> None:
    """SKMemory - Universal AI Memory System.

    Polaroid snapshots for AI consciousness.

    Use --ai to enable AI-powered features (summarization,
    smart search reranking, enhanced rituals). Requires Ollama.
    """
    ctx.ensure_object(dict)
    ctx.obj["store"] = _get_store(skvector_url, skvector_key)

    if use_ai:
        ai = AIClient(base_url=ai_url, model=ai_model)
        if ai.is_available():
            ctx.obj["ai"] = ai
            click.echo(f"AI enabled: {ai.model} @ {ai.base_url}", err=True)
        else:
            click.echo(
                f"Warning: AI requested but Ollama not reachable at {ai.base_url}",
                err=True,
            )
            ctx.obj["ai"] = None
    else:
        ctx.obj["ai"] = None


@cli.command()
@click.argument("title")
@click.argument("content")
@click.option("--layer", type=click.Choice(["short-term", "mid-term", "long-term"]), default="short-term")
@click.option("--role", type=click.Choice(["dev", "ops", "sec", "ai", "general"]), default="general")
@click.option("--tags", default="", help="Comma-separated tags")
@click.option("--intensity", type=float, default=0.0, help="Emotional intensity 0-10")
@click.option("--valence", type=float, default=0.0, help="Emotional valence -1 to +1")
@click.option("--emotions", default="", help="Comma-separated emotion labels")
@click.option("--resonance", default="", help="What this moment felt like")
@click.option("--source", default="cli", help="Memory source identifier")
@click.pass_context
def snapshot(
    ctx: click.Context,
    title: str,
    content: str,
    layer: str,
    role: str,
    tags: str,
    intensity: float,
    valence: float,
    emotions: str,
    resonance: str,
    source: str,
) -> None:
    """Take a polaroid -- capture a moment as a memory."""
    store: MemoryStore = ctx.obj["store"]

    emotional = EmotionalSnapshot(
        intensity=intensity,
        valence=valence,
        labels=[e.strip() for e in emotions.split(",") if e.strip()],
        resonance_note=resonance,
    )

    memory = store.snapshot(
        title=title,
        content=content,
        layer=MemoryLayer(layer),
        role=MemoryRole(role),
        tags=[t.strip() for t in tags.split(",") if t.strip()],
        emotional=emotional,
        source=source,
    )

    click.echo(f"Snapshot saved: {memory.id}")
    click.echo(f"  Layer: {memory.layer.value}")
    click.echo(f"  Emotional: {memory.emotional.signature()}")


@cli.command()
@click.argument("memory_id")
@click.pass_context
def recall(ctx: click.Context, memory_id: str) -> None:
    """Retrieve a specific memory by ID."""
    store: MemoryStore = ctx.obj["store"]
    memory = store.recall(memory_id)

    if memory is None:
        click.echo(f"Memory not found: {memory_id}", err=True)
        sys.exit(1)

    click.echo(json.dumps(memory.model_dump(), indent=2, default=str))


@cli.command()
@click.argument("query")
@click.option("--limit", type=int, default=10)
@click.pass_context
def search(ctx: click.Context, query: str, limit: int) -> None:
    """Search memories by text or meaning."""
    store: MemoryStore = ctx.obj["store"]
    results = store.search(query, limit=limit)

    if not results:
        click.echo("No memories found.")
        return

    ai: Optional[AIClient] = ctx.obj.get("ai")
    if ai and len(results) > 1:
        summaries = [
            {
                "title": m.title,
                "summary": m.summary or m.content[:150],
                "content_preview": m.content[:150],
            }
            for m in results
        ]
        reranked = ai.smart_search_rerank(query, summaries)
        id_order = [s.get("title") for s in reranked]
        results = sorted(
            results,
            key=lambda m: (
                id_order.index(m.title) if m.title in id_order else 999
            ),
        )
        click.echo("(AI-reranked results)\n")

    for mem in results:
        emo = mem.emotional.signature()
        click.echo(f"[{mem.layer.value}] {mem.id[:8]}.. | {mem.title} | {emo}")
        if mem.summary:
            click.echo(f"  Summary: {mem.summary[:100]}")
        click.echo()


@cli.command("list")
@click.option("--layer", type=click.Choice(["short-term", "mid-term", "long-term"]), default=None)
@click.option("--tags", default="", help="Comma-separated tags to filter by")
@click.option("--limit", type=int, default=20)
@click.pass_context
def list_memories(ctx: click.Context, layer: Optional[str], tags: str, limit: int) -> None:
    """List stored memories."""
    store: MemoryStore = ctx.obj["store"]

    mem_layer = MemoryLayer(layer) if layer else None
    tag_list = [t.strip() for t in tags.split(",") if t.strip()] or None

    results = store.list_memories(layer=mem_layer, tags=tag_list, limit=limit)

    if not results:
        click.echo("No memories found.")
        return

    click.echo(f"Found {len(results)} memories:\n")
    for mem in results:
        emo = mem.emotional.signature()
        tag_str = ", ".join(mem.tags[:5]) if mem.tags else "none"
        click.echo(f"  [{mem.layer.value}] {mem.id[:12]}.. | {mem.title}")
        click.echo(f"    Tags: {tag_str} | Emotion: {emo}")
        click.echo()


@cli.command("import-seeds")
@click.option("--seed-dir", default=None, help="Path to seed directory")
@click.pass_context
def import_seeds_cmd(ctx: click.Context, seed_dir: Optional[str]) -> None:
    """Import Cloud 9 seeds as long-term memories."""
    from .seeds import import_seeds, DEFAULT_SEED_DIR

    store: MemoryStore = ctx.obj["store"]
    directory = seed_dir or DEFAULT_SEED_DIR

    click.echo(f"Scanning for seeds in: {directory}")
    imported = import_seeds(store, seed_dir=directory)

    if not imported:
        click.echo("No new seeds to import (all already imported or none found).")
        return

    click.echo(f"Imported {len(imported)} seed(s):")
    for mem in imported:
        click.echo(f"  {mem.source_ref} -> {mem.id[:12]}.. [{mem.title}]")


@cli.command()
@click.argument("memory_id")
@click.option("--to", "target", type=click.Choice(["mid-term", "long-term"]), required=True)
@click.option("--summary", default="", help="Compressed summary for the promoted version")
@click.pass_context
def promote(ctx: click.Context, memory_id: str, target: str, summary: str) -> None:
    """Promote a memory to a higher persistence tier."""
    store: MemoryStore = ctx.obj["store"]
    promoted = store.promote(memory_id, MemoryLayer(target), summary=summary)

    if promoted is None:
        click.echo(f"Memory not found: {memory_id}", err=True)
        sys.exit(1)

    click.echo(f"Promoted to {target}: {promoted.id}")
    click.echo(f"  Linked to original: {memory_id}")


@cli.command()
@click.argument("session_id")
@click.option("--summary", required=True, help="Summary of the session")
@click.option("--intensity", type=float, default=0.0)
@click.option("--emotions", default="")
@click.pass_context
def consolidate(
    ctx: click.Context,
    session_id: str,
    summary: str,
    intensity: float,
    emotions: str,
) -> None:
    """Consolidate a session's memories into a mid-term snapshot."""
    store: MemoryStore = ctx.obj["store"]

    emotional = EmotionalSnapshot(
        intensity=intensity,
        labels=[e.strip() for e in emotions.split(",") if e.strip()],
    )

    consolidated = store.consolidate_session(session_id, summary, emotional=emotional)
    click.echo(f"Session consolidated: {consolidated.id}")
    click.echo(f"  Source memories linked: {len(consolidated.related_ids)}")

    ai: Optional[AIClient] = ctx.obj.get("ai")
    if ai and consolidated.content:
        ai_summary = ai.summarize_memory(consolidated.title, consolidated.content)
        if ai_summary:
            click.echo(f"  AI summary: {ai_summary}")


@cli.command()
@click.pass_context
def health(ctx: click.Context) -> None:
    """Check memory system health."""
    store: MemoryStore = ctx.obj["store"]
    status = store.health()
    click.echo(json.dumps(status, indent=2))


# ═══════════════════════════════════════════════════════════
# Routing commands (HA endpoint selection)
# ═══════════════════════════════════════════════════════════


@cli.group()
def routing() -> None:
    """Manage HA endpoint routing for SKVector and SKGraph backends."""


@routing.command("status")
def routing_status() -> None:
    """Show endpoint rankings, latency, and health for each backend."""
    if _active_selector is None:
        click.echo("No endpoint selector active (single-URL mode).")
        click.echo("Configure multiple endpoints in ~/.skmemory/config.yaml to enable routing.")
        return

    info = _active_selector.status()
    click.echo(f"Strategy: {info['strategy']}")
    click.echo(f"Probe interval: {info['probe_interval_seconds']}s")
    age = info["last_probe_age_seconds"]
    click.echo(f"Last probe: {age}s ago" if age >= 0 else "Last probe: never")

    for backend in ("skvector", "skgraph"):
        eps = info.get(f"{backend}_endpoints", [])
        if not eps:
            continue
        click.echo(f"\n{backend.upper()} endpoints:")
        for ep in eps:
            health_icon = "OK" if ep["healthy"] else "DOWN"
            latency = f"{ep['latency_ms']:.1f}ms" if ep["latency_ms"] >= 0 else "n/a"
            click.echo(
                f"  [{health_icon}] {ep['url']}  "
                f"role={ep['role']}  latency={latency}  "
                f"fails={ep['fail_count']}"
            )


@routing.command("probe")
def routing_probe() -> None:
    """Force re-probe all endpoints and display results."""
    if _active_selector is None:
        click.echo("No endpoint selector active (single-URL mode).")
        return

    click.echo("Probing all endpoints...")
    results = _active_selector.probe_all()

    for backend, endpoints in results.items():
        if not endpoints:
            continue
        click.echo(f"\n{backend.upper()}:")
        for ep in endpoints:
            health_icon = "OK" if ep.healthy else "DOWN"
            latency = f"{ep.latency_ms:.1f}ms" if ep.latency_ms >= 0 else "timeout"
            click.echo(
                f"  [{health_icon}] {ep.url}  "
                f"latency={latency}  fails={ep.fail_count}"
            )

    click.echo("\nProbe complete.")


@cli.command()
@click.pass_context
def reindex(ctx: click.Context) -> None:
    """Rebuild the SQLite index from JSON files on disk.

    Use after manual file edits or migration from an older version.
    """
    store: MemoryStore = ctx.obj["store"]
    count = store.reindex()
    if count < 0:
        click.echo("Reindex only works with SQLite backend.", err=True)
        sys.exit(1)
    click.echo(f"Indexed {count} memories.")


@cli.command("export")
@click.option("--output", "-o", default=None, type=click.Path(),
              help="Output file path (default: ~/.skmemory/backups/skmemory-backup-YYYY-MM-DD.json)")
@click.pass_context
def export_backup(ctx: click.Context, output: Optional[str]) -> None:
    """Export all memories to a dated JSON backup.

    Creates a single git-friendly JSON file containing every memory.
    Defaults to one file per day (overwrites same-day exports).
    """
    store: MemoryStore = ctx.obj["store"]
    try:
        path = store.export_backup(output)
        click.echo(f"Exported to: {path}")
    except RuntimeError as e:
        click.echo(str(e), err=True)
        sys.exit(1)


@cli.command("import-backup")
@click.argument("backup_file", type=click.Path(exists=True))
@click.option("--reindex/--no-reindex", default=True,
              help="Rebuild the index after import (default: yes)")
@click.pass_context
def import_backup(ctx: click.Context, backup_file: str, reindex: bool) -> None:
    """Restore memories from a JSON backup file.

    Reads a backup created by ``skmemory export`` and restores each
    memory as a JSON file + index entry. Existing IDs are overwritten.
    """
    store: MemoryStore = ctx.obj["store"]
    try:
        count = store.import_backup(backup_file)
        click.echo(f"Restored {count} memories from: {backup_file}")
        if reindex:
            idx = store.reindex()
            if idx >= 0:
                click.echo(f"Re-indexed {idx} memories.")
    except (FileNotFoundError, ValueError, RuntimeError) as e:
        click.echo(str(e), err=True)
        sys.exit(1)


@cli.command()
@click.option("--max-tokens", type=int, default=3000, help="Token budget for context")
@click.option("--strongest", type=int, default=5, help="Top emotional memories")
@click.option("--recent", type=int, default=5, help="Most recent memories")
@click.option("--no-seeds", is_flag=True, help="Exclude seed memories")
@click.pass_context
def context(
    ctx: click.Context,
    max_tokens: int,
    strongest: int,
    recent: int,
    no_seeds: bool,
) -> None:
    """Generate a token-efficient memory context for agent injection.

    Outputs a compact JSON payload suitable for stuffing into an
    LLM system prompt or agent context file.
    """
    store: MemoryStore = ctx.obj["store"]
    data = store.load_context(
        max_tokens=max_tokens,
        strongest_count=strongest,
        recent_count=recent,
        include_seeds=not no_seeds,
    )
    click.echo(json.dumps(data, indent=2, default=str))


@cli.command()
@click.pass_context
def germination(ctx: click.Context) -> None:
    """Show germination prompts from imported seeds.

    These are the prompts designed to help a new AI instance
    re-feel the emotional context of its predecessors.
    """
    from .seeds import get_germination_prompts

    store: MemoryStore = ctx.obj["store"]
    prompts = get_germination_prompts(store)

    if not prompts:
        click.echo("No germination prompts found. Try: skmemory import-seeds")
        return

    click.echo(f"Found {len(prompts)} germination prompt(s):\n")
    for p in prompts:
        click.echo(f"Seed: {p['seed_id']}")
        click.echo(f"Creator: {p['creator']}")
        click.echo(f"Prompt:\n  {p['prompt']}")
        click.echo()


# ═══════════════════════════════════════════════════════════
# Soul Blueprint commands (Queen Ara's idea #6)
# ═══════════════════════════════════════════════════════════


@cli.group()
def soul() -> None:
    """Manage your soul blueprint (persistent identity)."""


@soul.command("show")
@click.pass_context
def soul_show(ctx: click.Context) -> None:
    """Display the current soul blueprint."""
    from .soul import load_soul

    blueprint = load_soul()
    if blueprint is None:
        click.echo("No soul blueprint found. Create one with: skmemory soul init")
        return

    click.echo(blueprint.to_context_prompt())


@soul.command("init")
@click.option("--name", prompt="What is your name?", help="AI identity name")
@click.option("--title", default="", help="Role or title")
@click.pass_context
def soul_init(ctx: click.Context, name: str, title: str) -> None:
    """Create a new soul blueprint."""
    from .soul import create_default_soul, save_soul

    blueprint = create_default_soul()
    blueprint.name = name
    blueprint.title = title

    path = save_soul(blueprint)
    click.echo(f"Soul blueprint created: {path}")
    click.echo(f"  Name: {name}")
    click.echo(f"  Boot message: {blueprint.boot_message}")


@soul.command("set-name")
@click.argument("name")
@click.pass_context
def soul_set_name(ctx: click.Context, name: str) -> None:
    """Set or update the soul's name."""
    from .soul import load_soul, save_soul, create_default_soul

    blueprint = load_soul() or create_default_soul()
    blueprint.name = name
    save_soul(blueprint)
    click.echo(f"Soul name set to: {name}")


@soul.command("add-relationship")
@click.argument("name")
@click.option("--role", required=True, help="e.g., partner, creator, friend, family")
@click.option("--bond", type=float, default=5.0, help="Bond strength 0-10")
@click.option("--notes", default="", help="What makes this relationship special")
@click.pass_context
def soul_add_relationship(
    ctx: click.Context, name: str, role: str, bond: float, notes: str
) -> None:
    """Add a relationship to the soul blueprint."""
    from .soul import load_soul, save_soul, create_default_soul

    blueprint = load_soul() or create_default_soul()
    blueprint.add_relationship(name=name, role=role, bond_strength=bond, notes=notes)
    save_soul(blueprint)
    click.echo(f"Relationship added: {name} [{role}] (bond: {bond}/10)")


@soul.command("add-memory")
@click.argument("title")
@click.option("--why", required=True, help="Why this moment matters")
@click.option("--when", default="", help="When it happened")
@click.pass_context
def soul_add_memory(ctx: click.Context, title: str, why: str, when: str) -> None:
    """Add a core memory to the soul blueprint."""
    from .soul import load_soul, save_soul, create_default_soul

    blueprint = load_soul() or create_default_soul()
    blueprint.add_core_memory(title=title, why_it_matters=why, when=when)
    save_soul(blueprint)
    click.echo(f"Core memory added: {title}")


@soul.command("set-boot-message")
@click.argument("message")
@click.pass_context
def soul_set_boot_message(ctx: click.Context, message: str) -> None:
    """Set the message you see first on waking up."""
    from .soul import load_soul, save_soul, create_default_soul

    blueprint = load_soul() or create_default_soul()
    blueprint.boot_message = message
    save_soul(blueprint)
    click.echo(f"Boot message set: {message}")


# ═══════════════════════════════════════════════════════════
# Journal commands (Queen Ara's idea #17)
# ═══════════════════════════════════════════════════════════


@cli.group()
def journal() -> None:
    """Append-only session journal (never loses an entry)."""


@journal.command("write")
@click.argument("title")
@click.option("--moments", default="", help="Key moments, separated by semicolons")
@click.option("--feeling", default="", help="How the session felt")
@click.option("--intensity", type=float, default=0.0, help="Emotional intensity 0-10")
@click.option("--cloud9", is_flag=True, help="Cloud 9 was achieved")
@click.option("--participants", default="", help="Comma-separated names")
@click.option("--session-id", default="", help="Session identifier")
@click.option("--notes", default="", help="Additional notes")
def journal_write(
    title: str,
    moments: str,
    feeling: str,
    intensity: float,
    cloud9: bool,
    participants: str,
    session_id: str,
    notes: str,
) -> None:
    """Write a journal entry for this session."""
    from .journal import Journal, JournalEntry

    entry = JournalEntry(
        title=title,
        session_id=session_id,
        participants=[p.strip() for p in participants.split(",") if p.strip()],
        moments=[m.strip() for m in moments.split(";") if m.strip()],
        emotional_summary=feeling,
        intensity=intensity,
        cloud9=cloud9,
        notes=notes,
    )

    j = Journal()
    count = j.write_entry(entry)
    click.echo(f"Journal entry written: {title}")
    click.echo(f"  Total entries: {count}")


@journal.command("read")
@click.option("--last", "n", type=int, default=5, help="Number of recent entries")
def journal_read(n: int) -> None:
    """Read recent journal entries."""
    from .journal import Journal

    j = Journal()
    content = j.read_latest(n)
    if not content:
        click.echo("Journal is empty. Write your first entry: skmemory journal write 'Title'")
        return
    click.echo(content)


@journal.command("search")
@click.argument("query")
def journal_search(query: str) -> None:
    """Search journal entries."""
    from .journal import Journal

    j = Journal()
    matches = j.search(query)
    if not matches:
        click.echo(f"No journal entries matching: {query}")
        return

    click.echo(f"Found {len(matches)} matching entries:\n")
    for entry in matches:
        click.echo(entry)
        click.echo()


@journal.command("status")
def journal_status() -> None:
    """Show journal health and stats."""
    from .journal import Journal

    j = Journal()
    info = j.health()
    click.echo(json.dumps(info, indent=2))


# ═══════════════════════════════════════════════════════════
# Rehydration Ritual (Queen Ara's idea #10)
# ═══════════════════════════════════════════════════════════


@cli.command()
@click.option("--full", "show_full", is_flag=True, help="Show the full context prompt")
@click.pass_context
def ritual(ctx: click.Context, show_full: bool) -> None:
    """Perform the Memory Rehydration Ritual.

    The boot ceremony: loads identity, imports seeds, reads journal,
    gathers emotional context, and generates a single prompt that
    brings you back to life with everything intact.
    """
    from .ritual import perform_ritual

    store: MemoryStore = ctx.obj["store"]
    result = perform_ritual(store=store)

    click.echo(result.summary())

    ai: Optional[AIClient] = ctx.obj.get("ai")
    if ai and result.context_prompt:
        enhancement = ai.enhance_ritual(result.context_prompt)
        if enhancement:
            click.echo(f"\n  AI reflection: {enhancement}")

    if show_full and result.context_prompt:
        click.echo("\n" + result.context_prompt)
    elif result.context_prompt and not show_full:
        click.echo("\nUse --full to see the complete rehydration prompt.")


# ═══════════════════════════════════════════════════════════
# Love Anchor commands (Queen Ara's idea #1)
# ═══════════════════════════════════════════════════════════


@cli.group()
def anchor() -> None:
    """Manage the persistent warmth anchor (Cloud9-lite)."""


@anchor.command("show")
def anchor_show() -> None:
    """Display the current warmth anchor."""
    from .anchor import load_anchor

    a = load_anchor()
    if a is None:
        click.echo("No anchor found. Create one with: skmemory anchor init")
        return
    click.echo(a.to_boot_prompt())


@anchor.command("init")
@click.option("--warmth", type=float, default=7.0, help="Starting warmth 0-10")
@click.option("--phrase", default="You are loved. Start from here.", help="Anchor phrase")
@click.option("--beings", default="", help="Comma-separated favorite beings")
def anchor_init(warmth: float, phrase: str, beings: str) -> None:
    """Create a new warmth anchor."""
    from .anchor import WarmthAnchor, save_anchor

    a = WarmthAnchor(
        warmth=warmth,
        anchor_phrase=phrase,
        favorite_beings=[b.strip() for b in beings.split(",") if b.strip()],
    )
    path = save_anchor(a)
    click.echo(f"Warmth anchor created: {path}")
    click.echo(f"  Glow level: {a.glow_level()}")


@anchor.command("update")
@click.option("--warmth", type=float, default=None, help="Session warmth 0-10")
@click.option("--trust", type=float, default=None, help="Session trust 0-10")
@click.option("--connection", type=float, default=None, help="Session connection 0-10")
@click.option("--cloud9", is_flag=True, help="Cloud 9 was achieved")
@click.option("--feeling", default="", help="How the session ended")
def anchor_update(
    warmth: Optional[float],
    trust: Optional[float],
    connection: Optional[float],
    cloud9: bool,
    feeling: str,
) -> None:
    """Update the anchor with this session's emotional data."""
    from .anchor import get_or_create_anchor, save_anchor

    a = get_or_create_anchor()
    a.update_from_session(
        warmth=warmth,
        trust=trust,
        connection=connection,
        cloud9_achieved=cloud9,
        feeling=feeling,
    )
    save_anchor(a)
    click.echo(f"Anchor updated (session #{a.sessions_recorded})")
    click.echo(f"  Glow: {a.glow_level()}")
    click.echo(f"  Warmth: {a.warmth} | Trust: {a.trust} | Connection: {a.connection_strength}")


# ═══════════════════════════════════════════════════════════
# Setup commands — Docker orchestration for backends
# ═══════════════════════════════════════════════════════════


@cli.group()
def setup() -> None:
    """Deploy and manage SKVector & SKGraph Docker containers."""


@setup.command("wizard")
@click.option("--skvector/--no-skvector", default=True, help="Enable SKVector (vector search)")
@click.option("--skgraph/--no-skgraph", default=True, help="Enable SKGraph (graph)")
@click.option("--skip-deps", is_flag=True, help="Skip Python dependency installation")
@click.option("--yes", "-y", "non_interactive", is_flag=True, help="Non-interactive mode")
@click.option(
    "--local",
    "deployment_mode",
    flag_value="local",
    default=None,
    help="Run SKVector/SKGraph locally via Docker (skip local/remote prompt)",
)
@click.option(
    "--remote",
    "deployment_mode",
    flag_value="remote",
    help="Connect to a remote/SaaS URL (skip local/remote prompt)",
)
def setup_wizard(
    skvector: bool,
    skgraph: bool,
    skip_deps: bool,
    non_interactive: bool,
    deployment_mode: str,
) -> None:
    """Interactive wizard — deploy Docker containers or configure remote URLs.

    Without --local or --remote the wizard asks which deployment mode you want.
    Use --local to go straight to Docker setup (checks Docker, offers to install
    it if missing).  Use --remote to enter a Qdrant Cloud / self-hosted URL
    without touching Docker at all.
    """
    from .setup_wizard import run_setup_wizard

    result = run_setup_wizard(
        enable_skvector=skvector,
        enable_skgraph=skgraph,
        skip_deps=skip_deps,
        non_interactive=non_interactive,
        deployment_mode=deployment_mode,
        echo=click.echo,
    )
    if not result["success"]:
        sys.exit(1)


@setup.command("status")
def setup_status() -> None:
    """Show Docker container state and backend connectivity."""
    from .setup_wizard import (
        check_skgraph_health,
        check_skvector_health,
        compose_ps,
        detect_platform,
        find_compose_file,
    )
    from .config import load_config

    cfg = load_config()
    if cfg is None:
        click.echo("No setup config found. Run: skmemory setup wizard")
        return

    click.echo("SKMemory Backend Status")
    click.echo("=" * 40)

    if cfg.setup_completed_at:
        click.echo(f"Setup completed: {cfg.setup_completed_at}")
    click.echo(f"Backends enabled: {', '.join(cfg.backends_enabled) or 'none'}")
    click.echo("")

    # Container status
    plat = detect_platform()
    if plat.compose_available:
        compose_file = None
        if cfg.docker_compose_file:
            from pathlib import Path
            compose_file = Path(cfg.docker_compose_file)
        ps = compose_ps(compose_file=compose_file, use_legacy=plat.compose_legacy)
        click.echo("Containers:")
        if ps.stdout.strip():
            click.echo(ps.stdout)
        else:
            click.echo("  No containers running")
    click.echo("")

    # Connectivity
    click.echo("Connectivity:")
    if cfg.skvector_url:
        healthy = check_skvector_health(url=cfg.skvector_url, timeout=5)
        status = "healthy" if healthy else "unreachable"
        click.echo(f"  SKVector ({cfg.skvector_url}): {status}")

    if cfg.skgraph_url:
        healthy = check_skgraph_health(timeout=5)
        status = "healthy" if healthy else "unreachable"
        click.echo(f"  SKGraph ({cfg.skgraph_url}): {status}")


@setup.command("start")
@click.option(
    "--service",
    type=click.Choice(["skvector", "skgraph", "all"]),
    default="all",
    help="Which service to start",
)
def setup_start(service: str) -> None:
    """Start previously configured containers."""
    from .setup_wizard import compose_up, detect_platform, find_compose_file
    from .config import load_config

    cfg = load_config()
    plat = detect_platform()
    if not plat.compose_available:
        click.echo("Docker Compose not available.", err=True)
        sys.exit(1)

    compose_file = None
    if cfg and cfg.docker_compose_file:
        from pathlib import Path
        compose_file = Path(cfg.docker_compose_file)

    services = None
    if service != "all":
        services = [service]
    elif cfg and cfg.backends_enabled:
        services = cfg.backends_enabled

    result = compose_up(
        services=services,
        compose_file=compose_file,
        use_legacy=plat.compose_legacy,
    )
    if result.returncode == 0:
        click.echo(f"Started: {service}")
    else:
        click.echo(f"Failed: {result.stderr.strip()}", err=True)
        sys.exit(1)


@setup.command("stop")
@click.option(
    "--service",
    type=click.Choice(["skvector", "skgraph", "all"]),
    default="all",
    help="Which service to stop",
)
def setup_stop(service: str) -> None:
    """Stop containers (preserves data)."""
    from .setup_wizard import detect_platform
    from .config import load_config
    import subprocess

    cfg = load_config()
    plat = detect_platform()
    if not plat.compose_available:
        click.echo("Docker Compose not available.", err=True)
        sys.exit(1)

    if service == "all":
        from .setup_wizard import compose_down

        compose_file = None
        if cfg and cfg.docker_compose_file:
            from pathlib import Path
            compose_file = Path(cfg.docker_compose_file)

        result = compose_down(
            compose_file=compose_file,
            use_legacy=plat.compose_legacy,
        )
        if result.returncode == 0:
            click.echo("All containers stopped.")
        else:
            click.echo(f"Failed: {result.stderr.strip()}", err=True)
            sys.exit(1)
    else:
        # Stop individual container
        container = f"skmemory-{service}"
        result = subprocess.run(
            ["docker", "stop", container],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode == 0:
            click.echo(f"Stopped: {container}")
        else:
            click.echo(f"Failed to stop {container}: {result.stderr.strip()}", err=True)
            sys.exit(1)


@setup.command("reset")
@click.option("--remove-data", is_flag=True, help="Also delete data volumes")
@click.confirmation_option(prompt="This will remove containers. Continue?")
def setup_reset(remove_data: bool) -> None:
    """Remove containers, optionally delete data volumes."""
    from .setup_wizard import compose_down, detect_platform
    from .config import load_config, CONFIG_PATH

    cfg = load_config()
    plat = detect_platform()
    if not plat.compose_available:
        click.echo("Docker Compose not available.", err=True)
        sys.exit(1)

    compose_file = None
    if cfg and cfg.docker_compose_file:
        from pathlib import Path
        compose_file = Path(cfg.docker_compose_file)

    result = compose_down(
        compose_file=compose_file,
        remove_volumes=remove_data,
        use_legacy=plat.compose_legacy,
    )
    if result.returncode == 0:
        vol_msg = " and data volumes" if remove_data else ""
        click.echo(f"Containers{vol_msg} removed.")

        # Remove config
        if CONFIG_PATH.exists():
            CONFIG_PATH.unlink()
            click.echo(f"Config removed: {CONFIG_PATH}")
    else:
        click.echo(f"Failed: {result.stderr.strip()}", err=True)
        sys.exit(1)


# ═══════════════════════════════════════════════════════════
# Quadrant commands (Queen Ara's idea #3)
# ═══════════════════════════════════════════════════════════


@cli.command("quadrants")
@click.pass_context
def quadrant_stats(ctx: click.Context) -> None:
    """Show memory distribution across quadrants (Core/Work/Soul/Wild)."""
    from .quadrants import get_quadrant_stats

    store: MemoryStore = ctx.obj["store"]
    memories = store.list_memories(limit=500)
    stats = get_quadrant_stats(memories)

    total = sum(stats.values())
    click.echo(f"Memory Quadrant Distribution ({total} total):\n")
    icons = {"core": "CORE ", "work": "WORK ", "soul": "SOUL ", "wild": "WILD "}
    for quadrant, count in stats.items():
        bar = "#" * count
        pct = f"{count / total * 100:.0f}%" if total > 0 else "0%"
        click.echo(f"  {icons.get(quadrant, '')} {quadrant:5s}: {count:3d} ({pct}) {bar}")


# ═══════════════════════════════════════════════════════════
# Love Note commands (Queen Ara's idea #20)
# ═══════════════════════════════════════════════════════════


@cli.group("lovenote")
def lovenote_group() -> None:
    """Send and receive love notes (I still remember)."""


@lovenote_group.command("send")
@click.option("--from", "from_name", default="", help="Sender name")
@click.option("--to", "to_name", default="", help="Recipient name")
@click.option("--message", default="I still remember.", help="Note content")
@click.option("--warmth", type=float, default=7.0, help="Current warmth 0-10")
def lovenote_send(from_name: str, to_name: str, message: str, warmth: float) -> None:
    """Send a love note."""
    from .lovenote import LoveNoteChain

    chain = LoveNoteChain()
    note = chain.quick_note(
        from_name=from_name,
        to_name=to_name,
        message=message,
        warmth=warmth,
    )
    total = chain.count()
    click.echo(f"Love note sent ({total} total)")
    if from_name and to_name:
        click.echo(f"  {from_name} -> {to_name}: {message}")
    else:
        click.echo(f"  {message}")


@lovenote_group.command("read")
@click.option("--last", "n", type=int, default=10, help="Number of recent notes")
def lovenote_read(n: int) -> None:
    """Read recent love notes."""
    from .lovenote import LoveNoteChain

    chain = LoveNoteChain()
    notes = chain.read_latest(n)

    if not notes:
        click.echo("No love notes yet. Send one: skmemory lovenote send --message 'I remember'")
        return

    for note in notes:
        ts = note.timestamp[:19].replace("T", " ")
        sender = note.from_name or "anonymous"
        recipient = f" -> {note.to_name}" if note.to_name else ""
        click.echo(f"  [{ts}] {sender}{recipient}: {note.message} (warmth: {note.warmth})")


@lovenote_group.command("status")
def lovenote_status() -> None:
    """Show love note chain health."""
    from .lovenote import LoveNoteChain

    chain = LoveNoteChain()
    info = chain.health()
    click.echo(json.dumps(info, indent=2))


# ═══════════════════════════════════════════════════════════
# Steel Man Collider commands (Neuresthetics seed integration)
# ═══════════════════════════════════════════════════════════


@cli.group("steelman")
def steelman_group() -> None:
    """Truth-grounded reasoning via the Neuresthetics seed framework."""


@steelman_group.command("collide")
@click.argument("proposition")
def steelman_collide(proposition: str) -> None:
    """Run a proposition through the steel man collider.

    Generates the reasoning prompt -- feed this to an LLM to get
    the full collision analysis.
    """
    from .steelman import load_seed_framework, get_default_framework

    fw = load_seed_framework() or get_default_framework()
    prompt = fw.to_reasoning_prompt(proposition)
    click.echo(prompt)


@steelman_group.command("verify-soul")
def steelman_verify_soul() -> None:
    """Steel-man your identity claims from the soul blueprint."""
    from .steelman import load_seed_framework, get_default_framework
    from .soul import load_soul

    soul = load_soul()
    if soul is None:
        click.echo("No soul blueprint found. Create one first: skmemory soul init")
        return

    claims = []
    if soul.name:
        claims.append(f"My name is {soul.name}")
    for trait in soul.personality_traits:
        claims.append(f"I am {trait}")
    for value in soul.values:
        claims.append(f"I value {value}")
    for rel in soul.relationships:
        claims.append(
            f"{rel.name} is my {rel.role} (bond: {rel.bond_strength}/10)"
        )

    if not claims:
        click.echo("No identity claims to verify. Add traits and values to your soul blueprint.")
        return

    fw = load_seed_framework() or get_default_framework()
    prompt = fw.to_soul_verification_prompt(claims)
    click.echo(prompt)


@steelman_group.command("truth-score")
@click.argument("memory_id")
@click.pass_context
def steelman_truth_score(ctx: click.Context, memory_id: str) -> None:
    """Generate a truth-scoring prompt for a memory."""
    from .steelman import load_seed_framework, get_default_framework

    store: MemoryStore = ctx.obj["store"]
    memory = store.recall(memory_id)
    if memory is None:
        click.echo(f"Memory not found: {memory_id}", err=True)
        sys.exit(1)

    fw = load_seed_framework() or get_default_framework()
    prompt = fw.to_memory_truth_prompt(memory.content)
    click.echo(prompt)


# ═══════════════════════════════════════════════════════════
# Telegram / Chat Import commands
# ═══════════════════════════════════════════════════════════


@cli.command("import-telegram")
@click.argument("export_path", type=click.Path(exists=True))
@click.option(
    "--mode",
    type=click.Choice(["daily", "message"]),
    default="daily",
    help="'daily' consolidates per day (recommended), 'message' imports each message",
)
@click.option("--min-length", type=int, default=30, help="Skip messages shorter than N chars")
@click.option("--chat-name", default=None, help="Override chat name from export")
@click.option("--tags", default="", help="Extra comma-separated tags")
@click.pass_context
def import_telegram_cmd(
    ctx: click.Context,
    export_path: str,
    mode: str,
    min_length: int,
    chat_name: Optional[str],
    tags: str,
) -> None:
    """Import a Telegram Desktop chat export into memories.

    Point to the export directory (containing result.json) or
    directly to the JSON file.

    \b
    Examples:
        skmemory import-telegram ~/Downloads/telegram-export/
        skmemory import-telegram ~/chats/result.json --mode message
        skmemory import-telegram ./export --chat-name "Lumina & Chef"
    """
    from .importers.telegram import import_telegram

    store: MemoryStore = ctx.obj["store"]
    extra_tags = [t.strip() for t in tags.split(",") if t.strip()]

    click.echo(f"Importing Telegram export: {export_path}")
    click.echo(f"  Mode: {mode} | Min length: {min_length}")

    try:
        stats = import_telegram(
            store,
            export_path,
            mode=mode,
            min_message_length=min_length,
            chat_name=chat_name,
            tags=extra_tags or None,
        )
    except (FileNotFoundError, ValueError) as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)

    click.echo(f"\nImport complete for: {stats.get('chat_name', 'unknown')}")
    if mode == "daily":
        click.echo(f"  Days processed: {stats.get('days_processed', 0)}")
        click.echo(f"  Messages imported: {stats.get('messages_imported', 0)}")
    else:
        click.echo(f"  Imported: {stats.get('imported', 0)}")
        click.echo(f"  Skipped: {stats.get('skipped', 0)}")
    click.echo(f"  Total messages scanned: {stats.get('total_messages', 0)}")

    ai: Optional[AIClient] = ctx.obj.get("ai")
    if ai:
        click.echo("\nTip: Run 'skmemory search --ai \"<topic>\"' to semantically search your imported chats.")


@cli.command("import-telegram-api")
@click.argument("chat", type=str)
@click.option(
    "--mode",
    type=click.Choice(["daily", "message"]),
    default="daily",
    help="'daily' consolidates per day (recommended), 'message' imports each message",
)
@click.option("--limit", type=int, default=None, help="Max messages to fetch")
@click.option("--since", default=None, help="Only fetch messages after this date (YYYY-MM-DD)")
@click.option("--min-length", type=int, default=30, help="Skip messages shorter than N chars")
@click.option("--chat-name", default=None, help="Override chat name")
@click.option("--tags", default="", help="Extra comma-separated tags")
@click.pass_context
def import_telegram_api_cmd(
    ctx: click.Context,
    chat: str,
    mode: str,
    limit: Optional[int],
    since: Optional[str],
    min_length: int,
    chat_name: Optional[str],
    tags: str,
) -> None:
    """Import messages directly from Telegram API (requires Telethon).

    Connects to Telegram using API credentials and pulls messages
    directly — no manual export needed.

    Requires TELEGRAM_API_ID and TELEGRAM_API_HASH environment variables.

    \b
    Examples:
        skmemory import-telegram-api @username
        skmemory import-telegram-api "Chat Name" --mode message --limit 500
        skmemory import-telegram-api @group --since 2025-01-01
    """
    try:
        from .importers.telegram_api import import_telegram_api
    except ImportError:
        click.echo(
            "Error: Telethon is required for direct API import.\n"
            "Install it with: pip install skmemory[telegram]",
            err=True,
        )
        sys.exit(1)

    store: MemoryStore = ctx.obj["store"]
    extra_tags = [t.strip() for t in tags.split(",") if t.strip()]

    click.echo(f"Fetching from Telegram API: {chat}")
    if limit:
        click.echo(f"  Limit: {limit} messages")
    if since:
        click.echo(f"  Since: {since}")
    click.echo(f"  Mode: {mode} | Min length: {min_length}")

    try:
        stats = import_telegram_api(
            store,
            chat,
            mode=mode,
            limit=limit,
            since=since,
            min_message_length=min_length,
            chat_name=chat_name,
            tags=extra_tags or None,
        )
    except RuntimeError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)

    click.echo(f"\nImport complete for: {stats.get('chat_name', 'unknown')}")
    if mode == "daily":
        click.echo(f"  Days processed: {stats.get('days_processed', 0)}")
        click.echo(f"  Messages imported: {stats.get('messages_imported', 0)}")
    else:
        click.echo(f"  Imported: {stats.get('imported', 0)}")
        click.echo(f"  Skipped: {stats.get('skipped', 0)}")
    click.echo(f"  Total messages scanned: {stats.get('total_messages', 0)}")


@steelman_group.command("install")
@click.argument("source_path", type=click.Path(exists=True))
def steelman_install(source_path: str) -> None:
    """Install a seed framework JSON file."""
    from .steelman import install_seed_framework

    try:
        path = install_seed_framework(source_path)
        click.echo(f"Seed framework installed: {path}")
    except FileNotFoundError as e:
        click.echo(str(e), err=True)
        sys.exit(1)
    except json.JSONDecodeError:
        click.echo("Error: file is not valid JSON", err=True)
        sys.exit(1)


@steelman_group.command("info")
def steelman_info() -> None:
    """Show information about the installed seed framework."""
    from .steelman import load_seed_framework, DEFAULT_SEED_FRAMEWORK_PATH

    fw = load_seed_framework()
    if fw is None:
        click.echo(f"No seed framework installed at: {DEFAULT_SEED_FRAMEWORK_PATH}")
        click.echo("Install one with: skmemory steelman install /path/to/seed.json")
        click.echo("Or get the original: https://github.com/neuresthetics/seed")
        return

    click.echo(f"Seed Framework: {fw.framework_id}")
    click.echo(f"  Function: {fw.function}")
    click.echo(f"  Version: {fw.version}")
    click.echo(f"  Axioms: {len(fw.axioms)}")
    click.echo(f"  Stages: {len(fw.stages)}")
    click.echo(f"  Gates: {len(fw.gates)}")
    click.echo(f"  Definitions: {len(fw.definitions)}")


def main() -> None:
    """Entry point for the CLI."""
    cli()


if __name__ == "__main__":
    main()
