# ruff: noqa: LOG015
from __future__ import annotations

import logging
import re
import sys
from pathlib import Path
from typing import TYPE_CHECKING, Literal

from invoke.tasks import task

if TYPE_CHECKING:
    from collections.abc import Generator

    from invoke.context import Context


REPO_ROOT = Path(__file__).resolve().parent
LIB_ROOT = REPO_ROOT / "src" / "amplify_qaoa"

_BASIC_COPYRIGHT = [
    "# Copyright (c) Fixstars Corporation and Fixstars Amplify Corporation.",
    "#",
    "# This source code is licensed under the Apache2.0 license found in the",
    "# LICENSE file in the root directory of this source tree.",
]

_COPYRIGHTS_FROM_FILE: dict[Path, list[str]] = {}

_MAGIC_COMMENT_RE = re.compile(r"^#.*?coding[:=][ \t]*[-_.a-zA-Z0-9]+", re.IGNORECASE)
_COPYRIGHT_LINE_RE = re.compile(r"^#\s*copyright\b", re.IGNORECASE)
_Status = Literal["inserted", "matched", "incorrect"]


def _get_copyright_content(file: Path) -> list[str]:
    return _COPYRIGHTS_FROM_FILE.get(file, _BASIC_COPYRIGHT)


def _iter_library_python_files() -> Generator[Path]:
    if not LIB_ROOT.exists():
        return

    for path in LIB_ROOT.rglob("*.py"):
        if "__pycache__" in path.parts:
            continue
        if path == REPO_ROOT / "src" / "amplify_qaoa" / "__version__.py":
            continue

        yield path


def _get_insert_position(
    lines: list[str], legal_copyright: list[str] = _BASIC_COPYRIGHT
) -> tuple[int, tuple[_Status, str | None] | None]:
    insert_at = 0
    if lines and lines[0].startswith("#!"):  # shebang
        insert_at = 1
    if len(lines) > insert_at and _MAGIC_COMMENT_RE.match(lines[insert_at]):
        insert_at += 1

    next_content_at = insert_at
    # Skip blank lines after shebang/magic comments
    while len(lines) > insert_at and lines[next_content_at].strip() in ("", "#"):
        next_content_at += 1

    status, detail = _evaluate_existing_copyright_block(lines, next_content_at, legal_copyright)
    if status is not None:
        return -1, (status, detail)

    return insert_at, None


def _extract_leading_comment_block(lines: list[str], insert_at: int) -> list[str]:
    block: list[str] = []
    for line in lines[insert_at:]:
        stripped = line.strip()
        if not stripped.startswith("#"):
            break
        block.append(line.rstrip("\r\n"))
    return block


def _evaluate_existing_copyright_block(
    lines: list[str], insert_at: int, copyright_lines: list[str]
) -> tuple[_Status | None, str | None]:
    block = _extract_leading_comment_block(lines, insert_at)
    if not block:
        return None, None

    if _COPYRIGHT_LINE_RE.match(block[0]) is None:
        return None, None

    if block == copyright_lines:
        return "matched", None

    return "incorrect", block[0]


def _insert_copyright_header(path: Path) -> tuple[_Status, str | None]:
    original = path.read_text(encoding="utf-8")
    lines = original.splitlines(keepends=True)

    legal_copyright = _get_copyright_content(path)
    insert_at, detail = _get_insert_position(lines, legal_copyright)
    if insert_at == -1:
        assert detail is not None
        return detail

    newline = "\r\n" if "\r\n" in original else "\n"
    header = newline.join(legal_copyright) + newline

    prefix = "".join(lines[:insert_at])
    rest = "".join(lines[insert_at:])

    if rest and not rest.startswith(("\n", "\r\n")):
        rest = newline + rest

    updated = prefix + header + rest
    path.write_text(updated, encoding="utf-8")
    return "inserted", None


def _apply_copyright_headers() -> tuple[int, int, list[tuple[Path, str]]]:
    inserted = 0
    matched = 0
    incorrect: list[tuple[Path, str]] = []

    for path in _iter_library_python_files():
        status, detail = _insert_copyright_header(path)
        if status == "inserted":
            inserted += 1
        elif status == "matched":
            matched += 1
        elif status == "incorrect":
            incorrect.append((path, detail or ""))

    return inserted, matched, incorrect


def _print_copyright_summary(inserted: int, matched: int, incorrect: list[tuple[Path, str]]) -> None:
    for path, top_line in incorrect:
        rel_path = path.relative_to(REPO_ROOT)
        logging.warning("Incorrect copyright header found in %s: %s", rel_path, top_line)
    print(f"Copyright summary: inserted={inserted}, matched={matched}, incorrect={len(incorrect)}")


@task(name="copyright")
def apply_copyright(_c: Context) -> None:
    """Ensure required copyright headers in library sources."""
    inserted, matched, incorrect = _apply_copyright_headers()
    _print_copyright_summary(inserted, matched, incorrect)


@task(
    help={
        "copyright": "Ensure all library sources under src/amplify_qaoa have the required copyright header.",
    }
)
def format(c: Context, *, copyright: bool = False) -> None:  # noqa: A001, A002
    """Format and auto-fix the codebase.

    - Runs: `ruff format src` then `ruff check src --fix --extend-ignore ALL --extend-select I001`
    - With `--copyright`: inserts missing headers, checks existing ones, and warns on mismatches.
    """
    if copyright:
        inserted, matched, incorrect = _apply_copyright_headers()
        _print_copyright_summary(inserted, matched, incorrect)
        if incorrect:
            raise RuntimeError("Incorrect copyright headers found. See logs for details.")

    ruff = f"uv run --python {sys.version_info.major}.{sys.version_info.minor} ruff"

    c.run(
        f"{ruff} check --fix --extend-ignore ALL --extend-select I001 src",
        pty=True,
    )
    c.run(f"{ruff} format src", pty=True)
