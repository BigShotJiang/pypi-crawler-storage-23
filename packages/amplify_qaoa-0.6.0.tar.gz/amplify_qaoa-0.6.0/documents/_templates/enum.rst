{{ objname | escape | underline}}

.. currentmodule:: {{ module }}

.. autoclass:: {{ objname }}
   :exclude-members: __new__, __init__

   {% block attributes %}
   {% if attributes %}
   .. rubric:: {{ _('Members') }}

   {% endif %}
   {% endblock %}
