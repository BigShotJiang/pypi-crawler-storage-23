# How to Generate Documents

## Prepare Environment

If the Python environment for this project has not been established, run the following command:

```shell
$ uv sync --group doc
```

Make sure `public/` directory is placed in the root.

## Generate Documents

To generate the documents for this project, run the following command:

```shell
$ uv run sphinx-build -M html documents/ public/ -j auto -n
```

The resulting documents are generated in `public/`.
