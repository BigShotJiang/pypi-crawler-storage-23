---
jupytext:
  text_representation:
    extension: .md
    format_name: myst
    format_version: 4.0.0
    jupytext_version: 1.16.4
kernelspec:
  display_name: Python 3
  language: python
  name: python3
---

(measure)=
# 測定（`measure` 関数）

`measure` 関数は [QAOA の流れ](qaoa_steps) の Step6 に対応した解のサンプリングを行います。

`measure` 関数はサンプリングの結果 `counts` と各ステップにかかった時間を格納したクラス {py:class}`~amplify_qaoa.runners._timing.MeasureTiming` を返します。

## 入力

|     引数     | 説明                                                                                                                                        |
| :----------: | :------------------------------------------------------------------------------------------------------------------------------------------ |
|   `f_dict`   | イジング変数を key とし、係数を value とする辞書                                                                                            |
| `group_list` | 各リストの要素として One-hot 制約を課したい変数のリストを与えます。リストの各要素で与えられた変数のリストのうち、1 つだけが -1 になります。 |
| `init_ones`  | 値を -1 として初期化したい変数のリストを与えます。                                                                                          |
| `parameters` | float のリストでパラメータの値を与えます。`tune` 関数の結果の `opt_params` を用いると、最適化されたパラメータを渡すことができます。         |
| `qaoa_type`  | デフォルトでは `QaoaAnsatzType.Original`                                                                                                    |

## 戻り値

`measure` 関数の戻り値は {py:class}`~amplify_qaoa.runners.MeasureResult` クラスで、以下のプロパティを持ちます。

|       key        | 説明                                                                                                                |
| :--------------: | :------------------------------------------------------------------------------------------------------------------ |
| `measure_timing` | `measure` 関数での測定の各ステップにかかった時間の情報を持つ {py:class}`~amplify_qaoa.runners._timing.MeasureTiming` クラス |
|     `counts`     | `measure` 関数でのサンプリングの結果                                                                                |

### 測定時間に関する情報

`measure` 関数で測定にかかった時間に関する情報は、`measure_time` から取得できる {py:class}`~amplify_qaoa.runners._timing.MeasureTiming` クラスの以下のプロパティから取得できます。

| key             | 説明                               |
| --------------- | ---------------------------------- |
| `total_time`    | `measure` 関数にかかった時間の総計 |
| `runner_timing` | ランナーに依存した時間を扱うクラス |

`QulacsRunner` の場合は、`runner_timing` は以下のプロパティを持ちます。

| key                    | 説明                                                             |
| ---------------------- | ---------------------------------------------------------------- |
| `total_machine_time`   | 量子デバイス（実機 or シミュレーター）によってかかった時間の総計 |
| `total_execution_time` | 量子デバイスが実際に稼働していた時間の総計（待ち時間などを除く） |

`QiskitRunner` の場合は、`runner_timing` は以下のプロパティを持ちます。

| key                    | 説明                                                             |
| ---------------------- | ---------------------------------------------------------------- |
| `total_machine_time`   | 量子デバイス（実機 or シミュレーター）によってかかった時間の総計 |
| `total_execution_time` | 量子デバイスが実際に稼働していた時間の総計（待ち時間などを除く） |
| `qiskit_running_time`  | `measure` 関数のうち、 `qiskit` を呼び出していた時間の総計       |
| `machine_running_time` | 量子デバイスが実際に稼働していた時間の総計（待ち時間などを除く） |

各時間の関係は以下の図のようになります。

![measure_time_taken](figure/measure_time_taken.jpg)

なお、 `QulacsRunner` を用いた場合、 Qulacs は実機を持たないシミュレーターのため、 `total_machine_time` 、 `machine_running_time` を除いた時間の辞書が返って来ます。


```{include} figure/measure_timing.html
```

## `measure` 説明の説明

多くの場合、 `run` 関数の `parameters` には `tune` で得られた $\theta^{\textup{opt}}$ を代入します。
この時、状態 $\ket{\psi(\theta^{\textup{opt}})}$ は最適解を $x^{\textup{opt}}$ として $\ket{x^{\textup{opt}}}$ の良い近似となっていると期待されます。
あるいは、最適解が複数ある場合（ $x^{\textup{opt}}_1, x^{\textup{opt}}_2, \ldots, x^{\textup{opt}}_k$ ）、 $\ket{\psi(\theta^{\textup{opt}})}$ は $\ket{x^{\textup{opt}}}_1, \ldots, \ket{x^{\textup{opt}}}_k$ の何らかの重ね合わせ状態の近似になっていると期待されます。
したがってサンプル数が十分な場合、一番多くサンプルされたビット列 $x^{\ast}$ を解として出力すれば、何れの場合でも高確率で $x^{\ast}$ が最適解になっていると期待されます。

このように、 `tune` 関数でパラメータを Ansatz のパラメータを調整し、得られたパラメータの下で `run` 関数でサンプリングを行う下で、高確率で正確な最適解を得ることができます。

なお、ランナーを構成した直後に `f_dict` のみを与えて `run` を実行することで、パラメータの最適化と最適値の計算を同時に行うこともできます。

また、 `tune` を行うと `f_dict` 、 `result.opt_params` の情報が「ランナー」に保持されます。
そのため直前に `tune` を行っていた場合、引数無しで `run` を実行して最適解を得ることもできます。

## `measure` 関数の実装

`measure` 関数の引数の `parameters` には、何らかのパラメータを渡す必要があるので、例としてまず `tune` 関数でそのパラメータを取得するようにします。

```{code-cell} python
>>> from amplify_qaoa import QulacsRunner

>>> f_dict = {(0, 1): 1.0, (1, 2): 1.0, (0, 3): 1.0, (2, 3): 1.0}

>>> runner = QulacsRunner(reps=10, shots=1000)
>>> tune_result = runner.tune(f_dict=f_dict, optimizer="COBYLA")
```

この `tune_result` から、例として最適化されたパラメータ (`tune_result.opt_params`) を `measure` 関数の `parameters` 荷渡すようにして、観測結果は以下のように得ることができます。

```{code-cell} python
>>> measure_result = runner.measure(f_dict=f_dict, parameters=tune_result.opt_params, group_list=[], init_ones=[])
```

`measure_result` から、観測された解の分布を取得できます。

```{code-cell} python
>>> print(measure_result.counts)
```

`[-1, 1, -1, 1]` と `[1, -1, 1, -1]` の二つの解が同等に多く観測されており、これら二つの解が最適解となります。
