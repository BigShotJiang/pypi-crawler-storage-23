---
jupytext:
  text_representation:
    extension: .md
    format_name: myst
    format_version: 4.0.0
    jupytext_version: 1.16.4
kernelspec:
  display_name: Python 3
  language: python
  name: python3
---

# Amplify QAOA クイックスタート

## 動作環境

Amplify QAOA は次の環境において動作を確認しています。

````{grid} 1 2 2 2
:gutter: 5
:padding: 2 2 5 5
```{grid-item-card}  Python バージョン
* 3.10
* 3.11
* 3.12
* 3.13
```
```{grid-item-card}  サポート OS
* Windows 10/11
* Linux
    * Ubuntu 20.04/22.04, Rocky Linux 8/9
    * x86_64, ARM64

* macOS
    * x86_64 (Monterey 以降)
    * ARM64  (Monterey 以降)
```
````

最初に、お使いの Python のバージョンが上記のリストに含まれることを確認してください。

```bash
$ python3 --version
```

## インストール

Amplify QAOA は [PyPI](https://pypi.org/project/amplify/) からインストールできます。次のコマンドで自身の環境にインストールされます。

```bash
$ python3 -m pip install -U amplify_qaoa
```

Amplify QAOA が正しくインストールされると、次のようにしてバージョンを確認できます。
```{code-cell} python
>>> import amplify_qaoa
>>> amplify_qaoa.__version__
```

```{note}
Fixstars Amplify SDK（以下 Amplify SDK）経由で Qiskit と Qulacs クライアントを使用することで、Amplify QAOA の Qiskit と Qulacs ランナーと同等の操作を行うことができます。Amplify SDK を用いた QAOA の取り扱いの簡単な説明は [](sample_amplify_sdk.md) に記載されています。
Amplify SDK のより詳しい始め方の説明は [Fixstars Amplify クイックスタート](https://amplify.fixstars.com/ja/docs/amplify/v1/quickstart.html) を参照してください。
```

## サンプルコードの実行

Amplify QAOA のインストールが完了したら、簡単な QUBO の問題を解く方法を紹介します。ここではソルバーとして [Qiskit](https://www.ibm.com/quantum/qiskit) を使います。

サンプル問題として次を考えます。

```{card} Sample QUBO Problem
:width: 50%
:margin: 3 3 auto auto
目的関数
:   $$
    \text{minimize:} \quad f = s_0 s_1 + s_0 - s_1 + 3
    $$

決定変数
:   $$
    s_0, s_1 \in \{-1, 1\}
    $$

制約条件
:   $$
    \text{None}
    $$
```

この問題では、$s_0 = -1$, $s_1 = 1$ のときに関数 $f$ は最小値 $f = 0$ となります。この問題を Amplify QAOA で解いて正しい答えが得られるか確認しましょう。

### 1. ハミルトニアンの定義

問題に対応するハミルトニアンを定義します。ハミルトニアンは「キーが変数のインデックスのタプル、バリューをその係数」の辞書として記述します。この問題で **最小化する** ハミルトニアン `f_dict` は次のように書けます。

```{code-cell} python
>>> f_dict = {
...     (0, 1): 1.0,  # 1.0 * s_0 * s_1
...     (0,):  1.0,   # 1.0 * s_0
...     (1,): -1.0,   # -1.0 * s_1
...     ():   3.0,    # 3.0 （定数項）
... }
```

### 2. ランナーの指定

今回はソルバーとして Qiskit を使用するため、これに対応するランナークラス ({py:class}`~amplify_qaoa.runners.QiskitRunner`) を作成します。ランナーのプロパティ {py:attr}`~amplify_qaoa.runners.QiskitRunner.reps` と {py:attr}`~amplify_qaoa.runners.QiskitRunner.shots` で QAOA のパラメータを設定します。パラメータの意味については [](QAOA.md) を参照してください。

```{code-cell} python
>>> from amplify_qaoa import QiskitRunner
>>> runner = QiskitRunner()  # QiskitRunner ランナーを指定
>>> runner.reps = 10         # Ansatz 回路の深さ
>>> runner.shots = 1000      # サンプリング回数
```

### 3. QAOA の実行

QAOA の実行はランナークラスの {py:class}`~amplify_qaoa.runners.QiskitRunner.run` メソッドを用いて行います。この関数はハミルトニアン `f_dict` を引数として受け取り、 QAOA の実行結果を返します。

```{code-cell} python
>>> run_result = runner.run(f_dict)
```

### 4. 結果の確認

実行結果は {py:class}`~amplify_qaoa.runners.RunResult` クラスのインスタンスとして返されます。このインスタンスには回路パラメータの最適化に関する結果や最適パラメータでの解候補のサンプリング結果が含まれます。 {py:attr}`~amplify_qaoa.runners.RunResult.counts` プロパティを呼び出すことで、サンプリングよりどの解候補が何回観測されたかという情報を取得できます。

```{code-cell} python
>>> print(run_result.counts)
```

リストの各要素は「サンプリングされた解候補とその解候補が観測された回数のタプル」となっています。今回の例では 1000 回のサンプリングのうち $(s_0, s_1) = (-1, 1)$ が最も多く観測されており、これが最適解となります。

## 次のステップ

以上が Amplify QAOA を用いた定式化とランナー実行の流れです。ここでは非常に簡単な 2 変数の問題を扱いましたが、上記の手順はより複雑な問題に対しても同様に適用できます。

次のステップとして、 Amplify QAOA の機能について詳しく知りたい方は [](overview.md) に進んでください。 QAOA の理論を知りたい方は [](QAOA.md) に進んでください。

`````{grid} 1 2 2 2
:margin: 4 0 0 0
````{grid-item-card}  🌱 機能を詳しく知りたい
:margin: auto
```{button-ref} overview
:ref-type: doc
:color: info
:click-parent:
:expand:
**Amplify QAOA の全体像に進む**
```
````
````{grid-item-card}  📝 理論を詳しく知りたい
:margin: auto
```{button-ref} QAOA
:ref-type: doc
:color: success
:click-parent:
:expand:
**QAOA の理論に進む**
```
````
`````
