(qaoa_amplify_sdk)=
# Amplify SDK からのクイックスタート

Amplify SDK では Amplify QAOA で扱っているランナーに対応した[クライアント](https://amplify.fixstars.com/ja/docs/amplify/v1/clients.html#id3)が用意されているので、Amplify QAOA の一部の機能を他のクライアントと同様な方法で操作することができます。
ここでは、Amplify SKD を用いて QAOA の実効方法を紹介します。

## Amplify SDK のインストール

最初に、お使いの Python のバージョンが上記のリストに含まれることを確認してください。

```bash
$ python3 --version
```

Amplify SDK は [PyPI](https://pypi.org/project/amplify/) からインストールできます。次のコマンドで自身の環境にインストールされます。

```bash
$ python3 -m pip install -U 'amplify[extra]'
```

````{note}
Amplify QAOA を使う場合は、`amplify[extra]` として追加のパッケージを含めてインストールをする必要があります。
````


Amplify SDK が正しくインストールされると、次のようにしてインストールされたバージョンを確認できます。

```python
>>> import amplify
>>> amplify.__version__
1.3.1
```

Amplify SDK のインストールに関するより詳細な説明に関しては、[Amplify SDK クイックスタート](https://amplify.fixstars.com/ja/docs/amplify/v1/quickstart.html#id1) を参照してください。


## サンプルコードの実行

Amplify SDK のインストールが完了したら、QAOA を用いて簡単な問題を解く方法を紹介します。以下の例では、ソルバークライアントとして `QulacsClient` を用いて、次のような問題を考えます。

```{card} Sample QUBO Problem
:width: 50%
:margin: 3 3 auto auto
目的関数
:   $$
    \text{minimize:} \quad f = s_0 s_1 + s_0 - s_1 + 3
    $$

決定変数
:   $$
    s_0, s_1 \in \{-1, 1\}
    $$

制約条件
:   $$
    \text{None}
    $$
```

この問題では、$s_0 = -1$, $s_1 = 1$ のときに関数 $f$ は最小値 $f = 0$ となります。以下に紹介する方法でこの問題を QAOA によって解くことができます。

### 1. 変数配列の作成

まずは上記のサンプル問題に対応した -1 または 1 の値を取るイジング変数を $s_0$, $s_1$ として決定変数を定義します。

```python
>>> from amplify import VariableGenerator
>>> gen = VariableGenerator()     # 決定変数のジェネレータを作成
>>> s = gen.array("Ising", 2)    # 2つのイジング変数を持つ変数配列を作成
>>> print(s)
[s_0, s_1]
```

### 2. 目的関数の作成

次にサンプル問題の目的関数 $f = s_0 s_1 + s_0 - s_1 + 3$ を変数配列 `s`{l=python} を用いて以下のように定義します。

```python
>>> f = s[0] * s[1] + s[0] - s[1] + 3
>>> print(f)
s_0 s_1 + s_0 - s_1 + 1
```

この問題では制約条件を扱わないため、これで問題の定式化は完了です。

### 3. ソルバークライアントの作成

このサンプル問題の例では Qulacs を用いて QAOA を実行するため、ソルバークライアントとして Qulacs を扱うクライアントクラスである `QulacsClient` を作成します。

ソルバークライアントの設定として、Ansatz 回路の深さを指定する `reps` を 10、QAOA のサンプリングを行う際のサンプル数 `shots` を 1000 に設定します。`resp` と `shots` のより詳細な説明は [ランナーの設定](setting_runner) を参照してください。

```python
>>> from amplify import QulacsClient
>>> client = QulacsClient()  # QulacsClient を指定
>>> client.reps = 10  # Ansatz 回路の深さを指定
>>> client.shots = 1000  # サンプリング数を指定
```

### 4. ソルバーの実行

ここまでで定義した目的関数 `f` とソルバークライアント `client` を `solve` 関数に渡すことで、QAOA を実行し、その結果を取得することができます。

```python
>>> from amplify import solve
>>> result = solve(f, client)
```

### 5. 結果の確認

`result` に格納された実行結果から、見つかったベストな解の目的関数の値や変数の値を以下のようにしてを取得することができます。

```python
>>> result.best.objective   # 目的関数の値
0.0
>>> result.best.values      # 変数の値
Values({Poly(s_0): -1, Poly(s_1): 1})
```

より解を見やすくする方法として、`evaluate` メソッドを用いて変数の配列要素を解で得られた変数の値に置き換えた配列を得ることができます。

```python
>>> print(f"{s} = {s.evaluate(result.best.values)}")
[s_0, s_1] = [0. 1.]
```

このように、本サンプル問題の解が $s_0=0,\ s_1=1$ であることが確認できました。


