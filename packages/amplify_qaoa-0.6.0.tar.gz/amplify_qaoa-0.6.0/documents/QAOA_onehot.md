(constrained-qaoa)=
# 制約条件がある場合のQAOA

最適化問題の中には、変数にある種の制約を課した下での最適値を求める、というものがあります。

例えば、ハミルトニアン $f(x) = 2 x_1 x_2  + x_0 + x_1 - x_2$ を、「 $(x_0,x_1,x_2)$ のうちただ一つが値 $-1$ を取る」という制約の下で最小化したいとします。
もし変数に何も制約がなければ、このハミルトニアン $f(x)$ は $(x_0, x_1, x_2) = (-1, -1, 1)$ で最小値 $f(x) = -5$ を取ります。
しかし、この解は「 $(x_0,x_1,x_2)$ のうちただ一つが値 $-1$ を取る」という制約を満たしません。このような制約の下では $(x_0, x_1, x_2) = (1, -1, 1)$ で最小値 $f(x) = -3$ を取ります。

変数への制約は様々なものが考えられますが、特に、上記の例で課したような「変数のうちどれか一つだけが値 $1$ を取る」という制約は広く用いられます。
以下では「制約条件」といったとき、この条件を考えます。

ちなみに、変数が $\{0,1\}$ から成るバイナリ変数の場合には、このような制約は しばしば one-hot 制約と呼ばれます。
one-hot 制約について詳しくは、[Wikipedia: One-hot](https://ja.wikipedia.org/wiki/One-hot) を参照してください。

Amplify QAOA では、one-hot 制約が課された最適化問題を解く際に、与えられた制約条件に応じた変数のグルーピングを与えることで探索空間を削減し、より効率よく解を求めることができます。

## Constrained QAOA

ここでは、与えられた制約条件に対して変数のグルーピングを行うことでどのように最適解が得られるのかを説明します。

通常、このような制約条件付きの最適化問題を解く際には、制約条件を満たす解を最適解とする (緩和) 多項式 $g$ とペナルティ係数 $\lambda$ を与え、 $f' = f + \lambda g$ を解くことで制約条件の下での最適解を得ます。
例えば、上記の例のような、ハミルトニアン $f(x) = 2 x_1 x_2  + x_0 + x_1 - x_2$ を、「 $(x_0,x_1,x_2)$ のうちただ一つが値 $-1$ を取る」という one-hot 制約の下で解きたいときは、$g = (x_0+x_1+x_2 - 1)^2$ と指定して、適切な $\lambda$ を選ぶことで、所望の解を得ることができます。
詳しくは [Constraint](https://amplify.fixstars.com/ja/docs/constraint.html) を参照してください。
Amplify QAOAでもこれと同様に制約条件付きの解を得ることができます。

一方、 Amplify QAOA では制約条件を考慮した Ansatz を考えることで、与えられた最適化問題を「制約条件によって制限されたパラメーター空間内でハミルトニアンの最小の固有値と固有ベクトルを求める」問題に帰着させ、より効率的と期待される方法で問題を解く方法が実装されています。

与えられた変数 $x$ が $x = (x^{(1)},x^{(2)},\ldots,x^{(k)},\tilde{x})$ のように $k+1$ 個のグループに分けられるとします。

Ansatz は、 group が $k$ 個あるとき、 $\ket{\psi(\theta)}=\ket{\psi_{\mathrm{group}, 1}(\theta^{(1)})}\otimes\ket{\psi_{\mathrm{group}, 2}(\theta^{(2)})}\otimes\cdots\ket{\psi_{\mathrm{group}, k}(\theta^{(k)})}\otimes\ket{\psi_{\mathrm{ungroup}}(\tilde{\theta})}$ のように各 group について独立に量子回路が作用するように定義します。
このうち、 $\ket{\psi_{\mathrm{ungroup}}(\tilde{\theta})}$ は、<!-- `group_list` に含まれていない量子ビットについて独立にパラメータで特徴づけられた -->
$X$ 回転ゲート $R_X(\theta)=\mathrm{e}^{i\frac{\theta}{2} X}$ を作用させます。

回路の概略を示すと下図のようになります。

![grouping_ansatz](figure/grouping_ansatz.drawio.svg)

ここで、各 $i = 1,2,\ldots,k$ に対して、 $\ket{\psi_{\mathrm{group}, i}(\theta)} = U(\theta^{(i)}) \ket{\psi_{\mathrm{init}, i}}$ は次のような回路で構成されています。

![grouping_ansatz_component](figure/grouping_ansatz_component.drawio.svg)

回路図中で 2 量子ビットゲート $A(\theta)$ は下図のように CNOT ゲートと $Y$ 回転ゲート $R_Y(\theta) = \mathrm{e}^{i\frac{\theta}{2} Y}$ で実現されます。

![gateA](figure/gateA.drawio.svg)

このゲート $A(\theta)$ を行列表示すると

$$
A(\theta) =
\begin{pmatrix}
    1 & 0 & 0 & 0 \\
    0 & \sin\theta & \cos\theta & 0 \\
    0 & \cos\theta & -\sin\theta & 0 \\
    0 & 0 & 0 & 1
\end{pmatrix}
$$

となり、入力が計算基底の時、入力状態の持つ 1 の数を保存することが分かります。

<!--
したがって、 $\ket{\psi_{\mathrm{group}, i}(\theta^{(i)})}$ は`init_ones` で指定される初期状態と同様の個数の `1` を持っていることになり、 $\ket{\psi_{\mathrm{group}, i}(\theta^{(i)})}$ の表現能力が十分であれば、パラメータの最適化を行うことで所望の解を得ることができると考えられます。
-->

ここで用いた Ansatz 状態 $\ket{\psi(\theta)}$ は $k$ 個の独立な one-hot 制約条件を満たす状態に制限され、制約を緩和して解を探索する通常の方法と比べて、より効率的に解を求めることができると期待されます。

