---
jupytext:
  text_representation:
    extension: .md
    format_name: myst
    format_version: 4.0.0
    jupytext_version: 1.16.4
kernelspec:
  display_name: Python 3
  language: python
  name: python3
---


# Amplify QAOA の概要

Amplify QAOA では、ゲート型量子コンピューターやそのシミュレーターを扱うQiskitランナーやQulacsランナーを用いて最適化問題を解くことができます。

<!-- ## このモジュールで提供しているQAOAとは
* QAOAとはどのようなものか
* Amplify QAOA では何を提供しているのか？
* インターフェースの紹介
    * Amplify SDKの拡張モジュールです
* パラメータ
* どのようなアルゴリズム？

* 相手にして欲しいのは何か？
    * QAOA とは何か
* 知りたかったら調べればよいこと
    * どのようなアルゴリズム -->

(qaoa_steps)=
## QAOA の流れ

Quantum Optimization Algorithm (QAOA) は組合せ最適化問題を解くための量子アルゴリズムで、誤り訂正機能の無いゲート型量子コンピューターで解く際に用いられる手法です。QAOA で量子コンピュータを用いて最適化問題を解くアルゴリズムの大まかな流れは以下の Step1-Step6 です（QAOA の詳細については他文献[<sup>1</sup>][qiskit-ref][<sup>2</sup>][qulacs-ref] 、または[QAOAとは](QAOA.md#qaoa_details)を参照してください）。

[qiskit-ref]:<https://qiskit.org/textbook/ja/ch-applications/qaoa.html>

[qulacs-ref]:<https://dojo.qulacs.org/ja/latest/notebooks/5.3_quantum_approximate_optimazation_algorithm.html>

**Step1: ハミルトニアンの定義**
: 最適化問題を表すハミルトニアン $f(s)=\sum_{\alpha}c_{\alpha}f_{\alpha}(s)$（$s=s_1s_2\cdots s_n$ は $s_i \in \{-1,1\}$ のイジング変数からなる文字列、 $c_{\alpha}$ は実数、 $f_{\alpha}$ は有限次の単項式）が与えられたとき、量子ビットの空間における対応するハミルトニアン $H(s) = \sum_{\alpha} H_{\alpha}(s) \ket{x} \bra{s}$ を構成する。QAOAの目的は、 $H(s)$ の最小固有値/固有ベクトルを近似的に求めることで、 $f(s)$ の最小値を達成するビット列 $x$ を求めることである。

**Step2: Ansatz 回路の構成**
: 上で構成したハミルトニアン $H(s)$ の最小固有値を探索するために、実数パラメータ $\theta = (\theta_1,\theta_2.\ldots,\theta_k)$ で特徴づけられた回路（Ansatz 回路）を構成する。パラメータ $\theta$ に対応する量子状態を $\ket{\psi(\theta)}$ と書き、Ansatz 状態と呼ぶ。

**Step3: コスト関数の定義**
: コスト関数を $C(\theta) = \bra{\psi(\theta)} H(s) \ket{\psi(\theta)}$ (パラメータが $\theta$ における Ansatz 状態 $\ket{\psi(\theta)}$ でのハミルトニアン $H(s)$ の期待値)と定義する。

**Step4: パラメータのアップデート**
: 量子コンピューター/シミュレーター上での $C(\theta)$ の評価と、古典最適化アルゴリズムによるパラメータ $\theta$ のアップデートを収束するまで繰り返す。

**Step5: 収束条件の判定**
: 収束時のパラメータを $\theta^{\textup{opt}}$ と書く。この時、 $C(\theta^{\textup{opt}})$ 、 $\ket{\psi(\theta^{\textup{opt}})}$ は $H(s)$ の最小固有値/固有ベクトルの良い近似になっていると期待される。

**Step6: 解の抽出**
: $\ket{\psi(\theta^{\textup{opt}})}$ に対して計算基底でのサンプリングを行い、最も多く得られた結果 $s^{\textup{opt}}$ を解として出力する。十分多くのサンプルを取った場合、高確率で $s^{\textup{opt}}$ は $f(s)$ の最小値を与える正しい解になっていると期待される。

なお、量子計算の標準的な記法では、ビット列に対応する量子状態を $\{\ket{0}, \ket{1}\}$ と表しますが、ここでは古典文字列が　$\{-1,1\}$ から成っていることを考えて $\{\ket{1}, \ket{-1}\}$ という記号を用いることにしています。

## Amplify QAOA の実行の流れ
以下では与えられた最適化問題を Amplify QAOA でどのように解いていくかという説明をしていきます。

### **(1) ハミルトニアンの定義**
まず、Step1 に対応するハミルトニアンを定義します。
ハミルトニアンは、単項式 $f_{\alpha}(s)$ が持つ変数を key、その単項式の係数 $\tilde{c}_{ \alpha}$ を value とする辞書として与えます。
以下は $f(s) = s_0 s_1 + s_1 s_2 + s_0 s_3 + s_2 s_3$ を与えた場合の例で、以下のように辞書形式で `f_dict` を表します。


```{code-cell} python
>>> f_dict = {(0, 1): 1.0, (1, 2): 1.0, (0, 3): 1.0, (2, 3): 1.0}
```

このハミルトニアンは長方形の最大カット問題に対応しており、解は $s_0 = s_2 = 1,\, s_1 = s_3 = -1$ または  $s_0 = s_2 = -1,\,s_1 = s_3 = 1$ となり、その際の $f$ の最小値は $-4$ です。

````{note}
$s_0, s_1, s_2 \in \{-1, 1\}$ をイジング変数とし、$f(s) = 1 + 2 s_0 + 3 s_1s_2$ のようなハミルトニアンを考える際は

```python
f_dict = {(): 1, (0,): 2, (1, 2): 3}
```

として、それぞれ定数項、1次項、2次項を表現します。

````


### **(2) ランナーの指定**
Amplify QAOA を実行するには、まず量子コンピューター/シミュレーターを使うためのランナーを指定する必要があります。Amplify QAOA では以下のランナーをサポートしています。

* {py:class}`~amplify_qaoa.runners.QiskitRunner`
* {py:class}`~amplify_qaoa.runners.QulacsRunner`

トークンが必要な場合はトークンも指定します。

```{code-cell} python
>>> from amplify_qaoa.runners import QiskitRunner # QulacsRunner

# ランナーを指定
>>> runner = QiskitRunner()  # qulacsを用いたい場合は QulacsRunner()

# 必要な場合はランナーの API トークンを設定
# runner.token = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
```

<!-- TODO: トークンについての詳細を記載 -->
<!-- ```{note}
* qulacsはトークン必要ない
* qiskit: 内部シミュレータとクラウド
    * 実機を使う場合はトークン必要
    * シミュレータの場合はトークンは必要ない
``` -->

(setting_runner)=
### **(3) ランナーの設定**
次にランナーのパラメータの設定を行います。ランナーは以下のパラメータを持ちます。
* `reps`: Ansatz 回路の深さ
* `shots`: 測定回数（Step4 のパラメータの最適化と Step6 でサンプリングを行う際の測定回数）

この例では `reps` と `shots` をそれぞれ 10 と 1000 に設定します。

```{code-cell} python
>>> runner.reps = 10
>>> runner.shots = 1000
```

ランナーを指定する際に、`reps` や `shots` をあらかじめ以下のように決めておくこともできます。

```python
runner = QiskitRunner(reps=10, shots=1000)
```

明示的に `reps` と `shots` の値を指定しない場合は、自動でそれらの値が設定されます。
以下の例では `reps=10` 、 `shots=1000` として進めます。

### **(4) サンプリングによる最適解の抽出**

ランナーの設定を行ったら、次は `run` 関数を用いて解を取得します。
`run` 関数では [QAOAの流れ](qaoa_steps) の Step2-Step6 に対応した工程を行います。

`run` 関数に関するより詳しい説明は[サンプリングによる最適解の抽出](sample_sols)を参照してください。

```{code-cell} python
>>> run_result = runner.run(f_dict)
```

直感的には、 `run` 関数は $\theta^{\textup{opt}}$ に対応する状態 $\ket{\psi(\theta^{\textup{opt}})}$ から対応するビット列 $s^{\textup{opt}}$ を抽出するための関数です。
得られた $s^{\textup{opt}}$ は解きたかった最適化問題の解になっていると期待されます。


```{code-cell} python
>>> print(run_result.counts)
```
`run_result.counts` の各要素はサンプリングされた解とその回数のタプルとなっています。
こここの結果では、$[-1, 1, -1, 1]$ と $[1, -1, 1, -1]$ の解が同数程度観測され、それらの回数が全観測数の大半をし占めることがわかります。runner.shots=1000` としたので、1000回の観測のうちのほとんどの観測が上記二つの解となることがわかり、この二つの解が求めたい解であることがわかります。




### 制約条件がある場合
最適化問題の中には、変数にある種の制約を課した下での最適値を求める必要がある場合があります。以下ではそのような制約条件化の QAOA をどのようにして Amplify QAOA で扱うかについて説明しまうす。
制約条件がある場合の QAOA に関する概念的な説明は[制約条件がある場合のQAOA](#constrained-qaoa)を参照してください。

ここでは、Amplify QAOA で one-hot 制約が入った問題を解く方法について解説します。前節で考えた例をそのまま考え、ハミルトニアン $f(x) = 2 s_1 s_2  + s_0 + s_1 - s_2$ を、「 $(s_0,s_1,s_2)$ のうちただ一つが値 $-1$ を取る」という one-hot 制約の下で解くことを考えます。

```{code-cell} python
>>> from amplify_qaoa.runners import QiskitRunner # QulacsRunner

# ランナーを指定
>>> runner = QiskitRunner()  # qulacsを用いたい場合は QulacsRunner()

>>> runner.reps = 10
>>> runner.shots = 1000

>>> f_dict = {(1, 2): 2.0, (0,): 1.0, (1,): 1.0, (2,): -1.0}
>>> group_list = [[0, 1, 2]]
>>> run_result = runner.run(f_dict, group_list=group_list)
```

今回の例では、バイナリ変数 $s_0, s_1, s_2$ に対する one-hot 制約を `group_list` を用いて与えています。
これによって Ansatz 状態が取る解の探索空間を、 $s_0, s_1, s_2$ のうちただ 1 つが値 $-1$ を取るという制約を満たす空間に制限することができます。

```{code-cell} python
>>> print(run_result.counts)
```

この結果から、制約を満たす最適解は $s_0 = 1, s_1 = -1, s_2 = 1$ であることがわかります。
このように指定することで、結果として得られる解は、この制約を満たす最適解になることが期待されます。
なお制約が 2 グループ以上に分かれる場合、例えば、 変数が $\{s_i \in \{-1,1\}: i =0,1,2,3,4\}$ で、 $s_0, s_1$ と $s_2, s_3, s_4$ の双方に独立した one-hot 制約を課したい場合、`group_list=[[0,1],[2,3,4]]` と指定します。

初期状態で $s_i = -1$ となっているラベルのリストを `init_ones` で明示することで、より一般的な "n-hot" 制約を考えることも可能です。

例えば `group_list=[[0,1],[2,3,4]]` の時、 `init_ones=[0,2,3]` と指定することで、初期状態における各変数の値を $s_0 = -1$ 、 $s_1 = 1$ 、 $s_2 = -1$ 、 $s_3 = -1$ 、 $s_4 = 1$ と定めることができます。
これによって、 $s_0, s_1$ には one-hot 制約を、 $s_2, s_3, s_4$ には two-hot 制約を課して最適化問題を解くことができます。
なお `init_ones` を指定しなかった場合、 `group_list` の各グループから値 $-1$ を初期状態で持つ変数を一つランダムにピックアップします。
つまり、すべてのグループに one-hot 制約が課されます。

