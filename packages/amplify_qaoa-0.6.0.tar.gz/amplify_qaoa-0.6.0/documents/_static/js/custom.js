function documentReady(callback) {
    if (document.readyState != "loading") callback();
    else document.addEventListener("DOMContentLoaded", callback);
}

function scrollToActive() {
    // If the docs nav doesn't exist, do nothing (e.g., on search page)
    if (!document.querySelector("div.sidebar-scroll")) {
        return;
    }

    var sidebar = document.querySelector("div.sidebar-scroll");

    // Remember the sidebar scroll position between page loads
    // Inspired on source of revealjs.com
    let storedScrollTop = parseInt(
        sessionStorage.getItem("sidebar-scroll-top"),
        10
    );

    if (!isNaN(storedScrollTop)) {
        // If we've got a saved scroll position, just use that
        sidebar.scrollTop = storedScrollTop;
        console.log("[PST]: Scrolled sidebar using stored browser position...");
    } else {
        // Otherwise, calculate a position to scroll to based on the lowest `active` link
        var sidebarNav = document.querySelector(".sidebar-tree");
        var active_pages = sidebarNav.querySelectorAll(".current-page");
        if (active_pages.length > 0) {
            // Use the last active page as the offset since it's the page we're on
            var latest_active = active_pages[active_pages.length - 1];
            var offset =
                latest_active.getBoundingClientRect().y -
                sidebar.getBoundingClientRect().y;
            // Only scroll the navbar if the active link is lower than 50% of the page
            if (latest_active.getBoundingClientRect().y > window.innerHeight * 0.5) {
                let buffer = 0.25; // Buffer so we have some space above the scrolled item
                sidebar.scrollTop = offset - sidebar.clientHeight * buffer;
                console.log("[PST]: Scrolled sidebar using last active link...");
            }
        }
    }

    // Store the sidebar scroll position
    window.addEventListener("beforeunload", () => {
        sessionStorage.setItem("sidebar-scroll-top", sidebar.scrollTop);
    });
}

documentReady(scrollToActive);
