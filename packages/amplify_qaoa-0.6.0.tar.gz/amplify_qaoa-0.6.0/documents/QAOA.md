(qaoa_details)=
# QAOA とは

Quantum Approximate Optimization Algorithm (QAOA) は、組合せ最適化問題を誤り訂正を用いないゲート型量子コンピューター（NISQ デバイス）で解くことを目指して提案された、変分量子アルゴリズムの一つです。本ドキュメントでは、本ライブラリを利用するうえで必要となる範囲で、QAOA の概要と数理的な枠組みを説明します。より詳しい理論的背景やチュートリアルについては、以下の文献も参照してください。

- [Qiskit Textbook](https://qiskit.org/textbook/ja/ch-applications/qaoa.ipynb)
- [Quantum Native Dojo](https://dojo.qulacs.org/ja/latest/notebooks/5.3_quantum_approximate_optimazation_algorithm.html)

現在実際に利用可能な量子コンピューターは、量子ビット数が比較的少なく、誤り訂正を行わない NISQ デバイスが中心です。このため、量子アルゴリズムの応用範囲はまだ大きく制限されています。QAOA は、そのような現在の量子コンピューターでも比較的実行しやすいアルゴリズムであり、量子コンピューターを用いた最適化問題への応用に向けた重要な足掛かりとして有望視されています。

## QAOA が解く最適化問題

QAOA は、組合せ最適化問題の中でも Quadratic Unconstrained Binary Optimization (QUBO) と呼ばれるクラスの問題を扱います。その名の通り、QUBO はバイナリ (binary) 変数 $x = (x_1, x_2, \ldots, x_n) \quad (x_i \in \{0,1\},\ i=1,2,\ldots,n)$ に対する二次 (quadratic) の目的関数を、制約条件無し (unconstrained) で最小化する (optimization) 問題です。形式的には、$f$ を $x$ の二次式として

$$
\mathrm{minimize}_{x \in \{0,1\}^n} \quad f(x)
$$

と書けます。

量子コンピューターでは、バイナリ変数 $x \in \{0,1\}^n$ よりも、イジング変数 $z = (z_1, z_2, \ldots, z_n), \quad z_i \in \{-1,1\}$ を用いる方が扱いやすいのが一般的です。そのため、最適化したいバイナリ関数 $f(x)$ が与えられたとき、変数変換 $z_i = 1 - 2x_i$ を行い、$\tilde f(z) = f(x)$ となる等価なイジング関数 $\tilde f$ を定義します。以下では、このイジング関数 $\tilde f(z)$ の最小化を考えます。

```{important}
本ドキュメントでは、バイナリ変数 $x \in \{0,1\}$ とイジング変数 $z \in \{-1,1\}$ は、次の関係を満たすものとします：

$$
z = 1 - 2x, \qquad x = \frac{1 - z}{2}
$$
```

イジング変数 $z$ の定義と、$f(x)$ が $x$ の二次式で表現可能であることから、$\tilde f(z)$ も $z$ の高々二次の多項式となります。以下、二次多項式 $\tilde f(z)$ を構成する各単項式を $\tilde f_{\alpha}(z)$ と表し、

$$
\tilde f(z) = \sum_{\alpha}\tilde f_{\alpha}(z)
$$

と書きます。定義より、各 $\tilde f_{\alpha}(z)$ の次数は高々 2 です。

(quantum_state)=
## 量子状態について

QAOA の説明に入る前に、量子コンピューターにおいて情報がどのように表現されるかを簡単に確認します。

私たちが通常用いる古典コンピューターでは、情報は $0$ と $1$ からなる「ビット」の列として表されます。量子コンピューターの世界では、この「ビット」に対応するものを **量子ビット (qubit)** と呼び、これは大きさが 1 に規格化された複素数上の 2 次元ベクトル、すなわち **量子状態** として表現されます。

古典のビットが $0$ か $1$ のどちらかの値しか取らないのに対し、量子ビットはより多様な量子状態を取り得ます。数学的には、量子状態 $\ket{\psi}$ は、$|\alpha|^2 + |\beta|^2 = 1$ を満たす複素数 $\alpha, \beta$ を用いて、列ベクトル $(\alpha,\beta)^T$ で表されます。量子情報の分野では、しばしば $\ket{0} = (1,0)^{T},\quad \ket{1} = (0,1)^{T}$ と定義された正規直交基底 $\{\ket{0}, \ket{1}\}$ を用いて

$$
\ket{\psi} = \alpha \ket{0} + \beta \ket{1}
$$

と表現します。

一般に、$n$ 量子ビットの量子状態は $2^n$ 次元の複素ベクトルで表されますが、基本的な考え方は 1 量子ビットの場合と同様です。

## QAOA の動作手順

QAOA は次のような手順で最適化問題を解きます。

1. 与えられたイジング関数 $\tilde f$ から、目的関数に対応するハミルトニアン $H$ を構成する。このとき、$H$ の最小固有値が $\tilde f$ の最小値に対応する。
2. $H$ の最小固有値（に対応する固有状態）を探索するために、実数パラメータ $\boldsymbol{\theta} = (\theta_1,\theta_2,\ldots,\theta_k)$ で特徴づけられたパラメトリック量子回路（Ansatz 回路）を構成する。パラメータ $\boldsymbol{\theta}$ に対応する量子状態を $\ket{\psi(\boldsymbol{\theta})}$ と書き、Ansatz 状態と呼ぶ。
3. コスト関数を $C(\boldsymbol{\theta}) = \bra{\psi(\boldsymbol{\theta})} H \ket{\psi(\boldsymbol{\theta})}$ と定義する。
4. 量子コンピューター上での $C(\boldsymbol{\theta})$ の評価と、古典最適化アルゴリズムによるパラメータ $\boldsymbol{\theta}$ の更新を、ある収束条件を満たすまで繰り返す。

以下、各ステップについて順に説明します。

### 1. ハミルトニアンの作成

QAOA の目的関数として、イジング関数 $\tilde f$ が与えられているとします。目的は、$\tilde f(z)$ を最小化するイジング変数列 $z = (z_1,\ldots,z_n) \in \{-1,1\}^n$ を見つけることです。

量子コンピューターで最適化を行うには、このイジング関数を量子ビット上の演算子（ハミルトニアン）へと変換します。具体的には、目的関数に対応するハミルトニアン $H = \sum_{\alpha} H_{\alpha}$ を次のように定義します。

- 各単項式 $\tilde f_\alpha(z)$ に登場するイジング変数 $z_i$ を、対応する Pauli $Z$ 演算子 $Z_i$ に置き換える。

具体例を以下に示します。

- $\tilde f_{\alpha}(z) = 2z_1z_2$ のとき

  $$
  H_{\alpha} = 2 Z_1 Z_2
  $$

- $\tilde f_{\alpha}(z) = -3 z_3$ のとき

  $$
  H_{\alpha} = -3 Z_3
  $$

- $\tilde f_{\alpha}(z) = 5$ のような定数項は、恒等演算子 $I$ の係数に対応し

  $$
  H_{\alpha} = 5 I
  $$

  となります。このような定数項は、スペクトル全体を一定だけシフトするだけで基底状態は変えないため、多くの場合は無視して構いません（ただしエネルギーの絶対値が必要な場面では保持します）。

ここで $Z_i$ は「$i$ 番目の量子ビットに作用する Pauli $Z$ 演算子」を意味します。本ドキュメントではテンソル積 $\otimes$ は省略し、$Z_1 \otimes Z_2$ を $Z_1 Z_2$ のように書きます。

以上より、$n$ 変数のイジング関数 $\tilde f$ を QAOA で最適化したい場合、$n$ 量子ビット上で定義されたハミルトニアン $H$ が必要になります。したがって、少なくとも $n$ 量子ビットを持つ量子コンピューターが必要になります。

### 2. Ansatz 状態の準備

与えられた問題を解くため、パラメータ付きの量子状態（Ansatz 状態）を定義します。Ansatz 状態とは、**パラメータで特徴づけられた量子回路を初期状態に作用させて得られる状態** のことです。QAOA では、特定の構造を持つ QAOA Ansatz を用います。QAOA Anatz を作成する回路は次のようになります。

```{image} figure/qaoa_circuit.svg
:align: center
```

#### 初期状態

QAOA では、多くの場合、初期状態として $+$ 状態と呼ばれる状態を用います。1 量子ビットの $+$ 状態は

$$
\ket{+} = \frac{\ket{0} + \ket{1}}{\sqrt{2}}
$$

と定義されます。

```{hint}
$+$ 状態は、$0$ 状態 $\ket{0}$ に Hadamard ゲート

$$
\frac{1}{\sqrt{2}}
\begin{pmatrix}
1 & 1 \\
1 & -1
\end{pmatrix}
$$

を作用させることで得られます。
```

$n$ 個すべての量子ビットが $+$ 状態にある $\ket{+}^{\otimes n}$ を QAOA の初期状態として用います。

#### QAOA Ansatz の定義

QAOA Ansatz は、実数パラメータ列

$$
\boldsymbol{\theta} = (\boldsymbol{\beta},\boldsymbol{\gamma})
= (\beta_1,\ldots,\beta_p,\gamma_1,\ldots,\gamma_p)
$$

で特徴づけられる量子状態です。ここで $p$ は QAOA の「深さ」（層数）です。 本ドキュメントでは、パラメータ全体をまとめて $\boldsymbol{\theta}$ と書きます。QAOA Ansatz を生成する量子回路 $U(\boldsymbol{\theta})$ を次のように定義します。

$$
U(\boldsymbol{\theta})
= \prod_{j=1}^{p}
  \left[
    \exp\left(-i \beta_j \sum_{k} X_k\right)
    \exp\left(-i \gamma_j H\right)
  \right]
$$

ここで $H$ は先ほど定義したコストハミルトニアン、 $X_k$ は $k$ 番目の量子ビットに作用する Pauli $X$ 演算子を表します。因子の積 $\prod_{j=1}^{p}$ は、**右側の $j=1$ の層から左側の $j=p$ の層へ向かって順に作用する** と解釈します。本ドキュメントでは、$\gamma_j$ をコストハミルトニアン $H$ に対応するパラメータ、 $\beta_j$ を $X$ によるミキシングに対応するパラメータとして用いています。直感的には、

- $\exp(-i \gamma_j H)$ が Pauli $Z$ 方向（コスト関数）に沿って状態を発展させ、
- $\exp\left(-i \beta_j \sum_k X_k\right)$ が Pauli $X$ 方向に沿って状態を混合させる

ことで、多様な量子状態を表現します。

以上より、パラメータ $\boldsymbol{\theta}$ に対応する QAOA Ansatz 状態を

$$
\ket{\psi(\boldsymbol{\theta})}
= U(\boldsymbol{\theta}) \ket{+}^{\otimes n}
$$

と定義します。

### 3. コスト関数の定義

コスト関数 $C(\boldsymbol{\theta})$ は、ハミルトニアン $H$ の、Ansatz 状態 $\ket{\psi(\boldsymbol{\theta})}$ における期待値として定義されます。数学的には

$$
C(\boldsymbol{\theta})
= \bra{\psi(\boldsymbol{\theta})} H \ket{\psi(\boldsymbol{\theta})}
$$

です。

ここで、一般に量子状態 $\ket{\psi}$ は複素列ベクトルとして表され、その随伴ベクトル（転置と複素共役）をとったものが $\bra{\psi}$ です。例えば、$\ket{\psi} = (a,b)^T$ なら $\bra{\psi} = (a^*, b^*)$ となり、$n$ 量子ビットの場合も同様に共役転置で定義されます。

線形代数の観点から見ると、$C(\boldsymbol{\theta})$ はベクトル $\ket{\psi(\boldsymbol{\theta})}$ の行列 $H$ に関する二次形式です。$H$ の最小固有値を $\lambda_{\min}$、その固有ベクトルを $\ket{\psi_{\min}}$ とすると、$C(\boldsymbol{\theta})$ は $\ket{\psi(\boldsymbol{\theta})}$ が $\ket{\psi_{\min}}$ に一致するときに最小値 $\lambda_{\min}$ を取ります。

QAOA では、「$\ket{\psi(\boldsymbol{\theta})}$ のうち、$C(\boldsymbol{\theta})$ を最小にするものは $H$ の基底状態（の良い近似）になっているはずだ」という前提のもと、古典的な最適化により $C(\boldsymbol{\theta})$ を最小化するパラメータ $\boldsymbol{\theta}$ を探索します。

### 4. 古典最適化によるパラメータ更新

コスト関数 $C(\boldsymbol{\theta})$ の値を評価するのは量子コンピューターの仕事です。一方、その値をもとに

- パラメータ $\boldsymbol{\theta}$ を更新し、
- $C(\boldsymbol{\theta})$ を最小化する $\boldsymbol{\theta}^{\textup{opt}}$ を見つける

のは古典コンピューター側の役割です。

具体的には、

1. あるパラメータ $\boldsymbol{\theta}$ を用いて QAOA 回路 $U(\boldsymbol{\theta})$ を実行し、
2. 状態 $\ket{\psi(\boldsymbol{\theta})}$ に対するハミルトニアン $H$ の期待値
   $C(\boldsymbol{\theta})$ を測定により推定し、
3. 古典最適化アルゴリズム（勾配法、勾配無し最適化、ベイズ最適化など）を用いて
   次の $\boldsymbol{\theta}$ を決める

というステップを、ある収束条件を満たすまで繰り返します。

(qaoa_steps)=
## QAOA まとめ

最後に、QAOA の典型的なステップを改めてまとめます。

**Step1: ハミルトニアンの定義**
: 最適化したい古典コスト関数を $f(z) = \sum_{\alpha} c_{\alpha} f_{\alpha}(z)$ と書く。ここで、$z = (z_1,\ldots,z_n)$ は $z_i \in \{-1,1\}$ のイジング変数列、$c_{\alpha}$ は実数係数、$f_{\alpha}$ は高々二次の単項式である。各単項式 $f_{\alpha}(z)$ に現れるイジング変数 $z_i$ を対応する Pauli $Z$ 演算子 $Z_i$ に置き換え、必要に応じて恒等演算子 $I$ を用いることで、量子ビット空間上のハミルトニアン $H = \sum_{\alpha} H_{\alpha}$ を構成する。QAOA の目的は、この $H$ の最小固有値／固有ベクトルを近似的に求めることで、$f(z)$ の最小値を達成するイジング変数列 $z$ を得ることである。

**Step2: Ansatz 状態の準備**
: 上で構成したハミルトニアン $H$ の最小固有値を探索するため、実数パラメータ列 $\boldsymbol{\theta} = (\boldsymbol{\gamma},\boldsymbol{\beta})$ で特徴づけられた QAOA Ansatz 回路 $U(\boldsymbol{\theta})$ を構成する。初期状態 $\ket{+}^{\otimes n}$ に対し、 $\ket{\psi(\boldsymbol{\theta})} = U(\boldsymbol{\theta}) \ket{+}^{\otimes n}$ と定義し、この $\ket{\psi(\boldsymbol{\theta})}$ を Ansatz 状態と呼ぶ。

**Step3: コスト関数の定義**
: コスト関数を $C(\boldsymbol{\theta}) = \bra{\psi(\boldsymbol{\theta})} H \ket{\psi(\boldsymbol{\theta})}$ と定義する。$C(\boldsymbol{\theta})$ は、パラメータ $\boldsymbol{\theta}$ に対応する Ansatz 状態 $\ket{\psi(\boldsymbol{\theta})}$ におけるハミルトニアン $H$ の期待値である。

**Step4: パラメータのアップデート**
: 量子コンピューター上で $C(\boldsymbol{\theta})$ を評価し、その結果を用いて古典最適化アルゴリズムによりパラメータ $\boldsymbol{\theta}$ を更新する。この「（量子側での）評価」と「（古典側での）更新」を、所定の収束条件を満たすまで繰り返す。

**Step5: 収束条件の判定**
: 収束時のパラメータを $\boldsymbol{\theta}^{\textup{opt}}$ と書く。このとき、$C(\boldsymbol{\theta}^{\textup{opt}})$ および $\ket{\psi(\boldsymbol{\theta}^{\textup{opt}})}$ は、ハミルトニアン $H$ の最小固有値／固有ベクトルの良い近似になっていると期待される。

**Step6: 解の抽出**
: 最終的なパラメータ $\boldsymbol{\theta}^{\textup{opt}}$ を用いて状態 $\ket{\psi(\boldsymbol{\theta}^{\textup{opt}})}$ を準備し、計算基底で測定を多数回行う。得られたビット列 $z$ ごとに古典コスト $f(z)$ を計算し、

  - 出現回数の多いもの、
  - あるいは $f(z)$ が最小となるもの

  を候補解として選ぶ。本ドキュメントでは簡単のため、測定結果の中で最も多く得られたビット列を $z^{\textup{opt}}$ とし、これを最適解として出力することにする。十分多くのサンプルを取った場合、高確率で $z^{\textup{opt}}$ は $f(z)$ の最小値（またはその近傍の値）を与える解になっていると期待される。
