---
jupytext:
  text_representation:
    extension: .md
    format_name: myst
    format_version: 4.0.0
    jupytext_version: 1.16.4
kernelspec:
  display_name: Python 3
  language: python
  name: python3
---

(param_opt)=
# パラメータの最適化（`tune` 関数）

`tune` 関数は [QAOA の流れ](qaoa_steps) の Step2-Step4 に対応した Ansatz 回路のパラメータの最適化を行います。

`tune` 関数の動作の概略は以下の図のようになります。

![tune](figure/tune.jpg)

引数を受け取った `tune` 関数はまず、コスト関数を構成します。
コスト関数構成のために、引数として受け取ったハミルトニアン（`f_dict`）を、量子ビットの世界におけるハミルトニアン $H(x)$ に変換します。
その後、Ansatz 状態 $\ket{\psi(\theta)}$ を構成します。
`group_list`に特に指定がない限り、ハミルトニアン $H(x)$ を基にした、深さが `reps` で指定される QAOA ansatz が構成されます。（QAOA Ansatz について詳しくは...参照）
コスト関数を $C(\theta) = \bra{\psi(\theta)} H(x) \ket{\psi(\theta)}$ と $\theta$ の関数として定義したのち、 $\theta$ のランダムな初期値と古典最適化アルゴリズム `optimizer` とともに `scipy.optimize` の `minimize` 関数で $C(\theta)$ の最小化を行います。
この時現実には、 `minimize` 関数内でコスト関数が呼ばれるたびに量子デバイスが期待値の計算を行い、量子デバイスの計算結果を基に古典最適化アルゴリズムでパラメータのアップデートが行われ、これが収束するまで繰り返されます。
収束した際のパラメータの値を $\theta^{\textup{opt}}$ （`opt_params`） として返し、この時の量子状態が最適値を与えるビット列に対応すると考えます。


## 入力
<!-- TODO:tune 関数の引数の説明 -->
|         引数         | 説明                                                                                                                                                                                                                                             |
| :------------------: | :----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
|       `f_dict`       | イジング変数を key とし、係数を value とする辞書                                                                                                                                                                                                 |
|     `qaoa_type`      | デフォルトでは `QaoaAnsatzType.Original`                                                                                                                                                                                                         |
|     `optimizer`      | パラメータの古典最適化を行う際のアルゴリズムを指定します。現在 [scipy.optimize.minimize](https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.minimize.html) で取り扱い可能なものに対応しています。デフォルトでは `COBYLA` です。 |
|     `init_ones`      | 値を -1 として初期化したい変数のリストを与えます。                                                                                                                                                                                               |
| `initial_parameters` | 初期値として与えるパラメータで、float のリストで与えます。指定しない場合はランダムで初期値が設定されます。                                                                                                                                       |
|     `group_list`     | 各リストの要素として One-hot 制約を課したい変数のリストを与えます。リストの各要素で与えられた変数のリストのうち、1 つだけが -1 になります。                                                                                                      |

## 戻り値

`tune` 関数の戻り値は {py:class}`~amplify_qaoa.runners._results.TuneResult` クラスで、以下のプロパティを持ちます。

| key              | 説明                                                                                                                    |
| ---------------- | ----------------------------------------------------------------------------------------------------------------------- |
| `evals`          | 古典最適化にかかったコスト関数の総評価数                                                                                |
| `tune_timing`    | `tune` 関数の各ステップにかかった時間に関する情報を格納した {py:class}`~amplify_qaoa.runners._timing.TuneTiming` クラス |
| `opt_val`        | 最適化後のコスト関数の値 $C(\theta^{\textup{opt}})$                                                                     |
| `opt_params`     | 最適化後のパラメータの値 $\theta^{\textup{opt}}$                                                                        |
| `group_list`     | 入力で与えた `group_list`                                                                                               |
| `init_ones`      | 入力で与えた `init_ones`                                                                                                |
| `params_history` | 最適化各ステップにおけるパラメータ $\theta$ の履歴                                                                      |

{py:class}`~amplify_qaoa.runners._timing.TuneTiming` クラスには `tune` 関数の各ステップでかかった時間が記録されています。このクラスのプロパティとして、以下の情報を取得することができます。

|         key          |                                                                                                           説明                                                                                                            |
| -------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `total_time`         | `tune` 関数にかかった時間の総計                                                                                                                                                                                           |
| `minimize_time`      | コスト関数の最適化にかかった時間の総計                                                                                                                                                                                    |
| `classical_opt_time` | 最適化にかかった時間のうち、古典最適化アルゴリズムが走っていた時間の総計                                                                                                                                                  |
| `runner_timing`      | 使用したマシンに依存したタイミングクラス。`QulacsRunner` の場合 {py:class}`~amplify_qaoa.runners.QulacsRunner.QulacsTiming`、`QiskitRunner` の場合は {py:class}`~amplify_qaoa.runners.QulacsRunner.QiskitTiming` となる。 |

用いるマシンに依存する `runner_timing` は以下のようになります。

`QulacsRunner` を用いた場合の {py:class}`~amplify_qaoa.runners.QulacsRunner.QulacsTiming` クラスのプロパティ:
| key                    | 説明                                                             |
| ---------------------- | ---------------------------------------------------------------- |
| `total_machine_time`   | Qulacs の使用によってかかった時間の総計                          |
| `total_execution_time` | 量子デバイスが実際に稼働していた時間の総計（待ち時間などを除く） |

`QiskitRunner` を用いた場合の {py:class}`~amplify_qaoa.runners.QiskitRunner.QiskitTiming` クラスのプロパティ:
| key                    | 説明                                                             |
|------------------------|------------------------------------------------------------------|
| `total_machine_time`   | Qiskit の使用によってかかった時間の総計                          |
| `total_execution_time` | 量子デバイスが実際に稼働していた時間の総計（待ち時間などを除く） |
| `qiskit_running_time`  | `tune` 関数のうち、 `qiskit` を呼び出していた時間の総計                  |
| `machine_running_time` | 量子デバイスが実際に稼働していた時間の総計（待ち時間などを除く）         |


例として、Qiskit を用いた場合の間時間の関係は以下の図のようになります。

![tune_time_taken](figure/tune_time_taken.jpg)

なお、 `QulacsRunner` を用いた場合、 Qulacs は実機を持たないシミュレーターのため、 `total_machine_time` 、 `machine_running_time` を除いた時間の辞書が返って来ます。

(tune_example)=
## `tune` 関数の実装
Amplify QAOA では `tune` 関数にハミルトニアンを与えることで、[QAOAの流れ](qaoa_steps) の Step2-Step4 に対応した工程によるパラメータの最適化を行うことができます。

```{code-cell} python
>>> from amplify_qaoa import QulacsRunner

>>> f_dict = {(0, 1): 1.0, (1, 2): 1.0, (0, 3): 1.0, (2, 3): 1.0}

>>> runner = QulacsRunner(reps=10, shots=1000)
>>> tune_result = runner.tune(f_dict=f_dict, optimizer="COBYLA")
```


`optimizer` は Step4 で古典最適化を行う際のアルゴリズムを指定します。
現在 [scipy.optimize.minimize](https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.minimize.html) で取り扱い可能なものに対応しています。

得られた `tune_result` から以下のようにして最適化されたパラメータを取得できます。

```{code-cell} python
>>> print(tune_result.opt_params)
```

また、パラメータがどのような変遷で最適化されたのかを以下のように確認することができます。

```{code-cell} python
>>> print(tune_result.params_history)
```

`tune` 関数の結果から得られるパラメータの値は、`measure` 関数の `parameters` に渡すことによって、与えたパラメータに基づいた測定結果を得ることができます。
