# Changelog

## v0.6.0 (Feb. 26, 2026)

*   Support client classes for Qiskit and Qulacs

## v0.5.0 (Nov. 25, 2025)

*   Enable specification of the URL for the quantum device API endpoint.
*   Add support for configuring a proxy server for API requests.
