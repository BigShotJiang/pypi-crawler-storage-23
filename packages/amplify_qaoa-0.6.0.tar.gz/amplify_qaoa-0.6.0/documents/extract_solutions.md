---
jupytext:
  text_representation:
    extension: .md
    format_name: myst
    format_version: 4.0.0
    jupytext_version: 1.16.4
kernelspec:
  display_name: Python 3
  language: python
  name: python3
---

(sample_sols)=
# 候補解の抽出（`run` 関数）

ここでは Amplify QAOA で組合せ最適解の求解を行う方法を解説します。

## `run` 関数

Amplify QAOA のランナーには `run` 関数が用意されており、この関数にハミルトニアン `f_dict` を渡すと、[QAOA の流れ](qaoa_steps) の Step2-Step6 の工程が実行され、最適解の候補を求めることができます。`run` 関数の中では、まず `tune` 関数により Ansatz 回路のパラメータの最適化を行い（Step2 - Step5）、そのパラメータを用いて `measure` 関数により測定を行い解の候補を取得します（Step6）。詳細については [`run`関数の概要](run_func_description) を参照してください。

以下の例を参考に Amplify QAOA の `run` 関数についての詳細を解説します。

```{card} Sample Problem
:width: 55%
:margin: 3 3 auto auto
目的関数
:   $$
    \text{minimize:} \quad f = s_0 s_1 + s_1 s_2 + s_2s_0 + 1
    $$

決定変数
:   $$
    s_0, s_1, s_2 \in \{-1, 1\}
    $$

制約条件
:   $$
    (s_0, s_1, s_2) &= (-1, 1, 1)\;\text{or} \; (1, -1, 1)\; \text{or} \; (1, -1, 1) \\
    s_0 &= -1
    $$
```

この問題の最適解は $(s_0, s_1, s_2) = (-1, 1, 1)$ となり、目的関数の値は 0 となります。

Amplify QAOA で上記の問題の候補解を取得します。
まず、目的関数 `f_dict` を定義し、ランナーの設定を行います。`f_dict` と 適切な制約条件の表現を `run` 関数に渡し求解を実行します。
$s_0, s_1, s_2$ のうちただ一つだけが -1 となる one-hot 制約は `group_list=[[0, 1, 2]]` で指定します。さらに $s_0=-1$ の制約は `init_ones=[0]` により指定できます。

```{code-cell} python
>>> from amplify_qaoa import QulacsRunner

# 目的関数を定義
>>> f_dict = {(): 1.0, (0, 1): 1.0, (1, 2): 1.0, (2, 0): 1.0}

# ランナーの設定
>>> runner = QulacsRunner(reps=10, shots=1000)

# run 関数を実行
>>> result = runner.run(f_dict=f_dict, group_list=[[0, 1, 2]], init_ones=[0])
```

`run` 関数実行の結果 `result` から、`counts` を用いて、どの解が何回観測されたかに関する情報を取得することができます。

```{code-cell} python
>>> print(result.counts)
```

得られたリストの各要素はタプルになっており、タプルの最初の要素は得られた解の変数の値で、次の要素はその解が観測された回数です。`shots` を1000回とした測定のうち最も高い頻度で観測された `[-1, 1, 1]` が最も有力な最適解の候補となるので、$(s_0, s_1, s_2)=(-1, 1, 1)$ がこの実行で得られた最適解となります。

`run` 関数の結果には途中の過程で `tune` 関数で行われたパラメータの最適化に関する情報も含まれています。最適化されたパラメータは `result.opt_params` で、最適化の仮定でどのようにパラメータが遷移したかは `result.params_history` によって確認することができます。

実行時間に関しては、パラメータの最適化（`tune`関数部分の実行）に要した時間は `result.tune_timing`、測定（`measure` 関数部分の実効）に要した時間は `result.measure_timing` によって取得することができます。

## 入力
|     引数     | 説明                                                                                                                                        |
| :----------: | :------------------------------------------------------------------------------------------------------------------------------------------ |
|   `f_dict`   | イジング変数を key とし、係数を value とする辞書                                                                                            |
| `group_list` | 各リストの要素として One-hot 制約を課したい変数のリストを与えます。リストの各要素で与えられた変数のリストのうち、1 つだけが -1 になります。 |
| `init_ones`  | 値を -1 として初期化したい変数のリストを与えます。                                                                                          |
| `parameters` | float のリストでパラメータの値を与えます。`tune` 関数の結果の `opt_params` を用いると、最適化されたパラメータを渡すことができます。         |
| `qaoa_type`  | デフォルトでは `QaoaAnsatzType.Original`                                                                                                    |
## 戻り値

`run` 関数の戻り値は {py:class}`~amplify_qaoa.runners._results.RunResult` クラスで、以下のプロパティを持ちます。

|       key        | 説明                                                                                                                    |
| :--------------: | :---------------------------------------------------------------------------------------------------------------------- |
|    `opt_val`     | `tune` 関数での最適化後のコスト関数の値 $C(\theta^{\textup{opt}})$                                                      |
|   `opt_params`   | `tune` 関数での最適化後のパラメータの値 $\theta^{\textup{opt}}$                                                         |
|     `evals`      | `tune` 関数での古典最適化にかかったコスト関数の総評価                                                                   |
| `params_history` | `tune` 関数の最適化各ステップにおけるパラメータ $\theta$ の履歴                                                         |
|  `tune_timing`   | `tune` 関数の各ステップにかかった時間に関する情報を格納した {py:class}`~amplify_qaoa.runners._timing.TuneTiming` クラス |
|   `group_list`   | 入力で与えた `group_list`                                                                                               |
|   `init_ones`    | 入力で与えた `init_ones`                                                                                                |
| `measure_timing` | `measure` 関数での測定の各ステップにかかった時間にに関する情報を格納した {py:class}`~amplify_qaoa.runners._timing.MeasureTiming` クラス                                                                        |
|     `counts`     | `measure` 関数でのサンプリングの結果                                                                                    |

````{note}
`run` 関数の `parameters` 引数に以下のようにして `tune` 関数の結果から `opt_params` を渡した場合は、戻り値には `counts` と `measure_timing` のみが渡されます。

```python
tune_result = runner.tune(f_dict)
result = runner.run(f_dict, parameters=tune_result.opt_params)
```

````

(run_func_description)=
## `run` 関数の概要
以下では、 `run` 関数の動作の概略を解説します。
`run` 関数の動作をまとめると以下のような図になります。

![run](figure/run.jpg)

`run` 関数では、まずパラメータの処理を行います。引数の `parameters` を与えない場合、 `run` 関数の内部で、`tune` 関数（[パラメータの最適化](param_opt)を参照）を用いて、最適化されたパラメータを取得します。`parameters` で明示的にパラメータが与えられた場合はそのパラメータを用います。

 `run` 関数の中枢をなすのは `measure` 関数（[測定](measure)を参照）です。
 `measure` 関数はハミルトニアン `f_dict` 、パラメータ $\theta$ をインプットとして受け取って、そのパラメータの下で Ansatz 状態 $\ket{\psi(\theta)}$ を構成し、計算基底測定の元でのサンプリング結果を出力します。
$\ket{\psi(\theta)}$ を計算基底で表示したとき、 $\ket{x}$ の係数が $\alpha$ なら、一回の試行で $x$ がサンプルされる確率は $|\alpha|^2$ となります。
サンプル数は「ランナー」が持つ `shots` で指定されています。
サンプル数が大きいほど統計誤差が小さくなっていき、得られる結果は Ansatz 状態 $\ket{\psi(\theta)}$ をよりよく反映したものになっていきます。
サンプリングされた候補解は `run` 関数の結果の `counts` で取得できます。最も測定された回数が多い解が最適な解であると考えられます。


### `tune` と `measure` 関数を用いた方法

`run` 関数は前節の概要部分で `tune` 関数と `measure` 関数からなることを説明しました。Amplify QAOA で問題を扱う際は、 `run` 関数を用いてパラメータの最適化のことを気にすることなく結果を取得する方法が最もスタンダードな方法と考えられます。しかし、場合によっては、ユーザーが特定のパラメータを用いて測定を行いたいというようなニーズも考えられます。

以下の例では、問題を解く際に `tune` 関数と `measure` 関数を別々に実行して、最適化されたパラメータを取得し、そのパラメータを用いて測定を行うというような方法を紹介します。


```{code-cell} python
>>> from amplify_qaoa import QiskitRunner

# ハミルトニアンを定義
>>> f_dict = {(0, 1): 1.0, (1, 2): 1.0, (0, 3): 1.0, (2, 3): 1.0}

 # ランナーの指定と設定
>>> runner = QiskitRunner(reps=10, shots=1000)

# tune 関数を実行
>>> tune_result = runner.tune(f_dict, optimizer="COBYLA")

# measure 関数を実行
>>> measure_result = runner.measure(
    f_dict=f_dict,
    parameters=tune_result.opt_params,
    group_list=tune_result.group_list,
    init_ones=tune_result.init_ones,
)
```

`tune_result.opt_params` から最適化されたパラメータを取得することができます。このパラメータを `measure` 関数の `parameters` に渡すことにより、最適パラメータに基づいた測定を行うことができます。

```{code-cell} python
>>> print(tune_result.opt_params)
```

`measure_result.counts` からは測定された候補解のリストを取得することができます。リストの各要素はタプルになっており、タプルの第一要素は候補解の変数の値で、次の要素はその解が測定された回数となります。

```{code-cell} python
>>> print(measure_result.counts)
```

上記の結果では1000回の測定のうち、$(s_0, s_1, s_2, s_3)=(-1, 1, -1, 1)$ と $(s_0, s_1, s_2, s_3)=(1, -1, 1, -1)$ がの二つの解がほぼ同等にほとんどの観測数を占めているので、これらが最も有力な解の候補となります。実際の解もこれらの二つの解となります。

