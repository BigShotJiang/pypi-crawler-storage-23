from amplify import ConstraintList, VariableGenerator, equal_to

from amplify_qaoa.algo.qaoa.run import run_qaoa
from amplify_qaoa.runner.qulacs import QulacsRunner

reps = 10
shots = 1000
qaoa = QulacsRunner()

print("Example1: MaxCut")
wires_1 = 4
gen = VariableGenerator()
s = gen.array("Ising", wires_1)
f_1 = s[0] * s[1] + s[1] * s[2] + s[0] * s[3] + s[2] * s[3]
run_result_1 = run_qaoa(qaoa, f_1, reps=reps, shots=shots)
print(f"measure_times = {run_result_1.measure_timing}")
print(f"counts = {run_result_1.counts}")

print("Example2: TSP with grouping")
wires_2 = 9
gen = VariableGenerator()
s = gen.array("Ising", wires_2)
f_2 = (
    2.4
    + s[0] * s[5] * 0.1
    + s[2] * s[3] * 0.1
    + s[1] * s[5] * 0.05
    + s[2] * s[7] * 0.05
    + s[2] * s[6] * 0.1
    + s[0] * s[8] * 0.1
    + s[5] * 0.5
    + s[1] * s[4] * 0.2
    + s[2] * 0.5
    + s[4] * 0.4
    + s[4] * s[7] * 0.2
    + s[6] * 0.5
    + s[5] * s[6] * 0.1
    + s[1] * 0.4
    + s[0] * s[7] * 0.05
    + s[0] * s[3] * 0.2
    + s[5] * s[7] * 0.05
    + s[3] * s[6] * 0.2
    + s[4] * s[8] * 0.05
    + s[0] * s[4] * 0.05
    + s[5] * s[8] * 0.2
    + s[3] * s[7] * 0.05
    + s[1] * s[8] * 0.05
    + s[1] * s[3] * 0.05
    + s[2] * s[8] * 0.2
    + s[1] * s[6] * 0.05
    + s[3] * 0.5
    + s[2] * s[4] * 0.05
    + s[0] * 0.5
    + s[0] * s[6] * 0.2
    + s[2] * s[5] * 0.2
    + s[3] * s[8] * 0.1
    + s[8] * 0.5
    + s[1] * s[7] * 0.2
    + s[4] * s[6] * 0.05
    + s[7] * 0.4
)
# group_list_2 = [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
constraints = ConstraintList()
constraints += equal_to(s[0:3], 1)
constraints += equal_to(s[3:6], 1)
constraints += equal_to(s[6:9], 1)

run_result_2 = run_qaoa(qaoa, f_2 + constraints, reps=reps, shots=shots)
print(f"measure_times = {run_result_2.measure_timing}")
print(f"counts = {run_result_2.counts}")

print("Example3: Artificial problem without grouping")
gen = VariableGenerator()
s = gen.array("Ising", 3)
f = (
    (1 + s[0]) * (1 + s[1]) / 4
    - (1 + s[1]) * (1 + s[2]) / 4
    + (1 + s[0]) * (1 + s[2]) / 4
    + (1 + s[0]) / 2
    - (1 + s[1]) / 2
    - (1 + s[2]) / 2
    - 1
)

run_result_3 = run_qaoa(qaoa, f, reps=reps, shots=shots)
print(f"measure_times = {run_result_3.measure_timing}")
print(f"counts = {run_result_3.counts}")

print("Example4: Add grouping to Example3")
# group_list_4 = [[0, 1, 2]]
constraints = ConstraintList()
constraints += equal_to(s[0:3], 1)
run_result_4 = run_qaoa(qaoa, f + constraints, reps=reps, shots=shots)
print(f"measure_times = {run_result_4.measure_timing}")
print(f"counts = {run_result_4.counts}")
