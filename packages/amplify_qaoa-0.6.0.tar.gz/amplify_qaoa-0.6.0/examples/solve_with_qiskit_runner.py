import os

from amplify import VariableGenerator

from amplify_qaoa.algo.qaoa.run import run_qaoa
from amplify_qaoa.runner.qiskit import QiskitRunner

AMPLIFY_QAOA_QISKIT_TEST_TOKEN = os.getenv("AMPLIFY_QAOA_QISKIT_TEST_TOKEN")
if AMPLIFY_QAOA_QISKIT_TEST_TOKEN is None:
    raise ValueError("Set the environment variable AMPLIFY_QAOA_QISKIT_TEST_TOKEN to run solve_with_qiskit.py.")


wires = 4
gen = VariableGenerator()
s = gen.array("Ising", wires)
f = s[0] * s[1] + s[1] * s[2] + s[0] * s[3] + s[2] * s[3]

reps = 10
shots = 2000
qaoa = QiskitRunner()
qaoa.device = "CPU"
qaoa.token = AMPLIFY_QAOA_QISKIT_TEST_TOKEN
qaoa.backend_name = "statevector"  # simulator method

run_result = run_qaoa(qaoa, f, reps=reps, shots=shots)
print(f"measure_timing = {run_result.measure_timing}")
print(f"counts = {run_result.counts}")
