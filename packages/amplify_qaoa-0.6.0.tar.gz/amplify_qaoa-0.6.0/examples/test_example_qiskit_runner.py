import os

from amplify import ConstraintList, VariableGenerator, equal_to

from amplify_qaoa.algo.qaoa.run import run_qaoa
from amplify_qaoa.runner.qiskit import QiskitRunner

AMPLIFY_QAOA_QISKIT_TEST_TOKEN = os.getenv("AMPLIFY_QAOA_QISKIT_TEST_TOKEN")
if AMPLIFY_QAOA_QISKIT_TEST_TOKEN is None:
    raise ValueError("Set the environment variable AMPLIFY_QAOA_QISKIT_TEST_TOKEN to run test_example_qiskit.py.")

reps = 10
shots = 1000
qaoa = QiskitRunner()
qaoa.device = "CPU"
qaoa.token = AMPLIFY_QAOA_QISKIT_TEST_TOKEN
qaoa.backend_name = "statevector"  # simulator method

print("Example1: MaxCut")
wires_1 = 4
gen = VariableGenerator()
s = gen.array("Ising", wires_1)
f_1 = s[0] * s[1] + s[1] * s[2] + s[0] * s[3] + s[2] * s[3]
run_result_1 = run_qaoa(qaoa, f_1, reps=reps, shots=shots)
print(f"measure_timing = {run_result_1.measure_timing}")
print(f"counts = {run_result_1.counts}")

print("Example2: Artificial problem with grouping")
gen = VariableGenerator()
s = gen.array("Ising", 3)
f_2 = (
    (1 + s[0]) * (1 + s[1]) / 4
    - (1 + s[1]) * (1 + s[2]) / 4
    + (1 + s[0]) * (1 + s[2]) / 4
    + (1 + s[0]) / 2
    - (1 + s[1]) / 2
    - (1 + s[2]) / 2
    - 1
)
wires_2 = 3
constraints = ConstraintList()
constraints += equal_to(s[0:3], 1)  # rhs 1 is (+1) * (3 - 1) + (-1) * 1
run_result_2 = run_qaoa(qaoa, f_2 + constraints, reps=reps, shots=shots)
print(f"group = {run_result_2.group_list}")
print(f"init_ones = {run_result_2.init_ones}")
print(f"measure_timing = {run_result_2.measure_timing}")
print(f"counts = {run_result_2.counts}")

print("Example3: Remove grouping from Example2")
run_result_3 = run_qaoa(qaoa, f_2, reps=reps, shots=shots)
print(f"group = {run_result_3.group_list}")
print(f"init_ones = {run_result_3.init_ones}")
print(f"measure_timing = {run_result_3.measure_timing}")
print(f"counts = {run_result_3.counts}")
