from amplify import VariableGenerator

from amplify_qaoa.algo.qaoa.run import run_qaoa
from amplify_qaoa.runner.qulacs import QulacsRunner

wires = 4
gen = VariableGenerator()
s = gen.array("Ising", wires)
f = s[0] * s[1] + s[1] * s[2] + s[0] * s[3] + s[2] * s[3]

reps = 10
shots = 1000
runner = QulacsRunner()

run_result = run_qaoa(runner, f, reps=reps, shots=shots)
print(f"measure_timing = {run_result.measure_timing}")
print(f"counts = {run_result.counts}")
