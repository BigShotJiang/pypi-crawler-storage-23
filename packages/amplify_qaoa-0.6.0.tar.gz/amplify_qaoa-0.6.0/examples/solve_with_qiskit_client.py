import os

from amplify import VariableGenerator, solve

from amplify_qaoa import QiskitQAOAClient

AMPLIFY_QAOA_QISKIT_TEST_TOKEN = os.getenv("AMPLIFY_QAOA_QISKIT_TEST_TOKEN")
if AMPLIFY_QAOA_QISKIT_TEST_TOKEN is None:
    raise ValueError("Set the environment variable AMPLIFY_QAOA_QISKIT_TEST_TOKEN to run solve_with_qiskit.py.")


wires = 4
gen = VariableGenerator()
s = gen.array("Ising", wires)
f = s[0] * s[1] + s[1] * s[2] + s[0] * s[3] + s[2] * s[3]

client = QiskitQAOAClient()
client.token = AMPLIFY_QAOA_QISKIT_TEST_TOKEN
client.parameters.runner.device = "CPU"
client.parameters.runner.backend_name = "statevector"  # simulator method
client.parameters.algo.reps = 10
client.parameters.algo.shots = 2000

run_result = solve(f, client)
print(f"response time  = {run_result.response_time}")
print(f"execution time = {run_result.execution_time}")
print(f"best sol = {run_result.best.values}, obj = {run_result.best.objective}")

assert isinstance(run_result.client_result, QiskitQAOAClient.Result)
print(f"counts = {run_result.client_result.counts}")
