from __future__ import annotations

from itertools import product
from typing import TYPE_CHECKING

import numpy as np
from amplify import ConstraintList, VariableGenerator, equal_to

from amplify_qaoa.algo.qaoa.run import run_qaoa
from amplify_qaoa.runner.qulacs import QulacsRunner

if TYPE_CHECKING:
    from amplify_qaoa.core.type import IsingDict


def is_satisfied_group_constraints(sol: list[int], group_list: list[list[int]]) -> bool:
    for group in group_list:
        filtered = [sol[i] for i in group]
        if filtered.count(-1) != 1:
            return False

    return True


def calculate_energy(f_dict: IsingDict, sol: list[int]) -> float:
    ret = 0.0

    for key, val in f_dict.items():
        tmp = val
        for i in key:
            tmp *= sol[i]
        ret += tmp

    return ret


reps = 10
shots = 1000

wires = 9
gen = VariableGenerator()
s = gen.array("Ising", wires)
f = (
    2.4
    + s[0] * s[5] * 0.1
    + s[2] * s[3] * 0.1
    + s[1] * s[5] * 0.05
    + s[2] * s[7] * 0.05
    + s[2] * s[6] * 0.1
    + s[0] * s[8] * 0.1
    + s[5] * 0.5
    + s[1] * s[4] * 0.2
    + s[2] * 0.5
    + s[4] * 0.4
    + s[4] * s[7] * 0.2
    + s[6] * 0.5
    + s[5] * s[6] * 0.1
    + s[1] * 0.4
    + s[0] * s[7] * 0.05
    + s[0] * s[3] * 0.2
    + s[5] * s[7] * 0.05
    + s[3] * s[6] * 0.2
    + s[4] * s[8] * 0.05
    + s[0] * s[4] * 0.05
    + s[5] * s[8] * 0.2
    + s[3] * s[7] * 0.05
    + s[1] * s[8] * 0.05
    + s[1] * s[3] * 0.05
    + s[2] * s[8] * 0.2
    + s[1] * s[6] * 0.05
    + s[3] * 0.5
    + s[2] * s[4] * 0.05
    + s[0] * 0.5
    + s[0] * s[6] * 0.2
    + s[2] * s[5] * 0.2
    + s[3] * s[8] * 0.1
    + s[8] * 0.5
    + s[1] * s[7] * 0.2
    + s[4] * s[6] * 0.05
    + s[7] * 0.4
)
constraints = ConstraintList()
constraints += equal_to(s[0:3], 1)
constraints += equal_to(s[3:6], 1)
constraints += equal_to(s[6:9], 1)

qaoa = QulacsRunner()
run_result = run_qaoa(qaoa, f + constraints, reps=reps, shots=shots)
print(f"times = {run_result.measure_timing}")
print(f"counts = {run_result.counts}")

# find best solutions
best_sol_list = []
best_energy = 1000

f_dict: dict[tuple[int, int], float] = f.as_dict()  # type: ignore[reportAssignmentType]
group_list = [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
for sol in map(list, product([1, -1], repeat=wires)):
    if not is_satisfied_group_constraints(sol, group_list):
        continue

    energy = calculate_energy(f_dict, sol)
    if energy < best_energy:
        best_sol_list = [sol]
        best_energy = energy
    elif abs(energy - best_energy) < 1e-6:
        best_sol_list.append(sol)

# results contain optimal spin assignments
best_sol_frequency = 0
for sol in best_sol_list:
    correspond_counts = list(filter(lambda x: (np.array(x[0]) == np.array(sol)).all(), run_result.counts))
    assert len(correspond_counts) <= 1

    if len(correspond_counts) > 0:
        best_sol_frequency += correspond_counts[0][1]

# optimal solutions are majority
print(f"candidates of best solution: {best_sol_list}")
print(f"frequency of best solution: {best_sol_frequency}")
