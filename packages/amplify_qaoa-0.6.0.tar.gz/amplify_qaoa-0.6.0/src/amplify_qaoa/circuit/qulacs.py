# Copyright (c) Fixstars Corporation and Fixstars Amplify Corporation.
#
# This source code is licensed under the Apache2.0 license found in the
# LICENSE file in the root directory of this source tree.

from __future__ import annotations

from typing import TYPE_CHECKING

from qulacs import Observable, PauliOperator, QuantumCircuit
from typing_extensions import Self

from .base import CircuitProtocol, ObservableProtocol, SupportsAnsatz, SupportsCAnsatz, SupportsFullSim

if TYPE_CHECKING:
    from collections.abc import Iterable

    from amplify_qaoa.circuit.base import SupportsHam


class QulacsCircuit(CircuitProtocol):
    T_circuit = QuantumCircuit
    T_obs = Observable

    class ObservableImpl(ObservableProtocol):
        def __init__(self, wires: int, _obs: Observable | None = None) -> None:
            if _obs:
                self._wires = wires
                self._obs = _obs
            else:
                self.init_obs(wires)

        @staticmethod
        def construct_observable(wires: int) -> QulacsCircuit.T_obs:
            return Observable(wires)

        def init_obs(self, wires: int) -> Self:
            self._wires = wires
            self._obs = QulacsCircuit.ObservableImpl.construct_observable(wires)
            return self

        @property
        def obs(self) -> QulacsCircuit.T_obs:
            return self._obs

        def add_pauli_x(self, wires: int, i: int, value: float) -> Self:
            _ = wires  # not used
            pauli_str = f"X {i}"
            self._obs.add_operator(PauliOperator(pauli_str, value))
            return self

        def add_z_gates(self, wires: int, li: Iterable[int], value: float) -> Self:
            _ = wires  # not used
            pauli_str = ""
            for i in li:
                if pauli_str != "":
                    pauli_str += " "
                pauli_str += f"Z {i}"

            self._obs.add_operator(PauliOperator(pauli_str, value))
            return self

    @classmethod
    def get_observable_class(cls) -> type[ObservableImpl]:
        return QulacsCircuit.ObservableImpl

    def __init__(self, wires: int) -> None:
        self.init_circuit(wires)

    @staticmethod
    def construct_quantum_circuit(wires: int) -> QulacsCircuit.T_circuit:
        return QuantumCircuit(wires)

    def init_circuit(self, wires: int) -> Self:
        self._wires = wires
        self._circuit = QulacsCircuit.construct_quantum_circuit(wires)
        return self

    @property
    def num_wires(self) -> int:
        return self._wires

    @property
    def circuit(self) -> QulacsCircuit.T_circuit:
        return self._circuit

    def add_measurement(self, qi: int) -> Self:
        # do nothing
        _ = qi
        return self

    def add_measurements_forall(self) -> Self:
        # do nothing
        return self

    def add_h_gate(self, i: int) -> Self:
        self.circuit.add_H_gate(i)
        return self

    def add_cnot_gate(self, i: int, j: int) -> Self:
        self.circuit.add_CNOT_gate(i, j)
        return self

    def add_x_gate(self, i: int) -> Self:
        self.circuit.add_X_gate(i)
        return self

    def add_rx_gate(self, i: int, value: float, wires: int) -> Self:
        op_x = Observable(wires)
        pauli_str = f"X {i}"
        op_x.add_operator(PauliOperator(pauli_str, 1.0))
        self.circuit.add_observable_rotation_gate(op_x, value, 1)
        return self

    def add_ry_gate(self, i: int, value: float) -> Self:
        self.circuit.add_RY_gate(i, value)
        return self

    def add_observable_rotation_gate(self, op_f: SupportsHam[QulacsCircuit.T_obs], value: float, wires: int) -> Self:
        _ = wires  # not used
        self.circuit.add_observable_rotation_gate(op_f.obs, value, 1)
        return self


# for type checking purposes
_1: type[CircuitProtocol] = QulacsCircuit
_2: type[SupportsAnsatz] = QulacsCircuit
_3: type[SupportsCAnsatz] = QulacsCircuit
_4: type[SupportsFullSim] = QulacsCircuit
_5: type[ObservableProtocol] = QulacsCircuit.ObservableImpl
_6: type[SupportsHam] = QulacsCircuit.ObservableImpl
