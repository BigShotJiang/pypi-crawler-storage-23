# Copyright (c) Fixstars Corporation and Fixstars Amplify Corporation.
#
# This source code is licensed under the Apache2.0 license found in the
# LICENSE file in the root directory of this source tree.

from __future__ import annotations

from typing import TYPE_CHECKING

from qiskit import QuantumCircuit
from qiskit.circuit import ClassicalRegister, QuantumRegister
from qiskit.circuit.library import PauliEvolutionGate
from qiskit.quantum_info import SparsePauliOp
from typing_extensions import Self

from .base import CircuitProtocol, ObservableProtocol

if TYPE_CHECKING:
    from collections.abc import Iterable

    from .base import SupportsAnsatz, SupportsCAnsatz, SupportsHam


class QiskitCircuit(CircuitProtocol):
    T_circuit = QuantumCircuit
    T_obs = SparsePauliOp

    class ObservableImpl(ObservableProtocol):
        def __init__(self, wires: int, _obs: SparsePauliOp | None = None) -> None:
            if _obs:
                self._wires = wires
                self._obs = _obs
            else:
                self.init_obs(wires)

        @staticmethod
        def construct_observable(wires: int) -> QiskitCircuit.T_obs:
            return 0 * SparsePauliOp("I" * wires)

        def init_obs(self, wires: int) -> Self:
            self._wires = wires
            self._obs = QiskitCircuit.ObservableImpl.construct_observable(wires)
            return self

        @property
        def obs(self) -> QiskitCircuit.T_obs:
            return self._obs

        def add_pauli_x(self, wires: int, i: int, value: float) -> Self:
            self._obs += value * SparsePauliOp("I" * (wires - i - 1) + "X" + "I" * i)
            return self

        def add_z_gates(self, wires: int, li: Iterable[int], value: float) -> Self:
            pauli_list = ["I"] * wires
            for i in li:
                pauli_list[i] = "Z"

            self._obs += value * SparsePauliOp(str.join("", pauli_list))
            return self

    @classmethod
    def get_observable_class(cls) -> type[ObservableImpl]:
        return QiskitCircuit.ObservableImpl

    def __init__(self, wires: int) -> None:
        self.init_circuit(wires)

    @staticmethod
    def construct_quantum_circuit(wires: int) -> QiskitCircuit.T_circuit:
        qreg = QuantumRegister(size=wires)
        creg = ClassicalRegister(size=wires, name="meas")
        return QuantumCircuit(qreg, creg)

    def init_circuit(self, wires: int) -> Self:
        self._wires = wires
        self._circuit = QiskitCircuit.construct_quantum_circuit(wires)
        return self

    @property
    def num_wires(self) -> int:
        return self._wires

    @property
    def circuit(self) -> QiskitCircuit.T_circuit:
        return self._circuit

    def add_measurement(self, qi: int | list[int], ci: int | list[int] | None = None) -> Self:
        if ci is None:
            ci = qi
        self.circuit.measure(qi, ci)
        return self

    def add_measurements_forall(self, inplace: bool = True, add_bits: bool = False) -> Self:
        self.circuit.measure_all(inplace=inplace, add_bits=add_bits)
        return self

    def add_h_gate(self, i: int) -> Self:
        self.circuit.h(i)
        return self

    def add_cnot_gate(self, i: int, j: int) -> Self:
        self.circuit.cx(i, j)
        return self

    def add_x_gate(self, i: int) -> Self:
        self.circuit.x(i)
        return self

    def add_rx_gate(self, i: int, value: float, wires: int) -> Self:
        _ = wires  # not used
        self.circuit.rx(value, i)
        return self

    def add_ry_gate(self, i: int, value: float) -> Self:
        self.circuit.ry(value, i)
        return self

    def add_observable_rotation_gate(self, op_f: SupportsHam[QiskitCircuit.T_obs], value: float, wires: int) -> Self:
        self.circuit.append(PauliEvolutionGate(op_f.obs, value), list(reversed(range(wires))))
        return self


# for type checking purposes
_1: type[CircuitProtocol] = QiskitCircuit
_2: type[SupportsAnsatz] = QiskitCircuit
_3: type[SupportsCAnsatz] = QiskitCircuit
_4: type[SupportsHam] = QiskitCircuit.ObservableImpl
