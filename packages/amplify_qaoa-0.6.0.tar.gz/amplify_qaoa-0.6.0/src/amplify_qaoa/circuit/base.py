# Copyright (c) Fixstars Corporation and Fixstars Amplify Corporation.
#
# This source code is licensed under the Apache2.0 license found in the
# LICENSE file in the root directory of this source tree.

from __future__ import annotations

import typing
from typing import TYPE_CHECKING, Generic, Protocol, TypeVar

from typing_extensions import Self

if TYPE_CHECKING:
    from collections.abc import Iterable

CircType = TypeVar("CircType")
ObsType = TypeVar("ObsType")

CircType_co = TypeVar("CircType_co", covariant=True)
ObsType_co = TypeVar("ObsType_co", covariant=True)


@typing.runtime_checkable
class ObservableProtocol(Protocol, Generic[ObsType_co]):
    @staticmethod
    def construct_observable(wires: int) -> ObsType_co: ...

    def __init__(self, wires: int) -> None: ...

    def init_obs(self, wires: int) -> Self: ...

    @property
    def obs(self) -> ObsType_co: ...


@typing.runtime_checkable
class SupportsHam(ObservableProtocol[ObsType_co], Protocol):
    def add_z_gates(self, wires: int, li: Iterable[int], value: float) -> Self: ...


@typing.runtime_checkable
class SupportsAnsatzObservable(SupportsHam[ObsType_co], Protocol):
    def add_pauli_x(self, wires: int, i: int, value: float) -> Self: ...


@typing.runtime_checkable
class CircuitProtocol(Protocol, Generic[CircType_co, ObsType_co]):
    @classmethod
    def get_observable_class(cls) -> type[ObservableProtocol[ObsType_co]]: ...

    @staticmethod
    def construct_quantum_circuit(wires: int) -> CircType_co: ...

    def __init__(self, wires: int) -> None: ...

    def init_circuit(self, wires: int) -> Self: ...

    def add_measurement(self, qi: int) -> Self: ...

    def add_measurements_forall(self) -> Self: ...

    @property
    def num_wires(self) -> int: ...

    @property
    def circuit(self) -> CircType_co: ...


@typing.runtime_checkable
class SupportsAnsatz(CircuitProtocol[CircType_co, ObsType], Protocol):
    @classmethod
    def get_observable_class(cls) -> type[SupportsAnsatzObservable[ObsType]]: ...

    def add_h_gate(self, i: int) -> Self: ...

    def add_observable_rotation_gate(
        self, op_f: SupportsAnsatzObservable[ObsType], value: float, wires: int
    ) -> Self: ...


@typing.runtime_checkable
class SupportsCAnsatz(CircuitProtocol[CircType_co, ObsType_co], Protocol):
    def add_cnot_gate(self, i: int, j: int) -> Self: ...

    def add_x_gate(self, i: int) -> Self: ...

    def add_rx_gate(self, i: int, value: float, wires: int) -> Self: ...

    def add_ry_gate(self, i: int, value: float) -> Self: ...


@typing.runtime_checkable
class SupportsFullSim(SupportsAnsatz[CircType_co, ObsType], SupportsCAnsatz[CircType_co, ObsType], Protocol): ...
