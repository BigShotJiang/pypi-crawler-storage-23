# Copyright (c) Fixstars Corporation and Fixstars Amplify Corporation.
#
# This source code is licensed under the Apache2.0 license found in the
# LICENSE file in the root directory of this source tree.

from __future__ import annotations

import dataclasses
from abc import ABC, abstractmethod
from datetime import timedelta
from operator import itemgetter
from typing import TYPE_CHECKING, Generic, TypeVar

from amplify import (
    AcceptableDegrees,
    ConstraintList,
    CustomClientProtocol,
    CustomClientResultProtocol,
    Matrix,
    Model,
    Poly,
)

from amplify_qaoa.__version__ import __version__
from amplify_qaoa.algo.base.protocol import AlgoProtocol
from amplify_qaoa.algo.qaoa.qaoa import QAOA
from amplify_qaoa.runner.qiskit import ChannelType, DeviceType, QiskitRunner, QiskitTiming

if TYPE_CHECKING:
    from qiskit.transpiler import PassManager

    from amplify_qaoa.algo.base.result import OptimizeHistory
    from amplify_qaoa.algo.qaoa.result import QAOARunResult


@dataclasses.dataclass
class QiskitBaseParameters:
    @dataclasses.dataclass
    class RunnerParameters:
        backend_name: str | None = None
        channel: ChannelType | None = None
        device: DeviceType = "CPU"
        qiskit_pass_manager: PassManager | None = None

    runner: RunnerParameters = dataclasses.field(default_factory=RunnerParameters)


AlgoType = TypeVar("AlgoType", bound=AlgoProtocol)
RunnerParamType = TypeVar("RunnerParamType", bound=QiskitBaseParameters)


class QiskitBaseClient(CustomClientProtocol, ABC, Generic[AlgoType, RunnerParamType]):
    __slots__ = ("_parameters", "proxy", "token", "url", "verify")

    def __init_subclass__(cls, /, Algo: type[AlgoType], Parameters: type[RunnerParamType]) -> None:  # noqa: N803
        cls.Parameters = Parameters
        cls.Algo = Algo
        return super().__init_subclass__()

    def __init__(
        self,
        token: str | None = None,
        url: str | None = None,
        proxy: str | None = None,
        verify: bool | None = None,
    ) -> None:
        self.token = token
        self.url = url
        self.proxy = proxy
        self.verify = verify
        self._parameters: RunnerParamType = self.Parameters()

    @property
    def parameters(self) -> RunnerParamType:
        return self._parameters

    @property
    def acceptable_degrees(self) -> AcceptableDegrees:
        return self.Algo.acceptable_degrees

    def _create_runner(self) -> QiskitRunner:
        return QiskitRunner(
            url=self.url,
            token=self.token,
            proxy=self.proxy,
            verify=self.verify,
            **dataclasses.asdict(self._parameters.runner),
        )

    @abstractmethod
    def version(self) -> str:
        raise NotImplementedError

    @abstractmethod
    def solve(
        self, objective: Poly | Matrix, constraints: ConstraintList | None = None, dry_run: bool = False
    ) -> CustomClientResultProtocol | None:
        raise NotImplementedError


@dataclasses.dataclass
class QiskitQAOAParameters(QiskitBaseParameters):
    algo: QAOA.Parameters = dataclasses.field(default_factory=QAOA.Parameters)


class QiskitQAOAClient(QiskitBaseClient[QAOA, QiskitQAOAParameters], Algo=QAOA, Parameters=QiskitQAOAParameters):
    class Result(CustomClientResultProtocol):
        def __init__(self, result: QAOARunResult[QiskitTiming]) -> None:
            self.params_history: list[OptimizeHistory[QiskitTiming]] = result.params_history
            self.solutions: list[tuple[list[float], timedelta]] = []
            self.response_time: timedelta = result.tune_timing.total_time + result.measure_timing.total_time

            # extract only the most frequent solutions from each of the results obtained during the tuning phase
            for history in self.params_history:
                best_solution = [float(x) for x in max(history.counts, key=itemgetter(1))[0]]
                exec_time = history.timestamp.total_execution_time or timedelta(0)
                self.solutions.append((best_solution, exec_time))

            # extract all solutions from the measurement phase
            solutions = {tuple(count[0]) for count in result.counts}
            for solution in solutions:
                self.solutions.append((list(map(float, solution)), self.response_time))

            self.execution_time: timedelta = (
                result.tune_timing.runner_timing.qiskit_running_time
                + result.measure_timing.runner_timing.qiskit_running_time
            )

            self.tune_timing = result.tune_timing
            self.measure_timing = result.measure_timing
            self.evals = result.evals
            self.opt_val = result.opt_val
            self.opt_params = result.opt_params
            self.group_list = result.group_list
            self.init_ones = result.init_ones
            self.counts = result.counts

        @property
        def _solutions(self) -> list[tuple[list[float], timedelta]]:
            return self.solutions

        @property
        def _response_time(self) -> timedelta:
            return self.response_time

        @property
        def _execution_time(self) -> timedelta:
            return self.execution_time

    def __init__(
        self,
        token: str | None = None,
        url: str | None = None,
        proxy: str | None = None,
        verify: bool | None = None,
    ) -> None:
        super().__init__(token, url, proxy, verify)

    def solve(
        self, objective: Poly | Matrix, constraints: ConstraintList | None = None, dry_run: bool = False
    ) -> QiskitQAOAClient.Result | None:
        model = Model(objective, constraints) if constraints is not None else Model(objective)

        runner = self._create_runner()
        result = self.Algo.run(runner, model, self.parameters.algo, dry_run=dry_run)

        if result is None:
            return None

        return QiskitQAOAClient.Result(result)

    def version(self) -> str:
        return __version__


# type check
_1: type[QiskitBaseClient] = QiskitQAOAClient
_2: type[CustomClientProtocol] = QiskitQAOAClient
_3: type[AlgoProtocol] = QiskitQAOAClient.Algo
_4: type[QAOA] = QiskitQAOAClient.Algo
_5: QAOA.Parameters = QiskitQAOAClient.Parameters().algo
