# Copyright (c) Fixstars Corporation and Fixstars Amplify Corporation.
#
# This source code is licensed under the Apache2.0 license found in the
# LICENSE file in the root directory of this source tree.

from __future__ import annotations

import dataclasses
from abc import ABC, abstractmethod
from datetime import timedelta
from operator import itemgetter
from typing import TYPE_CHECKING, Generic, TypeVar

from amplify import (
    AcceptableDegrees,
    ConstraintList,
    CustomClientProtocol,
    CustomClientResultProtocol,
    Matrix,
    Model,
    Poly,
)

from amplify_qaoa.__version__ import __version__
from amplify_qaoa.algo.base.protocol import AlgoProtocol
from amplify_qaoa.algo.qaoa.qaoa import QAOA
from amplify_qaoa.runner.qulacs import QulacsRunner, QulacsTiming

if TYPE_CHECKING:
    from amplify_qaoa.algo.base.result import OptimizeHistory
    from amplify_qaoa.algo.qaoa.result import QAOARunResult


@dataclasses.dataclass
class QulacsBaseParameters:
    @dataclasses.dataclass
    class RunnerParameters: ...

    runner: RunnerParameters = dataclasses.field(default_factory=RunnerParameters)


AlgoType = TypeVar("AlgoType", bound=AlgoProtocol)
RunnerParamType = TypeVar("RunnerParamType", bound=QulacsBaseParameters)


class QulacsBaseClient(CustomClientProtocol, ABC, Generic[AlgoType, RunnerParamType]):
    __slots__ = ("_parameters", "proxy", "token", "url", "verify")

    def __init_subclass__(cls, /, Algo: type[AlgoType], Parameters: type[RunnerParamType]) -> None:  # noqa: N803
        cls.Parameters = Parameters
        cls.Algo = Algo
        return super().__init_subclass__()

    def __init__(self) -> None:
        self._parameters: RunnerParamType = self.Parameters()

    @property
    def parameters(self) -> RunnerParamType:
        return self._parameters

    @property
    def acceptable_degrees(self) -> AcceptableDegrees:
        return self.Algo.acceptable_degrees

    def _create_runner(self) -> QulacsRunner:
        return QulacsRunner()

    @abstractmethod
    def version(self) -> str:
        raise NotImplementedError

    @abstractmethod
    def solve(
        self, objective: Poly | Matrix, constraints: ConstraintList | None = None, dry_run: bool = False
    ) -> CustomClientResultProtocol | None:
        raise NotImplementedError


@dataclasses.dataclass
class QulacsQAOAParameters(QulacsBaseParameters):
    algo: QAOA.Parameters = dataclasses.field(default_factory=QAOA.Parameters)


class QulacsQAOAClient(QulacsBaseClient[QAOA, QulacsQAOAParameters], Algo=QAOA, Parameters=QulacsQAOAParameters):
    class Result(CustomClientResultProtocol):
        def __init__(self, result: QAOARunResult[QulacsTiming]) -> None:
            self.params_history: list[OptimizeHistory[QulacsTiming]] = result.params_history
            self.solutions: list[tuple[list[float], timedelta]] = []
            self.response_time: timedelta = result.tune_timing.total_time + result.measure_timing.total_time

            # extract only the most frequent solutions from each of the results obtained during the tuning phase
            for history in self.params_history:
                best_solution = [float(x) for x in max(history.counts, key=itemgetter(1))[0]]
                exec_time = history.timestamp.total_execution_time or timedelta(0)
                self.solutions.append((best_solution, exec_time))

            # extract all solutions from the measurement phase
            solutions = {tuple(count[0]) for count in result.counts}
            for solution in solutions:
                self.solutions.append((list(map(float, solution)), self.response_time))

            self.execution_time: timedelta = (
                result.tune_timing.runner_timing.total_machine_time
                + result.measure_timing.runner_timing.total_machine_time
            )

            self.tune_timing = result.tune_timing
            self.measure_timing = result.measure_timing
            self.evals = result.evals
            self.opt_val = result.opt_val
            self.opt_params = result.opt_params
            self.group_list = result.group_list
            self.init_ones = result.init_ones
            self.counts = result.counts

        @property
        def _solutions(self) -> list[tuple[list[float], timedelta]]:
            return self.solutions

        @property
        def _response_time(self) -> timedelta:
            return self.response_time

        @property
        def _execution_time(self) -> timedelta:
            return self.execution_time

    def __init__(self) -> None:
        super().__init__()

    def solve(
        self, objective: Poly | Matrix, constraints: ConstraintList | None = None, dry_run: bool = False
    ) -> QulacsQAOAClient.Result | None:
        model = Model(objective, constraints) if constraints is not None else Model(objective)

        runner = self._create_runner()

        result = self.Algo.run(runner, model, self.parameters.algo, dry_run=dry_run)

        if result is None:
            return None

        return QulacsQAOAClient.Result(result)

    def version(self) -> str:
        return __version__


# type check
_1: type[QulacsBaseClient] = QulacsQAOAClient
_2: type[CustomClientProtocol] = QulacsQAOAClient
_3: type[AlgoProtocol] = QulacsQAOAClient.Algo
_4: type[QAOA] = QulacsQAOAClient.Algo
_5: QAOA.Parameters = QulacsQAOAClient.Parameters().algo
