# Copyright (c) Fixstars Corporation and Fixstars Amplify Corporation.
#
# This source code is licensed under the Apache2.0 license found in the
# LICENSE file in the root directory of this source tree.

from __future__ import annotations

import dataclasses
import logging
import time
from datetime import datetime, timedelta
from typing import TYPE_CHECKING, Literal, TypeAlias, get_args
from urllib.parse import urlparse

from qiskit.primitives import PrimitiveJob
from qiskit.providers import BackendV2
from qiskit.transpiler.preset_passmanagers import generate_preset_pass_manager
from qiskit_aer import AerSimulator
from qiskit_ibm_runtime import IBMBackend, QiskitRuntimeService
from qiskit_ibm_runtime import RuntimeJobV2 as RuntimeJob
from qiskit_ibm_runtime import SamplerV2 as Sampler
from qiskit_ibm_runtime.accounts import ChannelType
from qiskit_ibm_runtime.fake_provider import FakeProviderForBackendV2 as FakeProvider
from qiskit_ibm_runtime.fake_provider.fake_backend import FakeBackendV2

from amplify_qaoa.circuit.qiskit import QiskitCircuit

from .base import Runner, TimingBase

if TYPE_CHECKING:
    from qiskit.transpiler import PassManager

    from amplify_qaoa.core.type import IsingSeqFreqList

Channels: tuple[ChannelType, ...] = get_args(get_args(ChannelType)[0])
DeviceType: TypeAlias = Literal["CPU", "GPU", "QPU"]
Devices: tuple[DeviceType, ...] = get_args(DeviceType)
BackendType: TypeAlias = AerSimulator | IBMBackend | BackendV2 | FakeBackendV2


logger = logging.getLogger(__name__)


@dataclasses.dataclass
class QiskitTiming(TimingBase):
    qiskit_running_time: timedelta
    machine_running_time: timedelta


def _get_time_from_result(result_date: str | datetime) -> datetime:
    if type(result_date) is datetime:
        return result_date
    if isinstance(result_date, str):
        try:
            timestamp = datetime.strptime(result_date, "%Y-%m-%dT%H:%M:%S.%f").astimezone()
        except ValueError:
            timestamp = datetime.strptime(result_date, "%Y-%m-%dT%H:%M:%S").astimezone()

        return timestamp
    raise RuntimeError(f"{result_date} is not supported datetime format")


def decode_raw_result(raw_result: dict[str, int]) -> IsingSeqFreqList:
    """Decode the solution from the raw solution as list of pair of spin list and frequency.

    Args:
        raw_result (Dict[str, int]): the raw solution (bit string and frequency)

    Returns:
        list[Tuple[list[int], int]]: list of pair of spin (+1 or -1) list and frequency

    Examples:
        >>> raw_solution = {"0000": 10, "0001": 20, "0010": 30, "0011": 40}
        >>> decode_raw_result(raw_result)
        [([1, 1, 1, 1], 10), ([1, 1, 1, -1], 20), ([1, 1, -1, 1], 30), ([1, 1, -1, -1], 40)]
    """
    return [
        ([-1 if int(i) > 0 else 1 for i in reversed(assignments)], frequency)
        for assignments, frequency in raw_result.items()
    ]


class QiskitRunner(Runner[QiskitCircuit, QiskitTiming]):
    @classmethod
    def get_circuit_class(cls) -> type[QiskitCircuit]:
        return QiskitCircuit

    @property
    def provider(self) -> QiskitRuntimeService | None:
        if self._provider is not None:
            return self._provider

        if self._token is None:
            self._provider = None
            return None

        if self.proxy is not None:
            proxies = {"urls": {urlparse(self.url).scheme: self.proxy}}
            self._provider = QiskitRuntimeService(
                token=self._token, channel=self.channel, url=self.url, proxies=proxies, verify=self.verify
            )
        else:
            self._provider = QiskitRuntimeService(
                token=self._token, channel=self.channel, url=self.url, verify=self.verify
            )

        return self._provider

    @property
    def channel(self) -> ChannelType | None:
        return self._channel

    @channel.setter
    def channel(self, value: ChannelType | None) -> None:
        if value is not None and value not in Channels:
            raise ValueError(
                f"Specified channel type ({value}) is not supported. "
                f"Supported channels are: {', '.join(map(str, Channels))}"
            )

        if self._channel != value:
            self._backend = None
            self._provider = None

        self._channel = value

    @property
    def device(self) -> DeviceType:
        return self._device

    @device.setter
    def device(self, value: DeviceType) -> None:
        if value not in Devices:
            raise ValueError(
                f"Specified device type ({value}) is not supported. "
                f"Supported devices are: {', '.join(map(str, Devices))}"
            )

        if self._device != value:
            self._backend = None
            self._provider = None

        self._device = value

    @property
    def token(self) -> str | None:
        return self._token

    @token.setter
    def token(self, value: str | None) -> None:
        if self._token == value:
            return

        self._token = value
        self._backend = None
        self._provider = None

    @property
    def backend_name(self) -> str | None:
        return self._backend_name

    @backend_name.setter
    def backend_name(self, value: str | None) -> None:
        if self._backend_name != value:
            self._backend = None

        self._backend_name = value

    @property
    def backend(self) -> BackendType | None:
        return self._backend

    def __init__(
        self,
        backend_name: str | None = None,
        channel: ChannelType | None = None,
        device: DeviceType = "CPU",
        url: str | None = None,
        token: str | None = None,
        proxy: str | None = None,
        verify: bool | None = None,
        qiskit_pass_manager: PassManager | None = None,
    ) -> None:
        super().__init__()
        self._token: str | None = None
        self._provider: QiskitRuntimeService | None = None
        self._channel: ChannelType | None = None
        self._device: DeviceType = "CPU"
        self._backend_name: str | None = None
        self._backend: BackendType | None = None

        self.url = url
        self.proxy = proxy or None
        self.verify = verify
        self.backend_name = backend_name
        self.channel = channel
        self.device = device
        self.token = token
        self.qiskit_pass_manager = qiskit_pass_manager

    def init_runner(self, wires: int) -> None:
        # If backend is None, must load backend.
        # If wires is larger than the number of qubits of the current backend,
        # the backend can't be applied to the problem.
        # If token is available or backend is not specified, must update the least busy backend.
        # Otherwise, the current backend is also available to the Ising model.
        if (
            self._backend is not None
            and wires <= self._backend.num_qubits
            and (self._token is None or self._backend_name is not None)
        ):
            return

        if self._device in ["CPU", "GPU"]:
            if self._backend_name is not None:
                available_methods = AerSimulator().available_methods() or ()
                if self._backend_name in available_methods:
                    # Simulation of ideal machine with specified method
                    self._backend = AerSimulator(method=self.backend_name)
                elif self.provider is not None:
                    # Simulation of actual machine with specified backend
                    self._backend = AerSimulator.from_backend(self.provider.backend(name=self._backend_name))
                else:
                    # Simulation of ideal machine with specified backend
                    # If the prefix of backend_name is not "fake", replace the name of the machiene by "fake_machine".
                    backend_name = self.backend_name or ""
                    if backend_name[:4] == "fake":
                        fake_name = backend_name
                    else:
                        hyphen_index = backend_name.rfind("_")
                        if hyphen_index == -1:
                            if self.backend_name == "ibmqx2":
                                fake_name = "fake_yorktown"
                            elif self.backend_name == "ibmqx4":
                                fake_name = "fake_tenerife"
                            else:
                                raise RuntimeError("Specified backend name is not supported.")
                        else:
                            fake_name = "fake" + backend_name[hyphen_index:]
                        logger.warning(
                            f"You chose an option to perform simulations with a fake backend. In this case, the backend name must start with 'fake_'. The provided backend name '{self.backend_name}' was automatically changed to '{fake_name}' to comply with this rule."  # noqa: E501, G004
                        )
                    self._backend = FakeProvider().backend(fake_name)
            elif self.provider is not None:
                # Simulation of actual machine with least busy backend
                self._backend = AerSimulator.from_backend(
                    self.provider.least_busy(min_num_qubits=wires, simulator=False)
                )
            else:
                # Simulation of ideal machine with default simulator
                self._backend = AerSimulator(method="automatic")

            self._backend.set_options(device=self.device)
        else:  # self._device == "QPU"
            if self.provider is None:
                raise RuntimeError('Specified device is "QPU", but a token is not set.')
            if self._backend_name is not None:
                # Run an actual machine with specified backend
                self._backend = self.provider.backend(self._backend_name)
            else:
                # Run an actual machine with least busy backend
                self._backend = self.provider.least_busy(min_num_qubits=wires, simulator=False)

        # Check if the backend has enough qubits for the problem
        if wires > self._backend.num_qubits:
            raise RuntimeError(
                f"Specified backend ({self._backend_name}) does not have enough qubits "
                f"(required: {wires}, available: {self._backend.num_qubits})."
            )

    def observe(self, qc: QiskitCircuit.T_circuit, shots: int) -> tuple[IsingSeqFreqList, QiskitTiming]:
        init_time_cf = time.perf_counter()

        pm = self.qiskit_pass_manager
        if pm is None:
            pm = generate_preset_pass_manager(backend=self.backend)
        isa_qc = pm.run(qc)
        sampler = Sampler(self.backend)

        init_total_machine_time = datetime.now().astimezone()
        assert self.backend is not None
        job = sampler.run([isa_qc], shots=shots)
        counts_encoded = job.result()[0].data.meas.get_counts()
        assert isinstance(counts_encoded, dict)
        end_total_machine_time = datetime.now().astimezone()
        counts = decode_raw_result(counts_encoded)

        total_machine_time = (end_total_machine_time - init_total_machine_time).total_seconds()
        assert isinstance(total_machine_time, float), "total_machine_time must be float"

        if hasattr(job, "metrics") and callable(job.metrics):
            assert isinstance(job, (RuntimeJob, PrimitiveJob))
            metrics = job.metrics()
            timestamps = metrics["timestamps"]
            time_created = timestamps["created"]
            assert isinstance(time_created, (datetime, str))
            time_running = timestamps["running"]
            assert isinstance(time_running, (datetime, str))
            time_finished = timestamps["finished"]
            assert isinstance(time_finished, (datetime, str))
            total_machine_time = (
                _get_time_from_result(time_finished) - _get_time_from_result(time_created)
            ).total_seconds()
            assert isinstance(total_machine_time, float), "total_machine_time must be float"
            machine_running_time = (
                _get_time_from_result(time_finished) - _get_time_from_result(time_running)
            ).total_seconds()
            assert isinstance(machine_running_time, float), "machine_running_time must be float"
        else:
            machine_running_time = total_machine_time

        return counts, QiskitTiming(
            qiskit_running_time=timedelta(seconds=time.perf_counter() - init_time_cf),
            total_machine_time=timedelta(seconds=total_machine_time),
            machine_running_time=timedelta(seconds=machine_running_time),
            total_execution_time=None,
        )


_: type[Runner] = QiskitRunner  # for type checking purposes
