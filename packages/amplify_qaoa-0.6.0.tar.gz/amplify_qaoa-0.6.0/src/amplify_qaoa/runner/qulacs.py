# Copyright (c) Fixstars Corporation and Fixstars Amplify Corporation.
#
# This source code is licensed under the Apache2.0 license found in the
# LICENSE file in the root directory of this source tree.

from __future__ import annotations

import dataclasses
import time
from collections import Counter
from datetime import timedelta
from typing import TYPE_CHECKING

from qulacs import QuantumState

from amplify_qaoa.circuit.qulacs import QulacsCircuit

from .base import Runner, TimingBase

if TYPE_CHECKING:
    from amplify_qaoa.core.type import IsingSeqFreqList


@dataclasses.dataclass
class QulacsTiming(TimingBase): ...


def decode_solutions(raw_solution: dict[str, int]) -> IsingSeqFreqList:
    """Decode the solution from the raw solution as list of pair of spin list and frequency.

    Args:
        raw_solution (Dict[str, int]): the raw solution (bit string and frequency)

    Returns:
        IsingSeqFreqList: list of pair of spin (+1 or -1) list and frequency

    Examples:
        >>> raw_solution = {"0000": 10, "0001": 20, "0010": 30, "0011": 40}
        >>> decode_solutions(raw_solution)
        [([1, 1, 1, 1], 10), ([1, 1, 1, -1], 20), ([1, 1, -1, 1], 30), ([1, 1, -1, -1], 40)]
    """
    return [
        ([-1 if int(i) > 0 else 1 for i in reversed(assignments)], frequency)
        for assignments, frequency in raw_solution.items()
    ]


class QulacsRunner(Runner[QulacsCircuit, QulacsTiming]):
    @classmethod
    def get_circuit_class(cls) -> type[QulacsCircuit]:
        return QulacsCircuit

    def __init__(self) -> None:
        super().__init__()

    def init_runner(self, wires: int) -> None:
        _ = wires  # not used

    def observe(self, qc: QulacsCircuit.T_circuit, shots: int) -> tuple[IsingSeqFreqList, QulacsTiming]:
        init_time_cf = time.perf_counter()

        wires = qc.get_qubit_count()
        state = QuantumState(wires)
        qc.update_quantum_state(state)

        tune_qulacs_time = timedelta(seconds=time.perf_counter() - init_time_cf)

        samples = Counter(state.sampling(shots))
        z_basis = [format(i, "b").zfill(wires) for i in range(2**wires)]
        counts = {z_basis[i]: samples[i] for i in range(2**wires) if i in samples}

        return decode_solutions(counts), QulacsTiming(total_machine_time=tune_qulacs_time, total_execution_time=None)
