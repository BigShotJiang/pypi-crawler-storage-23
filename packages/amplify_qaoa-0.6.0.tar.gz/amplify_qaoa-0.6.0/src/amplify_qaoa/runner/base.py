# Copyright (c) Fixstars Corporation and Fixstars Amplify Corporation.
#
# This source code is licensed under the Apache2.0 license found in the
# LICENSE file in the root directory of this source tree.

from __future__ import annotations

import dataclasses
from typing import TYPE_CHECKING, Any, Generic, Protocol, TypeVar, runtime_checkable

from typing_extensions import Self

from amplify_qaoa.circuit.base import CircuitProtocol

if TYPE_CHECKING:
    from datetime import timedelta

    from amplify_qaoa.core.type import IsingSeqFreqList


@dataclasses.dataclass
class TimingBase:
    total_execution_time: timedelta | None
    total_machine_time: timedelta

    def __iadd__(self, other: Self) -> Self:
        if type(self) is not type(other):
            raise TypeError(f"Cannot add {type(self)} and {type(other)}")

        for field in dataclasses.fields(self):
            if field.name == "total_execution_time" and getattr(self, field.name) is None:
                setattr(self, field.name, getattr(other, field.name))
                continue

            setattr(self, field.name, getattr(self, field.name) + getattr(other, field.name))

        return self


TimingType = TypeVar("TimingType", bound=TimingBase)


CircType_co = TypeVar("CircType_co", bound=CircuitProtocol, covariant=True)
TimingType_co = TypeVar("TimingType_co", bound=TimingBase, covariant=True)


@runtime_checkable
class Runner(Protocol, Generic[CircType_co, TimingType_co]):
    @classmethod
    def get_circuit_class(cls) -> type[CircType_co]: ...

    def init_runner(self, wires: int) -> None: ...

    # qc is expected to be an object of circuit class wrapped by CircuitProtocol
    # i.e. qc: CircType_co.T_circuit
    def observe(self, qc: Any, shots: int) -> tuple[IsingSeqFreqList, TimingType_co]: ...  # noqa: ANN401
