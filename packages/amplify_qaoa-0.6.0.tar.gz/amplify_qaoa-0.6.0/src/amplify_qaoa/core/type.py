# Copyright (c) Fixstars Corporation and Fixstars Amplify Corporation.
#
# This source code is licensed under the Apache2.0 license found in the
# LICENSE file in the root directory of this source tree.

from typing import TypeAlias

CoeffType: TypeAlias = float
Symbols: TypeAlias = tuple[int, ...]
IsingDict: TypeAlias = dict[Symbols, CoeffType]
IsingSeqFreqList: TypeAlias = list[tuple[list[int], int]]
