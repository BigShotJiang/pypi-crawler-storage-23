# Copyright (c) Fixstars Corporation and Fixstars Amplify Corporation.
#
# This source code is licensed under the Apache2.0 license found in the
# LICENSE file in the root directory of this source tree.

from .algo.qaoa.utility import QaoaAnsatzType
from .client.qiskit import QiskitQAOAClient
from .client.qulacs import QulacsQAOAClient

try:
    from .__version__ import __version__
except ImportError:
    from importlib.metadata import PackageNotFoundError, version

    try:
        __version__ = version("amplify-qaoa")
    except PackageNotFoundError:
        __version__ = "unknown"

__all__ = [
    "QaoaAnsatzType",
    "QiskitQAOAClient",
    "QulacsQAOAClient",
]
