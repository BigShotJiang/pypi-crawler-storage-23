# Copyright (c) Fixstars Corporation and Fixstars Amplify Corporation.
#
# This source code is licensed under the Apache2.0 license found in the
# LICENSE file in the root directory of this source tree.

from __future__ import annotations

import dataclasses
from typing import TYPE_CHECKING, Generic

from amplify_qaoa.runner.base import TimingType

if TYPE_CHECKING:
    from amplify_qaoa.core.type import IsingSeqFreqList


@dataclasses.dataclass
class OptimizeHistory(Generic[TimingType]):
    parameters: list[float]
    timestamp: TimingType
    objective: float
    counts: IsingSeqFreqList
