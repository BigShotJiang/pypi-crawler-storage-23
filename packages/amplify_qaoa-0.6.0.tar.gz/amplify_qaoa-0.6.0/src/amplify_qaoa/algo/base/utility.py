# Copyright (c) Fixstars Corporation and Fixstars Amplify Corporation.
#
# This source code is licensed under the Apache2.0 license found in the
# LICENSE file in the root directory of this source tree.

from __future__ import annotations

import itertools
import warnings
from collections import Counter, defaultdict
from typing import TYPE_CHECKING

from amplify import Constraint, ConstraintList, Degree, Poly, VariableType
from scipy.optimize import minimize

if TYPE_CHECKING:
    from amplify_qaoa.core.type import IsingDict, IsingSeqFreqList


def count_qubits(f_dict: IsingDict, group_list: list[list[int]]) -> int:
    """Get the number of qubits required to solve the problem.

    Args:
        f_dict (IsingDict): Ising model
        group_list (list[list[int]]): constraints

    Returns:
        int: the number of qubits

    Examples:
        >>> f_dict = {(0, 1): 1.0, (1, 2): 1.0, (2, 3): 1.0, (3, 0): 1.0}
        >>> group_list = [[0, 1], [2, 3]]
        >>> count_qubits(f_dict, group_list)
        4
    """
    index_set: set[int] = set()

    for key in f_dict:
        index_set |= set(key)

    index_set |= set(itertools.chain.from_iterable(group_list))
    return max(index_set) + 1


def compute_function_value(f_dict: IsingDict, group_list: list[list[int]], counts: IsingSeqFreqList) -> float:
    f_val = 0.0
    stat_sum = 0.0

    for sol, stat in counts:
        if not is_satisfied_group_constraints(sol, group_list):
            continue
        stat_sum += stat

        for key, val in f_dict.items():
            tmp = val
            for i in key:
                tmp *= sol[i]
            f_val += tmp * stat

    if stat_sum == 0.0:
        return float("inf")

    return f_val / stat_sum


def reduce_degree(f_dict: IsingDict) -> IsingDict:
    reduced_f_dict: IsingDict = defaultdict(float)

    for key, value in f_dict.items():
        count = Counter(key)
        reduced_key = tuple(i for i, a in count.items() if a % 2 == 1)
        reduced_f_dict[reduced_key] += value

    return reduced_f_dict


def get_degree_per_type(poly: Poly) -> dict[VariableType, Degree]:
    degrees: dict[VariableType, Degree] = {}
    for symbols, _ in poly:
        deg: Degree = Degree(len(symbols)) if len(symbols) < Degree.HighOrder.value else Degree.HighOrder
        for symbol in symbols:
            var_type = symbol.type
            if var_type not in degrees:
                degrees[var_type] = deg
            else:
                degrees[var_type] = max(degrees[var_type], deg, key=lambda d: d.value)
    return degrees


def validate_poly(poly: Poly, degrees: dict[VariableType, Degree]) -> None:
    if poly.is_number():
        raise ValueError("The client cannot treat models with no variables")
    degs_poly = get_degree_per_type(poly)
    for var_type, deg in degs_poly.items():
        if deg.value > degrees.get(var_type, Degree.Zero).value:
            raise ValueError(
                "The degree of the given polynomial (either the objective or constraints) is too high to solve. "
            )


def poly_to_ising_dict(poly: Poly) -> IsingDict:
    inter = {}
    for symbols, coeff in poly:
        idxs = ()
        for symbol in symbols:
            idxs += (symbol.id,)
        inter[idxs] = coeff
    return inter


def create_ising_dict(
    poly: Poly, degrees: dict[VariableType, Degree], is_intermediate_model: bool = False
) -> IsingDict:
    if not is_intermediate_model:
        validate_poly(poly, degrees)
    return poly_to_ising_dict(poly)


def approx_eq(lhs: float, rhs: float, epsilon: float = 1e-10) -> bool:
    return lhs <= rhs + epsilon and rhs <= lhs + epsilon


def approx_int(value: float, epsilon: float = 1e-10) -> bool:
    floor_val = int(value // 1)
    return (value <= floor_val + epsilon) or (value + epsilon >= 1 + floor_val)


def get_constant(poly: Poly) -> float:
    return poly.as_dict().get((), 0)


def is_ising_linear_uniform_eq(constraint: Constraint) -> bool:
    if constraint.conditional[1] != "EQ":
        return False

    poly = constraint.conditional[0]
    front_term_coeff = None
    for symbols, coeff in poly:
        if len(symbols) == 1:
            front_term_coeff = coeff
            break

    if front_term_coeff is None:
        return all(len(symbols) == 0 for symbols, _ in poly)

    return all(
        (len(symbols) == 0)
        or (
            len(symbols) == 1
            and all(symbol.type == VariableType.Ising for symbol in symbols)
            and approx_eq(coeff, front_term_coeff)
        )
        for symbols, coeff in poly
    )


def get_ising_n_hot_value(constraint: Constraint) -> int | None:
    if not is_ising_linear_uniform_eq(constraint):
        return None
    poly = constraint.conditional[0]
    front_term_coeff = None
    for symbols, coeff in poly:
        if len(symbols) != 0:
            front_term_coeff = coeff
            break
    if front_term_coeff is None:
        return None

    assert isinstance(constraint.conditional[2], float)
    raw_eq_value = (constraint.conditional[2] - get_constant(constraint.conditional[0])) / front_term_coeff

    if not approx_int(raw_eq_value):
        return None

    eq_value = int(raw_eq_value)
    num_vars = len(poly) - (1 if get_constant(constraint.conditional[0]) > 0 else 0)

    if eq_value < -num_vars or num_vars < eq_value or ((num_vars - eq_value) % 2) == 1:
        return None

    return (num_vars + eq_value) // 2


def gather_disjoint_nhot_greedy(constraints: ConstraintList) -> tuple[list[list[int]], list[int], ConstraintList]:
    used_indices: set[int] = set()
    unused_constraints: ConstraintList = ConstraintList()

    n_hot_groups: list[list[int]] = []
    init_ones: list[int] = []
    for constraint in constraints:
        n_hot_value = get_ising_n_hot_value(constraint)
        if not n_hot_value:
            unused_constraints.append(constraint)
            continue
        indices: list[int] = [var.id for var in constraint.conditional[0].variables]
        is_used: bool = any(i in used_indices for i in indices)
        if is_used:
            unused_constraints.append(constraint)
            continue
        n_hot_groups.append(indices)
        init_ones.extend(indices[: len(indices) - n_hot_value])
        used_indices.update(indices)

    return n_hot_groups, init_ones, unused_constraints


# counts the number of function evaluations done in scipy.optimize.minimize()
def maxfun_lower_bound(method: str, num_vars: int) -> int:
    def dummy_func(_: list[float]) -> float:
        return 0.0

    dummy_x0 = [0] * num_vars
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        res = minimize(dummy_func, dummy_x0, method=method, options={"maxiter": 1})
    return res.nfev


def is_satisfied_group_constraints(sol: list[int], group_list: list[list[int]]) -> bool:
    for group in group_list:
        filtered = [sol[i] for i in group]
        if filtered.count(-1) != 1:
            return False

    return True
