# Copyright (c) Fixstars Corporation and Fixstars Amplify Corporation.
#
# This source code is licensed under the Apache2.0 license found in the
# LICENSE file in the root directory of this source tree.

from __future__ import annotations

import dataclasses
import logging
import random
import time
from collections.abc import Iterable
from copy import deepcopy
from datetime import timedelta
from typing import TYPE_CHECKING, Any, Literal, TypeGuard, TypeVar, overload

from amplify import Degree, Matrix, Model, Poly, VariableType
from scipy.optimize import minimize
from typing_extensions import TypedDict

from amplify_qaoa.circuit.base import SupportsAnsatz, SupportsAnsatzObservable, SupportsCAnsatz, SupportsHam

from ..base.result import OptimizeHistory
from ..base.utility import (
    compute_function_value,
    count_qubits,
    create_ising_dict,
    gather_disjoint_nhot_greedy,
    maxfun_lower_bound,
    reduce_degree,
)
from .result import (
    QAOAMeasureResult,
    QAOARunResult,
    QAOATuneResult,
)
from .timing import (
    QAOAMeasureTiming,
    QAOATuneTiming,
)
from .utility import (
    QaoaAnsatzType,
    QaoaAnsatzTypeFixed,
    get_required_num_params,
    select_qaoa_type,
)

if TYPE_CHECKING:
    from collections.abc import Callable

    from amplify_qaoa.core.type import IsingDict
    from amplify_qaoa.runner.base import Runner, TimingType


REPS_DEFAULT = 10
SHOTS_DEFAULT = 1024

logger = logging.getLogger(__name__)

ObsTypeHams_co = TypeVar("ObsTypeHams_co", bound=SupportsHam, covariant=True)


def generate_hamiltonian(obs_class: type[ObsTypeHams_co], f_dict: IsingDict, wires: int) -> ObsTypeHams_co:
    op_f = obs_class(wires)

    for key, value in f_dict.items():
        if len(set(key)) > 0:
            op_f.add_z_gates(wires, key, value)

    return op_f


CircTypeAnsatz_co = TypeVar("CircTypeAnsatz_co", bound=SupportsAnsatz, covariant=True)
ObsTypeAnsatz_co = TypeVar("ObsTypeAnsatz_co", bound=SupportsAnsatzObservable, covariant=True)


def qaoa_ansatz(
    circ_class: type[CircTypeAnsatz_co],
    reps: int,
    wires: int,
    parameters: list[float],
    f_dict: IsingDict,
) -> CircTypeAnsatz_co:
    op_f = generate_hamiltonian(circ_class.get_observable_class(), f_dict, wires)

    circuit = circ_class(wires)

    op_mixer = circ_class.get_observable_class()(wires)

    for i in range(wires):
        op_mixer.add_pauli_x(wires, i, 1.0)

        circuit.add_h_gate(i)

    for idx in range(reps):
        circuit.add_observable_rotation_gate(op_f, parameters[idx], wires)

        circuit.add_observable_rotation_gate(op_mixer, parameters[reps + idx], wires)

    return circuit


CircTypeCAnsatz_co = TypeVar("CircTypeCAnsatz_co", bound=SupportsCAnsatz, covariant=True)


def constrained_ansatz(
    circ_class: type[CircTypeCAnsatz_co],
    reps: int,
    wires: int,
    parameters: list[float],
    group_list: list[list[int]],
    init_ones: list[int],
) -> CircTypeCAnsatz_co:
    # Runner requirements:
    # * construct_quantum_circuit(wires)
    # * add_x_gate(circuit, i)
    # * add_cnot_gate(circuit, i, j)
    # * add_rx_gate(circuit, i, value, wires)
    # * add_ry_gate(circuit, i, value)
    not_grouped = set(range(wires))
    for group in group_list:
        not_grouped -= set(group)

    k = 0

    circuit = circ_class(wires)
    for i in init_ones:
        circuit.add_x_gate(i)

    for i in not_grouped:
        circuit.add_rx_gate(i, parameters[k], wires)

        k += 1

    for _ in range(reps):
        for group in group_list:
            m = len(group)
            for i in range(m // 2):
                a = 2 * i
                b = 2 * i + 1

                circuit.add_cnot_gate(group[a], group[b])
                circuit.add_ry_gate(group[a], parameters[k])
                circuit.add_cnot_gate(group[b], group[a])
                circuit.add_ry_gate(group[a], -parameters[k])
                circuit.add_cnot_gate(group[a], group[b])

                k += 1

            for i in range((m - 1) // 2):
                a = 2 * i + 1
                b = 2 * i + 2
                circuit.add_cnot_gate(group[a], group[b])
                circuit.add_ry_gate(group[a], parameters[k])
                circuit.add_cnot_gate(group[b], group[a])
                circuit.add_ry_gate(group[a], -parameters[k])
                circuit.add_cnot_gate(group[a], group[b])
                k += 1

    return circuit


def _typeguard_circ__class_cansatz(circ_class: Callable) -> TypeGuard[type[SupportsCAnsatz]]:
    circ_dummy = circ_class(1)
    return isinstance(circ_dummy, SupportsCAnsatz)


def _typeguard_circ__class_ansatz(circ_class: Callable) -> TypeGuard[type[SupportsAnsatz]]:
    circ_dummy = circ_class(1)
    return isinstance(circ_dummy, SupportsAnsatz)


CircTypeAnsatzOrCAnsatz_co = TypeVar(
    "CircTypeAnsatzOrCAnsatz_co", bound=SupportsAnsatz | SupportsCAnsatz, covariant=True
)


def construct_qaoa_circuit(
    circ_class: type[CircTypeAnsatzOrCAnsatz_co],
    reps: int,
    wires: int,
    parameters: list[float],
    qaoa_type: QaoaAnsatzTypeFixed,
    *,
    f_dict: IsingDict | None = None,
    group_list: list[list[int]] | None = None,
    init_ones: list[int] | None = None,
) -> CircTypeAnsatzOrCAnsatz_co:
    if qaoa_type == QaoaAnsatzType.Constrained:
        if not _typeguard_circ__class_cansatz(circ_class):
            raise TypeError("Protocol check failed.")
        assert group_list is not None
        assert init_ones is not None
        return constrained_ansatz(
            circ_class,
            reps=reps,
            wires=wires,
            parameters=parameters,
            group_list=group_list,
            init_ones=init_ones,
        )

    if qaoa_type == QaoaAnsatzType.Original:
        if not _typeguard_circ__class_ansatz(circ_class):
            raise TypeError("Protocol check failed.")
        assert f_dict is not None
        return qaoa_ansatz(
            circ_class,
            reps=reps,
            wires=wires,
            parameters=parameters,
            f_dict=f_dict,
        )

    raise ValueError("Invalid QaoaAnsatzType.")


class MinimizeOptions(TypedDict, total=False, extra_items=Any):
    disp: bool
    maxiter: int


@dataclasses.dataclass
class MinimizeParameters:
    method: str = "COBYLA"
    tol: float | None = None
    options: MinimizeOptions | None = None


def tune(
    runner: Runner[SupportsAnsatz | SupportsCAnsatz, TimingType],
    *,
    reps: int = REPS_DEFAULT,
    shots: int = SHOTS_DEFAULT,
    f_dict: IsingDict | None = None,
    group_list: list[list[int]] | None = None,
    init_ones: list[int] | None = None,
    initial_parameters: list[float] | None = None,
    qaoa_type: QaoaAnsatzType = QaoaAnsatzType.Auto,
    minimize_parameters: MinimizeParameters,
) -> QAOATuneResult[TimingType]:
    if f_dict is None:
        f_dict = {}
    if group_list is None:
        group_list = []
    if init_ones is None:
        init_ones = []

    init_tune_total_time = time.perf_counter()

    reduced_f_dict = reduce_degree(f_dict)
    wires = count_qubits(reduced_f_dict, group_list)

    runner.init_runner(wires)

    # Create init_one list
    if group_list != [] and init_ones == []:
        for group in group_list:
            init_ones += random.sample(group, 1)

    if qaoa_type == QaoaAnsatzType.Auto:
        qaoa_type = select_qaoa_type(group_list)

    # Create initial parameters
    if initial_parameters is None:
        num_params = get_required_num_params(f_dict, group_list, reps, qaoa_type)
        initial_parameters = [random.random() for _ in range(num_params)]  # noqa: S311

    parameter_values_history: list[OptimizeHistory[TimingType]] = []

    class CostFuncFunctor:
        def __init__(self) -> None:
            self.summed_timing = None

        def __call__(self, params_val: list[float]) -> float:
            qc = construct_qaoa_circuit(
                runner.get_circuit_class(),
                reps=reps,
                wires=wires,
                parameters=params_val,
                qaoa_type=qaoa_type,
                f_dict=reduced_f_dict,
                group_list=group_list,
                init_ones=init_ones,
            )

            qc.add_measurements_forall()

            counts, timing = runner.observe(qc.circuit, shots)

            func_val = compute_function_value(reduced_f_dict, group_list, counts)

            # Store the total execution time
            timing.total_execution_time = timedelta(seconds=time.perf_counter() - init_tune_total_time)

            if self.summed_timing is None:
                self.summed_timing = deepcopy(timing)
            else:
                self.summed_timing.total_execution_time = timedelta(0.0)
                self.summed_timing += timing
            assert self.summed_timing is not None

            parameter_values_history.append(
                OptimizeHistory(parameters=params_val, timestamp=timing, objective=func_val, counts=counts)
            )

            return func_val

    # Time count for minimize
    init_tune_minimize_time = time.perf_counter()
    cost_func = CostFuncFunctor()

    res = minimize(cost_func, initial_parameters, **dataclasses.asdict(minimize_parameters))

    assert cost_func.summed_timing is not None

    summed_timing: TimingType = cost_func.summed_timing
    tune_minimize_time = time.perf_counter() - init_tune_minimize_time

    resx = res["x"]
    opt_params = list(resx) if isinstance(resx, Iterable) else [resx]

    assert summed_timing is not None

    timing = QAOATuneTiming(
        total_time=timedelta(seconds=time.perf_counter() - init_tune_total_time),
        minimize_time=timedelta(seconds=tune_minimize_time),
        classical_opt_time=timedelta(seconds=tune_minimize_time) - summed_timing.total_machine_time,
        runner_timing=summed_timing,
    )
    resfun = res["fun"]
    return QAOATuneResult(
        evals=res["nfev"],
        tune_timing=timing,
        opt_val=list(resfun) if isinstance(resfun, Iterable) else [resfun],
        opt_params=opt_params,
        group_list=group_list,
        init_ones=init_ones,
        qaoa_type=qaoa_type,
        params_history=parameter_values_history,
    )


def measure(
    runner: Runner[SupportsAnsatz | SupportsCAnsatz, TimingType],
    f_dict: IsingDict,
    parameters: list[float],
    *,
    reps: int = REPS_DEFAULT,
    shots: int = SHOTS_DEFAULT,
    group_list: list[list[int]] | None = None,
    init_ones: list[int] | None = None,
    qaoa_type: QaoaAnsatzType = QaoaAnsatzType.Auto,
) -> QAOAMeasureResult[TimingType]:
    if group_list is None:
        group_list = []
    if init_ones is None:
        init_ones = []

    # Time count for tune function
    init_meas_total_time = time.perf_counter()

    wires = count_qubits(f_dict, group_list)

    runner.init_runner(wires)

    if qaoa_type == QaoaAnsatzType.Auto:
        qaoa_type = select_qaoa_type(group_list)

    qc = construct_qaoa_circuit(
        runner.get_circuit_class(),
        reps=reps,
        wires=wires,
        parameters=parameters,
        f_dict=f_dict,
        group_list=group_list,
        init_ones=init_ones,
        qaoa_type=qaoa_type,
    )

    qc.add_measurements_forall()

    counts, runner_timing = runner.observe(qc.circuit, shots)

    meas_total_time = timedelta(seconds=time.perf_counter() - init_meas_total_time)

    runner_timing.total_execution_time = meas_total_time

    meas_time_taken = QAOAMeasureTiming(total_time=meas_total_time, runner_timing=runner_timing)

    return QAOAMeasureResult(counts, meas_time_taken, qaoa_type)


@overload
def run_qaoa(
    runner: Runner[SupportsAnsatz | SupportsCAnsatz, TimingType],
    model: Model | Poly | Matrix,
    reps: int = REPS_DEFAULT,
    shots: int = SHOTS_DEFAULT,
    qaoa_type: QaoaAnsatzType = QaoaAnsatzType.Auto,
    initial_parameters: list[float] | None = None,
    minimize_parameters: MinimizeParameters | None = None,
    dry_run: Literal[False] = False,
) -> QAOARunResult[TimingType]: ...


@overload
def run_qaoa(
    runner: Runner[SupportsAnsatz | SupportsCAnsatz, TimingType],
    model: Model | Poly | Matrix,
    reps: int,
    shots: int,
    qaoa_type: QaoaAnsatzType,
    initial_parameters: list[float] | None,
    minimize_parameters: MinimizeParameters | None = None,
    dry_run: Literal[True] = True,
) -> None: ...


def run_qaoa(
    runner: Runner[SupportsAnsatz | SupportsCAnsatz, TimingType],
    model: Model | Poly | Matrix,
    reps: int = REPS_DEFAULT,
    shots: int = SHOTS_DEFAULT,
    qaoa_type: QaoaAnsatzType = QaoaAnsatzType.Auto,
    initial_parameters: list[float] | None = None,
    minimize_parameters: MinimizeParameters | None = None,
    dry_run: bool = False,
) -> QAOARunResult[TimingType] | None:
    if isinstance(model, Poly | Matrix):
        model = Model(model)

    # detect n-hot constraints
    n_hot_groups, init_ones, unused_constraint = gather_disjoint_nhot_greedy(model.constraints)

    # penalty terms for constraints that are not in the shape of n-hot
    penalty_poly = Poly()
    for c in unused_constraint:
        penalty_poly += c.penalty

    # objective function
    obj_poly = model.objective
    if isinstance(obj_poly, Matrix):
        obj_poly = obj_poly.to_poly()

    f_dict = create_ising_dict(obj_poly + penalty_poly, {VariableType.Ising: Degree.HighOrder})

    group_list = n_hot_groups

    if qaoa_type == QaoaAnsatzType.Auto:
        qaoa_type = select_qaoa_type(group_list)

    minimize_parameters = deepcopy(minimize_parameters) or MinimizeParameters()

    num_params = get_required_num_params(f_dict, group_list, reps, qaoa_type)

    if minimize_parameters.options is not None:
        maxiter = minimize_parameters.options.get("maxiter")
        if maxiter is not None:
            if maxiter <= 0:
                raise ValueError("maxiter must be a positive integer.")
            method = minimize_parameters.method
            maxiter_tune_lb = maxfun_lower_bound(method, num_params)
            # saves 1 for the measurement after tuning
            maxiter_tune = maxiter - 1
            if maxiter_tune < maxiter_tune_lb:
                raise RuntimeError(
                    f"Given the input ({method = }, {reps = }, {group_list = }, {qaoa_type = }), "
                    f"maxiter must be set at least {maxiter_tune_lb + 1}. "
                    "Please consider setting a smaller reps or larger maxiter."
                )
            minimize_parameters.options["maxiter"] = maxiter_tune

    if initial_parameters is not None:
        if len(initial_parameters) < num_params:
            raise RuntimeError(
                f"Length of initial_parameters must be at least {num_params}, but got {len(initial_parameters)}."
            )
        if len(initial_parameters) > num_params:
            logger.warning(
                "Length of initial_parameters is too long (given: %d, required: %d). "
                "Only the first %d parameters will be used.",
                len(initial_parameters),
                num_params,
                num_params,
            )
            initial_parameters = initial_parameters[:num_params]

    if dry_run:
        return None

    tune_result = tune(
        runner,
        reps=reps,
        shots=shots,
        f_dict=f_dict,
        group_list=group_list,
        init_ones=init_ones,
        initial_parameters=initial_parameters,
        qaoa_type=qaoa_type,
        minimize_parameters=minimize_parameters,
    )
    parameters = tune_result.opt_params
    group_list = tune_result.group_list
    init_ones = tune_result.init_ones

    measure_result = measure(
        runner,
        reps=reps,
        shots=shots,
        f_dict=f_dict,
        parameters=parameters,
        group_list=group_list,
        init_ones=init_ones,
        qaoa_type=qaoa_type,
    )

    return QAOARunResult(measure_result, tune_result)
