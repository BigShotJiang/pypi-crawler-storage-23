# Copyright (c) Fixstars Corporation and Fixstars Amplify Corporation.
#
# This source code is licensed under the Apache2.0 license found in the
# LICENSE file in the root directory of this source tree.

from __future__ import annotations

import dataclasses
from typing import TYPE_CHECKING, Generic

from amplify_qaoa.runner.base import TimingType

if TYPE_CHECKING:
    from amplify_qaoa.core.type import IsingSeqFreqList

    from ..base.result import OptimizeHistory
    from .timing import QAOAMeasureTiming, QAOATuneTiming
    from .utility import QaoaAnsatzTypeFixed


@dataclasses.dataclass
class QAOATuneResult(Generic[TimingType]):
    tune_timing: QAOATuneTiming[TimingType]
    evals: int
    opt_val: list[float]
    opt_params: list[float]
    group_list: list[list[int]]
    init_ones: list[int]
    qaoa_type: QaoaAnsatzTypeFixed
    params_history: list[OptimizeHistory[TimingType]]


@dataclasses.dataclass
class QAOAMeasureResult(Generic[TimingType]):
    counts: IsingSeqFreqList
    measure_timing: QAOAMeasureTiming[TimingType]
    qaoa_type: QaoaAnsatzTypeFixed


@dataclasses.dataclass(init=False)
class QAOARunResult(Generic[TimingType]):
    # QAOATuneResult
    tune_timing: QAOATuneTiming[TimingType]
    evals: int
    opt_val: list[float]
    opt_params: list[float]
    group_list: list[list[int]]
    init_ones: list[int]
    params_history: list[OptimizeHistory[TimingType]]

    # QAOAMeasureResult
    counts: IsingSeqFreqList
    measure_timing: QAOAMeasureTiming[TimingType]

    def __init__(self, measure_result: QAOAMeasureResult[TimingType], tune_result: QAOATuneResult[TimingType]) -> None:
        for key, value in measure_result.__dict__.items():
            setattr(self, key, value)

        for key, value in tune_result.__dict__.items():
            setattr(self, key, value)
