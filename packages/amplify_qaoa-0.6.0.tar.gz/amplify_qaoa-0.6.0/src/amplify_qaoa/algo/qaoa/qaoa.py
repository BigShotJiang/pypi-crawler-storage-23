# Copyright (c) Fixstars Corporation and Fixstars Amplify Corporation.
#
# This source code is licensed under the Apache2.0 license found in the
# LICENSE file in the root directory of this source tree.

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal, overload

from amplify import AcceptableDegrees, Model, Poly

from amplify_qaoa.algo.qaoa.run import MinimizeParameters

from ..base.protocol import AlgoProtocol
from .run import REPS_DEFAULT, SHOTS_DEFAULT, run_qaoa
from .utility import QaoaAnsatzType

if TYPE_CHECKING:
    from amplify_qaoa.circuit.base import SupportsAnsatz, SupportsCAnsatz
    from amplify_qaoa.runner.base import Runner, TimingType

    from .result import QAOARunResult


class QAOA(AlgoProtocol):
    acceptable_degrees = AcceptableDegrees(objective={"Ising": "HighOrder"})

    @dataclass
    class Parameters(MinimizeParameters):
        reps: int = REPS_DEFAULT
        shots: int = SHOTS_DEFAULT
        qaoa_type: QaoaAnsatzType = QaoaAnsatzType.Auto
        initial_parameters: list[float] | None = None

    @overload
    @staticmethod
    def run(
        runner: Runner[SupportsAnsatz | SupportsCAnsatz, TimingType],
        model: Model | Poly,
        parameters: QAOA.Parameters,
        dry_run: Literal[False] = False,
    ) -> QAOARunResult[TimingType]: ...

    @overload
    @staticmethod
    def run(
        runner: Runner[SupportsAnsatz | SupportsCAnsatz, TimingType],
        model: Model | Poly,
        parameters: QAOA.Parameters,
        dry_run: Literal[True],
    ) -> None: ...

    @staticmethod
    def run(
        runner: Runner[SupportsAnsatz | SupportsCAnsatz, TimingType],
        model: Model | Poly,
        parameters: QAOA.Parameters,
        dry_run: bool = False,
    ) -> QAOARunResult[TimingType] | None:
        return run_qaoa(
            runner,
            model,
            reps=parameters.reps,
            shots=parameters.shots,
            qaoa_type=parameters.qaoa_type,
            initial_parameters=parameters.initial_parameters,
            minimize_parameters=MinimizeParameters(
                method=parameters.method,
                tol=parameters.tol,
                options=parameters.options,
            ),
            dry_run=dry_run,
        )
