# Copyright (c) Fixstars Corporation and Fixstars Amplify Corporation.
#
# This source code is licensed under the Apache2.0 license found in the
# LICENSE file in the root directory of this source tree.

from __future__ import annotations

import dataclasses
from typing import TYPE_CHECKING, Generic

from amplify_qaoa.runner.base import TimingType

if TYPE_CHECKING:
    from datetime import timedelta


@dataclasses.dataclass
class QAOATuneTiming(Generic[TimingType]):
    total_time: timedelta
    minimize_time: timedelta
    classical_opt_time: timedelta
    runner_timing: TimingType


@dataclasses.dataclass
class QAOAMeasureTiming(Generic[TimingType]):
    total_time: timedelta
    runner_timing: TimingType
