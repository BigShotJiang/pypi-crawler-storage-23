# Copyright (c) Fixstars Corporation and Fixstars Amplify Corporation.
#
# This source code is licensed under the Apache2.0 license found in the
# LICENSE file in the root directory of this source tree.

from __future__ import annotations

import itertools
from enum import Enum, auto
from typing import TYPE_CHECKING, Literal, TypeAlias

from typing_extensions import assert_never

from amplify_qaoa.algo.base.utility import count_qubits, reduce_degree

if TYPE_CHECKING:
    from amplify_qaoa.core.type import IsingDict


class QaoaAnsatzType(Enum):
    Original = auto()
    Constrained = auto()
    Auto = auto()


QaoaAnsatzTypeFixed: TypeAlias = Literal[QaoaAnsatzType.Original, QaoaAnsatzType.Constrained]


def get_required_num_params(
    f_dict: IsingDict, group_list: list[list[int]], reps: int, qaoa_type: QaoaAnsatzTypeFixed
) -> int:
    wires = count_qubits(reduce_degree(f_dict), group_list)

    # Prepare parameters
    match qaoa_type:
        case QaoaAnsatzType.Original:
            k = 2 * reps
        case QaoaAnsatzType.Constrained:
            not_grouped = set(range(wires)) - set(itertools.chain.from_iterable(group_list))
            k = sum(max(len(group) - 1, 0) for group in group_list) * reps
            k += len(not_grouped)
        case _ as unexpected:
            assert_never(unexpected)

    return k


def select_qaoa_type(
    group_list: list[list[int]] | None,
) -> QaoaAnsatzTypeFixed:
    if group_list is None:
        return QaoaAnsatzType.Original
    return QaoaAnsatzType.Constrained if len(group_list) > 0 else QaoaAnsatzType.Original
