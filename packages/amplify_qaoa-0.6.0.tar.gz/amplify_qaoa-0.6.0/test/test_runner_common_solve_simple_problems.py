from __future__ import annotations

from datetime import timedelta
from typing import TYPE_CHECKING

import numpy as np
import pytest
from amplify import VariableGenerator
from utility import check_run_result, ising_dict_to_model, runner_test_mark, runner_test_mark_no_heavy

from amplify_qaoa import QaoaAnsatzType
from amplify_qaoa.algo.base.result import OptimizeHistory
from amplify_qaoa.algo.base.utility import maxfun_lower_bound
from amplify_qaoa.algo.qaoa.result import QAOATuneResult
from amplify_qaoa.algo.qaoa.run import MinimizeParameters, measure, run_qaoa, tune
from amplify_qaoa.algo.qaoa.utility import get_required_num_params
from amplify_qaoa.runner.qiskit import QiskitRunner, QiskitTiming
from amplify_qaoa.runner.qulacs import QulacsRunner, QulacsTiming

if TYPE_CHECKING:
    from amplify_qaoa.core.type import IsingDict
    from amplify_qaoa.runner.base import Runner


@runner_test_mark
def test_run(runner: Runner, skip_check: bool) -> None:
    gen = VariableGenerator()
    s = gen.array("Ising", 2)
    f = s[0] * s[1] * -1.0 + 99.0
    shots = 2000
    reps = 3

    minimize_parameters = MinimizeParameters()
    if skip_check:
        num_params = get_required_num_params(f.as_dict(), [], reps, QaoaAnsatzType.Original)
        minimize_parameters.options = {"maxiter": maxfun_lower_bound("COBYLA", num_params) + 1}

    run_result = run_qaoa(runner, f, reps=reps, shots=shots, minimize_parameters=minimize_parameters)

    # assert result
    check_run_result(shots, f, [], run_result, skip_optimality_check=skip_check)


@runner_test_mark
def test_run_with_different_problems(runner: Runner, skip_check: bool) -> None:
    gen = VariableGenerator()
    s = gen.array("Ising", 2)
    f = s[0] * s[1] * -1.0 + 99.0
    shots = 2000
    reps = 3

    minimize_parameters = MinimizeParameters()
    if skip_check:
        num_params = get_required_num_params(f.as_dict(), [], reps, QaoaAnsatzType.Original)
        minimize_parameters.options = {"maxiter": maxfun_lower_bound("COBYLA", num_params) + 1}
    run_result = run_qaoa(runner, f, reps=reps, shots=shots, minimize_parameters=minimize_parameters)

    # assert result
    check_run_result(shots, f, [], run_result, skip_optimality_check=skip_check)

    gen = VariableGenerator()
    s = gen.array("Ising", 3)
    f = s[0] * s[1] + s[2] * 2.0

    if skip_check:
        num_params = get_required_num_params(f.as_dict(), [], reps, QaoaAnsatzType.Original)
        minimize_parameters.options = {"maxiter": maxfun_lower_bound("COBYLA", num_params) + 1}
    run_result = run_qaoa(runner, f, reps=reps, shots=shots, minimize_parameters=minimize_parameters)

    # assert result
    check_run_result(shots, f, [], run_result, skip_optimality_check=skip_check)

    gen = VariableGenerator()
    s = gen.array("Ising", 2)
    f = s[0] + s[1]

    if skip_check:
        num_params = get_required_num_params(f.as_dict(), [], reps, QaoaAnsatzType.Original)
        minimize_parameters.options = {"maxiter": maxfun_lower_bound("COBYLA", num_params) + 1}
    run_result = run_qaoa(runner, f, reps=reps, shots=shots, minimize_parameters=minimize_parameters)

    # assert result
    check_run_result(shots, f, [], run_result, skip_optimality_check=skip_check)


@runner_test_mark
def test_run_with_matrix(runner: Runner, skip_check: bool) -> None:
    gen = VariableGenerator()
    mat = gen.matrix("Ising", 2)
    q = mat.quadratic
    q[0, 1] = -1.0
    p = mat.linear
    p[0] = 1.0
    p[1] = 1.0
    mat.constant = 0
    shots = 2000
    reps = 3

    minimize_parameters = MinimizeParameters()
    if skip_check:
        num_params = get_required_num_params(mat.to_poly().as_dict(), [], reps, QaoaAnsatzType.Original)
        minimize_parameters.options = {"maxiter": maxfun_lower_bound("COBYLA", num_params) + 1}

    run_result = run_qaoa(runner, mat, reps=reps, shots=shots, minimize_parameters=minimize_parameters)

    # assert result
    check_run_result(shots, mat.to_poly(), [], run_result, skip_optimality_check=skip_check)


@runner_test_mark
def test_run_maxcut_without_grouping(runner: Runner, skip_check: bool) -> None:
    gen = VariableGenerator()
    s = gen.array("Ising", 4)
    f = s[0] * s[1] + s[1] * s[2] + s[0] * s[3] + s[2] * s[3]
    shots = 4000
    reps = 3

    minimize_parameters = MinimizeParameters()
    if skip_check:
        num_params = get_required_num_params(f.as_dict(), [], reps, QaoaAnsatzType.Original)
        minimize_parameters.options = {"maxiter": maxfun_lower_bound("COBYLA", num_params) + 1}
    run_result = run_qaoa(runner, f, reps=reps, shots=shots, minimize_parameters=minimize_parameters)

    # assert result
    check_run_result(shots, f, [], run_result, skip_optimality_check=skip_check)


@runner_test_mark
def test_run_tsp(runner: Runner, skip_check: bool) -> None:
    gen = VariableGenerator()
    s = gen.array("Ising", 9)
    f = (
        2.4
        + 0.1 * s[0] * s[5]
        + 0.1 * s[2] * s[3]
        + 0.05 * s[1] * s[5]
        + 0.05 * s[2] * s[7]
        + 0.1 * s[2] * s[6]
        + 0.1 * s[0] * s[8]
        + 0.5 * s[5]
        + 0.2 * s[1] * s[4]
        + 0.5 * s[2]
        + 0.4 * s[4]
        + 0.2 * s[4] * s[7]
        + 0.5 * s[6]
        + 0.1 * s[5] * s[6]
        + 0.4 * s[1]
        + 0.05 * s[0] * s[7]
        + 0.2 * s[0] * s[3]
        + 0.05 * s[5] * s[7]
        + 0.2 * s[3] * s[6]
        + 0.05 * s[4] * s[8]
        + 0.05 * s[0] * s[4]
        + 0.2 * s[5] * s[8]
        + 0.05 * s[3] * s[7]
        + 0.05 * s[1] * s[8]
        + 0.05 * s[1] * s[3]
        + 0.2 * s[2] * s[8]
        + 0.05 * s[1] * s[6]
        + 0.5 * s[3]
        + 0.05 * s[2] * s[4]
        + 0.5 * s[0]
        + 0.2 * s[0] * s[6]
        + 0.2 * s[2] * s[5]
        + 0.1 * s[3] * s[8]
        + 0.5 * s[8]
        + 0.2 * s[1] * s[7]
        + 0.05 * s[4] * s[6]
        + 0.4 * s[7]
    )
    group_list = [[0, 1, 2], [3, 4, 5], [6, 7, 8]]

    shots = 4000
    reps = 3

    minimize_parameters = MinimizeParameters()
    if skip_check:
        num_params = get_required_num_params(f.as_dict(), group_list, reps, QaoaAnsatzType.Constrained)
        minimize_parameters.options = {"maxiter": maxfun_lower_bound("COBYLA", num_params) + 1}

    run_result = run_qaoa(
        runner,
        ising_dict_to_model(f.as_dict(), group_list),
        reps=reps,
        shots=shots,
        minimize_parameters=minimize_parameters,
    )
    check_run_result(shots, f, group_list, run_result, skip_optimality_check=skip_check)


@runner_test_mark
def test_run_artificial_problem_without_grouping(runner: Runner, skip_check: bool) -> None:
    # Artificial problem without grouping
    gen = VariableGenerator()
    s = gen.array("Ising", 3)
    f = s[0] * s[1] + s[1] * s[2] * -1.0 + s[0] * s[2]
    shots = 4000
    reps = 3

    minimize_parameters = MinimizeParameters()
    if skip_check:
        num_params = get_required_num_params(f.as_dict(), [], reps, QaoaAnsatzType.Original)
        minimize_parameters.options = {"maxiter": maxfun_lower_bound("COBYLA", num_params) + 1}
    run_result = run_qaoa(runner, f, reps=reps, shots=shots, minimize_parameters=minimize_parameters)

    assert run_result.group_list == []
    check_run_result(shots, f, [], run_result, skip_optimality_check=skip_check)


@runner_test_mark
def test_run_artificial_problem_with_grouping(runner: Runner, skip_check: bool) -> None:
    # Add grouping to Example3
    gen = VariableGenerator()
    s = gen.array("Ising", 3)
    f = s[0] * s[1] + s[1] * s[2] * -1.0 + s[0] * s[2]
    group_list = [[0, 1, 2]]
    shots = 4000
    reps = 3

    minimize_parameters = MinimizeParameters()
    if skip_check:
        num_params = get_required_num_params(f.as_dict(), group_list, reps, QaoaAnsatzType.Constrained)
        minimize_parameters.options = {"maxiter": maxfun_lower_bound("COBYLA", num_params) + 1}
    run_result = run_qaoa(
        runner,
        ising_dict_to_model(f.as_dict(), group_list),
        reps=reps,
        shots=shots,
        minimize_parameters=minimize_parameters,
    )
    assert run_result.group_list == group_list
    assert run_result.init_ones is not None
    assert len(run_result.init_ones) == len(group_list)
    check_run_result(shots, f, group_list, run_result, skip_optimality_check=skip_check)


@runner_test_mark_no_heavy
def test_tune_param_val_history(runner: Runner, skip_check: bool) -> None:
    # not checking optimality anyway
    _ = skip_check

    # MaxCut without grouping
    f_dict: IsingDict = {(0, 1): 1.0, (1, 2): 1.0, (0, 3): 1.0, (2, 3): 1.0}
    shots = 4000
    reps = 3

    minimize_parameters = MinimizeParameters()
    if skip_check:
        num_params = get_required_num_params(f_dict, [], reps, QaoaAnsatzType.Original)
        minimize_parameters.options = {"maxiter": maxfun_lower_bound("COBYLA", num_params) + 1}

    tune_result = tune(runner, f_dict=f_dict, shots=shots, reps=reps, minimize_parameters=minimize_parameters)

    assert hasattr(tune_result, "params_history")
    assert isinstance(tune_result, QAOATuneResult)
    _HIST_ATTRS = ["counts", "objective", "parameters", "timestamp"]  # noqa: N806
    for hist in tune_result.params_history:
        assert isinstance(hist, OptimizeHistory)

        # check attributes
        for attr in _HIST_ATTRS:
            assert hasattr(hist, attr)

        # check counts
        assert isinstance(hist.counts, list)
        for count in hist.counts:
            assert isinstance(count, tuple)
            assert isinstance(count[0], list)
            assert set(count[0]) <= set({1, -1})
            assert isinstance(count[1], int)

        # check objective
        assert isinstance(hist.objective, float)

        # check parameters
        assert isinstance(hist.parameters, np.ndarray)

        # check timestamp
        timestamp = hist.timestamp
        for val in timestamp.__dict__.values():
            assert isinstance(val, timedelta)
        match runner:
            case QiskitRunner():
                assert isinstance(timestamp, QiskitTiming)
                assert set(timestamp.__dict__.keys()) == set(
                    {
                        "machine_running_time",
                        "qiskit_running_time",
                        "total_execution_time",
                        "total_machine_time",
                    }
                )
            case QulacsRunner():
                assert isinstance(timestamp, QulacsTiming)
                assert set(timestamp.__dict__.keys()) == set(
                    {
                        "total_execution_time",
                        "total_machine_time",
                    }
                )
            case _ as other:
                pytest.skip(f"Unknown runner type: {type(other)}")


@runner_test_mark_no_heavy
def test_qaoa_type(runner: Runner, skip_check: bool) -> None:
    # not checking optimality anyway
    _ = skip_check

    f_dict: IsingDict = {(0, 1): 1.0}
    shots = 128
    reps = 3

    minimize_parameters = MinimizeParameters()
    if skip_check:
        num_params = get_required_num_params(f_dict, [], reps, QaoaAnsatzType.Original)
        minimize_parameters.options = {"maxiter": maxfun_lower_bound("COBYLA", num_params) + 1}
    # Case: no group_list is given
    tune_res = tune(
        runner,
        shots=shots,
        reps=reps,
        f_dict=f_dict,
        minimize_parameters=minimize_parameters,
    )
    assert tune_res.qaoa_type == QaoaAnsatzType.Original

    opt_params = tune_res.opt_params

    measure_res = measure(
        runner,
        shots=shots,
        reps=reps,
        f_dict=f_dict,
        parameters=opt_params,
    )

    assert measure_res.qaoa_type == QaoaAnsatzType.Original

    measure_res = measure(
        runner,
        shots=shots,
        reps=reps,
        f_dict=f_dict,
        parameters=opt_params,
        qaoa_type=QaoaAnsatzType.Original,
    )
    assert measure_res.qaoa_type == QaoaAnsatzType.Original

    # Case: group_list is given
    group_list = [[0, 1]]

    tune_res = tune(
        runner,
        shots=shots,
        reps=reps,
        f_dict=f_dict,
        group_list=group_list,
        minimize_parameters=minimize_parameters,
    )
    assert tune_res.qaoa_type == QaoaAnsatzType.Constrained
    opt_params = tune_res.opt_params

    measure_res = measure(
        runner,
        shots=shots,
        reps=reps,
        f_dict=f_dict,
        group_list=group_list,
        parameters=opt_params,
    )
    assert measure_res.qaoa_type == QaoaAnsatzType.Constrained

    measure_res = measure(
        runner,
        shots=shots,
        reps=reps,
        f_dict=f_dict,
        group_list=group_list,
        parameters=opt_params,
        qaoa_type=QaoaAnsatzType.Constrained,
    )
    assert measure_res.qaoa_type == QaoaAnsatzType.Constrained
