from __future__ import annotations

from typing import TYPE_CHECKING

from utility import check_run_result, ising_dict_to_model, problems_mark_without_group, runner_test_mark

from amplify_qaoa.algo.base.utility import maxfun_lower_bound
from amplify_qaoa.algo.qaoa.run import MinimizeParameters, run_qaoa
from amplify_qaoa.algo.qaoa.utility import QaoaAnsatzType, get_required_num_params

if TYPE_CHECKING:
    from amplify_qaoa.core.type import IsingDict
    from amplify_qaoa.runner.base import Runner


@problems_mark_without_group
@runner_test_mark
def test_ising_model(f_dict: IsingDict, reps: int, runner: Runner, skip_check: bool) -> None:
    shots = 2048

    minimize_parameters = MinimizeParameters()
    if skip_check:
        num_params = get_required_num_params(f_dict, [], reps, QaoaAnsatzType.Original)
        minimize_parameters.options = {"maxiter": maxfun_lower_bound("COBYLA", num_params) + 1}
    run_result = run_qaoa(
        runner,
        ising_dict_to_model(f_dict),
        reps=reps,
        shots=shots,
        minimize_parameters=minimize_parameters,
    )

    check_run_result(shots, f_dict, [], run_result, skip_optimality_check=skip_check)
