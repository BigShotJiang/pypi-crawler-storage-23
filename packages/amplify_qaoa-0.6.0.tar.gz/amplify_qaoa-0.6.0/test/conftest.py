from __future__ import annotations

import pytest


def pytest_configure(config: pytest.Config) -> None:
    config.addinivalue_line("markers", "heavy: mark heavy test")
    config.addinivalue_line("markers", "qiskit: mark qiskit test")
    config.addinivalue_line("markers", "qulacs: mark qulacs test")

    # register assert rewrite
    pytest.register_assert_rewrite("utility")
