from __future__ import annotations

from collections import Counter
from datetime import timedelta
from itertools import product
from typing import TYPE_CHECKING, TypeAlias

import pytest
from amplify import ConstraintList, Matrix, Model, Poly, Result, VariableGenerator, VariableType, equal_to
from amplify import sum as amplify_sum
from config import QISKIT_TOKEN

from amplify_qaoa import QiskitQAOAClient, QulacsQAOAClient
from amplify_qaoa.algo.base.utility import is_satisfied_group_constraints
from amplify_qaoa.runner.qiskit import QiskitRunner
from amplify_qaoa.runner.qulacs import QulacsRunner

if TYPE_CHECKING:
    from amplify_qaoa.algo.qaoa.result import QAOARunResult
    from amplify_qaoa.core.type import IsingDict, IsingSeqFreqList
    from amplify_qaoa.runner.base import TimingType


runner_param_list = [
    pytest.param(QiskitRunner(), False, marks=pytest.mark.qiskit, id="QiskitRunner"),
    pytest.param(QulacsRunner(), False, marks=pytest.mark.qulacs, id="QulacsRunner"),
]


runner_test_mark = pytest.mark.parametrize(
    ("runner", "skip_check"),
    runner_param_list,
)

runner_test_mark_no_heavy = pytest.mark.parametrize(
    ("runner", "skip_check"),
    [param for param in runner_param_list if not any(mark.name == "heavy" for mark in param.marks)],
)

QAOAClientType: TypeAlias = QiskitQAOAClient | QulacsQAOAClient

client_qiskit_qaoa = QiskitQAOAClient(token=QISKIT_TOKEN)
client_qulacs_qaoa = QulacsQAOAClient()

client_test_mark = pytest.mark.parametrize(
    ("client", "skip_check"),
    [
        pytest.param(client_qiskit_qaoa, False, marks=pytest.mark.qiskit, id="QiskitQAOAClient"),
        pytest.param(client_qulacs_qaoa, False, marks=pytest.mark.qulacs, id="QulacsQAOAClient"),
    ],
)


problems_mark_without_group = pytest.mark.parametrize(
    ("f_dict", "reps"),
    [
        pytest.param({(0,): 1, (1,): 1}, 3, id="simple-primary-term"),
        pytest.param({(0, 1): 1, (2,): 2}, 3, id="simple-ising-model-1"),
        pytest.param({(0, 2): 1, (1,): -2}, 3, id="simple-ising-model-2"),
        pytest.param({(0, 1): -2, (0,): -1, (): 1}, 3, id="simple-ising-model-3"),
        pytest.param({(0, 1): -2, (0, 0): -1, (1, 1): 1, (): 1}, 3, id="duplicated-ising-model"),
        pytest.param({(0, 1, 2): 1, (1,): 1}, 3, id="3-order-term"),
        pytest.param({(0, 1, 2, 3): 1, (1,): 1}, 3, id="4-order-term"),
        pytest.param(
            {(0, 1, 1, 2, 2, 2): -2, (0, 0, 1, 2): -1, (1, 1, 1): 1, (): 1},
            8,
            marks=[pytest.mark.flaky(reruns=3, reruns_delay=1, only_rerun=["FlakyTestError"]), pytest.mark.heavy],
            id="duplicated-high-order-ising-model",
        ),
        pytest.param(
            {
                (0, 1, 2, 3, 4, 5, 6): 1,
                (0, 1, 2, 3): -1,
                (4, 5, 6): -1,
                (0, 1): 1,
                (2, 3): 1,
                (1,): 1,
            },
            15,
            marks=[pytest.mark.flaky(reruns=3, reruns_delay=1, only_rerun=["FlakyTestError"]), pytest.mark.heavy],
            id="6-order-ising-model",
        ),
        pytest.param(
            {
                (0, 1, 2, 3): 1,
                (0, 1, 2): -1,
                (0, 1, 3): 1,
                (0, 2, 3): 1,
                (1, 2, 3): 1,
                (0, 1): -1,
                (0, 2): -1,
                (0, 3): 1,
                (1, 2): 1,
                (1, 3): 1,
                (2, 3): 1,
                (1,): 1,
            },
            10,
            marks=[pytest.mark.flaky(reruns=3, reruns_delay=1, only_rerun=["FlakyTestError"]), pytest.mark.heavy],
            id="4-order-ising-model",
        ),
    ],
)


# 3-city-tsp is generated from
tsp_3_city_distance_table = [
    [0, 0.2, 0.4],
    [0.2, 0, 0.2],
    [0.4, 0.2, 0],
]

tsp_3_city_f_dict = {
    (): 2.4,
    (0, 5): 0.1,
    (2, 3): 0.1,
    (1, 5): 0.05,
    (2, 7): 0.05,
    (2, 6): 0.1,
    (0, 8): 0.1,
    (5,): 0.5,
    (1, 4): 0.2,
    (2,): 0.5,
    (4,): 0.4,
    (4, 7): 0.2,
    (6,): 0.5,
    (5, 6): 0.1,
    (1,): 0.4,
    (0, 7): 0.05,
    (0, 3): 0.2,
    (5, 7): 0.05,
    (3, 6): 0.2,
    (4, 8): 0.05,
    (0, 4): 0.05,
    (5, 8): 0.2,
    (3, 7): 0.05,
    (1, 8): 0.05,
    (1, 3): 0.05,
    (2, 8): 0.2,
    (1, 6): 0.05,
    (3,): 0.5,
    (2, 4): 0.05,
    (0,): 0.5,
    (0, 6): 0.2,
    (2, 5): 0.2,
    (3, 8): 0.1,
    (8,): 0.5,
    (1, 7): 0.2,
    (4, 6): 0.05,
    (7,): 0.4,
}
tsp_3_city_group_list = [[0, 1, 2], [3, 4, 5], [6, 7, 8]]


problems_mark_with_group = pytest.mark.parametrize(
    ("f_dict", "group_list", "reps"),
    [
        pytest.param({(0,): 1, (1,): 1, (2,): 1}, [[0, 1, 2]], 3, id="simple-one-hot"),
        pytest.param({(0, 1): -2, (0, 2): 1, (1, 2): 2}, [[0, 1]], 3, id="group-with-ungrouped"),
        pytest.param(
            tsp_3_city_f_dict,
            tsp_3_city_group_list,
            3,
            marks=pytest.mark.flaky(reruns=3, reruns_delay=1, only_rerun=["FlakyTestError"]),
            id="3-city-tsp",
        ),
        pytest.param({(0, 1, 2): -1}, [[0, 1, 2]], 3, id="3-order-one-hot"),
        pytest.param({(0, 1, 2, 3): -1}, [[0, 1], [2, 3]], 3, id="4-order-one-hot"),
        pytest.param({(0, 1, 2, 3): -1}, [[0, 1]], 3, id="4-order-group-with-ungrouped"),
        pytest.param(
            {
                (0, 1, 2, 3): -1,
                (0, 1): 1,
                (0, 2): -1,
                (0, 3): -1,
                (1, 2): 1,
                (0,): 5,
                (1,): 5,
            },
            [[0, 1]],
            3,
            id="4-order-one-hot-ising-model",
        ),
    ],
)


class FlakyTestError(Exception):
    """Raised when flaky test fails."""


def ising_dict_to_model(
    f_dict: IsingDict, group_list: list[list[int]] | None = None, init_ones: list[int] | None = None
) -> Model:
    gen = VariableGenerator()
    poly = Poly()
    # find the maximum index before generating variables
    max_index = 0
    for key in f_dict:
        if len(key) > 0:
            max_index = max(max_index, *key)
    for group in group_list or []:
        max_index = max(max_index, *group)

    s = gen.array("Ising", max_index + 1)

    for key, val in f_dict.items():
        if len(key) == 0:
            poly += val
        else:
            term = 1
            for i in key:
                term *= s[i]
            poly += val * term

    constraints: ConstraintList = ConstraintList()
    if group_list is not None:
        for group in group_list:
            num_negs = 0
            if init_ones is not None:
                for i in group:
                    if i in init_ones:
                        num_negs += 1
            else:
                num_negs = 1
            rhs = len(group) - 2 * num_negs
            constraints += equal_to(amplify_sum(s[i] for i in group), rhs)

    return Model(poly, constraints)


def calculate_energy(f_dict: IsingDict, sol: list[int]) -> float:
    ret = 0.0

    for key, val in f_dict.items():
        tmp = val
        for i in key:
            tmp *= sol[i]
        ret += tmp

    return ret


def compute_poly_value(poly: Poly, sol: list[int]) -> float:
    assert max(var.id for var in poly.variables) < len(sol)

    asgn_dict = {var: sol[var.id] for var in poly.variables}
    val = poly.substitute(asgn_dict)

    return float(val)


def result_to_solution_counts(result: Result) -> IsingSeqFreqList:
    freq_dict = Counter(tuple(solution.values.values()) for solution in result.solutions)
    return [(list(map(int, k)), v) for k, v in freq_dict.items()]


def check_result_counts(
    shots: int,
    cost_func: IsingDict | Poly | Matrix,
    group_list: list[list[int]],
    result_counts: IsingSeqFreqList,
    *,
    skip_optimality_check: bool = False,
) -> None:
    if isinstance(cost_func, Matrix):
        cost_func = cost_func.to_poly()

    # assert result
    sum_freq = 0
    for asgn, freq in result_counts:
        sum_freq += freq
        assert len(asgn) > 0  # spin assignments
        assert freq >= 1  # frequency

    assert shots == sum_freq

    # find best solutions
    best_sol_list = []
    best_energy = float("inf")

    # find # of wires
    wires = 0
    if isinstance(cost_func, dict):
        wires = max(max(key) for key in cost_func if len(key) > 0) + 1
    else:
        wires = max(var.id for var in cost_func.variables) + 1

    if len(group_list) > 0:
        wires = max(wires, max(max(group) for group in group_list) + 1)

    value_set = [1, -1]
    if isinstance(cost_func, Poly) and all(var.type == VariableType.Binary for var in cost_func.variables):
        value_set = [0, 1]

    if skip_optimality_check:
        return

    for sol_tup in product(value_set, repeat=wires):
        sol = list(sol_tup)
        if not is_satisfied_group_constraints(sol, group_list):
            continue

        energy = calculate_energy(cost_func, sol) if isinstance(cost_func, dict) else compute_poly_value(cost_func, sol)
        if abs(energy - best_energy) < 1e-6:
            best_sol_list.append(sol)
        elif energy < best_energy:
            best_sol_list = [sol]
            best_energy = energy

    # results contain optimal spin assignments
    best_sol_frequency = 0
    for sol in best_sol_list:
        correspond_counts = list(filter(lambda x: x[0] == list(sol), result_counts))
        assert len(correspond_counts) <= 1

        if len(correspond_counts) > 0:
            best_sol_frequency += correspond_counts[0][1]

    # optimal solutions are majority
    if not best_sol_frequency >= sum_freq / 2:
        raise FlakyTestError


def check_run_result(
    shots: int,
    cost_func: IsingDict | Poly,
    group_list: list[list[int]],
    result: QAOARunResult[TimingType],
    *,
    skip_optimality_check: bool = False,
) -> None:
    check_result_counts(shots, cost_func, group_list, result.counts, skip_optimality_check=skip_optimality_check)

    # assert measure timing
    assert result.measure_timing.total_time > timedelta(0.0)
    for k, v in result.measure_timing.runner_timing.__dict__.items():
        if k != "machine_running_time":
            assert v > timedelta(0.0)
        measure_total_execution_time = result.measure_timing.runner_timing.total_execution_time
        measure_total_machine_time = result.measure_timing.runner_timing.total_machine_time
        if measure_total_execution_time is not None:
            assert measure_total_execution_time > measure_total_machine_time

    # assert tune timing
    if result.tune_timing is not None:
        assert result.tune_timing.total_time > timedelta(0.0)
        assert result.tune_timing.minimize_time > timedelta(0.0)
        assert result.tune_timing.classical_opt_time > timedelta(0.0)
        assert (
            result.tune_timing.classical_opt_time + result.tune_timing.runner_timing.total_machine_time
            == result.tune_timing.minimize_time
        )
        for v in result.tune_timing.runner_timing.__dict__.values():
            assert v > timedelta(0.0)

        tune_total_execution_time = result.tune_timing.runner_timing.total_execution_time
        if tune_total_execution_time is not None:
            assert tune_total_execution_time < result.tune_timing.total_time

    # assert param history
    if result.params_history is not None:
        prev_total_execution_time = timedelta(0.0)
        # check TimingType has total_execution_time
        for history in result.params_history:
            current_total_execution_time = history.timestamp.total_execution_time
            if current_total_execution_time is not None:
                diff = current_total_execution_time - prev_total_execution_time
                assert diff > history.timestamp.total_machine_time
                prev_total_execution_time = current_total_execution_time
