from __future__ import annotations

from typing import TYPE_CHECKING

from utility import check_run_result, ising_dict_to_model, problems_mark_with_group, runner_test_mark

from amplify_qaoa.algo.base.utility import maxfun_lower_bound
from amplify_qaoa.algo.qaoa.run import MinimizeParameters, run_qaoa
from amplify_qaoa.algo.qaoa.utility import QaoaAnsatzType, get_required_num_params

if TYPE_CHECKING:
    from amplify_qaoa.core.type import IsingDict
    from amplify_qaoa.runner.base import Runner


@problems_mark_with_group
@runner_test_mark
def test_solve(
    runner: Runner,
    skip_check: bool,
    f_dict: IsingDict,
    group_list: list[list[int]],
    reps: int,
) -> None:
    shots = 8192

    minimize_parameters = MinimizeParameters()
    if skip_check:
        num_params = get_required_num_params(f_dict, group_list, reps, QaoaAnsatzType.Constrained)
        minimize_parameters.options = {"maxiter": maxfun_lower_bound("COBYLA", num_params) + 1}
    run_result = run_qaoa(
        runner,
        ising_dict_to_model(f_dict, group_list),
        shots=shots,
        reps=reps,
        minimize_parameters=minimize_parameters,
    )

    check_run_result(shots, f_dict, group_list, run_result, skip_optimality_check=skip_check)
