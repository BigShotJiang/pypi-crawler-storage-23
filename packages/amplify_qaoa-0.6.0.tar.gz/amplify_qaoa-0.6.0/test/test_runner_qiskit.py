from __future__ import annotations

import pytest
from amplify import VariableGenerator
from config import QISKIT_TOKEN, TEST_PROXY_URL
from utility import check_run_result

from amplify_qaoa.algo.qaoa.run import run_qaoa
from amplify_qaoa.circuit.base import SupportsFullSim
from amplify_qaoa.circuit.qiskit import QiskitCircuit
from amplify_qaoa.runner.qiskit import Devices, QiskitRunner

TEST_QISKIT_BACKEND_NAME = "ibm_fez"


def test_constructor() -> None:
    runner = QiskitRunner()

    assert runner.backend_name is None
    assert runner.device == "CPU"
    assert runner.provider is None


def test_proto() -> None:
    circuit = QiskitCircuit(wires=2)
    assert isinstance(circuit, SupportsFullSim)


def test_parameter_set() -> None:
    runner = QiskitRunner()

    # confirm setting backend_name
    backend_name_ = "automatic"
    runner.backend_name = backend_name_
    assert runner.backend_name == backend_name_

    # confirm setting device
    for device_ in Devices:
        runner.device = device_
        assert runner.device == device_
    with pytest.raises(ValueError, match="Specified device type"):
        runner.device = "invalid_device"  # pyright: ignore[reportAttributeAccessIssue]

    assert runner.channel is None
    runner.channel = "ibm_quantum_platform"
    assert runner.channel == "ibm_quantum_platform"
    with pytest.raises(ValueError, match="Specified channel type"):
        runner.channel = "invalid_channel"  # pyright: ignore[reportAttributeAccessIssue]

    # confirm setting backend_name
    token_ = QISKIT_TOKEN
    runner.token = token_
    assert runner.token == token_


def test_run_with_token_and_simulator_method() -> None:
    if QISKIT_TOKEN is None:
        pytest.skip("AMPLIFY_QAOA_QISKIT_TEST_TOKEN environment variable is not set. Skipping the test.")

    gen = VariableGenerator()
    s = gen.array("Ising", 2)
    f = s[0] * s[1] * -1.0 + 99.0

    shots = 4000
    runner = QiskitRunner()
    runner.device = "CPU"
    runner.token = QISKIT_TOKEN
    runner.backend_name = "statevector"  # simulator method

    run_result = run_qaoa(runner, f, shots=shots)

    # assert result
    check_run_result(shots, f, [], run_result)
    assert runner.backend is not None
    assert runner.backend.name == "aer_simulator_statevector"
    assert runner.backend.options is not None
    assert runner.backend.options.method == "statevector"


def test_run_with_token_and_backend_name() -> None:
    if QISKIT_TOKEN is None:
        pytest.skip("AMPLIFY_QAOA_QISKIT_TEST_TOKEN environment variable is not set. Skipping the test.")

    gen = VariableGenerator()
    s = gen.array("Ising", 2)
    f = s[0] * s[1] * -1.0 + 99.0
    shots = 4000
    reps = 2

    backend_name = TEST_QISKIT_BACKEND_NAME

    runner = QiskitRunner()
    runner.device = "CPU"
    runner.token = QISKIT_TOKEN
    runner.backend_name = backend_name

    run_result = run_qaoa(runner, f, shots=shots, reps=reps)

    # assert result
    check_run_result(shots, f, [], run_result)

    assert runner.backend is not None
    assert runner.backend.name == "aer_simulator_from(" + backend_name + ")"


@pytest.mark.heavy
def test_run_without_token_and_backend_name() -> None:
    gen = VariableGenerator()
    s = gen.array("Ising", 2)
    f = s[0] * s[1] * -1.0 + 99.0
    shots = 4000

    backend_name = TEST_QISKIT_BACKEND_NAME

    runner = QiskitRunner()
    runner.device = "CPU"
    runner.backend_name = backend_name

    run_result = run_qaoa(runner, f, shots=shots)
    # assert result
    check_run_result(shots, f, [], run_result)

    assert runner.backend is not None
    assert runner.backend.name == "fake_" + backend_name[4:]


def test_run_with_different_backend_in_tune_and_run() -> None:
    gen = VariableGenerator()
    s = gen.array("Ising", 2)
    f = s[0] * s[1] * -1.0 + 99.0
    shots = 4000

    runner = QiskitRunner()
    runner.device = "CPU"
    runner.backend_name = "statevector"

    runner.backend_name = "density_matrix"
    run_result = run_qaoa(runner, f, shots=shots)

    # assert result
    check_run_result(shots, f, [], run_result)


def test_multiple_clients_with_same_token() -> None:
    if QISKIT_TOKEN is None:
        pytest.skip("AMPLIFY_QAOA_QISKIT_TEST_TOKEN environment variable is not set. Skipping the test.")

    gen = VariableGenerator()
    s = gen.array("Ising", 2)
    f = s[0] * s[1] * -1.0 + 99.0
    shots = 4000

    runner_1 = QiskitRunner()
    runner_1.token = QISKIT_TOKEN
    runner_1.device = "CPU"
    runner_1.backend_name = TEST_QISKIT_BACKEND_NAME

    runner_2 = QiskitRunner()
    runner_2.token = QISKIT_TOKEN
    runner_2.device = "CPU"
    runner_2.backend_name = TEST_QISKIT_BACKEND_NAME
    runner_2.backend_name = "density_matrix"
    run_result = run_qaoa(runner_2, f, shots=shots)

    # assert result
    check_run_result(shots, f, [], run_result)


@pytest.mark.heavy
def test_run_with_proxy() -> None:
    if QISKIT_TOKEN is None:
        pytest.skip("AMPLIFY_QAOA_QISKIT_TEST_TOKEN environment variable is not set. Skipping the test.")
    if TEST_PROXY_URL is None:
        pytest.skip("TEST_PROXY_URL environment variable is not set. Skipping the test.")

    gen = VariableGenerator()
    s = gen.array("Ising", 2)
    f = s[0] * s[1] * -1.0 + 99.0
    shots = 4000

    backend_name = TEST_QISKIT_BACKEND_NAME

    runner = QiskitRunner(proxy=TEST_PROXY_URL, verify=False)
    runner.device = "CPU"
    runner.token = QISKIT_TOKEN
    runner.backend_name = backend_name

    run_result = run_qaoa(runner, f, shots=shots)

    # assert result
    check_run_result(shots, f, [], run_result)

    assert runner.backend is not None
    assert runner.backend.name == "aer_simulator_from(" + backend_name + ")"
