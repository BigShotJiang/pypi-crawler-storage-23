from __future__ import annotations

import logging
from copy import deepcopy
from datetime import timedelta
from typing import TYPE_CHECKING

import pytest
from amplify import ConstraintList, Matrix, Poly, Result, VariableGenerator, VariableType, equal_to, solve
from typing_extensions import assert_never
from utility import QAOAClientType, check_result_counts, client_test_mark

from amplify_qaoa import QiskitQAOAClient, QulacsQAOAClient
from amplify_qaoa.algo.base.utility import count_qubits, maxfun_lower_bound
from amplify_qaoa.algo.qaoa.utility import QaoaAnsatzType, QaoaAnsatzTypeFixed, get_required_num_params

if TYPE_CHECKING:
    from _pytest.mark.structures import ParameterSet
    from amplify import CustomClientProtocol

    from amplify_qaoa.core.type import IsingDict


gen = VariableGenerator()
s = gen.array("Ising", 2)
f_ising = s[0] + s[1] - s[0] * s[1] * 3.0
gen = VariableGenerator()
mat_ising = gen.matrix("Ising", 2)
mat_ising.quadratic[0, 1] = -3.0
mat_ising.linear[0] = 1.0
mat_ising.linear[1] = 1.0
mat_ising.constant = 0
gen = VariableGenerator()
q = gen.array("Binary", 2)
f_binary = q[0] + q[1] - q[0] * q[1] * 3.0
gen = VariableGenerator()
mat_binary = gen.matrix("Binary", 2)
mat_binary.quadratic[0, 1] = -3.0
mat_binary.linear[0] = 1.0
mat_binary.linear[1] = 1.0
mat_binary.constant = 0

problem_list: list[ParameterSet] = [
    pytest.param(f_ising, True, 3, id="ising-poly"),
    pytest.param(mat_ising, True, 3, id="ising-matrix"),
    pytest.param(f_binary, False, 3, id="binary-poly"),
    pytest.param(mat_binary, False, 3, id="binary-matrix"),
]


@pytest.mark.parametrize(("objective", "is_ising", "reps"), problem_list)
@client_test_mark
def test_client_solve_dry_run(
    objective: Poly | Matrix, is_ising: bool, reps: int, client: CustomClientProtocol, skip_check: bool
) -> None:
    _ = skip_check  # not used

    if not is_ising:
        with pytest.raises(ValueError, match=r"^The degree of the given polynomial"):
            client.solve(objective, constraints=None, dry_run=True)
        return

    client = deepcopy(client)
    if isinstance(client, QAOAClientType):
        client.parameters.algo.reps = reps
    else:
        pytest.skip(f"Unknown client type: {type(client)}")

    result = client.solve(objective, constraints=None, dry_run=True)

    assert result is None


@pytest.mark.parametrize(("objective", "_is_ising", "reps"), problem_list)
@client_test_mark
def test_amplify_solve_dry_run(
    objective: Poly | Matrix, _is_ising: bool, reps: int, client: CustomClientProtocol, skip_check: bool
) -> None:
    _ = skip_check  # not used

    client = deepcopy(client)
    if isinstance(client, QAOAClientType):
        client.parameters.algo.reps = reps
    else:
        pytest.skip(f"Unknown client type: {type(client)}")

    result = solve(objective, client, dry_run=True)

    assert result is not None
    assert hasattr(result, "solutions")
    assert len(result.solutions) == 0
    with pytest.raises(RuntimeError, match="has no solution"):
        _ = result.best

    assert isinstance(result, Result)
    assert result.client_result is None

    assert hasattr(result, "response_time")
    assert result.response_time == timedelta(0)
    assert hasattr(result, "execution_time")
    assert result.execution_time == timedelta(0)
    assert hasattr(result, "solutions")
    assert len(result.solutions) == 0

    type_original = VariableType.Ising if _is_ising else VariableType.Binary
    assert all(variable.type == VariableType.Ising for variable in result.intermediate.model.variables)
    assert all(p.is_variable and p.as_variable().type == type_original for p in result.intermediate.mapping)

    assert hasattr(result, "client_result")


@pytest.mark.parametrize(("objective", "_is_ising", "reps"), [problem_list[0], problem_list[3]])
@client_test_mark
def test_amplify_solve(
    objective: Poly | Matrix, _is_ising: bool, reps: int, client: CustomClientProtocol, skip_check: bool
) -> None:
    _ = skip_check  # not used
    shots = 2048
    client = deepcopy(client)
    if isinstance(client, QAOAClientType):
        client.parameters.algo.shots = shots
        client.parameters.algo.reps = reps
    else:
        pytest.skip(f"Unknown client type: {type(client)}")

    result = solve(objective, client)

    assert result is not None
    assert hasattr(result, "solutions")
    assert len(result.solutions) > 0
    assert hasattr(result, "best")

    assert isinstance(result, Result)
    match client:
        case QiskitQAOAClient():
            assert isinstance(result.client_result, QiskitQAOAClient.Result)
        case QulacsQAOAClient():
            assert isinstance(result.client_result, QulacsQAOAClient.Result)
        case _ as other:
            assert_never(other)

    assert hasattr(result, "response_time")
    assert result.response_time > timedelta(0)
    assert hasattr(result, "execution_time")
    assert result.execution_time > timedelta(0)

    check_result_counts(shots, objective, [], result.client_result.counts)


@pytest.mark.parametrize(
    "group_list",
    [
        pytest.param([], id="no-group"),
        pytest.param([[0, 1, 2]], id="one-group"),
        pytest.param([[0, 1, 2], [3, 4, 5]], id="two-groups"),
        pytest.param([[0, 1, 2], [3, 4, 5], [6, 7, 8]], id="three-groups"),
    ],
)
@client_test_mark
@pytest.mark.parametrize(
    "qaoa_type",
    [
        pytest.param(QaoaAnsatzType.Original, id="original"),
        pytest.param(QaoaAnsatzType.Constrained, id="constrained"),
    ],
)
def test_amplify_solve_below_min_maxiter(
    group_list: list[list[int]],
    client: CustomClientProtocol,
    skip_check: bool,
    qaoa_type: QaoaAnsatzTypeFixed,
) -> None:
    _ = skip_check  # not used
    f_dict: IsingDict = {(0, 1, 2, 3, 4, 5, 6, 7, 8): -1, (1, 3, 5, 7): 1, (0, 2, 4, 6, 8): 1}
    reps = 3

    if not isinstance(client, QAOAClientType):
        pytest.skip(f"Unknown client type: {type(client)}")

    method = "COBYLA"

    wires = count_qubits(f_dict, group_list)
    gen = VariableGenerator()
    s = gen.array("Ising", wires)
    f = Poly(0)
    for symbols, coeff in f_dict.items():
        term = coeff
        for i in symbols:
            term *= s[i]
        f += term
    constraints = ConstraintList()
    for group in group_list:
        sum_group = Poly(0)
        for i in group:
            sum_group += s[i]
        constraints += equal_to(sum_group, len(group) - 2)
    model = f + constraints

    num_params = get_required_num_params(f_dict, group_list, reps, qaoa_type)
    maxiter_lb = maxfun_lower_bound(method, num_params) + 1

    client.parameters.algo.method = method
    client.parameters.algo.reps = reps
    client.parameters.algo.qaoa_type = qaoa_type
    client.parameters.algo.options = {"maxiter": maxiter_lb}

    solve(model, client, dry_run=True)

    client.parameters.algo.options = {"maxiter": maxiter_lb - 1}
    with pytest.raises(RuntimeError, match="Given the input"):
        solve(model, client, dry_run=True)


@pytest.mark.parametrize(
    "group_list",
    [
        pytest.param([], id="no-group"),
        pytest.param([[0, 1, 2]], id="one-group"),
        pytest.param([[0, 1, 2], [3, 4, 5]], id="two-groups"),
        pytest.param([[0, 1, 2], [3, 4, 5], [6, 7, 8]], id="three-groups"),
    ],
)
@client_test_mark
@pytest.mark.parametrize(
    "qaoa_type",
    [
        pytest.param(QaoaAnsatzType.Original, id="original"),
        pytest.param(QaoaAnsatzType.Constrained, id="constrained"),
    ],
)
def test_amplify_solve_with_initial_parameters(
    caplog: pytest.LogCaptureFixture,
    group_list: list[list[int]],
    client: CustomClientProtocol,
    skip_check: bool,
    qaoa_type: QaoaAnsatzTypeFixed,
) -> None:
    _ = skip_check  # not used
    f_dict: IsingDict = {(0, 1, 2, 3, 4, 5, 6, 7, 8): -1, (1, 3, 5, 7): 1, (0, 2, 4, 6, 8): 1}
    reps = 5

    if not isinstance(client, QAOAClientType):
        pytest.skip(f"Unknown client type: {type(client)}")

    method = "COBYLA"

    wires = count_qubits(f_dict, group_list)
    gen = VariableGenerator()
    s = gen.array("Ising", wires)
    f = Poly(0)
    for symbols, coeff in f_dict.items():
        term = coeff
        for i in symbols:
            term *= s[i]
        f += term
    constraints = ConstraintList()
    for group in group_list:
        sum_group = Poly(0)
        for i in group:
            sum_group += s[i]
        constraints += equal_to(sum_group, len(group) - 2)
    model = f + constraints

    num_params = get_required_num_params(f_dict, group_list, reps, qaoa_type)
    maxiter_lb = maxfun_lower_bound(method, num_params) + 1

    client.parameters.algo.method = method
    client.parameters.algo.reps = reps
    client.parameters.algo.qaoa_type = qaoa_type
    client.parameters.algo.options = {"maxiter": maxiter_lb}
    assert client.parameters.algo.options["maxiter"] == maxiter_lb

    client.parameters.algo.initial_parameters = [0.01 * i for i in range(num_params)]
    solve(model, client, dry_run=True)

    client.parameters.algo.initial_parameters = [0.01 * i for i in range(num_params - 1)]
    with pytest.raises(RuntimeError, match="Length of initial_parameters must be at least"):
        solve(model, client, dry_run=True)

    client.parameters.algo.initial_parameters = [0.01 * i for i in range(num_params + 1)]
    with caplog.at_level(logging.WARNING):
        solve(model, client, dry_run=True)
    assert "Length of initial_parameters is too long" in caplog.text
