from __future__ import annotations

from amplify import Degree, VariableType

from amplify_qaoa import QaoaAnsatzType
from amplify_qaoa.algo.qaoa.run import REPS_DEFAULT, SHOTS_DEFAULT
from amplify_qaoa.client.qiskit import QAOA, QiskitQAOAClient


def test_constructor() -> None:
    client = QiskitQAOAClient()

    for var_type in [VariableType.Binary, VariableType.Ising, VariableType.Integer, VariableType.Real]:
        if var_type == VariableType.Ising:
            assert client.acceptable_degrees.objective[var_type] == Degree.HighOrder
        else:
            assert client.acceptable_degrees.objective[var_type] == Degree.Zero

        assert client.acceptable_degrees.equality_constraints[var_type] == Degree.Zero
        assert client.acceptable_degrees.inequality_constraints[var_type] == Degree.Zero

    assert client.url is None
    assert client.token is None
    assert client.proxy is None
    assert client.verify is None

    assert isinstance(client.parameters, QiskitQAOAClient.Parameters)

    assert isinstance(client.parameters.algo, QAOA.Parameters)
    assert client.parameters.algo.shots == SHOTS_DEFAULT
    assert client.parameters.algo.reps == REPS_DEFAULT
    assert client.parameters.algo.qaoa_type == QaoaAnsatzType.Auto

    assert isinstance(client.parameters.runner, QiskitQAOAClient.Parameters.RunnerParameters)
    assert client.parameters.runner.backend_name is None
    assert client.parameters.runner.channel is None
    assert client.parameters.runner.device == "CPU"


def test_parameter_set() -> None:
    token_dummy = "dummy_token"
    url_dummy = "https://example.com:8080"
    proxy_dummy = "http://proxy.example.com"

    client = QiskitQAOAClient()

    client.token = token_dummy
    assert client.token == token_dummy
    client.url = url_dummy
    assert client.url == url_dummy
    client.proxy = proxy_dummy
    assert client.proxy == proxy_dummy
    client.verify = False
    assert client.verify is False

    # confirm setting qaoa params
    client.parameters.algo = QAOA.Parameters(shots=2048, reps=5)
    assert client.parameters.algo.shots == 2048
    assert client.parameters.algo.reps == 5

    # confirm setting runner params
    client.parameters.runner = QiskitQAOAClient.Parameters.RunnerParameters(backend_name="automatic")
    assert client.parameters.runner.backend_name == "automatic"
