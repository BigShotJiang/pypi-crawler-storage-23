from datetime import timedelta

from typing_extensions import Self

from amplify_qaoa.circuit.base import CircuitProtocol, ObservableProtocol
from amplify_qaoa.core.type import IsingSeqFreqList
from amplify_qaoa.runner.base import Runner, TimingBase


class MockRawCircType:
    pass


class MockRawObsType:
    pass


class MockObsType:
    @staticmethod
    def construct_observable(wires: int) -> MockRawObsType:
        _ = wires
        return MockRawObsType()

    def __init__(self, wires: int) -> None:
        pass

    def init_obs(self, wires: int) -> Self: ...

    @property
    def obs(self) -> MockRawObsType: ...


class MockCircType:
    @classmethod
    def get_observable_class(cls) -> type[MockObsType]:
        return MockObsType

    @staticmethod
    def construct_quantum_circuit(wires: int) -> MockRawCircType:
        _ = wires
        return MockRawCircType()

    def __init__(self, wires: int) -> None:
        pass

    def init_circuit(self, wires: int) -> Self:
        _ = wires
        return self

    def add_measurement(self, qi: int) -> Self:
        _ = qi
        return self

    def add_measurements_forall(self) -> Self:
        return self

    @property
    def num_wires(self) -> int:
        return 0

    @property
    def circuit(self) -> MockRawCircType:
        return MockRawCircType()


class MockTimingType(TimingBase):
    pass


class MockRunner(Runner):
    def init_runner(self, wires: int) -> None: ...

    @classmethod
    def get_circuit_class(cls) -> type[MockCircType]:
        return MockCircType

    def observe(
        self,
        qc: CircuitProtocol[MockCircType, MockObsType],
        shots: int,
    ) -> tuple[IsingSeqFreqList, MockTimingType]:
        _1 = qc
        _2 = shots
        return ([], MockTimingType(total_execution_time=timedelta(0), total_machine_time=timedelta(0)))


def test_construct() -> None:
    runner = MockRunner()

    assert isinstance(runner, Runner)
    assert isinstance(runner, MockRunner)

    circuit = runner.get_circuit_class()(wires=2)
    assert isinstance(circuit, CircuitProtocol)
    assert isinstance(circuit, MockCircType)

    obs = circuit.get_observable_class()(wires=2)
    assert isinstance(obs, ObservableProtocol)
    assert isinstance(obs, MockObsType)


_: type[Runner[MockCircType, MockTimingType]] = MockRunner
