from __future__ import annotations

import pytest

from amplify_qaoa.circuit.base import SupportsFullSim
from amplify_qaoa.circuit.qulacs import QulacsCircuit
from amplify_qaoa.runner.qulacs import QulacsRunner

pytestmark = pytest.mark.qulacs


def test_constructor() -> None:
    _ = QulacsRunner()


def test_proto() -> None:
    circuit = QulacsCircuit(wires=2)
    assert isinstance(circuit, SupportsFullSim)
