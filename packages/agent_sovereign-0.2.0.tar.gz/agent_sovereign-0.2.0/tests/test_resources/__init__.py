"""Tests for the resources subpackage."""
