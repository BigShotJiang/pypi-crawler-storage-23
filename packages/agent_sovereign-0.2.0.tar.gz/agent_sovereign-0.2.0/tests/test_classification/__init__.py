"""Tests for the classification subpackage."""
