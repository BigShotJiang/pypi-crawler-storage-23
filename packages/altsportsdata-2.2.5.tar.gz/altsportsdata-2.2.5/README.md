# AltSportsData SDK

[![PyPI](https://img.shields.io/pypi/v/altsportsdata.svg)](https://pypi.org/project/altsportsdata/)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)

**Alternative sports odds & data for sportsbooks, DFS platforms, and prediction markets.**

30 leagues. Every market type. One call to see everything available.

```
pip install altsportsdata
```

---

## One Call — All Available Markets

```python
from altsportsdata import AltSportsData

client = AltSportsData(api_key="your_key")

for market in client.get_markets():
    print(f"\n{market['event_name']} ({market['league']})")
    for o in market['outcomes'][:5]:
        print(f"  {o['athlete']:25} {o['probability']:5.1f}%  ({o['odds']:.2f})")
```

```
Indianapolis (spr)
  Eli Tomac                49.4%  (2.02)
  Hunter Lawrence           37.6%  (2.66)
  Ken Roczen                23.5%  (4.26)
  Cooper Webb               14.6%  (6.84)
  Joey Savatgy               6.2%  (16.20)
```

That's it. Live odds, upcoming odds, or historical results — all with prices included. No second fetch.

---

## For Prediction Markets (Kalshi, Polymarket)

```python
client = AltSportsData(api_key="your_key")

# Browse all available contracts with probabilities
for market in client.get_markets():
    print(f"\n{market['event_name']}")
    for o in market['outcomes']:
        print(f"  {o['athlete']:25} {o['probability']:5.1f}%")
        # → outcome_id included for contract creation
```

## For DFS Platforms (PrizePicks, Underdog)

```python
client = AltSportsData(api_key="your_key")

# Head-to-head matchups — ready for pick'em
for market in client.get_markets():
    for h2h in market['matchups']:
        print(f"  {h2h['player1']} ({h2h['odds1']:.2f})"
              f"  vs  {h2h['player2']} ({h2h['odds2']:.2f})")
```

```
Cooper Webb (2.31)  vs  Ken Roczen (1.57)
Eli Tomac (1.66)  vs  Hunter Lawrence (2.13)
```

## For Sportsbooks (DraftKings, Bet365, Stake)

```python
client = AltSportsData(api_key="your_key")

# Full moneylines for a specific event
spr = client.get_league("spr")
events = spr.list_events(status="upcoming")
odds = spr.get_moneylines(events[0].id)

for o in sorted(odds["eventWinner"], key=lambda x: x["odds"])[:10]:
    ath = o["athlete"]
    print(f'{ath["firstName"]} {ath["lastName"]:20} {o["odds"]:.2f}')
```

## Historical Results & Settlement

```python
wsl = AltSportsData(api_key="your_key", league="wsl")

for market in wsl.get_markets(status="completed"):
    print(f"\n{market['event_name']}")
    for o in market['outcomes'][:5]:
        tag = "✅" if o.get("settlement") == "WIN" else "  "
        print(f"  {tag} {o['athlete']:25} {o['odds']:5.2f}  → {o.get('settlement', '')}")
```

```
Lexus Pipe Challenger
     Molly Picklum             3.50  → LOSE
     Caitlin Simmers           3.88  → LOSE
     Erin Brooks               5.49  → LOSE
  ✅ Gabriela Bryan             6.46  → WIN
     Bettylou Johnson          9.90  → LOSE
```

---

## Full API Reference

### Setup

```python
from altsportsdata import AltSportsData

# General client — all leagues
client = AltSportsData(api_key="your_key")

# League-scoped client — auto-filters everything
wsl = client.get_league("wsl")
f1  = client.get_league("f1")
spr = client.get_league("spr")

# Or set league directly
wsl = AltSportsData(api_key="your_key", league="wsl")
```

### Browse Leagues & Market Types

```python
# All leagues with their supported market types
for lg in client.list_leagues():
    print(f"{lg.league_key:15} {lg.name:35} {lg.market_types}")

# Details for a specific league
f1 = client.get_league_info("f1")
print(f"{f1.name}: {f1.market_count} markets — {f1.market_types}")

# All market types ASD offers across all leagues
client.list_market_types()
# → ['eventWinner', 'exactasEvent', 'fastestLap', 'headToHead', 'heat',
#    'multiOverUnder', 'overUnder', 'podium', 'propBet', 'raceTop3', ...]
```

### Markets (one call, prices included)

```python
client.get_markets()                          # upcoming with odds (default)
client.get_markets(status="live")             # live events with odds
client.get_markets(status="completed")        # historical with settlement
client.get_markets(status=["live","upcoming"])  # all active
```

### Events

```python
client.list_events(status="upcoming")
client.list_events(status="live")
client.list_events(status="completed")
client.list_events(status=["live", "upcoming"])
client.get_event("event_id")
client.get_participants("event_id")
client.get_heat_scores("event_id", "heat_id")
```

### Odds (per event)

```python
# Sportsbook
client.get_moneylines("event_id")         # event winner
client.get_matchups("event_id")           # head-to-head
client.get_totals("event_id")             # over/under
client.get_exactas("event_id", n=2)       # exacta
client.get_podiums("event_id")            # top-3
client.get_shows("event_id")              # shows
client.get_heat_winners("event_id")       # heat winner
client.get_fastest_lap("event_id")        # fastest lap
client.get_dream_team("event_id")         # dream team

# Prediction market
client.get_market_probabilities("event_id")
client.get_podium_probabilities("event_id")
client.get_top_finish_probabilities("event_id", top_n=5)

# DFS
client.get_player_props("event_id")
client.get_player_matchups("event_id")
client.get_player_totals("event_id", stat="points")

# Generic — any market by name or alias
client.get_odds("event_id", "moneyline")  # aliases: "h2h", "props", "totals"
```

### Parlays

```python
odds = client.get_moneylines("event_id")
picks = [o["id"] for o in odds["eventWinner"][:2]]
parlay = client.calculate_parlay("event_id", picks=picks)
```

### Futures

```python
client.list_futures()
client.get_futures(tour="tour_id", type="winner")
```

### Leagues

```python
for lg in client.list_leagues():
    print(f"{lg.key:15} {lg.name}")
```

## 30 Leagues

| Code | League | Code | League |
|------|--------|------|--------|
| `wsl` | World Surf League | `pbr` | Professional Bull Riders |
| `sls` | Street League Skateboarding | `bkfc` | Bare Knuckle FC |
| `f1` | Formula 1 | `motogp` | MotoGP |
| `spr` | Supercross | `mxgp` | MXGP |
| `nrx` | Nitrocross | `jaialai` | Jai Alai |
| `fdrift` | Formula Drift | `nll` | National Lacrosse League |
| `masl` | Major Arena Soccer | `nhra` | NHRA Drag Racing |
| `powerslap` | Power Slap | `dgpt` | Disc Golf Pro Tour |
| `worldoutlaws` | World of Outlaws | `usac` | USAC Racing |
| `xgame` | X Games | `motoamerica` | MotoAmerica |
| `hlrs` | High Limit Racing | `byb` | BYB Extreme Fighting |
| `athletesunlimited` | Athletes Unlimited | `lux` | LUX Fight League |
| `raf` | Real American Freestyle | `mltt` | Major League Table Tennis |
| `motocrs` | Motocross | `spectation` | Spectation |
| `gsoc` | Global Soccer | `sprmtcrs` | Supermotocross |

## Links

- [API Docs](https://api.altsportsdata.com/public/docs)
- [Swagger](https://api.altsportsdata.com/public/docs/swagger)

## License

MIT
