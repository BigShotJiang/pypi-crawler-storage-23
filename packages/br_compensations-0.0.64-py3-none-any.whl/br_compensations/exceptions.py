

class PartialReportError(Exception):
    pass