from django.shortcuts import redirect
from django.core.exceptions import PermissionDenied
from esi.models import Token
from allianceauth.framework.api.user import get_main_character_from_user
from allianceauth.services.hooks import get_extension_logger

logger = get_extension_logger(__name__)

class TokenRequiredMixin:
    """Миксин для проверки наличия токена с нужными scopes."""
    required_scopes = ['esi-mail.read_mail.v1', 'esi-ui.open_window.v1', 'esi-mail.send_mail.v1']
    
    def dispatch(self, request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect('auth_login_user')
        
        character = get_main_character_from_user(request.user)
        if not character:
            raise PermissionDenied("No main character found")
        
        # Проверяем наличие токена с нужными scopes
        token = Token.objects.filter(
            character_id=character.character_id
        ).first()
        
        if not token:
            logger.warning(f'Токен не найден для персонажа {character.character_id}')
            # Перенаправляем на страницу авторизации
            from django.urls import reverse
            scopes_str = ' '.join(self.required_scopes)
            return redirect(f"{reverse('esi:token_request')}?scopes={scopes_str}")
        
        # Проверяем наличие нужных scopes в токене
        token_scopes = set(token.scopes.values_list('name', flat=True))
        required_scopes = set(self.required_scopes)
        
        if not required_scopes.issubset(token_scopes):
            logger.warning(
                f'Токен для персонажа {character.character_id} не имеет нужных скоупов. '
                f'Требуется: {self.required_scopes}, есть: {token_scopes}'
            )
            # Перенаправляем на страницу авторизации
            from django.urls import reverse
            scopes_str = ' '.join(self.required_scopes)
            return redirect(f"{reverse('esi:token_request')}?scopes={scopes_str}")
        
        return super().dispatch(request, *args, **kwargs)