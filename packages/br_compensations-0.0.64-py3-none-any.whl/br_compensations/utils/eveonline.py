from typing import Optional
from esi.errors import TokenExpiredError, TokenInvalidError
from esi.models import Token
from esi.clients import EsiClientProvider
from allianceauth.services.hooks import get_extension_logger

logger = get_extension_logger(__name__)

class EveCharacterUtils:
    esi = EsiClientProvider()
    
    @classmethod
    def get_token_for_character(cls, character_id: int, REQUIRED_SCOPES: list[str]) -> Optional[Token]:
        """
        Получить валидный токен для персонажа с нужными скоупами.
        
        Args:
            character_id: ID персонажа
            REQUIRED_SCOPES: Список требуемых разрешений (если пуст, не проверяется)
            
        Returns:
            Token или None если не найден
        """
        try:
            tokens = Token.objects.filter(
                character_id=character_id
            )
            for token in tokens:
                if REQUIRED_SCOPES is not None:
                    # Проверяем наличие нужных скоупов
                    token_scopes = set(token.scopes.values_list('name', flat=True))
                    required_scopes = set(REQUIRED_SCOPES)
                    
                    if not required_scopes.issubset(token_scopes):
                        logger.warning(
                            f'Токен для персонажа {character_id} не имеет нужных скоупов. '
                            f'Требуется: {REQUIRED_SCOPES}, есть: {token_scopes}'
                        )
                        continue
                return token
            return None
            
        except Exception as e:
            logger.error(f'Ошибка при получении токена для персонажа {character_id}: {e}')
            return None