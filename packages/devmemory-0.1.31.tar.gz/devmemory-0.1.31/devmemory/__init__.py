__version__ = "0.1.31"
__app_name__ = "devmemory"
