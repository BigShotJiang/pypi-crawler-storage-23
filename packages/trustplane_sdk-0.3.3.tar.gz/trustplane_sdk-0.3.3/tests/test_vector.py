import unittest

from trustplane_sdk import sign


class TestVector(unittest.TestCase):
    def test_headers_shape(self) -> None:
        out = sign(
            tenant_id="mergematter.io",
            api_id="api_demo",
            client_id="client_demo",
            private_key_b64url="dyIi-Xwr2tl6NdzkT0CXWUZkb9cPRXTSbDQgz-SCcORqDZPYyFAEXEGn6Eg6hlokBxvS8avUjpmk4VwaXmg7zQ",
            method="GET",
            path="/orders",
            body="",
            bucket_seconds=20,
            time_bucket_override=88498363,
            nonce_override="9biCQnN2URhTCqhn_-orBQ",
        )
        headers = out["headers"]
        self.assertEqual(headers["x-tp-tenant-id"], "mergematter.io")
        self.assertEqual(headers["x-tp-api-id"], "api_demo")
        self.assertEqual(headers["x-tp-client-id"], "client_demo")
        self.assertEqual(headers["x-tp-time-bucket"], "88498363")
        self.assertEqual(headers["x-tp-nonce"], "9biCQnN2URhTCqhn_-orBQ")
        self.assertTrue(headers["x-tp-signature"])
        self.assertEqual(
            headers["x-tp-body-hash"],
            "sha256:47DEQpj8HBSa-_TImW-5JCeuQeRkm5NMpJWZG3hSuFU",
        )


if __name__ == "__main__":
    unittest.main()
