import base64
import hashlib
import json
import os
import time
from typing import Any, Dict, Optional
from urllib import request as urlrequest

from nacl.signing import SigningKey
from nacl.bindings import (
    crypto_core_ristretto255_from_hash,
    crypto_core_ristretto255_scalar_invert,
    crypto_core_ristretto255_scalar_random,
    crypto_scalarmult_ristretto255,
)


def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("utf-8").rstrip("=")


def _b64url_decode(data: str) -> bytes:
    pad = "=" * (-len(data) % 4)
    return base64.urlsafe_b64decode(data + pad)


def _sha256_b64url(data: bytes) -> str:
    return _b64url_encode(hashlib.sha256(data).digest())


def _random_nonce() -> str:
    return _b64url_encode(os.urandom(16))


def gen_keypair() -> Dict[str, str]:
    key = SigningKey.generate()
    pub = key.verify_key
    private_key = key.encode() + pub.encode()
    return {
        "public_key_b64url": _b64url_encode(pub.encode()),
        "private_key_b64url": _b64url_encode(private_key),
    }


def _oprf_mask_input(input_str: str) -> Dict[str, bytes]:
    digest = hashlib.blake2b(input_str.encode("utf-8"), digest_size=64).digest()
    point = crypto_core_ristretto255_from_hash(digest)
    mask = crypto_core_ristretto255_scalar_random()
    masked = crypto_scalarmult_ristretto255(mask, point)
    return {"masked": masked, "mask": mask}


def _oprf_unmask(evaluated: bytes, mask: bytes) -> bytes:
    inv = crypto_core_ristretto255_scalar_invert(mask)
    return crypto_scalarmult_ristretto255(inv, evaluated)


def _build_transcript(
    tenant_id: str,
    api_id: str,
    client_id: str,
    method: str,
    path: str,
    body_hash: str,
    time_bucket: int,
    nonce: str,
) -> str:
    return "\n".join(
        [
            "version=tp1",
            f"tenant_id={tenant_id}",
            f"api_id={api_id}",
            f"client_id={client_id}",
            f"method={method}",
            f"path={path}",
            f"body_hash={body_hash}",
            f"time_bucket={time_bucket}",
            f"nonce={nonce}",
        ]
    )


def sign(
    tenant_id: str,
    api_id: str,
    client_id: str,
    private_key_b64url: str,
    method: str = "GET",
    path: str = "/",
    body: str = "",
    bucket_seconds: int = 20,
    time_bucket_override: int = None,
    nonce_override: str = None,
) -> Dict[str, Any]:
    if not tenant_id or not api_id or not client_id:
        raise ValueError("tenant_id, api_id, and client_id are required")
    if not private_key_b64url:
        raise ValueError("private_key_b64url is required")
    if not path:
        raise ValueError("path is required")

    body_hash = f"sha256:{_sha256_b64url(body.encode('utf-8'))}"
    now_seconds = int(time.time())
    bucket = bucket_seconds if bucket_seconds > 0 else 20
    time_bucket = time_bucket_override if time_bucket_override is not None else (now_seconds // bucket)
    nonce = nonce_override if nonce_override is not None else _random_nonce()

    transcript = _build_transcript(
        tenant_id,
        api_id,
        client_id,
        method.upper(),
        path,
        body_hash,
        time_bucket,
        nonce,
    )

    digest = hashlib.sha256(transcript.encode("utf-8")).digest()
    priv = _b64url_decode(private_key_b64url)
    if len(priv) != 64:
        raise ValueError("private_key_b64url must be ed25519 private key (64 bytes)")
    signing_key = SigningKey(priv[:32])
    signature = signing_key.sign(digest).signature
    signature_b64url = _b64url_encode(signature)

    headers = {
        "x-tp-tenant-id": tenant_id,
        "x-tp-api-id": api_id,
        "x-tp-client-id": client_id,
        "x-tp-method": method.upper(),
        "x-tp-path": path,
        "x-tp-time-bucket": str(time_bucket),
        "x-tp-nonce": nonce,
        "x-tp-signature": signature_b64url,
        "x-tp-proof": signature_b64url,
        "x-tp-body-hash": body_hash,
    }

    verify_payload = {
        "tenant_id": tenant_id,
        "api_id": api_id,
        "client_id": client_id,
        "method": method.upper(),
        "path": path,
        "body_hash": body_hash,
        "time_bucket": time_bucket,
        "nonce": nonce,
        "signature": signature_b64url,
    }

    return {
        "headers": headers,
        "verify_payload": verify_payload,
        "transcript": transcript,
        "digest_b64url": _b64url_encode(digest),
    }


def verify_headers(
    auth_base_url: str,
    tenant_id: str,
    api_id: str,
    client_id: str,
    private_key_b64url: str,
    method: str,
    path: str,
    body: str = "",
    bucket_seconds: int = 20,
    proof_type: Optional[str] = None,
    proof_payload: Optional[str] = None,
) -> Dict[str, Any]:
    if not auth_base_url:
        raise ValueError("auth_base_url is required")
    signed = sign(
        tenant_id=tenant_id,
        api_id=api_id,
        client_id=client_id,
        private_key_b64url=private_key_b64url,
        method=method,
        path=path,
        body=body,
        bucket_seconds=bucket_seconds,
    )
    headers = dict(signed["headers"])
    if proof_type:
        headers["x-tp-proof-type"] = proof_type
    if proof_payload:
        headers["x-tp-proof-payload"] = proof_payload
    base = auth_base_url.rstrip("/")
    resp = _http_headers_post(f"{base}/auth/verify-headers", headers)
    resp["verify_payload"] = signed["verify_payload"]
    resp["transcript"] = signed["transcript"]
    resp["digest_b64url"] = signed["digest_b64url"]
    return resp


class TrustplaneClient:
    def __init__(self, tenant_id: str, api_id: str, client_id: str, bucket_seconds: int = 20):
        self.tenant_id = tenant_id
        self.api_id = api_id
        self.client_id = client_id
        self.bucket_seconds = bucket_seconds

    def sign(self, method: str, path: str, body: str, private_key_b64url: str) -> Dict[str, Any]:
        return sign(
            tenant_id=self.tenant_id,
            api_id=self.api_id,
            client_id=self.client_id,
            private_key_b64url=private_key_b64url,
            method=method,
            path=path,
            body=body,
            bucket_seconds=self.bucket_seconds,
        )

    def verify_headers(
        self,
        auth_base_url: str,
        method: str,
        path: str,
        body: str,
        private_key_b64url: str,
        proof_type: Optional[str] = None,
        proof_payload: Optional[str] = None,
    ) -> Dict[str, Any]:
        return verify_headers(
            auth_base_url=auth_base_url,
            tenant_id=self.tenant_id,
            api_id=self.api_id,
            client_id=self.client_id,
            private_key_b64url=private_key_b64url,
            method=method,
            path=path,
            body=body,
            bucket_seconds=self.bucket_seconds,
            proof_type=proof_type,
            proof_payload=proof_payload,
        )

    def blindfold_verify(self, auth_base_url: str, method: str, path: str, body: str, private_key_b64url: str) -> Dict[str, Any]:
        return blindfold_verify(
            auth_base_url=auth_base_url,
            tenant_id=self.tenant_id,
            api_id=self.api_id,
            client_id=self.client_id,
            private_key_b64url=private_key_b64url,
            method=method,
            path=path,
            body=body,
            bucket_seconds=self.bucket_seconds,
        )


def from_file(path: str) -> TrustplaneClient:
    with open(path, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    return TrustplaneClient(
        tenant_id=cfg.get("tenant_id"),
        api_id=cfg.get("api_id"),
        client_id=cfg.get("client_id"),
        bucket_seconds=cfg.get("bucket_seconds", 20),
    )


def _http_json_post(url: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    data = json.dumps(payload).encode("utf-8")
    req = urlrequest.Request(
        url,
        data=data,
        headers={"content-type": "application/json"},
        method="POST",
    )
    try:
        with urlrequest.urlopen(req) as resp:
            body = resp.read().decode("utf-8")
            return {"status": resp.status, "ok": True, "data": json.loads(body)}
    except Exception as exc:
        if hasattr(exc, "read"):
            raw = exc.read().decode("utf-8")
            try:
                parsed = json.loads(raw)
            except Exception:
                parsed = {"raw": raw}
            status = getattr(exc, "code", 0)
            return {"status": status, "ok": False, "data": parsed}
        raise


def _http_headers_post(url: str, headers: Dict[str, str]) -> Dict[str, Any]:
    req = urlrequest.Request(
        url,
        headers=headers,
        method="POST",
    )
    try:
        with urlrequest.urlopen(req) as resp:
            body = resp.read().decode("utf-8")
            try:
                data = json.loads(body) if body else {}
            except Exception:
                data = {"raw": body}
            return {
                "status": resp.status,
                "ok": True,
                "data": data,
                "headers": dict(resp.headers.items()),
            }
    except Exception as exc:
        if hasattr(exc, "read"):
            raw = exc.read().decode("utf-8")
            try:
                parsed = json.loads(raw) if raw else {}
            except Exception:
                parsed = {"raw": raw}
            status = getattr(exc, "code", 0)
            return {"status": status, "ok": False, "data": parsed, "headers": {}}
        raise


def fetch_gcp_identity_token(audience: str = "trustplane-enroll") -> str:
    aud = audience or "trustplane-enroll"
    url = (
        "http://metadata/computeMetadata/v1/instance/service-accounts/default/identity"
        f"?audience={aud}&format=full"
    )
    req = urlrequest.Request(
        url,
        headers={"Metadata-Flavor": "Google"},
        method="GET",
    )
    try:
        with urlrequest.urlopen(req, timeout=2) as resp:
            return resp.read().decode("utf-8").strip()
    except Exception as exc:
        raise RuntimeError(f"metadata token fetch failed: {exc}") from exc


def _fetch_imds_token() -> str:
    req = urlrequest.Request(
        "http://169.254.169.254/latest/api/token",
        headers={"X-aws-ec2-metadata-token-ttl-seconds": "21600"},
        method="PUT",
    )
    with urlrequest.urlopen(req, timeout=2) as resp:
        return resp.read().decode("utf-8").strip()


def _fetch_imds_text(path: str, token: str) -> str:
    headers = {"X-aws-ec2-metadata-token": token} if token else {}
    req = urlrequest.Request(
        f"http://169.254.169.254{path}",
        headers=headers,
        method="GET",
    )
    with urlrequest.urlopen(req, timeout=2) as resp:
        return resp.read().decode("utf-8").strip()


def fetch_aws_iid_payload() -> str:
    env_payload = os.environ.get("TP_AWS_IID_PAYLOAD", "").strip()
    if env_payload:
        return env_payload
    doc = os.environ.get("TP_AWS_IID_DOCUMENT", "").strip()
    sig = os.environ.get("TP_AWS_IID_SIGNATURE", "").strip()
    if doc and sig:
        return json.dumps({"document": doc, "signature": sig})
    token = ""
    try:
        token = _fetch_imds_token()
    except Exception:
        token = ""
    document = _fetch_imds_text("/latest/dynamic/instance-identity/document", token)
    signature = _fetch_imds_text("/latest/dynamic/instance-identity/signature", token)
    return json.dumps({"document": document, "signature": signature})


def _resolve_proof_payload(
    proof_payload: Optional[str],
    proof_auto: bool,
    proof_aud: Optional[str],
    proof_kind: Optional[str],
    force_refresh: bool = False,
) -> str:
    if proof_payload and str(proof_payload).strip() and not force_refresh:
        return str(proof_payload).strip()
    if not proof_auto:
        raise ValueError("proof_payload is required unless proof_auto is enabled")
    kind = (proof_kind or "").strip().lower()
    if kind == "aws_iid":
        return fetch_aws_iid_payload()
    env_token = os.environ.get("TP_OIDC_TOKEN", "").strip()
    if env_token:
        return env_token
    return fetch_gcp_identity_token(proof_aud or "trustplane-enroll")


def _should_retry_auto_approve(resp: Dict[str, Any]) -> bool:
    reason = str(resp.get("data", {}).get("auto_approve_reason", "")).strip()
    return reason in {"token_invalid", "token_expired", "token_invalid_or_expired"}


def enroll_request(
    base_url: str,
    tenant_id: str,
    client_id: str,
    public_key_b64url: str,
    scopes: Optional[list] = None,
    proof_kind: str = "oidc",
    proof_payload: Optional[str] = None,
    proof_auto: bool = False,
    proof_aud: str = "trustplane-enroll",
    auto_approve: bool = False,
    metadata: Optional[dict] = None,
) -> Dict[str, Any]:
    if not base_url:
        raise ValueError("base_url is required")
    if not tenant_id or not client_id or not public_key_b64url:
        raise ValueError("tenant_id, client_id, and public_key_b64url are required")
    payload = {
        "tenant_id": tenant_id,
        "client_id": client_id,
        "public_key_b64url": public_key_b64url,
        "key_algorithm": "ed25519",
        "scopes": scopes or [],
        "metadata": metadata or {},
        "proof_kind": proof_kind,
        "proof_payload": _resolve_proof_payload(proof_payload, proof_auto, proof_aud, proof_kind),
        "auto_approve": bool(auto_approve),
    }
    base = base_url.rstrip("/")
    resp = _http_json_post(f"{base}/enroll-requests", payload)
    if auto_approve and proof_auto and _should_retry_auto_approve(resp):
        payload["proof_payload"] = _resolve_proof_payload(
            None,
            proof_auto,
            proof_aud,
            proof_kind,
            force_refresh=True,
        )
        resp = _http_json_post(f"{base}/enroll-requests", payload)
    return resp


def onboard(
    base_url: str,
    tenant_id: str,
    client_id: str,
    api_id: Optional[str] = None,
    auth_base_url: Optional[str] = None,
    scopes: Optional[list] = None,
    proof_kind: str = "oidc",
    proof_payload: Optional[str] = None,
    proof_auto: bool = True,
    proof_aud: str = "trustplane-enroll",
    auto_approve: bool = True,
    verify: bool = False,
) -> Dict[str, Any]:
    keys = gen_keypair()
    enroll = enroll_request(
        base_url=base_url,
        tenant_id=tenant_id,
        client_id=client_id,
        public_key_b64url=keys["public_key_b64url"],
        scopes=scopes or [],
        proof_kind=proof_kind,
        proof_payload=proof_payload,
        proof_auto=proof_auto,
        proof_aud=proof_aud,
        auto_approve=auto_approve,
    )
    result = {
        "public_key_b64url": keys["public_key_b64url"],
        "private_key_b64url": keys["private_key_b64url"],
        "enroll_response": enroll,
    }
    if verify:
        if not auth_base_url:
            raise ValueError("auth_base_url is required for verify")
        if not api_id:
            raise ValueError("api_id is required for verify")
        signed = sign(
            tenant_id=tenant_id,
            api_id=api_id,
            client_id=client_id,
            private_key_b64url=keys["private_key_b64url"],
            method="GET",
            path="/orders",
            body="",
        )
        verify_payload = signed["verify_payload"]
        base = auth_base_url.rstrip("/")
        result["verify_response"] = _http_json_post(f"{base}/auth/verify", verify_payload)
    return result


def blindfold_verify(
    auth_base_url: str,
    tenant_id: str,
    api_id: str,
    client_id: str,
    private_key_b64url: str,
    method: str = "GET",
    path: str = "/",
    body: str = "",
    bucket_seconds: int = 20,
) -> Dict[str, Any]:
    signed = sign(
        tenant_id=tenant_id,
        api_id=api_id,
        client_id=client_id,
        private_key_b64url=private_key_b64url,
        method=method,
        path=path,
        body=body,
        bucket_seconds=bucket_seconds,
    )
    base = auth_base_url.rstrip("/")
    vp = signed["verify_payload"]

    start = _http_json_post(
        f"{base}/auth/blindfold/start",
        {
            "tenant_id": vp["tenant_id"],
            "api_id": vp["api_id"],
            "client_id": vp["client_id"],
            "method": vp["method"],
            "path": vp["path"],
            "body_hash": vp["body_hash"],
            "time_bucket": vp["time_bucket"],
            "nonce": vp["nonce"],
        },
    )
    if not start["ok"]:
        return {"step": "start", **start}

    oprf_input = signed["digest_b64url"]
    masked = _oprf_mask_input(oprf_input)
    eval_res = _http_json_post(
        f"{base}/oprf/full-evaluate",
        {"blinded_input_b64url": _b64url_encode(masked["masked"])},
    )
    if not eval_res["ok"]:
        return {"step": "evaluate", **eval_res}

    evaluated = _b64url_decode(eval_res["data"].get("evaluated_b64url", ""))
    proof_payload = _b64url_encode(_oprf_unmask(evaluated, masked["mask"]))

    finalize = _http_json_post(
        f"{base}/auth/blindfold/finalize",
        {
            "session_id": start["data"].get("session_id", ""),
            "proof_payload": proof_payload,
        },
    )
    if not finalize["ok"]:
        return {"step": "finalize", **finalize}

    verify_payload = dict(vp)
    verify_payload["proof_type"] = "blindfold"
    verify_payload["proof_payload"] = (
        finalize.get("data", {}).get("verify_payload", {}).get("proof_payload", "")
        or proof_payload
    )
    verify = _http_json_post(f"{base}/auth/verify", verify_payload)
    return {
        "step": "verify",
        **verify,
        "verify_payload": verify_payload,
        "digest_b64url": signed["digest_b64url"],
    }
