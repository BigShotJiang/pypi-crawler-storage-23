"""
Entry point for `python -m magicc`.
"""
from magicc.cli import main

if __name__ == '__main__':
    main()
