"""Domain constants shared across JAMMA modules."""

# GEMMA encodes missing phenotypes as -9 in .fam files.
PHENOTYPE_MISSING: float = -9.0
