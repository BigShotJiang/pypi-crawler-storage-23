from .global_config import global_config as global_config
