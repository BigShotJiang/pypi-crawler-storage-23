from arcade_microsoft_utils.client import StaticTokenCredential, get_client

__all__ = ["StaticTokenCredential", "get_client"]
