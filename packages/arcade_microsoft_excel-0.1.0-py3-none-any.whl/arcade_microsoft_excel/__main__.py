import argparse
from typing import cast

from arcade_mcp_server import MCPApp
from arcade_mcp_server.mcp_app import TransportType

import arcade_microsoft_excel

app = MCPApp(
    name="MicrosoftExcel",
    instructions=(
        "Use this server when you need to work with Microsoft Excel workbooks stored "
        "in OneDrive for Business. Only .xlsx files are supported. "
        "To find Excel files, use OneDrive.search_items with keywords like 'xlsx' or 'excel'."
    ),
)

app.add_tools_from_module(arcade_microsoft_excel)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the Microsoft Excel MCP server.")
    parser.add_argument(
        "--host", type=str, default="127.0.0.1", help="Host to bind the server."
    )
    parser.add_argument(
        "--port", type=int, default=8000, help="Port to bind the server."
    )
    parser.add_argument(
        "--transport",
        type=str,
        default="stdio",
        choices=["stdio", "http"],
        help="Transport type (stdio or http).",
    )
    args = parser.parse_args()

    app.run(
        host=args.host, port=args.port, transport=cast(TransportType, args.transport)
    )


if __name__ == "__main__":
    main()
