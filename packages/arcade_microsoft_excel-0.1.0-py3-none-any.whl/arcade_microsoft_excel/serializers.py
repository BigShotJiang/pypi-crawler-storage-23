"""Serializers for Excel workbook and worksheet Graph API responses."""

from typing import Any, cast

from arcade_microsoft_utils.utils import human_friendly_bytes_size, remove_none_values

from arcade_microsoft_excel.tool_responses import WorkbookItemData, WorksheetInfo


def serialize_workbook_item(item: dict[str, Any]) -> WorkbookItemData:
    """Serialize a DriveItem dict (from Graph API) into WorkbookItemData."""
    data: dict[str, Any] = {
        "object_type": "workbook",
        "item_id": item.get("id"),
        "name": item.get("name"),
    }

    parent_ref = item.get("parentReference")
    if parent_ref and parent_ref.get("id"):
        data["parent_folder_id"] = parent_ref["id"]

    size = item.get("size")
    if size is not None:
        data["size"] = {
            "bytes": size,
            "formatted": human_friendly_bytes_size(size),
        }

    if item.get("webUrl"):
        data["web_url"] = item["webUrl"]

    if item.get("eTag"):
        data["etag"] = item["eTag"]

    return cast(WorkbookItemData, remove_none_values(data))


def serialize_worksheet(ws: dict[str, Any]) -> WorksheetInfo:
    """Serialize a worksheet dict from Graph API response."""
    return {
        "id": ws.get("id", ""),
        "name": ws.get("name", ""),
        "position": ws.get("position", 0),
        "visibility": ws.get("visibility", "Visible"),
    }


def serialize_worksheet_from_sdk(ws: Any) -> WorksheetInfo:
    """Serialize a worksheet from SDK response object."""
    return {
        "id": ws.id or "",
        "name": ws.name or "",
        "position": ws.position if ws.position is not None else 0,
        "visibility": ws.visibility or "Visible",
    }
