
import os
import sys
from pathlib import Path

def find_workspace_root() -> Path:
    """Find the workspace root by looking for .agent or .git."""
    curr = Path(os.getcwd()).resolve()
    for parent in [curr] + list(curr.parents):
        if (parent / ".agent").exists() or (parent / ".git").exists():
            return parent
    return curr

WORKSPACE_ROOT = find_workspace_root()
AGENT_DIR = WORKSPACE_ROOT / ".agent"
MEMORY_DIR = AGENT_DIR / "memory"
SESSIONS_DIR = MEMORY_DIR / "sessions"
LOG_DIR = AGENT_DIR / "logs"
RULES_DIR = AGENT_DIR / "rules"
WORKFLOWS_DIR = AGENT_DIR / "workflows"
PERSONAS_DIR = AGENT_DIR / "roles" # We still look in .agent/roles for now
SKILLS_DIR = AGENT_DIR / "skills"
ACTIVE_CONTEXT_PATH = WORKSPACE_ROOT / "active_context.md"
RULES_PATH = RULES_DIR / "RULES.md"
METRICS_DIR = WORKSPACE_ROOT / "docs" / "metrics"

def ensure_dirs():
    """Ensure essential directories exist."""
    for d in [SESSIONS_DIR, LOG_DIR]:
        d.mkdir(parents=True, exist_ok=True)
