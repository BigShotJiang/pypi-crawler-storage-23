
import json
import asyncio
from typing import List, Optional
from mcp.server.fastmcp import FastMCP
from .delegator import run_sub_agent, auto_bundle_context

# Initialize FastMCP server
mcp = FastMCP("gemini-subagent")

@mcp.tool()
async def delegate_task(
    prompt: str,
    context_files: List[str] = [],
    persona: Optional[str] = None,
    workflow: Optional[str] = None,
    background: bool = True
) -> str:
    """
    Delegate a task to a Gemini sub-agent using the orchestration logic.
    
    Args:
        prompt: The main instruction for the sub-agent.
        context_files: Specific file paths to include.
        persona: The persona to use (e.g. 'backend').
        workflow: The workflow to include (e.g. 'test').
        background: Whether to run in background (default True).
    """
    # Bundle context
    bundled = auto_bundle_context(
        context_files=context_files,
        include_personas=[persona] if persona else None,
        include_workflows=[workflow] if workflow else None,
        task_prompt=prompt
    )
    
    # Run
    result_json = await run_sub_agent(
        prompt=prompt,
        context_files=bundled,
        background=background
    )
    
    return result_json

if __name__ == "__main__":
    mcp.run()
