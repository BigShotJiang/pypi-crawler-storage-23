
# SUBGEMI: Gemini Sub-Agent Orchestration

Parallel orchestration CLI for Gemini sub-agents.

## Installation

```bash
pip install gemini-subagent
```

## Usage

Once installed, you can use the `subgemi` command:

```bash
# Delegate a task to a parallel sub-agent
subgemi task delegate "Audit the code in src/auth.py" --persona security_auditor --file src/auth.py

# View the live dashboard
subgemi session board
```

## Features

- **Parallelism**: Dispatches tasks in the background by default.
- **Git Review**: Automatically creates isolation branches for sub-agents at `subgemi/sub_<timestamp>`.
- **Context Bundling**: Automatically finds and includes relevant rules, workflows, and plan files.
- **Tmux Integration**: Background tasks spawn tmux sessions for real-time monitoring.
