"""Common/shared (serializable) Models (dataclassses) for Music Assistant."""
