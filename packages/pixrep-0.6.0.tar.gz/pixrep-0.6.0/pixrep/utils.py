from functools import lru_cache


def xml_escape(text: str) -> str:
    return (text
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;")
            .replace("'", "&#39;"))


@lru_cache(maxsize=8192)
def char_width(char: str, font_size: float) -> float:
    """
    估算单个字符的渲染宽度。
    CJK字符约为 font_size 宽，ASCII约为 font_size * 0.6。
    """
    cp = ord(char)
    if (0x2E80 <= cp <= 0x9FFF) or \
       (0xF900 <= cp <= 0xFAFF) or \
       (0xFE30 <= cp <= 0xFE4F) or \
       (0xFF00 <= cp <= 0xFFEF) or \
       (0x20000 <= cp <= 0x2FA1F) or \
       (0x3000 <= cp <= 0x303F):
        return font_size * 1.0
    return font_size * 0.6


@lru_cache(maxsize=32768)
def _str_width_cached(text: str, font_size: float) -> float:
    return sum(char_width(c, font_size) for c in text)


def str_width(text: str, font_size: float) -> float:
    """
    估算字符串的渲染宽度。

    Note: caching full strings can create memory pressure for huge files.
    We only cache "short" strings; long strings are computed directly.
    """
    if text.isascii():
        return len(text) * font_size * 0.6
    if len(text) > 256:
        return sum(char_width(c, font_size) for c in text)
    return _str_width_cached(text, font_size)


def truncate_to_width(text: str, font_size: float, max_width: float) -> str:
    """将字符串截断到不超过 max_width 像素宽度"""
    if text.isascii():
        max_chars = int(max_width / (font_size * 0.6))
        if len(text) <= max_chars:
            return text
        return text[:max(0, max_chars)] + "…"

    w = 0.0
    for i, c in enumerate(text):
        w += char_width(c, font_size)
        if w > max_width:
            return text[:i] + "…"
    return text


def pdf_bytes_to_long_png(pdf_bytes: bytes, dpi: int = 150, max_total_pixels: int = 120_000_000) -> bytes:
    """将 PDF 字节流渲染为单张垂直拼接长图的 PNG 字节流。

    Parameters
    ----------
    pdf_bytes : bytes
        完整的 PDF 文件内容（内存中）。
    dpi : int
        渲染分辨率，默认 150。越高越清晰但文件越大。

    Returns
    -------
    bytes
        PNG 格式的图片字节流。
    """
    import fitz
    from PIL import Image
    import io

    Image.MAX_IMAGE_PIXELS = None

    doc = fitz.open(stream=pdf_bytes, filetype="pdf")
    images: list[Image.Image] = []
    total_height = 0
    max_width = 0
    total_pixels = 0

    for page in doc:
        pix = page.get_pixmap(dpi=dpi)
        img = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
        images.append(img)
        total_height += pix.height
        max_width = max(max_width, pix.width)
        total_pixels += pix.width * pix.height

    doc.close()

    if total_pixels > max_total_pixels and total_pixels > 0:
        scale = (max_total_pixels / total_pixels) ** 0.5
        resized: list[Image.Image] = []
        total_height = 0
        max_width = 0
        for img in images:
            new_w = max(1, int(img.width * scale))
            new_h = max(1, int(img.height * scale))
            shrunk = img.resize((new_w, new_h), resample=Image.Resampling.LANCZOS)
            resized.append(shrunk)
            total_height += new_h
            max_width = max(max_width, new_w)
            img.close()
        images = resized

    if not images:
        canvas = Image.new("RGB", (1, 1), color="white")
    else:
        canvas = Image.new("RGB", (max_width, total_height), color="white")
        y_offset = 0
        for img in images:
            canvas.paste(img, (0, y_offset))
            y_offset += img.height
            img.close()

    out_buf = io.BytesIO()
    canvas.save(out_buf, format="PNG", optimize=True)
    return out_buf.getvalue()
