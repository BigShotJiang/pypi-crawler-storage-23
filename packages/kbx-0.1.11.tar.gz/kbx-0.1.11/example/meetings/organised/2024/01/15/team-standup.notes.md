---
title: Team Standup
date: 2024-01-15
source: granola
tags: [standup, weekly]
---

## Notes

- Alice presented the Q1 roadmap update
- Bob raised a concern about API rate limits
- Carol demoed the new search feature

## Transcript

**Me:** Good morning everyone. Let's start with updates.

**System:** Sure. The API rate limiting work is almost done. We should be able to deploy by end of week.

**Me:** Great. Carol, how's the search feature coming along?

**System:** The hybrid search is working well. FTS5 handles keyword queries and the vector search picks up semantic matches.
