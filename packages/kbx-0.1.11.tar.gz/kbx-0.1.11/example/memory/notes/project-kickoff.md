---
title: Project Kickoff Notes
date: 2024-01-10
tags: [project, planning]
---

## Key Decisions

- Use hybrid search (FTS5 + vector) for best results
- Start with Qwen3-Embedding-0.6B model
- Index meetings and memory files separately
