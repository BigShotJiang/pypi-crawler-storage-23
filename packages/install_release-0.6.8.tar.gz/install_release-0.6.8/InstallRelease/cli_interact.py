import os
from typing import Dict, Optional, cast
from tempfile import TemporaryDirectory
import platform

# pipi
from rich.progress import track
from rich.console import Console

# locals
from InstallRelease.data import Release, irKey, TypeState, ReleaseAssets

from InstallRelease.pkgs.main import (
    detect_package_type_from_asset_name,
    detect_package_type_from_os_release,
    install_package,
)
from InstallRelease.utils import (
    mkdir,
    pprint,
    logger,
    show_table,
    is_none,
    threads,
    PackageVersion,
    requests_session,
    to_words,
    download,
)

from InstallRelease.core import (
    get_release,
    extract_release,
    install_bin,
    get_repo_info,
    RepoInfo,
)

from InstallRelease.release_scorer import PENALTY_KEYWORDS
from InstallRelease.config import cache, cache_config, config, dest


console = Console(width=40)

install_release_version = PackageVersion("install-release")
os_package_type = detect_package_type_from_os_release()

logger.debug(f"os_package_type: {os_package_type}")


def is_package(state, k):
    return hasattr(state[k], "install_method") and (
        state[k].install_method == "package"
    )


# ------- cli ----------


def _show_and_select_asset(release: Release, toolname: str) -> Optional[ReleaseAssets]:
    """Show all release assets in a table and let user select one by ID

    Returns:
        Selected ReleaseAssets object or None if cancelled
    """
    if not release.assets:
        pprint("[red]No assets available for this release[/red]")
        return None

    # Prepare data for table display
    assets_data = []
    for idx, asset in enumerate[ReleaseAssets](release.assets, start=1):
        if any(word in asset.name.lower() for word in PENALTY_KEYWORDS):
            continue
        assets_data.append(
            {
                "ID": idx,
                "Filename": asset.name,
                "Size (MB)": asset.size_mb() if hasattr(asset, "size_mb") else "N/A",
                "Downloads": asset.download_count
                if hasattr(asset, "download_count")
                else "N/A",
            }
        )

    # Display table
    show_table(assets_data, title=f"📦 Available Assets for {toolname}")

    # Get user selection
    pprint(
        "\n[yellow]Enter your desired file ID to install (or 'n' to cancel): [/yellow]",
        end="",
    )
    selection = input().strip()

    if selection.lower() == "n":
        return None

    try:
        selected_id = int(selection)
        if 1 <= selected_id <= len(release.assets):
            return release.assets[selected_id - 1]
        else:
            pprint(
                f"[red]Invalid ID. Please select between 1 and {len(release.assets)}[/red]"
            )
            return None
    except ValueError:
        pprint("[red]Invalid input. Please enter a number or 'n' to cancel[/red]")
        return None


def state_info():
    logger.debug(cache.state_file)
    logger.debug(cache_config.state_file)
    logger.debug(dest)


def _extract_words_from_filename(asset_filename: str) -> list:
    """Extract scoring keywords from an asset filename.

    Strips the extension, replaces dots with hyphens, and tokenizes.
    Returns: List of extracted keyword strings
    """
    basename = asset_filename.rsplit(".", 1)[0]
    return to_words(text=basename.replace(".", "-"), ignore_words=["v", "unknown"])


def _resolve_release_words(
    custom_words: Optional[list], cached_words: Optional[list]
) -> tuple:
    """Resolve extra_words and disable_penalties from custom and cached words.

    Priority: custom > cached > None.

    Returns: (extra_words, disable_penalties) tuple
    """
    if custom_words:
        return custom_words, True
    if cached_words:
        return cached_words, True
    return None, False


def _show_pkg_hint(releases: list, package_mode: bool) -> None:
    """Show a one-time hint if a native OS package is available but not selected.

    Only prints when package_mode is False and a matching package asset exists.

    Args:
        releases: List of Release objects
        package_mode: Whether --pkg was already requested
    """
    if package_mode or not os_package_type:
        return

    for release in releases:
        for asset in release.assets:
            if detect_package_type_from_asset_name(asset.name) == os_package_type:
                pprint(
                    f"[bold green]\n[INFO]: A `{os_package_type}` package is "
                    f"available for this release. Add `--pkg` to install it.[/bold green]"
                )
                return  # show hint only once


def _install_asset(
    asset: ReleaseAssets,
    release: "Release",
    package_mode: bool,
    package_type: Optional[str],
    toolname: str,
    temp_dir: str,
    local: bool,
) -> bool:
    """Download and install a release asset (package or binary).

    On success, mutates `release` with the installed asset metadata.

    Returns:
        True if installation succeeded, False otherwise
    """
    effective_pkg = (
        package_type
        if package_mode
        else detect_package_type_from_asset_name(asset.name)
    )

    if effective_pkg:
        download(asset.browser_download_url, temp_dir)
        logger.debug(f"Downloaded package to: {temp_dir}")

        success = install_package(
            package_type=effective_pkg,
            name=toolname,
            temp_dir=temp_dir,
        )
        if not success:
            logger.error(f"Failed to install {toolname} as {effective_pkg} package")
            return False

        release.assets = [asset]
        release.package_type = effective_pkg
        release.install_method = "package"
    else:
        extract_release(item=asset, at=temp_dir)
        release.assets = [asset]
        mkdir(dest)
        if not install_bin(src=temp_dir, dest=dest, local=local, name=toolname):
            return False

    return True


def get(
    repo: RepoInfo,
    tag_name: str = "",
    asset_file: str = "",
    local: bool = True,
    prompt: bool = False,
    name: Optional[str] = None,
    package_mode: bool = False,
) -> None:
    """Get a release from a GitHub/GitLab repository

    Args:
        repo: Repository information handler
        tag_name: Specific tag to fetch
        asset_file: Filename pattern to extract words from
        local: Whether to install locally (ignored for packages)
        prompt: Whether to prompt for confirmation
        name: Optional name to give the installed tool
        package_mode: Whether to install as a package (auto-detects type)
    """
    state_info()

    logger.debug(f"Python version: {platform.python_version()}")
    logger.debug(f"Platform: {platform.platform()}")
    try:
        logger.debug(f"Platform version: {platform.version()}")
        logger.debug(f"Platform release: {platform.release()}")
    except Exception as e:
        logger.error(f"Error getting platform info: {e}")

    # --- Parse custom words from asset_file --------------------------------
    custom_release_words = (
        _extract_words_from_filename(asset_file) if not is_none(asset_file) else None
    )

    # --- Fetch releases ----------------------------------------------------
    pre_release = bool(config.pre_release) if hasattr(config, "pre_release") else False
    releases = repo.release(tag_name=tag_name, pre_release=pre_release)

    if package_mode and os_package_type:
        """Filter release assets to only the requested package type.
        Falls back to AppImage if no native packages are found.
        Mutates release.assets in-place.
        """
        for release in releases:
            native = [
                a
                for a in release.assets
                if detect_package_type_from_asset_name(a.name) == os_package_type
            ]
            fallback = [
                a
                for a in release.assets
                if detect_package_type_from_asset_name(a.name) == "AppImage"
            ]
            release.assets = native or fallback

            if (
                release.assets
                and detect_package_type_from_asset_name(release.assets[0].name)
                == "AppImage"
                and os_package_type != "AppImage"
            ):
                logger.info(
                    f"No {os_package_type} package found, falling back to AppImage"
                )

    if not releases:
        logger.error(f"No releases found: {repo.repo_url}")
        return

    # ---  Resolve extra_words (custom > cached > None) ----------------------
    toolname = repo.repo_name.lower() if is_none(name) else name.lower()

    cached_release = cache.get(f"{repo.repo_url}#{toolname}")
    cached_custom_words = (
        cached_release.custom_release_words
        if cached_release
        and hasattr(cached_release, "custom_release_words")
        and cached_release.custom_release_words
        else None
    )

    extra_words, disable_penalties = _resolve_release_words(
        custom_release_words, cached_custom_words
    )

    logger.debug(f"custom_release_words: {custom_release_words}")
    logger.debug(f"cached_custom_words: {cached_custom_words}")
    logger.debug(f"extra_words: {extra_words}")
    logger.debug(f"disable_penalties: {disable_penalties}")

    # --- Validate package mode ---------------------------------------------
    package_type = os_package_type
    if package_mode:
        if not package_type:
            logger.error("Could not detect appropriate package type for your system")
            return
        logger.info(f"Installing as {package_type} package")

    # ---  Score & select asset ----------------------------------------------
    # Try exact name match: explicit --file, or previously cached asset name
    asset = None
    known_names = set()
    if not is_none(asset_file):
        known_names.add(asset_file)
    if cached_release and cached_release.assets:
        known_names.add(cached_release.assets[0].name)

    if known_names:
        for a in releases[0].assets:
            if a.name in known_names:
                asset = a
                logger.debug(f"Exact asset match: '{a.name}'")
                break

    if asset is None:
        result = get_release(
            releases=releases,
            repo_url=repo.repo_url,
            extra_words=extra_words,
            disable_penalties=disable_penalties,
            package_type=package_type if package_mode else None,
        )

        logger.debug(result)

        if result is False:
            logger.error("No suitable release assets found")
            return

        asset = cast(ReleaseAssets, result)

    # --- Show pkg hint (only when not in --pkg mode) -----------------------
    _show_pkg_hint(releases, package_mode)

    # --- Prompt user -------------------------------------------------------
    if prompt is not False:
        pprint(
            f"\n[green bold]📑 Repo     : {repo.info.full_name}"
            f"\n[blue]🌟 Stars    : {repo.info.stargazers_count}"
            f"\n[magenta]🔮 Language : {repo.info.language if repo.info.language else 'N/A'}"
            f"\n[yellow]🔥 Title    : {repo.info.description}"
        )
        show_table(
            data=[
                {
                    "Name": toolname,
                    "Selected Item": asset.name,
                    "Version": releases[0].tag_name,
                    "Size Mb": asset.size_mb() if hasattr(asset, "size_mb") else "N/A",
                    "Downloads": asset.download_count
                    if hasattr(asset, "download_count")
                    else "N/A",
                }
            ],
            title=f"🚀 Install: {toolname}",
        )
        pprint(f"[color(6)]\nPath: {dest}")
        pprint("[color(34)]Install this tool (Y/n/?): ", end="")
        yn = input()

        if yn.lower() == "?":
            selected_asset = _show_and_select_asset(releases[0], toolname)
            if selected_asset is None:
                return
            asset = selected_asset
            custom_release_words = _extract_words_from_filename(asset.name)
            pprint("\n[magenta]Downloading...[/magenta]")
        elif yn.lower() != "y":
            return
        else:
            pprint("\n[magenta]Downloading...[/magenta]")

    # ---  Install (package or binary) ---------------------------------------
    at = TemporaryDirectory(prefix=f"dn_{repo.repo_name}_")
    if not _install_asset(
        asset,
        releases[0],
        package_mode=package_mode,
        package_type=package_type,
        toolname=toolname,
        temp_dir=at.name,
        local=local,
    ):
        return

    # ---  Persist to cache --------------------------------------------------
    releases[0].hold_update = bool(tag_name)

    # Persist custom_release_words: custom > cached
    resolved_words, _ = _resolve_release_words(
        custom_release_words, cached_custom_words
    )
    if resolved_words:
        releases[0].custom_release_words = resolved_words

    cache.set(f"{repo.repo_url}#{toolname}", value=releases[0])
    cache.save()


def upgrade(
    force: bool = False, skip_prompt: bool = False, packages_only: bool = False
) -> None:
    """Upgrade all installed tools

    Args:
        force: Whether to force upgrade even if not newer
        skip_prompt: Whether to skip confirmation prompt
        packages_only: Whether to upgrade only packages (not binaries)
    """
    state_info()

    state: TypeState = cache.state

    upgrades: Dict[str, RepoInfo] = {}
    pkg_upgrades: Dict[str, RepoInfo] = {}

    def task(k: str) -> None:
        i = irKey(k)
        release = state[k]

        # Filter by package type if requested
        if packages_only:
            if (
                not hasattr(release, "install_method")
                or release.install_method != "package"
            ):
                return

        try:
            if state[k].hold_update is True:
                return
        except AttributeError:
            pass

        repo = get_repo_info(i.url)
        pprint(f"Fetching: {k}")
        # Ensure pre_release is boolean
        pre_release = (
            bool(config.pre_release) if hasattr(config, "pre_release") else False
        )
        releases = repo.release(pre_release=pre_release)

        if releases[0].published_dt() > state[k].published_dt() or force is True:
            if is_package(state, k) and not packages_only:
                pkg_upgrades[i.name] = repo
            else:
                upgrades[i.name] = repo

    threads(task, data=[k for k in state], max_workers=20, return_result=False)

    if packages_only is False and len(pkg_upgrades) > 0:
        pprint("\n[bold cyan]Following package can be upgraded.[/]\n")
        pprint("[bold indian_red]" + " ".join(pkg_upgrades.keys()))
        pprint(
            "\n[bold white]To upgrade packages, run: [green]ir upgrade --pkg[/green][/]\n"
        )

    # ask prompt to upgrade listed tools
    if len(upgrades) > 0:
        pprint("\n[bold magenta]Following tool will get upgraded.\n")
        console.print("[bold yellow]" + " ".join(upgrades.keys()))
        pprint("\n[bold blue]Upgrade these tools, (Y/n):", end=" ")

        if skip_prompt is False:
            r = input()
            if r.lower() != "y":
                return
    else:
        pprint("[bold green]All tools are onto latest version")
        return

    for name in track(upgrades, description="Upgrading...", disable=packages_only):
        repo = upgrades[name]
        releases = repo.release()
        k = f"{repo.repo_url}#{name}"

        pprint(
            "[bold yellow]"
            f"Updating: {name}, {state[k].tag_name} => {releases[0].tag_name}"
            "[/]"
        )

        get(repo, prompt=False, name=name, package_mode=is_package(state, k))


def show_state():
    """
    | Show state of all tools
    """
    state_info()
    if os.path.exists(cache.state_file) and os.path.isfile(cache.state_file):
        with open(cache.state_file) as f:
            print(f.read())


def list_install(
    state: Optional[TypeState] = None,
    title: str = "Installed tools",
    hold_update: bool = False,
) -> None:
    """List all installed tools

    Args:
        state: Optional state data to list, defaults to global state
        title: Title to display for the list
        hold_update: Whether to show only tools with updates on hold
    """
    if state is None:
        state_info()
        state = cache.state

    _table = []
    _hold_table = []
    for key in state:
        i = irKey(key)
        state[key]

        if hold_update:
            if state[key].hold_update is True:
                _hold_table.append(
                    {
                        "Name": i.name,
                        "Version": f"[dim]{state[key].tag_name}",
                        "Url": f"[dim]{state[key].url}",
                    }
                )
            continue

        # Add package type info if it's a package
        version_str = state[key].tag_name
        if is_package(state, key):
            version_str += " [cyan](pkg)[/cyan]"

        if state[key].hold_update is True:
            version_str += "[yellow] *HOLD_UPDATE*[/yellow]"

        _table.append(
            {
                "Name": i.name,
                "Version": version_str,
                "Url": state[key].url,
            }
        )

    if hold_update:
        show_table(_hold_table, title=f"{title} kept on hold")
    else:
        show_table(_table, title=title)


def remove(name: str):
    """
    | Remove any cli tool.

    Args:
        name: The name of the tool to remove
        as_package: Whether to remove as a package (use system package manager)

    Returns:
        None
    """
    state_info()
    state: TypeState = cache.state
    popKey = ""

    # Find the tool in the state
    for key in state:
        i = irKey(key)
        if i.name == name:
            popKey = key
            release = state[key]

            if is_package(state, key):
                if not hasattr(release, "package_type"):
                    logger.warning(f"{name} was not installed as a package")
                else:
                    package_type = release.package_type
                    logger.info(f"Removing {name} as {package_type} package")

                    try:
                        if package_type == "deb":
                            from InstallRelease.pkgs.deb import DebPackage

                            installer = DebPackage(name)
                            installer.uninstall()
                        elif package_type == "rpm":
                            from InstallRelease.pkgs.rpm import RpmPackage

                            installer = RpmPackage(name)
                            installer.uninstall()
                        elif package_type == "AppImage":
                            from InstallRelease.pkgs.app_images import AppImage

                            installer = AppImage(name)
                            installer.uninstall()
                    except Exception as e:
                        logger.error(f"Failed to uninstall package: {e}")
            else:
                # Remove binary file (existing code)
                try:
                    tool_path = f"{dest}/{name}"
                    if os.path.exists(tool_path):
                        os.remove(tool_path)
                        logger.debug(f"Removed file: {tool_path}")
                except OSError as e:
                    logger.error(f"Failed to remove file: {e}")
            break

    # Remove from state if found
    if popKey:
        try:
            del state[popKey]
            cache.save()
            logger.info(f"Removed: {name}")
        except Exception as e:
            logger.error(f"Failed to update state: {e}")
    else:
        logger.warning(f"Tool not found: {name}")


def hold(name: str, hold_update: bool):
    """
    | Holds updates of any cli tool.
    """
    state_info()
    state: TypeState = cache.state

    for _k in state:
        key = irKey(_k)
        if key.name == name:
            state[_k].hold_update = hold_update
            logger.info(f"Update on hold for, {name} to {hold_update}")
            break
    cache.save()


def pull_state(url: str = "", override: bool = False):
    """
    | Install tools from remote state
    """
    logger.debug(url)

    if is_none(url):
        return

    r: dict = requests_session.get(url=url).json()

    data: dict = {k: Release(**r[k]) for k in r}
    state: TypeState = cache.state

    temp: Dict[str, Release] = {}

    for key in data:
        try:
            i = irKey(key)
        except Exception:
            logger.warning(f"Invalid input: {key}")
            continue

        if state.get(key) is not None:
            if state[key].tag_name == data[key].tag_name or override is False:
                logger.debug(f"Skipping: {key}")
                continue
            else:
                temp[key] = data[key]
        else:
            temp[key] = data[key]

    logger.debug(temp)

    if len(temp) == 0:
        return

    list_install(state=temp, title="Tools to be installed")
    pprint("\n[bold magenta]Following tool will get Installed.\n")
    pprint("[bold blue]Install these tools, (Y/n):", end=" ")

    _i = input()
    if _i.lower() != "y":
        return

    for key in temp:
        try:
            i = irKey(key)
        except Exception:
            logger.warning(f"Invalid input: {key}")
            continue
        get(
            get_repo_info(i.url),
            tag_name=temp[key].tag_name,
            prompt=False,
            name=i.name,
        )
