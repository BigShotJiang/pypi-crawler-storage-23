Developer Documentation
=======================

Contents:

.. toctree::
   :maxdepth: 2

   installation
   usage
   contributing

Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
