"""Core data loading (modality-agnostic)."""

from gradiend.data.core.base_loader import resolve_base_data

__all__ = [
    "resolve_base_data",
]
