from setuptools import setup

setup(
    cffi_modules=["py/rvspecfit/ffibuilder.py:ffibuilder"],
)
