Changes

* 26.03 Neural-network interpolator checkpoints are now versioned and validated on load, preventing accidental use of incompatible weights after model-code changes (legacy checkpoints can still be loaded with a warning).
* 26.02 Improve the VSINI fitting, should provide much more accurate values (change the the threshold for the RVS_WARN flag LARGE_VSINI).
* 26.02 Batch FFT in fitter_ccf (could provide tiny speedup)
* 26.02 Save cmdline used to create various products in the hdf5 file
* 26.01 Fix the sign bug with the log(determinant) from marginalization (pointed out by @fcotizelati )
* 25.10 Update docs
* 25.10 Switch from fork multiprocessing to spawn
* 25.06 Fix the bookeeping bug, when the DESI spectra- files are fitted. If the object was selected to be fitted based on it's targeting bits, but it does not satistfy (SPECTYPE='STAR' |3e5*Z|<1500) criteria then previously the RR_Z, RR_SPECTYPE would be null
* 25.04 Update the penalty at the edge. Previously it was very sharp, because it was jumping from zero to some value. Now it is smooth, as computed throug distance to the edge of the convex hull
* 25.04 DESI specific. Now if the hessian inversions failed, there will be a warning flag
* 25.04 DESI specific. Now the redrock subtype is also saved in the rvtab
* 25.04 When using BFGS optimizer, I provide initial Inverse hessian, which should help convergence
* 25.01.17 Changed a way logarithmic step is setup. it is now set relative to the center of the wavelength
* 0.6.0.241122 The new MPI mode was added
* 0.6.0 Now the preprocessed information about the templates is stored in the HDF5. That means that all this information has to be regenerated. If you don't want to do that, you should use the 0.5.0 version
