"""
aap - Automatic argparse wrapper for Python callables.

This package provides functionality to automatically generate command-line
interfaces from Python functions using their type hints and docstrings.
"""

from .core import autoarg

__version__ = "0.1.0"
__all__ = ["autoarg"]
