"""Tests to achieve 100% code coverage."""

from typing import List
import pytest
from aap import autoarg


def test_bool_without_default():
    """Test boolean parameter without default value."""
    def func(name: str, flag: bool):
        """Function with bool without default.
        
        Args:
            name: The name
            flag: A boolean flag
        """
        return f"{name}: {flag}"
    
    wrapped = autoarg(func)
    result = wrapped(['--name', 'test', '--flag'])
    assert result == "test: True"


def test_list_without_inner_type():
    """Test List type without inner type specification."""
    def func(items: List):
        """Function with untyped List.
        
        Args:
            items: List of items
        """
        return len(items)
    
    wrapped = autoarg(func)
    result = wrapped(['--items', 'a', 'b', 'c'])
    assert result == 3


def test_none_default_value():
    """Test parameter with None as default value."""
    def func(name: str, value: str = None):
        """Function with None default.
        
        Args:
            name: The name
            value: Optional value
        """
        return f"{name}: {value}"
    
    wrapped = autoarg(func)
    result = wrapped(['--name', 'test'])
    assert result == "test: None"
