"""Additional edge case tests to achieve 100% coverage."""

from typing import Union
import pytest
from aap.parser import get_argparse_type


def test_get_argparse_type_union_multiple_non_none():
    """Test Union with multiple non-None types defaults to str."""
    union_type = Union[int, str, float]
    result_type, result_kwargs = get_argparse_type(union_type)
    assert result_type == str
    assert result_kwargs == {}


def test_get_argparse_type_custom_callable():
    """Test custom callable type."""
    def custom_type(value):
        return int(value) * 2
    
    result_type, result_kwargs = get_argparse_type(custom_type)
    assert result_type == custom_type
    assert result_kwargs == {}


def test_get_argparse_type_non_callable_fallback():
    """Test non-callable type falls back to str."""
    class NonCallableType:
        pass
    
    # Create an instance (not callable)
    instance = NonCallableType()
    result_type, result_kwargs = get_argparse_type(instance)
    assert result_type == str
    assert result_kwargs == {}


def test_get_argparse_type_list_without_args():
    """Test List without type arguments."""
    from typing import List
    # This simulates List without [T]
    result_type, result_kwargs = get_argparse_type(list)
    # Should handle as basic list type
    assert result_type == list or result_type == str
