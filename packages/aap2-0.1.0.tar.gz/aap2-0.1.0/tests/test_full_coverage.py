"""Tests to achieve 100% code coverage for remaining lines."""

import pytest
from aap import autoarg


def test_numpy_style_multiline_description():
    """Test NumPy-style docstring with multiline parameter descriptions."""
    def func(param1: str, param2: int):
        """
        A function with NumPy-style docstring.
        
        Parameters
        ----------
        param1 : str
            This is a long description
            that spans multiple lines
        param2 : int
            Another parameter
        """
        return f"{param1}: {param2}"
    
    wrapped = autoarg(func)
    result = wrapped(['--param1', 'test', '--param2', '42'])
    assert result == "test: 42"


def test_empty_help_text_with_none_default():
    """Test that empty help text doesn't add default for None values."""
    def func(name: str, optional: str = None):
        """Function with None default and no param docs."""
        return f"{name}: {optional}"
    
    wrapped = autoarg(func)
    result = wrapped(['--name', 'test'])
    assert result == "test: None"


def test_required_non_boolean_without_default():
    """Test required non-boolean parameter without default."""
    def func(required_param: int):
        """Function with required parameter.
        
        Args:
            required_param: A required integer
        """
        return required_param * 2
    
    wrapped = autoarg(func)
    result = wrapped(['--required-param', '5'])
    assert result == 10
