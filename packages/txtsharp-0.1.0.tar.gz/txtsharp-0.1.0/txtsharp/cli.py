# cli.py
import sys
from .core import Tsharp

def main():
    if len(sys.argv) < 2:
        print("Usage: txtsharp <file.tsh>")
        sys.exit(1)

    filename = sys.argv[1]
    if not filename.endswith(".tsh"):
        print("Error: T# files must have a .tsh extension")
        sys.exit(1)

    Tsharp().run_file(filename)

if __name__ == "__main__":
    main()