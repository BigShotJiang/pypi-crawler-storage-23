# __init__.py
from .core import Tsharp

__version__ = "0.1.0"