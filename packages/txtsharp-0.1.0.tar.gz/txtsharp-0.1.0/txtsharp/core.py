# core.py
class Tsharp:
    def __init__(self):
        self.vars = {}

    def get_var(self, name):
        return self.vars.get(name, 0)

    def set_var(self, name, value):
        self.vars[name] = value

    def eval_value(self, value):
        value = value.strip()
        # Number check
        if value.replace(".", "", 1).isdigit():
            if "." in value:
                return float(value)
            return int(value)
        # Known variable
        if value in self.vars:
            return self.vars[value]
        # Text fallback
        return value

    def run_line(self, line):
        line = line.strip()
        if not line or line.startswith("#"):
            return

        # SET <variable> TO <value>
        if line.lower().startswith("set "):
            parts = line[4:].split(" to ", 1)
            if len(parts) == 2:
                var_name = parts[0].strip()
                value = self.eval_value(parts[1])
                self.set_var(var_name, value)
            else:
                print(f"Invalid set command: {line}")
            return

        # SHOW <value/variable>
        if line.lower().startswith("show "):
            value = self.eval_value(line[5:])
            print(value)
            return

        # ASK <variable> (input)
        if line.lower().startswith("ask "):
            var_name = line[4:].strip()
            self.set_var(var_name, input(f"{var_name}: "))
            return

        # Math commands: add/subtract/multiply/divide
        words = line.lower().split()
        if words[0] in ["add", "subtract", "multiply", "divide"]:
            if "to" in words:
                idx = words.index("to")
                num = self.eval_value(" ".join(words[1:idx]))
                var = " ".join(words[idx+1:])
                self.set_var(var, self.get_var(var) + num)
                return
            elif "from" in words:
                idx = words.index("from")
                num = self.eval_value(" ".join(words[1:idx]))
                var = " ".join(words[idx+1:])
                self.set_var(var, self.get_var(var) - num)
                return
            elif "by" in words:
                idx = words.index("by")
                num = self.eval_value(" ".join(words[1:idx]))
                var = " ".join(words[idx+1:])
                if words[0] == "multiply":
                    self.set_var(var, self.get_var(var) * num)
                elif words[0] == "divide":
                    self.set_var(var, self.get_var(var) / num)
                return

        print(f"Unknown command: {line}")

    def run_file(self, filename):
        try:
            with open(filename, "r") as f:
                for line in f:
                    self.run_line(line)
        except FileNotFoundError:
            print(f"File {filename} not found.")