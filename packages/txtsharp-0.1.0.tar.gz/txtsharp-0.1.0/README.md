# T# — Fully English Text-Based Programming Language

T# is an ultra-simple, beginner-friendly programming language where all commands are fully readable in English. Programs use the `.tsh` file extension.

---

## Features

- English-style commands
- Variables and assignment
- Input from user
- Math operations (`add`, `subtract`, `multiply`, `divide`)
- Print output
- Comments (`# this is a comment`)

---

## Installation

Install via PyPI:

```bash
pip install txtsharp
```

