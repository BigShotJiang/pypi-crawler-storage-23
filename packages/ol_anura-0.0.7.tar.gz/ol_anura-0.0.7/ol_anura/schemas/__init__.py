"""
Anura table schema definitions.
"""
