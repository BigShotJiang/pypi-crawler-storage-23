"""OptimizationDemandSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, DemandStatus, TechnologySupport

# OptimizationDemandSummary table schema
optimization_demand_summary = Table(
    table_name="OptimizationDemandSummary",
    neo=TechnologySupport.FULLY_SUPPORTED,
    dart=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OptDemandSmry",
    basic_mode_neo=True,
    basic_mode_dart=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["NEO", "DART"],
            master_column=["Scenarios.ScenarioName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Periods"],
            explanation="The time period that the results are reported for.",
            precision_category=["NaN"],
            basic_mode=["NEO", "DART"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CustomerName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Customers"],
            explanation="The name of the customer.",
            precision_category=["NaN"],
            basic_mode=["NEO", "DART"],
            master_column=["Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Products"],
            explanation="The name of the product.",
            precision_category=["NaN"],
            basic_mode=["NEO", "DART"],
            master_column=["Products.ProductName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ServiceMode",
            data_type=DataType.STRING,
            pk=True,
            master_table=["TransportationModes"],
            explanation="The name of the mode used to serve demand. Defaults to \"all\".",
            precision_category=["NaN"],
            basic_mode=["NEO", "DART"],
            master_column=["TransportationModes.ModeName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DemandStatus",
            data_type=DataType.STRING,
            explanation="The status of the demand record, one of Include, Exclude, or Consider.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OriginalDemandQuantity",
            data_type=DataType.DOUBLE,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The demand quantity as specified in the Customer Demand table. In the event of multiple demand records for a Customer / Product / Period combination, the demand will be summed into one single demand record.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ServedDemandQuantity",
            data_type=DataType.DOUBLE,
            explanation="The amount of demand served for the Customer / Product / Period combination.",
            precision_category=["Quantity"],
            basic_mode=["NEO", "DART"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnservedDemandQuantity",
            data_type=DataType.DOUBLE,
            explanation="The amount of demand that was unserved for the Customer / Product / Period combination.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReturnQuantity",
            data_type=DataType.DOUBLE,
            explanation="The quantity of returned product generated for the Customer / Product / Period combination.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DemandQuantityUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the quantity is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OriginalDemandVolume",
            data_type=DataType.DOUBLE,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The demand volume as specified in the Customer Demand table. In the event of multiple demand records for a Customer / Product / Period combination, the demand will be summed into one single demand record.",
            precision_category=["Volume"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ServedDemandVolume",
            data_type=DataType.DOUBLE,
            explanation="The amount of demand served for the Customer / Product / Period combination.",
            precision_category=["Volume"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnservedDemandVolume",
            data_type=DataType.DOUBLE,
            explanation="The amount of demand that was unserved for the Customer / Product / Period combination.",
            precision_category=["Volume"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReturnVolume",
            data_type=DataType.DOUBLE,
            explanation="The volume of returned product generated for the Customer / Product / Period combination.",
            precision_category=["Volume"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DemandVolumeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the volume is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OriginalDemandWeight",
            data_type=DataType.DOUBLE,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The demand weight as specified in the Customer Demand table. In the event of multiple demand records for a Customer / Product / Period combination, the demand will be summed into one single demand record.",
            precision_category=["Weight"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ServedDemandWeight",
            data_type=DataType.DOUBLE,
            explanation="The amount of demand served for the Customer / Product / Period combination.",
            precision_category=["Weight"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnservedDemandWeight",
            data_type=DataType.DOUBLE,
            explanation="The amount of demand that was unserved for the Customer / Product / Period combination.",
            precision_category=["Weight"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReturnWeight",
            data_type=DataType.DOUBLE,
            explanation="The weight of returned product generated for the Customer / Product / Period combination.",
            precision_category=["Weight"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DemandWeightUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the weight is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnservedDemandPenaltyCost",
            data_type=DataType.DOUBLE,
            explanation="The penalty cost associated with the unserved demand at the Customer / Product / Period combination.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Revenue",
            data_type=DataType.DOUBLE,
            explanation="The revenue associated with the served demand at the Customer / Product / Period combination. Revenue is calculated as Demand Served * Product Price.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CostToServe",
            data_type=DataType.DOUBLE,
            explanation="The landed cost associated with the served demand at the Customer / Product / Period combination.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConcentrationRisk",
            data_type=DataType.DOUBLE,
            explanation="The Concentration Risk score associated with this Customer / Product / Period combination. Concentration Risk is based on what portion of the total demand for the Customer / Period combination the listed product represents. This will contribute to the model's Customer Risk score.",
            precision_category=["Risk"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SourceCountRisk",
            data_type=DataType.DOUBLE,
            explanation="The Source Count Risk metric associated with this Product for the Customer/ Product / Period combination. Source Count Risk is determined based on the number of unique sources that are used to satisfy the demand records at this Customer / Period combination for the listed product. This will contribute to the model's Customer Risk Score.",
            precision_category=["Risk"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="GeographicRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with the geographic location of the Customer. This is a weighted average of several geographic components that are reported in greater detail in the Optimization Geographic Risk Metrics table.",
            precision_category=["Risk"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UserDefinedRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with the User Defined Risk value entered in the Customers table.",
            precision_category=["Risk"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Latitude",
            data_type=DataType.DOUBLE,
            explanation="The customer latitude.",
            precision_category=["GeoCoordinate"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Longitude",
            data_type=DataType.DOUBLE,
            explanation="The customer longitude.",
            precision_category=["GeoCoordinate"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
