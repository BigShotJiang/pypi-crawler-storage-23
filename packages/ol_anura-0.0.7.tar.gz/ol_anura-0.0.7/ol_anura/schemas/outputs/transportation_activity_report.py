"""TransportationActivityReport table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# TransportationActivityReport table schema
transportation_activity_report = Table(
    table_name="TransportationActivityReport",
    hopper=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="TransportationActivityRpt",
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["Scenarios.ScenarioName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ActivityID",
            data_type=DataType.INTEGER,
            required=True,
            pk=True,
            explanation="A unique identifier for the activity",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Type",
            data_type=DataType.STRING,
            required=True,
            explanation="The type of this activity. It could be Pickup, Delivery, Travel, Wait, Break, Rest, Vehicle Return, Admin",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteName",
            data_type=DataType.STRING,
            explanation="The route that contains the stop.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourID",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="A unique identifier for the tour (asset schedule) that the Route is assigned to",
            precision_category=["NaN"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StartDate",
            data_type=DataType.DATETIME,
            explanation="The date and time at which the activity starts.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="EndDate",
            data_type=DataType.DATETIME,
            explanation="The date and time at which the activity ends.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteType",
            data_type=DataType.STRING,
            explanation="The type of the route: Outbound, Inbound, Backhaul, Interleaved, Template or Reposition",
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TransportationAssetName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["TransportationAssets"],
            explanation="The name of the transportation asset.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["TransportationAssets.AssetName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StartLocationName",
            data_type=DataType.STRING,
            required=True,
            explanation="The location of the start of the activity.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="EndLocationName",
            data_type=DataType.STRING,
            required=True,
            explanation="The location of the end of the activity.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Distance",
            data_type=DataType.DOUBLE,
            explanation="The distance of the activity.",
            precision_category=["Distance"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Time",
            data_type=DataType.DOUBLE,
            explanation="The duration of the activity.",
            precision_category=["Distance"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TimeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure used for time.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Quantity",
            data_type=DataType.DOUBLE,
            explanation="The quantity of product in the truck after this activity.",
            precision_category=["Quantity"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="QuantityUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the quantities are expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Volume",
            data_type=DataType.DOUBLE,
            explanation="The volume of product in the truck after this activity.",
            precision_category=["Volume"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VolumeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the volumes are expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Weight",
            data_type=DataType.DOUBLE,
            explanation="The weight of product in the truck after this activity.",
            precision_category=["Weight"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WeightUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the weights are expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PickupQuantity",
            data_type=DataType.DOUBLE,
            explanation="The quantity of product picked up during this activity.",
            precision_category=["Quantity"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PickupVolume",
            data_type=DataType.DOUBLE,
            explanation="The volume of product picked up during this activity.",
            precision_category=["Volume"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PickupWeight",
            data_type=DataType.DOUBLE,
            explanation="The weight of product picked up during this activity.",
            precision_category=["Weight"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DeliveredQuantity",
            data_type=DataType.DOUBLE,
            explanation="The quantity of product delivered during this activity.",
            precision_category=["Quantity"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DeliveredVolume",
            data_type=DataType.DOUBLE,
            explanation="The volume of product delivered during this activity.",
            precision_category=["Volume"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DeliveredWeight",
            data_type=DataType.DOUBLE,
            explanation="The weight of product delivered during this activity.",
            precision_category=["Weight"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ActivityCost",
            data_type=DataType.DOUBLE,
            explanation="The cost for this activity.",
            precision_category=["Cost"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CurrentDutyTimeWithinShift",
            data_type=DataType.DOUBLE,
            explanation="The current duty time accumulated since the last rest.",
            precision_category=["Time"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CurrentDriveTimeWithinShift",
            data_type=DataType.DOUBLE,
            explanation="The current drive time accumulated since the last rest.",
            precision_category=["Time"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CurrentDriveTimeBeforeShortBreak",
            data_type=DataType.DOUBLE,
            explanation="The current drive time accumulated since the last break.",
            precision_category=["Time"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CurrentDutyTimeBeforeShortBreak",
            data_type=DataType.DOUBLE,
            explanation="The current duty time accumulated since the last break.",
            precision_category=["Time"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
