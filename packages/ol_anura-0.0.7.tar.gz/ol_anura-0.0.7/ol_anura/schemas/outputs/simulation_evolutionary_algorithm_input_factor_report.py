"""SimulationEvolutionaryAlgorithmInputFactorReport table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# SimulationEvolutionaryAlgorithmInputFactorReport table schema
simulation_evolutionary_algorithm_input_factor_report = Table(
    table_name="SimulationEvolutionaryAlgorithmInputFactorReport",
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="SimEvoAlgorithmInputFactorRpt",
    basic_mode_throg=True,
    basic_mode_dendro=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The GA-generated scenario name that represents the grouping of genes that make up this scenario.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["Scenarios.ScenarioName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="InputFactorName",
            data_type=DataType.STRING,
            pk=True,
            explanation="The name of the Input Factor that is being modified in the GA-Scenario.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="InputFactorValue",
            data_type=DataType.STRING,
            explanation="The value that the Input Factor is using for the listed GA Scenario.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
