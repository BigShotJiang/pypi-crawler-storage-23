"""OptimizationGreenfieldNetworkSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# OptimizationGreenfieldNetworkSummary table schema
optimization_greenfield_network_summary = Table(
    table_name="OptimizationGreenfieldNetworkSummary",
    triad=TechnologySupport.FULLY_SUPPORTED,
    dart=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OptGreenfieldNetworkSmry",
    basic_mode_triad=True,
    basic_mode_dart=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["TRIAD", "DART"],
            master_column=["Scenarios.ScenarioName"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TRIADVersion",
            data_type=DataType.STRING,
            explanation="The version of the TRIAD solver that was used for the scenario.",
            precision_category=["NaN"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RunStartTime",
            data_type=DataType.DATETIME,
            explanation="The Date/Time when the scenario was run. Times are reported in UTC / Coordinated Universal Time.",
            precision_category=["NaN"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalRunTime",
            data_type=DataType.DOUBLE,
            explanation="The total time taken for the scenario run to complete.",
            precision_category=["Time"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ResourceSize",
            data_type=DataType.STRING,
            explanation="The size of the solver resource that was selected to run the greenfield engine.",
            precision_category=["NaN"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConsumedMemory",
            data_type=DataType.DOUBLE,
            explanation="The amount of memory (GB) that was consumed during the greenfield run.",
            precision_category=["Quantity"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SuggestedResourceSize",
            data_type=DataType.STRING,
            explanation="The smallest resource size required to successfully solve the model. Recommended based on the consumed memory.",
            precision_category=["NaN"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="NumberOfGreenfieldFacilities",
            data_type=DataType.INTEGER,
            explanation="The number of Greenfield Facilities that were used for the run.",
            precision_category=["Integer"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="NumberOfExistingFacilities",
            data_type=DataType.INTEGER,
            explanation="The number of Existing Facilities that were used for the run. Existing Facilities are Facilities with a Facility Status of Open.",
            precision_category=["Integer"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="NumberOfCandidateFacilities",
            data_type=DataType.INTEGER,
            explanation="The number of Candidate Facilities that were used for the run. Candidate Facilities are Facilities with a Facility Status of Consider",
            precision_category=["Integer"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost of the greenfield run. This will include Facility Fixed Costs, Supplier to Facility flow costs, and Facility to Customer flow costs.",
            precision_category=["Cost"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalFacilityFixedCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost of Facility fixed costs across the run.",
            precision_category=["Cost"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalFlowCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost of all flows.",
            precision_category=["Cost"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalDemandServed",
            data_type=DataType.DOUBLE,
            explanation="The total quantity of served demand at Customers.",
            precision_category=["Quantity"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AverageFacilityDistance",
            data_type=DataType.DOUBLE,
            explanation="The average distance of Supplier to Facility flows across the run.",
            precision_category=["Distance"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AverageCustomerDistance",
            data_type=DataType.DOUBLE,
            explanation="The average distance of Facility to Customer flows across the run.",
            precision_category=["Distance"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DistanceUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that distance is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["TRIAD"],
            master_column=["UnitsOfMeasure.Symbol"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PrimaryRiskRating",
            data_type=DataType.STRING,
            explanation="The Primary Risk Rating that is specified in the Model Settings. Details on all Risk Ratings can be found in the Greenfield Risk Metrics Summary table.",
            precision_category=["NaN"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RiskScore",
            data_type=DataType.DOUBLE,
            explanation="The risk score associated with this scenario. The Risk Score is the weighted sum of Customer, Facility, Supplier, and Network Risk, and is populated for the Primary Risk Rating that is specified in the Model Settings.",
            precision_category=["Risk"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
