"""OptimizationWorkCenterSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, InitialState, TechnologySupport

# OptimizationWorkCenterSummary table schema
optimization_work_center_summary = Table(
    table_name="OptimizationWorkCenterSummary",
    neo=TechnologySupport.FULLY_SUPPORTED,
    dart=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OptWorkCenterSmry",
    basic_mode_neo=True,
    basic_mode_dart=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["NEO", "DART"],
            master_column=["Scenarios.ScenarioName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Periods"],
            explanation="The time period that the results are reported for.",
            precision_category=["NaN"],
            basic_mode=["NEO", "DART"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WorkCenterName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["WorkCenters"],
            explanation="The name of the WorkCenter.",
            precision_category=["NaN"],
            basic_mode=["NEO", "DART"],
            master_column=["WorkCenters.WorkCenterName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities"],
            explanation="The name of the Facility.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Facilities.FacilityName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="InitialState",
            data_type=DataType.STRING,
            explanation="The initial state of the Work Center. This is specified in the Initial State field of the Work Centers table and will be one of Existing or Potential",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="InitialStatus",
            data_type=DataType.STRING,
            explanation="The Initial Status of the Work Center. This is specified in the Work Center Status field of the Work Centers table and will be one of Open, Closed or Consider.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OptimizedStatus",
            data_type=DataType.STRING,
            explanation="The status of the Work Center based on the optimization's results. This will be one of Open, Closed or Consider.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalWorkCenterCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost associated with the Work Center. This will be reported as the sum of the Fixed Operating Cost, Fixed Startup Cost, Fixed Closing Cost and any associated Process Costs.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OperatingCost",
            data_type=DataType.DOUBLE,
            explanation="The fixed operating cost of the Work Center. This is specified in the Fixed Operating Cost field of the Work Centers table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StartupCost",
            data_type=DataType.DOUBLE,
            explanation="The startup cost of the Work Center. If a Work Center opens in a period then the fixed startup cost will be applied. This is specified in the Fixed Startup Cost field of the Work Centers table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ClosingCost",
            data_type=DataType.DOUBLE,
            explanation="The closing cost of the Work Center. If a Work Center closes in a period then the fixed closing cost will be applied. This is specified in the Fixed Closing Cost field of the Work Centers table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalProcessCost",
            data_type=DataType.DOUBLE,
            explanation="The cost of any Processes that were run using this Work Center. This will be the sum of Unit Cost and Fixed Cost specified in the Processes table for any processes that were used at this Work Center. More detailed Process costs can be found in the Optimization Process Summary table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ThroughputQuantity",
            data_type=DataType.DOUBLE,
            explanation="The total throughput quantity that the Work Center handled in the Period.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ThroughputQuantityUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that quantity is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ThroughputVolume",
            data_type=DataType.DOUBLE,
            explanation="The total throughput volume that the Work Center handled in the Period.",
            precision_category=["Volume"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ThroughputVolumeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that volume is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ThroughputWeight",
            data_type=DataType.DOUBLE,
            explanation="The total throughput weight that the Work Center handled in the period.",
            precision_category=["Weight"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ThroughputWeightUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that weight is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ThroughputTime",
            data_type=DataType.DOUBLE,
            explanation="The total throughput time that the Work Center handled in the Period.",
            precision_category=["Time"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ThroughputTimeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that time is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ThroughputCapacity",
            data_type=DataType.DOUBLE,
            explanation="The throughput capacity for the Work Center. This is specified in the Throughput Capacity field of the Work Centers table.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ThroughputCapacityUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that time is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ThroughputUtilization",
            data_type=DataType.DOUBLE,
            explanation="The utilization of the Work Center for this period. Utilization is calculated as the Throughput divided by the Throughput Capacity.",
            precision_category=["Percentage"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UtilizationRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with how close the Work Center was to its specified capacity.",
            precision_category=["Risk"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalCO2Emissions",
            data_type=DataType.DOUBLE,
            explanation="The total CO2 emissions at this Work Center.",
            precision_category=["Quantity"],
            in_database=True
        ),
        Column(
            column_name="TotalCO2Cost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to CO2 Emissions at this Work Center.",
            precision_category=["Cost"],
            in_database=True
        ),
        Column(
            column_name="FixedCO2Emissions",
            data_type=DataType.DOUBLE,
            explanation="The fixed CO2 emissions at this Work Center. This is specified in the Fixed CO2 Emissions column of the Work Center table.",
            precision_category=["Quantity"],
            in_database=True
        ),
        Column(
            column_name="FixedCO2Cost",
            data_type=DataType.DOUBLE,
            explanation="The cost attributed to Fixed CO2 Emissions at this Work Center.",
            precision_category=["Cost"],
            in_database=True
        ),
        Column(
            column_name="TotalProductionCO2Emissions",
            data_type=DataType.DOUBLE,
            explanation="The total CO2 emissions attributed to production at this Work Center.",
            precision_category=["Quantity"],
            in_database=True
        ),
        Column(
            column_name="TotalProductionCO2Cost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to CO2 emissions of production at this Work Center.",
            precision_category=["Cost"],
            in_database=True
        ),
        Column(
            column_name="Latitude",
            data_type=DataType.DOUBLE,
            explanation="The latitude of the Facility.",
            precision_category=["GeoCoordinate"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Longitude",
            data_type=DataType.DOUBLE,
            explanation="The longitude of the Facility.",
            precision_category=["GeoCoordinate"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
