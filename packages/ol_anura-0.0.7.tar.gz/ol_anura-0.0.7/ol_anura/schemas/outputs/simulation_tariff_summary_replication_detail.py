"""SimulationTariffSummaryReplicationDetail table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, PathDestinationProperty, PathOriginProperty, TechnologySupport

# SimulationTariffSummaryReplicationDetail table schema
simulation_tariff_summary_replication_detail = Table(
    table_name="SimulationTariffSummaryReplicationDetail",
    throg=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="SimTariffSmryRD",
    basic_mode_throg=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["Scenarios.ScenarioName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReplicationNumber",
            data_type=DataType.INTEGER,
            pk=True,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathOriginProperty",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The property of the path origin.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathOriginValue",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The name of the path origin.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathDestinationProperty",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The property of the path destination.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathDestinationValue",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The name of the path destination.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Products"],
            explanation="The name of the product.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["Products.ProductName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TariffCost",
            data_type=DataType.DOUBLE,
            explanation="The cost attributed to the Tariff/Duty Rate in Tariffs Table",
            precision_category=["Cost"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VariableCost",
            data_type=DataType.DOUBLE,
            explanation="The cost attributed to the Unit Cost in Tariffs Table",
            precision_category=["Cost"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FlowQuantity",
            data_type=DataType.DOUBLE,
            explanation="The amount flow being shipped from the path origin to the path destination.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
