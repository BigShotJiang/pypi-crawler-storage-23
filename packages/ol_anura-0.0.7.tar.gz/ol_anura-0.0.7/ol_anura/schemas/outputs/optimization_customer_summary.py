"""OptimizationCustomerSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# OptimizationCustomerSummary table schema
optimization_customer_summary = Table(
    table_name="OptimizationCustomerSummary",
    neo=TechnologySupport.FULLY_SUPPORTED,
    dart=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OptCustomerSmry",
    basic_mode_neo=True,
    basic_mode_dart=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["NEO", "DART"],
            master_column=["Scenarios.ScenarioName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Periods"],
            explanation="The time period that the results are reported for.",
            precision_category=["NaN"],
            basic_mode=["NEO", "DART"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CustomerName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Customers"],
            explanation="The name of the Customer.",
            precision_category=["NaN"],
            basic_mode=["NEO", "DART"],
            master_column=["Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalOriginalDemandQuantity",
            data_type=DataType.DOUBLE,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The total of the input demand quantity for the Customer across all products. This is specified in the Customer Demand input table and will be the sum of all demand records that are included at the Customer.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalServedDemandQuantity",
            data_type=DataType.DOUBLE,
            explanation="The total of the served demand quantity for the Customer across all products. This is calculated based on the sum of all served demand quantity for the Customer reported in the Optimization Demand Summary table.",
            precision_category=["Quantity"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalUnservedDemandQuantity",
            data_type=DataType.DOUBLE,
            explanation="The total of the unserved demand quantity for the Customer across all products. This is calculated based on the sum of all unserved demand quantity for the Customer reported in the Optimization Demand Summary table.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReturnQuantity",
            data_type=DataType.DOUBLE,
            explanation="The total of the return quantity for the Customer across all products. This is calculated based on the sum of all returned quantity for the Customer reported in the Optimization Demand Summary table.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DemandQuantityUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that quantity is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalOriginalDemandVolume",
            data_type=DataType.DOUBLE,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The total of the input demand volume for the Customer across all products. This is specified in the Customer Demand input table and will be the sum of all demand records that are included at the Customer.",
            precision_category=["Volume"],
            basic_mode=["NEO"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalServedDemandVolume",
            data_type=DataType.DOUBLE,
            explanation="The total of the served demand volume for the Customer across all products. This is calculated based on the sum of all served demand volume for the Customer reported in the Optimization Demand Summary table.",
            precision_category=["Volume"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalUnservedDemandVolume",
            data_type=DataType.DOUBLE,
            explanation="The total of the unserved demand volume for the Customer across all products. This is calculated based on the sum of all unserved demand volume for the Customer reported in the Optimization Demand Summary table.",
            precision_category=["Volume"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReturnVolume",
            data_type=DataType.DOUBLE,
            explanation="The total of the return volume for the Customer across all products. This is calculated based on the sum of all returned volume for the Customer reported in the Optimization Demand Summary table.",
            precision_category=["Volume"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DemandVolumeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that volume is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalOriginalDemandWeight",
            data_type=DataType.DOUBLE,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The total of the input demand weight for the Customer across all products. This is specified in the Customer Demand input table and will be the sum of all demand records that are included at the Customer.",
            precision_category=["Weight"],
            basic_mode=["NEO"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalServedDemandWeight",
            data_type=DataType.DOUBLE,
            explanation="The total of the served demand weight for the Customer across all products. This is calculated based on the sum of all served demand weight for the Customer reported in the Optimization Demand Summary table.",
            precision_category=["Weight"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalUnservedDemandWeight",
            data_type=DataType.DOUBLE,
            explanation="The total of the unserved demand weight for the Customer across all products. This is calculated based on the sum of all unserved demand weight for the Customer reported in the Optimization Demand Summary table.",
            precision_category=["Weight"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReturnWeight",
            data_type=DataType.DOUBLE,
            explanation="The total of the return weight for the Customer across all products. This is calculated based on the sum of all returned weight for the Customer reported in the Optimization Demand Summary table.",
            precision_category=["eight"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DemandWeightUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that weight is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalRevenue",
            data_type=DataType.DOUBLE,
            explanation="The total revenue associated with this Customer. This is calculated based on the sum of all reported revenue for the Customer in the Optimization Demand Summary table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalUnservedDemandPenaltyCost",
            data_type=DataType.DOUBLE,
            explanation="The total penalty cost associated with unserved demand records at this Customer.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CustomerRiskScore",
            data_type=DataType.DOUBLE,
            explanation="The risk score associated with this Customer / Period. This is based on a weighted average of the Concentration Risk, Source Count Risk, Geographic Risk and User Defined Risk of the Customer.",
            precision_category=["Risk"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConcentrationRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated the with the demand concentration at the Customer location. This is reported as a weighted average based off of the Concentration Risk over all Products in the Optimization Demand Summary table.",
            precision_category=["Risk"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SourceCountRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with the number of sources that the Customer uses across all products. This is reported as a weighted average based off of the Source Count Risk over all Products in the Optimization Demand Summary table.",
            precision_category=["Risk"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="GeographicRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with the geographic location of the Customer. This is a weighted average of several geographic components that are reported in greater detail in the Optimization Geographic Risk Metrics table.",
            precision_category=["Risk"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UserDefinedRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with the User Defined Risk value entered in the Customers table.",
            precision_category=["Risk"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Latitude",
            data_type=DataType.DOUBLE,
            explanation="The latitude of the Customer.",
            precision_category=["GeoCoordinate"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Longitude",
            data_type=DataType.DOUBLE,
            explanation="The longitude of the Customer.",
            precision_category=["GeoCoordinate"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
