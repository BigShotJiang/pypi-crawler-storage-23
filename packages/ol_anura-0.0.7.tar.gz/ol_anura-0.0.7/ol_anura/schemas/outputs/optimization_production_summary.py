"""OptimizationProductionSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# OptimizationProductionSummary table schema
optimization_production_summary = Table(
    table_name="OptimizationProductionSummary",
    neo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OptProductionSmry",
    basic_mode_neo=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Scenarios.ScenarioName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StartingPeriodName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Periods"],
            explanation="The Period in which production begins. For any Facility, Product combinations where production time is less than the period length, Starting and Completion Periods will be the same.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CompletionPeriodName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Periods"],
            explanation="The Period in which production completes. For any Facility, Product combinations where production time is less than the period length, Starting and Completion Periods will be the same.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities"],
            explanation="The name of the Facility.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Facilities.FacilityName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Products"],
            explanation="The name of the Product.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Products.ProductName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BOMName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["BillsOfMaterials"],
            explanation="The name of the Bill of Material that was used to make the listed Product. If no BOM was specified, this will be left blank.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["BillsOfMaterials.BOMName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProcessName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Processes"],
            explanation="The name of the Process that was used to make the listed product. If no Process was specified, this will be blank.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Processes.ProcessName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductionQuantity",
            data_type=DataType.DOUBLE,
            explanation="The quantity of the listed Product produced at the specified Facility.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductionQuantityUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the quantity is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductionVolume",
            data_type=DataType.DOUBLE,
            explanation="The volume of the listed Product produced at the specified Facility.",
            precision_category=["Volume"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductionVolumeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the volume is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductionWeight",
            data_type=DataType.DOUBLE,
            explanation="The weight of the listed Product produced at the specified Facility.",
            precision_category=["Weight"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductionWeightUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the weight is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductionCost",
            data_type=DataType.DOUBLE,
            explanation="The policy cost associated with the production activity for this Facility Product combination. This is specified in the Production Policies table as Unit Cost.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProcessCost",
            data_type=DataType.DOUBLE,
            explanation="The cost associated with the production process used for this Facility Product combination. This is specified in the Unit Cost of the Processes table for the Process Name that was referenced in the Production Policies table for the listed Facility Product combination.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductionTime",
            data_type=DataType.DOUBLE,
            explanation="The time taken for the production of this Facility Product combination. This is taken from the Production Rate from the Production Policies table, unless a process is assigned to the Production Policy record, then the Processing Rate from the Process table is used.",
            precision_category=["Time"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductionTimeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the time is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductionEstimatedInventoryQuantity",
            data_type=DataType.DOUBLE,
            explanation="The quantity of estimated inventory attributed to productions for the listed Facility / Product / Period combination. This is calculated from the Time Between Productions column in the Production Policies table",
            precision_category=["Quantity"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="ProductionEstimatedInventoryVolume",
            data_type=DataType.DOUBLE,
            explanation="The volume of estimated inventory attributed to productions for the listed Facility / Product / Period combination. This is calculated from the Time Between Productions column in the Production Policies table",
            precision_category=["Volume"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="ProductionEstimatedInventoryWeight",
            data_type=DataType.DOUBLE,
            explanation="The weight of estimated inventory attributed to productions for the listed Facility / Product / Period combination. This is calculated from the Time Between Productions column in the Production Policies table",
            precision_category=["Weight"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="ProductionEstimatedInventoryHoldingCost",
            data_type=DataType.DOUBLE,
            explanation="The holding cost associated with the production estimated inventory",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="CO2Emissions",
            data_type=DataType.DOUBLE,
            explanation="The CO2 emissions from this production activity.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CO2Cost",
            data_type=DataType.DOUBLE,
            explanation="The cost attributed to CO2 Emissions for this production activity.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UserDefinedCost",
            data_type=DataType.DOUBLE,
            explanation="The proportion of user defined cost attributed to this production record.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="Latitude",
            data_type=DataType.DOUBLE,
            explanation="The latitude of the Facility.",
            precision_category=["GeoCoordinate"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Longitude",
            data_type=DataType.DOUBLE,
            explanation="The longitude of the Facility.",
            precision_category=["GeoCoordinate"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
