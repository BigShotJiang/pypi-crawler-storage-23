"""OptimizationGreenfieldSupplierSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# OptimizationGreenfieldSupplierSummary table schema
optimization_greenfield_supplier_summary = Table(
    table_name="OptimizationGreenfieldSupplierSummary",
    triad=TechnologySupport.FULLY_SUPPORTED,
    dart=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OptGreenfieldSupplierSmry",
    basic_mode_triad=True,
    basic_mode_dart=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["TRIAD", "DART"],
            master_column=["Scenarios.ScenarioName"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SupplierName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Suppliers"],
            explanation="The name of the Supplier.",
            precision_category=["NaN"],
            basic_mode=["TRIAD", "DART"],
            master_column=["Suppliers.SupplierName"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalOutboundFlowCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost of outbound flows from this Supplier to Facilities.",
            precision_category=["Cost"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SuppliedQuantity",
            data_type=DataType.DOUBLE,
            explanation="The quantity that was supplied by the Supplier to the Facilities.",
            precision_category=["Quantity"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SupplierCapacity",
            data_type=DataType.DOUBLE,
            explanation="The capacity of the Supplier.",
            precision_category=["Quantity"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SupplierUtilization",
            data_type=DataType.DOUBLE,
            explanation="The utilization of the listed Supplier expressed as the Supplied Quantity / Supplier Capacity.",
            precision_category=["Percentage"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilitiesServed",
            data_type=DataType.INTEGER,
            explanation="The number of Facilities that were serviced by this Supplier.",
            precision_category=["Integer"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AverageFacilityDistance",
            data_type=DataType.DOUBLE,
            explanation="The average service distance for Facilities from this Supplier.",
            precision_category=["Distance"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FurthestFacilityDistance",
            data_type=DataType.DOUBLE,
            explanation="The largest service distance for a Facility that was serviced by this Supplier.",
            precision_category=["Distance"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DistanceUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that distance is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["TRIAD"],
            master_column=["UnitsOfMeasure.Symbol"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="City",
            data_type=DataType.STRING,
            explanation="This will be specified in the City field of the Suppliers table. For Suppliers that have no geodata information entered in the Suppliers table, reverse-geocoding will be utilized to determine the city.",
            precision_category=["NaN"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PostalCode",
            data_type=DataType.STRING,
            explanation="This will be specified in the Postal Code field of the Suppliers table.",
            precision_category=["NaN"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Region",
            data_type=DataType.STRING,
            explanation="This will be specified in the Region field of the Suppliers table. For Suppliers that have no geodata information entered in the Suppliers table, reverse-geocoding will be utilized to determine the region.",
            precision_category=["NaN"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Country",
            data_type=DataType.STRING,
            explanation="This will be specified in the Country field of the Suppliers table. For Suppliers that have no geodata information entered in the Suppliers table, reverse-geocoding will be utilized to determine the country.",
            precision_category=["NaN"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SupplierRiskScore",
            data_type=DataType.DOUBLE,
            explanation="The risk score associated with this Supplier. This is based on a weighted average of the Supplier's Concentration Risk, Utilization Risk, Geographic Risk and User Defined Risk of the Supplier.",
            precision_category=["Risk"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConcentrationRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated the with the throughput concentration of the Supplier location. This is calculated based on the throughput quantity of the facility relative to the total demanded quantity.",
            precision_category=["Risk"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UtilizationRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with how close to capacity the Supplier is during the model solve.",
            precision_category=["Risk"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="GeographicRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with the geographic location of the Facility. This is a weighted average of several geographic components that are reported in greater detail in the Optimization Facility Risk Metrics table.",
            precision_category=["Risk"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UserDefinedRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with the User Defined Risk value entered in the Suppliers table.",
            precision_category=["Risk"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Latitude",
            data_type=DataType.DOUBLE,
            explanation="The latitude of the Supplier.",
            precision_category=["GeoCoordinate"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Longitude",
            data_type=DataType.DOUBLE,
            explanation="The longitude of the Supplier.",
            precision_category=["GeoCoordinate"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
