"""OptimizationNetworkSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# OptimizationNetworkSummary table schema
optimization_network_summary = Table(
    table_name="OptimizationNetworkSummary",
    neo=TechnologySupport.FULLY_SUPPORTED,
    dart=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OptNetworkSmry",
    basic_mode_neo=True,
    basic_mode_dart=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["NEO", "DART"],
            master_column=["Scenarios.ScenarioName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="NEOVersion",
            data_type=DataType.STRING,
            explanation="The version of the NEO solver that was used for the scenario run.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DARTVersion",
            data_type=DataType.STRING,
            explanation="The version of the DART solver that was used for the scenario run.",
            precision_category=["NaN"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RunStartTime",
            data_type=DataType.DATETIME,
            explanation="The Date/Time when the scenario was run. Times are reported in UTC / Coordinated Universal Time.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalRunTime",
            data_type=DataType.DOUBLE,
            explanation="The total time taken for the scenario run to complete. Total Run Time will be expressed in minutes.",
            precision_category=["Time"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SolveTime",
            data_type=DataType.DOUBLE,
            explanation="The solve time taken during the scenario run. Solve Time will be expressed in minutes.",
            precision_category=["Time"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OptimizationGapPercentage",
            data_type=DataType.DOUBLE,
            explanation="The gap percentage of the solution that was returned for the scenario.",
            precision_category=["Percentage"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ResourceSize",
            data_type=DataType.STRING,
            explanation="The size of the solver resource that was selected to run the optimization.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConsumedMemory",
            data_type=DataType.DOUBLE,
            explanation="The amount of memory (GB) that was consumed during the optimization run.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SuggestedResourceSize",
            data_type=DataType.STRING,
            explanation="The smallest resource size required to successfully solve the model. Recommended based on the consumed memory.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SolveType",
            data_type=DataType.STRING,
            explanation="The type of solve that was run. This will be one of Single Objective, Sequential Solve, or Infeasibility Diagnosis.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SolveStatus",
            data_type=DataType.STRING,
            explanation="The status of the optimization run. This will be one of Optimal, Infeasible, or Unbounded.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalSupplyChainCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost of the scenario.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalRevenue",
            data_type=DataType.DOUBLE,
            explanation="The total revenue generated from all of the satisfied demand records in the scenario.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalProfit",
            data_type=DataType.DOUBLE,
            explanation="The total profit of the scenario, calculated as Total Revenue - Total Supply Chain Cost.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalServedDemandQuantity",
            data_type=DataType.DOUBLE,
            explanation="The total quantity of demand that was served in the scenario run.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalUnservedDemandQuantity",
            data_type=DataType.DOUBLE,
            explanation="The total quantity of demand that went unserved in this scenario run.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReturnQuantity",
            data_type=DataType.DOUBLE,
            explanation="The total quantity of returned product in the scenario run.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="QuantityUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the quantities are expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalServedDemandVolume",
            data_type=DataType.DOUBLE,
            explanation="The total volume of demand that was served in the scenario run.",
            precision_category=["Volume"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalUnservedDemandVolume",
            data_type=DataType.DOUBLE,
            explanation="The total volume of demand that went unserved in this scenario run.",
            precision_category=["Volume"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReturnVolume",
            data_type=DataType.DOUBLE,
            explanation="The total volume of returned product in the scenario run.",
            precision_category=["Volume"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VolumeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the volumes are expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalServedDemandWeight",
            data_type=DataType.DOUBLE,
            explanation="The total weight of demand that was served in the scenario run.",
            precision_category=["Weight"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalUnservedDemandWeight",
            data_type=DataType.DOUBLE,
            explanation="The total weight of demand that went unserved in this scenario run.",
            precision_category=["Weight"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReturnWeight",
            data_type=DataType.DOUBLE,
            explanation="The total weight of returned product in the scenario run.",
            precision_category=["Weight"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WeightUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the weights are expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalTransportationCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to the Unit Costs of the Transportation Policies. This is taken as the total Transportation Cost from the Optimization Flow Summary.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalFuelSurchargeCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to the Fuel Surcharge of the Transportation Policies. This is taken as the total Fuel Surcharge Cost from the Optimization Flow Summary.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalShipmentCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to the Fixed Shipment Costs of the Transportation Policies. This is taken as the total Shipment Cost in the Optimization Flow Summary. It can also be found in the Optimization Shipment Summary table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalMultiStopRouteCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to the Multi Stop Route Costs of the flows in this scenario.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalInTransitHoldingCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to In Transit Holding Costs. This is taken as the total In Transit Holding Cost from the Optimization Flow Summary table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalDutyCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to the Duty Rate in the Transportation Policies. This is taken as the total Duty Cost from the Optimization Flow Summary table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalTariffCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to the Tariffs.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalDisposalCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to the Disposals. This is taken as the total Disposal Cost from the Optimization Inventory Age Summary table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalUnservedDemandPenaltyCost",
            data_type=DataType.DOUBLE,
            explanation="The total Penalty Cost resulted from not serving a customer demand at full quantity..",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalProductionCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to the Unit Costs of the Production Policies. This is taken as the total Production Cost from the Optimization Production Summary table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPrebuildHoldingCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to the holding cost of pre build inventory. This is taken as the total Prebuild Holding Cost from the Optimization Inventory Summary table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalTurnEstimatedHoldingCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to the holding cost of turn estimated inventory. This is taken as the total Turn Estimated Holding Cost from the Optimization Inventory Summary table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalTransportationEstimatedHoldingCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to the holding cost of transportation estimated inventory. This is taken as the total Transportation Estimated Holding Cost from the Optimization Inventory Summary table.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalProductionEstimatedHoldingCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to the holding cost of transportation estimated inventory. This is taken as the total Transportation Estimated Holding Cost from the Optimization Inventory Summary table.",
            precision_category=["Cost"],
            in_database=True
        ),
        Column(
            column_name="TotalStorageCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to the storage cost. This is taken as the total Storage Cost from the Optimization Inventory Summary table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalSourcingCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to sourcing from either Customer Fulfillment, Replenishment or Procurement Policy Unit Sourcing Cost. This is taken as the total Sourcing Cost from the Optimization Flow Summary table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReturnCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to returned product from Return Policy Unit Cost. This is taken as the total Return  Cost from the Optimization Flow Summary table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalFixedOperatingCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to fixed operating costs in the model. This is taken as the sum of Fixed Operating Cost from the Optimization Facility Summary and Optimization WorkCenter Summary tables.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalFixedStartupCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to fixed startup costs in the model. This is taken as the sum of Fixed Startup Cost from the Optimization Facility Summary and Optimization Work Center Summary tables.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalFixedClosingCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to fixed closing costs in the model. This is taken as the sum of Fixed Closing Cost from the Optimization Facility Summary and Optimization Work Center Summary tables.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalInboundHandlingCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to inbound handling cost. This is taken as the total Inbound Handling Cost from the Optimization Warehousing Summary table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalOutboundHandlingCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to outbound handling cost. This is taken as the total Outbound Handling Cost from the Optimization Warehousing Summary table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalStockingCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to stocking cost. This is taken as the total Stocking Cost from the Optimization Warehousing Summary table.",
            precision_category=["Cost"],
            in_database=True
        ),
        Column(
            column_name="TotalDestockingCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to destocking cost. This is taken as the total Destocking Cost from the Optimization Warehousing Summary table.",
            precision_category=["Cost"],
            in_database=True
        ),
        Column(
            column_name="TotalProcessCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to process unit costs. This is taken as the total Process Cost from the Optimization Process Summary table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalSupplyCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost of introducing products at the suppliers. This is taken as the total Supply Cost from the Optimization Supply Summary table.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalUserDefinedCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to user defined costs. This is taken as the total Cost from the Optimization User Defined Cost Summary table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalCO2Emissions",
            data_type=DataType.DOUBLE,
            explanation="The total CO2 emissions.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalCO2Cost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to CO2 Emissions.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PrimaryRiskRating",
            data_type=DataType.STRING,
            explanation="The Primary Risk Rating that is specified in the Model Settings. Details on all Risk Ratings can be found in the Risk Metrics Summary table.",
            precision_category=["NaN"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RiskScore",
            data_type=DataType.DOUBLE,
            explanation="The risk score associated with this scenario. Details on the risk score can be found in the Optimization Risk Metrics Summary table.  The Risk Score is the weighted sum of Customer, Facility, Supplier, and Network Risk, and is populated for the Primary Risk Rating that is specified in the Model Settings.",
            precision_category=["Risk"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
