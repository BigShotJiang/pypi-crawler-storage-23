"""OptimizationInventorySummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# OptimizationInventorySummary table schema
optimization_inventory_summary = Table(
    table_name="OptimizationInventorySummary",
    neo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OptInventorySmry",
    basic_mode_neo=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Scenarios.ScenarioName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Periods"],
            explanation="The time period that the results are reported for.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities"],
            explanation="The name of the Facility.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Facilities.FacilityName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Products"],
            explanation="The name of the Product.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Products.ProductName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AveragePrebuildInventoryQuantity",
            data_type=DataType.DOUBLE,
            explanation="The average amount of prebuild inventory for the listed Product at the Facility. This is calculated based on the average between Starting and Ending Prebuild Inventory Quantities.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StartingPrebuildInventoryQuantity",
            data_type=DataType.DOUBLE,
            explanation="The starting amount of prebuild inventory for the listed Product at the Facility.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="EndingPrebuildInventoryQuantity",
            data_type=DataType.DOUBLE,
            explanation="The ending amount of prebuild inventory for the listed Product at the Facility.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MaxTurnEstimatedInventoryQuantity",
            data_type=DataType.DOUBLE,
            explanation="The estimated amount of inventory located at the Facility that is attributed to Inventory Turns as specified in the Inventory Policies table.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TurnEstimatedInventoryQuantity",
            data_type=DataType.DOUBLE,
            explanation="The estimated quantity of inventory located at the Facility that is attributed to Inventory Turns as specified through the Time Between Turns column in the Inventory Policies table.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TransportationEstimatedInventoryQuantity",
            data_type=DataType.DOUBLE,
            explanation="The estimated quantity of inventory located at the Facility that is attributed to Transportation as specified through the Time Between Deliveries column in the Transportation Policies table.",
            precision_category=["Quantity"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductionEstimatedInventoryQuantity",
            data_type=DataType.DOUBLE,
            explanation="The estimated quantity of inventory located at the Facility that is attributed to Productions as specified through the Time Between Productions column in the Production Policies table.",
            precision_category=["Quantity"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="TotalCycleInventoryQuantity",
            data_type=DataType.DOUBLE,
            explanation="The total quantity of all estimated inventory for the Facility / Product / Period combination. This is taken as the total of Turn Estimated, Transportation Estimated  and Production Estimated Inventory.",
            precision_category=["Quantity"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="InventoryQuantityUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the quantity is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AveragePrebuildInventoryVolume",
            data_type=DataType.DOUBLE,
            explanation="The average amount of prebuild inventory for the listed Product at the Facility. This is calculated based on the average between Starting and Ending Prebuild Inventory Volumes.",
            precision_category=["Volume"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StartingPrebuildInventoryVolume",
            data_type=DataType.DOUBLE,
            explanation="The starting amount of prebuild inventory for the listed Product at the Facility.",
            precision_category=["Volume"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="EndingPrebuildInventoryVolume",
            data_type=DataType.DOUBLE,
            explanation="The ending amount of prebuild inventory for the listed Product at the Facility.",
            precision_category=["Volume"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MaxTurnEstimatedInventoryVolume",
            data_type=DataType.DOUBLE,
            explanation="The estimated amount of inventory located at the Facility that is attributed to Inventory Turns as specified in the Inventory Policies table.",
            precision_category=["Volume"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TurnEstimatedInventoryVolume",
            data_type=DataType.DOUBLE,
            explanation="The estimated volume of inventory located at the Facility that is attributed to Inventory Turns as specified through the Time Between Turns column in the Inventory Policies table.",
            precision_category=["Volume"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TransportationEstimatedInventoryVolume",
            data_type=DataType.DOUBLE,
            explanation="The estimated volume of inventory located at the Facility that is attributed to Transportation as specified through the Time Between Deliveries column in the Transportation Policies table.",
            precision_category=["Volume"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductionEstimatedInventoryVolume",
            data_type=DataType.DOUBLE,
            explanation="The estimated volume of inventory located at the Facility that is attributed to Productions as specified through the Time Between Productions column in the Production Policies table.",
            precision_category=["Volume"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="TotalCycleInventoryVolume",
            data_type=DataType.DOUBLE,
            explanation="The total volume of all estimated inventory for the Facility / Product / Period combination. This is taken as the total of Turn Estimated, Transportation Estimated  and Production Estimated Inventory.",
            precision_category=["Volume"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="InventoryVolumeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the volume is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AveragePrebuildInventoryWeight",
            data_type=DataType.DOUBLE,
            explanation="The average amount of prebuild inventory for the listed Product at the Facility. This is calculated based on the average between Starting and Ending Prebuild Inventory Weights.",
            precision_category=["Weight"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StartingPrebuildInventoryWeight",
            data_type=DataType.DOUBLE,
            explanation="The starting amount of prebuild inventory for the listed Product at the Facility.",
            precision_category=["Weight"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="EndingPrebuildInventoryWeight",
            data_type=DataType.DOUBLE,
            explanation="The ending amount of prebuild inventory for the listed Product at the Facility.",
            precision_category=["Weight"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MaxTurnEstimatedInventoryWeight",
            data_type=DataType.DOUBLE,
            explanation="The estimated amount of inventory located at the Facility that is attributed to Inventory Turns as specified in the Inventory Policies table.",
            precision_category=["Weight"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TurnEstimatedInventoryWeight",
            data_type=DataType.DOUBLE,
            explanation="The estimated weight of inventory located at the Facility that is attributed to Inventory Turns as specified through the Time Between Turns column in the Inventory Policies table.",
            precision_category=["Weight"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TransportationEstimatedInventoryWeight",
            data_type=DataType.DOUBLE,
            explanation="The estimated weight of inventory located at the Facility that is attributed to Transportation as specified through the Time Between Deliveries column in the Transportation Policies table.",
            precision_category=["Weight"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductionEstimatedInventoryWeight",
            data_type=DataType.DOUBLE,
            explanation="The estimated weight of inventory located at the Facility that is attributed to Productions as specified through the Time Between Productions column in the Production Policies table.",
            precision_category=["Weight"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="TotalCycleInventoryWeight",
            data_type=DataType.DOUBLE,
            explanation="The total weight of all estimated inventory for the Facility / Product / Period combination. This is taken as the total of Turn Estimated, Transportation Estimated  and Production Estimated Inventory.",
            precision_category=["Weight"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="InventoryWeightUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the weight is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalInventoryCost",
            data_type=DataType.DOUBLE,
            explanation="The Total Inventory Cost for the listed Product / Facility / Period combination. This is calculated as the sum of PreBuild Inventory Holding Cost, Turn Estimated Inventory Holding Cost and Inventory Storage Cost.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PrebuildHoldingCost",
            data_type=DataType.DOUBLE,
            explanation="The holding cost charged to the amount of average prebuild inventory. This is determined based on the holding cost percentage in the Inventory Policies table and the Product's value. This cost is calculated as Average Prebuild Inventory * Product Unit Value * Inventory Carrying Cost Percentage * (Period Length in Days / 365)",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TurnEstimatedHoldingCost",
            data_type=DataType.DOUBLE,
            explanation="The holding cost charged to the average amount of turn estimated inventory which is calculated as Max Turn Estimated Inventory / 2. The cost is determined based on the holding cost percentage in the Inventory Policies table and the Product's value. This cost is calculated as (Max Turn Estimated Inventory / 2) * Product Unit Value * Inventory Carrying Cost Percentage * (Period Length in Days / 365)",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TransportationEstimatedHoldingCost",
            data_type=DataType.DOUBLE,
            explanation="The holding cost charged to the average amount of transportation estimated inventory. The cost is determined based on the holding cost percentage in the Inventory Policies table and the Product's value. This cost is calculated as Transportation Estimated Inventory * Product Unit Value * Inventory Carrying Cost Percentage * (Period Length in Days / 365)",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductionEstimatedHoldingCost",
            data_type=DataType.DOUBLE,
            explanation="The holding cost charged to the average amount of production estimated inventory. The cost is determined based on the holding cost percentage in the Inventory Policies table and the Product's value. This cost is calculated as Production Estimated Inventory * Product Unit Value * Inventory Carrying Cost Percentage * (Period Length in Days / 365)",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="StorageCost",
            data_type=DataType.DOUBLE,
            explanation="The cost of storage for the Product at the Facility. This cost is separate from any holding costs and is described in the Unit Storage Cost field in the Inventory Policies table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UserDefinedCost",
            data_type=DataType.DOUBLE,
            explanation="The proportion of user defined cost attributed to this inventory record.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="Latitude",
            data_type=DataType.DOUBLE,
            explanation="The latitude of the Facility.",
            precision_category=["GeoCoordinate"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Longitude",
            data_type=DataType.DOUBLE,
            explanation="The longitude of the Facility.",
            precision_category=["GeoCoordinate"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
