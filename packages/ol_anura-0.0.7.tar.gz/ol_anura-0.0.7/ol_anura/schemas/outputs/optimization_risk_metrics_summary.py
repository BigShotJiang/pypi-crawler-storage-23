"""OptimizationRiskMetricsSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# OptimizationRiskMetricsSummary table schema
optimization_risk_metrics_summary = Table(
    table_name="OptimizationRiskMetricsSummary",
    neo=TechnologySupport.FULLY_SUPPORTED,
    dart=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OptRiskSmry",
    basic_mode_neo=True,
    basic_mode_dart=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["NEO", "DART"],
            master_column=["Scenarios.ScenarioName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RiskRatingName",
            data_type=DataType.STRING,
            pk=True,
            explanation="The Risk Rating that risk metrics are reported for.",
            precision_category=["NaN"],
            basic_mode=["DART"],
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RiskScore",
            data_type=DataType.DOUBLE,
            explanation="The risk score associated with this scenario. This is calculated as the weighted average of the Customer Risk, Facility Risk, Supplier Risk and Network Risk.",
            precision_category=["Risk"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CustomerRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with Customers in this scenario. More details on the Risk components can be found in the Optimization Customer Summary and Optimization Customer Risk Metrics tables.",
            precision_category=["Risk"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with Facilities in this scenario. More details on the Risk components can be found in the Optimization Facility Summary and Optimization Facility Risk Metrics tables.",
            precision_category=["Risk"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SupplierRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with Suppliers in this scenario. More details on the Risk components can be found in the Optimization Supplier Summary and Optimization Supplier Risk Metrics tables.",
            precision_category=["Risk"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="NetworkRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with Network activities in this scenario. More details on the Risk components can be found in the Optimization Network Risk Metrics and Optimization Product Risk Metrics tables.",
            precision_category=["Risk"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DARTVersion",
            data_type=DataType.STRING,
            explanation="The version of the DART solver that was used for the scenario run.",
            precision_category=["NaN"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
