"""SimulationFlowSummaryReplicationDetail table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# SimulationFlowSummaryReplicationDetail table schema
simulation_flow_summary_replication_detail = Table(
    table_name="SimulationFlowSummaryReplicationDetail",
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    dart=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="SimFlowSmryRD",
    basic_mode_throg=True,
    basic_mode_dendro=True,
    basic_mode_dart=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO", "DART"],
            master_column=["Scenarios.ScenarioName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReplicationNumber",
            data_type=DataType.INTEGER,
            pk=True,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO", "DART"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OriginName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities", "Suppliers", "Customers"],
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO", "DART"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DestinationName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities", "Suppliers", "Customers"],
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO", "DART"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ModeName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["TransportationModes"],
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO", "DART"],
            master_column=["TransportationModes.ModeName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Products"],
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO", "DART"],
            master_column=["Products.ProductName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalQuantityShipped",
            data_type=DataType.DOUBLE,
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO", "DART"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="QuantityShippedUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalVolumeShipped",
            data_type=DataType.DOUBLE,
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VolumeShippedUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalWeightShipped",
            data_type=DataType.DOUBLE,
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WeightShippedUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CostDimension",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalShipmentCost",
            data_type=DataType.DOUBLE,
            explanation="fixed cost plus unit cost. Divide back out based on the proportion of product based on UOM (cost dimension)",
            precision_category=["Cost"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalInTransitHoldingCost",
            data_type=DataType.DOUBLE,
            precision_category=["Cost"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalDutyCost",
            data_type=DataType.DOUBLE,
            precision_category=["Cost"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TransportDistance",
            data_type=DataType.DOUBLE,
            precision_category=["Distance"],
            basic_mode=["THROG", "DENDRO", "DART"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TransportTime",
            data_type=DataType.DOUBLE,
            precision_category=["Time"],
            basic_mode=["THROG", "DENDRO", "DART"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TransportTimeRisk",
            data_type=DataType.DOUBLE,
            precision_category=["Risk"],
            basic_mode=["THROG", "DENDRO", "DART"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TimeToImportRisk",
            data_type=DataType.DOUBLE,
            precision_category=["Risk"],
            basic_mode=["THROG", "DENDRO", "DART"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TimeToExportRisk",
            data_type=DataType.DOUBLE,
            precision_category=["Risk"],
            basic_mode=["THROG", "DENDRO", "DART"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OriginLatitude",
            data_type=DataType.DOUBLE,
            master_table=["Facilities", "Suppliers", "Customers"],
            precision_category=["GeoCoordinate"],
            basic_mode=["THROG", "DENDRO", "DART"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OriginLongitude",
            data_type=DataType.DOUBLE,
            master_table=["Facilities", "Suppliers", "Customers"],
            precision_category=["GeoCoordinate"],
            basic_mode=["THROG", "DENDRO", "DART"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DestinationLatitude",
            data_type=DataType.DOUBLE,
            master_table=["Facilities", "Suppliers", "Customers"],
            precision_category=["GeoCoordinate"],
            basic_mode=["THROG", "DENDRO", "DART"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DestinationLongitude",
            data_type=DataType.DOUBLE,
            master_table=["Facilities", "Suppliers", "Customers"],
            precision_category=["GeoCoordinate"],
            basic_mode=["THROG", "DENDRO", "DART"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
