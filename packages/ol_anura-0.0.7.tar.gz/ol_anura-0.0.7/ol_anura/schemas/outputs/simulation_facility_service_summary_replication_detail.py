"""SimulationFacilityServiceSummaryReplicationDetail table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# SimulationFacilityServiceSummaryReplicationDetail table schema
simulation_facility_service_summary_replication_detail = Table(
    table_name="SimulationFacilityServiceSummaryReplicationDetail",
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="SimFacilitySvcSmryRD",
    basic_mode_throg=True,
    basic_mode_dendro=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["Scenarios.ScenarioName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReplicationNumber",
            data_type=DataType.INTEGER,
            pk=True,
            explanation="The replication the results are saved for.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities"],
            explanation="The name of the Facility.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["Facilities.FacilityName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrders",
            data_type=DataType.INTEGER,
            explanation="The number of orders received by the listed Facility.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrdersPrimarySource",
            data_type=DataType.INTEGER,
            explanation="The number of orders received by the listed Facility where the Facility was listed as the primary source for the order as specified in either the Customer Fulfillment Policies or Replenishment Policies table.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrdersNonPrimarySource",
            data_type=DataType.INTEGER,
            explanation="The number of orders received by the listed Facility where the Facility was not listed as the primary source for the order as specified in either the Customer Fulfillment Policies or Replenishment Policies table.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrdersMultiSource",
            data_type=DataType.INTEGER,
            explanation="The number of orders received by the listed Facility where multiple Facilities were used to satisfy the order.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrdersMissedPrimarySource",
            data_type=DataType.INTEGER,
            explanation="The number of orders rejected by the listed Facility where the Facility was supposed to serve as the primary source as specified in either the Customer Fulfillment or Replenishment Policies table.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrdersUndelivered",
            data_type=DataType.INTEGER,
            explanation="The number of orders received by the listed Facility that were undelivered. This would include orders that were cancelled as well as orders that were in-transit at the time the simulation ended.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrdersBackordered",
            data_type=DataType.INTEGER,
            explanation="The number of orders received by the listed Facility that were placed into backorder.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrdersCancelled",
            data_type=DataType.INTEGER,
            explanation="The number of orders received by the listed Facility that were cancelled.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrdersFilledOnTime",
            data_type=DataType.INTEGER,
            explanation="The number of orders received by the listed Facility that were filled within the listed Quoted Time To Fill as specified in the Inventory Policies table.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrdersOnTimeFillRate",
            data_type=DataType.DOUBLE,
            explanation="The rate of orders fulfilled on time for the listed Facility. This is calculated as the Received Orders Filled On Time divided by Received Orders.",
            precision_category=["Percentage"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedLines",
            data_type=DataType.INTEGER,
            explanation="The number of lines received by the listed Facility.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedLinesPrimarySource",
            data_type=DataType.INTEGER,
            explanation="The number of lines received by the listed Facility where the Facility was listed as the primary source for the order as specified in either the Customer Fulfillment Policies or Replenishment Policies table.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedLinesNonPrimarySource",
            data_type=DataType.INTEGER,
            explanation="The number of lines received by the listed Facility where the Facility was not listed as the primary source for the order as specified in either the Customer Fulfillment Policies or Replenishment Policies table.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedLinesMultiSource",
            data_type=DataType.INTEGER,
            explanation="The number of lines received by the listed Facility where multiple Facilities were used to satisfy the order.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedLinesMissedPrimarySource",
            data_type=DataType.INTEGER,
            explanation="The number of lines rejected by the listed Facility where the Facility was supposed to serve as the primary source as specified in either the Customer Fulfillment or Replenishment Policies table.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedLinesUndelivered",
            data_type=DataType.INTEGER,
            explanation="The number of lines received by the listed Facility that were undelivered. This would include lines that were cancelled as well as lines that were in-transit at the time the simulation ended.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedLinesBackordered",
            data_type=DataType.INTEGER,
            explanation="The number of lines received by the listed Facility that were placed into backorder.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedLinesCancelled",
            data_type=DataType.INTEGER,
            explanation="The number of lines received by the listed Facility that were cancelled.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedLinesFilledOnTime",
            data_type=DataType.INTEGER,
            explanation="The number of lines received by the listed Facility that were filled within the listed Quoted Time To Fill as specified in the Inventory Policies table.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedLinesOnTimeFillRate",
            data_type=DataType.DOUBLE,
            explanation="The rate of lines fulfilled on time for the listed Facility. This is calculated as the Received Lines Filled On Time divided by Received Lines.",
            precision_category=["Percentage"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderQuantity",
            data_type=DataType.DOUBLE,
            explanation="The total quantity of received orders for the listed Facility.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderQuantityPrimarySource",
            data_type=DataType.DOUBLE,
            explanation="The total quantity of received orders for the listed Facility where the Facility was listed as the primary source in either the Customer Fulfillment or Replenishment Policies table.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderQuantityNonPrimarySource",
            data_type=DataType.DOUBLE,
            explanation="The total quantity of received orders for the listed Facility where the Facility was not listed as the primary source in either the Customer Fulfillment or Replenishment Policies table.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderQuantityMultiSource",
            data_type=DataType.DOUBLE,
            explanation="The total quantity of received orders for the listed Facility where multiple Facilities were used to satisfy the order.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderQuantityMissedPrimarySource",
            data_type=DataType.DOUBLE,
            explanation="The total quantity of received orders that was rejected for the listed Facility where the Facility was supposed to serve as the primary source as specified in either the Customer Fulfillment or Replenishment Policies table.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderQuantityUndelivered",
            data_type=DataType.DOUBLE,
            explanation="The total quantity of received orders for the listed Facility that was undelivered. This would include orders that were cancelled as well as orders that were in-transit at the time the simulation ended.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderQuantityBackordered",
            data_type=DataType.DOUBLE,
            explanation="The total quantity of received orders for the listed Facility that was placed into backorder.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderQuantityCancelled",
            data_type=DataType.DOUBLE,
            explanation="The total quantity of received orders for the listed Facility that was cancelled.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderQuantityFilledOnTime",
            data_type=DataType.DOUBLE,
            explanation="The total quantity of received orders for the listed Facility that was filled within the listed Quoted Time To Fill.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderQuantityOnTimeFillRate",
            data_type=DataType.DOUBLE,
            explanation="The rate of received order quantity fulfilled on time for the listed Facility. This is calculated as the Received Order Quantity Filled On Time divided by Received Order Quantity.",
            precision_category=["Percentage"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="QuantityUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that quantity outputs are expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderVolume",
            data_type=DataType.DOUBLE,
            explanation="The total volume of received orders for the listed Facility.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderVolumePrimarySource",
            data_type=DataType.DOUBLE,
            explanation="The total volume of received orders for the listed Facility where the Facility was listed as the primary source in either the Customer Fulfillment or Replenishment Policies table.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderVolumeNonPrimarySource",
            data_type=DataType.DOUBLE,
            explanation="The total volume of received orders for the listed Facility where the Facility was not listed as the primary source in either the Customer Fulfillment or Replenishment Policies table.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderVolumeMultiSource",
            data_type=DataType.DOUBLE,
            explanation="The total volume of received orders for the listed Facility where multiple Facilities were used to satisfy the order.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderVolumeMissedPrimarySource",
            data_type=DataType.DOUBLE,
            explanation="The total volume of received orders that was rejected for the listed Facility where the Facility was supposed to serve as the primary source as specified in either the Customer Fulfillment or Replenishment Policies table.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderVolumeUndelivered",
            data_type=DataType.DOUBLE,
            explanation="The total volume of received orders for the listed Facility that was undelivered. This would include orders that were cancelled as well as orders that were in-transit at the time the simulation ended.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderVolumeBackordered",
            data_type=DataType.DOUBLE,
            explanation="The total volume of received orders for the listed Facility that was placed into backorder.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderVolumeCancelled",
            data_type=DataType.DOUBLE,
            explanation="The total volume of received orders for the listed Facility that was cancelled.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderVolumeFilledOnTime",
            data_type=DataType.DOUBLE,
            explanation="The total volume of received orders for the listed Facility that was filled within the listed Quoted Time To Fill.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderVolumeOnTimeFillRate",
            data_type=DataType.DOUBLE,
            explanation="The rate of received order volume fulfilled on time for the listed Facility. This is calculated as the Received Order volume Filled On Time divided by Received Order volume.",
            precision_category=["Percentage"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VolumeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that volume outputs are expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderWeight",
            data_type=DataType.DOUBLE,
            explanation="The total weight of received orders for the listed Facility.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderWeightPrimarySource",
            data_type=DataType.DOUBLE,
            explanation="The total weight of received orders for the listed Facility where the Facility was listed as the primary source in either the Customer Fulfillment or Replenishment Policies table.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderWeightNonPrimarySource",
            data_type=DataType.DOUBLE,
            explanation="The total weight of received orders for the listed Facility where the Facility was not listed as the primary source in either the Customer Fulfillment or Replenishment Policies table.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderWeightMultiSource",
            data_type=DataType.DOUBLE,
            explanation="The total weight of received orders for the listed Facility where multiple Facilities were used to satisfy the order.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderWeightMissedPrimarySource",
            data_type=DataType.DOUBLE,
            explanation="The total weight of received orders that was rejected for the listed Facility where the Facility was supposed to serve as the primary source as specified in either the Customer Fulfillment or Replenishment Policies table.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderWeightUndelivered",
            data_type=DataType.DOUBLE,
            explanation="The total weight of received orders for the listed Facility that was undelivered. This would include orders that were cancelled as well as orders that were in-transit at the time the simulation ended.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderWeightBackordered",
            data_type=DataType.DOUBLE,
            explanation="The total weight of received orders for the listed Facility that was placed into backorder.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderWeightCancelled",
            data_type=DataType.DOUBLE,
            explanation="The total weight of received orders for the listed Facility that was cancelled.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderWeightFilledOnTime",
            data_type=DataType.DOUBLE,
            explanation="The total weight of received orders for the listed Facility that was filled within the listed Quoted Time To Fill.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderWeightOnTimeFillRate",
            data_type=DataType.DOUBLE,
            explanation="The rate of received order weight fulfilled on time for the listed Facility. This is calculated as the Received Order weight Filled On Time divided by Received Order weight.",
            precision_category=["Percentage"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WeightUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that weight outputs are expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrders",
            data_type=DataType.INTEGER,
            explanation="The number of orders placed by the listed Facility.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrdersPrimarySourced",
            data_type=DataType.INTEGER,
            explanation="The number of orders placed by the listed Facility that were sourced from the primary location as specified in the Replenishment or Procurement Policies table.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrdersNonPrimarySourced",
            data_type=DataType.INTEGER,
            explanation="The number of orders placed by listed Facility that were sourced from a non-primary location as specified in the Replenishment or Procurement Policies table.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrdersMultiSourced",
            data_type=DataType.INTEGER,
            explanation="The number of orders placed by the listed Facility that were sourced from multiple locations.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrdersUndelivered",
            data_type=DataType.INTEGER,
            explanation="The number of orders placed by the listed Facility that were undelivered. This would include orders that were cancelled as well as orders that were in-transit at the time the simulation ended.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrdersBackordered",
            data_type=DataType.INTEGER,
            explanation="The number of orders placed by the listed Facility that were backordered",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrdersCancelled",
            data_type=DataType.INTEGER,
            explanation="The number of orders placed by the listed Facility that were cancelled.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedLines",
            data_type=DataType.INTEGER,
            explanation="The number of lines that were placed by the listed Facility.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedLinesPrimarySourced",
            data_type=DataType.INTEGER,
            explanation="The number of lines placed by the listed Facility that were sourced from the primary location as specified in the Replenishment or Procurement Policies table.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedLinesNonPrimarySourced",
            data_type=DataType.INTEGER,
            explanation="The number of lines placed by the listed Facility that were sourced from a non-primary location as specified in the Replenishment or Procurement Policies table.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedLinesMultiSourced",
            data_type=DataType.INTEGER,
            explanation="The number of lines placed by the listed Facility that were sourced from multiple locations.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedLinesUndelivered",
            data_type=DataType.INTEGER,
            explanation="The number of lines placed by the listed Facility that were undelivered. This would include lines that were cancelled as well as lines that were in-transit at the time the simulation ended.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedLinesBackordered",
            data_type=DataType.INTEGER,
            explanation="The number of lines placed by the listed Facility that were backordered.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedLinesCancelled",
            data_type=DataType.INTEGER,
            explanation="The number of lines placed by the listed Facility that were cancelled.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderQuantity",
            data_type=DataType.DOUBLE,
            explanation="The total ordered quantity placed by the listed Facility.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderQuantityPrimarySourced",
            data_type=DataType.DOUBLE,
            explanation="The total ordered quantity placed by the listed Facility that was sourced from the primary location as specified in the Replenishment or Procurement Policies table.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderQuantityNonPrimarySourced",
            data_type=DataType.DOUBLE,
            explanation="The total ordered quantity placed by the listed Facility that was sourced from a non-primary location as specified in the Replenishment or Procurement Policies table.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderQuantityMultiSourced",
            data_type=DataType.DOUBLE,
            explanation="The total ordered quantity placed by the listed Facility that was sourced from multiple locations.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderQuantityUndelivered",
            data_type=DataType.DOUBLE,
            explanation="The total ordered quantity placed by the listed Facility that was undelivered . This would include quantity that was cancelled as well as quantity that was in-transit at the time the simulation ended.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderQuantityBackordered",
            data_type=DataType.DOUBLE,
            explanation="The total ordered quantity placed by the listed Facility that was backordered.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderQuantityCancelled",
            data_type=DataType.DOUBLE,
            explanation="The total ordered quantity placed by the listed Facility that was cancelled.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderVolume",
            data_type=DataType.DOUBLE,
            explanation="The total ordered volume placed by the listed Facility.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderVolumePrimarySourced",
            data_type=DataType.DOUBLE,
            explanation="The total ordered volume placed by the listed Facility that was sourced from the primary location as specified in the Replenishment or Procurement Policies table.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderVolumeNonPrimarySourced",
            data_type=DataType.DOUBLE,
            explanation="The total ordered volume placed by the listed Facility that was sourced from a non-primary location as specified in the Replenishment or Procurement Policies table.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderVolumeMultiSourced",
            data_type=DataType.DOUBLE,
            explanation="The total ordered volume placed by the listed Facility that was sourced from multiple locations.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderVolumeUndelivered",
            data_type=DataType.DOUBLE,
            explanation="The total ordered volume placed by the listed Facility that was undelivered . This would include volume that was cancelled as well as volume that was in-transit at the time the simulation ended.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderVolumeBackordered",
            data_type=DataType.DOUBLE,
            explanation="The total ordered volume placed by the listed Facility that was backordered.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderVolumeCancelled",
            data_type=DataType.DOUBLE,
            explanation="The total ordered volume placed by the listed Facility that was cancelled.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderWeight",
            data_type=DataType.DOUBLE,
            explanation="The total ordered weight placed by the listed Facility.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderWeightPrimarySourced",
            data_type=DataType.DOUBLE,
            explanation="The total ordered weight placed by the listed Facility that was sourced from the primary location as specified in the Replenishment or Procurement Policies table.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderWeightNonPrimarySourced",
            data_type=DataType.DOUBLE,
            explanation="The total ordered weight placed by the listed Facility that was sourced from a non-primary location as specified in the Replenishment or Procurement Policies table.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderWeightMultiSourced",
            data_type=DataType.DOUBLE,
            explanation="The total ordered weight placed by the listed Facility that was sourced from multiple locations.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderWeightUndelivered",
            data_type=DataType.DOUBLE,
            explanation="The total ordered weight placed by the listed Facility that was undelivered . This would include weight that was cancelled as well as weight that was in-transit at the time the simulation ended.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderWeightBackordered",
            data_type=DataType.DOUBLE,
            explanation="The total ordered weight placed by the listed Facility that was backordered.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderWeightCancelled",
            data_type=DataType.DOUBLE,
            explanation="The total ordered weight placed by the listed Facility that was cancelled.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
