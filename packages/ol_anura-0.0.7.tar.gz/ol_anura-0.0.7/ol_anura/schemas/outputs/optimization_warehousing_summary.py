"""OptimizationWarehousingSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# OptimizationWarehousingSummary table schema
optimization_warehousing_summary = Table(
    table_name="OptimizationWarehousingSummary",
    neo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OptWarehousingSmry",
    basic_mode_neo=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Scenarios.ScenarioName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Periods"],
            explanation="The time period that the results are reported for.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities"],
            explanation="The name of the Facility.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Facilities.FacilityName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Products"],
            explanation="The name of the Product.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Products.ProductName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="InboundHandlingCost",
            data_type=DataType.DOUBLE,
            explanation="The cost associated with inbound handling at the Facility for the listed Product. This is specified in the Inbound Handling Cost field of the Warehousing Policies table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StockingCost",
            data_type=DataType.DOUBLE,
            explanation="The cost associated with placing the listed Product into inventory at the Facility. This is specified in the Stocking Unit Cost field in the Warehousing Policies table.",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="DestockingCost",
            data_type=DataType.DOUBLE,
            explanation="The cost associated with picking the listed Product from inventory at the Facility. This is specified in the Destocking Unit Cost field in the Warehousing Policies table.",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="OutboundHandlingCost",
            data_type=DataType.DOUBLE,
            explanation="The cost associated with outbound handling for the listed Product as it leaves the Facility. This is specified in the Outbound Handling Cost field of the Warehousing Policies table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="InboundQuantity",
            data_type=DataType.DOUBLE,
            explanation="The quantity of inbound flow for the listed Product into the Facility.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StockedQuantity",
            data_type=DataType.DOUBLE,
            explanation="The quantity of the listed product that was placed into inventory at the Facility",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DestockedQuantity",
            data_type=DataType.DOUBLE,
            explanation="The quantity of the listed product that was taken out of inventory at the Facility",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OutboundQuantity",
            data_type=DataType.DOUBLE,
            explanation="The quantity of outbound flow for the listed Product out of the Facility.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="QuantityUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that quantity is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="InboundVolume",
            data_type=DataType.DOUBLE,
            explanation="The volume of inbound flow for the listed Product into the Facility.",
            precision_category=["Volume"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StockedVolume",
            data_type=DataType.DOUBLE,
            explanation="The volume of the listed product that was placed into inventory at the Facility",
            precision_category=["Volume"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DestockedVolume",
            data_type=DataType.DOUBLE,
            explanation="The volume of the listed product that was taken out of inventory at the Facility",
            precision_category=["Volume"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OutboundVolume",
            data_type=DataType.DOUBLE,
            explanation="The volume of outbound flow for the listed Product out of the Facility.",
            precision_category=["Volume"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VolumeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that volume is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="InboundWeight",
            data_type=DataType.DOUBLE,
            explanation="The weight of inbound flow for the listed Product into the Facility.",
            precision_category=["Weight"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StockedWeight",
            data_type=DataType.DOUBLE,
            explanation="The weight of the listed product that was placed into inventory at the Facility",
            precision_category=["Weight"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DestockedWeight",
            data_type=DataType.DOUBLE,
            explanation="The weight of the listed product that was taken out of inventory at the Facility",
            precision_category=["Weight"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OutboundWeight",
            data_type=DataType.DOUBLE,
            explanation="The weight of outbound flow for the listed Product out of the Facility.",
            precision_category=["Weight"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WeightUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that weight is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Latitude",
            data_type=DataType.DOUBLE,
            explanation="The latitude of the Facility.",
            precision_category=["GeoCoordinate"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Longitude",
            data_type=DataType.DOUBLE,
            explanation="The longitude of the Facility.",
            precision_category=["GeoCoordinate"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
