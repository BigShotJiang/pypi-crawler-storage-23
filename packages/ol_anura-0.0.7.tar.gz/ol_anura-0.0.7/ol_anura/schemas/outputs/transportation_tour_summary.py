"""TransportationTourSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# TransportationTourSummary table schema
transportation_tour_summary = Table(
    table_name="TransportationTourSummary",
    hopper=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="TransportationTourSmry",
    basic_mode_hopper=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            master_column=["Scenarios.ScenarioName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourID",
            data_type=DataType.STRING,
            pk=True,
            explanation="The ID for the Tour.",
            precision_category=["NaN"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost of the Tour.",
            precision_category=["Cost"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourRouteFixedCost",
            data_type=DataType.DOUBLE,
            explanation="The total route fixed costs.",
            precision_category=["Cost"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourAssetFixedCost",
            data_type=DataType.DOUBLE,
            explanation="The sum of the asset fixed cost of the routes on this Tour.",
            precision_category=["Cost"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourDistanceCost",
            data_type=DataType.DOUBLE,
            explanation="The total distance cost of the tour.",
            precision_category=["Cost"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourRepositionDistanceCost",
            data_type=DataType.DOUBLE,
            explanation="The total reposition distance cost of the tour.",
            precision_category=["Cost"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourOutOfRouteDistanceCost",
            data_type=DataType.DOUBLE,
            explanation="The total out of route distance cost of the tour.",
            precision_category=["Cost"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourTimeCost",
            data_type=DataType.DOUBLE,
            explanation="The time cost of the tour.",
            precision_category=["Cost"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourWaitTimeCost",
            data_type=DataType.DOUBLE,
            explanation="The wait time cost of the tour.",
            precision_category=["Cost"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourRestTimeCost",
            data_type=DataType.DOUBLE,
            explanation="The rest time cost for the tour.",
            precision_category=["Cost"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourBreakTimeCost",
            data_type=DataType.DOUBLE,
            explanation="The short break time cost for the tour.",
            precision_category=["Cost"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourDutyTimeCost",
            data_type=DataType.DOUBLE,
            explanation="The duty time cost for the tour. This is the additive cost for duty time specified in the Duty Time Cost field of the Transportation Rates table.",
            precision_category=["Cost"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourStopCost",
            data_type=DataType.DOUBLE,
            explanation="The cost attributed to the number of stops in the tour.",
            precision_category=["Cost"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourUnitCost",
            data_type=DataType.DOUBLE,
            explanation="The unit cost for the tour.",
            precision_category=["Cost"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourDistance",
            data_type=DataType.DOUBLE,
            explanation="The total Tour distance.",
            precision_category=["Distance"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourRepositionDistance",
            data_type=DataType.DOUBLE,
            explanation="The total reposition distance of the tour.",
            precision_category=["Cost"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourOutOfRouteDistance",
            data_type=DataType.DOUBLE,
            explanation="The total out of route distance of the tour.",
            precision_category=["Cost"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourDistanceUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure used for distance.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourTime",
            data_type=DataType.DOUBLE,
            explanation="The total duration of the Tour, calculated as the difference between TourEndDate and TourStartDate.",
            precision_category=["Time"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourRouteTime",
            data_type=DataType.DOUBLE,
            explanation="The total duration of all routes on this tour.",
            precision_category=["Time"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourTravelTime",
            data_type=DataType.DOUBLE,
            explanation="The total tour travel time.",
            precision_category=["Time"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourServiceTime",
            data_type=DataType.DOUBLE,
            explanation="The total tour service time.",
            precision_category=["Time"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourAdminTime",
            data_type=DataType.DOUBLE,
            explanation="The total admin time across all routes in the tour.",
            precision_category=["Time"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourWaitTime",
            data_type=DataType.DOUBLE,
            explanation="The total tour wait time.",
            precision_category=["Time"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourRestTime",
            data_type=DataType.DOUBLE,
            explanation="The total time spent in a rest during the tour.",
            precision_category=["Time"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourBreakTime",
            data_type=DataType.DOUBLE,
            explanation="The total time spent in a short break during the tour.",
            precision_category=["Time"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourTimeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure used for time.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AssetUtilization",
            data_type=DataType.DOUBLE,
            explanation="The proportion of the tour time spent on routes, calculated as TourRouteTime divided by TourTime.",
            precision_category=["NaN"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="NumberOfRoutes",
            data_type=DataType.INTEGER,
            explanation="The number of routes in the Tour",
            precision_category=["Quantity"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TransportationAssetName",
            data_type=DataType.STRING,
            master_table=["TransportationAssets"],
            explanation="The name of the Asset operating this Tour",
            precision_category=["Quantity"],
            master_column=["TransportationAssets.AssetName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OriginName",
            data_type=DataType.STRING,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The name of the pickup location for all routes in this Tour",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourStartDate",
            data_type=DataType.DATETIME,
            explanation="The date and time at which the first route in the Tour starts.",
            precision_category=["NaN"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourEndDate",
            data_type=DataType.DATETIME,
            explanation="The date and time at which the last route in the tour ends.",
            precision_category=["NaN"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourCO2Emissions",
            data_type=DataType.DOUBLE,
            explanation="The CO2 emissions for this tour.",
            precision_category=["Quantity"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourCO2Cost",
            data_type=DataType.DOUBLE,
            explanation="The cost attributed to CO2 Emissions for this tour.",
            precision_category=["Cost"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourFuelSurchargeCost",
            data_type=DataType.DOUBLE,
            explanation="The fuel surcharge cost for this tour.",
            precision_category=["Cost"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DecompositionName",
            data_type=DataType.STRING,
            explanation="Decomposition Name given to the shipments that make up the routes on this tour.",
            precision_category=["NaN"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
