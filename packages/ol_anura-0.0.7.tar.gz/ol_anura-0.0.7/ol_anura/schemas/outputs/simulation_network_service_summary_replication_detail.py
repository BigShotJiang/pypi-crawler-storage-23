"""SimulationNetworkServiceSummaryReplicationDetail table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# SimulationNetworkServiceSummaryReplicationDetail table schema
simulation_network_service_summary_replication_detail = Table(
    table_name="SimulationNetworkServiceSummaryReplicationDetail",
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="SimNetworkSvcSmryRD",
    basic_mode_throg=True,
    basic_mode_dendro=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["Scenarios.ScenarioName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReplicationNumber",
            data_type=DataType.INTEGER,
            pk=True,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrders",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrdersPrimarySourced",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrdersNonPrimarySourced",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrdersMultiSourced",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrdersUndelivered",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrdersOnTimeInFull",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrdersLateInFull",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrdersOnTimeInFullRate",
            data_type=DataType.DOUBLE,
            precision_category=["Percentage"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrdersBackordered",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrdersCancelled",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerLines",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerLinesPrimarySourced",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerLinesNonPrimarySourced",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerLinesMultiSourced",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerLinesUndelivered",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerLinesOnTimeInFull",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerLinesLateInFull",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerLinesOnTimeInFullRate",
            data_type=DataType.DOUBLE,
            precision_category=["Percentage"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerLinesBackordered",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerLinesCancelled",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrderQuantity",
            data_type=DataType.DOUBLE,
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrderQuantityPrimarySourced",
            data_type=DataType.DOUBLE,
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrderQuantityNonPrimarySourced",
            data_type=DataType.DOUBLE,
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrderQuantityMultiSourced",
            data_type=DataType.DOUBLE,
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrderQuantityUndelivered",
            data_type=DataType.DOUBLE,
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrderQuantityOnTimeInFull",
            data_type=DataType.DOUBLE,
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrderQuantityLateInFull",
            data_type=DataType.DOUBLE,
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrderQuantityOnTimeInFullRate",
            data_type=DataType.DOUBLE,
            precision_category=["Percentage"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrderQuantityBackordered",
            data_type=DataType.DOUBLE,
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrderQuantityCancelled",
            data_type=DataType.DOUBLE,
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="QuantityUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrderVolume",
            data_type=DataType.DOUBLE,
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrderVolumePrimarySourced",
            data_type=DataType.DOUBLE,
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrderVolumeNonPrimarySourced",
            data_type=DataType.DOUBLE,
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrderVolumeMultiSourced",
            data_type=DataType.DOUBLE,
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrderVolumeUndelivered",
            data_type=DataType.DOUBLE,
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrderVolumeOnTimeInFull",
            data_type=DataType.DOUBLE,
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrderVolumeLateInFull",
            data_type=DataType.DOUBLE,
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrderVolumeOnTimeInFullRate",
            data_type=DataType.DOUBLE,
            precision_category=["Percentage"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrderVolumeBackordered",
            data_type=DataType.DOUBLE,
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrderVolumeCancelled",
            data_type=DataType.DOUBLE,
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VolumeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrderWeight",
            data_type=DataType.DOUBLE,
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrderWeightPrimarySourced",
            data_type=DataType.DOUBLE,
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrderWeightNonPrimarySourced",
            data_type=DataType.DOUBLE,
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrderWeightMultiSourced",
            data_type=DataType.DOUBLE,
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrderWeightUndelivered",
            data_type=DataType.DOUBLE,
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrderWeightOnTimeInFull",
            data_type=DataType.DOUBLE,
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrderWeightLateInFull",
            data_type=DataType.DOUBLE,
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrderWeightOnTimeInFullRate",
            data_type=DataType.DOUBLE,
            precision_category=["Percentage"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrderWeightBackordered",
            data_type=DataType.DOUBLE,
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPlacedCustomerOrderWeightCancelled",
            data_type=DataType.DOUBLE,
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrders",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrdersPrimarySource",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrdersNonPrimarySource",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrdersMultiSource",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrdersMissedPrimarySource",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrdersUndelivered",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrdersBackordered",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrdersCancelled",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrdersFilledOnTime",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrdersOnTimeFillRate",
            data_type=DataType.DOUBLE,
            precision_category=["Percentage"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedLines",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedLinesPrimarySource",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedLinesNonPrimarySource",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedLinesMultiSource",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedLinesMissedPrimarySource",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedLinesUndelivered",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedLinesBackordered",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedLinesCancelled",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedLinesFilledOnTime",
            data_type=DataType.INTEGER,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedLinesOnTimeFillRate",
            data_type=DataType.DOUBLE,
            precision_category=["Percentage"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderQuantity",
            data_type=DataType.DOUBLE,
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderQuantityPrimarySource",
            data_type=DataType.DOUBLE,
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderQuantityNonPrimarySource",
            data_type=DataType.DOUBLE,
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderQuantityMultiSource",
            data_type=DataType.DOUBLE,
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderQuantityMissedPrimarySource",
            data_type=DataType.DOUBLE,
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderQuantityUndelivered",
            data_type=DataType.DOUBLE,
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderQuantityBackordered",
            data_type=DataType.DOUBLE,
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderQuantityCancelled",
            data_type=DataType.DOUBLE,
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderQuantityFilledOnTime",
            data_type=DataType.DOUBLE,
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderQuantityOnTimeFillRate",
            data_type=DataType.DOUBLE,
            precision_category=["Percentage"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderVolume",
            data_type=DataType.DOUBLE,
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderVolumePrimarySource",
            data_type=DataType.DOUBLE,
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderVolumeNonPrimarySource",
            data_type=DataType.DOUBLE,
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderVolumeMultiSource",
            data_type=DataType.DOUBLE,
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderVolumeMissedPrimarySource",
            data_type=DataType.DOUBLE,
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderVolumeUndelivered",
            data_type=DataType.DOUBLE,
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderVolumeBackordered",
            data_type=DataType.DOUBLE,
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderVolumeCancelled",
            data_type=DataType.DOUBLE,
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderVolumeFilledOnTime",
            data_type=DataType.DOUBLE,
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderVolumeOnTimeFillRate",
            data_type=DataType.DOUBLE,
            precision_category=["Percentage"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderWeight",
            data_type=DataType.DOUBLE,
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderWeightPrimarySource",
            data_type=DataType.DOUBLE,
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderWeightNonPrimarySource",
            data_type=DataType.DOUBLE,
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderWeightMultiSource",
            data_type=DataType.DOUBLE,
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderWeightMissedPrimarySource",
            data_type=DataType.DOUBLE,
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderWeightUndelivered",
            data_type=DataType.DOUBLE,
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderWeightBackordered",
            data_type=DataType.DOUBLE,
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderWeightCancelled",
            data_type=DataType.DOUBLE,
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderWeightFilledOnTime",
            data_type=DataType.DOUBLE,
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderWeightOnTimeFillRate",
            data_type=DataType.DOUBLE,
            precision_category=["Percentage"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OrderCycleTime",
            data_type=DataType.DOUBLE,
            explanation="How long it takes for a placed order to be delivered on average.  Expressed in the base time UOM",
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AverageOrderDaysLate",
            data_type=DataType.DOUBLE,
            explanation="Average time either before or after the due date the order is completely delivered.  Negative numbers would represent delivering early",
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="LineCycleTime",
            data_type=DataType.DOUBLE,
            explanation="How long it takes for a placed line to be delivered on average.  Expressed in the base time UOM",
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AverageLineDaysLate",
            data_type=DataType.DOUBLE,
            explanation="Average time either before or after the due date the line is completely delivered.  Negative numbers would represent delivering early",
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
