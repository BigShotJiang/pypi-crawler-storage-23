"""OptimizationUserDefinedVariableSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# OptimizationUserDefinedVariableSummary table schema
optimization_user_defined_variable_summary = Table(
    table_name="OptimizationUserDefinedVariableSummary",
    neo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OptUserDefinedVariableSmry",
    basic_mode_neo=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Scenarios.ScenarioName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VariableName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["UserDefinedVariables", "TransportationUserDefinedVariables"],
            explanation="The name of the User Defined Variable.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UserDefinedVariables.VariableName", "TransportationUserDefinedVariables.VariableName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VariableValue",
            data_type=DataType.DOUBLE,
            explanation="The value of the Variable for the listed scenario.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
