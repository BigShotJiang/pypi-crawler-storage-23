"""OptimizationGreenfieldCustomerSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# OptimizationGreenfieldCustomerSummary table schema
optimization_greenfield_customer_summary = Table(
    table_name="OptimizationGreenfieldCustomerSummary",
    triad=TechnologySupport.FULLY_SUPPORTED,
    dart=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OptGreenfieldCustomerSmry",
    basic_mode_triad=True,
    basic_mode_dart=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["TRIAD", "DART"],
            master_column=["Scenarios.ScenarioName"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CustomerName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Customers"],
            explanation="The name of the Customer.",
            precision_category=["NaN"],
            basic_mode=["TRIAD", "DART"],
            master_column=["Customers.CustomerName"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ClusterID",
            data_type=DataType.STRING,
            explanation="The ID of the cluster that the Customer was assigned to.",
            precision_category=["NaN"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalDemand",
            data_type=DataType.DOUBLE,
            explanation="The total demand across all products for the Customer.",
            precision_category=["Quantity"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FlowCost",
            data_type=DataType.DOUBLE,
            explanation="The cost of the flows to service this customer. The cost is calculated using a quantity-distance basis and is entered as the Greenfield Flow Cost from the Model Run Options.",
            precision_category=["Cost"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="City",
            data_type=DataType.STRING,
            explanation="This will be specified in the City field of the Customers table. For Customers that have no geodata information entered in the Customers table, reverse-geocoding will be utilized to determine the city.",
            precision_category=["NaN"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PostalCode",
            data_type=DataType.STRING,
            explanation="This will be specified in the Postal Code field of the Customers table.",
            precision_category=["NaN"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Region",
            data_type=DataType.STRING,
            explanation="This will be specified in the Region field of the Customers table. For Customers that have no geodata information entered in the Customers table, reverse-geocoding will be utilized to determine the region.",
            precision_category=["NaN"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Country",
            data_type=DataType.STRING,
            explanation="This will be specified in the Country field of the Customers table. For Customers that have no geodata information entered in the Customers table, reverse-geocoding will be utilized to determine the country.",
            precision_category=["NaN"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CustomerRiskScore",
            data_type=DataType.DOUBLE,
            explanation="The risk score associated with this Customer. This is based on a weighted average of the Concentration Risk, Geographic Risk and User Defined Risk of the Customer.",
            precision_category=["Risk"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConcentrationRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated the with the demand concentration at the Customer location.",
            precision_category=["Risk"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="GeographicRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with the geographic location of the Customer. This is a weighted average of several geographic components that are reported in greater detail in the Optimization Greenfield Geographic Risk Metrics table.",
            precision_category=["Risk"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UserDefinedRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with the User Defined Risk value entered in the Customers table.",
            precision_category=["Risk"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Latitude",
            data_type=DataType.DOUBLE,
            explanation="The latitude of the Customer.",
            precision_category=["GeoCoordinate"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Longitude",
            data_type=DataType.DOUBLE,
            explanation="The longitude of the Customer.",
            precision_category=["GeoCoordinate"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
