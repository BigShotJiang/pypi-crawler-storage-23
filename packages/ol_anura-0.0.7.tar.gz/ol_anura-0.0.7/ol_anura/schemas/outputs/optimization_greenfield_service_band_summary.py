"""OptimizationGreenfieldServiceBandSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# OptimizationGreenfieldServiceBandSummary table schema
optimization_greenfield_service_band_summary = Table(
    table_name="OptimizationGreenfieldServiceBandSummary",
    triad=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OptGreenfieldSvcBandSmry",
    basic_mode_triad=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["TRIAD"],
            master_column=["Scenarios.ScenarioName"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ServiceBandName",
            data_type=DataType.STRING,
            pk=True,
            explanation="The name of the Greenfield Service Band. The band name will be  defined in the Service Band Name field of the Greenfield Service Bands input table.",
            precision_category=["NaN"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CustomerName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Customers"],
            u_o_m_conversion="",
            explanation="The name of the Customer or Group of Customers that the service constraint applies to. When left blank, the service constraints is applied across all customers.",
            master_column=["Customers.CustomerName"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ServiceBandDistance",
            data_type=DataType.DOUBLE,
            pk=True,
            explanation="The distance band for the listed Greenfield Service Band.",
            precision_category=["Distance"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ServiceBandDistanceUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the distance is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["TRIAD"],
            master_column=["UnitsOfMeasure.Symbol"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ServiceBandPercentage",
            data_type=DataType.DOUBLE,
            explanation="The percentage of demand that is required to be serviced within the listed Service Band Distance for this Service Band.",
            precision_category=["Percentage"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ActualDemandPercentage",
            data_type=DataType.DOUBLE,
            explanation="The actual percentage of demand that was serviced within the listed distance band. Note that customer clustering may lead to small violations of these service band constraints.",
            precision_category=["Percentage"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CustomersServed",
            data_type=DataType.INTEGER,
            explanation="The number of customers that were serviced within the listed distance band.",
            precision_category=["Integer"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
