"""OptimizationUserDefinedCostSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# OptimizationUserDefinedCostSummary table schema
optimization_user_defined_cost_summary = Table(
    table_name="OptimizationUserDefinedCostSummary",
    neo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OptUserDefinedCostSmry",
    basic_mode_neo=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Scenarios.ScenarioName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CostName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["UserDefinedCosts"],
            explanation="The name of the User Defined Cost that is specified in the Cost Name field of the User Defined Costs table.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UserDefinedCosts.CostName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VariableName",
            data_type=DataType.STRING,
            master_table=["UserDefinedVariables", "TransportationUserDefinedVariables"],
            explanation="The Variable Name that captures the behavior the User Defined Cost is being applied over. Variables are specified in the User Defined Variables table.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UserDefinedVariables.VariableName", "TransportationUserDefinedVariables.VariableName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VariableValue",
            data_type=DataType.DOUBLE,
            explanation="The value that the variable has taken on for the model solve. This value will be used as the amount that the user defined cost is charged against.",
            precision_category=["Constraint"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StepCostBand",
            data_type=DataType.DOUBLE,
            pk=True,
            explanation="If a step cost is used for the User Defined Cost, each band is reported in its own row. The lower bound of the band will be listed in the Step Cost Band field.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VariableInCostBand",
            data_type=DataType.DOUBLE,
            explanation="The amount of the variable that falls within the listed band.",
            precision_category=["Constraint"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Cost",
            data_type=DataType.DOUBLE,
            explanation="The cost charged against the variable that falls within the listed band.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
