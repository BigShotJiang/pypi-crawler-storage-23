"""OptimizationCostToServePathSegmentDetails table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# OptimizationCostToServePathSegmentDetails table schema
optimization_cost_to_serve_path_segment_details = Table(
    table_name="OptimizationCostToServePathSegmentDetails",
    neo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OptCostToServePathSegmentDeets",
    basic_mode_neo=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            master_column=["Scenarios.ScenarioName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathId",
            data_type=DataType.STRING,
            explanation="A unique identifier for each path.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathStartPeriodName",
            data_type=DataType.STRING,
            master_table=["Periods"],
            explanation="The name of the start period for the path.",
            precision_category=["NaN"],
            master_column=["Periods.PeriodName"],
            in_database=True
        ),
        Column(
            column_name="PathEndPeriodName",
            data_type=DataType.STRING,
            master_table=["Periods"],
            explanation="The name of the end period for the path.",
            precision_category=["NaN"],
            master_column=["Periods.PeriodName"],
            in_database=True
        ),
        Column(
            column_name="PathProductName",
            data_type=DataType.STRING,
            master_table=["Products"],
            explanation="The name of the product associated with the path.",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathOrigin",
            data_type=DataType.STRING,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The origin point of the path.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathOriginType",
            data_type=DataType.STRING,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The type or category of the origin point (e.g. supplier, facility).",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathDestination",
            data_type=DataType.STRING,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The destination point of the path.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathDestinationType",
            data_type=DataType.STRING,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The type of the destination point (e.g. customer location).",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentSequence",
            data_type=DataType.INTEGER,
            explanation="The sequence number of the segment within the path.",
            precision_category=["Integer"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentOrigin",
            data_type=DataType.STRING,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The origin point of the segment.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentDestination",
            data_type=DataType.STRING,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The destination point of the segment.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentType",
            data_type=DataType.STRING,
            explanation="The type or category of the segment (e.g., flow, production, inventory).",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentProductName",
            data_type=DataType.STRING,
            master_table=["Products"],
            explanation="The name of the product associated with the segment.",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentStartPeriodName",
            data_type=DataType.STRING,
            master_table=["Periods"],
            explanation="The name of the start period for the segment.",
            precision_category=["NaN"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentEndPeriodName",
            data_type=DataType.STRING,
            master_table=["Periods"],
            explanation="The name of the end period for the segment.",
            precision_category=["NaN"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentQuantity",
            data_type=DataType.DOUBLE,
            explanation="The quantity associated with the segment.",
            precision_category=["Quantity"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DemandQuantity",
            data_type=DataType.DOUBLE,
            explanation="The demand quantity for the product associated with the segment.",
            precision_category=["Quantity"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BomName",
            data_type=DataType.STRING,
            master_table=["BillsOfMaterials"],
            explanation="The name of the Bill of Materials (BOM) associated with the segment.",
            precision_category=["NaN"],
            master_column=["BillsOfMaterials.BOMName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProcessName",
            data_type=DataType.STRING,
            master_table=["Processes"],
            explanation="The name of the process associated with the segment.",
            precision_category=["NaN"],
            master_column=["Processes.ProcessName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ModeName",
            data_type=DataType.STRING,
            master_table=["TransportationModes"],
            explanation="The name of the mode associated with the segment.",
            precision_category=["NaN"],
            master_column=["TransportationModes.ModeName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentCost",
            data_type=DataType.DOUBLE,
            explanation="The cost associated with the segment.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentRevenue",
            data_type=DataType.DOUBLE,
            explanation="The revenue associated with the segment.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentTransportationCost",
            data_type=DataType.DOUBLE,
            explanation="The transportation cost associated with the segment.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentShipmentCost",
            data_type=DataType.DOUBLE,
            explanation="The shipment cost associated with the segment.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentFuelSurchargeCost",
            data_type=DataType.DOUBLE,
            explanation="The fuel surcharge cost associated with the segment.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentMultiStopRouteCost",
            data_type=DataType.DOUBLE,
            explanation="The Multi Stop Route Cost associated with this segment.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentDutyCost",
            data_type=DataType.DOUBLE,
            explanation="The duty cost associated with the segment.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentTariffCost",
            data_type=DataType.DOUBLE,
            explanation="The tariff cost associated with the segment.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentInTransitHoldingCost",
            data_type=DataType.DOUBLE,
            explanation="The in-transit holding cost associated with the segment.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentSourcingCost",
            data_type=DataType.DOUBLE,
            explanation="The sourcing cost associated with the segment.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentProductionCost",
            data_type=DataType.DOUBLE,
            explanation="The production cost associated with the segment.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentProcessCost",
            data_type=DataType.DOUBLE,
            explanation="The unit process cost associated with the segment.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentProcessFixedCost",
            data_type=DataType.DOUBLE,
            explanation="The fixed process cost associated with the segment.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentSupplyCost",
            data_type=DataType.DOUBLE,
            explanation="The Supply Cost associated with the segment",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentInboundHandlingCost",
            data_type=DataType.DOUBLE,
            explanation="The inbound handling cost associated with the segment.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentOutboundHandlingCost",
            data_type=DataType.DOUBLE,
            explanation="The outbound handling cost associated with the segment.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentPrebuildHoldingCost",
            data_type=DataType.DOUBLE,
            explanation="The prebuild holding cost associated with the segment.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentTurnEstimatedHoldingCost",
            data_type=DataType.DOUBLE,
            explanation="The estimated holding cost associated with the segment.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentStorageCost",
            data_type=DataType.DOUBLE,
            explanation="The storage cost associated with the segment.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentFacilityFixedOperatingCost",
            data_type=DataType.DOUBLE,
            explanation="The facility fixed operating cost associated with the segment.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentFacilityFixedStartupCost",
            data_type=DataType.DOUBLE,
            explanation="The facility fixed startup cost associated with the segment.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentFacilityFixedClosingCost",
            data_type=DataType.DOUBLE,
            explanation="The facility fixed closing cost associated with the segment.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentWorkCenterFixedOperatingCost",
            data_type=DataType.DOUBLE,
            explanation="The work center fixed operating cost associated with the segment.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentWorkCenterFixedStartupCost",
            data_type=DataType.DOUBLE,
            explanation="The work center fixed startup cost associated with the segment.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentWorkCenterFixedClosingCost",
            data_type=DataType.DOUBLE,
            explanation="The work center fixed closing cost associated with the segment.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentUserDefinedCost",
            data_type=DataType.DOUBLE,
            explanation="The user-defined cost associated with the segment.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentCO2Cost",
            data_type=DataType.DOUBLE,
            explanation="The cost associated with CO2 emissions for the segment.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentReturnCost",
            data_type=DataType.DOUBLE,
            explanation="The cost associated with returns for the segment.",
            precision_category=["Cost"],
            in_database=True
        ),
    ]
)
