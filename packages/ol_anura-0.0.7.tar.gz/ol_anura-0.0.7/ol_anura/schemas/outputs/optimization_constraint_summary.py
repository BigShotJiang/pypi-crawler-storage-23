"""OptimizationConstraintSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, ConstraintType, TechnologySupport

# OptimizationConstraintSummary table schema
optimization_constraint_summary = Table(
    table_name="OptimizationConstraintSummary",
    neo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OptConstraintSmry",
    basic_mode_neo=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Scenarios.ScenarioName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConstraintName",
            data_type=DataType.STRING,
            pk=True,
            explanation="The name assigned to the constraint by the optimization solver. Depending on the type of constraint, only applicable fields will be populated with the constraint details that apply.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            master_table=["Periods"],
            explanation="The name of the Period.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            master_table=["Facilities"],
            explanation="The name of the Facility.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Facilities.FacilityName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OriginName",
            data_type=DataType.STRING,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The name of the Origin location.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DestinationName",
            data_type=DataType.STRING,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The name of the Destination location.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            master_table=["Products"],
            explanation="The name of the Product.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Products.ProductName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ModeName",
            data_type=DataType.STRING,
            master_table=["TransportationModes"],
            explanation="The name of the Mode.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["TransportationModes.ModeName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProcessName",
            data_type=DataType.STRING,
            master_table=["Processes"],
            explanation="The name of the Process.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Processes.ProcessName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WorkCenterName",
            data_type=DataType.STRING,
            master_table=["WorkCenters"],
            explanation="The name of the Work Center.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["WorkCenters.WorkCenterName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BOMName",
            data_type=DataType.STRING,
            master_table=["BillsOfMaterials"],
            explanation="The name of the BOM.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["BillsOfMaterials.BOMName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConstraintType",
            data_type=DataType.STRING,
            explanation="The type of Constraint, one of Min, Max, Fixed, or Conditional Min",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConstraintValue",
            data_type=DataType.DOUBLE,
            explanation="The requirement of the Constraint. This is the populated Constraint value field of the corresponding constraint table.",
            precision_category=["Constraint"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConstraintActivity",
            data_type=DataType.DOUBLE,
            explanation="The resulting activity of the constraint will be reported here.",
            precision_category=["Constraint"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SlackPercentage",
            data_type=DataType.DOUBLE,
            explanation="The Slack Percentage will show how close the constraints were to being binding. For a Constraint Type of Max, the percentage will be reported as Constraint Activity / Constraint Value.",
            precision_category=["Percentage"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConstraintViolation",
            data_type=DataType.DOUBLE,
            explanation="If a model is infeasible and constraints must be relaxed, the Constraint Violation field will show how much the constraint had to be relaxed for a feasible solution to be obtained.",
            precision_category=["Constraint"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SuggestedConstraintValue",
            data_type=DataType.DOUBLE,
            explanation="If a model is infeasible and constraints must be relaxed, the Suggest Constraint Value will show what the constraint value must be adjusted to for a feasible solution to be obtained.",
            precision_category=["Constraint"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
