"""SimulationFacilityProductServiceSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# SimulationFacilityProductServiceSummary table schema
simulation_facility_product_service_summary = Table(
    table_name="SimulationFacilityProductServiceSummary",
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="SimFacilityProductSvcSmry",
    basic_mode_throg=True,
    basic_mode_dendro=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["Scenarios.ScenarioName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities"],
            explanation="The name of the Facility.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["Facilities.FacilityName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Products"],
            explanation="The name of the Product.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["Products.ProductName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StatType",
            data_type=DataType.STRING,
            pk=True,
            explanation="Simulations that were run for multiple replications will have outputs summarized into several statistics. The type of statistic being reported will be populated in this field. For a single replication simulation, the only Stat Type will be Mean.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="QuotedTimeToFill",
            data_type=DataType.DOUBLE,
            explanation="The quoted time to fill as entered in the Inventory Policies table for the listed Facility / Product combination. This is the length of time from the point that an order enters the fulfillment queue at the Facility until it must be filled to be considered filled on time.",
            precision_category=["Time"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TimeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that time outputs are expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedLines",
            data_type=DataType.DOUBLE,
            explanation="The number of lines received by the listed Facility / Product combination.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedLinesPrimarySource",
            data_type=DataType.DOUBLE,
            explanation="The number of lines received by the listed Facility / Product combination where the Facility was listed as the primary source for the order as specified in either the Customer Fulfillment Policies or Replenishment Policies table.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedLinesNonPrimarySource",
            data_type=DataType.DOUBLE,
            explanation="The number of lines received by the listed Facility / Product combination where the Facility was not listed as the primary source for the order as specified in either the Customer Fulfillment Policies or Replenishment Policies table.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedLinesMultiSource",
            data_type=DataType.DOUBLE,
            explanation="The number of lines received by the listed Facility / Product combination where multiple Facilities were used to satisfy the line item for the listed Product.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedLinesMissedPrimarySource",
            data_type=DataType.DOUBLE,
            explanation="The number of lines rejected by the listed Facility / Product combination where the Facility was supposed to serve as the primary source as specified in either the Customer Fulfillment or Replenishment Policies table.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedLinesUndelivered",
            data_type=DataType.DOUBLE,
            explanation="The number of lines received by the listed Facility / Product combination that were undelivered. This would include lines that were cancelled as well as lines that were in-transit at the time the simulation ended.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedLinesBackordered",
            data_type=DataType.DOUBLE,
            explanation="The number of lines received by the listed Facility / Product combination that were placed into backorder.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedLinesCancelled",
            data_type=DataType.DOUBLE,
            explanation="The number of lines received by the listed Facility / Product combination that were cancelled.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedLinesFilledOnTime",
            data_type=DataType.DOUBLE,
            explanation="The number of lines received by the listed Facility / Product combination that were filled within the listed Quoted Time To Fill.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedLinesOnTimeFillRate",
            data_type=DataType.DOUBLE,
            explanation="The rate of lines fulfilled on time by the listed Facility / Product combination. This is calculated as the Received Lines Filled On Time divided by Received Lines.",
            precision_category=["Percentage"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderQuantity",
            data_type=DataType.DOUBLE,
            explanation="The total quantity of received orders for the listed Facility / Product combination.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderQuantityPrimarySource",
            data_type=DataType.DOUBLE,
            explanation="The total quantity of received orders for the listed Facility / Product combination where the Facility was listed as the primary source in either the Customer Fulfillment or Replenishment Policies table.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderQuantityNonPrimarySource",
            data_type=DataType.DOUBLE,
            explanation="The total quantity of received orders for the listed Facility / Product combination where the Facility was not listed as the primary source in either the Customer Fulfillment or Replenishment Policies table.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderQuantityMultiSource",
            data_type=DataType.DOUBLE,
            explanation="The total quantity of received orders for the listed Facility / Product combination where multiple Facilities were used to satisfy the line item for the listed Product.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderQuantityMissedPrimarySource",
            data_type=DataType.DOUBLE,
            explanation="The total quantity of received orders that was rejected for the listed Facility / Product combination where the Facility was supposed to serve as the primary source as specified in either the Customer Fulfillment or Replenishment Policies table.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderQuantityUndelivered",
            data_type=DataType.DOUBLE,
            explanation="The total quantity of received orders for the listed Facility / Product combination that was undelivered. This would include lines that were cancelled as well as lines that were in-transit at the time the simulation ended.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderQuantityBackordered",
            data_type=DataType.DOUBLE,
            explanation="The total quantity of received orders for the listed Facility / Product combination that was placed into backorder.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderQuantityCancelled",
            data_type=DataType.DOUBLE,
            explanation="The total quantity of received orders for the listed Facility / Product combination that was cancelled.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderQuantityFilledOnTime",
            data_type=DataType.DOUBLE,
            explanation="The total quantity of received orders for the listed Facility / Product combination that was filled within the listed Quoted Time To Fill.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderQuantityOnTimeFillRate",
            data_type=DataType.DOUBLE,
            explanation="The rate of received order quantity fulfilled on time for the listed Facility / Product combination. This is calculated as the Received Order Quantity Filled On Time divided by Received Order Quantity.",
            precision_category=["Percentage"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="QuantityUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that quantity outputs are expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderVolume",
            data_type=DataType.DOUBLE,
            explanation="The total volume of received orders for the listed Facility / Product combination.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderVolumePrimarySource",
            data_type=DataType.DOUBLE,
            explanation="The total volume of received orders for the listed Facility / Product combination where the Facility was listed as the primary source in either the Customer Fulfillment or Replenishment Policies table.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderVolumeNonPrimarySource",
            data_type=DataType.DOUBLE,
            explanation="The total volume of received orders for the listed Facility / Product combination where the Facility was not listed as the primary source in either the Customer Fulfillment or Replenishment Policies table.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderVolumeMultiSource",
            data_type=DataType.DOUBLE,
            explanation="The total volume of received orders for the listed Facility / Product combination where multiple Facilities were used to satisfy the line item for the listed Product.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderVolumeMissedPrimarySource",
            data_type=DataType.DOUBLE,
            explanation="The total volume of received orders that was rejected for the listed Facility / Product combination where the Facility was supposed to serve as the primary source as specified in either the Customer Fulfillment or Replenishment Policies table.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderVolumeUndelivered",
            data_type=DataType.DOUBLE,
            explanation="The total volume of received orders for the listed Facility / Product combination that was undelivered. This would include lines that were cancelled as well as lines that were in-transit at the time the simulation ended.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderVolumeBackordered",
            data_type=DataType.DOUBLE,
            explanation="The total volume of received orders for the listed Facility / Product combination that was placed into backorder.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderVolumeCancelled",
            data_type=DataType.DOUBLE,
            explanation="The total volume of received orders for the listed Facility / Product combination that was cancelled.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderVolumeFilledOnTime",
            data_type=DataType.DOUBLE,
            explanation="The total volume of received orders for the listed Facility / Product combination that was filled within the listed Quoted Time To Fill.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderVolumeOnTimeFillRate",
            data_type=DataType.DOUBLE,
            explanation="The rate of received order volume fulfilled on time for the listed Facility / Product combination. This is calculated as the Received Order volume Filled On Time divided by Received Order volume.",
            precision_category=["Percentage"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VolumeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that volume outputs are expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderWeight",
            data_type=DataType.DOUBLE,
            explanation="The total weight of received orders for the listed Facility / Product combination.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderWeightPrimarySource",
            data_type=DataType.DOUBLE,
            explanation="The total weight of received orders for the listed Facility / Product combination where the Facility was listed as the primary source in either the Customer Fulfillment or Replenishment Policies table.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderWeightNonPrimarySource",
            data_type=DataType.DOUBLE,
            explanation="The total weight of received orders for the listed Facility / Product combination where the Facility was not listed as the primary source in either the Customer Fulfillment or Replenishment Policies table.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderWeightMultiSource",
            data_type=DataType.DOUBLE,
            explanation="The total weight of received orders for the listed Facility / Product combination where multiple Facilities were used to satisfy the line item for the listed Product.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderWeightMissedPrimarySource",
            data_type=DataType.DOUBLE,
            explanation="The total weight of received orders that was rejected for the listed Facility / Product combination where the Facility was supposed to serve as the primary source as specified in either the Customer Fulfillment or Replenishment Policies table.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderWeightUndelivered",
            data_type=DataType.DOUBLE,
            explanation="The total weight of received orders for the listed Facility / Product combination that was undelivered. This would include lines that were cancelled as well as lines that were in-transit at the time the simulation ended.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderWeightBackordered",
            data_type=DataType.DOUBLE,
            explanation="The total weight of received orders for the listed Facility / Product combination that was placed into backorder.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderWeightCancelled",
            data_type=DataType.DOUBLE,
            explanation="The total weight of received orders for the listed Facility / Product combination that was cancelled.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderWeightFilledOnTime",
            data_type=DataType.DOUBLE,
            explanation="The total weight of received orders for the listed Facility / Product combination that was filled within the listed Quoted Time To Fill.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReceivedOrderWeightOnTimeFillRate",
            data_type=DataType.DOUBLE,
            explanation="The rate of received order weight fulfilled on time for the listed Facility / Product combination. This is calculated as the Received Order weight Filled On Time divided by Received Order weight.",
            precision_category=["Percentage"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WeightUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that weight outputs are expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedLines",
            data_type=DataType.DOUBLE,
            explanation="The number of lines that were placed for the listed Facility / Product combination.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedLinesPrimarySourced",
            data_type=DataType.DOUBLE,
            explanation="The number of lines for the listed Facility / Product combination that were sourced from the primary location as specified in the Replenishment or Procurement Policies table.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedLinesNonPrimarySourced",
            data_type=DataType.DOUBLE,
            explanation="The number of lines for the listed Facility / Product combination that were sourced from a non-primary location as specified in the Replenishment or Procurement Policies tabl.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedLinesMultiSourced",
            data_type=DataType.DOUBLE,
            explanation="The number of lines for the listed Facility / Product combination.that were sourced from multiple locations.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedLinesUndelivered",
            data_type=DataType.DOUBLE,
            explanation="The number of lines for the listed Facility / Product combination that were undelivered. This would include lines that were cancelled as well as lines that were in-transit at the time the simulation ended.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedLinesBackordered",
            data_type=DataType.DOUBLE,
            explanation="The number of lines for the listed Facility / Product combination that were placed into backorder.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedLinesCancelled",
            data_type=DataType.DOUBLE,
            explanation="The number of lines for the listed Facility / Product combination that were cancelled.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderQuantity",
            data_type=DataType.DOUBLE,
            explanation="The total ordered quantity for the listed Facility / Product combination.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderQuantityPrimarySourced",
            data_type=DataType.DOUBLE,
            explanation="The total ordered quantity for the listed Facility / Product combination that was sourced from the primary location as specified in the Replenishment or Procurement Policies table.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderQuantityNonPrimarySourced",
            data_type=DataType.DOUBLE,
            explanation="The total ordered quantity for the listed Facility / Product combination that was sourced from a non-primary location as specified in the Replenishment or Procurement Policies table.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderQuantityMultiSourced",
            data_type=DataType.DOUBLE,
            explanation="The total ordered quantity for the listed Facility / Product combination that was sourced from multiple locations.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderQuantityUndelivered",
            data_type=DataType.DOUBLE,
            explanation="The total ordered quantity that was undelivered for the listed Facility / Product combination. This would include quantity that was cancelled as well as quantity that was in-transit at the time the simulation ended.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderQuantityBackordered",
            data_type=DataType.DOUBLE,
            explanation="The total ordered quantity for the listed Facility / Product combination that was placed into backorder.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderQuantityCancelled",
            data_type=DataType.DOUBLE,
            explanation="The total ordered quantity that was cancelled for the listed Facility / Product combination.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderVolume",
            data_type=DataType.DOUBLE,
            explanation="The total ordered volume for the listed Facility / Product combination.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderVolumePrimarySourced",
            data_type=DataType.DOUBLE,
            explanation="The total ordered volume for the listed Facility / Product combination that was sourced from the primary location as specified in the Replenishment or Procurement Policies table.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderVolumeNonPrimarySourced",
            data_type=DataType.DOUBLE,
            explanation="The total ordered volume for the listed Facility / Product combination that was sourced from a non-primary location as specified in the Replenishment or Procurement Policies table.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderVolumeMultiSourced",
            data_type=DataType.DOUBLE,
            explanation="The total ordered volume for the listed Facility / Product combination that was sourced from multiple locations.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderVolumeUndelivered",
            data_type=DataType.DOUBLE,
            explanation="The total ordered volume that was undelivered for the listed Facility / Product combination. This would include volume that was cancelled as well as volume that was in-transit at the time the simulation ended.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderVolumeBackordered",
            data_type=DataType.DOUBLE,
            explanation="The total ordered volume for the listed Facility / Product combination that was placed into backorder.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderVolumeCancelled",
            data_type=DataType.DOUBLE,
            explanation="The total ordered volume that was cancelled for the listed Facility / Product combination.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderWeight",
            data_type=DataType.DOUBLE,
            explanation="The total ordered weight for the listed Facility / Product combination.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderWeightPrimarySourced",
            data_type=DataType.DOUBLE,
            explanation="The total ordered weight for the listed Facility / Product combination that was sourced from the primary location as specified in the Replenishment or Procurement Policies table.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderWeightNonPrimarySourced",
            data_type=DataType.DOUBLE,
            explanation="The total ordered weight for the listed Facility / Product combination that was sourced from a non-primary location as specified in the Replenishment or Procurement Policies table.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderWeightMultiSourced",
            data_type=DataType.DOUBLE,
            explanation="The total ordered weight for the listed Facility / Product combination that was sourced from multiple locations.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderWeightUndelivered",
            data_type=DataType.DOUBLE,
            explanation="The total ordered weight that was undelivered for the listed Facility / Product combination. This would include weight that was cancelled as well as weight that was in-transit at the time the simulation ended.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderWeightBackordered",
            data_type=DataType.DOUBLE,
            explanation="The total ordered weight for the listed Facility / Product combination that was placed into backorder.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderWeightCancelled",
            data_type=DataType.DOUBLE,
            explanation="The total ordered weight that was cancelled for the listed Facility / Product combination.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReadyRate",
            data_type=DataType.DOUBLE,
            explanation="The proportion of time the facility product is not stocked out",
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CustomReadyRate",
            data_type=DataType.DOUBLE,
            explanation="The proportion of time the facility product's on hand inventory is above the custom ready threshold",
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
