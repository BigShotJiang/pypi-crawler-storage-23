"""SimulationRouteReport table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# SimulationRouteReport table schema
simulation_route_report = Table(
    table_name="SimulationRouteReport",
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="SimRouteRpt",
    basic_mode_throg=True,
    basic_mode_dendro=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["Scenarios.ScenarioName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReplicationNumber",
            data_type=DataType.INTEGER,
            pk=True,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteName",
            data_type=DataType.STRING,
            pk=True,
            explanation="The name of the route.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TransportationAssetName",
            data_type=DataType.STRING,
            master_table=["TransportationAssets"],
            explanation="The name of the Transportation Asset used on the route",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["TransportationAssets.AssetName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TransportationAssetUnitId",
            data_type=DataType.INTEGER,
            explanation="The unit id of the Transportation Asset used on the route",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost of the route. This will be the sum of the fixed route cost, the total distance cost of all segments of this route, the total time cost of the route, the total reposition distance cost of the route, the total stop cost of the route and the total unit cost of the route.",
            precision_category=["Cost"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FixedCost",
            data_type=DataType.DOUBLE,
            explanation="The route fixed cost.",
            precision_category=["Cost"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DistanceCost",
            data_type=DataType.DOUBLE,
            explanation="The total distance cost of the route.",
            precision_category=["Cost"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RepositionDistanceCost",
            data_type=DataType.DOUBLE,
            explanation="The total reposition distance cost of the route.",
            precision_category=["Cost"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OutOfRouteDistanceCost",
            data_type=DataType.DOUBLE,
            explanation="The total out of route distance cost of the route.",
            precision_category=["Cost"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TimeCost",
            data_type=DataType.DOUBLE,
            explanation="The time cost of the route.",
            precision_category=["Cost"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WaitTimeCost",
            data_type=DataType.DOUBLE,
            explanation="The wait time cost of the route.",
            precision_category=["Cost"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RestTimeCost",
            data_type=DataType.DOUBLE,
            explanation="The rest time cost for the route.",
            precision_category=["Cost"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BreakTimeCost",
            data_type=DataType.DOUBLE,
            explanation="The short break time cost for the route.",
            precision_category=["Cost"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StopCost",
            data_type=DataType.DOUBLE,
            explanation="The cost attributed to the number of stops in the route.",
            precision_category=["Cost"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnitCost",
            data_type=DataType.DOUBLE,
            explanation="The unit cost for the route.",
            precision_category=["Cost"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteDistance",
            data_type=DataType.DOUBLE,
            explanation="The total route distance.",
            precision_category=["Distance"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RepositionDistance",
            data_type=DataType.DOUBLE,
            explanation="The total reposition distance of the route.",
            precision_category=["Cost"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OutOfRouteDistance",
            data_type=DataType.DOUBLE,
            explanation="The total out of route distance of the route.",
            precision_category=["Cost"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteDistanceUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure used for distance.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteTime",
            data_type=DataType.DOUBLE,
            explanation="The total route time.",
            precision_category=["Time"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteTravelTime",
            data_type=DataType.DOUBLE,
            explanation="The total route travel time.",
            precision_category=["Time"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteServiceTime",
            data_type=DataType.DOUBLE,
            explanation="The total route service time.",
            precision_category=["Time"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteWaitTime",
            data_type=DataType.DOUBLE,
            explanation="The total route wait time.",
            precision_category=["Time"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteRestTime",
            data_type=DataType.DOUBLE,
            explanation="The total time spent in a rest during the route.",
            precision_category=["Time"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteBreakTime",
            data_type=DataType.DOUBLE,
            explanation="The total route break time.",
            precision_category=["Time"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteTimeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure used for time.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="NumberOfStops",
            data_type=DataType.INTEGER,
            explanation="The number of stops taken on this route",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DeliveredQuantity",
            data_type=DataType.DOUBLE,
            explanation="The quantity of product that was served by the route.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="QuantityUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the quantities are expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DeliveredVolume",
            data_type=DataType.DOUBLE,
            explanation="The volume of product that was served by the route.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VolumeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the volumes are expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DeliveredWeight",
            data_type=DataType.DOUBLE,
            explanation="The weight of product that was served by the route.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WeightUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the weights are expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="NumberOfDeliveredShipments",
            data_type=DataType.INTEGER,
            explanation="The number of shipments delivered on the route",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OriginName",
            data_type=DataType.STRING,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The name of the pickup location for the route",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteStartDate",
            data_type=DataType.DATETIME,
            explanation="The date and time at which the Route starts.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteEndDate",
            data_type=DataType.DATETIME,
            explanation="The date and time at which the Route ends.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
