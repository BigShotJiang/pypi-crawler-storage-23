"""SimulationCustomerProductServiceSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# SimulationCustomerProductServiceSummary table schema
simulation_customer_product_service_summary = Table(
    table_name="SimulationCustomerProductServiceSummary",
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="SimCustomerProductSvcSmry",
    basic_mode_throg=True,
    basic_mode_dendro=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["Scenarios.ScenarioName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CustomerName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Customers"],
            explanation="The name of the Customer.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["Customers.CustomerName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Products"],
            explanation="The name of the Product.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["Products.ProductName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StatType",
            data_type=DataType.STRING,
            pk=True,
            explanation="Simulations that were run for multiple replications will have outputs summarized into several statistics. The type of statistic being reported will be populated in this field. For a single replication simulation, the only Stat Type will be Mean.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedLines",
            data_type=DataType.DOUBLE,
            explanation="The number of lines that were placed for the listed Customer / Product combination.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedLinesPrimarySourced",
            data_type=DataType.DOUBLE,
            explanation="The number of lines for the listed Customer / Product combination that were sourced from the primary location as specified in the Customer Fulfillment Policies .",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedLinesNonPrimarySourced",
            data_type=DataType.DOUBLE,
            explanation="The number of lines for the listed Customer / Product combination that were sourced from a non-primary location as specified in the Customer Fulfillment Policies.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedLinesMultiSourced",
            data_type=DataType.DOUBLE,
            explanation="The number of lines for the listed Customer / Product combination that were sourced from multiple locations.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedLinesUndelivered",
            data_type=DataType.DOUBLE,
            explanation="The number of lines for the listed Customer / Product combination that were undelivered. This would include lines that were cancelled as well as lines that were in-transit at the time the simulation ended.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedLinesOnTimeInFull",
            data_type=DataType.DOUBLE,
            explanation="The number of lines for the listed Customer / Product combination that had the complete ordered quantity delivered on time.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedLinesLateInFull",
            data_type=DataType.DOUBLE,
            explanation="The number of lines for the listed Customer / Product combination that had the complete ordered quantity delivered late.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedLinesOnTimeInFullRate",
            data_type=DataType.DOUBLE,
            explanation="The rate of lines delivered on time and in full for the listed Customer / Product combination. This is calculated as PlacedLines On Time In Full divided by Placed Lines.",
            precision_category=["Percentage"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedLinesBackordered",
            data_type=DataType.DOUBLE,
            explanation="The number of lines for the listed Customer / Product combination that were placed into backorder.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedLinesCancelled",
            data_type=DataType.DOUBLE,
            explanation="The number of lines for the listed Customer / Product combination that were cancelled.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderQuantity",
            data_type=DataType.DOUBLE,
            explanation="The total ordered quantity for the listed Customer / Product combination.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderQuantityPrimarySourced",
            data_type=DataType.DOUBLE,
            explanation="The total ordered quantity for the listed Customer / Product combination that was sourced from the primary location as specified in the Customer Fulfillment Policies.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderQuantityNonPrimarySourced",
            data_type=DataType.DOUBLE,
            explanation="The total ordered quantity for the listed Customer / Product combination that was sourced from a non-primary location as specified in the Customer Fulfillment Policies.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderQuantityMultiSourced",
            data_type=DataType.DOUBLE,
            explanation="The total ordered quantity for the listed Customer / Product combination that was sourced from multiple locations.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderQuantityUndelivered",
            data_type=DataType.DOUBLE,
            explanation="The total ordered quantity for the listed Customer / Product combination that was undelivered. This would include quantity that was cancelled as well as quantity that was in-transit at the time the simulation ended.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderQuantityOnTimeInFull",
            data_type=DataType.DOUBLE,
            explanation="The total delivered quantity across all lines that had the complete ordered quantity delivered on time for the listed Customer / Product combination.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderQuantityLateInFull",
            data_type=DataType.DOUBLE,
            explanation="The total delivered quantity across all lines that had the complete ordered quantity delivered late for the listed Customer / Product combination.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderQuantityOnTimeInFullRate",
            data_type=DataType.DOUBLE,
            explanation="The rate of quantity delivered on time and in full for the listed Customer / Product combination. This is calculated as Placed Order Quantity On Time In Full divided by Placed Order Quantity.",
            precision_category=["Percentage"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderQuantityBackordered",
            data_type=DataType.DOUBLE,
            explanation="The total ordered quantity for the listed Customer / Product combination that were placed into backorder.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderQuantityCancelled",
            data_type=DataType.DOUBLE,
            explanation="The total ordered quantity for the listed Customer / Product combination that was cancelled.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="QuantityUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that quantity outputs are expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderVolume",
            data_type=DataType.DOUBLE,
            explanation="The total ordered volume for the listed Customer / Product combination.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderVolumePrimarySourced",
            data_type=DataType.DOUBLE,
            explanation="The total ordered volume for the listed Customer / Product combination that was sourced from the primary location as specified in the Customer Fulfillment Policies.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderVolumeNonPrimarySourced",
            data_type=DataType.DOUBLE,
            explanation="The total ordered volume for the listed Customer / Product combination that was sourced from a non-primary location as specified in the Customer Fulfillment Policies.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderVolumeMultiSourced",
            data_type=DataType.DOUBLE,
            explanation="The total ordered volume for the listed Customer / Product combination that was sourced from multiple locations.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderVolumeUndelivered",
            data_type=DataType.DOUBLE,
            explanation="The total ordered volume for the listed Customer / Product combination that was undelivered. This would include volume that was cancelled as well as volume that was in-transit at the time the simulation ended.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderVolumeOnTimeInFull",
            data_type=DataType.DOUBLE,
            explanation="The total delivered volume across all lines that had the complete ordered volume delivered on time for the listed Customer / Product combination.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderVolumeLateInFull",
            data_type=DataType.DOUBLE,
            explanation="The total delivered volume across all lines that had the complete ordered volume delivered late for the listed Customer / Product combination.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderVolumeOnTimeInFullRate",
            data_type=DataType.DOUBLE,
            explanation="The rate of volume delivered on time and in full for the listed Customer / Product combination. This is calculated as Placed Order volume On Time In Full divided by Placed Order volume.",
            precision_category=["Percentage"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderVolumeBackordered",
            data_type=DataType.DOUBLE,
            explanation="The total ordered volume for the listed Customer / Product combination that were placed into backorder.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderVolumeCancelled",
            data_type=DataType.DOUBLE,
            explanation="The total ordered volume for the listed Customer / Product combination that was cancelled.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VolumeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that volume outputs are expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderWeight",
            data_type=DataType.DOUBLE,
            explanation="The total ordered weight for the listed Customer / Product combination.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderWeightPrimarySourced",
            data_type=DataType.DOUBLE,
            explanation="The total ordered weight for the listed Customer / Product combination that was sourced from the primary location as specified in the Customer Fulfillment Policies.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderWeightNonPrimarySourced",
            data_type=DataType.DOUBLE,
            explanation="The total ordered weight for the listed Customer / Product combination that was sourced from a non-primary location as specified in the Customer Fulfillment Policies.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderWeightMultiSourced",
            data_type=DataType.DOUBLE,
            explanation="The total ordered weight for the listed Customer / Product combination that was sourced from multiple locations.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderWeightUndelivered",
            data_type=DataType.DOUBLE,
            explanation="The total ordered weight for the listed Customer / Product combination that was undelivered. This would include weight that was cancelled as well as weight that was in-transit at the time the simulation ended.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderWeightOnTimeInFull",
            data_type=DataType.DOUBLE,
            explanation="The total delivered weight across all lines that had the complete ordered weight delivered on time for the listed Customer / Product combination.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderWeightLateInFull",
            data_type=DataType.DOUBLE,
            explanation="The total delivered weight across all lines that had the complete ordered weight delivered late for the listed Customer / Product combination.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderWeightOnTimeInFullRate",
            data_type=DataType.DOUBLE,
            explanation="The rate of weight delivered on time and in full for the listed Customer / Product combination. This is calculated as Placed Order weight On Time In Full divided by Placed Order weight.",
            precision_category=["Percentage"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderWeightBackordered",
            data_type=DataType.DOUBLE,
            explanation="The total ordered weight for the listed Customer / Product combination that were placed into backorder.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PlacedOrderWeightCancelled",
            data_type=DataType.DOUBLE,
            explanation="The total ordered weight for the listed Customer / Product combination that was cancelled.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WeightUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that weight outputs are expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Latitude",
            data_type=DataType.DOUBLE,
            explanation="The latitude of the Customer.",
            precision_category=["GeoCoordinate"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Longitude",
            data_type=DataType.DOUBLE,
            explanation="The longitude of the Customer.",
            precision_category=["GeoCoordinate"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="LineCycleTime",
            data_type=DataType.DOUBLE,
            explanation="How long it takes for a placed line to be delivered on average.  Expressed in the base time UOM",
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AverageLineDaysLate",
            data_type=DataType.DOUBLE,
            explanation="Average time either before or after the due date the line is completely delivered.  Negative numbers would represent delivering early",
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
