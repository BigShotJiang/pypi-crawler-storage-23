"""OptimizationIncrementalChangeSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, BudgetBasis, ChangeType, TechnologySupport

# OptimizationIncrementalChangeSummary table schema
optimization_incremental_change_summary = Table(
    table_name="OptimizationIncrementalChangeSummary",
    neo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OptIncrementalChangeSmry",
    basic_mode_neo=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Scenarios.ScenarioName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ChangeType",
            data_type=ChangeType,
            required=True,
            pk=True,
            explanation="The change type that user would like to limit its variation.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Periods"],
            default_value="ALL",
            explanation="The Period(s) in which we are limiting the changes. Groups are supported.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ActualChange",
            data_type=DataType.DOUBLE,
            required=True,
            default_value="0",
            explanation="The acutal variation of the change type.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Budget",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            required=True,
            default_value="0",
            explanation="The limit for the amount of change on the change type's subject in the specified Period.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BudgetBasis",
            data_type=BudgetBasis,
            default_value="Quantity",
            explanation="The basis for the change limit.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
