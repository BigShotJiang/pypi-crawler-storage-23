"""SimulationNetworkRiskMetricsReplicationDetail table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# SimulationNetworkRiskMetricsReplicationDetail table schema
simulation_network_risk_metrics_replication_detail = Table(
    table_name="SimulationNetworkRiskMetricsReplicationDetail",
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    dart=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="SimNetworkRiskRD",
    basic_mode_throg=True,
    basic_mode_dendro=True,
    basic_mode_dart=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO", "DART"],
            master_column=["Scenarios.ScenarioName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReplicationNumber",
            data_type=DataType.INTEGER,
            pk=True,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO", "DART"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RiskRatingName",
            data_type=DataType.STRING,
            pk=True,
            explanation="The Risk Rating that risk metrics are reported for.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO", "DART"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="NetworkRiskScore",
            data_type=DataType.DOUBLE,
            precision_category=["Risk"],
            basic_mode=["THROG", "DENDRO", "DART"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductStockingPointCountRisk",
            data_type=DataType.DOUBLE,
            precision_category=["Risk"],
            basic_mode=["THROG", "DENDRO", "DART"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductMakeAndSupplyCountRisk",
            data_type=DataType.DOUBLE,
            precision_category=["Risk"],
            basic_mode=["THROG", "DENDRO", "DART"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TransportTimeRisk",
            data_type=DataType.DOUBLE,
            precision_category=["Risk"],
            basic_mode=["THROG", "DENDRO", "DART"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TimeToImportRisk",
            data_type=DataType.DOUBLE,
            precision_category=["Risk"],
            basic_mode=["THROG", "DENDRO", "DART"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TimeToExportRisk",
            data_type=DataType.DOUBLE,
            precision_category=["Risk"],
            basic_mode=["THROG", "DENDRO", "DART"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
