"""TransportationRouteSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# TransportationRouteSummary table schema
transportation_route_summary = Table(
    table_name="TransportationRouteSummary",
    hopper=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="TransportationRouteSmry",
    basic_mode_hopper=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["Scenarios.ScenarioName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteName",
            data_type=DataType.STRING,
            pk=True,
            explanation="The name of the route.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourID",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="A unique identifier for the tour (asset schedule) that the Route is assigned to",
            precision_category=["NaN"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteType",
            data_type=DataType.STRING,
            explanation="The type of the route: Outbound, Inbound, Backhaul, Interleaved, Template or Reposition",
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TransportationAssetName",
            data_type=DataType.STRING,
            master_table=["TransportationAssets"],
            explanation="The name of the Transportation Asset used on the route",
            precision_category=["Quantity"],
            basic_mode=["HOPPER"],
            master_column=["TransportationAssets.AssetName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost of the route. This will be the sum of the fixed route cost, the total distance cost of all segments of this route, the total time cost of the route, the total reposition distance cost of the route, the total stop cost of the route and the total unit cost of the route.",
            precision_category=["Cost"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FixedCost",
            data_type=DataType.DOUBLE,
            explanation="The route fixed cost. This is specified in the Fixed Cost Per Route field of the Transportation Rates table.",
            precision_category=["Cost"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DistanceCost",
            data_type=DataType.DOUBLE,
            explanation="The total distance cost of the route.",
            precision_category=["Cost"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RepositionDistanceCost",
            data_type=DataType.DOUBLE,
            explanation="The total reposition distance cost of the route.",
            precision_category=["Cost"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OutOfRouteDistanceCost",
            data_type=DataType.DOUBLE,
            explanation="The total out of route distance cost of the route.",
            precision_category=["Cost"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TimeCost",
            data_type=DataType.DOUBLE,
            explanation="The time cost of the route.",
            precision_category=["Cost"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WaitTimeCost",
            data_type=DataType.DOUBLE,
            explanation="The wait time cost of the route.",
            precision_category=["Cost"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RestTimeCost",
            data_type=DataType.DOUBLE,
            explanation="The rest time cost for the route.",
            precision_category=["Cost"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BreakTimeCost",
            data_type=DataType.DOUBLE,
            explanation="The short break time cost for the route.",
            precision_category=["Cost"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DutyTimeCost",
            data_type=DataType.DOUBLE,
            explanation="The duty time cost for the route. This is the additive cost for duty time specified in the Duty Time Cost field of the Transportation Rates table.",
            precision_category=["Cost"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StopCost",
            data_type=DataType.DOUBLE,
            explanation="The cost attributed to the number of stops in the route.",
            precision_category=["Cost"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnitCost",
            data_type=DataType.DOUBLE,
            explanation="The unit cost for the route.",
            precision_category=["Cost"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteDistance",
            data_type=DataType.DOUBLE,
            explanation="The total route distance.",
            precision_category=["Distance"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RepositionDistance",
            data_type=DataType.DOUBLE,
            explanation="The total reposition distance of the route.",
            precision_category=["Cost"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OutOfRouteDistance",
            data_type=DataType.DOUBLE,
            explanation="The total out of route distance of the route.",
            precision_category=["Cost"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteDistanceUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure used for distance.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteTime",
            data_type=DataType.DOUBLE,
            explanation="The total route time.",
            precision_category=["Time"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteTravelTime",
            data_type=DataType.DOUBLE,
            explanation="The total route travel time.",
            precision_category=["Time"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteServiceTime",
            data_type=DataType.DOUBLE,
            explanation="The total route service time.",
            precision_category=["Time"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteAdminTime",
            data_type=DataType.DOUBLE,
            explanation="The total route admin time.",
            precision_category=["Time"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteWaitTime",
            data_type=DataType.DOUBLE,
            explanation="The total route wait time.",
            precision_category=["Time"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteRestTime",
            data_type=DataType.DOUBLE,
            explanation="The total time spent in a rest during the route.",
            precision_category=["Time"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteBreakTime",
            data_type=DataType.DOUBLE,
            explanation="The total time spent in a short break during the route.",
            precision_category=["Time"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteTimeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure used for time.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="NumberOfStops",
            data_type=DataType.INTEGER,
            explanation="The number of stops taken on this route",
            precision_category=["Quantity"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DeliveredQuantity",
            data_type=DataType.DOUBLE,
            explanation="The quantity of product that was served by the route.",
            precision_category=["Quantity"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="QuantityUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the quantities are expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="QuantityCapacityUtilization",
            data_type=DataType.DOUBLE,
            explanation="For pooled inbound and outbound routes, utilization is calculated as total load quantity divided by asset capacity. For interleaved routes, this is calculated as the maximum load quantity over all stops divided by the asset capacity.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DeliveredVolume",
            data_type=DataType.DOUBLE,
            explanation="The volume of product that was served by the route.",
            precision_category=["Volume"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VolumeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the volumes are expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VolumeCapacityUtilization",
            data_type=DataType.DOUBLE,
            explanation="For pooled inbound and outbound routes, utilization is calculated as total load volume divided by asset capacity. For interleaved routes, this is calculated as the maximum load volume over all stops divided by the asset capacity.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DeliveredWeight",
            data_type=DataType.DOUBLE,
            explanation="The weight of product that was served by the route.",
            precision_category=["Weight"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WeightUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the weights are expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WeightCapacityUtilization",
            data_type=DataType.DOUBLE,
            explanation="For pooled inbound and outbound routes, utilization is calculated as total load weight divided by asset capacity. For interleaved routes, this is calculated as the maximum load weight over all stops divided by the asset capacity.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="NumberOfDeliveredShipments",
            data_type=DataType.INTEGER,
            explanation="The number of shipments delivered on the route",
            precision_category=["Quantity"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OriginName",
            data_type=DataType.STRING,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The name of the pickup location for the route",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteStartDate",
            data_type=DataType.DATETIME,
            explanation="The date and time at which the Route starts.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteEndDate",
            data_type=DataType.DATETIME,
            explanation="The date and time at which the Route ends.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteCO2Emissions",
            data_type=DataType.DOUBLE,
            explanation="The CO2 emissions for this route.",
            precision_category=["Quantity"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteCO2Cost",
            data_type=DataType.DOUBLE,
            explanation="The cost attributed to CO2 Emissions for this route.",
            precision_category=["Cost"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteFuelSurchargeCost",
            data_type=DataType.DOUBLE,
            explanation="The fuel surcharge cost for this route.",
            precision_category=["Cost"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteSequenceInTour",
            data_type=DataType.INTEGER,
            explanation="The position of the route in the tour (asset schedule) that it is assigned to.",
            precision_category=["NaN"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DecompositionName",
            data_type=DataType.STRING,
            explanation="Decomposition Name given to the shipments in this route.",
            precision_category=["NaN"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RateName",
            data_type=DataType.STRING,
            explanation="The Rate that was used to calculate the cost of this route. This is selected from the TransportationRates input table.",
            precision_category=["NaN"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RateRouteOriginName",
            data_type=DataType.STRING,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The RouteOriginName used to calculate the cost of this route. This is selected from the TransportationRates input table.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RateRouteDestinationName",
            data_type=DataType.STRING,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The RouteDestinationName used to calculate the cost of this route. This is selected from the TransportationRates input table.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RateType",
            data_type=DataType.STRING,
            explanation="The Rate Type that was used to calculate the cost of this route. This is specified in the Rate Type field of the TransportationAssets table.",
            precision_category=["NaN"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TerritoryName",
            data_type=DataType.STRING,
            explanation="A unique identifier for the territory the route is assigned to.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TerritoryType",
            data_type=DataType.STRING,
            explanation="The type of the territory the route is assigned to.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
