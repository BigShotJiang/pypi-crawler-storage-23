"""OptimizationGreenfieldFacilitySummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# OptimizationGreenfieldFacilitySummary table schema
optimization_greenfield_facility_summary = Table(
    table_name="OptimizationGreenfieldFacilitySummary",
    triad=TechnologySupport.FULLY_SUPPORTED,
    dart=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OptGreenfieldFacilitySmry",
    basic_mode_triad=True,
    basic_mode_dart=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["TRIAD", "DART"],
            master_column=["Scenarios.ScenarioName"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities"],
            explanation="The name of the Greenfield Facility.",
            precision_category=["NaN"],
            basic_mode=["TRIAD", "DART"],
            master_column=["Facilities.FacilityName"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityType",
            data_type=DataType.STRING,
            explanation="The type of Facility, this will be one of Greenfield Facility, Candidate Facility, or Existing Facility. If the Facility was a newly selected location based on the model solve then it will be classified as a Type of Greenfield Facility",
            precision_category=["NaN"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FixedCost",
            data_type=DataType.DOUBLE,
            explanation="The fixed cost of the Facility. For Candidate Facilities and Existing Facilities, this entry comes from the Fixed Operating Cost in the Facilities table. For Greenfield Facilities, this cost comes from the Greenfield Facility Fixed Cost entry in the GreenfieldSettings table.",
            precision_category=["Cost"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalInboundFlowCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost of flows from Suppliers to this Facility.",
            precision_category=["Cost"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalOutboundFlowCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost of greenfield flows that originated at this Facility.",
            precision_category=["Cost"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DemandServed",
            data_type=DataType.DOUBLE,
            explanation="The quantity of demand that was serviced by this Facility.",
            precision_category=["Quantity"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityCapacity",
            data_type=DataType.DOUBLE,
            explanation="The capacity of the listed Facility. For Candidate Facilities and Existing Facilities, this will be specified in the Throughput Capacity field of the Facilities table. For Greenfield Facilities, this will be specified in the Greenfield Facility Throughput Capacity entry of the Greenfield Settings table.",
            precision_category=["Quantity"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityUtilization",
            data_type=DataType.DOUBLE,
            explanation="The utilization of the listed Facility expressed as the Demand Served / Facility Capacity.",
            precision_category=["Percentage"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CustomersServed",
            data_type=DataType.INTEGER,
            explanation="The number of customers that were serviced by this Facility.",
            precision_category=["Integer"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AverageCustomerDistance",
            data_type=DataType.DOUBLE,
            explanation="The average service distance for customers from this Facility.",
            precision_category=["Distance"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FurthestCustomerDistance",
            data_type=DataType.DOUBLE,
            explanation="The largest service distance for a customer that was serviced by this Facility.",
            precision_category=["Distance"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DistanceUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that distance is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["TRIAD"],
            master_column=["UnitsOfMeasure.Symbol"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="City",
            data_type=DataType.STRING,
            explanation="For Candidate Facilities and Existing Facilities, this will be the City specified in the City field of the Facilities table. For Greenfield Facilities, this will be determined by a reverse-geocoding operation using the Greenfield Facility's latitude and longitude coordinates. For Existing or Candidate Facilities that have no geodata information entered in the Facilities table, reverse-geocoding will also be utilized.",
            precision_category=["NaN"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PostalCode",
            data_type=DataType.STRING,
            explanation="For Candidate Facilities and Existing Facilities, this will be the Postal Code specified in the Postal Code field of the Facilities table.",
            precision_category=["NaN"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Region",
            data_type=DataType.STRING,
            explanation="For Candidate Facilities and Existing Facilities, this will be the Region specified in the Region field of the Facilities table. For Greenfield Facilities, this will be determined by a reverse-geocoding operation using the Greenfield Facility's latitude and longitude coordinates. For Existing or Candidate Facilities that have no geodata information entered in the Facilities table, reverse-geocoding will also be utilized.",
            precision_category=["NaN"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Country",
            data_type=DataType.STRING,
            explanation="For Candidate Facilities and Existing Facilities, this will be the Country specified in the Country field of the Facilities table. For Greenfield Facilities, this will be determined by a reverse-geocoding operation using the Greenfield Facility's latitude and longitude coordinates. For Existing or Candidate Facilities that have no geodata information entered in the Facilities table, reverse-geocoding will also be utilized.",
            precision_category=["NaN"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityRiskScore",
            data_type=DataType.DOUBLE,
            explanation="The risk score associated with this Facility. This is based on a weighted average of the Concentration Risk, Utilization Risk, Geographic Risk and User Defined Risk of the Facility.",
            precision_category=["Risk"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConcentrationRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated the with the throughput concentration of the Facility. This is calculated based on the throughput quantity of the facility relative to the total demanded quantity.",
            precision_category=["Risk"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UtilizationRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with how close to capacity the Facility is during the model solve. Unlike NEO, TRIAD will only consider Throughput Utilization for Utilization Risk and therefore there is no further detailed output table on Utilization Risk Metrics in TRIAD.",
            precision_category=["Risk"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="GeographicRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with the geographic location of the Facility. This is a weighted average of several geographic components that are reported in greater detail in the Optimization Greenfield Geographic Risk Metrics table.",
            precision_category=["Risk"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UserDefinedRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with the User Defined Risk value entered in the Facilities table.",
            precision_category=["Risk"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Latitude",
            data_type=DataType.DOUBLE,
            explanation="The latitude of the Facility.",
            precision_category=["GeoCoordinate"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Longitude",
            data_type=DataType.DOUBLE,
            explanation="The longitude of the Facility.",
            precision_category=["GeoCoordinate"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
