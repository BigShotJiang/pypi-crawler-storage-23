"""OptimizationGreenfieldFlowSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# OptimizationGreenfieldFlowSummary table schema
optimization_greenfield_flow_summary = Table(
    table_name="OptimizationGreenfieldFlowSummary",
    triad=TechnologySupport.FULLY_SUPPORTED,
    dart=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OptGreenfieldFlowSmry",
    basic_mode_triad=True,
    basic_mode_dart=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["TRIAD", "DART"],
            master_column=["Scenarios.ScenarioName"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FlowType",
            data_type=DataType.STRING,
            explanation="The type of flow that the record represents. Customer Fulfillment will represent flows from Facilities to Customers and Procurement will represent flows from Suppliers to Facilities.",
            precision_category=["NaN"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OriginName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The Facility or Supplier that the flow originated from.",
            precision_category=["NaN"],
            basic_mode=["TRIAD", "DART"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DestinationName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The Customer or Facility location that the flow arrived to.",
            precision_category=["NaN"],
            basic_mode=["TRIAD", "DART"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FlowQuantity",
            data_type=DataType.DOUBLE,
            explanation="The quantity of the flow units for the listed Origin / Destination combination.",
            precision_category=["Quantity"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FlowCost",
            data_type=DataType.DOUBLE,
            explanation="The transportation cost associated with this flow record.",
            precision_category=["Cost"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TransportDistance",
            data_type=DataType.DOUBLE,
            explanation="The distance of the flow record.",
            precision_category=["Distance"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ServiceBandName",
            data_type=DataType.STRING,
            explanation="The name of the Greenfield Service Band that this flow record falls into. The band name will be defined in the Service Band Name field of the Greenfield Service Bands input table. Service Bands will only be populated for Customer Fulfillment flows.",
            precision_category=["NaN"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ServiceBandDistance",
            data_type=DataType.DOUBLE,
            explanation="The distance of the Greenfield Service band that this flow record falls into. The most restrictive Service Band Distance will be populated here. Service Bands will only be populated for Customer Fulfillment flows.",
            precision_category=["Distance"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DistanceUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the distance is expressed in terms of",
            precision_category=["NaN"],
            basic_mode=["TRIAD"],
            master_column=["UnitsOfMeasure.Symbol"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TransportTime",
            data_type=DataType.DOUBLE,
            explanation="The transport time of the flow record.",
            precision_category=["Time"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TransportTimeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the time is expressed in terms of",
            precision_category=["NaN"],
            basic_mode=["TRIAD"],
            master_column=["UnitsOfMeasure.Symbol"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TransportTimeRisk",
            data_type=DataType.DOUBLE,
            explanation="The Risk metric associated with how long of a transport time the flow has. This will contribute to the model's overall Network Risk score.",
            precision_category=["Risk"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TimeToImportRisk",
            data_type=DataType.DOUBLE,
            explanation="The Risk metric associated with how long it can take imported products to clear customs as they enter the destination country. This contributes to the model's overall Network Risk score.",
            precision_category=["Risk"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TimeToExportRisk",
            data_type=DataType.DOUBLE,
            explanation="The Risk metric associated with how long it can take exported products to clear customs as they leave the origin country. This contributes to the model's overall Network Risk Score.",
            precision_category=["Risk"],
            basic_mode=["TRIAD", "DART"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OriginLatitude",
            data_type=DataType.DOUBLE,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The origin latitude.",
            precision_category=["GeoCoordinate"],
            basic_mode=["TRIAD", "DART"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OriginLongitude",
            data_type=DataType.DOUBLE,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The origin longitude.",
            precision_category=["GeoCoordinate"],
            basic_mode=["TRIAD", "DART"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DestinationLatitude",
            data_type=DataType.DOUBLE,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The destination latitude.",
            precision_category=["GeoCoordinate"],
            basic_mode=["TRIAD", "DART"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DestinationLongitude",
            data_type=DataType.DOUBLE,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The destination longitude.",
            precision_category=["GeoCoordinate"],
            basic_mode=["TRIAD", "DART"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
