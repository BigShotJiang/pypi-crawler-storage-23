"""SimulationEvolutionaryAlgorithmSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# SimulationEvolutionaryAlgorithmSummary table schema
simulation_evolutionary_algorithm_summary = Table(
    table_name="SimulationEvolutionaryAlgorithmSummary",
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="SimEvoAlgorithmSmry",
    basic_mode_throg=True,
    basic_mode_dendro=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The GA-generated scenario name that represents the grouping of genes that make up this scenario. Each Generation will have a set numer of genes, as is specified in the Number of Genes Per Generation Model Run Option.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["Scenarios.ScenarioName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="GenerationNumber",
            data_type=DataType.INTEGER,
            pk=True,
            explanation="The generation number that the outputs are reported for. The maximum number of generations that the GA will run for is specified in the Number OF Generations Model Run Option.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OverallFitnessScore",
            data_type=DataType.DOUBLE,
            explanation="The overall fitness score expressed based on the Utility Curve / Output Factor Weights expressed in the Output Factors table.",
            precision_category=["Percentage"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OriginalScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios", "Facilities", "Suppliers", "Customers"],
            explanation="The original scenario name that each DENDRO-generated scenario was created from.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["Scenarios.ScenarioName", "Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
