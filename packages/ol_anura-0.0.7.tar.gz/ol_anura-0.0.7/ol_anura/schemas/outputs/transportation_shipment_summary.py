"""TransportationShipmentSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# TransportationShipmentSummary table schema
transportation_shipment_summary = Table(
    table_name="TransportationShipmentSummary",
    hopper=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="TransportationShipmentSmry",
    basic_mode_hopper=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["Scenarios.ScenarioName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ShipmentID",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="A unique identifier for the Shipment.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SourceName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            explanation="The Facility that the shipment originates from.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DestinationName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The Customer that the shipment was delivered to.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            master_table=["Products"],
            explanation="The Product in the shipment.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["Products.ProductName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Quantity",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            required=True,
            explanation="The amount of the Product being shipped.",
            precision_category=["Quantity"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="QuantityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity]",
            required_if="Quantity",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that Quantity is reported in terms of.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Volume",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            required=True,
            explanation="The volume of the Product being shipped.",
            precision_category=["Quantity"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VolumeUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Volume]",
            required_if="Volume",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Volume"],
            default_value="{PrimaryVolumeUOM}",
            explanation="The unit of measure that Volume is reported in terms of.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Weight",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            required=True,
            explanation="The weight of the Product being shipped.",
            precision_category=["Quantity"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WeightUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Weight]",
            required_if="Weight",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Weight"],
            default_value="{PrimaryWeightUOM}",
            explanation="The unit of measure that Weight is reported in terms of.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ShipmentStatus",
            data_type=DataType.STRING,
            required=True,
            explanation="The status of the shipment in the solution. It could be Routed, Direct Shipping, Unrouted",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteName",
            data_type=DataType.STRING,
            explanation="The route that contains the shipment.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteType",
            data_type=DataType.STRING,
            explanation="The type of the route: Outbound, Inbound, Backhaul, Interleaved, Template or Reposition",
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AllocatedRouteCost",
            data_type=DataType.DOUBLE,
            explanation="The route cost that the shipment is responsible for",
            precision_category=["Cost"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AllocatedRouteCostPercent",
            data_type=DataType.DOUBLE,
            explanation="The proportion of the route cost that the shipment is responsible for",
            precision_category=["double"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StopID",
            data_type=DataType.STRING,
            explanation="A unique identifier for the delivery stop",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PickupStopID",
            data_type=DataType.STRING,
            explanation="A unique identifier for the pickup stop",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DirectCost",
            data_type=DataType.DOUBLE,
            explanation="The direct cost of the shipment if it uses direct shipping",
            precision_category=["double"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnroutedReason",
            data_type=DataType.STRING,
            explanation="The diagnosed reason of why the shipment is could not be routed",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TransportationAssetName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["TransportationAssets"],
            explanation="The Transportation Asset used for this shipment.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["TransportationAssets.AssetName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PickupDate",
            data_type=DataType.DATETIME,
            explanation="The date and time at which the shipment was picked-up.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DeliveryDate",
            data_type=DataType.DATETIME,
            explanation="The date and time at which the Shipment was delivered.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AllocatedCO2Emissions",
            data_type=DataType.DOUBLE,
            explanation="The allocated CO2 emissions from delivering this shipment.",
            precision_category=["Quantity"],
            in_database=True
        ),
        Column(
            column_name="AllocatedCO2Cost",
            data_type=DataType.DOUBLE,
            explanation="The cost attributed to CO2 Emissions for this shipment.",
            precision_category=["Cost"],
            in_database=True
        ),
        Column(
            column_name="DecompositionName",
            data_type=DataType.STRING,
            explanation="Decomposition Name given to the shipment.",
            precision_category=["NaN"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourID",
            data_type=DataType.STRING,
            explanation="A unique identifier for the tour",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TerritoryName",
            data_type=DataType.STRING,
            explanation="A unique identifier for the territory the shipment is assigned to.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TerritoryType",
            data_type=DataType.STRING,
            explanation="The type of the territory the shipment is assigned to.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OriginLatitude",
            data_type=DataType.DOUBLE,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The origin latitude.",
            precision_category=["GeoCoordinate"],
            basic_mode=["HOPPER"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OriginLongitude",
            data_type=DataType.DOUBLE,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The origin longitude.",
            precision_category=["GeoCoordinate"],
            basic_mode=["HOPPER"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DestinationLatitude",
            data_type=DataType.DOUBLE,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The destination latitude.",
            precision_category=["GeoCoordinate"],
            basic_mode=["HOPPER"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DestinationLongitude",
            data_type=DataType.DOUBLE,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The destination longitude.",
            precision_category=["GeoCoordinate"],
            basic_mode=["HOPPER"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
