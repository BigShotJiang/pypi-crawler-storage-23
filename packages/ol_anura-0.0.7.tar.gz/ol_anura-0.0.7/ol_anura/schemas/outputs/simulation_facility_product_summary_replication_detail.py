"""SimulationFacilityProductSummaryReplicationDetail table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# SimulationFacilityProductSummaryReplicationDetail table schema
simulation_facility_product_summary_replication_detail = Table(
    table_name="SimulationFacilityProductSummaryReplicationDetail",
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="SimFacilityProductSmryRD",
    basic_mode_throg=True,
    basic_mode_dendro=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["Scenarios.ScenarioName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReplicationNumber",
            data_type=DataType.INTEGER,
            pk=True,
            explanation="The replication the results are saved for.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities"],
            explanation="The name of the Facility.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["Facilities.FacilityName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Products"],
            explanation="The name of the Product.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["Products.ProductName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="InventoryHoldingCost",
            data_type=DataType.DOUBLE,
            explanation="The holding cost for the listed Product in inventory at the listed Facility. This is calculated based off of the Carrying Cost Percentage entered in the Inventory Policies table and the Product's Unit Value.",
            precision_category=["Cost"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StorageCost",
            data_type=DataType.DOUBLE,
            explanation="The storage cost for the listed Product being held at the listed Facility. This is a per-unit cost that is calculated based off of the Unit Storage Cost in the Inventory Policies table.",
            precision_category=["Cost"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalInTransitHoldingCost",
            data_type=DataType.DOUBLE,
            explanation="The in-transit holding cost for the listed Product that was assigned to the listed Facility as specified in the Transportation Policies table.",
            precision_category=["Cost"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalProductionCost",
            data_type=DataType.DOUBLE,
            explanation="The production cost for the listed Facility / Product combination. This is specified in the Unit Cost field of the Production Policies table.",
            precision_category=["Cost"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalInboundHandlingCost",
            data_type=DataType.DOUBLE,
            explanation="The inbound handling cost for the listed Product as it entered the listed Facility. This is specified as the Inbound Handling Cost in the Warehousing Policies table.",
            precision_category=["Cost"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalOutboundHandlingCost",
            data_type=DataType.DOUBLE,
            explanation="The outbound handling cost for the listed Product as it left the listed Facility. This is specified as the Outbound Handling Cost in the Warehousing Policies table.",
            precision_category=["Cost"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalProcessCost",
            data_type=DataType.DOUBLE,
            explanation="The total process cost associated with the Facility / Product combination. This cost can be attributed to process costs from a Production Process assigned in the Production Policies table, Stocking / Destocking Process assigned in the Warehousing Policies table, or Load / Unload Process assigned in the Transportation Policies table.",
            precision_category=["Cost"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="EndingOnHandInventoryQuantity",
            data_type=DataType.DOUBLE,
            explanation="The quantity of inventory for the listed Product that was at the listed Facility when the simulation ended.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MinInventoryQuantity",
            data_type=DataType.DOUBLE,
            explanation="The lowest level of inventory quantity for the listed Facility / Product combination.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MaxInventoryQuantity",
            data_type=DataType.DOUBLE,
            explanation="The highest level of inventory quantity for the listed Facility / Product combination.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AverageInventoryQuantity",
            data_type=DataType.DOUBLE,
            explanation="The average level of inventory quantity for the listed Facility / Product combination.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AverageCycleStock",
            data_type=DataType.DOUBLE,
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalProductionQuantity",
            data_type=DataType.DOUBLE,
            explanation="The total quantity of the listed Product that was produced at the listed Facility.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalInboundQuantity",
            data_type=DataType.DOUBLE,
            explanation="The total quantity of the listed Product that entered the listed Facility.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalOutboundQuantity",
            data_type=DataType.DOUBLE,
            explanation="The total quantity of the listed Product that left the listed Facility.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="QuantityUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that quantity outputs are expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="EndingOnHandInventoryVolume",
            data_type=DataType.DOUBLE,
            explanation="The volume of inventory for the listed Product that was at the listed Facility when the simulation ended.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MinInventoryVolume",
            data_type=DataType.DOUBLE,
            explanation="The lowest level of inventory volume for the listed Facility / Product combination.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MaxInventoryVolume",
            data_type=DataType.DOUBLE,
            explanation="The highest level of inventory volume for the listed Facility / Product combination.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AverageInventoryVolume",
            data_type=DataType.DOUBLE,
            explanation="The average level of inventory volume for the listed Facility / Product combination.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalProductionVolume",
            data_type=DataType.DOUBLE,
            explanation="The total volume of the listed Product that was produced at the listed Facility.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalInboundVolume",
            data_type=DataType.DOUBLE,
            explanation="The total volume of the listed Product that entered the listed Facility.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalOutboundVolume",
            data_type=DataType.DOUBLE,
            explanation="The total volume of the listed Product that left the listed Facility.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VolumeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that volume outputs are expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="EndingOnHandInventoryWeight",
            data_type=DataType.DOUBLE,
            explanation="The weight of inventory for the listed Product that was at the listed Facility when the simulation ended.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MinInventoryWeight",
            data_type=DataType.DOUBLE,
            explanation="The lowest level of inventory weight for the listed Facility / Product combination.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MaxInventoryWeight",
            data_type=DataType.DOUBLE,
            explanation="The highest level of inventory weight for the listed Facility / Product combination.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AverageInventoryWeight",
            data_type=DataType.DOUBLE,
            explanation="The average level of inventory weight for the listed Facility / Product combination.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalProductionWeight",
            data_type=DataType.DOUBLE,
            explanation="The total weight of the listed Product that was produced at the listed Facility.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalInboundWeight",
            data_type=DataType.DOUBLE,
            explanation="The total weight of the listed Product that entered the listed Facility.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalOutboundWeight",
            data_type=DataType.DOUBLE,
            explanation="The total weight of the listed Product that left the listed Facility.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WeightUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that weight outputs are expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedLines",
            data_type=DataType.INTEGER,
            explanation="The total number of lines that were received for the listed Facility / Product combination.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedLinesBackordered",
            data_type=DataType.INTEGER,
            explanation="The total number of lines that were received for the listed Facility / Product combination that were placed into backorder.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedLinesCancelled",
            data_type=DataType.INTEGER,
            explanation="The total number of lines that were received for the listed Facility / Product combination that were cancelled.",
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderQuantity",
            data_type=DataType.DOUBLE,
            explanation="The total quantity of received orders for the listed Facility / Product combination.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderQuantityBackordered",
            data_type=DataType.DOUBLE,
            explanation="The total quantity of received orders for the listed Facility / Product combination that was placed into backorder.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderQuantityCancelled",
            data_type=DataType.DOUBLE,
            explanation="The total quantity of received orders for the listed Facility / Product combination that was cancelled.",
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderVolume",
            data_type=DataType.DOUBLE,
            explanation="The total volume of received orders for the listed Facility / Product combination.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderVolumeBackordered",
            data_type=DataType.DOUBLE,
            explanation="The total volume of received orders for the listed Facility / Product combination that was placed into backorder.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderVolumeCancelled",
            data_type=DataType.DOUBLE,
            explanation="The total volume of received orders for the listed Facility / Product combination that was cancelled.",
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderWeight",
            data_type=DataType.DOUBLE,
            explanation="The total weight of received orders for the listed Facility / Product combination.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderWeightBackordered",
            data_type=DataType.DOUBLE,
            explanation="The total weight of received orders for the listed Facility / Product combination that was placed into backorder.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalReceivedOrderWeightCancelled",
            data_type=DataType.DOUBLE,
            explanation="The total weight of received orders for the listed Facility / Product combination that was cancelled.",
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Latitude",
            data_type=DataType.DOUBLE,
            explanation="The latitude of the Facility.",
            precision_category=["GeoCoordinate"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Longitude",
            data_type=DataType.DOUBLE,
            explanation="The longitude of the Facility.",
            precision_category=["GeoCoordinate"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
