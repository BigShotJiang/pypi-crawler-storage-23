"""TransportationTerritoryPlanningSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# TransportationTerritoryPlanningSummary table schema
transportation_territory_planning_summary = Table(
    table_name="TransportationTerritoryPlanningSummary",
    hopper=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="TransportationTerritoryPlanningSummary",
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["Scenarios.ScenarioName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TerritoryName",
            data_type=DataType.STRING,
            pk=True,
            explanation="A unique identifier for the territory.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TerritoryType",
            data_type=DataType.STRING,
            explanation="The type of the territory.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="NumberOfDeliveryLocations",
            data_type=DataType.INTEGER,
            explanation="The number of delivery locations in the territory.",
            precision_category=["Quantity"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="NumberOfPickupLocations",
            data_type=DataType.INTEGER,
            explanation="The number of pickup locations in the territory.",
            precision_category=["Quantity"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalDeliveredQuantity",
            data_type=DataType.DOUBLE,
            explanation="The total quantity of product that was delivered to the territory.",
            precision_category=["Quantity"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="QuantityUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the quantities are expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalDeliveredVolume",
            data_type=DataType.DOUBLE,
            explanation="The total volume of product that was delivered to the territory.",
            precision_category=["Volume"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VolumeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the volumes are expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalDeliveredWeight",
            data_type=DataType.DOUBLE,
            explanation="The total weight of product that was delivered to the territory.",
            precision_category=["Weight"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WeightUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the weights are expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="NumberOfDeliveredShipments",
            data_type=DataType.INTEGER,
            explanation="The number of shipments that were delivered to the territory.",
            precision_category=["Quantity"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="NumberOfRoutes",
            data_type=DataType.INTEGER,
            explanation="The number of routes serving the territory.",
            precision_category=["Quantity"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalDistance",
            data_type=DataType.DOUBLE,
            explanation="The total distance of all routes serving the territory.",
            precision_category=["Distance"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DistanceUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure used for distance.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalTime",
            data_type=DataType.DOUBLE,
            explanation="The total time of all routes serving the territory.",
            precision_category=["Time"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TimeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure used for time.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
