"""SimulationWorkCenterSummaryReplicationDetail table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# SimulationWorkCenterSummaryReplicationDetail table schema
simulation_work_center_summary_replication_detail = Table(
    table_name="SimulationWorkCenterSummaryReplicationDetail",
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    dart=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="SimWorkCenterSmryRD",
    basic_mode_throg=True,
    basic_mode_dendro=True,
    basic_mode_dart=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["Scenarios.ScenarioName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReplicationNumber",
            data_type=DataType.INTEGER,
            pk=True,
            precision_category=["Integer"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WorkCenterName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["WorkCenters"],
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["WorkCenters.WorkCenterName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities"],
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["Facilities.FacilityName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalWorkCenterCost",
            data_type=DataType.DOUBLE,
            precision_category=["Cost"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalProcessCost",
            data_type=DataType.DOUBLE,
            precision_category=["Cost"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OperatingCost",
            data_type=DataType.DOUBLE,
            precision_category=["Cost"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="NetTotalProcessedQuantity",
            data_type=DataType.DOUBLE,
            precision_category=["Quantity"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="QuantityUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="NetTotalProcessedVolume",
            data_type=DataType.DOUBLE,
            precision_category=["Volume"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VolumeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="NetTotalProcessedWeight",
            data_type=DataType.DOUBLE,
            precision_category=["Weight"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WeightUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalProcessedTime",
            data_type=DataType.DOUBLE,
            precision_category=["Time"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TimeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Latitude",
            data_type=DataType.DOUBLE,
            precision_category=["GeoCoordinate"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Longitude",
            data_type=DataType.DOUBLE,
            precision_category=["GeoCoordinate"],
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
