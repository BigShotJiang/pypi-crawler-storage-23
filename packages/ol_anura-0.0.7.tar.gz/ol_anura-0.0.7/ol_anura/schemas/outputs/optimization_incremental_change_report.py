"""OptimizationIncrementalChangeReport table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# OptimizationIncrementalChangeReport table schema
optimization_incremental_change_report = Table(
    table_name="OptimizationIncrementalChangeReport",
    neo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OptIncrementalChangeRpt",
    basic_mode_neo=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Scenarios.ScenarioName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Periods"],
            default_value="ALL",
            explanation="The Period(s) in which we are limiting the changes",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ChangeColumn",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            default_value="ALL",
            explanation="The name of the column where the change has been identified",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ChangeKey",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            default_value="ALL",
            explanation="The key(s) that specifies the change column",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ChangeKeyValue",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            default_value="ALL",
            explanation="The key's value that specifies the change column",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Reference",
            data_type=DataType.STRING,
            required=True,
            default_value="ALL",
            explanation="The reference for the change which can be an initial state, the previous period or another scenario",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ActualChange",
            data_type=DataType.STRING,
            required=True,
            explanation="The acutal variation of the change column.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
