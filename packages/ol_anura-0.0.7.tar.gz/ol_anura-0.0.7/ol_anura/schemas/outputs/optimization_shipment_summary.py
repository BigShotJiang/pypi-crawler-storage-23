"""OptimizationShipmentSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# OptimizationShipmentSummary table schema
optimization_shipment_summary = Table(
    table_name="OptimizationShipmentSummary",
    neo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OptShipmentSmry",
    basic_mode_neo=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Scenarios.ScenarioName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Periods"],
            explanation="The time period that the results are reported for.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OriginName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The Facility or Supplier or Customer that the shipment originated from.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DestinationName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The Customer or Facility location that the shipment arrived to.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductGroupName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Products", "Groups"],
            explanation="The Product Group the shipment record is reported for. This can be listed as an individual product if the Product Name in the Transportation Policies table was specified as an individual product and a Fixed Cost was entered.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Products.ProductName", "Groups.GroupName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ModeName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["TransportationModes"],
            explanation="The Transportation Mode used for this shipment.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["TransportationModes.ModeName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Shipments",
            data_type=DataType.DOUBLE,
            explanation="The number of shipments that moved along the transportation arc specified. This is calculated as the Flow Quantity / Average Shipment Size and will consider the Flow Quantity across all of the Products that are captured in the listed Product Group.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ShipmentCost",
            data_type=DataType.DOUBLE,
            explanation="The cost associated with the number of shipments that were sent. This is specified in the Fixed Cost column of the Transportation Policies table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ShipmentSize",
            data_type=DataType.DOUBLE,
            explanation="The shipment  size that was used to calculate the number of shipments. This is specified in the Average Shipment Size field of the Transportation Polices table. In the event that Average Shipment Size is not filled out in the Transportation Policies table, the Average Shipment Size of the Transportation Modes table will be used.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ShipmentSizeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the Shipment Size is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OriginLatitude",
            data_type=DataType.DOUBLE,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The latitude of the Origin location.",
            precision_category=["GeoCoordinate"],
            basic_mode=["NEO"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OriginLongitude",
            data_type=DataType.DOUBLE,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The longitude of the Origin location.",
            precision_category=["GeoCoordinate"],
            basic_mode=["NEO"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DestinationLatitude",
            data_type=DataType.DOUBLE,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The latitude of the Destination location.",
            precision_category=["GeoCoordinate"],
            basic_mode=["NEO"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DestinationLongitude",
            data_type=DataType.DOUBLE,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The longitude of the Destination location.",
            precision_category=["GeoCoordinate"],
            basic_mode=["NEO"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
