"""OptimizationFacilitySummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, InitialState, TechnologySupport

# OptimizationFacilitySummary table schema
optimization_facility_summary = Table(
    table_name="OptimizationFacilitySummary",
    neo=TechnologySupport.FULLY_SUPPORTED,
    dart=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OptFacilitySmry",
    basic_mode_neo=True,
    basic_mode_dart=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["NEO", "DART"],
            master_column=["Scenarios.ScenarioName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Periods"],
            explanation="The time period that the results are reported for.",
            precision_category=["NaN"],
            basic_mode=["NEO", "DART"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities"],
            explanation="The name of the Facility.",
            precision_category=["NaN"],
            basic_mode=["NEO", "DART"],
            master_column=["Facilities.FacilityName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="InitialState",
            data_type=DataType.STRING,
            explanation="The initial state of the Facility. This is specified in the Initial State field of the Facilities table and will be one of Existing or Potential",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="InitialStatus",
            data_type=DataType.STRING,
            explanation="The Initial Status of the Facility. This is specified in the Facility Status field of the Facilities table and will be one of Open, Closed or Consider.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OptimizedStatus",
            data_type=DataType.STRING,
            explanation="The status of the Facility based on the optimization's results. This will be one of Open, Closed or Consider.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalFacilityCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost associated with the Facility. This will be reported as the sum of the Fixed Operating Cost, Fixed Startup Cost, Fixed Closing Cost, Inbound Handling Cost, Outbound Handling Cost, Prebuild Holding Cost, Turn Estimated Holding Cost, Storage Cost, In Transit Holding Cost, Production Cost and Process Cost for all activities associated with the Facility.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OperatingCost",
            data_type=DataType.DOUBLE,
            explanation="The fixed operating cost of the Facility. This is specified in the Fixed Operating Cost field of the Facilities table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StartupCost",
            data_type=DataType.DOUBLE,
            explanation="The startup cost of the Facility. If a Facility opens in a period then the fixed startup cost will be applied. This is specified in the Fixed Startup Cost field of the Facilities table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ClosingCost",
            data_type=DataType.DOUBLE,
            explanation="The closing cost of the Facility. If a Facility closes in a period then the fixed closing cost will be applied. This is specified in the Fixed Closing Cost field of the Facilities table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalInboundHandlingCost",
            data_type=DataType.DOUBLE,
            explanation="The cost associated with inbound handling at the Facility for the listed Product. This is calculated as the sum of Inbound Handling Costs across all products for the Facility as reported in the Optimization Warehousing Summary table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalOutboundHandlingCost",
            data_type=DataType.DOUBLE,
            explanation="The cost associated with outbound handling at the Facility for the listed Product. This is calculated as the sum of Outbound Handling Costs across all products for the Facility as reported in the Optimization Warehousing Summary table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalPrebuildHoldingCost",
            data_type=DataType.DOUBLE,
            explanation="The holding cost charged to the amount of average prebuild inventory. This is calculated as the sum of Prebuild Holding Costs across all products for the Facility as reported in the Optimization Inventory Summary table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalTurnEstimatedHoldingCost",
            data_type=DataType.DOUBLE,
            explanation="The holding cost charged to the amount of turn estimated inventory. This is calculated as the sum of Turn Estimated Holding Costs across all products for the Facility as reported in the Optimization Inventory Summary table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalTransportationEstimatedHoldingCost",
            data_type=DataType.DOUBLE,
            explanation="The holding cost charged to the amount of transportation estimated inventory. This is calculated as the sum of Transportation Estimated Holding Costs across all products for the Facility as reported in the Optimization Inventory Summary table.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalProductionEstimatedHoldingCost",
            data_type=DataType.DOUBLE,
            explanation="The holding cost charged to the amount of production estimated inventory. This is calculated as the sum of Production Estimated Holding Costs across all products for the Facility as reported in the Optimization Inventory Summary table.",
            precision_category=["Cost"],
            in_database=True
        ),
        Column(
            column_name="TotalStorageCost",
            data_type=DataType.DOUBLE,
            explanation="The cost of storage for the Product at the Facility. This is calculated as the sum of Storage Costs across all products for the Facility as reported in the Optimization Inventory Summary table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalInTransitHoldingCost",
            data_type=DataType.DOUBLE,
            explanation="The holding cost charged to the amount of In-Transit Inventory that has been assigned to the Facility. This is calculated as the sum of In Transit Holding Costs across all products that are assigned to the Facility as reported in the Optimization Flow Summary table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalProductionCost",
            data_type=DataType.DOUBLE,
            explanation="The cost associated with production at the Facility. This is calculated as the sum of Production Cost across all products as reported in the Optimization Production Summary table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalProcessCost",
            data_type=DataType.DOUBLE,
            explanation="The cost associated with processes at the Facility. This is calculated as the sum of Process Unit Costs and Process Fixed costs for all processes used at the Facility as reported in the Optimization Process Summary table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalStockingCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost associated with stocking cost at the Facility. This is taken as the total Stocking Cost from the Optimization Warehousing Summary table.",
            precision_category=["Cost"],
            in_database=True
        ),
        Column(
            column_name="TotalDestockingCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost associated with destocking cost at the Facility. This is taken as the total Destocking Cost from the Optimization Warehousing Summary table.",
            precision_category=["Cost"],
            in_database=True
        ),
        Column(
            column_name="TotalInboundQuantity",
            data_type=DataType.DOUBLE,
            explanation="The quantity of inbound flow across all products into the Facility.",
            precision_category=["Quantity"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalOutboundQuantity",
            data_type=DataType.DOUBLE,
            explanation="The quantity of outbound flow across all products out of the Facility.",
            precision_category=["Quantity"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalInventoryQuantity",
            data_type=DataType.DOUBLE,
            explanation="The quantity of inventory at the Facility. This is reported as the sum of Average Prebuild Inventory Quantity, Average Turn Estimated Inventory Quantity, Average Transportation Estimated Inventory Quantity and Average Production Estimated Inventory Quantity across all products as reported in the Optimization Inventory Summary table.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalProductionQuantity",
            data_type=DataType.DOUBLE,
            explanation="The quantity of production across all products at the Facility.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="QuantityUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that quantity is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalInboundVolume",
            data_type=DataType.DOUBLE,
            explanation="The volume of inbound flow across all products into the Facility.",
            precision_category=["Volume"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalOutboundVolume",
            data_type=DataType.DOUBLE,
            explanation="The volume of outbound flow across all products out of the Facility.",
            precision_category=["Volume"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalInventoryVolume",
            data_type=DataType.STRING,
            explanation="The volume of inventory at the Facility. This is reported as the sum of Average Prebuild Inventory Volume, Average Turn Estimated Inventory Volume, Average Transportation Estimated Inventory Volume and Average Production Estimated Inventory Volume across all products as reported in the Optimization Inventory Summary table.",
            precision_category=["Volume"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalProductionVolume",
            data_type=DataType.DOUBLE,
            explanation="The volume of production across all products at the Facility.",
            precision_category=["Volume"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VolumeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that volume is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalInboundWeight",
            data_type=DataType.DOUBLE,
            explanation="The weight of inbound flow across all products into the Facility.",
            precision_category=["Weight"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalOutboundWeight",
            data_type=DataType.DOUBLE,
            explanation="The weight of outbound flow across all products out of the Facility.",
            precision_category=["Weight"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalInventoryWeight",
            data_type=DataType.DOUBLE,
            explanation="The weight of inventory at the Facility. This is reported as the sum of Average Prebuild Inventory Weight, Average Turn Estimated Inventory Weight, Average Transportation Estimated Inventory Weight and Average Production Estimated Inventory Weight across all products as reported in the Optimization Inventory Summary table.",
            precision_category=["Weight"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalProductionWeight",
            data_type=DataType.DOUBLE,
            explanation="The weight of production across all products at the Facility.",
            precision_category=["Weight"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WeightUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that weight is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ThroughputCapacity",
            data_type=DataType.DOUBLE,
            explanation="The throughput capacity for the Facility. This is specified in the Throughput Capacity field of the Facilities table.",
            precision_category=["Quantity"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ThroughputCapacityUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the throughput capacity is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ThroughputUtilization",
            data_type=DataType.DOUBLE,
            explanation="The throughput utilization of the Facility for this period. Utilization is calculated as the Throughput divided by the Throughput Capacity.",
            precision_category=["Percentage"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StorageCapacity",
            data_type=DataType.DOUBLE,
            explanation="The storage capacity for this Facility. This is specified in the Storage Capacity field of the Facilities table and is measured as Max Turns Estimated Inventory + Ending Prebuild Inventory.",
            precision_category=["Quantity"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StorageCapacityUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the storage capacity is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StorageUtilization",
            data_type=DataType.DOUBLE,
            explanation="The storage utilization of the Facility for this period. Utilization is calculated as the Total Inventory/Storage Capacity. This is meant to capture average utilization during the period.",
            precision_category=["Percentage"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityRiskScore",
            data_type=DataType.DOUBLE,
            explanation="The risk score associated with this Facility. This is based on a weighted average of the Concentration Risk, Source Count Risk, Utilization Risk, Geographic Risk and the User Defined Risk of the Facility.",
            precision_category=["Risk"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConcentrationRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated the with the throughput concentration of the Facility location. This is calculated based on the throughput quantity of the facility relative to the total demanded quantity across all products for the period.",
            precision_category=["Risk"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SourceCountRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with the number of sources that the Facility uses across all products.",
            precision_category=["Risk"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UtilizationRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with how close to capacity the Facility is during the model solve. This is calculated as the weighted average of Storage Utilization Risk, Throughput Utilization Risk, and the Work Center Utilization Risk. Additional details can be found in the Optimization Utilization Risk Metrics table.",
            precision_category=["Risk"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="GeographicRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with the geographic location of the Facility. This is a weighted average of several geographic components that are reported in greater detail in the Optimization Geographic Risk Metrics table.",
            precision_category=["Risk"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UserDefinedRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with the User Defined Risk value entered in the Facilities table.",
            precision_category=["Risk"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalCO2Emissions",
            data_type=DataType.DOUBLE,
            explanation="The total CO2 emissions at this facility.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalCO2Cost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to CO2 Emissions at this facility.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FixedCO2Emissions",
            data_type=DataType.DOUBLE,
            explanation="The fixed CO2 emissions at this Facility. This is specified in the FixedCO2 emissions column of the Facilities table.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FixedCO2Cost",
            data_type=DataType.DOUBLE,
            explanation="The cost attributed to Fixed CO2 Emissions at this facility.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalProductionCO2Emissions",
            data_type=DataType.DOUBLE,
            explanation="The total CO2 emissions attributed to production at this facility.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalProductionCO2Cost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to CO2 emissions of production at this facility.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Latitude",
            data_type=DataType.DOUBLE,
            explanation="The latitude of the Facility.",
            precision_category=["GeoCoordinate"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Longitude",
            data_type=DataType.DOUBLE,
            explanation="The longitude of the Facility.",
            precision_category=["GeoCoordinate"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
