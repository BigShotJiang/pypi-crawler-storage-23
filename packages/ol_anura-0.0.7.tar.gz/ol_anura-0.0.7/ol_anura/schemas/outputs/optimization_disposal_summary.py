"""OptimizationDisposalSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# OptimizationDisposalSummary table schema
optimization_disposal_summary = Table(
    table_name="OptimizationDisposalSummary",
    abbreviated_name="OptDisposalSmry",
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            master_column=["Scenarios.ScenarioName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Periods"],
            explanation="The time period that the results are reported for.",
            precision_category=["NaN"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities"],
            explanation="The name of the Facility.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Facilities.FacilityName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Products"],
            explanation="The name of the product.",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DisposedProductQuantity",
            data_type=DataType.DOUBLE,
            explanation="The quantity of product disposed once its shelf life has expired. Shelf life is specified in Products.ShelfLife.",
            precision_category=["Quantity"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DisposedProductVolume",
            data_type=DataType.DOUBLE,
            explanation="The volume of product disposed once its shelf life has expired. Shelf life is specified in Products.ShelfLife.",
            precision_category=["Volume"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DisposedProductWeight",
            data_type=DataType.DOUBLE,
            explanation="The weight of product disposed once its shelf life has expired. Shelf life is specified in Products.ShelfLife.",
            precision_category=["Weight"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DisposalCost",
            data_type=DataType.DOUBLE,
            explanation="The cost incurred for disposing a product once its shelf life has expired. Disposal cost is specified in Products.DisposalCost",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
