"""OptimizationSupplierRiskMetrics table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# OptimizationSupplierRiskMetrics table schema
optimization_supplier_risk_metrics = Table(
    table_name="OptimizationSupplierRiskMetrics",
    neo=TechnologySupport.FULLY_SUPPORTED,
    dart=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OptSupplierRisk",
    basic_mode_neo=True,
    basic_mode_dart=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["NEO", "DART"],
            master_column=["Scenarios.ScenarioName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RiskRatingName",
            data_type=DataType.STRING,
            pk=True,
            explanation="The Risk Rating that risk metrics are reported for.",
            precision_category=["NaN"],
            basic_mode=["DART"],
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SupplierName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Suppliers"],
            explanation="The name of the Supplier.",
            precision_category=["NaN"],
            basic_mode=["NEO", "DART"],
            master_column=["Suppliers.SupplierName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SupplierRiskScore",
            data_type=DataType.DOUBLE,
            explanation="The risk score associated with this Supplier. This is based on a weighted average of the Supplier's Concentration Risk, Utilization Risk, Geographic Risk and User Defined Risk across the entire model horizon.",
            precision_category=["Risk"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConcentrationRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated the with the throughput concentration at the Supplier location. This is reported as a weighted average based off of the Concentration Risk in the Optimization Supplier Summary table.",
            precision_category=["Risk"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UtilizationRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with how close to capacity the Supplier is during the model solve.",
            precision_category=["Risk"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="GeographicRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with the geographic location of the Supplier. This is a weighted average of several geographic components that are reported in greater detail in the Optimization Geographic Risk Metrics table.",
            precision_category=["Risk"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UserDefinedRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with the User Defined Risk value entered in the Suppliers table.",
            precision_category=["Risk"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Latitude",
            data_type=DataType.DOUBLE,
            explanation="The latitude of the Supplier.",
            precision_category=["GeoCoordinate"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Longitude",
            data_type=DataType.DOUBLE,
            explanation="The longitude of the Supplier.",
            precision_category=["GeoCoordinate"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
