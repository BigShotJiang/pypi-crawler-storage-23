"""TransportationAssetSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# TransportationAssetSummary table schema
transportation_asset_summary = Table(
    table_name="TransportationAssetSummary",
    hopper=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="TransportationAssetSmry",
    basic_mode_hopper=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["Scenarios.ScenarioName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TransportationAssetName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["TransportationAssets"],
            explanation="The name of the transportation asset.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["TransportationAssets.AssetName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OriginName",
            data_type=DataType.STRING,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The name of the domicile for the transportation asset.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="NumberUsed",
            data_type=DataType.INTEGER,
            explanation="The number of transportation assets of this type used in the solution.",
            precision_category=["Quantity"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost across all routes using this transportation asset type.",
            precision_category=["Cost"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalRouteFixedCost",
            data_type=DataType.DOUBLE,
            explanation="The total route fixed cost across all routes using this transportation asset type. This is specified in the Fixed Cost Per Route field of the Transportation Rates table.",
            precision_category=["Cost"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalFixedCost",
            data_type=DataType.DOUBLE,
            explanation="The total fixed cost across all routes using this transportation asset type. This is specified in the Fixed Cost field of the Transportation Assets table",
            precision_category=["Cost"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalDistanceCost",
            data_type=DataType.DOUBLE,
            explanation="The total distance cost across all routes using this transportation asset type.",
            precision_category=["Cost"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalRepositionDistanceCost",
            data_type=DataType.DOUBLE,
            explanation="The total reposition distance cost across all routes using this transportation asset type.",
            precision_category=["Cost"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalOutOfRouteDistanceCost",
            data_type=DataType.DOUBLE,
            explanation="The total out of route distance cost across all routes using this transportation asset type.",
            precision_category=["Cost"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalTimeCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to time across all routes using this transportation asset type.",
            precision_category=["Cost"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalWaitTimeCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to wait time across all routes using this transportation asset type.",
            precision_category=["Cost"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalRestTimeCost",
            data_type=DataType.DOUBLE,
            explanation="The rest time cost across all routes using this transportation asset type.",
            precision_category=["Cost"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalBreakTimeCost",
            data_type=DataType.DOUBLE,
            explanation="The short break time cost across all routes using this transportation asset type.",
            precision_category=["Cost"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalDutyTimeCost",
            data_type=DataType.DOUBLE,
            explanation="The duty time cost across all routes using this transportation asset type. This is the additive cost for duty time specified in the Duty Time Cost field of the Transportation Rates table.",
            precision_category=["Cost"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalStopCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to the number of stops across all routes using this transportation asset type.",
            precision_category=["Cost"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalUnitCost",
            data_type=DataType.DOUBLE,
            explanation="The total unit cost across all routes using this transportation asset type.",
            precision_category=["Cost"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalDistance",
            data_type=DataType.DOUBLE,
            explanation="The total route distance across all routes using this transportation asset type.",
            precision_category=["Distance"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalRepositionDistance",
            data_type=DataType.DOUBLE,
            explanation="The total reposition distance across all routes using this transportation asset type.",
            precision_category=["Cost"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalOutOfRouteDistance",
            data_type=DataType.DOUBLE,
            explanation="The total out of route distance across all routes using this transportation asset type.",
            precision_category=["Cost"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DistanceUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure used for distance.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalTime",
            data_type=DataType.DOUBLE,
            explanation="The total route time across all routes using this transportation asset type.",
            precision_category=["Distance"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalTravelTime",
            data_type=DataType.DOUBLE,
            explanation="The total travel time across all routes using this transportation asset type.",
            precision_category=["Distance"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalServiceTime",
            data_type=DataType.DOUBLE,
            explanation="The total service time across all routes using this transportation asset type.",
            precision_category=["Distance"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalAdminTime",
            data_type=DataType.DOUBLE,
            explanation="The total admin time across all routes using this transportation asset type.",
            precision_category=["Time"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalWaitTime",
            data_type=DataType.DOUBLE,
            explanation="The total wait time across all routes using this transportation asset type.",
            precision_category=["Distance"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalRestTime",
            data_type=DataType.DOUBLE,
            explanation="The total time spent in a rest across all routes using this transportation asset type.",
            precision_category=["Time"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalBreakTime",
            data_type=DataType.DOUBLE,
            explanation="The total time spent in a short break across all routes using this transportation asset type.",
            precision_category=["Time"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TimeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure used for time.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalDeliveredQuantity",
            data_type=DataType.DOUBLE,
            explanation="The total quantity of product that was served across all routes using this transportation asset type.",
            precision_category=["Quantity"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="QuantityUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the quantities are expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalDeliveredVolume",
            data_type=DataType.DOUBLE,
            explanation="The total volume of product that was served across all routes using this transportation asset type.",
            precision_category=["Volume"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VolumeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the volumes are expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalDeliveredWeight",
            data_type=DataType.DOUBLE,
            explanation="The total weight of product that was served across all routes using this transportation asset type.",
            precision_category=["Weight"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WeightUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the weights are expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="NumberOfDeliveredShipments",
            data_type=DataType.INTEGER,
            explanation="The total number of shipments delivered by this asset.",
            precision_category=["Quantity"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalCO2Emissions",
            data_type=DataType.DOUBLE,
            explanation="The total CO2 emissions from all uses of this asset. This is taken as the total of Route CO2 Emissions for routes that this asset was assigned to.",
            precision_category=["Quantity"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalCO2Cost",
            data_type=DataType.DOUBLE,
            explanation="The cost attributed to CO2 Emissions for this asset.",
            precision_category=["Cost"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalFuelSurchargeCost",
            data_type=DataType.DOUBLE,
            explanation="The total fuel surcharge cost across all routes using this transportation asset type.",
            precision_category=["Cost"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TerritoryName",
            data_type=DataType.STRING,
            explanation="A unique identifier for the territory the asset is assigned to.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TerritoryType",
            data_type=DataType.STRING,
            explanation="The type of the territory the asset is assigned to.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
