"""OptimizationFacilityCostToServeSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table

# OptimizationFacilityCostToServeSummary table schema
optimization_facility_cost_to_serve_summary = Table(
    table_name="OptimizationFacilityCostToServeSummary",
    abbreviated_name="OptFacilityCostToServeSmry",
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            master_column=["Scenarios.ScenarioName"],
            in_database=True
        ),
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Periods"],
            explanation="The time period that the results are reported for.",
            precision_category=["NaN"],
            master_column=["Periods.PeriodName"],
            in_database=True
        ),
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities"],
            explanation="The Facility location that Cost To Serve information is being reported for.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName"],
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Products"],
            explanation="The Product that Cost To Serve information is being reported for.",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            in_database=True
        ),
        Column(
            column_name="ActivityType",
            data_type=DataType.STRING,
            pk=True,
            explanation="The type of activity that is captured at the listed Facility / Product combination.",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="Cost",
            data_type=DataType.DOUBLE,
            explanation="The landed cost for the listed Product to reach the Facility. This is the total cost of all previous activities but does not include the cost of the current activity",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="Quantity",
            data_type=DataType.DOUBLE,
            explanation="The amount of the listed Product that is treated as inbound flow to the node.",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="PerUnitCost",
            data_type=DataType.DOUBLE,
            explanation="The per unit landed cost for the listed Product to reach the Facility. This is the total per-unit cost of all previous activities but does not include the cost of the current activity.",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="PerUnitTransportationCost",
            data_type=DataType.DOUBLE,
            explanation="The per unit landed transportation cost for the listed Product to reach the Facility. This is the total per-unit cost of all previous activities but does not include the cost of the current activity.",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="PerUnitShipmentCost",
            data_type=DataType.DOUBLE,
            explanation="The per unit landed shipment cost for the listed Product to reach the Facility. This is the total per-unit cost of all previous activities but does not include the cost of the current activity.",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="PerUnitInTransitHoldingCost",
            data_type=DataType.DOUBLE,
            explanation="The per unit landed in transit holding cost for the listed Product to reach the Facility. This is the total in-holding cost of all previous activities but does not include the cost of the current activity.",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="PerUnitMultiStopRouteCost",
            data_type=DataType.DOUBLE,
            explanation="The per unit landed multi stop route cost for the listed Product to reach the Facility. This is the total per-unit cost of all previous activities but does not include the cost of the current activity.",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="PerUnitDutyCost",
            data_type=DataType.DOUBLE,
            explanation="The per unit landed duty cost for the listed Product to reach the Facility. This is the total per-unit cost of all previous activities but does not include the cost of the current activity.",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="PerUnitProductionCost",
            data_type=DataType.DOUBLE,
            explanation="The per unit landed production cost for the listed Product to reach the Facility. This is the total per-unit cost of all previous activities but does not include the cost of the current activity.",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="PerUnitPrebuildHoldingCost",
            data_type=DataType.DOUBLE,
            explanation="The per unit landed prebuild holding cost for the listed Product to reach the Facility. This is the total prebuild-holding cost of all previous activities but does not include the cost of the current activity.",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="PerUnitTurnEstimatedHoldingCost",
            data_type=DataType.DOUBLE,
            explanation="The per unit landed turn estimated holding cost for the listed Product to reach the Facility. This is the total turn-holding cost of all previous activities but does not include the cost of the current activity.",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="PerUnitStorageCost",
            data_type=DataType.DOUBLE,
            explanation="The per unit landed storage cost for the listed Product to reach the Facility. This is the total per-unit cost of all previous activities but does not include the cost of the current activity.",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="PerUnitSourcingCost",
            data_type=DataType.DOUBLE,
            explanation="The per unit landed sourcing cost for the listed Product to reach the Facility. This is the total per-unit cost of all previous activities but does not include the cost of the current activity.",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="PerUnitFacilityFixedOperatingCost",
            data_type=DataType.DOUBLE,
            explanation="The per unit landed facility fixed operating cost for the listed Product to reach the Facility. This is the total facility-operating cost of all previous activities but does not include the cost of the current activity.",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="PerUnitFacilityFixedStartupCost",
            data_type=DataType.DOUBLE,
            explanation="The per unit landed facility fixed startup cost for the listed Product to reach the Facility. This is the total facility-startup cost of all previous activities but does not include the cost of the current activity.",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="PerUnitFacilityFixedClosingCost",
            data_type=DataType.DOUBLE,
            explanation="The per unit landed facility fixed closing cost for the listed Product to reach the Facility. This is the total facility-closing cost of all previous activities but does not include the cost of the current activity.",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="PerUnitWorkCenterFixedOperatingCost",
            data_type=DataType.DOUBLE,
            explanation="The per unit landed workcenter fixed operating cost for the listed Product to reach the Facility. This is the total facility-closing cost of all previous activities but does not include the cost of the current activity.",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="PerUnitWorkCenterFixedStartupCost",
            data_type=DataType.DOUBLE,
            explanation="The per unit landed workcenter fixed startup cost for the listed Product to reach the Facility. This is the total facility-closing cost of all previous activities but does not include the cost of the current activity.",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="PerUnitWorkCenterFixedClosingCost",
            data_type=DataType.DOUBLE,
            explanation="The per unit landed workcenter fixed closing cost for the listed Product to reach the Facility. This is the total facility-closing cost of all previous activities but does not include the cost of the current activity.",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="PerUnitSupplyCost",
            data_type=DataType.DOUBLE,
            explanation="The Supply Cost associated with the path. This is the total inbound-handling cost of all previous activities but does not include the cost of the current activity.",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="PerUnitInboundHandlingCost",
            data_type=DataType.DOUBLE,
            explanation="The inbound handling landed cost for the listed Product to reach the Facility. This is the total inbound-handling cost of all previous activities but does not include the cost of the current activity.",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="PerUnitOutboundHandlingCost",
            data_type=DataType.DOUBLE,
            explanation="The outbound handling landed cost for the listed Product to reach the Facility. This is the total outbound-handling cost of all previous activities but does not include the cost of the current activity.",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="PerUnitProcessCost",
            data_type=DataType.DOUBLE,
            explanation="The per unit landed process cost for the listed Product to reach the Facility. This is the total per-unit cost of all previous activities but does not include the cost of the current activity.",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="PerUnitProcessFixedCost",
            data_type=DataType.DOUBLE,
            explanation="The per unit landed fixed Process Cost associated with serving the Product to reach the Facility. This is the total per-unit cost of all previous activities but does not include the cost of the current activity.",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="PerUnitUserDefinedCost",
            data_type=DataType.DOUBLE,
            explanation="The per unit landed user defined cost for the listed Product to reach the Facility. This is the total user-defined cost of all previous activities but does not include the cost of the current activity.",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="PerUnitCO2Cost",
            data_type=DataType.DOUBLE,
            explanation="The per unit landed cost of CO2 emissions for the listed Product to reach the Facility. This is the total CO2 cost of all previous activities but does not include the cost of the current activity.",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="PerUnitReturnCost",
            data_type=DataType.DOUBLE,
            explanation="The per unit cost associated with returns to serve the product / site combination.",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="Latitude",
            data_type=DataType.DOUBLE,
            explanation="The latitude of the Facility.",
            precision_category=["GeoCoordinate"],
            in_database=True
        ),
        Column(
            column_name="Longitude",
            data_type=DataType.DOUBLE,
            explanation="The longitude of the Facility.",
            precision_category=["GeoCoordinate"],
            in_database=True
        ),
    ]
)
