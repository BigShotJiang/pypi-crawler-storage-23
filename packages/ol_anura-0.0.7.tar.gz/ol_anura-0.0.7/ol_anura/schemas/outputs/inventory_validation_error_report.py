"""InventoryValidationErrorReport table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# InventoryValidationErrorReport table schema
inventory_validation_error_report = Table(
    table_name="InventoryValidationErrorReport",
    cyclo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="InventoryValidationErrorReport",
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TableName",
            data_type=DataType.STRING,
            pk=True,
            explanation="The name of the table where the error has identified.",
            precision_category=["NaN"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ColumnName",
            data_type=DataType.STRING,
            pk=True,
            explanation="The name of the column where the error has been identified.",
            precision_category=["NaN"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ValidationRule",
            data_type=DataType.STRING,
            explanation="The name of the internal validation rule that the optimization engine found a problem in.",
            precision_category=["NaN"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ErrorType",
            data_type=DataType.STRING,
            pk=True,
            explanation="The listed type of error associated with the validation rule.",
            precision_category=["NaN"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ErrorMessage",
            data_type=DataType.STRING,
            explanation="A description of the reported error.",
            precision_category=["NaN"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Severity",
            data_type=DataType.STRING,
            explanation="The severity value of the identified error, this will be 0 to 3 with 3 being the most severe.\n\n0 - Informational Errors\n\n1 - Minor Errors\n\n2 - Moderate Errors\n\n3- Critical - Infeasible or Failed Model",
            precision_category=["NaN"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="IdentifiedValue",
            data_type=DataType.STRING,
            explanation="The value that has been identified as the source of the error",
            precision_category=["NaN"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Action",
            data_type=DataType.STRING,
            explanation="If corrective action was taken, the data adjustment performed by the solver will be listed here.",
            precision_category=["NaN"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ValueReplaced",
            data_type=DataType.STRING,
            explanation="If a value had to be replaced, the updated value will be listed here.",
            precision_category=["NaN"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Count",
            data_type=DataType.INTEGER,
            explanation="The number of times that the error occurred.",
            precision_category=["Integer"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
