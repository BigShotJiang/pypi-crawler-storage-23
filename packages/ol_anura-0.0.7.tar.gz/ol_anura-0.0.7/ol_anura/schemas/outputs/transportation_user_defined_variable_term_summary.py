"""TransportationUserDefinedVariableTermSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# TransportationUserDefinedVariableTermSummary table schema
transportation_user_defined_variable_term_summary = Table(
    table_name="TransportationUserDefinedVariableTermSummary",
    hopper=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="TransportUDVTermSmry",
    basic_mode_hopper=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["Scenarios.ScenarioName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VariableName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["UserDefinedVariables", "TransportationUserDefinedVariables"],
            explanation="The name of the User Defined Variable.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["UserDefinedVariables.VariableName", "TransportationUserDefinedVariables.VariableName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TermName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["UserDefinedVariables", "TransportationUserDefinedVariables"],
            explanation="The name of the Term in the specified User Defined Variable.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["UserDefinedVariables.TermName", "TransportationUserDefinedVariables.TermName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TermValue",
            data_type=DataType.DOUBLE,
            explanation="The value of the Term in the specified User Defined Variable.",
            precision_category=["Quantity"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ScaledTermValue",
            data_type=DataType.DOUBLE,
            explanation="The value of the Term in the specified User Defined Variable multiplied by Coefficient.",
            precision_category=["Quantity"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
