"""OptimizationUserDefinedVariableTermSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# OptimizationUserDefinedVariableTermSummary table schema
optimization_user_defined_variable_term_summary = Table(
    table_name="OptimizationUserDefinedVariableTermSummary",
    neo=TechnologySupport.FULLY_SUPPORTED,
    dart=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OptUserDefinedVariableTermSmry",
    basic_mode_neo=True,
    basic_mode_dart=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Scenarios.ScenarioName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VariableName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["UserDefinedVariables", "TransportationUserDefinedVariables"],
            explanation="The name of the User Defined Variable.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UserDefinedVariables.VariableName", "TransportationUserDefinedVariables.VariableName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TermName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["UserDefinedVariables", "TransportationUserDefinedVariables"],
            explanation="The name of the Term in the specified User Defined Variable.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UserDefinedVariables.TermName", "TransportationUserDefinedVariables.TermName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TermValue",
            data_type=DataType.DOUBLE,
            explanation="The value of the Term in the specified User Defined Variable.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ScaledTermValue",
            data_type=DataType.DOUBLE,
            explanation="The value of the Term in the specified User Defined Variable multiplied by Coefficient.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
