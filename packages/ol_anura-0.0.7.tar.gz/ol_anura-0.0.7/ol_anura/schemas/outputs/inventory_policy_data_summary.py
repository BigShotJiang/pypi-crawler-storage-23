"""InventoryPolicyDataSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# InventoryPolicyDataSummary table schema
inventory_policy_data_summary = Table(
    table_name="InventoryPolicyDataSummary",
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="InventoryPolicyDataSummary",
    basic_mode_throg=True,
    basic_mode_dendro=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["Scenarios.ScenarioName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities"],
            explanation="The name of the Facility.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["Facilities.FacilityName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Products"],
            explanation="The name of the Product.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["Products.ProductName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AverageDemand",
            data_type=DataType.DOUBLE,
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StandardDeviationDemand",
            data_type=DataType.DOUBLE,
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AverageLeadTime",
            data_type=DataType.DOUBLE,
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StandardDeviationLeadTime",
            data_type=DataType.DOUBLE,
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DemandPoints",
            data_type=DataType.INTEGER,
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SuggestedPolicy",
            data_type=DataType.STRING,
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PolicyValue1",
            data_type=DataType.DOUBLE,
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PolicyValue2",
            data_type=DataType.DOUBLE,
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SafetyStock",
            data_type=DataType.DOUBLE,
            basic_mode=["THROG", "DENDRO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
