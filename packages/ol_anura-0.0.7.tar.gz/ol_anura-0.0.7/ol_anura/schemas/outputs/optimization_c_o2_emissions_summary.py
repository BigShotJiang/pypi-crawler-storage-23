"""OptimizationCO2EmissionsSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# OptimizationCO2EmissionsSummary table schema
optimization_c_o2_emissions_summary = Table(
    table_name="OptimizationCO2EmissionsSummary",
    neo=TechnologySupport.FULLY_SUPPORTED,
    dart=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OptCO2EmissionsSmry",
    basic_mode_neo=True,
    basic_mode_dart=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Scenarios.ScenarioName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Periods"],
            explanation="The time period that the results are reported for.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalCO2Emissions",
            data_type=DataType.DOUBLE,
            explanation="The total CO2 emissions across the network for this period.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalCO2Cost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to CO2 Emissions across the network for this period.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalFixedCO2Emissions",
            data_type=DataType.DOUBLE,
            explanation="The total fixed CO2 emissions across the network for this period. This is specified as the total of Fixed CO2 Emissions at all Facilities and Work Centers.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FixedCO2Cost",
            data_type=DataType.DOUBLE,
            explanation="The cost attributed to Fixed CO2 Emissions across the network for this period.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalTransportationCO2Emissions",
            data_type=DataType.DOUBLE,
            explanation="The total CO2 emissions attributed to transport across the network for this period. This is taken as the total CO2 Emissions from the Optimization Flow Summary table.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalTransportationCO2Cost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to CO2 emissions of transport across the network for this period.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalProductionCO2Emissions",
            data_type=DataType.DOUBLE,
            explanation="The total CO2 emissions attributed to production across the network for this period. This is taken as the total CO2 Emissions from the Optimization Production Summary table.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalProductionCO2Cost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to CO2 emissions of production at this Work Center.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalSupplyCO2Emissions",
            data_type=DataType.DOUBLE,
            explanation="The total CO2 emissions attributed to supply across the network for this period. This is taken as the total CO2 Emissions from the Optimization Supply Summary table.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalSupplyCO2Cost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to CO2 emissions of supply across the network for this period.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
