"""InventoryNetworkSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# InventoryNetworkSummary table schema
inventory_network_summary = Table(
    table_name="InventoryNetworkSummary",
    cyclo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="InventoryNetworkSummary",
    basic_mode_cyclo=True,
    in_database=True,
    fields=[
        Column(
            column_name="ModelName",
            data_type=DataType.STRING,
            pk=True,
            explanation="The name of the model.",
            precision_category=["NaN"],
            basic_mode=["CYCLO"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["CYCLO"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ServiceType",
            data_type=DataType.STRING,
            explanation="The type of service level used in the CYCLO run.",
            precision_category=["NaN"],
            basic_mode=["CYCLO"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TargetServiceLevel",
            data_type=DataType.DOUBLE,
            explanation="The target service level to be met during the CYCLO run.",
            precision_category=["Percentage"],
            basic_mode=["CYCLO"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=DataType.STRING,
            explanation="The status of the CYCLO solve.",
            precision_category=["NaN"],
            basic_mode=["CYCLO"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost of the CYCLO solution.",
            precision_category=["Cost"],
            basic_mode=["CYCLO"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Gap",
            data_type=DataType.DOUBLE,
            explanation="The optimality gap of the CYCLO solution.",
            precision_category=["Percentage"],
            basic_mode=["CYCLO"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SolveTime",
            data_type=DataType.DOUBLE,
            explanation="The time taken to solve the CYCLO problem.",
            precision_category=["Time"],
            basic_mode=["CYCLO"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="NumStages",
            data_type=DataType.INTEGER,
            explanation="The number of stages in the multi-echelon inventory network.",
            precision_category=["Integer"],
            basic_mode=["CYCLO"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
