"""TransportationSegmentSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# TransportationSegmentSummary table schema
transportation_segment_summary = Table(
    table_name="TransportationSegmentSummary",
    hopper=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="TransportationSegmentSmry",
    basic_mode_hopper=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["Scenarios.ScenarioName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentID",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="A unique identifier for the segment",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OriginName",
            data_type=DataType.STRING,
            required=True,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The location of the origin of the segment.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DestinationName",
            data_type=DataType.STRING,
            required=True,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The location of the destination of the segment.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteName",
            data_type=DataType.STRING,
            explanation="The route that contains the segment.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteType",
            data_type=DataType.STRING,
            explanation="The type of the route: Outbound, Inbound, Backhaul, Interleaved, Template or Reposition",
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TourID",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="A unique identifier for the tour (asset schedule) that the Route is assigned to",
            precision_category=["NaN"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentDistance",
            data_type=DataType.DOUBLE,
            explanation="The distance of the segment.",
            precision_category=["Distance"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentDistanceUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure used for distance.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DistanceSource",
            data_type=DataType.STRING,
            explanation="The source used for this segment distance. Can be Transit Matrix or Hopper",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentTime",
            data_type=DataType.DOUBLE,
            explanation="The total time for the segment. This will include Travel, Rest and Break time.",
            precision_category=["Distance"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentTravelTime",
            data_type=DataType.DOUBLE,
            explanation="The travel time for the segment.",
            precision_category=["Distance"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentRestTime",
            data_type=DataType.DOUBLE,
            explanation="The total time spent in a rest on this segment.",
            precision_category=["Time"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SegmentBreakTime",
            data_type=DataType.DOUBLE,
            explanation="The total time spent in a short break on this segment.",
            precision_category=["Time"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TimeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure used for time.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OriginLatitude",
            data_type=DataType.DOUBLE,
            validation_type="LatitudeValue",
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The latitude coordinate of the origin of the segment",
            precision_category=["GeoCoordinate"],
            basic_mode=["HOPPER"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OriginLongitude",
            data_type=DataType.DOUBLE,
            validation_type="LongitudeValue",
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The longitude coordinate of the origin of the segment",
            precision_category=["GeoCoordinate"],
            basic_mode=["HOPPER"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DestinationLatitude",
            data_type=DataType.DOUBLE,
            validation_type="LatitudeValue",
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The latitude coordinate of the destination of the segment",
            precision_category=["GeoCoordinate"],
            basic_mode=["HOPPER"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DestinationLongitude",
            data_type=DataType.DOUBLE,
            validation_type="LongitudeValue",
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The longitude coordinate of the destination of the segment",
            precision_category=["GeoCoordinate"],
            basic_mode=["HOPPER"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StartDate",
            data_type=DataType.DATETIME,
            explanation="The date and time at which the Asset departs from the origin of the Segment.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="EndDate",
            data_type=DataType.DATETIME,
            explanation="The date and time at which the Asset arrives at the destination of the Segment.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CO2Emissions",
            data_type=DataType.DOUBLE,
            explanation="The CO2 emissions from this segment.",
            precision_category=["Quantity"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CO2Cost",
            data_type=DataType.DOUBLE,
            explanation="The cost attributed to CO2 Emissions for this segment.",
            precision_category=["Cost"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TerritoryName",
            data_type=DataType.STRING,
            explanation="A unique identifier for the territory the segment is assigned to.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TerritoryType",
            data_type=DataType.STRING,
            explanation="The type of the territory the segment is assigned to.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
