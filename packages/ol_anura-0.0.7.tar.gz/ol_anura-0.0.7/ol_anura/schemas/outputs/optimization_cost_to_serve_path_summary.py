"""OptimizationCostToServePathSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# OptimizationCostToServePathSummary table schema
optimization_cost_to_serve_path_summary = Table(
    table_name="OptimizationCostToServePathSummary",
    neo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OptCostToServePathSmry",
    basic_mode_neo=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            master_column=["Scenarios.ScenarioName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathId",
            data_type=DataType.STRING,
            pk=True,
            explanation="The unique identifier for the path.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathOrigin",
            data_type=DataType.STRING,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The origin of the path.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathDestination",
            data_type=DataType.STRING,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The destination of the path.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathDemandQuantity",
            data_type=DataType.DOUBLE,
            explanation="The demand quantity for the path.",
            precision_category=["Quantity"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathProductName",
            data_type=DataType.STRING,
            master_table=["Products"],
            explanation="The product name associated with the path.",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost of the path.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathRevenue",
            data_type=DataType.DOUBLE,
            explanation="The total revenue for the path.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathTransportationCost",
            data_type=DataType.DOUBLE,
            explanation="The transportation cost associated with the path.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathShipmentCost",
            data_type=DataType.DOUBLE,
            explanation="The shipment cost associated with the path.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathFuelSurchargeCost",
            data_type=DataType.DOUBLE,
            explanation="The fuel surcharge cost associated with the path.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathUnitMultiStopRouteCost",
            data_type=DataType.DOUBLE,
            explanation="The Multi Stop Route Cost associated with this path.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathDutyCost",
            data_type=DataType.DOUBLE,
            explanation="The duty cost associated with the path.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathTariffCost",
            data_type=DataType.DOUBLE,
            explanation="The tariff cost associated with the path.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathInTransitHoldingCost",
            data_type=DataType.DOUBLE,
            explanation="The in-transit holding cost associated with the path.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathSourcingCost",
            data_type=DataType.DOUBLE,
            explanation="The sourcing cost associated with the path.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathProductionCost",
            data_type=DataType.DOUBLE,
            explanation="The production cost associated with the path.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathProcessCost",
            data_type=DataType.DOUBLE,
            explanation="The unit process cost associated with the path.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathProcessFixedCost",
            data_type=DataType.DOUBLE,
            explanation="The fixed process cost associated with the path.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathSupplyCost",
            data_type=DataType.DOUBLE,
            explanation="The Supply Cost associated with the path.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathInboundHandlingCost",
            data_type=DataType.DOUBLE,
            explanation="The inbound handling cost associated with the path.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathOutboundHandlingCost",
            data_type=DataType.DOUBLE,
            explanation="The outbound handling cost associated with the path.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathPrebuildHoldingCost",
            data_type=DataType.DOUBLE,
            explanation="The prebuild holding cost associated with the path.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathTurnEstimatedHoldingCost",
            data_type=DataType.DOUBLE,
            explanation="The estimated holding cost associated with the path.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathStorageCost",
            data_type=DataType.DOUBLE,
            explanation="The storage cost associated with the path.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathFacilityFixedOperatingCost",
            data_type=DataType.DOUBLE,
            explanation="The fixed operating cost of the facility associated with the path.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathFacilityFixedStartupCost",
            data_type=DataType.DOUBLE,
            explanation="The fixed startup cost of the facility associated with the path.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathFacilityFixedClosingCost",
            data_type=DataType.DOUBLE,
            explanation="The fixed closing cost of the facility associated with the path.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathWorkCenterFixedOperatingCost",
            data_type=DataType.DOUBLE,
            explanation="The fixed operating cost of the work center associated with the path.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathWorkCenterFixedStartupCost",
            data_type=DataType.DOUBLE,
            explanation="The fixed startup cost of the work center associated with the path.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathWorkCenterFixedClosingCost",
            data_type=DataType.DOUBLE,
            explanation="The fixed closing cost of the work center associated with the path.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathUserDefinedCost",
            data_type=DataType.DOUBLE,
            explanation="The user-defined cost associated with the path.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathCO2Cost",
            data_type=DataType.DOUBLE,
            explanation="The cost associated with CO2 emissions for the path.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathReturnCost",
            data_type=DataType.DOUBLE,
            explanation="The cost associated with returns for the path.",
            precision_category=["Cost"],
            in_database=True
        ),
    ]
)
