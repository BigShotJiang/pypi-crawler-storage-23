"""OptimizationTariffSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, PathDestinationProperty, PathOriginProperty, TechnologySupport

# OptimizationTariffSummary table schema
optimization_tariff_summary = Table(
    table_name="OptimizationTariffSummary",
    neo=TechnologySupport.FULLY_SUPPORTED,
    dart=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OptTariffSmry",
    basic_mode_neo=True,
    basic_mode_dart=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Scenarios.ScenarioName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Periods"],
            explanation="The time period that the results are reported for.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathOriginProperty",
            data_type=PathOriginProperty,
            pk=True,
            master_table=["Facilities", "Suppliers", "Customers"],
            default_value="Country",
            notes="Optimization: Only Country and Region are currently supported as an Origin Property.",
            explanation="The property of the Source (Supplier or Facility) that the Tariff cost structure has been created for. ",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathOriginValue",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The value to look up in the Source table (either Facilities or Suppliers) Source Property column.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathDestinationProperty",
            data_type=PathDestinationProperty,
            pk=True,
            master_table=["Facilities", "Suppliers", "Customers"],
            default_value="Country",
            notes="Optimization: Only Country and Region are currently supported as an Destination Property.",
            explanation="The property of the Destination (Customer or Facility) that the Tariff cost structure has been created for.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PathDestinationValue",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The value to look up in the Destination table (either Customers or Facilities) Destination Property column.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            pk=True,
            master_table=["Products"],
            default_value="ALL",
            explanation="The Product that the duty record applies to. If NULL, the duty will be applied to all products in the model.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Products.ProductName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TariffCost",
            data_type=DataType.DOUBLE,
            explanation="The cost attributed to the Tariff/Duty Rate in Tariffs Table",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VariableCost",
            data_type=DataType.DOUBLE,
            explanation="The cost attributed to the Unit Cost in Tariffs Table",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FlowQuantity",
            data_type=DataType.DOUBLE,
            explanation="The demand quantity as specified in the Customer Demand Origin Policies table. Multiple quantities can be defined for a given Customer / Product / Period combination if there are multiple origin location requirements.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
