"""OptimizationFlowSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# OptimizationFlowSummary table schema
optimization_flow_summary = Table(
    table_name="OptimizationFlowSummary",
    neo=TechnologySupport.FULLY_SUPPORTED,
    dart=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OptFlowSmry",
    basic_mode_neo=True,
    basic_mode_dart=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["NEO", "DART"],
            master_column=["Scenarios.ScenarioName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DepartingPeriodName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Periods"],
            explanation="The Period in which the flow left the Origin location.",
            precision_category=["NaN"],
            basic_mode=["NEO", "DART"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ArrivingPeriodName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Periods"],
            explanation="The Period in which the flow arrived at the Destination Location.",
            precision_category=["NaN"],
            basic_mode=["NEO", "DART"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FlowType",
            data_type=DataType.STRING,
            explanation="The type of flow that the record represents. Customer Fulfillment will represent flows from Facilities to Customers, Replenishment will represent flows from Facilities to other Facilities, Procurement will represent flows from Suppliers to Facilities and Drop Ship will represent flows from Suppliers to Customers.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OriginName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The Facility or Supplier or Customer that the flow originated from.",
            precision_category=["NaN"],
            basic_mode=["NEO", "DART"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DestinationName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The Customer or Facility location that the flow arrived to.",
            precision_category=["NaN"],
            basic_mode=["NEO", "DART"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Products"],
            explanation="The Product the flow record is for.",
            precision_category=["NaN"],
            basic_mode=["NEO", "DART"],
            master_column=["Products.ProductName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ModeName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["TransportationModes"],
            explanation="The Transportation Mode used for this flow.",
            precision_category=["NaN"],
            basic_mode=["NEO", "DART"],
            master_column=["TransportationModes.ModeName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FlowQuantity",
            data_type=DataType.DOUBLE,
            explanation="The quantity of the flow units for the listed Origin / Destination / Mode / Period combination.",
            precision_category=["Quantity"],
            basic_mode=["NEO", "DART"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FlowQuantityUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the quantity is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FlowVolume",
            data_type=DataType.DOUBLE,
            explanation="The volume of the flow units for the listed Origin / Destination / Mode / Period combination.",
            precision_category=["Volume"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FlowVolumeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the volume is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FlowWeight",
            data_type=DataType.DOUBLE,
            explanation="The weight of the flow units for the listed Origin / Destination / Mode / Period combination.",
            precision_category=["Weight"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FlowWeightUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the weight is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SourcingCost",
            data_type=DataType.DOUBLE,
            explanation="The sourcing cost associated with this flow record. Sourcing costs will be defined in the Unit Cost field of the Customer Fulfillment, Replenishment or Procurement Policy tables.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReturnCost",
            data_type=DataType.DOUBLE,
            explanation="The cost associated with return flow records. Sourcing costs will be defined in the Unit Cost field of Return Policies table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TransportationCost",
            data_type=DataType.DOUBLE,
            explanation="The transportation cost associated with this flow record. Transportation Costs will be defined by the Unit Cost field of the Transportation Policies or Transportation Modes table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ShipmentCost",
            data_type=DataType.DOUBLE,
            explanation="The proportion of the fixed cost entered in the Transportation Policies that will apply to the product flow. In the case of grouped products, the complete shipment costs are reported in the Optimization Shipment Summary table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MultiStopRouteCost",
            data_type=DataType.DOUBLE,
            explanation="The proportion of multi-stop route attributed to this flow record.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UserDefinedCost",
            data_type=DataType.DOUBLE,
            explanation="The proportion of user defined cost attributed to this flow record.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="DutyCost",
            data_type=DataType.DOUBLE,
            explanation="The duty cost associated with this flow record. Duty Cost will be defined as a percentage of product value in the Duty Rate column of the Transportation Policies table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="InTransitHoldingCost",
            data_type=DataType.DOUBLE,
            explanation="The holding cost associated with the in-transit inventory estimate for this flow record.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="InboundHandlingCost",
            data_type=DataType.DOUBLE,
            explanation="The handling cost associated with inbound flow of the listed product into the Destination facility. This cost is specified in the Warehousing Policies table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OutboundHandlingCost",
            data_type=DataType.DOUBLE,
            explanation="The handling cost associated with outbound flow of the listed product from the Origin facility. This cost is specified in the Warehousing Policies table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FuelSurchargeCost",
            data_type=DataType.DOUBLE,
            explanation="The fuel surcharge cost associated with this flow. This cost is specified in the Transportation Policies table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalCost",
            data_type=DataType.DOUBLE,
            explanation="The total cost for this product flow record. This will be made up of the Transportation Cost, Shipment Cost, Duty Cost and the In-Transit Inventory Cost.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TransportDistance",
            data_type=DataType.DOUBLE,
            explanation="The distance of the flow record. Distance will be determined from the Transport Distance in the Transportation Policies table, or if no distance is entered a default distance calculation will have been used.",
            precision_category=["Distance"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TotalTransportDistance",
            data_type=DataType.DOUBLE,
            explanation="The total distance traveled by all shipments on this flow record. This is calculated as the number of shipments required multiplied by the Transport Distance. Fractional shipments are not rounded up, so if 1.5 shipments are used, the TotalTransportDistance is 1.5 times the TransportDistance. This is consistent with all other prorated flow metrics, including costs.",
            precision_category=["Distance"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TransportDistanceUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the distance is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TransportTime",
            data_type=DataType.DOUBLE,
            explanation="The time taken to move from the Origin to the Destination for the flow record. The time will be determined based on the Transport Time field in the Transportation Policies table, or if no time is entered then a default speed will be used to determine the time based on the flow distance.",
            precision_category=["Time"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TransportTimeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the time is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TransportationEstimatedInventoryQuantity",
            data_type=DataType.DOUBLE,
            explanation="The quantity of estimated inventory attributed to deliveries for the listed Origin / Destination / Mode / Period combination. This is calculated from the Time Between Deliveries column in the Transportation Policies table.",
            precision_category=["Quantity"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TransportationEstimatedInventoryVolume",
            data_type=DataType.DOUBLE,
            explanation="The volume of estimated inventory attributed to deliveries for the listed Origin / Destination / Mode / Period combination. This is calculated from the Time Between Deliveries column in the Transportation Policies table.",
            precision_category=["Quantity"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TransportationEstimatedInventoryWeight",
            data_type=DataType.DOUBLE,
            explanation="The weight of estimated inventory attributed to deliveries for the listed Origin / Destination / Mode / Period combination. This is calculated from the Time Between Deliveries column in the Transportation Policies table.",
            precision_category=["Quantity"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TransportationEstimatedInventoryHoldingCost",
            data_type=DataType.DOUBLE,
            explanation="The holding cost associated with the transportation estimated inventory.",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TransportTimeRisk",
            data_type=DataType.DOUBLE,
            explanation="The Risk metric associated with how long of a transport time the flow has. This will contribute to the model's overall Network Risk score.",
            precision_category=["Risk"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TimeToImportRisk",
            data_type=DataType.DOUBLE,
            explanation="The Risk metric associated with how long it can take imported products to clear customs as they enter the destination country. This contributes to the model's overall Network Risk score.",
            precision_category=["Risk"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TimeToExportRisk",
            data_type=DataType.DOUBLE,
            explanation="The Risk metric associated with how long it can take exported products to clear customs as they leave the origin country. This contributes to the model's overall Network Risk Score.",
            precision_category=["Risk"],
            basic_mode=["NEO", "DART"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CO2Emissions",
            data_type=DataType.DOUBLE,
            explanation="The total CO2 emissions.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CO2Cost",
            data_type=DataType.DOUBLE,
            explanation="The total cost attributed to CO2 Emissions.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OriginLatitude",
            data_type=DataType.DOUBLE,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The origin latitude.",
            precision_category=["GeoCoordinate"],
            basic_mode=["NEO", "DART"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OriginLongitude",
            data_type=DataType.DOUBLE,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The origin longitude.",
            precision_category=["GeoCoordinate"],
            basic_mode=["NEO", "DART"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DestinationLatitude",
            data_type=DataType.DOUBLE,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The destination latitude.",
            precision_category=["GeoCoordinate"],
            basic_mode=["NEO", "DART"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DestinationLongitude",
            data_type=DataType.DOUBLE,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The destination longitude.",
            precision_category=["GeoCoordinate"],
            basic_mode=["NEO", "DART"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
