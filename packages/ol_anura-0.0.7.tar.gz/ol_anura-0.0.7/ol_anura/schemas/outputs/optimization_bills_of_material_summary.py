"""OptimizationBillsOfMaterialSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# OptimizationBillsOfMaterialSummary table schema
optimization_bills_of_material_summary = Table(
    table_name="OptimizationBillsOfMaterialSummary",
    neo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OptBillsOfMaterialSmry",
    basic_mode_neo=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Scenarios.ScenarioName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Periods"],
            explanation="The time period that the results are reported for.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BOMName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["BillsOfMaterials"],
            explanation="The name of the Bill Of Material.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["BillsOfMaterials.BOMName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities"],
            explanation="The name of the Facility where the Bill Of Material was used in production.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Facilities.FacilityName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Products"],
            explanation="The product that is being consumed or created through this Bill of Material.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Products.ProductName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductType",
            data_type=DataType.STRING,
            pk=True,
            explanation="One of either Component, Byproduct or End Product. This field defines what purpose the specified product served in this Bill of Material.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BOMQuantity",
            data_type=DataType.DOUBLE,
            explanation="The quantity of the product that was either consumed or produced through this Bill of Material.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BOMQuantityUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the quantity is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BOMVolume",
            data_type=DataType.DOUBLE,
            explanation="The volume of the product that was either consumed or produced through this Bill of Material.",
            precision_category=["Volume"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BOMVolumeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the volume is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BOMWeight",
            data_type=DataType.DOUBLE,
            explanation="The weight of the product that was either consumed or produced through this Bill of Material.",
            precision_category=["Weight"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BOMWeightUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the weight is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Latitude",
            data_type=DataType.DOUBLE,
            explanation="The latitude of the Facility where the BOM has been consumed.",
            precision_category=["GeoCoordinate"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Longitude",
            data_type=DataType.DOUBLE,
            explanation="The longitude of the Facility where the BOM has been consumed.",
            precision_category=["GeoCoordinate"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
