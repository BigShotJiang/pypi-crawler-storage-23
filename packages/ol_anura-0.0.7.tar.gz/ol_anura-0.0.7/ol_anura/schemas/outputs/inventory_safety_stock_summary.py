"""InventorySafetyStockSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# InventorySafetyStockSummary table schema
inventory_safety_stock_summary = Table(
    table_name="InventorySafetyStockSummary",
    cyclo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="InventorySafetyStockSummary",
    basic_mode_cyclo=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["CYCLO"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            pk=True,
            explanation="The name of the Facility.",
            precision_category=["NaN"],
            basic_mode=["CYCLO"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            pk=True,
            explanation="The name of the Product.",
            precision_category=["NaN"],
            basic_mode=["CYCLO"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StageType",
            data_type=DataType.STRING,
            explanation="The type of stage in the multi-echelon inventory network.",
            precision_category=["NaN"],
            basic_mode=["CYCLO"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProcessingTime",
            data_type=DataType.DOUBLE,
            explanation="The processing time at this stage.",
            precision_category=["Time"],
            basic_mode=["CYCLO"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="IncomingServiceTime",
            data_type=DataType.DOUBLE,
            explanation="The incoming service time at this stage.",
            precision_category=["Time"],
            basic_mode=["CYCLO"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OutgoingServiceTime",
            data_type=DataType.DOUBLE,
            explanation="The outgoing service time at this stage.",
            precision_category=["Time"],
            basic_mode=["CYCLO"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="NetReplenishmentTime",
            data_type=DataType.DOUBLE,
            explanation="The net replenishment time at this stage.",
            precision_category=["Time"],
            basic_mode=["CYCLO"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DemandMean",
            data_type=DataType.DOUBLE,
            explanation="The mean demand at this stage.",
            precision_category=["Quantity"],
            basic_mode=["CYCLO"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DemandStd",
            data_type=DataType.DOUBLE,
            explanation="The standard deviation of demand at this stage.",
            precision_category=["Quantity"],
            basic_mode=["CYCLO"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="HoldingCost",
            data_type=DataType.DOUBLE,
            explanation="The holding cost at this stage.",
            precision_category=["Cost"],
            basic_mode=["CYCLO"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SafetyStock",
            data_type=DataType.DOUBLE,
            explanation="The safety stock quantity at this stage.",
            precision_category=["Quantity"],
            basic_mode=["CYCLO"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="HoldingCostContribution",
            data_type=DataType.DOUBLE,
            explanation="The holding cost contribution of safety stock at this stage.",
            precision_category=["Cost"],
            basic_mode=["CYCLO"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DemandClass",
            data_type=DataType.STRING,
            explanation="The demand classification at this stage.",
            precision_category=["NaN"],
            basic_mode=["CYCLO"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="InventoryPolicy",
            data_type=DataType.STRING,
            explanation="The inventory policy applied at this stage.",
            precision_category=["NaN"],
            basic_mode=["CYCLO"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PolicyValue1",
            data_type=DataType.DOUBLE,
            explanation="The first policy parameter value for the inventory policy.",
            basic_mode=["CYCLO"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PolicyValue2",
            data_type=DataType.DOUBLE,
            explanation="The second policy parameter value for the inventory policy.",
            basic_mode=["CYCLO"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
