"""OptimizationProcessSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# OptimizationProcessSummary table schema
optimization_process_summary = Table(
    table_name="OptimizationProcessSummary",
    neo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OptProcessSmry",
    basic_mode_neo=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Scenarios.ScenarioName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StartingPeriodName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Periods"],
            explanation="The Period in which production begins. For any Processes where the resulting processing time is less than the period length, Starting and Completion Periods will be the same.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CompletionPeriodName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Periods"],
            explanation="The Period in which production completes. For any Processes where the resulting processing time is less than the period length, Starting and Completion Periods will be the same.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities"],
            explanation="The name of the Facility where the Process was used.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Facilities.FacilityName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Products"],
            explanation="The name of the Product for which the Process was used.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Products.ProductName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProcessName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Processes"],
            explanation="The name of the Process.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Processes.ProcessName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProcessType",
            data_type=DataType.STRING,
            explanation="The type of the Process. This will be determined by the policy table that the Process was assigned to and will be one of Production, Stocking, Destocking, Loading or Unloading.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CurrentStepName",
            data_type=DataType.STRING,
            pk=True,
            explanation="The Step Name that the specific records are being reported for.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="NextStepName",
            data_type=DataType.STRING,
            pk=True,
            explanation="In the case of multi-step Processes, the Step Name of the next step that was used will be reported here.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WorkCenterName",
            data_type=DataType.STRING,
            master_table=["WorkCenters"],
            explanation="The name of the Work Center that was used to complete the current step of the Process.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["WorkCenters.WorkCenterName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProcessedQuantity",
            data_type=DataType.DOUBLE,
            explanation="The quantity of the listed Product that was processed by the listed Process Step.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProcessedQuantityUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the quantity is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProcessedVolume",
            data_type=DataType.DOUBLE,
            explanation="The volume of the listed Product that was processed by the listed Process Step.",
            precision_category=["Volume"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProcessedVolumeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the volume is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProcessedWeight",
            data_type=DataType.DOUBLE,
            explanation="The weight of the listed Product that was processed by the listed Process Step.",
            precision_category=["Weight"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProcessedWeightUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the weight is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="YieldLossQuantity",
            data_type=DataType.DOUBLE,
            explanation="The quantity of product lost due to the Yield Percentage of the Process Step.",
            precision_category=["Quantity"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProcessedTime",
            data_type=DataType.DOUBLE,
            explanation="The time taken for the production of this Process Step. This is taken from the Processing Rate and the Fixed Time from the Processes table.",
            precision_category=["Time"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProcessedTimeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that the time is expressed in terms of.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProcessUnitCost",
            data_type=DataType.DOUBLE,
            explanation="The variable cost for the listed process step. This is specified in the Unit Cost field of the Processes table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProcessFixedCost",
            data_type=DataType.DOUBLE,
            explanation="The fixed cost for the listed process step. This is specified in the Fixed Cost field of the Processes table.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="NumberOfLots",
            data_type=DataType.DOUBLE,
            explanation="Total Number of Lots that is produced at this step. This is calculated as Processed Units / Lot Size.",
            precision_category=["Quantity"],
            basic_mode=["NEO"],
            disaggregation_logic="ByRatio",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CO2Emissions",
            data_type=DataType.DOUBLE,
            explanation="The CO2 emissions from this process.",
            precision_category=["Quantity"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="CO2Cost",
            data_type=DataType.DOUBLE,
            explanation="The cost attributed to CO2 Emissions for this process.",
            precision_category=["Cost"],
            disaggregation_logic="ByRatio",
            in_database=True
        ),
        Column(
            column_name="Latitude",
            data_type=DataType.DOUBLE,
            explanation="The latitude of the Facility.",
            precision_category=["GeoCoordinate"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Longitude",
            data_type=DataType.DOUBLE,
            explanation="The longitude of the Facility.",
            precision_category=["GeoCoordinate"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
