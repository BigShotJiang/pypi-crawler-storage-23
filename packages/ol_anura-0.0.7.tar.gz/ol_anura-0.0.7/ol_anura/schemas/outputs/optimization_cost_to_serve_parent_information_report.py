"""OptimizationCostToServeParentInformationReport table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table

# OptimizationCostToServeParentInformationReport table schema
optimization_cost_to_serve_parent_information_report = Table(
    table_name="OptimizationCostToServeParentInformationReport",
    abbreviated_name="OptCostToServeParentInfoRpt",
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            master_column=["Scenarios.ScenarioName"],
            in_database=True
        ),
        Column(
            column_name="ParentActivityType",
            data_type=DataType.STRING,
            pk=True,
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="ParentSiteName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities", "Suppliers", "Customers"],
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            in_database=True
        ),
        Column(
            column_name="ParentProductName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Products"],
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            in_database=True
        ),
        Column(
            column_name="ParentPeriodName",
            data_type=DataType.STRING,
            master_table=["Periods"],
            precision_category=["NaN"],
            master_column=["Periods.PeriodName"],
            in_database=True
        ),
        Column(
            column_name="CurrentActivityType",
            data_type=DataType.STRING,
            pk=True,
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="CurrentSiteName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities", "Suppliers", "Customers"],
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            in_database=True
        ),
        Column(
            column_name="CurrentProductName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Products"],
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            in_database=True
        ),
        Column(
            column_name="CurrentPeriodName",
            data_type=DataType.STRING,
            master_table=["Periods"],
            precision_category=["NaN"],
            master_column=["Periods.PeriodName"],
            in_database=True
        ),
        Column(
            column_name="ParentNodeCost",
            data_type=DataType.DOUBLE,
            precision_category=["Cost"],
            in_database=True
        ),
        Column(
            column_name="Quantity",
            data_type=DataType.DOUBLE,
            precision_category=["Quantity"],
            in_database=True
        ),
        Column(
            column_name="Ratio",
            data_type=DataType.DOUBLE,
            precision_category=["Percentage"],
            in_database=True
        ),
        Column(
            column_name="SegmentCost",
            data_type=DataType.DOUBLE,
            precision_category=["Cost"],
            in_database=True
        ),
    ]
)
