"""OptimizationSequentialObjectiveSummary table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, ConstraintType, TechnologySupport

# OptimizationSequentialObjectiveSummary table schema
optimization_sequential_objective_summary = Table(
    table_name="OptimizationSequentialObjectiveSummary",
    neo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OptSequentialObjectiveSmry",
    basic_mode_neo=True,
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Scenarios.ScenarioName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ObjectiveType",
            data_type=DataType.STRING,
            pk=True,
            explanation="The type of the sequential objective that results are being reported for.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UserDefinedObjectiveName",
            data_type=DataType.STRING,
            pk=True,
            explanation="The User Defined Cost or User Defined Variable for which we are defining the Objective. If nothing is specified, All Costs/Variables will be considered.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Level",
            data_type=DataType.INTEGER,
            pk=True,
            explanation="The Level of the sequential optimization.",
            precision_category=["Integer"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConstraintType",
            data_type=DataType.STRING,
            explanation="The ConstraintType of the objective for the current level: 'Optimized, Unbounded, Lower Bound, Upper Bound",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConstraintValue",
            data_type=DataType.DOUBLE,
            explanation="The value of the upper/lower bound constraint created using the objective value and the tolerance.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ObjectiveValue",
            data_type=DataType.DOUBLE,
            explanation="The value of the listed Objective that was calculated at the end of the current Level solve.",
            precision_category=["Cost"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
