"""TerritoryPlanningSettings table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, Status, TechnologySupport

# TerritoryPlanningSettings table schema
territory_planning_settings = Table(
    table_name="TerritoryPlanningSettings",
    hopper=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="TerritoryPlanningSettings",
    in_database=True,
    fields=[
        Column(
            column_name="TerritoryType",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the territory type.",
            precision_category=["NaN"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="NumberOfTerritories",
            data_type=DataType.INTEGER,
            validation_type="PositiveNumeric",
            u_o_m_conversion="",
            explanation="The number of territories of this type to be created.",
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MinNumberOfDeliveryLocations",
            data_type=DataType.INTEGER,
            validation_type="NonNegative",
            u_o_m_conversion="",
            explanation="The minimum number of delivery locations to be assigned to each territory of this type.",
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MaxNumberOfDeliveryLocations",
            data_type=DataType.INTEGER,
            validation_type="NonNegative",
            u_o_m_conversion="",
            explanation="The maximum number of delivery locations that can be assigned to each territory of this type.",
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MinNumberOfPickupLocations",
            data_type=DataType.INTEGER,
            validation_type="NonNegative",
            u_o_m_conversion="",
            explanation="The minimum number of pickup locations to be assigned to each territory of this type.",
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MaxNumberOfPickupLocations",
            data_type=DataType.INTEGER,
            validation_type="NonNegative",
            u_o_m_conversion="",
            explanation="The maximum number of pickup locations that can be assigned to each territory of this type.",
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MinDeliveredQuantity",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            u_o_m_conversion="",
            explanation="The minimum quantity of delivered product for each territory of this type.",
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MaxDeliveredQuantity",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            u_o_m_conversion="",
            explanation="The maximum quantity of delivered product for each territory of this type.",
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not this territory type will be considered in the model",
            precision_category=["NaN"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
