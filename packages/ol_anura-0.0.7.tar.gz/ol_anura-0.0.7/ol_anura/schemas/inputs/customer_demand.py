"""CustomerDemand table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, DemandStatus, GroupBehavior, Status, TechnologySupport

# CustomerDemand table schema
customer_demand = Table(
    table_name="CustomerDemand",
    neo=TechnologySupport.FULLY_SUPPORTED,
    triad=TechnologySupport.FULLY_SUPPORTED,
    cyclo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="CustomerDemand",
    fixed_tags=["Demand"],
    basic_mode_neo=True,
    basic_mode_triad=True,
    basic_mode_cyclo=True,
    in_database=True,
    fields=[
        Column(
            column_name="CustomerName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Customers"],
            expandable=True,
            explanation="The name of the Customer. Customer Groups are supported; the Group behavior will be Enumerate.",
            precision_category=["NaN"],
            basic_mode=["TRIAD", "NEO", "CYCLO"],
            master_column=["Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Products"],
            expandable=True,
            explanation="The name of the Product requested by the Customer. Product Groups are supported; the Group behavior will be Enumerate.",
            precision_category=["NaN"],
            basic_mode=["NEO", "CYCLO"],
            master_column=["Products.ProductName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductNameGroupBehavior",
            data_type=GroupBehavior,
            default_value="Enumerate",
            explanation="If  product group is entered in the Product Name field, the Product Name Group Behavior field allows you to specify if demand records should be generated for every individual product in the group (Enumerate) or if any product contained in the group would be able to satisfy the demand record (Aggregate). In the case that Aggregate is used, the flows into the customer location for all products contained in the product group will be summed, and this total quantity is used to evaluate the demand record.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Periods"],
            expandable=True,
            default_value="Model Horizon",
            explanation="The Period in which the demand record occurs. Period Groups are supported; the Group behavior will be enumerate.",
            precision_category=["NaN"],
            basic_mode=["NEO", "CYCLO"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Quantity",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            required=True,
            explanation="The amount of the Product requested by the Customer in the specified Period.",
            precision_category=["Quantity"],
            basic_mode=["TRIAD", "NEO", "CYCLO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MinQuantity",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="The minimum amount of Product required to satisfy the Customer's demand in the specified Period. This value is used to turn demand satisfaction into a soft constraint; if no value is entered, it is assumed that Min Quantity is equal to Quantity.",
            precision_category=["Quantity"],
            in_database=True
        ),
        Column(
            column_name="MaxQuantity",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="The maximum amount of Product that the Customer can receive in the specified Period. This value is used to turn demand satisfaction into a soft constraint; if no value is entered, it is assumed that Max Quantity is equal to Quantity.",
            precision_category=["Quantity"],
            in_database=True
        ),
        Column(
            column_name="QuantityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="Quantity",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that measures Quantity, Min Quantity, and Max Quantity. Quantity, Volume, and Weight units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the Demand record exists in the model. If Status is set to Exclude, this  record will be ignored during the model run.",
            precision_category=["NaN"],
            basic_mode=["TRIAD", "NEO", "CYCLO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DemandStatus",
            data_type=DemandStatus,
            required=True,
            default_value="Include",
            explanation="Demand Status dictates whether or not the Demand record must be considered in the optimization run. If the Demand Status is set to Consider, the demand record can be serviced if it is optimal to do so, and if it is chosen not to be served then any associated penalty costs will be applied. If the Demand Status is set to Exclude then the demand record will be forced into a Not Served status and any associated Penalty Cost will be applied.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ServiceMode",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            pk=True,
            master_table=["TransportationModes"],
            explanation="Optionally, a required Transportation Mode can be specified here. If multiple Modes are acceptable, a Mode Group may be used; the Group behavior will be Aggregate.",
            precision_category=["NaN"],
            master_column=["TransportationModes.ModeName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DeliveryFrequency",
            data_type=DataType.INTEGER,
            validation_type="PositiveNumeric",
            explanation="The Delivery Frequency can be used as a way to generate shipment sizes for inbound arcs to customers. If the Shipment Size field is left empty in the Transportation Policies table for an inbound lane to a Customer and Delivery Frequency is populated, the Shipment Size will be applied as Demand Quantity / Delivery Frequency. This is especially useful when your costs are using rate cards entered in the Transportation Band Costing table.",
            precision_category=["Quantity"],
            in_database=True
        ),
        Column(
            column_name="UnitPrice",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="The price that the Customer will pay for each unit of the Product. This price overrides the Unit Price given in the Products table.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnitPriceUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="UnitPrice",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines Unit Price. Quantity, Volume, and Weight units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PenaltyCost",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="The penalty cost associated with not fulfilling a unit of demand",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PenaltyCostUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="PenaltyCost",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines Penalty Cost. Quantity, Volume, and Weight units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            basic_mode=["TRIAD", "NEO", "CYCLO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
