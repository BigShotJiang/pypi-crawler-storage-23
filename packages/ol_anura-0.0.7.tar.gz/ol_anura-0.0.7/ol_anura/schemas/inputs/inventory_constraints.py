"""InventoryConstraints table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, ConsideredInventory, ConstraintType, GroupBehavior, Status, TechnologySupport

# InventoryConstraints table schema
inventory_constraints = Table(
    table_name="InventoryConstraints",
    neo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="InventoryConstraints",
    fixed_tags=["Facilities", "Facility", "Constraints", "Multi", "Time", "Period", "Inventory"],
    in_database=True,
    fields=[
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Facilities"],
            expandable=True,
            default_value="ALL",
            explanation="The Facility or Facilities at which we are constraining inventory. Groups are supported.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityNameGroupBehavior",
            data_type=GroupBehavior,
            pk=True,
            default_value="Aggregate",
            explanation="If Facility Name is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this constraint will be created for each member of the Group. If Aggregate is selected, the flow in the constraint will be summed over the members of the Group.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Products"],
            expandable=True,
            default_value="ALL",
            explanation="The Product(s) for which we are constraining inventory. Groups are supported.",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductNameGroupBehavior",
            data_type=GroupBehavior,
            pk=True,
            default_value="Aggregate",
            explanation="If Product Name is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this constraint will be created for each member of the Group. If Aggregate is selected, the flow in the constraint will be summed over the members of the Group.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Periods"],
            expandable=True,
            default_value="ALL",
            explanation="The Period(s) in which we are constraining inventory. Groups are supported.",
            precision_category=["NaN"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PeriodNameGroupBehavior",
            data_type=GroupBehavior,
            pk=True,
            default_value="Aggregate",
            explanation="If Period Name is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this constraint will be created for each member of the Group. If Aggregate is selected, the flow in the constraint will be summed over the members of the Group.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConstraintType",
            data_type=ConstraintType,
            required=True,
            pk=True,
            explanation="The type of constraint imposed on the inventory for the specified Facility/Product combination. \n\nMin: the inventory level must be greater than or equal to the Constraint Value.\nMax: the inventory level must be less than or equal to the Constraint Value.\nFixed: the inventory level must be equal to the Constraint Value.\nFixed With Tolerance: The inventory level must be equal to the Constraint Value * (1 +/- Relative Constraint Tolerance). Relative Constraint Tolerance is specified in the Model Run Options.\nConditional Min: if the inventory level is nonzero, it must be greater than or equal to the Constraint Value.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConstraintValue",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            required=True,
            pk=True,
            explanation="The numeric value that the specified inventory level will be evaluated against.",
            precision_category=["Constraint"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConstraintValueUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight, DaysOfSupply]",
            required_if="ConstraintValue",
            pk=True,
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight", "DaysOfSupply"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines Constraint Value. Quantity, Volume, and Weight units of measure are supported. DOS is also supported where Constraint Type = Min.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConsideredInventory",
            data_type=ConsideredInventory,
            required=True,
            pk=True,
            default_value="Prebuild Only",
            explanation="The type of inventory that is to be considered when applying the constraint. Prebuild inventory is restricted based on the Ending Prebuild Inventory, and Cycle Inventory is restricted based on the total of Average Turn Estimated Inventory, Average Transportation Estimated Inventory and Average Production Estimated Inventory.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the constraint exists in the model. If Status is set to Exclude, this constraint (or constraints in the case of Enumerated Groups) will be ignored during the model run.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
