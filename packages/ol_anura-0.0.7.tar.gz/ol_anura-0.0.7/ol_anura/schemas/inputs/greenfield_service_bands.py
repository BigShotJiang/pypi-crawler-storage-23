"""GreenfieldServiceBands table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, GroupBehavior, Status, TechnologySupport

# GreenfieldServiceBands table schema
greenfield_service_bands = Table(
    table_name="GreenfieldServiceBands",
    triad=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="GreenfieldServiceBands",
    in_database=True,
    fields=[
        Column(
            column_name="ServiceBandName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the Service Band constraint, this name will be referenced in the Greenfield output tables",
            precision_category=["NaN"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CustomerName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Customers"],
            expandable=True,
            default_value="ALL",
            explanation="The name of the Customer or Group of Customers that the service constraint applies to. When left blank, the service constraints will be applied across all customers.",
            precision_category=["NaN"],
            master_column=["Customers.CustomerName"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CustomerNameGroupBehavior",
            data_type=GroupBehavior,
            pk=True,
            default_value="Aggregate",
            explanation="If Customer Name is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this constraint will be created for each member of the Group. If Aggregate is selected, the flow in the constraint will be summed over the members of the Group.",
            precision_category=["NaN"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ServiceBandPercentage",
            data_type=DataType.DOUBLE,
            validation_type="Percentage",
            required=True,
            pk=True,
            explanation="The percentage (in terms of demand quantity) that must be fulfilled within the specified Service Band Distance.",
            precision_category=["Percentage"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ServiceBandDistance",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            required=True,
            explanation="The distance value for the service band.",
            precision_category=["Distance"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ServiceBandDistanceUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required_if="ServiceBandDistance",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Distance"],
            default_value="{PrimaryDistanceUOM}",
            explanation="The distance unit of measure that the service band is expressed in terms of.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            explanation="Status dictates whether or not the constraint exists in the model. If Status is set to Exclude, this constraint will be ignored during the model run.",
            precision_category=["NaN"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
