"""InventorySettings table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, ServiceType, TechnologySupport

# InventorySettings table schema
inventory_settings = Table(
    table_name="InventorySettings",
    cyclo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="InventorySettings",
    basic_mode_cyclo=True,
    in_database=True,
    fields=[
        Column(
            column_name="TargetServiceLevel",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="The target Service Level to be met during the CYCLO run.",
            precision_category=["Percentage"],
            basic_mode=["CYCLO"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ServiceType",
            data_type=ServiceType,
            explanation="The type of service level to be met during the CYCLO run.",
            precision_category=["NaN"],
            basic_mode=["CYCLO"],
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
