"""InventoryPoliciesAdvanced table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, Status, TechnologySupport

# InventoryPoliciesAdvanced table schema
inventory_policies_advanced = Table(
    table_name="InventoryPoliciesAdvanced",
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    cyclo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="InventoryPoliciesAdvanced",
    basic_mode_cyclo=True,
    in_database=True,
    fields=[
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Facilities"],
            expandable=True,
            explanation="The Facility that the policy record applies to.",
            precision_category=["NaN"],
            basic_mode=["CYCLO"],
            master_column=["Facilities.FacilityName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Products"],
            expandable=True,
            explanation="The Product that the policy record applies to.",
            precision_category=["NaN"],
            basic_mode=["CYCLO"],
            master_column=["Products.ProductName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the policy exists in the model. If Status is set to Exclude, the policy record is ignored during the model run.",
            precision_category=["NaN"],
            basic_mode=["CYCLO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SafetyStock",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="The safety stock for this inventory policy",
            precision_category=["Quantity"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SafetyStockUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight, DaysOfSupply]",
            required_if="SafetyStock",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight", "DaysOfSupply"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure of the safety stock",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StockoutDueDateOffset",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            required=True,
            explanation="The stock out due date offset",
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StockoutDueDateOffsetUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required_if="ServiceLevel",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure (Type = Time) used to define the stock out due date offset.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BelowSafetyStockDueDateOffset",
            data_type=DataType.DOUBLE,
            required=True,
            default_value="True",
            explanation="The below safety stock due date offset",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BelowSafetyStockDueDateOffsetUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required_if="ServiceLevel",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure (Type = Time) used to define the below safety stock due date offset.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StandardDueDateOffset",
            data_type=DataType.DOUBLE,
            explanation="The standard due date offset",
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StandardDueDateOffsetUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required_if="StandardDueDateOffset",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure (Type = Time) used to define the standard due date offset.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CustomReadyRateThreshold",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="The custom ready rate threshold",
            precision_category=["Quantity"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CustomReadyRateThresholdUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight, DaysOfSupply]",
            required_if="SafetyStock",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight", "DaysOfSupply"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure of the custom ready rate threshold",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TargetServiceLevel",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="The target service level for this inventory policy",
            basic_mode=["CYCLO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="IncludeInDendro",
            data_type=bool,
            required=True,
            default_value="True",
            explanation="Whether to include this inventory policy in Dendro",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            basic_mode=["CYCLO"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
