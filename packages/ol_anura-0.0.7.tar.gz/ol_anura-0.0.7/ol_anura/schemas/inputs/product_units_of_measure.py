"""ProductUnitsOfMeasure table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# ProductUnitsOfMeasure table schema
product_units_of_measure = Table(
    table_name="ProductUnitsOfMeasure",
    neo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="ProductUnitsOfMeasure",
    in_database=True,
    fields=[
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Products"],
            expandable=True,
            explanation="The Product for which we are defining a unit conversion. Product Groups are also supported with the behavior of enumerate",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UOMSymbol",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity]",
            required=True,
            pk=True,
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity"],
            explanation="The UOM (Type = Quantity) for which we are specifying the unit conversion.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Quantity",
            data_type=DataType.DOUBLE,
            required=True,
            default_value="1",
            explanation="This field allows for a product-specific number of units to be assigned to a generic Quantity UOM. For example, we could specify in this record that one pallet contains 1000 coffee mugs. In a separate record, we could specify that one pallet contains four refrigerators. This enables us to convert aggregate UOMs to smaller UOMs and vice versa.",
            precision_category=["Quantity"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
