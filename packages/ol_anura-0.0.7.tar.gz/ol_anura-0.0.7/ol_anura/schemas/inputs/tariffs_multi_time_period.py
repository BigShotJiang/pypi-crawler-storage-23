"""TariffsMultiTimePeriod table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, PathDestinationProperty, PathOriginProperty, Status

# TariffsMultiTimePeriod table schema
tariffs_multi_time_period = Table(
    table_name="TariffsMultiTimePeriod",
    abbreviated_name="TariffsMTP",
    fixed_tags=["Multi", "Time", "Period"],
    in_database=True,
    fields=[
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Periods"],
            expandable=True,
            explanation="The period name in which the product enters the Path Destination. The period selected is the period in which the product enters the Tariff Destination Zone. Groups of periods are also supported. Changes that are made in the Multi Time Period table will be applied as overrides for the records of the base table for the specified periods only. Additionally, only the fields that contain information needing to be updated are required to be entered, in the absence of data in the Multi Time Period table the data from the standard table will be persisted",
            precision_category=["NaN"],
            master_column=["Periods.PeriodName"],
            in_database=True
        ),
        Column(
            column_name="PathOriginProperty",
            data_type=PathOriginProperty,
            pk=True,
            default_value="Country",
            explanation="The property of the Source (Supplier or Facility) that the Rate cost structure has been created for. For example, a Postal Code to Postal Code rate system could be defined; both the Source and Destination Properties would be set to Postal Code and the Source/Destination values would include all allowable Postal Code pairings.",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="PathOriginValue",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities", "Suppliers", "Sources"],
            explanation="The value to look up in the Source table (either Facilities or Suppliers) Source Property column.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName", "Facilities.Address", "Facilities.City", "Facilities.PostalCode", "Facilities.Region", "Facilities.Country", "Suppliers.SupplierName", "Suppliers.Address", "Suppliers.City", "Suppliers.PostalCode", "Suppliers.Region", "Suppliers.Country"],
            in_database=True
        ),
        Column(
            column_name="PathDestinationProperty",
            data_type=PathDestinationProperty,
            pk=True,
            default_value="Country",
            explanation="The property of the Destination (Customer or Facility) that the Rate cost structure has been created for. For example, a Postal Code to Postal Code rate system could be defined; both the Source and Destination Properties would be set to Postal Code and the Source/Destination values would include all allowable Postal Code pairings.",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="PathDestinationValue",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Customers", "Facilities", "Destinations"],
            explanation="The value to look up in the Destination table (either Customers or Facilities) Destination Property column.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName", "Facilities.Address", "Facilities.City", "Facilities.PostalCode", "Facilities.Region", "Facilities.Country", "Customers.CustomerName", "Customers.Address", "Customers.City", "Customers.PostalCode", "Customers.Region", "Customers.Country"],
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Products"],
            expandable=True,
            u_o_m_conversion="",
            explanation="The name of the Product",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            in_database=True
        ),
        Column(
            column_name="HSCode",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="DutyRate",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            u_o_m_conversion="",
            default_value="0",
            explanation="The Duty Rate will be applied as a percentage of the product's value that is moving along the path starts at the Origin and ends in the Destination. For a Duty Rate of 10%, enter a value of 10 into the Duty Rate field.",
            precision_category=["Percentage"],
            in_database=True
        ),
        Column(
            column_name="UnitCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            master_table=["StepCosts"],
            u_o_m_conversion="",
            default_value="0",
            explanation="The duty cost per product unit",
            precision_category=["Cost"],
            in_database=True
        ),
        Column(
            column_name="UnitCostUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            u_o_m_conversion="Per-Intra",
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines Cost. UOM Types of Quantity, Volume, Weight are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="ProductUnitValueOverride",
            data_type=DataType.COST_TIME_EXPRESSION,
            master_table=["StepCosts"],
            u_o_m_conversion="",
            default_value="0",
            explanation="The unit value of the product that should be used for the tariff calculation. If blank, the unit value from the Products table will be used.",
            precision_category=["Cost"],
            in_database=True
        ),
        Column(
            column_name="ProductUnitValueOverrideUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="UnitValue",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines the basis for Unit Value. For example, we could set the Product's Unit Value as $5 per pound or $5 each.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the TariffRate exists in the model. If Status is set to Exclude, the Rate will be ignored during the model run.",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            in_database=True
        ),
    ]
)
