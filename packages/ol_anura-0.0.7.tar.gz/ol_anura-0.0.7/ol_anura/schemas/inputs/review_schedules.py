"""ReviewSchedules table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# ReviewSchedules table schema
review_schedules = Table(
    table_name="ReviewSchedules",
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="ReviewSchedules",
    in_database=True,
    fields=[
        Column(
            column_name="ReviewScheduleName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the schedule defining review times each day of the week; this value can be referenced in tables dealing with review periods.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SundayReviewTime",
            data_type=DataType.TIME,
            pk=True,
            explanation="The time on Sunday that the review occurs.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MondayReviewTime",
            data_type=DataType.TIME,
            pk=True,
            explanation="The time on Monday that the review occurs.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TuesdayReviewTime",
            data_type=DataType.TIME,
            pk=True,
            explanation="The time on Tuesday that the review occurs.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WednesdayReviewTime",
            data_type=DataType.TIME,
            pk=True,
            explanation="The time on Wednesday that the review occurs.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ThursdayReviewTime",
            data_type=DataType.TIME,
            pk=True,
            explanation="The time on Thursday that the review occurs.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FridayReviewTime",
            data_type=DataType.TIME,
            pk=True,
            explanation="The time on Friday that the review occurs.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SaturdayReviewTime",
            data_type=DataType.TIME,
            pk=True,
            explanation="The time on Saturday that the review occurs.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
