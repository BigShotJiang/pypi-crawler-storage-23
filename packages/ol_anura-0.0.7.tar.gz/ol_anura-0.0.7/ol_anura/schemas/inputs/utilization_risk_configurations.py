"""UtilizationRiskConfigurations table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# UtilizationRiskConfigurations table schema
utilization_risk_configurations = Table(
    table_name="UtilizationRiskConfigurations",
    neo=TechnologySupport.FULLY_SUPPORTED,
    triad=TechnologySupport.FULLY_SUPPORTED,
    dart=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="UtilizationRiskConfigurations",
    in_database=True,
    fields=[
        Column(
            column_name="RiskProfileName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["RiskRatingConfigurations"],
            explanation="The name of the Risk Profile that the risk configuration is saved for. Risk Profiles are configured to run using specified source data in the Risk Rating Configurations table, and will take the risk weightings and bands associated with the Risk Profile from each of the configuration tables.",
            precision_category=["NaN"],
            master_column=["RiskRatingConfigurations.RiskProfileName"],
            dart=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ThroughputUtilizationRiskWeight",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            required=True,
            explanation="The weight applied to the Throughput Utilization Risk when calculating the Utilization Risk Score for Facilities and Suppliers.",
            precision_category=["Risk"],
            dart=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ThroughputUtilizationRiskBand",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            master_table=["RiskBandDefinitions"],
            explanation="The Risk Band that is used to evaluate the Throughput Utilization Risk at Facilities and Suppliers. Risk Bands are defined in the Risk Band Definitions table.",
            precision_category=["NaN"],
            master_column=["RiskBandDefinitions.BandName"],
            dart=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StorageUtilizationRiskWeight",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            required=True,
            explanation="The weight applied to the Storage Utilization Risk when calculating the Utilization Risk Score for Facilities.",
            precision_category=["Risk"],
            dart=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StorageUtilizationRiskBand",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            master_table=["RiskBandDefinitions"],
            explanation="The Risk Band that is used to evaluate the Storage Utilization Risk for Facilities. Risk Bands are defined in the Risk Band Definitions table.",
            precision_category=["NaN"],
            master_column=["RiskBandDefinitions.BandName"],
            dart=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WorkCenterUtilizationRiskWeight",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            required=True,
            explanation="The weight applied to the Work Center Utilization Risk when calculating the Utilization Risk Score for Facilities.",
            precision_category=["Risk"],
            dart=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WorkCenterUtilizationRiskBand",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            master_table=["RiskBandDefinitions"],
            explanation="The Risk Band that is used to evaluate the Work Center Utilization Risk for Facilities. Risk Bands are defined in the Risk Band Definitions table.",
            precision_category=["NaN"],
            master_column=["RiskBandDefinitions.BandName"],
            dart=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            dart=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
