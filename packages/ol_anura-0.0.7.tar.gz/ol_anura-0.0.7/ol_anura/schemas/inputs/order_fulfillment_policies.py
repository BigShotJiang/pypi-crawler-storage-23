"""OrderFulfillmentPolicies table schema definition."""

import sys
from pathlib import Path
from enum import Enum

from ...core import DataType, Column, Table, Status, TechnologySupport


class QueueingPriorityLogic(str, Enum):
    """QueueingPriorityLogic values."""
    BYDAYQUEUEDANDLOCATION = "ByDayQueuedAndLocation"
    BYDUEDATEANDLOCATION = "ByDueDateAndLocation"
    FIFO = "FIFO"

# OrderFulfillmentPolicies table schema
order_fulfillment_policies = Table(
    table_name="OrderFulfillmentPolicies",
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OrderFulfillmentPolicies",
    fixed_tags=["Customers", "Customer", "Policies", "OrderFulfillment"],
    in_database=True,
    fields=[
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Facilities"],
            expandable=True,
            explanation="The Facility that the policy record applies to.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AllowPartialFillOrders",
            data_type=bool,
            default_value="True",
            explanation="If True, orders fulfilled by the Facility may be partially filled. Otherwise, orders must be filled in full. A value of False overrides a value of True in the Allow Partial Fill Lines field.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AllowPartialFillLineItems",
            data_type=bool,
            default_value="True",
            explanation="If True, line items within orders fulfilled by the Facility may be partially filled. Otherwise, line items must be filled in full.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReviewPeriodFirstTime",
            data_type=DataType.DATETIME,
            explanation="The first Date/Time at which to review order queues at the specified Facility. Order queues will be evaluated using the logic specified in Order Assignment Policies. After this Date/Time, the review period length will dictate when order queue reviews occur. If NULL, Review Period First Time will be the start of the simulation.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReviewPeriod",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable",
            master_table=["ReviewSchedules"],
            explanation="The time between order queue reviews. After Review Period First Time, an order queue review will occur each time Review Period has elapsed. For example, if Review Period First Time is 1/1/2022 12:00:00 AM and Review Period is six hours, we will conduct reviews on 1/1/2022 at 12:00:00 AM, 6:00:00 AM, 12:00:00 PM, and 6:00:00 PM, continuing similarly until the simulation ends. A Review Schedule defined in the Review Schedules table can be entered by Review Schedule Name in this field as well. If NULL, continuous review is used.",
            precision_category=["Time"],
            master_column=["ReviewSchedules.ReviewScheduleName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReviewPeriodUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Time]",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure (Type = Time) that defines Review Period length.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="QueueingPriorityLogic",
            data_type=QueueingPriorityLogic,
            default_value="FIFO",
            explanation="The logic used at the Facility both when deciding how to arrange orders in the order queue and when evaluating the order queue to determine if an order should be repositioned. ByDueDateAndLocation will fulfill the orders that are due the soonest first, and in the case of ties will prioritize orders based on the destination priority set in either the Customers, Facilities, or the Advanced Queueing Priorities table. ByDayQueuedAndLocation will place the items that have been in the queue the longest first, and apply the same prioritization logic as described for ByDueDateAndLocation",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the policy exists in the model. If Status is set to Exclude, the policy record is ignored during the model run.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TimeInQueueCost",
            data_type=DataType.DOUBLE,
            explanation="The cost associated with an item sitting in a queue. The cost expressed in this field will be charged each time that items sit in a queue for the length of time specified in the Time In Queue Cost UOM field.",
            precision_category=["Cost"],
            in_database=True
        ),
        Column(
            column_name="TimeInQueueCostUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required_if="TimeInQueueCost",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure that time is expressed in terms of.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
