"""ReturnPolicies table schema definition."""

import sys
from pathlib import Path
from enum import Enum

from ...core import DataType, Column, Table, Status, TechnologySupport


class OptimizationPolicy(str, Enum):
    """OptimizationPolicy values."""
    BY_RATIO_AUTO_SCALE = "By Ratio (Auto Scale)"
    BY_RATIO_NO_SCALE = "By Ratio (No Scale)"
    RETURN_TO_SENDER = "Return to Sender"
    SINGLE_DESTINATION = "Single Destination"
    TO_OPTIMIZE = "To Optimize"

# ReturnPolicies table schema
return_policies = Table(
    table_name="ReturnPolicies",
    neo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="ReturnPolicies",
    fixed_tags=["Customers", "Customer", "Policies", "Returns"],
    in_database=True,
    fields=[
        Column(
            column_name="SiteName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Customers"],
            expandable=True,
            explanation="The Customer that the policy record applies to.",
            precision_category=["NaN"],
            master_column=["Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReturnProductName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Products"],
            expandable=True,
            explanation="The Product (or Product group) that the policy record applies to.",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DestinationName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Facilities"],
            expandable=True,
            explanation="The destination Facility (or Facility group) that the policy record applies to.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OptimizationPolicy",
            data_type=OptimizationPolicy,
            required=True,
            default_value="To Optimize",
            explanation="The logic that returns for the site, Product, and Destination combination(s) must follow. To Optimize selects the lowest cost option. By Ratio (Auto Scale) will enforce a flow split between the specified destinations, the defined ratios will apply to flow from the site into the listed destinations only. By Ratio (No Scale) will enforce a flow split between the specified destinations and the defined ratios will be in terms of the total outbound flow from the site. Single Destination policies force the site to return the Product to one Destination.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OptimizationPolicyValue",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            required_if="OptimizationPolicy = By Ratio (Auto Scale) OR By Ratio (No Scale)",
            explanation="By Ratio (Auto Scale): The Policy Parameter will define the percentage of flow that must be satisfied from the listed destination. The percentage will be calculated based on the total outbound flow for the site/product combination and enforced proportionally across the destinations with a policy of By Ratio (Auto Scale).\n\nBy Ratio (No Scale): The Policy Parameter will define the percentage of flow that must be satisfied from the listed destination. The percentage will be calculated based on the total outbound flow for the site/product combination  and enforced over the listed destinations. If the Policy Parameters add up to less than 100, the remainder of unaccounted flow can be delivered through any other viable lane. If the Policy Parameters add up to more than 100, they will be scaled to 100 and enforced the same as Auto Scale.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the policy exists in the model. If Status is set to Exclude, the policy record is ignored during the model run.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnitCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE ThroughputLevelUOM = [Quantity, Volume, Weight]",
            master_table=["StepCosts"],
            default_value="0",
            explanation="The cost incurred per unit of flow for the specified Source/Customer/Product combination.",
            precision_category=["NaN"],
            master_column=["StepCosts.StepCostName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnitCostUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required_if="UnitCost",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines flow for the Source/Customer/Product combination.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MaxDeliveryRange",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="The maximum allowable distance between Destination and Customer for the Product(s) specified. This field is intended for use in models with group policies to eliminate excessively long lanes from consideration.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MaxDeliveryRangeUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required_if="MaxDeliveryRange",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Distance"],
            default_value="{PrimaryDistanceUOM}",
            explanation="The unit of measure (Type = Distance) that defines Max Delivery Range.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
