"""CustomerDemandOriginConstraints table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, GroupBehavior, Status, TechnologySupport

# CustomerDemandOriginConstraints table schema
customer_demand_origin_constraints = Table(
    table_name="CustomerDemandOriginConstraints",
    neo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="CustomerDemandOriginConstraints",
    in_database=True,
    fields=[
        Column(
            column_name="CustomerName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Customers"],
            expandable=True,
            explanation="The name of the Customer. Customer Groups are supported; the Group behavior will be Enumerate.",
            precision_category=["NaN"],
            master_column=["Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Products"],
            expandable=True,
            explanation="The name of the Product requested by the Customer. Product Groups are supported; the Group behavior will be Enumerate.",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Periods"],
            expandable=True,
            default_value="Model Horizon",
            explanation="The Period in which the demand record occurs. Period Groups are supported; the Group behavior will be enumerate.",
            precision_category=["NaN"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the Origin Policy record exists in the model. If Status is set to Exclude, this  record will be ignored during the model run.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductOriginLocation",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            pk=True,
            master_table=["Facilities", "Suppliers", "Sources"],
            explanation="An origin location for the product can be specified here. Groups are supported in this field, with the Group Behavior being treated as Aggregate.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductOriginLocationGroupBehavior",
            data_type=GroupBehavior,
            pk=True,
            default_value="Aggregate",
            explanation="If ProductOriginLocation Name is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this constraint will be created for each member of the Group. If Aggregate is selected, flow in the constraint will be summed over the members of the Group to satisfy demand.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Quantity",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            required=True,
            explanation="The amount of the Product requested by the Customer in the specified Period that this Origin Location policy will apply for. If you want to prevent an origin location from being used to service a demand record, you can enter a quantity of 0.",
            precision_category=["Quantity"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="QuantityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="Quantity",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that measures Quantity, Min Quantity, and Max Quantity. Quantity, Volume, and Weight units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
