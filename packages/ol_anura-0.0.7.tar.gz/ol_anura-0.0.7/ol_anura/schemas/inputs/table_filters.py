"""TableFilters table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# TableFilters table schema
table_filters = Table(
    table_name="TableFilters",
    neo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="TableFilters",
    in_database=True,
    fields=[
        Column(
            column_name="TableName",
            data_type=DataType.STRING,
            pk=True,
            explanation="The input table that the filter is targeting.",
            precision_category=["NaN"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FilterName",
            data_type=DataType.STRING,
            pk=True,
            explanation="The name assigned to the filter. If this filter is applied against Customers, Facilities, Suppliers, Products, Periods, BOMs, WorkCenters, WorkResources, Modes or Processes then it can be used as an input where entries from the target table would have been supported. This will function the same as a group when used as an input record, however the members captured by the filter logic will be evaluated each time the model is run.",
            precision_category=["NaN"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FilterLogic",
            data_type=DataType.STRING,
            explanation="The logic applied against the listed Table Name for the filter.",
            precision_category=["NaN"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MapFilterLogic",
            data_type=DataType.STRING,
            explanation="The map logic applied against the listed Table Name for the filter.",
            precision_category=["NaN"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="EngineFilterLogic",
            data_type=DataType.STRING,
            explanation="The engine logic applied against the listed Table Name for the filter.",
            precision_category=["NaN"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
