"""Customers table schema definition."""

import sys
from pathlib import Path
from enum import Enum

from ...core import DataType, Column, Table, Status, TechnologySupport


class StopSequenceConstraint(str, Enum):
    """StopSequenceConstraint values."""
    FIRST_DELIVERY = "First Delivery"
    FIRST_PICKUP = "First Pickup"
    LAST_DELIVERY = "Last Delivery"
    LAST_PICKUP = "Last Pickup"

# Customers table schema
customers = Table(
    table_name="Customers",
    neo=TechnologySupport.FULLY_SUPPORTED,
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    hopper=TechnologySupport.FULLY_SUPPORTED,
    triad=TechnologySupport.FULLY_SUPPORTED,
    dart=TechnologySupport.FULLY_SUPPORTED,
    cyclo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="Customers",
    fixed_tags=["Customers", "Customer"],
    basic_mode_neo=True,
    basic_mode_throg=True,
    basic_mode_dendro=True,
    basic_mode_hopper=True,
    basic_mode_triad=True,
    basic_mode_cyclo=True,
    in_database=True,
    fields=[
        Column(
            column_name="CustomerName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the Customer",
            precision_category=["NaN"],
            basic_mode=["TRIAD", "THROG", "DENDRO", "NEO", "HOPPER", "CYCLO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the Customer exists in the model. If the Customer is included in the model, all of its demand records are enforced based on the Min QTY/Max QTY specified in the Customer Demand table. If the Customer is excluded from the model, any records for this Customer in other tables will also be ignored.",
            precision_category=["NaN"],
            basic_mode=["TRIAD", "THROG", "DENDRO", "NEO", "HOPPER", "CYCLO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Address",
            data_type=DataType.STRING,
            explanation="The street address of the Customer",
            precision_category=["NaN"],
            basic_mode=["TRIAD", "CYCLO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="City",
            data_type=DataType.STRING,
            explanation="The city of the Customer",
            precision_category=["NaN"],
            basic_mode=["TRIAD", "THROG", "DENDRO", "NEO", "HOPPER", "CYCLO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Region",
            data_type=DataType.STRING,
            explanation="The state/region of the Customer",
            precision_category=["NaN"],
            basic_mode=["TRIAD", "THROG", "DENDRO", "NEO", "HOPPER", "CYCLO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PostalCode",
            data_type=DataType.STRING,
            explanation="The ZIP/postal Code of the Customer",
            precision_category=["NaN"],
            basic_mode=["TRIAD", "THROG", "DENDRO", "NEO", "HOPPER", "CYCLO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Country",
            data_type=DataType.STRING,
            explanation="The country of the Customer",
            precision_category=["NaN"],
            basic_mode=["TRIAD", "THROG", "DENDRO", "NEO", "HOPPER", "CYCLO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Latitude",
            data_type=DataType.DOUBLE,
            validation_type="LatitudeValue",
            default_value="0",
            explanation="The latitude coordinate of the Customer",
            precision_category=["GeoCoordinate"],
            basic_mode=["TRIAD", "THROG", "DENDRO", "NEO", "HOPPER", "CYCLO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Longitude",
            data_type=DataType.DOUBLE,
            validation_type="LongitudeValue",
            default_value="0",
            explanation="The longitude coordinate of the Customer",
            precision_category=["GeoCoordinate"],
            basic_mode=["TRIAD", "THROG", "DENDRO", "NEO", "HOPPER", "CYCLO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            cyclo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SingleSource",
            data_type=bool,
            default_value="False",
            explanation="If True, all demand records for the Customer must be satisfied by a single source. Otherwise, demand may be satisfied by multiple sources. In the case of multi-period models, the Single Source rule will be applied over each period individually.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SingleSourceOrders",
            data_type=bool,
            default_value="False",
            explanation="If True, all Line Items in the Orders placed from this Customer must be sourced from a single site (Facility or Supplier). If False, each Line Item within the Orders may be sourced from a different site. A value of True in this field overrides Single Source Line Items = False, enforcing that all Line Items in the orders come from a single source.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SingleSourceLineItems",
            data_type=bool,
            default_value="False",
            explanation="If True, the entire Line Item in orders placed from this Customer must be sourced from a single site (Facility or Supplier). If False, the Line Items may be sourced from different sites.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AllowBackorders",
            data_type=bool,
            explanation="If True, the Customer accepts backorders in the event that an order cannot be fulfilled before its Due Date (defined in the Customer Orders table).",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BackorderTimeLimit",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="This value is the amount of time after which unsatisfied backorders will be cancelled by the Customer. A value of NULL will be interpreted as an infinite time limit, while a value of 0 is equivalent to setting Allow Backorders = False.",
            precision_category=["Time"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BackorderTimeUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Time]",
            required_if="BackorderTimeLimit",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure used to define the Backorder Time Limit. Any of the time units of measure defined in the Units Of Measure table can be used here.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AllowPartialFillOrders",
            data_type=bool,
            explanation="If True, orders placed by the Customer may be partially filled. Otherwise, orders must be filled in full. If backordering is allowed, the remaining quantity of partially filled orders may be satisfied in the future with additional shipments; if the Backorder Time Limit is reached on a partially filled order, the remaining quantity will be cancelled. If Partial Fill Orders is False, Partial Fill Line Items will also be forced to False.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AllowPartialFillLineItems",
            data_type=bool,
            explanation="If True, line items within orders placed by the Customer may be partially filled. Otherwise, line items must be filled in full. If backordering is allowed, the remaining quantity of partially filled line items may be satisfied in the future with additional shipments; if the Backorder Time Limit is reached on a partially filled line item, the remaining quantity will be cancelled.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AllowDirectShip",
            data_type=bool,
            default_value="False",
            explanation="If True, orders placed by the Customer that cannot be filled directly by its fulfillment source(s) can be shipped directly to the customer from an alternative location (Supplier or Facility)",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="QueuePriority",
            data_type=DataType.INTEGER,
            explanation="For any Queues that are evaluated with a Queueing Priority Logic, there can be a By Location component to the priority logic used. If By Location is used, The Queue Priority fields in the Customers, Facilities and Suppliers table will be used to determine how the queues will be ordered",
            precision_category=["Integer"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OperatingSchedule",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["BusinessHours"],
            explanation="The schedule (defined in the Business Hours table) dictating when the Customer will be open for business. If no schedule is specified, the Customer is assumed to be open 24 hours per day.",
            precision_category=["NaN"],
            master_column=["BusinessHours.ScheduleName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FixedPickupTime",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="NonNegative",
            explanation="The fixed pickup time required at this Customer. This will be additive to the FixedPickupTime specified in the Shipments, Facilities and Transportation Assets tables.",
            precision_category=["Time"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FixedPickupTimeUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Time]",
            required_if="FixedPickupTime",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure (Type = Time) that defines Fixed Pickup Time.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FixedDeliveryTime",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="NonNegative",
            explanation="The fixed time required at the delivery locations for this Customer. This will be additive to the FixedDeliveryTime specified in the Shipments, Facilities and Transportation Assets tables.",
            precision_category=["Time"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FixedDeliveryTimeUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Time]",
            required_if="FixedDeliveryTime",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure (Type = Time) that defines Fixed Delivery Time",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnitPickupTime",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="NonNegative",
            explanation="The time required per unit to be loaded at this Customer. This will be additive to any UnitPickupTime that is specified in the Shipments, Facilities and Transportation Assets tables.",
            precision_category=["Time"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnitPickupTimeUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Time]",
            required_if="UnitPickupTime",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure (Type = Time) that defines Unit Pickup Time.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnitDeliveryTime",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="NonNegative",
            explanation="The time required per unit to be delivered at this location. This will be additive to any UnitDeliveryTime that is specified in the Shipments, Facilities and Transportation Assets tables.",
            precision_category=["Time"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnitUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="UnitPickupTime OR UnitDeliveryTime",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines the basis on which UnitPickupTime and UnitDeliveryTime will be applied for the Customer. Quantity, Volume, and Weight units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnitDeliveryTimeUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Time]",
            required_if="UnitDeliveryTime",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure (Type = Time) that defines Unit Delivery Time.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="GeographicRiskScore",
            data_type=DataType.DOUBLE,
            explanation="When geocoding a location, or following the most recent DART run, the Geographic Risk will be populated using the Primary Risk Rating defined in Model Settings. For more detailed information on Geographic Risk, reference the Geographic Risk Metrics output table.",
            precision_category=["Risk"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UserDefinedRiskScore",
            data_type=DataType.DOUBLE,
            explanation="An optional input that can be leveraged by DART when calculating Customer Risk. If left empty for some records, the User Defined Risk will not be considered for those specific Customers. The weighting for this component will be defined in the Customer Risk Configurations table, and any outputs will be reported alongside other geographic risk scores in the Geographic Risk Metrics table.",
            precision_category=["Risk"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            basic_mode=["TRIAD", "THROG", "DENDRO", "NEO", "HOPPER"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StopSequenceConstraint",
            data_type=StopSequenceConstraint,
            explanation="This field can be used to force a customer to be visited first or last on a route.",
            precision_category=["NaN"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OperatingCalendar",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["BusinessCalendars"],
            default_value="None",
            explanation="The calendar (defined in the Business Calendars table) dictating which days of the year the Customer will shut down. If no calendar is specified, the Customer is assumed not to shut down.",
            precision_category=["NaN"],
            master_column=["BusinessCalendars.CalendarName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
