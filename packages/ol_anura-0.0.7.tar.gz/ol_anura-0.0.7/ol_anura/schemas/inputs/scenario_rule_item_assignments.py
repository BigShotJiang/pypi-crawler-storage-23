"""ScenarioRuleItemAssignments table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# ScenarioRuleItemAssignments table schema
scenario_rule_item_assignments = Table(
    table_name="ScenarioRuleItemAssignments",
    neo=TechnologySupport.FULLY_SUPPORTED,
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    hopper=TechnologySupport.FULLY_SUPPORTED,
    triad=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="ScenarioRuleItemAssignments",
    in_database=True,
    fields=[
        Column(
            column_name="RuleName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["ScenarioRules"],
            explanation="The name of the Scenario Rule; Scenario Rules are assigned to Scenarios via the Scenario Item Assignments table.",
            precision_category=["NaN"],
            master_column=["ScenarioRules.RuleName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ItemName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["ScenarioItems"],
            explanation="The name of the Scenario Item.",
            precision_category=["NaN"],
            master_column=["ScenarioItems.ItemName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ItemOrder",
            data_type=DataType.INTEGER,
            validation_type="PositiveNumeric",
            required=True,
            default_value="1",
            explanation="The order in which the item will execute within this scenario rule. ",
            precision_category=["Integer"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
