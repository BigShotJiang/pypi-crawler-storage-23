"""BusinessCalendars table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# BusinessCalendars table schema
business_calendars = Table(
    table_name="BusinessCalendars",
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    hopper=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="BusinessCalendars",
    in_database=True,
    fields=[
        Column(
            column_name="CalendarName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the Calendar; this value can be referenced in tables that deal with downtime.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ClosureDates",
            data_type=DataType.DATETIME,
            required=True,
            explanation="Dates which any entities following this calendar will be shut down. Each date requires its own record.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
