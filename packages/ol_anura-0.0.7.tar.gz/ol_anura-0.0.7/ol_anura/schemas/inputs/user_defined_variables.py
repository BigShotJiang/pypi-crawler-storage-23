"""UserDefinedVariables table schema definition."""

import sys
from pathlib import Path
from enum import Enum

from ...core import DataType, Column, Table, ConsideredInventory, GroupBehavior, Status, TechnologySupport


class CountingRule(str, Enum):
    """CountingRule values."""
    BOMS = "BOMs"
    DESTINATIONS = "Destinations"
    DESTINATIONS_MODES = "Destinations-Modes"
    DESTINATIONS_PRODUCTS = "Destinations-Products"
    FACILITIES = "Facilities"
    MODES = "Modes"
    ORIGINS = "Origins"
    ORIGINS_DESTINATIONS = "Origins-Destinations"
    ORIGINS_MODES = "Origins-Modes"
    ORIGINS_PRODUCTS = "Origins-Products"
    PERIODS = "Periods"
    PROCESSES = "Processes"
    PRODUCTS = "Products"
    PRODUCTS_MODES = "Products-Modes"
    WORKCENTERS = "WorkCenters"

class Type(str, Enum):
    """Type values."""
    CONSTANT = "Constant"
    DEFINITION = "Definition"
    FACILITYCOUNT = "FacilityCount"
    FLOW = "Flow"
    FLOWCOUNT = "FlowCount"
    INVENTORY = "Inventory"
    INVENTORYCOUNT = "InventoryCount"
    PRODUCTION = "Production"
    PRODUCTIONCOUNT = "ProductionCount"
    VARIABLE = "Variable"
    WORKCENTERCOUNT = "WorkCenterCount"

# UserDefinedVariables table schema
user_defined_variables = Table(
    table_name="UserDefinedVariables",
    neo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="UserDefinedVariables",
    in_database=True,
    fields=[
        Column(
            column_name="VariableName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name assigned to the Variable. Users may define variables in this table to capture behaviors which are not directly supported by other constraint tables. User-Defined Variables are  functions of Terms made of native model variables. User-Defined Variables allow a user to create a detailed expression which is then constrained in the User-Defined Constraints table and/or incurs a cost defined in the User-Defined Costs table.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TermName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The unique name assigned to the Variable Term being defined. The Terms associated with a Variable Name will be summed to give the final Variable value.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the Term exists. If Status is set to Exclude, this Term will not be included in the Variable.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Coefficient",
            data_type=DataType.DOUBLE,
            required=True,
            default_value="1",
            explanation="The coefficient by which to scale the Term. The default value is one.",
            precision_category=["Constraint"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Type",
            data_type=Type,
            required=True,
            explanation="The Type of behavior the user wishes to capture via the Term. Terms will be related to each other via their coefficients. If the TermName is referencing a variable which has already been defined (TermName = VariableName) select a type of Variable.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight, DaysOfSupply, Shipment, Quantity-Distance, Volume-Distance, Weight-Distance, Quantity-Time, Volume-Time, Weight-Time]",
            required_if="Type = Flow OR Production OR Inventory",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight", "DaysOfSupply", "Shipment", "Quantity-Distance", "Volume-Distance", "Weight-Distance", "Quantity-Time", "Volume-Time", "Weight-Time"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines Type if Flow, Production, or Inventory is selected. Quantity, Volume, Weight, Shipment, Quantity-Distance, Volume-Distance, Weight-Distance, Quantity-Time, Volume-Time, Weight-Time (if Type = Flow) or Days of Supply (if Type = Inventory) units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required_if="Type = Production OR Inventory OR ProductionCount OR InventoryCount OR FacilityCount OR WorkCenterCount",
            master_table=["Facilities"],
            expandable=True,
            default_value="ALL",
            explanation="The relevant Facility or Facilities. Groups are supported. Type must be one of [Production, Inventory, ProductionCount, FacilityCount, InventoryCount, WorkCenterCount].",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityNameGroupBehavior",
            data_type=GroupBehavior,
            default_value="Aggregate",
            explanation="If Facility Name is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this Variable will be created for each member of the Group. If Aggregate is selected, the flow in the constraint will be summed over the members of the Group. If you are using multiple terms for a variable, a group behavior entry of enumerate is only supported for one term. Having multiple terms with enumerations is not currently supported.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OriginName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required_if="Type = Flow OR FlowCount",
            master_table=["Facilities", "Suppliers", "Customers", "Sources"],
            expandable=True,
            default_value="ALL",
            explanation="The Origin(s) (Facilities and/or Suppliers and/or Customers) of flow. Groups are supported. Type must be one of [Flow, FlowCount].",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OriginNameGroupBehavior",
            data_type=GroupBehavior,
            default_value="Aggregate",
            explanation="If Origin Name is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this Variable will be created for each member of the Group. If Aggregate is selected, the flow in the constraint will be summed over the members of the Group. If you are using multiple terms for a variable, a group behavior entry of enumerate is only supported for one term. Having multiple terms with enumerations is not currently supported.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DestinationName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required_if="Type = Flow OR FlowCount",
            master_table=["Customers", "Facilities", "Destinations"],
            expandable=True,
            default_value="ALL",
            explanation="The Destination(s) (Facilities and/or Customers) of flow. Groups are supported. Type must be one of [Flow, FlowCount].",
            precision_category=["NaN"],
            master_column=["Customers.CustomerName", "Facilities.FacilityName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DestinationNameGroupBehavior",
            data_type=GroupBehavior,
            default_value="Aggregate",
            explanation="If Destination Name is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this Variable will be created for each member of the Group. If Aggregate is selected, the flow in the constraint will be summed over the members of the Group. If you are using multiple terms for a variable, a group behavior entry of enumerate is only supported for one term. Having multiple terms with enumerations is not currently supported.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required_if="Type = Flow OR Production OR Inventory OR FlowCount OR ProductionCount OR InventoryCount",
            master_table=["Products"],
            expandable=True,
            default_value="ALL",
            explanation="The relevant Product(s). Groups are supported. Type must be one of [Flow, Production, Inventory, FlowCount, ProductionCount, InventoryCount].",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductNameGroupBehavior",
            data_type=GroupBehavior,
            default_value="Aggregate",
            explanation="If Product Name is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this Variable will be created for each member of the Group. If Aggregate is selected, the flow in the constraint will be summed over the members of the Group. If you are using multiple terms for a variable, a group behavior entry of enumerate is only supported for one term. Having multiple terms with enumerations is not currently supported.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ModeName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required_if="Type = Flow OR FlowCount",
            master_table=["TransportationModes"],
            expandable=True,
            default_value="ALL",
            explanation="The relevant Transportation Mode(s). Groups are supported. Type must be one of [Flow, FlowCount]. If left empty, all flows will be considered regardless of if a Mode is used. To specifically constrain against flows that do not use a Mode, enter a value of 'None'",
            precision_category=["NaN"],
            master_column=["TransportationModes.ModeName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ModeNameGroupBehavior",
            data_type=GroupBehavior,
            default_value="Aggregate",
            explanation="If Mode Name is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this Variable will be created for each member of the Group. If Aggregate is selected, the flow in the constraint will be summed over the members of the Group. If you are using multiple terms for a variable, a group behavior entry of enumerate is only supported for one term. Having multiple terms with enumerations is not currently supported.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WorkCenterName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required_if="Type = WorkCenterCount",
            master_table=["WorkCenters"],
            expandable=True,
            default_value="ALL",
            explanation="The relevant Work Center. Groups are supported. Type must be one of [WorkCenterCount]. If left empty, all productions will be considered regardless of if a Work Center is used. To specifically constrain against productions that do not use a Work Center, enter a value of 'None'",
            precision_category=["NaN"],
            master_column=["WorkCenters.WorkCenterName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WorkCenterNameGroupBehavior",
            data_type=GroupBehavior,
            default_value="Aggregate",
            explanation="If Work Center Name is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this Variable will be created for each member of the Group. If Aggregate is selected, the flow in the constraint will be summed over the members of the Group. If you are using multiple terms for a variable, a group behavior entry of enumerate is only supported for one term. Having multiple terms with enumerations is not currently supported.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BOMName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["BillsOfMaterials"],
            expandable=True,
            default_value="ALL",
            explanation="The relevant Bill(s) of Material. Groups are supported. Type must be one of [Production, ProductionCount]. If left empty, all productions will be considered regardless of if a BOM is used. To specifically constrain against productions that do not use a BOM, enter a value of 'None'",
            precision_category=["NaN"],
            master_column=["BillsOfMaterials.BOMName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BOMNameGroupBehavior",
            data_type=GroupBehavior,
            default_value="Aggregate",
            explanation="If BOM Name is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this Variable will be created for each member of the Group. If Aggregate is selected, the flow in the constraint will be summed over the members of the Group. If you are using multiple terms for a variable, a group behavior entry of enumerate is only supported for one term. Having multiple terms with enumerations is not currently supported.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProcessName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required_if="Type = Production OR ProductionCount",
            master_table=["Processes"],
            expandable=True,
            default_value="ALL",
            explanation="The relevant Process. Groups are supported. Type must be one of [Production, ProductionCount]. If left empty, all productions will be considered regardless of if a Process is used. To specifically constrain against productions that do not use a Process, enter a value of 'None'",
            precision_category=["NaN"],
            master_column=["Processes.ProcessName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProcessNameGroupBehavior",
            data_type=GroupBehavior,
            default_value="Aggregate",
            explanation="If Process Name is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this Variable will be created for each member of the Group. If Aggregate is selected, the flow in the constraint will be summed over the members of the Group. If you are using multiple terms for a variable, a group behavior entry of enumerate is only supported for one term. Having multiple terms with enumerations is not currently supported.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            master_table=["Periods"],
            expandable=True,
            default_value="ALL",
            explanation="The relevant Period(s). Groups are supported. Type must be one of [Flow, Production, Inventory, FlowCount, ProductionCount, FacilityCount, InventoryCount, WorkCenterCount].",
            precision_category=["NaN"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PeriodNameGroupBehavior",
            data_type=GroupBehavior,
            default_value="Aggregate",
            explanation="If Period Name is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this Variable will be created for each member of the Group. If Aggregate is selected, the flow in the constraint will be summed over the members of the Group. If you are using multiple terms for a variable, a group behavior entry of enumerate is only supported for one term. Having multiple terms with enumerations is not currently supported.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConsideredInventory",
            data_type=ConsideredInventory,
            required_if="Type = Inventory",
            default_value="Prebuild Only",
            explanation="The type of inventory that is to be considered when applying the constraint. Prebuild inventory is restricted based on the Ending Prebuild Inventory, and Cycle Inventory is restricted based on the total of Average Turn Estimated Inventory, Average Transportation Estimated Inventory and Average Production Estimated Inventory.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CountingRule",
            data_type=CountingRule,
            required_if="Type = FlowCount OR InventoryCount OR ProductionCount OR FacilityCount OR WorkCenterCount",
            explanation="Facilities: Count the number of unique facilities for Inventory Count, Production Count, Facility Count\nOrigins: Count the number of unique Origins for Flow Count\nDestinations: Count the number of unique Destinations for Flow Count\nProducts: Count the number of unique products for Flow Count, Production Count, Inventory Count\nModes: Count the number of unique modes for Flow Count\nWorkCenters: Count the number of unique Work Centers for Work Center Count\nBOMs: Count the number of unique BOMs for Production Count\nProcesses: Count the number of unique Processes for Production Count\nWorkCenters: Count the number of unique work centers for WorkCenter Count\nPeriods: Count the number of unique periods for Flow Count, Inventory Count, Production Count, Facility Count, Work Center Count\nOrigins-Destinations: Count the number of unique Origin-Destination combinations on which flow occurs for the specified Mode/Product/Period combination.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
