"""FixedRoutesDefinitions table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, Status, TechnologySupport

# FixedRoutesDefinitions table schema
fixed_routes_definitions = Table(
    table_name="FixedRoutesDefinitions",
    neo=TechnologySupport.FULLY_SUPPORTED,
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="FixedRoutesDefinitions",
    in_database=True,
    fields=[
        Column(
            column_name="FixedRouteName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["FixedRoutes"],
            explanation="The name of the fixed route that the stop is associated with",
            precision_category=["NaN"],
            master_column=["FixedRoutes.FixedRouteName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SiteName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            pk=True,
            master_table=["Customers", "Facilities"],
            explanation="The location of the stop for the fixed route, this can be a Facility or a Customer.",
            precision_category=["NaN"],
            master_column=["Customers.CustomerName", "Facilities.FacilityName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StopNumber",
            data_type=DataType.INTEGER,
            validation_type="NonNegative",
            explanation="The stop number within the fixed route for the specified site name",
            precision_category=["Time"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the stop exists in the route. If Status is set to Exclude, the stop is ignored during the model run.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
