"""TransportationStopRates table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, Status, TechnologySupport

# TransportationStopRates table schema
transportation_stop_rates = Table(
    table_name="TransportationStopRates",
    hopper=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="TransportationStopRates",
    fixed_tags=["Transport"],
    in_database=True,
    fields=[
        Column(
            column_name="TransportationStopRateName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the Transportation Stop Rate. This value can be referenced in the Transportation Assets table.",
            precision_category=["NaN"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SiteName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            pk=True,
            master_table=["Facilities", "Customers"],
            expandable=True,
            default_value="ALL",
            explanation="The location of the stop where these costs will be applied",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName", "Customers.CustomerName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the rate exists in the model.",
            precision_category=["NaN"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FixedPickupCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [All Item, Incremental]",
            master_table=["StepCosts"],
            default_value="0",
            explanation="The fixed cost incurred for a pickup at this location.",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FixedDeliveryCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [All Item, Incremental]",
            master_table=["StepCosts"],
            default_value="0",
            explanation="The fixed cost incurred for a delivery at this location.",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnitPickupCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [All Item, Incremental]",
            master_table=["StepCosts"],
            default_value="0",
            explanation="The unit cost associated with product picked up at this location. This field can support a single numeric value, a step cost lookup (defined in the Step Costs table).",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnitPickupCostUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="UnitPickupCost",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines the basis on which UnitPickupCost will be applied. Quantity, Volume, and Weight units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnitDeliveryCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [All Item, Incremental]",
            master_table=["StepCosts"],
            default_value="0",
            explanation="The unit cost associated with product delivered at this location. This field can support a single numeric value, a step cost lookup (defined in the Step Costs table).",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnitDeliveryCostUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="UnitDeliveryCost",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines the basis on which UnitDeliveryCost will be applied. Quantity, Volume, and Weight units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
