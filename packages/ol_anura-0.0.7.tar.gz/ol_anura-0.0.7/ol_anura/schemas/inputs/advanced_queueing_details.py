"""AdvancedQueueingDetails table schema definition."""

import sys
from pathlib import Path
from enum import Enum

from ...core import DataType, Column, Table, Status, TechnologySupport


class QueueDirection(str, Enum):
    """QueueDirection values."""
    INBOUND = "Inbound"
    OUTBOUND = "Outbound"

# AdvancedQueueingDetails table schema
advanced_queueing_details = Table(
    table_name="AdvancedQueueingDetails",
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="AdvancedQueueingDetails",
    in_database=True,
    fields=[
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            pk=True,
            master_table=["Facilities"],
            explanation="The Facility at which the Queueing Priority is being defined for. Queues will occur on Work Centers, Transportation Lanes, Transportation Lane Modes, and for Order Fulfillments. In all of these instances, we have the ability to select a Queueing Priority Logic that has Location as a part of the priority. Queue Priorities are specified in the Customers, Facilities and Suppliers tables but these will be overwritten by the priorities specified in this table.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName"],
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            pk=True,
            master_table=["Products"],
            explanation="The Product Name for which the Queueing Priority is being defined for. For Transportation Lane and Transportation Lane Mode queues, the key structure of Origin / Destination / Product Name in the Transportation Policies table must match exactly with the Facility / Target Location / Product Name in the Advanced Queueing Priority table",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            in_database=True
        ),
        Column(
            column_name="QueueDirection",
            data_type=QueueDirection,
            pk=True,
            explanation="Queue Direction specifies whether or not the queue at being applied at the Facility / Product combination is inbound or outbound. For example, if an unload process was used as for a Facility / Product combination we would classify this as an Inbound Queue, and could set the priority for which Target Locations (Origins) would be handled first. If we wanted to control the Outbound Queue for the same Facility / Product combination we could set a separate priority for outbound flow to distinct Target Locations (Destinations).",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="TargetLocation",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            pk=True,
            master_table=["Customers", "Facilities", "Suppliers"],
            explanation="The Target Location will represent either the Origin or Destination depending on whether the Queue Direction is set to Inbound or Outbound.",
            precision_category=["NaN"],
            master_column=["Customers.CustomerName", "Facilities.FacilityName", "Suppliers.SupplierName"],
            in_database=True
        ),
        Column(
            column_name="TargetLocationQueuePriority",
            data_type=DataType.INTEGER,
            explanation="The Queue Priority entered here will override the Priority value that was set in the Customers, Facilities, or Suppliers table. Priorities will be evaluated with 1 being the highest priority.",
            precision_category=["Integer"],
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the multi-time period record exists in the model. If Status is set to Exclude, the record is ignored during the model run.",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="TimeInQueueCost",
            data_type=DataType.DOUBLE,
            explanation="The cost associated with an item sitting in a queue. The cost expressed in this field will be charged each time that items sit in a queue for the length of time specified in the Time In Queue Cost UOM field.",
            precision_category=["Cost"],
            in_database=True
        ),
        Column(
            column_name="TimeInQueueCostUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required_if="TimeInQueueCost",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure that time is expressed in terms of.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            in_database=True
        ),
    ]
)
