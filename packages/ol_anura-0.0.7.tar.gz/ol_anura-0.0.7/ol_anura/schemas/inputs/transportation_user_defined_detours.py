"""TransportationUserDefinedDetours table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, Status

# TransportationUserDefinedDetours table schema
transportation_user_defined_detours = Table(
    table_name="TransportationUserDefinedDetours",
    abbreviated_name="TransportationUserDefDetours",
    fixed_tags=["Transport"],
    in_database=True,
    fields=[
        Column(
            column_name="DetourName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name assigned to the Detour.",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="SiteName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Facilities", "Customers"],
            expandable=True,
            default_value="ALL",
            explanation="The site that the detour will cause the asset to travel to. Facilities and Customers are supported.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName", "Customers.CustomerName"],
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the detour is considered in the solve.",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            in_database=True
        ),
    ]
)
