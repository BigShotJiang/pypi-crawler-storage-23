"""FacilitiesMultiTimePeriod table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, FacilityStatus, Status, TechnologySupport

# FacilitiesMultiTimePeriod table schema
facilities_multi_time_period = Table(
    table_name="FacilitiesMultiTimePeriod",
    neo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="FacilitiesMTP",
    fixed_tags=["Facilities", "Facility", "Policies", "Multi", "Time", "Period"],
    in_database=True,
    fields=[
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Periods"],
            expandable=True,
            explanation="The period name in which a change is being made. Groups of periods are also supported. Changes that are made in the Multi Time Period table will be applied as overrides for the records of the base table for the specified periods only. Additionally, only the fields that contain information needing to be updated are required to be entered, in the absence of data in the Multi Time Period table the data from the standard table will be persisted",
            precision_category=["NaN"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Facilities"],
            expandable=True,
            explanation="The name of the Facility",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the multi-time period record exists in the model. If Status is set to Exclude, the record is ignored during the model run.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityStatus",
            data_type=FacilityStatus,
            explanation="Facility Status dictates whether or not the Facility is included in the model for the specified period(s). If Status is set to Consider, the Facility may either be opened (Initial State = Potential) or closed (Initial State = Existing) depending on what is optimal. If the Facility is excluded from the model, any records for this Facility in other tables will also be ignored.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FixedStartupCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [Stepwise]",
            master_table=["StepCosts"],
            notes="Currently supports doubles and named step costs that are defined in the StepCosts table where StepCostBehavior = Stepwise",
            explanation="If Status = Consider and Initial State = Potential, the Fixed Startup Cost will be incurred if the Facility is opened during the model solve. No startup cost will be incurred if the facility already exists. Fixed Startup Cost may be a single value or a step function of the Facility's throughput. If a step function is used, this cost will be determined based on the largest throughput recorded in any of the periods for which the Facility will be operating once opened.",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FixedOperatingCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [Stepwise]",
            master_table=["StepCosts"],
            notes="Currently supports doubles and named step costs that are defined in the StepCosts table where StepCostBehavior = Stepwise",
            explanation="The fixed cost associated with operating the Facility; Fixed Operating Cost may be a single value or a step function of the Facility's throughput. If a step function is used, this cost will be determined using the total throughput over each period. Step costs can be defined in the Step Costs table and referenced by name here.",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FixedClosingCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [Stepwise]",
            master_table=["StepCosts"],
            notes="Currently supports doubles and named step costs that are defined in the StepCosts table where StepCostBehavior = Stepwise",
            explanation="If Status = Consider and Initial State = Existing, the Fixed Closing Cost will be incurred if the Facility is closed during the model solve. Fixed Closing Cost may be a single value or a step function of the Facility's throughput. If a step function is used, this cost will be determined based on the largest throughput recorded in any of the periods for which the Facility was operating. Step costs can be defined in the Step Costs table and referenced by name here.",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StorageCapacity",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="This value indicates the total storage capacity (across products) of the Facility for the specified periods. Total Storage is measured as the Ending Inventory Product-specific capacities can be modeled using inventory constraints.",
            precision_category=["Quantity"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StorageCapacityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="StorageCapacity",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure used to define the Storage Capacity of the Facility. Quantity, weight, and volume units of measure defined in the Units Of Measure table are accepted.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ThroughputCapacity",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="This value indicates the total allowable throughput (across products) of the Facility over the specified period(s). Product-specific limits can be modeled using flow constraints.",
            precision_category=["Quantity"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ThroughputCapacityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="ThroughputCapacity",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure used to define the Throughput Capacity of the Facility. Quantity, weight, and volume units of measure defined in the Units Of Measure table are accepted.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ThroughputCapacityPeriod",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="For Simulation runs, this field will specify the length of time over which the throughput capacity will be applied. For example, the Throughput Capacity might be set to 500 EA with Capacity Period = 1 and Capacity Period UOM = DAY - this would mean that the Facility could process no more than 500 units in any day. The first period will be evaluated at the Simulation Start Time, and throughput capacity will be evaluated over the specified period length. Capacity is evaluated over individual capacity periods, a rolling capacity is not considered.",
            precision_category=["Time"],
            in_database=True
        ),
        Column(
            column_name="ThroughputCapacityPeriodUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Time]",
            required_if="ThroughputCapacityPeriod",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure (Type = Time) that defines Throughput Capacity Period.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="SingleSource",
            data_type=bool,
            explanation="If True, the Facility can only receive inbound product from a single source.",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="SingleSourceOrders",
            data_type=bool,
            explanation="If True, every order placed at the Facility must be satisfied from a single source.",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="SingleSourceLineItems",
            data_type=bool,
            explanation="If True, each line item in an order must come from a single source. Otherwise, a line item may be satisfied by multiple sources.",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="AllowBackorders",
            data_type=bool,
            explanation="If True, the Facility accepts backorders in the event that an order cannot be fulfilled before the Order Due Date (defined in the Replenishment Orders and Procurement Orders tables).",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="BackorderTimeLimit",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="This value is the amount of time after which unsatisfied backorders will be cancelled by the Facility. A value of NULL will be interpreted as an infinite time limit, while a value of 0 is equivalent to setting Allow Backorders = False.",
            precision_category=["Time"],
            in_database=True
        ),
        Column(
            column_name="BackorderTimeUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Time]",
            required_if="BackorderTimeLimit",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure used to define the Backorder Time Limit. Any of the time units of measure defined in the Units Of Measure table can be used here.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="AllowPartialFillOrders",
            data_type=bool,
            explanation="If True, orders placed by the Facility may be partially filled. Otherwise, orders must be filled in full. The remaining quantity of partially filled orders may be satisfied in the future with additional shipments; if the Backorder Time Limit is reached on a partially filled order, the remaining quantity will be cancelled.",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="AllowPartialFillLineItems",
            data_type=bool,
            explanation="If True, line items within orders placed by the Facility may be partially filled. Otherwise, line items must be filled in full. The remaining quantity of partially filled line items may be satisfied in the future with additional shipments; if the Backorder Time Limit is reached on a partially filled line item, the remaining quantity will be cancelled.",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="OperatingSchedule",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["BusinessHours"],
            explanation="The schedule (defined in the Business Hours table) dictating when the Facility will be open for business. If no schedule is specified, the Facility is assumed to be open 24 hours per day.",
            precision_category=["NaN"],
            master_column=["BusinessHours.ScheduleName"],
            in_database=True
        ),
        Column(
            column_name="OperatingCalendar",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["BusinessCalendars"],
            explanation="The calendar (defined in the Business Calendars table) dictating which days of the year the Facility will shut down. If no calendar is specified, the Facility is assumed not to shut down.",
            precision_category=["NaN"],
            master_column=["BusinessCalendars.CalendarName"],
            in_database=True
        ),
        Column(
            column_name="QueuePriority",
            data_type=DataType.INTEGER,
            explanation="For any Queues that are evaluated with a Queueing Priority Logic, there can be a By Location component to the priority logic used. If By Location is used, The Queue Priority fields in the Customers, Facilities and Suppliers table will be used to determine how the queues will be ordered",
            precision_category=["Integer"],
            in_database=True
        ),
        Column(
            column_name="FixedCO2Emissions",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="The fixed amount of CO2 Emissions at this Facility for the given period. This can be thought of as the amount of CO2 that needs to be offset for the facility to exist in the network. Variable CO2 Emissions can be defined for specific production or transportation activities in the Production Policy and Transportation Policy tables.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
