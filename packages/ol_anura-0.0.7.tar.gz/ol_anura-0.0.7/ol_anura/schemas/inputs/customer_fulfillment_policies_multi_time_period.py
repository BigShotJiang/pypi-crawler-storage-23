"""CustomerFulfillmentPoliciesMultiTimePeriod table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, PolicyStatus, Status, TechnologySupport
from .customer_fulfillment_policies import OptimizationPolicy, SimulationPolicy

# CustomerFulfillmentPoliciesMultiTimePeriod table schema
customer_fulfillment_policies_multi_time_period = Table(
    table_name="CustomerFulfillmentPoliciesMultiTimePeriod",
    neo=TechnologySupport.FULLY_SUPPORTED,
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="CustomerFulfillmentPoliciesMTP",
    in_database=True,
    fields=[
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Periods"],
            expandable=True,
            explanation="The period name in which a change is being made. Groups of periods are also supported. Changes that are made in the Multi Time Period table will be applied as overrides for the records of the base table for the specified periods only. Additionally, only the fields that contain information needing to be updated are required to be entered, in the absence of data in the Multi Time Period table the data from the standard table will be persisted",
            precision_category=["NaN"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CustomerName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Customers"],
            expandable=True,
            explanation="The Customer that the policy record applies to.",
            precision_category=["NaN"],
            master_column=["Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Products"],
            expandable=True,
            explanation="The Product (or Product group) that the policy record applies to.",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SourceName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Facilities", "Suppliers", "Sources"],
            expandable=True,
            explanation="The source Facility or Supplier (Groups are also supported) that the policy record applies to.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the multi-time period record exists in the model. If Status is set to Exclude, the record is ignored during the model run.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PolicyStatus",
            data_type=PolicyStatus,
            explanation="Policy Status dictates whether or not the policy exists in the model for the specified period(s). If Policy Status is set to Exclude, the policy record is ignored during the model run for the specified periods.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OptimizationPolicy",
            data_type=OptimizationPolicy,
            explanation="The logic that order fulfillments for the Customer, Product, and Source combination(s) must follow. To Optimize selects the lowest cost option. By Ratio (Auto Scale) will enforce a flow split between the specified sources, the defined ratios will apply to flow into the customer from the listed sources only. By Ratio (No Scale) will enforce a flow split between the specified sources and the defined ratios will be in terms of the total inbound flow into the Customer. Single Source policies force the Customer to receive the Product from one Source. Note that if a group is used in the Period Name, Customer Name, Product Name, or Source Name field that the groups will be enumerated and the policy logic will be applied over the enumerated entries.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OptimizationPolicyValue",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            required_if="OptimizationPolicy = By Ratio (Auto Scale) OR By Ratio (No Scale)",
            explanation="By Ratio (Auto Scale): The Policy Value will define the percentage of flow that must be satisfied from the listed source. The percentage will be calculated based on the total inbound flow for the customer/product combination and enforced proportionally across the sources with a policy of By Ratio (Auto Scale).\n\nBy Ratio (No Scale): The Policy Value will define the percentage of flow that must be satisfied from the listed source. The percentage will be calculated based on the total inbound flow for the customer/product combination  and enforced over the listed sources. If the Policy Values add up to less than 100, the remainder of unaccounted flow can be sourced from any other viable lane. If the Policy Values add up to more than 100, they will be scaled to 100 and enforced the same as Auto Scale.",
            precision_category=["Percentage"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SimulationPolicy",
            data_type=SimulationPolicy,
            explanation="The logic that order assignment flows for the Customer, Product, and Source combination(s) must follow. By Preference will pick the sources pending product availability in the specified order of preference. Single Source policies force the Customer to receive the Product from one Source. Allocation will source as much as possible from the sources based on availability in the specified order of preference - this is similar to By Preference but the Allocation policy will not attempt to keep orders together from a single source. By Distance will select the closest source using straight-line distances.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SimulationPolicyValue",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            required_if="SimulationPolicy = By Preference",
            explanation="By Preference: Policy Value defines the order of preference in which a source will be selected pending product availability, with the lower numbers representing a higher selection preference. Allocation: Policy value defines the order in which sources will be selected.",
            precision_category=["Percentage"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnitCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [All Item, Incremental, Stepwise]",
            master_table=["StepCosts"],
            notes="Currently supports doubles and named step costs that are defined in the StepCosts table where StepCostBehavior = All Item, Incremental or Stepwise or a combination of Stepwise and All Item",
            explanation="The cost incurred per unit of flow for the specified Source/Customer/Product combination.",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnitCostUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="UnitCost",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines flow for the Source/Customer/Product combination.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MinimumOrderQuantity",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="The minimum quantity that must move between source and destination in a period for a flow to occur",
            precision_category=["Quantity"],
            in_database=True
        ),
        Column(
            column_name="MinimumOrderQuantityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="MinimumOrderQuantity",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines the MOQ for the Source/Customer/Product combination.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="LotSize",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="Orders placed from the Customer to the specified sources must be filled in multiples of the specified lot size.",
            precision_category=["Quantity"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="LotSizeUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="LotSize",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines the Lot Size for the Source/Customer/Product combination.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MaxSourcingRange",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="The maximum allowable distance between Customer and Source for the Product(s) specified. This field is intended for use in models with group policies to eliminate excessively long lanes from consideration. If all sources exceed the max sourcing range for a Customer-Product pairing, the closest source will be kept by default - this behavior can be overwritten through the Keep Closest Lane For Max Sourcing Distance run option.",
            precision_category=["Distance"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MaxSourcingRangeUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Distance]",
            required_if="MaxSourcingRange",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Distance"],
            default_value="{PrimaryDistanceUOM}",
            explanation="The unit of measure (Type = Distance) that defines Max Delivery Range.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OnlySourceFromSurplus",
            data_type=bool,
            explanation="If True, when selecting a source for the Customer / Product combination only sources that have available surplus can be selected to fulfill the order.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
