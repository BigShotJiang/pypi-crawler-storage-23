"""WorkResources table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, Status, TechnologySupport

# WorkResources table schema
work_resources = Table(
    table_name="WorkResources",
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="WorkResources",
    in_database=True,
    fields=[
        Column(
            column_name="WorkResourceName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the Work Resource.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Facilities"],
            expandable=True,
            explanation="The Facility at which the Work Resource will be located. If a Facility Group is used, identical Work Resources will be associated with each Facility in the Group.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AvailableUnits",
            data_type=DataType.INTEGER,
            validation_type="NonNegative",
            explanation="The units of the Work Resource available at the specified Facility. If left blank, an infinite amount of resources will be assumed",
            precision_category=["Integer"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the Work Resource is included in the model. If Status is set to Consider, the Work Resource may either be included (Type = Potential) or excluded (Type = Existing) depending on what is optimal. If the Work Resource is excluded from the model, it will be dropped from Routing records that reference it.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Capacity",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="The capacity of the Work Center (throughput or time). This Capacity applies to the entire model horizon; period-specific capacities can be defined in the Work Centers Multi Time Period table.",
            precision_category=["Quantity"],
            in_database=True
        ),
        Column(
            column_name="CapacityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="Capacity",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines Throughput Capacity. Quantity, Volume, Weight, and Time units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="UnitCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [All Item, Incremental]",
            master_table=["StepCosts"],
            default_value="0",
            explanation="The cost associated with completing one unit of work using the Work Resource.",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName"],
            in_database=True
        ),
        Column(
            column_name="UnitCostUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight, Time]",
            required_if="UnitCost",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight", "Time"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines Unit Cost. Quantity, Volume, Weight, and Time units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="FixedOperatingCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [Stepwise]",
            master_table=["StepCosts"],
            default_value="0",
            explanation="The fixed cost associated with operating the Work Resource. This field can support a single numeric value or a step cost (entered directly or a lookup of a record in the Step Costs table). If a step cost is used, the Work Resource's throughput for the entire model horizon will be used to determine Fixed Operating Cost. Period-specific costs can be defined in the Work Centers Multi Time Period table.",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName"],
            in_database=True
        ),
        Column(
            column_name="OperatingSchedule",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["BusinessHours"],
            explanation="The schedule (defined in the Business Hours table) dictating when the Work Resource will be operational. If no schedule is specified, the Work Center is assumed to operate 24 hours per day.",
            precision_category=["NaN"],
            master_column=["BusinessHours.ScheduleName"],
            in_database=True
        ),
        Column(
            column_name="OperatingCalendar",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["BusinessCalendars"],
            explanation="The calendar (defined in the Business Calendars table) dictating which days of the year the Work Resource will shut down. If no calendar is specified, the Work Resource is assumed to be operational every day.",
            precision_category=["NaN"],
            master_column=["BusinessCalendars.CalendarName"],
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
