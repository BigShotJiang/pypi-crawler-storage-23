"""ModelInfo table schema definition."""

import sys
from pathlib import Path
from enum import Enum

from ...core import DataType, Column, Table, TechnologySupport


class DataModel(str, Enum):
    """DataModel values."""
    ANURA = "ANURA"
    TADPOLE = "Tadpole"

# ModelInfo table schema
model_info = Table(
    table_name="ModelInfo",
    neo=TechnologySupport.FULLY_SUPPORTED,
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    triad=TechnologySupport.FULLY_SUPPORTED,
    dart=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="ModelInfo",
    in_database=True,
    fields=[
        Column(
            column_name="ModelName",
            data_type=DataType.STRING,
            explanation="The model name",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ModelDescription",
            data_type=DataType.STRING,
            explanation="The model description",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Tags",
            data_type=DataType.STRING,
            explanation="The tags for this model",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Image",
            data_type=DataType.STRING,
            explanation="The image for this model",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DataModel",
            data_type=DataModel,
            explanation="The data model for this model",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DataModelVersion",
            data_type=DataType.STRING,
            explanation="The data model version for this model",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CreatedBy",
            data_type=DataType.STRING,
            explanation="The author of this model",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CreatedDate",
            data_type=DataType.DATETIME,
            explanation="The creation date of this model",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UpgradeDate",
            data_type=DataType.DATETIME,
            explanation="The upgrade date of this model",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
