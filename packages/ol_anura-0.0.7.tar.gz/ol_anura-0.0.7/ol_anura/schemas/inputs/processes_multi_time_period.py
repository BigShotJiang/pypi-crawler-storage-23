"""ProcessesMultiTimePeriod table schema definition."""

import sys
from pathlib import Path
from enum import Enum

from ...core import DataType, Column, Table, FixedCostRule, Status, TechnologySupport


class ProcessStepStatus(str, Enum):
    """ProcessStepStatus values."""
    EXCLUDE = "Exclude"
    INCLUDE = "Include"

# ProcessesMultiTimePeriod table schema
processes_multi_time_period = Table(
    table_name="ProcessesMultiTimePeriod",
    neo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="ProcessesMTP",
    fixed_tags=["Multi", "Time", "Period"],
    in_database=True,
    fields=[
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Periods"],
            expandable=True,
            explanation="The period name in which a change is being made. Groups of periods are also supported. Changes that are made in the Multi Time Period table will be applied as overrides for the records of the base table for the specified periods only. Additionally, only the fields that contain information needing to be updated are required to be entered, in the absence of data in the Multi Time Period table the data from the standard table will be persisted",
            precision_category=["NaN"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProcessName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Processes"],
            expandable=True,
            explanation="The name of the Process; Processes are a single path of sequential processing steps that can be used to describe Production, Inbound/Outbound Warehousing, and Inbound/Outbound Transportation behavior.",
            precision_category=["NaN"],
            master_column=["Processes.ProcessName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StepName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the Process Step being defined; each Step can have its own unit cost, processing time, component consumption, and byproduct production details.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the multi-time period record exists in the model. If Status is set to Exclude, the record is ignored during the model run.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProcessStepStatus",
            data_type=ProcessStepStatus,
            explanation="Process Step Status dictates whether or not the policy exists in the model for the specified period(s). If Process Step Status is set to Exclude, the Process Step will be  ignored during the model run for the specified period(s).",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StepNumber",
            data_type=DataType.INTEGER,
            validation_type="NonNegative",
            explanation="The position of the specified Step in the Process sequence.",
            precision_category=["Integer"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ComponentName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["Products"],
            explanation="The name of the Component (optional) consumed at the specified Process Step; at most one Component can be associated with each Step. If a BOM is associated with the specified Routing via a production policy but consumption of a BOM Component is not specified in a Process Step, the Component will be consumed during the first Process Step. A Component may be consumed during a Process Step without explicitly being required by a BOM.",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            in_database=True
        ),
        Column(
            column_name="ComponentQuantity",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="The amount of the Component consumed during the Process Step. If a BOM is associated with the Process via a production policy and the Component is a member of the BOM, this amount will be compared to the Component's required amount in the BOM. In the event that the total amount of the Component consumed across all Steps of the Process is less than the BOM requirement, the difference will be consumed at the first Step of the Process. Otherwise, the Component Quantity specified at each Step will be consumed accordingly.",
            precision_category=["Quantity"],
            in_database=True
        ),
        Column(
            column_name="ComponentQuantityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="ComponentQuantity",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines Component Quantity. Quantity, Volume, and Weight units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="ByproductName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["Products"],
            explanation="The name of the Byproduct (optional) produced at the specified Process Step; at most one Byproduct can be associated with each Step. If a BOM is associated with the specified Process via a production policy but production of a Byproduct is not specified in a Process Step, the Byproduct will be produced during the final Process Step. A Byproduct may be produced during a Process Step without explicitly being specified in a BOM.",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            in_database=True
        ),
        Column(
            column_name="ByproductQuantity",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="The amount of the Byproduct produced during the Process Step. If a BOM is associated with the Process via a production policy and the Byproduct is a member of the BOM, this amount will be compared to the Byproduct's amount in the BOM. In the event that the total amount of the Byproduct produced across all Steps of the Process is less than the BOM requirement, the difference will be produced at the final Step of the Process. Otherwise, the Byproduct Quantity specified at each Step will be consumed accordingly.",
            precision_category=["Quantity"],
            in_database=True
        ),
        Column(
            column_name="ByproductQuantityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="ByproductQuantity",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines Byproduct Quantity. Quantity, Volume, and Weight units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="EndProductName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["Products"],
            explanation="The name of the End Product that will be introduced as the result of the Process Step.",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            in_database=True
        ),
        Column(
            column_name="EndProductQuantity",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="The amount of the End Product that is introduced as the result of the specified Process Step.",
            precision_category=["Quantity"],
            in_database=True
        ),
        Column(
            column_name="EndProductQuantityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="EndProductQuantity",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines End Product Quantity. Quantity, Volume, and Weight units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="WorkCenterName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["WorkCenters"],
            default_value="None",
            notes="Optimization: Currently supports single WorkCenter entries, WorkCenter groups are not supported",
            explanation="The Work Center assigned to the Process Step; the processing time and capacity consumed by the Process Step will count toward the capacity of the Work Center. Work Center Groups are not supported.",
            precision_category=["NaN"],
            master_column=["WorkCenters.WorkCenterName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WorkResourceName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["WorkResources"],
            default_value="None",
            explanation="The Work Resource assigned to the Process Step; the processing time and capacity consumed by the Process Step will count toward the capacity of the Work Resource. If a Work Resource Group is entered into this field, the Process will be created for each group member (i.e., the group behavior will be Enumerate).",
            precision_category=["NaN"],
            master_column=["WorkResources.WorkResourceName"],
            in_database=True
        ),
        Column(
            column_name="ProcessingRate",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="The production rate for the given Process Step. It will be defined as Quantity/Time as is specified in the Quantity/Time UOM fields. If there are is a production rate defined in the Production Policies table where the Routing is called, the information in the Process table will override any information that exists in the Production Policies table",
            precision_category=["Quantity"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RateQuantityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="ProcessingRate",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The UOM that defines the number of units that the Production Rate is expressed in. This can be any UOM of Type = Quantity, Weight, Volume.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RateTimeUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Time]",
            required_if="ProcessingRate",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The UOM that defines the amount of time that the Production Rate is expressed in. This can be any UOM of Type = Time.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnitCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [All Item, Incremental, Stepwise]",
            master_table=["StepCosts"],
            notes="Optimization: Currently supports doubles and named step costs that are defined in the StepCosts table where StepCostBehavior = All Item, Incremental or Stepwise or a combination of Stepwise and All Item",
            explanation="The cost associated with each unit of flow that undergoes the specified Process Step. This field can support a single numeric value, a step cost lookup (defined in Step Costs), or a custom cost function.",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnitCostUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="UnitCost",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines Unit Cost. Quantity, Volume, and Weight units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FixedTime",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="NonNegative",
            notes="Optimization: Currently supports doubles",
            explanation="The fixed time that is applied if the Process is used. This is how NEO will apply the concept of Changeover Time",
            precision_category=["Time"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FixedTimeUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Time]",
            required_if="FixedTime",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure (Type = Time) that defines the Fixed Time",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FixedCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            master_table=["StepCosts"],
            notes="Optimization: Currently supports doubles and named step costs that are defined in the StepCosts table where StepCostBehavior = Stepwise",
            explanation="The fixed cost that is applied if the Process is used. This is how NEO will apply the concept of Changeover Costs",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FixedCostRule",
            data_type=FixedCostRule,
            default_value="Prorate",
            explanation="The rule by which Fixed Cost is applied to the estimated number of lots. The cost can be prorated in the event that the estimated number of lots is not an integer. If the selected rule is Treat as Full, the estimated number of lots will be rounded up and the fixed cost will be applied accordingly.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="LotSize",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="The Lot Size for the Process Step",
            precision_category=["Quantity"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="LotSizeUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="LotSize",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines the Lot Size. Quantity, Volume, and Weight units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="YieldPercentage",
            data_type=DataType.DOUBLE,
            validation_type="Percentage",
            explanation="The yield percentage of the Process Step, if the field is left as null it will be assumed that the Yield is 100% and there is no loss",
            precision_category=["Percentage"],
            in_database=True
        ),
        Column(
            column_name="CO2EmissionRate",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="NonNegative",
            explanation="The rate of CO2 emissions for this process for the given period.",
            precision_category=["Cost"],
            in_database=True
        ),
        Column(
            column_name="CO2EmissionRateUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight, Time]",
            required_if="CO2EmissionRate",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight", "Time"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure (Type = Quantity, Volume, Weight, Time) that defines the CO2 Emission Rate.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
