"""TransportationAssetsMultiTimePeriod table schema definition."""

import sys
from pathlib import Path
from enum import Enum

from ...core import DataType, Column, Table, Status


class AssetStatus(str, Enum):
    """AssetStatus values."""
    EXCLUDE = "Exclude"
    INCLUDE = "Include"

# TransportationAssetsMultiTimePeriod table schema
transportation_assets_multi_time_period = Table(
    table_name="TransportationAssetsMultiTimePeriod",
    abbreviated_name="TransportationAssetsMTP",
    fixed_tags=["Multi", "Time", "Period"],
    in_database=True,
    fields=[
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Periods"],
            expandable=True,
            explanation="The period name in which a change is being made. Groups of periods are also supported. Changes that are made in the Multi Time Period table will be applied as overrides for the records of the base table for the specified periods only. Additionally, only the fields that contain information needing to be updated are required to be entered, in the absence of data in the Multi Time Period table the data from the standard table will be persisted",
            precision_category=["NaN"],
            master_column=["Periods.PeriodName"],
            in_database=True
        ),
        Column(
            column_name="AssetName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            master_table=["TransportationAssets"],
            explanation="The name of the Transportation Asset. This value can be referenced in other tables involving Transportation Assets.",
            precision_category=["NaN"],
            master_column=["TransportationAssets.AssetName"],
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the multi-time period record exists in the model. If Status is set to Exclude, the record is ignored during the model run.",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="AssetStatus",
            data_type=AssetStatus,
            explanation="Asset Status dictates whether or not the policy exists in the model for the specified period(s). If Asset Status is set to Exclude, the policy record is ignored during the model run.",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="AvailableUnits",
            data_type=DataType.INTEGER,
            validation_type="NonNegative",
            explanation="The units of this Asset that are available at the specified Base Location.",
            precision_category=["Integer"],
            in_database=True
        ),
        Column(
            column_name="DomicileLocation",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["Facilities"],
            explanation="The Facility at which the Asset is based. Units of this Asset will be located at the Base Location at the beginning of the model run.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName"],
            in_database=True
        ),
        Column(
            column_name="FixedCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [All Item, Incremental]",
            master_table=["StepCosts"],
            explanation="The one-time fixed cost incurred per unit of the Asset used in the model run.",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName"],
            in_database=True
        ),
        Column(
            column_name="UnitCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [All Item, Incremental]",
            master_table=["StepCosts", "TransportationBandCosting"],
            explanation="The unit cost associated with flow transported using the specified Asset. This field can support a single numeric value, a step cost lookup (defined in the Step Costs table), or a custom cost function. If a cost is entered on a record using this Asset in the Transportation Policies table, that cost will overwrite the one entered here.",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName", "TransportationBandCosting.RateName"],
            in_database=True
        ),
        Column(
            column_name="UnitCostUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight, Time, Distance, Quantity-Distance, Volume-Distance, Weight-Distance, Quantity-Time, Volume-Time, Weight-Time]",
            required_if="UnitCost",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight", "Time", "Distance", "Quantity-Distance", "Volume-Distance", "Weight-Distance", "Quantity-Time", "Volume-Time", "Weight-Time"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines Unit Cost. Quantity, Volume, Weight, Distance, Time, Quantity-Distance, Quantity-Time, Volume-Distance, Volume-Time, Weight-Distance, and Weight-Time units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="QuantityCapacity",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="The capacity (quantity) of the Asset. The most restrictive capacity given in this record (among quantity, volume, and weight) will be applied to the Asset.",
            precision_category=["Quantity"],
            in_database=True
        ),
        Column(
            column_name="QuantityCapacityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity]",
            required_if="QuantityCapacity",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure (Type = Quantity) that defines Quantity Capacity.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="QuantityFillLevel",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="The fill level of the Asset (quantity). Quantity Fill Level is the minimum quantity of items required for the Asset to depart.",
            precision_category=["Quantity"],
            in_database=True
        ),
        Column(
            column_name="QuantityFillLevelUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity]",
            required_if="QuantityFillLevel",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure (Type = Quantity) that defines Quantity Fill Level.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="VolumeCapacity",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="The capacity (volume) of the Asset. The most restrictive capacity given in this record (among quantity, volume, and weight) will be applied to the Asset.",
            precision_category=["Volume"],
            in_database=True
        ),
        Column(
            column_name="VolumeCapacityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Volume]",
            required_if="VolumeCapacity",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Volume"],
            default_value="{PrimaryVolumeUOM}",
            explanation="The unit of measure (Type = Volume) that defines Volume Capacity.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="VolumeFIllLevel",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="The fill level of the Asset (volume). Volume Fill Level is the minimum volume of items required for the Asset to depart.",
            precision_category=["Volume"],
            in_database=True
        ),
        Column(
            column_name="VolumeFillLevelUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Volume]",
            required_if="VolumeFillLevel",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Volume"],
            default_value="{PrimaryVolumeUOM}",
            explanation="The unit of measure (Type = Volume) that defines Volume Fill Level.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="WeightCapacity",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="The capacity (weight) of the Asset. The most restrictive capacity given in this record (among quantity, volume, and weight) will be applied to the Asset.",
            precision_category=["Weight"],
            in_database=True
        ),
        Column(
            column_name="WeightCapacityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Weight]",
            required_if="WeightCapacity",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Weight"],
            default_value="{PrimaryWeightUOM}",
            explanation="The unit of measure (Type = Weight) that defines Weight Capacity.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="WeightFillLevel",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="The fill level of the Asset (weight). Weight Fill Level is the minimum volume of items required for the Asset to depart.",
            precision_category=["Weight"],
            in_database=True
        ),
        Column(
            column_name="WeightFillLevelUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Weight]",
            required_if="WeightFillLevel",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Weight"],
            default_value="{PrimaryWeightUOM}",
            explanation="The unit of measure (Type = Weight) that defines Weight Fill Level.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="AssetWeight",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="NonNegative",
            allowable_uom_types=["Weight"],
            explanation="The weight of the transportation asset when empty. This weight is added to the weight of products being shipped by this asset and will be used for CO2 emission calculations.",
            precision_category=["Quantity"],
            in_database=True
        ),
        Column(
            column_name="AssetWeightUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Weight]",
            required_if="AssetWeight",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Weight"],
            default_value="{PrimaryWeightUOM}",
            explanation="The unit of measure of Type = Weight that the asset weight is defined in terms of.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="CO2EmissionRate",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="NonNegative",
            explanation="The rate of CO2 emissions for this transportation asset for the given period.",
            precision_category=["Cost"],
            in_database=True
        ),
        Column(
            column_name="CO2EmissionRateUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Distance, Quantity-Distance, Volume-Distance, Weight-Distance]",
            required_if="CO2EmissionRate",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Distance", "Quantity-Distance", "Volume-Distance", "Weight-Distance"],
            default_value="{PrimaryDistanceUOM}",
            explanation="The unit of measure (Type = Distance, Quantity-Distance, Volume-Distance, Weight-Distance) that defines the CO2 Emission Rate. If a UOM of Type = Distance is used, the total distance of the route will be used to calculate CO2 emissions. If weight-distance is used, the product of the total route distance and the total delivered shipment weight will be used.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            in_database=True
        ),
    ]
)
