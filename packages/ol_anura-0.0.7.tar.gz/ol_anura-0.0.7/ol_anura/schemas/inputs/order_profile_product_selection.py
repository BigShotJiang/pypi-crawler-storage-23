"""OrderProfileProductSelection table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# OrderProfileProductSelection table schema
order_profile_product_selection = Table(
    table_name="OrderProfileProductSelection",
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="OrderProfileProductSelection",
    in_database=True,
    fields=[
        Column(
            column_name="OrderID",
            data_type=DataType.STRING,
            pk=True,
            explanation="The Order ID as specified in any of the Order Profile tables for which the product selection likelihoods will apply. If left empty, the product selection details will apply over all order profiles.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PrimaryProduct",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            pk=True,
            master_table=["Products"],
            explanation="The product name that will be selected as the primary product. For Order Profiles that contain multiple lines, the primary product will be selected first and then draws will occur to fill the products of the remaining line items based on the likelihood of selection as defined in the OrderProfileProductAffinity table.",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SelectionPercentage",
            data_type=DataType.DOUBLE,
            validation_type="Percentage",
            explanation="The percentage chance that the listed product will be selected as the primary product for the order. When selecting a primary product, the SIM will generate a probability distribution for all possible primary products and will draw one product to be used as the primary product of the order.",
            precision_category=["Percentage"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OrderQuantity",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="The quantity of product to be ordered. If the Order Quantity was filled out in the Order Profile record, this quantity entry will be ignored.",
            precision_category=["Quantity"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OrderQuantityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines Quantity. Quantity, Volume, and Weight units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OrderProportion",
            data_type=DataType.DOUBLE,
            explanation="If the Order Quantity was filled out in the Order Profile table, the Order Proportion field will be used to determine how the Order Profile Quantity will be divided amongst the products that were selected to make up the line items.",
            precision_category=["Percentage"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
