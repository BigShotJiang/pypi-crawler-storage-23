"""UserDefinedConstraints table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, ConstraintType, Status, TechnologySupport

# UserDefinedConstraints table schema
user_defined_constraints = Table(
    table_name="UserDefinedConstraints",
    neo=TechnologySupport.FULLY_SUPPORTED,
    hopper=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="UserDefinedConstraints",
    in_database=True,
    fields=[
        Column(
            column_name="ConstraintName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name assigned to the Constraint. This value is purely descriptive; it can increase visibility into the constraints that are implemented into the model in the event that the Variable referenced includes an Enumerated Group. This Constraint Name will be automatically indexed to match the indexed (as a result of Enumeration) instances of the relevant Variable Name.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VariableName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["UserDefinedVariables", "TransportationUserDefinedVariables"],
            explanation="The name of the User-Defined Variable to be constrained.",
            precision_category=["NaN"],
            master_column=["UserDefinedVariables.VariableName", "TransportationUserDefinedVariables.VariableName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConstraintType",
            data_type=ConstraintType,
            required=True,
            explanation="The type of constraint imposed on the specified Variable.\n\nMin: the Variable must be greater than or equal to the Constraint Value.\nMax: the Variable must be less than or equal to the Constraint Value.\nFixed: the Variable must be equal to the Constraint Value.\nFixed With Tolerance: The Variable must be equal to the Constraint Value * (1 +/- Relative Constraint Tolerance). Relative Constraint Tolerance is specified in the Model Run Options.\nConditional Min: if the Variable is nonzero, it must be greater than or equal to the Constraint Value.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConstraintValue",
            data_type=DataType.DOUBLE,
            required=True,
            explanation="The numeric value that the specified Variable will be evaluated against.",
            precision_category=["Constraint"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConditionVariableName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["UserDefinedVariables", "TransportationUserDefinedVariables"],
            explanation="The name of the User-Defined Variable that acts as a Condition on this constraint. The constraint entered in fields VariableName, ConstraintType and ConstraintValue will be applied if and only if this ConditionVariable has a value between ConditionMinValue and ConditionMaxValue.",
            precision_category=["NaN"],
            master_column=["UserDefinedVariables.VariableName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConditionMinValue",
            data_type=DataType.DOUBLE,
            explanation="The lower bound value of the range where the condition is satisfied.",
            precision_category=["Constraint"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConditionMaxValue",
            data_type=DataType.DOUBLE,
            explanation="The upper bound value of the range where the condition is satisfied.",
            precision_category=["Constraint"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the Constraint exists. If Status is set to Exclude, this Constraint will be ignored in the model solve.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
