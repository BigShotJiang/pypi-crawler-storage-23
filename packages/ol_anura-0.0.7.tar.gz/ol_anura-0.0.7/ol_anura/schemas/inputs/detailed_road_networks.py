"""DetailedRoadNetworks table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table

# DetailedRoadNetworks table schema
detailed_road_networks = Table(
    table_name="DetailedRoadNetworks",
    abbreviated_name="DetailedRoadNetworks",
    in_database=True,
    fields=[
        Column(
            column_name="OriginName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="DestinationName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="Shape",
            data_type=DataType.STRING,
            required=True,
            precision_category=["NaN"],
            in_database=True
        ),
    ]
)
