"""RiskSummaryConfigurations table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# RiskSummaryConfigurations table schema
risk_summary_configurations = Table(
    table_name="RiskSummaryConfigurations",
    neo=TechnologySupport.FULLY_SUPPORTED,
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    triad=TechnologySupport.FULLY_SUPPORTED,
    dart=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="RiskSummaryConfigurations",
    in_database=True,
    fields=[
        Column(
            column_name="RiskProfileName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            master_table=["RiskRatingConfigurations"],
            explanation="The name of the Risk Profile that the risk configuration is saved for. Risk Profiles are configured to run using specified source data in the Risk Rating Configurations table, and will take the risk weightings and bands associated with the Risk Profile from each of the configuration tables",
            precision_category=["NaN"],
            master_column=["RiskRatingConfigurations.RiskProfileName"],
            dart=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CustomerRiskWeight",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            required=True,
            explanation="The weight applied to the Customer Risk when calculating the overall Risk Score.",
            precision_category=["Risk"],
            dart=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityRiskWeight",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            required=True,
            explanation="The weight applied to the Facility Risk when calculating the overall Risk Score.",
            precision_category=["Risk"],
            dart=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SupplierRiskWeight",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            required=True,
            explanation="The weight applied to the Supplier Risk when calculating the overall Risk Score.",
            precision_category=["Risk"],
            dart=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="NetworkRiskWeight",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            required=True,
            explanation="The weight applied to the Network Risk when calculating the overall Risk Score.",
            precision_category=["Risk"],
            dart=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            dart=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
