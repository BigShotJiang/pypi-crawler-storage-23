"""Histograms table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# Histograms table schema
histograms = Table(
    table_name="Histograms",
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="Histograms",
    in_database=True,
    fields=[
        Column(
            column_name="HistogramName",
            data_type=DataType.STRING,
            pk=True,
            explanation="The name of the histogram. If this Histogram Name is used as an input in another table, the histogram's data as described by the Bin Edges and Bin Heights will be used to form a distribution and draw a value.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BinEdge",
            data_type=DataType.DOUBLE,
            pk=True,
            explanation="The lower edge of the bin, a bin's width will be determined by the next defined bin edge. The last edge will serve as the upper edge for the last bin and the height will be ignored.",
            precision_category=["Quantity"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BinHeight",
            data_type=DataType.DOUBLE,
            explanation="The height of each bin.",
            precision_category=["Quantity"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
