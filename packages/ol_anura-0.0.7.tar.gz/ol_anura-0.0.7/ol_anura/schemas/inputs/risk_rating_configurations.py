"""RiskRatingConfigurations table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, Status, TechnologySupport

# RiskRatingConfigurations table schema
risk_rating_configurations = Table(
    table_name="RiskRatingConfigurations",
    neo=TechnologySupport.FULLY_SUPPORTED,
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    triad=TechnologySupport.FULLY_SUPPORTED,
    dart=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="RiskRatingConfigurations",
    in_database=True,
    fields=[
        Column(
            column_name="RiskRatingName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the Risk Rating, Risk Ratings will be a combination of a Risk Profile Name, External Data Source Name, and an External Data Date. Risk Ratings that are included will be run, and a default Opti Risk rating will always be run as well.",
            precision_category=["NaN"],
            dart=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RiskProfileName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the Risk Profile. Risk Profiles have weights and bands assigned for all of the various risk components in each of the risk configuration tables.",
            precision_category=["NaN"],
            dart=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the Risk Rating will be run in the model. If Status is set to Exclude, the Risk Rating is ignored during the model run.",
            precision_category=["NaN"],
            dart=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            dart=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
