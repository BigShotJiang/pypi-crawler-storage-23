"""ProductionPoliciesMultiTimePeriod table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, PolicyStatus, Status, TechnologySupport
from .production_policies import SimulationPolicy

# ProductionPoliciesMultiTimePeriod table schema
production_policies_multi_time_period = Table(
    table_name="ProductionPoliciesMultiTimePeriod",
    neo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="ProductionPoliciesMTP",
    fixed_tags=["Facilities", "Facility", "Suppliers", "Supplier", "Policies", "Production", "Multi", "Time", "Period"],
    in_database=True,
    fields=[
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Periods"],
            expandable=True,
            explanation="The period name in which a change is being made. Groups of periods are also supported. Changes that are made in the Multi Time Period table will be applied as overrides for the records of the base table for the specified periods only. Additionally, only the fields that contain information needing to be updated are required to be entered, in the absence of data in the Multi Time Period table the data from the standard table will be persisted",
            precision_category=["NaN"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Facilities"],
            expandable=True,
            explanation="The Facility at which the production policy is being defined",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Products"],
            expandable=True,
            explanation="The Product for which the production policy is being defined",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the multi-time period record exists in the model. If Status is set to Exclude, the record is ignored during the model run.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PolicyStatus",
            data_type=PolicyStatus,
            explanation="Policy Status dictates whether or not the policy exists in the model for the specified period(s). If Policy Status is set to Exclude, the policy record is ignored during the model run for the specified periods.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SimulationPolicy",
            data_type=SimulationPolicy,
            explanation="The policy that will dictate the production logic for the Facility/Product combination. Make By Demand will trigger production events based on the Production Orders which are triggered by the Inventory Policy for the Facility/Product combination. Make By Schedule will trigger production events based off of Production Orders specified in the Production Orders / Recurring Production Orders tables. Make By Demand And Schedule will trigger production orders based on both the Inventory Policy and the orders specified in the Production Orders / Recurring Production Orders tables. Continuous Production will continuously trigger production orders of the amount specified in the SIM Policy Lot Size field as soon as the production of the previous lot is completed.",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="UnitCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [All Item, Incremental, Stepwise]",
            master_table=["StepCosts"],
            notes="Optimization: Currently supports doubles and named step costs that are defined in the StepCosts table where StepCostBehavior = All Item, Incremental or Stepwise or a combination of Stepwise and All Item",
            explanation="The unit cost of a production flow at the Facility/Product combination. This field can support either a single numeric value, a lookup into a defined step cost, or a custom cost function entered directly into the field. If there are Processes defined, the information in the Processes table will override any information that exists in the Production Policies table",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnitCostUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The UOM that specifies what unit the Unit Cost will be applied over. This can be any UOM of Type = Quantity, Weight, Volume. If there are Processes defined, the information in the Processes table will override any information that exists in the Production Policies table",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductionRate",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="The production rate for the given Facility/Product combination. It will be defined as Quantity/Time as is specified in the Quantity/Time UOM fields. If there are Processes defined, the information in the Processes table will override any information that exists in the Production Policies table",
            precision_category=["Quantity"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RateQuantityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="ProductionRate",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The UOM that defines the number of units that are able to be produced on this Production Policy. This can be any UOM of Type = Quantity, Weight, Volume. If there are Processes defined, the information in the Processes table will override any information that exists in the Production Policies table",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RateTimeUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Time]",
            required_if="ProductionRate",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The UOM that defines the amount of time that the Production Rate is expressed in. This can be any UOM of Type = Time. If there are Processes defined, the information in the Processes table will override any information that exists in the Production Policies table",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WorkCenterName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            pk=True,
            master_table=["WorkCenters"],
            default_value="None",
            notes="Optimization: Currently supports single WorkCenter entries, WorkCenter groups are not supported\n\nSimulation: Currently supports single WorkCenter entries, WorkCenter groups are not supported",
            explanation="The Work Center assigned to the Production Policy; the production time and capacity consumed by the production at the listed Facility / Product will count toward the capacity of the Work Center. If a Process is also specified for this Production Policy, then this Work Center field is ignored and the value from the Processes table will take precedence.\n\nWorkCenter groups are not supported",
            precision_category=["NaN"],
            master_column=["WorkCenters.WorkCenterName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BOMName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            pk=True,
            master_table=["BillsOfMaterials"],
            default_value="None",
            notes="Optimization: Currently supports single Bill Of Material entries, Bill Of Material groups are not supported",
            explanation="The Bill of Material record that will be associated with any productions that occur at the Facility/Product combination. If a BOM is specified, in order to produce the product for this policy record the production location must also be able to source all required components as entered in the BOM\n\nBOM Groups are not currently supported.",
            precision_category=["NaN"],
            master_column=["BillsOfMaterials.BOMName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProcessName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            pk=True,
            master_table=["Processes"],
            default_value="None",
            notes="Optimization: Currently supports single Process entries, Process Groups are not supported",
            explanation="The Process associated with the production behavior for the specified Facility/Product combination. Processes offer a more detailed step by step production behavior that can specify the work time per unit, which Work Centers or Work Resources must be used, and at which points a component is required in the production flow.\n\nProcess Groups are not currently supported.",
            precision_category=["NaN"],
            master_column=["Processes.ProcessName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="LotSize",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            required_if="SimulationPolicy = Continuous Production",
            explanation="For SIM Policy = Continuous Production, the SIM Policy Lot Size will determine the size of each production order that is triggered for the Facility / Product combination.",
            precision_category=["Quantity"],
            in_database=True
        ),
        Column(
            column_name="LotSizeUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The UOM that specifies what unit the SIM Policy Lot Size will be defined in. This can be any UOM of Type = Quantity, Weight, Volume.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="TimeBetweenProductions",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="The amount of time between productions for this Facility / Product combination. Given the time between productions, the number of production runs will be calculated for the length of the period. Then, total production will be divided by the number of production runs to determine the Production Estimated Inventory. In the event that the Time Between Productions is longer than the length of the Period, the Production Estimated Inventory will be calculated based off of the proportion of the calculated production window that falls within the period.",
            precision_category=["Time"],
            in_database=True
        ),
        Column(
            column_name="TimeBetweenProductionsUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required_if="TimeBetweenProductions",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure that defines the Time Between Productions. Time units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="CO2EmissionRate",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="NonNegative",
            explanation="The rate of CO2 emissions for this production policy for the given period.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CO2EmissionRateUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight, Time]",
            required_if="CO2EmissionRate",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight", "Time"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure (Type = Quantity, Volume, Weight, Time) that defines the CO2 Emission Rate.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
