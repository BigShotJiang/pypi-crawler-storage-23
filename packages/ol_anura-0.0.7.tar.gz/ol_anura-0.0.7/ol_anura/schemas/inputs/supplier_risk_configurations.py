"""SupplierRiskConfigurations table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# SupplierRiskConfigurations table schema
supplier_risk_configurations = Table(
    table_name="SupplierRiskConfigurations",
    neo=TechnologySupport.FULLY_SUPPORTED,
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    triad=TechnologySupport.FULLY_SUPPORTED,
    dart=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="SupplierRiskConfigurations",
    in_database=True,
    fields=[
        Column(
            column_name="RiskProfileName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            master_table=["RiskRatingConfigurations"],
            explanation="The name of the Risk Profile that the risk configuration is saved for. Risk Profiles are configured to run using specified source data in the Risk Rating Configurations table, and will take the risk weightings and bands associated with the Risk Profile from each of the configuration tables",
            precision_category=["NaN"],
            master_column=["RiskRatingConfigurations.RiskProfileName"],
            dart=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="GeographicRiskWeight",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            required=True,
            explanation="The weight applied to the Geographic Risk when calculating the Supplier Risk Score. Detailed Geographic Risks configurations on geographic risk components are entered in the Geographic Risk Configurations table.",
            precision_category=["Risk"],
            dart=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UserDefinedRiskWeight",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            required=True,
            explanation="The weight applied to the User Defined Risk when calculating the Supplier Risk Score.",
            precision_category=["Risk"],
            dart=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UtilizationRiskWeight",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            required=True,
            explanation="The weight applied to the Utilization Risk when calculating the Supplier Risk Score. Unlike Facilities, Suppliers will only be impacted by a single capacity factor and therefore there is no need for more detailed Utilization Risk configurations.",
            precision_category=["Risk"],
            dart=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConcentrationRiskWeight",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            required=True,
            explanation="The weight applied to the Concentration Risk when calculating the Supplier Risk Score.",
            precision_category=["Risk"],
            dart=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConcentrationRiskBand",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            master_table=["RiskBandDefinitions"],
            explanation="The Risk Band that is used to evaluate the Concentration Risk at the Supplier. Risk Bands are defined in the Risk Band Definitions table.",
            precision_category=["NaN"],
            master_column=["RiskBandDefinitions.BandName"],
            dart=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            dart=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
