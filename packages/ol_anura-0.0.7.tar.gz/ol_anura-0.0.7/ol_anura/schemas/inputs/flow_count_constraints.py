"""FlowCountConstraints table schema definition."""

import sys
from pathlib import Path
from enum import Enum

from ...core import DataType, Column, Table, ConstraintType, GroupBehavior, Status, TechnologySupport


class CountingRule(str, Enum):
    """CountingRule values."""
    DESTINATIONS = "Destinations"
    DESTINATIONS_MODES = "Destinations-Modes"
    DESTINATIONS_PRODUCTS = "Destinations-Products"
    MODES = "Modes"
    ORIGINS = "Origins"
    ORIGINS_DESTINATIONS = "Origins-Destinations"
    ORIGINS_MODES = "Origins-Modes"
    ORIGINS_PRODUCTS = "Origins-Products"
    PERIODS = "Periods"
    PRODUCTS = "Products"
    PRODUCTS_MODES = "Products-Modes"

# FlowCountConstraints table schema
flow_count_constraints = Table(
    table_name="FlowCountConstraints",
    neo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="FlowCountConstraints",
    fixed_tags=["Transport", "OrderFulfillment", "Replenishment", "Procurement", "Multi", "Time", "Period", "Constraints", "Count"],
    in_database=True,
    fields=[
        Column(
            column_name="OriginName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Facilities", "Suppliers", "Customers", "Sources"],
            expandable=True,
            default_value="ALL",
            explanation="The Origin(s) (Facilities and/or Suppliers and/or Customers) of the flow we are counting. Groups are supported.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OriginNameGroupBehavior",
            data_type=GroupBehavior,
            pk=True,
            default_value="Aggregate",
            explanation="If Origin Name is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this constraint will be created for each member of the Group. If Aggregate is selected, the flow in the constraint will be summed over the members of the Group.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DestinationName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Customers", "Facilities", "Destinations"],
            expandable=True,
            default_value="ALL",
            explanation="The Destination(s) (Facilities and/or Customers) of the flow we are counting. Groups are supported.",
            precision_category=["NaN"],
            master_column=["Customers.CustomerName", "Facilities.FacilityName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DestinationNameGroupBehavior",
            data_type=GroupBehavior,
            pk=True,
            default_value="Aggregate",
            explanation="If Destination Name is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this constraint will be created for each member of the Group. If Aggregate is selected, the flow in the constraint will be summed over the members of the Group.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Products"],
            expandable=True,
            default_value="ALL",
            explanation="The Product(s) in the flow we are counting. Groups are supported.",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductNameGroupBehavior",
            data_type=GroupBehavior,
            pk=True,
            default_value="Aggregate",
            explanation="If Product Name is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this constraint will be created for each member of the Group. If Aggregate is selected, the flow in the constraint will be summed over the members of the Group.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ModeName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            pk=True,
            master_table=["TransportationModes"],
            expandable=True,
            default_value="ALL",
            explanation="The Transportation Mode(s) of the flow we are counting (optional). Groups are supported. If left empty, all flows will be considered regardless of if a Mode is used. To specifically constrain against flows that do not use a Mode, enter a value of 'None'",
            precision_category=["NaN"],
            master_column=["TransportationModes.ModeName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ModeNameGroupBehavior",
            data_type=GroupBehavior,
            pk=True,
            default_value="Aggregate",
            explanation="If Mode Name is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this constraint will be created for each member of the Group. If Aggregate is selected, the flow in the constraint will be summed over the members of the Group.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Periods"],
            expandable=True,
            default_value="ALL",
            explanation="The Period(s) in which we are counting flow. Groups are supported.",
            precision_category=["NaN"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PeriodNameGroupBehavior",
            data_type=GroupBehavior,
            pk=True,
            default_value="Aggregate",
            explanation="If Period Name is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this constraint will be created for each member of the Group. If Aggregate is selected, the flow in the constraint will be summed over the members of the Group.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConstraintType",
            data_type=ConstraintType,
            required=True,
            pk=True,
            explanation="The type of constraint imposed on the flow for the specified Source/Destination/Product/Mode/Period combination. \n\nMin: the count must be greater than or equal to the Constraint Value.\nMax: the count must be less than or equal to the Constraint Value.\nFixed: the count must be equal to the Constraint Value.\nFixed With Tolerance: The count must be equal to the Constraint Value * (1 +/- Relative Constraint Tolerance). Relative Constraint Tolerance is specified in the Model Run Options.\nConditional Min: if the count is nonzero, it must be greater than or equal to the Constraint Value.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConstraintValue",
            data_type=DataType.INTEGER,
            validation_type="NonNegative",
            required=True,
            pk=True,
            explanation="The numeric value that the specified flow count will be evaluated against.",
            precision_category=["Integer"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the constraint exists in the model. If Status is set to Exclude, this constraint (or constraints in the case of Enumerated Groups) will be ignored during the model run.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CountingRule",
            data_type=CountingRule,
            required=True,
            pk=True,
            explanation="Origins: Count the number of unique Origins in the flows for the specified Destination/Product/Mode/Period combination.\nDestinations: Count the number of unique Destinations in the flows for the specified Origin/Product/Mode/Period combination.\nProducts: Count the number of unique Products in the flows for the specified Origin/Destination/Mode/Period combination.\nModes: Count the number of unique Modes used in the flows for the specified Origin/Destination/Product/Period combination.\nPeriods: Count the number of unique Periods in which flow occurs for the specified Origin/Destination/Product/Mode combination.\nOrigins-Destinations: Count the number of unique Origin-Destination combinations on which flow occurs for the specified Mode/Product/Period combination.\nDestinations-Modes: Count the number of unique Destination-Mode combinations on which flow occurs for the specified Origin/Product/Period combination.\nProducts-Modes: Count the number of unique Product-Mode combinations on which flow occurs for the specified Origin/Destination/Period combination.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
