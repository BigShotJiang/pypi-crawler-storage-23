"""CompartmentConfigurations table schema definition."""

import sys
from pathlib import Path
from enum import Enum

from ...core import DataType, Column, Table, Status, TechnologySupport


# CompartmentConfigurations table schema
compartment_configurations = Table(
    table_name="CompartmentConfigurations",
    hopper=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="CompartmentConfigurations",
    in_database=True,
    fields=[
        Column(
            column_name="CompartmentConfigurationName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name given to the Compartment Configuration. This name may be referenced in the TransportationAssets table.",
            precision_category=["NaN"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CompartmentName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name given to a given compartment",
            precision_category=["NaN"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="QuantityCapacity",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="The capacity (quantity) of the Compartment.",
            precision_category=["Quantity"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="QuantityCapacityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity]",
            required_if="QuantityCapacity",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity"],
            u_o_m_conversion="Intra",
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure (Type = Quantity) that defines Quantity Capacity.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VolumeCapacity",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="The capacity (volume) of the compartment.",
            precision_category=["Volume"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VolumeCapacityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Volume]",
            required_if="VolumeCapacity",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Volume"],
            u_o_m_conversion="Intra",
            default_value="{PrimaryVolumeUOM}",
            explanation="The unit of measure (Type = Volume) that defines Volume Capacity.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WeightCapacity",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="The capacity (weight) of the compartment.",
            precision_category=["Weight"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WeightCapacityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Weight]",
            required_if="WeightCapacity",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Weight"],
            u_o_m_conversion="Intra",
            default_value="{PrimaryWeightUOM}",
            explanation="The unit of measure (Type = Weight) that defines Weight Capacity.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            explanation="",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="NumberOfAllowedProducts",
            data_type=DataType.INTEGER,
            validation_type="NonNegative",
            default_value="1",
            explanation="The number of different products that can be loaded into this compartment simultaneously.",
            precision_category=["Integer"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AllowedProductName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["Products"],
            explanation="The products that can be loaded in this compartment. Blank means that all products are allowed. Single product name, groups and named filters can be used. ",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
