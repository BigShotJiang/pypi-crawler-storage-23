"""IncrementalChangeConstraints table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, BudgetBasis, ChangeType, GroupBehavior, Status, TechnologySupport

# IncrementalChangeConstraints table schema
incremental_change_constraints = Table(
    table_name="IncrementalChangeConstraints",
    neo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="IncrementalChangeConstraints",
    in_database=True,
    fields=[
        Column(
            column_name="ChangeType",
            data_type=ChangeType,
            required=True,
            pk=True,
            explanation="The change type that user would like to limit its variation.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Periods"],
            expandable=True,
            default_value="ALL",
            explanation="The Period(s) in which we are constraining the changes. Groups are supported.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PeriodNameGroupBehavior",
            data_type=GroupBehavior,
            required=True,
            default_value="Enumerate",
            explanation="If Period Name is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this constraint will be created for each member of the Group. If Aggregate is selected, the limit in the constraint will be applied over the members of the Group.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Budget",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            required=True,
            default_value="0",
            explanation="The limit for the amount of change on the change type's subject in the given Period.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BudgetBasis",
            data_type=BudgetBasis,
            default_value="Quantity",
            explanation="The basis for the change limit.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the constraint exists in the model. If Status is set to Exclude, this constraint (or constraints in the case of Enumerated Groups) will be ignored during the model run.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
