"""CategoricalDistributions table schema definition."""

import sys
from pathlib import Path
from enum import Enum

from ...core import DataType, Column, Table, TechnologySupport


class DistributionType(str, Enum):
    """DistributionType values."""
    PRODUCTS = "Products"

# CategoricalDistributions table schema
categorical_distributions = Table(
    table_name="CategoricalDistributions",
    abbreviated_name="CategoricalDistributions",
    in_database=True,
    fields=[
        Column(
            column_name="DistributionName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the categorical distribution. If this Distribution Name is used as an input in another table, the populated weights will be used to sample from the distribution and draw a value.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DistributionType",
            data_type=DistributionType,
            required=True,
            pk=True,
            notes="Currently supports DistributionType = [Products]",
            explanation="The type of elements the Distribution consists of.",
            precision_category=["Quantity"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MemberName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Products"],
            notes="Currently supports DistributionType = [Products]",
            explanation="The entity that is being assigned to the Distribution. The Member Name must have an associated record in the relevant master table.",
            precision_category=["NaN"],
            basic_mode=["THROG", "DENDRO"],
            master_column=["Products.ProductName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Weight",
            data_type=DataType.DOUBLE,
            explanation="The weight of each outcome.",
            precision_category=["Quantity"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
