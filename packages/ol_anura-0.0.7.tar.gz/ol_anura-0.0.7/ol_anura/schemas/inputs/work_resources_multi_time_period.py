"""WorkResourcesMultiTimePeriod table schema definition."""

import sys
from pathlib import Path
from enum import Enum

from ...core import DataType, Column, Table, Status


class WorkResourceStatus(str, Enum):
    """WorkResourceStatus values."""
    EXCLUDE = "Exclude"
    INCLUDE = "Include"

# WorkResourcesMultiTimePeriod table schema
work_resources_multi_time_period = Table(
    table_name="WorkResourcesMultiTimePeriod",
    abbreviated_name="WorkResourcesMTP",
    fixed_tags=["Multi", "Time", "Period"],
    in_database=True,
    fields=[
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Periods"],
            expandable=True,
            explanation="The period name in which a change is being made. Groups of periods are also supported. Changes that are made in the Multi Time Period table will be applied as overrides for the records of the base table for the specified periods only. Additionally, only the fields that contain information needing to be updated are required to be entered, in the absence of data in the Multi Time Period table the data from the standard table will be persisted",
            precision_category=["NaN"],
            master_column=["Periods.PeriodName"],
            in_database=True
        ),
        Column(
            column_name="WorkResourceName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["WorkResources"],
            expandable=True,
            explanation="The name of the Work Resource.",
            precision_category=["NaN"],
            master_column=["WorkResources.WorkResourceName"],
            in_database=True
        ),
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["Facilities"],
            expandable=True,
            explanation="The Facility at which the Work Resource will be located. If a Facility Group is used, identical Work Resources will be associated with each Facility in the Group.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName"],
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the multi-time period record exists in the model. If Status is set to Exclude, the record is ignored during the model run.",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="WorkResourceStatus",
            data_type=WorkResourceStatus,
            explanation="Work Resource Status dictates whether or not the policy exists in the model for the specified period(s). If Work Resource Status is set to Exclude, the policy record is ignored during the model run.",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="AvailableUnits",
            data_type=DataType.INTEGER,
            validation_type="NonNegative",
            explanation="The units of the Work Resource available at the specified Facility.",
            precision_category=["Integer"],
            in_database=True
        ),
        Column(
            column_name="Capacity",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="The capacity of the Work Center (throughput or time). This Capacity applies to the entire model horizon; period-specific capacities can be defined in the Work Centers Multi Time Period table.",
            precision_category=["Quantity"],
            in_database=True
        ),
        Column(
            column_name="CapacityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="Capacity",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines Throughput Capacity. Quantity, Volume, Weight, and Time units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="UnitCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [All Item, Incremental]",
            master_table=["StepCosts"],
            explanation="The cost associated with completing one unit of work using the Work Resource.",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName"],
            in_database=True
        ),
        Column(
            column_name="UnitCostUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight, Time]",
            required_if="UnitCost",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight", "Time"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines Unit Cost. Quantity, Volume, Weight, and Time units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="FixedOperatingCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [Stepwise]",
            master_table=["StepCosts"],
            explanation="The fixed cost associated with operating the Work Resource. This field can support a single numeric value or a step cost (entered directly or a lookup of a record in the Step Costs table). If a step cost is used, the Work Resource's throughput for the entire model horizon will be used to determine Fixed Operating Cost. Period-specific costs can be defined in the Work Centers Multi Time Period table.",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName"],
            in_database=True
        ),
        Column(
            column_name="OperatingSchedule",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["BusinessHours"],
            explanation="The schedule (defined in the Business Hours table) dictating when the Work Resource will be operational. If no schedule is specified, the Work Center is assumed to operate 24 hours per day.",
            precision_category=["NaN"],
            master_column=["BusinessHours.ScheduleName"],
            in_database=True
        ),
        Column(
            column_name="OperatingCalendar",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["BusinessCalendars"],
            explanation="The calendar (defined in the Business Calendars table) dictating which days of the year the Work Resource will shut down. If no calendar is specified, the Work Resource is assumed to be operational every day.",
            precision_category=["NaN"],
            master_column=["BusinessCalendars.CalendarName"],
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            in_database=True
        ),
    ]
)
