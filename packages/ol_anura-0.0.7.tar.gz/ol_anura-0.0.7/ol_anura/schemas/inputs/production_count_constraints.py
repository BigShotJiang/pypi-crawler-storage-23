"""ProductionCountConstraints table schema definition."""

import sys
from pathlib import Path
from enum import Enum

from ...core import DataType, Column, Table, ConstraintType, GroupBehavior, Status, TechnologySupport


class CountingRule(str, Enum):
    """CountingRule values."""
    BOMS = "BOMs"
    FACILITIES = "Facilities"
    PERIODS = "Periods"
    PROCESSES = "Processes"
    PRODUCTS = "Products"

# ProductionCountConstraints table schema
production_count_constraints = Table(
    table_name="ProductionCountConstraints",
    neo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="ProductionCountConstraints",
    fixed_tags=["Facilities", "Facility", "Suppliers", "Supplier", "Constraints", "Production", "Multi", "Time", "Period", "Count"],
    in_database=True,
    fields=[
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Facilities"],
            expandable=True,
            default_value="ALL",
            explanation="The Facility or Facilities at which we are counting production occurrences. Groups are supported.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityNameGroupBehavior",
            data_type=GroupBehavior,
            pk=True,
            default_value="Aggregate",
            explanation="If Facility Name is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this constraint will be created for each member of the Group. If Aggregate is selected, the flow in the constraint will be summed over the members of the Group.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Products"],
            expandable=True,
            default_value="ALL",
            explanation="The Product(s) for which we are counting production occurrences. Groups are supported.",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductNameGroupBehavior",
            data_type=GroupBehavior,
            pk=True,
            default_value="Aggregate",
            explanation="If Product Name is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this constraint will be created for each member of the Group. If Aggregate is selected, the flow in the constraint will be summed over the members of the Group.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BOMName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            pk=True,
            master_table=["BillsOfMaterials"],
            expandable=True,
            default_value="ALL",
            explanation="TThe Bill(s) of Materials (BOMs) associated with the production we are counting over. If a BOM is not specified in the Production Policies table for this Facility/Product combination, the constraint will be ignored and the user will be alerted.If left empty, the constraint will be counted over productions that use a BOM as well as those which do not. To specifically constrain against productions that do not use a BOM, enter a value of 'None'.",
            precision_category=["NaN"],
            master_column=["BillsOfMaterials.BOMName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BOMNameGroupBehavior",
            data_type=GroupBehavior,
            pk=True,
            default_value="Aggregate",
            explanation="If BOM Name is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this constraint will be created for each member of the Group. If Aggregate is selected, the flow in the constraint will be summed over the members of the Group.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProcessName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            pk=True,
            master_table=["Processes"],
            expandable=True,
            default_value="ALL",
            explanation="The Process(es) associated with the production we are counting over. If a Process is not specified in the Production Policies table for this Facility/Product combination, the constraint will be ignored and the user will be alerted.If left empty, the constraint will be counted over productions that use a Process as well as those which do not. To specifically constrain against productions that do not use a Process, enter a value of 'None'.",
            precision_category=["NaN"],
            master_column=["Processes.ProcessName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProcessNameGroupBehavior",
            data_type=GroupBehavior,
            pk=True,
            default_value="Aggregate",
            explanation="If Process Name is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this constraint will be created for each member of the Group. If Aggregate is selected, the flow in the constraint will be summed over the members of the Group.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Periods"],
            expandable=True,
            default_value="ALL",
            explanation="The Period(s) in which we are counting production occurrences. Groups are supported.",
            precision_category=["NaN"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PeriodNameGroupBehavior",
            data_type=GroupBehavior,
            pk=True,
            default_value="Aggregate",
            explanation="If Period Name is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this constraint will be created for each member of the Group. If Aggregate is selected, the flow in the constraint will be summed over the members of the Group.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConstraintType",
            data_type=ConstraintType,
            required=True,
            pk=True,
            explanation="The type of constraint imposed on the production count for the specified Facility/Product/Period combination. \n\nMin: the count must be greater than or equal to the Constraint Value.\nMax: the count must be less than or equal to the Constraint Value.\nFixed: the count must be equal to the Constraint Value.\nFixed With Tolerance: The count must be equal to the Constraint Value * (1 +/- Relative Constraint Tolerance). Relative Constraint Tolerance is specified in the Model Run Options.\nConditional Min: if the count is nonzero, it must be greater than or equal to the Constraint Value.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConstraintValue",
            data_type=DataType.INTEGER,
            validation_type="NonNegative",
            required=True,
            pk=True,
            explanation="The numeric value that the specified count will be evaluated against.",
            precision_category=["Integer"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the constraint exists in the model. If Status is set to Exclude, this constraint (or constraints in the case of Enumerated Groups) will be ignored during the model run.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CountingRule",
            data_type=CountingRule,
            required=True,
            pk=True,
            explanation="Facilities: Count the number of unique Facilities at which production occurs for the specified Product/BOM/Routing/Period combination.\nProducts: Count the number of unique Products for which production occurs for the specified Facility/BOM/Routing/Period combination.\nBOMs: Count the number of unique BOMs used in production at the specified Facility/Product/Routing/Period combination.\nProcesses: Count the number of unique Processes used in production at the specified Facility/Product/BOM/Period combination.\nPeriods: Count the number of unique Periods in which production occurs for the specified Facility/Product/BOM/Routing combination.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
