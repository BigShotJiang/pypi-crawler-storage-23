"""ProcurementOrders table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, Status, TechnologySupport

# ProcurementOrders table schema
procurement_orders = Table(
    table_name="ProcurementOrders",
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="ProcurementOrders",
    fixed_tags=["Facilities", "Facility", "Supplier", "Order"],
    in_database=True,
    fields=[
        Column(
            column_name="OrderID",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The unique identifier for each Order; an Order consists of one or more Line Items.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="LineItemID",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The unique identifier for the single Line Item being defined; Orders with multiple Line Items will require multiple table records.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            master_table=["Facilities"],
            explanation="The name of the Facility placing the Order. Facility Groups are supported; the Group behavior will be Enumerate.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            master_table=["Products"],
            explanation="The Product in the Line Item",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Quantity",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            required=True,
            explanation="The amount of Product requested by the Facility.",
            precision_category=["Quantity"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="QuantityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="Quantity",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines Quantity. Quantity, Volume, and Weight units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="OrderDate",
            data_type=DataType.DATETIME,
            required=True,
            explanation="The date and time at which the Facility places the Order.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DueDate",
            data_type=DataType.DATETIME,
            explanation="The date and time at which the Order is due at the Facility.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the Line Item exists in the model. If Status is set to Exclude, this  record will be ignored during the model run.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ServiceMode",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["TransportationModes"],
            explanation="Optionally, a required Transportation Mode can be specified here. If multiple Modes are acceptable, a Mode Group may be used; the Group behavior will be Aggregate. If NULL, any Mode is assumed to be acceptable.",
            precision_category=["NaN"],
            master_column=["TransportationModes.ModeName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SourceName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["Suppliers"],
            explanation="Optionally, a required Supplier for the Line Item can be specified here. If multiple Suppliers are acceptable, a Supplier Group may be used; the Group behavior will be Aggregate. If NULL, any Supplier of the Product is assumed to be acceptable.",
            precision_category=["NaN"],
            master_column=["Suppliers.SupplierName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SingleSourceOrder",
            data_type=bool,
            explanation="If True, all Line Items in the Order must be sourced from a single Supplier. If False, each Line Item within the Order may be sourced from a different Supplier. A value of True in this field overrides Single Source Line Items = False, enforcing that all Line Items in the order come from a single source.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SingleSourceLineItems",
            data_type=bool,
            explanation="If True, the entire Line Item must be sourced from a single Supplier. If False, the Line Item may be sourced from different sites.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AllowPartialFillOrders",
            data_type=bool,
            explanation="If True, the Order may be partially filled. Otherwise, it must be filled in full. If backordering is allowed, the remaining quantity may be satisfied in the future with additional shipments; if the Backorder Time Limit is reached on a partially filled order, the remaining quantity will be cancelled. If Partial Fill Orders is False, Partial Fill Line Items will also be forced to False.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AllowPartialFillLineItems",
            data_type=bool,
            explanation="If True, the specified Line Item may be partially filled. Otherwise, the Line Item must be filled in full. If backordering is allowed, the remaining quantity of partially filled Line Items may be satisfied in the future with additional shipments; if the Backorder Time Limit is reached on a partially filled Line Item, the remaining quantity will be cancelled.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AllowBackorders",
            data_type=bool,
            explanation="If True, the Facility will accept a backorder in the event that the Order cannot be fulfilled before its Due Date. If False and if the Order is not fulfilled by its Due Date, it will be cancelled on that date.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BackorderTimeLimit",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="If Allow Backorders = True, this value is the amount of time after which the backorder will be cancelled by the Facility. A value of NULL will be interpreted as an infinite time limit, while a value of zero is equivalent to setting Allow Backorders = False.",
            precision_category=["Time"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BackorderTimeLimitUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Time]",
            required_if="BackorderTimeLimit",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure (Type = Time) used to define Backorder Time Limit.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
