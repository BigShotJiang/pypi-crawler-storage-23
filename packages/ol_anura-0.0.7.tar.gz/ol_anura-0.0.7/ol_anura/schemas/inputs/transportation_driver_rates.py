"""TransportationDriverRates table schema definition."""

import sys
from pathlib import Path
from enum import Enum

from ...core import DataType, Column, Table, Status, TechnologySupport


class CostResetInterval(str, Enum):
    """CostResetInterval values."""
    DAILY = "Daily"
    MONTHLY = "Monthly"
    WEEKLY = "Weekly"

class FuelSurchargeBasis(str, Enum):
    """FuelSurchargeBasis values."""
    PER_DISTANCE = "Per Distance"
    PERCENTAGE = "Percentage"

# TransportationDriverRates table schema
transportation_driver_rates = Table(
    table_name="TransportationDriverRates",
    hopper=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="TransportationDriverRates",
    fixed_tags=["Transport"],
    in_database=True,
    fields=[
        Column(
            column_name="TransportationDriverRateName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the Transportation Driver Rate. This value can be referenced in the TransportationAssets table. These costs will be applied across multiple routes assigned to the same driver",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="CostResetInterval",
            data_type=CostResetInterval,
            pk=True,
            explanation="If blank, the costs are calculated across all routes assigned to the driver during the model horizon. This field can be used to apply cost over the specified time bucket instead. This is particularly useful in combination with step costs, eg. to model overtime cost after 40h each week. The costs will reset each day at midnight for Daily, each Monday for Weekly and on the first day of each month for Monthly.",
            precision_category=["NaN"],
            master_column=["Customers.CustomerName", "Facilities.FacilityName"],
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not this rate exists in the model. If Status is set to Exclude, this rate is ignored in all tables.",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="DistanceCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [All Item, Incremental]",
            master_table=["StepCosts"],
            default_value="0",
            explanation="The cost per distance travelled by this driver.",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName"],
            in_database=True
        ),
        Column(
            column_name="DistanceCostUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Distance]",
            required_if="DistanceCost",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Distance"],
            default_value="{PrimaryDistanceUOM}",
            explanation="The unit of measure (Type = Distance) that defines how the distance costs will be applied.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="TimeCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [All Item, Incremental]",
            master_table=["StepCosts"],
            default_value="0",
            explanation="The cost per unit of time across all routes assigned to this driver.",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName"],
            in_database=True
        ),
        Column(
            column_name="TimeCostUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Time]",
            required_if="TimeCost",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure (Type = Time) that defines how the time costs will be applied.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="WaitTimeCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [All Item, Incremental]",
            master_table=["StepCosts"],
            default_value="0",
            explanation="The cost per unit of time that the driver is waiting.",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName"],
            in_database=True
        ),
        Column(
            column_name="WaitTimeCostUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Time]",
            required_if="WaitTimeCost",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure (Type = Time) that defines how the time costs will be applied.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="RestTimeCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [All Item, Incremental]",
            master_table=["StepCosts"],
            default_value="0",
            explanation="The cost per unit of time during a rest between shifts.",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RestTimeCostUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Time]",
            required_if="RestTimeCost",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure (Type = Time) that defines how the time costs will be applied.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BreakTimeCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [All Item, Incremental]",
            master_table=["StepCosts"],
            default_value="0",
            explanation="The cost per unit of time during a break after the maximum drive or duty time before short break is reached.",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BreakTimeCostUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Time]",
            required_if="BreakTimeCost",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure (Type = Time) that defines how the time costs will be applied.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DutyTimeCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [All Item, Incremental]",
            master_table=["StepCosts"],
            default_value="0",
            explanation="The cost per unit of time a driver is on duty. This is additive to any other time costs specified for this driver.",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DutyTimeCostUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Time]",
            required_if="DutyTimeCost",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure (Type = Time) that defines how the time costs will be applied.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StopCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [All Item, Incremental]",
            master_table=["StepCosts"],
            default_value="0",
            explanation="The cost incurred by the Driver at each stop.",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName"],
            in_database=True
        ),
        Column(
            column_name="UnitCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [All Item, Incremental]",
            master_table=["StepCosts"],
            default_value="0",
            explanation="The unit cost associated with shipments transported. This field can support a single numeric value, a step cost lookup (defined in the Step Costs table), or a custom cost function.",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName"],
            in_database=True
        ),
        Column(
            column_name="UnitCostUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="UnitCost",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines the basis on which UnitCost will be applied for the Asset. Quantity, Volume, and Weight units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="FuelSurcharge",
            data_type=DataType.DOUBLE,
            default_value="0",
            explanation="The Fuel surcharge is an additional type of per distance cost.",
            precision_category=["Cost"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FuelSurchargeBasis",
            data_type=FuelSurchargeBasis,
            default_value="Percentage",
            explanation="The Basis for the fuel surcharge. If percentage is selected, surcharge is calculated as DistanceCost * (FuelSurcharge / 100). For example, to apply a 5% surcharge you would enter a value of FuelSurcharge = 5, FuelSurchargeBasis = Percentage. \n\nIf Per Distance is selected then surcharge is calculated as TotalDistance * FuelSurcharge.",
            precision_category=["NaN"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            in_database=True
        ),
    ]
)
