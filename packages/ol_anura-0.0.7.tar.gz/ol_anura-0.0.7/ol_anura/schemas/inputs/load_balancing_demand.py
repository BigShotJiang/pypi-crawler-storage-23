"""LoadBalancingDemand table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, Status, TechnologySupport

# LoadBalancingDemand table schema
load_balancing_demand = Table(
    table_name="LoadBalancingDemand",
    hopper=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="LoadBalancingDemand",
    basic_mode_hopper=True,
    in_database=True,
    fields=[
        Column(
            column_name="SourceName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Facilities", "Suppliers"],
            explanation="The Facility or Supplier that the demand will be served from.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CustomerName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Customers"],
            u_o_m_conversion="",
            explanation="The name of the Customer receiving the demand",
            master_column=["Customers.CustomerName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Products"],
            explanation="The Product for the demand.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["Products.ProductName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not this demand will be considered in the model",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WeeklyDemand",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            u_o_m_conversion="",
            default_value="1",
            explanation="The weekly demand that the customer needs to receive for this source/product combination.",
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="NumberOfDeliveriesPerWeek",
            data_type=DataType.INTEGER,
            validation_type="PositiveNumeric",
            u_o_m_conversion="",
            default_value="1",
            explanation="The number of days that the customer should be visited receive deliveries from this source during the week.",
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="LoadBalancingScheduleName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["LoadBalancingSchedules"],
            explanation="The rules that the delivery schedule must follow for this customer",
            precision_category=["NaN"],
            master_column=["LoadBalancingSchedules.LoadBalancingScheduleName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
