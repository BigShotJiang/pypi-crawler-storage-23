"""GreenfieldSettings table schema definition."""

import sys
from pathlib import Path
from enum import Enum

from ...core import DataType, Column, Table, TechnologySupport


class ClusteringApproach(str, Enum):
    """ClusteringApproach values."""
    FCLUSTER = "fcluster"
    UTM = "utm"

# GreenfieldSettings table schema
greenfield_settings = Table(
    table_name="GreenfieldSettings",
    triad=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="GreenfieldSettings",
    basic_mode_triad=True,
    in_database=True,
    fields=[
        Column(
            column_name="MinNumberOfNewFacilities",
            data_type=DataType.INTEGER,
            validation_type="NonNegative",
            explanation="The minimum number of new facility locations to be opened during solve. This will include any Candidate Facilities that are selected as well as any Greenfield Facilities. This value is ignored if MinimizeTotalFacilities is set to True.",
            precision_category=["Integer"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MaxNumberOfNewFacilities",
            data_type=DataType.INTEGER,
            validation_type="NonNegative",
            explanation="The maximum number of new facility locations to be opened during solve. This will include any Candidate Facilities that are selected as well as any Greenfield Facilities. This value is ignored if MinimizeTotalFacilities is set to True.",
            precision_category=["Integer"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MinimizeTotalFacilities",
            data_type=bool,
            default_value="False",
            explanation="If True, the number of new facility locations to be opened will be minimized (Greenfield Facilities and Candidate Facilities). If False, the total cost (Facility Fixed Cost and Transportation Cost) will be minimized.",
            precision_category=["NaN"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ExcludeFacilities",
            data_type=bool,
            default_value="True",
            explanation="If True, all Facilities in the model will be ignored during the Greenfield run. This value is set to False if OnlyUseFacilitiesAsCandidateLocations is set to True.",
            precision_category=["NaN"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ExcludeSuppliers",
            data_type=bool,
            default_value="True",
            explanation="If True, all Suppliers in the model will be ignored during the Greenfield run.",
            precision_category=["NaN"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OnlyUseFacilitiesAsCandidateLocations",
            data_type=bool,
            default_value="False",
            explanation="If True, the selection pool for Greenfield locations will be restricted to Facilities that are Included. Facilities with a Facility Status of 'Open' will be forced to open and have their fixed operating cost charged in the Greenfield solve. Facilities with a Facility Status of 'Consider' will have the option to be opened as a Candidate Facility location and if selected, their fixed operating cost will be charged.",
            precision_category=["NaN"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CustomerMaxSourcingDistance",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="The maximum distance that any Customer can source a flow from a Greenfield Facility, a Candidate Facility, or an Existing Facility.",
            precision_category=["Distance"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="GreenfieldFacilityMinThroughput",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="The minimum quantity of demand that a Greenfield Facility must service to be selected.This will apply to all Facilities, both new and existing, for the Greenfield solve.",
            precision_category=["Quantity"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="GreenfieldFacilityMaxThroughput",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="The maximum quantity of demand that a single Greenfield Facility can service. For existing or candidate Facilities the throughput capacity will be specified in the Facilities table.",
            precision_category=["Quantity"],
            basic_mode=["TRIAD"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="GreenfieldFacilityFixedCost",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            default_value="0",
            explanation="The fixed cost applied to each Greenfield Facility used in the solve.",
            precision_category=["Cost"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CustomerFulfillmentCost",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            default_value="1",
            explanation="The cost charged for all flows from Facilities to Customers on a quantity-distance basis.",
            precision_category=["Cost"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProcurementCost",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            default_value="0.75",
            explanation="The cost charged for all flows from Suppliers to Facilities on a quantity-distance basis.",
            precision_category=["Cost"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RunLocationRefinementHeuristic",
            data_type=bool,
            default_value="True",
            explanation="If True, the Greenfield Facilities selected by the solver can be improved beyond their initial location that would be co-located with a Customer / Cluster location.",
            precision_category=["NaN"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CustomerClusterRadius",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="The distance that Customers should be clustered over. The UOM of this distance measure is the primary distance UOM specified in the Model Settings table.",
            precision_category=["Distance"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AutoDetectClusterRadius",
            data_type=bool,
            default_value="True",
            explanation="If True, large models with more than 3000 customers will be automatically clustered to have less than 3000 nodes during the optimization phase. Clustomers are then disaggregated for outputs.",
            precision_category=["NaN"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ClusteringApproach",
            data_type=ClusteringApproach,
            default_value="utm",
            explanation="The method used to identify customer clusters. The 'fcluster' method requires a computation of the full distance matrix between all customers pairs which can be a time consuming process. The 'utm' method is based on the Universal Transverse Mercator (UTM) coordinate system looks to identify clusters in each UTM zone. While UTM based method may in some cases be less accurate it does not to precompute the full distance matrix between all customer pairs.",
            precision_category=["NaN"],
            triad=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
