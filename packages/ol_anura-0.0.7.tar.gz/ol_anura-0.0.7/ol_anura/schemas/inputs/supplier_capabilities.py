"""SupplierCapabilities table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, Status, TechnologySupport

# SupplierCapabilities table schema
supplier_capabilities = Table(
    table_name="SupplierCapabilities",
    neo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="SupplierCapabilities",
    fixed_tags=["Suppliers", "Supplier", "Policies", "Production"],
    basic_mode_neo=True,
    in_database=True,
    fields=[
        Column(
            column_name="SupplierName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Suppliers"],
            expandable=True,
            explanation="The Supplier at which the listed product will be available at",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Suppliers.SupplierName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Products"],
            expandable=True,
            explanation="The Product that will be available at the listed Supplier",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            master_column=["Products.ProductName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the policy exists in the model. If Status is set to Exclude, the policy record is ignored during the model run.",
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnitCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [All Item, Incremental, Stepwise]",
            master_table=["StepCosts"],
            default_value="0",
            explanation="The unit cost of the listed Supplier creating the Product. This field can support either a single numeric value or a defined step cost",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnitCostUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="UnitCost",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The UOM that specifies what unit the Unit Cost will be applied over. This can be any UOM of Type = Quantity, Weight, Volume.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SupplyCapacity",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="The maximum amount for the listed product, across all destinations, that can be procured from the Supplier.",
            precision_category=["Quantity"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SupplyCapacityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required_if="SupplyCapacity",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines Max Supply Amount. Quantity, Volume, and Weight units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CO2EmissionRate",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="NonNegative",
            default_value="0",
            explanation="The rate of CO2 emissions for this supplier capability.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CO2EmissionRateUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="CO2EmissionRate",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure (Type = Quantity, Volume, Weight) that defines the CO2 Emission Rate.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            basic_mode=["NEO"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
