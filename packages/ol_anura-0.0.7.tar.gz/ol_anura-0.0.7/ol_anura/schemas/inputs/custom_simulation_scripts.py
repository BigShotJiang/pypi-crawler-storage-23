"""CustomSimulationScripts table schema definition."""

import sys
from pathlib import Path
from enum import Enum

from ...core import DataType, Column, Table, TechnologySupport


class CustomScriptPolicyType(str, Enum):
    """CustomScriptPolicyType values."""
    INVENTORY = "Inventory"
    ONMODELSTART = "OnModelStart"
    PRODUCTION = "Production"
    RECURRINGEVENT = "RecurringEvent"
    SOURCING = "Sourcing"
    TRANSPORTATION = "Transportation"

# CustomSimulationScripts table schema
custom_simulation_scripts = Table(
    table_name="CustomSimulationScripts",
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="CustomSimulationScripts",
    in_database=True,
    fields=[
        Column(
            column_name="CustomScriptName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            expandable=True,
            explanation="The name of the custom script. Depending on the Script Policy Type, this name can be entered into the SIM Policy field of the Transportation, Production, Inventory, Customer Fulfillment, Replenishment or Procurement Policy tables.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CustomScriptPolicyType",
            data_type=CustomScriptPolicyType,
            required=True,
            expandable=True,
            explanation="The type of policy the script has been built to enforce. If the policy is set to Transportation, Production, Inventory or Sourcing then the Script Name must be referenced in the corresponding Policy table. If the Policy Type is set to be On Model Start, it will execute at the beginning of the model. If the Policy Type is set to Recurring Event it will begin on the entered Start Date, will be repeatedly executed based on the Time Between Events, and then will stop on the End Date.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ExecutablePath",
            data_type=DataType.STRING,
            required=True,
            explanation="The path to where the python file is saved.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StartDate",
            data_type=DataType.DATETIME,
            explanation="For a Policy Type of Recurring Event, the Start Date will specify the first point in the simulation at which the script will execute.",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="TimeBetweenEvents",
            data_type=DataType.DOUBLE,
            explanation="For a Policy Type of Recurring Event, the Time Between Events will specify how the interval at which the policy will be evaluated.",
            precision_category=["Time"],
            in_database=True
        ),
        Column(
            column_name="TimeBetweenEventsUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["UnitsOfMeasure"],
            explanation="The unit of measure that time is evaluated in.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="EndDate",
            data_type=DataType.DATETIME,
            explanation="For a Policy Type of Recurring Event, the End Date will specify the last point in the simulation at which the script will execute.",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
