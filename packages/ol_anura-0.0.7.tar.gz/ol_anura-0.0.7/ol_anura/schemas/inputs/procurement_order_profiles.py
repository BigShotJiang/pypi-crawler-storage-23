"""ProcurementOrderProfiles table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, Status, TechnologySupport

# ProcurementOrderProfiles table schema
procurement_order_profiles = Table(
    table_name="ProcurementOrderProfiles",
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="ProcurementOrderProfiles",
    fixed_tags=["Facilities", "Facility", "Supplier", "Order"],
    in_database=True,
    fields=[
        Column(
            column_name="OrderID",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The unique identifier for each Order profile, as orders are generated based on their recurring properties they will be indexed off of the entered order number. All Orders will be placed as single line item orders, however multiple recurring orders can be set at the same Facility",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            master_table=["Facilities"],
            explanation="The name of the Facility placing the Order",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            master_table=["Products"],
            explanation="The Product that the Order will be placed for",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the Order profile exists in the model. If Status is set to Exclude, this  record will be ignored during the model run.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Quantity",
            data_type=DataType.STRING,
            explanation="The amount of Product being ordered by the Facility. Both doubles, as well as distributions are accepted as entries.",
            precision_category=["Quantity"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="QuantityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required_if="Quantity",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines Quantity. Quantity, Volume, and Weight units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="NumberOfOrders",
            data_type=DataType.STRING,
            default_value="1",
            explanation="Based on the information entered in the Start Date, Time Between Orders and End Date fields, the Order Profile will generate orders based at different times throughout the simulation. When an order is generated, the Number Of Orders will be evaluated to determine how many orders are going to be placed at that specific time. Once the Number Of Orders is determined, all of the other information specified in the Product Name, Quantity, Number of Lines will be used to generate the details for each of the orders at that time.",
            precision_category=["Integer"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="NumberOfLines",
            data_type=DataType.STRING,
            default_value="1",
            explanation="If the Product Name is left blank for the Order Profile, recurring orders can be generated with a varying number of line items in each order. An integer value, or a distribution can be entered in this field. In the event that the number of lines in an order is 2 or greater, the Order Profile Product Selection and Order Profile Product Affinity tables will be used to determine which products are to be ordered.",
            precision_category=["Integer"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ServiceLevel",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="Service Level will be used to calculate the Due Date for all of the generated recurring orders. Due Date will be set to the Order Date + Service Level.",
            precision_category=["Time"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ServiceLevelUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required_if="ServiceLevel",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure (Type = Time) used to define Service Level.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StartDate",
            data_type=DataType.DATETIME,
            explanation="The Start Date will defined the date that the first order will drop. Orders will drop exactly at the date/time specified in Start Date, and then each following order's drop date will be determined by the Time Between Orders information.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TimeBetweenOrders",
            data_type=DataType.STRING,
            explanation="Time Between Orders will specify how much time goes by from the previous order until the next order drops. Both doubles, as well as distribution entries are supported.",
            precision_category=["Time"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TimeBetweenOrdersUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required_if="TimeBetweenOrders",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure (Type = Time) used to define Time Between Orders.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="EndDate",
            data_type=DataType.DATETIME,
            explanation="The End Date will specify the last possible time that an order can drop. If the Time Between Orders causes the next order drop date to fall after the specified End Date, that last order will not be generated.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            in_database=True
        ),
    ]
)
