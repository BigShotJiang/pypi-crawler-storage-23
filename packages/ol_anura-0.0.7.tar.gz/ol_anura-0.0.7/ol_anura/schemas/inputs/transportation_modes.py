"""TransportationModes table schema definition."""

import sys
from pathlib import Path
from enum import Enum

from ...core import DataType, Column, Table, BehaviorRule, FixedCostRule, Status, TechnologySupport


class FuelSurchargeBasis(str, Enum):
    """FuelSurchargeBasis values."""
    PER_UNIT = "Per Unit"
    PERCENTAGE = "Percentage"

class ModeSpeedUOM(str, Enum):
    """ModeSpeedUOM values."""
    KPH = "KPH"
    MPH = "MPH"

# TransportationModes table schema
transportation_modes = Table(
    table_name="TransportationModes",
    neo=TechnologySupport.FULLY_SUPPORTED,
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    cyclo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="TransportationModes",
    fixed_tags=["Transport"],
    basic_mode_throg=True,
    basic_mode_dendro=True,
    basic_mode_cyclo=True,
    in_database=True,
    fields=[
        Column(
            column_name="ModeName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the Transportation Mode. This value can be referenced in other tables involving Transportation Modes.",
            precision_category=["NaN"],
            basic_mode=["THROG"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BehaviorRule",
            data_type=BehaviorRule,
            required=True,
            default_value="FTL",
            explanation="The rule that governs the behavior for any flows that use this Mode. This is a SIM-specific field.",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="AssetName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["TransportationAssets"],
            explanation="The name of the Transportation Asset assigned to this Mode. Capacity, Fill Level, and Cost fields in this table will be overwritten by those of the specified Asset (if one is given).",
            precision_category=["NaN"],
            master_column=["TransportationAssets.AssetName"],
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the Mode exists in the model. If Status is set to Exclude, the Mode is ignored in all tables.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnitCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [All Item, Incremental, Stepwise]",
            master_table=["StepCosts", "TransportationBandCosting"],
            default_value="0",
            notes="Optimization: Currently supports doubles and named step costs that are defined in the StepCosts table where StepCostBehavior = All Item, Incremental or Stepwise or a combination of Stepwise and All Item",
            explanation="The cost associated with each unit of flow transported using this Mode. This field can support a single numeric value, a step cost lookup (defined in the Step Costs table), transportation rate, or a custom cost function. If a cost is entered on a record using this Mode in the Transportation Policies table, that cost will override the one entered here.",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName", "TransportationBandCosting.RateName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnitCostUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight, Time, Distance, Quantity-Distance, Volume-Distance, Weight-Distance, Quantity-Time, Volume-Time, Weight-Time]",
            required_if="UnitCost",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight", "Time", "Distance", "Quantity-Distance", "Volume-Distance", "Weight-Distance", "Quantity-Time", "Volume-Time", "Weight-Time"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines Unit Cost. Quantity, Volume, Weight, Distance, Time, Quantity-Distance, Quantity-Time, Volume-Distance, Volume-Time, Weight-Distance, and Weight-Time units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FixedCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [All Item, Incremental, Stepwise]",
            master_table=["StepCosts", "TransportationBandCosting"],
            default_value="0",
            notes="Optimization: Currently supports doubles and named step costs that are defined in the StepCosts table where StepCostBehavior = All Item, Incremental or Stepwise or a combination of Stepwise and All Item",
            explanation="The cost associated with a shipment made under the specified Source/Destination/Product/Mode combination. The Average Shipment Size will be used to estimate the number of shipments that occurred; the Fixed Cost will be applied to the estimated number of shipments according to the Fixed Cost Rule.",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName", "TransportationBandCosting.RateName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FixedCostRule",
            data_type=FixedCostRule,
            default_value="Prorate",
            explanation="The rule by which Fixed Cost is applied to the estimated number of shipments. The cost can be prorated in the event that the estimated number of shipments is not an integer. If the selected rule is Treat as Full, the estimated number of shipments will be rounded up and the fixed cost will be applied accordingly.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AverageShipmentSize",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            default_value="1",
            explanation="The average shipment size associated with this Source/Destination/Product/Mode combination. This figure will be used to estimate the fixed cost of shipments and will also be used in combination with any Time or Distance Unit Costs. If NULL, a default value of one unit will be assumed.",
            precision_category=["Quantity"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AverageShipmentSizeUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="AverageShipmentSize",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines Average Shipment Size. Quantity, Volume, and Weight units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FuelSurcharge",
            data_type=DataType.DOUBLE,
            default_value="0",
            explanation="The Fuel surcharge applied to this mode.",
            precision_category=["Cost"],
            in_database=True
        ),
        Column(
            column_name="FuelSurchargeBasis",
            data_type=FuelSurchargeBasis,
            default_value="Percentage",
            explanation="The Basis for the fuel surcharge applied to this mode. If percentage is selected, surcharge per unit = UnitCost*(1+ FuelSurcharge). If Per Unit is selected then surcharge per unit = FuelSurcharge",
            precision_category=["Cost"],
            in_database=True
        ),
        Column(
            column_name="QuantityCapacity",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="The capacity (quantity) of the Mode. The most restrictive capacity given in this record (among quantity, volume, and weight) will be applied to the Mode.",
            precision_category=["Quantity"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="QuantityCapacityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity]",
            required_if="QuantityCapacity",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure (Type = Quantity) that defines Quantity Capacity.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="QuantityFillLevel",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="The fill level of the Mode (quantity). Quantity Fill Level is the minimum quantity of items required for the Mode to depart.",
            precision_category=["Quantity"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="QuantityFillLevelUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity]",
            required_if="QuantityFillLevel",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure (Type = Quantity) that defines Quantity Fill Level.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VolumeCapacity",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="The capacity (volume) of the Mode. The most restrictive capacity given in this record (among quantity, volume, and weight) will be applied to the Mode.",
            precision_category=["Volume"],
            basic_mode=["THROG"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VolumeCapacityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Volume]",
            required_if="VolumeCapacity",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Volume"],
            default_value="{PrimaryVolumeUOM}",
            explanation="The unit of measure (Type = Volume) that defines Volume Capacity.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VolumeFillLevel",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="The fill level of the Mode (volume). Volume Fill Level is the minimum volume of items required for the Mode to depart.",
            precision_category=["Volume"],
            basic_mode=["THROG"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VolumeFillLevelUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Volume]",
            required_if="VolumeFillLevel",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Volume"],
            default_value="{PrimaryVolumeUOM}",
            explanation="The unit of measure (Type = Volume) that defines Volume Fill Level.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WeightCapacity",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="The capacity (weight) of the Mode. The most restrictive capacity given in this record (among quantity, volume, and weight) will be applied to the Mode.",
            precision_category=["Weight"],
            basic_mode=["THROG"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WeightCapacityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Weight]",
            required_if="WeightCapacity",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Weight"],
            default_value="{PrimaryWeightUOM}",
            explanation="The unit of measure (Type = Weight) that defines Weight Capacity.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WeightFillLevel",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="The fill level of the Mode (weight). Weight Fill Level is the minimum volume of items required for the Mode to depart.",
            precision_category=["Weight"],
            basic_mode=["THROG"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WeightFillLevelUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Weight]",
            required_if="WeightFillLevel",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Weight"],
            default_value="{PrimaryWeightUOM}",
            explanation="The unit of measure (Type = Weight) that defines Weight Fill Level.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TransportTime",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="NonNegative",
            explanation="The time required to travel from the Source to the Destination for the specific Product/Mode combination. This is meant to be a function that is attached to the mode and should be evaluated at the transportation policy tables",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="TransportTimeUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Time]",
            required_if="TransportTime",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure (Type = Time) that defines Transport Time.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="ModeSpeed",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="The speed of the Mode.",
            precision_category=["Quantity"],
            in_database=True
        ),
        Column(
            column_name="ModeSpeedUOM",
            data_type=ModeSpeedUOM,
            required_if="ModeSpeed",
            default_value="{PrimarySpeedUOM}",
            explanation="The unit of measure (Type = Speed) that defines Mode Speed.",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="CO2EmissionRate",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="NonNegative",
            default_value="0",
            explanation="The rate of CO2 emissions for this transportation mode.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="CO2EmissionRateUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight, Distance, Time, Quantity-Distance, Volume-Distance, Weight-Distance, Quantity-Time, Volume-Time, Weight-Time]",
            required_if="CO2EmissionRate",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight", "Distance", "Time", "Quantity-Distance", "Volume-Distance", "Weight-Distance", "Quantity-Time", "Volume-Time", "Weight-Time"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure (Type = Quantity, Volume, Weight, Distance, Time, Quantity-Distance, Volume-Distance, Weight-Distance, Quantity-Time, Volume-Time, Weight-Time) that defines the CO2 Emission Rate. If a UOM of Type = Distance is used, then the CO2 generated will be based off of the number of shipments - this would be calculated as the (Flow / Shipment Size) * Distance * CO2 Emission Rate.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ConsolidateToDueDate",
            data_type=bool,
            default_value="False",
            explanation="If True, Orders in the queue wait until they must leave to meet their earliest due date. If a new order arrives with an urgent due date that is already at risk, the shipment departs immediately.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            basic_mode=["THROG"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
