"""TransportationPoliciesMultiTimePeriod table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, FixedCostRule, GroupBehavior, InventoryOwnership, PolicyStatus, Status, TechnologySupport
from .transportation_policies import FuelSurchargeBasis, OptimizationPolicy, SimulationPolicy

# TransportationPoliciesMultiTimePeriod table schema
transportation_policies_multi_time_period = Table(
    table_name="TransportationPoliciesMultiTimePeriod",
    neo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="TransportationPoliciesMTP",
    fixed_tags=["Multi", "Time", "Period"],
    in_database=True,
    fields=[
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Periods"],
            expandable=True,
            explanation="The period name in which a change is being made. Groups of periods are also supported. Changes that are made in the Multi Time Period table will be applied as overrides for the records of the base table for the specified periods only. Additionally, only the fields that contain information needing to be updated are required to be entered, in the absence of data in the Multi Time Period table the data from the standard table will be persisted",
            precision_category=["NaN"],
            master_column=["Periods.PeriodName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OriginName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Facilities", "Suppliers", "Customers", "Sources"],
            expandable=True,
            explanation="The source Facility or Supplier that the policy record applies to.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DestinationName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Customers", "Facilities", "Destinations"],
            expandable=True,
            explanation="The Customer or destination Facility that the policy record applies to.",
            precision_category=["NaN"],
            master_column=["Customers.CustomerName", "Facilities.FacilityName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Products"],
            expandable=True,
            explanation="The Product that the policy record applies to. If NULL, the policy will be applied to all products in the model.",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ModeName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            pk=True,
            master_table=["TransportationModes"],
            expandable=True,
            default_value="None",
            explanation="The Transportation Mode that the policy record applies to.",
            precision_category=["NaN"],
            master_column=["TransportationModes.ModeName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the multi-time period record exists in the model. If Status is set to Exclude, the record is ignored during the model run.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="PolicyStatus",
            data_type=PolicyStatus,
            explanation="Policy Status dictates whether or not the policy exists in the model for the specified period(s). If Policy Status is set to Exclude, the policy record is ignored during the model run.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OptimizationPolicy",
            data_type=OptimizationPolicy,
            explanation="The logic that transportation flows for the Origin, Destination, and Product combination(s) must follow when selecting a Mode. To Optimize selects the lowest cost option. By Ratio (Auto Scale) will enforce a flow split between the specified Modes, the defined ratios will apply to flow into the Facility from the listed Modes only. By Ratio (No Scale) will enforce a flow split between the specified Modes and the defined ratios will be in terms of the total flow between the Origin/Destination pair for the specified product. Note that the Product Name Group Behavior field will be used when applying the policy logic - if a group is entered in the Product Name field and a Group Behavior of Aggregate is selected, the policy logic will apply over the group of products collectively.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OptimizationPolicyValue",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            required_if="OptimizationPolicy = By Ratio (Auto Scale) OR By Ratio (No Scale)",
            explanation="By Ratio (Auto Scale): The Policy Value will define the percentage of flow that must be satisfied by the listed Mode. The percentage will be calculated based on the total flow between the Origin/Destination pair for the specified product. If the Policy Values do not add up to 100, the ratios will be automatically scaled and enforced.\n\nBy Ratio (No Scale): The Policy Value will define the percentage of flow that must be satisfied by the listed Mode. The percentage will be calculated based on the total flow between the Origin/Destination pair for the specified product. If the Policy Values add up to less than 100, the remaining flow between the Origin/Destination pair for the specified product can be satisfied using any other available Modes.",
            precision_category=["Percentage"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SimulationPolicy",
            data_type=SimulationPolicy,
            explanation="The logic applied for Mode Selection for specified Source/Destination/Product combinations. By Preference will select Modes, pending availability, in the order of preference specified in the SIM Policy Value field. By Due Date will select the highest priority mode that is available which can reach the destination by the due date of the shipment moving on the lane. On Quantity, On Volume, and On Weight will send shipments on the mode once the value specified in SIM Policy Value is met for the number of items being sent on that shipment. By Cut off Time finds the next mode in the list with a cut off time after the current time.  If no cut off time is after current time then it wraps back to the first time. By Cut Off Time Default Last works the same as By Cut Off Time, but the last policy will be treated as the default rather than wrapping around to the earliest.",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="SimulationPolicyValue",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            required_if="SimulationPolicy = By Preference OR On Quantity OR On Volume OR On Weight",
            explanation="The values used to define policies. For By Preference and By Due Date, the lower the value the higher the preference. For On Quantity, On Volume, and On Weight the value will reference the shipment amount at which a shipment is sent. These will be expressed in units of EA, CFT, and LB respectively.",
            precision_category=["Percentage"],
            in_database=True
        ),
        Column(
            column_name="UnitCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [All Item, Incremental, Stepwise]",
            master_table=["StepCosts", "TransportationBandCosting"],
            notes="Optimization: Currently supports doubles and named step costs that are defined in the StepCosts table where StepCostBehavior = All Item, Incremental or Stepwise or a combination of Stepwise and All Item",
            explanation="The cost associated with one unit of flow for the Facilities/Product/Mode combination. This field can support a single numeric value, a step cost lookup (defined in the Step Costs table), transportation rate, or a custom cost function.",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName", "TransportationBandCosting.RateName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnitCostUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight, Time, Distance, Quantity-Distance, Volume-Distance, Weight-Distance, Quantity-Time, Volume-Time, Weight-Time]",
            required_if="UnitCost",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight", "Time", "Distance", "Quantity-Distance", "Volume-Distance", "Weight-Distance", "Quantity-Time", "Volume-Time", "Weight-Time"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines Unit Cost. UOM Types of Quantity, Volume, Weight, Distance, Time, Quantity-Distance, Quantity-Time, Volume-Distance, Volume-Time, Weight-Distance, and Weight-Time are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FixedCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [All Item, Incremental, Stepwise]",
            master_table=["StepCosts", "TransportationBandCosting"],
            notes="Optimization: Currently supports doubles and named step costs that are defined in the StepCosts table where StepCostBehavior = All Item, Incremental or Stepwise or a combination of Stepwise and All Item",
            explanation="The cost associated with a shipment made under the specified Origin/Destination/Product/Mode combination. The Average Shipment Size will be used to estimate the number of shipments that occurred; the Fixed Cost will be applied to the estimated number of shipments according to the Fixed Cost Rule. If a step cost is used, the steps will be evaluated in terms of the number of shipments that are sent over the Origin/Destination/Product/Mode combination.",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName", "TransportationBandCosting.RateName"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FixedCostRule",
            data_type=FixedCostRule,
            explanation="The rule by which Fixed Cost is applied to the estimated number of shipments. The cost can be prorated in the event that the estimated number of shipments is not an integer. If the selected rule is Treat as Full, the estimated number of shipments will be rounded up and the fixed cost will be applied accordingly.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AverageShipmentSize",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="The average shipment size associated with this Origin/Destination/Product/Mode combination. This figure will be used to estimate the fixed cost of shipments and will also be used in combination with any Time or Distance Unit Costs. If NULL, a default value of one unit will be assumed.",
            precision_category=["Quantity"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AverageShipmentSizeUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="AverageShipmentSize",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines Average Shipment Size. Quantity, Volume, and Weight units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductNameGroupBehavior",
            data_type=GroupBehavior,
            explanation="When determining the number of shipments to apply the Fixed Cost over, Product Name Group Behavior can describe how records for grouped products should be considered. If Enumerate is selected, Fixed Costs will be applied over each product in the group individually. If Aggregate is selected, the total flow of all products in the group will be used to determine how many shipments were sent. The same logic will apply for calculating what level of Step Costs to apply for a Unit Cost",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DutyRate",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="The Duty Rate will be applied as a percentage of the product's value that is moving along this Origin / Destination / Mode combination. For a Duty Rate of 10%, enter a value of 10 into the Duty Rate field",
            precision_category=["Percentage"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FuelSurcharge",
            data_type=DataType.DOUBLE,
            explanation="The Fuel surcharge applied to this policy for the given period.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FuelSurchargeBasis",
            data_type=FuelSurchargeBasis,
            default_value="Percentage",
            explanation="The Basis for the fuel surcharge applied to this policy. If percentage is selected, surcharge per unit = UnitCost*(1+ FuelSurcharge). If Per Unit is selected then surcharge per unit = FuelSurcharge",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="LaneCapacity",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="The capacity that applies over the Origin, Destination, Product combination. Capacities can be expressed in terms of flow quantity, volume, weight, or in terms of the number of shipments that are sent along the lane. This capacity will be measured over the time period specified in the Lane Capacity Period field.",
            precision_category=["Quantity"],
            in_database=True
        ),
        Column(
            column_name="LaneCapacityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight, Shipment]",
            required_if="LaneCapacity",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight", "Shipment"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines the Lane Capacity. UOM Types of Quantity, Volume, Weight, and Shipment are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="LaneCapacityPeriod",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="The time period over which the Lane Capacity is evaluated. If a Lane Capacity was set at 50 shipments per week, Lane Capacity = 50, Lane Capacity UOM = SHIPMENT, Lane Capacity Period = 1, Lane Capacity Period UOM = WK",
            precision_category=["Time"],
            in_database=True
        ),
        Column(
            column_name="LaneCapacityPeriodUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Time]",
            required_if="LaneCapacityPeriod",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure (Type = Time) that defines the Lane Capacity Period.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="LaneModeCapacity",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="The capacity that applies over the Origin, Destination, Product, Mode combination. Capacities can be expressed in terms of flow quantity, volume, weight, or in terms of the number of shipments that are sent along the lane/mode combination. This capacity will be measured over the time period specified in the Lane Capacity Period field.",
            precision_category=["Quantity"],
            in_database=True
        ),
        Column(
            column_name="LaneModeCapacityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight, Shipment]",
            required_if="LaneModeCapacity",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight", "Shipment"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines the Lane Mode Capacity. UOM Types of Quantity, Volume, Weight, and Shipment are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="LaneModeCapacityPeriod",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="The time period over which the Lane Mode Capacity is evaluated. If a Lane Mode Capacity was set at 50 shipments per week, Lane Mode Capacity = 50, Lane Mode Capacity UOM = SHIPMENT, Lane Mode Capacity Period = 1, Lane Mode Capacity Period UOM = WK",
            precision_category=["Time"],
            in_database=True
        ),
        Column(
            column_name="LaneModeCapacityPeriodUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Time]",
            required_if="LaneModeCapacityPeriod",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure (Type = Time) that defines the Lane Mode Capacity Period.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="InventoryOwnership",
            data_type=InventoryOwnership,
            explanation="This field will determine whether the in-transit inventory costs will be assigned to the origin or the destination for products flowing on this transportation lane.",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="InventoryCarryingCostPercentage",
            data_type=DataType.DOUBLE,
            validation_type="Percentage",
            default_value="{InventoryCarryingCostPercentage}",
            explanation="The percentage of the product value that the in-transit inventory cost will consider. The in-transit inventory cost will be calculated as an annual cost, with the cost calculation being Product Value * Cost Percentage * (Transport Time in DAY / 365)",
            precision_category=["Percentage"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TimeBetweenDeliveries",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="The amount of time between delivers for this lane. Given the time between deliveries, the number of deliveries will be calculated for the length of the period. Then, total flow of for the  lane will be divided by the number of deliveries to determine the Transportation Estimated Inventory. In the event that the Time Between Deliveries is longer than the length of the Period, the Transportation Estimated Inventory will be calculated based off of the proportion of the calculated delivery window that falls within the period.",
            precision_category=["Time"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TimeBetweenDeliveriesUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required_if="TimeBetweenDeliveries",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure that defines the Time Between Deliveries. Time units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="LoadProcessName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["Processes"],
            explanation="The Processes table record that can be used to add detail to the initialization of the transportation policy at the Source under the specified Origin/Destination/Product/Mode combination. This field allows us to associate processing times, costs, and resource consumption with the beginning of the transportation process.",
            precision_category=["NaN"],
            master_column=["Processes.ProcessName"],
            in_database=True
        ),
        Column(
            column_name="UnloadProcessName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["Processes"],
            explanation="The Processes table record that can be used to add detail to the conclusion of the transportation policy at the Destination under the specified Origin/Destination/Product/Mode combination. This field allows us to associate processing times, costs, and resource consumption with the end of the transportation process.",
            precision_category=["NaN"],
            master_column=["Processes.ProcessName"],
            in_database=True
        ),
        Column(
            column_name="CO2EmissionRate",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="NonNegative",
            explanation="The rate of CO2 emissions for this transportation policy for the given period.",
            precision_category=["Cost"],
            in_database=True
        ),
        Column(
            column_name="CO2EmissionRateUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight, Distance, Time, Quantity-Distance, Volume-Distance, Weight-Distance, Quantity-Time, Volume-Time, Weight-Time]",
            required_if="CO2EmissionRate",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight", "Distance", "Time", "Quantity-Distance", "Volume-Distance", "Weight-Distance", "Quantity-Time", "Volume-Time", "Weight-Time"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure (Type = Quantity, Volume, Weight, Distance, Time, Quantity-Distance, Volume-Distance, Weight-Distance, Quantity-Time, Volume-Time, Weight-Time) that defines the CO2 Emission Rate. If a UOM of Type = Distance is used, then the CO2 generated will be based off of the number of shipments - this would be calculated as the (Flow / Shipment Size) * Distance * CO2 Emission Rate.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True
        ),
        Column(
            column_name="RoutePlannerName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["TransportationRoutePlanners"],
            precision_category=["NaN"],
            master_column=["TransportationRoutePlanners.RoutePlannerName"],
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
