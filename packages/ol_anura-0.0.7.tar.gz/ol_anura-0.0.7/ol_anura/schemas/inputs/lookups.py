"""Lookups table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# Lookups table schema
lookups = Table(
    table_name="Lookups",
    neo=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="Lookups",
    in_database=True,
    fields=[
        Column(
            column_name="LookupName",
            data_type=DataType.STRING,
            pk=True,
            explanation="The name assigned to this lookup. This name can be referenced in other input tables, at which point the lookup will attempt to pull in the Source Value based on the mappings defined in the Source Column and Destination Column fields.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Source",
            data_type=DataType.STRING,
            explanation="The location where SourceTable can be found. If the data exists in another database, put the database name here. If blank, SourceTable must be part of this Frog Model.",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="SourceTable",
            data_type=DataType.STRING,
            explanation="The table that will serve as the data source for the lookup. Values will be pulled from the column listed in the Source Value field based on the mappings specified in the Source Column and Destination Column Mapping fields",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DestinationTable",
            data_type=DataType.STRING,
            explanation="The table in the ANURA database that the lookup will be used in.",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SourceColumnMapping",
            data_type=DataType.STRING,
            pk=True,
            explanation="The Source Column Mapping and Destination Column Mapping fields will specify the columns in the listed Source Table and the Input Table where the lookup is referenced that a join will be defined over.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DestinationColumnMapping",
            data_type=DataType.STRING,
            pk=True,
            explanation="The Source Column Mapping and Destination Column Mapping fields will specify the columns in the listed Source Table and the Input Table where the lookup is referenced that a join will be defined over. The Destination Column will support the use of a dot operator to reference columns in the associated master table, if applicable. For example, the Destination Column could be listed as ProductName.UnitWeight and this would be referencing the Unit Weight entry in the Products table for whatever product the lookup is being evaluated over.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="IsRangeLookup",
            data_type=bool,
            explanation="The Is Range Lookup field will define whether or not the mapping for the Source / Destination Column mapping fields should be an exact match (Range Lookup = FALSE) or a ranged lookup (Range Lookup = True). If a value of True is entered, the value from the Source column will be evaluated against those in the Destination Column where the Destination values will serve as lower bounds for the different bands.",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SourceValue",
            data_type=DataType.STRING,
            explanation="The column from the Source Table that is the be populated into the input filed where the Lookup is called.",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DefaultValue",
            data_type=DataType.STRING,
            explanation="If a lookup fails to return a value for a record, the Default Value will be inserted instead.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
