"""RiskBandDefinitions table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# RiskBandDefinitions table schema
risk_band_definitions = Table(
    table_name="RiskBandDefinitions",
    neo=TechnologySupport.FULLY_SUPPORTED,
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    triad=TechnologySupport.FULLY_SUPPORTED,
    dart=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="RiskBandDefinitions",
    in_database=True,
    fields=[
        Column(
            column_name="BandName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the Risk Band. Risk Bands are referenced by name in all of the Risk Configuration tables. Bands are defined based on a series of levels and associated Risk Scores and when the DART engine is run the corresponding scores will be assigned to all places where the Risk Band is called in the configuration tables.",
            precision_category=["NaN"],
            dart=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BandLowerValue",
            data_type=DataType.DOUBLE,
            required=True,
            pk=True,
            explanation="The lower bound of the step that the Risk Score will be applied over.",
            precision_category=["Risk"],
            dart=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RiskScore",
            data_type=DataType.DOUBLE,
            validation_type="RiskScore",
            required=True,
            pk=True,
            explanation="The Risk Score that will be selected based on the corresponding band's lower value.",
            precision_category=["Risk"],
            dart=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            dart=TechnologySupport.FULLY_SUPPORTED,
            neo=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
