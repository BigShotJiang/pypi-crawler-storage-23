"""InputFactors table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, Status, TechnologySupport

# InputFactors table schema
input_factors = Table(
    table_name="InputFactors",
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="InputFactors",
    in_database=True,
    fields=[
        Column(
            column_name="InputFactorName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the Input Factor (SIM-specific); Input Factors correspond to values (\"genes\") that are allowed to be adjusted in the genetic algorithm (GA). The GA will iteratively run the simulation with modified genes to improve the model outcomes according to the Utility Level field of the Output Factors table.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TableName",
            data_type=DataType.STRING,
            validation_type="Valid Input Table",
            required=True,
            explanation="The name of the table that contains the data which the Input Factor can adjust.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ColumnName",
            data_type=DataType.STRING,
            validation_type="Valid Column Name",
            required=True,
            explanation="The name of the column (within the specified table) that the Input Factor will adjust.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Filter",
            data_type=DataType.STRING,
            validation_type="Valid Filter",
            explanation="The filter to apply to the specified column and table (optional).",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="BaseValue",
            data_type=DataType.DOUBLE,
            explanation="The value used to initialize the Input Factor. If left empty, the value from the cell in the Input Table being referenced will be used as the base value.",
            precision_category=["Quantity"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MinValue",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="The minimum value that the Input Factor is allowed to take in any iteration.",
            precision_category=["Quantity"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MaxValue",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="The maximum value that the Input Factor is allowed to take in any iteration.",
            precision_category=["Quantity"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="StepSize",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="The increments by which the Input Factor is allowed to be adjusted. Min Value and Max Value will always be allowed even if they cannot be reached from Base Value in increments of this size.",
            precision_category=["Quantity"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RelativeValues",
            data_type=bool,
            explanation="If True, the values specified for Min Value, Max Value and Step Size will be relative percentages of the Base Value. For example, if Base Value = 200, Min Value = 50 and RelativeValues = TRUE then the Minimum Value that van be used would be 100.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Enumerate",
            data_type=DataType.STRING,
            explanation="Optionally, a list of values which the Input Factor is allowed to take. These values should be entered as [ Value 1 | Value 2 | Value 3 | … ]. If both the Base Value and Enumerate fields are populated, the values specified in Enumerate will be used.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            explanation="Status dictates whether or not the Input Factor is included when running the genetic algorithm.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
