"""BusinessHours table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, TechnologySupport

# BusinessHours table schema
business_hours = Table(
    table_name="BusinessHours",
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    hopper=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="BusinessHours",
    in_database=True,
    fields=[
        Column(
            column_name="ScheduleName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the schedule defining hours of operation for each day of the week; this value can be referenced in tables dealing with work schedules.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SundayOpenTime",
            data_type=DataType.TIME,
            pk=True,
            explanation="The time on Sunday that the Facility, Customer, or TransportationAsset opens. Times should be entered in the 24 hour format of HH:MM - for example 6:00 AM would be 06:00 and 4 PM would be 16:00. If entries for Open and Close Times are left blank, this will be treated as Closed for that day.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SundayCloseTime",
            data_type=DataType.TIME,
            pk=True,
            explanation="The time on Sunday that the Facility, Customer, or TransportationAsset closes. Times should be entered in the 24 hour format of HH:MM - for example 6:00 AM would be 06:00 and 4 PM would be 16:00. If entries for Open and Close Times are left blank, this will be treated as Closed for that day.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MondayOpenTime",
            data_type=DataType.TIME,
            pk=True,
            explanation="The time on Monday that the Facility, Customer, or TransportationAsset opens. Times should be entered in the 24 hour format of HH:MM - for example 6:00 AM would be 06:00 and 4 PM would be 16:00. If entries for Open and Close Times are left blank, this will be treated as Closed for that day.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MondayCloseTime",
            data_type=DataType.TIME,
            pk=True,
            explanation="The time on Monday that the Facility, Customer, or TransportationAsset closes. Times should be entered in the 24 hour format of HH:MM - for example 6:00 AM would be 06:00 and 4 PM would be 16:00. If entries for Open and Close Times are left blank, this will be treated as Closed for that day.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TuesdayOpenTime",
            data_type=DataType.TIME,
            pk=True,
            explanation="The time on Tuesday that the Facility, Customer, or TransportationAsset opens. Times should be entered in the 24 hour format of HH:MM - for example 6:00 AM would be 06:00 and 4 PM would be 16:00. If entries for Open and Close Times are left blank, this will be treated as Closed for that day.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TuesdayCloseTime",
            data_type=DataType.TIME,
            pk=True,
            explanation="The time on Tuesday that the Facility, Customer, or TransportationAsset closes. Times should be entered in the 24 hour format of HH:MM - for example 6:00 AM would be 06:00 and 4 PM would be 16:00. If entries for Open and Close Times are left blank, this will be treated as Closed for that day.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WednesdayOpenTime",
            data_type=DataType.TIME,
            pk=True,
            explanation="The time on Wednesday that the Facility, Customer, or TransportationAsset opens. Times should be entered in the 24 hour format of HH:MM - for example 6:00 AM would be 06:00 and 4 PM would be 16:00. If entries for Open and Close Times are left blank, this will be treated as Closed for that day.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WednesdayCloseTime",
            data_type=DataType.TIME,
            pk=True,
            explanation="The time on Wednesday that the Facility, Customer, or TransportationAsset closes. Times should be entered in the 24 hour format of HH:MM - for example 6:00 AM would be 06:00 and 4 PM would be 16:00. If entries for Open and Close Times are left blank, this will be treated as Closed for that day.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ThursdayOpenTime",
            data_type=DataType.TIME,
            pk=True,
            explanation="The time on Thursday that the Facility, Customer, or TransportationAsset opens. Times should be entered in the 24 hour format of HH:MM - for example 6:00 AM would be 06:00 and 4 PM would be 16:00. If entries for Open and Close Times are left blank, this will be treated as Closed for that day.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ThursdayCloseTime",
            data_type=DataType.TIME,
            pk=True,
            explanation="The time on Thursday that the Facility, Customer, or TransportationAsset closes. Times should be entered in the 24 hour format of HH:MM - for example 6:00 AM would be 06:00 and 4 PM would be 16:00. If entries for Open and Close Times are left blank, this will be treated as Closed for that day.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FridayOpenTime",
            data_type=DataType.TIME,
            pk=True,
            explanation="The time on Friday that the Facility, Customer, or TransportationAsset opens. Times should be entered in the 24 hour format of HH:MM - for example 6:00 AM would be 06:00 and 4 PM would be 16:00. If entries for Open and Close Times are left blank, this will be treated as Closed for that day.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FridayCloseTime",
            data_type=DataType.TIME,
            pk=True,
            explanation="The time on Friday that the Facility, Customer, or TransportationAsset closes. Times should be entered in the 24 hour format of HH:MM - for example 6:00 AM would be 06:00 and 4 PM would be 16:00. If entries for Open and Close Times are left blank, this will be treated as Closed for that day.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SaturdayOpenTime",
            data_type=DataType.TIME,
            pk=True,
            explanation="The time on Saturday that the Facility, Customer, or TransportationAsset opens. Times should be entered in the 24 hour format of HH:MM - for example 6:00 AM would be 06:00 and 4 PM would be 16:00. If entries for Open and Close Times are left blank, this will be treated as Closed for that day.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SaturdayCloseTime",
            data_type=DataType.TIME,
            pk=True,
            explanation="The time on Saturday that the Facility, Customer, or TransportationAsset closes. Times should be entered in the 24 hour format of HH:MM - for example 6:00 AM would be 06:00 and 4 PM would be 16:00. If entries for Open and Close Times are left blank, this will be treated as Closed for that day.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
