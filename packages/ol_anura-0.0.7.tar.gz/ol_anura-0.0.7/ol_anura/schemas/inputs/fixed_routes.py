"""FixedRoutes table schema definition."""

import sys
from pathlib import Path
from enum import Enum

from ...core import DataType, Column, Table, Status, TechnologySupport


class RouteCostRule(str, Enum):
    """RouteCostRule values."""
    PRORATE = "Prorate"
    TREAT_AS_FULL = "Treat As Full"

# FixedRoutes table schema
fixed_routes = Table(
    table_name="FixedRoutes",
    neo=TechnologySupport.FULLY_SUPPORTED,
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="FixedRoutes",
    in_database=True,
    fields=[
        Column(
            column_name="FixedRouteName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the fixed route",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RoutePlannerName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["TransportationRoutePlanners"],
            expandable=True,
            explanation="The route planner that will use the fixed route",
            precision_category=["NaN"],
            master_column=["TransportationRoutePlanners.RoutePlannerName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReviewPeriodFirstTime",
            data_type=DataType.DATETIME,
            explanation="The first Date/Time at which to review the queue for the specified fixed route. After this Date/Time, the review period length will dictate when fixed route reviews occur. If NULL, Review Period First Time will be the start of the simulation.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReviewPeriod",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable",
            master_table=["ReviewSchedules"],
            explanation="The time between fixed route executions. After Review Period First Time, a fixed route execution will occur each time Review Period has elapsed. For example, if Review Period First Time is 1/1/2022 12:00:00 AM and Review Period is six hours, we will conduct reviews on 1/1/2022 at 12:00:00 AM, 6:00:00 AM, 12:00:00 PM, and 6:00:00 PM, continuing similarly until the simulation ends. A Review Schedule defined in the Review Schedules table can be entered by Review Schedule Name in this field as well. If NULL, continuous review is used.",
            precision_category=["Time"],
            master_column=["ReviewSchedules.ReviewScheduleName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReviewPeriodUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Time]",
            master_table=["UnitsOfMeastre"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure (Type = Time) that defines Review Period length.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteCost",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            u_o_m_conversion="",
            default_value="0",
            explanation="The cost associated with a shipment made under the specified Origin/Destination/Product/Mode combination. The Average Shipment Size will be used to estimate the number of shipments that occurred; the Fixed Cost will be applied to the estimated number of shipments according to the Fixed Cost Rule. If a step cost is used, the steps will be evaluated in terms of the number of shipments that are sent over the Origin/Destination/Product/Mode combination.",
            precision_category=["Cost"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteCostRule",
            data_type=RouteCostRule,
            required_if="RouteCost",
            u_o_m_conversion="",
            default_value="Prorate",
            explanation="The rule by which Fixed Cost is applied to the estimated number of shipments. The cost can be prorated in the event that the estimated number of shipments is not an integer. If the selected rule is Treat as Full, the estimated number of shipments will be rounded up and the fixed cost will be applied accordingly.",
            precision_category=["NaN"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteCapacity",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            u_o_m_conversion="",
            default_value="1",
            explanation="The average shipment size associated with this Origin/Destination/Product/Mode combination. This figure will be used to estimate the fixed cost of shipments and will also be used in combination with any Time or Distance Unit Costs. If NULL, for an inbound lane to a Customer and Delivery Frequency is populated under CustomerDemand table, the Shipment Size will be applied as Demand Quantity / Delivery Frequency. For other Cases where the field is NULL, a default value of one unit will be assumed.",
            precision_category=["Quantity"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="RouteCapacityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required_if="RouteCapacity",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            u_o_m_conversion="Inter",
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines Average Shipment Size. Quantity, Volume, and Weight units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AssetName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["TransportationAssets"],
            explanation="The name of the Transportation Asset assigned to this fixed route.  If none is provided then the planner will dynamically select from those available",
            precision_category=["NaN"],
            master_column=["TransportationAssets.AssetName"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the fixed route exists in the model. If Status is set to Exclude, the fixed route record is ignored during the model run.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
