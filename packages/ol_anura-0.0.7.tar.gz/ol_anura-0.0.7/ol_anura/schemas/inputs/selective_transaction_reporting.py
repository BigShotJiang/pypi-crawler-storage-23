"""SelectiveTransactionReporting table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, Status, TechnologySupport

# SelectiveTransactionReporting table schema
selective_transaction_reporting = Table(
    table_name="SelectiveTransactionReporting",
    abbreviated_name="SelectiveTransactionReporting",
    in_database=True,
    fields=[
        Column(
            column_name="TableName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the Throg output table we want to filter by applying the ReportingCondition.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ReportingCondition",
            data_type=DataType.STRING,
            explanation="The condition that we want to apply in order to filter the results in the output table.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not this reporting condition should be applied. If Status is set to Exclude, the reporting condition is ignored during the model run.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
