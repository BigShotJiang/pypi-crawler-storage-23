"""Shipments table schema definition."""

import sys
from pathlib import Path

from ...core import DataType, Column, Table, Status, TechnologySupport

# Shipments table schema
shipments = Table(
    table_name="Shipments",
    throg=TechnologySupport.FULLY_SUPPORTED,
    dendro=TechnologySupport.FULLY_SUPPORTED,
    hopper=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="Shipments",
    basic_mode_hopper=True,
    in_database=True,
    fields=[
        Column(
            column_name="ShipmentID",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="A unique identifier for the Shipment; a Shipment consists of one or more Line Items.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="LineItemID",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="A unique identifier for the Line Item being defined; Shipments with multiple Line Items will require multiple table records.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SourceName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            master_table=["Facilities", "Suppliers", "Customers"],
            explanation="The Facility or Supplier that the shipment originates from.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName", "Customers.CustomerName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DestinationName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            master_table=["Customers", "Facilities"],
            explanation="The Facility or Customer that the shipment will be delivered to.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["Customers.CustomerName", "Facilities.FacilityName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            master_table=["Products"],
            explanation="The Product in the Line Item.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            master_column=["Products.ProductName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Quantity",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            required=True,
            default_value="0",
            explanation="The amount of the Product being shipped.",
            precision_category=["Quantity"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="QuantityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="Quantity",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines Quantity.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Volume",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="The volume of the Product being shipped. If empty, the solver will use the unitVolume of the Product if it is defined, or 0 otherwise.",
            precision_category=["Weight"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="VolumeUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Volume]",
            required_if="Volume",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Volume"],
            default_value="{PrimaryVolumeUOM}",
            explanation="The unit of measure that defines Volume.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Weight",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="The weight of the Product being shipped. If empty, the solver will use the unitVolume of the Product if it is defined, or 0 otherwise.",
            precision_category=["Weight"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WeightUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Weight]",
            required_if="Weight",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Weight"],
            default_value="{PrimaryWeightUOM}",
            explanation="The unit of measure that defines Weight.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="OrderDate",
            data_type=DataType.DATETIME,
            explanation="The date and time at which the Shipment is requested.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DueDate",
            data_type=DataType.DATETIME,
            explanation="The date and time at which the Shipment must be delivered.",
            precision_category=["NaN"],
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="EarliestPickupDate",
            data_type=DataType.DATETIME,
            explanation="The date and time of the earliest possible shipment pickup.",
            precision_category=["NaN"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="LatestPickupDate",
            data_type=DataType.DATETIME,
            explanation="The date and time of the latest possible shipment pickup.",
            precision_category=["NaN"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="EarliestDeliveryDate",
            data_type=DataType.DATETIME,
            explanation="The date and time of the earliest possible shipment delivery.",
            precision_category=["NaN"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="LatestDeliveryDate",
            data_type=DataType.DATETIME,
            explanation="The date and time of the latest possible shipment delivery.",
            precision_category=["NaN"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the Line Item exists in the model. If Status is set to Exclude, this record will be ignored during the model run.",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ServiceMode",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["TransportationModes"],
            explanation="Optionally, a required Transportation Mode can be specified here. If multiple Modes are acceptable, a Mode Group may be used; the Group behavior will be Aggregate. If NULL, any Mode is assumed to be acceptable.",
            precision_category=["NaN"],
            master_column=["TransportationModes.ModeName"],
            in_database=True
        ),
        Column(
            column_name="AllowPartialFillShipment",
            data_type=bool,
            default_value="True",
            explanation="If True, the specified Line Item may be partially filled. Otherwise, the Line Item must be filled in full. The remaining quantity of partially filled Line Items may be satisfied in the future with additional shipments. If Partial Fill Shipment is False, Partial Fill Line Items will also be forced to False.",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="AllowPartialFillLineItems",
            data_type=bool,
            default_value="True",
            explanation="If True, individual Line Items can be partially filled. If Allow Partial Fill Shipment = False and Allow Partial Fill Line Item = True, the Line Item Partial Fill behavior will override the Shipment Partial Fill behavior.",
            precision_category=["NaN"],
            in_database=True
        ),
        Column(
            column_name="FixedPickupTime",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="NonNegative",
            explanation="The fixed time required at the pickup location of the shipment. This will be additive to the FixedPickupTime specified in the Facilities, Customers and Transportation Assets tables.",
            precision_category=["Time"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FixedPickupTimeUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Time]",
            required_if="FixedPickupTime",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure (Type = Time) that defines Fixed Pickup Time.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FixedDeliveryTime",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="NonNegative",
            explanation="The fixed time required at the delivery location of the shipment. This will be additive to the FixedDeliveryTime specified in the Facilities, Customers and Transportation Assets tables.",
            precision_category=["Time"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FixedDeliveryTimeUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Time]",
            required_if="FixedDeliveryTime",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure (Type = Time) that defines Fixed Delivery Time.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnitPickupTime",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="NonNegative",
            explanation="The time required per unit to be loaded onto an Asset at the pickup location. This will be additive to any UnitPickupTime that is specified in the Facilities, Customers and Transportation Assets tables.",
            precision_category=["Time"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnitUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="UnitPickupTime OR UnitDeliveryTime",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines the basis on which UnitPickupTime and UnitDeliveryTime will be applied for the Shipment. Quantity, Volume, and Weight units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnitPickupTimeUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Time]",
            required_if="UnitPickupTime",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure (Type = Time) that defines Unit Pickup Time.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnitDeliveryTime",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="NonNegative",
            explanation="The time required per unit to be delivered at the destination location. This will be additive to any UnitDeliveryTime that is specified in the Transportation Assets table.",
            precision_category=["Time"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="UnitDeliveryTimeUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Time]",
            required_if="UnitDeliveryTime",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure (Type = Time) that defines Unit Delivery Time.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DirectCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [All Item, Incremental, Stepwise]",
            master_table=["StepCosts"],
            notes="Currently supports doubles and named step costs that are defined in the StepCosts table where StepCostBehavior = All Item, Incremental or Stepwise or a combination of Stepwise and All Item",
            explanation="The cost to send the shipment directly to the destination.",
            precision_category=["Cost"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TemplateRouteName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["TemplateRoutes"],
            default_value="None",
            explanation="If the Shipment is assigned to a Template Route, the Template Route Name is specified here.",
            precision_category=["NaN"],
            master_column=["TemplateRoutes.TemplateRouteName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TemplateRouteStopSequence",
            data_type=DataType.INTEGER,
            validation_type="NonNegative",
            explanation="The Stop sequence for the delivery stop of the shipment on the defined Template Route.",
            precision_category=["Integer"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TemplateRoutePickupStopSequence",
            data_type=DataType.INTEGER,
            validation_type="NonNegative",
            explanation="The Stop sequence for the pickup stop of the shipment on the defined Template Route.",
            precision_category=["Integer"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TemplateTerritoryName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["TemplateTerritories"],
            default_value="None",
            explanation="If the Shipment is assigned to a Template Territory, the Template Territory Name is specified here.",
            precision_category=["NaN"],
            master_column=["TemplateTerritories.TemplateTerritoryName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="DecompositionName",
            data_type=DataType.STRING,
            explanation="Shipments with the same Decomposition Name will be run together as a subproblem in the Hopper solve.",
            precision_category=["NaN"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="AllowedAssetName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["TransportationAssets"],
            explanation="The Transportation Asset(s) that can be used to route this shipment. Blank means that all assets are allowed. Single asset name, groups and named filters can be used. ",
            precision_category=["NaN"],
            master_column=["TransportationAssets.AssetName"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
