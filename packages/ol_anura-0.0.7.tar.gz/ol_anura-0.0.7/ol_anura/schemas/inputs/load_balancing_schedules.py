"""LoadBalancingSchedules table schema definition."""

import sys
from pathlib import Path
from enum import Enum

from ...core import DataType, Column, Table, Status, TechnologySupport


class FridayDelivery(str, Enum):
    """FridayDelivery values."""
    CONSIDER = "Consider"
    FORCE = "Force"
    PREVENT = "Prevent"

class MondayDelivery(str, Enum):
    """MondayDelivery values."""
    CONSIDER = "Consider"
    FORCE = "Force"
    PREVENT = "Prevent"

class SaturdayDelivery(str, Enum):
    """SaturdayDelivery values."""
    CONSIDER = "Consider"
    FORCE = "Force"
    PREVENT = "Prevent"

class SundayDelivery(str, Enum):
    """SundayDelivery values."""
    CONSIDER = "Consider"
    FORCE = "Force"
    PREVENT = "Prevent"

class ThursdayDelivery(str, Enum):
    """ThursdayDelivery values."""
    CONSIDER = "Consider"
    FORCE = "Force"
    PREVENT = "Prevent"

class TuesdayDelivery(str, Enum):
    """TuesdayDelivery values."""
    CONSIDER = "Consider"
    FORCE = "Force"
    PREVENT = "Prevent"

class WednesdayDelivery(str, Enum):
    """WednesdayDelivery values."""
    CONSIDER = "Consider"
    FORCE = "Force"
    PREVENT = "Prevent"

# LoadBalancingSchedules table schema
load_balancing_schedules = Table(
    table_name="LoadBalancingSchedules",
    hopper=TechnologySupport.FULLY_SUPPORTED,
    abbreviated_name="LoadBalancingSchedules",
    basic_mode_hopper=True,
    in_database=True,
    fields=[
        Column(
            column_name="LoadBalancingScheduleName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="A set of rules governing the delivery schedule for a customer. Multiple rows with the same schedule name can be used to define a list of allowed schedules.",
            precision_category=["NaN"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not this schedule will be considered in the model",
            precision_category=["NaN"],
            basic_mode=["HOPPER"],
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MinDaysBetweenDelivery",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            pk=True,
            u_o_m_conversion="",
            default_value="0",
            explanation="The minimum number of days between deliveries for this customer.",
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MaxDaysBetweenDelivery",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            pk=True,
            u_o_m_conversion="",
            default_value="7",
            explanation="The maximum number of days between deliveries for this customer.",
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="MondayDelivery",
            data_type=MondayDelivery,
            required=True,
            pk=True,
            u_o_m_conversion="",
            default_value="Consider",
            explanation="Status to control whether this customer can be visited on Monday",
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="TuesdayDelivery",
            data_type=TuesdayDelivery,
            required=True,
            pk=True,
            u_o_m_conversion="",
            default_value="Consider",
            explanation="Status to control whether this customer can be visited on Tuesday",
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="WednesdayDelivery",
            data_type=WednesdayDelivery,
            required=True,
            pk=True,
            u_o_m_conversion="",
            default_value="Consider",
            explanation="Status to control whether this customer can be visited on Wednesday",
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="ThursdayDelivery",
            data_type=ThursdayDelivery,
            required=True,
            pk=True,
            u_o_m_conversion="",
            default_value="Consider",
            explanation="Status to control whether this customer can be visited on Thursday",
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="FridayDelivery",
            data_type=FridayDelivery,
            required=True,
            pk=True,
            u_o_m_conversion="",
            default_value="Consider",
            explanation="Status to control whether this customer can be visited on Friday",
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SaturdayDelivery",
            data_type=SaturdayDelivery,
            required=True,
            pk=True,
            u_o_m_conversion="",
            default_value="Consider",
            explanation="Status to control whether this customer can be visited on Saturday",
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
        Column(
            column_name="SundayDelivery",
            data_type=SundayDelivery,
            required=True,
            pk=True,
            u_o_m_conversion="",
            default_value="Consider",
            explanation="Status to control whether this customer can be visited on Sunday",
            hopper=TechnologySupport.FULLY_SUPPORTED,
            in_database=True
        ),
    ]
)
