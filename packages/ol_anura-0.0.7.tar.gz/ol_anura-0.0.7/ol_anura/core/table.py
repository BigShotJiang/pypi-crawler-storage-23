"""Table schema model for Anura schemas."""

from pydantic import BaseModel, Field, field_validator, model_validator
from typing import List, Optional
from .column import Column
from .enums import TechnologySupport, TECHNOLOGY_NAMES


class Table(BaseModel):
    """
    Represents a complete table schema with metadata and fields.

    Pure data container - query methods will be provided by AnuraSchema class.
    Uses snake_case in Python code and camelCase for JSON serialization.
    """

    table_name: str = Field(
        ...,
        alias="tableName",
        description="Name of the table"
    )

    # Technology support fields
    neo: Optional[TechnologySupport] = Field(
        default=None,
        alias="neo",
        description="NEO technology support level"
    )

    throg: Optional[TechnologySupport] = Field(
        default=None,
        alias="throg",
        description="THROG technology support level"
    )

    dendro: Optional[TechnologySupport] = Field(
        default=None,
        alias="dendro",
        description="DENDRO technology support level"
    )

    hopper: Optional[TechnologySupport] = Field(
        default=None,
        alias="hopper",
        description="HOPPER technology support level"
    )

    triad: Optional[TechnologySupport] = Field(
        default=None,
        alias="triad",
        description="TRIAD technology support level"
    )

    dart: Optional[TechnologySupport] = Field(
        default=None,
        alias="dart",
        description="DART technology support level"
    )
    
    cyclo: Optional[TechnologySupport] = Field(
        default=None,
        alias="cyclo",
        description="CYCLO technology support level"
    )

    # Table metadata fields
    abbreviated_name: Optional[str] = Field(
        default=None,
        alias="abbreviatedName",
        description="Short name for this table"
    )

    fixed_tags: List[str] = Field(
        default_factory=list,
        alias="fixedTags",
        description="Fixed tags for this table"
    )

    # Basic mode flags (whether table is shown in basic mode for each technology)
    basic_mode_neo: bool = Field(
        default=False,
        alias="basicModeNeo",
        description="Whether this table is available in basic mode for NEO"
    )

    basic_mode_throg: bool = Field(
        default=False,
        alias="basicModeThrog",
        description="Whether this table is available in basic mode for THROG"
    )

    basic_mode_dendro: bool = Field(
        default=False,
        alias="basicModeDendro",
        description="Whether this table is available in basic mode for DENDRO"
    )

    basic_mode_hopper: bool = Field(
        default=False,
        alias="basicModeHopper",
        description="Whether this table is available in basic mode for HOPPER"
    )

    basic_mode_triad: bool = Field(
        default=False,
        alias="basicModeTriad",
        description="Whether this table is available in basic mode for TRIAD"
    )

    basic_mode_dart: bool = Field(
        default=False,
        alias="basicModeDart",
        description="Whether this table is available in basic mode for DART"
    )

    basic_mode_cyclo: bool = Field(
        default=False,
        alias="basicModeCyclo",
        description="Whether this table is available in basic mode for CYCLO"
    )

    # Lifecycle flag
    in_database: bool = Field(
        default=False,
        alias="inDatabase",
        description="Whether this table exists in the database (False for in-development tables)"
    )

    fields: List[Column] = Field(
        ...,
        description="List of field definitions for this table"
    )

    # === Configuration ===

    model_config = {
        "populate_by_name": True,  # Allow both snake_case and camelCase
    }

    # === Validators ===

    @field_validator('fixed_tags')
    @classmethod
    def validate_fixed_tags(cls, v: List[str]) -> List[str]:
        """Ensure fixed_tags is a list of strings."""
        if not isinstance(v, list):
            raise ValueError("fixed_tags must be a list")
        for tag in v:
            if not isinstance(tag, str):
                raise ValueError(f"All tags must be strings, got {type(tag)}")
        return v

    @model_validator(mode='after')
    def validate_basic_mode_consistency(self) -> 'Table':
        """
        Ensure basic_mode flags are consistent with technology support.

        If basic_mode_X=True, then technology support for X must be
        FULLY_SUPPORTED or IN_DEVELOPMENT (not UNSUPPORTED or None).
        """
        tech_fields = TECHNOLOGY_NAMES

        for tech in tech_fields:
            basic_mode_attr = f'basic_mode_{tech}'
            basic_mode_value = getattr(self, basic_mode_attr, False)
            tech_support = getattr(self, tech, None)

            if basic_mode_value:
                if tech_support is None or tech_support == TechnologySupport.UNSUPPORTED:
                    raise ValueError(
                        f"Invalid configuration for table '{self.table_name}': "
                        f"{basic_mode_attr}=True but {tech}={tech_support}. "
                        f"Cannot enable basic mode for an unsupported technology."
                    )

        return self

    # === Methods ===

    def to_json_dict(self) -> dict:
        """
        Export to JSON format with camelCase keys.
        Matches the original JSON structure exactly.

        Includes schema metadata (AppName, SchemaName, SchemaVersion, TableName).
        Filters columns based on in_database flag (only includes columns where in_database=True).

        Special handling for technology fields:
        - TechnologySupport enum → string value
        - None or UNSUPPORTED → omitted from JSON

        Note: in_database field is excluded from JSON output (used for filtering only)
        """
        from .enums import TechnologySupport, TECHNOLOGY_NAMES
        from .schema_metadata import get_schema_metadata

        # Start with schema metadata - this ensures correct order
        result = get_schema_metadata(table_name=self.table_name)

        # Add technology fields if they are supported
        for tech in ['neo', 'throg', 'dendro', 'hopper', 'triad', 'dart']:
            value = getattr(self, tech, None)
            if value and value != TechnologySupport.UNSUPPORTED:
                result[tech] = value.value  # "fully-supported" or "in-development"

        # Filter fields to only include columns where in_database=True
        production_fields = [
            field for field in self.fields
            if field.in_database
        ]

        # Add filtered fields to result
        result["fields"] = [field.to_json_dict() for field in production_fields]

        return result

    def get_primary_keys(self) -> List[Column]:
        """Get all primary key fields."""
        return [field for field in self.fields if field.pk]

    def get_required_fields(self) -> List[Column]:
        """Get all required fields."""
        return [field for field in self.fields if field.required]

    def get_field(self, column_name: str) -> Column:
        """
        Get a specific field by column name.

        Args:
            column_name: The name of the column to find

        Returns:
            The field definition

        Raises:
            ValueError: If field not found
        """
        for field in self.fields:
            if field.column_name == column_name:
                return field
        raise ValueError(f"Field '{column_name}' not found in table '{self.table_name}'")

    def is_fully_supported(self, tech_name: str) -> bool:
        """
        Check if table is fully supported for a technology.

        Args:
            tech_name: Technology name (lowercase): "neo", "throg", "dendro", "hopper", "triad", "dart"

        Returns:
            True if technology is fully supported
        """
        from .enums import TechnologySupport, TECHNOLOGY_NAMES
        support = getattr(self, tech_name.lower(), None)
        return support == TechnologySupport.FULLY_SUPPORTED

    def is_available(self, tech_name: str, include_in_dev: bool = False) -> bool:
        """
        Check if table is available for a technology.

        Args:
            tech_name: Technology name (lowercase): "neo", "throg", "dendro", "hopper", "triad", "dart"
            include_in_dev: Include in-development features

        Returns:
            True if technology is available
        """
        from .enums import TechnologySupport, TECHNOLOGY_NAMES
        support = getattr(self, tech_name.lower(), None)

        if support == TechnologySupport.FULLY_SUPPORTED:
            return True
        if include_in_dev and support == TechnologySupport.IN_DEVELOPMENT:
            return True
        return False
