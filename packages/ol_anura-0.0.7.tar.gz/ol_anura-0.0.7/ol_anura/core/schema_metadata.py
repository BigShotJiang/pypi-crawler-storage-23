"""Schema metadata constants for JSON generation."""

from typing import Optional

# Schema metadata constants
APP_NAME = "cosmicfrog"
SCHEMA_NAME = "anura"
SCHEMA_VERSION = "v0.3"


def get_schema_metadata(table_name: Optional[str] = None) -> dict:
    """
    Get schema metadata dictionary for JSON serialization.

    Args:
        table_name: Optional table name to include in metadata

    Returns:
        Dictionary with appName, schemaName, schemaVersion, and optionally tableName
    """
    metadata = {
        "appName": APP_NAME,
        "schemaName": SCHEMA_NAME,
        "schemaVersion": SCHEMA_VERSION
    }

    if table_name:
        metadata["tableName"] = table_name

    return metadata
