"""Tests for Table model."""

import pytest
from ol_anura.core import Table, Column, DataType, TechnologySupport


class TestTableToJsonDict:
    """Test Table serialization to JSON."""

    def test_simple_table(self):
        table = Table(
            table_name="TestTable",
            fields=[
                Column(
                    column_name="ID",
                    data_type=DataType.STRING,
                    required=True,
                    pk=True,
                    in_database=True
                )
            ]
        )

        json_dict = table.to_json_dict()

        assert json_dict['tableName'] == 'TestTable'
        assert 'fields' in json_dict
        assert len(json_dict['fields']) == 1
        assert json_dict['fields'][0]['columnName'] == 'ID'

    def test_table_to_json_dict_includes_metadata(self):
        """Test that to_json_dict() includes appName, schemaName, schemaVersion."""
        table = Table(
            table_name="TestTable",
            in_database=True,
            fields=[
                Column(
                    column_name="Col1",
                    data_type=DataType.STRING,
                    in_database=True
                )
            ]
        )

        result = table.to_json_dict()

        # Verify metadata fields are present
        assert result["appName"] == "cosmicfrog"
        assert result["schemaName"] == "anura"
        assert result["schemaVersion"] == "v0.3"
        assert result["tableName"] == "TestTable"

    def test_table_to_json_dict_excludes_in_database(self):
        """Test that to_json_dict() excludes inDatabase from table level."""
        table = Table(
            table_name="TestTable",
            in_database=True,
            fields=[
                Column(
                    column_name="Col1",
                    data_type=DataType.STRING,
                    in_database=True
                )
            ]
        )

        result = table.to_json_dict()

        # Verify inDatabase is NOT in the result
        assert "inDatabase" not in result
        assert "in_database" not in result

    def test_table_to_json_dict_filters_columns_by_in_database(self):
        """Test that to_json_dict() only includes columns where in_database=True."""
        table = Table(
            table_name="TestTable",
            in_database=True,
            fields=[
                Column(
                    column_name="ProductionCol",
                    data_type=DataType.STRING,
                    in_database=True  # Should be included
                ),
                Column(
                    column_name="DevCol",
                    data_type=DataType.STRING,
                    in_database=False  # Should be excluded
                ),
                Column(
                    column_name="AnotherProdCol",
                    data_type=DataType.INTEGER,
                    in_database=True  # Should be included
                )
            ]
        )

        result = table.to_json_dict()

        # Should have exactly 2 fields (only in_database=True)
        assert len(result["fields"]) == 2

        # Verify correct columns are included
        field_names = [f["columnName"] for f in result["fields"]]
        assert "ProductionCol" in field_names
        assert "AnotherProdCol" in field_names
        assert "DevCol" not in field_names

    def test_table_to_json_dict_metadata_order(self):
        """Test that metadata fields come first in specific order."""
        table = Table(
            table_name="TestTable",
            neo=TechnologySupport.FULLY_SUPPORTED,
            in_database=True,
            fields=[
                Column(
                    column_name="Col1",
                    data_type=DataType.STRING,
                    in_database=True
                )
            ]
        )

        result = table.to_json_dict()

        # Get list of keys
        keys = list(result.keys())

        # Verify order: appName, schemaName, schemaVersion, tableName should be first
        assert keys[0] == "appName"
        assert keys[1] == "schemaName"
        assert keys[2] == "schemaVersion"
        assert keys[3] == "tableName"

        # fields should come after metadata
        assert keys.index("fields") > keys.index("tableName")


class TestTableMetadataFields:
    """Test new metadata fields on Table model."""

    def test_abbreviated_name(self):
        """Test abbreviated_name field."""
        table = Table(
            table_name="TestTable",
            abbreviated_name="TT",
            fields=[]
        )
        assert table.abbreviated_name == "TT"

    def test_abbreviated_name_default_none(self):
        """Test that abbreviated_name defaults to None."""
        table = Table(table_name="TestTable", fields=[])
        assert table.abbreviated_name is None

    def test_fixed_tags(self):
        """Test fixed_tags field."""
        table = Table(
            table_name="TestTable",
            fixed_tags=["tag1", "tag2", "tag3"],
            fields=[]
        )
        assert table.fixed_tags == ["tag1", "tag2", "tag3"]

    def test_fixed_tags_default_empty_list(self):
        """Test that fixed_tags defaults to empty list."""
        table = Table(table_name="TestTable", fields=[])
        assert table.fixed_tags == []

    def test_fixed_tags_validation(self):
        """Test that fixed_tags must be a list of strings."""
        # Valid: list of strings
        table = Table(
            table_name="TestTable",
            fixed_tags=["a", "b"],
            fields=[]
        )
        assert table.fixed_tags == ["a", "b"]

    def test_in_database_flag(self):
        """Test in_database flag."""
        table = Table(
            table_name="TestTable",
            in_database=True,
            fields=[]
        )
        assert table.in_database is True

    def test_in_database_default_false(self):
        """Test that in_database defaults to False."""
        table = Table(table_name="TestTable", fields=[])
        assert table.in_database is False


class TestTableBasicModeFlags:
    """Test basic mode flags on Table model."""

    def test_basic_mode_neo(self):
        """Test basic_mode_neo flag."""
        table = Table(
            table_name="TestTable",
            basic_mode_neo=True,
            neo=TechnologySupport.FULLY_SUPPORTED,
            fields=[]
        )
        assert table.basic_mode_neo is True

    def test_basic_mode_flags_default_false(self):
        """Test that basic_mode flags default to False."""
        table = Table(table_name="TestTable", fields=[])
        assert table.basic_mode_neo is False
        assert table.basic_mode_throg is False
        assert table.basic_mode_dendro is False
        assert table.basic_mode_hopper is False
        assert table.basic_mode_triad is False
        assert table.basic_mode_dart is False

    def test_all_basic_mode_flags(self):
        """Test all basic_mode flags can be set."""
        table = Table(
            table_name="TestTable",
            basic_mode_neo=True,
            basic_mode_throg=True,
            basic_mode_dendro=True,
            basic_mode_hopper=True,
            basic_mode_triad=True,
            basic_mode_dart=True,
            neo=TechnologySupport.FULLY_SUPPORTED,
            throg=TechnologySupport.FULLY_SUPPORTED,
            dendro=TechnologySupport.FULLY_SUPPORTED,
            hopper=TechnologySupport.FULLY_SUPPORTED,
            triad=TechnologySupport.FULLY_SUPPORTED,
            dart=TechnologySupport.FULLY_SUPPORTED,
            fields=[]
        )
        assert table.basic_mode_neo is True
        assert table.basic_mode_throg is True
        assert table.basic_mode_dendro is True
        assert table.basic_mode_hopper is True
        assert table.basic_mode_triad is True
        assert table.basic_mode_dart is True


class TestTableBasicModeValidation:
    """Test basic_mode consistency validation."""

    def test_basic_mode_with_fully_supported_is_valid(self):
        """Test that basic_mode=True with FULLY_SUPPORTED is valid."""
        table = Table(
            table_name="TestTable",
            basic_mode_neo=True,
            neo=TechnologySupport.FULLY_SUPPORTED,
            fields=[]
        )
        assert table.basic_mode_neo is True

    def test_basic_mode_with_in_development_is_valid(self):
        """Test that basic_mode=True with IN_DEVELOPMENT is valid."""
        table = Table(
            table_name="TestTable",
            basic_mode_neo=True,
            neo=TechnologySupport.IN_DEVELOPMENT,
            fields=[]
        )
        assert table.basic_mode_neo is True

    def test_basic_mode_with_unsupported_raises_error(self):
        """Test that basic_mode=True with UNSUPPORTED raises ValueError."""
        with pytest.raises(ValueError, match="Invalid configuration"):
            Table(
                table_name="TestTable",
                basic_mode_neo=True,
                neo=TechnologySupport.UNSUPPORTED,
                fields=[]
            )

    def test_basic_mode_with_none_raises_error(self):
        """Test that basic_mode=True with None technology raises ValueError."""
        with pytest.raises(ValueError, match="Invalid configuration"):
            Table(
                table_name="TestTable",
                basic_mode_neo=True,
                neo=None,
                fields=[]
            )

    def test_basic_mode_false_with_unsupported_is_valid(self):
        """Test that basic_mode=False with UNSUPPORTED is valid."""
        table = Table(
            table_name="TestTable",
            basic_mode_neo=False,
            neo=TechnologySupport.UNSUPPORTED,
            fields=[]
        )
        assert table.basic_mode_neo is False

    def test_validation_all_technologies(self):
        """Test that validation applies to all technology fields."""
        # Test each technology raises error when basic_mode=True but tech=UNSUPPORTED
        technologies = ['neo', 'throg', 'dendro', 'hopper', 'triad', 'dart']

        for tech in technologies:
            basic_mode_field = f'basic_mode_{tech}'
            with pytest.raises(ValueError, match=f"Invalid configuration"):
                Table(
                    table_name="TestTable",
                    **{basic_mode_field: True, tech: TechnologySupport.UNSUPPORTED},
                    fields=[]
                )
