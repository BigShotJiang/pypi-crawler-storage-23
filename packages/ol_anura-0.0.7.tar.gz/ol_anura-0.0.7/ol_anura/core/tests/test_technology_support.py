"""Tests for technology support refactor."""

from ol_anura.core import Column, Table, DataType, TechnologySupport


def test_technology_support_enum():
    """Test that TechnologySupport enum has correct values."""
    assert TechnologySupport.UNSUPPORTED.value == "unsupported"
    assert TechnologySupport.IN_DEVELOPMENT.value == "in-development"
    assert TechnologySupport.FULLY_SUPPORTED.value == "fully-supported"


def test_column_technology_fields():
    """Test that Column can have technology support fields."""
    column = Column(
        column_name="TestColumn",
        data_type=DataType.STRING,
        neo=TechnologySupport.FULLY_SUPPORTED,
        throg=TechnologySupport.IN_DEVELOPMENT,
        dendro=None  # Unsupported
    )

    assert column.neo == TechnologySupport.FULLY_SUPPORTED
    assert column.throg == TechnologySupport.IN_DEVELOPMENT
    assert column.dendro is None
    assert column.hopper is None
    assert column.triad is None


def test_column_helper_methods():
    """Test Column helper methods for technology support."""
    column = Column(
        column_name="TestColumn",
        data_type=DataType.STRING,
        neo=TechnologySupport.FULLY_SUPPORTED,
        throg=TechnologySupport.IN_DEVELOPMENT,
    )

    # Test is_fully_supported
    assert column.is_fully_supported("neo") is True
    assert column.is_fully_supported("throg") is False
    assert column.is_fully_supported("dendro") is False

    # Test is_available
    assert column.is_available("neo") is True
    assert column.is_available("throg", include_in_dev=False) is False
    assert column.is_available("throg", include_in_dev=True) is True
    assert column.is_available("dendro", include_in_dev=True) is False


def test_column_json_serialization():
    """Test that Column serializes technology fields correctly to JSON."""
    column = Column(
        column_name="TestColumn",
        data_type=DataType.STRING,
        neo=TechnologySupport.FULLY_SUPPORTED,
        throg=TechnologySupport.IN_DEVELOPMENT,
        dendro=None,  # Should be omitted from JSON
    )

    json_dict = column.to_json_dict()

    # Check that supported technologies are in JSON with correct values
    assert json_dict.get("neo") == "fully-supported"
    assert json_dict.get("throg") == "in-development"

    # Check that unsupported technologies are omitted from JSON
    assert "dendro" not in json_dict
    assert "hopper" not in json_dict
    assert "triad" not in json_dict


def test_table_technology_fields():
    """Test that Table can have technology support fields."""
    table = Table(
        table_name="TestTable",
        neo=TechnologySupport.FULLY_SUPPORTED,
        throg=TechnologySupport.IN_DEVELOPMENT,
        fields=[
            Column(column_name="Col1", data_type=DataType.STRING)
        ]
    )

    assert table.neo == TechnologySupport.FULLY_SUPPORTED
    assert table.throg == TechnologySupport.IN_DEVELOPMENT
    assert table.dendro is None


def test_table_helper_methods():
    """Test Table helper methods for technology support."""
    table = Table(
        table_name="TestTable",
        neo=TechnologySupport.FULLY_SUPPORTED,
        throg=TechnologySupport.IN_DEVELOPMENT,
        fields=[
            Column(column_name="Col1", data_type=DataType.STRING)
        ]
    )

    # Test is_fully_supported
    assert table.is_fully_supported("neo") is True
    assert table.is_fully_supported("throg") is False

    # Test is_available
    assert table.is_available("neo") is True
    assert table.is_available("throg", include_in_dev=False) is False
    assert table.is_available("throg", include_in_dev=True) is True


def test_table_json_serialization():
    """Test that Table serializes technology fields correctly to JSON."""
    table = Table(
        table_name="TestTable",
        neo=TechnologySupport.FULLY_SUPPORTED,
        fields=[
            Column(column_name="Col1", data_type=DataType.STRING)
        ]
    )

    json_dict = table.to_json_dict()

    assert json_dict.get("neo") == "fully-supported"
    assert "throg" not in json_dict
    assert "dendro" not in json_dict


def test_no_old_technology_field():
    """Test that old 'technology' field no longer exists."""
    column = Column(
        column_name="TestColumn",
        data_type=DataType.STRING,
    )

    # Old 'technology' field should not exist
    assert not hasattr(column, 'technology')
