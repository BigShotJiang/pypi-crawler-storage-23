"""Tests for anura.core module."""
