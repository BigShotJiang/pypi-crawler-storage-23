from ol_anura.core.schema_metadata import (
    APP_NAME,
    SCHEMA_NAME,
    SCHEMA_VERSION,
    get_schema_metadata,
)


def test_app_name_constant():
    """Test that APP_NAME is defined correctly."""
    assert APP_NAME == "cosmicfrog"


def test_schema_name_constant():
    """Test that SCHEMA_NAME is defined correctly."""
    assert SCHEMA_NAME == "anura"


def test_schema_version_constant():
    """Test that SCHEMA_VERSION is defined correctly."""
    assert SCHEMA_VERSION == "v0.3"


def test_get_schema_metadata():
    """Test that get_schema_metadata returns correct dict."""
    metadata = get_schema_metadata()

    assert metadata == {
        "appName": "cosmicfrog",
        "schemaName": "anura",
        "schemaVersion": "v0.3",
    }


def test_get_schema_metadata_with_table_name():
    """Test that get_schema_metadata can include table name."""
    metadata = get_schema_metadata(table_name="Analytics")

    assert metadata == {
        "appName": "cosmicfrog",
        "schemaName": "anura",
        "schemaVersion": "v0.3",
        "tableName": "Analytics",
    }
