"""Core enumerations for Anura schemas."""

from enum import Enum


# === Hand-Coded Core Enums ===

class DataType(str, Enum):
    """Primitive data types."""
    STRING = "String"
    DOUBLE = "Double"
    INTEGER = "Integer"
    DATE = "Date"
    DATETIME = "DateTime"
    TIME = "Time"
    BOOLEAN = "Boolean"
    COST_TIME_EXPRESSION = "Cost Time Expression"


class UOMType(str, Enum):
    """Unit of measure types."""
    QUANTITY = "Quantity"
    VOLUME = "Volume"
    WEIGHT = "Weight"
    DISTANCE = "Distance"
    TIME = "Time"
    CURRENCY = "Currency"


class QuantityUOMType(str, Enum):
    """Allowable UOM types for quantity fields."""
    QUANTITY = "Quantity"
    VOLUME = "Volume"
    WEIGHT = "Weight"


class PrecisionCategory(str, Enum):
    """Precision categories for numeric fields."""
    NAN = "NaN"
    QUANTITY = "Quantity"
    COST = "Cost"
    PERCENTAGE = "Percentage"


class ValidationType(str, Enum):
    """Validation types."""
    POSITIVE_NUMERIC = "PositiveNumeric"
    NON_NEGATIVE = "NonNegative"
    EXISTS_IN_MASTER_TABLE = "ExistsInMasterTable"


class GroupBehavior(str, Enum):
    """Group behavior for *NameGroupBehavior columns.

    Used for columns like ProductNameGroupBehavior, FacilityNameGroupBehavior, etc.
    This is the only shared enum where the enum name doesn't match the column name.
    """
    AGGREGATE = "Aggregate"
    ENUMERATE = "Enumerate"


# === Generated Shared Enums ===



class BehaviorRule(str, Enum):
    """BehaviorRule values."""
    EXPEDITE = "Expedite"
    FTL = "FTL"
    LTL = "LTL"


class BudgetBasis(str, Enum):
    """BudgetBasis values."""
    PERCENTAGE = "Percentage"
    QUANTITY = "Quantity"


class ChangeType(str, Enum):
    """ChangeType values."""
    FACILITIES_CLOSED = "Facilities Closed"
    FACILITIES_OPENED = "Facilities Opened"
    LANES_ADDED = "Lanes Added"
    PRODUCTION_DECREASE = "Production Decrease"
    PRODUCTION_INCREASE = "Production Increase"
    SUPPLIERS_ADDED = "Suppliers Added"
    SUPPLIERS_REMOVED = "Suppliers Removed"


class ConsideredInventory(str, Enum):
    """ConsideredInventory values."""
    CYCLE_ONLY = "Cycle Only"
    PREBUILD_ONLY = "Prebuild Only"
    PREBUILD_AND_CYCLE = "Prebuild and Cycle"


class ConstraintType(str, Enum):
    """ConstraintType values."""
    CONDITIONAL_MIN = "Conditional Min"
    FIXED = "Fixed"
    FIXED_WITH_TOLERANCE = "Fixed With Tolerance"
    MAX = "Max"
    MIN = "Min"


class DemandStatus(str, Enum):
    """DemandStatus values."""
    CONSIDER = "Consider"
    EXCLUDE = "Exclude"
    INCLUDE = "Include"


class FacilityStatus(str, Enum):
    """FacilityStatus values."""
    CLOSED = "Closed"
    CONSIDER = "Consider"
    OPEN = "Open"


class FixedCostRule(str, Enum):
    """FixedCostRule values."""
    PRORATE = "Prorate"
    TREAT_AS_FULL = "Treat As Full"


class ForecastType(str, Enum):
    """ForecastType values."""
    HISTORICAL = "Historical"
    USER_DEFINED = "User-Defined"


class GroupBehavior(str, Enum):
    """GroupBehavior values."""
    AGGREGATE = "Aggregate"
    ENUMERATE = "Enumerate"


class InitialState(str, Enum):
    """InitialState values."""
    EXISTING = "Existing"
    POTENTIAL = "Potential"


class InventoryOwnership(str, Enum):
    """InventoryOwnership values."""
    DESTINATION = "Destination"
    ORIGIN = "Origin"


class PathDestinationProperty(str, Enum):
    """PathDestinationProperty values."""
    ADDRESS = "Address"
    CITY = "City"
    COUNTRY = "Country"
    NAME = "Name"
    POSTALCODE = "PostalCode"
    REGION = "Region"


class PathOriginProperty(str, Enum):
    """PathOriginProperty values."""
    ADDRESS = "Address"
    CITY = "City"
    COUNTRY = "Country"
    NAME = "Name"
    POSTALCODE = "PostalCode"
    REGION = "Region"


class PolicyStatus(str, Enum):
    """PolicyStatus values."""
    EXCLUDE = "Exclude"
    INCLUDE = "Include"


class ProductBehavior(str, Enum):
    """ProductBehavior values."""
    CONTINUOUS = "Continuous"
    DISCRETE = "Discrete"


class QueueingPriorityLogic(str, Enum):
    """QueueingPriorityLogic values."""
    BYDAYQUEUEDANDLOCATION = "ByDayQueuedAndLocation"
    BYDUEDATEANDLOCATION = "ByDueDateAndLocation"
    FIFO = "FIFO"


class SecondaryQueueingPriorityLogic(str, Enum):
    """SecondaryQueueingPriorityLogic values."""
    MINIMIZECHANGEOVER = "MinimizeChangeover"


class ServiceType(str, Enum):
    """ServiceType values."""
    TYPE1 = "Type1"
    TYPE2 = "Type2"
    TYPE3 = "Type3"


class Status(str, Enum):
    """Status values."""
    EXCLUDE = "Exclude"
    INCLUDE = "Include"



class Technology(str, Enum):
    """Technologies supported."""
    CYCLO = "CYCLO"
    DART = "DART"
    DENDRO = "DENDRO"
    HOPPER = "HOPPER"
    NEO = "NEO"
    THROG = "THROG"
    TRIAD = "TRIAD"



# Derived constants from Technology enum
TECHNOLOGY_NAMES = [tech.value.lower() for tech in Technology]
"""List of technology names in lowercase (for attribute access)."""


# Technology utility functions
def technology_to_attr(tech: Technology) -> str:
    """Convert Technology enum to attribute name (e.g., Technology.NEO -> 'neo')."""
    return tech.value.lower()


def get_technology_attr(obj, tech: Technology, prefix: str = ""):
    """
    Get technology attribute from object.

    Args:
        obj: Object to get attribute from (e.g., Table or Column instance)
        tech: Technology enum member
        prefix: Optional prefix (e.g., "basic_mode" for basic_mode_neo)

    Returns:
        Attribute value or None if not found

    Example:
        >>> get_technology_attr(table, Technology.NEO)  # Returns table.neo
        >>> get_technology_attr(table, Technology.NEO, "basic_mode")  # Returns table.basic_mode_neo
    """
    attr_name = f"{prefix}{'_' if prefix else ''}{technology_to_attr(tech)}"
    return getattr(obj, attr_name, None)


class TechnologySupport(str, Enum):
    """Support level for a technology."""
    UNSUPPORTED = "unsupported"
    IN_DEVELOPMENT = "in-development"
    FULLY_SUPPORTED = "fully-supported"


class WorkCenterStatus(str, Enum):
    """WorkCenterStatus values."""
    CLOSED = "Closed"
    CONSIDER = "Consider"
    OPEN = "Open"
