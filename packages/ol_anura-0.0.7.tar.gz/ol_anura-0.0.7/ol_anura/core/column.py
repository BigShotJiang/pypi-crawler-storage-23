"""Field definition model for Anura schemas."""

from pydantic import BaseModel, Field, field_validator
from typing import List, Optional, Union, Type, Any
from enum import Enum

from .enums import TechnologySupport, TECHNOLOGY_NAMES

# Type aliases for better clarity
TableName = str  # Name of a table (e.g., "Customers", "Products")
ColumnReference = str  # Column reference in format "TableName.ColumnName"


class Column(BaseModel):
    """
    Represents a single field/column in a table schema.

    Uses snake_case in Python code and camelCase for JSON serialization.
    """

    # === Core Properties (always present) ===

    column_name: str = Field(
        ...,
        alias="columnName",
        description="The name of the column"
    )

    data_type: Union[Type[Enum], type, str] = Field(
        ...,
        alias="dataType",
        description="Either a primitive type, bool, or an enum class"
    )

    validation_type: Optional[str] = Field(
        default=None,
        alias="validationType",
        description="Validation rules for this field"
    )

    required: Optional[bool] = Field(
        default=False,
        description="Whether this field is required"
    )

    required_if: Optional[str] = Field(
        default=None,
        alias="requiredIf",
        description="Conditional requirement logic"
    )

    pk: Optional[bool] = Field(
        default=False,
        description="Whether this is a primary key field"
    )

    master_table: List[TableName] = Field(
        default_factory=list,
        alias="masterTable",
        description="Tables this field references"
    )

    expandable: Optional[bool] = Field(
        default=False,
        description="Whether this field can be expanded"
    )

    # Technology support fields
    neo: Optional[TechnologySupport] = Field(
        default=None,
        alias="neo",
        description="NEO technology support level"
    )

    throg: Optional[TechnologySupport] = Field(
        default=None,
        alias="throg",
        description="THROG technology support level"
    )

    dendro: Optional[TechnologySupport] = Field(
        default=None,
        alias="dendro",
        description="DENDRO technology support level"
    )

    hopper: Optional[TechnologySupport] = Field(
        default=None,
        alias="hopper",
        description="HOPPER technology support level"
    )

    triad: Optional[TechnologySupport] = Field(
        default=None,
        alias="triad",
        description="TRIAD technology support level"
    )

    dart: Optional[TechnologySupport] = Field(
        default=None,
        alias="dart",
        description="DART technology support level"
    )
    
    cyclo: Optional[TechnologySupport] = Field(
        default=None,
        alias="cyclo",
        description="CYCLO technology support level"
    )

    allowable_uom_types: List[str] = Field(
        default_factory=list,
        alias="allowableUOMTypes",
        description="Allowed unit of measure types"
    )

    u_o_m_conversion: Optional[str] = Field(
        default=None,
        alias="UOMConversion",
        description="Unit of measure conversion specification"
    )

    relates_to_keys: Optional[str] = Field(
        default=None,
        alias="relatesToKeys",
        description="Key relationships"
    )

    default_value: Optional[str] = Field(
        default=None,
        alias="defaultValue",
        description="Default value for this field"
    )

    notes: Optional[str] = Field(
        default=None,
        description="Internal notes about this field"
    )

    explanation: Optional[str] = Field(
        default=None,
        description="User-facing explanation of this field"
    )

    master_column: List[ColumnReference] = Field(
        default_factory=list,
        alias="masterColumn",
        description="Column references in format 'TableName.ColumnName'"
    )

    # === Common Optional Properties ===

    precision_category: List[str] = Field(
        default_factory=list,
        alias="precisionCategory",
        description="Precision categorization for this field"
    )

    basic_mode: List[str] = Field(
        default_factory=list,
        alias="basicMode",
        description="Basic mode settings"
    )

    disaggregation_logic: Optional[str] = Field(
        default=None,
        alias="disaggregationLogic",
        description="Logic for disaggregating this field (output tables only)"
    )

    # Lifecycle flag
    in_database: bool = Field(
        default=False,
        alias="inDatabase",
        description="Whether this column exists in the database (False for in-development columns)"
    )

    # === Validators ===

    @field_validator('master_column')
    @classmethod
    def validate_master_column(cls, v: List[ColumnReference]) -> List[ColumnReference]:
        """Validate column references (format: 'TableName.ColumnName')."""
        for col_ref in v:
            if col_ref and '.' not in col_ref:
                raise ValueError(f"Invalid column reference format: {col_ref}")
        return v

    # === Configuration ===

    model_config = {
        "populate_by_name": True,  # Allow both snake_case and camelCase
        "arbitrary_types_allowed": True,  # For Enum types and bool
        "extra": "allow",  # Allow column-specific fields
    }

    # === Methods ===

    def to_json_dict(self) -> dict:
        """
        Export to JSON format with camelCase keys.

        Special handling for data_type field:
        - bool → ["True", "False"]
        - DataType enum → "String", "Double", etc.
        - Value enum → ["Value1", "Value2", ...]

        Special handling for technology fields:
        - TechnologySupport enum → string value
        - None or UNSUPPORTED → omitted from JSON

        Note: in_database field is excluded from JSON output (used for filtering only)
        """
        from .enums import DataType, TechnologySupport

        # Store data_type before serialization
        dt = self.data_type

        # Get base dict with camelCase keys, excluding data_type and in_database
        result = self.model_dump(
            by_alias=True,
            exclude_none=True,  # Changed from False to skip None values
            exclude={'data_type', 'in_database'},  # Exclude in_database
            mode='json'
        )

        # Special handling for dataType field - need to insert it in correct position
        # to preserve field order (after columnName, before validationType/required)
        if dt is bool:
            data_type_value = ["True", "False"]
        elif isinstance(dt, DataType):
            data_type_value = dt.value
        elif isinstance(dt, type) and issubclass(dt, Enum):
            data_type_value = [member.value for member in dt]
        elif isinstance(dt, str):
            # Shouldn't happen, but handle gracefully
            data_type_value = dt
        else:
            data_type_value = str(dt)

        # Insert dataType in the correct position (after columnName)
        # Create a new dict with correct field order
        ordered_result = {}
        for key, value in result.items():
            ordered_result[key] = value
            # Insert dataType right after columnName
            if key == 'columnName':
                ordered_result['dataType'] = data_type_value

        # If columnName wasn't in result (shouldn't happen), add dataType at end
        if 'dataType' not in ordered_result:
            ordered_result['dataType'] = data_type_value

        result = ordered_result

        # Special handling for technology fields
        # Convert TechnologySupport enum to string, omit UNSUPPORTED/None
        for tech in TECHNOLOGY_NAMES:
            value = getattr(self, tech, None)
            if value and value != TechnologySupport.UNSUPPORTED:
                result[tech] = value.value  # "fully-supported" or "in-development"
            else:
                result.pop(tech, None)  # Remove if None or UNSUPPORTED

        return result

    def is_fully_supported(self, tech_name: str) -> bool:
        """
        Check if column is fully supported for a technology.

        Args:
            tech_name: Technology name (lowercase): "neo", "throg", "dendro", "hopper", "triad", "dart"

        Returns:
            True if technology is fully supported
        """
        from .enums import TechnologySupport, TECHNOLOGY_NAMES
        support = getattr(self, tech_name.lower(), None)
        return support == TechnologySupport.FULLY_SUPPORTED

    def is_available(self, tech_name: str, include_in_dev: bool = False) -> bool:
        """
        Check if column is available for a technology.

        Args:
            tech_name: Technology name (lowercase): "neo", "throg", "dendro", "hopper", "triad", "dart"
            include_in_dev: Include in-development features

        Returns:
            True if technology is available
        """
        from .enums import TechnologySupport, TECHNOLOGY_NAMES
        support = getattr(self, tech_name.lower(), None)

        if support == TechnologySupport.FULLY_SUPPORTED:
            return True
        if include_in_dev and support == TechnologySupport.IN_DEVELOPMENT:
            return True
        return False
