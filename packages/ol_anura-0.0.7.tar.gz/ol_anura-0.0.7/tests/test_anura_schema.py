from ol_anura import *

TABLE_NAME = "Customers"
COLUMN_NAME = "CustomerName"
TECHNOLOGY = "neo"


def test_table_discovery_methods():
    # Arrange
    category = Category.MODEL_ELEMENTS

    # Act
    all_tables = AnuraSchema.get_all_table_names()
    input_tables = AnuraSchema.get_input_table_names()
    output_tables = AnuraSchema.get_output_table_names()
    by_category = AnuraSchema.get_tables_by_category(category)
    abbreviated = AnuraSchema.get_abbreviated_table_names()

    # Assert
    assert isinstance(all_tables, list)
    assert isinstance(input_tables, list)
    assert isinstance(output_tables, list)
    assert isinstance(by_category, list)
    assert isinstance(abbreviated, dict)
    assert len(all_tables) > 0


def test_table_technology_methods():
    # Arrange
    technology = TECHNOLOGY
    table_name = TABLE_NAME

    # Act
    tables_for_tech = AnuraSchema.get_tables_for_technology(technology)
    supported = AnuraSchema.get_supported_tables(technology)
    fully_supported = AnuraSchema.get_fully_supported_tables(technology)
    support_level = AnuraSchema.get_table_support_level(table_name, technology)
    basic_mode = AnuraSchema.get_basic_mode_tables(technology)

    # Assert
    assert isinstance(tables_for_tech, list)
    assert isinstance(supported, list)
    assert isinstance(fully_supported, list)
    assert isinstance(basic_mode, list)
    assert support_level in {
        TechnologySupport.FULLY_SUPPORTED,
        TechnologySupport.IN_DEVELOPMENT,
        TechnologySupport.UNSUPPORTED,
        None,
    }


def test_column_query_methods():
    # Arrange
    technology = TECHNOLOGY
    table_name = TABLE_NAME
    column_name = COLUMN_NAME
    data_type = DataType.STRING

    # Act
    primary_keys = AnuraSchema.get_primary_keys(table_name)
    columns = AnuraSchema.get_columns(table_name)
    dtype = AnuraSchema.get_column_data_type(table_name, column_name)
    supported = AnuraSchema.is_column_supported_by_technology(
        table_name, column_name, technology
    )
    required = AnuraSchema.get_required_columns(table_name)
    by_type = AnuraSchema.get_columns_by_data_type(table_name, data_type)
    with_validation = AnuraSchema.get_columns_with_validation(table_name)
    field_defs = AnuraSchema.get_field_definitions(table_name)
    columns_for_tech = AnuraSchema.get_columns_for_technology(table_name, technology)
    supported_columns = AnuraSchema.get_supported_columns(table_name, technology)
    column_support = AnuraSchema.get_column_support_level(
        table_name, column_name, technology
    )

    # Assert
    assert isinstance(primary_keys, list)
    assert isinstance(columns, list)
    assert dtype is not None
    assert isinstance(supported, bool)
    assert isinstance(required, list)
    assert isinstance(by_type, list)
    assert isinstance(with_validation, list)
    assert isinstance(field_defs, list)
    assert isinstance(columns_for_tech, list)
    assert isinstance(supported_columns, list)
    assert column_support in {
        TechnologySupport.FULLY_SUPPORTED,
        TechnologySupport.IN_DEVELOPMENT,
        TechnologySupport.UNSUPPORTED,
        None,
    }


def test_engine_schema_methods():
    # Arrange
    technology = TECHNOLOGY
    table_name = TABLE_NAME

    # Act
    table_schema = AnuraSchema.get_table_schema_for_technology(table_name, technology)
    engine_schema = AnuraSchema.get_engine_schema(technology)
    engine_tables = AnuraSchema.get_engine_table_list(technology)
    column_mapping = AnuraSchema.get_engine_column_mapping(technology)
    export_dict = AnuraSchema.export_engine_schema_to_dict(technology)

    # Assert
    assert isinstance(table_schema, dict)
    assert isinstance(engine_schema, dict)
    assert isinstance(engine_tables, list)
    assert isinstance(column_mapping, dict)
    assert isinstance(export_dict, dict)
    assert export_dict.get("technology") == technology


def test_relationship_and_metadata_methods():
    # Arrange
    table_name = TABLE_NAME
    column_name = COLUMN_NAME

    # Act
    columns_with_master = AnuraSchema.get_columns_with_master_table(table_name)
    master_tables = AnuraSchema.get_master_tables(table_name, column_name)
    master_column_refs = AnuraSchema.get_master_column_references(table_name, column_name)
    all_master_mappings = AnuraSchema.get_all_master_table_mappings()
    group_enabled = AnuraSchema.get_group_enabled_columns()
    explanation = AnuraSchema.get_column_explanation(table_name, column_name)
    metadata = AnuraSchema.get_table_metadata(table_name)
    summary = AnuraSchema.get_schema_summary()
    table_schema = AnuraSchema.get_table_schema(table_name)

    # Assert
    assert isinstance(columns_with_master, list)
    assert isinstance(master_tables, list)
    assert isinstance(master_column_refs, list)
    assert isinstance(all_master_mappings, dict)
    assert isinstance(group_enabled, dict)
    assert isinstance(explanation, str)
    assert isinstance(metadata, dict)
    assert isinstance(summary, dict)
    assert table_schema.table_name


def test_validation_and_compatibility_wrappers():
    # Arrange
    table_name = TABLE_NAME

    # Act
    validations = AnuraSchema.get_anura_validations()
    validation_types = AnuraSchema.get_validation_types()
    table_validations = AnuraSchema.get_table_validations(table_name)
    masterlist = AnuraSchema.get_anura_masterlist()
    all_tables = AnuraSchema.get_anura_table_names()
    input_tables = AnuraSchema.get_anura_input_table_names()
    output_tables = AnuraSchema.get_anura_output_table_names()
    abbrev = AnuraSchema.get_anura_abbreviated_table_names()
    keys = AnuraSchema.get_anura_keys(table_name)
    columns = AnuraSchema.get_anura_columns(table_name)
    field_defs = AnuraSchema.get_anura_field_definitions()
    table_field_defs = AnuraSchema.get_table_field_definitions(table_name)

    # Assert
    assert isinstance(validations, dict)
    assert isinstance(validation_types, dict)
    assert isinstance(table_validations, list)
    assert isinstance(masterlist, list)
    assert isinstance(all_tables, list)
    assert isinstance(input_tables, list)
    assert isinstance(output_tables, list)
    assert isinstance(abbrev, dict)
    assert isinstance(keys, list)
    assert isinstance(columns, list)
    assert isinstance(field_defs, dict)
    assert isinstance(table_field_defs, list)
