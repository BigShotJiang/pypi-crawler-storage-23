![logo](https://raw.githubusercontent.com/xingkaixin/agent-dump/refs/heads/main/assets/logo.png)

# Agent Dump

AI Coding Assistant Session Export Tool - Supports exporting session data from multiple AI coding tools to JSON format.

## Supported AI Tools

- **OpenCode** - Open source AI coding assistant
- **Claude Code** - Anthropic's AI coding tool
- **Codex** - OpenAI's command-line AI coding assistant
- **Kimi** - Moonshot AI assistant
- **More Tools** - PRs are welcome to support other AI coding tools

## Features

- **Interactive Selection**: Provides a friendly command-line interactive interface using questionary
- **Multi-Agent Support**: Automatically scan session data from multiple AI tools
- **Batch Export**: Supports exporting all sessions from the last N days
- **Specific Export**: Export specific sessions by session ID
- **Session List**: Only list sessions without exporting them
- **Statistics**: Exports include statistics such as token usage and cost
- **Message Details**: Fully retains session messages, tool calls, and other details
- **Smart Title Extraction**: Automatically extract session titles from agent metadata

## Installation

### Method 1: Install using uv tool (Recommended)

```bash
# Install from PyPI (Available after release)
uv tool install agent-dump

# Install directly from GitHub
uv tool install git+https://github.com/xingkaixin/agent-dump
```

### Method 2: Run directly using uvx (No installation required)

```bash
# Run from PyPI (Available after release)
uvx agent-dump --help

# Run directly from GitHub
uvx --from git+https://github.com/xingkaixin/agent-dump agent-dump --help
```

### Method 3: Local Development

```bash
# Clone the repository
git clone https://github.com/xingkaixin/agent-dump.git
cd agent-dump

# Use uv to install dependencies
uv sync

# Local installation test
uv tool install . --force
```

## Usage

### Interactive Export

```bash
# Enter interactive mode to select and export sessions
uv run agent-dump --interactive

# Or run as a module
uv run python -m agent_dump --interactive
```

After running, it will display the list of sessions from the last 7 days grouped by time (Today, Yesterday, This Week, This Month, Earlier). Use the spacebar to select/deselect, and press Enter to confirm the export.

> **Note:** Starting from v0.3.0, the default behavior has changed. Running `agent-dump` without arguments now shows the help message. Use `--interactive` to enter interactive mode.

### Command-line Arguments

```bash
# Display help
uv run agent-dump                             # Show help message
uv run agent-dump --help                      # Show detailed help

# List mode (with pagination)
uv run agent-dump --list                      # List sessions from last 7 days
uv run agent-dump --list --days 3             # List sessions from last 3 days
uv run agent-dump --list --page-size 10       # Show 10 sessions per page

# Interactive export mode
uv run agent-dump --interactive               # Interactive mode (default 7 days)
uv run agent-dump --interactive --days 3      # Interactive mode (3 days)
uv run agent-dump --days 3                    # Auto-activates list mode

# Other options
uv run agent-dump --output ./my-sessions      # Specify output directory
uv run agent-dump --export ses_abc,ses_xyz    # Export specific session IDs
```

### Full Parameter Reference

| Parameter | Description | Default |
|-----------|-------------|---------|
| `--interactive` | Run in interactive mode to select and export sessions | - |
| `--days` | Query sessions from the last N days | 7 |
| `--list` | Only list sessions without exporting (auto-activated if `--days` is specified without `--interactive`) | - |
| `--page-size` | Number of sessions to display per page in list mode | 20 |
| `--output` | Output directory | ./sessions |
| `--export` | Export specific session IDs (comma-separated) | - |
| `-h, --help` | Show help message | - |

## Project Structure

```text
.
├── src/
│   └── agent_dump/          # Main package directory
│       ├── __init__.py      # Package initialization
│       ├── __main__.py      # python -m agent_dump entry point
│       ├── cli.py           # Command-line interface
│       ├── scanner.py       # Agent scanner
│       ├── selector.py      # Interactive selection
│       └── agents/          # Agent modules directory
│           ├── __init__.py  # Agent exports
│           ├── base.py      # BaseAgent abstract class
│           ├── opencode.py  # OpenCode Agent
│           ├── claudecode.py # Claude Code Agent
│           ├── codex.py     # Codex Agent
│           └── kimi.py      # Kimi Agent
├── tests/                   # Test directory
├── pyproject.toml           # Project configuration
├── justfile                 # Automated commands
├── ruff.toml                # Code style configuration
└── sessions/                # Export directory
    └── {agent-name}/        # Exported files categorized by tool
        └── ses_xxx.json
```

## Development

```bash
# Lint code
just lint

# Auto-fix linting issues
just lint-fix

# Format code
just lint-format

# Type checking
just check

# Testing
just test
```

## License

MIT
