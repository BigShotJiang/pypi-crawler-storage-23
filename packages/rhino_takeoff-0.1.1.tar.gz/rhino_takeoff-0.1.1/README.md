# 🦏 Rhino-Takeoff

> **Grasshopper 3D 모델 자동 물량 산출 및 ZEB/녹색건축 인증 리포트 생성 라이브러리**

![Python](https://img.shields.io/badge/python-3.9%2B-blue)
![Rhino](https://img.shields.io/badge/Rhino-7%2F8-black)
![Coverage](https://img.shields.io/badge/coverage-81%25-green)
![License](https://img.shields.io/badge/license-MIT-green)

**Rhino-Takeoff**는 건축 설계 단계에서 Rhino/Grasshopper로 작성된 3D BIM 모델로부터 **면적, 체적, 길이** 등의 물량 정보를 자동으로 추출하고, **한국 에너지자립률(ZEB) 인증 기준(2025)**에 맞춘 견적서(Excel)를 생성하는 Python 라이브러리입니다.

---

## 🚀 왜 필요한가요?

건축 설계 실무에서 Grasshopper로 생성한 비정형 모델의 물량을 산출하여 엑셀 견적서로 옮기는 과정은 대부분 **수작업**으로 이루어집니다. 이는 다음과 같은 문제를 야기합니다.

- **휴먼 에러**: 수많은 객체의 면적을 하나하나 확인하고 기입하는 과정에서 실수 발생.
- **반복 작업**: 설계 변경 시마다 처음부터 다시 산출해야 하는 비효율.
- **복잡한 인증 기준**: 해마다 강화되는 ZEB/녹색건축 인증 기준(에너지자립률 등)을 매번 확인하고 적용하기 어려움.

**Rhino-Takeoff**는 이 과정을 100% 자동화하여 설계자의 시간을 절약하고 데이터의 신뢰성을 보장합니다.

---

## ✨ 주요 기능

### 1. 정밀 물량 추출 (`Extractor`)
- **이원화된 계산 로직**: 
  - `Rhino` 실행 환경: `AreaMassProperties`를 사용하여 정밀한 솔리드(Solid) 면적/체적 계산.
  - `CI/CD` (Rhino 미설치): `rhino3dm` 기반으로 Mesh 변환 후 Cross-Product 적분을 통해 오차 없는 면적 계산.

### 2. 중복 물량 제거 (`Deduplicator`)
- **Boolean 연산**: 기둥과 슬래브, 벽체가 겹치는 부분의 체적/면적을 자동으로 차감.
- **Shapely 최적화**: 2D Footprint 투영을 통해 대용량 모델에서도 빠른 간섭 체크.

### 3. ZEB 인증 리포트 (`ZEBReport`)
- **2025년 기준 적용**: 최신 한국 에너지자립률(%) 산정 공식을 적용.
- **등급 자동 판정**: 1차 에너지 소요량과 신재생 생산량을 기반으로 **ZEB 1~5등급** 달성 여부 자동 판단.

### 4. Excel 자동화 (`ExcelWriter`)
- **Template 보존**: 기존 엑셀 서식(스타일, 수식)을 그대로 유지하면서 데이터만 정확한 셀 위치에 기입.
- **SheetWrapper**: 컬럼명 기반 데이터 접근 및 Pandas DataFrame 변환 지원.

---

## 📦 설치 (Installation)

Python 3.9 이상 환경에서 설치할 수 있습니다.

```bash
# 기본 설치
pip install rhino-takeoff

# 데이터 분석(pandas), 기하 연산(shapely) 포함 설치
pip install "rhino-takeoff[pandas]"
```

---

## ⚡ 퀵스타트 (Quick Start)

### 1. 기본 물량 추출

```python
from rhino_takeoff import Extractor, Classifier
import rhino3dm

# 모델 로드
model = rhino3dm.File3dm.Read("building.3dm")
objects = model.Objects

# 객체 분류 및 면적 추출
clf = Classifier()
ext = Extractor()

classified = clf.classify_all(objects)
# {'slab': [...], 'wall': [...], ...}

results = ext.batch(objects, measure="area", unit="m2")
print(results[:3])
# [{'id': 'guid...', 'measure': 'area', 'value': 120.5, 'unit': 'm2'}, ...]
```

### 2. ZEB 인증 리포트 생성

```python
from rhino_takeoff.zeb import ZEBReport

# 프로젝트 생성
zeb = ZEBReport(project_name="강남 업무시설 신축")

# 에너지 데이터 입력 (kWh/m2/y)
zeb.set_energy_consumption(primary_energy_kwh_m2_y=150.0, floor_area_m2=3000.0)
zeb.set_renewable_production(renewable_primary_energy_kwh_m2_y=35.0)

# 외피 정보 추가 (단열 성능 체크용)
zeb.add_envelope(element="지붕", area_m2=500.0, u_value=0.12)
zeb.add_envelope(element="외벽", area_m2=1200.0, u_value=0.14)

# 등급 계산 및 엑셀 출력
rate = zeb.calc_energy_independence_rate() # 23.33%
grade = zeb.get_achievable_grade()         # "ZEB_5"

print(f"자립률: {rate}%, 등급: {grade}")

# zeb.export_excel("ZEB_Report.xlsx") 
```

---

## 📂 프로젝트 구조

```text
rhino-takeoff/
├── rhino_takeoff/
│   ├── extractor.py   # 기하 물량 추출 (Core)
│   ├── dedup.py       # 중복 제거 로직
│   ├── zeb.py         # ZEB 인증 및 등급 산정
│   ├── excel_io.py    # Excel 입출력 핸들러
│   ├── classifier.py  # 객체 유형 분류
│   ├── validators.py  # 단위 검증
│   └── models.py      # 데이터 모델 (Pydantic)
├── data/
│   └── zeb_standards.json # ZEB 인증 기준 데이터
├── examples/          # 사용 예시 스크립트
├── tests/             # 단위 테스트 (pytest)
└── pyproject.toml     # 프로젝트 설정
```

---

## 🤝 기여하기 (Contributing)

이 프로젝트는 오픈 소스이며 모든 기여를 환영합니다.
1. Fork this repository.
2. Create a feature branch (`git checkout -b feat/new-feature`).
3. Commit your changes (`git commit -m 'feat: Add new feature'`).
4. Push to the branch (`git push origin feat/new-feature`).
5. Open a Pull Request.

---

## 📄 라이선스 (License)

이 프로젝트는 [MIT License](LICENSE)를 따릅니다.
