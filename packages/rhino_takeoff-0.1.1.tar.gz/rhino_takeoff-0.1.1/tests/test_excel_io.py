import pytest
from rhino_takeoff.excel_io import ExcelWriter


def test_sheet_wrapper_functionality():
    import unittest.mock

    # Create mock setup that mimics worksheet behavior
    mock_ws = unittest.mock.MagicMock()

    # Setup cell values for Header access (Row 1)
    # Row 1: ["ColA", "ColB"]
    # Row 2: [10, 20]
    # Row 3: [30, None]

    def cell_side_effect(row, column):
        m = unittest.mock.MagicMock()
        val = None
        if row == 1:
            if column == 1:
                val = "ColA"
            if column == 2:
                val = "ColB"
        elif row == 2:
            if column == 1:
                val = 10
            if column == 2:
                val = 20
        elif row == 3:
            if column == 1:
                val = 30
            if column == 2:
                val = None

        m.value = val
        return m

    mock_ws.cell.side_effect = cell_side_effect
    mock_ws.max_column = 2
    mock_ws.max_row = 3
    # mock item access
    mock_ws.__getitem__.return_value.value = "AccessVal"

    from rhino_takeoff.excel_io import SheetWrapper

    sw = SheetWrapper(mock_ws)

    # 1. Test __getitem__
    assert sw["A1"] == "AccessVal"

    # 2. Test column()
    col_a = sw.column("ColA")
    assert col_a == [10, 30]
    col_b = sw.column("ColB")
    assert col_b == [20]  # None excluded
    col_none = sw.column("NoHeader")
    assert col_none == []

    # 3. Test row()
    row_2 = sw.row(2)
    assert row_2 == {"ColA": 10, "ColB": 20}

    # 4. Test to_dataframe (Pandas Check)
    # Ensure pandas import works or fails gracefully
    # If pandas installed in environment, it returns DF.
    # If not, returns list.
    # We can mock pandas absence or presence.

    # Case: Pandas missing
    import sys

    with unittest.mock.patch.dict(sys.modules, {"pandas": None}):
        mock_ws.values = [["H1", "H2"], [1, 2]]
        res = sw.to_dataframe()
        assert isinstance(res, list)
        assert res == [["H1", "H2"], [1, 2]]


def test_reader_sheet_returns_wrapper():
    # Verify ExcelReader.sheet() returns SheetWrapper
    import unittest.mock

    with unittest.mock.patch("os.path.exists", return_value=True):
        from rhino_takeoff.excel_io import ExcelReader

        reader = ExcelReader("dummy.xlsx")
        # configure sheetnames
        reader.wb.sheetnames = ["S1"]

        s = reader.sheet("S1")
        from rhino_takeoff.excel_io import SheetWrapper

        assert isinstance(s, SheetWrapper)

        with pytest.raises(KeyError):
            reader.sheet("NonExistent")


def test_write_table_logic():
    writer = ExcelWriter()
    # Mock behavior already similar, just ensuring no regress
    data = [{"ColA": 1}, {"ColA": None}]  # Test None value skipping
    writer.write_table("A1", data, ["ColA"])


def test_write_dict_logic():
    writer = ExcelWriter()

    # Mock header row
    def cell_side_effect(row, column, value=None):
        from unittest.mock import MagicMock

        m = MagicMock()
        if row == 1 and column == 1:
            m.value = "Head"
        return m

    writer.wb.active.cell.side_effect = cell_side_effect
    writer.write_dict({"Head": "Val"})
