from rhino_takeoff.validators import UnitValidator


def test_unit_conversion():
    uv = UnitValidator()
    assert uv.to_mm(1.0, "m") == 1000.0
    assert uv.to_m(1000.0, "mm") == 1.0
    assert uv.to_mm(10.0, "cm") == 100.0


def test_helper_unit_detection(caplog):
    uv = UnitValidator()
    assert uv.detect_unit(5000) == "mm"
    assert uv.detect_unit(3.5) == "m"
    assert uv.detect_unit(2000000) == "mm2"


def test_convert_all():
    uv = UnitValidator()
    data = {"len1": 1000, "len2": 2000}  # mm

    res = uv.convert_all(data, "mm", "m")
    assert res["len1"] == 1.0
    assert res["len2"] == 2.0


def test_area_validator():
    from rhino_takeoff.validators import AreaValidator

    av = AreaValidator()

    # Normal case
    assert av.check_range(100.0)

    # Negative case
    assert not av.check_range(-10.0)

    # Excessive case
    assert not av.check_range(200000.0)


def test_validator_warnings():
    uv = UnitValidator()
    # Invalid units should return original value and log warning
    assert uv.to_mm(100, "km") == 100
    assert uv.to_m(100, "km") == 100
    assert uv.to_m2(100, "km2") == 100
    assert uv.to_mm2(100, "km2") == 100
