from rhino_takeoff.extractor import Extractor, _area_from_mesh
from unittest.mock import MagicMock, patch


def test_area_from_mesh():
    import rhino3dm as rg

    mesh = rg.Mesh()
    mesh.AddVertex(0, 0, 0)
    mesh.AddVertex(10, 0, 0)
    mesh.AddVertex(0, 10, 0)
    mesh.AddFace(0, 1, 2)
    assert _area_from_mesh(mesh) == 50.0


def test_extractor_rhino3dm_modes():
    ext = Extractor()
    import rhino3dm as rg

    # Mesh
    mesh = rg.Mesh()
    mesh.AddVertex(0, 0, 0)
    mesh.AddVertex(1000, 0, 0)
    mesh.AddVertex(1000, 1000, 0)
    mesh.AddVertex(0, 1000, 0)
    mesh.AddFace(0, 1, 2, 3)
    assert ext.area(mesh, "m2") == 1.0

    # Brep with GetMesh support (User Requirement)
    # We monkeypatch GetMesh on the instance for rhino3dm environment simulation
    brep = rg.Brep()

    # Create method to bind
    def get_mesh_mock(t):
        return mesh

    brep.GetMesh = get_mesh_mock

    # We need to make sure isinstance(brep, rg.Brep) is True (it is, since we instantiated it from rg)
    # And our extractor uses hasattr(geometry, "GetMesh")

    val_m2_brep = ext.area(brep, unit="m2")
    assert val_m2_brep == 1.0


def test_extractor_is_rhino_true():
    # Mock the module-level IS_RHINO constant to True
    with patch("rhino_takeoff.extractor.IS_RHINO", True):
        # We also need to mock Rhino.Geometry which is imported in extractor
        # Since extractor imports RG inside try-except, if IS_RHINO=True, it means import succeeded.
        # But we replaced it in `sys.modules`?
        # `patch` on IS_RHINO only changes the variable.
        # We need to patch `rhino_takeoff.extractor.rg`.

        with patch("rhino_takeoff.extractor.rg") as mock_rg:
            # Setup AreaMassProperties
            mock_amp = MagicMock()
            mock_amp.Area = 123.0
            mock_rg.AreaMassProperties.Compute.return_value = mock_amp

            # Setup VolumeMassProperties
            mock_vmp = MagicMock()
            mock_vmp.Volume = 456.0
            mock_rg.VolumeMassProperties.Compute.return_value = mock_vmp

            ext = Extractor()
            geo = MagicMock()

            # Test Area (mm2) -> loops to return val_mm2
            assert ext.area(geo, "mm2") == 123.0

            # Test Volume
            # In volume() code: val_mm3 = vmp.Volume if vmp else 0.0
            # Then if unit=="m3": return val/1e9
            # Else return val
            # We call with "raw" unit (anything not m3)
            assert ext.volume(geo, "raw") == 456.0

            # Test Exception path for coverage
            mock_rg.AreaMassProperties.Compute.side_effect = Exception("Fail")
            assert ext.area(geo, "mm2") == 0.0

            # Reset side effect
            mock_rg.AreaMassProperties.Compute.side_effect = None
            mock_rg.AreaMassProperties.Compute.return_value = None
            assert ext.area(geo, "mm2") == 0.0


def test_extractor_getmesh_none():
    # IS_RHINO = False fallback
    ext = Extractor()
    MagicMock()
    # It passes isinstance check if we use MockBrep from conftest or generic mock if not checked strictly
    # The code checks `isinstance(geometry, rg.Brep)`
    import rhino3dm as rg

    # Create Brep that returns None for GetMesh
    class BadBrep(rg.Brep):
        def GetMesh(self, t):
            return None

    b = BadBrep()
    assert ext.area(b) == 0.0


def test_volume_rhino3dm(mock_geometry):
    ext = Extractor()
    geo = mock_geometry("v1")
    # conftest mock bbox 10x10x0.3 m = 30 m3
    assert ext.volume(geo, "m3") == 30.0


def test_length_calc():
    ext = Extractor()
    c = MagicMock()
    c.GetLength.return_value = 1000.0
    assert ext.length(c) == 1.0
