from rhino_takeoff.classifier import Classifier


def test_classifier_full(mock_geometry):
    clf = Classifier()

    s = mock_geometry("s", "SLAB")
    w = mock_geometry("w", "WALL")

    res = clf.classify_all([s, w])
    assert len(res["slab"]) == 1
    assert len(res["wall"]) == 1

    rpt = clf.report()
    assert rpt["slab"] == 1
    assert rpt["wall"] == 1


def test_classify_unknown_fallback(mock_geometry):
    clf = Classifier()
    u = mock_geometry("u", "UNK")

    # Default mock BBox is slab-like.
    assert clf.classify(u) == "slab"

    # Override bbox to be unknown
    from unittest.mock import MagicMock

    class MockBBoxCube:
        class Pt:
            def __init__(self, x, y, z):
                self.X, self.Y, self.Z = x, y, z

        def __init__(self):
            self.Min = self.Pt(0, 0, 0)
            self.Max = self.Pt(1000, 1000, 1000)
            self.IsValid = True

    u.GetBoundingBox = MagicMock(return_value=MockBBoxCube())

    assert clf.classify(u) == "unknown"
