import logging
import re
from typing import Any, Dict, List, Optional

try:
    import Rhino.Geometry as rg  # type: ignore  # noqa: F401

    IS_RHINO = True
except ImportError:
    IS_RHINO = False

logger = logging.getLogger(__name__)


class Classifier:
    """
    Classifies Rhino objects into architectural elements (Column, Beam, Slab, Wall, etc.)
    based on layer names or geometric properties.
    """

    def __init__(self, rules: Optional[Dict[str, str]] = None):
        """
        Initializes the Classifier with optional custom rules.

        Args:
            rules: A dictionary mapping regex patterns to category names.
                   Example: { r"C\\d+": "column", r"S\\d+": "slab" }
        """
        self.rules = rules or self._default_rules()
        self._last_result: Dict[str, int] = {}

    def _default_rules(self) -> Dict[str, str]:
        return {
            r"(?i)col": "column",
            r"(?i)slab": "slab",
            r"(?i)wall": "wall",
            r"(?i)beam": "beam",
            r"(?i)foun": "foundation",
        }

    def classify(self, geometry: Any, layer_name: str = "") -> str:
        """
        Classifies a single geometry object.

        Prioritizes layer name matching. Falls back to geometric inference if layer matching fails.

        Args:
            geometry: The Rhino geometry object.
            layer_name: The name of the layer the object belongs to.

        Returns:
            The determined category string ("column", "slab", "wall", etc.) or "unknown".
        """
        # 1. Layer Name Matching
        if layer_name:
            for pattern, category in self.rules.items():
                if re.search(pattern, layer_name):
                    return category

        # 2. Geometric Fallback (Proportions of BoundingBox)
        if geometry:
            bbox = geometry.GetBoundingBox(True)
            if bbox.IsValid:
                dx = bbox.Max.X - bbox.Min.X
                dy = bbox.Max.Y - bbox.Min.Y
                dz = bbox.Max.Z - bbox.Min.Z

                # Flat and wide -> Slab
                if dz < dx * 0.2 and dz < dy * 0.2:
                    return "slab"
                # Tall and narrow -> Column
                if dz > dx * 2 and dz > dy * 2:
                    return "column"

        return "unknown"

    def classify_all(self, geometries: List[Any]) -> Dict[str, List[Any]]:
        """
        Classifies a list of geometries.

        Args:
            geometries: A list of Rhino geometry objects.

        Returns:
            A dictionary where keys are categories and values are lists of objects.
            Example: { "slab": [obj1, obj2], "column": [obj3] }
        """
        classified: Dict[str, List[Any]] = {
            "slab": [],
            "column": [],
            "wall": [],
            "beam": [],
            "foundation": [],
            "unknown": [],
        }

        for geo in geometries:
            layer = ""
            if hasattr(geo, "UserDictionary") and "layer_name" in geo.UserDictionary:
                layer = geo.UserDictionary["layer_name"]

            category = self.classify(geo, layer_name=layer)
            if category not in classified:
                classified[category] = []
            classified[category].append(geo)

        self._last_result = {k: len(v) for k, v in classified.items()}

        return classified

    def report(self) -> Dict[str, int]:
        """
        Returns statistics from the most recent classification.

        Returns:
            A dictionary mapping categories to the count of classified items.
        """
        return self._last_result
