import logging
import os
from typing import List, Dict, Any, Optional
import openpyxl
from openpyxl.utils import cell as cell_utils

logger = logging.getLogger(__name__)


class SheetWrapper:
    """
    Wrapper for Excel Worksheet to provide enhanced access methods.
    """

    def __init__(self, ws):
        self.ws = ws

    def __getitem__(self, key):
        return self.ws[key].value

    def column(self, header_name: str) -> List[Any]:
        """
        Extracts data from a column identified by its header name.
        Assumes the first row contains headers.

        Args:
            header_name: The name of the column header.

        Returns:
            A list of values in that column (excluding the header).
        """
        target_col = -1
        for col in range(1, self.ws.max_column + 1):
            val = self.ws.cell(row=1, column=col).value
            if val == header_name:
                target_col = col
                break

        if target_col == -1:
            logger.warning(f"Header '{header_name}' not found.")
            return []

        return [
            self.ws.cell(row=r, column=target_col).value
            for r in range(2, self.ws.max_row + 1)
            if self.ws.cell(row=r, column=target_col).value is not None
        ]

    def row(self, index: int) -> Dict[str, Any]:
        """
        Retrieves a specific row as a dictionary mapped using headers from the first row.

        Args:
            index: The 1-based row index.

        Returns:
            Dictionary mapping headers to cell values.
        """
        headers = []
        for c in range(1, self.ws.max_column + 1):
            h = self.ws.cell(row=1, column=c).value
            headers.append(h)

        values = []
        for c in range(1, self.ws.max_column + 1):
            v = self.ws.cell(row=index, column=c).value
            values.append(v)

        return dict(zip(headers, values))

    def to_dataframe(self):
        """
        Converts the sheet content to a Pandas DataFrame.

        Returns:
            pd.DataFrame or a list of rows if pandas is not installed.
        """
        try:
            import pandas as pd

            data = list(self.ws.values)
            if not data:
                return pd.DataFrame()
            return pd.DataFrame(data[1:], columns=data[0])
        except ImportError:
            logger.warning("Pandas not installed. Returning raw list of values.")
            return list(self.ws.values)


class ExcelWriter:
    """
    Handles writing data to Excel files, preserving templates if provided.
    """

    def __init__(self, template_path: Optional[str] = None):
        """
        Args:
            template_path: Path to an existing Excel file to use as a template.
        """
        if template_path and os.path.exists(template_path):
            self.wb = openpyxl.load_workbook(template_path)
            self.filepath = template_path
        else:
            self.wb = openpyxl.Workbook()
            self.filepath = "output.xlsx"

    def write(self, cell_address: str, value: Any, sheet_name: Optional[str] = None):
        """
        Writes a single value to a specific cell.

        Args:
            cell_address: Excel cell address (e.g., "A1").
            value: The value to write.
            sheet_name: Name of the sheet. Defaults to active sheet.
        """
        ws = self._get_sheet(sheet_name)
        try:
            ws[cell_address] = value
        except Exception as e:
            logger.error(f"Failed to write to {cell_address}: {e}")

    def write_table(
        self,
        start_cell: str,
        data: List[Dict[str, Any]],
        headers: List[str],
        sheet_name: Optional[str] = None,
    ):
        """
        Writes a list of dictionaries as a table starting from a specific cell.

        Args:
            start_cell: Top-left cell address for the table.
            data: List of data dictionaries.
            headers: List of keys to extract from dictionaries and write as headers.
            sheet_name: Name of the sheet.
        """
        ws = self._get_sheet(sheet_name)
        try:
            col_idx, row_idx = cell_utils.coordinate_from_string(start_cell)
            col_idx = cell_utils.column_index_from_string(col_idx)
        except ValueError:
            logger.error(f"Invalid start cell: {start_cell}")
            return

        for i, header in enumerate(headers):
            cell = ws.cell(row=row_idx, column=col_idx + i)
            cell.value = header

        current_row = row_idx + 1
        for item in data:
            for i, header in enumerate(headers):
                val = item.get(header)
                cell = ws.cell(row=current_row, column=col_idx + i)
                if val is not None:
                    cell.value = val
            current_row += 1

    def write_dict(self, data: Dict[str, Any], sheet_name: Optional[str] = None):
        """
        Writes dictionary values to specific cells or columns.

        Keys can be:
        1. Cell addresses (e.g., "B2") -> Value written to that cell.
        2. Header names -> Value written to the first available row under that header.

        Args:
            data: Dictionary of data to write.
            sheet_name: Name of the sheet.
        """
        ws = self._get_sheet(sheet_name)

        header_map = {}
        headers_scanned = False

        def scan_headers():
            for col in range(1, ws.max_column + 1):
                val = ws.cell(row=1, column=col).value
                if val:
                    header_map[str(val)] = col
            return True

        for k, v in data.items():
            is_coord = False
            if k and k[0].isalpha() and k[-1].isdigit():
                try:
                    cell_utils.coordinate_from_string(k)
                    is_coord = True
                except ValueError:
                    is_coord = False

            if is_coord:
                ws[k] = v
            else:
                if not headers_scanned:
                    headers_scanned = scan_headers()

                col_idx = header_map.get(k)
                if col_idx:
                    ws.cell(row=2, column=col_idx, value=v)
                else:
                    logger.warning(
                        f"Could not find column header or cell address for key: {k}"
                    )

    def save(self, filepath: Optional[str] = None):
        """
        Saves the workbook to the file system.

        Args:
            filepath: Destination path. Defaults to the template path or "output.xlsx".
        """
        path = filepath or self.filepath
        self.wb.save(path)

    def _get_sheet(self, sheet_name):
        if sheet_name:
            if sheet_name in self.wb.sheetnames:
                return self.wb[sheet_name]
            else:
                return self.wb.create_sheet(sheet_name)
        return self.wb.active


class ExcelReader:
    """
    Reads data from Excel files.
    """

    def __init__(self, filepath: str):
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"File not found: {filepath}")
        self.wb = openpyxl.load_workbook(filepath, data_only=True)

    def sheet(self, sheet_name: str) -> SheetWrapper:
        """
        Returns a SheetWrapper for the specified sheet.

        Args:
            sheet_name: Name of the sheet to read.

        Raises:
            KeyError: If the sheet does not exist.
        """
        if sheet_name not in self.wb.sheetnames:
            raise KeyError(f"Sheet {sheet_name} not found")
        return SheetWrapper(self.wb[sheet_name])
