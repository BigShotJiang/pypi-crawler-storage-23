from typing import List, Dict, Any
import json
import os
import logging
from .models import ZEBEnvelope

logger = logging.getLogger(__name__)


class ZEBReport:
    """
    Calculates Energy Independence Rate and determines the ZEB (Zero Energy Building)
    Grade based on Korean Green Building Certification Standards (2025).
    """

    def __init__(self, project_name: str, building_type: str = "Residential"):
        """
        Args:
            project_name: Name of the project.
            building_type: Type of the building (e.g., "Residential", "Commercial").
        """
        self.project_name = project_name
        self.building_type = building_type
        self.envelopes: List[ZEBEnvelope] = []

        self.primary_energy_kwh_m2_y = 0.0
        self.renewable_prod_kwh_m2_y = 0.0
        self.floor_area_m2 = 0.0

        self.standards = self._load_standards()

    def _load_standards(self) -> Dict[str, Any]:
        """Loads ZEB standards from the embedded JSON file."""
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        json_path = os.path.join(base_dir, "data", "zeb_standards.json")

        try:
            with open(json_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except FileNotFoundError:
            logger.warning("zeb_standards.json not found. Using defaults.")
            return {}

    def set_energy_consumption(
        self, primary_energy_kwh_m2_y: float, floor_area_m2: float
    ):
        """
        Sets the primary energy consumption metrics.

        Args:
            primary_energy_kwh_m2_y: Annual primary energy consumption per unit area.
            floor_area_m2: Total floor area.
        """
        self.primary_energy_kwh_m2_y = primary_energy_kwh_m2_y
        self.floor_area_m2 = floor_area_m2

    def set_renewable_production(self, renewable_primary_energy_kwh_m2_y: float):
        """
        Sets the renewable energy production metrics.

        Args:
            renewable_primary_energy_kwh_m2_y: Annual renewable primary energy production per unit area.
        """
        self.renewable_prod_kwh_m2_y = renewable_primary_energy_kwh_m2_y

    def add_envelope(self, element: str, area_m2: float, u_value: float):
        """
        Adds information about an envelope element (for insulation checks).

        Args:
            element: Name of the element (e.g., "Wall").
            area_m2: Area of the element.
            u_value: Thermal transmittance.
        """
        env = ZEBEnvelope(element=element, area_m2=area_m2, u_value=u_value)
        self.envelopes.append(env)

    def calc_energy_independence_rate(self) -> float:
        """
        Calculates the Energy Independence Rate.

        Formula:
            (Renewable Production / Primary Energy Consumption) * 100

        Returns:
            The rate as a percentage (0.0 - 100.0+).
        """
        if self.primary_energy_kwh_m2_y <= 0:
            return 0.0

        rate = (self.renewable_prod_kwh_m2_y / self.primary_energy_kwh_m2_y) * 100.0
        return round(rate, 2)

    def check_compliance(self, standard: str = "ZEB_5") -> Dict[str, Any]:
        """
        Checks compliance against a specific ZEB grade.

        Args:
            standard: The target grade identifier (e.g., "ZEB_1", "ZEB_5").

        Returns:
            A dictionary containing compliance result, calculated rate, and details.
        """
        current_rate = self.calc_energy_independence_rate()
        target = self.standards.get("grades", {}).get(standard, None)

        if not target:
            logger.warning(f"Unknown standard: {standard}")
            return {"compliant": False, "message": "Unknown standard"}

        required_rate = target["min_independence_rate"]
        compliant = current_rate >= required_rate

        bems = self.standards.get("common_requirements", {}).get(
            "bems_or_remote_meter", True
        )

        return {
            "grade": standard,
            "energy_independence_rate": current_rate,
            "required_rate": required_rate,
            "compliant": compliant,
            "primary_energy_kwh_m2_y": self.primary_energy_kwh_m2_y,
            "bems_required": bems,
            "details": {
                "renewable_production": self.renewable_prod_kwh_m2_y,
                "project": self.project_name,
            },
        }

    def get_achievable_grade(self) -> str:
        """
        Determines the highest ZEB grade achievable with current metrics.

        Returns:
            The grade name (e.g., "ZEB_1") or "None".
        """
        current_rate = self.calc_energy_independence_rate()
        grades = self.standards.get("grades", {})

        sorted_grades = sorted(
            grades.items(), key=lambda x: x[1]["min_independence_rate"], reverse=True
        )

        for name, criteria in sorted_grades:
            if current_rate >= criteria["min_independence_rate"]:
                return name

        return "None"

    def export_summary(self) -> Dict[str, Any]:
        """
        Exports a summary of the project's ZEB status.

        Returns:
            Review summary dictionary.
        """
        return {
            "project": self.project_name,
            "energy_independence_rate": self.calc_energy_independence_rate(),
            "achieved_grade": self.get_achievable_grade(),
            "items_count": len(self.envelopes),
        }
