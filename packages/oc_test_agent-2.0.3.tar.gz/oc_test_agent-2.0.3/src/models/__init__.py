# Data Models

from .test_result import TestResult, TestStatus, Dependency
from .test_report import TestReport, TestReportStatus, TestReportResult

__all__ = [
    'TestResult',
    'TestStatus',
    'Dependency',
    'TestReport',
    'TestReportStatus',
    'TestReportResult',
]
