import click

from ..db.database import Database
from ..core.result_service import ResultService


@click.command()
@click.option('--project', help='项目名')
@click.option('--version', help='版本号')
@click.option('--status', help='状态')
@click.option('--limit', default=10, type=int, help='返回数量')
def query(project, version, status, limit):
    """查询历史测试结果"""
    
    db = Database.get_instance()
    db.init_schema()
    
    result_svc = ResultService()
    
    status_enum = None
    if status:
        from ..models.test_result import TestStatus
        try:
            status_enum = TestStatus(status.lower())
        except ValueError:
            click.echo(f"Error: 无效状态 '{status}'", err=True)
            return
    
    results = result_svc.query(
        project=project,
        version=version,
        status=status_enum,
        limit=limit
    )
    
    if not results:
        click.echo("No results found")
        return
    
    for r in results:
        click.echo(f"\n{r.id}")
        click.echo(f"  Project: {r.project}")
        click.echo(f"  Version: {r.version}")
        click.echo(f"  Status: {r.status.value}")
        click.echo(f"  Passed/Failed/Errors: {r.passed}/{r.failed}/{r.errors}")
        click.echo(f"  Created: {r.created_at}")
