import click
import logging

from ..db.database import Database
from ..core.test_executor import TestExecutor
from ..core.version_client import VersionClient
from ..models.test_report import TestReport

logger = logging.getLogger(__name__)


@click.command()
@click.option('--project', required=True, help='项目名')
@click.option('--project-path', default=None, help='项目代码路径')
@click.option('--version', required=True, help='版本号')
@click.option('--test-type', default='all',
              type=click.Choice(['unit', 'integration', 'e2e', 'all']),
              help='测试类型')
@click.option('--test-type-filter', default='directory',
              type=click.Choice(['directory', 'marker']),
              help='测试过滤方式')
@click.option('--dependencies', default='', help='依赖项目(格式: name:path)')
@click.option('--timeout', default=300, type=int, help='超时时间(秒)')
@click.option('--tag', default='latest', help='镜像标签')
@click.option('--auto-register', is_flag=True, help='测试通过后自动注册版本')
@click.option('--manifest', default=None, help='版本清单文件路径(auto-register时必需)')
@click.option('--auto-release', is_flag=True, help='注册后自动发布版本')
def execute(project, project_path, version, test_type, test_type_filter, dependencies, timeout, tag, auto_register, manifest, auto_release):
    """在 Docker 容器内执行测试"""
    
    db = Database.get_instance()
    db.init_schema()
    
    if not project_path:
        from ..core.config_service import ConfigService
        config_svc = ConfigService()
        project_path = config_svc.get_project_path(project)
    
    if not project_path:
        click.echo(f"Error: 项目路径未指定，请使用 --project-path 或配置 projects.yaml", err=True)
        return
    
    try:
        executor = TestExecutor(
            project=project,
            version=version,
            project_path=project_path,
            test_type=test_type,
            test_type_filter=test_type_filter,
            timeout=timeout,
            tag=tag
        )
        
        click.echo(f"Starting test: {executor.id}")
        
        result = executor.execute()
        
        click.echo(f"\nTest ID: {result.id}")
        click.echo(f"Status: {result.status.value}")
        click.echo(f"Passed: {result.passed}")
        click.echo(f"Failed: {result.failed}")
        click.echo(f"Errors: {result.errors}")
        if result.duration:
            click.echo(f"Duration: {result.duration:.2f}s")
        
        if result.report_path:
            click.echo(f"Report: {result.report_path}")
        
        if auto_register:
            if not manifest:
                click.echo("Error: --manifest is required when using --auto-register", err=True)
                return
            
            test_report = TestReport.from_test_result(result, project)
            
            version_client = VersionClient()
            success = version_client.register(
                version=version,
                manifest_path=manifest,
                test_report=test_report,
                project=project
            )
            
            if success:
                click.echo(f"Version {version} registered successfully")
                
                if auto_release:
                    version_client.release_version(version)
                    click.echo(f"Version {version} released")
            else:
                click.echo(f"Failed to register version {version}", err=True)
        
    except Exception as e:
        logger.error(f"Test execution failed: {e}")
        click.echo(f"Error: {e}", err=True)
