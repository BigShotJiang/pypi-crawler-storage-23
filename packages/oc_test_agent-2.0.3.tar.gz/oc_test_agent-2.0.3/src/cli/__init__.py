"""CLI Commands - re-export from parent cli module."""

# This file allows 'src.cli' to be used as both a module (cli.py) and a package (cli/)
# The cli function is defined in src/cli.py

import click

@click.group()
@click.version_option(version="2.0.3")
def cli():
    """Test-Agent: Docker-based Test Execution System."""
    pass

# Import subcommands
from src.cli.execute import execute
from src.cli.build import build
from src.cli.query import query
from src.cli.report import report
from src.cli.cancel import cancel
from src.cli.cleanup import cleanup
from src.cli.init import init

cli.add_command(execute)
cli.add_command(build)
cli.add_command(query)
cli.add_command(report)
cli.add_command(cancel)
cli.add_command(cleanup)
cli.add_command(init)
