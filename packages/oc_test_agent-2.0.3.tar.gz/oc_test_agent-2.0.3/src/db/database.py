import os
import sqlite3
from pathlib import Path
from typing import Optional
import logging

logger = logging.getLogger(__name__)

# 环境变量配置
OC_STATE_DIR = os.environ.get('OC_STATE_DIR', 'state')
DEFAULT_DB_PATH = os.path.join(OC_STATE_DIR, 'test_results.db')


class Database:
    """SQLite 数据库连接管理"""
    
    _instance: Optional['Database'] = None
    
    def __init__(self, db_path: str = None):
        db_path = db_path or DEFAULT_DB_PATH
        self.db_path = Path(db_path)
        self._connection: Optional[sqlite3.Connection] = None
        
    @classmethod
    def get_instance(cls, db_path: str = None) -> 'Database':
        """单例模式获取数据库实例"""
        if cls._instance is None:
            db_path = db_path or DEFAULT_DB_PATH
            cls._instance = cls(db_path)
        return cls._instance
    
    def get_connection(self) -> sqlite3.Connection:
        """获取数据库连接"""
        if self._connection is None:
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
            self._connection = sqlite3.connect(
                str(self.db_path),
                check_same_thread=False
            )
            self._connection.row_factory = sqlite3.Row
        return self._connection
    
    def init_schema(self) -> None:
        """初始化数据库Schema"""
        conn = self.get_connection()
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS test_results (
                id TEXT PRIMARY KEY,
                project TEXT NOT NULL,
                version TEXT NOT NULL,
                test_type TEXT DEFAULT 'all',
                status TEXT NOT NULL CHECK(status IN ('pending', 'running', 'passed', 'failed', 'error', 'cancelled')),
                duration REAL,
                passed INTEGER DEFAULT 0,
                failed INTEGER DEFAULT 0,
                errors INTEGER DEFAULT 0,
                total INTEGER DEFAULT 0,
                report_path TEXT,
                logs_path TEXT,
                container_id TEXT,
                created_at TEXT NOT NULL DEFAULT (datetime('now')),
                finished_at TEXT,
                metadata TEXT DEFAULT '{}'
            );
            
            CREATE INDEX IF NOT EXISTS idx_results_project ON test_results(project);
            CREATE INDEX IF NOT EXISTS idx_results_version ON test_results(version);
            CREATE INDEX IF NOT EXISTS idx_results_status ON test_results(status);
            CREATE INDEX IF NOT EXISTS idx_results_created ON test_results(created_at);
            
            CREATE TABLE IF NOT EXISTS test_dependencies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                test_id TEXT NOT NULL,
                dependency_project TEXT NOT NULL,
                dependency_path TEXT NOT NULL,
                dependency_version TEXT,
                FOREIGN KEY (test_id) REFERENCES test_results(id) ON DELETE CASCADE
            );
            
            CREATE INDEX IF NOT EXISTS idx_deps_test ON test_dependencies(test_id);
            
            CREATE TABLE IF NOT EXISTS test_config (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                updated_at TEXT NOT NULL DEFAULT (datetime('now'))
            );
            
            CREATE TABLE IF NOT EXISTS test_case_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                test_id TEXT NOT NULL,
                test_case_name TEXT NOT NULL,
                status TEXT NOT NULL CHECK(status IN ('passed', 'failed', 'error', 'skipped')),
                duration REAL DEFAULT 0,
                requirement_id TEXT,
                agent_id TEXT,
                created_at TEXT NOT NULL DEFAULT (datetime('now')),
                FOREIGN KEY (test_id) REFERENCES test_results(id) ON DELETE CASCADE
            );
            
            CREATE INDEX IF NOT EXISTS idx_case_records_test_id ON test_case_records(test_id);
            CREATE INDEX IF NOT EXISTS idx_case_records_name ON test_case_records(test_case_name);
            CREATE INDEX IF NOT EXISTS idx_case_records_requirement ON test_case_records(requirement_id);
            CREATE INDEX IF NOT EXISTS idx_case_records_agent ON test_case_records(agent_id);
        """)
        conn.commit()
        logger.info(f"Database initialized at {self.db_path}")
    
    def close(self) -> None:
        """关闭数据库连接"""
        if self._connection:
            self._connection.close()
            self._connection = None
    
    def backup(self, backup_path: str) -> None:
        """备份数据库"""
        import shutil
        shutil.copy2(self.db_path, backup_path)
