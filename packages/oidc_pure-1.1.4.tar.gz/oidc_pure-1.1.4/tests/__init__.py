"""Tests for OIDC library."""
