# streamlit_flexnav/tools/debug_runtime.py
# 2026-02-22 16:25 CET (FlexNav 2.0 aligned)

from __future__ import annotations

import typer
import json
import structlog
from pathlib import Path

from streamlit_flexnav.core.loaders.config_loader import find_config, load_config, to_runtime_settings
from streamlit_flexnav.core.loaders.load_all import load_all

debug_app = typer.Typer(help="Debug tools")
log = structlog.get_logger().bind(component="debug_runtime")


@debug_app.callback(invoke_without_command=True)
def debug_app_root(ctx: typer.Context):
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit()

@debug_app.command("runtime")
def debug_runtime(full: bool = False):
    """
    Load the full FlexNav runtime and print a JSON dump of the model.

    Use --full to dump the entire RuntimeSettings object.
    Without --full, prints a summarized diagnostic view.
    """

    typer.echo("\n🔎 FLEXNAV RUNTIME DEBUGGER\n")

    # ---------------------------------------------------------
    # 1. Load config
    # ---------------------------------------------------------
    try:
        cfg_path = find_config()
        cfg = load_config(cfg_path)
        typer.echo(f"✔ Loaded config: {cfg_path}")
    except Exception as e:
        typer.echo(f"❌ Failed to load config: {e}")
        raise typer.Exit(code=1)

    # ---------------------------------------------------------
    # 2. Build runtime + run pipeline
    # ---------------------------------------------------------
    try:
        app_root = Path(cfg_path).parent.parent
        runtime = to_runtime_settings(cfg, app_root)
        runtime = load_all(runtime)
        typer.echo("✔ RuntimeSettings created and pipeline completed")
    except Exception as e:
        typer.echo(f"❌ Failed to initialize runtime: {e}")
        raise typer.Exit(code=1)

    # ---------------------------------------------------------
    # 3. Summary view
    # ---------------------------------------------------------
    if not full:
        typer.echo("\n📁 PATHS")
        typer.echo(f"  app_root:        {runtime.app_root}")
        typer.echo(f"  menupages_root:  {runtime.menupages_root}")
        typer.echo(f"  internal_root:   {runtime.internal_root}")

        typer.echo("\n📚 COUNTS")
        typer.echo(f"  menu groups:     {len(runtime.menu_metadata)}")
        typer.echo(f"  pages:           {len(runtime.pages)}")

        typer.echo("\n🌳 MENU TREE")
        if not runtime.menu_tree:
            typer.echo("  (empty)")
        else:
            for group_label, pages in runtime.menu_tree.items():
                typer.echo(f"  - {group_label}: {len(pages)} pages")

        typer.echo("\nℹ️  Use --full to dump the entire RuntimeSettings object.\n")
        return

    # ---------------------------------------------------------
    # 4. Full JSON dump
    # ---------------------------------------------------------
    typer.echo("\n🧩 FULL RUNTIME JSON DUMP\n")
    typer.echo(json.dumps(runtime.model_dump(mode="json"), indent=2))
