# streamlit_flexnav/tools/setup_app.py
# 2026-02-22 16:55 CET (FlexNav 2.0 aligned)

from __future__ import annotations

import typer
from pathlib import Path
import shutil
import structlog

log = structlog.get_logger().bind(component="setup_app")

setup_app = typer.Typer(help="Create a new FlexNav 2.0 application structure")



# ---------------------------------------------------------
# Helpers
# ---------------------------------------------------------

def _normalize_folder_name(name: str) -> str:
    return name.lower().replace(" ", "_")


def _write(path: Path, content: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


# ---------------------------------------------------------
# FlexNav 2.0 CONFIG TEMPLATE
# ---------------------------------------------------------

CONFIG_TEMPLATE = """flexnav:
  menupages: "menupages"
  internal: "internal"
  menulocation: "sidebar"
  authentication: "none"
  env: "dev"

logging:
  to_file: false
  level: "INFO"
"""


# ---------------------------------------------------------
# ROOT PAGE TEMPLATE (FlexNav 2.0)
# ---------------------------------------------------------

ROOT_PAGE = """import streamlit as st
from streamlit_flexnav.core.models.pagestruct import PageStruct

def page():
    return PageStruct(
        label="{label}",
        order={order},
        icon="{icon}",
        path=__file__,
        group=None,
        required_roles=[],
    )

def render():
    st.title("{label}")
    st.write("This is the {label} page.")

if __name__ == "__main__":
    render()
"""


# ---------------------------------------------------------
# GROUP MENU TEMPLATE
# ---------------------------------------------------------

GROUP_MENU = """from streamlit_flexnav.core.models.menustruct import MenuStruct

def menu() -> MenuStruct:
    return MenuStruct(
        label="{label}",
        icon="{icon}",
        order={order},
    )
"""


# ---------------------------------------------------------
# PAGE TEMPLATE (FlexNav 2.0)
# ---------------------------------------------------------

PAGE_TEMPLATE = """import streamlit as st
from streamlit_flexnav.core.models.pagestruct import PageStruct

def page():
    return PageStruct(
        label="{label}",
        order={order},
        icon="{icon}",
        path=__file__,
        group="{group}",
        required_roles=[],
    )

def render():
    st.title("{label}")
    st.write("You are on: {group} → {label}")

if __name__ == "__main__":
    render()
"""


# ---------------------------------------------------------
# MAIN.PY (FlexNav 2.0)
# ---------------------------------------------------------

MAIN_PY = """from __future__ import annotations

from pathlib import Path
import streamlit as st

from streamlit_flexnav.core.loaders.config_loader import load_config, to_runtime_settings
from streamlit_flexnav.core.loaders.load_all import load_all
from streamlit_flexnav.core.menurenderer import render_navigation


def main() -> None:
    base = Path(__file__).parent
    cfg = load_config(base / "configs" / "flexnav_config.yaml")

    runtime = to_runtime_settings(cfg, base)
    runtime = load_all(runtime)

    render_navigation(runtime)


if __name__ == "__main__":
    main()
"""


# ---------------------------------------------------------
# AUTH SCAFFOLD (FlexNav 2.0)
# ---------------------------------------------------------

AUTH_LOGIN = """import streamlit as st
from streamlit_flexnav.core.models.pagestruct import PageStruct

def page():
    return PageStruct(
        label="Login",
        icon="🔐",
        order=0,
        path=__file__,
        group="auth",
        required_roles=[],
    )

def render():
    st.title("Login")
    st.write("This is a placeholder login page.")

if __name__ == "__main__":
    render()
"""

AUTH_LOGOUT = """import streamlit as st
from streamlit_flexnav.core.models.pagestruct import PageStruct

def page():
    return PageStruct(
        label="Logout",
        icon="🚪",
        order=1,
        path=__file__,
        group="auth",
        required_roles=[],
    )

def render():
    st.title("Logout")
    st.write("This is a placeholder logout page.")

if __name__ == "__main__":
    render()
"""


# ---------------------------------------------------------
# DEMO GENERATOR (FlexNav 2.0)
# ---------------------------------------------------------

GROUPS = ["group1", "group2"]
PAGES = ["page1", "page2", "page3"]

def _generate_demo(folder: Path):
    print("✨ Generating FlexNav 2.0 demo...")

    if folder.exists():
        shutil.rmtree(folder)

    pages_root = folder / "menupages"
    config_root = folder / "configs"

    # Config
    _write(config_root / "flexnav_config.yaml", CONFIG_TEMPLATE)

    # Root pages
    _write(pages_root / "home.py", ROOT_PAGE.format(label="Home", order=1, icon="🏠"))
    _write(pages_root / "settings.py", ROOT_PAGE.format(label="Settings", order=2, icon="⚙️"))

    # Groups + pages
    order_counter = 10
    for group in GROUPS:
        _write(
            pages_root / group / "__menu__.py",
            GROUP_MENU.format(label=group.capitalize(), icon="📁", order=order_counter),
        )
        order_counter += 10

        for p in PAGES:
            order_counter += 1
            _write(
                pages_root / group / f"{p}.py",
                PAGE_TEMPLATE.format(
                    label=p.capitalize(),
                    order=order_counter,
                    icon="📄",
                    group=group,
                ),
            )

    # main.py
    _write(folder / "main.py", MAIN_PY)

    print("🎉 Demo application created at:", folder)


# ---------------------------------------------------------
# AUTH GENERATOR
# ---------------------------------------------------------

def _generate_auth(folder: Path):
    auth_dir = folder / "internal" / "auth"
    _write(auth_dir / "login.py", AUTH_LOGIN)
    _write(auth_dir / "logout.py", AUTH_LOGOUT)
    print("🔐 Auth pages added")


# ---------------------------------------------------------
# MAIN SETUP COMMAND
# ---------------------------------------------------------

@setup_app.callback(invoke_without_command=True)
def setup_app_root(ctx: typer.Context):
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit()


@setup_app.command("new")
def setup_app_cmd(
    app_name: str = typer.Option("FlexNav App", "--app-name", "-a"),
    folder_name: str | None = typer.Option(None, "--folder-name", "-f"),
    with_demo: bool = typer.Option(False, "--with-demo", help="Include full demo app"),
    with_auth: bool = typer.Option(False, "--with-auth", help="Include login/logout pages"),
):
    """
    Create a new FlexNav 2.0 application folder with optional demo and auth scaffolding.
    """
    folder = Path(folder_name or _normalize_folder_name(app_name))

    (folder / "menupages").mkdir(parents=True, exist_ok=True)
    (folder / "internal").mkdir(exist_ok=True)
    (folder / "configs").mkdir(exist_ok=True)

    if with_demo:
        _generate_demo(folder)

    if with_auth:
        _generate_auth(folder)

    print(f"📦 Created FlexNav app at: {folder.resolve()}")
    raise typer.Exit(code=0)
