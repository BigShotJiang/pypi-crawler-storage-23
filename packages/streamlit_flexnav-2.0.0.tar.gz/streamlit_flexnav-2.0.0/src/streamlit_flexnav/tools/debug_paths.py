# streamlit_flexnav/tools/debug_paths.py
# 2026-02-22 16:20 CET (FlexNav 2.0 aligned)

from __future__ import annotations

import typer
from pathlib import Path
import structlog

from streamlit_flexnav.core.loaders.config_loader import find_config, load_config, to_runtime_settings
from streamlit_flexnav.core.loaders.load_all import load_all

log = structlog.get_logger().bind(component="debug_paths")

debug_app = typer.Typer(help="Debug filesystem paths")


def run_debug_paths() -> int:
    typer.echo("🔎 FlexNav Path Debugger\n")

    # 1) Show working directory
    typer.echo(f"Current working directory: {Path.cwd()}")

    # 2) Load config + runtime
    try:
        cfg_path = find_config()
        cfg = load_config(cfg_path)

        app_root = Path(cfg_path).parent.parent
        runtime = to_runtime_settings(cfg, app_root)

        # Run full pipeline to resolve menu/pages
        runtime = load_all(runtime)

    except Exception as e:
        typer.echo(f"❌ Failed to initialize runtime: {e}")
        return 1

    # 3) Show resolved paths
    typer.echo(f"Config file:          {cfg_path.resolve()}")
    typer.echo(f"App root:             {runtime.app_root}")
    typer.echo(f"Menupages root:       {runtime.menupages_root}")
    typer.echo(f"Internal pages root:  {runtime.internal_root}")

    typer.echo("\n✔ Path debug complete")
    return 0


@debug_app.callback(invoke_without_command=True)
def debug_app_root(ctx: typer.Context):
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit()


@debug_app.command("run")
def debug_paths_cmd():
    code = run_debug_paths()
    raise typer.Exit(code=code)
