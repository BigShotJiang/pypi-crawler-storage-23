# streamlit_flexnav/tools/menu_visualizer.py
# 2026-02-22 16:35 CET (FlexNav 2.0 aligned)

from __future__ import annotations

import time
from pathlib import Path

import typer
import structlog

from streamlit_flexnav.core.loaders.config_loader import (
    find_config,
    load_config,
    to_runtime_settings,
)
from streamlit_flexnav.core.loaders.load_all import load_all

log = structlog.get_logger().bind(component="menu_visualizer")

menu_visualizer_app = typer.Typer(
    help="Visualize and inspect FlexNav menu structure"
)


# ---------------------------------------------------------
# Pretty-print helpers
# ---------------------------------------------------------
def _print_group_header(label: str, icon: str | None, order: int | None):
    icon = icon or "•"
    order_txt = order if order is not None else "-"
    typer.echo(f"{icon}  {label}  (order={order_txt})")


def _print_page(indent: str, label: str, key: str | None, icon: str | None, order: int | None):
    icon = icon or "•"
    key_txt = key or "<none>"
    order_txt = order if order is not None else "-"
    typer.echo(f"{indent}{icon}  {label}  [key={key_txt}, order={order_txt}]")


# ---------------------------------------------------------
# App root
# ---------------------------------------------------------
@menu_visualizer_app.callback(invoke_without_command=True)
def menu_visualizer_app_root(ctx: typer.Context):
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit()


# ---------------------------------------------------------
# Command 1: Visualize menu tree
# ---------------------------------------------------------
@menu_visualizer_app.command("visualize")
def visualize_menu():
    """
    Pretty-print the full FlexNav menu structure.

    Menus are metadata only; pages are derived from PageStruct.group.
    """

    cfg_path = find_config()
    cfg = load_config(cfg_path)
    app_root = Path(cfg_path).parent.parent

    runtime = to_runtime_settings(cfg, app_root)
    runtime = load_all(runtime)

    typer.echo("\n🌳 FLEXNAV MENU VISUALIZER\n")

    if not runtime.menu_metadata:
        typer.echo("❌ No menu metadata loaded.")
        return

    # Deterministic menu ordering
    menus = sorted(
        runtime.menu_metadata.items(),
        key=lambda kv: (
            kv[1].order if kv[1].order is not None else 10**9,
            kv[0],
        ),
    )

    for group_key, meta in menus:
        _print_group_header(meta.label, meta.icon, meta.order)

        pages = [
            p for p in runtime.pages
            if p.group == group_key
        ]

        pages = sorted(
            pages,
            key=lambda p: (
                p.order if p.order is not None else 10**9,
                p.key if p.key is not None else "",
            ),
        )

        for p in pages:
            _print_page("   └─ ", p.label, p.key, p.icon, p.order)

        typer.echo("")

    typer.echo("✔ Visualization complete.\n")


# ---------------------------------------------------------
# Command 2: Deep menu inspection
# ---------------------------------------------------------
@menu_visualizer_app.command("inspect")
def inspect_menu():
    """
    Deep inspection of menu-related filesystem and loader behavior:
      - folder existence
      - discovered menupages
      - discovered internal pages
      - loader timings
      - derived menu summary
    """

    typer.echo("\n🔎 FLEXNAV MENU INSPECTOR\n")

    cfg_path = find_config()
    cfg = load_config(cfg_path)
    app_root = Path(cfg_path).parent.parent

    runtime = to_runtime_settings(cfg, app_root)

    # ---------------------------------------------------------
    # Folder existence
    # ---------------------------------------------------------
    typer.echo("📁 FOLDER CHECKS")

    for name, path in {
        "menupages_root": runtime.menupages_root,
        "internal_root": runtime.internal_root,
    }.items():
        if not path.exists():
            typer.echo(f"❌ Missing {name}: {path}")
        else:
            typer.echo(f"✔ {name}: {path}")

    # ---------------------------------------------------------
    # Discover pages on disk
    # ---------------------------------------------------------
    typer.echo("\n📄 DISCOVERED MENUPAGES FILES")
    for f in sorted(runtime.menupages_root.rglob("*.py")):
        typer.echo(f" - {f}")

    typer.echo("\n📄 DISCOVERED INTERNAL FILES")
    for f in sorted(runtime.internal_root.rglob("*.py")):
        typer.echo(f" - {f}")

    # ---------------------------------------------------------
    # Loader timings
    # ---------------------------------------------------------
    typer.echo("\n⏱ LOADER TIMINGS")

    t0 = time.perf_counter()
    runtime2 = load_all(runtime)
    total = time.perf_counter() - t0

    typer.echo(f"Full loader pipeline: {total:.4f}s")

    # ---------------------------------------------------------
    # Derived menu summary
    # ---------------------------------------------------------
    typer.echo("\n🌳 DERIVED MENU SUMMARY")

    if not runtime2.menu_metadata:
        typer.echo("❌ No menu metadata loaded.")
    else:
        for group_key, meta in runtime2.menu_metadata.items():
            count = sum(
                1 for p in runtime2.pages
                if p.group == group_key
            )
            typer.echo(f" - {group_key}: {count} pages")

    typer.echo("\n✔ Menu inspection complete.\n")
