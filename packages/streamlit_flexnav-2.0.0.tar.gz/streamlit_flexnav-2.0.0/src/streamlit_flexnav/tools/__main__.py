# python -m streamlit_flexnav.tools

# streamlit_flexnav/tools/__main__.py
# 2026-02-15 20:45 CET

from .cli import main

if __name__ == "__main__":
    main()
