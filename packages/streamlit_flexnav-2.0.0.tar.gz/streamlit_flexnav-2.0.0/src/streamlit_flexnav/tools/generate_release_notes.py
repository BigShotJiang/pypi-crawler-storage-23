#!/usr/bin/env python3
"""
Generate GitHub‑ready release notes from CHANGELOG.md and git history.

Usage:
    python tools/generate_release_notes.py v0.2.0
"""

import re
import sys
from pathlib import Path
import subprocess

def extract_changelog(version: str) -> str:
    changelog = Path("CHANGELOG.md").read_text()

    pattern = rf"## 

\[{re.escape(version)}\]

(.*?)(?=## 

\[|\Z)"
    match = re.search(pattern, changelog, re.S)

    if not match:
        return f"⚠️ No changelog entry found for {version}"

    return match.group(1).strip()

def extract_commits(tag: str) -> str:
    try:
        commits = subprocess.check_output(
            ["git", "log", f"{tag}..HEAD", "--pretty=format:- %s"],
            text=True
        )
        return commits.strip() or "No commits found."
    except Exception:
        return "⚠️ Unable to read git history."

def main():
    if len(sys.argv) != 2:
        print("Usage: generate_release_notes.py <version>")
        sys.exit(1)

    version = sys.argv[1]

    print(f"# Release {version}\n")

    print("## Changelog\n")
    print(extract_changelog(version))
    print("\n---\n")

    print("## Commits Since Last Tag\n")
    print(extract_commits(version))

if __name__ == "__main__":
    main()
