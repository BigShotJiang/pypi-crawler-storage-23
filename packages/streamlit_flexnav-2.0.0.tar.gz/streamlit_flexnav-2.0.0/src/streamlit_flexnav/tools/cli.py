# streamlit_flexnav/tools/cli.py
# 2026-02-22 17:05 CET (FlexNav 2.0 aligned)

from __future__ import annotations

import typer
import structlog
from pathlib import Path
import streamlit as st
from streamlit_flexnav.core.loaders.config_loader import load_config

# Import all subcommand apps (FlexNav 2.0 aligned)
from streamlit_flexnav.tools.config import config_app
from streamlit_flexnav.tools.debug_paths import debug_app as debug_paths_app
from streamlit_flexnav.tools.debug_runtime import debug_app as debug_runtime_app
from streamlit_flexnav.tools.debug_inspect import debug_inspect_app
from streamlit_flexnav.tools.menu import menu_app
from streamlit_flexnav.tools.menu_visualizer import menu_visualizer_app
from streamlit_flexnav.tools.pages import page_app
from streamlit_flexnav.tools.linter import linter_app
from streamlit_flexnav.tools.doctor import doctor_app
from streamlit_flexnav.tools.setup_app import setup_app
#from streamlit_flexnav.tools.rbac import rbac_app

log = structlog.get_logger().bind(component="cli")

app = typer.Typer(
    help="FlexNav 2.0 Command Line Interface",
    no_args_is_help=True,
)


# ---------------------------------------------------------
# Register subcommands
# ---------------------------------------------------------

app.add_typer(config_app, name="config", invoke_without_command=True)
app.add_typer(menu_app, name="menu", invoke_without_command=True)
app.add_typer(menu_visualizer_app, name="menuviz", invoke_without_command=True)
app.add_typer(page_app, name="pages", invoke_without_command=True)
app.add_typer(linter_app, name="lint", invoke_without_command=True)
app.add_typer(doctor_app, name="doctor", invoke_without_command=True)
app.add_typer(setup_app, name="setup", invoke_without_command=True)
# app.add_typer(rbac_app, name="rbac", invoke_without_command=True)

# Debug suite
debug_group = typer.Typer(help="Debugging tools", invoke_without_command=True)
debug_group.add_typer(debug_paths_app, name="paths", invoke_without_command=True)
debug_group.add_typer(debug_runtime_app, name="runtime", invoke_without_command=True)
debug_group.add_typer(debug_inspect_app, name="inspect", invoke_without_command=True)
app.add_typer(debug_group, name="debug", invoke_without_command=True)


# ---------------------------------------------------------
# Root command
# ---------------------------------------------------------

@app.callback()
def main():
    """
    FlexNav 2.0 CLI entrypoint.
    """
    app_root = Path.cwd()   
    config_path = app_root / "configs" / "flexnav_config.yaml"
    cfg = load_config(config_path)
    st.session_state["_flexnav_runtime_cli"] = cfg
    log.info("flexnav_cli_start")
