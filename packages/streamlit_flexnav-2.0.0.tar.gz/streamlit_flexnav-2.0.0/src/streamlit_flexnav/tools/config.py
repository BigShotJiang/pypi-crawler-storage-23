# streamlit_flexnav/tools/config.py
# 2026-03-01 — FlexNav 2.0 aligned

from __future__ import annotations

import typer
import yaml
import structlog
from pathlib import Path

from streamlit_flexnav.core.loaders.config_loader import (
    find_config,
    load_config,
    to_runtime_settings,
)
from streamlit_flexnav.core.loaders.load_all import load_all

config_app = typer.Typer(help="FlexNav configuration tools")
log = structlog.get_logger().bind(component="config")


@config_app.callback(invoke_without_command=True)
def config_root(ctx: typer.Context):
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit()


@config_app.command("show")
def config_show():
    """
    Show:
      1. Raw YAML config
      2. Parsed YAML dict
      3. Resolved RuntimeSettings paths
      4. Full pipeline initialization check
    """

    typer.echo("\n=== FLEXNAV CONFIGURATION ===\n")

    # ---------------------------------------------------------
    # 1. Raw YAML
    # ---------------------------------------------------------
    typer.echo("📄 Raw YAML:")
    try:
        cfg_path = find_config()
        raw = cfg_path.read_text(encoding="utf-8")
        typer.echo(raw)
    except Exception as e:
        typer.echo(f"❌ Could not read YAML: {e}")
        raise typer.Exit(code=1)

    # ---------------------------------------------------------
    # 2. Parsed YAML dict
    # ---------------------------------------------------------
    typer.echo("\n🧩 Parsed YAML (dict):")
    try:
        cfg = load_config(cfg_path)
        typer.echo(yaml.safe_dump(cfg, sort_keys=False))
    except Exception as e:
        typer.echo(f"❌ Config parsing failed: {e}")
        raise typer.Exit(code=1)

    # ---------------------------------------------------------
    # 3. Resolved RuntimeSettings (paths only)
    # ---------------------------------------------------------
    typer.echo("\n📁 Resolved Runtime Settings (paths):")
    try:
        app_root = Path(cfg_path).parent.parent  # configs/ → project root
        runtime = to_runtime_settings(cfg, app_root)

        typer.echo(f"app_root:        {runtime.app_root}")
        typer.echo(f"menupages_root:  {runtime.menupages_root}")
        typer.echo(f"internal_root:   {runtime.internal_root}")
        typer.echo(f"profile:         {runtime.profile}")
        typer.echo(f"roles:           {runtime.current_user_roles}")

    except Exception as e:
        typer.echo(f"❌ Runtime resolution failed: {e}")
        raise typer.Exit(code=1)

    # ---------------------------------------------------------
    # 4. Full pipeline initialization
    # ---------------------------------------------------------
    typer.echo("\n⚙️  Runtime Initialization Check:")
    try:
        _ = load_all(runtime)
        typer.echo("✔ Runtime loads successfully")
    except Exception as e:
        typer.echo(f"❌ Runtime failed to initialize: {e}")

    typer.echo("\n=== END CONFIG ===\n")
