# streamlit_flexnav/tools/pages.py
# 2026-02-22 16:45 CET (FlexNav 2.0 aligned)

from __future__ import annotations

import json
import re
from pathlib import Path

import typer

from streamlit_flexnav.core.import_module_safely import import_module_safely
from streamlit_flexnav.core.loaders.config_loader import (
    find_config,
    load_config,
    to_runtime_settings,
)
from streamlit_flexnav.core.loaders.load_all import load_all

page_app = typer.Typer(help="Page inspection tools")


# ---------------------------------------------------------
# Runtime loader (FlexNav 2.0 pipeline)
# ---------------------------------------------------------
def _load_runtime():
    cfg_path = find_config()
    cfg = load_config(cfg_path)
    app_root = Path(cfg_path).parent.parent

    runtime = to_runtime_settings(cfg, app_root)
    runtime = load_all(runtime)
    return runtime


# ---------------------------------------------------------
# pages list
# ---------------------------------------------------------
@page_app.callback(invoke_without_command=True)
def page_app_root(ctx: typer.Context):
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit()


@page_app.command("list")
def page_list():
    runtime = _load_runtime()

    typer.echo("\n=== FLEXNAV PAGES ===")
    for p in runtime.pages:
        typer.echo(
            f"{p.icon or '•'}  {p.key:<20}  {p.label:<30}  "
            f"group={p.group}  order={p.order}"
        )
    typer.echo("=== END ===\n")


# ---------------------------------------------------------
# pages export
# ---------------------------------------------------------
@page_app.command("export")
def page_export():
    runtime = _load_runtime()

    pages = [
        {
            "key": p.key,
            "label": p.label,
            "icon": p.icon,
            "group": p.group,
            "order": p.order,
            "required_roles": p.required_roles,
            "path": str(p.path),
        }
        for p in runtime.pages
    ]

    typer.echo(json.dumps(pages, indent=2, ensure_ascii=False))


# ---------------------------------------------------------
# pages roles (RBAC)
# ---------------------------------------------------------
@page_app.command("roles")
def page_roles():
    runtime = _load_runtime()

    typer.echo("\n🔐 PAGE RBAC REQUIREMENTS\n")

    for p in runtime.pages:
        roles = ", ".join(p.required_roles) if p.required_roles else "<public>"
        typer.echo(f"{p.key:<20}  {p.label:<30}  roles={roles}")

    typer.echo("\n✔ RBAC listing complete.\n")


# ---------------------------------------------------------
# pages groups
# ---------------------------------------------------------
@page_app.command("groups")
def page_groups():
    runtime = _load_runtime()

    typer.echo("\n=== FLEXNAV PAGES BY GROUP ===")

    groups: dict[str | None, list] = {}
    for p in runtime.pages:
        groups.setdefault(p.group, []).append(p)

    for group, pages in groups.items():
        typer.echo(f"\n📁 {group or '<root>'}")
        for p in pages:
            typer.echo(f"   └─ {p.label}  (key={p.key}, order={p.order})")

    typer.echo("\n=== END ===\n")


# ---------------------------------------------------------
# pages conflicts
# ---------------------------------------------------------
@page_app.command("conflicts")
def page_conflicts():
    """
    Detect page-level conflicts:
      - duplicate keys
      - duplicate orders within a group (ignore order=None)
      - missing labels
      - invalid keys
      - invalid required_roles
      - missing page() function
      - orphaned menupages pages
      - invalid group references
      - internal vs menupages collisions
      - duplicate filenames
    """
    runtime = _load_runtime()

    typer.echo("\n⚠️  FLEXNAV PAGE CONFLICT CHECK\n")

    failures = 0

    valid_groups = set(runtime.menu_metadata.keys())

    # ---------------------------------------------------------
    # 1. Duplicate keys
    # ---------------------------------------------------------
    typer.echo("🔍 Checking duplicate keys...")
    seen_keys: dict[str, object] = {}
    for p in runtime.pages:
        if p.key is None:
            continue
        if p.key in seen_keys:
            typer.echo(f"❌ Duplicate key '{p.key}' in:")
            typer.echo(f"   - {seen_keys[p.key].path}")
            typer.echo(f"   - {p.path}")
            failures += 1
        else:
            seen_keys[p.key] = p

    # ---------------------------------------------------------
    # 2. Duplicate orders within a group
    # ---------------------------------------------------------
    typer.echo("\n🔍 Checking duplicate orders within groups...")
    groups: dict[str | None, list] = {}
    for p in runtime.pages:
        groups.setdefault(p.group, []).append(p)

    for group, pages in groups.items():
        seen_orders: dict[int, object] = {}
        for p in pages:
            if p.order is None:
                continue
            if p.order in seen_orders:
                typer.echo(f"❌ Duplicate order {p.order} in group '{group}':")
                typer.echo(f"   - {seen_orders[p.order].path}")
                typer.echo(f"   - {p.path}")
                failures += 1
            else:
                seen_orders[p.order] = p

    # ---------------------------------------------------------
    # 3. Missing labels
    # ---------------------------------------------------------
    typer.echo("\n🔍 Checking missing labels...")
    for p in runtime.pages:
        if not p.label:
            typer.echo(f"❌ Missing label in {p.path}")
            failures += 1

    # ---------------------------------------------------------
    # 4. Invalid keys
    # ---------------------------------------------------------
    typer.echo("\n🔍 Checking invalid keys...")
    for p in runtime.pages:
        if p.key is None:
            continue
        if not re.match(r"^[a-z0-9_. ]+$", p.key):
            typer.echo(f"❌ Invalid key '{p.key}' in {p.path}")
            failures += 1

    # ---------------------------------------------------------
    # 5. Invalid required_roles
    # ---------------------------------------------------------
    typer.echo("\n🔍 Checking required_roles...")
    for p in runtime.pages:
        if p.required_roles is None:
            continue
        if not isinstance(p.required_roles, list):
            typer.echo(f"❌ required_roles must be a list in {p.path}")
            failures += 1

    # ---------------------------------------------------------
    # 6. Missing page() function
    # ---------------------------------------------------------
    typer.echo("\n🔍 Checking page() functions...")
    for p in runtime.pages:
        try:
            module = import_module_safely(p.file)
        except Exception:
            typer.echo(f"❌ Could not import module for {p.path}")
            failures += 1
            continue

        page_fn = getattr(module, "page", None) or getattr(module, "render", None)
        if not callable(page_fn):
            typer.echo(f"❌ Missing or non-callable page() in {p.path}")
            failures += 1

    # ---------------------------------------------------------
    # 7. Orphaned pages (menupages only)
    # ---------------------------------------------------------
    typer.echo("\n🔍 Checking orphaned pages (menupages only)...")
    grouped_keys = {
        p.key
        for p in runtime.pages
        if p.key is not None and p.group in valid_groups
    }

    for p in runtime.pages:
        if p.key is None:
            continue
        try:
            in_menupages = p.path.is_relative_to(runtime.menupages_root)
        except Exception:
            in_menupages = False

        if in_menupages and p.key not in grouped_keys:
            typer.echo(f"❌ Orphaned menupages page: {p.label} ({p.key})")
            failures += 1

    # ---------------------------------------------------------
    # 8. Invalid group references
    # ---------------------------------------------------------
    typer.echo("\n🔍 Checking invalid group references...")
    for p in runtime.pages:
        if p.group is None:
            continue
        if p.group not in valid_groups:
            typer.echo(f"❌ Page '{p.label}' references unknown group '{p.group}'")
            failures += 1

    # ---------------------------------------------------------
    # 9. Internal vs menupages collisions
    # ---------------------------------------------------------
    typer.echo("\n🔍 Checking internal vs menupages collisions...")
    internal_keys: set[str] = set()
    menupages_keys: set[str] = set()

    for p in runtime.pages:
        if p.key is None:
            continue
        try:
            if p.path.is_relative_to(runtime.internal_root):
                internal_keys.add(p.key)
        except Exception:
            pass
        try:
            if p.path.is_relative_to(runtime.menupages_root):
                menupages_keys.add(p.key)
        except Exception:
            pass

    for key in sorted(internal_keys & menupages_keys):
        typer.echo(f"❌ Page key '{key}' defined in BOTH internal and menupages")
        failures += 1

    # ---------------------------------------------------------
    # 10. Duplicate filenames
    # ---------------------------------------------------------
    typer.echo("\n🔍 Checking duplicate filenames...")
    seen_filenames: dict[str, object] = {}
    for p in runtime.pages:
        filename = p.file.name
        if filename in seen_filenames:
            typer.echo(f"❌ Duplicate filename '{filename}' detected:")
            typer.echo(f"   - {seen_filenames[filename].path}")
            typer.echo(f"   - {p.path}")
            failures += 1
        else:
            seen_filenames[filename] = p

    # ---------------------------------------------------------
    # Final result
    # ---------------------------------------------------------
    if failures:
        typer.echo(f"\n❌ Page conflict check failed with {failures} issues.\n")
        raise typer.Exit(code=1)

    typer.echo("\n✔ No page conflicts detected.\n")
