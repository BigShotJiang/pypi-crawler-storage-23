# streamlit_flexnav/tools/debug_inspect.py
# 2026-02-22 16:15 CET (FlexNav 2.0 aligned)

from __future__ import annotations

import typer
import time
from pathlib import Path
import structlog

from streamlit_flexnav.core.loaders.config_loader import find_config, load_config, to_runtime_settings
from streamlit_flexnav.core.loaders.load_all import load_all

debug_inspect_app = typer.Typer(help="Deep FlexNav inspection tools")
log = structlog.get_logger().bind(component="debug_inspect")


@debug_inspect_app.callback(invoke_without_command=True)
def debug_inspect_root(ctx: typer.Context):
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit()


@debug_inspect_app.command("inspect")
def inspect():
    """
    Deep inspection of FlexNav environment:
      - config loading
      - runtime resolution
      - folder checks
      - discovered pages (via loader)
      - import errors
      - RBAC summary
      - menu_tree summary
      - loader timings
    """

    typer.echo("\n🔎 FLEXNAV DEEP INSPECTOR\n")

    # ---------------------------------------------------------
    # 1. Load config + runtime
    # ---------------------------------------------------------
    typer.echo("📄 Loading configuration...")

    try:
        cfg_path = find_config()
        cfg = load_config(cfg_path)
        app_root = Path(cfg_path).parent.parent
        runtime = to_runtime_settings(cfg, app_root)

        typer.echo(f"✔ Loaded config from: {cfg_path}")
        typer.echo(f"✔ RuntimeSettings created")
    except Exception as e:
        typer.echo(f"❌ Failed to load config/runtime: {e}")
        raise typer.Exit(code=1)

    # ---------------------------------------------------------
    # 2. Folder existence
    # ---------------------------------------------------------
    typer.echo("\n📁 FOLDER CHECKS")

    folders = {
        "app_root": runtime.app_root,
        "menupages_root": runtime.menupages_root,
        "internal_root": runtime.internal_root,
    }

    for name, path in folders.items():
        if path.exists():
            typer.echo(f"✔ {name}: {path}")
        else:
            typer.echo(f"❌ Missing {name}: {path}")

    # ---------------------------------------------------------
    # 3. Discover files
    # ---------------------------------------------------------
    typer.echo("\n📄 DISCOVERED MENUPAGES")
    menupage_files = list(runtime.menupages_root.rglob("*.py"))
    for f in menupage_files:
        typer.echo(f" - {f}")

    typer.echo("\n📄 DISCOVERED INTERNAL PAGES")
    internal_files = list(runtime.internal_root.rglob("*.py"))
    for f in internal_files:
        typer.echo(f" - {f}")

    # ---------------------------------------------------------
    # 4. Loader timings + full pipeline
    # ---------------------------------------------------------
    typer.echo("\n⏱ LOADER TIMINGS")

    t0 = time.perf_counter()
    runtime2 = load_all(runtime)
    t_full = time.perf_counter() - t0

    typer.echo(f"✔ Full pipeline: {t_full:.4f}s")

    # ---------------------------------------------------------
    # 5. RBAC summary
    # ---------------------------------------------------------
    typer.echo("\n🔐 RBAC SUMMARY")

    typer.echo(f"auth_enabled: {runtime2.auth_enabled}")
    typer.echo(f"current_user_roles: {runtime2.current_user_roles}")

    # ---------------------------------------------------------
    # 6. Menu tree summary
    # ---------------------------------------------------------
    typer.echo("\n🌳 MENU TREE")

    if not runtime2.menu_tree:
        typer.echo("❌ menu_tree is empty")
    else:
        for group, pages in runtime2.menu_tree.items():
            typer.echo(f"\n📁 {group}")
            for p in pages:
                typer.echo(f"   - {p.title} ({p.path})")

    typer.echo("\n✔ Inspection complete.\n")
