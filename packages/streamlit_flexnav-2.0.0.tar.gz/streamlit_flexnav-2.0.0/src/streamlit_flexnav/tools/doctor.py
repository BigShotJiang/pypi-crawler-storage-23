# streamlit_flexnav/tools/doctor.py
# 2026-02-22 17:00 CET (FlexNav 2.0 aligned)

from __future__ import annotations

import sys
from pathlib import Path

import typer
import streamlit

from streamlit_flexnav.core.loaders.config_loader import (
    find_config,
    load_config,
    to_runtime_settings,
)
from streamlit_flexnav.core.loaders.load_all import load_all

doctor_app = typer.Typer(help="FlexNav 2.0 health checks")


# ---------------------------------------------------------
# Shared runtime loader
# ---------------------------------------------------------
def _load_runtime():
    cfg_path = find_config()
    cfg = load_config(cfg_path)
    app_root = cfg_path.parent.parent

    runtime = to_runtime_settings(cfg, app_root)
    runtime = load_all(runtime)
    return runtime


# ---------------------------------------------------------
# Individual Checks
# ---------------------------------------------------------
def _check_python():
    version = sys.version.split()[0]
    if sys.version_info < (3, 10):
        return False, f"Python {version} — requires 3.10+"
    return True, f"Python {version}"


def _check_streamlit():
    return True, f"Streamlit {streamlit.__version__}"


def _check_config_file():
    try:
        cfg_path = find_config()
        return True, f"Found config file: {cfg_path}"
    except Exception as e:
        return False, f"Config not found: {e}"


def _check_config_valid():
    try:
        cfg_path = find_config()
        _ = load_config(cfg_path)
        return True, "Config loaded successfully"
    except Exception as e:
        return False, f"Config error: {e}"


def _check_folders():
    try:
        runtime = _load_runtime()

        msgs = []
        ok = True

        if not runtime.menupages_root.exists():
            ok = False
            msgs.append(f"Missing menupages folder: {runtime.menupages_root}")
        else:
            msgs.append(f"Menupages folder OK: {runtime.menupages_root}")

        if not runtime.internal_root.exists():
            ok = False
            msgs.append(f"Missing internal folder: {runtime.internal_root}")
        else:
            msgs.append(f"Internal folder OK: {runtime.internal_root}")

        return ok, " | ".join(msgs)

    except Exception as e:
        return False, f"Folder check failed: {e}"


def _check_runtime_initialization():
    try:
        runtime = _load_runtime()
        return True, f"Runtime initialized ({len(runtime.pages)} pages loaded)"
    except Exception as e:
        return False, f"Runtime initialization failed: {e}"


def _check_menu_metadata():
    try:
        runtime = _load_runtime()
        if not runtime.menu_metadata:
            return False, "No menu metadata loaded"
        return True, f"{len(runtime.menu_metadata)} menu groups defined"
    except Exception as e:
        return False, f"Menu metadata check failed: {e}"


def _check_page_discovery():
    try:
        runtime = _load_runtime()
        if not runtime.pages:
            return False, "No pages discovered"
        return True, f"{len(runtime.pages)} pages discovered"
    except Exception as e:
        return False, f"Page discovery failed: {e}"


def _check_page_group_links():
    try:
        runtime = _load_runtime()
        valid_groups = set(runtime.menu_metadata.keys())

        invalid = [
            p for p in runtime.pages
            if p.group is not None and p.group not in valid_groups
        ]

        if invalid:
            labels = ", ".join(p.label for p in invalid)
            return False, f"Pages reference unknown groups: {labels}"

        return True, "All page → group references valid"

    except Exception as e:
        return False, f"Page/group linkage check failed: {e}"


def _check_internal_vs_menupages_collisions():
    try:
        runtime = _load_runtime()

        internal_keys = set()
        menupages_keys = set()

        for p in runtime.pages:
            if p.key is None:
                continue
            try:
                if p.path.is_relative_to(runtime.internal_root):
                    internal_keys.add(p.key)
            except Exception:
                pass
            try:
                if p.path.is_relative_to(runtime.menupages_root):
                    menupages_keys.add(p.key)
            except Exception:
                pass

        collisions = internal_keys & menupages_keys
        if collisions:
            return False, f"Key collisions between internal and menupages: {sorted(collisions)}"

        return True, "No internal/menupages key collisions"

    except Exception as e:
        return False, f"Collision check failed: {e}"


# ---------------------------------------------------------
# List of checks
# ---------------------------------------------------------
CHECKS = [
    ("Python version", _check_python),
    ("Streamlit version", _check_streamlit),
    ("Config file exists", _check_config_file),
    ("Config is valid", _check_config_valid),
    ("Folder structure", _check_folders),
    ("Runtime initialization", _check_runtime_initialization),
    ("Menu metadata", _check_menu_metadata),
    ("Page discovery", _check_page_discovery),
    ("Page → group linkage", _check_page_group_links),
    ("Internal vs menupages collisions", _check_internal_vs_menupages_collisions),
]


# ---------------------------------------------------------
# Doctor Runner
# ---------------------------------------------------------
def run_doctor() -> int:
    typer.echo("🩺 FlexNav 2.0 Doctor\n")

    failures = 0

    for name, fn in CHECKS:
        ok, msg = fn()
        if ok:
            typer.echo(f"✔ {name}: {msg}")
        else:
            typer.echo(f"❌ {name}: {msg}")
            failures += 1

    typer.echo("\nDoctor complete.")
    return 1 if failures else 0


@doctor_app.callback(invoke_without_command=True)
def doctor_app_root(ctx: typer.Context):
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit()


@doctor_app.command("run")
def doctor_cmd():
    raise typer.Exit(code=run_doctor())
