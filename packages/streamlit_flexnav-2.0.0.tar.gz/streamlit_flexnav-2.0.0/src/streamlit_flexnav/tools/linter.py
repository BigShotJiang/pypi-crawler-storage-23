# streamlit_flexnav/tools/linter.py
# 2026-02-22 16:30 CET (FlexNav 2.0 aligned)

from __future__ import annotations

import re
from pathlib import Path

import typer

from streamlit_flexnav.core.import_module_safely import import_module_safely
from streamlit_flexnav.core.loaders.config_loader import (
    find_config,
    load_config,
    to_runtime_settings,
)
from streamlit_flexnav.core.loaders.load_all import load_all

linter_app = typer.Typer(help="FlexNav linter")


# ---------------------------------------------------------
# Helpers
# ---------------------------------------------------------
def _validate_key(key: str) -> bool:
    return bool(re.match(r"^[a-z0-9_. ]+$", key))


# ---------------------------------------------------------
# App root
# ---------------------------------------------------------
@linter_app.callback(invoke_without_command=True)
def linter_app_root(ctx: typer.Context):
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit()


# ---------------------------------------------------------
# Linter command
# ---------------------------------------------------------
@linter_app.command("run")
def linter_cmd():
    """
    FlexNav 2.0 Linter (runtime-based):

      - validates PageStruct fields after loader pipeline
      - checks duplicate keys (ignores key=None)
      - checks missing labels
      - checks key format
      - checks order type (allows None)
      - checks icon type
      - checks required_roles format
      - checks presence of page()/render() function
      - checks folder structure
    """

    typer.echo("🔍 FlexNav Linter\n")

    # ---------------------------------------------------------
    # Load runtime using FlexNav 2.0 pipeline
    # ---------------------------------------------------------
    try:
        cfg_path = find_config()
        cfg = load_config(cfg_path)
        app_root = Path(cfg_path).parent.parent

        runtime = to_runtime_settings(cfg, app_root)
        runtime = load_all(runtime)

        typer.echo(f"✔ Loaded runtime from: {cfg_path}")

    except Exception as e:
        typer.echo(f"❌ Failed to load runtime: {e}")
        raise typer.Exit(code=1)

    failures = 0
    seen_keys: dict[str, Path] = {}

    # ---------------------------------------------------------
    # Folder structure checks
    # ---------------------------------------------------------
    typer.echo("\n📁 FOLDER CHECKS")

    for name, path in {
        "menupages_root": runtime.menupages_root,
        "internal_root": runtime.internal_root,
    }.items():
        if not path.exists():
            typer.echo(f"❌ Missing folder: {name} → {path}")
            failures += 1
        else:
            typer.echo(f"✔ {name}: {path}")

    # ---------------------------------------------------------
    # PageStruct validation (loader output)
    # ---------------------------------------------------------
    typer.echo("\n📄 PAGESTRUCT VALIDATION")

    for p in runtime.pages:
        file = p.file

        # Key validation
        if p.key is not None and not _validate_key(p.key):
            typer.echo(f"❌ Invalid key in {file}: {p.key}")
            failures += 1

        # Duplicate key detection
        if p.key is not None:
            if p.key in seen_keys:
                typer.echo(f"❌ Duplicate key '{p.key}' in:")
                typer.echo(f"   - {seen_keys[p.key]}")
                typer.echo(f"   - {file}")
                failures += 1
            else:
                seen_keys[p.key] = file

        # Label validation
        if not p.label:
            typer.echo(f"❌ Missing label in {file}")
            failures += 1

        # Order validation (None allowed)
        if p.order is not None and not isinstance(p.order, int):
            typer.echo(f"❌ Order must be int or None in {file}")
            failures += 1

        # Icon validation
        if p.icon is not None and not isinstance(p.icon, str):
            typer.echo(f"❌ Icon must be a string in {file}")
            failures += 1

        # Required roles validation
        if not isinstance(p.required_roles, list):
            typer.echo(f"❌ required_roles must be a list in {file}")
            failures += 1

        # Render function validation (page() or render())
        try:
            module = import_module_safely(p.file)
        except Exception:
            typer.echo(f"❌ Could not import module for {file}")
            failures += 1
            continue

        page_fn = getattr(module, "page", None) or getattr(module, "render", None)
        if not callable(page_fn):
            typer.echo(f"❌ Missing or non-callable page() in {file}")
            failures += 1

    # ---------------------------------------------------------
    # Final result
    # ---------------------------------------------------------
    if failures:
        typer.echo(f"\n❌ Linter failed with {failures} issues.")
        raise typer.Exit(code=1)

    typer.echo("\n✔ Linter passed with no issues.")
