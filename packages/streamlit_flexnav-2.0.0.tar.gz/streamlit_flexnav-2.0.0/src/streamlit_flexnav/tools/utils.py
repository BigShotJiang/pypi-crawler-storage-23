from __future__ import annotations

import structlog
from pathlib import Path

log = structlog.get_logger().bind(component="utils")


def safe_read(path: Path) -> str | None:
    try:
        return path.read_text(encoding="utf-8")
    except Exception as e:
        log.error("read_failed", file=str(path), error=str(e))
        return None


def safe_write(path: Path, content: str) -> bool:
    try:
        path.write_text(content, encoding="utf-8")
        return True
    except Exception as e:
        log.error("write_failed", file=str(path), error=str(e))
        return False
