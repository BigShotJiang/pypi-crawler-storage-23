# streamlit_flexnav/tools/__init__.py
# 2026-02-15 22:35 CET

from .cli import app as flexnav_cli
from .pages import page_app
from .menu import menu_app
from .config import config_app
from .debug_runtime import debug_app
from .doctor import doctor_app
from .linter import linter_app
from .menu_visualizer import menu_visualizer_app
from .setup_app import setup_app

__all__ = [
    "flexnav_cli",
    "page_app",
    "menu_app",
    "config_app",
    "debug_app",
    "doctor_app",
    "linter_app",
    "menu_visualizer_app",
    "setup_app",
]
