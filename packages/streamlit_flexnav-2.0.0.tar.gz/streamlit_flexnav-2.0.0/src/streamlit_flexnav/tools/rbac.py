# streamlit_flexnav/tools/rbac.py
# 2026-02-17 23:40 CET

from __future__ import annotations

from pathlib import Path
import typer

from streamlit_flexnav.core.config_loader import load_config, to_runtime_settings
from streamlit_flexnav.core.load_all import load_all
from streamlit_flexnav.core.models.rolemode import RoleMode
from streamlit_flexnav.core.rbac_resolver import (
    analyze_page,
    resolve_access,
    roles_unused,
    roles_unknown,
)

rbac_app = typer.Typer(help="RBAC tools", no_args_is_help=True)


# ---------------------------------------------------------
# Shared runtime loader
# ---------------------------------------------------------

def _load_runtime(config: str | None):
    if config:
        config_path = Path(config).resolve()
    else:
        default = Path("configs/admin/flexnav_config.yaml")
        if not default.exists():
            typer.echo("❌ No --config provided and default config not found.")
            raise typer.Exit(code=1)
        config_path = default.resolve()

    cfg = load_config(config_path)
    runtime = to_runtime_settings(cfg, config_path.parent.parent)
    runtime = load_all(runtime)
    return runtime


# ---------------------------------------------------------
# audit
# ---------------------------------------------------------
@rbac_app.callback(invoke_without_command=True)
def page_app_root(ctx: typer.Context):
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit()
    
@rbac_app.command("audit")
def rbac_audit(config: str = typer.Option(None, "--config")):
    """
    Run RBAC linting on all pages.
    """
    runtime = _load_runtime(config)

    messages: list[str] = []
    for page in runtime.pages:
        info = analyze_page(page)
        messages.extend(info.warnings)

    if not messages:
        typer.echo("✔ RBAC audit passed — no issues found.")
        raise typer.Exit(code=0)

    typer.echo("⚠ RBAC audit results:")
    for m in messages:
        typer.echo(f"  {m}")

    raise typer.Exit(code=1)


# ---------------------------------------------------------
# matrix
# ---------------------------------------------------------

@rbac_app.command("matrix")
def rbac_matrix(config: str = typer.Option(None, "--config")):
    """
    Print a role → page access matrix (CSV).
    """
    runtime = _load_runtime(config)

    typer.echo("role,page,allow,highest_required")
    if RoleMode:
        typer.echo("NO roles on pages, means NO access")
    for role in RoleMode:
        for page in runtime.pages:
            decision = resolve_access(page, role)
            allow = "yes" if decision.allow else "no"
            typer.echo(
                f"{role.value},{page.label},{allow},{decision.highest_required.value}"
            )


# ---------------------------------------------------------
# explain
# ---------------------------------------------------------

@rbac_app.command("explain")
def rbac_explain(
    page_label: str = typer.Argument(..., help="Page label to explain."),
    role_label: str = typer.Option(None, "--role"),
    config: str = typer.Option(None, "--config"),
):
    """
    Explain RBAC for a single page.
    """
    runtime = _load_runtime(config)

    page = next((p for p in runtime.pages if p.label == page_label), None)
    if not page:
        typer.echo(f"❌ Page '{page_label}' not found.")
        raise typer.Exit(code=1)

    info = analyze_page(page)
    role = RoleMode.from_label(role_label) if role_label else max(RoleMode)
    decision = resolve_access(page, role)

    typer.echo(f"Page: {info.label}")
    if info.path:
        typer.echo(f"Path: {info.path}")
    if info.group:
        typer.echo(f"Group: {info.group}")
    typer.echo(f"Required roles (raw): {info.required_roles_raw}")
    typer.echo(
        f"Required roles (normalized): {[r.value for r in info.required_roles_normalized]}"
    )
    typer.echo(f"Highest required: {info.highest_required.value}")
    typer.echo(f"Role evaluated: {role.value}")
    typer.echo(f"Allow: {'yes' if decision.allow else 'no'}")
    typer.echo(f"Reason: {decision.reason}")

    if info.warnings:
        typer.echo("Warnings:")
        for w in info.warnings:
            typer.echo(f"  - {w}")


# ---------------------------------------------------------
# coverage
# ---------------------------------------------------------

@rbac_app.command("coverage")
def rbac_coverage(config: str = typer.Option(None, "--config")):
    """
    Show RBAC coverage: unused roles, unknown roles, pages with no RBAC.
    """
    runtime = _load_runtime(config)

    unused = roles_unused(runtime.pages)
    unknown = roles_unknown(runtime.pages)
    no_rbac = [p.label for p in runtime.pages if not (p.required_roles or [])]

    typer.echo("RBAC coverage:")
    typer.echo(f"  Unused roles: {sorted(unused) or '[]'}")
    typer.echo(f"  Unknown roles: {sorted(unknown) or '[]'}")
    typer.echo(f"  Pages with no required_roles: {no_rbac or '[]'}")


# ---------------------------------------------------------
# graph (Graphviz DOT)
# ---------------------------------------------------------

@rbac_app.command("graph")
def rbac_graph(
    config: str = typer.Option(None, "--config"),
    only_role: str = typer.Option(None, "--only-role"),
    hide_public: bool = typer.Option(False, "--hide-public"),
):
    """
    Emit a Graphviz DOT RBAC graph: roles → pages.
    """
    runtime = _load_runtime(config)

    roles = list(RoleMode)
    if only_role:
        roles = [RoleMode.from_label(only_role)]

    typer.echo("digraph RBAC {")
    typer.echo('  rankdir=LR;')
    typer.echo('  node [fontname="Helvetica"];')

    # Role nodes
    for role in roles:
        typer.echo(f'  "{role.value}" [shape=box, style=filled, fillcolor="#f0f0f0"];')

    # Page nodes
    for page in runtime.pages:
        info = analyze_page(page)
        if hide_public and info.highest_required == RoleMode.NONE:
            continue
        label = page.label.replace('"', '\\"')
        typer.echo(f'  "page:{label}" [label="{label}", shape=ellipse];')

    # Edges
    for role in roles:
        for page in runtime.pages:
            info = analyze_page(page)
            if hide_public and info.highest_required == RoleMode.NONE:
                continue
            decision = resolve_access(page, role)
            if decision.allow:
                plabel = page.label.replace('"', '\\"')
                typer.echo(f'  "{role.value}" -> "page:{plabel}";')

    typer.echo("}")


# ---------------------------------------------------------
# doctor (deep diagnostics)
# ---------------------------------------------------------

@rbac_app.command("doctor")
def rbac_doctor(config: str = typer.Option(None, "--config")):
    """
    Deep RBAC diagnostics: unreachable pages, invalid roles, NONE-locked pages, etc.
    """
    runtime = _load_runtime(config)

    unreachable_pages: list[str] = []
    none_locked_pages: list[str] = []
    invalid_role_pages: list[str] = []

    for page in runtime.pages:
        info = analyze_page(page)

        if any("invalid role label" in w for w in info.warnings):
            invalid_role_pages.append(page.label)

        if info.highest_required == RoleMode.NONE:
            none_locked_pages.append(page.label)

        # Unreachable = no role can access it
        if not any(resolve_access(page, role).allow for role in RoleMode):
            unreachable_pages.append(page.label)

    typer.echo("RBAC doctor report:")
    typer.echo(f"  Pages with invalid role labels: {invalid_role_pages or '[]'}")
    typer.echo(f"  Pages requiring NONE: {none_locked_pages or '[]'}")
    typer.echo(f"  Pages unreachable by any role: {unreachable_pages or '[]'}")
