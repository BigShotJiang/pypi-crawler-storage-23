# streamlit_flexnav/tools/menu.py
# 2026-02-22 16:40 CET (FlexNav 2.0 aligned)

from __future__ import annotations

from pathlib import Path

import pandas as pd
import typer

from streamlit_flexnav.core.auth.rbac import AuthStruct
from streamlit_flexnav.core.loaders.config_loader import (
    find_config,
    load_config,
    to_runtime_settings,
)
from streamlit_flexnav.core.loaders.load_all import load_all

menu_app = typer.Typer(help="Menu inspection tools")


# ---------------------------------------------------------
# Load runtime (FlexNav 2.0 pipeline)
# ---------------------------------------------------------
def _load_runtime():
    cfg_path = find_config()
    cfg = load_config(cfg_path)
    app_root = Path(cfg_path).parent.parent

    runtime = to_runtime_settings(cfg, app_root)
    runtime = load_all(runtime)
    return runtime


# ---------------------------------------------------------
# menu list
# ---------------------------------------------------------
@menu_app.command("list")
def menu_list():
    runtime = _load_runtime()

    typer.echo("\n=== FLEXNAV MENU GROUPS ===")

    if not runtime.menu_metadata:
        typer.echo("⚠ No menu metadata was loaded.")
        typer.echo("=== END ===\n")
        return

    menus = sorted(
        runtime.menu_metadata.items(),
        key=lambda kv: (
            kv[1].order if kv[1].order is not None else 10**9,
            kv[0],
        ),
    )

    for group_key, meta in menus:
        typer.echo(
            f"- {meta.label}  (group='{group_key}', icon='{meta.icon}', order={meta.order})"
        )

    typer.echo("=== END ===\n")


# ---------------------------------------------------------
# menu tree
# ---------------------------------------------------------
@menu_app.callback(invoke_without_command=True)
def menu_app_root(ctx: typer.Context):
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit()


@menu_app.command("tree")
def menu_tree():
    runtime = _load_runtime()

    typer.echo("\n=== FLEXNAV MENU TREE ===")

    if not runtime.menu_metadata:
        typer.echo("⚠ menu_metadata is empty")
        typer.echo("=== END ===\n")
        return

    menus = sorted(
        runtime.menu_metadata.items(),
        key=lambda kv: (
            kv[1].order if kv[1].order is not None else 10**9,
            kv[0],
        ),
    )

    for group_key, meta in menus:
        typer.echo(f"{meta.label} ({group_key})")

        pages = [
            p
            for p in runtime.pages
            if p.group == group_key
        ]

        pages = sorted(
            pages,
            key=lambda p: (
                p.order if p.order is not None else 10**9,
                p.key if p.key is not None else "",
            ),
        )

        for p in pages:
            typer.echo(f"   └─ {p.label}  (key={p.key}, icon={p.icon})")

    typer.echo("=== END ===\n")


# ---------------------------------------------------------
# RBAC visibility matrix
# ---------------------------------------------------------
@menu_app.command("rbac")
def menu_rbac():
    """
    Print an RBAC visibility matrix showing which roles can see which pages.
    """
    runtime = _load_runtime()

    typer.echo("\n🔐 FLEXNAV RBAC VISIBILITY MATRIX\n")

    roles = set(runtime.current_user_roles or [])
    for p in runtime.pages:
        if p.required_roles:
            roles.update(p.required_roles)

    roles = sorted(roles)

    rows = []
    for p in runtime.pages:
        required_roles = p.required_roles or []
        required = p.required_role_highest()

        row = {
            "page_key": p.key,
            "label": p.label,
            "group": p.group,
            "required_roles": ", ".join(required_roles) if required_roles else "<public>",
        }

        for role in roles:
            user_role = AuthStruct.highest_role([role])
            row[role] = "✔" if user_role.can_access(required) else "—"

        rows.append(row)

    df = pd.DataFrame(rows)
    typer.echo(df.to_string(index=False))
    typer.echo("\n✔ RBAC matrix complete.\n")


# ---------------------------------------------------------
# menu conflicts
# ---------------------------------------------------------
@menu_app.command("conflicts")
def menu_conflicts():
    """
    Detect menu conflicts:
      - duplicate page orders within a group (ignore order=None)
      - duplicate page keys (ignore key=None)
      - orphaned menupages pages
      - invalid group references
    """
    runtime = _load_runtime()

    typer.echo("\n⚠️  FLEXNAV MENU CONFLICT CHECK\n")

    failures = 0
    valid_groups = set(runtime.menu_metadata.keys())

    # ---------------------------------------------------------
    # 1. Duplicate page orders within a group
    # ---------------------------------------------------------
    typer.echo("🔍 Checking duplicate page orders...")
    for group_key in valid_groups:
        pages = [p for p in runtime.pages if p.group == group_key]
        seen_orders: dict[int, object] = {}

        for p in pages:
            if p.order is None:
                continue
            if p.order in seen_orders:
                typer.echo(f"❌ Duplicate order {p.order} in group '{group_key}':")
                typer.echo(f"   - {seen_orders[p.order].path}")
                typer.echo(f"   - {p.path}")
                failures += 1
            else:
                seen_orders[p.order] = p

    # ---------------------------------------------------------
    # 2. Duplicate page keys
    # ---------------------------------------------------------
    typer.echo("\n🔍 Checking duplicate page keys...")
    seen_keys: dict[str, object] = {}
    for p in runtime.pages:
        if p.key is None:
            continue
        if p.key in seen_keys:
            typer.echo(f"❌ Duplicate key '{p.key}' in:")
            typer.echo(f"   - {seen_keys[p.key].path}")
            typer.echo(f"   - {p.path}")
            failures += 1
        else:
            seen_keys[p.key] = p

    # ---------------------------------------------------------
    # 3. Orphaned pages (menupages only)
    # ---------------------------------------------------------
    typer.echo("\n🔍 Checking orphaned pages (menupages only)...")
    grouped_keys = {
        p.key
        for p in runtime.pages
        if p.key is not None and p.group in valid_groups
    }

    for p in runtime.pages:
        if p.key is None:
            continue
        try:
            in_menupages = p.path.is_relative_to(runtime.menupages_root)
        except Exception:
            in_menupages = False

        if in_menupages and p.key not in grouped_keys:
            typer.echo(f"❌ Orphaned menupages page: {p.label} ({p.key})")
            failures += 1

    # ---------------------------------------------------------
    # 4. Invalid group references
    # ---------------------------------------------------------
    typer.echo("\n🔍 Checking invalid group references...")
    for p in runtime.pages:
        if p.group is None:
            continue
        if p.group not in valid_groups:
            typer.echo(f"❌ Page '{p.label}' references unknown group '{p.group}'")
            failures += 1

    # ---------------------------------------------------------
    # Final result
    # ---------------------------------------------------------
    if failures:
        typer.echo(f"\n❌ Menu conflict check failed with {failures} issues.\n")
        raise typer.Exit(code=1)

    typer.echo("\n✔ No menu conflicts detected.\n")
