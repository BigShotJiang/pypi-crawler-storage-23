# streamlit_flexnav/core/user_store.py
# 2026-02-18 00:45 CET

from __future__ import annotations
import yaml
from cryptography.fernet import Fernet
from pathlib import Path
import hashlib

class UserStore:
    def __init__(self, root: Path):
        self.root = root
        self.enc_file = root / "users.yaml.enc"
        self.key_file = root / "users.key"

        if not self.key_file.exists():
            self._generate_key()

        self.fernet = Fernet(self.key_file.read_bytes())

        # Auto-create encrypted user file if missing
        if not self.enc_file.exists():
            self._bootstrap_admin_user()

    # ---------------------------------------------------------
    # Key handling
    # ---------------------------------------------------------
    def _generate_key(self):
        key = Fernet.generate_key()
        self.key_file.write_bytes(key)

    # ---------------------------------------------------------
    # Bootstrap default admin user
    # ---------------------------------------------------------
    def _bootstrap_admin_user(self):
        default = {
            "users": [
                {
                    "username": "admin",
                    "password": self._hash_password("flexadmin"),
                    "roles": ["superadmin"],
                }
            ]
        }
        self.save(default)

    # ---------------------------------------------------------
    # Password hashing (SHA256)
    # ---------------------------------------------------------
    def _hash_password(self, password: str) -> str:
        return hashlib.sha256(password.encode("utf-8")).hexdigest()

    # ---------------------------------------------------------
    # Load / Save encrypted YAML
    # ---------------------------------------------------------
    def load(self) -> dict:
        encrypted = self.enc_file.read_bytes()
        decrypted = self.fernet.decrypt(encrypted)
        return yaml.safe_load(decrypted)

    def save(self, data: dict):
        raw = yaml.safe_dump(data).encode("utf-8")
        encrypted = self.fernet.encrypt(raw)
        self.enc_file.write_bytes(encrypted)

    # ---------------------------------------------------------
    # CRUD operations
    # ---------------------------------------------------------
    def list_users(self):
        return self.load().get("users", [])

    def add_user(self, username: str, roles: list[str], password: str = None):
        data = self.load()
        data.setdefault("users", [])
        data["users"].append({
            "username": username,
            "password": self._hash_password(password or "changeme"),
            "roles": roles,
        })
        self.save(data)

    def update_user(self, username: str, roles: list[str]):
        data = self.load()
        for u in data["users"]:
            if u["username"] == username:
                u["roles"] = roles
        self.save(data)

    def delete_user(self, username: str):
        data = self.load()
        data["users"] = [u for u in data["users"] if u["username"] != username]
        self.save(data)
