# streamlit_flexnav/core/loaders/merge_menu_and_pages.py
# 2026-03-01 — FlexNav 2.1 (MenuStruct.key aligned with PageStruct.key)


from __future__ import annotations
from typing import Dict, List
import structlog

from streamlit_flexnav.core.models.runtime_settings import RuntimeSettings
from streamlit_flexnav.core.models.pagestruct import PageStruct
from streamlit_flexnav.core.models.menustruct import MenuStruct

log = structlog.get_logger().bind(component="merge_menu_and_pages")

"""
flowchart TD

    %% --- Inputs ---
    subgraph INPUTS[RuntimeSettings Inputs]
        PAGES[pages: List<PageStruct>]
        MENUS[menu_metadata: Dict[group → MenuStruct]]
    end

    %% --- Merge process ---
    subgraph MERGE[merge_menu_and_pages()]
        A[Iterate over PageStructs]
        B{MenuStruct<br/>for page.group<br/>found?}
        C1[Keep PageStruct<br/>unchanged]
        C2[Apply MenuStruct<br/>metadata]
        D1[Override key<br/>(MenuStruct.key)]
        D2[Fill auto label<br/>if page.label_is_auto]
        D3[Fill auto icon<br/>if page.icon_is_auto]
        D4[Fill auto group<br/>if page.group_is_auto]
        D5[Fill auto order<br/>if page.order_is_auto]
        E[Collect merged PageStructs]
        F[Sort final list<br/>Application first<br/>Internal last]
    end

    %% --- Output ---
    subgraph OUTPUT[RuntimeSettings Output]
        FINAL[pages (merged + sorted)]
    end

    %% --- Flow ---
    PAGES --> A
    MENUS --> A

    A --> B
    B -->|nein| C1
    B -->|ja| C2

    C2 --> D1 --> D2 --> D3 --> D4 --> D5 --> E
    C1 --> E

    E --> F --> FINAL

"""
def merge_menu_and_pages(runtime: RuntimeSettings) -> RuntimeSettings:
    menu_meta: Dict[str, MenuStruct] = runtime.menu_metadata
    pages: List[PageStruct] = runtime.pages

    # ---------------------------------------------------------
    # 1) Build group buckets: external with order, external without, internal
    # ---------------------------------------------------------
    external_with_order = []
    external_without_order = []
    internal = []

    for group_key, menu in menu_meta.items():
        is_internal = group_key.startswith("internal")
        if is_internal:
            internal.append((group_key, menu))
        elif menu.order is not None:
            external_with_order.append((group_key, menu))
        else:
            external_without_order.append((group_key, menu))

    # ---------------------------------------------------------
    # 2) Sort each bucket deterministically
    # ---------------------------------------------------------
    # external with explicit order: by numeric order, then group_key for stability
    external_with_order.sort(key=lambda t: (t[1].order, t[0]))

    # external without order: stable, but only within this bucket
    external_without_order.sort(key=lambda t: t[0])

    # internal: by numeric order if present, then group_key
    internal.sort(key=lambda t: (t[1].order or 8999, t[0]))

    # ---------------------------------------------------------
    # 3) Assign group_rank: external-with-order → external-without → internal
    # ---------------------------------------------------------
    group_rank: Dict[str, int] = {}
    rank = 10
    step = 10

    # tier 1: external with explicit order
    for group_key, menu in external_with_order:
        group_rank[group_key] = rank
        rank += step

    # tier 2: external without explicit order
    for group_key, menu in external_without_order:
        group_rank[group_key] = rank
        rank += step

    # remember where external ends
    external_max_rank = rank if (external_with_order or external_without_order) else 0

    # tier 3: internal, always last
    if external_max_rank == 0:
        rank = 10
    else:
        rank = external_max_rank + 100  # clear gap after external

    for group_key, menu in internal:
        group_rank[group_key] = rank
        rank += step

    # fallback rank for pages without menu group (treated as external without order, but before internal)
    fallback_external_rank = (external_max_rank + 5) if external_max_rank else 50

    # ---------------------------------------------------------
    # 4) Merge PageStructs and compute final per-page order
    # ---------------------------------------------------------
    merged: List[PageStruct] = []
    group_counters: Dict[str, int] = {}

    for page in pages:
        group_key = page.group or ""
        menu = menu_meta.get(group_key)
        update: Dict[str, Any] = {}

        # attach menu metadata if present
        if menu is not None:
            update["key"] = menu.key

            # label
            if page.label is not None:
                update["label"] = page.label
            else:
                update["label"] = page.file.stem.replace("_", " ").title()

            # icon
            if getattr(page, "icon_is_auto", True) and menu.icon:
                update["icon"] = menu.icon

            # group
            if getattr(page, "group_is_auto", True) and menu.group:
                update["group"] = menu.group
                group_key = menu.group  # ensure consistency

        # determine group_rank
        if group_key in group_rank:
            base_rank = group_rank[group_key]
        else:
            # no menu group: treat as external without order, but before internal
            base_rank = fallback_external_rank

        # per-group counter for stable intra-group ordering
        idx = group_counters.get(group_key, 0) + 1
        group_counters[group_key] = idx

        # final numeric order: group_rank dominates, idx is local within group
        final_order = base_rank * 10 + idx
        update["order"] = final_order

        merged.append(page.model_copy(update=update))

    # ---------------------------------------------------------
    # 5) Final sort: strictly by final_order
    # ---------------------------------------------------------
    merged.sort(key=lambda p: p.order or 99999)

    # ---------------------------------------------------------
    # 6) Build menu_tree
    # ---------------------------------------------------------
    menu_tree: Dict[str, List[Dict[str, Any]]] = {}

    for p in merged:
        group = p.group or ""
        if group not in menu_tree:
            menu_tree[group] = []
        menu_tree[group].append(
            {
                "key": p.key,
                "label": p.label,
                "icon": p.icon,
                "order": p.order,
                "path": p.path,
            }
        )

    for group, items in menu_tree.items():
        items.sort(key=lambda x: x["order"])

    return runtime.model_copy(
        update={
            "pages": merged,
            "menu_tree": menu_tree,
        }
    )
