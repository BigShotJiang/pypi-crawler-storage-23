# streamlit_flexnav/core/loaders/load_all.py
# FlexNav 2.4 — PageStruct + MenuStruct pipeline

from __future__ import annotations

import structlog

from streamlit_flexnav.core.models.runtime_settings import RuntimeSettings
from streamlit_flexnav.core.loaders.pagestruct_loader import load_pagestructs
from streamlit_flexnav.core.loaders.menustruct_loader import load_menustructs
from streamlit_flexnav.core.loaders.merge_menu_and_pages import merge_menu_and_pages

log = structlog.get_logger().bind(component="load_all")


def load_all(runtime: RuntimeSettings) -> RuntimeSettings:
    """
    FlexNav 2.4 metadata pipeline (PageStruct + MenuStruct).

    Steps:
      1. Load PageStructs
      2. Load MenuStructs
      3. Merge MenuStruct → PageStruct
    """

    log.info("load_all_start")

    runtime = load_pagestructs(runtime)            # now calls load_pagestructs()
    runtime = load_menustructs(runtime)
    runtime = merge_menu_and_pages(runtime)

    log.info("load_all_complete")
    return runtime
