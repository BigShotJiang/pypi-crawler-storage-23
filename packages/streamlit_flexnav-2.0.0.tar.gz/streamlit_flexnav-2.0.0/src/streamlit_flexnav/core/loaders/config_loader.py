# streamlit_flexnav/core/config_loader.py
# 2026-03-01 — FlexNav 2.0 (RuntimeSettings + FlexNavConfig)

from __future__ import annotations

from pathlib import Path
import yaml
import structlog

from pydantic import ValidationError

from streamlit_flexnav.core.models.runtime_settings import RuntimeSettings
from streamlit_flexnav.core.models.authentication import (
    AuthMode,
    AuthenticationSettings,
    LocalAuthConfig,
    DatabaseAuthConfig,
    OAuthConfig,
)

log = structlog.get_logger().bind(component="config_loader")

CONFIG_PATH = "configs/flexnav_config.yaml"


# ---------------------------------------------------------
# Locate config file
# ---------------------------------------------------------
def find_config() -> Path:
    app_root = Path.cwd()
    cfg = app_root / CONFIG_PATH

    if not cfg.exists():
        raise FileNotFoundError(
            f"Missing config: {cfg}\n"
            f"Expected structure:\n"
            f"  {app_root}/{CONFIG_PATH}"
        )

    return cfg


# ---------------------------------------------------------
# Load raw YAML → dict
# ---------------------------------------------------------
def load_config(path: Path) -> dict:
    log.debug("loading_config", path=str(path))

    with path.open("r", encoding="utf-8") as f:
        data = yaml.safe_load(f)

    if not isinstance(data, dict):
        raise ValueError("Top-level YAML must be a mapping.")

    log.debug("config_loaded")
    return data


# ---------------------------------------------------------
# Convert YAML dict → RuntimeSettings
# ---------------------------------------------------------
def to_runtime_settings(cfg: dict, base: Path) -> RuntimeSettings:
    base = base.resolve()

    if "flexnav" not in cfg:
        raise ValueError("YAML must contain a 'flexnav:' section.")

    flex = cfg["flexnav"]

    # Required
    menupages = flex["menupages"]
    env = flex.get("env")
    profile = flex.get("profile", "default")

    # ---------------------------------------------------------
    # Authentication (inside flexnav)
    # ---------------------------------------------------------
    auth_cfg = flex.get("authentication", {})

    mode_str = auth_cfg.get("mode", "none").lower()
    try:
        mode = AuthMode(mode_str)
    except ValueError:
        log.warning("invalid_auth_mode", mode=mode_str)
        mode = AuthMode.NONE

    # Local auth
    local_cfg = auth_cfg.get("local")
    local = LocalAuthConfig(**local_cfg) if local_cfg else None

    # Database auth
    db_cfg = auth_cfg.get("database")
    database = DatabaseAuthConfig(**db_cfg) if db_cfg else None

    # OAuth (top-level)
    oauth_cfg = cfg.get("oauth")
    oauth = OAuthConfig(**oauth_cfg) if oauth_cfg else None

    authentication = AuthenticationSettings(
        mode=mode,
        local=local if mode == AuthMode.LOCAL else None,
        oauth=oauth if mode == AuthMode.OAUTH else None,
        database=database if mode == AuthMode.DATABASE else None,
    )

    # ---------------------------------------------------------
    # Logging (top-level)
    # ---------------------------------------------------------
    logging_cfg = cfg.get("logging", {})

    # ---------------------------------------------------------
    # Build RuntimeSettings via its factory
    # ---------------------------------------------------------
    try:
        return RuntimeSettings.from_config(
            base=base,
            config={
                "flexnav": {
                    "menupages": menupages,
                    "env": env,
                    "authentication": authentication,
                },
                "oauth": oauth_cfg,
                "logging": logging_cfg,
            },
        )
    except ValidationError as e:
        log.error("runtime_settings_validation_failed", errors=e.errors())
        raise


# ---------------------------------------------------------
# Public entrypoint
# ---------------------------------------------------------
def load_runtime() -> RuntimeSettings:
    cfg_path = find_config()
    raw = load_config(cfg_path)
    app_root = cfg_path.parent.parent  # configs/ → project root
    return to_runtime_settings(raw, app_root)
