# streamlit_flexnav/core/loaders/menustruct_loader.py
# 2026-02-23 — FlexNav 2.0 (aligned with extended MenuStruct)

from __future__ import annotations
from pathlib import Path
from typing import Dict
import structlog

from streamlit_flexnav.core.import_module_safely import import_module_safely
from streamlit_flexnav.core.models.menustruct import MenuStruct
from streamlit_flexnav.core.models.runtime_settings import RuntimeSettings

log = structlog.get_logger().bind(component="menustruct_loader")

"""
flowchart TD

    %% --- Filesystem ---
    subgraph FS[Filesystem]
        MP[menupages/ (folders)]
        INT[internal/ (folders)]
    end

    %% --- MenuLoader ---
    subgraph LOADER[MenuStruct Loader]
        A[Scan folders<br/>under menupages/ and internal/]
        B{__menu__.py vorhanden?}
        C1[Auto-generate MenuStruct<br/>(group, label, order)]
        C2[Load module<br/>import_module_safely]
        C3{menu() vorhanden?}
        C4[Auto-generate MenuStruct]
        C5[User MenuStruct<br/>(menu())]
        D1[Auto group<br/>menupages/... → menupages/<rel><br/>internal/... → internal/<rel>]
        D2[Auto label<br/>folder → Title Case]
        D3[Auto order<br/>Application < 9000<br/>Internal > 9000]
        D4[Fill missing fields<br/>and auto-flags]
    end

    %% --- Runtime ---
    subgraph RT[RuntimeSettings]
        OUT[menu_metadata:<br/>Dict[group → MenuStruct]]
    end

    %% --- Flow ---
    MP --> A
    INT --> A

    A --> B
    B -->|nein| C1
    B -->|ja| C2

    C2 --> C3
    C3 -->|nein| C4
    C3 -->|ja| C5

    C1 --> D1
    C4 --> D1
    C5 --> D1

    D1 --> D2 --> D3 --> D4 --> OUT

"""
IGNORE_FOLDERS = {
    "__pycache__", ".pytest_cache", ".git", ".idea", ".vscode", ".venv"
}


def _derive_group(folder: Path, runtime: RuntimeSettings) -> str:
    try:
        rel = folder.relative_to(runtime.menupages_root)
        if rel == Path("."):
            return ""
        return "/".join(rel.parts)
    except ValueError:
        pass

    try:
        rel = folder.relative_to(runtime.internal_root)
        if rel == Path("."):
            return "internal"
        return "internal/" + "/".join(rel.parts)
    except ValueError:
        pass

    return ""


def _auto_menu(folder: Path, runtime: RuntimeSettings) -> MenuStruct:
    group = _derive_group(folder, runtime)
    label = group.split("/")[-1].replace("_", " ").title() if group else folder.name.title()

    return MenuStruct(
        key=group or folder.name,
        group=group,
        label=label,
        icon=None,
        color=None,
        bold=False,
        italic=False,
        order=None,
        path=str(folder),
        file=folder,
    )

def _load_single_menu(folder: Path, runtime: RuntimeSettings) -> MenuStruct:
    menu_file = folder / "__menu__.py"

    # 1) No __menu__.py → auto menu
    if not menu_file.exists():
        return _auto_menu(folder, runtime)

    module = import_module_safely(menu_file)
    if not hasattr(module, "menu"):
        return _auto_menu(folder, runtime)

    raw = module.menu()
    if not isinstance(raw, MenuStruct):
        raise TypeError(f"menu() in {menu_file} must return a MenuStruct")

    # 2) Determine group
    group = raw.group if raw.group is not None else _derive_group(folder, runtime)

    # 3) Determine label (MenuStruct.label ALWAYS wins)
    if raw.label:
        label = raw.label
    else:
        # Auto label fallback
        label = (
            group.split("/")[-1].replace("_", " ").title()
            if group else folder.name.title()
        )

    # 4) INTERNAL PREFIX RULE
    if group.startswith("internal"):
        # Avoid double prefix
        if not label.lower().startswith("internal "):
            label = f"internal {label}"

    # 5) Return final MenuStruct
    return raw.model_copy(
        update={
            "group": group,
            "label": label,
            "path": str(menu_file),
            "file": menu_file,
        }
    )

def old_load_single_menu(folder: Path, runtime: RuntimeSettings) -> MenuStruct:
    menu_file = folder / "__menu__.py"

    if not menu_file.exists():
        return _auto_menu(folder, runtime)

    module = import_module_safely(menu_file)
    if not hasattr(module, "menu"):
        return _auto_menu(folder, runtime)

    raw = module.menu()
    if not isinstance(raw, MenuStruct):
        raise TypeError(f"menu() in {menu_file} must return a MenuStruct")

    group = raw.group if raw.group is not None else _derive_group(folder, runtime)
    label = raw.label if raw.label is not None else (
        group.split("/")[-1].replace("_", " ").title() if group else folder.name.title()
    )

    return raw.model_copy(
        update={
            "group": group,
            "label": label,
            "path": str(menu_file),
            "file": menu_file,
        }
    )


def load_menustructs(runtime: RuntimeSettings) -> RuntimeSettings:
    menu_metadata: Dict[str, MenuStruct] = {}

    def scan_folder(folder: Path):
        # Debug: show every scanned folder
        log.info("scan_folder", folder=str(folder))

        if folder.name in IGNORE_FOLDERS:
            log.info("skip_ignored_folder", folder=str(folder))
            return

        if folder not in (runtime.menupages_root, runtime.internal_root):
            menu = _load_single_menu(folder, runtime)
            menu_metadata[menu.group or ""] = menu

            log.info(
                "menu_loaded",
                group=menu.group,
                label=menu.label,
                key=menu.key,
                order=menu.order,
                path=menu.path,
            )

        children = [
            p for p in folder.iterdir()
            if p.is_dir() and p.name not in IGNORE_FOLDERS
        ]

        for child in sorted(children, key=lambda x: x.name):
            scan_folder(child)


    # Scan both roots deeply
    for root in (runtime.menupages_root, runtime.internal_root):
        if root.exists():
            scan_folder(root)

    return runtime.model_copy(update={"menu_metadata": menu_metadata})
