# streamlit_flexnav/core/loaders/pagestruct_loader.py
# 2026-02-26 — FlexNav 2.0 (PageStruct + MenuStruct aligned)

from __future__ import annotations

from pathlib import Path
from typing import List
import structlog

from streamlit_flexnav.core.import_module_safely import import_module_safely
from streamlit_flexnav.core.models.pagestruct import PageStruct
from streamlit_flexnav.core.models.runtime_settings import RuntimeSettings

log = structlog.get_logger().bind(component="pagestruct_loader")

"""
flowchart TD

    %% --- Filesystem ---
    subgraph FS[Filesystem]
        ROOT_M[menupages/...]
        ROOT_I[internal/...]
    end

    %% --- PageLoader ---
    subgraph LOADER[PageStruct Loader]
        A[Import module\n(import_module_safely)]
        B{page() vorhanden?}
        C1[Minimal PageStruct\n(app/render/main)]
        C2[User PageStruct\n(page())]
        D1[Auto group\nmenupages/... → menupages/<rel>\ninternal/... → internal/<rel>]
        D2[Auto label\nfilename → Title Case]
        D3[Auto order\nApplication < 9000\nInternal > 9000]
        D4[Generate key\ngroup.filename.slug.order]
        D5[Normalize RBAC roles]
        D6[Inject path + file]
    end

    %% --- Runtime ---
    subgraph RT[RuntimeSettings]
        OUT[pages: List<PageStruct>]
    end

    %% --- Flow ---
    ROOT_M --> A
    ROOT_I --> A

    A --> B
    B -->|nein| C1
    B -->|ja| C2

    C1 --> D1
    C2 --> D1

    D1 --> D2 --> D3 --> D4 --> D5 --> D6 --> OUT
"""
# ---------------------------------------------------------
# Helpers
# ---------------------------------------------------------
def _collapse_to_label(path_str: str) -> str:
    """
    Convert a path like 'HR/EU/Admin.py' into 'Hr Eu'.
    Removes file extensions and title-cases each segment.
    """
    # Remove .py if present
    cleaned = path_str.replace(".py", "")

    # Split into segments
    parts = cleaned.split("/")

    # Title-case each segment
    return Path(" ".join(p.title() for p in parts))

def _is_internal(path: Path, runtime: RuntimeSettings) -> bool:
    try:
        path.relative_to(runtime.internal_root)
        return True
    except ValueError:
        return False

def test_derive_group(path: Path, runtime: RuntimeSettings) -> str:
    """
    MUST match MenuStruct._derive_group semantics.
    """
    folder =  _collapse_to_label(path)

    try:
        rel = folder.relative_to(runtime.menupages_root)
        if rel == Path("."):
            return ""
        return "/".join(rel.parts)
    except ValueError:
        pass

    try:
        rel = folder.relative_to(runtime.internal_root)
        if rel == Path("."):
            return "internal"
        return "internal/" + "/".join(rel.parts)
    except ValueError:
        pass

    return ""

def _derive_group(path: Path, runtime: RuntimeSettings) -> str:
    """
    MUST match MenuStruct._derive_group semantics.
    """
    base = runtime.internal_root if _is_internal(path, runtime) else runtime.menupages_root

    try:
        rel = path.parent.relative_to(base)
    except ValueError:
        return ""

    if rel == Path("."):
        return "" if not _is_internal(path, runtime) else "internal"

    parts = list(rel.parts)
    if _is_internal(path, runtime):
        return "internal/" + "/".join(parts)
    return "/".join(parts)


def _auto_label(path: Path) -> str:
    return path.stem.replace("_", " ").title()


def _generate_key(group: str, filename: str, label: str) -> str:
    """
    Key WITHOUT order (order is never leading).
    """
    slug = label.lower().replace(" ", "_")
    base = f"{filename}.{slug}"
    return f"{group}.{base}" if group else base


# ---------------------------------------------------------
# Load a single page
# ---------------------------------------------------------

def _load_single_page(path: Path, runtime: RuntimeSettings) -> PageStruct:
    if path.name in ("__init__.py", "__menu__.py"):
        raise RuntimeError("Should not be called for meta files")

    module = import_module_safely(path)

    # page() or fallback
    if not hasattr(module, "page"):
        group = _derive_group(path, runtime)
        print("DERIVE GROUP:", path, "=>", _derive_group(path, runtime))

        label = _auto_label(path)
        return PageStruct(
            key=_generate_key(group, path.stem, label),
            group=group,
            label=label,
            icon=None,
            order=None,
            path=str(path),
            file=path,
        )

    raw = module.page()
    if not isinstance(raw, PageStruct):
        raise TypeError(f"page() in {path} must return a PageStruct")

    group = raw.group if raw.group is not None else _derive_group(path, runtime)

    # Label-Regel:
    if raw.label is not None:
        label = raw.label
    else:
        label = _auto_label(path)

    return raw.model_copy(
        update={
            "group": group,
            "label": label,
            "key": _generate_key(group, path.stem, label),
            "path": str(path),
            "file": path,
        }
    )


# ---------------------------------------------------------
# Public API
# ---------------------------------------------------------

def load_pagestructs(runtime: RuntimeSettings) -> RuntimeSettings:
    pages: List[PageStruct] = []

    # Load menupages first, then internal
    for root in [runtime.menupages_root, runtime.internal_root]:
        if not root.exists():
            continue

        # BFS: Ordner alphabetisch, Dateien physisch
        stack = [root]

        while stack:
            current = stack.pop(0)

            # Unterordner alphabetisch
            children_dirs = [p for p in current.iterdir() if p.is_dir()]
            children_dirs_sorted = sorted(children_dirs, key=lambda x: x.name)
            stack.extend(children_dirs_sorted)

            # Dateien in physischer Reihenfolge
            files = [p for p in current.iterdir() if p.is_file()]

            for f in files:
                # Skip meta + cache
                if f.name in ("__init__.py", "__menu__.py"):
                    continue
                if f.suffix != ".py":
                    continue
                if "__pycache__" in f.parts:
                    continue
                if f.name.endswith(".pyc"):
                    continue

                # Jetzt ist es garantiert eine echte Page
                page = _load_single_page(f, runtime)
                pages.append(page)

                log.debug(
                    "page_loaded",
                    key=page.key,
                    group=page.group,
                    path=str(f),
                    label=page.label,
                )

    return runtime.model_copy(update={"pages": pages})
