# streamlit_flexnav/core/rbac_resolver.py
# 2026-02-17 23:40 CET

from __future__ import annotations

from typing import Iterable, List, Set
from pydantic import BaseModel, Field

from streamlit_flexnav.core.models.rolemode import RoleMode


# ---------------------------------------------------------
# Pydantic models
# ---------------------------------------------------------

class AccessDecision(BaseModel):
    allow: bool
    role: RoleMode
    required_roles_raw: List[str]
    required_roles_normalized: List[RoleMode]
    highest_required: RoleMode
    reason: str


class PageRBACInfo(BaseModel):
    label: str
    path: str | None = None
    group: str | None = None
    required_roles_raw: List[str]
    required_roles_normalized: List[RoleMode]
    highest_required: RoleMode
    warnings: List[str]


# ---------------------------------------------------------
# Helpers
# ---------------------------------------------------------

def _normalize_roles(raw_roles: Iterable[str]) -> List[RoleMode]:
    out: List[RoleMode] = []
    for r in raw_roles:
        try:
            out.append(RoleMode.from_label(r))
        except Exception:
            # invalid roles handled in analyze_page()
            pass
    return out


# ---------------------------------------------------------
# Page analysis
# ---------------------------------------------------------

def analyze_page(page) -> PageRBACInfo:
    """
    Inspect a page's RBAC definition and return structured info + warnings.
    """
    raw = list(page.required_roles or [])
    warnings: List[str] = []

    if not raw:
        warnings.append(
            f"Page '{page.label}' has no required_roles → defaults to NONE (no access)."
        )

    normalized = _normalize_roles(raw)
    invalid = set(raw) - {r.value for r in normalized}
    for r in invalid:
        warnings.append(
            f"Page '{page.label}' has invalid role label: '{r}'."
        )

    highest = RoleMode.highest_role([r.value for r in normalized] or ["none"])
    if highest == RoleMode.NONE:
        warnings.append(
            f"Page '{page.label}' requires NONE → no authenticated user can access it."
        )

    return PageRBACInfo(
        label=page.label,
        path=getattr(page, "path", None),
        group=getattr(page, "group", None),
        required_roles_raw=raw,
        required_roles_normalized=normalized,
        highest_required=highest,
        warnings=warnings,
    )


# ---------------------------------------------------------
# Access resolver
# ---------------------------------------------------------

def resolve_access(page, role: RoleMode) -> AccessDecision:
    """
    Canonical RBAC decision engine.
    """
    info = analyze_page(page)

    # No valid roles → treat as NONE (deny)
    if not info.required_roles_normalized or info.highest_required == RoleMode.NONE:
        return AccessDecision(
            allow=False,
            role=role,
            required_roles_raw=info.required_roles_raw,
            required_roles_normalized=info.required_roles_normalized,
            highest_required=info.highest_required,
            reason="Page has no valid required_roles or requires NONE → access denied.",
        )

    if role >= info.highest_required:
        allow = True
        reason = (
            f"Role '{role.value}' >= required '{info.highest_required.value}' → allowed."
        )
    else:
        allow = False
        reason = (
            f"Role '{role.value}' < required '{info.highest_required.value}' → denied."
        )

    return AccessDecision(
        allow=allow,
        role=role,
        required_roles_raw=info.required_roles_raw,
        required_roles_normalized=info.required_roles_normalized,
        highest_required=info.highest_required,
        reason=reason,
    )


# ---------------------------------------------------------
# Role introspection
# ---------------------------------------------------------

def roles_used(pages: Iterable) -> Set[str]:
    used: Set[str] = set()
    for p in pages:
        for r in p.required_roles or []:
            used.add(r)
    return used


def roles_defined() -> Set[str]:
    return {m.value for m in RoleMode}


def roles_unused(pages: Iterable) -> Set[str]:
    return roles_defined() - roles_used(pages)


def roles_unknown(pages: Iterable) -> Set[str]:
    defined = roles_defined()
    return {r for r in roles_used(pages) if r not in defined}
