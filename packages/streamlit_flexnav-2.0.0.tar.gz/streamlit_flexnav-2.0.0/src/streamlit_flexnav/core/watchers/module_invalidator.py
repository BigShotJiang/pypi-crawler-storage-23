# streamlit_flexnav/core/watchers/module_invalidator.py
# 2026-02-22

import sys
import importlib
from pathlib import Path


def invalidate_menupage_modules(root: Path):
    """
    Removes all modules under the menupages directory from sys.modules
    so that Python reloads them on next import.
    """

    root_str = str(root.resolve())

    to_delete = []

    for name, module in list(sys.modules.items()):
        try:
            file = Path(getattr(module, "__file__", "")).resolve()
        except Exception:
            continue

        if root_str in str(file):
            to_delete.append(name)

    for name in to_delete:
        del sys.modules[name]

    importlib.invalidate_caches()
