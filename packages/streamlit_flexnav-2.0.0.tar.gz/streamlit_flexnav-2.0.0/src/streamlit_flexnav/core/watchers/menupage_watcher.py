# streamlit_flexnav/core/watchers/menupage_watcher.py
# 2026-02-22

from __future__ import annotations
import os
from pathlib import Path
import streamlit as st

SESSION_KEY = "_flexnav_menupages_mtime"


def compute_menupages_mtime(root: Path) -> float:
    """
    Returns a single float representing the latest modification time
    of any .py file under the menupages tree (recursive).
    """
    latest = 0.0

    for dirpath, _, filenames in os.walk(root):
        for name in filenames:
            if not name.endswith(".py"):
                continue

            p = Path(dirpath) / name
            try:
                m = p.stat().st_mtime
            except FileNotFoundError:
                continue

            if m > latest:
                latest = m

    return latest


def menupages_changed(root: Path) -> bool:
    """
    Returns True if any .py file under menupages changed since last run.
    Uses Streamlit session_state to persist the previous fingerprint.
    """
    current = compute_menupages_mtime(root)
    previous = st.session_state.get(SESSION_KEY)

    # Store for next run
    st.session_state[SESSION_KEY] = current

    # First run → nothing to compare
    if previous is None:
        return False

    return current != previous
