# streamlit_flexnav/core/menu_builder.py
# 2026-02-26 — FlexNav 2.0
# Grouped PageStruct + RBAC + collapsed groups + ordered menus

from __future__ import annotations

from collections import OrderedDict
from typing import Dict, List, Tuple

import structlog

from streamlit_flexnav.core.models.runtime_settings import RuntimeSettings
from streamlit_flexnav.core.models.pagestruct import PageStruct
from streamlit_flexnav.core.auth.rbac import AuthStruct

log = structlog.get_logger().bind(component="menu_builder")

# -------------------------------------------------------------------
# Ordering policy (explicit and authoritative)
# -------------------------------------------------------------------
UNORDERED_MENU_FALLBACK = 8000
INTERNAL_MENU_FALLBACK = 10000
INTERNAL_MENU_PREFIX = "internal"


# -------------------------------------------------------------------
# RBAC helpers
# -------------------------------------------------------------------
def _user_highest_role(runtime: RuntimeSettings) -> AuthStruct:
    return AuthStruct.highest_role(runtime.current_user_roles)


def _page_is_accessible(user_role: AuthStruct, page: PageStruct) -> bool:
    return AuthStruct.has_any_role([user_role], page.required_roles)


# -------------------------------------------------------------------
# Group collapsing
# -------------------------------------------------------------------
def _collapse_group_label(group_key: str, runtime: RuntimeSettings) -> str:
    """
    Collapse a menu key into a display label.

    Priority:
      1. MenuStruct.label (from __menu__.py)
      2. Collapse path segments: "sales/finance/hr" → "Sales Finance Hr"
      3. Empty group → "Main"
    """
    if not group_key:
        return "Main"

    menu = runtime.menu_metadata.get(group_key)
    if menu and menu.label:
        return menu.label.title()

    return " ".join(part.title() for part in group_key.split("/"))


# -------------------------------------------------------------------
# Page ordering
# -------------------------------------------------------------------
def _page_order(page: PageStruct) -> int:
    return page.order if page.order is not None else 10_000


# -------------------------------------------------------------------
# Default-page resolution
# -------------------------------------------------------------------
def _resolve_default_page(group_label: str, pages: List[PageStruct]) -> List[PageStruct]:
    defaults = [p for p in pages if p.is_default]

    if len(defaults) <= 1:
        return pages

    defaults.sort(key=_page_order)
    chosen = defaults[0]

    log.warning(
        "multiple_default_pages",
        group=group_label,
        chosen=chosen.key,
    )

    return [
        p if p is chosen else p.model_copy(update={"is_default": False})
        for p in pages
    ]


# -------------------------------------------------------------------
# Group ordering (FINAL, AUTHORITATIVE)
# -------------------------------------------------------------------
def _group_sort_key(
    group_key: str,
    group_label: str,
    runtime: RuntimeSettings,
) -> Tuple[int, int, str]:
    """
    Menu ordering policy:

      1. Menus with explicit MenuStruct.order (from __menu__.py)
      2. Menus without an order (start at UNORDERED_MENU_FALLBACK)
      3. All internal menus (group_key starts with 'internal')

    Alphabetical fallback applies only within the same priority band.
    """
    menu = runtime.menu_metadata.get(group_key)

    is_internal = group_key.lower().startswith(INTERNAL_MENU_PREFIX)
    has_order = menu is not None and menu.order is not None

    if is_internal:
        return (2, INTERNAL_MENU_FALLBACK, group_label.lower())

    if has_order:
        return (0, menu.order, group_label.lower())

    return (1, UNORDERED_MENU_FALLBACK, group_label.lower())


# -------------------------------------------------------------------
# Public API
# -------------------------------------------------------------------
def build_grouped_pages(runtime: RuntimeSettings) -> Dict[str, List[PageStruct]]:
    """
    Build a grouped, RBAC-filtered mapping:

        Dict[collapsed_group_label → List[PageStruct]]

    Guarantees:
      - MenuStruct.order from __menu__.py is the primary ordering signal
      - Unordered menus start at UNORDERED_MENU_FALLBACK
      - All internal* menus are always last
      - Alphabetical order is only a tie-breaker
    """

    user_role = _user_highest_role(runtime)
    pages = runtime.pages

    log.info("=== MENU BUILDER START ===")
    log.info("user_role", role=user_role.display_name())
    log.info("total_pages_in_runtime", count=len(pages))

    # group_label → (group_key, pages)
    grouped: Dict[str, Dict[str, object]] = {}

    # 1) RBAC filter + group collapse
    for page in pages:
        if not _page_is_accessible(user_role, page):
            log.warning(
                "page_filtered_rbac",
                key=page.key,
                group=page.group,
                required_roles=page.required_roles,
                user_role=user_role.display_name(),
            )
            continue

        group_key = page.group or ""
        group_label = _collapse_group_label(group_key, runtime)

        entry = grouped.setdefault(
            group_label,
            {"group_key": group_key, "pages": []},
        )
        entry["pages"].append(page)

    log.info("groups_after_collapse", groups=list(grouped.keys()))

    # 2) Sort pages within each group
    for entry in grouped.values():
        entry["pages"].sort(key=_page_order)

    # 3) Resolve default-page conflicts
    for group_label, entry in grouped.items():
        entry["pages"] = _resolve_default_page(group_label, entry["pages"])

    # 4) Sort groups using MenuStruct.order
    sorted_items = sorted(
        grouped.items(),
        key=lambda item: _group_sort_key(
            group_key=item[1]["group_key"],
            group_label=item[0],
            runtime=runtime,
        ),
    )

    ordered: Dict[str, List[PageStruct]] = OrderedDict()
    for group_label, entry in sorted_items:
        ordered[group_label] = entry["pages"]

        log.info(
            "final_group",
            group=group_label,
            pages=[p.key for p in entry["pages"]],
        )

    log.info("=== MENU BUILDER END ===")
    return ordered
