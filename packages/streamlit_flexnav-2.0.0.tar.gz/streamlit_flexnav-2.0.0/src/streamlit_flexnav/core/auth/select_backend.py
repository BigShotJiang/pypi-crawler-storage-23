# streamlit_flexnav/core/auth/select_backend.py

from __future__ import annotations

from pathlib import Path

from streamlit_flexnav.core.auth.backend import AuthBackend
from streamlit_flexnav.core.auth.oauth_auth import OAuthBackend
from streamlit_flexnav.core.models.authentication import AuthMode


def get_auth_backend(settings, root_path: Path):
    """
    Factory for selecting the correct authentication backend.
    """

    mode = settings.mode

    if mode == AuthMode.NONE:
        return None

    if mode == AuthMode.LOCAL:
        return AuthBackend(root_path)

    if mode == AuthMode.DATABASE:
        return AuthBackend(root_path)  # DB support can be added later

    if mode == AuthMode.OAUTH:
        return OAuthBackend(settings.oauth, root_path)

    raise ValueError(f"Unknown authentication mode: {mode}")
