# streamlit_flexnav/core/auth/db_auth.py
# 2026-02-23

from __future__ import annotations

from pathlib import Path
from typing import Optional, List

import streamlit as st
import sqlalchemy as sa

from streamlit_flexnav.core.auth.userstruct import UserStruct
from streamlit_flexnav.core.auth.passwords import verify_password


class DatabaseAuthBackend:
    """
    Database-backed authentication for FlexNav.

    Expected schema:

        users(username TEXT PRIMARY KEY,
              password TEXT,
              first_login BOOLEAN)

        user_roles(username TEXT,
                   role TEXT)

    """

    def __init__(self, settings: dict):
        self.engine = sa.create_engine(settings["connection"])

    # ---------------------------------------------------------
    # Session handling
    # ---------------------------------------------------------
    def _set_session(self, user: UserStruct) -> None:
        st.session_state["user"] = user

    def _clear_session(self) -> None:
        st.session_state.pop("user", None)

    def current_user(self) -> Optional[UserStruct]:
        user = st.session_state.get("user")
        if isinstance(user, UserStruct):
            return user
        return None

    # ---------------------------------------------------------
    # Authentication
    # ---------------------------------------------------------
    def authenticate(self, username: str, password: str) -> Optional[UserStruct]:
        with self.engine.begin() as conn:
            row = conn.execute(
                sa.text(
                    "SELECT username, password, first_login "
                    "FROM users WHERE username=:u"
                ),
                {"u": username},
            ).fetchone()

        if not row:
            return None

        stored_hash = row.password
        if not verify_password(stored_hash, password):
            return None

        # Load roles
        with self.engine.begin() as conn:
            rows = conn.execute(
                sa.text("SELECT role FROM user_roles WHERE username=:u"),
                {"u": username},
            ).fetchall()

        roles: List[str] = [r[0] for r in rows] if rows else []

        return UserStruct(
            username=row.username,
            roles=roles,
            first_login=row.first_login,
        )

    def login(self, username: str, password: str) -> bool:
        user = self.authenticate(username, password)
        if not user:
            return False
        self._set_session(user)
        return True

    def logout(self) -> None:
        self._clear_session()
