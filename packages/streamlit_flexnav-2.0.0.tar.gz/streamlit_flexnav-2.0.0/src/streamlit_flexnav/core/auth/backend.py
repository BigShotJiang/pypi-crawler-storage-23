from __future__ import annotations

from pathlib import Path
from typing import Optional

import streamlit as st

from streamlit_flexnav.core.auth.user_store import UserStore
from streamlit_flexnav.core.auth.userstruct import UserStruct
from streamlit_flexnav.core.auth.passwords import verify_password


class AuthBackend:
    """
    Unified authentication backend for FlexNav.

    - Uses UserStore for persistence
    - Stores UserStruct in session_state["user"]
    """

    def __init__(self, root_path: Path):
        self.root_path = Path(root_path)
        self.store = UserStore(self.root_path)

    # ---------------------------------------------------------
    # Session handling
    # ---------------------------------------------------------
    def _set_session(self, user: UserStruct) -> None:
        st.session_state["user"] = user

    def _clear_session(self) -> None:
        st.session_state.pop("user", None)

    def current_user(self) -> Optional[UserStruct]:
        user = st.session_state.get("user")
        if isinstance(user, UserStruct):
            return user
        return None

    # ---------------------------------------------------------
    # Authentication
    # ---------------------------------------------------------
    def authenticate(self, username: str, password: str) -> Optional[UserStruct]:
        raw = self.store.lookup_user(username)
        if not raw:
            return None

        stored_hash = raw.get("password")
        if not stored_hash or not verify_password(stored_hash, password):
            return None

        return UserStruct(
            username=raw.get("username", username),
            roles=raw.get("roles", []) or [],
            first_login=raw.get("first_login", True),
        )

    def login(self, username: str, password: str) -> bool:
        user = self.authenticate(username, password)
        if not user:
            return False
        self._set_session(user)
        return True

    def logout(self) -> None:
        self._clear_session()
