# streamlit_flexnav/core/middleware/auth_redirect.py
# 2026-02-18 02:30 CET

import streamlit as st

def enforce_auth(runtime, active_page):
    """
    Redirect to logon page if:
      - authentication is enabled
      - user is not logged in
      - page requires roles
    """

    if not runtime.auth_enabled:
        return

    auth = runtime.auth
    roles = auth.get_roles()

    # If no user and page requires roles → redirect
    if not roles and active_page.required_roles != ["none"]:
        st.switch_page("auth/logon")
