# streamlit_flexnav/core/auth/no_auth.py
# 2026-02-23

from __future__ import annotations

from pathlib import Path
from typing import Optional

import streamlit as st

from streamlit_flexnav.core.auth.userstruct import UserStruct


class NoAuthBackend:
    """
    Trivial backend: no authentication required.
    Always returns an anonymous user with role 'none'.
    """

    def __init__(self, root_path: Path | None = None):
        self.root_path = Path(root_path) if root_path else None

    # ---------------------------------------------------------
    # Session handling
    # ---------------------------------------------------------
    def current_user(self) -> UserStruct:
        """
        Always returns an anonymous user.
        """
        user = st.session_state.get("user")
        if isinstance(user, UserStruct):
            return user

        anon = UserStruct(
            username="anonymous",
            roles=["none"],
            first_login=False,
        )
        st.session_state["user"] = anon
        return anon

    # ---------------------------------------------------------
    # Login / Logout (no-op)
    # ---------------------------------------------------------
    def login(self, username: str = "", password: str = "") -> bool:
        """
        No login required. Always succeeds.
        """
        st.session_state["user"] = UserStruct(
            username="anonymous",
            roles=["none"],
            first_login=False,
        )
        return True

    def logout(self) -> None:
        """
        No logout required. Clears session user.
        """
        st.session_state.pop("user", None)
