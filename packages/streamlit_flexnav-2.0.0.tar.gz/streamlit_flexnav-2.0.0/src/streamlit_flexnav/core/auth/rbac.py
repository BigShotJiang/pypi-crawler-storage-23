# streamlit_flexnav/core/auth/rbac.py
# 2026-02-23

from __future__ import annotations

from enum import IntEnum
from typing import Iterable, List, Optional, Any

import structlog

from streamlit_flexnav.core.auth.userstruct import UserStruct

log = structlog.get_logger().bind(component="rbac")


class AuthStruct(IntEnum):
    """
    Hierarchical role model for FlexNav.

    Ordering (lowest → highest privilege):
        NONE < VIEWER < USER < ADMIN < SUPERADMIN

    This enables simple hierarchical RBAC:
        ADMIN can access USER pages
        SUPERADMIN can access everything
    """

    NONE = 0
    VIEWER = 1
    USER = 2
    ADMIN = 3
    SUPERADMIN = 99

    # ---------------------------------------------------------------
    # Display helpers
    # ---------------------------------------------------------------

    def display_name(self) -> str:
        mapping = {
            AuthStruct.NONE: "None",
            AuthStruct.VIEWER: "Viewer",
            AuthStruct.USER: "User",
            AuthStruct.ADMIN: "Admin",
            AuthStruct.SUPERADMIN: "Super Admin",
        }
        # Defensive: never crash on unknown enum values
        name = mapping.get(self)
        if name is None:
            log.error("authstruct_unknown_display_name", value=int(self))
            return f"Unknown({int(self)})"
        return name

    # ---------------------------------------------------------------
    # Normalization helpers
    # ---------------------------------------------------------------

    @classmethod
    def from_label(cls, value: Any) -> AuthStruct:
        """
        Normalize strings/ints/AuthStruct into an AuthStruct instance.

        - Unknown strings → NONE (with warning)
        - Invalid ints → NONE (with warning)
        - Unsupported types → NONE (with warning)
        """
        try:
            if isinstance(value, AuthStruct):
                return value

            if isinstance(value, int):
                try:
                    return AuthStruct(value)
                except ValueError:
                    log.warning("authstruct_invalid_integer", value=value)
                    return AuthStruct.NONE

            if isinstance(value, str):
                normalized = value.strip().lower()
                mapping = {
                    "none": cls.NONE,
                    "noauth": cls.NONE,
                    "guest": cls.NONE,

                    "viewer": cls.VIEWER,
                    "read-only": cls.VIEWER,
                    "readonly": cls.VIEWER,
                    "read only": cls.VIEWER,

                    "user": cls.USER,
                    "member": cls.USER,

                    "admin": cls.ADMIN,
                    "administrator": cls.ADMIN,

                    "superadmin": cls.SUPERADMIN,
                    "super admin": cls.SUPERADMIN,
                    "root": cls.SUPERADMIN,
                }

                if normalized in mapping:
                    return mapping[normalized]

                log.warning("authstruct_unknown_label", value=value)
                return AuthStruct.NONE

            log.warning("authstruct_invalid_type", value=value, type=str(type(value)))
            return AuthStruct.NONE

        except Exception as exc:
            # Absolute last‑resort guard: RBAC must never crash the app
            log.error("authstruct_from_label_exception", value=value, error=str(exc))
            return AuthStruct.NONE

    @classmethod
    def normalize_list(cls, values: Optional[Iterable[Any]]) -> List[AuthStruct]:
        """
        Normalize a list of role labels/ints/AuthStruct into AuthStruct instances.

        - None → []
        - Any invalid entry → mapped to NONE (with logging)
        """
        if not values:
            return []
        normalized: List[AuthStruct] = []
        for v in values:
            try:
                normalized.append(cls.from_label(v))
            except Exception as exc:
                log.error("authstruct_normalize_list_exception", value=v, error=str(exc))
                normalized.append(AuthStruct.NONE)
        return normalized

    @classmethod
    def highest_role(cls, values: Optional[Iterable[Any]]) -> AuthStruct:
        """
        Return the highest role from a list of roles.

        - Empty/None → NONE
        - Any invalid entries are normalized to NONE
        """
        try:
            roles = cls.normalize_list(values)
            if not roles:
                return AuthStruct.NONE
            return max(roles, key=lambda r: r.value)
        except Exception as exc:
            log.error("authstruct_highest_role_exception", values=list(values or []), error=str(exc))
            return AuthStruct.NONE

    # ---------------------------------------------------------------
    # RBAC logic
    # ---------------------------------------------------------------

    def can_access(self, required: Any) -> bool:
        """
        Hierarchical RBAC check.

        - required can be AuthStruct/int/str
        - Any invalid required value → treated as NONE (most permissive)
        """
        try:
            if not isinstance(required, AuthStruct):
                required = AuthStruct.from_label(required)
            return self.value >= required.value
        except Exception as exc:
            log.error(
                "authstruct_can_access_exception",
                self_value=int(self),
                required=required,
                error=str(exc),
            )
            # Fail closed: if RBAC logic fails, deny access
            return False

    @classmethod
    def has_any_role(cls, user_roles: Optional[Iterable[Any]], required_roles: Optional[Iterable[Any]]) -> bool:
        """
        True if the user has ANY of the required roles.

        - required_roles empty/None → public page → True
        - user_roles empty/None → False (unless public)
        """
        try:
            if not required_roles:
                return True  # public page

            if not user_roles:
                return False

            user = cls.highest_role(user_roles)
            required = cls.normalize_list(required_roles)
            return any(user.can_access(r) for r in required)
        except Exception as exc:
            log.error(
                "authstruct_has_any_role_exception",
                user_roles=list(user_roles or []),
                required_roles=list(required_roles or []),
                error=str(exc),
            )
            # Fail closed: deny access on RBAC failure
            return False

    @classmethod
    def has_all_roles(cls, user_roles: Optional[Iterable[Any]], required_roles: Optional[Iterable[Any]]) -> bool:
        """
        True if the user has ALL required roles.

        - required_roles empty/None → public page → True
        - user_roles empty/None → False (unless public)
        """
        try:
            if not required_roles:
                return True

            if not user_roles:
                return False

            user = cls.highest_role(user_roles)
            required = cls.normalize_list(required_roles)
            return all(user.can_access(r) for r in required)
        except Exception as exc:
            log.error(
                "authstruct_has_all_roles_exception",
                user_roles=list(user_roles or []),
                required_roles=list(required_roles or []),
                error=str(exc),
            )
            # Fail closed: deny access on RBAC failure
            return False

    # ---------------------------------------------------------------
    # Convenience flags
    # ---------------------------------------------------------------

    @property
    def is_admin(self) -> bool:
        try:
            return self.value >= AuthStruct.ADMIN.value
        except Exception as exc:
            log.error("authstruct_is_admin_exception", value=int(self), error=str(exc))
            return False

    @property
    def is_superadmin(self) -> bool:
        try:
            return self.value >= AuthStruct.SUPERADMIN.value
        except Exception as exc:
            log.error("authstruct_is_superadmin_exception", value=int(self), error=str(exc))
            return False


# ---------------------------------------------------------------
# Public helper
# ---------------------------------------------------------------

def user_can_access(user: Optional[UserStruct], required_roles: Optional[Iterable[Any]]) -> bool:
    """
    Evaluate whether a user can access a page.

    - Anonymous users:
        - required_roles empty/None → True (public)
        - otherwise → False
    - Authenticated users:
        - use hierarchical RBAC via AuthStruct.has_any_role
    """
    try:
        if user is None:
            return False if required_roles else True

        return AuthStruct.has_any_role(user.roles, required_roles)
    except Exception as exc:
        log.error(
            "user_can_access_exception",
            user=user.username if user else None,
            roles=getattr(user, "roles", None),
            required_roles=list(required_roles or []),
            error=str(exc),
        )
        # Fail closed: deny access on RBAC failure
        return False
