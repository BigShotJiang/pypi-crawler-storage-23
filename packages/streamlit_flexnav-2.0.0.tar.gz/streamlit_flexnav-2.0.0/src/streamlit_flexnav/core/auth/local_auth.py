# streamlit_flexnav/core/auth/local_auth.py
# 2026-02-26 — LocalAuthBackend (admin/admin first login + first-login flow)

from __future__ import annotations

from pathlib import Path
from typing import Optional

import streamlit as st

from streamlit_flexnav.core.auth.base_auth import BaseAuthBackend
from streamlit_flexnav.core.auth.user_store import UserStore
from streamlit_flexnav.core.auth.userstruct import UserStruct
from streamlit_flexnav.core.auth.passwords import verify_password


class LocalAuthBackend(BaseAuthBackend):
    """
    Local authentication backend using encrypted YAML (UserStore).
    Supports:
      - admin/admin bootstrap login
      - first-login forced password change
      - removal of first_login after first login
    """

    def __init__(self, root_path: Path):
        self.root_path = Path(root_path)
        self.store = UserStore(self.root_path)

    # ---------------------------------------------------------
    # Session handling
    # ---------------------------------------------------------
    def _set_session(self, user: UserStruct) -> None:
        st.session_state["user"] = user

    def _clear_session(self) -> None:
        st.session_state.pop("user", None)

    def current_user(self) -> Optional[UserStruct]:
        user = st.session_state.get("user")
        if isinstance(user, UserStruct):
            return user
        return None

    # ---------------------------------------------------------
    # FlexNav 2.0 API
    # ---------------------------------------------------------
    def get_current_user(self) -> Optional[UserStruct]:
        return self.current_user()

    def get_login_page(self):
        class LoginPage:
            def render_fn(_, ctx):
                st.title("Login")

                username = st.text_input("Username")
                password = st.text_input("Password", type="password")

                if st.button("Login"):
                    if ctx.auth.login(username, password):
                        st.rerun()
                    else:
                        st.error("Invalid username or password")

        return LoginPage()

    def get_first_login_page(self):
        class FirstLoginPage:
            def render_fn(_, ctx):
                st.title("Set a new password")

                new1 = st.text_input("New password", type="password")
                new2 = st.text_input("Confirm new password", type="password")

                if st.button("Update password"):
                    if not new1:
                        st.error("Password cannot be empty.")
                        return
                    if new1 != new2:
                        st.error("Passwords do not match.")
                        return

                    user = ctx.auth.get_current_user()
                    if not user:
                        st.error("No active user in session.")
                        return

                    # Update password + remove first_login
                    ctx.auth.update_password(user.username, new1)
                    ctx.auth.mark_first_login_complete(user.username)

                    # Reload user from store
                    updated = ctx.auth.store.lookup_user(user.username)

                    ctx.auth._set_session(
                        UserStruct(
                            username=updated["username"],
                            roles=updated.get("roles", []) or [],
                            first_login=False,
                        )
                    )

                    st.success("Password updated successfully.")
                    st.rerun()

        return FirstLoginPage()

    def logout(self) -> None:
        self._clear_session()
        st.rerun()

    # ---------------------------------------------------------
    # Authentication
    # ---------------------------------------------------------
    def authenticate(self, username: str, password: str) -> Optional[UserStruct]:
        raw = self.store.lookup_user(username)
        if not raw:
            return None

        stored_hash = raw.get("password")
        first_login = raw.get("first_login", None)

        # ---------------------------------------------------------
        # FIRST LOGIN: admin/admin
        # ---------------------------------------------------------
        if first_login is True and username == "admin" and password == "admin":
            return UserStruct(
                username="admin",
                roles=raw.get("roles", []) or [],
                first_login=True,
            )

        # ---------------------------------------------------------
        # NORMAL LOGIN
        # ---------------------------------------------------------
        if not stored_hash:
            return None

        if not verify_password(stored_hash, password):
            return None

        return UserStruct(
            username=raw["username"],
            roles=raw.get("roles", []) or [],
            first_login=False,
        )

    def login(self, username: str, password: str) -> bool:
        user = self.authenticate(username, password)
        if not user:
            return False
        self._set_session(user)
        return True

    # ---------------------------------------------------------
    # First-login helpers
    # ---------------------------------------------------------
    def update_password(self, username: str, new_password: str) -> None:
        self.store.update_password(username, new_password)

    def mark_first_login_complete(self, username: str) -> None:
        self.store.mark_first_login_complete(username)
