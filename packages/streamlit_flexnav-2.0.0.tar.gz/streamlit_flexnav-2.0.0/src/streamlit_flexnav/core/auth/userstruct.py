from __future__ import annotations

from typing import List

from pydantic import BaseModel, Field


class UserStruct(BaseModel):
    """
    Canonical FlexNav user object.
    """
    id : str
    username: str
    roles: List[str] = Field(default_factory=list)
    first_login: bool = Field(default=True)

    def has_role(self, role: str) -> bool:
        return role in self.roles

    def is_superadmin(self) -> bool:
        return "superadmin" in self.roles
