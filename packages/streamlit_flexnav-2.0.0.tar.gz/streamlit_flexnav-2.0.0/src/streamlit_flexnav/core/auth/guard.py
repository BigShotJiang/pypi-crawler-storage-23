from __future__ import annotations

from typing import Iterable, List

import streamlit as st

from streamlit_flexnav.core.auth.userstruct import UserStruct
from streamlit_flexnav.core.auth.rbac import user_can_access


def get_current_user() -> UserStruct | None:
    user = st.session_state.get("user")
    if isinstance(user, UserStruct):
        return user
    return None


def set_current_user(user: UserStruct | None) -> None:
    """
    Store the authenticated user in session_state.

    Passing None clears the user implicitly, but clear_current_user()
    is the explicit API for that.
    """
    if user is None:
        st.session_state.pop("user", None)
    else:
        st.session_state["user"] = user


def clear_current_user() -> None:
    """
    Remove the current user from session_state.
    """
    st.session_state.pop("user", None)


def ensure_access(required_roles: Iterable[str]) -> None:
    """
    Guard to be called at the top of each page.

    - Redirects to login if no user
    - Redirects to reset_password if first_login
    - Redirects to unauthorized if RBAC fails
    """
    user = get_current_user()

    # No user → login
    if user is None:
        st.switch_page("internal/auth/logon")
        return

    # First login → force password reset
    if user.first_login:
        st.switch_page("internal/account/reset_password")
        return

    # RBAC
    required: List[str] = list(required_roles or [])
    if not user_can_access(user, required):
        st.switch_page("internal/auth/unauthorized")
        return
