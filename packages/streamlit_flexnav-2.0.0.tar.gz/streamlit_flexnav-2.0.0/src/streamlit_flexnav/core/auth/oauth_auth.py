# streamlit_flexnav/core/auth/oauth_auth.py
# 2026-02-23

from __future__ import annotations

from typing import Optional, Dict, Any

import streamlit as st

from streamlit_flexnav.core.auth.userstruct import UserStruct
from streamlit_flexnav.core.auth.backend import AuthBackend


class OAuthBackend:
    """
    Minimal OAuth backend for FlexNav.

    Responsibilities:
      - Render login button
      - Handle OAuth callback
      - Create a UserStruct and store it in session
      - Assign default roles from settings
    """

    def __init__(self, settings: Dict[str, Any], root_path):
        self.settings = settings
        self.backend = AuthBackend(root_path)

    # ---------------------------------------------------------
    # UI
    # ---------------------------------------------------------
    def login_button(self) -> None:
        """
        Render a simple OAuth login link.
        """
        try:
            auth_url = self.settings["authorize_url"]
            client_id = self.settings["client_id"]
            redirect = self.settings["redirect_uri"]
        except KeyError as e:
            st.error(f"OAuth configuration missing: {e}")
            return

        st.markdown(
            f"[Login with OAuth]({auth_url}?client_id={client_id}&redirect_uri={redirect})"
        )

    # ---------------------------------------------------------
    # Callback handler
    # ---------------------------------------------------------
    def handle_callback(self, token: Dict[str, Any]) -> Optional[UserStruct]:
        """
        Handle OAuth callback token and create a session user.

        Expected token fields:
          - email
          - sub (fallback)
        """
        username = token.get("email") or token.get("sub")
        if not username:
            st.error("OAuth callback did not include an email or subject identifier.")
            return None

        roles = self.settings.get("default_roles", ["viewer"])

        user = UserStruct(
            username=username,
            roles=roles,
            first_login=False,  # OAuth users do not require password reset
        )

        self.backend._set_session(user)
        return user

    # ---------------------------------------------------------
    # Compatibility method (not used)
    # ---------------------------------------------------------
    def authenticate(self, username: str, password: str) -> None:
        """
        OAuth does not use username/password authentication.
        Included only for interface compatibility.
        """
        return None
