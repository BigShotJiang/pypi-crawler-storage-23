# streamlit_flexnav/core/auth/base_auth.py
# 2026-02-26 — FlexNav 2.0 unified auth interface

from __future__ import annotations
from typing import Optional


class BaseAuthBackend:
    """
    Canonical FlexNav 2.0 authentication interface.
    All backends must implement these methods.
    """

    # ---------------------------------------------------------
    # Required
    # ---------------------------------------------------------
    def get_current_user(self):
        raise NotImplementedError

    def get_login_page(self):
        raise NotImplementedError

    def logout(self):
        raise NotImplementedError

    # ---------------------------------------------------------
    # Optional (LocalAuth overrides this)
    # ---------------------------------------------------------
    def get_first_login_page(self):
        return None

    # ---------------------------------------------------------
    # Optional (LocalAuth overrides this)
    # ---------------------------------------------------------
    def authenticate(self, username: str, password: str):
        return None
