from __future__ import annotations

from argon2 import PasswordHasher

_ph = PasswordHasher()


def hash_password(password: str) -> str:
    """
    Hash a plaintext password using Argon2.

    Raises:
        Exception: if hashing fails (rare, usually configuration issues).
    """
    return _ph.hash(password)


def verify_password(stored_hash: str, password: str) -> bool:
    """
    Verify a plaintext password against a stored Argon2 hash.

    Returns:
        bool: True if the password matches, False otherwise.
    """
    try:
        return _ph.verify(stored_hash, password)
    except Exception:
        return False
