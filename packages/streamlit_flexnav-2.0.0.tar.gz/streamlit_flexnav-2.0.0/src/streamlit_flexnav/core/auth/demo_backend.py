# flexnav/auth/demo_backend.py

from streamlit_flexnav.core.auth.base_auth import BaseAuthBackend
from streamlit_flexnav.core.auth.userstruct import UserStruct

class DemoAuthBackend(BaseAuthBackend):
    async def authenticate(self, request) -> UserStruct | None:
        # Demo user with full privileges
        return UserStruct(
            id="demo",
            username="demo_user",
            roles=["superadmin"]
        )
