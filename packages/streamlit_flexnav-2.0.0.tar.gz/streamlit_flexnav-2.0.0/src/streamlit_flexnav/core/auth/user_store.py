from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml
from cryptography.fernet import Fernet

from streamlit_flexnav.core.auth.passwords import hash_password


class UserStore:
    """
    Encrypted user store backed by YAML + Fernet.

    File layout inside `root`:
      - users.yaml.enc : encrypted user data
      - users.key      : symmetric encryption key
    """

    def __init__(self, root: Path):
        self.root = Path(root)
        self.enc_file = self.root / "users.yaml.enc"
        self.key_file = self.root / "users.key"

        self.root.mkdir(parents=True, exist_ok=True)

        if not self.key_file.exists():
            self._generate_key()

        self.fernet = Fernet(self.key_file.read_bytes())

        if not self.enc_file.exists():
            self._bootstrap_admin_user()

    # ---------------------------------------------------------
    # Key handling
    # ---------------------------------------------------------
    def _generate_key(self) -> None:
        key = Fernet.generate_key()
        self.key_file.write_bytes(key)

    # ---------------------------------------------------------
    # Bootstrap default admin user
    # ---------------------------------------------------------
    def _bootstrap_admin_user(self) -> None:
        default = {
            "users": [
                {
                    "username": "flexadmin",
                    "password": hash_password("flexadmin"),
                    "roles": ["superadmin"],
                    "first_login": True,
                }
            ]
        }
        self._save(default)

    # ---------------------------------------------------------
    # Load / Save encrypted YAML
    # ---------------------------------------------------------
    def _load(self) -> Dict[str, Any]:
        if not self.enc_file.exists():
            return {"users": []}

        encrypted = self.enc_file.read_bytes()
        decrypted = self.fernet.decrypt(encrypted)
        data = yaml.safe_load(decrypted) or {}
        data.setdefault("users", [])
        return data

    def _save(self, data: Dict[str, Any]) -> None:
        data.setdefault("users", [])
        raw = yaml.safe_dump(data).encode("utf-8")
        encrypted = self.fernet.encrypt(raw)
        self.enc_file.write_bytes(encrypted)

    # ---------------------------------------------------------
    # CRUD operations
    # ---------------------------------------------------------
    def list_users(self) -> List[Dict[str, Any]]:
        return self._load().get("users", [])

    def lookup_user(self, username: str) -> Optional[Dict[str, Any]]:
        data = self._load()
        for u in data.get("users", []):
            if u.get("username") == username:
                return u
        return None

    def add_user(self, username: str, roles: List[str], password: Optional[str] = None) -> None:
        data = self._load()
        data.setdefault("users", [])

        if any(u.get("username") == username for u in data["users"]):
            raise ValueError(f"User '{username}' already exists")

        data["users"].append(
            {
                "username": username,
                "password": hash_password(password or "changeme"),
                "roles": roles or [],
                "first_login": True,
            }
        )
        self._save(data)

    def update_user_roles(self, username: str, roles: List[str]) -> None:
        data = self._load()
        found = False
        for u in data.get("users", []):
            if u.get("username") == username:
                u["roles"] = roles or []
                found = True
                break
        if not found:
            raise ValueError(f"User '{username}' not found")
        self._save(data)

    def delete_user(self, username: str) -> None:
        data = self._load()
        before = len(data.get("users", []))
        data["users"] = [u for u in data.get("users", []) if u.get("username") != username]
        after = len(data["users"])
        if before == after:
            raise ValueError(f"User '{username}' not found")
        self._save(data)

    def update_password(self, username: str, new_password: str) -> None:
        data = self._load()
        found = False
        for u in data.get("users", []):
            if u.get("username") == username:
                u["password"] = hash_password(new_password)
                found = True
                break
        if not found:
            raise ValueError(f"User '{username}' not found")
        self._save(data)

    def mark_first_login_complete(self, username: str) -> None:
        users = self._load()
        if username in users:
            users[username].pop("first_login", None)  # REMOVE the field entirely
            self._save(users)

