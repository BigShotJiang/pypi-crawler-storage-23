# streamlit_flexnav/core/models/runtime_settings.py
# 2026-02-26 — FlexNav 2.0 (PageStruct + MenuStruct, clean)
from __future__ import annotations
from pathlib import Path
from typing import Dict, List, Optional, Literal
from pydantic import BaseModel, Field, ConfigDict

import streamlit_flexnav

from streamlit_flexnav.core.models.pagestruct import PageStruct
from streamlit_flexnav.core.models.menustruct import MenuStruct
from streamlit_flexnav.core.models.authentication import (
    AuthMode,
    OAuthConfig,
    AuthenticationSettings,
)

# ---------------------------------------------------------
# FlexNav block (matches YAML)
# ---------------------------------------------------------
class FlexNavConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")
    menupages: str
    env: str
    menulocation: Literal["sidebar", "top"] = "sidebar"

    authentication: AuthenticationSettings

# ---------------------------------------------------------
# Logging
# ---------------------------------------------------------
class LoggingConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    to_file: bool
    file_path: Optional[str] = None
    level: str = "INFO"


# ---------------------------------------------------------
# Runtime Settings (single, final version)
# ---------------------------------------------------------
class RuntimeSettings(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
        arbitrary_types_allowed=True,
        frozen=True,
    )

    # YAML blocks
    flexnav: FlexNavConfig
    oauth: OAuthConfig
    logging: LoggingConfig

    # Derived paths
    app_root: Path
    menupages_root: Path
    internal_root: Path

    # Loaded metadata
    menu_metadata: Dict[str, MenuStruct] = Field(default_factory=dict)
    pages: List[PageStruct] = Field(default_factory=list)


    # Session + environment
    env: Optional[str] = None
    profile: str = "default"
    current_user_roles: List[str] = Field(default_factory=list)



    @property
    def authentication(self) -> AuthenticationSettings:
        return self.flexnav.authentication

    @property
    def auth_enabled(self) -> bool:
        return self.authentication.mode != AuthMode.NONE

    # Factory used by config_loader
    @classmethod
    def from_config(
        cls,
        base: Path,
        config: dict,
    ) -> "RuntimeSettings":

        flexnav = FlexNavConfig(**config["flexnav"])
        oauth = OAuthConfig(**config["oauth"])
        logging = LoggingConfig(**config["logging"])

        base = base.resolve()

        menupages_root = (base / flexnav.menupages).resolve()
        # internal lives under the installed package
        package_root = Path(streamlit_flexnav.__file__).parent 
        internal_root = (package_root / "internal").resolve()        

        menupages_root.mkdir(parents=True, exist_ok=True)
        # internal_root.mkdir(parents=True, exist_ok=True)

        return cls(
            flexnav=flexnav,
            oauth=oauth,
            logging=logging,
            app_root=base,
            menupages_root=menupages_root,
            internal_root=internal_root,
            env=flexnav.env,
            profile="default"
        )
