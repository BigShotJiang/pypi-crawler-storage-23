# streamlit_flexnav/core/models/authentication.py
# 2026-02-26 — FlexNav 2.0 (final authentication schema)

from __future__ import annotations

from typing import Optional, List
from pydantic import BaseModel
from enum import Enum


class AuthMode(str, Enum):
    NONE = "none"
    LOCAL = "local"
    OAUTH = "oauth"
    DATABASE = "database"


# ---------------------------------------------------------
# Local authentication
# ---------------------------------------------------------

class LocalAuthConfig(BaseModel):
    users_file: str


# ---------------------------------------------------------
# OAuth authentication
# ---------------------------------------------------------

class OAuthConfig(BaseModel):
    enabled: bool = False
    provider: str = "google"
    client_id: str = ""
    client_secret: str = ""
    redirect_uri: str = "http://localhost:8501"
    scopes: List[str] = ["openid", "email", "profile"]
    auth_url: Optional[str] = None
    token_url: Optional[str] = None
    userinfo_url: Optional[str] = None


# ---------------------------------------------------------
# Database authentication
# ---------------------------------------------------------

class DatabaseAuthConfig(BaseModel):
    connection_string: str
    users_table: str
    roles_table: str


# ---------------------------------------------------------
# AuthenticationSettings (root)
# ---------------------------------------------------------

class AuthenticationSettings(BaseModel):
    mode: AuthMode = AuthMode.NONE
    local: Optional[LocalAuthConfig] = None
    oauth: Optional[OAuthConfig] = None
    database: Optional[DatabaseAuthConfig] = None
