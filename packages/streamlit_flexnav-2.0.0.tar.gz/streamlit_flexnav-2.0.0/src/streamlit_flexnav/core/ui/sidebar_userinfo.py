# streamlit_flexnav/core/ui/sidebar_userinfo.py
# 2026-02-18 03:05 CET

from __future__ import annotations

import streamlit as st
from streamlit_flexnav.core.state import get_runtime


def render_sidebar_userinfo() -> None:
    runtime = get_runtime()
    auth = getattr(runtime, "auth", None)

    if not auth:
        return

    user = getattr(auth, "current_user", None)
    roles = auth.get_roles() if hasattr(auth, "get_roles") else []

    with st.sidebar:
        if user:
            st.markdown(f"**Logged in as:** {user}")
            if roles:
                st.caption(f"Roles: {', '.join(roles)}")
        else:
            st.caption("Not logged in.")
