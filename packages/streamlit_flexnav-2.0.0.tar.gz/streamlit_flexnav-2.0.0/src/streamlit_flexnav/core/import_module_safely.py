import importlib.util
import sys
from pathlib import Path


def import_module_safely(path: Path):
    """
    Import a Python module from a file path without polluting sys.modules.

    - Each import gets a unique module name
    - No collisions with other modules
    - No permanent entries in sys.modules
    - Clean error messages
    """

    if not path.exists():
        raise FileNotFoundError(f"Cannot import module: file not found: {path}")

    module_name = f"flexnav_dynamic_{path.stem}_{abs(hash(path))}"

    spec = importlib.util.spec_from_file_location(module_name, str(path))
    if spec is None:
        raise ImportError(f"Could not load spec for module at {path}")

    module = importlib.util.module_from_spec(spec)

    try:
        loader = spec.loader
        if loader is None:
            raise ImportError(f"No loader available for module at {path}")

        loader.exec_module(module)
    except Exception as e:
        raise ImportError(f"Error importing module {path}: {e}") from e

    return module
