# streamlit_flexnav/core/state.py
# 2026-02-15 17:45 CET

from __future__ import annotations

import streamlit as st
from pathlib import Path

from streamlit_flexnav.core.loaders.config_loader import load_config, to_runtime_settings
from streamlit_flexnav.core.loaders.load_all import load_all
from streamlit_flexnav.core.models.runtime_settings import RuntimeSettings

RUNTIME_KEY = "_flexnav_runtime"

# streamlit_flexnav/core/state.py

def get_runtime() -> RuntimeSettings:
    runtime = st.session_state.get("_flexnav_runtime")
    if runtime is None:
        raise RuntimeError("FlexNav runtime not initialized. run_flexnav() must be called first.")
    return runtime

def old_get_runtime() -> "RuntimeSettings":
    """
    Return the global RuntimeSettings instance for this Streamlit session.

    - Created once per session
    - Stored in st.session_state
    - Immutable after creation (load_all returns new copies)
    """

    if RUNTIME_KEY not in st.session_state:
        # 1) Load YAML config
        base = Path(__file__).parent
        cfg = load_config(base / "configs" / "flexnav_config.yaml")

        # 2) Build initial RuntimeSettings
        runtime = to_runtime_settings(cfg, base)

        # 3) Run full FlexNav pipeline
        runtime = load_all(runtime)

        # 4) Store in session_state
        st.session_state[RUNTIME_KEY] = runtime

    return st.session_state[RUNTIME_KEY]
