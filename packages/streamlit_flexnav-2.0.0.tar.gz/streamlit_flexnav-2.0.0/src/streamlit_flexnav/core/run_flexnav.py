# streamlit_flexnav/core/run_flexnav.py
# 2026-02-26 — FlexNav 2.0 (grouped UI + auth + first-login)

from __future__ import annotations

from pathlib import Path
import streamlit as st
import structlog

from streamlit_flexnav.core.logging import configure_logging
from streamlit_flexnav.core.loaders.config_loader import load_config, to_runtime_settings
from streamlit_flexnav.core.loaders.load_all import load_all
from streamlit_flexnav.core.menu_builder import build_grouped_pages

# Auth
from streamlit_flexnav.core.auth.local_auth import LocalAuthBackend
from streamlit_flexnav.core.auth.no_auth import NoAuthBackend
from streamlit_flexnav.core.auth.oauth_auth import OAuthBackend
from streamlit_flexnav.core.auth.db_auth import DatabaseAuthBackend
from streamlit_flexnav.core.models.authentication import AuthMode

# Watchers
from streamlit_flexnav.core.watchers.menupage_watcher import menupages_changed
from streamlit_flexnav.core.watchers.module_invalidator import invalidate_menupage_modules

log = structlog.get_logger().bind(component="run_flexnav")

def attach_auth_backend(runtime):
    mode = runtime.authentication.mode if runtime.authentication else AuthMode.NONE

    if mode == AuthMode.LOCAL:
        store_path = runtime.app_root / "configs"
        auth = LocalAuthBackend(store_path)
        store = auth.store
    elif mode == AuthMode.OAUTH:
        auth = OAuthBackend(runtime.authentication.oauth)
        store = None
    elif mode == AuthMode.DATABASE:
        auth = DatabaseAuthBackend(runtime.authentication.database)
        store = None
    else:
        auth = NoAuthBackend()
        store = None

    class FlexNavContext:
        def __init__(self, runtime, auth, store=None):
            self.runtime = runtime
            self.auth = auth
            self.store = store

    return FlexNavContext(runtime, auth, store)


def run_flexnav(app_root: Path, config_path: Path | None = None) -> None:
    if config_path is None:
        config_path = app_root / "configs" / "flexnav_config.yaml"

    configure_logging()
    log.info("flexnav_start", app_root=str(app_root))

    # 0) Detect changes BEFORE loading anything
    menupages_root = app_root / "menupages"
    if menupages_changed(menupages_root):
        invalidate_menupage_modules(menupages_root)
        st.rerun()

    # 1) Load config
    cfg = load_config(config_path)

    # 2) Build initial RuntimeSettings
    runtime = to_runtime_settings(cfg, app_root)
    st.session_state["_flexnav_runtime"] = runtime

    # 3) Attach authentication backend
    ctx = attach_auth_backend(runtime)

    # 4) Authentication gate (FINAL, CORRECT ORDER)
    if ctx.runtime.authentication and ctx.runtime.authentication.mode != AuthMode.NONE:
        user = ctx.auth.get_current_user()

        # Not logged in → show login page
        if user is None:
            login_page = ctx.auth.get_login_page()
            login_page.render_fn(ctx)
            return

        # First-time login → force password change
        if getattr(user, "first_login", False):
            first_login_page = ctx.auth.get_first_login_page()
            first_login_page.render_fn(ctx)
            return

    # 5) Load metadata (PageStruct + MenuStruct)
    runtime = load_all(runtime)

    # 6) Build grouped, RBAC-filtered pages
    grouped_pages = build_grouped_pages(runtime)

    if not grouped_pages:
        st.error("No pages available. Check your menupages configuration.")
        return

    # 7) Convert grouped PageStruct → grouped st.Page
    menu_tree: dict[str, list[st.Page]] = {}
    
    log.info("=== DEBUG: ALL GROUPED PAGES BEFORE STREAMLIT CONVERSION ===")

    for group_label, pages in grouped_pages.items():
        log.info("group_start", group=group_label, count=len(pages))     
        log.info("grouped_pages_keys", keys=list(grouped_pages.keys()))           

        label = group_label or "Main"
        st_pages: list[st.Page] = []

        for p in pages:
            st_pages.append(
                st.Page(
                    p.file,
                    title=p.label,
                    icon=p.icon,
                )
            )

        if st_pages:
            menu_tree[label] = st_pages

    if not menu_tree:
        st.error("No pages available after conversion.")
        return
    # log.info("menu_tree", group=menu_tree, count=len(pages)) 
    # 8) Grouped navigation via st.navigation
    log.info( runtime.flexnav.menulocation )

    if runtime.flexnav.menulocation == "sidebar":
        nav = st.navigation(pages=menu_tree, position="sidebar")
    else:
        nav = st.navigation(pages=menu_tree, position="top")
    # nav = st.navigation(pages=menu_tree, position="top")

    # 9) Run selected page
    nav.run()
