from streamlit_flexnav.core.models.menustruct import MenuStruct


def menu() -> MenuStruct:
    return MenuStruct(
        label="Account",
        icon="👤",
        color="blue",
        bold=True,
        italic=False,
        order=9000,
    )
