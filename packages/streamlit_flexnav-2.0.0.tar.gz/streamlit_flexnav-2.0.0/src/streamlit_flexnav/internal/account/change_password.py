import streamlit as st
from streamlit_flexnav.core.models.pagestruct import PageStruct
from streamlit_flexnav.core.auth.guard import get_current_user
from streamlit_flexnav.core.auth.backend import AuthBackend


def page() -> PageStruct:
    return PageStruct(
        label="Change Password",
        required_roles=[],
        order=9001,        
    )


def render():
    st.title("🔑 Change Password")

    current = get_current_user()
    if current is None:
        st.warning("You must be logged in to change your password.")
        return

    root = st.session_state.get("auth_root")
    if root is None:
        st.error("Authentication root path is not configured.")
        return

    backend = AuthBackend(root)
    store = backend.store

    new_pw = st.text_input("New password", type="password")
    confirm_pw = st.text_input("Confirm password", type="password")

    if st.button("Change password"):
        if not new_pw or not confirm_pw:
            st.error("Both fields are required.")
        elif new_pw != confirm_pw:
            st.error("Passwords do not match.")
        else:
            try:
                store.update_password(current.username, new_pw)
            except Exception as e:
                st.error("Failed to change password: %s" % e)
            else:
                st.success("Password changed successfully.")
                st.rerun()


if __name__ == "__main__":
    render()
