import streamlit as st
from streamlit_flexnav.core.models.pagestruct import PageStruct
from streamlit_flexnav.core.auth.guard import get_current_user
from streamlit_flexnav.core.auth.backend import AuthBackend
from streamlit_flexnav.core.auth.guard import get_current_user

def page() -> PageStruct:
    return PageStruct(
        label="Reset Password (Admin)",
        required_roles=["admin"],
        order=9002,                
    )


def render():
    st.title("🧰 Reset Password (Admin)")

    current = get_current_user()
    if current is None:
        st.warning("You must be logged in as admin to reset passwords.")
        return

    root = st.session_state.get("auth_root")
    if root is None:
        st.error("Authentication root path is not configured.")
        return

    backend = AuthBackend(root)
    store = backend.store

    try:
        users = store.list_users()
    except Exception as e:
        st.error("Failed to load users: %s" % e)
        return

    usernames = [u.get("username") for u in users]
    if not usernames:
        st.info("No users available.")
        return

    target = st.selectbox("Select user", usernames)
    new_pw = st.text_input("New password", type="password")

    if st.button("Reset password"):
        if not new_pw:
            st.error("New password is required.")
        else:
            try:
                store.update_password(target, new_pw)
            except Exception as e:
                st.error("Failed to reset password: %s" % e)
            else:
                st.success("Password reset for '%s'." % target)
                st.rerun()


if __name__ == "__main__":
    render()
