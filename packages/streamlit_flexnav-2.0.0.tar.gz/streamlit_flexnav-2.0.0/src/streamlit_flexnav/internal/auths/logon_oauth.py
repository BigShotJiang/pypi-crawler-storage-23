# internal/auth/logon_oauth.py

import streamlit as st
from streamlit_flexnav.core.auth.oauth_auth import OAuthBackend
from streamlit_flexnav.core.auth.guard import get_current_user

def render():
    st.title("Sign in with OAuth")

    current = get_current_user()
    if current is None:
        st.warning("You must be logged in to connect to OAUTH.")
        return
    root = st.session_state.get("auth_root")
    oauth_settings = st.session_state.get("oauth_settings")

    if not root or not oauth_settings:
        st.error("OAuth is not configured.")
        return

    backend = OAuthBackend(oauth_settings, root)
    backend.login_button()

if __name__ == "__main__":
    render()