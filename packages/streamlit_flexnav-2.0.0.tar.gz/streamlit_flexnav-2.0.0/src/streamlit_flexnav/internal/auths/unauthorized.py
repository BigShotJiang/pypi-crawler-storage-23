import streamlit as st
from streamlit_flexnav.core.models.pagestruct import PageStruct

def page() -> PageStruct:
    return PageStruct(
        label="Unauthorized",
        required_roles=["viewer"],
    )

def render():
    st.title("⛔ Unauthorized")
    st.error("You do not have permission to access this page.")

if __name__ == "__main__":
    render()
