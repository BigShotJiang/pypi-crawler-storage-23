import streamlit as st

from streamlit_flexnav.core.auth.backend import AuthBackend
from streamlit_flexnav.core.models.pagestruct import PageStruct
from streamlit_flexnav.core.auth.guard import clear_current_user
from streamlit_flexnav.core.auth.guard import get_current_user
def page() -> PageStruct:
    return PageStruct(
        label="Logout",
        required_roles=["viewer"],
    )

def render():
    st.title("Signed out")
    current = get_current_user()
    if current is None:
        st.warning("You must be logged to logout.")
        return
    root = st.session_state.get("auth_root")
    if root is None:
        st.error("Authentication root path is not configured.")
        return

    backend = AuthBackend(root)
    try:
        backend.logout()
    except Exception as e:
        st.error(f"Logout failed: {e}")
        return

    st.success("You have been signed out.")
    st.info("Redirecting to login…")
    clear_current_user()
    st.switch_page("internal/auth/logon")

if __name__ == "__main__":
    render()