# internal/auth/oauth_callback.py
# 2026-02-23

from __future__ import annotations

import streamlit as st
from urllib.parse import parse_qs, urlparse

from streamlit_flexnav.core.auth.oauth_auth import OAuthBackend
from streamlit_flexnav.core.auth.guard import set_current_user
from streamlit_flexnav.core.models.pagestruct import PageStruct
from streamlit_flexnav.core.auth.guard import get_current_user

def page():
    return PageStruct(
        label="OAuth",
        order=9610,
        path=__file__,
        required_roles=["viewer"],  # any authenticated user
        group="auth",
    )


def render():
    st.title("Completing OAuth login…")
    current = get_current_user()
    if current is None:
        st.warning("You must be logged in to manage users.")
        return
    root = st.session_state.get("auth_root")
    oauth_settings = st.session_state.get("oauth_settings")

    if not root or not oauth_settings:
        st.error("OAuth is not configured.")
        return

    backend = OAuthBackend(oauth_settings, root)

    # ---------------------------------------------------------
    # Extract token parameters from query string
    # ---------------------------------------------------------
    query = st.query_params
    token = {}

    for key, value in query.items():
        token[key] = value

    if not token:
        st.error("OAuth callback did not include any token parameters.")
        return

    # ---------------------------------------------------------
    # Validate token and create user
    # ---------------------------------------------------------
    user = backend.handle_callback(token)
    if not user:
        st.error("OAuth login failed.")
        return

    # ---------------------------------------------------------
    # Store user in session
    # ---------------------------------------------------------
    set_current_user(user)

    st.success(f"Welcome, {user.username}")
    st.rerun()


if __name__ == "__main__":
    render()
