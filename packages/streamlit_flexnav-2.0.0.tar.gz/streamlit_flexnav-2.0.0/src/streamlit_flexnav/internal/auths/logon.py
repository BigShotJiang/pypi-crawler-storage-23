import streamlit as st

from streamlit_flexnav.core.auth.backend import AuthBackend
from streamlit_flexnav.core.models.pagestruct import PageStruct
from streamlit_flexnav.core.auth.guard import set_current_user
from streamlit_flexnav.core.auth.guard import get_current_user

def page() -> PageStruct:
    return PageStruct(
        label="Logon",
        required_roles=[],
    )

def render():
    st.title("Sign in")

    root = st.session_state.get("auth_root")
    if root is None:
        st.error("Authentication root path is not configured.")
        return

    backend = AuthBackend(root)

    username = st.text_input("Username")
    password = st.text_input("Password", type="password")

    if st.button("Sign in"):
        try:
            ok = backend.login(username, password)
        except Exception as e:
            st.error(f"Authentication failed: {e}")
            return

        if not ok:
            st.error("Invalid username or password")
            return

        user = backend.current_user()
        if user and user.first_login:
            st.success("Signed in. Please set a new password.")
            st.switch_page("internal/account/reset_password")
            return
        set_current_user(user)
        st.success("Signed in successfully.")
        st.rerun()
        
if __name__ == "__main__":
    render()
