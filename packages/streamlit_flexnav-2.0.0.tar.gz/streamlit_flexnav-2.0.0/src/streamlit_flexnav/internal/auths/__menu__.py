from streamlit_flexnav.core.models.menustruct import MenuStruct


def menu() -> MenuStruct:
    return MenuStruct(
        label="Authorisation",
        icon="🔐",
        color="green",
        bold=True,
        italic=False,
        order=9600,
    )
