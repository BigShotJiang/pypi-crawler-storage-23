# 2026-02-26 — Internal pages are auto-discovered by loaders

# Intentionally empty:
# - menustruct_loader discovers internal/*/__menu__.py
# - pagestruct_loader discovers internal/*/*.py
