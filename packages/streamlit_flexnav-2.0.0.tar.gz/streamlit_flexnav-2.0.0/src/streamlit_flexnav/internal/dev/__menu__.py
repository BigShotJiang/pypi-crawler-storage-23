from streamlit_flexnav.core.models.menustruct import MenuStruct


def menu() -> MenuStruct:
    return MenuStruct(
        label="Dev Tools",
        icon="🛠️",
        color="purple",
        bold=False,
        italic=False,
        order=9800,
    )
