# internal/dev/log_viewer.py
# 2026-02-22

import json
import re
import time
from pathlib import Path

import streamlit as st
from streamlit_flexnav.core.models.pagestruct import PageStruct


def page():
    return PageStruct(
        label="Log Viewer",
        icon="📜",
        order=9801,
        path=__file__,
        required_roles=[],
    )


def render(ctx=None):
    st.title("FlexNav Log Viewer")

    # ---------------------------------------------------------
    # Locate log files
    # ---------------------------------------------------------
    log_root = Path(__file__).resolve().parent.parent.parent
    log_files = sorted(log_root.glob("flexnav.log*"), reverse=True)
    file_names = [f.name for f in log_files]

    if not file_names:
        st.warning("No log files found.")
        return

    # ---------------------------------------------------------
    # Sidebar: file selector
    # ---------------------------------------------------------
    selected_file = st.sidebar.selectbox("Log file", file_names)
    selected_path = log_root / selected_file

    # ---------------------------------------------------------
    # Sidebar: filters
    # ---------------------------------------------------------
    st.sidebar.header("Filters")

    level_filter = st.sidebar.selectbox(
        "Level", ["ALL", "info", "warning", "error", "critical"]
    )

    component_filter = st.sidebar.text_input("Component contains")
    text_filter = st.sidebar.text_input("Search text")

    tail_lines = st.sidebar.slider("Lines", 50, 5000, 500)

    # ---------------------------------------------------------
    # Sidebar: live mode
    # ---------------------------------------------------------
    live_mode = st.sidebar.checkbox("Live mode (auto-refresh)", value=True)

    # ---------------------------------------------------------
    # Placeholder for dynamic content
    # ---------------------------------------------------------
    container = st.empty()

    # ---------------------------------------------------------
    # Render once
    # ---------------------------------------------------------
    def render_once():
        try:
            with selected_path.open("r") as f:
                lines = f.readlines()[-tail_lines:]
        except Exception as e:
            st.error(f"Failed to read log file: {e}")
            return

        entries = []
        for line in lines:
            try:
                entries.append(json.loads(line))
            except Exception:
                continue

        # ---------------------------------------------------------
        # Metrics
        # ---------------------------------------------------------
        st.subheader("Metrics")

        level_counts = {}
        component_counts = {}

        for e in entries:
            lvl = e.get("level")
            comp = e.get("component")

            if lvl:
                level_counts[lvl] = level_counts.get(lvl, 0) + 1
            if comp:
                component_counts[comp] = component_counts.get(comp, 0) + 1

        col1, col2 = st.columns(2)
        with col1:
            st.write("### Levels")
            st.json(level_counts)
        with col2:
            st.write("### Components")
            st.json(component_counts)

        # ---------------------------------------------------------
        # Apply filters
        # ---------------------------------------------------------
        if level_filter != "ALL":
            entries = [e for e in entries if e.get("level") == level_filter]

        if component_filter:
            entries = [
                e
                for e in entries
                if component_filter.lower() in str(e.get("component", "")).lower()
            ]

        if text_filter:
            entries = [
                e for e in entries if text_filter.lower() in json.dumps(e).lower()
            ]

        # ---------------------------------------------------------
        # Display logs with highlighting
        # ---------------------------------------------------------
        st.subheader("Log Entries")

        for entry in entries:
            raw = json.dumps(entry, indent=2)

            if text_filter:
                pattern = re.escape(text_filter)
                raw = re.sub(
                    pattern,
                    f"**<<{text_filter}>>**",
                    raw,
                    flags=re.IGNORECASE,
                )

            title = f"{entry.get('timestamp')} — {entry.get('event')}"
            with st.expander(title):
                st.code(raw)

    # ---------------------------------------------------------
    # Live mode loop (Streamlit 1.54 safe)
    # ---------------------------------------------------------
    if live_mode:
        container.empty()
        with container:
            render_once()

        # Throttle refresh
        time.sleep(2)

        # Trigger rerun (Streamlit 1.54 compatible)
        st.rerun()

    else:
        render_once()
if __name__ == "__main__":
    render()
