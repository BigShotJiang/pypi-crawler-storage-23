from streamlit_flexnav.core.models.menustruct import MenuStruct


def menu() -> MenuStruct:
    return MenuStruct(
        label="Admin",
        icon="🛡️",
        color="red",
        bold=True,
        italic=False,
        order=9500,
    )
