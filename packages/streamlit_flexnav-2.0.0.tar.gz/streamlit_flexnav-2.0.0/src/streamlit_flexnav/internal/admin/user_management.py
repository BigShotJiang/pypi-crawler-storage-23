import streamlit as st

from streamlit_flexnav.core.auth.backend import AuthBackend
from streamlit_flexnav.core.auth.guard import get_current_user
from streamlit_flexnav.core.models.pagestruct import PageStruct


def page() -> PageStruct:
    return PageStruct(
        label="User Management",
        required_roles=[],
        icon="🛠️",
        order=9503,                 
    )


def render():
    st.title("🛠️ User Management")

    current = get_current_user()
    if current is None:
        st.warning("You must be logged in to manage users.")
        return

    roles = current.roles or []
    if "superadmin" not in roles:
        st.error("Only superadmin can manage users.")
        return

    root = st.session_state.get("auth_root")
    if root is None:
        st.error("Authentication root path is not configured.")
        return

    backend = AuthBackend(root)
    store = backend.store

    try:
        users = store.list_users()
    except Exception as e:
        st.error("Failed to load users: %s" % e)
        return

    st.header("Existing Users")

    if not users:
        st.info("No users found.")
    else:
        for u in users:
            username = u.get("username")
            u_roles = u.get("roles", [])
            st.write("**%s** — roles: %s" % (username, u_roles))

    st.write("---")

    st.header("Add New User")

    new_username = st.text_input("Username")
    new_password = st.text_input("Password", type="password")
    new_roles = st.multiselect(
        "Roles",
        ["viewer", "user", "admin", "superadmin"],
        default=["viewer"],
    )

    if st.button("Create user"):
        if not new_username or not new_password:
            st.error("Username and password are required.")
        else:
            try:
                store.add_user(new_username, new_roles, new_password)
            except Exception as e:
                st.error("Failed to create user: %s" % e)
            else:
                st.success("User '%s' created." % new_username)
                st.rerun()

    st.write("---")

    st.header("Delete User")

    usernames = [u.get("username") for u in users]

    if usernames:
        del_user = st.selectbox("Select user to delete", usernames)

        if st.button("Delete user"):
            if del_user == "flexadmin":
                st.error("Cannot delete default admin user.")
            else:
                try:
                    store.delete_user(del_user)
                except Exception as e:
                    st.error("Failed to delete user: %s" % e)
                else:
                    st.success("User '%s' deleted." % del_user)
                    st.rerun()
    else:
        st.info("No users available to delete.")

    st.write("---")

    st.header("Reset Password")

    if usernames:
        reset_user = st.selectbox("Select user", usernames, key="reset_user")
        new_pw = st.text_input("New password", type="password", key="reset_pw")

        if st.button("Reset password"):
            if not new_pw:
                st.error("New password is required.")
            else:
                try:
                    store.update_password(reset_user, new_pw)
                except Exception as e:
                    st.error("Failed to reset password: %s" % e)
                else:
                    st.success("Password reset for '%s'." % reset_user)
                    st.rerun()
    else:
        st.info("No users available for password reset.")


if __name__ == "__main__":
    render()
