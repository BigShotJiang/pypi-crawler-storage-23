import streamlit as st
from streamlit_flexnav.core.models.pagestruct import PageStruct
from streamlit_flexnav.core.auth.rbac import AuthStruct


def page() -> PageStruct:
    return PageStruct(
        label="Role Inspector",
        required_roles=[],
        order=9502,                 
    )


def render():
    st.title("🔐 Role Inspector")

    from streamlit_flexnav.core.state import get_runtime

    runtime = get_runtime()

    roles_used = _collect_roles_used(runtime.pages)
    roles_normalized = _collect_roles_normalized(runtime.pages)
    roles_highest = _collect_highest_roles(runtime.pages)

    st.header("Role Overview")
    st.write("Roles used by pages:", sorted(roles_used) or "None")
    st.write("Normalized roles:", sorted(roles_normalized) or "None")
    st.write("Highest required roles:", sorted(roles_highest) or "None")

    st.write("---")

    st.header("Page RBAC Overview")

    for page in runtime.pages:
        raw = page.required_roles or []
        normalized = [AuthStruct.from_label(r) for r in raw]
        highest = AuthStruct.highest_role(raw)

        with st.expander("%s" % page.label):
            st.write("Path:", page.path)
            st.write("Group:", page.group)
            st.write("Required (raw):", raw)
            st.write(
                "Required (normalized):",
                [r.display_name() for r in normalized],
            )
            st.write("Highest required:", highest.display_name())

    st.write("---")

    st.header("Runtime Settings")

    with st.expander("Show runtime settings"):
        st.json(runtime.model_dump())


def _collect_roles_used(pages):
    roles = set()
    for p in pages:
        for r in p.required_roles or []:
            roles.add(str(r))
    return roles


def _collect_roles_normalized(pages):
    roles = set()
    for p in pages:
        for r in p.required_roles or []:
            roles.add(AuthStruct.from_label(r).display_name())
    return roles


def _collect_highest_roles(pages):
    roles = set()
    for p in pages:
        highest = AuthStruct.highest_role(p.required_roles)
        roles.add(highest.display_name())
    return roles


if __name__ == "__main__":
    render()
