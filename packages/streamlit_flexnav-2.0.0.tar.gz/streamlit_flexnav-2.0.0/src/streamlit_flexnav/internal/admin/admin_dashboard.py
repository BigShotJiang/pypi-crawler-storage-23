import streamlit as st
from streamlit_flexnav.core.models.pagestruct import PageStruct
from streamlit_flexnav.core.auth.rbac import AuthStruct


def page() -> PageStruct:
    return PageStruct(
        label="Admin Dashboard",
        required_roles=[],
        order=9501,         
    )


def render():
    st.title("🛡️ Admin Dashboard")

    from streamlit_flexnav.core.state import get_runtime

    runtime = get_runtime()

    st.header("System Overview")

    total_pages = len(runtime.pages)
    roles_used = _collect_roles_used(runtime.pages)

    col1, col2, col3 = st.columns(3)
    col1.metric("Total Pages", total_pages)
    col2.metric("Distinct Roles Used", len(roles_used))
    col3.metric("Active Profile", runtime.profile)

    st.write("---")

    st.subheader("Role Overview")
    st.write("Roles used by pages:", sorted(roles_used) or "None")

    st.write("---")

    st.subheader("Page RBAC Overview")

    for page in runtime.pages:
        raw = page.required_roles or []
        normalized = [AuthStruct.from_label(r) for r in raw]
        highest = AuthStruct.highest_role(raw)

        with st.expander("%s" % page.label):
            st.write("Path:", page.path)
            st.write("Group:", page.group)
            st.write("Required (raw):", raw)
            st.write(
                "Required (normalized):",
                [r.display_name() for r in normalized],
            )
            st.write("Highest required:", highest.display_name())

    st.write("---")

    st.subheader("Menu Structure")

    if getattr(runtime, "menu_tree", None):
        st.json(runtime.menu_tree.to_dict())
    else:
        st.info("Menu tree not available.")

    st.write("---")

    st.subheader("Runtime Settings")

    with st.expander("Show runtime settings"):
        st.json(runtime.model_dump())


def _collect_roles_used(pages):
    roles = set()
    for p in pages:
        for r in p.required_roles or []:
            roles.add(str(r))
    return roles


if __name__ == "__main__":
    render()
