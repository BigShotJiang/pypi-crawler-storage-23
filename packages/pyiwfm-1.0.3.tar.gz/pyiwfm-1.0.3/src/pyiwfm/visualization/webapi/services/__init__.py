"""
Service modules for the web viewer.
"""
