"""Enable running pyiwfm as a module: python -m pyiwfm."""

import sys

from pyiwfm.cli import main

sys.exit(main())
