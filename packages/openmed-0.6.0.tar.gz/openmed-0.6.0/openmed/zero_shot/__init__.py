"""Zero-shot tooling (APIs + assets) for OpenMed."""

from __future__ import annotations

__all__ = []
