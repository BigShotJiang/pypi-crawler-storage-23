"""Version information for OpenMed."""

__version__ = "0.6.0"
