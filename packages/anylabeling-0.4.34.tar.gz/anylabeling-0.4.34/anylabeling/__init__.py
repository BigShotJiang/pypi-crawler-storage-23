from .app_info import __appdescription__, __appname__, __version__

__all__ = ["__appdescription__", "__appname__", "__version__"]
