# hglass

A terminal-based pomodoro timer with an animated ASCII hourglass.

## Install

```bash
pip install hglass
```

## Usage

```bash
hglass 25      # 25-minute pomodoro
hglass 5       # 5-minute break
hglass 0.1     # 6-second test run
```

Press `Ctrl+C` to cancel the timer early.

## Features

- Large animated hourglass with falling sand
- Smooth grain-drop neck animation at 8 fps
- Big-digit countdown timer (MM:SS)
- Warm amber/blue color scheme optimized for dark terminals
- Bell notification and flashing "TIME'S UP!" on completion
- Automatic fallback for small terminal windows

## Requirements

- Python 3.9+
- [Rich](https://github.com/Textualize/rich)

## License

MIT
