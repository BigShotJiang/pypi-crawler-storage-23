---
name: ao-gh-actionable-comments
description: "Analyze PR review comments using gh CLI to identify actionable items."
---

Use skill `ao-gh-actionable-comments` to analyze pull request review comments.

## Quick Usage

```
/ao-gh-actionable-comments [PR_NUMBER]
```

If PR number is omitted, uses the current branch's PR.

## When to Use

- After receiving code review on a PR
- To track which comments need action
- Before marking a PR as ready to merge
- To identify questions that need reviewer response

## Output Includes

| Category | Description |
|----------|-------------|
| 🟢 HIGH | Specific, mechanical changes |
| 🟡 MEDIUM | Actions requiring some decisions |
| 🔴 LOW | Ambiguous, needs discussion |
| ❓ Question | Author asked for clarification |
| ⏳ No reply | Awaiting author response |

## Prerequisites

- `gh` CLI installed and authenticated
- Active pull request exists
