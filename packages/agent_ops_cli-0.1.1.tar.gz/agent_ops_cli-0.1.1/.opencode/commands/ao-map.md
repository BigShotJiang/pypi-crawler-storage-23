---
name: ao-map
description: "Generate or update the codebase context map in .agent/ops/map.md"
---

Use skill `ao-context-map` to create a concise, LLM-optimized overview of the project.

## Procedure:
1. Scan file structure (2-3 levels deep)
2. Identify key architectural elements:
   - Configuration files (package.json, pyproject.toml, etc.)
   - Entry points (main.py, index.js, App.tsx, etc.)
   - Core modules and responsibilities
3. Summarize architecture patterns and data flow
4. Write/update `.agent/ops/map.md` using the template
5. Keep it concise (target < 150 lines)
6. Update `.agent/ops/focus.md` noting the map was created/updated

## When to use:
- New project onboarding
- After major refactors
- When context is unclear
- Before improvement discovery
