---
name: ao-baseline
description: "Collect mandatory baseline: build/lint + tests, write full report to .agent/ops/baseline.md."
---

Precondition (mandatory):
- .agent/ops/constitution.md exists and contains CONFIRMED build/lint/test commands.
- If missing or unconfirmed: stop and run /ao-constitution.

Use skill `ao-baseline` for the full workflow.

Then:
1) Read .agent/ops/constitution.md and extract the confirmed commands.
2) Run build/lint and unit tests exactly as defined in the constitution.
3) Write a detailed baseline report into .agent/ops/baseline.md (timestamp, commands, outputs summarized, findings grouped by file, test summary + failure details).
4) Update .agent/ops/focus.md accordingly using skill `ao-state`.
