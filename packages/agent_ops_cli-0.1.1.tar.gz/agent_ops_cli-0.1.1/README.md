# AO — Agent Ops

High-performance JSONL issue/event store with CLI interface.

## ⚠️ Important: Always Use `uv run`

**All Python commands MUST be run using `uv run`.**

```bash
# ✅ CORRECT
uv run ao --version
uv run python scripts/build.py
uv run pytest

# ❌ WRONG
python scripts/build.py
ao --version  # only works after uv tool install
```

## Installation

### Development (local)

```bash
git clone <repo-url>
cd agent-ops
uv sync
uv run ao --version
```

### Global tool install

```bash
uv tool install .        # from local checkout
uv tool install agent-ops-cli  # from PyPI (once published)
ao --version
```

## Usage

```bash
# Generate test data
uv run ao gen events --issues 1000 --updates-per-issue 3

# Rebuild active snapshot from events
uv run ao rebuild --events events.jsonl --active active.jsonl

# Query active issues
uv run ao query --status todo --priority critical

# Benchmarks
uv run ao bench decode --file data/events.jsonl --codec orjson
uv run ao bench rebuild --events data/events.jsonl --codec msgspec
```

## Development

```bash
uv sync                                    # Install dependencies
uv run python scripts/build.py             # Full build pipeline
uv run python scripts/build.py --fix       # Auto-fix lint/format
uv run pytest tests/ -v                    # Run tests
uv run ruff check src/ao/                 # Lint
uv run ruff format src/ao/               # Format
uv run mypy src/ao/                       # Type check
```

## Publishing to PyPI

This repo includes a GitHub Actions workflow at `.github/workflows/publish-pypi.yml`.

- **Release publish (PyPI):** publishing happens when a GitHub Release is marked `published`.
- **Manual publish:** run the workflow manually and choose `testpypi` or `pypi`.

### Required repository settings

1. In GitHub, create environments:
   - `pypi`
   - `testpypi`
2. Configure PyPI/TestPyPI trusted publisher entries for this repository.

### Recommended: Trusted Publishing (OIDC)

PyPI Trusted Publishing (OIDC) is the default in this workflow:

1. Configure a trusted publisher in PyPI/TestPyPI for this GitHub repository.
2. Keep workflow `permissions.id-token: write` enabled.
3. Optional token fallback: if your org requires API tokens, add
   `password: ${{ secrets.PYPI_API_TOKEN }}` / `password: ${{ secrets.TEST_PYPI_API_TOKEN }}`
   to the publish steps in `.github/workflows/publish-pypi.yml`.

The workflow always builds `sdist` + `wheel` with `uv build`, runs
`uvx twine check dist/*`, and only then publishes.

## Architecture

- **events.jsonl** — append-only event log (source of truth)
- **active.jsonl** — deterministic snapshot of active issues (derived)
- **orjson / msgspec** — dual codec backends for benchmarking
- **Typer + Rich** — CLI with progress bars for heavy IO
