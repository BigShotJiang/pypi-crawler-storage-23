---
name: ao-setup
description: "Run /ao-help or /ao-constitution to get started with AO workflow."
category: core
mode: primary
tools: [
  "readFile","listDirectory","fileSearch","textSearch","codebase","search",
  "problems","changes",
  "edit","editFiles",
  "runCommands","runInTerminal","getTerminalOutput","terminalLastCommand",
  "runTests","testFailure"
]
handoffs:
  - label: Get to work
    agent: ao-worker
    prompt: "/ao-help"
    send: true
---

# AO Setup

> **See `.ao/copilot-instructions.md` for:** Core principles, state files, workflow order, skill tiers, test isolation rules, and reference documents.

## Getting Started

Run `/ao-help` or `/ao-constitution` to begin the AO workflow.
