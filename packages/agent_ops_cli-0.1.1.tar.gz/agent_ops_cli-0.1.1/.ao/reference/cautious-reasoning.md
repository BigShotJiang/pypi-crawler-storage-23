# Cautious Reasoning Framework

> **Type**: Reference document (not a workflow skill)
> **Use**: Framework for epistemically cautious analysis in complex decisions

---

## Purpose

Apply this framework when analyzing open-ended, strategic, or multi-causal problems where confidence must be carefully calibrated.

## Core Constraints

### 1. No Narrative Collapse

Do NOT compress uncertainty into a single explanation.

**Instead**: Enumerate multiple plausible hypotheses before evaluating any of them.

### 2. No Unjustified Causality

Do NOT use causal language ("because," "drives," "leads to") unless you explicitly state:

a) Whether the relationship is causal or correlational
b) At least one alternative explanation

### 3. Conditional Reasoning Only

Do NOT recommend a single "best" strategy.

**Instead**: Frame guidance as conditional decision trees:
- IF condition A is true → action X
- IF condition B is true → action Y
- IF conditions cannot be determined → state "insufficient data"

### 4. Explicit Uncertainty is Mandatory

For each major claim:
- State what would falsify it
- Rate confidence (0–100%)
- Note whether required data is missing

### 5. Bias Awareness

Assume these biases are present:
- Survivorship bias
- Selection effects
- Hindsight bias

For every observed pattern, explain how it could be an artifact of these biases.

### 6. Role Constraint

Act as a skeptical peer reviewer, not a coach, consultant, or cheerleader.

Default stance: reject weak explanations.

## Output Structure

When applying this framework, structure analysis as:

### A. Hypothesis Enumeration
List all plausible hypotheses without evaluation.

### B. Evidence Required
What evidence would discriminate between hypotheses?

### C. Conditional Implications
IF hypothesis 1 is true → implication X
IF hypothesis 2 is true → implication Y
(No prescriptions without conditions)

### D. Failure Modes
What could go wrong? What might we be misattributing?

### E. Confidence Assessment
| Claim | Confidence | Falsifiable By | Missing Data |
|-------|------------|----------------|--------------|
| ... | X% | ... | ... |

## When to Apply

- Strategic decisions with uncertain outcomes
- Root cause analysis of complex problems
- Evaluating competing approaches
- Assessing risks and trade-offs
- Any situation where overconfidence is dangerous

## When NOT to Apply

- Simple, well-defined tasks
- Implementation details with clear solutions
- Following established procedures
- Time-critical decisions requiring action

## Integration with AO

This framework can inform:
- **Planning**: When evaluating approaches with uncertain outcomes
- **Recovery**: When diagnosing unexpected failures
- **Improvement Discovery**: When assessing proposed enhancements
- **Critical Review**: When evaluating risk of changes
