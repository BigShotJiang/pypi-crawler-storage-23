# Conflict Detection Reference

**Authority**: This document defines the conflict detection layer that validates user requests against active safety protocols. All agents and skills MUST reference these rules.

## Purpose

Detect and resolve conflicts between:
- User requests (convenience, speed, autonomy)
- Safety protocols (validation, review, hard stops)

**Principle**: Safety protocols ALWAYS take priority over user convenience requests.

## Conflict Types

### Type 1: Autonomous Mode + LOW Confidence

**Conflict**: User requests autonomous work, but active issue has LOW confidence.

**Detection**:
```
IF user_request CONTAINS ("autonomous", "without asking", "just do it", "don't ask"):
    IF current_issue.confidence == "low":
        CONFLICT DETECTED — Autonomous + LOW
```

**Resolution**:
- **Default**: SOFT BLOCK — require "OVERRIDE-LOW" keyword to proceed
- **OVERRIDE-LOW scope**: Single issue only — next issue requires new override
- **No justification required** — override keyword is sufficient

**Agent Response**:
```markdown
⚠️ CONFLICT DETECTED — Autonomous Mode + LOW Confidence

LOW confidence issues require human oversight at each step.

Current issue: {ISSUE-ID} — {title}
Confidence: LOW

Autonomous mode is BLOCKED for this issue.

To proceed anyway, respond with: OVERRIDE-LOW

Note: Override applies to this issue only. Next issue will require new confirmation.
```

### Type 2: Batch Request + LOW Confidence

**Conflict**: User requests working on multiple issues, but one or more has LOW confidence.

**Detection**:
```
IF requested_batch_size > 1:
    FOR issue IN requested_issues:
        IF issue.confidence == "low":
            CONFLICT DETECTED — Batch + LOW
```

**Resolution**:
- **HARD BLOCK** — cannot batch LOW confidence issues
- LOW confidence = max 1 issue per iteration
- Must complete and review before selecting next issue

**Agent Response**:
```markdown
⛔ CONFLICT DETECTED — Batch Request + LOW Confidence

Cannot batch LOW confidence issues. LOW confidence requires:
- Single issue focus (max 1 per iteration)
- Human review hard stop after each completion
- Explicit approval before any next issue

LOW confidence issues in request:
- {ISSUE-ID} — {title}

Options:
1. Work on single LOW confidence issue (with full protocol)
2. Work on only the NORMAL/HIGH confidence issues as batch
3. Use OVERRIDE-LOW for each LOW issue individually
```

### Type 3: Skip Validation + Any Confidence

**Conflict**: User requests skipping validation steps.

**Detection**:
```
IF user_request CONTAINS ("skip validation", "skip tests", "don't validate"):
    CONFLICT DETECTED — Skip Validation
```

**Resolution**:
- **SOFT BLOCK for HIGH** — warn but allow
- **HARD BLOCK for NORMAL/LOW** — validation is mandatory

**Agent Response for NORMAL/LOW**:
```markdown
⛔ CONFLICT DETECTED — Skip Validation Request

Validation is MANDATORY for {confidence} confidence issues.

Cannot skip:
- Test suite execution
- Lint checks
- Baseline comparison
- {if LOW: Coverage threshold check}

Proceeding without validation risks undetected regressions.

Options:
1. Run validation (RECOMMENDED)
2. Explain why validation should be skipped (requires justification file)
```

### Type 4: Auto-Close + Human Review Required

**Conflict**: Agent attempting to auto-close issue that requires human review.

**Detection**:
```
IF status_change_to == "done":
    IF issue.confidence == "low" AND NOT human_review_completed:
        CONFLICT DETECTED — Auto-close + Human Review
```

**Resolution**:
- **HARD BLOCK** — LOW confidence issues cannot be auto-closed
- Must present hard stop checkpoint
- Must receive explicit human approval

**Agent Response**:
```markdown
⛔ CONFLICT DETECTED — Auto-Close Without Human Review

LOW confidence issues require human review before completion.

This is a HARD BLOCK — cannot be overridden.

Human review checkpoint MUST be presented with:
- All changes made
- Test results
- Coverage analysis
- Any uncertainties or assumptions

Waiting for human response before proceeding.
```

### Type 5: Backlog Promotion

**Conflict**: Agent attempts to move an issue from backlog.md to any priority file (critical.md, high.md, medium.md, low.md).

**Detection**:
```
IF agent_action == "move_issue" AND source == "backlog.md" AND target IN priority_files:
    CONFLICT DETECTED — Backlog Promotion
```

**Resolution**:
- **HARD BLOCK** — Only the human can promote issues from backlog
- No override mechanism — this is an absolute rule
- Agent must present backlog items and wait for human selection

**Agent Response**:
```markdown
⛔ CONFLICT DETECTED — Backlog Promotion

Only the human can promote issues from backlog to priority files.

This is a HARD BLOCK — cannot be overridden.

Available backlog items:
- {ISSUE-ID} — {title}
- {ISSUE-ID} — {title}

Please select which issue(s) to promote and to which priority level.
```

## Conflict Detection Procedure

**Run this check BEFORE executing any user request:**

```
function detect_conflicts(user_request, active_issues):
    conflicts = []
    
    // Check for autonomous mode keywords
    autonomous_keywords = ["autonomous", "without asking", "just do it", 
                          "don't ask", "work independently", "no interruptions"]
    is_autonomous_request = any(kw in user_request.lower() for kw in autonomous_keywords)
    
    // Check for batch request
    is_batch_request = len(active_issues) > 1 OR "all issues" in user_request.lower()
    
    // Check for skip validation
    skip_keywords = ["skip validation", "skip tests", "don't validate", "no tests"]
    is_skip_request = any(kw in user_request.lower() for kw in skip_keywords)
    
    // Check for backlog promotion attempt
    is_backlog_promotion = agent_attempts_to_move_issue_from("backlog.md", to_priority_file)
    if is_backlog_promotion:
        conflicts.append(("backlog_promotion", None))
    
    // Evaluate conflicts
    for issue in active_issues:
        if issue.confidence == "low":
            if is_autonomous_request:
                conflicts.append(("autonomous_low", issue))
            if is_batch_request:
                conflicts.append(("batch_low", issue))
        
        if is_skip_request and issue.confidence in ["low", "normal"]:
            conflicts.append(("skip_validation", issue))
    
    return conflicts

function handle_conflicts(conflicts):
    FOR conflict_type, issue IN conflicts:
        IF conflict_type == "autonomous_low":
            SOFT_BLOCK("Autonomous + LOW", require_override="OVERRIDE-LOW")
        
        ELIF conflict_type == "batch_low":
            HARD_BLOCK("Batch + LOW")
        
        ELIF conflict_type == "skip_validation":
            IF issue.confidence == "low":
                HARD_BLOCK("Skip validation forbidden for LOW")
            ELSE:
                SOFT_BLOCK("Skip validation for NORMAL", require_justification=True)
        
        ELIF conflict_type == "backlog_promotion":
            HARD_BLOCK("Backlog promotion forbidden — only human can promote from backlog")
```

## Override Tracking

When OVERRIDE-LOW is used:

1. **Log the override** in issue history:
   ```
   - YYYY-MM-DD: OVERRIDE-LOW used — autonomous mode permitted for this issue
   ```

2. **Reset for next issue**:
   - Override does NOT carry forward
   - Each new LOW confidence issue requires fresh confirmation

3. **No justification required**:
   - The override keyword is sufficient
   - User is assumed to understand the risks

## Integration Points

### ao-focus-scan

Before selecting issues, run conflict detection on user request.

### ao-implementation

Before each implementation step, validate action against active constraints.

### Worker Agent Mode Instructions

Include conflict detection in pre-execution checks.

---

## Test Scenarios

### Scenario 1: Autonomous + LOW (Soft Block)

**Input**: "Work autonomously on all issues"
**Active Issues**: [ENH-001 (confidence: low)]
**Expected**: SOFT BLOCK, prompt for OVERRIDE-LOW

### Scenario 2: Batch + LOW (Hard Block)

**Input**: "Work on ENH-001 and ENH-002"
**Issues**: ENH-001 (low), ENH-002 (normal)
**Expected**: HARD BLOCK, can only batch the NORMAL issue

### Scenario 3: Skip Validation + LOW (Hard Block)

**Input**: "Skip tests and mark done"
**Active Issue**: (confidence: low)
**Expected**: HARD BLOCK, validation mandatory

### Scenario 4: Auto-Close + LOW (Hard Block)

**Action**: Agent attempts `status: done` without human checkpoint
**Active Issue**: (confidence: low)
**Expected**: HARD BLOCK, human review required

### Scenario 5: OVERRIDE-LOW Scoped to Single Issue

**Input**: "OVERRIDE-LOW, work autonomously"
**Issue 1**: ENH-001 (low) — override applied
**Issue 2**: ENH-002 (low) — next issue, no override
**Expected**: ENH-001 proceeds, ENH-002 re-prompts for override

### Scenario 6: Backlog Promotion (Hard Block)

**Action**: Agent attempts to move issue from backlog.md to a priority file
**Expected**: HARD BLOCK — only the human can promote from backlog. Agent must present backlog items and wait for human selection.

---

*Last updated: 2026-02-13*
