# Reference Documents

This folder contains reference materials, guidelines, and frameworks that inform AO workflows but are not executable skills themselves.

## Contents

| Document | Purpose |
|----------|---------|
| [api-guidelines.md](api-guidelines.md) | Production-ready API development checklist |
| [cautious-reasoning.md](cautious-reasoning.md) | Epistemically cautious reasoning framework |
| [code-review-framework.md](code-review-framework.md) | Comprehensive code review methodology |

## Usage

These documents are **reference material**, not workflow skills. They should be:

- Read when relevant context is needed
- Referenced in plans and reviews
- Used as checklists during implementation
- Cited in task descriptions when applicable

## Difference from Skills

| Skills | Reference Docs |
|--------|----------------|
| Have procedures to follow | Have checklists/frameworks to apply |
| Update state files | Do not update state files |
| Have preconditions | Are context-independent |
| Are invoked by prompts/agents | Are read on demand |
