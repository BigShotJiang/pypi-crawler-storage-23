Use the `ao-idea` skill to capture and research ideas.

## Quick Usage

```
/ao-idea <your idea description>
```

Or simply describe your idea and ask to capture it.

## When to Use

- You have a vague concept that needs fleshing out
- You want to research feasibility before committing to work
- You want to capture a brainstorm for later triage
- You have an idea but aren't sure how to implement it

## Options

| Mode | Description | When to Use |
|------|-------------|-------------|
| **Full** (default) | Capture + research + create enriched issue | Most ideas |
| **Minimal** | Just capture, no research | Quick notes, obvious ideas |

For minimal mode, say "just capture it" or "no research needed".

## What You Get

The skill creates an IDEA issue in backlog.md with:

- **Original idea** — your raw text preserved
- **Problem statement** — what problem this solves
- **Research findings** — existing solutions, libraries, challenges
- **Suggested approach** — high-level implementation direction
- **Next steps** — triage, refine, or implement

## Examples

**Full mode:**
```
/ao-idea What if we could export issues to a Kanban board in Miro?
```

**Minimal mode:**
```
/ao-idea Add keyboard shortcuts to TUI — just capture it
```

## After Capture

The idea goes to `backlog.md` with status `idea`. Use `/ao-task triage` later to assign priority and move it to the appropriate queue.
