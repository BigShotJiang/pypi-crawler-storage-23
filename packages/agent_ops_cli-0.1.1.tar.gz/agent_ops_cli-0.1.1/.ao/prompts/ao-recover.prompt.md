---
name: ao-recover
description: "Trigger error recovery workflow when stuck or after failures."
agent: AO
---

Use skill `ao-recovery` for this workflow.

Run this when:
- Build broke after your changes
- Tests failing that were passing
- You're stuck or going in circles
- Something unexpected happened

The recovery skill will:
1. **Debug first** — invoke `ao-debugging` for systematic root cause analysis
2. Diagnose what went wrong (your change vs pre-existing)
3. Compare to baseline
4. Propose rollback options
5. Execute recovery (with confirmation for destructive actions)

**Tip:** For pure debugging without recovery, use `/ao-debug` instead.
