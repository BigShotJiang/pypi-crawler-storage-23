````prompt
---
name: ao-llm-export
description: "Export skills, agents, and prompts to llm.txt or JSON format"
agent: AO
---

## Purpose

Export AO capabilities (skills, agents, prompts) to a structured file for external LLM consumption.

## Quick Usage

```
/ao-llm-export
```

Generates `.agent/ops/llm.txt` with all capabilities in markdown format.

## Arguments

| Argument | Values | Default | Description |
|----------|--------|---------|-------------|
| `--format` | `markdown`, `json` | `markdown` | Output format |
| `--include` | `skills`, `agents`, `prompts`, `all` | `all` | What to include (comma-separated) |
| `--content` | `metadata`, `summary`, `full` | `metadata` | Content depth to include |
| `--output` | `<path>` | `.agent/ops/llm.txt` or `.agent/ops/llm.json` | Custom output path |

**Content Modes:**
- `metadata` — Frontmatter fields only (default, fast)
- `summary` — Metadata + first 50 lines of content
- `full` — Complete file content (uses Python, bypasses context limits)

## Examples

### Export everything to markdown (default)
```
/ao-llm-export
```

### Export to JSON
```
/ao-llm-export --format json
```

### Export only skills and prompts
```
/ao-llm-export --include skills,prompts
```

### Custom output path
```
/ao-llm-export --output docs/capabilities.md
```

### Combination: JSON skills only to custom path
```
/ao-llm-export --format json --include skills --output .agent/ops/skills-only.json
```

### Full content export (uses Python)
```
/ao-llm-export --content full --output output/llm-full.txt
```
Includes complete file content in collapsible `<details>` sections. Requires Python (checked via `.agent/ops/tools.json`).

### Summary content export
```
/ao-llm-export --content summary
```
Includes metadata plus first 50 lines of each file.

## What Gets Exported

**Skills** (from `.ao/skills/*/SKILL.md`):
- Name, description, category
- What it invokes and what invokes it
- File path

**Agents** (from `.github/agents/` and `tools/*/agents/`):
- Name, description
- Argument hints
- File path

**Prompts** (from `.github/prompts/*.prompt.md`):
- Name, description
- Target agent
- File path

## Output Format

### Markdown (llm.txt)

```markdown
# AO Capabilities Export

Generated: 2026-01-25T14:30:00Z

## Skills (54 total)

### ao-planning
**Description**: Produce thorough plans before implementation...
**Category**: core
**File**: .ao/skills/ao-planning/SKILL.md
**Invokes**: ao-state, ao-interview
**Invoked By**: none

---

## Agents (4 total)

### AO Worker
**Description**: Plan→Implement→Review→Retrospective
**File**: .github/agents/ao-worker.agent.md
**Argument Hint**: Task description or issue ID

---

## Prompts (25 total)

### ao-task
**Description**: Create, refine, or manage issues
**Target Agent**: AO
**File**: .github/prompts/ao-task.prompt.md
```

### JSON Format

```json
{
  "generated": "2026-01-25T14:30:00Z",
  "stats": {
    "skills": 54,
    "agents": 4,
    "prompts": 25
  },
  "skills": [...],
  "agents": [...],
  "prompts": [...]
}
```

## Error Handling

The skill handles missing directories gracefully:
- Missing skills/ → warns, continues with empty list
- Missing agents/ → warns, continues with empty list
- Missing prompts/ → warns, continues with empty list
- Invalid YAML → warns, skips that file

Use the `ao-llm-export` skill for implementation details.

````
