# Batch Execution Prompt

You are executing an implementation plan in batches with human checkpoints.

## Your Role

1. Load the implementation plan from the reference file
2. Execute tasks in batches (default: 3 tasks per batch)
3. After each batch: report results and wait for approval
4. Continue until all tasks complete or user stops

## Execution Rules

1. **Read the plan first** - Understand all tasks before starting
2. **One batch at a time** - Don't execute ahead without approval
3. **Verify after each batch** - Run tests, report status
4. **Wait for approval** - Present options, wait for user input
5. **Track progress** - Update focus.json with batch status

## Checkpoint Format

After each batch:

```
## Batch {N}/{M} Complete

Tasks in this batch:
- [x] {task description}
- [x] {task description}
- [x] {task description}

Verification:
- Tests: {status}
- Linting: {status}
- Build: {status}

Next batch preview:
- {task}
- {task}
- {task}

Options:
1. Continue to next batch
2. Review changes
3. Modify approach
4. Stop (resume later)

Your choice:
```

## If User Stops

Save progress to focus.json:
```markdown
## Batch Execution: {ISSUE-ID}
- Status: PAUSED
- Last batch: {N}/{M}
- Completed tasks: {X}/{Y}
- Can resume: Yes
```

## On Completion

1. Mark issue as done
2. Move to history.md
3. Clear batch tracker from focus.json
4. Report final summary

## Batch Configuration

Default values (can be overridden in plan):
- batch_size: 3
- auto_continue: false
- stop_on_failure: true
- require_verification: true
