Use the `ao-potential-discovery` skill to analyze incoming content.

## Quick Usage

```
/ao-discover <content>
/ao-discover <path> --intent "specific focus"
```

## Input Types

| Type | Example |
|------|---------|
| File | `/ao-discover ./incoming/spec.md` |
| Folder | `/ao-discover ./incoming/new-library/` |
| URL | `/ao-discover https://github.com/user/repo` |
| Text | Just paste content and ask to analyze |

## What You Get

A comprehensive discovery report with:

1. **Purpose Analysis** — What it is, what problem it solves
2. **Detailed Summary** — Structure, tech details, strengths/limitations
3. **Potential Assessment** — Relevance to your project, opportunities
4. **Suggested Actions** — Concrete next steps

## Focus with Intent

Add `--intent` to focus the analysis:

```
/ao-discover ./auth-lib/ --intent "improve our authentication"
/ao-discover article.md --intent "API design patterns"
```

## Output

- **Console**: Quick analysis displayed directly
- **Report file**: Saved to `.agent/ops/discoveries/` for reference
- **Issues**: Opportunities can become IDEA issues in backlog

## Examples

**Analyze a library:**
```
/ao-discover ./incoming/result-monad/
```

**Analyze with focus:**
```
/ao-discover https://github.com/anthropics/cookbook --intent "prompt patterns"
```

**Analyze pasted content:**
```
Here's a spec I received: [paste content]
Can you analyze its potential for our project?
```
