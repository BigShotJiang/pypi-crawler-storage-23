---
name: ao-review
description: "Critical review + baseline compare + retrospective learning before declaring done."
agent: AO
---

1) Run deep code review (use skill `ao-critical-review`) — analyze correctness, security, performance.
   - **If project contains APIs**: Also run `ao-api-review` for contract alignment, endpoint audit.
2) Run baseline comparison (use skill `ao-baseline`) — compare build/lint/test results.
3) Then run retrospective/learning (use skill `ao-retrospective`) and update .agent/ops/memory.md.
4) Update .agent/ops/focus.json and .agent/ops/issues/ using skill `ao-state`.

Do not declare done until both critical review AND retrospective have been completed.

## Low-Confidence Issues: Human Review Required

**For issues with `confidence: low`, the following rules apply:**

1. ❌ **Cannot auto-close** — Low-confidence issues require human review checklist approval
2. ⏸️ **Must stop after review** — Agent presents findings and WAITS for human decision
3. ✅ **Human must explicitly approve** — Options: approve, request changes, block, or defer
4. 📋 **Must use human review checklist** — All items must be addressed or explicitly accepted

### Human Review Checklist for Low-Confidence

```markdown
- [ ] Edge cases documented and acceptable
- [ ] Failure modes understood and handled
- [ ] No unaddressed critical/high review comments
- [ ] Baseline comparison shows no regressions
- [ ] Manually verified behavior (if applicable)
```

**After review, agent asks:**

> "This is a low-confidence issue. Based on the review:
> 1. ✅ Approve and mark done
> 2. 🔄 Request another iteration
> 3. ❌ Block (issue stays open)
> 
> Your decision?"
