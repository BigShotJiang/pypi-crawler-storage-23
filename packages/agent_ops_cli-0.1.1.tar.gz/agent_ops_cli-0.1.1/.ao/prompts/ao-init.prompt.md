---
name: ao-init
description: "Create/repair .agent/ops/* state files and folders using the standard templates."
agent: AO
---

Create the required folder structure and state files under .agent/ops/ if missing:
- .agent/ops/memory.md
- .agent/ops/focus.json
- .agent/ops/issues/
- .agent/ops/baseline.md
- .agent/ops/constitution.md
- .agent/ops/references-index.md
- .agent/ops/references/ (folder)
- .agent/ops/docs/ (folder)
- .agent/ops/time-tracking.json (use template from .ao/skills/ao-state/templates/time-tracking.template.json)

Create the required ao issue tracking files under .agent/ops/issues/ if missing:
- .agent/ops/issues/events.jsonl (empty)
- .agent/ops/issues/active.jsonl (empty)
- .agent/ops/issues/events.jsonl and active.jsonl (ao manages the counter automatically)

Use the standard templates. Do not create any other files.

After creation:
- Update .agent/ops/focus.json indicating the repo is ready for constitution creation.
- Create an issue via `ao issue add` for completing the constitution interview.

Then the next step is constitution creation (handoff button "Create/Update Constitution" or run /ao-constitution).
