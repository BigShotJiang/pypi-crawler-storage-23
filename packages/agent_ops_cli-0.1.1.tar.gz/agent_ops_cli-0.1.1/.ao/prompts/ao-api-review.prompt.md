---
mode: agent
description: Audit API implementation for correctness, contract alignment, and test coverage
tools:
  - read_file
  - grep_search
  - semantic_search
  - list_dir
  - run_in_terminal
---

# API Review

Perform a critical, evidence-based audit of the API implementation.

## Your Task

Read the skill file at `.ao/skills/ao-api-review/SKILL.md` and follow its procedure to audit the API.

## Quick Checklist

1. **Find OpenAPI spec** (openapi.yaml, swagger.json, or generated)
2. **Inventory all endpoints** (routes, handlers, controllers)
3. **Build Contract Alignment Matrix** (spec → impl → tests)
4. **Audit each axis** (A1-A10)
5. **Document findings** with severity and evidence
6. **Render verdict** (PASS only if no must_fix, no misaligned)

## Key Outputs

- Endpoint inventory by resource
- Contract alignment matrix
- Findings with severity, evidence, recommendations
- Test gap assessment
- PASS/FAIL verdict

## Remember

- **No credit without evidence**
- **Spec is not proof** — verify implementation matches
- **Tests are not proof** — verify they assert required outcomes
- Cite concrete file locations for every claim
