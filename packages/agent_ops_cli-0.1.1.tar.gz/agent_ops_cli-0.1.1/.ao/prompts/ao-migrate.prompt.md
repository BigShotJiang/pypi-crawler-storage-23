Use the `ao-migrate` skill to migrate projects or merge codebases.

## Quick Usage

```
/ao-migrate <source-path> <target-path>
```

Or describe what you want to migrate.

## When to Use

- Consolidating projects into a monorepo
- Upgrading to a new project template
- Merging two codebases
- Moving features between projects

## Migration Types

| Type | Description |
|------|-------------|
| Full merge | Entire source → target |
| Selective | Specific modules only |
| Template upgrade | Apply new template, keep custom code |
| Framework migration | Change underlying framework |

## What It Does

1. **Analyzes** source and target projects
2. **Identifies** conflicts and dependencies
3. **Creates** backup before changes
4. **Executes** migration with checkpoints
5. **Validates** build and tests pass
6. **Reports** results and follow-ups

## Safety Features

- ✅ Creates backup before any changes
- ✅ Validates at each checkpoint
- ✅ Rollback support if validation fails
- ✅ User confirmation for conflict resolution

## Example

```
> /ao-migrate ./old-api ./monorepo/services/api

## Migration Analysis

Source: ./old-api (47 files, 3 dependencies)
Target: ./monorepo/services/api (exists, 12 files)

Conflicts detected: 2
- package.json (different scripts)
- config.ts (different settings)

Proceed? [Y]es / [E]dit plan / [C]ancel
```
