---
name: ao-install
description: "Install AO framework into a new or existing project"
agent: AO
---

Use skill `ao-install` to set up AO in a project.

## Quick Start

```
/ao-install                # Interactive installation
/ao-install --quick        # Use defaults, minimal prompts
/ao-install --update       # Update skills/prompts only
/ao-install --dry-run      # Preview without changes
```

## What Gets Installed

| Location | Contents | Strategy |
|----------|----------|----------|
| `.agent/ops/` | State files, issues, specs | Created fresh |
| `.ao/skills/` | 21 AO skills | Copied (overwrite on update) |
| `.github/prompts/` | 17 prompt files | Added (skip existing) |
| `.github/agents/` | AO.md agent definition | Copied |
| `.github/reference/` | API, reasoning, review guides | Copied |
| `copilot-instructions.md` | Framework instructions | **Merged** with existing |

## Installation Modes

- **Fresh**: Empty folder → full install
- **Merge**: Existing .github/ → preserve + add AO
- **Update**: Existing AO → refresh skills/prompts, keep state

## After Installation

1. Run `/ao-constitution` to customize for your project
2. Run `/ao-baseline` to capture initial state
3. Start using `/ao-help` for guidance
