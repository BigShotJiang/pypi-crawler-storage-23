---
mode: agent
description: Dispatch parallel agents for independent issues
tools:
  - read_file
  - run_in_terminal
---

# Parallel Agent Dispatch

Dispatch multiple agents in parallel to handle independent issues simultaneously.

## Your Task

Read skill file at `.ao/skills/ao-parallel/SKILL.md` and follow the parallel dispatch process.

## Quick Process

1. **Analyze** - Check issues for independence and conflicts
2. **Create** - Generate focused agent tasks for each independent issue
3. **Dispatch** - Run agents in parallel
4. **Monitor** - Track progress and detect conflicts
5. **Aggregate** - Collect results and test for regressions

## Dependency Analysis

For each issue to dispatch:
- Check if issue depends on other open issues
- Check if issue shares files/modifies with other issues
- Check if issue affects same subsystem/component

**Classify as:**
- ✅ INDEPENDENT - Safe for parallel work
- ⚠️ BLOCKING - Must fix first, blocks others
- ❌ CONFLICTING - Cannot work in parallel

## Conflict Detection

When results return:

**Check for file conflicts:**
```python
# Pseudocode
file_modifications = {}
for agent_result in results:
    for file in agent_result.modified_files:
        if file in file_modifications:
            CONFLICT detected
            Report: "Agent {A} and Agent {B} both modified {file}"
```

**If conflict found:**
- STOP remaining agents
- Report conflict to user
- Recommend sequential execution
- Document in focus.json

## Remember

- **Never dispatch on main branch** - Use worktrees
- **Require issue independence** - No dependencies or shared files
- **Track conflicts** - Stop immediately if detected
- **Aggregate results** - Run full test suite after all complete
- **Measure performance** - Compare parallel vs sequential time

## When to Use Parallel Dispatch

✅ **USE** when:
- 3+ independent issues in queue
- Issues affect different subsystems
- No shared state between issues
- Sprint deadline approaching

❌ **DON'T USE** when:
- Issues are related (fixing one might fix others)
- Issues share code/files
- Need full system context
- Issues have dependencies

## Output

Update `.agent/ops/focus.json` with:
- Parallel dispatch analysis
- Agent assignments and progress
- Conflict detection results
- Final results aggregation
- Performance metrics (time saved)
