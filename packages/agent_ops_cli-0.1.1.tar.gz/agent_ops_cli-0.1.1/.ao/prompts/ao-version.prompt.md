---
name: ao-version
description: "Manage semantic versioning, generate changelogs from issues or git diff, and coordinate releases."
agent: AO
---

Manage versioning and releases using the `ao-versioning` skill.

## Commands

| Command | Description |
|---------|-------------|
| `/ao-version bump major` | Breaking changes → X.0.0 |
| `/ao-version bump minor` | New features → x.Y.0 |
| `/ao-version bump patch` | Bug fixes → x.y.Z |
| `/ao-version check` | Validate version consistency |
| `/ao-version unreleased` | Show changes since last release |
| `/ao-version release-notes` | Generate user-friendly release notes |
| `/ao-version from-git main` | Generate changelog from git diff |

## Input Sources

```bash
# From issues (default) - uses ao ls --status done
/ao-version bump minor

# From git diff - for teams not using AO issues
/ao-version bump minor --from main
/ao-version bump minor --from v2.0.0

# Hybrid - issues + catch commits without issues
/ao-version bump minor --include-git
```

## Pre-release Tags

```
/ao-version bump minor --prerelease beta
→ 2.0.0 → 2.1.0-beta.1
```

## What It Does

1. Queries `ao ls --status done` OR parses git commits (conventional commits)
2. Groups by type (Added, Fixed, Changed, Security, etc.)
3. Updates CHANGELOG.md with new version section
4. Updates README.md version badge and history table
5. Suggests git tag command (never auto-creates)

## Example

```
/ao-version bump minor

📦 Version Bump: 2.0.0 → 2.1.0

Changes detected (8 issues):
- Added: 3 features
- Fixed: 4 bugs
- Security: 1 fix

Update CHANGELOG.md and README.md? [Y/n]
```

## Git Diff Example

```
/ao-version from-git main

📋 Git Diff: main..HEAD (15 commits)
- feat: 4 commits
- fix: 6 commits  
- chore: 3 commits
- unparsed: 2 commits (need review)

Generate changelog? [Y/n]
```
