---
mode: agent
description: Create a production-ready Python project with proper structure, tooling, and best practices
---

# Create Python Project

Create a plan and implementation issues for a **production-ready Python project**.

## Your Task

Read the skill file at `.ao/skills/ao-create-python-project/SKILL.md` and follow its procedure to:

1. **Gather requirements** from user input (discussion, markdown, or interview)
2. **Design architecture** (modules, dependencies, interfaces)
3. **Create issues** for each component in `.agent/ops/issues/`
4. **Generate plan** with implementation order

## Input Sources

Accept one of:
- Markdown file with project requirements
- Pasted text describing the project
- Interactive interview if no input provided

## Output

- Implementation issues in priority files
- Ordered plan with dependencies
- Ready to scaffold: `uv sync && uv run python scripts/build.py`

## Key Standards

- **uv** for dependency management (always `uv run`)
- **ruff** for linting/formatting
- **mypy** for type checking
- **pytest** with ≥75% coverage
- **Thin CLI** pattern (typer)
- **src layout** with proper packaging
