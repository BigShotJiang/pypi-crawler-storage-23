Use the `ao-optimize-instructions` skill to reduce instruction file sizes.

## Quick Usage

```
/ao-optimize-instructions <file-path>
```

Or ask to "optimize my AGENTS.md" or "reduce instruction file size".

## When to Use

- Instruction file exceeds ~2000 lines
- Agent runs out of context during work
- File contains large code examples
- Preparing for smaller context models

## What It Does

1. **Analyzes** instruction file for extractable sections
2. **Plans** extraction to reference files
3. **Executes** with your approval
4. **Verifies** links and reports size reduction

## Optimization Strategies

| Strategy | Description |
|----------|-------------|
| Section extraction | Move large sections to `.github/reference/` |
| Example consolidation | Move code examples to `reference/examples/` |
| Tiered detail | Keep summary inline, link to full guide |

## Size Guidelines

| File Type | Recommended Max |
|-----------|-----------------|
| AGENTS.md | 1,000 lines |
| SKILL.md | 500 lines |
| copilot-instructions.md | 500 lines |

## Example Result

```
✅ Optimization Complete

Before: 2,450 lines (98k tokens)
After: 812 lines (32k tokens)
Reduction: 67%

Created:
- .github/reference/api-guidelines.md
- .github/reference/lang-python.md
```
