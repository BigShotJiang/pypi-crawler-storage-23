Use the `ao-project-sections` skill to identify and map project architecture.

## Quick Usage

```
/ao-sections
```

Or ask to "map the project structure" or "identify project sections".

## When to Use

- Starting work on an unfamiliar codebase
- Need to scope work to a specific layer (API, frontend, etc.)
- Generating architecture documentation
- Preparing focused context for implementation

## What You Get

A structured map of project sections:

| Section | Type | Root Path | Dependencies |
|---------|------|-----------|--------------|
| API | api | src/api/ | domain, database |
| Frontend | frontend | web/ | api |
| CLI | cli | src/cli/ | domain |

## Section Types

`api` · `frontend` · `backend` · `database` · `cli` · `domain` · `infrastructure` · `tests` · `config` · `docs` · `scripts` · `shared`

## Scoped Mode

After mapping, you can scope context to specific sections:

```
/ao-scope api          # Focus on API only
/ao-scope api,domain   # Focus on API and domain
/ao-scope clear        # Return to full context
```

## Example

```
> /ao-sections

## Project Sections: my-app

| Section | Type | Root | Key Files |
|---------|------|------|-----------|
| REST API | api | src/api/ | routes.py, handlers/ |
| Web UI | frontend | web/src/ | App.tsx, components/ |
| Data Layer | database | src/models/ | user.py, migrations/ |
| Business Logic | domain | src/domain/ | entities/, services/ |
```
