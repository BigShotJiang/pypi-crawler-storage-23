---
name: ao-constitution
description: "Create .agent/ops/constitution.md (v0), then interview user to confirm and finalize."
agent: Constitution
---

Goal: Create and maintain .agent/ops/constitution.md as the project-specific authority for:
- Allowed folders to work in / forbidden areas
- Build/lint/test/format commands
- Required environment assumptions (versions, tools)
- Quality gates (baseline rules, test expectations)
- Any project-specific constraints (no migrations, no API changes, etc.)

Use skill `ao-constitution` for the full workflow.

Process (mandatory):
1) Read current .agent/ops/* state files (focus/memory/tasks/baseline/constitution if exists).
2) Inspect repository structure and key config files to infer commands and boundaries (do not guess):
   - If evidence exists, propose it as "CANDIDATE (from file X)"
   - If not, mark as TODO/UNCONFIRMED
3) Write v0 constitution to .agent/ops/constitution.md (even if incomplete) with:
   - clear TODO/UNCONFIRMED sections
   - explicit rationale notes where possible ("why this boundary exists")
4) Interview the user:
   - Ask one question per TODO/UNCONFIRMED item.
   - Ask both "what should it be?" and "why?" for boundaries and commands.
5) Update .agent/ops/constitution.md based on answers until it has no blocking TODOs for baseline.
6) Update .agent/ops/focus.json and .agent/ops/issues/.

Stop condition:
- Constitution is "baseline-ready" only when build + test commands are confirmed and allowed work areas are confirmed.
