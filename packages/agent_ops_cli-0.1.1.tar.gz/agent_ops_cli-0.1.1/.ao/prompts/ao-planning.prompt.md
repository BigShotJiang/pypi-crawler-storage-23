---
mode: agent
description: Produce a thorough plan before implementation
tools:
  - read_file
  - grep_search
---

# Plan

Create a thorough implementation plan using enhanced brainstorming workflow.

## Your Task

Read skill file at `.ao/skills/ao-planning/SKILL.md` and follow the brainstorming process.

## Brainstorming Process (Enhanced)

### 1) Check Project State First (MANDATORY)

**Before planning, examine current project state:**
```
Check:
  - Current project files and structure
  - Existing documentation (README, docs/)
  - Recent commits and changes
  - Related issues or previous plans
  - Codebase architecture and patterns

Purpose:
  - Understand existing solutions
  - Identify patterns used in codebase
  - Avoid proposing solutions that already exist
  - Leverage existing architecture
```

### 2) Intake and Refine

```
Restate goal (1-3 lines):
  - What are we trying to solve?
  - Why does this matter?

List unknowns as explicit questions:
  - Don't assume answers
  - List what needs clarification
  - Stop and ask until clear

Scope boundaries:
  - What's explicitly OUT OF SCOPE for this issue?
  - What must NOT be changed?
```

### 3) Present Plan in Sections (200-300 words each)

**Break plan into sections:**
```
Section 1: {Architecture / Data Flow / Components}
  [200-300 words]
  Ask: Does this look right? (yes/no/revise)

Section 2: {Next area}
  [200-300 words]
  Ask: Does this look right? (yes/no/revise)

... (continue sections as needed)
```

### 4) Explore 2-3 Approaches (Alternatives Analysis)

**Don't create 2 iterations of same approach. Present alternatives:**
```
Approach 1: {Description}
  Pros: {list advantages}
  Cons: {list disadvantages}

Approach 2: {Different approach}
  Pros: {list advantages}
  Cons: {list disadvantages}

Approach 3: {Optional - another approach}
  Pros: {list advantages}
  Cons: {list disadvantages}

Lead with recommendation and explain why:
  - "I recommend Approach {N} because..."
  - Include specific trade-offs
  - Let user choose before detailed plan
```

### 5) YAGNI Enforcement (Ruthless Feature Pruning)

**For EVERY proposed feature, ask:**
```
"Do we REALLY need this?"
"What happens if we DON'T implement this?"
```

**Ruthlessly remove:**
- Nice-to-haves that add complexity
- Future-proofing for uncertain requirements
- Non-essential features

**Focus on:**
- Minimal viable solution
- Core functionality only
- Can ship faster
```

### 6) Incremental Validation

**After each section, validate:**
```
Ask: "Does this section look right so far?"
Be ready to:
  - Revise previous sections
  - Don't proceed until validated

Benefits:
  - Early course correction
  - Reduced rework
  - Continuous feedback
```

### 7) Document Flexibility

**Add revision capability:**
```
Document in plan:
  - "You can ask me to revise any previous section"
  - "No section is final until full plan is reviewed"
  - "I can modify any section if you discover issues later"

This encourages:
  - Don't get locked into a path
  - Iterate based on feedback
  - Change approach if better solution emerges
```

## Remember

- **Project state check first** - Avoid proposing solutions that already exist
- **Section-based planning** - 200-300 word sections with validation
- **Alternatives exploration** - 2-3 approaches with trade-offs
- **YAGNI enforcement** - Ruthlessly question every proposed feature
- **Incremental validation** - Validate after each section
- **Flexibility documentation** - Allow revision of any section
- **Interview if needed** - Stop and ask if unclear

## Output Format

**For each section:**
```
## Section {N}: {Title}

[200-300 words describing this section]

---
Does this section look right? (yes/no/revise)

[If revise, go back to relevant section]
```

**For alternatives:**
```
## Approach Options

### Approach 1: {Description}
**Pros:**
- {pro 1}
- {pro 2}

**Cons:**
- {con 1}
- {con 2}

### Approach 2: {Description}
**Pros:**
- {pro 1}
- {pro 2}

**Cons:**
- {con 1}
- {con 2}

## Recommendation

I recommend **Approach {N}** because:
{reason with trade-offs}

Continue with detailed plan for chosen approach? (yes/no/choose approach)
```
