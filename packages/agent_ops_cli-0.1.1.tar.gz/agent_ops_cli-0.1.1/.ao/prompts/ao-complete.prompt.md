---
mode: agent
description: Verify issue completion before marking done
tools:
  - read_file
  - run_in_terminal
---

# Complete Issue

Verify issue completion with evidence-based Gate Function before marking done.

## Your Task

Read the skill file at `.ao/skills/ao-complete/SKILL.md` and follow the Gate Function process.

## Gate Function Process

1. **IDENTIFY** - What command proves this claim?
2. **RUN** - Execute the FULL command (fresh, complete)
3. **READ** - Full output, check exit code, count failures
4. **VERIFY** - Does output confirm the claim?
5. **ONLY THEN** - Make the claim

## Remember

- **NO completion claims without fresh verification evidence**
- Don't use "should", "probably", "seems to"
- Don't express satisfaction before verification
- Don't trust agent reports without checking
- Run FULL verification command every time
- Check exit code explicitly
- Read full output, not just summary

## Red Flags to Avoid

❌ Wrong: "Tests should pass"
✅ Right: Run `pytest`, see exit code 0, read "PASSED" in output

❌ Wrong: "Build probably succeeded"
✅ Right: Run `npm run build`, see exit code 0

❌ Wrong: "Code looks correct"
✅ Right: Run `ruff check .`, verify no errors in output

## Output

After verification:
- If **PASSED**: Update issue to `done`, move to `history.md`, update `focus.json`
- If **FAILED**: Set issue to `blocked`, document reason, do NOT mark done
