---
name: markdown-to-jira
description: "Convert standard markdown to Jira-compatible wiki markup"
---
Use the `markdown-to-jira` skill for converting standard markdown to Jira-compatible wiki markup.

## Quick Usage

Provide a markdown file path:
```
Convert docs/release-notes.md to Jira format
```

Or paste markdown content directly:
```
Convert this to Jira markup:

# My Heading
- Item 1
- Item 2
```

## When to Use

- Copying markdown documentation into Jira issues
- Preparing release notes for Jira
- Migrating markdown content to Confluence/Jira

## Key Conversions

| Markdown | Jira |
|----------|------|
| `**bold**` | `*bold*` |
| `*italic*` | `_italic_` |
| `# Heading` | `h1. Heading` |
| `` `code` `` | `{{code}}` |
| `[text](url)` | `[text\|url]` |
