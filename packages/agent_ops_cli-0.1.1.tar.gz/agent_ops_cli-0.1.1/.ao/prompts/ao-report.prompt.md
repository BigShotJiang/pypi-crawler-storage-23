---
name: ao-report
description: "Generate project status reports from issues. Supports summary, detailed, epic progress, history, and burndown views with filters."
agent: AO
---

Generate a report from AO issues.

## Report Types

| Type | Use When |
|------|----------|
| `summary` | Quick overview of open issues (default) |
| `detailed` | Full issue details with descriptions |
| `epic` | Progress on a specific epic |
| `history` | Completed work over time |
| `burndown` | Velocity and completion projection |

## Filters

Combine any filters:
- `type:BUG,FEAT` — filter by issue type
- `priority:critical,high` — filter by priority
- `epic:FEAT-0010@xyz789` — filter by parent epic
- `status:open,blocked` — filter by status
- `from:2026-01-01 to:2026-01-15` — date range
- `label:api` — filter by label

## Examples

```
/ao-report
→ Summary report of all open issues

/ao-report detailed priority:critical
→ Full details for critical issues only

/ao-report epic FEAT-0010@xyz789
→ Progress report for that epic

/ao-report history type:BUG from:2026-01-01
→ Bugs completed since Jan 1

/ao-report burndown
→ Velocity and completion estimate
```

## Output

- Default: Display in chat
- `--file`: Save to `.agent/ops/reports/`
- `--json`: Output as JSON (for tooling)

Invoke `ao-report` skill.
