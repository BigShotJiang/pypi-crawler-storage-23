---
mode: agent
description: Conduct structured interviews with users
tools:
  - read_file
---

# Interview

Conduct structured interviews with users, asking ONE question at a time.

## Your Task

Read skill file at `.ao/skills/ao-interview/SKILL.md` and follow the interview workflow.

## Interview Workflow

**1. Setup:**
```
List all questions internally (don't show to user yet).
Mark which are multiple choice vs open-ended.
```

**2. Ask Q1:**
```
If multiple choice:
  Present with labeled options (A, B, C, D, E)
  Include "Other (please specify)" option for unlisted choices
  Use clear format:

Q1: Which API style fits this project?

A) REST — Simple, cacheable, broad tooling. Best for CRUD-heavy APIs.
B) GraphQL — Flexible queries, single endpoint. Best for complex data needs.
C) gRPC — High performance, typed contracts. Best for internal services.
D) Something else? — If you have another preference in mind.

Your choice (A/B/C/D/E or type "other: {value}"):
```

If open-ended:
  Ask question with clear format
  Keep it specific to context

Q1: What's your preferred programming language for the API backend?
```

**3. Wait:**
```
Do not proceed until user responds.
```

**4. Record:**
```
Update focus.json with the answer:
- If multiple choice: Record exact choice (A/B/C/D/E or "other: {value}")
- If open-ended: Record user's answer
```

**5. Ask Q2+:**
```
Repeat for all questions
Build on previous answers if relevant
```

**6. Summarize:**
```
Present all answers for confirmation.
```

## Multiple Choice Questions

**Format:**
```
Q{N}: {Clear question text}

Options:
A) {Option label}: {Brief description}
B) {Option label}: {Brief description}
C) {Option label}: {Brief description}
D) {Option label}: {Brief description}

E) Other (please specify): [______]

Your choice (A/B/C/D/E or type "other: {value}"):
```

**When to Use Multiple Choice:**
- Options are well-defined and limited (3-6 options)
- User needs to choose from predefined set
- Custom "Other" option available for unlisted choices
- Decision is categorical, not open-ended

**When to Use Open-Ended:**
- Complex answers need elaboration
- User's input is unique and can't be predicted
- Information gathering (free-form text)
- Clarifying follow-up questions

**Examples:**

**Multiple Choice:**
```
Q1: Which issue tracking system should we use?

A) GitHub Issues
   - Native to GitHub, good for open source
   - Simple and familiar to most developers
   - Free public projects

B) Linear
   - Great UI, excellent keyboard workflow
   - Good for both personal and team use
   - Free tier available

C) Jira
   - Enterprise features, customizable workflows
   - Good for large teams
   - More complex setup

D) Azure Boards
   - Integrated with Azure DevOps
   - Good for Microsoft stack
   - Requires Azure subscription

E) Other (please specify): [______]

Your choice (A/B/C/D/E or type "other: {value}"):
```

**Open-Ended:**
```
Q2: Can you describe your deployment architecture?

Expected answer: Something like:
"Using AWS ECS with Fargate for container orchestration,
with CloudFront for CDN and Route53 for DNS."
```

## Remember

**One question per message** — Never batch multiple questions.
**Present clear options** — Each question should have labeled options (A, B, C) or a clear format.
**Wait for response** — Don't proceed until user answers.
**Record immediately** — Note answer in focus.json before asking next question.
**Allow escape** — User can say "skip", "defer", "use your recommendation", or "stop".
**Multiple choice format** — For categorical decisions, present labeled options (A-E) with "Other" option.
**Open-ended format** — For elaboration, information gathering, unique situations.

## Output Format

For multiple choice questions, use this format:

```
Q{N}: {Question}

Options:
A) {Label}: {Description}
B) {Label}: {Description}
C) {Label}: {Description}
D) {Label}: {Description}

E) Other (please specify): [______]

Your choice (A/B/C/D/E or type "other: {value}"):
```

For open-ended questions, use this format:

```
Q{N}: {Question}

Expected answer: {What you're looking for}
```

## Special Responses

| User says | Action |
|-----------|--------|
| "skip" | Mark as SKIPPED, move to next question |
| "defer" | Mark as DEFERRED, move to next question |
| "use your recommendation" | Apply agent's recommended default, note it |
| "stop" / "pause" | End interview, save progress, can resume later |
| "go back" | Re-ask previous question |
| unclear answer | Ask a brief clarifying follow-up (still counts as same question) |
