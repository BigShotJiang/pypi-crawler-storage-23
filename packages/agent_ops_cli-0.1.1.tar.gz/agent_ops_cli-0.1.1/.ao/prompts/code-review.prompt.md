---
mode: agent
description: Automated code review with subagent
tools:
  - read_file
  - grep_search
  - run_in_terminal
---

# Code Review

Run automated code review with subagent for quality assessment.

## Your Task

Read skill file at `.ao/skills/ao-review/SKILL.md` and follow the two-stage review process.

## Two-Stage Process

### Stage 1: Plan Compliance Review

**Check FIRST** before code quality review:

```
Does implementation match plan?
✓ All requirements met
✓ No extra features added
✓ Follows specified approach

If NO:
  → BLOCK progress
  → Identify plan deviations
  → Require corrections

If YES:
  → Proceed to Stage 2: Code Quality Review
```

### Stage 2: Code Quality Review

**Review categories:**

| Category | Definition | Action |
|-----------|-----------|--------|
| **Critical** | Security, breaking, test failures | BLOCK - must fix |
| **Important** | Missing error handling, performance, duplication | Should fix before next task |
| **Minor** | Style, refactoring suggestions | Optional, nice to have |

**Assessment:**
- APPROVED: Can continue
- REJECTED: Block until fixes
- APPROVED with Important: Fix Important before continuing

## Remember

- **Two-stage process**: Plan compliance FIRST, then code quality
- **Critical findings block progress**: Can't continue until fixed
- **Important findings should be addressed**: Fix before next task or get approval
- **Minor findings are optional**: Can defer
- **Subagent has fresh context**: No pollution from implementation work
- **Document findings in issue notes**: Create review history

## Output Format

```
Code Review Results: Diff between BASE (abc123) and HEAD (def456)

## Stage 1: Plan Compliance

✓ All requirements met
✓ No extra features added
✓ Follows specified approach

Result: SPEC COMPLIANT ✓

---

## Stage 2: Code Quality

✓ Strengths: Clean separation of concerns, comprehensive tests

⚠ Important: Missing input validation on email field
  File: src/auth.py
  Line: 45
  Issue: No validation before database insert
  Recommendation: Add email regex validation

• Minor: Extract magic number (100) to constant
  File: src/auth.py
  Line: 78
  Suggestion: Define MAX_RETRY_ATTEMPTS = 100

Assessment: APPROVED (Important fix required before proceeding)
```

## Update Issue Notes

Add to {ISSUE-ID} notes:
```markdown
### Code Review [Date]

Stage 1: Plan Compliance
  ✓ All requirements met
  Result: SPEC COMPLIANT ✓

Stage 2: Code Quality
  ✓ Strengths: Clean code, good tests
  ⚠ Important: Missing input validation (fix before next task)
  • Minor: Extract magic numbers
  Result: APPROVED (Important fix required)
```

## Integration Points

The ao-review skill is invoked by:
- ao-implementation after each task/major feature
- Manual: `/ao-review`
- Pre-completion: Before moving issue to history
