---
name: ao-junior-explain
description: "Translate complex plans or implementations into junior-level explanations. If you can't explain it simply, you don't understand it."
category: analysis
invokes: [ao-state]
invoked_by: [ao-critical-review, ao-docs]
state_files:
  read: []
  write: []
---

# ao-junior-explain

Translate complex plans or implementations into junior-level explanations. If you can't explain it simply, you don't understand it.

## Purpose

Complex explanations often hide unclear thinking, unnecessary complexity, or missing understanding. This skill forces simplification as a correctness check.

## Trigger

- During review (optional)
- Before documentation
- For complex decisions
- On demand for any artifact

## Explanation Levels

| Level | Audience | Vocabulary | Max Concepts | Use When |
|-------|----------|------------|--------------|----------|
| **Intern** | First day on job | No jargon, concrete examples | 3 | Onboarding docs |
| **Junior** | 1-2 years experience | Minimal jargon | 5 | Standard docs |
| **Mid-level** | 3-5 years experience | Some jargon | 8 | Design docs |
| **Senior** | 5+ years experience | Full jargon | Unlimited | Spec docs |

## Simplicity Test

If you cannot explain it at the **Junior** level:
1. Your understanding is incomplete
2. The design is too complex
3. Simplicity is needed

## Related Skills

- `ao-docs` — documentation generation
- `ao-critical-review` — includes simplicity check
- `ao-improvement-discovery` — finds simplification opportunities
