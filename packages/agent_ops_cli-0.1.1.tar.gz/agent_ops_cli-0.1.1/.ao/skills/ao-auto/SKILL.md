---
name: ao-auto
description: "Autonomous work mode - actively finds and works on NORMAL and HIGH confidence issues without asking. LOW confidence issues are skipped and reported. Queries ao when no actionable issues exist and prompts for prioritization."
category: core
invokes: [ao-focus-scan, ao-implementation, ao-interview, ao-parallel]
invoked_by: [ao-worker]
state_files:
  read: [issues/active.jsonl, focus.json]
  write: [focus.json]
references: [.ao/reference/confidence.md]
---

# AO Auto — Autonomous Issue Work

## Purpose

**Enable autonomous work flow by continuously selecting and implementing NORMAL and HIGH confidence issues** without requiring user intervention between issues.

**LOW confidence issues are EXCLUDED** from ao-auto processing. They require explicit human oversight per AO safety protocols and are reported but not worked on.

The goal is to **keep working** on issues as long as there are NORMAL or HIGH confidence actionable items available, only asking the user when:
- No actionable issues remain in ao (`ao ls --ready` is empty)
- Only LOW confidence issues remain (auto cannot process them)
- Backlog triage is needed
- All remaining issues need clarification

## Core Principle

**Work autonomously on NORMAL and HIGH confidence issues, skip LOW confidence issues:**
```
IF actionable issues exist in ao (excluding LOW confidence):
    → Work on them autonomously (no prompts)
ELSE IF ao has backlog items:
    → Ask user for prioritization/triage
ELSE:
    → Ask what to work on next (discovery mode)
```

**IMPORTANT: ao-auto does NOT work on LOW confidence issues.** LOW confidence issues require explicit human oversight and are skipped by the autonomous loop.

## Autonomous Issue Selection Logic

### Step 1: Check ao for Actionable Issues (Autonomous Path)

Query `ao ls` for actionable issues with NORMAL or HIGH confidence:

```
1. Run: ao ls --ready --sort priority
2. Filter for issues with ALL of these properties:
    - status: todo or in_progress
    - Not blocked
    - Not cancelled or dropped
    - No unresolved questions
    - All depends_on dependencies are done
    - confidence: normal OR high (NOT low)
```

**NOTE: LOW confidence issues are EXCLUDED from ao-auto autonomous processing.**

### Step 2: Found Actionable Issue? → Work Autonomously

**If any actionable issue exists in priority files:**

```
🔄 AUTONOMOUS MODE — Working on issues without interruption

Found {N} actionable issue(s):
- {ISSUE-ID} — {title}
- {ISSUE-ID} — {title}

Selecting highest priority issue for work...
```

**Then:**
1. Update `focus.json` with current issue
2. Implement the issue (invoke ao-implementation or follow iteration script)
3. After completion, **repeat from Step 1** (loop back to find next issue)
4. Continue until no more actionable issues in priority files

**No user confirmation needed** between issues. Just report progress:

```
✅ Completed: {ISSUE-ID} — {title}

Scanning for next issue...
→ Found: {ISSUE-ID} — {title}
→ Starting implementation...
```

### Step 3: No Actionable Issues? → Check Reasons

If no actionable issues found in priority files, **determine WHY**:

#### Case A: All issues need clarification

If there are issues but they all have unresolved questions:

```
📋 All remaining issues need clarification

Found {N} issue(s) blocked by questions:
- {ISSUE-ID} — {title} ({N} questions)
- {ISSUE-ID} — {title} ({N} questions)

Options:
1. Start clarification interview (will prompt for each question)
2. Create new issue to work on instead
3. Exit to let you decide

[1] Interview  [2] New issue  [3] Exit
```

#### Case B: No actionable issues in ao

If `ao ls --ready` returns **no issues**:

**⛔ HARD STOP — Backlog promotion requires human approval. Agent MUST NOT promote issues from backlog autonomously.**

```
📋 No actionable issues found

ao ls --ready returned 0 issues. Checking backlog...

{N} item(s) with priority:backlog:
  ao ls priority:backlog

- {ISSUE-ID} — {title}
- {ISSUE-ID} — {title}

⛔ HARD STOP: Only the human can promote issues from backlog.

Options:
1. Promote issues from backlog to priority (**human selects which — agent MUST NOT promote autonomously**)
2. Run backlog triage to review and prioritize
3. Create new issue
4. Run discovery to find work

[1] Promote  [2] Triage  [3] New issue  [4] Discovery
```

If user selects **Option 1 (Promote)**:
```
Select issues to promote (comma-separated IDs):
Available:
  • {ISSUE-ID} — {title}
  • {ISSUE-ID} — {title}
  • {ISSUE-ID} — {title}

Enter IDs or "all": _
```

If user selects **Option 2 (Triage)**:
- Invoke ao-task triage on backlog items
- After triage, **repeat autonomous loop from Step 1**

#### Case C: Priority files exist but blocked/need clarification

If priority files have issues but none are actionable:

```
📋 Found {N} issue(s) but none are actionable

Blocked issues:
- {ISSUE-ID} — {title} (blocked by {blocker})
- {ISSUE-ID} — {title} (blocked by {blocker})

Issues needing clarification:
- {ISSUE-ID} — {title} ({N} questions)
- {ISSUE-ID} — {title} ({N} questions)

Options:
1. Resolve blockers first
2. Clarify issues first
3. Create new issue to work on
4. Exit

[1] Blockers  [2] Clarify  [3] New issue  [4] Exit
```

## Autonomous Continuation Loop

### Main Loop Algorithm

```
function autonomous_continue_loop():
    WHILE True:
        // Step 1: Find actionable issues (NORMAL or HIGH confidence only)
        actionable_issues = scan_priority_files_for_actionable()

        // Step 1.5: Check for LOW confidence issues
        low_confidence_issues = scan_for_low_confidence_issues()
        IF len(low_confidence_issues) > 0:
            log("⚠️ Skipped {len(low_confidence_issues)} LOW confidence issue(s) - require human oversight")
            // List them for awareness
            FOR issue IN low_confidence_issues:
                log("   - {issue.id} — {issue.title} (confidence: low)")

        // Step 2: If found, work autonomously
        IF len(actionable_issues) > 0:
            issue = select_highest_priority(actionable_issues)
            log("🔄 Working on: {issue.id} — {issue.title}")
            update_focus(issue)

            // IMPLEMENT: Execute full 5-phase workflow via implement_issue()
            // This helper function handles: PLAN → IMPLEMENT → VALIDATE → REVIEW → COMPLETE → ARCHIVE
            success = implement_issue(issue)

            IF success:
                log("✅ Completed: {issue.id} — {issue.title}")
                // Note: mark_as_done() is called within implement_issue(), so we don't call it again
                // LOOP: Go back to Step 1 for next issue
                CONTINUE
            ELSE:
                // Implementation failed
                log("⚠️ Failed: {issue.id} — {issue.title}")
                log("   Error: {success.error}")
                BREAK  // Exit loop, ask user what to do

        // Step 3: No actionable issues - determine why
        priority_issues = run_aoi_ls(status=["todo", "in_progress"])

        IF len(priority_issues) == 0:
            // Case: All priority files empty
            handle_empty_priority_files()
            BREAK  // Exit loop after handling

        ELSE:
            // Case: Issues exist but not actionable
            IF all_need_clarification(priority_issues):
                handle_clarification_needed()
                BREAK  // Exit loop after handling
            ELSE:
                handle_blocked_or_mixed_issues()
                BREAK  // Exit loop after handling
```

**Key:** LOW confidence issues are detected and reported but NOT worked on. They require manual selection with explicit human oversight. The `implement_issue()` helper function now executes the complete 5-phase workflow including validation (ao-validation), testing, review (ao-critical-review), and closing in ao (via ao-complete).

### Actionable Issue Criteria

An issue is **actionable** (for ao-auto) if ALL of these are true:

| Criterion | Check |
|-----------|-------|
| **Status** | `todo` or `in_progress` |
| **Blocked** | Not `blocked` (or has no `blocked_by`) |
| **Cancelled** | Not `cancelled` or `dropped` |
| **Clarification** | No unresolved `- [ ]` questions |
| **Dependencies** | All `depends_on` items are `done` |
| **Confidence** | `normal` or `high` (**NOT `low`**) |

**LOW confidence issues are NOT actionable for ao-auto.** They require explicit human oversight per AO safety protocols.

### Scan Priority Files Helper

```
function scan_for_actionable():
    // Run: ao ls --ready --sort priority
    all_issues = run_aoi_ls(ready=True, sort='priority')
    actionable = [i for i in all_issues if i.confidence in ('normal', 'high')]
    RETURN actionable
```

**Key: Only issues with `confidence: normal` or `confidence: high` are considered actionable for ao-auto.** LOW confidence issues are filtered out during scanning.

### Scan for LOW Confidence Issues Helper

```
function scan_for_low_confidence_issues():
    // Run: ao ls --confidence low
    all_issues = run_aoi_ls(confidence='low', status=['todo', 'in_progress'])
    RETURN all_issues
```

This helper detects and reports LOW confidence issues for user awareness, but they are NOT worked on by ao-auto.

### Select Highest Priority Helper

```
function select_highest_priority(issues):
    // Issues are already sorted by file priority (critical > high > medium > low)
    // Within same priority, pick by:
    // 1. created date (oldest first)
    // 2. depends_on dependencies (fewer first)
    // 3. effort (smaller first)

    RETURN issues[0]
```

### Implement Issue Helper

```
function implement_issue(issue):
    // Execute full 5-phase workflow for an issue
    // This follows the iteration script from ao-worker.agent.md

    // PHASE 1: PLAN
    log("📋 Planning: {issue.id} — {issue.title}")

    // Check if plan already exists in issue reference or focus.json
    IF issue has plan OR focus.json has plan:
        log("  → Plan exists, skipping ao-planning")
    ELSE:
        // Invoke ao-planning to create/validate plan
        invoke_ao_planning(issue)
        log("  → Plan created/validated")

    // PHASE 2: IMPLEMENT
    log("🔨 Implementing: {issue.id} — {issue.title}")

    // Invoke ao-implementation to do the implementation
    // This handles: small diffs, frequent tests, update log entries
    invoke_ao_implementation(issue)

    // Update focus.json with implementation progress
    update_focus("Implementation complete, starting validation")

    // PHASE 3: VALIDATE
    log("🧪 Validating: {issue.id} — {issue.title}")

    // Invoke ao-validation to run validation checks
    // This runs: build, lint, tests, coverage checks
    validation_result = invoke_ao_validation(issue)

    IF validation_result.failed:
        log("  ❌ Validation failed: {validation_result.reason}")
        log("  → Stopping workflow, do not mark as done")
        RETURN {success: false}

    // Check test coverage if required by confidence
    IF issue.confidence == 'LOW':
        // LOW confidence requires ≥90% line, ≥85% branch coverage
        coverage = check_test_coverage()

        IF coverage.line < 90 OR coverage.branch < 85:
            log("  ❌ Coverage insufficient: {coverage.line}% line, {coverage.branch}% branch")
            log("  → Required: ≥90% line, ≥85% branch for LOW confidence")
            RETURN {success: false}

        log("  ✅ Coverage sufficient: {coverage.line}% line, {coverage.branch}% branch")

    // PHASE 4: REVIEW
    log("🔍 Reviewing: {issue.id} — {issue.title}")

    // Invoke ao-critical-review for code review
    review_result = invoke_ao_critical_review(issue)

    // LOW confidence requires MANDATORY human approval
    IF issue.confidence == 'LOW' AND NOT review_result.approved_by_human:
        log("  ❌ LOW confidence requires human review before completion")
        log("  → Awaiting human approval...")
        RETURN {success: false, needs_approval: true}

    log("  ✅ Review complete")

    // PHASE 5: COMPLETE AND ARCHIVE
    log("📦 Completing: {issue.id} — {issue.title}")

    // Invoke ao-complete to verify and archive
    complete_result = invoke_ao_complete(issue)

    IF complete_result.verified:
        log("  ✅ Verified, closed in ao")
        RETURN {success: true}
    ELSE:
        log("  ❌ Verification failed, NOT archived")
        RETURN {success: false}
```

### Mark as Done Helper

```
function mark_as_done(issue):
    // This function marks an issue as done and archives it
    // Should only be called AFTER successful validation

    log("🏁 Running completion gate for: {issue.id}")

    // Invoke ao-complete to verify and archive
    complete_result = invoke_ao_complete(issue)

    IF complete_result.verified:
        // Update issue status to done
        issue.status = 'done'
        issue.completed_at = current_timestamp()
        issue.duration_minutes = complete_result.duration_minutes

        // Close the issue in ao
        run_command(f'ao --yes issue patch {issue.id} status:done')

        log("✅ Issue completed and archived: {issue.id}")
        RETURN {success: true}
    ELSE:
        log("❌ Completion verification failed for: {issue.id}")
        RETURN {success: false}
```

### Archive to History Helper

```
function archive_to_history(issue):
    // Close the issue in ao and log completion
    run_command(f'ao --yes issue patch {issue.id} status:done')
    run_command(f'ao --yes log add {issue.id} "Completed (ao-auto autonomous session)"')
```

## Integration with ao-worker

### Entry Point from "Auto" Handoff

When user selects "Auto" from handoff options:

```
1. Invoke ao-auto skill
2. Skill starts autonomous work loop
3. Works through issues autonomously
4. Stops only when:
   - No more actionable issues in priority files
   - User interrupts (Ctrl+C or new message)
   - Error occurs requiring human decision
5. On stop, present next options
```

### After Autonomous Session Ends

When the autonomous loop stops, **present handoff options**:

```
🏁 Autonomous session complete

Completed in this session:
✅ {ISSUE-ID} — {title}
✅ {ISSUE-ID} — {title}
✅ {ISSUE-ID} — {title}

Status:
- {N} issues completed
- {N} issues remaining in priority files
- {N} items in backlog

What would you like to do next?

A) Continue — Keep working autonomously
B) Report — View status report
C) Triage — Review and prioritize backlog
D) New issue — Create new issue
E) Discovery — Find work to do
```

## Confidence Handling

### Autonomy Rules by Confidence

| Confidence | Autonomous Behavior |
|------------|---------------------|
| **LOW** | **NOT worked on by ao-auto** - skipped and reported |
| **NORMAL** | Work on up to 3 issues autonomously |
| **HIGH** | Work on up to 5 issues autonomously |

**IMPORTANT:** ao-auto **EXCLUDES** all LOW confidence issues. LOW confidence issues require explicit human oversight and are not eligible for autonomous processing. They are detected, logged, and reported but not worked on.

### Batch Validation

When selecting issues for autonomous work:

```
IF confidence == NORMAL:
    max_issues = 3  // Hard limit
    Can work on up to 3 issues without asking

ELSE IF confidence == HIGH:
    max_issues = 5  // Hard limit
    Can work on up to 5 issues without asking
```

**LOW confidence issues are filtered out before batch validation.**

### LOW Confidence Issue Handling

When ao-auto encounters LOW confidence issues:

```
⚠️ Skipped {N} LOW confidence issue(s) - require human oversight
   - {ISSUE-ID} — {title} (confidence: low)
   - {ISSUE-ID} — {title} (confidence: low)

🔄 Continuing scan for NORMAL/HIGH confidence issues...
```

**These LOW confidence issues are:**
- Detected during scanning
- Logged to focus.json for awareness
- Reported to user
- NOT processed by autonomous loop
- Require manual selection with explicit approval

### Conflict Detection (Safety)

**Do NOT work autonomously if:**

```
IF user said "autonomous" and only LOW confidence issues exist:
    // No action - ao-auto cannot work on LOW confidence issues
    REPORT:
    "Only LOW confidence issues available. These require human oversight.
     Use /ao-implement with explicit selection or /ao-task to create new issues."
    STOP
```

## CLI Reference (ao commands)

Use `ao` to query and manage issues:

```bash
# Find actionable issues (NORMAL/HIGH confidence only)
ao ls --ready --sort priority

# List by priority level
ao ls priority:critical
ao ls priority:high
ao ls priority:normal

# Find LOW confidence issues (for awareness)
ao ls --confidence low

# Find backlog items (HUMAN-ONLY promotion — agent must ask first)
ao ls priority:backlog

# Promote from backlog: patch priority (HUMAN selects — agent must not do this autonomously)
# ao --yes issue patch <ID> priority:high
```

## Example Sessions

### Example 1: Autonomous Multi-Issue Session

```
User: Auto

🔄 AUTONOMOUS MODE — Scanning for issues...

⚠️ Skipped 2 LOW confidence issue(s) - require human oversight
   - LOW-0089 — Update README documentation (confidence: low)
   - LOW-0090 — Fix typo in config (confidence: low)

🔄 Continuing scan for NORMAL/HIGH confidence issues...

Found 3 actionable issues:
- CRIT-0023 — Fix authentication bug (critical, confidence: high)
- HIGH-0018 — Add user profile API (high, confidence: normal)
- MED-0045 — Update email templates (medium, confidence: normal)

Selecting highest priority: CRIT-0023
→ Implementing...

✅ Completed: CRIT-0023 — Fix authentication bug

Scanning for next issue...
⚠️ Skipped 1 LOW confidence issue(s) - require human oversight
   - LOW-0091 — Fix indentation in CSS (confidence: low)

🔄 Continuing scan for NORMAL/HIGH confidence issues...
→ Found: HIGH-0018 — Add user profile API
→ Implementing...

✅ Completed: HIGH-0018 — Add user profile API

Scanning for next issue...
→ Found: MED-0045 — Update email templates
→ Implementing...

✅ Completed: MED-0045 — Update email templates

Scanning for next issue...
📋 No more NORMAL/HIGH confidence issues in priority files

🏁 Autonomous session complete

Completed 3 issues:
✅ CRIT-0023 — Fix authentication bug (confidence: high)
✅ HIGH-0018 — Add user profile API (confidence: normal)
✅ MED-0045 — Update email templates (confidence: normal)

Skipped 3 LOW confidence issues (require manual processing):
⚠️ LOW-0089 — Update README documentation
⚠️ LOW-0090 — Fix typo in config
⚠️ LOW-0091 — Fix indentation in CSS
```
✅ CRIT-0023 — Fix authentication bug
✅ HIGH-0018 — Add user profile API
✅ HIGH-0019 — Update email templates

Options:
A) Clarify remaining issues
B) Create new issue
C) Report status
```

### Example 2: Empty Priority Files, Promote from Backlog

```
User: Continue

🔄 AUTONOMOUS MODE — Scanning for issues...

🔍 Running: ao ls --ready --sort priority
  → 0 actionable issues found

📋 No actionable issues found

Running: ao ls priority:backlog
Found 5 backlog items:
- IDEA-0010 — Add dark mode theme
- IDEA-0011 — Mobile app integration
- IDEA-0012 — Export to PDF
- IDEA-0013 — Team collaboration
- IDEA-0014 — Analytics dashboard

All priority files are empty. Please prioritize backlog items.

Options:
1. Promote specific issues (you select which)
2. Run triage to review all backlog
3. Create new issue
4. Exit to manual mode

[1] Promote  [2] Triage  [3] New issue  [4] Exit
```

### Example 3: All Issues Need Clarification

```
User: Continue

🔄 AUTONOMOUS MODE — Scanning for issues...

Found 3 issues but none are actionable:

Issues needing clarification:
- FEAT-0023 — OAuth integration (4 questions)
- FEAT-0024 — Password reset flow (2 questions)
- BUG-0031 — Session timeout error (1 question)

All remaining issues have unresolved questions.

Options:
1. Start clarification interview
2. Create new issue instead
3. Exit to manual mode

[1] Interview  [2] New issue  [3] Exit
```

## Error Handling

### On Implementation Failure

If an issue fails to implement:

```
⚠️ Implementation failed: {ISSUE-ID} — {title}

Error: {error_message}

Stopping autonomous mode.

Options:
1. Retry this issue
2. Skip to next issue
3. Create new issue to work on
4. Exit to manual mode

[1] Retry  [2] Skip  [3] New issue  [4] Exit
```

### On Validation Failure

If tests fail and cannot be auto-fixed after 2 attempts:

```
❌ Validation failed: {ISSUE-ID} — {title}

Tests failed after 2 fix attempts.
Regressions detected vs baseline.

Stopping autonomous mode for review.

Failed tests:
- {test_name}: {error}
- {test_name}: {error}

Options:
1. Review and fix manually
2. Revert changes
3. Mark as blocked and continue with next issue
4. Exit

[1] Review  [2] Revert  [3] Block & continue  [4] Exit
```

## Logging and Progress

### Session Summary

After each autonomous session, log to `focus.json`:

```markdown
## Autonomous Session: {timestamp}

Duration: {minutes} minutes
Issues Completed: {N}
Issues Failed: {N}

### Completed
- ✅ {ISSUE-ID} — {title} ({duration} min)
- ✅ {ISSUE-ID} — {title} ({duration} min)

### Failed
- ❌ {ISSUE-ID} — {title} — {reason}

### Next Steps
- {next_action}
```

### Issue Progress Updates

For each issue worked on, update its `### Log` section:

```markdown
### Log
- [YYYY-MM-DD HH:MM] Started (autonomous session {session_id})
- [YYYY-MM-DD HH:MM] Implemented changes
- [YYYY-MM-DD HH:MM] Validated: {tests_passed}/{tests_total}
- [YYYY-MM-DD HH:MM] Completed
```

## Edge Cases

### Edge Case 1: Mixed Priorities with LOW Confidence

```
Found issues:
- CRIT-0023 (confidence: high) — critical bug
- HIGH-0018 (confidence: normal) — feature
- MED-0045 (confidence: low) — refactor

Autonomous rules apply:
- Can work on CRIT-0023 and HIGH-0018 autonomously (total 2, within limits)
- MED-0045 (low) requires human review before close

Strategy:
1. Work on CRIT-0023 autonomously
2. Work on HIGH-0018 autonomously
3. STOP before MED-0045
4. Ask: "Low confidence issue MED-0045 requires review. Proceed?"
```

### Edge Case 2: Dependencies

```
Issue FEAT-0023 depends_on: [FEAT-0020, FEAT-0021]

If FEAT-0020 and FEAT-0021 are NOT done:
  → FEAT-0023 is NOT actionable
  → Skip it, select next issue

If FEAT-0020 is done, FEAT-0021 is in_progress:
  → FEAT-0023 is NOT actionable
  → Skip it, select next issue

If FEAT-0020 and FEAT-0021 are both done:
  → FEAT-0023 IS actionable
  → Select it for work
```

### Edge Case 3: Circular Dependencies

```
FEAT-0020 depends_on: [FEAT-0021]
FEAT-0021 depends_on: [FEAT-0020]

Both blocked by each other → neither is actionable

Autonomous loop will detect this:
→ Skip both issues
→ Move to next priority level
→ Log warning: "Circular dependency detected between FEAT-0020 and FEAT-0021"
```

## Integration Notes

### With ao-focus-scan

The ao-auto skill uses the same scanning logic as ao-focus-scan but adds:
- Autonomous loop (don't stop after first issue)
- Backlog promotion logic
- Clarification handling

### With ao-implementation

For each selected issue, ao-auto invokes ao-implementation:
- This runs the full iteration script (plan → implement → validate → review)
- After completion, loop continues to next issue

### With ao-interview

When issues need clarification, ao-auto invokes ao-interview:
- Prompts user for each unresolved question
- Updates issue with answers
- After clarification completes, issue becomes actionable
- Autonomous loop can then continue with that issue

### Parallel Agent Dispatch (Optional — Platform-Dependent)

> **Credit**: Parallel dispatch concept adapted from obra/superpowers by Jesse Vincent (MIT License). See `skills/dispatching-parallel-agents/SKILL.md`.

When **3 or more independent issues** are actionable simultaneously, consider dispatching them in parallel using subagents rather than working sequentially.

#### When to Use Parallel Dispatch

| Condition | Use Parallel? |
|-----------|--------------|
| 3+ independent issues with NO shared files | ✅ Yes |
| Issues modify overlapping files | ❌ No — sequential only |
| Issues have dependency chains | ❌ No — respect depends_on |
| Mix of NORMAL and HIGH confidence | ✅ Yes (same rules per agent) |
| Any LOW confidence issues | ❌ No — LOW excluded from ao-auto entirely |

#### How to Dispatch

```
1. Identify independent issues (no shared file dependencies)
2. For each issue, dispatch a subagent:
   - Each agent gets: issue context, constitution, baseline
   - Each agent works in isolation on its assigned issue
   - Each agent follows the full 5-phase workflow
3. Wait for all agents to complete
4. Review and integrate results:
   - Check for unexpected conflicts
   - Run full test suite after integration
   - If conflicts found → resolve manually, DO NOT auto-merge
```

#### Platform Support

| Platform | Parallel Support | Mechanism |
|----------|-----------------|-----------|
| Claude Code | ✅ Yes | `Task` tool dispatches subagents |
| VS Code (Copilot) | ⚠️ Limited | Multiple chat sessions, no formal dispatch |
| OpenCode | ❌ No | Single-agent only |

#### Safety Rules for Parallel Dispatch

- Each subagent MUST follow all AO safety rules (hard-gates, confidence, etc.)
- After integration, run validation tier appropriate to confidence level
- If ANY subagent fails → stop and report (don't auto-retry)
- Maximum 5 parallel agents (prevent resource exhaustion)

## Configuration

### Environment Variables (Optional)

```
AO_AUTO_MAX_ITERATIONS=10  # Safety limit: max issues per session
AO_AUTO_TIMEOUT=3600        # Safety limit: max seconds per session
```

These are safeguards to prevent runaway autonomous sessions.

## Safety Gates

**Autonomous mode will STOP if:**

1. **Max iterations reached** (default: 10 issues)
2. **Max time reached** (default: 1 hour)
3. **Implementation fails** (cannot auto-recover)
4. **Validation fails** (regressions detected)
5. **User interrupts** (Ctrl+C or new message)
6. **No more actionable issues**

## Summary

**AO Continue = Autonomous issue work flow**

- **Always look** for issues first (don't ask by default)
- **Work autonomously** as long as actionable issues exist
- **Ask only when necessary** (empty priority files, needs clarification)
- **Respect safety rules** (confidence limits, batch limits, validation)
- **Provide clear feedback** (progress updates, session summaries)
- **Exit gracefully** (present options when stopping)
