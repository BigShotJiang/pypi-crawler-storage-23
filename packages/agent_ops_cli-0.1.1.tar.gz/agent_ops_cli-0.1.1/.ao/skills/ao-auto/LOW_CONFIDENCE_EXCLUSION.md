# AO Auto — LOW Confidence Exclusion Summary

## Overview

Updated ao-auto skill to **EXCLUDE all LOW confidence issues** from autonomous processing. LOW confidence issues require explicit human oversight per AO safety protocols and are now skipped and reported but not worked on by ao-auto.

## Changes Made

### 1. Updated `.ao/skills/ao-auto/SKILL.md`

**Purpose Section (lines 15-22):**
- Added explicit statement that LOW confidence issues are EXCLUDED
- Updated core principle to mention NORMAL and HIGH confidence only

**Core Principle:**
```markdown
# BEFORE
IF actionable issues exist in priority files:
    → Work on them autonomously (no prompts)

# AFTER
IF actionable issues exist in priority files (excluding LOW confidence):
    → Work on them autonomously (no prompts)

IMPORTANT: ao-auto does NOT work on LOW confidence issues.
```

**Step 1: Check Priority Files (lines 38-56):**
- Added confidence filtering criteria to scan
- Updated to scan for NORMAL or HIGH confidence only
- Added note: "LOW confidence issues are EXCLUDED from ao-auto autonomous processing."

**Actionable Issue Criteria (lines 218-228):**
- Added confidence criterion to table
- Explicitly states confidence must be `normal` or `high`, NOT `low`
- Added note: "LOW confidence issues are NOT actionable for ao-auto. They require explicit human oversight."

**Main Loop Algorithm (lines 174-216):**
- Added Step 1.5 to scan for LOW confidence issues
- Added logging of skipped LOW confidence issues
- Updated comments to reflect NORMAL/HIGH confidence focus
- Added note: "LOW confidence issues are detected and reported but NOT worked on."

**Confidence Handling Section (lines 304-342):**
- Complete rewrite of autonomy rules table
- Changed LOW from "Work on single issue" to "NOT worked on by ao-auto - skipped and reported"
- Added LOW Confidence Issue Handling subsection
- Updated conflict detection to handle only LOW confidence remaining case
- Updated batch validation to exclude LOW confidence

**CLI Integration (lines 344-357):**
- Updated CLI commands to filter for NORMAL/HIGH confidence only
- Added command to find LOW confidence issues for awareness

**Example Sessions (lines 359-403):**
- Updated Example 1 to show LOW confidence issues being skipped
- Added logging of skipped LOW confidence issues
- Updated session summary to include skipped LOW confidence issues

**New Helper Function (lines 248-268):**
- Added `scan_for_low_confidence_issues()` helper
- Detects and reports LOW confidence issues
- Includes documentation that they are not worked on

### 2. Updated `.ao/opencode/commands/ao-auto.md`

**Frontmatter (lines 1-3):**
- Updated description to include LOW confidence exclusion

**Main Content (lines 6-43):**
- Updated step 1 to mention NORMAL/HIGH confidence only
- Added step 3 for skipping LOW confidence issues
- Updated "Only ask when" to include "Only LOW confidence issues remain"
- Updated Actionable issue criteria table to include confidence row
- Rewrote Confidence limits section to exclude LOW
- Added IMPORTANT note about LOW confidence exclusion

**Key Changes:**
```
# BEFORE
**Confidence limits:**
- LOW: 1 issue per batch, mandatory human review
- NORMAL: Up to 3 issues per batch
- HIGH: Up to 5 issues per batch

# AFTER
**Confidence limits:**
- **LOW:** NOT processed - skipped and reported (requires human oversight)
- **NORMAL:** Up to 3 issues per batch
- **HIGH:** Up to 5 issues per batch
```

### 3. Updated `.ao/agents/ao-worker.agent.md`

**Option Details Table (line 248):**
- Updated Auto description to mention NORMAL/HIGH confidence and LOW exclusion

**Auto Option Behavior Section (lines 253-285):**
- Updated step 1 to mention NORMAL/HIGH confidence
- Added step 3 for skipping LOW confidence issues
- Updated "Only ask when" to include "Only LOW confidence issues remain"
- Updated summary to mention skipped LOW confidence issues

### 4. Updated `.ao/claude/agents/ao-worker.md`

**Handoff Options (lines 246-247):**
```json
// BEFORE
{
  "label": "Auto",
  "description": "Autonomous work on issues without asking"
}

// AFTER
{
  "label": "Auto",
  "description": "Autonomous work on NORMAL/HIGH confidence issues (LOW confidence issues are skipped)"
}
```

### 5. Updated `.ao/skills/ao-auto/IMPLEMENTATION.md`

**Core Behavior (lines 25-30):**
- Added note about LOW confidence filtering
- Updated Actionable Issue Criteria to include confidence: normal or high
- Updated Confidence Handling to exclude LOW

**Key Features (lines 26-31):**
- Added "LOW Confidence Exclusion" feature
- Updated criteria to include confidence of normal or high
- Updated confidence handling to work only on NORMAL and HIGH

**Testing Section (lines 201-210):**
- Updated verification steps to include LOW confidence skipping
- Added test for LOW confidence exclusion behavior

## Behavior Changes

### Before
```
User: Auto

🔄 AUTONOMOUS MODE — Scanning for issues...

Found 3 actionable issues:
- CRIT-0023 — Fix authentication bug (confidence: low)
- HIGH-0018 — Add user profile API (confidence: normal)
- MED-0045 — Update email templates (confidence: high)

Working on CRIT-0023...
```

### After
```
User: Auto

🔄 AUTONOMOUS MODE — Scanning for issues...

⚠️ Skipped 1 LOW confidence issue(s) - require human oversight
   - CRIT-0023 — Fix authentication bug (confidence: low)

🔄 Continuing scan for NORMAL/HIGH confidence issues...

Found 2 actionable issues:
- HIGH-0018 — Add user profile API (confidence: normal)
- MED-0045 — Update email templates (confidence: high)

Working on HIGH-0018...
```

## Key Principles

1. **LOW Confidence Issues Are EXCLUDED:**
   - Detected during scanning
   - Logged for awareness
   - Reported to user
   - NOT processed by autonomous loop
   - Require manual selection with explicit human oversight

2. **NORMAL and HIGH Confidence Issues:**
   - Processed autonomously
   - Respect batch limits (3 for NORMAL, 5 for HIGH)
   - No user confirmation needed between issues

3. **Safety Protocols:**
   - LOW confidence requires human oversight per AO safety rules
   - ao-auto enforces this by excluding LOW confidence issues
   - Prevents autonomous work on uncertain or risky changes

## Files Modified

1. `.ao/skills/ao-auto/SKILL.md` — Major updates for LOW confidence exclusion
2. `.ao/opencode/commands/ao-auto.md` — Updated to reflect LOW confidence exclusion
3. `.ao/agents/ao-worker.agent.md` — Updated handoff descriptions and behavior
4. `.ao/claude/agents/ao-worker.md` — Updated handoff description

## Verification

Run these commands to verify LOW confidence exclusion:

```bash
# Verify SKILL.md mentions LOW confidence exclusion
grep -i "LOW confidence" .ao/skills/ao-auto/SKILL.md

# Verify command file excludes LOW confidence
grep -i "NOT processed" .opencode/commands/ao-auto.md

# Verify ao-worker.agent.md reflects exclusion
grep -i "LOW confidence" .ao/agents/ao-worker.agent.md

# Verify .claude ao-worker reflects exclusion
grep -i "skipped" .claude/agents/ao-worker.md
```

## Summary

- ✅ ao-auto skill updated to EXCLUDE all LOW confidence issues
- ✅ LOW confidence issues are detected, reported, but NOT worked on
- ✅ Only NORMAL and HIGH confidence issues are processed autonomously
- ✅ All documentation updated to reflect LOW confidence exclusion
- ✅ Handoff descriptions updated to mention LOW confidence handling
- ✅ Example sessions updated to show LOW confidence skipping
- ✅ Safety protocols maintained - LOW confidence requires human oversight

## Testing

To test LOW confidence exclusion:

1. Create test issues with different confidence levels:
   - Create a CRITICAL issue with `confidence: low`
   - Create a HIGH issue with `confidence: normal`
   - Create a MEDIUM issue with `confidence: high`

2. Run `/ao-auto`

3. Verify behavior:
   - ✅ LOW confidence issue is skipped and reported
   - ✅ NORMAL confidence issue is worked on
   - ✅ HIGH confidence issue is worked on
   - ✅ Session summary includes skipped LOW confidence issues

4. Check focus.json for proper logging

## Impact

**Users should expect:**
- LOW confidence issues will NOT be automatically processed
- They will be clearly reported as skipped
- Manual intervention required to work on LOW confidence issues
- Use `/ao-implement` with explicit selection for LOW confidence issues
- Or use `/ao-task` to review and potentially re-evaluate confidence level
