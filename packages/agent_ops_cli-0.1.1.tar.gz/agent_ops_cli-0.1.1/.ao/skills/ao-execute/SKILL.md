---
name: ao-execute
description: "Execute implementation plans in batches with human checkpoints. Use for implementing approved plans with review between batches."
category: core
invokes: [ao-state, ao-implementation, ao-complete]
invoked_by: [ao-plan, ao-task]
state_files:
  read: [focus.json, issues/*.md]
  write: [focus.json, issues/*.md]
references: [.ao/reference/confidence.md]
---

# Batch Execution Workflow

## Purpose

Execute implementation plans in batches with human review checkpoints between each batch. This provides:
- Human oversight at regular intervals
- Course correction before issues compound
- Graceful handling of interruptions
- Progress tracking for long-running work

## When to Use

- After `/ao-plan` has created an implementation plan
- Issue has status `todo` with implementation plan
- User wants structured execution with checkpoints
- Plans with 6+ tasks (benefit most from batching)

## Preconditions

- Implementation plan exists in `.agent/ops/issues/references/{ISSUE-ID}-impl-plan.md`
- Issue status is `todo`
- All dependencies are resolved
- User approves batch execution approach

## Batch Configuration

Default configuration (in plan frontmatter or user-provided):

```yaml
execution:
  batch_size: 3          # Tasks per batch
  auto_continue: false   # Require human approval
  stop_on_failure: true  # Stop if task fails
  require_verification: true  # Verify after each task
```

## Procedure

### 1) Load Implementation Plan

```
Read: .agent/ops/issues/references/{ISSUE-ID}-impl-plan.md

Extract:
  - Issue ID and title
  - Implementation steps (numbered list)
  - Files to modify
  - Test strategy
  - Batch configuration (or use defaults)
```

### 2) Initialize Execution

```
Update issue status: todo → in_progress
Record start_time in focus.json
Create batch tracker in focus.json

Format:
  ## Batch Execution: {ISSUE-ID}
  - Started: {timestamp}
  - Total tasks: {N}
  - Batch size: {N}
  - Current batch: 0/{total_batches}
```

### 3) Execute Batch Loop

For each batch:
  a) Determine tasks for this batch
  b) Execute tasks sequentially
  c) Track completion status
  d) Run verification (if required)
  e) Checkpoint review with user
  f) Wait for approval to continue
  g) Resume or abort based on user input

### 4) Task Execution within Batch

For each task in batch:
  a) Mark task as in_progress
  b) Execute the task (invoke ao-implementation logic)
  c) Run tests/verification
  d) Mark task as completed or failed
  e) If failed and stop_on_failure=true → pause

### 5) Checkpoint Review (After Each Batch)

```
Report format:

## Batch {N}/{M} Complete

Tasks completed in this batch:
- [x] Task 1: {description}
- [x] Task 2: {description}
- [x] Task 3: {description}

Verification results:
- Tests: {X}/{Y} passing
- Linting: {status}
- Build: {status}

Next batch preview:
- Task 4: {description}
- Task 5: {description}
- Task 6: {description}

Options:
1. Continue to next batch
2. Review changes in detail
3. Modify approach before continuing
4. Stop here (can resume later)

Your choice (1/2/3/4):
```

### 6) Resume Capability

If execution is interrupted (user stops, error, etc.):

```
Check focus.json for batch tracker

If found:
  - Report current batch and progress
  - Ask: "Resume execution from batch {N}?"
  - If yes → continue from current batch
  - If no → start fresh or abort
```

### 7) Completion

When all batches complete:

```
Update issue status: in_progress → done
Record completion_time in focus.json
Calculate total duration
Move issue to done in ao (per ao-task completion procedure)

Final summary:
## Execution Complete: {ISSUE-ID}
- Total tasks: {N}
- Completed: {N}
- Duration: {time}
- Verification: all tests passing
```

## Batch Configuration Options

### batch_size: 3 (default)

Number of tasks per batch.
- Smaller (1-2): More frequent checkpoints, slower execution
- Larger (5-10): Fewer checkpoints, faster execution
- Recommended: 3 for balance

### auto_continue: false (default)

If true, skip checkpoint approval and continue automatically.
- false: Wait for user approval after each batch
- true: Run autonomously until completion or failure
- Recommended: false for human oversight

### stop_on_failure: true (default)

If true, stop batch execution when any task fails.
- true: Pause on first failure for review
- false: Continue executing batch despite failures
- Recommended: true for safety

### require_verification: true (default)

If true, run verification after each task completes.
- true: Run tests, lint, build after each task
- false: Verify only at batch checkpoints
- Recommended: true for immediate feedback

## UI/UX Examples

### Starting Batch Execution

```
User: /ao-execute FEAT-0012

AO: Loading implementation plan for FEAT-0012...

Plan loaded: Add user authentication
- Total tasks: 9
- Batch size: 3
- Batches: 3

Configuration:
- Batch size: 3 tasks
- Checkpoints: After each batch
- Stop on failure: Yes
- Verification: After each task

Ready to start batch execution?
[Y]es, start / [C]onfigure / [A]bort

User: Y

AO: Starting batch execution for FEAT-0012...
Issue status updated: todo → in_progress
```

### During Batch Execution

```
AO: [Starting Batch 1/3: Tasks 1-3]

Task 1: Create User model ✓
  - Created src/models/user.py
  - Tests passing: 5/5

Task 2: Add validation ✓
  - Updated src/models/user.py
  - Tests passing: 8/8

Task 3: Write tests ✓
  - Created tests/test_user.py
  - Tests passing: 12/12

[Batch 1 Complete]

Verification:
- Tests: 12/12 passing ✓
- Linting: Clean ✓
- Build: Success ✓

Next batch (Tasks 4-6):
- Task 4: Create password hashing
- Task 5: Add user repository
- Task 6: Implement registration endpoint

Options:
1. Continue to batch 2
2. Review changes first
3. Modify approach
4. Stop here (resume later)

Your choice (1/2/3/4):
```

### Resume After Interruption

```
User: /ao-execute FEAT-0012

AO: Checking for existing execution...

Found in-progress execution:
- Issue: FEAT-0012
- Current batch: 2/3
- Completed: 6/9 tasks
- Last checkpoint: 2 hours ago

Resume from batch 2?
[Y]es, resume / [N]o, start fresh

User: Y

AO: Resuming from Batch 2...
[Continuing execution...]
```

## Error Handling

### Task Failure

```
Task 4: Create password hashing ✗

Error: ImportError: No module named 'bcrypt'

[Execution Paused]

Task failed in batch 2.
Options:
1. Retry task 4
2. Skip task 4 and continue
3. Stop execution for manual fix
4. Abort entire execution

Your choice (1/2/3/4):
```

### Verification Failure

```
[Batch 2 Complete]

Verification:
- Tests: 15/20 passing ✗
  Failing tests:
    - test_password_validation
    - test_hash_uniqueness

[Execution Paused]

Verification failed. Review recommended.
Options:
1. Review failing tests
2. Continue anyway (not recommended)
3. Stop for manual fix

Your choice (1/2/3):
```

## Integration with Existing AO

- Works with `/ao-plan` created plans
- Updates issue status through ao-state
- Uses ao-implementation logic for task execution
- Invokes ao-complete for final verification
- Links to worktrees (optional, for isolated execution)

## Files Modified During Execution

- `.agent/ops/issues/{priority}.md` - Update issue status
- `.agent/ops/focus.json` - Track batch progress
- Implementation files - Modified by tasks
- `.agent/ops/issues/events.jsonl` - Updated via ao on issue completion
