# Agent Memory (durable)

## Workflow invariants
- Never assume or guess; ask clarifying questions.
- Constitution is mandatory before baseline and code changes.
- Baseline is mandatory before any code change.
- Minimal change only; no refactor without explicit permission.
- Validate with unit tests; compare final state vs baseline.

## Confirmed conventions
- TODO

## Retrospective learnings (append-only)
<!-- Append new retrospective sections below this line -->
