# Focus (session-resume context)

## Session info
- last_updated: YYYY-MM-DD HH:MM
- branch: TODO
- last_commit: TODO (short hash)

## Iteration tracking
- current_iteration: TODO (number, starting at 1)
- issues_in_iteration: TODO (list of issue IDs worked on this iteration)
- confidence_mix: TODO (e.g., "1 low, 2 normal" — summary of confidence levels in current batch)
- iteration_started: TODO (YYYY-MM-DD HH:MM)

## Just did
- TODO

## Doing now
- Issue: TODO (issue ID or "none")
- Confidence: TODO (low | normal | high | N/A if no active issue)
- Task: TODO

## Next
- TODO
