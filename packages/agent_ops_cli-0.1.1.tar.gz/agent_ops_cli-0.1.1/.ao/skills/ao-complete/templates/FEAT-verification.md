# FEAT Verification Template

Use this template to verify FEAT implementation before marking complete.

## Issue Details

**Issue ID**: {ISSUE-ID}
**Title**: {Feature Title}
**Status**: in_progress → done

## Acceptance Criteria

From issue description:
1. [ ] {Criteria 1}
2. [ ] {Criteria 2}
3. [ ] {Criteria 3}
4. [ ] {Criteria 4}

## Verification Gate Function

### 1. IDENTIFY

**Claim**: Feature implementation is complete and working

**Verification Commands**:
```bash
# Test verification
{test_command}

# Lint verification
{lint_command}

# Build verification (if applicable)
{build_command}
```

**What these prove**:
- All tests pass
- Code quality standards met
- Build succeeds
- All acceptance criteria met

### 2. RUN

**Execute verification commands:**

```bash
# Run tests
{test_command}

# Run linter
{lint_command}

# Run build (if applicable)
{build_command}
```

### 3. READ

**Test Output**:
```
[Paste full test output]
```
- Exit code: {0}
- Tests run: {count}
- Tests passed: {count}
- Tests failed: {count}
- Coverage: {percentage}%
- Status: ✅ ALL PASS / ❌ SOME FAIL

**Lint Output**:
```
[Paste full lint output]
```
- Exit code: {0}
- Lint errors: {count}
- Lint warnings: {count}
- Files checked: {count}
- Status: ✅ PASS / ❌ FAIL

**Build Output**:
```
[Paste full build output]
```
- Exit code: {0}
- Build status: ✅ SUCCESS / ❌ FAILED
- Artifacts: {what was built}
- Status: ✅ PASS / ❌ FAIL / N/A

### 4. VERIFY

**Does output confirm the claim?**

| Verification | Command | Exit Code | Result |
|-------------|----------|-----------|--------|
| Tests | {test_command} | {0} | ✅ PASS / ❌ FAIL |
| Lint | {lint_command} | {0} | ✅ PASS / ❌ FAIL |
| Build | {build_command} | {0} | ✅ PASS / ❌ FAIL / N/A |

**Acceptance Criteria Verification**:
- [x] Criteria 1: {verified how}
- [x] Criteria 2: {verified how}
- [x] Criteria 3: {verified how}
- [x] Criteria 4: {verified how}

**Overall Verification Result**: ✅ VERIFIED / ❌ FAILED

### 5. ONLY THEN

**If verification PASSED:**
- Update issue: `status: done`, `completed_at: {timestamp}`, `duration_minutes: {minutes}`
- Move to `history.md`
- Update `focus.json`

**If verification FAILED:**
- Update issue: `status: blocked`
- Add note: "Verification failed: {reason}"
- Do NOT move to `history.md`

## Verification Evidence

### Test Verification
- Date: {timestamp}
- Command: ` {test_command}`
- Exit code: {0}
- Tests: {total}, Passed: {passed}, Failed: {failed}
- Coverage: {percentage}%
- Status: ✅ PASS / ❌ FAIL

### Lint Verification
- Date: {timestamp}
- Command: ` {lint_command}`
- Exit code: {0}
- Errors: {count}, Warnings: {count}
- Status: ✅ PASS / ❌ FAIL

### Build Verification
- Date: {timestamp}
- Command: ` {build_command}`
- Exit code: {0}
- Status: ✅ SUCCESS / ❌ FAILED / N/A

### Acceptance Criteria Check
- Criteria 1: {criteria} → ✅ MET / ❌ NOT MET ({details})
- Criteria 2: {criteria} → ✅ MET / ❌ NOT MET ({details})
- Criteria 3: {criteria} → ✅ MET / ❌ NOT MET ({details})
- Criteria 4: {criteria} → ✅ MET / ❌ NOT MET ({details})

## Completion Checklist

- [ ] All acceptance criteria verified
- [ ] Tests pass (verified with exit code 0)
- [ ] Linting passes (verified with exit code 0)
- [ ] Build succeeds (if applicable, verified with exit code 0)
- [ ] All verifications run fresh (not cached)
- [ ] Full output read and documented
- [ ] Verification documented in issue notes
- [ ] Issue moved to history.md (if all passed)

## Anti-Pattern Check

❌ **Wrong**: "Tests should pass"
✅ **Right**: Ran `pytest`, exit code 0, all tests PASS

❌ **Wrong**: "Linting probably fine"
✅ **Right**: Ran `ruff check`, exit code 0, no errors

❌ **Wrong**: "Build succeeded"
✅ **Right**: Ran `npm run build`, exit code 0, artifacts created

❌ **Wrong**: "Acceptance criteria met"
✅ **Right**: Tested each criterion, verified with evidence

❌ **Wrong**: "Feature implemented correctly"
✅ **Right**: Tests PASS, lint PASS, build PASS, all criteria VERIFIED

## Notes

**Completed on**: {Date}
**Duration**: {minutes} minutes
**Verification method**: Automated test + lint + build verification

## Follow-up Issues

- [ ] Related: {ISSUE-ID} - {description}
