# BUG Verification Template

Use this template to verify BUG fixes before marking complete.

## Issue Details

**Issue ID**: {ISSUE-ID}
**Title**: {Bug Title}
**Status**: in_progress → done

## Verification Gate Function

### 1. IDENTIFY

**Claim**: Bug fix is complete and working

**Verification Command**:
```bash
{test_command_from_constitution}
```

**What this proves**:
- Failing test now passes
- No regressions introduced

### 2. RUN

**Execute verification command:**

```bash
# Before fix - confirm test fails
{test_command}

# After fix - confirm test passes
{test_command}

# Full suite - confirm no regressions
{full_test_command}
```

### 3. READ

**Before Fix Output**:
```
[Paste full test output showing failure]
```
- Exit code: {non-zero}
- Test status: ❌ FAILED
- Failure reason: {bug symptom}

**After Fix Output**:
```
[Paste full test output showing pass]
```
- Exit code: {0}
- Test status: ✅ PASSED

**Full Suite Output**:
```
[Paste full test suite output]
```
- Total tests: {count}
- Passed: {count}
- Failed: {count}
- Exit code: {0 if all pass}
- Status: ✅ NO REGRESSIONS

### 4. VERIFY

**Does output confirm the claim?**

| Check | Result |
|-------|--------|
| Failing test now passes | ✅ / ❌ |
| No regressions in full suite | ✅ / ❌ |
| Exit code is 0 | ✅ / ❌ |
| All checks pass | ✅ / ❌ |

**Verification Result**: ✅ VERIFIED / ❌ FAILED

### 5. ONLY THEN

**If verification PASSED:**
- Update issue: `status: done`, `completed_at: {timestamp}`, `duration_minutes: {minutes}`
- Move to `history.md`
- Update `focus.json`

**If verification FAILED:**
- Update issue: `status: blocked`
- Add note: "Verification failed: {reason}"
- Do NOT move to `history.md`

## Verification Evidence

### Before Fix
- Date: {timestamp}
- Test run: ` {test_command}`
- Result: ❌ FAILED
- Bug symptom: {what was broken}

### After Fix
- Date: {timestamp}
- Test run: ` {test_command}`
- Result: ✅ PASSED
- Fix applied: {what was changed}

### Regression Check
- Date: {timestamp}
- Full suite run: ` {full_test_command}`
- Total tests: {count}
- Passed: {count}
- Failed: {count}
- Exit code: {0}
- Result: ✅ NO REGRESSIONS

## Completion Checklist

- [ ] Failing test created and confirmed to fail
- [ ] Fix implemented
- [ ] Failing test now passes
- [ ] No regressions (full suite passes)
- [ ] Exit code is 0
- [ ] Verification documented in issue notes
- [ ] Issue moved to history.md (if verification passed)

## Anti-Pattern Check

❌ **Wrong**: "Tests should pass now"
✅ **Right**: Ran `pytest`, exit code 0, all tests PASS

❌ **Wrong**: "No regressions detected"
✅ **Right**: Ran full test suite, 0 failures, exit code 0

❌ **Wrong**: "Fix looks correct"
✅ **Right**: Ran test, output shows PASS, exit code 0

## Notes

**Fixed on**: {Date}
**Duration**: {minutes} minutes
**Verification method**: Automated test execution
