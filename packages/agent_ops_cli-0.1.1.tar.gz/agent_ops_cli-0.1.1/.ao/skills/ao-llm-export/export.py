#!/usr/bin/env python3
"""AgentOps Capabilities Export - Full Content Mode

This script is colocated with the ao-ops-llm-export skill.
Usage: python export.py <base_path> <output_path> <format> <include> <content_mode>

Arguments:
  base_path     - Root of the AgentOps repository
  output_path   - Where to write the export file
  format        - 'markdown' or 'json'
  include       - Comma-separated: 'skills,agents,prompts' or 'all'
  content_mode  - 'full', 'summary', or 'metadata'
"""
import os
import re
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

def parse_frontmatter(content: str) -> tuple[dict[str, Any], str]:
    """Extract YAML frontmatter and remaining content."""
    if not content.startswith('---'):
        return {}, content
    parts = content.split('---', 2)
    if len(parts) < 3:
        return {}, content
    frontmatter_text = parts[1].strip()
    body = parts[2].strip() if len(parts) > 2 else ''
    # Simple YAML parsing (no external deps)
    meta = {}
    for line in frontmatter_text.split('\n'):
        if ':' in line:
            key, val = line.split(':', 1)
            key = key.strip()
            val = val.strip().strip('"').strip("'")
            if val.startswith('[') and val.endswith(']'):
                val = [v.strip().strip('"').strip("'") for v in val[1:-1].split(',') if v.strip()]
            meta[key] = val
    return meta, body

def scan_files(pattern: str, base_path: Path) -> list[Path]:
    """Find files matching glob pattern."""
    return sorted(base_path.glob(pattern))

def generate_export(base_path: Path, output_path: Path, format: str, include: list[str], content_mode: str):
    """Generate the capabilities export."""
    scan_skills = 'skills' in include or 'all' in include
    scan_agents = 'agents' in include or 'all' in include
    scan_prompts = 'prompts' in include or 'all' in include
    
    skills, agents, prompts = [], [], []
    
    # Scan skills
    if scan_skills:
        for f in scan_files('.ao/skills/*/SKILL.md', base_path):
            try:
                content = f.read_text(encoding='utf-8')
                meta, body = parse_frontmatter(content)
                skills.append({
                    'name': meta.get('name', f.parent.name),
                    'description': meta.get('description', ''),
                    'category': meta.get('category', ''),
                    'file': str(f.relative_to(base_path)).replace('\\', '/'),
                    'invokes': meta.get('invokes', []) or [],
                    'invoked_by': meta.get('invoked_by', []) or [],
                    'full_content': content if content_mode == 'full' else (body[:2000] if content_mode == 'summary' else '')
                })
            except Exception as e:
                print(f'Warning: Could not parse {f}: {e}')
    
    # Scan agents
    if scan_agents:
        seen = {}
        for pattern in ['.github/agents/*.agent.md', 'tools/*/agents/*.agent.md']:
            for f in scan_files(pattern, base_path):
                if '.venv' in str(f) or '_bundle' in str(f):
                    continue
                try:
                    content = f.read_text(encoding='utf-8')
                    meta, body = parse_frontmatter(content)
                    name = meta.get('name', f.stem.replace('.agent', ''))
                    if name not in seen or '.github/agents' in str(f):
                        seen[name] = {
                            'name': name,
                            'description': meta.get('description', ''),
                            'file': str(f.relative_to(base_path)).replace('\\', '/'),
                            'argumentHint': meta.get('argumentHint', ''),
                            'full_content': content if content_mode == 'full' else (body[:2000] if content_mode == 'summary' else '')
                        }
                except Exception as e:
                    print(f'Warning: Could not parse {f}: {e}')
        agents = list(seen.values())
    
    # Scan prompts
    if scan_prompts:
        for f in scan_files('.github/prompts/*.prompt.md', base_path):
            try:
                content = f.read_text(encoding='utf-8')
                meta, body = parse_frontmatter(content)
                prompts.append({
                    'name': meta.get('name', f.stem.replace('.prompt', '')),
                    'description': meta.get('description', ''),
                    'agent': meta.get('agent', ''),
                    'file': str(f.relative_to(base_path)).replace('\\', '/'),
                    'full_content': content if content_mode == 'full' else (body[:2000] if content_mode == 'summary' else '')
                })
            except Exception as e:
                print(f'Warning: Could not parse {f}: {e}')
    
    # Sort all alphabetically
    skills.sort(key=lambda x: x['name'].lower())
    agents.sort(key=lambda x: x['name'].lower())
    prompts.sort(key=lambda x: x['name'].lower())
    
    # Generate output
    timestamp = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
    
    if format == 'json':
        output = {
            'generated': timestamp,
            'content_mode': content_mode,
            'stats': {'skills': len(skills), 'agents': len(agents), 'prompts': len(prompts)}
        }
        if scan_skills: output['skills'] = skills
        if scan_agents: output['agents'] = agents
        if scan_prompts: output['prompts'] = prompts
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(json.dumps(output, indent=2), encoding='utf-8')
    else:
        lines = ['# AgentOps Capabilities Export', '', f'Generated: {timestamp}', f'Content Mode: {content_mode}', '', '---', '']
        
        if scan_skills:
            lines.extend([f'## Skills ({len(skills)} total)', ''])
            for s in skills:
                lines.extend([
                    f"### {s['name']}", '',
                    f"**Description**: {s['description']}",
                    f"**Category**: {s['category']}",
                    f"**File**: {s['file']}",
                    f"**Invokes**: {', '.join(s['invokes']) if s['invokes'] else 'none'}",
                    f"**Invoked By**: {', '.join(s['invoked_by']) if s['invoked_by'] else 'none'}", ''
                ])
                if s['full_content']:
                    lines.extend([
                        '<details>',
                        '<summary>Full Content (click to expand)</summary>', '',
                        '```markdown',
                        s['full_content'],
                        '```', '',
                        '</details>', ''
                    ])
                lines.extend(['---', ''])
        
        if scan_agents:
            lines.extend(['', f'## Agents ({len(agents)} total)', ''])
            for a in agents:
                lines.extend([
                    f"### {a['name']}", '',
                    f"**Description**: {a['description']}",
                    f"**File**: {a['file']}",
                    f"**Argument Hint**: {a['argumentHint'] or 'N/A'}", ''
                ])
                if a['full_content']:
                    lines.extend([
                        '<details>',
                        '<summary>Full Content (click to expand)</summary>', '',
                        '```markdown',
                        a['full_content'],
                        '```', '',
                        '</details>', ''
                    ])
                lines.extend(['---', ''])
        
        if scan_prompts:
            lines.extend(['', f'## Prompts ({len(prompts)} total)', ''])
            for p in prompts:
                lines.extend([
                    f"### {p['name']}", '',
                    f"**Description**: {p['description']}",
                    f"**Target Agent**: {p['agent'] or 'N/A'}",
                    f"**File**: {p['file']}", ''
                ])
                if p['full_content']:
                    lines.extend([
                        '<details>',
                        '<summary>Full Content (click to expand)</summary>', '',
                        '```markdown',
                        p['full_content'],
                        '```', '',
                        '</details>', ''
                    ])
                lines.extend(['---', ''])
        
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text('\n'.join(lines), encoding='utf-8')
    
    print(f'✓ Export complete: {output_path}')
    print(f'  Skills: {len(skills)}, Agents: {len(agents)}, Prompts: {len(prompts)}')
    print(f'  Size: {output_path.stat().st_size / 1024:.1f} KB')

if __name__ == '__main__':
    import sys
    base = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd()
    output = Path(sys.argv[2]) if len(sys.argv) > 2 else base / '.agent' / 'llm.txt'
    fmt = sys.argv[3] if len(sys.argv) > 3 else 'markdown'
    include = sys.argv[4].split(',') if len(sys.argv) > 4 else ['all']
    content = sys.argv[5] if len(sys.argv) > 5 else 'full'
    generate_export(base, output, fmt, include, content)
