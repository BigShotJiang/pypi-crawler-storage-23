# FEAT TDD Checklist

Use this template when implementing FEAT issues with Test-Driven Development.

## Issue Details

**Issue ID**: {ISSUE-ID}
**Title**: {Feature Title}
**Created**: {Date}

## Feature Breakdown

Break down the feature into testable behaviors:

1. **Behavior 1**: {description}
   - Test name: `test_{clear_name}`
   - Expected: {what should happen}

2. **Behavior 2**: {description}
   - Test name: `test_{clear_name}`
   - Expected: {what should happen}

3. **Behavior 3**: {description}
   - Test name: `test_{clear_name}`
   - Expected: {what should happen}

## TDD Cycle: Behavior 1

### RED - Write Failing Test

**Test Name**: `test_{clear_name}`

```python/any
[Write test code here - ONE behavior only]
```

- Test created: [Date/Time]
- Test run result: ❌ FAIL
- Expected failure: {why it should fail}
- ✅ This proves we're testing the right thing

### Verify RED (MANDATORY)

```bash
[Test command output]
```

- Exit code: {non-zero expected}
- Failure message: {matches expected behavior}
- Test is NOT passing immediately
- ✅ RED phase complete

### GREEN - Write Minimal Code

```python/any
[Write minimal code to make test pass]
```

- Code added: {file/functions}
- Lines changed: {count}
- Simplicity check: {only what's needed for this test}

### Verify GREEN (MANDATORY)

```bash
[Test command output]
```

- Exit code: {0 expected}
- Test result: ✅ PASS
- Only failing test now passes
- ✅ GREEN phase complete

### REFACTOR (if needed)

```python/any
[Clean up code while keeping tests green]
```

- Refactored: {what was improved}
- Tests after refactor: ✅ ALL PASS
- No behavior changes
- ✅ REFACTOR phase complete

---

## TDD Cycle: Behavior 2

### RED - Write Failing Test

**Test Name**: `test_{clear_name}`

```python/any
[Write test code here - ONE behavior only]
```

- Test created: [Date/Time]
- Test run result: ❌ FAIL
- Expected failure: {why it should fail}
- ✅ This proves we're testing the right thing

### Verify RED (MANDATORY)

```bash
[Test command output]
```

- Exit code: {non-zero expected}
- Failure message: {matches expected behavior}
- Test is NOT passing immediately
- ✅ RED phase complete

### GREEN - Write Minimal Code

```python/any
[Write minimal code to make test pass]
```

- Code added: {file/functions}
- Lines changed: {count}
- Simplicity check: {only what's needed for this test}

### Verify GREEN (MANDATORY)

```bash
[Test command output]
```

- Exit code: {0 expected}
- Test result: ✅ PASS
- Only failing test now passes
- ✅ GREEN phase complete

### REFACTOR (if needed)

```python/any
[Clean up code while keeping tests green]
```

- Refactored: {what was improved}
- Tests after refactor: ✅ ALL PASS
- No behavior changes
- ✅ REFACTOR phase complete

---

## Implementation Summary

**Total behaviors implemented**: {N}
**Total tests written**: {N}
**Total test failures observed**: {N}
**Total test fixes**: {N}

## Anti-Pattern Check

Before completing, verify NO anti-patterns used:

- [ ] No code written before tests (test-first respected)
- [ ] No "reference code" kept during implementation
- [ ] No tests that passed immediately on first run
- [ ] No vague test names (test1, works, etc.)

## Commit History

### Test Commit(s)

1. `test: add test for {behavior}` - [Commit hash]
2. `test: add test for {behavior}` - [Commit hash]

### Implementation Commit(s)

1. `feat: implement {feature}` - [Commit hash]
2. `refactor: clean up {component}` - [Commit hash] (if applicable)

## Completion Checklist

- [ ] All behaviors tested with RED-GREEN-REFACTOR
- [ ] All tests verified FAIL before implementation
- [ ] All tests verified PASS after implementation
- [ ] Tests committed separately with "test:" prefix
- [ ] No regressions introduced
- [ ] Code is minimal and focused
- [ ] Documentation updated if needed
