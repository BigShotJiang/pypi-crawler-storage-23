---
name: ao-skill-fatigue
description: "Detect overuse or misuse of skills indicating workflow smells. If the agent keeps reaching for the same tool, something upstream is broken."
category: analysis
invokes: [ao-state]
invoked_by: [ao-housekeeping, ao-retrospective]
state_files:
  read: [memory.md]
  write: [memory.md]
---

# ao-skill-fatigue

Detect overuse or misuse of skills indicating workflow smells. If the agent keeps reaching for the same tool, something upstream is broken.

## Purpose

Patterns like repeated recovery, constant replanning, or excessive reviews indicate systemic issues, not just bad luck. This skill identifies unhealthy usage patterns and suggests corrections.

## Trigger

- Automatically during session (background monitoring)
- On explicit request
- After repeated failures
- During retrospective

## Fatigue Patterns

| Pattern | Symptom | Likely Cause | Severity |
|---------|---------|--------------|----------|
| **Recovery Loop** | `ao-recovery` 3+ times | Fundamental misunderstanding | High |
| **Plan Flip-Flop** | `ao-planning` repeated on same issue | Unclear requirements | High |
| **Review Anxiety** | `ao-critical-review` every step | Low confidence, lack of trust | Medium |
| **Test Churn** | `ao-testing` repeated runs | Flaky tests, bad tests | Medium |
| **Housekeeping Obsession** | `ao-housekeeping` every action | Procrastination, anxiety | Low |

## Interventions

| Pattern | Suggested Action |
|---------|-----------------|
| Recovery Loop | Stop, replan from basics |
| Plan Flip-Flop | Interview for clarity |
| Review Anxiety | Increase confidence or simplify |
| Test Churn | Fix test infrastructure |
| Housekeeping Obsession | Focus on real work |

## Related Skills

- `ao-retrospective` — analyzes patterns
- `ao-housekeeping` — includes fatigue check
- `ao-calibrator` — challenges confidence levels
