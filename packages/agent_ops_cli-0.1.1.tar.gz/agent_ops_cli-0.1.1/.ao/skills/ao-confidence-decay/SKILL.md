---
name: ao-confidence-decay
description: "Automatically decay confidence on stale issues or long-lived branches. Old certainty is usually false certainty."
category: analysis
invokes: [ao-state, ao-task]
invoked_by: [ao-housekeeping, ao-planning]
state_files:
  read: [issues/*.md, memory.md]
  write: [issues/*.md, memory.md]
---

# ao-confidence-decay

Automatically decay confidence on stale issues or long-lived branches. Old certainty is usually false certainty.

## Purpose

Issues planned weeks or months ago carry assumptions that may no longer hold — dependencies updated, requirements evolved, context forgotten. This skill enforces confidence decay to maintain accuracy.

## Trigger

- Daily automatic check (if enabled)
- When work resumes on an issue
- During housekeeping
- On demand

## Decay Schedule

| Time Inactive | HIGH → | NORMAL → | LOW → |
|---------------|--------|----------|-------|
| 14 days | NORMAL | (no change) | (no change) |
| 30 days | LOW | LOW | (no change) |
| 60 days | LOW | LOW | (no change) |

## Branch Age

| Branch Age | Action |
|------------|--------|
| 14 days | Review if still needed |
| 30 days | Stale warning |
| 60 days | Consider deletion |

## Related Skills

- `ao-housekeeping` — checks stale issues
- `ao-planning` — reassesses old plans
- `ao-retrospective` — reviews outdated assumptions
