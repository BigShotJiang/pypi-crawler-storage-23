# Parallel Agent Dispatch Template

Use this template when dispatching parallel agents for independent issues.

## Analysis

**Dispatch Date**: {Date}
**Batch Size**: {N} issues

### Issue Independence Check

| Issue ID | Dependencies | Shared Files | Shared State | Status |
|-----------|------------|-------------|-------------|--------|
| {ISSUE-1} | {list} | {list} | {INDEPENDENT/BLOCKING/CONFLICTING} |
| {ISSUE-2} | {list} | {list} | {INDEPENDENT/BLOCKING/CONFLICTING} |
| {ISSUE-3} | {list} | {list} | {INDEPENDENT/BLOCKING/CONFLICTING} |

**Independent Issues Count**: {count}
**Blocking Issues Count**: {count}
**Conflicting Issues Count**: {count}

**Decision**: {PROCEED / REJECT / SEQUENTIAL}

### Problem Domain Analysis

| Issue ID | Subsystem | Component | Affected Area |
|-----------|----------|------------|----------------|
| {ISSUE-1} | {e.g., API} | {e.g., authentication} | {e.g., api/auth.py} |
| {ISSUE-2} | {e.g., Frontend} | {e.g., UI components} | {e.g., frontend/components/} |
| {ISSUE-3} | {e.g., Database} | {e.g., connections} | {e.g., db/connection.py} |

**Domain Independence**: {YES/NO}

## Agent Dispatch Configuration

### Agent Tasks

**Agent 1**:
- Issue: {ISSUE-1}
- Goal: {Resolve issue}
- Scope: {Specific scope}
- Constraints: {Don't change X, Y, Z}

**Agent 2**:
- Issue: {ISSUE-2}
- Goal: {Resolve issue}
- Scope: {Specific scope}
- Constraints: {Don't change X, Y, Z}

**Agent 3**:
- Issue: {ISSUE-3}
- Goal: {Resolve issue}
- Scope: {Specific scope}
- Constraints: {Don't change X, Y, Z}

### Safety Setup

| Item | Configuration |
|-------|-------------|
| Worktree for each agent | Yes/No |
| Branch naming convention | `agent/{issue-id}-{short-desc}` |
| Base branch | main |
| Protected branches | main, master (never push) |

## Execution Progress

### Progress Tracking

| Agent | Issue | Progress | Status |
|-------|--------|----------|----------|
| Agent 1 | {ISSUE-1} | {█████████░░} | {IN_PROGRESS/DONE/BLOCKED} |
| Agent 2 | {ISSUE-2} | {█████████░░} | {IN_PROGRESS/DONE/BLOCKED} |
| Agent 3 | {ISSUE-3} | {█████████░░} | {IN_PROGRESS/DONE/BLOCKED} |

### Timeline

- {Time}: Agent 1 started
- {Time}: Agent 2 started
- {Time}: Agent 3 started
- {Time}: All agents complete

## Conflict Detection

### File Modification Conflicts

| File | Modified By | Status |
|------|-------------|--------|
| {file} | Agent 1, Agent 2 | ❌ CONFLICT |
| {file} | Agent 3 | ✅ OK |

### State Conflicts

| Shared State | Modified By | Status |
|-------------|-------------|--------|
| {state/file} | Agent 1, Agent 2 | ❌ CONFLICT |
| {state/file} | Agent 3 | ✅ OK |

### Dependency Conflicts

| Issue | Depends On | Modified By | Status |
|-------|-------------|-------------|--------|
| {ISSUE-ID} | {DEPENDENT-ISSUE} | Agent X | ❌ BROKEN |

## Conflict Resolution

**If conflicts detected:**

1. Stop all remaining agents
2. Report conflicts to user:
   ```
   ⚠️ CONFLICT DETECTED

   File Conflicts:
   - {file}: Agent 1 and Agent 2 both modified

   Recommended Actions:
   1. Manual merge of conflicting files
   2. Sequential execution: Agent 1 → Agent 2 → Agent 3
   3. Re-run parallel after conflicts resolved
   ```

3. Wait for user decision

## Results Aggregation

### Agent Results

| Agent | Issue | Status | Files Modified | Commit | Duration |
|-------|--------|--------|----------------|--------|----------|
| Agent 1 | {ISSUE-1} | ✅ DONE | {list} | {hash} | {min} |
| Agent 2 | {ISSUE-2} | ✅ DONE | {list} | {hash} | {min} |
| Agent 3 | {ISSUE-3} | ✅ DONE | {list} | {hash} | {min} |

### Verification

**Full Test Suite**:
```
$ {test_command}
{Output}
```
- Total tests: {count}
- Passed: {count}
- Failed: {count}
- Exit code: {0}
- Status: ✅ NO REGRESSIONS

### Performance Metrics

| Metric | Sequential (Est) | Parallel (Actual) | Time Saved | Efficiency |
|--------|-----------------|-------------------|-----------|------------|
| Total Duration | {X} min | {Y} min | {Z} min | {P}% |

## Completion Summary

**Issues Resolved**: {count}
**Parallel Agents Used**: {count}
**Conflicts**: {count}
**Regressions**: {count}
**Time Saved**: {X} minutes
**Success Rate**: {count/total}%

## Follow-up Issues

- [ ] Related: {ISSUE-ID} - {description}
- [ ] Related: {ISSUE-ID} - {description}
