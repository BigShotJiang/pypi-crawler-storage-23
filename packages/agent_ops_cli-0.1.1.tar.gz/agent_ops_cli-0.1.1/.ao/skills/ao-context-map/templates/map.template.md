# Context Map

## System Overview

[One paragraph summary of the project's purpose, primary technologies, and architecture style]

## Key Components

| Component | Location | Responsibility |
|-----------|----------|----------------|
| | | |

## Architecture Patterns

- **Pattern**: [Description]
- **Data flow**: [Description]
- **State management**: [Description]

## Key Files

| File | Purpose | Notes |
|------|---------|-------|
| | | |

## Entry Points

| Entry Point | Type | Description |
|-------------|------|-------------|
| | | |

## Dependencies (External)

| Dependency | Purpose | Version |
|------------|---------|---------|
| | | |

## Configuration

| Config Source | Purpose |
|---------------|---------|
| | |

## Last Updated

- Date: YYYY-MM-DD
- By: agent | human
- Reason: [Why the map was updated]

```
