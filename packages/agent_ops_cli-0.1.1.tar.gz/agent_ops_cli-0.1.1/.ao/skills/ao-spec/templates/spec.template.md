# Spec: [Title]

## Metadata

- spec_id: SPEC-XXXX
- created: YYYY-MM-DD
- updated: YYYY-MM-DD
- author: user | agent
- status: draft | confirmed | implemented | validated
- linked_tasks: [T-XXXX]

## Overview

Brief description of what this spec covers.

## Requirements

### R1: [Requirement title]

- **Description**: What must be true
- **Priority**: P0 (must) | P1 (should) | P2 (could) | P3 (nice-to-have)
- **Acceptance criteria**:
  - [ ] Criterion 1
  - [ ] Criterion 2

### R2: [Requirement title]

- **Description**: ...
- **Priority**: ...
- **Acceptance criteria**:
  - [ ] ...

## Constraints

- Constraint 1
- Constraint 2

## Out of scope

- Explicitly excluded item 1
- Explicitly excluded item 2

## Traceability matrix

| Requirement | Priority | Implementation | Test(s) | Status |
|-------------|----------|----------------|---------|--------|
| R1 | P0 | file.ts#L10-20 | test_r1 | ❌ |
| R2 | P1 | | | ❌ |

Status: ❌ not started | 🔄 in progress | ✅ complete

## Open questions

- [ ] Question 1
- [ ] Question 2

## Changelog

- YYYY-MM-DD: created
