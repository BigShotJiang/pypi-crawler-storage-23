---
name: ao-existential-review
description: "Challenge every artifact's right to exist. Force explicit justification for files, modules, abstractions, or features."
category: analysis
invokes: [ao-state]
invoked_by: [ao-critical-review, ao-retrospective]
state_files:
  read: [issues/*.md, memory.md]
  write: [issues/*.md, memory.md]
---

# ao-existential-review

Challenge every artifact's right to exist. Force explicit justification for files, modules, abstractions, or features.

## Purpose

Code generation is easy. Code *interrogation* is hard. This skill ensures artifacts earn their existence.

## Trigger

- After implementation completes (optional)
- During critical review (on demand)
- During retrospective (optional)
- Standalone analysis

## Workflow

### Phase 1: Scope Selection

**Determine review scope:**

- Full codebase
- Specific module
- Recent changes
- Single artifact

### Phase 2: Existence Challenge

For each artifact, ask:

1. **What problem does it solve?**
2. **Is this problem still relevant?**
3. **Could this be simpler?**
4. **Could this be deleted?**
5. **What depends on this?**

### Phase 3: Verdict

| Verdict | Meaning | Action |
|---------|---------|--------|
| **ESSENTIAL** | Critical value | Keep |
| **USEFUL** | Has purpose | Keep, document |
| **QUESTIONABLE** | Uncertain value | Review, improve, or delete |
| **REDUNDANT** | Duplicates existing | Delete or merge |
| **DEAD** | No longer relevant | Delete |

## Related Skills

- `ao-cognitive-load` — analyzes complexity value
- `ao-improvement-discovery` — finds unnecessary code
- `ao-critical-review` — includes existence checks
