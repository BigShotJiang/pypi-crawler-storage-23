# Baseline (MANDATORY)

## Baseline metadata
- created_at: TODO (ISO timestamp)
- created_by: AO
- repo_state: TODO (branch/commit if available)

## Confirmed commands (must match .agent/ops/constitution.md)
- build: TODO
- lint: TODO
- tests: TODO

## Build/Lint results
### Command(s)
- TODO

### Summary
- exit_code: TODO
- warnings_count: TODO
- errors_count: TODO

### Findings grouped by file
- TODO

## Unit test results
### Command(s)
- TODO

### Summary
- exit_code: TODO
- passed: TODO
- failed: TODO
- skipped: TODO

### Failure details (verbatim excerpts)
- TODO

## Notes
- Any known pre-existing failures/issues that are accepted as baseline.
