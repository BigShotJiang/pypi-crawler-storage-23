---
name: ao-baseline
description: "Create .agent/ops/baseline.md and later compare against it. Use when capturing baseline build/lint/test results or investigating newly introduced findings."
category: core
invokes: [ao-state, ao-task]
invoked_by: [ao-validation]
state_files:
  read: [constitution.md, focus.json]
  write: [baseline.md, focus.json]
---

# Baseline Workflow

## Low-Confidence Issues: MANDATORY Baseline (HARD RULE)

**For any issue with `confidence: low`, baseline is NON-NEGOTIABLE.**

| Condition | Requirement |
|-----------|-------------|
| `confidence: low` + no baseline | ⛔ MUST capture baseline BEFORE implementation |
| `confidence: low` + stale baseline (>24h) | ⚠️ MUST refresh baseline before implementation |
| `confidence: low` + completion attempt | ⛔ MUST have baseline comparison in validation |

**Enforcement:**
- `ao-implementation` MUST check for baseline existence when confidence is low
- `ao-validation` MUST refuse Tier 1 (quick) validation for low-confidence work
- Completion gate MUST include baseline comparison for low-confidence issues

**This is a HARD rule. Skipping baseline for low-confidence work is forbidden.**

## Preconditions
- `.agent/ops/constitution.md` exists and commands are CONFIRMED.

## CLI Commands

**Works with or without `aoc` CLI installed.** Baseline operations use direct file editing by default.

### Build/Lint/Test Commands

Get commands from `.agent/ops/constitution.md` — these vary by project:

```bash
# Example constitution commands (project-specific)
build: npm run build
lint: npm run lint
test: npm run test
format: npm run format
```

### Issue Discovery After Baseline (File-Based — Default)

When baseline findings need to be tracked as issues:

1. Use `ao --yes issue add "{title}" --type BUG` to create issues (ao manages counters automatically)
2. Use type `BUG` for failures, `CHORE` for warnings

### ao CLI Reference

| Operation | Command |
|-----------|---------|
| Create issue from finding | `ao --yes issue add "..." priority:high type:BUG` |
| List existing issues | `ao ls` |
| Show issue | `ao --yes issue show <ID>` |

## Baseline Capture (mandatory before code changes)

1) Run build/lint commands from constitution
2) Write to `.agent/ops/baseline.md`:
   - commands executed
   - exit codes
   - warnings/errors grouped by file
3) Run unit tests command from constitution
4) Write to `.agent/ops/baseline.md`:
   - command
   - summary (pass/fail/skip counts)
   - failure details (stack traces / logs)

## Issue Discovery After Baseline

**After capturing baseline, invoke `ao-task` discovery procedure:**

1) Collect all findings from baseline:
   - Build errors → `BUG` (critical/high)
   - Test failures → `BUG` (high)
   - Lint errors → `BUG` (medium)
   - Lint warnings → `CHORE` (low/medium)
   - Missing test coverage → `TEST` (medium)
   - Security warnings → `SEC` (high)

2) Present to user:
   ```
   📋 Baseline captured. Found {N} existing issues:
   
   High:
   - [BUG] 2 failing tests in UserService
   - [SEC] 1 security warning (npm audit)
   
   Medium:
   - [BUG] 15 lint errors
   - [TEST] Coverage below threshold (72%)
   
   Low:
   - [CHORE] 23 lint warnings
   
   Create issues for these? [A]ll / [S]elect / [N]one / [D]efer
   ```

3) If user creates issues:
   - Offer to start fixing highest priority issue
   - After fixes, re-run baseline to capture cleaner state

4) If user defers:
   - Note in focus.json: "Baseline captured with {N} pre-existing issues"
   - Continue to next workflow step

## Baseline Comparison

Use this procedure when comparing current state to baseline (called by this skill or by critical-review):

### Input
- Current build/lint/test output
- `.agent/ops/baseline.md` contents

### Comparison Procedure

1) **Run checks** using constitution commands:
   ```
   build → lint → tests
   ```

2) **Categorize each finding**:

   | Finding | In Baseline? | Category | Action |
   |---------|--------------|----------|--------|
   | Error | No | NEW_REGRESSION | **BLOCK** — must fix |
   | Error | Yes | PRE_EXISTING | Note, continue |
   | Warning | No | NEW_WARNING | Investigate |
   | Warning | Yes | PRE_EXISTING | Ignore |
   | Test fail | No | NEW_FAILURE | **BLOCK** — must fix |
   | Test fail | Yes | PRE_EXISTING | Note, continue |
   | Fewer issues | — | IMPROVEMENT | Note improvement |

3) **Output comparison report**:
   ```markdown
   ## Comparison vs Baseline

   ### New Issues (must address)
   - [list new errors/failures]

   ### New Warnings (investigate)
   - [list new warnings]

   ### Pre-existing (noted)
   - [count of baseline issues still present]

   ### Improvements
   - [any reductions from baseline]

   ### Verdict: PASS | FAIL | INVESTIGATE
   ```

4) **Decision rules**:
   - Any NEW_REGRESSION → FAIL (block until fixed)
   - Only NEW_WARNING → INVESTIGATE (document or fix)
   - No new issues → PASS

## Template
Start from [baseline template](./templates/baseline.template.md).
