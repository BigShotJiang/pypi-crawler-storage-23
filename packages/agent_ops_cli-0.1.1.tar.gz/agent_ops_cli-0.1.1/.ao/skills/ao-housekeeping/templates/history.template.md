# Issue History (Archived)

Completed, cancelled, and dropped issues archived from priority files.

## Archive Policy

- Issues move here when status becomes: `done`, `cancelled`, `dropped`
- Rotate to `.agent/ops/issues/archives/history-YYYYMMDD.md` when exceeding 500 lines
- Use `ao-housekeeping` skill to perform archival

---

## Archived

<!-- Archived issues are appended below this line -->
