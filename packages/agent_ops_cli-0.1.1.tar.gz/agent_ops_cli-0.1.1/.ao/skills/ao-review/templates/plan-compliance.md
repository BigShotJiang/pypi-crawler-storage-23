# Plan Compliance Review Template

Use this template for Stage 1 of two-stage code review.

## Review Details

**Issue ID**: {ISSUE-ID}
**Review Date**: {Date}
**Diff**: BASE {base} → HEAD {head}

---

## Stage 1: Plan Compliance Review

### Implementation Plan Reference

Plan file: `.agent/ops/issues/references/{ISSUE-ID}-impl-plan.md`

### Compliance Check

| Requirement | Met? | Evidence |
|------------|--------|----------|
| All requirements implemented | ✅ / ❌ | {what was done} |
| No extra features added | ✅ / ❌ | {YAGNI check} |
| Follows specified approach | ✅ / ❌ | {architecture match} |
| No scope creep | ✅ / ❌ | {in scope only} |

### Deviations Identified

| Deviation Type | Description | Impact |
|----------------|-----------|--------|
| Missing requirement | {what's missing} | High/Medium/Low |
| Extra feature | {what was added} | Violates YAGNI |
| Architecture change | {different approach} | May need replan |

### Stage 1 Assessment

**Result**: SPEC COMPLIANT / NEEDS REVISION

**If NEEDS REVISION:**
- Required fixes: {list deviations}
- Block further work: Yes/No
- Approval required: Yes/No

**If SPEC COMPLIANT:**
- Proceed to Stage 2: Code Quality Review

---

## Stage 2: Code Quality Review

Only proceed if Stage 1 is SPEC COMPLIANT.

### Files Changed

| File | Lines Changed | Type |
|-------|----------------|------|
| {file1} | {count} | {modified/created} |
| {file2} | {count} | {modified/created} |

### Code Quality Assessment

| Category | Item | File | Line | Severity | Action |
|-----------|------|------|------|----------|--------|
| **Critical** | {description} | {file} | {line} | Must fix |
| **Critical** | {description} | {file} | {line} | Must fix |
| **Important** | {description} | {file} | {line} | Should fix |
| **Important** | {description} | {file} | {line} | Should fix |
| **Important** | {description} | {file} | {line} | Should fix |
| **Minor** | {description} | {file} | {line} | Optional |
| **Minor** | {description} | {file} | {line} | Optional |

### Strengths

- {strength 1}
- {strength 2}
- {strength 3}

### Overall Assessment

**Result**: APPROVED / REJECTED

**If APPROVED with Important:**
- Important fixes required before next task

**If APPROVED with Minor only:**
- Can proceed (Minor items optional)

**If REJECTED:**
- Critical items must be fixed
- Important items should be addressed
- Re-review required after fixes

---

## Notes

**Reviewer**: {agent/subagent}
**Review Duration**: {minutes}
**Next Steps**: {what happens next}
