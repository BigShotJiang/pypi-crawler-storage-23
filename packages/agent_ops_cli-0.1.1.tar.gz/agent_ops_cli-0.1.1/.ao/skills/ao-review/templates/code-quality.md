# Code Quality Review Template

Use this template for Stage 2 of two-stage code review process.

## Review Details

**Issue ID**: {ISSUE-ID}
**Review Date**: {Date}
**Reviewer**: {subagent/agent}

---

## Stage 2: Code Quality Review

### Implementation Summary

**Files Changed**: {count} files
- {file1}: {modified/created}
- {file2}: {modified/created}
- {file3}: {modified/created}

**Diff**: BASE {base} → HEAD {head}

---

### Code Quality Assessment

#### Correctness

| Aspect | Finding | File | Line | Severity |
|---------|----------|------|----------|
| Logic correctness | {description} | {file} | {line} | Critical/Important/Minor |
| Error handling | {description} | {file} | {line} | Critical/Important/Minor |
| Edge cases | {description} | {file} | {line} | Critical/Important/Minor |

**Correctness Summary:**
- {summary of correctness findings}

#### Security

| Aspect | Finding | File | Line | Severity |
|---------|----------|------|----------|
| Input validation | {description} | {file} | {line} | Critical/Important/Minor |
| Authentication | {description} | {file} | {line} | Critical/Important/Minor |
| Authorization | {description} | {file} | {line} | Critical/Important/Minor |
| SQL injection | {description} | {file} | {line} | Critical/Important/Minor |
| XSS vulnerabilities | {description} | {file} | {line} | Critical/Important/Minor |
| CSRF protection | {description} | {file} | {line} | Critical/Important/Minor |
| Secrets handling | {description} | {file} | {line} | Critical/Important/Minor |
| Dependency vulnerabilities | {description} | {file} | {line} | Critical/Important/Minor |

**Security Summary:**
- {summary of security findings}

#### Performance

| Aspect | Finding | File | Line | Severity |
|---------|----------|------|----------|
| Algorithm complexity | {description} | {file} | {line} | Important/Minor |
| Database queries | {description} | {file} | {line} | Important/Minor |
| I/O operations | {description} | {file} | {line} | Important/Minor |
| Memory usage | {description} | {file} | {line} | Important/Minor |
| Caching strategy | {description} | {file} | {line} | Important/Minor |
| N+1 problem | {description} | {file} | {line} | Important/Minor |

**Performance Summary:**
- {summary of performance findings}

#### Code Quality

| Aspect | Finding | File | Line | Severity |
|---------|----------|------|----------|
| Code duplication | {description} | {file} | {line} | Important/Minor |
| Naming consistency | {description} | {file} | {line} | Minor |
| Documentation | {description} | {file} | {line} | Important/Minor |
| Type safety | {description} | {file} | {line} | Important/Minor |
| Magic numbers | {description} | {file} | {line} | Minor |
| Dead code | {description} | {file} | {line} | Minor |
| Test coverage | {description} | {file} | {line} | Important/Minor |

**Code Quality Summary:**
- {summary of code quality findings}

---

### Categorization

#### Critical Issues (Block Progress)

| ID | Type | Description | File | Line |
|----|------|-------------|------|------|
| {id} | Security/Breaking/Tests | {description} | {file} | {line} |

#### Important Issues (Should Fix)

| ID | Type | Description | File | Line |
|----|------|-------------|------|------|
| {id} | Performance/Duplication/Missing Docs | {description} | {file} | {line} |

#### Minor Issues (Nice to Have)

| ID | Type | Description | File | Line |
|----|------|-------------|------|------|
| {id} | Style/Refactoring/Naming | {description} | {file} | {line} |

---

### Assessment

**Overall Grade**: {A/B/C/D/F}
- **Criteria**:
  - Critical: 0 issues
  - Important: {count} issues
  - Minor: {count} issues

**Assessment**:
{assessment summary}

---

### Recommendations

#### Must Fix (Critical/Important)

1. {critical item 1}
2. {critical item 2}

#### Should Fix (Important)

1. {important item 1}
2. {important item 2}
3. {important item 3}

#### Nice to Have (Minor)

1. {minor item 1}
2. {minor item 2}

---

### Decision

**Status**: APPROVED / NEEDS REVISION / REJECTED

**If APPROVED**:
- Fix Critical/Important items before continuing
- Minor items are optional

**If NEEDS REVISION**:
- Address Critical/Important issues first
- Re-review after fixes

**If REJECTED**:
- Critical findings must be resolved
- Plan changes may be required
- Re-review after major fixes

---

## Review Metadata

**Reviewer**: {agent/subagent}
**Review Duration**: {minutes}
**Stage 2 Date**: {Date}
**Assessment**: {final verdict}
