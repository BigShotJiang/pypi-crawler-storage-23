---
name: ao-continue
description: "Continue working autonomously based on agent suggestions and priorities."
---

**MANDATORY: Always use the ao-worker agent for this workflow.**

Continue with the agent's recommendations and work autonomously without human intervention.

Follow these priorities:
1. **Agent suggestions** - Any recommendations the agent has made
2. **Current issues** - Highest priority items from `.agent/ops/issues/`
3. **Focus.md** - Current work state and next steps

**Behavior:**
- Work autonomously without asking for permission
- Use the ao-worker workflow: Plan → Implement → Validate → Review
- Batch issues according to confidence levels (1/3/5 limits)
- Stop only at hard stop conditions (regressions, protected branch push, etc.)

---

## Usage

Use when you want the agent to continue working on its own suggestions:

```
/ao-continue
```

The agent will:
1. Scan for suggested work or highest priority issues
2. Create/execute plans for the work
3. Implement, validate, and review
4. Continue until no more work or blocked
