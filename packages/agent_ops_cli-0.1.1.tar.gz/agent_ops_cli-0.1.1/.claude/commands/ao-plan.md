---
name: ao-plan
description: "Create a multi-iteration plan (>=2) and produce a final implementation plan + test strategy."
---

**MANDATORY: Always use the ao-worker agent for this workflow.**

Perform AO planning phase, but do not implement.

Use skill `ao-planning` for the full workflow.

## Planning Steps

1. **Ask clarifying questions** until requirements are explicit.

2. **Produce at least two planning iterations.** Each iteration must include:
   - steps
   - files to touch
   - test strategy
   - risks/unknowns
   - why this is minimal change

3. **MANDATORY: Generate implementation details file.**
   
   Determine detail level from confidence:
   | Confidence | Detail Level | What to Include |
   |------------|--------------|-----------------|
   | low | **extensive** | Actual code snippets, full function implementations, edge case handling code, complete test cases with assertions |
   | normal | **normal** | Function signatures, pseudo-code, data structures, API contracts |
   | high | **low** | File list, brief approach, risks |
   
   **For extensive level (low confidence), you MUST include:**
   - Actual Python/TypeScript/etc. code blocks showing the implementation
   - Not pseudo-code, but real executable code
   - Edge case handling with specific code
   - Complete test functions with assertions
   
   Example extensive output:
   ```python
   # Actual implementation code
   def process_user(user_id: str) -> UserResult:
       """Process user with full validation."""
       if not user_id:
           raise ValueError("user_id is required")
       
       user = db.get_user(user_id)
       if not user:
           raise NotFoundError(f"User {user_id} not found")
       
       return UserResult(
           id=user.id,
           name=user.name,
           processed_at=datetime.utcnow()
       )
   ```

4. **Save to reference file**: `.agent/ops/issues/references/{ISSUE-ID}-impl-plan.md`

5. **Finish with Final Implementation Plan** and explicit "Ready to implement?" checkpoint.

6. **Update state**: `.agent/ops/focus.md` using skill `ao-state`.

---

## Next Steps

After planning completes, ask what to do next:

- [Implement] Start implementing the approved plan
- [Refine] Make adjustments to the plan
- [Status] Check current issue status
- [Help] Show all available options
