---
name: ao-implement
description: "Implement an approved plan with minimal diffs; run tests; keep .agent state updated."
---

**MANDATORY: Always use the ao-worker agent for this workflow.**

Implement the currently approved Final Implementation Plan.

Use skill `ao-implementation` for the full workflow.

**Before starting:**
- Check for implementation details file: `.agent/ops/issues/references/{ISSUE-ID}-impl-plan.md`
- If exists, use it as the primary guide for exact code to write

Constraints:
- No refactors without permission.
- Small, reviewable steps.
- Run the smallest reliable test subset after each step; full suite at the end.
- Update .agent/ops/focus.md continuously using skill `ao-state`.
- If you discover ambiguity, stop and ask clarifying questions (no guessing).
- Before finishing: compare results to .agent/ops/baseline.md and investigate all new findings.
- Reference implementation details file for edge cases and test scenarios.

---

## Next Steps

After implementation completes, ask what to do next:

- [Validate] Run validation checks against baseline
- [Continue] Continue with next issue/iteration
- [Status] Check current issue status
- [Review] Do a critical review of changes
- [Help] Show all available options
