---
name: ao-init
description: "Create/repair .agent/ops/* state files and folders using the standard templates."
agent: AO
---

**MANDATORY: Always use the ao-worker agent for this workflow.**

Create the required folder structure and state files under .agent/ops/ if missing:
- .agent/ops/memory.md
- .agent/ops/focus.md
- .agent/ops/issues/
- .agent/ops/issues/ (folder; ao will create events.jsonl and active.jsonl)
- .agent/ops/issues/.counter (initialized to 0)
- .agent/ops/baseline.md
- .agent/ops/constitution.md
- .agent/ops/references-index.md
- .agent/ops/references/ (folder)
- .agent/ops/docs/ (folder)
- .agent/ops/time-tracking.json (use template from .ao/skills/ao-state/templates/time-tracking.template.json)

Use the standard templates. Do not create any other files.

After creation:
- Update .agent/ops/focus.md indicating the repo is ready for constitution creation.
- Create an issue in .agent/ops/issues/ for completing the constitution interview.

Then the next step is constitution creation (handoff button "Create/Update Constitution" or run /ao-constitution).
