---
name: ao-task
description: "Create, refine, or manage issues in .agent/ops/issues/"
---

**MANDATORY: Always use the ao-worker agent for this workflow.**

## CRITICAL: Task Creation ONLY

**This prompt is for ISSUE MANAGEMENT only. NEVER start implementing issues.**

- ✅ Create issues
- ✅ Refine issues  
- ✅ List/search issues
- ✅ Triage backlog
- ❌ **NEVER implement code**
- ❌ **NEVER make file changes** (except to .agent/ops/issues/)
- ❌ **NEVER run build/test commands**

**After creating issues, ALWAYS offer a handoff:**
```
Issue(s) created. What's next?
1. Start implementing highest priority issue
2. Create more issues
3. Do nothing (end here)
```

Use the `ao-task` skill for all issue operations.

## Quick Create (just describe it)

Simply tell me what you need:
- "Add a bug for the login timeout issue, high priority"
- "Create a feature to add dark mode, medium priority, epic UI Refresh"
- "I need to fix the API rate limiting - it's critical"

I'll create the issue using `ao issue add` with a proper ID.

## Shorthand Format

```
/ao-task add "Fix login timeout" bug high
/ao-task add "Add dark mode" feat medium epic:"UI Refresh"
/ao-task add "Update dependencies" chore low
```

## Batch Mode (multiple issues)

```
/ao-task batch
```
Then list issues one per line, type `done` when finished.

## Other Operations

- **Refine**: `/ao-task refine` — clarify ambiguous issues
- **List**: `/ao-task list` — show issues by priority/status/epic
- **Search**: `/ao-task search FEAT-0012` — find specific issue
- **Triage**: `/ao-task triage` — prioritize backlog items
- **Backlog**: `/ao-task backlog "idea description"` — quick capture to backlog

## Backlog Quick Capture

For ideas that aren't ready for prioritization:
```
/ao-task idea "Maybe add GraphQL support"
/ao-task backlog "Research caching strategies"
```

These are added to ao with `priority: backlog`. Use triage later to promote or drop.

## Issue ID Format

`{TYPE}-{NUMBER}@{HASH}` — e.g., `BUG-0023@efa54f`

Types: `BUG` | `FEAT` | `CHORE` | `ENH` | `SEC` | `PERF` | `DOCS` | `TEST` | `REFAC` | `PLAN`
