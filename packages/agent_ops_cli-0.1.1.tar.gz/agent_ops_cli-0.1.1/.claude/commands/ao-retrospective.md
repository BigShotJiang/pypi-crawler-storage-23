---
name: ao-retrospective
description: "Scan this chat session for durable learnings and update .agent/ops/memory.md."
---

**MANDATORY: Always use the ao-worker agent for this workflow.**

Run the retrospective/learning workflow (use skill `ao-retrospective`).

Ensure:
- Commands/boundaries go into `.agent/ops/constitution.md`
- Only durable learnings (workflow rules, conventions, pitfalls, preferences) go into `.agent/ops/memory.md`
- Transient state stays in `.agent/ops/focus.md`
- Follow-ups and approvals needed go into `.agent/ops/issues/`

Update .agent/ops/focus.md and .agent/ops/issues/ using skill `ao-state`.
