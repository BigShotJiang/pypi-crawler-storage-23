---
name: ao-auto
description: "Autonomous work mode - actively finds and works on NORMAL/HIGH confidence issues without asking. LOW confidence issues are excluded."
---

**MANDATORY: Always use ao-worker agent for this workflow.**

Work autonomously on NORMAL and HIGH confidence issues without human intervention. The agent will:

1. **Scan active issues** (`ao ls --ready --sort priority`) for NORMAL/HIGH confidence actionable issues
2. **Work autonomously** on NORMAL/HIGH confidence issues without asking between them
3. **Skip LOW confidence issues** - they are detected and reported but not worked on
4. **Only ask when:**
   - No actionable issues found (`ao ls --ready` is empty; HARD STOP — only human can promote from backlog)
   - Only LOW confidence issues remain (auto cannot process them)
   - All remaining NORMAL/HIGH issues need clarification
   - Implementation or validation fails
   - Safety limits reached (max iterations, max time)

**Actionable issue criteria:**
- Status: `todo` or `in_progress`
- Not blocked
- No unresolved questions (no `- [ ]` items in "Questions to Resolve")
- All `depends_on` dependencies are done
- **Confidence: `normal` or `high` (NOT `low`)**

**Confidence limits:**
- **LOW:** NOT processed - skipped and reported (requires human oversight)
- **NORMAL:** Up to 3 issues per batch
- **HIGH:** Up to 5 issues per batch

**IMPORTANT:** ao-auto does NOT work on LOW confidence issues. LOW confidence issues require explicit human oversight per AO safety protocols.

---

## Usage

Use when you want the agent to work autonomously on NORMAL/HIGH confidence issues:

```
/ao-auto
```

The agent will:
1. Scan for NORMAL/HIGH confidence actionable issues via `ao ls --ready`
2. Work through them autonomously without asking
3. Skip LOW confidence issues and report them
4. Stop only when no more NORMAL/HIGH confidence issues exist or backlog needs prioritization
