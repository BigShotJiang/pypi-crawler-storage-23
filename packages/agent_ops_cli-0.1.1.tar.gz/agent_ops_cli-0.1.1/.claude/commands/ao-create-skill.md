---
name: ao-create-skill
description: "Create a new AO skill via interactive interview."
---

**MANDATORY: Always use the ao-worker agent for this workflow.**

Create a new skill using the `ao-create-skill` skill.

## Workflow

1. **Mode selection**: Ask user to choose:
   - A) From scratch — blank template
   - B) Clone existing — use existing skill as base

2. **Complexity assessment**: Determine tier:
   - Simple (5 questions): Single procedure, minimal dependencies
   - Complex (10+ questions): Multiple procedures, decision trees, error handling

3. **Interview**: Interview the user about the skill

4. **Generate**: Create SKILL.md in `.ao/skills/{name}/`

5. **Validate**: Verify file structure and frontmatter

## Quick Start

If user provides skill name/description upfront, skip to relevant questions.

Example: "Create a skill called ao-metrics for tracking project metrics"
→ Skip Q1-Q2, start at Q3 (category)

## Output

- `.ao/skills/{name}/SKILL.md` — the skill definition
