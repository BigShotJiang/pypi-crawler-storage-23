---
name: ao-housekeeping
description: "Comprehensive project hygiene: clean clutter, align docs, check git, audit ignores"
---

**MANDATORY: Always use the ao-worker agent for this workflow.**

Use skill `ao-housekeeping` for project-wide hygiene.

## Quick Commands

```
/ao-housekeeping           # Full sweep (all checks)
/ao-housekeeping --fix     # Auto-fix safe issues
/ao-housekeeping issues    # Archive completed issues only
/ao-housekeeping clutter   # Find stray markdown files
/ao-housekeeping readme    # Check README alignment
/ao-housekeeping git       # Git health warnings
/ao-housekeeping gitignore # Audit .gitignore
/ao-housekeeping state     # Verify .agent/ops/ integrity
```

## What It Checks

| Check | What | Action |
|-------|------|--------|
| **Issues** | Verify ao store consistency | Run `ao rebuild` to check |
| **Clutter** | Stray markdown, empty files, orphaned specs | Report, suggest cleanup |
| **README** | Outdated docs, broken links, missing features | Report, offer to update |
| **Git** | Uncommitted changes, stale branches, conflicts | Warn (never auto-commit) |
| **Gitignore** | Missing ignores for node_modules, dist, etc. | Suggest additions |
| **State** | Corrupted issues, stale focus, counter drift | Report, offer repair |
| **Deps** | Lock file staleness, obvious issues | Informational only |

## When to Run

- After completing a milestone
- Weekly maintenance
- Before starting new major work
- When things feel cluttered
- Before handoff to another developer
