---
name: ao-gh-actionable-comments
description: "Analyze PR review comments using gh CLI to identify actionable items."
---

**MANDATORY: Always use the ao-worker agent for this workflow.**

Use skill `ao-gh-actionable-comments` for the full workflow.

## Quick Start

Analyze pull request review comments for actionable items:

```
/ao-gh-actionable-comments [PR_NUMBER]
```

If PR number is omitted, uses the current branch's PR.

## Examples

**Current branch:**
```
/ao-gh-actionable-comments
```

**Specific PR:**
```
/ao-gh-actionable-comments #106
```

## Prerequisites

- `gh` CLI installed and authenticated
- Active pull request exists

## Output

- Summary table of all comment threads
- Actionable items with confidence levels
- Questions needing reviewer response
- Comments without author reply
