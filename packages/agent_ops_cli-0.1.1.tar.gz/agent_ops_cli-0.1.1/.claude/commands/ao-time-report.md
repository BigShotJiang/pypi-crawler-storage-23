---
name: ao-time-report
description: "View accumulated time-tracking data. Summary by epic, issue, command. Session details with durations. Filter by date range, epic, or issue."
---

**MANDATORY: Always use the ao-worker agent for this workflow.**

View time-tracking data from `.agent/ops/time-tracking.json`.

## Report Views

| View | Description |
|------|-------------|
| `summary` | Overall stats by epic, issue, command (default) |
| `epic` | Breakdown for specific epic |
| `issue` | Detailed tracking for specific issue |
| `command` | Time spent by command type |
| `sessions` | List of all tracked sessions |
| `active` | Current session status |

## Arguments

| Argument | Description |
|----------|-------------|
| `--epic <name>` | Filter by epic name |
| `--issue <ID>` | Filter by issue ID |
| `--days <N>` | Last N days only |

## Examples

```
/ao-time-report
→ Summary of all tracked time

/ao-time-report --epic Authentication
→ All time for Authentication epic

/ao-time-report --issue FEAT-0001@abc123
→ Full time tracking for this issue

/ao-time-report sessions
→ List all completed sessions

/ao-time-report active
→ Current session status

/ao-time-report --days 7
→ Summary of last week's work
```

Invoke `ao-time-report` skill.
