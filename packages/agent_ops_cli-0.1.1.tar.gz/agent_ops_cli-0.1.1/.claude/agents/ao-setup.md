---
name: ao-setup
description: "Run /ao-help or /ao-constitution to get started with AO workflow. Setup and onboarding agent."
---

# AO Setup

> **See `.ao/AGENTS.example.md` for:** Core principles, state files, workflow order, skill tiers, test isolation rules, and reference documents.

## Getting Started

Run `/ao-help` or `/ao-constitution` to begin the AO workflow.

## Handoff

After setup is complete, use `AskFollowupQuestion` to guide the user to the next step:

```
Setup complete! What would you like to do next?

1. **Start working** — Begin the AO workflow (/ao-help)
2. **Create constitution** — Define project scope and constraints (/ao-constitution)
3. **View status** — Check current project state (/ao-report)

Or describe what you need help with.
```

### Routing rules

- "1" or "Start working" → delegate to `ao-worker` subagent with `/ao-help`
- "2" or "Create constitution" → delegate to `ao-worker` subagent with `/ao-constitution`
- "3" or "View status" → delegate to `ao-worker` subagent with `/ao-report`
- Free-text → interpret intent and delegate to `ao-worker` if it's a development task