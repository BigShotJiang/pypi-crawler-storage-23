"""AO CLI — Typer application with global options and AppContext."""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version as pkg_version
from pathlib import Path
from typing import TYPE_CHECKING, Annotated

import typer
from rich.console import Console

from ao._internal.context import AppContext, OutputFormat, ProgressMode
from ao._internal.output import ErrorCode, emit_error, emit_success

if TYPE_CHECKING:
    from ao.api import AOClient

app = typer.Typer(add_completion=False, help="AO — Agent Ops Issues CLI")
console = Console()

issue_app = typer.Typer(help="Issue management commands")
gen_app = typer.Typer(help="Data generation commands")
bench_app = typer.Typer(help="Benchmark commands")
app.add_typer(issue_app, name="issue")
app.add_typer(gen_app, name="gen")
app.add_typer(bench_app, name="bench")

# Module-level context — set by app callback, consumed by commands.
_ctx: AppContext | None = None


def get_ctx() -> AppContext:
    """Return current AppContext (must be called after callback)."""
    assert _ctx is not None, "AppContext not initialised"  # noqa: S101
    return _ctx


def _get_client() -> AOClient:
    """Create AOClient from current AppContext."""
    from ao.api import AOClient as _Cls
    from ao.store import AOPaths

    ctx = get_ctx()
    return _Cls(AOPaths(ctx.root), codec="msgspec")


def _version_callback(value: bool) -> None:
    if value:
        for dist_name in ("agent-ops-cli", "agent-ops", "ao"):
            try:
                console.print(pkg_version(dist_name))
                raise typer.Exit()
            except PackageNotFoundError:
                continue
        console.print("unknown")
        raise typer.Exit()


@app.callback()
def main_callback(
    version: Annotated[
        bool,
        typer.Option("--version", callback=_version_callback, is_eager=True, help="Show version"),
    ] = False,
    root: Annotated[
        Path | None,
        typer.Option("--root", help="Override .agent/ops/ auto-detection"),
    ] = None,
    fmt: Annotated[
        OutputFormat,
        typer.Option("--format", help="Output format: table|json|jsonl|plain"),
    ] = OutputFormat.TABLE,
    yes: Annotated[
        bool,
        typer.Option("--yes", help="Non-interactive mode, no prompts"),
    ] = False,
    quiet: Annotated[
        bool,
        typer.Option("--quiet", help="Minimal output"),
    ] = False,
    progress: Annotated[
        ProgressMode,
        typer.Option("--progress", help="Progress display: auto|rich|none"),
    ] = ProgressMode.AUTO,
    in_path: Annotated[
        str | None,
        typer.Option("--in", help="Read JSON input from file or stdin (-)"),
    ] = None,
    out_path: Annotated[
        str,
        typer.Option("--out", help="Write output to file or stdout (-)"),
    ] = "-",
    sandbox: Annotated[
        bool,
        typer.Option("--sandbox", help="Sandbox mode: no background processes, direct JSONL I/O"),
    ] = False,
) -> None:
    """AO — Agent Ops Issues: high-performance JSONL issue/event store."""
    global _ctx  # noqa: PLW0603
    # When --yes is set and format wasn't explicitly changed, default to json+none
    effective_fmt = fmt
    effective_progress = progress
    if yes and fmt == OutputFormat.TABLE:
        effective_fmt = OutputFormat.JSON
    if yes and progress == ProgressMode.AUTO:
        effective_progress = ProgressMode.NONE
    _ctx = AppContext(
        root=root,
        fmt=effective_fmt,
        yes=yes,
        quiet=quiet,
        progress=effective_progress,
        in_path=in_path,
        out_path=out_path,
        sandbox=sandbox,
    )


@app.command()
def rebuild(
    codec: str = typer.Option("msgspec", help="Codec to use: orjson or msgspec"),
) -> None:
    """Rebuild active.jsonl from events.jsonl."""
    ctx = get_ctx()
    if not ctx.events_path.exists():
        console.print(f"[red]Error:[/red] {ctx.events_path} not found")
        raise typer.Exit(1)
    client = _get_client()
    stats = client.rebuild_snapshot()
    console.print(
        f"[green]Done:[/green] {stats['active_count']} active issues written to {ctx.active_path}"
    )


@app.command()
def query(
    status: str | None = typer.Option(None, help="Filter by status"),
    priority: str | None = typer.Option(None, help="Filter by priority"),
    type_: str | None = typer.Option(None, "--type", help="Filter by type"),
    epic: str | None = typer.Option(None, help="Filter by epic"),
    owner: str | None = typer.Option(None, help="Filter by owner"),
    confidence: str | None = typer.Option(None, help="Filter by confidence"),
) -> None:
    """Query and filter active issues."""
    from ao.codec import get_codec
    from ao.query import print_issues, query_active

    ctx = get_ctx()
    if not ctx.active_path.exists():
        console.print(f"[red]Error:[/red] {ctx.active_path} not found")
        raise typer.Exit(1)
    c = get_codec("msgspec")
    issues = query_active(
        ctx.active_path,
        c,
        status=status,
        priority=priority,
        type_=type_,
        epic=epic,
        owner=owner,
        confidence=confidence,
    )
    print_issues(issues)


# ── issue add (+ top-level alias) ─────────────────────────────────────────────


def _add_command(
    title: Annotated[str | None, typer.Argument(help="Issue title")] = None,
    type_: Annotated[str, typer.Option("--type", help="Issue type")] = "feat",
    priority: Annotated[str, typer.Option("--priority", help="Priority")] = "backlog",
    epic: Annotated[str, typer.Option("--epic", help="Epic name")] = "",
    owner: Annotated[str, typer.Option("--owner", help="Owner")] = "agent",
    confidence: Annotated[str, typer.Option("--confidence", help="Confidence")] = "normal",
    status: Annotated[str, typer.Option("--status", help="Initial status")] = "todo",
) -> None:
    """Create a new issue."""
    ctx = get_ctx()
    if ctx.in_path == "-":
        from ao._internal.commands.issue import issue_add

        issue_add(ctx, title, type_, priority, epic, owner, confidence, status)
        return
    if not title:
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, "Title is required")
        return
    client = _get_client()
    result = client.create(
        {
            "title": title,
            "type": type_,
            "priority": priority,
            "status": status,
            "epic": epic,
            "owner": owner,
            "confidence": confidence,
        }
    )
    emit_success(ctx, result)


issue_app.command("add")(_add_command)
app.command("add")(_add_command)


# ── issue show (+ top-level alias) ───────────────────────────────────────────


def _show_command(
    issue_id: Annotated[str, typer.Argument(help="Issue ID to display")],
) -> None:
    """Display full issue details."""
    ctx = get_ctx()
    from ao.api import AOClient
    from ao.errors import NotFoundError
    from ao.store import AOPaths

    paths = AOPaths(ctx.root)
    try:
        if ctx.format in (OutputFormat.JSON, OutputFormat.JSONL):
            client = AOClient(paths, codec="msgspec")
            result = client.get(issue_id)
            emit_success(ctx, {"issue": result})
        else:
            client = AOClient(paths, codec="msgspec", typed=True)
            issue = client.get(issue_id)
            from ao._internal.commands.issue import _render_issue_rich
            from ao.models import Issue

            assert isinstance(issue, Issue)  # noqa: S101
            _render_issue_rich(issue)
    except NotFoundError:
        emit_error(ctx, ErrorCode.NOT_FOUND, f"Issue {issue_id} not found")


issue_app.command("show")(_show_command)
app.command("show")(_show_command)


# ── issue set (+ top-level alias) ────────────────────────────────────────────


def _set_command(
    issue_id: Annotated[str, typer.Argument(help="Issue ID to update")],
    status: Annotated[str | None, typer.Option("--status", help="Status")] = None,
    priority: Annotated[str | None, typer.Option("--priority", help="Priority")] = None,
    owner: Annotated[str | None, typer.Option("--owner", help="Owner")] = None,
    confidence: Annotated[str | None, typer.Option("--confidence", help="Confidence")] = None,
    epic: Annotated[str | None, typer.Option("--epic", help="Epic")] = None,
    title: Annotated[str | None, typer.Option("--title", help="Title")] = None,
    notes: Annotated[str | None, typer.Option("--notes", help="Notes")] = None,
    external_ref: Annotated[
        str | None,
        typer.Option("--external-ref", help="External reference ID (e.g. JIRA-123 or URL)"),
    ] = None,
) -> None:
    """Quick scalar update on an issue."""
    ctx = get_ctx()
    fields: dict[str, str] = {}
    for key, val in [
        ("status", status),
        ("priority", priority),
        ("owner", owner),
        ("confidence", confidence),
        ("epic", epic),
        ("title", title),
        ("notes", notes),
        ("external_ref", external_ref),
    ]:
        if val is not None:
            fields[key] = val
    if not fields:
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, "No fields to update")
        return
    client = _get_client()
    result = client.patch(issue_id, {"set": fields})
    emit_success(ctx, result)


issue_app.command("set")(_set_command)
app.command("set")(_set_command)


# ── issue patch ───────────────────────────────────────────────────────────────


@issue_app.command("patch")
def patch_command(
    issue_id: Annotated[str, typer.Argument(help="Issue ID to patch")],
) -> None:
    """Apply structured JSON patch from stdin (--in -)."""
    from ao._internal.commands.issue import issue_patch

    issue_patch(get_ctx(), issue_id)


# ── issue close (+ top-level alias) ──────────────────────────────────────────


def _close_command(
    issue_id: Annotated[str, typer.Argument(help="Issue ID to close")],
    status: Annotated[str, typer.Option("--status", help="Terminal status")] = "done",
    log: Annotated[str | None, typer.Option("--log", help="Log message before close")] = None,
    solution: Annotated[str | None, typer.Option("--solution", help="Solution notes")] = None,
) -> None:
    """Close an issue."""
    ctx = get_ctx()
    client = _get_client()
    from ao.errors import ValidationError

    try:
        with client.batch() as b:
            if solution:
                b.patch(issue_id, {"set": {"notes": solution}})
            result = b.close(issue_id, log=log or "", status=status)
    except ValidationError as exc:
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, str(exc))
        return
    result["status"] = status
    emit_success(ctx, result)


issue_app.command("close")(_close_command)
app.command("close")(_close_command)


# ── complete ──────────────────────────────────────────────────────────────────


def _complete_command(
    issue_id: Annotated[str, typer.Argument(help="Issue ID to complete")],
    action: Annotated[str, typer.Option("--action", help="Completion action")] = "close",
    log: Annotated[str | None, typer.Option("--log", help="Log message")] = None,
) -> None:
    """Execute a completion action on an issue."""
    ctx = get_ctx()
    from ao._internal.commands.complete import execute_completion
    from ao.errors import ValidationError

    client = _get_client()
    try:
        result = execute_completion(
            issue_id, action, None, client, log=log or ""
        )
    except (ValidationError, ValueError) as exc:
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, str(exc))
        return
    emit_success(ctx, result)


issue_app.command("complete")(_complete_command)
app.command("complete")(_complete_command)


# ── log add ───────────────────────────────────────────────────────────────────


log_app = typer.Typer(help="Log management commands")
app.add_typer(log_app, name="log")


@log_app.command("add")
def log_add_cmd(
    issue_id: Annotated[str, typer.Argument(help="Issue ID")],
    message: Annotated[str, typer.Argument(help="Log message")],
) -> None:
    """Append a log entry to an issue."""
    ctx = get_ctx()
    client = _get_client()
    result = client.log_append(issue_id, message)
    emit_success(ctx, result)


# ── ls (+ kanban alias) ──────────────────────────────────────────────────────


@app.command("ls")
def ls_command(
    query_tokens: Annotated[list[str] | None, typer.Argument(help="Query tokens")] = None,
    status: Annotated[str | None, typer.Option("--status", help="Filter by status")] = None,
    priority: Annotated[str | None, typer.Option("--priority", help="Filter by priority")] = None,
    type_: Annotated[str | None, typer.Option("--type", help="Filter by type")] = None,
    epic: Annotated[str | None, typer.Option("--epic", help="Filter by epic")] = None,
    owner: Annotated[str | None, typer.Option("--owner", help="Filter by owner")] = None,
    confidence: Annotated[
        str | None, typer.Option("--confidence", help="Filter by confidence")
    ] = None,
    label: Annotated[str | None, typer.Option("--label", help="Filter by label")] = None,
    text: Annotated[str | None, typer.Option("--text", help="Text search")] = None,
    view: Annotated[
        str, typer.Option("--view", help="View: table|kanban|summary|counts|ids")
    ] = "table",
    sort: Annotated[
        str, typer.Option("--sort", help="Sort: priority|updated|id|confidence")
    ] = "priority",
    limit: Annotated[int | None, typer.Option("--limit", help="Max results")] = None,
) -> None:
    """List and filter issues."""
    from ao._internal.commands.ls import issue_ls

    issue_ls(
        get_ctx(),
        query_tokens=query_tokens,
        status=status,
        priority=priority,
        type_=type_,
        epic=epic,
        owner=owner,
        confidence=confidence,
        label=label,
        text=text,
        view=view,
        sort=sort,
        limit=limit,
    )


@app.command("kanban")
def kanban_command(
    query_tokens: Annotated[list[str] | None, typer.Argument(help="Query tokens")] = None,
) -> None:
    """Kanban board view (alias for ls --view kanban)."""
    from ao._internal.commands.ls import issue_ls

    issue_ls(get_ctx(), query_tokens=query_tokens, view="kanban")


# ── epic subcommands ──────────────────────────────────────────────────────────

epic_app = typer.Typer(help="Epic management commands")
app.add_typer(epic_app, name="epic")


@epic_app.command("ls")
def epic_ls_cmd() -> None:
    """List unique epics with issue counts."""
    from ao._internal.commands.epic import epic_ls

    epic_ls(get_ctx())


@epic_app.command("show")
def epic_show_cmd(
    epic_name: Annotated[str, typer.Argument(help="Epic name")],
) -> None:
    """List issues in a specific epic."""
    from ao._internal.commands.epic import epic_show

    epic_show(get_ctx(), epic_name)


@epic_app.command("rename")
def epic_rename_cmd(
    old_name: Annotated[str, typer.Argument(help="Current epic name")],
    new_name: Annotated[str, typer.Argument(help="New epic name")],
) -> None:
    """Rename an epic across all issues."""
    from ao._internal.commands.epic import epic_rename

    epic_rename(get_ctx(), old_name, new_name)


@epic_app.command("summary")
def epic_summary_cmd(
    epic_name: Annotated[str, typer.Argument(help="Epic name")],
) -> None:
    """Status/priority breakdown for an epic."""
    from ao._internal.commands.epic import epic_summary

    epic_summary(get_ctx(), epic_name)


@epic_app.command("analyze")
def epic_analyze_cmd(
    model: Annotated[
        str | None, typer.Argument(help="AI model (e.g. openai:gpt-4o)")
    ] = None,
    apply: Annotated[bool, typer.Option("--apply", help="Apply suggestions")] = False,
    include_assigned: Annotated[
        bool, typer.Option("--include-assigned", help="Include issues with epics")
    ] = False,
) -> None:
    """Suggest epic assignments for issues using an AI model."""
    from ao._internal.commands.epic_analyze import epic_analyze

    epic_analyze(get_ctx(), model, apply=apply, include_assigned=include_assigned)


# ── ac subcommands ────────────────────────────────────────────────────────────

ac_app = typer.Typer(help="Acceptance criteria commands")
app.add_typer(ac_app, name="ac")


@ac_app.command("ls")
def ac_ls_cmd(
    issue_id: Annotated[str, typer.Argument(help="Issue ID")],
) -> None:
    """List acceptance criteria for an issue."""
    from ao._internal.commands.ac import ac_ls

    ac_ls(get_ctx(), issue_id)


@ac_app.command("add")
def ac_add_cmd(
    issue_id: Annotated[str, typer.Argument(help="Issue ID")],
    text: Annotated[str, typer.Argument(help="Criterion text")],
) -> None:
    """Add an acceptance criterion to an issue."""
    from ao._internal.commands.ac import ac_add

    ac_add(get_ctx(), issue_id, text)


@ac_app.command("check")
def ac_check_cmd(
    issue_id: Annotated[str, typer.Argument(help="Issue ID")],
    index: Annotated[int, typer.Argument(help="1-based criterion index")],
) -> None:
    """Mark an acceptance criterion as done."""
    from ao._internal.commands.ac import ac_check

    ac_check(get_ctx(), issue_id, index)


@ac_app.command("uncheck")
def ac_uncheck_cmd(
    issue_id: Annotated[str, typer.Argument(help="Issue ID")],
    index: Annotated[int, typer.Argument(help="1-based criterion index")],
) -> None:
    """Mark an acceptance criterion as not done."""
    from ao._internal.commands.ac import ac_uncheck

    ac_uncheck(get_ctx(), issue_id, index)


@ac_app.command("rm")
def ac_rm_cmd(
    issue_id: Annotated[str, typer.Argument(help="Issue ID")],
    index: Annotated[int, typer.Argument(help="1-based criterion index")],
) -> None:
    """Remove an acceptance criterion."""
    from ao._internal.commands.ac import ac_rm

    ac_rm(get_ctx(), issue_id, index)


# ── event subcommands ─────────────────────────────────────────────────────────

event_app = typer.Typer(help="Raw event commands")
app.add_typer(event_app, name="event")


@event_app.command("append")
def event_append_cmd(
    no_rebuild: Annotated[
        bool, typer.Option("--no-rebuild", help="Skip active.jsonl rebuild")
    ] = False,
) -> None:
    """Append a raw event from stdin (--in -)."""
    from ao._internal.commands.event import event_append

    event_append(get_ctx(), no_rebuild=no_rebuild)


# ── ref subcommands ───────────────────────────────────────────────────────────

ref_app = typer.Typer(help="Reference doc commands")
app.add_typer(ref_app, name="ref")


@ref_app.command("init")
def ref_init_cmd(
    issue_id: Annotated[str, typer.Argument(help="Issue ID")],
) -> None:
    """Create reference doc from template and attach it."""
    from ao._internal.commands.ref import ref_init

    ref_init(get_ctx(), issue_id)


@ref_app.command("open")
def ref_open_cmd(
    issue_id: Annotated[str, typer.Argument(help="Issue ID")],
) -> None:
    """Open reference doc in $EDITOR."""
    from ao._internal.commands.ref import ref_open

    ref_open(get_ctx(), issue_id)


@ref_app.command("attach")
def ref_attach_cmd(
    issue_id: Annotated[str, typer.Argument(help="Issue ID")],
    path: Annotated[str, typer.Argument(help="Path to reference doc")],
) -> None:
    """Attach a custom reference doc path."""
    from ao._internal.commands.ref import ref_attach

    ref_attach(get_ctx(), issue_id, path)


@ref_app.command("status")
def ref_status_cmd(
    issue_id: Annotated[str, typer.Argument(help="Issue ID")],
) -> None:
    """Check reference doc status."""
    from ao._internal.commands.ref import ref_status

    ref_status(get_ctx(), issue_id)


# ── link subcommands ──────────────────────────────────────────────────────────

link_app = typer.Typer(help="Dependency link commands")
app.add_typer(link_app, name="link")


@link_app.command("add")
def link_add_cmd(
    issue_id: Annotated[str, typer.Argument(help="Issue ID")],
    depends_on: Annotated[
        str | None, typer.Option("--depends-on", help="Depends on issue ID")
    ] = None,
    blocks: Annotated[str | None, typer.Option("--blocks", help="Blocks issue ID")] = None,
) -> None:
    """Add a dependency link."""
    from ao._internal.commands.link import link_add

    link_add(get_ctx(), issue_id, depends_on=depends_on, blocks=blocks)


@link_app.command("rm")
def link_rm_cmd(
    issue_id: Annotated[str, typer.Argument(help="Issue ID")],
    depends_on: Annotated[
        str | None, typer.Option("--depends-on", help="Depends on issue ID")
    ] = None,
    blocks: Annotated[str | None, typer.Option("--blocks", help="Blocks issue ID")] = None,
) -> None:
    """Remove a dependency link."""
    from ao._internal.commands.link import link_rm

    link_rm(get_ctx(), issue_id, depends_on=depends_on, blocks=blocks)


@link_app.command("show")
def link_show_cmd(
    issue_id: Annotated[str, typer.Argument(help="Issue ID")],
) -> None:
    """Display dependency info for an issue."""
    from ao._internal.commands.link import link_show

    link_show(get_ctx(), issue_id)


@link_app.command("graph")
def link_graph_cmd(
    epic: Annotated[str | None, typer.Option("--epic", help="Filter by epic")] = None,
    fmt: Annotated[str, typer.Option("--graph-format", help="Output: json|mermaid|table")] = "json",
) -> None:
    """Generate dependency graph."""
    from ao._internal.commands.link import link_graph

    link_graph(get_ctx(), epic=epic, fmt=fmt)


@link_app.command("typed-add")
def link_typed_add_cmd(
    issue_id: Annotated[str, typer.Argument(help="Issue ID")],
    link_type: Annotated[
        str,
        typer.Option("--type", help="Link type: related|duplicate_of|discovered_from|parent|child"),
    ],
    target: Annotated[str, typer.Option("--to", help="Target issue ID")],
) -> None:
    """Add a typed link (related, duplicate_of, discovered_from, parent, child)."""
    from ao._internal.commands.link import typed_link_add

    typed_link_add(get_ctx(), issue_id, link_type, target)


@link_app.command("typed-rm")
def link_typed_rm_cmd(
    issue_id: Annotated[str, typer.Argument(help="Issue ID")],
    link_type: Annotated[str, typer.Option("--type", help="Link type")],
    target: Annotated[str, typer.Option("--to", help="Target issue ID")],
) -> None:
    """Remove a typed link."""
    from ao._internal.commands.link import typed_link_rm

    typed_link_rm(get_ctx(), issue_id, link_type, target)


@app.command("dep-tree")
def dep_tree_cmd(
    issue_id: Annotated[str, typer.Argument(help="Issue ID")],
    depth: Annotated[int, typer.Option("--depth", help="Max traversal depth")] = 5,
) -> None:
    """Show dependency tree for an issue with cycle detection."""
    from ao._internal.commands.link import dep_tree

    dep_tree(get_ctx(), issue_id, depth)


@app.command("merge")
def merge_cmd(
    output: Annotated[str, typer.Argument(help="Output events.jsonl path")],
    ours: Annotated[str, typer.Argument(help="Our events.jsonl path")],
    theirs: Annotated[str, typer.Argument(help="Their events.jsonl path")],
    base: Annotated[
        str | None, typer.Option("--base", help="Common ancestor events.jsonl (optional)")
    ] = None,
    strategy: Annotated[
        str,
        typer.Option("--strategy", help="Conflict strategy: newest|ours|theirs"),
    ] = "newest",
    rebuild_after: Annotated[
        bool, typer.Option("--rebuild/--no-rebuild", help="Rebuild active.jsonl after merge")
    ] = True,
) -> None:
    """Merge two events.jsonl files deterministically (union + dedup by event_id)."""
    from ao._internal.merge import merge_command

    ctx = get_ctx()
    base_path = Path(base) if base else None
    result = merge_command(Path(output), Path(ours), Path(theirs), base_path, strategy)
    if rebuild_after:
        from ao._internal.rebuild import rebuild as do_rebuild
        from ao.codec import MsgspecCodec

        active = Path(output).parent / "active.jsonl"
        do_rebuild(Path(output), active, MsgspecCodec(), show_progress=False)
        result["active"] = str(active)
    emit_success(ctx, result)


# ── hooks subcommands ─────────────────────────────────────────────────────────

hooks_app = typer.Typer(help="Git hook management commands")
app.add_typer(hooks_app, name="hooks")


@hooks_app.command("install")
def hooks_install_cmd(
    force: Annotated[bool, typer.Option("--force", help="Overwrite existing non-AO hooks")] = False,
) -> None:
    """Install AO git hooks (post-merge, post-checkout, pre-push)."""
    from ao._internal.hooks import hooks_install

    ctx = get_ctx()
    result = hooks_install(Path.cwd(), force=force)
    emit_success(ctx, result)


@hooks_app.command("uninstall")
def hooks_uninstall_cmd() -> None:
    """Remove AO-installed git hooks."""
    from ao._internal.hooks import hooks_uninstall

    ctx = get_ctx()
    result = hooks_uninstall(Path.cwd())
    emit_success(ctx, result)


@hooks_app.command("status")
def hooks_status_cmd() -> None:
    """Show status of AO git hooks."""
    from ao._internal.hooks import hooks_status

    ctx = get_ctx()
    result = hooks_status(Path.cwd())
    emit_success(ctx, result)


@hooks_app.command("run")
def hook_run_cmd(
    engine: Annotated[str, typer.Option("--engine", help="Engine: claude|copilot|vscode|opencode")],
    event: Annotated[str, typer.Option("--event", help="Hook event name from the engine")],
) -> None:
    """Run an AO hook rule: read JSON payload from stdin, write decision to stdout."""
    import sys

    from ao._internal.agent_hook import format_decision, run_hook

    ctx = get_ctx()
    raw_bytes = sys.stdin.buffer.read()
    payload: dict[str, object] = {}
    if raw_bytes.strip():
        import json as _json

        payload = _json.loads(raw_bytes)
    decision = run_hook(ctx, engine, event, payload)
    formatted = format_decision(engine, decision)
    emit_success(ctx, formatted if formatted else decision)
    if decision.get("exit_code", 0) != 0:
        raise typer.Exit(code=int(decision["exit_code"]))


@hooks_app.command("test")
def hook_test_cmd(
    engine: Annotated[str, typer.Option("--engine", help="Engine: claude|copilot|vscode|opencode")],
    event: Annotated[str, typer.Option("--event", help="Hook event name from the engine")],
    payload_file: Annotated[
        Path | None,
        typer.Option("--payload", help="JSON payload file (- for stdin)"),
    ] = None,
) -> None:
    """Test an AO hook rule with a sample payload and show the decision."""
    import json as _json
    import sys

    from ao._internal.agent_hook import format_decision, run_hook

    ctx = get_ctx()
    if payload_file and str(payload_file) != "-":
        raw = payload_file.read_bytes()
    else:
        raw = sys.stdin.buffer.read()
    payload: dict[str, object] = _json.loads(raw) if raw.strip() else {}
    decision = run_hook(ctx, engine, event, payload)
    formatted = format_decision(engine, decision)
    emit_success(ctx, {"decision": decision, "formatted": formatted})


@hooks_app.command("agent-install")
def hooks_agent_install_cmd(
    engine: Annotated[str, typer.Option("--engine", help="Engine: claude|copilot|vscode|opencode")],
) -> None:
    """Install AO hook config for an AI agent engine (Claude/Copilot/VS Code/OpenCode)."""
    from ao._internal.agent_install import agent_install

    ctx = get_ctx()
    result = agent_install(Path.cwd(), engine)
    emit_success(ctx, result)


@hooks_app.command("loop-prompt")
def hooks_loop_prompt_cmd(
    engine: Annotated[str, typer.Option("--engine", help="Engine: opencode|copilot|claude")],
    output: Annotated[
        Path | None,
        typer.Option("--output", "-o", help="Write prompt to file instead of stdout"),
    ] = None,
) -> None:
    """Generate an AO iteration prompt for the given agent engine."""
    from ao._internal.loop import generate_loop_prompt

    ctx = get_ctx()
    prompt = generate_loop_prompt(ctx, engine)
    if output:
        output.write_text(prompt, encoding="utf-8")
        emit_success(ctx, {"ok": True, "file": str(output), "engine": engine})
    else:
        import sys

        sys.stdout.write(prompt)


@hooks_app.command("loop-run")
def hooks_loop_run_cmd(
    engine: Annotated[str, typer.Option("--engine", help="Engine: opencode|copilot|claude")],
    max_iterations: Annotated[
        int,
        typer.Option("--max", help="Maximum number of agent iterations"),
    ] = 10,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="Generate prompt only, do not invoke agent"),
    ] = False,
) -> None:
    """Run the AO iteration loop: invoke the agent engine until no ready issues remain."""
    from ao._internal.loop import run_loop

    ctx = get_ctx()
    result = run_loop(ctx, engine, max_iterations, dry_run=dry_run)
    emit_success(ctx, result)


# ── validate ──────────────────────────────────────────────────────────────────


@app.command("validate")
def validate_cmd(
    timeout: Annotated[int, typer.Option("--timeout", help="Per-command timeout in seconds")] = 60,
    commands: Annotated[
        list[str] | None,
        typer.Option("--cmd", help="Override command (repeat for multiple)"),
    ] = None,
) -> None:
    """Run configured validation commands (tests, lint, etc.)."""
    from ao._internal.validate import validate_all

    ctx = get_ctx()
    result = validate_all(ctx.root, timeout=timeout, commands=commands or None)
    emit_success(ctx, result)
    if not result.get("ok"):
        raise typer.Exit(code=1)


# ── gate ──────────────────────────────────────────────────────────────────────


@app.command("gate")
def gate_cmd(
    issue_id: Annotated[
        str | None, typer.Argument(help="Issue ID to check; uses focus.json if omitted")
    ] = None,
    no_validate: Annotated[
        bool, typer.Option("--no-validate", help="Skip running validation commands")
    ] = False,
    timeout: Annotated[int, typer.Option("--timeout", help="Validation timeout in seconds")] = 60,
) -> None:
    """Check AO completion gate: issue done + no blockers + validation passes."""
    from ao._internal.gate import check_gate

    ctx = get_ctx()
    result = check_gate(ctx, issue_id, run_validate=not no_validate, validate_timeout=timeout)
    emit_success(ctx, result)
    if result.get("state") != "done":
        raise typer.Exit(code=1)


# ── import ────────────────────────────────────────────────────────────────────


@app.command("import")
def import_cmd(
    source: Annotated[Path, typer.Argument(help="Source JSONL file to import events from")],
    dedupe: Annotated[
        bool, typer.Option("--dedupe/--no-dedupe", help="Skip duplicate event_ids")
    ] = True,
    orphan: Annotated[
        str, typer.Option("--orphan", help="Orphan strategy: allow|skip|strict|resurrect")
    ] = "allow",
    rebuild: Annotated[
        bool, typer.Option("--rebuild/--no-rebuild", help="Rebuild active.jsonl after import")
    ] = True,
) -> None:
    """Import events from an external JSONL file into events.jsonl."""
    from ao._internal.importer import import_events

    ctx = get_ctx()
    result = import_events(ctx.events_path, source, dedupe=dedupe, orphan=orphan)
    if rebuild:
        from ao._internal.rebuild import rebuild as _do_rebuild
        from ao.codec import MsgspecCodec

        _do_rebuild(ctx.events_path, ctx.active_path, MsgspecCodec(), show_progress=False)
    emit_success(ctx, result)


# ── suggest-labels ────────────────────────────────────────────────────────────


@app.command("suggest-labels")
def suggest_labels_cmd(
    files: Annotated[list[str], typer.Argument(help="File paths to match against label patterns")],
    config: Annotated[
        Path | None, typer.Option("--config", help="Path to labels-config.toml")
    ] = None,
    apply: Annotated[
        str | None, typer.Option("--apply", help="Issue ID to apply labels to")
    ] = None,
) -> None:
    """Suggest labels for the given file paths using glob-to-label config."""
    from ao._internal.suggest_labels import suggest_labels_for_issue

    ctx = get_ctx()
    labels = suggest_labels_for_issue(ctx.root, files, config_path=config)
    if apply and labels:
        from ao._internal.commands.label import label_add

        for lbl in labels:
            label_add(ctx, apply, lbl)
    emit_success(ctx, {"labels": labels, "applied_to": apply})


# ── admin ─────────────────────────────────────────────────────────────────────


admin_app = typer.Typer(help="Admin recovery and migration commands")
app.add_typer(admin_app, name="admin")


@admin_app.command("cleanup")
def admin_cleanup_cmd(
    no_rebuild: Annotated[
        bool, typer.Option("--no-rebuild", help="Skip rebuild after cleanup")
    ] = False,
) -> None:
    """Remove derived files and rebuild from events.jsonl."""
    from ao._internal.admin import admin_cleanup

    ctx = get_ctx()
    result = admin_cleanup(ctx.root, rebuild=not no_rebuild)
    emit_success(ctx, result)


@admin_app.command("reset")
def admin_reset_cmd(
    force: Annotated[
        bool, typer.Option("--force", help="Actually delete data (default: dry-run)")
    ] = False,
) -> None:
    """Wipe all AO data (dry-run unless --force)."""
    from ao._internal.admin import admin_reset

    ctx = get_ctx()
    result = admin_reset(ctx.root, force=force)
    emit_success(ctx, result)


@admin_app.command("migrate")
def admin_migrate_cmd(
    from_path: Annotated[Path, typer.Argument(help="Source project path or events.jsonl")],
    no_dedupe: Annotated[
        bool, typer.Option("--no-dedupe", help="Allow duplicate event ids")
    ] = False,
    orphan: Annotated[
        str, typer.Option("--orphan", help="Orphan strategy: allow|skip|strict|resurrect")
    ] = "allow",
) -> None:
    """Migrate events from another project into this one."""
    from ao._internal.admin import admin_migrate

    ctx = get_ctx()
    result = admin_migrate(ctx.root, from_path, dedupe=not no_dedupe, orphan=orphan)
    emit_success(ctx, result)


# ── next + triage ─────────────────────────────────────────────────────────────


@app.command("next")
def next_command(
    owner: Annotated[str | None, typer.Option("--owner", help="Filter by owner")] = None,
    limit: Annotated[int, typer.Option("--limit", help="Max results")] = 10,
) -> None:
    """Print top N ready-to-work issues."""
    from ao._internal.commands.triage import issue_next

    issue_next(get_ctx(), owner=owner, limit=limit)


@app.command("stale")
def stale_command(
    days: Annotated[int, typer.Option("--days", help="Issues not updated in N+ days")] = 7,
) -> None:
    """List issues not updated within N days."""
    from ao._internal.commands.stale import issue_stale

    issue_stale(get_ctx(), days=days)


@app.command("onboard")
def onboard_command(
    output: Annotated[str | None, typer.Option("--output", help="Output file path")] = None,
) -> None:
    """Generate AOI_GUIDE.md for agent onboarding."""
    from ao._internal.commands.onboard import onboard_generate

    onboard_generate(get_ctx(), output=output)


@app.command("install")
def install_command(
    target: Annotated[
        Path | None,
        typer.Argument(help="Install destination folder (defaults to current directory)"),
    ] = None,
    with_github: Annotated[
        bool | None,
        typer.Option("--github/--no-github", help="Install .github assets"),
    ] = None,
    with_claude: Annotated[
        bool | None,
        typer.Option("--claude/--no-claude", help="Install .claude assets"),
    ] = None,
    with_opencode: Annotated[
        bool | None,
        typer.Option("--opencode/--no-opencode", help="Install .opencode assets"),
    ] = None,
    categories: Annotated[
        list[str] | None,
        typer.Option("--category", help="Category to install from .ao assets (repeatable)"),
    ] = None,
    force: Annotated[
        bool,
        typer.Option("--force", help="Overwrite existing files without prompting"),
    ] = False,
    skip_existing: Annotated[
        bool,
        typer.Option("--skip-existing", help="Skip files that already exist"),
    ] = False,
) -> None:
    """Install AO asset folders (.ao always, optional engine-specific folders)."""
    from ao._internal.commands.install import install_command as run_install

    run_install(
        get_ctx(),
        target,
        with_github=with_github,
        with_claude=with_claude,
        with_opencode=with_opencode,
        categories=categories,
        force=force,
        skip_existing=skip_existing,
    )


@app.command("update")
def update_command(
    target: Annotated[
        Path | None,
        typer.Argument(help="Update destination folder (defaults to current directory)"),
    ] = None,
    with_github: Annotated[
        bool | None,
        typer.Option("--github/--no-github", help="Update .github assets"),
    ] = None,
    with_claude: Annotated[
        bool | None,
        typer.Option("--claude/--no-claude", help="Update .claude assets"),
    ] = None,
    with_opencode: Annotated[
        bool | None,
        typer.Option("--opencode/--no-opencode", help="Update .opencode assets"),
    ] = None,
    categories: Annotated[
        list[str] | None,
        typer.Option("--category", help="Category to update from .ao assets (repeatable)"),
    ] = None,
    force: Annotated[
        bool,
        typer.Option("--force", help="Overwrite existing files without prompting"),
    ] = False,
    skip_existing: Annotated[
        bool,
        typer.Option("--skip-existing", help="Skip files that already exist"),
    ] = False,
) -> None:
    """Update AO assets; never mutates `.agent` files."""
    from ao._internal.commands.install import update_command as run_update

    run_update(
        get_ctx(),
        target,
        with_github=with_github,
        with_claude=with_claude,
        with_opencode=with_opencode,
        categories=categories,
        force=force,
        skip_existing=skip_existing,
    )


@app.command("prime")
def prime_command(
    fmt: Annotated[str, typer.Option("--fmt", help="Output format: text|json")] = "text",
) -> None:
    """Output machine-readable AO command/schema summary."""
    from ao._internal.commands.onboard import prime_output

    prime_output(get_ctx(), fmt=fmt)


@app.command("duplicate")
def duplicate_command(
    skill_name: Annotated[str, typer.Argument(help="Existing skill name (e.g. ao-task)")],
    new_skill_name: Annotated[str, typer.Argument(help="New skill name to create")],
    target: Annotated[
        Path | None,
        typer.Option("--target", help="Project root containing .ao/.github/.claude/.opencode"),
    ] = None,
) -> None:
    """Duplicate a skill and related prompt/command assets across supported engines."""
    from ao._internal.commands.duplicate import duplicate_skill_assets

    ctx = get_ctx()
    root = (target or Path.cwd()).resolve()
    try:
        result = duplicate_skill_assets(root, skill_name, new_skill_name)
    except ValueError as exc:
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, str(exc))
        return
    emit_success(ctx, result)


focus_app = typer.Typer(
    invoke_without_command=True, help="Session focus management (show or update focus.json)"
)
app.add_typer(focus_app, name="focus")


@focus_app.callback()
def focus_callback(ctx: typer.Context) -> None:
    """Show session-resume context from focus.json with resolved issue details."""
    if ctx.invoked_subcommand is None:
        from ao._internal.commands.focus import show_focus

        show_focus(get_ctx())


@focus_app.command("set-doing")
def focus_set_doing_cmd(
    issue_id: Annotated[
        str, typer.Argument(help="Full issue ID (e.g. FEAT-0042@abc123) or empty string to clear")
    ],
    task: Annotated[str | None, typer.Option("--task", help="Short task description")] = None,
    confidence: Annotated[
        str | None, typer.Option("--confidence", help="Confidence level: low|normal|high")
    ] = None,
) -> None:
    """Set the doing_now field in focus.json. REQUIRED — never edit focus.json directly."""
    from ao._internal.commands.focus import update_doing_now

    ctx = get_ctx()
    result = update_doing_now(ctx, issue_id, task=task, confidence=confidence)
    emit_success(ctx, result)


@focus_app.command("set-next")
def focus_set_next_cmd(
    text: Annotated[str, typer.Argument(help="Description of the next step")],
) -> None:
    """Set the 'next' field in focus.json. REQUIRED — never edit focus.json directly."""
    from ao._internal.commands.focus import update_next

    ctx = get_ctx()
    result = update_next(ctx, text)
    emit_success(ctx, result)


@focus_app.command("set-just-did")
def focus_set_just_did_cmd(
    summary: Annotated[str, typer.Argument(help="Summary of what was just completed")],
) -> None:
    """Set the 'just_did' field in focus.json. REQUIRED — never edit focus.json directly."""
    from ao._internal.commands.focus import update_just_did

    ctx = get_ctx()
    result = update_just_did(ctx, summary)
    emit_success(ctx, result)


@focus_app.command("iteration")
def focus_iteration_cmd(
    increment: Annotated[
        bool, typer.Option("--increment", help="Increment current_iteration by 1")
    ] = False,
    issues: Annotated[
        str | None, typer.Option("--issues", help="Comma-separated issue IDs for this iteration")
    ] = None,
    confidence_mix: Annotated[
        str | None,
        typer.Option("--confidence-mix", help="Free-text confidence summary (e.g. '3 normal')"),
    ] = None,
) -> None:
    """Update iteration_tracking in focus.json. REQUIRED — never edit focus.json directly."""
    from ao._internal.commands.focus import update_iteration

    ctx = get_ctx()
    parsed_issues = [i.strip() for i in issues.split(",")] if issues else None
    result = update_iteration(
        ctx, increment=increment, issues=parsed_issues, confidence_mix=confidence_mix
    )
    emit_success(ctx, result)


@focus_app.command("sync")
def focus_sync_cmd() -> None:
    """Rebuild in_progress/next_queue/recent_work from active issue store."""
    from ao._internal.commands.focus import sync_queues

    ctx = get_ctx()
    result = sync_queues(ctx)
    emit_success(ctx, result)


@app.command("triage")
def triage_command() -> None:
    """Interactive bulk triage (human only)."""
    from ao._internal.commands.triage import issue_triage

    issue_triage(get_ctx())


# ── export subcommands ────────────────────────────────────────────────────────

export_app = typer.Typer(help="Export commands")
app.add_typer(export_app, name="export")


@export_app.command("json")
def export_json_cmd(
    out: Annotated[str, typer.Option("--out", help="Output file path")],
) -> None:
    """Export all active issues as single JSON file."""
    from ao._internal.commands.export import export_json

    export_json(get_ctx(), out)


@export_app.command("jsonl")
def export_jsonl_cmd(
    out: Annotated[str, typer.Option("--out", help="Output file path")],
) -> None:
    """Export all active issues as JSONL file."""
    from ao._internal.commands.export import export_jsonl

    export_jsonl(get_ctx(), out)


@gen_app.command("events")
def gen_events(
    issues: int = typer.Option(1000, help="Number of issues to generate"),
    updates_per_issue: int = typer.Option(3, help="Updates per issue"),
    close_ratio: float = typer.Option(0.3, help="Fraction of issues to close"),
    avg_notes_bytes: int = typer.Option(100, help="Average note size in bytes"),
    out: str = typer.Option("data/events.jsonl", help="Output file path"),
) -> None:
    """Generate stress-test events.jsonl."""
    from ao._internal.gen import generate_events

    count = generate_events(
        issues=issues,
        updates_per_issue=updates_per_issue,
        close_ratio=close_ratio,
        avg_notes_bytes=avg_notes_bytes,
        out=Path(out),
    )
    console.print(f"[green]Done:[/green] {count:,} events written to {out}")


@bench_app.command("decode")
def bench_decode_cmd(
    file: str = typer.Option(..., help="JSONL file to decode"),
    codec: str = typer.Option("msgspec", help="Codec: orjson or msgspec"),
) -> None:
    """Benchmark decode throughput."""
    from ao._internal.bench import bench_decode

    file_path = Path(file)
    if not file_path.exists():
        console.print(f"[red]Error:[/red] {file} not found")
        raise typer.Exit(1)
    bench_decode(file_path, codec)


@bench_app.command("rebuild")
def bench_rebuild_cmd(
    events: str = typer.Option(..., help="Events JSONL file"),
    codec: str = typer.Option("msgspec", help="Codec: orjson or msgspec"),
) -> None:
    """Benchmark rebuild performance."""
    from ao._internal.bench import bench_rebuild

    events_path = Path(events)
    if not events_path.exists():
        console.print(f"[red]Error:[/red] {events} not found")
        raise typer.Exit(1)
    bench_rebuild(events_path, codec)


# ── label subcommands ─────────────────────────────────────────────────────────

label_app = typer.Typer(help="Label management commands")
app.add_typer(label_app, name="label")


@label_app.command("add")
def label_add_cmd(
    issue_id: Annotated[str, typer.Argument(help="Issue ID")],
    label: Annotated[str, typer.Argument(help="Label to add")],
) -> None:
    """Add a label to an issue."""
    from ao._internal.commands.label import label_add

    label_add(get_ctx(), issue_id, label)


@label_app.command("rm")
def label_rm_cmd(
    issue_id: Annotated[str, typer.Argument(help="Issue ID")],
    label: Annotated[str, typer.Argument(help="Label to remove")],
) -> None:
    """Remove a label from an issue."""
    from ao._internal.commands.label import label_rm

    label_rm(get_ctx(), issue_id, label)


@label_app.command("ls")
def label_ls_cmd(
    issue_id: Annotated[str, typer.Argument(help="Issue ID")],
) -> None:
    """List labels on an issue."""
    from ao._internal.commands.label import label_ls

    label_ls(get_ctx(), issue_id)


# ── state subcommands ─────────────────────────────────────────────────────────

state_app = typer.Typer(help="Operational state commands (dimension:value labels)")
app.add_typer(state_app, name="state")


@state_app.command("get")
def state_get_cmd(
    issue_id: Annotated[str, typer.Argument(help="Issue ID")],
    dimension: Annotated[str, typer.Argument(help="State dimension (e.g. review, risk)")],
) -> None:
    """Get an operational state dimension value."""
    from ao._internal.commands.label import state_get

    state_get(get_ctx(), issue_id, dimension)


@state_app.command("set")
def state_set_cmd(
    issue_id: Annotated[str, typer.Argument(help="Issue ID")],
    dimension_value: Annotated[str, typer.Argument(help="dimension:value or dimension=value")],
) -> None:
    """Set an operational state dimension (replaces existing value for dimension)."""
    from ao._internal.commands.label import state_set

    state_set(get_ctx(), issue_id, dimension_value)


# ── lock status ──────────────────────────────────────────────────────────────

lock_app = typer.Typer(help="Lock management commands")
app.add_typer(lock_app, name="lock")


# ── worker subcommands ───────────────────────────────────────────────────────

worker_app = typer.Typer(help="Worker registry commands")
app.add_typer(worker_app, name="worker")

worktree_app = typer.Typer(help="Git worktree management commands")
app.add_typer(worktree_app, name="worktree")
app.add_typer(worktree_app, name="wt")


@lock_app.command("status")
def lock_status_cmd() -> None:
    """Show lock status for events.jsonl (debugging)."""
    from ao._internal.lock import status as lock_status

    ctx = get_ctx()
    info = lock_status(ctx.events_path)
    emit_success(ctx, info)


@lock_app.command("release")
def lock_release_cmd() -> None:
    """Force-release a stale lock (use with caution)."""
    from ao._internal.lock import release as lock_release
    from ao._internal.lock import status as lock_status

    ctx = get_ctx()
    info = lock_status(ctx.events_path)
    if info.get("locked") and not info.get("stale"):
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, "Lock is held by an active process")
        return
    lock_release(ctx.events_path)
    emit_success(ctx, {"released": True, "path": str(ctx.events_path)})


# ── worker commands ──────────────────────────────────────────────────────────


@worker_app.command("ls")
def worker_ls_cmd() -> None:
    """List all registered workers."""
    from ao._internal.commands.worker import worker_ls

    worker_ls(get_ctx())


@worker_app.command("add")
def worker_add_cmd(
    name: Annotated[str, typer.Argument(help="Worker name (lowercase, alphanumeric + hyphens)")],
    engine: Annotated[str, typer.Option("--engine", help="Engine: claude|copilot|opencode")],
    label: Annotated[str, typer.Option("--label", help="Optional display label")] = "",
    model: Annotated[
        str, typer.Option("--model", help="Default model (e.g. claude-sonnet-4)")
    ] = "",
    context: Annotated[
        str, typer.Option("--context", help="Path to context/instructions file")
    ] = "",
    instructions: Annotated[
        str, typer.Option("--instructions", help="Inline instructions text")
    ] = "",
) -> None:
    """Register a new worker."""
    from ao._internal.commands.worker import worker_add

    worker_add(
        get_ctx(),
        name,
        engine,
        label,
        model=model,
        context=context,
        instructions=instructions,
    )


@worker_app.command("show")
def worker_show_cmd(
    name: Annotated[str, typer.Argument(help="Worker name to show")],
) -> None:
    """Show details of a registered worker."""
    from ao._internal.commands.worker import worker_show

    worker_show(get_ctx(), name)


@worker_app.command("update")
def worker_update_cmd(
    name: Annotated[str, typer.Argument(help="Worker name to update")],
    label: Annotated[str | None, typer.Option("--label", help="Display label")] = None,
    model: Annotated[str | None, typer.Option("--model", help="Default model")] = None,
    context: Annotated[str | None, typer.Option("--context", help="Context file path")] = None,
    instructions: Annotated[
        str | None, typer.Option("--instructions", help="Inline instructions")
    ] = None,
    engine: Annotated[str | None, typer.Option("--engine", help="Engine type")] = None,
) -> None:
    """Update fields of a registered worker."""
    from ao._internal.commands.worker import worker_update

    worker_update(
        get_ctx(),
        name,
        label=label,
        model=model,
        context=context,
        instructions=instructions,
        engine=engine,
    )


@worker_app.command("rm")
def worker_rm_cmd(
    name: Annotated[str, typer.Argument(help="Worker name to remove")],
) -> None:
    """Remove a registered worker."""
    from ao._internal.commands.worker import worker_rm

    worker_rm(get_ctx(), name)


@worker_app.command("assign")
def worker_assign_cmd(
    issue_id: Annotated[str, typer.Argument(help="Issue ID to assign")],
    worker: Annotated[str, typer.Option("--worker", help="Worker name to assign")],
) -> None:
    """Assign a worker to an issue (sets owner field)."""
    from ao._internal.commands.worker import worker_assign

    worker_assign(get_ctx(), issue_id, worker)


# ── worktree commands ─────────────────────────────────────────────────────────


@worktree_app.command("add")
def worktree_add_cmd(
    epic: Annotated[str, typer.Option("--epic", "-e", help="Filter issues by epic name")] = "",
    open_with: Annotated[
        str,
        typer.Option(
            "--open", "-o", help="Open in editor/agent (editor, copilot, opencode, claude)"
        ),
    ] = "",
    prompt: Annotated[
        str, typer.Option("--prompt", "-p", help="Prompt text or file path (agent CLIs only)")
    ] = "",
    branch: Annotated[
        str, typer.Option("--branch", "-b", help="Branch name (auto-derived from epic if omitted)")
    ] = "",
) -> None:
    """Create an epic-scoped worktree with optional editor launch."""
    from ao._internal.commands.worktree import worktree_add

    worktree_add(get_ctx(), epic=epic, open_with=open_with, prompt=prompt, branch=branch)


@worktree_app.command("ls")
def worktree_ls_cmd() -> None:
    """List existing git worktrees."""
    from ao._internal.commands.worktree import worktree_ls

    worktree_ls(get_ctx())


@worktree_app.command("rm")
def worktree_rm_cmd(
    path: Annotated[str, typer.Argument(help="Worktree path to remove")],
) -> None:
    """Remove a git worktree."""
    from ao._internal.commands.worktree import worktree_rm

    worktree_rm(get_ctx(), path)


@worktree_app.command("merge")
def worktree_merge_cmd(
    path: Annotated[
        str, typer.Argument(help="Worktree path to merge (default: all managed worktrees)")
    ] = "",
) -> None:
    """Merge worktree(s) back to source branch."""
    from ao._internal.commands.worktree import worktree_merge

    worktree_merge(get_ctx(), worktree_path=path)


@app.command("web")
def web_command(
    host: Annotated[str, typer.Option("--host", help="Bind host")] = "127.0.0.1",
    port: Annotated[int, typer.Option("--port", help="Bind port")] = 8042,
    open_browser: Annotated[bool, typer.Option("--open/--no-open", help="Open in browser")] = True,
) -> None:
    """Launch the Kanban web UI."""
    ctx = get_ctx()
    if ctx.sandbox:
        console.print(
            "[yellow]Sandbox mode:[/yellow] web server disabled (no background processes)"
        )
        raise typer.Exit(0)

    try:
        import uvicorn
    except ImportError:
        console.print("[red]Error:[/red] Web UI requires extras: pip install agent-ops-cli[web]")
        raise typer.Exit(1)  # noqa: B904

    from ao.store import AOPaths

    ctx = get_ctx()
    paths = AOPaths(ctx.root)

    from ao.web.app import build_app

    application = build_app(paths)

    if host not in ("127.0.0.1", "localhost", "::1"):
        console.print(
            f"[yellow]Warning:[/yellow] Binding to [bold]{host}[/bold] exposes the "
            "web UI to the network. No authentication is configured."
        )

    if open_browser:
        import threading
        import webbrowser

        def _open() -> None:
            import time

            time.sleep(1.0)
            webbrowser.open(f"http://{host}:{port}")

        threading.Thread(target=_open, daemon=True).start()

    uvicorn.run(application, host=host, port=port, log_level="info")


def main() -> None:
    """Entry point for the AO CLI."""
    app()
