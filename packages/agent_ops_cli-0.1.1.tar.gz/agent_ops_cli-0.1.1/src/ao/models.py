"""AO data models — msgspec Structs for events and issues."""

from __future__ import annotations

from enum import StrEnum
from typing import Any

import msgspec

# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class IssueType(StrEnum):
    BUG = "bug"
    FEAT = "feat"
    CHORE = "chore"
    ENH = "enh"
    SEC = "sec"
    PERF = "perf"
    DOCS = "docs"
    TEST = "test"
    REFAC = "refac"
    PLAN = "plan"


class Status(StrEnum):
    TODO = "todo"
    IN_PROGRESS = "in_progress"
    REVIEW = "review"
    PULL_REQUEST = "pull_request"
    BLOCKED = "blocked"
    DONE = "done"
    CANCELLED = "cancelled"
    DROPPED = "dropped"


TERMINAL_STATUSES: frozenset[Status] = frozenset({Status.DONE, Status.CANCELLED, Status.DROPPED})

# Statuses shown as board columns in the web UI (excludes blocked/cancelled/dropped)
BOARD_STATUSES: tuple[str, ...] = (
    Status.TODO,
    Status.IN_PROGRESS,
    Status.REVIEW,
    Status.PULL_REQUEST,
    Status.DONE,
)


class Priority(StrEnum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    BACKLOG = "backlog"


class Confidence(StrEnum):
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"


class Op(StrEnum):
    CREATE = "create"
    SET = "set"
    SCOPE_SET = "scope_set"
    REQUIREMENTS_SET = "requirements_set"
    ACCEPTANCE_SET = "acceptance_set"
    ACCEPTANCE_ADD = "acceptance_add"
    ACCEPTANCE_RM = "acceptance_rm"
    ACCEPTANCE_CHECK = "acceptance_check"
    DEPS_SET = "deps_set"
    DEPS_ADD = "deps_add"
    DEPS_RM = "deps_rm"
    REF_SET = "ref_set"
    FILES_ADD = "files_add"
    LOG_APPEND = "log_append"
    CLOSE = "close"
    REOPEN = "reopen"
    TIME_LOG = "time_log"
    LABEL_ADD = "label_add"
    LABEL_RM = "label_rm"
    LINK_ADD = "link_add"
    LINK_RM = "link_rm"


# ---------------------------------------------------------------------------
# Nested structs
# ---------------------------------------------------------------------------


class Scope(msgspec.Struct):
    files_to_change: list[str] = []
    files_must_not_change: list[str] = []


class Dependencies(msgspec.Struct):
    depends_on: list[str] = []
    blocks: list[str] = []


class References(msgspec.Struct):
    spec_file: str = ""
    files: list[str] = []


class LogEntry(msgspec.Struct):
    date: str
    message: str


class AcceptanceCriterion(msgspec.Struct):
    description: str
    done: bool = False


# ---------------------------------------------------------------------------
# Event (append-only log line)
# ---------------------------------------------------------------------------


class Event(msgspec.Struct):
    event_id: str
    issue_id: str
    op: Op
    timestamp: str
    payload: dict[str, Any] = {}


# ---------------------------------------------------------------------------
# Issue (active snapshot line)
# ---------------------------------------------------------------------------


class Issue(msgspec.Struct):
    id: str
    title: str
    type: IssueType = IssueType.FEAT
    status: Status = Status.TODO
    priority: Priority = Priority.MEDIUM
    epic: str = ""
    owner: str = "agent"
    confidence: Confidence = Confidence.NORMAL
    created: str = ""
    updated: str = ""
    scope: Scope = msgspec.field(default_factory=Scope)
    requirements: list[str] = []
    acceptance_criteria: list[AcceptanceCriterion] = []
    dependencies: Dependencies = msgspec.field(default_factory=Dependencies)
    references: References = msgspec.field(default_factory=References)
    notes: str = ""
    external_ref: str = ""
    labels: list[str] = []
    links: dict[str, list[str]] = {}
    log: list[LogEntry] = []
    started_at: str = ""
    completed_at: str = ""
    duration_minutes: int = 0
