"""AO query — filter, group, and summarize active issues."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path

from rich.console import Console
from rich.table import Table

from ao._internal.filters import parse_query_tokens
from ao._internal.io import iter_jsonl_bytes
from ao.codec import Codec
from ao.models import Issue

console = Console()


@dataclass
class Filters:
    """Typed filter specification for issue queries."""

    status: set[str] = field(default_factory=set)
    priority: set[str] = field(default_factory=set)
    type: set[str] = field(default_factory=set)
    epic: str | None = None
    owner: str | None = None
    confidence: set[str] = field(default_factory=set)
    text: str | None = None


def parse_filters(tokens: list[str]) -> Filters:
    """Parse CLI query tokens into a typed ``Filters`` object."""
    raw = parse_query_tokens(tokens)
    return Filters(
        status={raw["status"]} if "status" in raw else set(),
        priority={raw["priority"]} if "priority" in raw else set(),
        type={raw["type"]} if "type" in raw else set(),
        epic=raw.get("epic"),
        owner=raw.get("owner"),
        confidence={raw["confidence"]} if "confidence" in raw else set(),
        text=raw.get("text"),
    )


# ── grouping helpers ──────────────────────────────────────────────────────────


def group_by_status(issues: list[Issue]) -> dict[str, list[Issue]]:
    """Group issues by their status value."""
    groups: dict[str, list[Issue]] = defaultdict(list)
    for issue in issues:
        groups[issue.status.value].append(issue)
    return dict(groups)


def group_by_epic(issues: list[Issue]) -> dict[str, list[Issue]]:
    """Group issues by their epic value."""
    groups: dict[str, list[Issue]] = defaultdict(list)
    for issue in issues:
        groups[issue.epic or "(none)"].append(issue)
    return dict(groups)


def group_by_priority(issues: list[Issue]) -> dict[str, list[Issue]]:
    """Group issues by their priority value."""
    groups: dict[str, list[Issue]] = defaultdict(list)
    for issue in issues:
        groups[issue.priority.value].append(issue)
    return dict(groups)


# ── core query ────────────────────────────────────────────────────────────────


def query_active(
    active_path: Path,
    codec: Codec,
    *,
    status: str | None = None,
    priority: str | None = None,
    type_: str | None = None,
    epic: str | None = None,
    owner: str | None = None,
    confidence: str | None = None,
) -> list[Issue]:
    """Load and filter active issues."""
    issues: list[Issue] = []
    for line in iter_jsonl_bytes(active_path):
        if b'"_meta"' in line:
            continue
        try:
            issue = codec.decode_issue(line)
        except Exception:  # noqa: S112
            continue
        if _matches(issue, status, priority, type_, epic, owner, confidence):
            issues.append(issue)
    return issues


def _matches(
    issue: Issue,
    status: str | None,
    priority: str | None,
    type_: str | None,
    epic: str | None,
    owner: str | None,
    confidence: str | None,
) -> bool:
    """Check if issue matches all non-None filters."""
    if status and issue.status != status:
        return False
    if priority and issue.priority != priority:
        return False
    if type_ and issue.type != type_:
        return False
    if epic and issue.epic != epic:
        return False
    if owner and issue.owner != owner:
        return False
    if confidence and issue.confidence != confidence:
        return False
    return True


def print_issues(issues: list[Issue]) -> None:
    """Print issues in a rich table."""
    table = Table(title=f"Active Issues ({len(issues)})")
    table.add_column("ID", style="bold")
    table.add_column("Title")
    table.add_column("Status")
    table.add_column("Priority")
    table.add_column("Type")
    table.add_column("Epic")
    table.add_column("Owner")

    for iss in issues:
        table.add_row(iss.id, iss.title, iss.status, iss.priority, iss.type, iss.epic, iss.owner)

    console.print(table)
