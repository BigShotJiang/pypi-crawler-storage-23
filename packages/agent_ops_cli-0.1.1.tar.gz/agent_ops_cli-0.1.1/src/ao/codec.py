"""AO codecs — orjson and msgspec backends for JSONL encoding/decoding."""

from __future__ import annotations

from typing import Protocol, TypeVar, runtime_checkable

import msgspec
import orjson

from ao.models import Event, Issue

T = TypeVar("T")


@runtime_checkable
class Codec(Protocol):
    """Protocol for JSON codec backends."""

    def decode_event(self, data: bytes) -> Event: ...

    def decode_issue(self, data: bytes) -> Issue: ...

    def encode_event(self, event: Event) -> bytes: ...

    def encode_issue(self, issue: Issue) -> bytes: ...


class MsgspecCodec:
    """Fast typed codec using compiled msgspec decoders."""

    def __init__(self) -> None:
        self._event_decoder = msgspec.json.Decoder(Event)
        self._issue_decoder = msgspec.json.Decoder(Issue)
        self._encoder = msgspec.json.Encoder()

    def decode_event(self, data: bytes) -> Event:
        return self._event_decoder.decode(data)

    def decode_issue(self, data: bytes) -> Issue:
        return self._issue_decoder.decode(data)

    def encode_event(self, event: Event) -> bytes:
        return self._encoder.encode(event)

    def encode_issue(self, issue: Issue) -> bytes:
        return self._encoder.encode(issue)


class OrjsonCodec:
    """Fast dict-based codec using orjson with sorted keys."""

    def __init__(self) -> None:
        self._event_decoder = msgspec.json.Decoder(Event)
        self._issue_decoder = msgspec.json.Decoder(Issue)

    def decode_event(self, data: bytes) -> Event:
        return self._event_decoder.decode(data)

    def decode_issue(self, data: bytes) -> Issue:
        return self._issue_decoder.decode(data)

    def encode_event(self, event: Event) -> bytes:
        return orjson.dumps(
            msgspec.to_builtins(event),
            option=orjson.OPT_SORT_KEYS,
        )

    def encode_issue(self, issue: Issue) -> bytes:
        return orjson.dumps(
            msgspec.to_builtins(issue),
            option=orjson.OPT_SORT_KEYS,
        )


def get_codec(name: str) -> Codec:
    """Get a codec by name ('orjson' or 'msgspec')."""
    codecs: dict[str, type[Codec]] = {
        "msgspec": MsgspecCodec,
        "orjson": OrjsonCodec,
    }
    if name not in codecs:
        msg = f"Unknown codec: {name!r}. Choose from: {', '.join(codecs)}"
        raise ValueError(msg)
    return codecs[name]()
