"""AO api — programmatic client for reading and writing issues."""

from __future__ import annotations

import builtins
import hashlib
import re
from collections import defaultdict
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import msgspec
import orjson

from ao.codec import Codec, get_codec
from ao.errors import NotFoundError, ValidationError
from ao.models import TERMINAL_STATUSES, Event, Issue, IssueType, Op, Priority, Status
from ao.store import AOPaths, discover_root
from ao.store.io import append_jsonl, iter_jsonl

# Priority sort order (lower index = higher priority).
_PRIORITY_ORDER: dict[str, int] = {
    "critical": 0,
    "high": 1,
    "medium": 2,
    "low": 3,
    "backlog": 4,
}

_CREATE_FIELDS = frozenset(
    {
        "title",
        "type",
        "status",
        "priority",
        "epic",
        "owner",
        "confidence",
    }
)
_PATCH_TOP_FIELDS = frozenset({"set", "append"})


def _build_create_payload(issue: dict[str, Any], actor: str) -> dict[str, Any]:
    return {
        "title": issue.get("title", ""),
        "type": issue.get("type", "feat"),
        "status": issue.get("status", "todo"),
        "priority": issue.get("priority", "medium"),
        "epic": issue.get("epic", ""),
        "owner": issue.get("owner", actor),
        "confidence": issue.get("confidence", "normal"),
    }


def _is_issue_ready(issue: Issue, all_issues: dict[str, Issue]) -> bool:
    """Check if issue is ready to work (not blocked, not terminal, deps satisfied)."""
    if issue.status in TERMINAL_STATUSES:
        return False
    if issue.status == Status.BLOCKED:
        return False
    for dep_id in issue.dependencies.depends_on:
        dep = all_issues.get(dep_id)
        if dep is not None and dep.status not in TERMINAL_STATUSES:
            return False
    return True


class AOClient:
    """Primary programmatic interface for AO workspaces."""

    __slots__ = ("_codec", "_paths", "_strict", "_typed")

    def __init__(
        self,
        paths: AOPaths,
        codec: str = "orjson",
        *,
        typed: bool = False,
        strict: bool = False,
    ) -> None:
        self._paths = paths
        self._codec: Codec = get_codec(codec)
        self._typed = typed
        self._strict = strict

    @classmethod
    def discover(
        cls,
        start: Path | None = None,
        *,
        codec: str = "orjson",
        typed: bool = False,
        strict: bool = False,
    ) -> AOClient:
        """Auto-discover workspace and return a configured client."""
        paths = discover_root(start)
        return cls(paths, codec, typed=typed, strict=strict)

    # ── helpers ───────────────────────────────────────────────────────────

    @property
    def paths(self) -> AOPaths:
        """Return the resolved workspace paths."""
        return self._paths

    def _to_output(self, issue: Issue) -> dict[str, Any] | Issue:
        """Convert issue to the configured output type."""
        if self._typed:
            return issue
        result: dict[str, Any] = msgspec.to_builtins(issue)
        return result

    def _load_active(self) -> builtins.list[Issue]:
        """Load all active issues from active.jsonl."""
        issues: builtins.list[Issue] = []
        if not self._paths.active_path.exists():
            return issues
        for line in iter_jsonl(self._paths.active_path):
            if b'"_meta"' in line:
                continue
            try:
                issues.append(self._codec.decode_issue(line))
            except Exception:  # noqa: BLE001, S112
                continue
        return issues

    def _match(self, issue: Issue, filters: dict[str, Any] | None) -> bool:
        """Check if an issue matches the given filters dict."""
        if not filters:
            return True
        for key, values in filters.items():
            if not isinstance(values, builtins.list):
                values = [values]  # noqa: PLW2901
            attr = getattr(issue, key, None)
            if attr is None:
                return False
            if str(attr) not in [str(v) for v in values]:
                return False
        return True

    # ── read operations ───────────────────────────────────────────────────

    def get(self, issue_id: str) -> dict[str, Any] | Issue:
        """Get a single issue by ID. Raises ``NotFoundError`` if missing."""
        issue_id = self._resolve_id(issue_id)
        for issue in self._load_active():
            if issue.id == issue_id:
                return self._to_output(issue)
        msg = f"Issue not found: {issue_id}"
        raise NotFoundError(msg)

    def list(
        self,
        filters: dict[str, Any] | None = None,
        *,
        view: str = "full",
        limit: int | None = None,
        sort: str | None = None,
    ) -> builtins.list[dict[str, Any]] | builtins.list[Issue]:
        """List active issues with optional filters, sorting, and limits."""
        issues = [i for i in self._load_active() if self._match(i, filters)]
        issues = self._sort(issues, sort)
        if limit is not None:
            issues = issues[:limit]
        return self._format_list(issues, view)

    def counts(
        self,
        filters: dict[str, Any] | None = None,
    ) -> dict[str, int]:  # noqa: A003
        """Aggregate active issue counts by status."""
        issues = [i for i in self._load_active() if self._match(i, filters)]
        agg: dict[str, int] = defaultdict(int)
        for issue in issues:
            agg[issue.status.value] += 1
        return dict(agg)

    def epics(self) -> builtins.list[dict[str, Any]]:
        """Return epic summary: name, count, by_status breakdown."""
        issues = self._load_active()
        groups: dict[str, list[Issue]] = defaultdict(list)
        for issue in issues:
            groups[issue.epic or "(none)"].append(issue)
        result: list[dict[str, Any]] = []
        for name in sorted(groups):
            items = groups[name]
            by_status: dict[str, int] = defaultdict(int)
            for item in items:
                by_status[item.status.value] += 1
            result.append(
                {
                    "name": name,
                    "count": len(items),
                    "by_status": dict(by_status),
                }
            )
        return result

    def graph(self, epic: str | None = None) -> dict[str, Any]:
        """Build dependency graph for active issues."""
        from ao._internal.graph import build_adjacency, detect_cycle, generate_mermaid

        issues = self._load_active()
        if epic:
            issues = [i for i in issues if i.epic == epic]
        dep_map: dict[str, list[str]] = {}
        for issue in issues:
            dep_map[issue.id] = list(issue.dependencies.depends_on)
        adj = build_adjacency(dep_map)
        cycle = detect_cycle(adj)
        mermaid = generate_mermaid(adj)
        nodes = [{"id": n} for n in sorted(adj)]
        edges = [
            {"from": src, "to": tgt} for src, targets in sorted(adj.items()) for tgt in targets
        ]
        return {
            "nodes": nodes,
            "edges": edges,
            "has_cycle": cycle is not None,
            "mermaid": mermaid,
        }

    # ── sorting ───────────────────────────────────────────────────────────

    def _sort(self, issues: builtins.list[Issue], sort: str | None) -> builtins.list[Issue]:
        """Sort issues by the given field."""
        if sort == "priority":
            return sorted(issues, key=lambda i: _PRIORITY_ORDER.get(i.priority.value, 99))
        if sort == "updated":
            return sorted(issues, key=lambda i: i.updated, reverse=True)
        if sort == "created":
            return sorted(issues, key=lambda i: i.created, reverse=True)
        if sort == "id":
            return sorted(issues, key=lambda i: i.id)
        return issues

    def _format_list(
        self,
        issues: builtins.list[Issue],
        view: str,
    ) -> builtins.list[dict[str, Any]] | builtins.list[Issue]:
        """Format the issue list according to the requested view."""
        if self._typed:
            return issues
        if view == "ids":
            return [{"id": i.id} for i in issues]
        if view == "summary":
            return [
                {
                    "id": i.id,
                    "title": i.title,
                    "type": i.type.value,
                    "status": i.status.value,
                    "priority": i.priority.value,
                    "epic": i.epic,
                    "owner": i.owner,
                }
                for i in issues
            ]
        # full view
        return [msgspec.to_builtins(i) for i in issues]

    # ── write helpers ─────────────────────────────────────────────────────

    def _now_iso(self) -> str:
        return datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")

    def _next_id(self) -> int:
        """Derive next monotonic number from events.jsonl (max event_id + 1).

        Scans events.jsonl for the max N in evt-NNNNNNNN event_ids.  Migrates
        .counter on first run: reads file value as floor, then deletes it.
        """
        max_n = 0
        events_path = self._paths.events_path
        if events_path.exists():
            for raw in iter_jsonl(events_path):
                if b"evt-" in raw:
                    start = raw.find(b'"evt-')
                    if start != -1:
                        end = raw.find(b'"', start + 1)
                        if end != -1:
                            token = raw[start + 1 : end]
                            if token.startswith(b"evt-") and token[4:].isdigit():
                                n = int(token[4:])
                                if n > max_n:
                                    max_n = n
        # Migration: consume legacy .counter if present
        counter_path = events_path.parent / ".counter"
        if counter_path.exists():
            text = counter_path.read_text().strip()
            if text.isdigit():
                max_n = max(max_n, int(text))
            counter_path.unlink()
        return max_n + 1

    def _make_issue_id(self, number: int, issue_type: str) -> str:
        h = hashlib.md5(str(number).encode(), usedforsecurity=False).hexdigest()[:6]
        return f"{issue_type.upper()}-{number:04d}@{h}"

    def _make_event_id(self, number: int) -> str:
        return f"evt-{number:08d}"

    def _append_event(self, event: Event) -> None:
        self._paths.events_path.parent.mkdir(parents=True, exist_ok=True)
        append_jsonl(self._paths.events_path, self._codec.encode_event(event))

    def _do_rebuild(self) -> None:
        from ao._internal.rebuild import rebuild as _rebuild

        _rebuild(self._paths.events_path, self._paths.active_path, self._codec, show_progress=False)

    def _maybe_rebuild(self, rebuild: bool | str) -> None:
        if rebuild is True or rebuild == "auto":
            self._do_rebuild()

    def _validate_enum(self, field: str, value: str, enum_cls: type[Any]) -> None:
        valid = {e.value for e in enum_cls}
        if value not in valid:
            msg = f"Invalid {field}: {value!r}. Valid: {', '.join(sorted(valid))}"
            raise ValidationError(msg)

    def _resolve_id(self, issue_id: str) -> str:
        """Resolve TYPE-NNNN short form to full TYPE-NNNN@hhhhhh.

        Returns issue_id unchanged if it already contains '@'.
        Raises NotFoundError if short form given but no matching active issue.
        """
        if "@" in issue_id:
            return issue_id
        if not re.match(r"^[A-Z]+-\d{1,4}$", issue_id.upper()):
            return issue_id
        prefix = issue_id.upper()
        for issue in self._load_active():
            if issue.id.split("@")[0] == prefix:
                return issue.id
        raise NotFoundError(f"No active issue matching {issue_id!r}")

    def _get_issue(self, issue_id: str) -> Issue:
        """Load a typed Issue from active.jsonl or raise NotFoundError."""
        issue_id = self._resolve_id(issue_id)
        iss = next((i for i in self._load_active() if i.id == issue_id), None)
        if iss is None:
            raise NotFoundError(f"Issue not found: {issue_id}")
        return iss

    def _emit(self, issue_id: str, op: Op, payload: dict[str, Any]) -> str:
        """Append one event and return its event_id."""
        eid = self._make_event_id(self._next_id())
        event = Event(
            event_id=eid, issue_id=issue_id, op=op, timestamp=self._now_iso(), payload=payload
        )
        self._append_event(event)
        return eid

    # ── write operations ──────────────────────────────────────────────────

    def create(
        self,
        issue: dict[str, Any],
        *,
        actor: str = "agent",
        rebuild: bool | str = "auto",
    ) -> dict[str, Any]:
        """Create a new issue. Returns result dict with issue_id."""
        title = issue.get("title", "")
        if not title:
            raise ValidationError("title is required")
        itype = issue.get("type", "feat")
        if self._strict:
            self._validate_enum("type", itype, IssueType)
            if "priority" in issue:
                self._validate_enum("priority", issue["priority"], Priority)
            if "status" in issue:
                self._validate_enum("status", issue["status"], Status)

        num = self._next_id()
        issue_id = self._make_issue_id(num, itype)
        event_id = self._make_event_id(num)
        ts = self._now_iso()

        payload: dict[str, Any] = {
            "title": title,
            "type": itype,
            "status": issue.get("status", "todo"),
            "priority": issue.get("priority", "medium"),
            "epic": issue.get("epic", ""),
            "owner": issue.get("owner", actor),
            "confidence": issue.get("confidence", "normal"),
        }
        event = Event(
            event_id=event_id, issue_id=issue_id, op=Op.CREATE, timestamp=ts, payload=payload
        )
        self._append_event(event)
        self._maybe_rebuild(rebuild)
        return {"issue_id": issue_id, "event_id": event_id, "title": title}

    def patch(
        self,
        issue_id: str,
        patch: dict[str, Any],
        *,
        actor: str = "agent",
        rebuild: bool | str = "auto",
    ) -> dict[str, Any]:
        """Patch an existing issue. Returns result dict."""
        issue_id = self._resolve_id(issue_id)
        set_fields = patch.get("set", {})
        if self._strict and "status" in set_fields:
            self._validate_enum("status", set_fields["status"], Status)
        if self._strict and "priority" in set_fields:
            self._validate_enum("priority", set_fields["priority"], Priority)

        events_out: builtins.list[str] = []
        ts = self._now_iso()

        if set_fields:
            num = self._next_id()
            eid = self._make_event_id(num)
            event = Event(
                event_id=eid, issue_id=issue_id, op=Op.SET, timestamp=ts, payload=set_fields
            )
            self._append_event(event)
            events_out.append(eid)

        for entry in patch.get("append", {}).get("log", []):
            num = self._next_id()
            eid = self._make_event_id(num)
            payload: dict[str, Any] = {
                "date": entry.get("ts", ts),
                "message": entry.get("text", ""),
            }
            event = Event(
                event_id=eid, issue_id=issue_id, op=Op.LOG_APPEND, timestamp=ts, payload=payload
            )
            self._append_event(event)
            events_out.append(eid)

        self._maybe_rebuild(rebuild)
        return {"issue_id": issue_id, "events": events_out}

    def close(
        self,
        issue_id: str,
        log: str = "",
        *,
        status: str = "done",
        actor: str = "agent",
        rebuild: bool | str = "auto",
    ) -> dict[str, Any]:
        """Close an issue with an optional log message."""
        issue_id = self._resolve_id(issue_id)
        if status not in {s.value for s in TERMINAL_STATUSES}:
            msg = f"Close status must be terminal, got: {status!r}"
            raise ValidationError(msg)

        events_out: builtins.list[str] = []
        ts = self._now_iso()

        if log:
            num = self._next_id()
            eid = self._make_event_id(num)
            payload: dict[str, Any] = {"date": ts, "message": log}
            event = Event(
                event_id=eid, issue_id=issue_id, op=Op.LOG_APPEND, timestamp=ts, payload=payload
            )
            self._append_event(event)
            events_out.append(eid)

        num = self._next_id()
        eid = self._make_event_id(num)
        event = Event(
            event_id=eid, issue_id=issue_id, op=Op.CLOSE, timestamp=ts, payload={"status": status}
        )
        self._append_event(event)
        events_out.append(eid)

        self._maybe_rebuild(rebuild)
        return {"issue_id": issue_id, "events": events_out, "closed": True}

    def reopen(
        self,
        issue_id: str,
        log: str = "",
        *,
        status: str = "todo",
        actor: str = "agent",
        rebuild: bool | str = "auto",
    ) -> dict[str, Any]:
        """Reopen a previously closed issue."""
        issue_id = self._resolve_id(issue_id)
        events_out: builtins.list[str] = []
        ts = self._now_iso()

        if log:
            num = self._next_id()
            eid = self._make_event_id(num)
            payload: dict[str, Any] = {"date": ts, "message": log}
            event = Event(
                event_id=eid, issue_id=issue_id, op=Op.LOG_APPEND, timestamp=ts, payload=payload
            )
            self._append_event(event)
            events_out.append(eid)

        num = self._next_id()
        eid = self._make_event_id(num)
        event = Event(
            event_id=eid, issue_id=issue_id, op=Op.REOPEN, timestamp=ts, payload={"status": status}
        )
        self._append_event(event)
        events_out.append(eid)

        self._maybe_rebuild(rebuild)
        return {"issue_id": issue_id, "events": events_out, "reopened": True}

    def log_append(
        self,
        issue_id: str,
        text: str,
        *,
        ts: str | None = None,
        actor: str = "agent",
    ) -> dict[str, Any]:
        """Append a log entry to an issue."""
        issue_id = self._resolve_id(issue_id)
        now = ts or self._now_iso()
        num = self._next_id()
        eid = self._make_event_id(num)
        payload: dict[str, Any] = {"date": now, "message": text}
        event = Event(
            event_id=eid, issue_id=issue_id, op=Op.LOG_APPEND, timestamp=now, payload=payload
        )
        self._append_event(event)
        self._do_rebuild()
        return {"issue_id": issue_id, "event_id": eid}

    def append_event(
        self,
        event_dict: dict[str, Any],
        *,
        rebuild: bool | str = "auto",
    ) -> dict[str, Any]:
        """Append a raw event dict to the event log."""
        try:
            event = Event(
                event_id=event_dict["event_id"],
                issue_id=event_dict["issue_id"],
                op=Op(event_dict["op"]),
                timestamp=event_dict["timestamp"],
                payload=event_dict.get("payload", {}),
            )
        except (KeyError, ValueError) as exc:
            msg = f"Invalid event: {exc}"
            raise ValidationError(msg) from exc
        self._append_event(event)
        self._maybe_rebuild(rebuild)
        return {"event_id": event.event_id, "issue_id": event.issue_id}

    def rebuild_snapshot(self) -> dict[str, Any]:
        """Force rebuild active.jsonl from events. Returns stats."""
        from ao.store.rebuild import rebuild as store_rebuild

        stats = store_rebuild(
            self._paths.events_path,
            self._paths.active_path,
            self._codec,
            show_progress=False,
        )
        return {
            "event_count": stats.event_count,
            "active_count": stats.active_count,
        }

    # ── acceptance criteria ───────────────────────────────────────────────

    def ac_add(
        self, issue_id: str, description: str, *, rebuild: bool | str = "auto"
    ) -> dict[str, Any]:
        """Add an acceptance criterion to an issue."""
        eid = self._emit(issue_id, Op.ACCEPTANCE_ADD, {"description": description})
        self._maybe_rebuild(rebuild)
        return {"issue_id": issue_id, "event_id": eid}

    def ac_remove(
        self, issue_id: str, index: int, *, rebuild: bool | str = "auto"
    ) -> dict[str, Any]:
        """Remove AC at 0-based index (validates issue and index exist)."""
        iss = self._get_issue(issue_id)
        if not (0 <= index < len(iss.acceptance_criteria)):
            raise ValidationError(
                f"AC index {index} out of range (0..{len(iss.acceptance_criteria) - 1})"
            )
        eid = self._emit(issue_id, Op.ACCEPTANCE_RM, {"index": index})
        self._maybe_rebuild(rebuild)
        return {"issue_id": issue_id, "event_id": eid}

    def ac_update(
        self, issue_id: str, index: int, description: str, *, rebuild: bool | str = "auto"
    ) -> dict[str, Any]:
        """Update AC text at 0-based index via acceptance_set."""
        iss = self._get_issue(issue_id)
        if not (0 <= index < len(iss.acceptance_criteria)):
            raise ValidationError(
                f"AC index {index} out of range (0..{len(iss.acceptance_criteria) - 1})"
            )
        criteria = [
            {"description": (description if i == index else ac.description), "done": ac.done}
            for i, ac in enumerate(iss.acceptance_criteria)
        ]
        eid = self._emit(issue_id, Op.ACCEPTANCE_SET, {"criteria": criteria})
        self._maybe_rebuild(rebuild)
        return {"issue_id": issue_id, "event_id": eid}

    def ac_check(
        self, issue_id: str, index: int, *, done: bool, rebuild: bool | str = "auto"
    ) -> dict[str, Any]:
        """Check or uncheck AC at 0-based index."""
        iss = self._get_issue(issue_id)
        if not (0 <= index < len(iss.acceptance_criteria)):
            raise ValidationError(
                f"AC index {index} out of range (0..{len(iss.acceptance_criteria) - 1})"
            )
        eid = self._emit(issue_id, Op.ACCEPTANCE_CHECK, {"index": index, "done": done})
        self._maybe_rebuild(rebuild)
        return {"issue_id": issue_id, "event_id": eid}

    # ── dependencies ──────────────────────────────────────────────────────

    def deps_add(
        self, issue_id: str, link_type: str, target_id: str, *, rebuild: bool | str = "auto"
    ) -> dict[str, Any]:
        """Add a dependency link (depends_on or blocks)."""
        if link_type not in ("depends_on", "blocks"):
            msg = f"link_type must be 'depends_on' or 'blocks', got: {link_type!r}"
            raise ValidationError(msg)
        eid = self._emit(issue_id, Op.DEPS_ADD, {link_type: [target_id]})
        self._maybe_rebuild(rebuild)
        return {"issue_id": issue_id, "event_id": eid}

    def deps_remove(
        self, issue_id: str, target_id: str, *, rebuild: bool | str = "auto"
    ) -> dict[str, Any]:
        """Remove target_id from both depends_on and blocks."""
        eid = self._emit(issue_id, Op.DEPS_RM, {"depends_on": [target_id], "blocks": [target_id]})
        self._maybe_rebuild(rebuild)
        return {"issue_id": issue_id, "event_id": eid}

    # ── references ────────────────────────────────────────────────────────

    def ref_set(
        self, issue_id: str, spec_file: str, *, rebuild: bool | str = "auto"
    ) -> dict[str, Any]:
        """Set spec_file for an issue's references."""
        eid = self._emit(issue_id, Op.REF_SET, {"spec_file": spec_file})
        self._maybe_rebuild(rebuild)
        return {"issue_id": issue_id, "event_id": eid}

    # ── epics ─────────────────────────────────────────────────────────────

    def epic_rename(
        self, name: str, new_name: str, *, rebuild: bool | str = "auto"
    ) -> dict[str, Any]:
        """Rename all issues in an epic to new_name."""
        issues = [i for i in self._load_active() if i.epic == name]
        if not issues:
            raise NotFoundError(f"Epic not found: {name!r}")
        for issue in issues:
            self._emit(issue.id, Op.SET, {"epic": new_name})
        self._maybe_rebuild(rebuild)
        return {"renamed": len(issues), "from": name, "to": new_name}

    def epic_analyze(
        self,
        model: str | None = None,
        *,
        apply: bool = False,
        include_assigned: bool = False,
    ) -> builtins.list[dict[str, Any]]:
        """Suggest epic assignments for issues using an AI model.

        Args:
            model: pydantic-ai model string (e.g. ``openai:gpt-4o``).
                Falls back to ``ai_model`` in ``~/.ao/config.json``.
            apply: If True, write SET events to assign the suggested epics.
            include_assigned: Also analyze issues that already have an epic.

        Returns:
            List of suggestion dicts with ``issue_id``, ``epic``, ``reason``.
        """
        from ao._internal.commands.epic_analyze import epic_analyze
        from ao._internal.context import AppContext, OutputFormat, ProgressMode

        ctx = AppContext(
            root=self._paths.root, fmt=OutputFormat.JSON, yes=True,
            progress=ProgressMode.NONE,
        )
        return epic_analyze(
            ctx, model, apply=apply, include_assigned=include_assigned
        )

    # ── stale issues ──────────────────────────────────────────────────────

    def stale(self, days: int = 7) -> builtins.list[dict[str, Any]]:
        """Return issues not updated in the last ``days`` days, with days_stale field."""
        from datetime import UTC, datetime, timedelta

        now = datetime.now(UTC)
        threshold = now - timedelta(days=days)
        result: builtins.list[dict[str, Any]] = []
        for issue in self._load_active():
            if not issue.updated:
                continue
            try:
                updated = datetime.fromisoformat(issue.updated.replace("Z", "+00:00"))
            except ValueError:
                continue
            if updated < threshold:
                d: dict[str, Any] = msgspec.to_builtins(issue)
                d["days_stale"] = (now - updated).days
                result.append(d)
        result.sort(key=lambda x: x["days_stale"], reverse=True)
        return result

    # ── next issues ───────────────────────────────────────────────────────

    def next_issues(
        self, limit: int = 5, *, owner: str | None = None
    ) -> builtins.list[dict[str, Any]]:
        """Return top N ready-to-work issues sorted by priority."""
        all_issues = self._load_active()
        all_map = {i.id: i for i in all_issues}
        ready = [i for i in all_issues if _is_issue_ready(i, all_map)]
        if owner:
            ready = [i for i in ready if i.owner == owner]
        ready.sort(key=lambda i: (_PRIORITY_ORDER.get(i.priority.value, 99), i.updated or ""))
        return [msgspec.to_builtins(i) for i in ready[:limit]]

    # ── batching ──────────────────────────────────────────────────────────

    def batch(self, *, rebuild: bool = True) -> Batch:
        """Return a Batch context manager for buffered operations."""
        return Batch(self, rebuild=rebuild)

    # ── workers ───────────────────────────────────────────────────────────

    def workers(self) -> builtins.list[dict[str, Any]]:
        """List all registered workers."""
        from ao._internal.workers import list_workers

        return list_workers(self._paths.workers_path)

    def worker_add(
        self,
        name: str,
        engine: str,
        *,
        label: str = "",
        model: str = "",
        context: str = "",
        instructions: str = "",
        completion_action: str = "close",
    ) -> dict[str, Any]:
        """Register a new worker. Raises ValidationError on bad input."""
        from ao._internal.workers import add_worker

        try:
            return add_worker(
                self._paths.workers_path,
                name,
                engine,
                label=label,
                model=model,
                context=context,
                instructions=instructions,
                completion_action=completion_action,
            )
        except ValueError as exc:
            raise ValidationError(str(exc)) from exc

    def worker_get(self, name: str) -> dict[str, Any]:
        """Get a single worker. Raises ValidationError if not found."""
        from ao._internal.workers import get_worker

        try:
            return get_worker(self._paths.workers_path, name)
        except ValueError as exc:
            raise ValidationError(str(exc)) from exc

    def worker_update(self, name: str, **fields: str) -> dict[str, Any]:
        """Update worker fields. Raises ValidationError if not found."""
        from ao._internal.workers import update_worker

        try:
            return update_worker(self._paths.workers_path, name, **fields)
        except ValueError as exc:
            raise ValidationError(str(exc)) from exc

    def worker_remove(self, name: str) -> dict[str, Any]:
        """Remove a registered worker. Raises ValidationError if not found."""
        from ao._internal.workers import remove_worker

        try:
            return remove_worker(self._paths.workers_path, name)
        except ValueError as exc:
            raise ValidationError(str(exc)) from exc

    def worker_assign(
        self,
        issue_id: str,
        worker_name: str,
        *,
        rebuild: bool | str = "auto",
    ) -> dict[str, Any]:
        """Assign a worker to an issue by setting its owner field."""
        from ao._internal.workers import load_registry

        reg = load_registry(self._paths.workers_path)
        if worker_name not in reg.workers:
            raise ValidationError(f"Worker not found: {worker_name!r}")
        issue_id = self._resolve_id(issue_id)
        result = self.patch(issue_id, {"set": {"owner": worker_name}}, rebuild=rebuild)
        return {**result, "worker": worker_name}

    # ── JSON helpers ──────────────────────────────────────────────────────

    def _parse_json(self, json_str: str) -> dict[str, Any]:
        """Parse a JSON string to dict."""
        try:
            data = orjson.loads(json_str)
        except (orjson.JSONDecodeError, TypeError) as exc:
            msg = f"Invalid JSON: {exc}"
            raise ValidationError(msg) from exc
        if not isinstance(data, dict):
            msg = "JSON input must be an object"
            raise ValidationError(msg)
        return data

    def _check_fields(
        self,
        data: dict[str, Any],
        valid: frozenset[str],
        ctx: str,
    ) -> None:
        if not self._strict:
            return
        unknown = set(data) - valid
        if unknown:
            msg = f"Unknown fields in {ctx}: {', '.join(sorted(unknown))}"
            raise ValidationError(msg)

    def create_json(
        self,
        json_str: str,
        *,
        actor: str = "agent",
        rebuild: bool | str = "auto",
    ) -> dict[str, Any]:
        """Create issue from a JSON string."""
        data = self._parse_json(json_str)
        self._check_fields(data, _CREATE_FIELDS, "create")
        return self.create(data, actor=actor, rebuild=rebuild)

    def patch_json(
        self,
        issue_id: str,
        json_str: str,
        *,
        actor: str = "agent",
        rebuild: bool | str = "auto",
    ) -> dict[str, Any]:
        """Patch issue from a JSON string."""
        data = self._parse_json(json_str)
        self._check_fields(data, _PATCH_TOP_FIELDS, "patch")
        return self.patch(issue_id, data, actor=actor, rebuild=rebuild)

    def list_json(self, filters_json: str = "{}") -> dict[str, Any]:
        """List issues from a JSON filter string."""
        filters = self._parse_json(filters_json)
        saved = self._typed
        self._typed = False
        try:
            issues = self.list(filters=filters)
        finally:
            self._typed = saved
        return {"issues": issues, "count": len(issues)}

    def append_event_json(
        self,
        json_str: str,
        *,
        rebuild: bool | str = "auto",
    ) -> dict[str, Any]:
        """Append raw event from a JSON string."""
        data = self._parse_json(json_str)
        return self.append_event(data, rebuild=rebuild)


class Batch:
    """Buffers events in memory; single commit with optional rebuild.

    Note: commit writes sequentially — partial writes possible on error.
    """

    __slots__ = ("_buffer", "_client", "_committed", "_counter_base", "_counter_used", "_rebuild")

    def __init__(self, client: AOClient, *, rebuild: bool = True) -> None:
        self._client = client
        self._buffer: builtins.list[bytes] = []
        self._committed = False
        self._rebuild = rebuild
        self._counter_base: int | None = None
        self._counter_used: int = 0

    def __enter__(self) -> Batch:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> None:
        if exc_type is None and not self._committed:
            self.commit()

    def _buf(self, event: Event) -> None:
        self._buffer.append(self._client._codec.encode_event(event))

    def _eid(self) -> tuple[int, str]:
        if self._counter_base is None:
            self._counter_base = self._client._next_id()
        num = self._counter_base + self._counter_used
        self._counter_used += 1
        return num, self._client._make_event_id(num)

    def create(self, issue: dict[str, Any], *, actor: str = "agent") -> dict[str, Any]:
        """Buffer a create event."""
        title = issue.get("title", "")
        if not title:
            raise ValidationError("title is required")
        itype = issue.get("type", "feat")
        if self._client._strict:
            self._client._validate_enum("type", itype, IssueType)
            if "priority" in issue:
                self._client._validate_enum("priority", issue["priority"], Priority)
        num, eid = self._eid()
        issue_id = self._client._make_issue_id(num, itype)
        ts = self._client._now_iso()
        payload = _build_create_payload(issue, actor)
        event = Event(
            event_id=eid,
            issue_id=issue_id,
            op=Op.CREATE,
            timestamp=ts,
            payload=payload,
        )
        self._buf(event)
        return {"issue_id": issue_id, "event_id": eid, "title": title}

    def patch(
        self,
        issue_id: str,
        patch: dict[str, Any],
        *,
        actor: str = "agent",
    ) -> dict[str, Any]:
        """Buffer patch events."""
        set_fields = patch.get("set", {})
        if self._client._strict:
            if "status" in set_fields:
                self._client._validate_enum("status", set_fields["status"], Status)
            if "priority" in set_fields:
                self._client._validate_enum("priority", set_fields["priority"], Priority)
        events_out: builtins.list[str] = []
        ts = self._client._now_iso()
        if set_fields:
            events_out.append(self._buf_set(issue_id, set_fields, ts))
        for entry in patch.get("append", {}).get("log", []):
            events_out.append(self._buf_log(issue_id, entry, ts))
        return {"issue_id": issue_id, "events": events_out}

    def _buf_set(self, issue_id: str, fields: dict[str, Any], ts: str) -> str:
        _, eid = self._eid()
        event = Event(
            event_id=eid,
            issue_id=issue_id,
            op=Op.SET,
            timestamp=ts,
            payload=fields,
        )
        self._buf(event)
        return eid

    def _buf_log(self, issue_id: str, entry: dict[str, Any], ts: str) -> str:
        _, eid = self._eid()
        payload: dict[str, Any] = {
            "date": entry.get("ts", ts),
            "message": entry.get("text", ""),
        }
        event = Event(
            event_id=eid,
            issue_id=issue_id,
            op=Op.LOG_APPEND,
            timestamp=ts,
            payload=payload,
        )
        self._buf(event)
        return eid

    def _buf_close(self, issue_id: str, status: str, ts: str) -> str:
        _, eid = self._eid()
        event = Event(
            event_id=eid,
            issue_id=issue_id,
            op=Op.CLOSE,
            timestamp=ts,
            payload={"status": status},
        )
        self._buf(event)
        return eid

    def _buf_log_raw(self, issue_id: str, message: str, ts: str) -> str:
        _, eid = self._eid()
        payload: dict[str, Any] = {"date": ts, "message": message}
        event = Event(
            event_id=eid,
            issue_id=issue_id,
            op=Op.LOG_APPEND,
            timestamp=ts,
            payload=payload,
        )
        self._buf(event)
        return eid

    def close(
        self,
        issue_id: str,
        log: str = "",
        *,
        status: str = "done",
        actor: str = "agent",
    ) -> dict[str, Any]:
        """Buffer close events."""
        if status not in {s.value for s in TERMINAL_STATUSES}:
            msg = f"Close status must be terminal, got: {status!r}"
            raise ValidationError(msg)
        events_out: builtins.list[str] = []
        ts = self._client._now_iso()
        if log:
            events_out.append(self._buf_log_raw(issue_id, log, ts))
        events_out.append(self._buf_close(issue_id, status, ts))
        return {"issue_id": issue_id, "events": events_out, "closed": True}

    def append_event(self, event_dict: dict[str, Any]) -> dict[str, Any]:
        """Buffer a raw event dict."""
        try:
            event = Event(
                event_id=event_dict["event_id"],
                issue_id=event_dict["issue_id"],
                op=Op(event_dict["op"]),
                timestamp=event_dict["timestamp"],
                payload=event_dict.get("payload", {}),
            )
        except (KeyError, ValueError) as exc:
            msg = f"Invalid event: {exc}"
            raise ValidationError(msg) from exc
        self._buf(event)
        return {"event_id": event.event_id, "issue_id": event.issue_id}

    def commit(self) -> dict[str, Any]:
        """Flush buffered events to disk, optionally rebuild once."""
        if self._committed:
            msg = "Batch already committed"
            raise ValidationError(msg)
        self._committed = True
        count = len(self._buffer)
        self._flush()
        if self._rebuild:
            self._client._do_rebuild()
        return {"committed": True, "event_count": count}

    def _flush(self) -> None:
        self._client._paths.events_path.parent.mkdir(parents=True, exist_ok=True)
        for line in self._buffer:
            append_jsonl(self._client._paths.events_path, line)
        self._buffer.clear()

    def rollback(self) -> None:
        """Discard all buffered events (only before commit)."""
        if self._committed:
            msg = "Cannot rollback after commit"
            raise ValidationError(msg)
        self._buffer.clear()
        self._committed = True
