"""AO errors — typed exceptions with stable string codes."""

from __future__ import annotations


class AOError(Exception):
    """Base exception for all AO library errors."""

    code: str = "AO_ERROR"

    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(message)


class ValidationError(AOError):
    """Schema, enum, or field validation failure."""

    code: str = "VALIDATION_ERROR"


class NotFoundError(AOError):
    """Issue or resource not found."""

    code: str = "NOT_FOUND"


class LockError(AOError):
    """Events file locked by another process."""

    code: str = "LOCKED"


class IntegrityError(AOError):
    """Dependency cycle, invalid state transition, or data corruption."""

    code: str = "INTEGRITY_ERROR"


class ParseError(AOError):
    """Malformed JSON or JSONL input."""

    code: str = "PARSE_ERROR"
