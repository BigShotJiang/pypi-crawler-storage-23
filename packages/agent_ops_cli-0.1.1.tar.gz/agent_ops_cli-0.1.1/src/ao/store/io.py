"""AO store IO — public wrappers for binary JSONL read/write."""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path

from ao._internal.io import append_jsonl as _append
from ao._internal.io import atomic_write_jsonl as _atomic
from ao._internal.io import iter_jsonl_bytes as _iter


def iter_jsonl(path: Path) -> Iterator[bytes]:
    """Yield non-empty raw byte lines from a JSONL file."""
    yield from _iter(path)


def append_jsonl(path: Path, line_bytes: bytes) -> None:
    """Append a single JSON line to a JSONL file."""
    _append(path, line_bytes)


def atomic_write(path: Path, lines: Iterator[bytes]) -> None:
    """Write JSONL atomically via temp file + os.replace."""
    _atomic(path, lines)
