"""AO store rebuild — public rebuild and event-application wrappers."""

from __future__ import annotations

from collections.abc import Iterator
from dataclasses import dataclass
from pathlib import Path

from ao._internal.apply import ApplyError
from ao._internal.apply import apply_event as _apply_event
from ao._internal.io import iter_jsonl_bytes
from ao._internal.rebuild import rebuild as _rebuild
from ao.codec import Codec
from ao.models import TERMINAL_STATUSES, Event, Issue


def apply_event(issue: Issue | None, event: Event) -> Issue | None:
    """Apply a single event to an issue, returning the updated issue.

    Raises ``ApplyError`` if the event cannot be applied.
    """
    return _apply_event(issue, event)


@dataclass(frozen=True, slots=True)
class RebuildStats:
    """Statistics returned by a rebuild operation."""

    event_count: int
    active_count: int


def rebuild(
    events_path: Path,
    active_path: Path,
    codec: Codec,
    *,
    show_progress: bool = False,
) -> RebuildStats:
    """Rebuild active.jsonl from events.jsonl and return stats."""
    issues = _rebuild(
        events_path,
        active_path,
        codec,
        show_progress=show_progress,
    )
    return RebuildStats(
        event_count=_count_events(events_path),
        active_count=len(issues),
    )


def iter_active_from_events(
    events_path: Path,
    codec: Codec,
) -> Iterator[Issue]:
    """Stream rebuild: yield active issues without writing a snapshot."""
    issues: dict[str, Issue] = {}
    for line in iter_jsonl_bytes(events_path):
        try:
            event = codec.decode_event(line)
        except Exception:  # noqa: BLE001, S112
            continue
        current = issues.get(event.issue_id)
        try:
            result = _apply_event(current, event)
        except ApplyError:
            continue
        if result is None:
            issues.pop(event.issue_id, None)
        else:
            issues[event.issue_id] = result
    active = {k: v for k, v in issues.items() if v.status not in TERMINAL_STATUSES}
    yield from (active[k] for k in sorted(active))


def _count_events(events_path: Path) -> int:
    """Count lines in the events file."""
    count = 0
    for _ in iter_jsonl_bytes(events_path):
        count += 1
    return count
