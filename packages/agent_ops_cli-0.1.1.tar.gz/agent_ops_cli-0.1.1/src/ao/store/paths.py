"""AO store paths — workspace discovery and path resolution."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from ao.errors import NotFoundError

_AGENT_OPS_DIR = ".agent/ops"
_ISSUES_DIR = "issues"


@dataclass(frozen=True, slots=True)
class AOPaths:
    """Resolved filesystem paths for an AO workspace."""

    root: Path
    ops_dir: Path
    events_path: Path
    active_path: Path
    ref_dir: Path
    workers_path: Path

    def __init__(self, root: Path) -> None:
        resolved = root.resolve()
        issues = resolved / _ISSUES_DIR
        object.__setattr__(self, "root", resolved)
        object.__setattr__(self, "ops_dir", resolved)
        object.__setattr__(self, "events_path", issues / "events.jsonl")
        object.__setattr__(self, "active_path", issues / "active.jsonl")
        object.__setattr__(self, "ref_dir", issues / "references")
        object.__setattr__(self, "workers_path", resolved / "workers.json")


def discover_root(start: Path | None = None) -> AOPaths:
    """Walk up from *start* to find `.agent/ops/` and return resolved paths.

    Raises ``NotFoundError`` if no workspace is found.
    """
    current = (start or Path.cwd()).resolve()
    for parent in (current, *current.parents):
        candidate = parent / _AGENT_OPS_DIR
        if candidate.is_dir():
            return AOPaths(root=candidate)
    msg = f"No .agent/ops/ found above {current}"
    raise NotFoundError(msg)
