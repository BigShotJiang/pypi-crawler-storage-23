"""AO store — public storage layer: paths, IO, rebuild."""

from __future__ import annotations

from ao.store.io import append_jsonl, atomic_write, iter_jsonl
from ao.store.paths import AOPaths, discover_root
from ao.store.rebuild import apply_event, iter_active_from_events, rebuild

__all__ = [
    "AOPaths",
    "append_jsonl",
    "apply_event",
    "atomic_write",
    "discover_root",
    "iter_active_from_events",
    "iter_jsonl",
    "rebuild",
]
