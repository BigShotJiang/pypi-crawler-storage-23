"""FastAPI application factory for AO Web UI."""

from __future__ import annotations

import asyncio
from collections import defaultdict
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from jinja2 import select_autoescape

from ao.api import AOClient
from ao.models import BOARD_STATUSES
from ao.store import AOPaths, discover_root


class _IssueCache:
    """Mtime-based cache for active.jsonl to avoid re-parsing on every request."""

    def __init__(self, paths: AOPaths, client: AOClient) -> None:
        self._path = paths.active_path
        self._client = client
        self._mtime: float = 0.0
        self._data: list[dict[str, Any]] = []

    def get(self) -> list[dict[str, Any]]:
        """Return cached issues, re-reading only if file changed."""
        try:
            cur = self._path.stat().st_mtime
        except OSError:
            cur = 0.0
        if cur != self._mtime:
            self._data = self._client.list(view="full")  # type: ignore[assignment]
            self._mtime = cur
        return self._data


def build_app(paths: AOPaths | None = None) -> FastAPI:
    """Build and return a fully-configured FastAPI app."""
    if paths is None:
        paths = discover_root()

    client = AOClient(paths, codec="msgspec")

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
        from ao.web.watcher import start_watcher

        loop = asyncio.get_running_loop()
        observer = start_watcher(paths, loop)
        yield
        observer.stop()
        observer.join()

    app = FastAPI(title="AO Web UI", version="0.1.0", lifespan=lifespan)
    app.state.client = client
    app.state.paths = paths
    cache = _IssueCache(paths, client)

    _mount_refs(app, paths)
    _mount_static(app)
    templates = _setup_templates()

    from ao.web.api.issues import router as issues_router
    from ao.web.api.workers import router as workers_router
    from ao.web.api.ws import router as ws_router

    app.include_router(issues_router, prefix="/api")
    app.include_router(workers_router, prefix="/api")
    app.include_router(ws_router)

    @app.get("/")
    async def index(request: Request, layout: str = "priority") -> Any:
        return _render_board(request, layout, templates, cache)

    @app.get("/board")
    async def board_partial(request: Request, layout: str = "priority") -> Any:
        return _render_board(request, layout, templates, cache, partial=True)

    @app.get("/health")
    async def health() -> dict[str, str]:
        return {"status": "ok"}

    return app


def _mount_static(app: FastAPI) -> None:
    static_dir = Path(__file__).parent / "static"
    if static_dir.exists():
        app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")


def _mount_refs(app: FastAPI, paths: AOPaths) -> None:
    paths.ref_dir.mkdir(parents=True, exist_ok=True)
    app.mount("/static/refs", StaticFiles(directory=str(paths.ref_dir)), name="refs")


def _setup_templates() -> Jinja2Templates:
    tpl_dir = Path(__file__).parent / "templates"
    return Jinja2Templates(
        directory=str(tpl_dir),
        autoescape=select_autoescape(["html", "xml"]),
    )


def _render_board(
    request: Request,
    layout: str,
    templates: Jinja2Templates,
    cache: _IssueCache,
    *,
    partial: bool = False,
) -> Any:
    """Render the Kanban board template."""
    issues = cache.get()
    priorities = ["critical", "high", "medium", "low", "backlog"]
    statuses = ["todo", "in_progress", "review", "blocked", "done", "cancelled", "dropped"]

    data: dict[str, Any] = {
        "request": request,
        "layout": layout,
        "priorities": priorities,
        "statuses": statuses,
    }

    if layout == "status":
        board_cols = list(BOARD_STATUSES)
        grouped = _group_by_field(issues, "status", board_cols)
        data["issues"] = grouped
        data["columns"] = board_cols
        data["column_type"] = "status"
    else:
        grouped = _group_by_field(issues, "priority", priorities)
        data["issues"] = grouped
        data["columns"] = priorities
        data["column_type"] = "priority"

    tpl = "_board_partial.html" if partial else "index.html"
    return templates.TemplateResponse(tpl, data)


def _group_by_field(
    issues: list[dict[str, Any]],
    field: str,
    keys: list[str],
) -> dict[str, list[dict[str, Any]]]:
    """Group a flat list of issue dicts by a field value."""
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for key in keys:
        grouped[key] = []
    for issue in issues:
        val = str(issue.get(field, ""))
        grouped[val].append(issue)
    return dict(grouped)
