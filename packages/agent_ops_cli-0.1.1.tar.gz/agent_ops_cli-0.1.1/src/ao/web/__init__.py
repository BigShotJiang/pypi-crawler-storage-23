"""AO Web UI — Kanban board for issue management.

Requires optional dependencies: ``pip install agent-ops-cli[web]``
"""

from __future__ import annotations


def create_app() -> object:
    """Create and return the FastAPI application.

    Raises ``ImportError`` with helpful message if web extras not installed.
    """
    try:
        from ao.web.app import build_app
    except ImportError as exc:
        msg = (
            "Web UI requires extra dependencies. Install with:\n"
            "  pip install agent-ops-cli[web]   OR   uv pip install agent-ops-cli[web]"
        )
        raise ImportError(msg) from exc
    return build_app()
