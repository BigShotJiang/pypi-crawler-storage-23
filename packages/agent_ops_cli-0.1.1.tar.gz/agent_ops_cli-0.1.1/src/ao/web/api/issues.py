"""REST API endpoints for issues, backed by AOClient."""

from __future__ import annotations

import re
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from fastapi import APIRouter, File, Request, UploadFile
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from ao.api import AOClient
from ao.errors import NotFoundError, ValidationError

router = APIRouter()

_TYPE_LABELS: dict[str, str] = {
    "bug": "Bug",
    "feat": "Feature",
    "chore": "Chore",
    "enh": "Enhancement",
    "sec": "Security",
    "perf": "Performance",
    "docs": "Documentation",
    "test": "Test",
    "refac": "Refactor",
    "plan": "Plan",
}
_STATUS_LABELS: dict[str, str] = {
    "todo": "Todo",
    "in_progress": "In Progress",
    "review": "Review",
    "blocked": "Blocked",
    "done": "Done",
    "cancelled": "Cancelled",
    "dropped": "Dropped",
}
_PRIORITY_LABELS: dict[str, str] = {
    "critical": "Critical",
    "high": "High",
    "medium": "Medium",
    "low": "Low",
    "backlog": "Backlog",
}
_CONFIDENCE_LABELS: dict[str, str] = {
    "low": "Low",
    "normal": "Normal",
    "high": "High",
}


def _ok(data: Any = None, *, status_code: int = 200) -> JSONResponse:
    return JSONResponse(content={"data": data, "errors": []}, status_code=status_code)


def _err(code: str, detail: str, *, status_code: int = 400) -> JSONResponse:
    return JSONResponse(
        content={"data": None, "errors": [{"code": code, "detail": detail}]},
        status_code=status_code,
    )


def _client(request: Request) -> AOClient:
    return request.app.state.client  # type: ignore[no-any-return]


# ── Pydantic schemas ──────────────────────────────────────────────────────


class IssueCreate(BaseModel):
    title: str
    type: str = "feat"
    status: str = "todo"
    priority: str = "backlog"
    confidence: str = "normal"
    epic: str = ""
    owner: str = "agent"
    notes: str = ""
    external_ref: str = ""


class IssueUpdate(BaseModel):
    title: str | None = None
    status: str | None = None
    confidence: str | None = None
    type: str | None = None
    priority: str | None = None
    epic: str | None = None
    owner: str | None = None
    notes: str | None = None
    external_ref: str | None = None


class MoveRequest(BaseModel):
    target_priority: str | None = None
    target_status: str | None = None


class LogAppendRequest(BaseModel):
    message: str


class AcAddRequest(BaseModel):
    description: str


class AcUpdateRequest(BaseModel):
    description: str


class LinkAddRequest(BaseModel):
    type: str
    target: str


class RefsUpdateRequest(BaseModel):
    spec_file: str = ""


class EpicRenameRequest(BaseModel):
    new_name: str


# ── Endpoints ─────────────────────────────────────────────────────────────


@router.get("/meta")
async def get_meta() -> JSONResponse:
    """Return available issue types, statuses, priorities, and confidence levels."""
    from ao.models import Confidence, IssueType, Priority, Status

    return _ok(
        {
            "types": [{"value": v, "label": _TYPE_LABELS.get(v, v.title())} for v in IssueType],
            "statuses": [
                {"value": v, "label": _STATUS_LABELS.get(v, v.replace("_", " ").title())}
                for v in Status
            ],
            "priorities": [
                {"value": v, "label": _PRIORITY_LABELS.get(v, v.title())} for v in Priority
            ],
            "confidences": [
                {"value": v, "label": _CONFIDENCE_LABELS.get(v, v.title())} for v in Confidence
            ],
        }
    )


@router.get("/issues")
async def list_issues(request: Request) -> JSONResponse:
    """List all issues grouped by priority."""
    client = _client(request)
    issues: list[dict[str, Any]] = client.list(view="full")  # type: ignore[assignment]
    grouped: dict[str, list[dict[str, Any]]] = {}
    for issue in issues:
        prio = str(issue.get("priority", "backlog"))
        grouped.setdefault(prio, []).append(issue)
    return _ok(grouped)


@router.get("/issues/next")
async def get_next_issues(request: Request, n: int = 5, owner: str = "") -> JSONResponse:
    """Return top N ready-to-work issues sorted by priority."""
    client = _client(request)
    issues = client.next_issues(limit=n, owner=owner or None)
    return _ok({"count": len(issues), "issues": issues})


@router.get("/issues/{issue_id}")
async def get_issue(issue_id: str, request: Request) -> JSONResponse:
    """Get a specific issue by ID."""
    client = _client(request)
    try:
        issue = client.get(issue_id)
    except NotFoundError:
        return _err("NOT_FOUND", "Issue not found", status_code=404)
    return _ok(issue)


@router.post("/issues")
async def create_issue(body: IssueCreate, request: Request) -> JSONResponse:
    """Create a new issue."""
    client = _client(request)
    try:
        result = client.create(
            {
                "title": body.title,
                "type": body.type,
                "status": body.status,
                "priority": body.priority,
                "confidence": body.confidence,
                "epic": body.epic,
                "owner": body.owner,
            }
        )
    except ValidationError as exc:
        return _err("VALIDATION", str(exc))
    if body.notes:
        client.patch(result["issue_id"], {"set": {"notes": body.notes}})
    if body.external_ref:
        client.patch(result["issue_id"], {"set": {"external_ref": body.external_ref}})
    await _broadcast(request, "issue.created", {"issue_id": result["issue_id"]})
    return _ok(result, status_code=201)


@router.put("/issues/{issue_id}")
async def update_issue(issue_id: str, body: IssueUpdate, request: Request) -> JSONResponse:
    """Update an existing issue."""
    client = _client(request)
    set_fields: dict[str, Any] = {}
    if body.title is not None:
        set_fields["title"] = body.title
    if body.status is not None:
        set_fields["status"] = body.status
    if body.priority is not None:
        set_fields["priority"] = body.priority
    if body.confidence is not None:
        set_fields["confidence"] = body.confidence
    if body.type is not None:
        set_fields["type"] = body.type

    if body.epic is not None:
        set_fields["epic"] = body.epic
    if body.owner is not None:
        set_fields["owner"] = body.owner
    if body.notes is not None:
        set_fields["notes"] = body.notes
    if body.external_ref is not None:
        set_fields["external_ref"] = body.external_ref

    if not set_fields:
        return _err("BAD_REQUEST", "No fields to update")

    try:
        result = client.patch(issue_id, {"set": set_fields})
    except NotFoundError:
        return _err("NOT_FOUND", "Issue not found", status_code=404)
    except ValidationError as exc:
        return _err("VALIDATION", str(exc))
    await _broadcast(request, "issue.updated", {"issue_id": issue_id})
    return _ok(result)


@router.delete("/issues/{issue_id}")
async def delete_issue(issue_id: str, request: Request) -> JSONResponse:
    """Delete (close as dropped) an issue."""
    client = _client(request)
    try:
        result = client.close(issue_id, "Deleted via web UI", status="dropped")
    except NotFoundError:
        return _err("NOT_FOUND", "Issue not found", status_code=404)
    except ValidationError as exc:
        return _err("VALIDATION", str(exc))
    await _broadcast(request, "issue.deleted", {"issue_id": issue_id})
    return _ok(result)


@router.post("/issues/{issue_id}/move")
async def move_issue(issue_id: str, request: Request, body: MoveRequest) -> JSONResponse:
    """Move an issue to a different priority or update its status."""
    client = _client(request)

    if body.target_status:
        try:
            result = client.patch(issue_id, {"set": {"status": body.target_status}})
        except NotFoundError:
            return _err("NOT_FOUND", "Issue not found", status_code=404)
        except ValidationError as exc:
            return _err("VALIDATION", str(exc))
        await _broadcast(request, "issue.updated", {"issue_id": issue_id})
        return _ok(result)

    if body.target_priority:
        try:
            result = client.patch(issue_id, {"set": {"priority": body.target_priority}})
        except NotFoundError:
            return _err("NOT_FOUND", "Issue not found", status_code=404)
        except ValidationError as exc:
            return _err("VALIDATION", str(exc))
        await _broadcast(request, "issue.moved", {"issue_id": issue_id})
        return _ok(result)

    return _err("BAD_REQUEST", "Must specify target_priority or target_status")


# ── Log endpoints ─────────────────────────────────────────────────────────


@router.get("/issues/{issue_id}/log")
async def get_issue_log(issue_id: str, request: Request) -> JSONResponse:
    """List log entries for an issue."""
    client = _client(request)
    try:
        issue = client.get(issue_id)
    except NotFoundError:
        return _err("NOT_FOUND", "Issue not found", status_code=404)
    return _ok(issue.get("log", []))  # type: ignore[union-attr]


@router.post("/issues/{issue_id}/log")
async def append_issue_log(issue_id: str, body: LogAppendRequest, request: Request) -> JSONResponse:
    """Append a log entry to an issue."""
    client = _client(request)
    result = client.log_append(issue_id, body.message)
    return _ok(result)


# ── Acceptance criteria endpoints ─────────────────────────────────────────


@router.get("/issues/{issue_id}/ac")
async def get_issue_ac(issue_id: str, request: Request) -> JSONResponse:
    """List acceptance criteria for an issue."""
    client = _client(request)
    try:
        issue = client.get(issue_id)
    except NotFoundError:
        return _err("NOT_FOUND", "Issue not found", status_code=404)
    return _ok(issue.get("acceptance_criteria", []))  # type: ignore[union-attr]


@router.post("/issues/{issue_id}/ac")
async def add_issue_ac(issue_id: str, body: AcAddRequest, request: Request) -> JSONResponse:
    """Add an acceptance criterion."""
    client = _client(request)
    result = client.ac_add(issue_id, body.description)
    return _ok(result)


@router.put("/issues/{issue_id}/ac/{index}")
async def update_issue_ac(
    issue_id: str, index: int, body: AcUpdateRequest, request: Request
) -> JSONResponse:
    """Update AC text (1-based index)."""
    client = _client(request)
    try:
        result = client.ac_update(issue_id, index - 1, body.description)
    except NotFoundError:
        return _err("NOT_FOUND", "Issue not found", status_code=404)
    except ValidationError as exc:
        return _err("VALIDATION", str(exc))
    return _ok(result)


@router.delete("/issues/{issue_id}/ac/{index}")
async def remove_issue_ac(issue_id: str, index: int, request: Request) -> JSONResponse:
    """Remove AC by 1-based index."""
    client = _client(request)
    try:
        result = client.ac_remove(issue_id, index - 1)
    except NotFoundError:
        return _err("NOT_FOUND", "Issue not found", status_code=404)
    except ValidationError as exc:
        return _err("VALIDATION", str(exc))
    return _ok(result)


@router.post("/issues/{issue_id}/ac/{index}/check")
async def check_issue_ac(issue_id: str, index: int, request: Request) -> JSONResponse:
    """Mark AC as done (1-based index)."""
    client = _client(request)
    try:
        result = client.ac_check(issue_id, index - 1, done=True)
    except (NotFoundError, ValidationError) as exc:
        code = "NOT_FOUND" if isinstance(exc, NotFoundError) else "VALIDATION"
        status = 404 if isinstance(exc, NotFoundError) else 400
        return _err(code, str(exc), status_code=status)
    return _ok(result)


@router.post("/issues/{issue_id}/ac/{index}/uncheck")
async def uncheck_issue_ac(issue_id: str, index: int, request: Request) -> JSONResponse:
    """Mark AC as not done (1-based index)."""
    client = _client(request)
    try:
        result = client.ac_check(issue_id, index - 1, done=False)
    except (NotFoundError, ValidationError) as exc:
        code = "NOT_FOUND" if isinstance(exc, NotFoundError) else "VALIDATION"
        status = 404 if isinstance(exc, NotFoundError) else 400
        return _err(code, str(exc), status_code=status)
    return _ok(result)


# ── Link endpoints ────────────────────────────────────────────────────────


@router.get("/issues/{issue_id}/links")
async def get_issue_links(issue_id: str, request: Request) -> JSONResponse:
    """Get dependency links (depends_on / blocks) for an issue."""
    client = _client(request)
    try:
        issue = client.get(issue_id)
    except NotFoundError:
        return _err("NOT_FOUND", "Issue not found", status_code=404)
    return _ok(issue.get("dependencies", {}))  # type: ignore[union-attr]


@router.post("/issues/{issue_id}/links")
async def add_issue_link(issue_id: str, body: LinkAddRequest, request: Request) -> JSONResponse:
    """Add a dependency link (type: depends_on or blocks)."""
    client = _client(request)
    try:
        result = client.deps_add(issue_id, body.type, body.target)
    except ValidationError as exc:
        return _err("VALIDATION", str(exc))
    return _ok(result)


@router.delete("/issues/{issue_id}/links/{target}")
async def remove_issue_link(issue_id: str, target: str, request: Request) -> JSONResponse:
    """Remove a dependency link (from both depends_on and blocks)."""
    client = _client(request)
    result = client.deps_remove(issue_id, target)
    return _ok(result)


# ── Reference endpoints ───────────────────────────────────────────────────


@router.get("/issues/{issue_id}/refs")
async def get_issue_refs(issue_id: str, request: Request) -> JSONResponse:
    """Get reference metadata (spec_file, files) for an issue."""
    client = _client(request)
    try:
        issue = client.get(issue_id)
    except NotFoundError:
        return _err("NOT_FOUND", "Issue not found", status_code=404)
    return _ok(issue.get("references", {}))  # type: ignore[union-attr]


@router.put("/issues/{issue_id}/refs")
async def update_issue_refs(
    issue_id: str, body: RefsUpdateRequest, request: Request
) -> JSONResponse:
    """Set spec_file for an issue."""
    client = _client(request)
    result = client.ref_set(issue_id, body.spec_file)
    return _ok(result)


# ── Epic endpoints ────────────────────────────────────────────────────────


@router.get("/epics")
async def list_epics(request: Request) -> JSONResponse:
    """List all epics with issue counts."""
    client = _client(request)
    return _ok(client.epics())


@router.get("/epics/{name}")
async def get_epic(name: str, request: Request) -> JSONResponse:
    """List issues in an epic."""
    client = _client(request)
    issues: list[dict[str, Any]] = client.list(filters={"epic": name}, view="full")  # type: ignore[assignment]
    return _ok({"name": name, "issues": issues})


@router.put("/epics/{name}")
async def rename_epic(name: str, body: EpicRenameRequest, request: Request) -> JSONResponse:
    """Rename an epic (updates all issues in it)."""
    client = _client(request)
    try:
        result = client.epic_rename(name, body.new_name)
    except NotFoundError:
        return _err("NOT_FOUND", f"Epic not found: {name!r}", status_code=404)
    return _ok(result)


# ── Utility endpoints ─────────────────────────────────────────────────────


@router.post("/rebuild")
async def rebuild_snapshot(request: Request) -> JSONResponse:
    """Force rebuild of active snapshot from events."""
    client = _client(request)
    return _ok(client.rebuild_snapshot())


@router.get("/graph")
async def get_graph(request: Request, format: str = "json") -> JSONResponse:  # noqa: A002
    """Return full dependency graph (format=mermaid|json)."""
    client = _client(request)
    data = client.graph()
    if format == "mermaid":
        return _ok(data.get("mermaid", ""))
    return _ok(data)


async def _broadcast(request: Request, event_type: str, data: dict[str, Any]) -> None:
    from ao.web.api.ws import broadcast_update

    await broadcast_update(event_type, data)


# ── Complete issue ────────────────────────────────────────────────────────


class CompleteRequest(BaseModel):
    action: str = "close"
    log: str = ""


@router.post("/issues/{issue_id}/complete")
async def complete_issue(
    issue_id: str, body: CompleteRequest, request: Request
) -> JSONResponse:
    """Execute a completion action on an issue."""
    from ao._internal.commands.complete import execute_completion

    client = _client(request)
    try:
        result = execute_completion(
            issue_id, body.action, None, client, log=body.log
        )
    except (ValidationError, ValueError) as exc:
        return _err("VALIDATION", str(exc))
    await _broadcast(request, "issue.updated", {"issue_id": issue_id})
    return _ok(result)


# ── File upload ───────────────────────────────────────────────────────────

_MAX_FILE_BYTES: int = 10 * 1024 * 1024
_UNSAFE_RE = re.compile(r"[^\w.\-]")


def _sanitize_filename(name: str) -> str:
    """Strip path components and replace unsafe characters."""
    safe = _UNSAFE_RE.sub("_", Path(name).name)
    return safe[:200] or "upload"


async def _save_upload(upload: UploadFile, dest_dir: Path) -> str | None:
    """Write upload to dest_dir; return filename or None if too large."""
    raw = await upload.read()
    if len(raw) > _MAX_FILE_BYTES:
        return None
    safe = _sanitize_filename(upload.filename or "upload")
    (dest_dir / safe).write_bytes(raw)
    return safe


@router.post("/issues/{issue_id}/upload")
async def upload_files(
    issue_id: str,
    request: Request,
    files: list[UploadFile] = File(...),
) -> JSONResponse:
    """Upload one or more files and attach them to an issue."""
    upload_dir = request.app.state.paths.ref_dir / issue_id
    upload_dir.mkdir(parents=True, exist_ok=True)
    stored: list[str] = []
    for upload in files:
        name = await _save_upload(upload, upload_dir)
        if name is None:
            return _err("FILE_TOO_LARGE", "A file exceeds the 10 MB limit")
        stored.append(f"{issue_id}/{name}")
    if stored:
        ts = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
        _client(request).append_event(
            {
                "event_id": f"evt-{uuid.uuid4().hex[:8]}",
                "issue_id": issue_id,
                "op": "files_add",
                "timestamp": ts,
                "payload": {"files": stored},
            }
        )
    return _ok({"stored": stored})
