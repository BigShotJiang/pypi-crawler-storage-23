"""WebSocket endpoint for real-time updates."""

from __future__ import annotations

import logging
from urllib.parse import urlparse

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

router = APIRouter()
logger = logging.getLogger(__name__)

_ALLOWED_HOSTS = {"localhost", "127.0.0.1", "[::1]"}


def _origin_allowed(websocket: WebSocket) -> bool:
    """Check the WebSocket Origin header against allowed hosts."""
    origin = websocket.headers.get("origin", "")
    if not origin:
        return True  # same-origin (no Origin header)
    host = urlparse(origin).hostname or ""
    return host in _ALLOWED_HOSTS


class ConnectionManager:
    """Manages WebSocket connections."""

    def __init__(self) -> None:
        self.active_connections: list[WebSocket] = []

    async def connect(self, websocket: WebSocket) -> None:
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket) -> None:
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)

    async def broadcast(self, message: dict[str, object]) -> None:
        for conn in list(self.active_connections):
            try:
                await conn.send_json(message)
            except Exception:  # noqa: BLE001
                logger.debug("Failed to send to client, removing", exc_info=True)
                self.disconnect(conn)


manager = ConnectionManager()


async def broadcast_update(event_type: str, data: dict[str, object]) -> None:
    """Broadcast an update to all connected WebSocket clients."""
    await manager.broadcast({"type": event_type, "data": data})


@router.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket) -> None:
    """WebSocket endpoint for real-time issue change notifications."""
    if not _origin_allowed(websocket):
        await websocket.close(code=4003)
        return
    await manager.connect(websocket)
    try:
        while True:
            await websocket.receive_text()
            await websocket.send_json({"type": "pong"})
    except WebSocketDisconnect:
        pass
    except Exception:  # noqa: BLE001
        logger.debug("WebSocket error", exc_info=True)
    finally:
        manager.disconnect(websocket)
