"""REST API endpoints for worker registry."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from ao.api import AOClient
from ao.errors import ValidationError

router = APIRouter()


def _ok(data: Any = None, *, status_code: int = 200) -> JSONResponse:
    return JSONResponse(content={"data": data, "errors": []}, status_code=status_code)


def _err(code: str, detail: str, *, status_code: int = 400) -> JSONResponse:
    return JSONResponse(
        content={"data": None, "errors": [{"code": code, "detail": detail}]},
        status_code=status_code,
    )


def _client(request: Request) -> AOClient:
    return request.app.state.client  # type: ignore[no-any-return]


class WorkerCreate(BaseModel):
    name: str
    engine: str
    label: str = ""
    model: str = ""
    context: str = ""
    instructions: str = ""
    completion_action: str = "close"


class WorkerUpdate(BaseModel):
    label: str | None = None
    model: str | None = None
    context: str | None = None
    instructions: str | None = None
    engine: str | None = None
    completion_action: str | None = None


class WorkerAssign(BaseModel):
    issue_id: str


class BulkAssign(BaseModel):
    issue_ids: list[str]


class WorktreeDispatch(BaseModel):
    worker_name: str
    issue_ids: list[str]
    branch_name: str = ""
    launch_with: str = ""
    completion_action: str = ""


def _build_prompt_file(
    dispatch_dir: Path,
    worker_info: dict[str, Any],
    issue_ids: list[str],
    client: AOClient,
) -> Path:
    """Write .ao/prompt.md with worker context and issue details."""
    lines: list[str] = ["# Dispatch Prompt\n"]

    lines.append("## Skill\n")
    lines.append("Use the **ao-auto** skill (`/ao-auto`) to work through the assigned issues.")
    lines.append("This activates autonomous work mode for NORMAL/HIGH confidence issues.\n")

    ctx = worker_info.get("context", "")
    instr = worker_info.get("instructions", "")
    if ctx:
        lines.append(f"## Context\n\n{ctx}\n")
    if instr:
        lines.append(f"## Instructions\n\n{instr}\n")

    lines.append("## Assigned Issues\n")
    for iid in issue_ids:
        lines.append(f"### {iid}\n")
        try:
            info: dict[str, Any] = client.get(iid)  # type: ignore[assignment]
            title = info.get("title", "")
            notes = info.get("notes", "")
            status = info.get("status", "")
            priority = info.get("priority", "")
            lines.append(f"- **Title:** {title}")
            lines.append(f"- **Status:** {status}")
            lines.append(f"- **Priority:** {priority}\n")
            if notes:
                lines.append(f"{notes}\n")
        except Exception:  # noqa: BLE001
            lines.append(f"(Could not fetch details for {iid})\n")

    lines.append("Work through these issues using `/ao-auto`.")
    lines.append("Commit progress as you go.\n")

    ca = worker_info.get("completion_action", "close")
    lines.append("## Completion\n")
    lines.append(
        f"When all work is done and tests pass, run: `ao complete <issue_id> --action {ca}`\n"
    )

    prompt_path = dispatch_dir / "prompt.md"
    prompt_path.write_text("\n".join(lines), encoding="utf-8")
    return prompt_path


@router.get("/workers")
async def list_workers(request: Request) -> JSONResponse:
    """List all registered workers."""
    client = _client(request)
    workers = client.workers()
    return _ok({"workers": workers, "count": len(workers)})


@router.post("/workers")
async def add_worker(body: WorkerCreate, request: Request) -> JSONResponse:
    """Register a new worker."""
    client = _client(request)
    try:
        result = client.worker_add(
            body.name,
            body.engine,
            label=body.label,
            model=body.model,
            context=body.context,
            instructions=body.instructions,
            completion_action=body.completion_action,
        )
    except ValidationError as exc:
        return _err("VALIDATION", str(exc))
    return _ok(result, status_code=201)


@router.get("/workers/{name}")
async def get_worker(name: str, request: Request) -> JSONResponse:
    """Get a single worker."""
    client = _client(request)
    try:
        result = client.worker_get(name)
    except ValidationError as exc:
        return _err("VALIDATION", str(exc), status_code=404)
    return _ok(result)


@router.put("/workers/{name}")
async def update_worker(name: str, body: WorkerUpdate, request: Request) -> JSONResponse:
    """Update worker fields."""
    client = _client(request)
    fields: dict[str, str] = {}
    if body.label is not None:
        fields["label"] = body.label
    if body.model is not None:
        fields["model"] = body.model
    if body.context is not None:
        fields["context"] = body.context
    if body.instructions is not None:
        fields["instructions"] = body.instructions
    if body.engine is not None:
        fields["engine"] = body.engine
    if body.completion_action is not None:
        fields["completion_action"] = body.completion_action
    if not fields:
        return _err("BAD_REQUEST", "No fields to update")
    try:
        result = client.worker_update(name, **fields)
    except ValidationError as exc:
        sc = 404 if "not found" in str(exc).lower() else 400
        return _err("VALIDATION", str(exc), status_code=sc)
    return _ok(result)


@router.delete("/workers/{name}")
async def remove_worker(name: str, request: Request) -> JSONResponse:
    """Remove a registered worker."""
    client = _client(request)
    try:
        result = client.worker_remove(name)
    except ValidationError as exc:
        return _err("VALIDATION", str(exc), status_code=404)
    return _ok(result)


@router.post("/workers/{name}/assign")
async def assign_worker(name: str, body: WorkerAssign, request: Request) -> JSONResponse:
    """Assign a worker to an issue."""
    client = _client(request)
    try:
        result = client.worker_assign(body.issue_id, name)
    except ValidationError as exc:
        return _err("VALIDATION", str(exc))

    from ao.web.api.ws import broadcast_update

    await broadcast_update("issue.updated", {"issue_id": body.issue_id})
    return _ok(result)


@router.post("/workers/{name}/bulk-assign")
async def bulk_assign_worker(name: str, body: BulkAssign, request: Request) -> JSONResponse:
    """Assign a worker to multiple issues at once."""
    client = _client(request)
    if not body.issue_ids:
        return _err("BAD_REQUEST", "No issue IDs provided")
    results: list[dict[str, Any]] = []
    errors: list[str] = []
    for iid in body.issue_ids:
        try:
            r = client.worker_assign(iid, name)
            results.append(r)
        except (ValidationError, Exception) as exc:  # noqa: BLE001
            errors.append(f"{iid}: {exc}")

    from ao.web.api.ws import broadcast_update

    for iid in body.issue_ids:
        await broadcast_update("issue.updated", {"issue_id": iid})
    return _ok({"assigned": len(results), "errors": errors, "worker": name})


@router.post("/worktree/dispatch")
async def worktree_dispatch(body: WorktreeDispatch, request: Request) -> JSONResponse:
    """Create a git worktree and assign filtered issues to a worker."""
    client = _client(request)
    if not body.issue_ids:
        return _err("BAD_REQUEST", "No issue IDs provided")
    if not body.worker_name:
        return _err("BAD_REQUEST", "No worker specified")

    # Validate worker exists and capture details for prompt
    try:
        worker_info = client.worker_get(body.worker_name)
    except ValidationError as exc:
        return _err("VALIDATION", str(exc), status_code=404)

    # Create worktree via CLI internals
    from ao._internal.commands.worktree import (
        _current_branch,
        _ensure_config,
        _git_available,
        _is_git_repo,
        _open_editor,
        _resolve_worktree_path,
    )
    from ao._internal.context import AppContext

    if not _git_available():
        return _err("VALIDATION", "git is not available on PATH")
    if not _is_git_repo():
        return _err("VALIDATION", "Not inside a git repository")

    ctx = AppContext(root=request.app.state.paths.root, yes=True)
    config = _ensure_config(ctx)
    if config is None:
        return _err("VALIDATION", "Config creation failed")

    branch = body.branch_name or f"wt/{body.worker_name}"
    source = _current_branch()
    wt_path = _resolve_worktree_path(config, branch)

    import subprocess

    cmd: list[str] = ["git", "worktree", "add", "-b", branch, str(wt_path)]
    try:
        subprocess.run(cmd, check=True, capture_output=True, text=True)  # noqa: S603
    except subprocess.CalledProcessError as exc:
        return _err("VALIDATION", f"git worktree add failed: {exc.stderr.strip()}")

    # Bulk assign issues to the worker
    assigned = 0
    assign_errors: list[str] = []
    for iid in body.issue_ids:
        try:
            client.worker_assign(iid, body.worker_name)
            assigned += 1
        except (ValidationError, Exception) as exc:  # noqa: BLE001
            assign_errors.append(f"{iid}: {exc}")

    # Write dispatch config so tools in the worktree know the assignment
    import json
    from pathlib import Path

    dispatch_dir = Path(wt_path) / ".ao"
    dispatch_dir.mkdir(parents=True, exist_ok=True)
    dispatch_cfg = {
        "worker": body.worker_name,
        "branch": branch,
        "source": source,
        "issue_ids": body.issue_ids,
        "completion_action": body.completion_action or worker_info.get("completion_action", "close"),
    }
    (dispatch_dir / "dispatch.json").write_text(
        json.dumps(dispatch_cfg, indent=2) + "\n",
        encoding="utf-8",
    )

    # Build prompt file for CLI tools with issue context
    prompt_file = _build_prompt_file(
        dispatch_dir,
        worker_info,
        body.issue_ids,
        client,
    )

    # Launch editor / agent CLI in the worktree
    launched_with = ""
    if body.launch_with:
        launched_with = _open_editor(
            config,
            Path(wt_path),
            launch_with=body.launch_with,
            prompt_file=prompt_file,
        )

    from ao.web.api.ws import broadcast_update

    for iid in body.issue_ids:
        await broadcast_update("issue.updated", {"issue_id": iid})

    return _ok(
        {
            "worktree_path": str(wt_path),
            "branch": branch,
            "source": source,
            "worker": body.worker_name,
            "assigned": assigned,
            "issue_count": len(body.issue_ids),
            "errors": assign_errors,
            "launched_with": launched_with,
        },
        status_code=201,
    )
