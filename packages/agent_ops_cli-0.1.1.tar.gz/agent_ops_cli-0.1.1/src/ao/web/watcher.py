"""File watcher for JSONL file changes — broadcasts via WebSocket."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Any

from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer

if TYPE_CHECKING:
    from ao.store import AOPaths


class _JsonlHandler(FileSystemEventHandler):
    """Watches for changes to events.jsonl / active.jsonl."""

    def __init__(self, loop: asyncio.AbstractEventLoop) -> None:
        self._loop = loop

    def on_modified(self, event: object) -> None:
        src = getattr(event, "src_path", "")
        if src.endswith(".jsonl"):
            from pathlib import Path

            from ao.web.api.ws import broadcast_update

            asyncio.run_coroutine_threadsafe(
                broadcast_update("issues.updated", {"file": Path(src).name}),
                self._loop,
            )


def start_watcher(paths: AOPaths, loop: asyncio.AbstractEventLoop) -> Any:
    """Start a watchdog observer on the issues directory."""
    handler = _JsonlHandler(loop)
    observer = Observer()
    watch_dir = str(paths.events_path.parent)
    observer.schedule(handler, watch_dir, recursive=False)
    observer.start()
    return observer
