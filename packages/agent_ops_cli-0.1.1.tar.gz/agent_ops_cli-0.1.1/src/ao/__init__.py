"""AO — Agent Ops Issues: high-performance JSONL issue/event store."""

__version__ = "0.1.0"
