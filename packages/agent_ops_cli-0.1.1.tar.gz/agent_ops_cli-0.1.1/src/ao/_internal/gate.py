"""AO gate — deterministic AO completion gate checker."""

from __future__ import annotations

import json
from typing import Any

from ao._internal.context import AppContext
from ao._internal.io import iter_jsonl_bytes
from ao.codec import MsgspecCodec

_TERMINAL: frozenset[str] = frozenset({"done", "cancelled", "dropped"})


def _load_focus_data(ctx: AppContext) -> dict[str, Any]:
    """Load focus.json returning empty dict if absent.

    Args:
        ctx: Resolved application context.

    Returns:
        Parsed focus dict or empty dict.
    """
    path = ctx.root / "focus.json"
    if not path.exists():
        return {}
    data: dict[str, Any] = json.loads(path.read_text(encoding="utf-8"))
    return data


def _find_issue_data(ctx: AppContext, issue_id: str) -> dict[str, Any] | None:
    """Return a minimal issue dict from active.jsonl, or None if not found.

    Args:
        ctx: Resolved application context.
        issue_id: Full issue ID to look up.

    Returns:
        Dict with id, status, depends_on, or None if absent.
    """
    if not ctx.active_path.exists():
        return None
    codec = MsgspecCodec()
    for line in iter_jsonl_bytes(ctx.active_path):
        if b'"_meta"' in line:
            continue
        try:
            issue = codec.decode_issue(line)
            if issue.id == issue_id:
                return {
                    "id": issue.id,
                    "status": str(issue.status),
                    "depends_on": list(issue.dependencies.depends_on or []),
                }
        except Exception:  # noqa: BLE001,S112
            continue
    return None


def _collect_issue_reasons(ctx: AppContext, issue_id: str) -> list[str]:
    """Return gate-failure reasons for the given issue.

    Args:
        ctx: Resolved application context.
        issue_id: Issue ID to check.

    Returns:
        List of human-readable reason strings (empty = issue passes gate).
    """
    issue = _find_issue_data(ctx, issue_id)
    if issue is None:
        return [f"Issue {issue_id} not found in active store"]
    reasons: list[str] = []
    if issue["status"] not in _TERMINAL:
        reasons.append(f"Status is '{issue['status']}', not done")
    for dep_id in issue["depends_on"]:
        dep = _find_issue_data(ctx, dep_id)
        if dep is None or dep["status"] not in _TERMINAL:
            reasons.append(f"Blocker {dep_id} is not done")
    return reasons


def _validate_reasons(ctx: AppContext, timeout: int) -> list[str]:
    """Run validate_all and return failure reason strings.

    Args:
        ctx: Resolved application context.
        timeout: Per-command timeout in seconds.

    Returns:
        List of validation failure reason strings.
    """
    from ao._internal.validate import validate_all

    result = validate_all(ctx.root, timeout=timeout)
    if result.get("ok"):
        return []
    return [f"Validation failed: {r['cmd']}" for r in result.get("results", []) if not r.get("ok")]


def _next_cmds(reasons: list[str], issue_id: str) -> list[str]:
    """Suggest next CLI commands based on gate-failure reasons.

    Args:
        reasons: List of gate failure reason strings.
        issue_id: Current issue ID for context.

    Returns:
        List of recommended command strings.
    """
    joined = " ".join(reasons)
    if "not found" in joined:
        return ["ao ls --status in_progress"]
    if "not done" in joined and issue_id:
        return [f"ao issue show {issue_id}"]
    if "Validation" in joined:
        return ["uv run pytest -q", "uv run ruff check ."]
    return []


def check_gate(
    ctx: AppContext,
    issue_id: str | None = None,
    *,
    run_validate: bool = True,
    validate_timeout: int = 60,
) -> dict[str, Any]:
    """Check all AO completion gates for the current or specified issue.

    Gates checked: issue exists, status is terminal, no open blockers,
    and (if run_validate) all configured validation commands pass.

    Args:
        ctx: Resolved application context.
        issue_id: Issue to check; uses focus.json doing_now.issue_id if None.
        run_validate: If True, also run configured validation commands.
        validate_timeout: Per-command timeout for validation runs.

    Returns:
        Dict with state (done|continue|blocked), reasons, issue_id, next fields.
    """
    focus = _load_focus_data(ctx)
    eid = issue_id or (focus.get("doing_now") or {}).get("issue_id") or ""
    if not eid:
        return {
            "state": "blocked",
            "reasons": ["No current issue in focus.json"],
            "issue_id": "",
            "next": {"recommended_commands": ["ao focus set-doing ISSUE_ID"]},
        }
    reasons = _collect_issue_reasons(ctx, eid)
    if run_validate:
        reasons.extend(_validate_reasons(ctx, validate_timeout))
    state = "done" if not reasons else "continue"
    return {
        "state": state,
        "reasons": reasons,
        "issue_id": eid,
        "next": {"recommended_commands": _next_cmds(reasons, eid)},
    }
