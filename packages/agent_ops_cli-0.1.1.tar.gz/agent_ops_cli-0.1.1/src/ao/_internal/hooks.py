"""AO git hooks — install/uninstall hooks that auto-rebuild and protect events.jsonl."""

from __future__ import annotations

import stat
from pathlib import Path
from typing import Any

# ── hook script templates ─────────────────────────────────────────────────────

_POST_MERGE_HOOK = """\
#!/usr/bin/env sh
# AO: rebuild active.jsonl after merge
set -e
if command -v ao >/dev/null 2>&1; then
    ao rebuild
fi
"""

_POST_CHECKOUT_HOOK = """\
#!/usr/bin/env sh
# AO: rebuild active.jsonl after checkout
set -e
if command -v ao >/dev/null 2>&1; then
    ao rebuild
fi
"""

_PRE_PUSH_HOOK = """\
#!/usr/bin/env sh
# AO: block push if events.jsonl has uncommitted changes
if git diff --name-only HEAD 2>/dev/null | grep -q 'events\\.jsonl'; then
    echo "AO: events.jsonl has uncommitted changes. Commit before pushing." >&2
    exit 1
fi
"""

_HOOK_TEMPLATES: dict[str, str] = {
    "post-merge": _POST_MERGE_HOOK,
    "post-checkout": _POST_CHECKOUT_HOOK,
    "pre-push": _PRE_PUSH_HOOK,
}

_AO_MARKER = "# AO:"


def _find_git_dir(start: Path) -> Path | None:
    """Walk up from start to find the .git directory."""
    for parent in (start, *start.parents):
        candidate = parent / ".git"
        if candidate.is_dir():
            return candidate
    return None


def _is_ao_hook(path: Path) -> bool:
    """Return True if the hook was installed by AO (contains marker)."""
    if not path.exists():
        return False
    try:
        return _AO_MARKER in path.read_text()
    except OSError:
        return False


def hooks_install(start: Path, *, force: bool = False) -> dict[str, Any]:
    """Install AO git hooks into the nearest .git/hooks/ directory.

    Args:
        start: Directory to start searching for .git from.
        force: Overwrite existing non-AO hooks.

    Returns:
        Dict with installed/skipped/hooks_dir keys.
    """
    git_dir = _find_git_dir(start)
    if git_dir is None:
        return {"ok": False, "error": "No .git directory found"}
    hooks_dir = git_dir / "hooks"
    hooks_dir.mkdir(exist_ok=True)
    installed: list[str] = []
    skipped: list[str] = []
    for name, content in _HOOK_TEMPLATES.items():
        hook_path = hooks_dir / name
        if hook_path.exists() and not _is_ao_hook(hook_path) and not force:
            skipped.append(name)
            continue
        hook_path.write_text(content)
        hook_path.chmod(hook_path.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)
        installed.append(name)
    return {"ok": True, "installed": installed, "skipped": skipped, "hooks_dir": str(hooks_dir)}


def hooks_uninstall(start: Path) -> dict[str, Any]:
    """Remove AO-installed git hooks.

    Returns:
        Dict with removed/skipped keys.
    """
    git_dir = _find_git_dir(start)
    if git_dir is None:
        return {"ok": False, "error": "No .git directory found"}
    hooks_dir = git_dir / "hooks"
    removed: list[str] = []
    skipped: list[str] = []
    for name in _HOOK_TEMPLATES:
        hook_path = hooks_dir / name
        if _is_ao_hook(hook_path):
            hook_path.unlink()
            removed.append(name)
        else:
            skipped.append(name)
    return {"ok": True, "removed": removed, "skipped": skipped}


def hooks_status(start: Path) -> dict[str, Any]:
    """Return status of AO hooks in the nearest .git/hooks/ directory."""
    git_dir = _find_git_dir(start)
    if git_dir is None:
        return {"ok": False, "error": "No .git directory found"}
    hooks_dir = git_dir / "hooks"
    hooks_info: dict[str, Any] = {}
    for name in _HOOK_TEMPLATES:
        hook_path = hooks_dir / name
        hooks_info[name] = {
            "exists": hook_path.exists(),
            "ao_installed": _is_ao_hook(hook_path),
        }
    return {"ok": True, "hooks": hooks_info, "hooks_dir": str(hooks_dir)}
