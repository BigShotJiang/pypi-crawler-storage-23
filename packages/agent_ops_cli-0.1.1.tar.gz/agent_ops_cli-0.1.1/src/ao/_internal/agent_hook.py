"""AO agent hook engine — normalize payloads, apply AO rules, emit decisions.

Supports Claude Code, GitHub Copilot/VS Code, and OpenCode hook systems.
Reads JSON from stdin, applies the matching AO rule, writes decision to stdout.
"""

from __future__ import annotations

import re
from typing import Any

from ao._internal.context import AppContext
from ao._internal.gate import check_gate

# ── deny lists (Rule B) ───────────────────────────────────────────────────────

_DENY_PATH_RE: list[re.Pattern[str]] = [
    re.compile(r"(?i)(^|[/\\])(\.env(\..+)?|.*\.pem|.*\.key|.*\.p12|secrets[/\\])"),
    re.compile(r"(?i)(events\.jsonl|active\.jsonl)(\.tmp)?$"),
]

_DENY_CMD_RE: list[re.Pattern[str]] = [
    re.compile(r"git\s+push\s+(.*\s+)?(-f|--force)"),
    re.compile(r"\brm\s+(-[a-z]*\s+)*-[a-z]*r[a-z]*\s+"),
    re.compile(r"\bdrop\s+database\b", re.IGNORECASE),
]

# ── payload normalization ─────────────────────────────────────────────────────


def _normalize_claude(event: str, payload: dict[str, Any]) -> dict[str, Any]:
    """Normalize a Claude Code hook payload to common schema."""
    return {
        "engine": "claude",
        "event": event,
        "tool_name": payload.get("tool_name") or payload.get("name", ""),
        "tool_input": payload.get("tool_input") or payload.get("input") or {},
        "tool_result": payload.get("tool_response") or {},
        "session_id": str(payload.get("session_id", "")),
        "cwd": str(payload.get("cwd", "")),
    }


def _normalize_copilot(event: str, payload: dict[str, Any]) -> dict[str, Any]:
    """Normalize a Copilot/VS Code hook payload to common schema."""
    data: dict[str, Any] = payload.get("data") or payload
    return {
        "engine": "copilot",
        "event": event,
        "tool_name": str(data.get("toolName") or data.get("tool_name", "")),
        "tool_input": data.get("input") or data.get("toolInput") or {},
        "tool_result": data.get("output") or {},
        "session_id": str(payload.get("sessionId", "")),
        "cwd": str(payload.get("cwd", "")),
    }


def _normalize_opencode(event: str, payload: dict[str, Any]) -> dict[str, Any]:
    """Normalize an OpenCode plugin event payload to common schema."""
    data: dict[str, Any] = payload.get("data") or payload
    tool_info: dict[str, Any] = data.get("tool") or {}
    return {
        "engine": "opencode",
        "event": event,
        "tool_name": str(tool_info.get("tool", "")),
        "tool_input": tool_info.get("input") or {},
        "tool_result": data.get("output") or {},
        "session_id": str(payload.get("sessionID", "")),
        "cwd": str(payload.get("cwd", "")),
    }


def normalize_payload(engine: str, event: str, payload: dict[str, Any]) -> dict[str, Any]:
    """Normalize an engine-specific hook payload to the common AO schema.

    Args:
        engine: Engine identifier: claude | copilot | vscode | opencode.
        event: Event name from the engine's hook system.
        payload: Raw hook payload dict.

    Returns:
        Normalized dict with engine, event, tool_name, tool_input, tool_result,
        session_id, and cwd fields.
    """
    if engine == "claude":
        return _normalize_claude(event, payload)
    if engine in ("copilot", "vscode"):
        return _normalize_copilot(event, payload)
    return _normalize_opencode(event, payload)


# ── Rule B: PreToolUse policy gate ────────────────────────────────────────────


def _path_is_denied(path_str: str) -> bool:
    """Return True if the path matches any deny pattern."""
    return any(p.search(path_str) for p in _DENY_PATH_RE)


def _cmd_is_denied(cmd: str) -> bool:
    """Return True if the command matches any deny pattern."""
    return any(p.search(cmd) for p in _DENY_CMD_RE)


def _check_tool_paths(inp: dict[str, Any]) -> str | None:
    """Return a denial reason if any tool input path is denied, else None."""
    for key in ("path", "file_path", "target", "paths"):
        val = inp.get(key)
        items = val if isinstance(val, list) else ([val] if val else [])
        for item in items:
            if item and _path_is_denied(str(item)):
                return f"Denied path: {item}"
    return None


def apply_policy_rule(normalized: dict[str, Any]) -> dict[str, Any] | None:
    """Apply Rule B: PreToolUse policy — block dangerous or protected operations.

    Args:
        normalized: Common-schema normalized payload.

    Returns:
        Block decision dict with action and reason, or None to allow.
    """
    inp: dict[str, Any] = normalized.get("tool_input") or {}
    path_denial = _check_tool_paths(inp)
    if path_denial:
        return {"action": "block", "reason": f"{path_denial}. Use the ao CLI for AO data."}
    for key in ("command", "cmd", "shell"):
        cmd = inp.get(key)
        if cmd and _cmd_is_denied(str(cmd)):
            return {"action": "block", "reason": f"Denied command: {cmd}"}
    return None


# ── Rule C: PostToolUse audit log ─────────────────────────────────────────────


def _extract_changed_files(inp: dict[str, Any]) -> list[str]:
    """Extract changed file paths from tool input dict."""
    files: list[str] = []
    for key in ("path", "file_path", "paths"):
        val = inp.get(key)
        if isinstance(val, list):
            files.extend(str(p) for p in val)
        elif val:
            files.append(str(val))
    return files


def build_audit_entry(normalized: dict[str, Any]) -> dict[str, Any]:
    """Build a structured audit log entry from a normalized PostToolUse payload.

    Args:
        normalized: Common-schema normalized payload.

    Returns:
        Audit entry dict with kind, tool, files, ok, engine, session_id.
    """
    result: dict[str, Any] = normalized.get("tool_result") or {}
    return {
        "kind": "tool_used",
        "tool": normalized.get("tool_name", "unknown"),
        "files": _extract_changed_files(normalized.get("tool_input") or {}),
        "ok": not result.get("is_error", False),
        "engine": normalized.get("engine", ""),
        "session_id": normalized.get("session_id", ""),
    }


def apply_audit_rule(ctx: AppContext, normalized: dict[str, Any]) -> None:
    """Apply Rule C: PostToolUse audit — silently append evidence to current issue.

    Reads the current issue ID from focus.json doing_now.issue_id and appends
    a structured log entry. No-ops if no issue is active.

    Args:
        ctx: Resolved application context.
        normalized: Common-schema normalized payload.
    """
    import json as _json

    from ao._internal.commands.focus import _load_focus
    from ao._internal.commands.issue import log_append_silent

    focus = _load_focus(ctx)
    if not focus:
        return
    issue_id: str = (focus.get("doing_now") or {}).get("issue_id", "")
    if not issue_id:
        return
    entry = build_audit_entry(normalized)
    log_append_silent(ctx, issue_id, _json.dumps(entry))


# ── Rule D: Stop gate ─────────────────────────────────────────────────────────


def apply_stop_gate_rule(ctx: AppContext) -> dict[str, Any] | None:
    """Apply Rule D: Stop gate — run ao gate and block stop if not done.

    Args:
        ctx: Resolved application context.

    Returns:
        Block decision dict if gate fails, or None to allow stop.
    """
    gate = check_gate(ctx, run_validate=True, validate_timeout=30)
    if gate.get("state") == "done":
        return None
    reasons = gate.get("reasons") or ["Gate not passed"]
    next_cmds = (gate.get("next") or {}).get("recommended_commands") or []
    return {
        "action": "block",
        "reason": "AO gate not passed: " + "; ".join(reasons),
        "next": next_cmds,
        "gate": gate,
    }


# ── Rule A: SessionStart context injection ───────────────────────────────────

_SESSION_START_EVENTS: frozenset[str] = frozenset(
    {"SessionStart", "sessionStart", "session.start", "session.created", "session_start"}
)


def _load_ready_issues(ctx: AppContext) -> list[dict[str, Any]]:
    """Return up to 5 non-terminal, non-blocked issues from active.jsonl."""
    if not ctx.active_path.exists():
        return []
    from ao._internal.io import iter_jsonl_bytes
    from ao.codec import MsgspecCodec

    codec = MsgspecCodec()
    _SKIP = frozenset({"done", "cancelled", "dropped", "blocked"})
    ready: list[dict[str, Any]] = []
    for line in iter_jsonl_bytes(ctx.active_path):
        if b'"_meta"' in line or len(ready) >= 5:
            continue
        try:
            issue = codec.decode_issue(line)
            if str(issue.status) not in _SKIP:
                ready.append({"id": issue.id, "title": issue.title, "status": str(issue.status)})
        except Exception:  # noqa: BLE001,S112
            continue
    return ready


def build_session_context(ctx: AppContext) -> dict[str, Any]:
    """Build AO focus context for injection at session start.

    Args:
        ctx: Resolved application context.

    Returns:
        Dict with current_issue, ready_issues, and focus_summary.
    """
    from ao._internal.commands.focus import _load_focus

    focus = _load_focus(ctx) or {}
    doing: dict[str, Any] = focus.get("doing_now") or {}
    issue_id: str = doing.get("issue_id", "")
    task: str = doing.get("task", "")
    return {
        "current_issue": {"id": issue_id, "task": task} if issue_id else None,
        "ready_issues": _load_ready_issues(ctx),
        "focus_summary": f"Working on {issue_id}: {task}" if issue_id else "No active issue",
    }


def apply_context_rule(ctx: AppContext) -> dict[str, Any]:
    """Apply Rule A: SessionStart context injection — inject AO focus state.

    Args:
        ctx: Resolved application context.

    Returns:
        Allow decision dict with context payload.
    """
    return {"action": "allow", "context": build_session_context(ctx)}


# ── Rule E: SessionEnd rebuild ────────────────────────────────────────────────

_SESSION_END_EVENTS: frozenset[str] = frozenset(
    {"SessionEnd", "sessionEnd", "session.end", "session.idle", "SubagentResult"}
)


def apply_session_end_rule(ctx: AppContext) -> None:
    """Apply Rule E: SessionEnd — rebuild active.jsonl after session closes.

    Args:
        ctx: Resolved application context.
    """
    from ao._internal.rebuild import rebuild
    from ao.codec import MsgspecCodec

    try:
        rebuild(ctx.events_path, ctx.active_path, MsgspecCodec(), show_progress=False)
    except Exception:  # noqa: BLE001,S110
        pass


# ── event dispatch sets ───────────────────────────────────────────────────────

_PRE_TOOL_EVENTS: frozenset[str] = frozenset(
    {"PreToolUse", "preToolUse", "tool.before", "tool.execute.before", "pre_tool_use"}
)
_POST_TOOL_EVENTS: frozenset[str] = frozenset(
    {
        "PostToolUse",
        "postToolUse",
        "PostToolUseFailure",
        "tool.after",
        "tool.execute.after",
        "post_tool_use",
    }
)
_STOP_EVENTS: frozenset[str] = frozenset({"Stop", "SubagentStop", "stop", "session.stop"})


# ── main dispatcher ───────────────────────────────────────────────────────────


def run_hook(
    ctx: AppContext,
    engine: str,
    event: str,
    raw: dict[str, Any],
) -> dict[str, Any]:
    """Normalize hook payload, apply the matching AO rule, and return a decision.

    Args:
        ctx: Resolved application context.
        engine: Engine identifier (claude|copilot|vscode|opencode).
        event: Event name from the engine's hook system.
        raw: Raw hook payload dict (parsed from stdin JSON).

    Returns:
        Decision dict with action (allow|block), reason, exit_code, engine, event.
    """
    normalized = normalize_payload(engine, event, raw)
    decision: dict[str, Any] | None = None
    if event in _PRE_TOOL_EVENTS:
        decision = apply_policy_rule(normalized)
    elif event in _POST_TOOL_EVENTS:
        apply_audit_rule(ctx, normalized)
    elif event in _STOP_EVENTS:
        decision = apply_stop_gate_rule(ctx)
    elif event in _SESSION_START_EVENTS:
        decision = apply_context_rule(ctx)
    elif event in _SESSION_END_EVENTS:
        apply_session_end_rule(ctx)
    if decision is None:
        return {"action": "allow", "exit_code": 0, "engine": engine, "event": event}
    exit_code = 2 if decision.get("action") == "block" else 0
    return {**decision, "exit_code": exit_code, "engine": engine, "event": event}


def format_decision(engine: str, decision: dict[str, Any]) -> dict[str, Any]:
    """Format decision using engine-specific output schema.

    Args:
        engine: Engine identifier.
        decision: Decision dict from run_hook.

    Returns:
        Engine-formatted dict (empty dict = allow, no output needed).
    """
    if decision.get("action") != "block":
        ctx_data = decision.get("context")
        if ctx_data is not None:
            return {"context": ctx_data}
        return {}
    reason = str(decision.get("reason", "Blocked by AO policy"))
    if engine in ("vscode", "copilot"):
        return {"decision": "block", "reason": reason}
    if engine == "claude":
        return {"decision": "block", "reason": reason, "suppress_output": False}
    return {"allowed": False, "reason": reason}
