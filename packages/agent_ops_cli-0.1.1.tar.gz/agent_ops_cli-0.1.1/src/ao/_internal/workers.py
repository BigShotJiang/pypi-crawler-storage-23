"""Worker registry — manage named workers with engine types."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

import msgspec

_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9\-]{0,62}$")
VALID_ENGINES = frozenset({"claude", "copilot", "opencode"})
VALID_COMPLETION_ACTIONS = frozenset({"none", "close", "review", "commit", "pull_request"})


class Worker(msgspec.Struct, frozen=True):
    """A registered worker agent."""

    engine: str
    label: str = ""
    model: str = ""
    context: str = ""
    instructions: str = ""
    completion_action: str = "close"


class WorkerRegistry(msgspec.Struct):
    """Top-level workers.json structure."""

    workers: dict[str, Worker] = {}


_encoder = msgspec.json.Encoder()
_decoder = msgspec.json.Decoder(WorkerRegistry)


def _validate_name(name: str) -> None:
    """Raise ValueError if name is not valid."""
    if not _NAME_RE.match(name):
        msg = f"Invalid worker name: {name!r}. Must be lowercase alphanumeric/hyphens, 1-63 chars."
        raise ValueError(msg)


def _validate_engine(engine: str) -> None:
    """Raise ValueError if engine is not supported."""
    if engine not in VALID_ENGINES:
        msg = f"Invalid engine: {engine!r}. Valid: {', '.join(sorted(VALID_ENGINES))}"
        raise ValueError(msg)


def _validate_completion_action(action: str) -> None:
    """Raise ValueError if completion_action is not valid."""
    if action not in VALID_COMPLETION_ACTIONS:
        msg = f"Invalid completion_action: {action!r}. Valid: {', '.join(sorted(VALID_COMPLETION_ACTIONS))}"
        raise ValueError(msg)


def load_registry(path: Path) -> WorkerRegistry:
    """Load worker registry from workers.json, returning empty if missing."""
    if not path.exists():
        return WorkerRegistry()
    return _decoder.decode(path.read_bytes())


def save_registry(path: Path, registry: WorkerRegistry) -> None:
    """Write worker registry to workers.json."""
    path.write_bytes(_encoder.encode(registry))


def add_worker(
    path: Path,
    name: str,
    engine: str,
    *,
    label: str = "",
    model: str = "",
    context: str = "",
    instructions: str = "",
    completion_action: str = "close",
) -> dict[str, Any]:
    """Add a worker to the registry. Returns result dict."""
    _validate_name(name)
    _validate_engine(engine)
    _validate_completion_action(completion_action)
    reg = load_registry(path)
    if name in reg.workers:
        msg = f"Worker already exists: {name!r}"
        raise ValueError(msg)
    w = Worker(
        engine=engine,
        label=label,
        model=model,
        context=context,
        instructions=instructions,
        completion_action=completion_action,
    )
    reg.workers[name] = w
    save_registry(path, reg)
    return _worker_dict(name, w)


def remove_worker(path: Path, name: str) -> dict[str, Any]:
    """Remove a worker from the registry. Returns result dict."""
    reg = load_registry(path)
    if name not in reg.workers:
        msg = f"Worker not found: {name!r}"
        raise ValueError(msg)
    del reg.workers[name]
    save_registry(path, reg)
    return {"name": name, "removed": True}


def get_worker(path: Path, name: str) -> dict[str, Any]:
    """Get a single worker by name. Raises ValueError if not found."""
    reg = load_registry(path)
    if name not in reg.workers:
        msg = f"Worker not found: {name!r}"
        raise ValueError(msg)
    return _worker_dict(name, reg.workers[name])


def update_worker(path: Path, name: str, **fields: str) -> dict[str, Any]:
    """Update worker fields. Raises ValueError if not found."""
    reg = load_registry(path)
    if name not in reg.workers:
        msg = f"Worker not found: {name!r}"
        raise ValueError(msg)
    w = reg.workers[name]
    kw = {"engine": w.engine, "label": w.label, "model": w.model}
    kw.update({"context": w.context, "instructions": w.instructions})
    kw["completion_action"] = w.completion_action
    for k, v in fields.items():
        if k == "engine":
            _validate_engine(v)
        if k == "completion_action":
            _validate_completion_action(v)
        if k in kw:
            kw[k] = v
    reg.workers[name] = Worker(**kw)
    save_registry(path, reg)
    return _worker_dict(name, reg.workers[name])


def list_workers(path: Path) -> list[dict[str, Any]]:
    """Return all workers as a list of dicts."""
    reg = load_registry(path)
    return [_worker_dict(n, w) for n, w in sorted(reg.workers.items())]


def _worker_dict(name: str, w: Worker) -> dict[str, Any]:
    """Convert a Worker to a dict with name included."""
    return {
        "name": name,
        "engine": w.engine,
        "label": w.label,
        "model": w.model,
        "context": w.context,
        "instructions": w.instructions,
        "completion_action": w.completion_action,
    }
