"""AO import — ingest events from external sources with collision/orphan handling."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import msgspec

from ao._internal.io import append_jsonl, iter_jsonl_bytes


def _parse_events_from_path(path: Path) -> list[dict[str, Any]]:
    """Parse valid events from a JSONL file (non-strict)."""
    events: list[dict[str, Any]] = []
    for raw in iter_jsonl_bytes(path):
        if b'"_meta"' in raw:
            continue
        try:
            evt: dict[str, Any] = msgspec.json.decode(raw)
            if "event_id" in evt and "issue_id" in evt and "op" in evt:
                events.append(evt)
        except (msgspec.DecodeError, KeyError):
            continue
    return events


def _existing_ids(events_path: Path) -> set[str]:
    """Load set of existing event_ids to detect collisions."""
    if not events_path.exists():
        return set()
    ids: set[str] = set()
    for raw in iter_jsonl_bytes(events_path):
        if b'"event_id"' in raw:
            try:
                evt: dict[str, Any] = msgspec.json.decode(raw)
                eid = evt.get("event_id")
                if eid:
                    ids.add(str(eid))
            except msgspec.DecodeError:
                continue
    return ids


def _existing_issue_ids(events_path: Path) -> set[str]:
    """Return set of all issue_ids that have been created in events."""
    if not events_path.exists():
        return set()
    issue_ids: set[str] = set()
    for raw in iter_jsonl_bytes(events_path):
        if b'"issue_id"' in raw:
            try:
                evt: dict[str, Any] = msgspec.json.decode(raw)
                iid = evt.get("issue_id")
                if iid:
                    issue_ids.add(str(iid))
            except msgspec.DecodeError:
                continue
    return issue_ids


def _apply_orphan_strategy(
    evt: dict[str, Any],
    strategy: str,
    known_issue_ids: set[str],
    tombstones: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    """Handle orphan events (events whose issue has no CREATE event yet).

    Returns list of events to emit (may be empty or include a tombstone).
    """
    issue_id = str(evt.get("issue_id", ""))
    if issue_id in known_issue_ids:
        return [evt]
    op = str(evt.get("op", ""))
    if op == "create":
        known_issue_ids.add(issue_id)
        return [evt]
    if strategy == "skip":
        return []
    if strategy == "strict":
        raise ValueError(f"Orphan event: issue {issue_id!r} has no CREATE event")
    if strategy == "resurrect" and issue_id not in tombstones:
        # Emit a synthetic CREATE tombstone for the missing issue
        tomb: dict[str, Any] = {
            "event_id": f"tomb-{issue_id.replace('@', '-')}",
            "issue_id": issue_id,
            "op": "create",
            "timestamp": str(evt.get("timestamp", "")),
            "payload": {
                "title": f"[Resurrected] {issue_id}",
                "type": "feat",
                "priority": "backlog",
            },
        }
        tombstones[issue_id] = tomb
        known_issue_ids.add(issue_id)
        return [tomb, evt]
    # allow strategy — import as-is
    known_issue_ids.add(issue_id)
    return [evt]


def import_events(
    events_path: Path,
    source: Path,
    *,
    dedupe: bool = True,
    orphan: str = "allow",
) -> dict[str, Any]:
    """Import events from *source* into *events_path*.

    Args:
        events_path: Target events.jsonl to append to.
        source: Source JSONL file containing events to import.
        dedupe: Skip events whose event_id already exists in target.
        orphan: Strategy for events whose issue has no CREATE: allow|skip|strict|resurrect.

    Returns:
        Dict with counts: imported, skipped_dupe, skipped_orphan, resurrected.
    """
    if orphan not in ("allow", "skip", "strict", "resurrect"):
        raise ValueError(f"Unknown orphan strategy: {orphan!r}")

    incoming = _parse_events_from_path(source)
    existing_ids = _existing_ids(events_path) if dedupe else set()
    known_issue_ids = _existing_issue_ids(events_path)
    tombstones: dict[str, dict[str, Any]] = {}
    encoder = msgspec.json.Encoder()

    imported = 0
    skipped_dupe = 0
    skipped_orphan = 0
    resurrected = 0

    events_path.parent.mkdir(parents=True, exist_ok=True)

    for evt in incoming:
        eid = str(evt.get("event_id", ""))
        if dedupe and eid in existing_ids:
            skipped_dupe += 1
            continue
        to_emit = _apply_orphan_strategy(evt, orphan, known_issue_ids, tombstones)
        if not to_emit:
            skipped_orphan += 1
            continue
        for e in to_emit:
            line = encoder.encode(e)
            append_jsonl(events_path, line)
            if str(e.get("event_id", "")).startswith("tomb-"):
                resurrected += 1
            else:
                imported += 1
            existing_ids.add(str(e.get("event_id", "")))

    return {
        "imported": imported,
        "skipped_dupe": skipped_dupe,
        "skipped_orphan": skipped_orphan,
        "resurrected": resurrected,
        "source": str(source),
        "target": str(events_path),
    }
