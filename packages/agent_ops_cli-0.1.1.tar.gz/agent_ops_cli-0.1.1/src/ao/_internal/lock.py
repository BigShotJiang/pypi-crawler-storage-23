"""Cross-platform exclusive file lock for events.jsonl (PID-based advisory lock)."""

from __future__ import annotations

import os
import sys
import time
from collections.abc import Generator
from contextlib import contextmanager
from pathlib import Path
from typing import Any

from ao.errors import LockError

_TIMEOUT: float = 10.0
_POLL: float = 0.05


def _lock_path(events_file: Path) -> Path:
    """Return the lock file path adjacent to events_file."""
    return events_file.parent / ".events.lock"


def _pid_alive(pid: int) -> bool:
    """Return True if the process with *pid* is still running."""
    if sys.platform == "win32":
        import ctypes

        SYNCHRONIZE = 0x00100000
        handle = ctypes.windll.kernel32.OpenProcess(SYNCHRONIZE, False, pid)
        if handle:
            ctypes.windll.kernel32.CloseHandle(handle)
            return True
        return False
    try:
        os.kill(pid, 0)
        return True
    except (ProcessLookupError, PermissionError):
        return False


def _try_create_lock(lock: Path) -> bool:
    """Atomically create lock file with current PID. Returns True if acquired."""
    try:
        fd = os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        try:
            os.write(fd, str(os.getpid()).encode())
        finally:
            os.close(fd)
        return True
    except FileExistsError:
        return False


def _clear_if_stale(lock: Path) -> None:
    """Remove lock file if the PID recorded in it is no longer alive."""
    try:
        pid = int(lock.read_text().strip())
        if not _pid_alive(pid):
            lock.unlink(missing_ok=True)
    except (ValueError, OSError):
        lock.unlink(missing_ok=True)


def acquire(events_file: Path, timeout: float = _TIMEOUT) -> None:
    """Acquire exclusive lock on *events_file*.

    Raises:
        LockError: if the lock cannot be acquired within *timeout* seconds.
    """
    lock = _lock_path(events_file)
    lock.parent.mkdir(parents=True, exist_ok=True)
    deadline = time.monotonic() + timeout
    while True:
        if _try_create_lock(lock):
            return
        _clear_if_stale(lock)
        if time.monotonic() >= deadline:
            raise LockError(f"Timeout acquiring lock on {events_file} after {timeout}s")
        time.sleep(_POLL)


def release(events_file: Path) -> None:
    """Release the lock (idempotent — safe to call even if not held)."""
    _lock_path(events_file).unlink(missing_ok=True)


def status(events_file: Path) -> dict[str, Any]:
    """Return a dict describing the current lock state.

    Returns:
        dict with keys: locked, path, and optionally pid/stale.
    """
    lock = _lock_path(events_file)
    if not lock.exists():
        return {"locked": False, "path": str(lock)}
    try:
        pid = int(lock.read_text().strip())
        alive = _pid_alive(pid)
        return {"locked": alive, "pid": pid, "stale": not alive, "path": str(lock)}
    except (ValueError, OSError):
        return {"locked": False, "stale": True, "path": str(lock)}


@contextmanager
def locked(events_file: Path, timeout: float = _TIMEOUT) -> Generator[None, None, None]:
    """Context manager: acquire on enter, release on exit (even on exception).

    Args:
        events_file: Path to the events.jsonl file being protected.
        timeout: Seconds to wait before raising LockError.
    """
    acquire(events_file, timeout)
    try:
        yield
    finally:
        release(events_file)
