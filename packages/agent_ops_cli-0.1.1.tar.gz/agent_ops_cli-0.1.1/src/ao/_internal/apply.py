"""AO apply — pure functions to apply events to issues."""

from __future__ import annotations

from datetime import UTC

from ao.models import (
    TERMINAL_STATUSES,
    AcceptanceCriterion,
    Dependencies,
    Event,
    Issue,
    LogEntry,
    Op,
    References,
    Scope,
)


class ApplyError(Exception):
    """Raised when an event cannot be applied."""


def apply_event(issue: Issue | None, event: Event) -> Issue | None:
    """Apply a single event to an issue, returning the updated issue."""
    handlers = {
        Op.CREATE: _handle_create,
        Op.SET: _handle_set,
        Op.SCOPE_SET: _handle_scope_set,
        Op.REQUIREMENTS_SET: _handle_requirements_set,
        Op.ACCEPTANCE_SET: _handle_acceptance_set,
        Op.ACCEPTANCE_ADD: _handle_acceptance_add,
        Op.ACCEPTANCE_RM: _handle_acceptance_rm,
        Op.ACCEPTANCE_CHECK: _handle_acceptance_check,
        Op.DEPS_SET: _handle_deps_set,
        Op.DEPS_ADD: _handle_deps_add,
        Op.DEPS_RM: _handle_deps_rm,
        Op.REF_SET: _handle_ref_set,
        Op.FILES_ADD: _handle_files_add,
        Op.LOG_APPEND: _handle_log_append,
        Op.CLOSE: _handle_close,
        Op.REOPEN: _handle_reopen,
        Op.TIME_LOG: _handle_time_log,
        Op.LABEL_ADD: _handle_label_add,
        Op.LABEL_RM: _handle_label_rm,
        Op.LINK_ADD: _handle_link_add,
        Op.LINK_RM: _handle_link_rm,
    }
    handler = handlers.get(event.op)
    if handler is None:
        msg = f"Unknown op: {event.op}"
        raise ApplyError(msg)
    return handler(issue, event)


def _require_issue(issue: Issue | None, op: Op) -> Issue:
    """Raise if issue is None for a non-create op."""
    if issue is None:
        msg = f"Cannot apply {op} to non-existent issue"
        raise ApplyError(msg)
    return issue


def _handle_create(issue: Issue | None, event: Event) -> Issue:
    """Create a new issue from event payload."""
    if issue is not None:
        msg = f"Issue {event.issue_id} already exists"
        raise ApplyError(msg)
    p = event.payload
    return Issue(
        id=event.issue_id,
        title=p.get("title", ""),
        type=p.get("type", "feat"),
        status=p.get("status", "todo"),
        priority=p.get("priority", "medium"),
        epic=p.get("epic", ""),
        owner=p.get("owner", "agent"),
        confidence=p.get("confidence", "normal"),
        created=event.timestamp,
        updated=event.timestamp,
    )


def _handle_set(issue: Issue | None, event: Event) -> Issue:
    """Apply partial scalar updates."""
    iss = _require_issue(issue, event.op)
    allowed = {
        "title",
        "type",
        "status",
        "priority",
        "epic",
        "owner",
        "confidence",
        "notes",
        "external_ref",
    }
    for key, val in event.payload.items():
        if key in allowed:
            object.__setattr__(iss, key, val)
    iss.updated = event.timestamp
    return iss


def _handle_scope_set(issue: Issue | None, event: Event) -> Issue:
    """Replace scope."""
    iss = _require_issue(issue, event.op)
    p = event.payload
    iss.scope = Scope(
        files_to_change=p.get("files_to_change", []),
        files_must_not_change=p.get("files_must_not_change", []),
    )
    iss.updated = event.timestamp
    return iss


def _handle_requirements_set(issue: Issue | None, event: Event) -> Issue:
    """Replace requirements list."""
    iss = _require_issue(issue, event.op)
    iss.requirements = event.payload.get("requirements", [])
    iss.updated = event.timestamp
    return iss


def _handle_acceptance_set(issue: Issue | None, event: Event) -> Issue:
    """Replace acceptance criteria."""
    iss = _require_issue(issue, event.op)
    raw = event.payload.get("criteria", [])
    iss.acceptance_criteria = [
        AcceptanceCriterion(description=c["description"], done=c.get("done", False)) for c in raw
    ]
    iss.updated = event.timestamp
    return iss


def _handle_acceptance_add(issue: Issue | None, event: Event) -> Issue:
    """Append a single acceptance criterion."""
    iss = _require_issue(issue, event.op)
    desc = event.payload.get("description", "")
    iss.acceptance_criteria = [*iss.acceptance_criteria, AcceptanceCriterion(description=desc)]
    iss.updated = event.timestamp
    return iss


def _handle_acceptance_rm(issue: Issue | None, event: Event) -> Issue:
    """Remove acceptance criterion by index."""
    iss = _require_issue(issue, event.op)
    idx = event.payload.get("index", -1)
    if not (0 <= idx < len(iss.acceptance_criteria)):
        msg = f"AC index {idx} out of range (0..{len(iss.acceptance_criteria) - 1})"
        raise ApplyError(msg)
    iss.acceptance_criteria = [c for i, c in enumerate(iss.acceptance_criteria) if i != idx]
    iss.updated = event.timestamp
    return iss


def _handle_acceptance_check(issue: Issue | None, event: Event) -> Issue:
    """Toggle done status of acceptance criterion by index."""
    iss = _require_issue(issue, event.op)
    idx = event.payload.get("index", -1)
    if not (0 <= idx < len(iss.acceptance_criteria)):
        msg = f"AC index {idx} out of range (0..{len(iss.acceptance_criteria) - 1})"
        raise ApplyError(msg)
    ac = iss.acceptance_criteria[idx]
    done = event.payload.get("done", not ac.done)
    iss.acceptance_criteria = [
        AcceptanceCriterion(description=c.description, done=done if i == idx else c.done)
        for i, c in enumerate(iss.acceptance_criteria)
    ]
    iss.updated = event.timestamp
    return iss


def _handle_deps_set(issue: Issue | None, event: Event) -> Issue:
    """Update dependencies."""
    iss = _require_issue(issue, event.op)
    p = event.payload
    iss.dependencies = Dependencies(
        depends_on=p.get("depends_on", []),
        blocks=p.get("blocks", []),
    )
    iss.updated = event.timestamp
    return iss


def _handle_deps_add(issue: Issue | None, event: Event) -> Issue:
    """Add entries to dependencies without replacing."""
    iss = _require_issue(issue, event.op)
    p = event.payload
    for dep in p.get("depends_on", []):
        if dep not in iss.dependencies.depends_on:
            iss.dependencies.depends_on = [*iss.dependencies.depends_on, dep]
    for blk in p.get("blocks", []):
        if blk not in iss.dependencies.blocks:
            iss.dependencies.blocks = [*iss.dependencies.blocks, blk]
    iss.updated = event.timestamp
    return iss


def _handle_deps_rm(issue: Issue | None, event: Event) -> Issue:
    """Remove specific entries from dependencies."""
    iss = _require_issue(issue, event.op)
    p = event.payload
    rm_deps = set(p.get("depends_on", []))
    rm_blocks = set(p.get("blocks", []))
    iss.dependencies.depends_on = [d for d in iss.dependencies.depends_on if d not in rm_deps]
    iss.dependencies.blocks = [b for b in iss.dependencies.blocks if b not in rm_blocks]
    iss.updated = event.timestamp
    return iss


def _handle_ref_set(issue: Issue | None, event: Event) -> Issue:
    """Update references, preserving files if not supplied."""
    iss = _require_issue(issue, event.op)
    iss.references = References(
        spec_file=event.payload.get("spec_file", ""),
        files=event.payload.get("files", list(iss.references.files)),
    )
    iss.updated = event.timestamp
    return iss


def _handle_files_add(issue: Issue | None, event: Event) -> Issue:
    """Append file paths to references.files (deduped)."""
    iss = _require_issue(issue, event.op)
    existing = set(iss.references.files)
    new_files = [f for f in event.payload.get("files", []) if f not in existing]
    iss.references = References(
        spec_file=iss.references.spec_file,
        files=[*iss.references.files, *new_files],
    )
    iss.updated = event.timestamp
    return iss


def _handle_log_append(issue: Issue | None, event: Event) -> Issue:
    """Append a log entry."""
    iss = _require_issue(issue, event.op)
    entry = LogEntry(
        date=event.payload.get("date", event.timestamp),
        message=event.payload.get("message", ""),
    )
    iss.log = [*iss.log, entry]
    iss.updated = event.timestamp
    return iss


def _handle_close(issue: Issue | None, event: Event) -> Issue:
    """Close an issue (terminal status)."""
    iss = _require_issue(issue, event.op)
    status = event.payload.get("status", "done")
    if status not in {s.value for s in TERMINAL_STATUSES}:
        msg = f"Close status must be terminal, got: {status}"
        raise ApplyError(msg)
    iss.status = status
    iss.completed_at = event.timestamp
    if iss.started_at:
        iss.duration_minutes = _compute_duration(iss.started_at, iss.completed_at)
    iss.updated = event.timestamp
    return iss


def _handle_reopen(issue: Issue | None, event: Event) -> Issue:
    """Reopen a closed issue."""
    iss = _require_issue(issue, event.op)
    iss.status = event.payload.get("status", "todo")
    iss.completed_at = ""
    iss.duration_minutes = 0
    iss.updated = event.timestamp
    return iss


def _handle_time_log(issue: Issue | None, event: Event) -> Issue:
    """Record time tracking start."""
    iss = _require_issue(issue, event.op)
    if "started_at" in event.payload:
        iss.started_at = event.payload["started_at"]
    iss.updated = event.timestamp
    return iss


def _compute_duration(started: str, completed: str) -> int:
    """Compute duration in minutes between two ISO timestamps."""
    from datetime import datetime

    fmt = "%Y-%m-%dT%H:%M:%SZ"
    try:
        start = datetime.strptime(started, fmt).replace(tzinfo=UTC)
        end = datetime.strptime(completed, fmt).replace(tzinfo=UTC)
        return max(0, int((end - start).total_seconds() / 60))
    except (ValueError, TypeError):
        return 0


def _handle_label_add(issue: Issue | None, event: Event) -> Issue:
    """Add labels to an issue (deduped, order-preserving)."""
    iss = _require_issue(issue, event.op)
    existing = set(iss.labels)
    new_labels = [lb for lb in event.payload.get("labels", []) if lb not in existing]
    iss.labels = [*iss.labels, *new_labels]
    iss.updated = event.timestamp
    return iss


def _handle_label_rm(issue: Issue | None, event: Event) -> Issue:
    """Remove labels from an issue."""
    iss = _require_issue(issue, event.op)
    to_remove = set(event.payload.get("labels", []))
    iss.labels = [lb for lb in iss.labels if lb not in to_remove]
    iss.updated = event.timestamp
    return iss


# Valid typed link types (beyond depends_on / blocks).
VALID_LINK_TYPES: frozenset[str] = frozenset(
    {"related", "duplicate_of", "discovered_from", "parent", "child"}
)


def _handle_link_add(issue: Issue | None, event: Event) -> Issue:
    """Add a typed link to an issue's links dict."""
    iss = _require_issue(issue, event.op)
    link_type = event.payload.get("link_type", "")
    targets: list[str] = event.payload.get("targets", [])
    existing = set(iss.links.get(link_type, []))
    new_targets = [t for t in targets if t not in existing]
    updated_links = dict(iss.links)
    updated_links[link_type] = [*iss.links.get(link_type, []), *new_targets]
    iss.links = updated_links
    iss.updated = event.timestamp
    return iss


def _handle_link_rm(issue: Issue | None, event: Event) -> Issue:
    """Remove a typed link from an issue's links dict."""
    iss = _require_issue(issue, event.op)
    link_type = event.payload.get("link_type", "")
    targets: set[str] = set(event.payload.get("targets", []))
    updated_links = dict(iss.links)
    if link_type in updated_links:
        updated_links[link_type] = [t for t in updated_links[link_type] if t not in targets]
        if not updated_links[link_type]:
            del updated_links[link_type]
    iss.links = updated_links
    iss.updated = event.timestamp
    return iss
