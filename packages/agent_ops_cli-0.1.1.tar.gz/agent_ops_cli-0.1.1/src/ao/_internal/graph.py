"""AO graph — pure functions for dependency graph analysis."""

from __future__ import annotations


def build_adjacency(
    issues: dict[str, list[str]],
) -> dict[str, list[str]]:
    """Build adjacency list from {issue_id: depends_on_list}.

    Returns adjacency as {node: [nodes it depends on]}.
    """
    adj: dict[str, list[str]] = {}
    for node, deps in issues.items():
        adj.setdefault(node, [])
        for dep in deps:
            adj[node].append(dep)
            adj.setdefault(dep, [])
    return adj


def detect_cycle(adj: dict[str, list[str]]) -> list[str] | None:
    """DFS-based cycle detection. Returns cycle path or None."""
    white: set[str] = set(adj.keys())
    gray: set[str] = set()
    black: set[str] = set()
    parent: dict[str, str | None] = {}

    def dfs(node: str) -> list[str] | None:
        white.discard(node)
        gray.add(node)
        for neighbor in adj.get(node, []):
            if neighbor in gray:
                return _extract_cycle(parent, node, neighbor)
            if neighbor in white:
                parent[neighbor] = node
                result = dfs(neighbor)
                if result is not None:
                    return result
        gray.discard(node)
        black.add(node)
        return None

    for node in list(white):
        if node in white:
            parent[node] = None
            result = dfs(node)
            if result is not None:
                return result
    return None


def _extract_cycle(
    parent: dict[str, str | None],
    current: str,
    target: str,
) -> list[str]:
    """Extract cycle path from parent map."""
    path = [target, current]
    node = parent.get(current)
    while node is not None and node != target:
        path.append(node)
        node = parent.get(node)
    path.append(target)
    path.reverse()
    return path


def generate_mermaid(adj: dict[str, list[str]]) -> str:
    """Generate mermaid graph syntax from adjacency list."""
    lines = ["graph TD"]
    for node, deps in sorted(adj.items()):
        safe_node = node.replace("@", "_")
        for dep in deps:
            safe_dep = dep.replace("@", "_")
            lines.append(f"    {safe_node} --> {safe_dep}")
    if len(lines) == 1:
        lines.append("    (empty)")
    return "\n".join(lines)
