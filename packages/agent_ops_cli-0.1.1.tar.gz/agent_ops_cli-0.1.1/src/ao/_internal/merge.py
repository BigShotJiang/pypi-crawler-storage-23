"""AO merge — deterministic JSONL event-log merge tool."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import msgspec

from ao._internal.io import atomic_write_jsonl, iter_jsonl_bytes


def _parse_events(path: Path) -> list[dict[str, Any]]:
    """Parse all events from a JSONL file."""
    events: list[dict[str, Any]] = []
    for raw in iter_jsonl_bytes(path):
        if b'"_meta"' in raw:
            continue
        try:
            evt: dict[str, Any] = msgspec.json.decode(raw)
            events.append(evt)
        except (msgspec.DecodeError, json.JSONDecodeError):
            continue
    return events


def _sort_key(evt: dict[str, Any]) -> tuple[str, str]:
    """Stable sort key: (timestamp, event_id)."""
    return (str(evt.get("timestamp", "")), str(evt.get("event_id", "")))


def _dedupe_by_id(events: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Dedup events by event_id, preserving first occurrence in sorted order."""
    seen: set[str] = set()
    result: list[dict[str, Any]] = []
    for evt in events:
        eid = str(evt.get("event_id", ""))
        if eid not in seen:
            seen.add(eid)
            result.append(evt)
    return result


def merge_events(
    ours: Path,
    theirs: Path,
    base: Path | None = None,
    strategy: str = "newest",
) -> list[dict[str, Any]]:
    """Merge two event logs into a single deterministic event list.

    Args:
        ours: Our events.jsonl (the local copy).
        theirs: Their events.jsonl (the incoming copy).
        base: Optional common ancestor events.jsonl.
        strategy: Conflict resolution strategy (newest|ours|theirs).

    Returns:
        Merged, deduped, sorted event list.
    """
    ours_events = _parse_events(ours)
    theirs_events = _parse_events(theirs)

    if strategy == "ours":
        all_events = [*ours_events, *theirs_events]
    elif strategy == "theirs":
        all_events = [*theirs_events, *ours_events]
    else:  # newest — sort by timestamp before dedup
        all_events = sorted([*ours_events, *theirs_events], key=_sort_key)

    all_events = sorted(_dedupe_by_id(all_events), key=_sort_key)
    return all_events


def merge_command(
    output: Path,
    ours: Path,
    theirs: Path,
    base: Path | None = None,
    strategy: str = "newest",
) -> dict[str, Any]:
    """Run the merge and write output. Returns stats dict."""
    merged = merge_events(ours, theirs, base, strategy)
    encoder = msgspec.json.Encoder()

    def _lines() -> Any:
        for evt in merged:
            yield encoder.encode(evt)

    atomic_write_jsonl(output, _lines())
    return {
        "output": str(output),
        "merged_count": len(merged),
        "strategy": strategy,
    }
