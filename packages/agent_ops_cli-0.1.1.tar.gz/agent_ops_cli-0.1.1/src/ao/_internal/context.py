"""AO context — path auto-detection and global options container."""

from __future__ import annotations

import os
from enum import StrEnum
from pathlib import Path


class OutputFormat(StrEnum):
    TABLE = "table"
    JSON = "json"
    JSONL = "jsonl"
    PLAIN = "plain"


class ProgressMode(StrEnum):
    AUTO = "auto"
    RICH = "rich"
    NONE = "none"


# Standardized exit codes
EXIT_OK = 0
EXIT_USER_ERROR = 1
EXIT_VALIDATION_ERROR = 2
EXIT_CONFLICT = 3
EXIT_CYCLE = 4


_AGENT_OPS_DIR = ".agent/ops"
_ISSUES_DIR = "issues"

# Environment variable signals for sandbox auto-detection.
_SANDBOX_ENV_VARS = (
    "CI",
    "GITHUB_ACTIONS",
    "GITLAB_CI",
    "CIRCLECI",
    "JENKINS_URL",
    "BUILDKITE",
    "TRAVIS",
    "AO_SANDBOX",
)


def is_sandbox_env() -> bool:
    """Return True if common CI/sandbox environment variables are set."""
    return any(os.environ.get(v) for v in _SANDBOX_ENV_VARS)


def find_agent_ops(start: Path | None = None) -> Path | None:
    """Walk up from *start* to find a directory containing `.agent/ops/`."""
    current = (start or Path.cwd()).resolve()
    for parent in (current, *current.parents):
        candidate = parent / _AGENT_OPS_DIR
        if candidate.is_dir():
            return candidate
    return None


class AppContext:
    """Resolved runtime context shared by all commands."""

    __slots__ = (
        "root",
        "events_path",
        "active_path",
        "references_dir",
        "format",
        "yes",
        "quiet",
        "progress",
        "in_path",
        "out_path",
        "sandbox",
    )

    def __init__(
        self,
        *,
        root: Path | None = None,
        fmt: OutputFormat = OutputFormat.TABLE,
        yes: bool = False,
        quiet: bool = False,
        progress: ProgressMode = ProgressMode.AUTO,
        in_path: str | None = None,
        out_path: str = "-",
        sandbox: bool = False,
    ) -> None:
        resolved = root or _default_root()
        self.root = resolved
        issues = resolved / _ISSUES_DIR
        self.events_path = issues / "events.jsonl"
        self.active_path = issues / "active.jsonl"
        self.references_dir = issues / "references"
        self.format = fmt
        self.yes = yes
        self.quiet = quiet
        self.progress = progress
        self.in_path = in_path
        self.out_path = out_path
        self.sandbox = sandbox or is_sandbox_env()


def _default_root() -> Path:
    """Auto-detect `.agent/ops/` or fall back to cwd-relative."""
    found = find_agent_ops()
    if found is not None:
        return found
    return Path.cwd() / _AGENT_OPS_DIR
