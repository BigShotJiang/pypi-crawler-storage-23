"""AO suggest-labels — map file paths to labels using glob patterns from config."""

from __future__ import annotations

import fnmatch
import tomllib
from pathlib import Path
from typing import Any

_CONFIG_FILENAME = "labels-config.toml"


def _load_config(config_path: Path) -> dict[str, str]:
    """Load glob-to-label mapping from a TOML config file.

    Expected TOML structure::

        [directories]
        "src/auth/*" = "area:auth"
        "src/web/*" = "area:web"

    Args:
        config_path: Path to the TOML config file.

    Returns:
        Dict mapping glob patterns to label strings.
    """
    if not config_path.exists():
        return {}
    with open(config_path, "rb") as fh:
        data: dict[str, Any] = tomllib.load(fh)
    mapping = data.get("directories", {})
    return {str(k): str(v) for k, v in mapping.items()}


def _find_config(start: Path) -> Path | None:
    """Walk up from *start* to find a labels-config.toml."""
    for parent in (start, *start.parents):
        candidate = parent / _CONFIG_FILENAME
        if candidate.exists():
            return candidate
        agent_candidate = parent / ".agent" / "ops" / _CONFIG_FILENAME
        if agent_candidate.exists():
            return agent_candidate
    return None


def suggest_labels(
    files: list[str],
    config: dict[str, str] | None = None,
    config_path: Path | None = None,
) -> list[str]:
    """Return labels matching the given file paths using glob patterns.

    Args:
        files: List of file paths to match against patterns.
        config: Direct mapping dict (glob -> label). Overrides config_path.
        config_path: Path to TOML config file.

    Returns:
        Sorted, deduplicated list of matching labels.
    """
    if config is None:
        resolved_path = config_path or _find_config(Path.cwd())
        patterns = _load_config(resolved_path) if resolved_path else {}
    else:
        patterns = config

    matched: set[str] = set()
    for file_path in files:
        normalized = file_path.replace("\\", "/")
        for pattern, label in patterns.items():
            norm_pattern = pattern.replace("\\", "/")
            if fnmatch.fnmatch(normalized, norm_pattern):
                matched.add(label)

    return sorted(matched)


def suggest_labels_for_issue(
    ctx_root: Path,
    files: list[str],
    config_path: Path | None = None,
) -> list[str]:
    """Suggest labels for an issue based on affected files. Looks for config relative to ctx_root."""
    resolved = config_path or ctx_root / _CONFIG_FILENAME
    if not resolved.exists():
        resolved = ctx_root.parent.parent / _CONFIG_FILENAME  # try project root
    patterns = _load_config(resolved) if resolved.exists() else {}
    return suggest_labels(files, config=patterns)
