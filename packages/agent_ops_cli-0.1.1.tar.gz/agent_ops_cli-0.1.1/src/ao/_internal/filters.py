"""AO filters — query-string parser for human-friendly issue filtering."""

from __future__ import annotations

import re

# Short aliases that expand to canonical field names.
_ALIASES: dict[str, str] = {
    "prio": "priority",
    "conf": "confidence",
    "stat": "status",
}


def parse_query_tokens(tokens: list[str]) -> dict[str, str]:
    """Parse ``key:value`` tokens into a filter dict.

    Supports:
      - ``status:todo``
      - ``prio:high`` (alias → priority)
      - ``text:"login timeout"`` (quoted values)
    """
    filters: dict[str, str] = {}
    for token in tokens:
        m = re.match(r"^(\w+):(.+)$", token)
        if m is None:
            # Bare word → treat as text search.
            filters["text"] = filters.get("text", "") + (" " if "text" in filters else "") + token
            continue
        key = m.group(1).lower()
        val = m.group(2).strip("\"'")
        key = _ALIASES.get(key, key)
        filters[key] = val
    return filters
