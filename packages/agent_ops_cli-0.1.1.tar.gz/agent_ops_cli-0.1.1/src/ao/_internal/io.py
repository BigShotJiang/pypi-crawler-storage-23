"""AO IO primitives — fast JSONL read/write in binary mode."""

from __future__ import annotations

import os
import tempfile
from collections.abc import Iterator
from pathlib import Path


def iter_jsonl_bytes(path: Path, buf_mb: int = 32) -> Iterator[bytes]:
    """Yield non-empty raw byte lines from a JSONL file."""
    buf_size = buf_mb * 1024 * 1024
    with open(path, "rb", buffering=buf_size) as f:
        for line in f:
            stripped = line.strip()
            if stripped:
                yield stripped


def append_jsonl(path: Path, line_bytes: bytes) -> None:
    """Append a single JSON line to a JSONL file (with exclusive advisory lock)."""
    from ao._internal.lock import locked

    with locked(path):
        with open(path, "ab") as f:
            f.write(line_bytes + b"\n")


def atomic_write_jsonl(path: Path, lines: Iterator[bytes]) -> None:
    """Write JSONL atomically: temp file + os.replace."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(
        dir=path.parent,
        prefix=".aoi_tmp_",
        suffix=".jsonl",
    )
    try:
        with os.fdopen(fd, "wb") as f:
            for line in lines:
                f.write(line)
                f.write(b"\n")
        os.replace(tmp, path)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


def file_byte_size(path: Path) -> int:
    """Return file size in bytes (for progress bars)."""
    return path.stat().st_size
