"""AO admin — recovery, cleanup, and migrate commands."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import msgspec

from ao._internal.io import iter_jsonl_bytes

_DERIVED_FILENAMES = ("active.jsonl", ".counter", "index.sqlite")


def _validate_events(events_path: Path) -> dict[str, Any]:
    """Validate that events.jsonl is readable and all lines are valid JSON objects."""
    if not events_path.exists():
        return {"ok": False, "error": "events.jsonl not found"}
    valid = 0
    invalid: list[str] = []
    for i, raw in enumerate(iter_jsonl_bytes(events_path), 1):
        try:
            obj: Any = msgspec.json.decode(raw)
            if not isinstance(obj, dict):
                invalid.append(f"line {i}: not an object")
        except msgspec.DecodeError as exc:
            invalid.append(f"line {i}: {exc}")
    return {"ok": len(invalid) == 0, "valid_lines": valid, "invalid_lines": invalid}


def admin_cleanup(root: Path, *, rebuild: bool = True) -> dict[str, Any]:
    """Remove derived files under *root/issues/* and optionally rebuild.

    Args:
        root: The `.agent/ops` root directory.
        rebuild: If True, rebuild active.jsonl after cleanup.

    Returns:
        Stats dict with removed, rebuilt, validation keys.
    """
    issues_dir = root / "issues"
    removed: list[str] = []

    for name in _DERIVED_FILENAMES:
        path = issues_dir / name
        if path.exists():
            path.unlink()
            removed.append(name)

    validation = _validate_events(issues_dir / "events.jsonl")
    result: dict[str, Any] = {"removed": removed, "validation": validation}

    if rebuild and validation["ok"]:
        from ao._internal.rebuild import rebuild as do_rebuild
        from ao.codec import MsgspecCodec

        stats = do_rebuild(
            issues_dir / "events.jsonl",
            issues_dir / "active.jsonl",
            MsgspecCodec(),
            show_progress=False,
        )
        result["rebuilt"] = True
        result["active_count"] = len(stats)
    else:
        result["rebuilt"] = False

    return result


def admin_reset(root: Path, *, force: bool = False) -> dict[str, Any]:
    """Wipe all AO data under *root/issues/*.

    Dry-run by default. Pass ``force=True`` to actually delete.

    Args:
        root: The `.agent/ops` root directory.
        force: Actually delete files. Default False = dry-run.

    Returns:
        Stats dict with would_remove (dry-run) or removed (forced).
    """
    issues_dir = root / "issues"
    targets: list[str] = []

    for path in sorted(issues_dir.iterdir()) if issues_dir.exists() else []:
        targets.append(path.name)

    if not force:
        return {"dry_run": True, "would_remove": targets}

    removed: list[str] = []
    for path in sorted(issues_dir.iterdir()):
        if path.is_file():
            path.unlink()
            removed.append(path.name)
        elif path.is_dir():
            import shutil

            shutil.rmtree(path)
            removed.append(path.name + "/")

    return {"dry_run": False, "removed": removed}


def admin_migrate(
    root: Path,
    from_path: Path,
    *,
    dedupe: bool = True,
    orphan: str = "allow",
) -> dict[str, Any]:
    """Migrate events from another project's events.jsonl into this project.

    This is a thin wrapper around :func:`ao._internal.importer.import_events`.

    Args:
        root: Target `.agent/ops` root.
        from_path: Source events.jsonl (or its parent directory).
        dedupe: Skip duplicate event_ids.
        orphan: Orphan handling strategy (allow|skip|strict|resurrect).

    Returns:
        Import stats dict.
    """
    from ao._internal.importer import import_events

    source = from_path if from_path.is_file() else from_path / "issues" / "events.jsonl"
    target = root / "issues" / "events.jsonl"
    result = import_events(target, source, dedupe=dedupe, orphan=orphan)

    if result.get("imported", 0) > 0:
        from ao._internal.rebuild import rebuild as do_rebuild
        from ao.codec import MsgspecCodec

        do_rebuild(target, root / "issues" / "active.jsonl", MsgspecCodec(), show_progress=False)
        result["rebuilt"] = True
    else:
        result["rebuilt"] = False

    return result
