"""AO validate — config-driven validation runner."""

from __future__ import annotations

import subprocess
import tomllib
from pathlib import Path
from typing import Any

_DEFAULT_COMMANDS: list[str] = ["uv run pytest -q", "uv run ruff check ."]


def _find_repo_root(start: Path) -> Path:
    """Walk up from start to find the directory containing pyproject.toml.

    Args:
        start: Directory to begin search from.

    Returns:
        Path of the directory containing pyproject.toml, or start if not found.
    """
    for parent in (start, *start.parents):
        if (parent / "pyproject.toml").exists():
            return parent
    return start


def _load_toml(path: Path) -> dict[str, Any]:
    """Parse a TOML file, returning empty dict on any error.

    Args:
        path: Path to the TOML file.

    Returns:
        Parsed dict or empty dict if file is absent or unparseable.
    """
    if not path.exists():
        return {}
    try:
        return tomllib.loads(path.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {}


def load_validate_config(root: Path) -> list[str]:
    """Return validate commands from pyproject.toml or .ao/config.toml.

    Checks pyproject.toml [tool.ao.validate] section first, then
    .ao/config.toml [validate] section, then falls back to defaults.

    Args:
        root: The .agent/ops root; used to locate the repo root.

    Returns:
        List of shell command strings to run for validation.
    """
    repo_root = _find_repo_root(root)
    pyproject = _load_toml(repo_root / "pyproject.toml")
    cmds: Any = pyproject.get("tool", {}).get("ao", {}).get("validate", {}).get("commands")
    if isinstance(cmds, list):
        return [str(c) for c in cmds]
    aoi_cfg = _load_toml(repo_root / ".ao" / "config.toml")
    cmds2: Any = aoi_cfg.get("validate", {}).get("commands")
    if isinstance(cmds2, list):
        return [str(c) for c in cmds2]
    return list(_DEFAULT_COMMANDS)


def run_command(cmd: str, *, cwd: Path, timeout: int = 60) -> dict[str, Any]:
    """Run a single shell command and return a structured result dict.

    Args:
        cmd: Shell command string to execute.
        cwd: Working directory for the command.
        timeout: Maximum seconds to wait before terminating.

    Returns:
        Dict with cmd, exit_code, ok, and output fields.
    """
    try:
        proc = subprocess.run(  # noqa: S602
            cmd, shell=True, capture_output=True, text=True, cwd=cwd, timeout=timeout
        )
        output = (proc.stdout + proc.stderr).strip()[:2000]
        return {
            "cmd": cmd,
            "exit_code": proc.returncode,
            "ok": proc.returncode == 0,
            "output": output,
        }
    except subprocess.TimeoutExpired:
        return {"cmd": cmd, "exit_code": -1, "ok": False, "output": f"Timed out after {timeout}s"}
    except Exception as exc:  # noqa: BLE001
        return {"cmd": cmd, "exit_code": -1, "ok": False, "output": str(exc)}


def validate_all(
    root: Path,
    *,
    timeout: int = 60,
    commands: list[str] | None = None,
) -> dict[str, Any]:
    """Run all configured validation commands and report results.

    Args:
        root: The .agent/ops root directory; used to locate commands config.
        timeout: Per-command timeout in seconds.
        commands: Override command list; uses configured commands if None.

    Returns:
        Dict with ok, passed, failed, and results fields.
    """
    repo_root = _find_repo_root(root)
    cmds = commands if commands is not None else load_validate_config(root)
    results = [run_command(cmd, cwd=repo_root, timeout=timeout) for cmd in cmds]
    passed = sum(1 for r in results if r["ok"])
    return {
        "ok": all(r["ok"] for r in results),
        "passed": passed,
        "failed": len(results) - passed,
        "results": results,
    }
