"""AO gen — generate large JSONL files for stress testing."""

from __future__ import annotations

import hashlib
import random
from datetime import UTC, datetime
from pathlib import Path

import orjson
from rich.progress import BarColumn, MofNCompleteColumn, Progress, TextColumn

from ao.models import (
    Confidence,
    IssueType,
    Op,
    Priority,
    Status,
)


def generate_events(
    *,
    issues: int = 1000,
    updates_per_issue: int = 3,
    close_ratio: float = 0.3,
    avg_notes_bytes: int = 100,
    out: Path = Path("data/events.jsonl"),
    seed: int = 42,
    show_progress: bool = True,
) -> int:
    """Generate a stress-test events.jsonl file. Returns event count."""
    rng = random.Random(seed)  # noqa: S311
    out.parent.mkdir(parents=True, exist_ok=True)

    total_events = issues * (1 + updates_per_issue) + int(issues * close_ratio)

    progress = Progress(
        TextColumn("[bold green]Generating"),
        BarColumn(),
        MofNCompleteColumn(),
        TextColumn("events"),
        disable=not show_progress,
    )

    event_seq = 0
    with progress, open(out, "wb") as f:
        task = progress.add_task("gen", total=total_events)
        for i in range(issues):
            issue_id = _make_issue_id(i, rng)
            ts = _make_timestamp(rng)

            # Create event
            event_seq += 1
            create_evt = _create_event(event_seq, issue_id, ts, rng, avg_notes_bytes)
            f.write(orjson.dumps(create_evt, option=orjson.OPT_SORT_KEYS))
            f.write(b"\n")
            progress.advance(task)

            # Update events
            for _ in range(updates_per_issue):
                event_seq += 1
                ts = _advance_time(ts, rng)
                update_evt = _update_event(event_seq, issue_id, ts, rng, avg_notes_bytes)
                f.write(orjson.dumps(update_evt, option=orjson.OPT_SORT_KEYS))
                f.write(b"\n")
                progress.advance(task)

            # Close event
            if rng.random() < close_ratio:
                event_seq += 1
                ts = _advance_time(ts, rng)
                close_evt = _close_event(event_seq, issue_id, ts, rng)
                f.write(orjson.dumps(close_evt, option=orjson.OPT_SORT_KEYS))
                f.write(b"\n")
                progress.advance(task)

    return event_seq


def _make_issue_id(seq: int, rng: random.Random) -> str:
    type_ = rng.choice(list(IssueType)).value.upper()
    h = hashlib.md5(f"{seq}".encode(), usedforsecurity=False).hexdigest()[:6]
    return f"{type_}-{seq:04d}@{h}"


def _make_timestamp(rng: random.Random) -> str:
    year = 2026
    month = rng.randint(1, 12)
    day = rng.randint(1, 28)
    hour = rng.randint(0, 23)
    minute = rng.randint(0, 59)
    return f"{year}-{month:02d}-{day:02d}T{hour:02d}:{minute:02d}:00Z"


def _advance_time(ts: str, rng: random.Random) -> str:
    """Advance timestamp by random minutes."""
    dt = datetime.strptime(ts, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC)
    from datetime import timedelta

    dt += timedelta(minutes=rng.randint(1, 1440))
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def _random_notes(rng: random.Random, avg_bytes: int) -> str:
    length = max(10, rng.gauss(avg_bytes, avg_bytes // 3))
    chars = "abcdefghijklmnopqrstuvwxyz       "
    return "".join(rng.choice(chars) for _ in range(int(length)))


def _create_event(
    seq: int, issue_id: str, ts: str, rng: random.Random, avg_notes: int
) -> dict[str, object]:
    return {
        "event_id": f"evt-{seq:08d}",
        "issue_id": issue_id,
        "op": Op.CREATE.value,
        "timestamp": ts,
        "payload": {
            "title": f"Issue {issue_id}",
            "type": rng.choice(list(IssueType)).value,
            "status": Status.TODO.value,
            "priority": rng.choice(list(Priority)).value,
            "epic": rng.choice(["Alpha", "Beta", "Gamma", "Delta", ""]),
            "owner": rng.choice(["agent", "human", "alice", "bob"]),
            "confidence": rng.choice(list(Confidence)).value,
            "notes": _random_notes(rng, avg_notes),
        },
    }


def _update_event(
    seq: int, issue_id: str, ts: str, rng: random.Random, avg_notes: int
) -> dict[str, object]:
    op = rng.choice([Op.SET, Op.LOG_APPEND, Op.REQUIREMENTS_SET])
    payload: dict[str, object] = {}
    if op == Op.SET:
        field = rng.choice(["priority", "status", "notes", "title"])
        if field == "priority":
            payload["priority"] = rng.choice(list(Priority)).value
        elif field == "status":
            payload["status"] = rng.choice(
                [Status.TODO, Status.IN_PROGRESS, Status.REVIEW, Status.BLOCKED]
            ).value
        elif field == "notes":
            payload["notes"] = _random_notes(rng, avg_notes)
        else:
            payload["title"] = f"Updated issue {issue_id}"
    elif op == Op.LOG_APPEND:
        payload = {"date": ts, "message": _random_notes(rng, avg_notes // 2)}
    elif op == Op.REQUIREMENTS_SET:
        payload = {"requirements": [_random_notes(rng, 30) for _ in range(rng.randint(1, 5))]}
    return {
        "event_id": f"evt-{seq:08d}",
        "issue_id": issue_id,
        "op": op.value,
        "timestamp": ts,
        "payload": payload,
    }


def _close_event(seq: int, issue_id: str, ts: str, rng: random.Random) -> dict[str, object]:
    status = rng.choice([Status.DONE, Status.CANCELLED, Status.DROPPED])
    return {
        "event_id": f"evt-{seq:08d}",
        "issue_id": issue_id,
        "op": Op.CLOSE.value,
        "timestamp": ts,
        "payload": {"status": status.value},
    }
