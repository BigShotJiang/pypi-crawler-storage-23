"""AO rebuild — derive active.jsonl from events.jsonl in a single pass."""

from __future__ import annotations

from collections.abc import Iterator
from datetime import UTC, datetime
from pathlib import Path

from ao._internal.apply import ApplyError, apply_event
from ao._internal.io import atomic_write_jsonl, file_byte_size, iter_jsonl_bytes
from ao.codec import Codec
from ao.models import TERMINAL_STATUSES, Issue


def rebuild(
    events_path: Path,
    active_path: Path,
    codec: Codec,
    *,
    show_progress: bool = True,
) -> dict[str, Issue]:
    """Rebuild active issue snapshot from event log."""
    from rich.progress import BarColumn, Progress, TextColumn, TransferSpeedColumn

    issues: dict[str, Issue] = {}
    total_bytes = file_byte_size(events_path)
    event_count = 0
    last_event_id = ""
    errors = 0

    progress = Progress(
        TextColumn("[bold blue]Rebuilding"),
        BarColumn(),
        TextColumn("{task.completed}/{task.total} bytes"),
        TransferSpeedColumn(),
        disable=not show_progress,
    )

    with progress:
        task = progress.add_task("rebuild", total=total_bytes)
        for line in iter_jsonl_bytes(events_path):
            progress.advance(task, len(line) + 1)
            try:
                event = codec.decode_event(line)
            except Exception:
                errors += 1
                continue
            event_count += 1
            last_event_id = event.event_id
            current = issues.get(event.issue_id)
            try:
                result = apply_event(current, event)
            except ApplyError:
                errors += 1
                continue
            if result is None:
                issues.pop(event.issue_id, None)
            else:
                issues[event.issue_id] = result

    active = {k: v for k, v in issues.items() if v.status not in TERMINAL_STATUSES}
    _write_active(active_path, active, codec, event_count, last_event_id)
    return active


def _write_active(
    path: Path,
    issues: dict[str, Issue],
    codec: Codec,
    event_count: int,
    last_event_id: str,
) -> None:
    """Write deterministic active.jsonl sorted by issue_id."""
    import orjson

    now = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")

    def lines() -> Iterator[bytes]:
        meta = {
            "_meta": True,
            "generated_at": now,
            "source_last_event_id": last_event_id,
            "event_count": event_count,
            "active_count": len(issues),
        }
        yield orjson.dumps(meta, option=orjson.OPT_SORT_KEYS)
        for issue_id in sorted(issues):
            yield codec.encode_issue(issues[issue_id])

    atomic_write_jsonl(path, lines())
