"""AO output — format-aware rendering with JSON envelope protocol."""

from __future__ import annotations

import sys
from enum import StrEnum
from typing import Any

import msgspec
from rich.console import Console
from rich.table import Table

from ao._internal.context import AppContext, OutputFormat

# Stderr console for progress/diagnostics when stdout is JSON.
_stderr_console = Console(stderr=True)


class ErrorCode(StrEnum):
    VALIDATION_ERROR = "VALIDATION_ERROR"
    NOT_FOUND = "NOT_FOUND"
    CONFLICT = "CONFLICT"
    CYCLE_DETECTED = "CYCLE_DETECTED"
    PARSE_ERROR = "PARSE_ERROR"


# ── internal encoder ──────────────────────────────────────────────────────────


_encoder = msgspec.json.Encoder()


def _json_bytes(obj: Any) -> bytes:
    """Encode a plain dict/list to JSON bytes via msgspec."""
    return _encoder.encode(obj)


# ── public API ────────────────────────────────────────────────────────────────


def emit_success(ctx: AppContext, result: Any) -> None:
    """Write a success result in the active format."""
    fmt = ctx.format
    if fmt == OutputFormat.JSON:
        _write_json({"ok": True, "result": result})
    elif fmt == OutputFormat.JSONL:
        _write_json(result)
    elif fmt == OutputFormat.PLAIN:
        _write_plain(result)
    else:
        _write_plain(result)


def emit_error(
    ctx: AppContext,
    code: ErrorCode,
    message: str,
    details: dict[str, Any] | None = None,
) -> None:
    """Write an error envelope and exit nonzero."""
    fmt = ctx.format
    envelope: dict[str, Any] = {
        "ok": False,
        "error": {"code": str(code), "message": message},
    }
    if details:
        envelope["error"]["details"] = details
    if fmt in (OutputFormat.JSON, OutputFormat.JSONL):
        _write_json(envelope)
    else:
        con = Console(stderr=True)
        con.print(f"[red]Error ({code}):[/red] {message}")


def emit_table(
    ctx: AppContext,
    columns: list[str],
    rows: list[list[str]],
    *,
    title: str = "",
) -> None:
    """Render a table (Rich) or JSON array depending on format."""
    fmt = ctx.format
    if fmt == OutputFormat.JSON:
        records = [dict(zip(columns, r, strict=True)) for r in rows]
        _write_json({"ok": True, "result": records})
    elif fmt == OutputFormat.JSONL:
        for row in rows:
            _write_json(dict(zip(columns, row, strict=True)))
    elif fmt == OutputFormat.PLAIN:
        for row in rows:
            sys.stdout.write("\t".join(row) + "\n")
    else:
        table = Table(title=title or None)
        for col in columns:
            table.add_column(col)
        for row in rows:
            table.add_row(*row)
        Console().print(table)


def emit_issue(ctx: AppContext, issue: dict[str, Any]) -> None:
    """Write a single issue in the active format."""
    emit_success(ctx, issue)


def emit_issues(ctx: AppContext, issues: list[dict[str, Any]]) -> None:
    """Write multiple issues in the active format."""
    fmt = ctx.format
    if fmt == OutputFormat.JSONL:
        for iss in issues:
            _write_json(iss)
    else:
        emit_success(ctx, issues)


def stderr_console() -> Console:
    """Return a Console that writes to stderr (for progress in json mode)."""
    return _stderr_console


# ── private helpers ───────────────────────────────────────────────────────────


def _write_json(obj: Any) -> None:
    """Write JSON bytes to stdout with a trailing newline."""
    sys.stdout.buffer.write(_json_bytes(obj))
    sys.stdout.buffer.write(b"\n")
    sys.stdout.buffer.flush()


def _write_plain(obj: Any) -> None:
    """Write a plain-text representation to stdout."""
    if isinstance(obj, dict):
        for k, v in obj.items():
            sys.stdout.write(f"{k}: {v}\n")
    elif isinstance(obj, list):
        for item in obj:
            sys.stdout.write(f"{item}\n")
    else:
        sys.stdout.write(f"{obj}\n")
