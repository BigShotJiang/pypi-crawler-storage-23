"""AO loop runner — external iteration orchestrator for Copilot and OpenCode.

Generates markdown iteration prompts from focus/issues state and optionally
drives an agent CLI in a subprocess loop until all ready issues are resolved.
"""

from __future__ import annotations

import subprocess
import tempfile
from pathlib import Path
from typing import Any

from ao._internal.context import AppContext

# ── engine CLI command prefixes ───────────────────────────────────────────────

_ENGINE_CMDS: dict[str, list[str]] = {
    "opencode": ["opencode", "run"],
    "copilot": ["gh", "copilot", "suggest", "-t", "shell"],
    "claude": ["claude", "--print"],
}

# ── prompt generation ─────────────────────────────────────────────────────────


def _focus_section(focus: dict[str, Any]) -> str:
    """Build the current task section from focus doing_now."""
    doing: dict[str, Any] = focus.get("doing_now") or {}
    issue_id = doing.get("issue_id", "")
    task = doing.get("task", "")
    if issue_id:
        return f"## Current Task\n\nIssue: {issue_id}\nTask: {task}\n"
    return "## Current Task\n\nNo active issue — run `ao next` to pick one.\n"


def _ready_section(ctx: AppContext) -> str:
    """Build the ready issues section from active.jsonl (up to 5 items)."""
    from ao._internal.agent_hook import _load_ready_issues

    issues = _load_ready_issues(ctx)
    if not issues:
        return "## Ready Issues\n\nNone — all issues are complete or blocked.\n"
    lines = ["## Ready Issues\n"]
    for i in issues:
        lines.append(f"- {i['id']}: [{i['status']}] {i['title']}")
    return "\n".join(lines) + "\n"


def _instructions_section(engine: str) -> str:
    """Build the engine-specific instructions section."""
    base = (
        "## Instructions\n\n"
        "You are the AO worker agent. Work on the current task above.\n"
        "Run `ao next` if no current task is set. Use `ao` CLI for all issue operations.\n"
        "When the task is done, close the issue: `ao issue close <ID> --log 'Done'`.\n"
    )
    if engine == "copilot":
        base += "Use VS Code tools. Prefer small incremental changes with tests.\n"
    elif engine == "opencode":
        base += "Run all commands non-interactively. Exit when the task is complete.\n"
    return base


def generate_loop_prompt(ctx: AppContext, engine: str) -> str:
    """Generate a markdown iteration prompt from focus and ready issues.

    Args:
        ctx: Resolved application context.
        engine: Target agent engine identifier.

    Returns:
        Formatted markdown string suitable for passing to the agent.
    """
    from ao._internal.commands.focus import _load_focus

    focus = _load_focus(ctx) or {}
    sections = [
        "# AO Iteration Prompt\n",
        _focus_section(focus),
        _ready_section(ctx),
        _instructions_section(engine),
    ]
    return "\n".join(sections)


# ── loop runner ───────────────────────────────────────────────────────────────


def _has_ready_issues(ctx: AppContext) -> bool:
    """Return True if there are any non-terminal, non-blocked issues."""
    from ao._internal.agent_hook import _load_ready_issues

    return len(_load_ready_issues(ctx)) > 0


def _run_agent(cmd: list[str], prompt: str) -> int:
    """Write prompt to a temp file and invoke the agent CLI, returning exit code."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".md", delete=False, encoding="utf-8") as tmp:
        tmp.write(prompt)
        tmp_path = Path(tmp.name)
    try:
        result = subprocess.run(  # noqa: S603
            [*cmd, str(tmp_path)], check=False
        )
        return result.returncode
    finally:
        tmp_path.unlink(missing_ok=True)


def run_loop(
    ctx: AppContext,
    engine: str,
    max_iterations: int = 10,
    *,
    dry_run: bool = False,
) -> dict[str, Any]:
    """Orchestrate agent iterations until no ready issues remain or limit reached.

    Generates an iteration prompt, invokes the engine CLI with the prompt as
    input, then rebuilds active.jsonl and checks for remaining ready issues.

    Args:
        ctx: Resolved application context.
        engine: Agent engine identifier (opencode | copilot | claude).
        max_iterations: Maximum number of iterations to run.
        dry_run: If True, generate prompt but do not invoke the agent.

    Returns:
        Dict with iterations_run, done, engine, and last_prompt fields.
    """
    cmd = _ENGINE_CMDS.get(engine)
    if cmd is None:
        return {"ok": False, "error": f"Unknown engine: {engine!r}. Use: {', '.join(_ENGINE_CMDS)}"}
    iterations_run = 0
    last_prompt = ""
    while iterations_run < max_iterations:
        if not _has_ready_issues(ctx):
            break
        last_prompt = generate_loop_prompt(ctx, engine)
        iterations_run += 1
        if dry_run:
            break
        _run_agent(cmd, last_prompt)
        _rebuild_active(ctx)
    done = not _has_ready_issues(ctx)
    return {
        "ok": True,
        "iterations_run": iterations_run,
        "done": done,
        "engine": engine,
        "last_prompt": last_prompt,
    }


def _rebuild_active(ctx: AppContext) -> None:
    """Rebuild active.jsonl after an agent iteration completes."""
    try:
        from ao._internal.rebuild import rebuild
        from ao.codec import MsgspecCodec

        rebuild(ctx.events_path, ctx.active_path, MsgspecCodec(), show_progress=False)
    except Exception:  # noqa: BLE001,S110
        pass
