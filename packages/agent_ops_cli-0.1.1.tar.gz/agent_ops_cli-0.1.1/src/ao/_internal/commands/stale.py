"""AO stale — detect issues not updated within N days."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import Any

import msgspec
from rich.console import Console
from rich.table import Table

from ao._internal.context import AppContext, OutputFormat
from ao._internal.io import iter_jsonl_bytes
from ao._internal.output import emit_success
from ao.codec import MsgspecCodec
from ao.models import Issue


def _load_issues(ctx: AppContext) -> list[Issue]:
    """Load all issues from active.jsonl."""
    codec = MsgspecCodec()
    issues: list[Issue] = []
    if not ctx.active_path.exists():
        return issues
    for line in iter_jsonl_bytes(ctx.active_path):
        if b'"_meta"' in line:
            continue
        try:
            issues.append(codec.decode_issue(line))
        except Exception:  # noqa: S112
            continue
    return issues


def _compute_stale(issues: list[Issue], days: int, now: datetime) -> list[dict[str, Any]]:
    """Return issues not updated in `days` days with days_stale computed."""
    threshold = now - timedelta(days=days)
    result: list[dict[str, Any]] = []
    for issue in issues:
        if not issue.updated:
            continue
        try:
            updated = datetime.fromisoformat(issue.updated.replace("Z", "+00:00"))
        except ValueError:
            continue
        if updated < threshold:
            days_stale = (now - updated).days
            d: dict[str, Any] = msgspec.to_builtins(issue)
            d["days_stale"] = days_stale
            result.append(d)
    result.sort(key=lambda x: x["days_stale"], reverse=True)
    return result


def issue_stale(ctx: AppContext, days: int) -> None:
    """List issues not updated within the given number of days."""
    now = datetime.now(UTC)
    issues = _load_issues(ctx)
    stale = _compute_stale(issues, days, now)

    if ctx.format in (OutputFormat.JSON, OutputFormat.JSONL):
        emit_success(ctx, {"count": len(stale), "days": days, "issues": stale})
        return

    _render_stale_table(stale, days)


def _render_stale_table(stale: list[dict[str, Any]], days: int) -> None:
    """Render stale issues as a Rich table."""
    con = Console()
    table = Table(title=f"Stale Issues (no update in {days}+ days, {len(stale)} found)")
    for col in ("ID", "Title", "Status", "Priority", "Days Stale", "Updated"):
        table.add_column(col)
    for issue in stale:
        table.add_row(
            str(issue.get("id", "")),
            str(issue.get("title", "")),
            str(issue.get("status", "")),
            str(issue.get("priority", "")),
            str(issue.get("days_stale", "")),
            str(issue.get("updated", "")),
        )
    con.print(table)
