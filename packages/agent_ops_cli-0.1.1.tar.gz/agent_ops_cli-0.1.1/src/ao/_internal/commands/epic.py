"""AO epic — epic listing, show, rename, summary commands."""

from __future__ import annotations

from collections import Counter

import msgspec

from ao._internal.commands.issue import (
    _do_rebuild,
    _encode_and_append,
    _make_event_id,
    _next_id,
    _now_iso,
)
from ao._internal.context import AppContext, OutputFormat
from ao._internal.io import iter_jsonl_bytes
from ao._internal.output import ErrorCode, emit_error, emit_success
from ao.codec import MsgspecCodec
from ao.models import Event, Issue, Op


def _load_all_issues(ctx: AppContext) -> list[Issue]:
    """Load all issues from active.jsonl."""
    codec = MsgspecCodec()
    issues: list[Issue] = []
    if not ctx.active_path.exists():
        return issues
    for line in iter_jsonl_bytes(ctx.active_path):
        if b'"_meta"' in line:
            continue
        try:
            issues.append(codec.decode_issue(line))
        except Exception:  # noqa: S112
            continue
    return issues


def epic_ls(ctx: AppContext) -> None:
    """List unique epics with issue counts."""
    issues = _load_all_issues(ctx)
    epics: dict[str, dict[str, int]] = {}
    for iss in issues:
        name = iss.epic or "(none)"
        if name not in epics:
            epics[name] = {"total": 0}
        epics[name]["total"] += 1
        status_key = iss.status.value
        epics[name][status_key] = epics[name].get(status_key, 0) + 1

    if ctx.format in (OutputFormat.JSON, OutputFormat.JSONL):
        result = [{"name": k, **v} for k, v in sorted(epics.items())]
        emit_success(ctx, {"epics": result})
        return

    from rich.console import Console
    from rich.table import Table

    table = Table(title="Epics")
    for col in ("Epic", "Total", "Todo", "In Progress", "Done"):
        table.add_column(col)
    for name in sorted(epics):
        d = epics[name]
        table.add_row(
            name,
            str(d["total"]),
            str(d.get("todo", 0)),
            str(d.get("in_progress", 0)),
            str(d.get("done", 0)),
        )
    Console().print(table)


def epic_show(ctx: AppContext, epic_name: str) -> None:
    """List issues in a specific epic."""
    issues = [i for i in _load_all_issues(ctx) if (i.epic or "(none)") == epic_name]
    if ctx.format in (OutputFormat.JSON, OutputFormat.JSONL):
        dicts = [msgspec.to_builtins(i) for i in issues]
        emit_success(ctx, {"epic": epic_name, "count": len(dicts), "issues": dicts})
        return

    from rich.console import Console
    from rich.table import Table

    table = Table(title=f"Epic: {epic_name} ({len(issues)})")
    for col in ("ID", "Title", "Status", "Priority"):
        table.add_column(col)
    for i in issues:
        table.add_row(i.id, i.title, i.status, i.priority)
    Console().print(table)


def epic_rename(ctx: AppContext, old_name: str, new_name: str) -> None:
    """Rename an epic across all issues."""
    issues = [i for i in _load_all_issues(ctx) if i.epic == old_name]
    if not issues:
        emit_error(ctx, ErrorCode.NOT_FOUND, f"No issues with epic '{old_name}'")
        return

    ts = _now_iso()
    events: list[Event] = []
    for iss in issues:
        num = _next_id(ctx)
        events.append(
            Event(
                event_id=_make_event_id(num),
                issue_id=iss.id,
                op=Op.SET,
                timestamp=ts,
                payload={"epic": new_name},
            )
        )

    for evt in events:
        _encode_and_append(ctx, evt)
    _do_rebuild(ctx)
    emit_success(
        ctx,
        {
            "renamed": len(events),
            "from": old_name,
            "to": new_name,
            "events": [e.event_id for e in events],
        },
    )


def epic_summary(ctx: AppContext, epic_name: str) -> None:
    """Status/priority breakdown for an epic."""
    issues = [i for i in _load_all_issues(ctx) if (i.epic or "(none)") == epic_name]
    status_counts: dict[str, int] = dict(Counter(i.status.value for i in issues))
    prio_counts: dict[str, int] = dict(Counter(i.priority.value for i in issues))

    if ctx.format in (OutputFormat.JSON, OutputFormat.JSONL):
        emit_success(
            ctx,
            {
                "epic": epic_name,
                "total": len(issues),
                "by_status": status_counts,
                "by_priority": prio_counts,
            },
        )
        return

    from rich.console import Console

    con = Console()
    con.print(f"[bold]Epic: {epic_name}[/bold] ({len(issues)} issues)")
    con.print("[bold underline]By Status[/bold underline]")
    for k, v in status_counts.items():
        con.print(f"  {k}: {v}")
    con.print("[bold underline]By Priority[/bold underline]")
    for k, v in prio_counts.items():
        con.print(f"  {k}: {v}")
