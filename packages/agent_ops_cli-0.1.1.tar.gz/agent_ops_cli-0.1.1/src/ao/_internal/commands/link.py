"""AO link — dependency link management commands."""

from __future__ import annotations

from typing import Any

from ao._internal.commands.epic import _load_all_issues
from ao._internal.commands.issue import (
    _do_rebuild,
    _encode_and_append,
    _load_issue,
    _make_event_id,
    _next_id,
    _now_iso,
    _resolve_issue_id,
)
from ao._internal.context import AppContext, OutputFormat
from ao._internal.graph import build_adjacency, detect_cycle, generate_mermaid
from ao._internal.output import ErrorCode, emit_error, emit_success
from ao.models import Event, Op

# Supported typed link types (beyond depends_on / blocks).
TYPED_LINK_TYPES = frozenset({"related", "duplicate_of", "discovered_from", "parent", "child"})


def link_add(
    ctx: AppContext,
    issue_id: str,
    *,
    depends_on: str | None = None,
    blocks: str | None = None,
) -> None:
    """Add a dependency link."""
    target = depends_on or blocks
    if not target:
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, "Specify --depends-on or --blocks")
        return

    try:
        issue_id = _resolve_issue_id(ctx, issue_id)
        if depends_on:
            depends_on = _resolve_issue_id(ctx, depends_on)
        if blocks:
            blocks = _resolve_issue_id(ctx, blocks)
    except ValueError as exc:
        emit_error(ctx, ErrorCode.NOT_FOUND, str(exc))
        return

    if (depends_on or blocks) == issue_id:
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, "Cannot link issue to itself")
        return

    ts = _now_iso()
    events: list[Event] = []

    if depends_on:
        num = _next_id(ctx)
        events.append(
            Event(
                event_id=_make_event_id(num),
                issue_id=issue_id,
                op=Op.DEPS_ADD,
                timestamp=ts,
                payload={"depends_on": [depends_on]},
            )
        )
        # Also add reverse blocks link
        num = _next_id(ctx)
        events.append(
            Event(
                event_id=_make_event_id(num),
                issue_id=depends_on,
                op=Op.DEPS_ADD,
                timestamp=ts,
                payload={"blocks": [issue_id]},
            )
        )

    if blocks:
        num = _next_id(ctx)
        events.append(
            Event(
                event_id=_make_event_id(num),
                issue_id=issue_id,
                op=Op.DEPS_ADD,
                timestamp=ts,
                payload={"blocks": [blocks]},
            )
        )
        # Also add reverse depends_on link
        num = _next_id(ctx)
        events.append(
            Event(
                event_id=_make_event_id(num),
                issue_id=blocks,
                op=Op.DEPS_ADD,
                timestamp=ts,
                payload={"depends_on": [issue_id]},
            )
        )

    for evt in events:
        _encode_and_append(ctx, evt)
    _do_rebuild(ctx)
    emit_success(
        ctx,
        {
            "issue_id": issue_id,
            "added": {"depends_on": depends_on, "blocks": blocks},
            "events": [e.event_id for e in events],
        },
    )


def link_rm(
    ctx: AppContext,
    issue_id: str,
    *,
    depends_on: str | None = None,
    blocks: str | None = None,
) -> None:
    """Remove a dependency link."""
    target = depends_on or blocks
    if not target:
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, "Specify --depends-on or --blocks")
        return

    try:
        issue_id = _resolve_issue_id(ctx, issue_id)
        if depends_on:
            depends_on = _resolve_issue_id(ctx, depends_on)
        if blocks:
            blocks = _resolve_issue_id(ctx, blocks)
    except ValueError as exc:
        emit_error(ctx, ErrorCode.NOT_FOUND, str(exc))
        return

    ts = _now_iso()
    events: list[Event] = []

    if depends_on:
        num = _next_id(ctx)
        events.append(
            Event(
                event_id=_make_event_id(num),
                issue_id=issue_id,
                op=Op.DEPS_RM,
                timestamp=ts,
                payload={"depends_on": [depends_on]},
            )
        )
        num = _next_id(ctx)
        events.append(
            Event(
                event_id=_make_event_id(num),
                issue_id=depends_on,
                op=Op.DEPS_RM,
                timestamp=ts,
                payload={"blocks": [issue_id]},
            )
        )

    if blocks:
        num = _next_id(ctx)
        events.append(
            Event(
                event_id=_make_event_id(num),
                issue_id=issue_id,
                op=Op.DEPS_RM,
                timestamp=ts,
                payload={"blocks": [blocks]},
            )
        )
        num = _next_id(ctx)
        events.append(
            Event(
                event_id=_make_event_id(num),
                issue_id=blocks,
                op=Op.DEPS_RM,
                timestamp=ts,
                payload={"depends_on": [issue_id]},
            )
        )

    for evt in events:
        _encode_and_append(ctx, evt)
    _do_rebuild(ctx)
    emit_success(
        ctx,
        {
            "issue_id": issue_id,
            "removed": {"depends_on": depends_on, "blocks": blocks},
            "events": [e.event_id for e in events],
        },
    )


def link_show(ctx: AppContext, issue_id: str) -> None:
    """Display dependency graph for an issue."""
    issue = _load_issue(ctx, issue_id)
    if issue is None:
        emit_error(ctx, ErrorCode.NOT_FOUND, f"Issue {issue_id} not found")
        return

    deps = issue.dependencies
    result: dict[str, Any] = {
        "issue_id": issue_id,
        "depends_on": deps.depends_on,
        "blocks": deps.blocks,
    }
    emit_success(ctx, result)


def link_graph(
    ctx: AppContext,
    *,
    epic: str | None = None,
    fmt: str = "json",
) -> None:
    """Generate dependency graph."""
    issues = _load_all_issues(ctx)
    if epic:
        issues = [i for i in issues if i.epic == epic]

    adj = build_adjacency({i.id: i.dependencies.depends_on for i in issues})
    cycle = detect_cycle(adj)

    if fmt == "mermaid":
        mermaid = generate_mermaid(adj)
        if ctx.format in (OutputFormat.JSON, OutputFormat.JSONL):
            emit_success(
                ctx,
                {
                    "format": "mermaid",
                    "graph": mermaid,
                    "has_cycle": cycle is not None,
                    "cycle": cycle,
                },
            )
        else:
            print(mermaid)  # noqa: T201
            if cycle:
                print(f"\n⚠ Cycle detected: {' → '.join(cycle)}")  # noqa: T201
        return

    result: dict[str, Any] = {
        "nodes": len(adj),
        "edges": sum(len(v) for v in adj.values()),
        "has_cycle": cycle is not None,
        "cycle": cycle,
        "adjacency": {k: v for k, v in adj.items() if v},
    }
    emit_success(ctx, result)


def typed_link_add(ctx: AppContext, issue_id: str, link_type: str, target_id: str) -> None:
    """Add a typed link (related, duplicate_of, discovered_from, parent, child)."""
    if link_type not in TYPED_LINK_TYPES:
        emit_error(
            ctx,
            ErrorCode.VALIDATION_ERROR,
            f"Unknown link type: {link_type!r}. Valid: {', '.join(sorted(TYPED_LINK_TYPES))}",
        )
        return
    try:
        issue_id = _resolve_issue_id(ctx, issue_id)
        target_id = _resolve_issue_id(ctx, target_id)
    except ValueError as exc:
        emit_error(ctx, ErrorCode.NOT_FOUND, str(exc))
        return
    if target_id == issue_id:
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, "Cannot link issue to itself")
        return
    ts = _now_iso()
    num = _next_id(ctx)
    event = Event(
        event_id=_make_event_id(num),
        issue_id=issue_id,
        op=Op.LINK_ADD,
        timestamp=ts,
        payload={"link_type": link_type, "targets": [target_id]},
    )
    _encode_and_append(ctx, event)
    _do_rebuild(ctx)
    emit_success(
        ctx,
        {
            "issue_id": issue_id,
            "link_type": link_type,
            "target": target_id,
            "event_id": event.event_id,
        },
    )


def typed_link_rm(ctx: AppContext, issue_id: str, link_type: str, target_id: str) -> None:
    """Remove a typed link."""
    if link_type not in TYPED_LINK_TYPES:
        emit_error(
            ctx,
            ErrorCode.VALIDATION_ERROR,
            f"Unknown link type: {link_type!r}. Valid: {', '.join(sorted(TYPED_LINK_TYPES))}",
        )
        return
    try:
        issue_id = _resolve_issue_id(ctx, issue_id)
        target_id = _resolve_issue_id(ctx, target_id)
    except ValueError as exc:
        emit_error(ctx, ErrorCode.NOT_FOUND, str(exc))
        return
    ts = _now_iso()
    num = _next_id(ctx)
    event = Event(
        event_id=_make_event_id(num),
        issue_id=issue_id,
        op=Op.LINK_RM,
        timestamp=ts,
        payload={"link_type": link_type, "targets": [target_id]},
    )
    _encode_and_append(ctx, event)
    _do_rebuild(ctx)
    emit_success(
        ctx,
        {
            "issue_id": issue_id,
            "link_type": link_type,
            "removed": target_id,
            "event_id": event.event_id,
        },
    )


def dep_tree(ctx: AppContext, issue_id: str, depth: int = 5) -> None:
    """Traverse dependency tree with depth limit and cycle detection."""
    try:
        issue_id = _resolve_issue_id(ctx, issue_id)
    except ValueError as exc:
        emit_error(ctx, ErrorCode.NOT_FOUND, str(exc))
        return

    all_issues = {i.id: i for i in _load_all_issues(ctx)}
    if issue_id not in all_issues:
        emit_error(ctx, ErrorCode.NOT_FOUND, f"Issue {issue_id} not found")
        return

    visited: set[str] = set()
    tree = _build_tree(issue_id, all_issues, visited, depth)
    cycle_detected = _check_cycle_in_traversal(issue_id, all_issues, depth * 2)
    emit_success(
        ctx, {"root": issue_id, "depth": depth, "cycle_detected": cycle_detected, "tree": tree}
    )


def _build_tree(
    node: str,
    all_issues: dict[str, Any],
    visited: set[str],
    depth: int,
) -> dict[str, Any]:
    """Recursively build a dependency tree node."""
    if depth <= 0 or node in visited:
        return {"id": node, "truncated": True}
    visited = {*visited, node}
    issue = all_issues.get(node)
    if issue is None:
        return {"id": node, "missing": True}
    children = [
        _build_tree(dep, all_issues, visited, depth - 1) for dep in issue.dependencies.depends_on
    ]
    typed = {lt: tgts for lt, tgts in issue.links.items() if tgts}
    return {
        "id": node,
        "title": issue.title,
        "status": str(issue.status),
        "depends_on": children,
        "links": typed,
    }


def _check_cycle_in_traversal(root: str, all_issues: dict[str, Any], max_depth: int) -> bool:
    """Return True if a cycle is reachable from root via depends_on."""
    adj = {i.id: i.dependencies.depends_on for i in all_issues.values()}
    from ao._internal.graph import detect_cycle

    root_adj = {k: v for k, v in adj.items() if k == root or _reachable(root, k, adj, max_depth)}
    return detect_cycle(root_adj) is not None


def _reachable(start: str, target: str, adj: dict[str, list[str]], depth: int) -> bool:
    """Return True if target is reachable from start within depth hops."""
    if depth <= 0:
        return False
    return any(
        dep == target or _reachable(dep, target, adj, depth - 1) for dep in adj.get(start, [])
    )
