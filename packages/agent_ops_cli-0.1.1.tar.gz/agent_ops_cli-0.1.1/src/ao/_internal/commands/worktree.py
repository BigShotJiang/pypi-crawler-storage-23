"""CLI commands for git worktree management."""

from __future__ import annotations

import json
import re
import subprocess
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from rich.console import Console

from ao._internal.output import ErrorCode, emit_error, emit_success

if TYPE_CHECKING:
    from ao._internal.context import AppContext

_AO_CONFIG_DIR = ".ao"
_CONFIG_FILE = "config.json"

console = Console()

# Launch-with option → CLI command mapping
_LAUNCH_COMMANDS: dict[str, str] = {
    "editor": "",
    "copilot": "code",
    "opencode": "opencode",
    "claude": "claude",
}

VALID_LAUNCH_OPTIONS = frozenset(_LAUNCH_COMMANDS.keys())

# Options that are CLI tools requiring a terminal window
_CLI_LAUNCH_OPTIONS = frozenset({"opencode", "claude"})


def _editor_for_engine(engine: str) -> str:
    """Return the editor command for a worker engine."""
    return _LAUNCH_COMMANDS.get(engine, "code")


def _ao_config_path() -> Path:
    """Return path to ~/.ao/config.json."""
    return Path.home() / _AO_CONFIG_DIR / _CONFIG_FILE


def _read_config() -> dict[str, str]:
    """Read ~/.ao/config.json if it exists, else return empty dict."""
    cfg_path = _ao_config_path()
    if not cfg_path.exists():
        return {}
    raw = cfg_path.read_bytes()
    result: dict[str, str] = json.loads(raw)
    return result


def _write_config(config: dict[str, str]) -> Path:
    """Write config to ~/.ao/config.json, creating dirs as needed."""
    cfg_path = _ao_config_path()
    cfg_path.parent.mkdir(parents=True, exist_ok=True)
    cfg_path.write_text(
        json.dumps(config, indent=2) + "\n",
        encoding="utf-8",
    )
    return cfg_path


def _default_config() -> dict[str, str]:
    """Return default config values."""
    return {"editor": "code", "terminal": "wt", "worktree_dir": ""}


def _ensure_config(ctx: AppContext) -> dict[str, str] | None:
    """Ensure ~/.ao/config.json exists. Return config or None if user declined."""
    config = _read_config()
    if config:
        return config
    if ctx.yes:
        config = _default_config()
        _write_config(config)
        return config
    console.print("[yellow]~/.ao/config.json not found.[/yellow]")
    console.print("Create it with defaults?")
    console.print("  editor: code")
    console.print("  terminal: wt")
    console.print("  worktree_dir: (adjacent to repo)")
    answer: str = console.input("[bold]Create config? [Y/n]: [/bold]").strip()
    if answer.lower() in ("n", "no"):
        return None
    config = _default_config()
    _write_config(config)
    console.print(f"[green]Created:[/green] {_ao_config_path()}")
    return config


def _git_available() -> bool:
    """Check if git is available on PATH."""
    try:
        subprocess.run(  # noqa: S603
            ["git", "--version"],  # noqa: S607
            capture_output=True,
            check=True,
        )
    except (FileNotFoundError, subprocess.CalledProcessError):
        return False
    return True


def _is_git_repo() -> bool:
    """Check if CWD is inside a git repo."""
    try:
        subprocess.run(  # noqa: S603
            ["git", "rev-parse", "--git-dir"],  # noqa: S607
            capture_output=True,
            check=True,
        )
    except (FileNotFoundError, subprocess.CalledProcessError):
        return False
    return True


def _current_branch() -> str:
    """Get the current git branch name."""
    result = subprocess.run(  # noqa: S603
        ["git", "rev-parse", "--abbrev-ref", "HEAD"],  # noqa: S607
        capture_output=True,
        text=True,
        check=True,
    )
    return result.stdout.strip()


def _repo_name() -> str:
    """Get the current repo directory name."""
    result = subprocess.run(  # noqa: S603
        ["git", "rev-parse", "--show-toplevel"],  # noqa: S607
        capture_output=True,
        text=True,
        check=True,
    )
    return Path(result.stdout.strip()).name


def _resolve_worktree_path(
    config: dict[str, str],
    branch: str,
) -> Path:
    """Resolve the full worktree path from config and branch name."""
    worktree_dir = config.get("worktree_dir", "")
    if worktree_dir:
        base = Path(worktree_dir).expanduser()
    else:
        repo = _repo_name()
        top = subprocess.run(  # noqa: S603
            ["git", "rev-parse", "--show-toplevel"],  # noqa: S607
            capture_output=True,
            text=True,
            check=True,
        )
        repo_parent = Path(top.stdout.strip()).parent
        base = repo_parent / f"{repo}-worktrees"
    safe_branch = branch.replace("/", "-")
    return base / safe_branch


def _build_terminal_cmd(
    terminal: str,
    cli_cmd: str,
    path: Path,
    *,
    cli_args: list[str] | None = None,
) -> list[str]:
    """Build args to launch *cli_cmd* inside *terminal* at *path*."""
    extra = cli_args or []
    full_cli = " ".join([cli_cmd, *extra]) if extra else cli_cmd
    name = Path(terminal).stem.lower()
    if name in ("wt", "windowsterminal"):
        return [terminal, "-d", str(path), cli_cmd, *extra]
    if name in ("pwsh", "powershell"):
        return [
            terminal,
            "-NoExit",
            "-WorkingDirectory",
            str(path),
            "-Command",
            full_cli,
        ]
    if name == "cmd":
        return [terminal, "/k", f"cd /d {path} && {full_cli}"]
    return [terminal, "-e", full_cli]


def _cli_prompt_args(
    launch_with: str,
    prompt_file: Path,
    wt_root: Path,
) -> list[str]:
    """Return extra CLI args to pass a prompt file to the agent."""
    try:
        rel = prompt_file.relative_to(wt_root).as_posix()
    except ValueError:
        rel = prompt_file.name
    msg = f"Read and follow the instructions in {rel}"
    if launch_with == "opencode":
        return ["run", msg]
    if launch_with == "claude":
        return [msg]
    return []


def _open_editor(
    config: dict[str, str],
    path: Path,
    *,
    launch_with: str = "",
    prompt_file: Path | None = None,
) -> str:
    """Open the worktree path in an editor or agent CLI.

    GUI tools (editor, copilot/VS Code) are launched directly.
    CLI tools (opencode, claude) are launched inside the configured
    terminal emulator, optionally with a prompt file.

    Returns:
        The command that was launched.
    """
    import os
    import shutil

    cmd = _LAUNCH_COMMANDS.get(launch_with, "")
    if not cmd:
        cmd = config.get("editor", "")
        if not cmd:
            cmd = os.environ.get("EDITOR", "code")

    resolved_cmd = shutil.which(cmd) or cmd

    if launch_with in _CLI_LAUNCH_OPTIONS:
        terminal = config.get("terminal", "")
        if not terminal:
            terminal = "wt"
        resolved_term = shutil.which(terminal) or terminal
        cli_args: list[str] | None = None
        if prompt_file and prompt_file.exists():
            cli_args = _cli_prompt_args(launch_with, prompt_file, path)
        args = _build_terminal_cmd(
            resolved_term,
            resolved_cmd,
            path,
            cli_args=cli_args,
        )
    else:
        args = [resolved_cmd, str(path)]

    subprocess.Popen(args)  # noqa: S603
    return cmd


def worktree_create(
    ctx: AppContext,
    branch: str | None = None,
    new_branch: str | None = None,
    edit: bool = False,
) -> None:
    """Create a git worktree."""
    if not _git_available():
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, "git is not available on PATH")
        return
    if not _is_git_repo():
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, "Not inside a git repository")
        return
    config = _ensure_config(ctx)
    if config is None:
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, "Config creation declined, aborting")
        return

    source = branch or _current_branch()
    wt_branch = new_branch or source
    wt_path = _resolve_worktree_path(config, wt_branch)

    cmd: list[str] = ["git", "worktree", "add"]
    if new_branch:
        cmd.extend(["-b", new_branch])
    cmd.append(str(wt_path))
    if branch:
        cmd.append(branch)

    try:
        subprocess.run(cmd, check=True, capture_output=True, text=True)  # noqa: S603
    except subprocess.CalledProcessError as exc:
        emit_error(
            ctx, ErrorCode.VALIDATION_ERROR, f"git worktree add failed: {exc.stderr.strip()}"
        )
        return

    result: dict[str, str | bool] = {
        "path": str(wt_path),
        "branch": wt_branch,
        "source": source,
        "new_branch": bool(new_branch),
    }

    if edit:
        _open_editor(config, wt_path)
        result["opened_in_editor"] = True

    emit_success(ctx, result)


def worktree_ls(ctx: AppContext) -> None:
    """List existing git worktrees."""
    if not _git_available():
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, "git is not available on PATH")
        return
    if not _is_git_repo():
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, "Not inside a git repository")
        return

    result = subprocess.run(  # noqa: S603
        ["git", "worktree", "list", "--porcelain"],  # noqa: S607
        capture_output=True,
        text=True,
        check=True,
    )
    worktrees: list[dict[str, str]] = []
    current: dict[str, str] = {}
    for line in result.stdout.splitlines():
        if not line.strip():
            if current:
                worktrees.append(current)
                current = {}
            continue
        if line.startswith("worktree "):
            current["path"] = line[len("worktree ") :]
        elif line.startswith("HEAD "):
            current["head"] = line[len("HEAD ") :]
        elif line.startswith("branch "):
            current["branch"] = line[len("branch ") :]
        elif line == "bare":
            current["bare"] = "true"
        elif line == "detached":
            current["detached"] = "true"
    if current:
        worktrees.append(current)
    emit_success(ctx, {"worktrees": worktrees, "count": len(worktrees)})


def worktree_rm(ctx: AppContext, path: str) -> None:
    """Remove a git worktree."""
    if not _git_available():
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, "git is not available on PATH")
        return
    if not _is_git_repo():
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, "Not inside a git repository")
        return

    try:
        subprocess.run(  # noqa: S603
            ["git", "worktree", "remove", path],  # noqa: S607
            check=True,
            capture_output=True,
            text=True,
        )
    except subprocess.CalledProcessError as exc:
        emit_error(
            ctx, ErrorCode.VALIDATION_ERROR, f"git worktree remove failed: {exc.stderr.strip()}"
        )
        return
    emit_success(ctx, {"removed": path})


# ── manifest helpers ─────────────────────────────────────────────────────────

_MANIFEST_FILE = "worktrees.json"


def _manifest_path(ctx: AppContext) -> Path:
    """Return path to .agent/ops/worktrees.json."""
    return ctx.root / _MANIFEST_FILE


def _load_manifest(ctx: AppContext) -> list[dict[str, Any]]:
    """Load worktree manifest or return empty list."""
    mp = _manifest_path(ctx)
    if not mp.exists():
        return []
    result: list[dict[str, Any]] = json.loads(mp.read_bytes())
    return result


def _save_manifest(ctx: AppContext, entries: list[dict[str, Any]]) -> None:
    """Write worktree manifest atomically."""
    mp = _manifest_path(ctx)
    mp.parent.mkdir(parents=True, exist_ok=True)
    mp.write_text(json.dumps(entries, indent=2) + "\n", encoding="utf-8")


def _add_to_manifest(ctx: AppContext, entry: dict[str, Any]) -> None:
    """Append an entry to the manifest and save."""
    entries = _load_manifest(ctx)
    entries.append(entry)
    _save_manifest(ctx, entries)


def _remove_from_manifest(ctx: AppContext, wt_path: str) -> None:
    """Remove an entry by path and save."""
    entries = _load_manifest(ctx)
    entries = [e for e in entries if e.get("path") != wt_path]
    _save_manifest(ctx, entries)


def _slugify(text: str) -> str:
    """Convert text to a safe branch-name slug."""
    slug = text.lower().strip()
    slug = re.sub(r"[^a-z0-9]+", "-", slug)
    return slug.strip("-")


# ── worktree add ─────────────────────────────────────────────────────────────


def _scope_active_jsonl(wt_path: Path, epic: str, ctx: AppContext) -> list[str]:
    """Write a scoped active.jsonl containing only issues matching *epic*."""
    from ao.api import AOClient
    from ao.codec import MsgspecCodec
    from ao.store import AOPaths

    client = AOClient(AOPaths(ctx.root), codec="msgspec")
    issues = client.list({"epic": epic})
    codec = MsgspecCodec()
    active_path = wt_path / ".agent" / "ops" / "issues" / "active.jsonl"
    active_path.parent.mkdir(parents=True, exist_ok=True)

    from ao._internal.io import atomic_write_jsonl
    from ao.models import Issue

    lines: list[bytes] = []
    ids: list[str] = []
    for item in issues:
        if isinstance(item, Issue):
            lines.append(codec.encode_issue(item))
            ids.append(item.id)
        else:
            ids.append(str(item.get("id", "")))
    atomic_write_jsonl(active_path, iter(lines))
    return ids


def _write_dispatch_json(
    wt_path: Path,
    *,
    branch: str,
    source: str,
    epic: str,
    issue_ids: list[str],
) -> None:
    """Write .ao/dispatch.json into the worktree."""
    dispatch_dir = wt_path / ".ao"
    dispatch_dir.mkdir(parents=True, exist_ok=True)
    cfg = {
        "branch": branch,
        "source": source,
        "epic": epic,
        "issue_ids": issue_ids,
    }
    (dispatch_dir / "dispatch.json").write_text(json.dumps(cfg, indent=2) + "\n", encoding="utf-8")


def _write_prompt_file(
    wt_path: Path,
    prompt: str,
) -> Path:
    """Write .ao/prompt.md in the worktree from text or file reference."""
    prompt_dir = wt_path / ".ao"
    prompt_dir.mkdir(parents=True, exist_ok=True)
    prompt_path = prompt_dir / "prompt.md"
    src = Path(prompt)
    if src.is_file():
        content = src.read_text(encoding="utf-8")
    else:
        content = prompt
    prompt_path.write_text(content, encoding="utf-8")
    return prompt_path


def worktree_add(
    ctx: AppContext,
    *,
    epic: str = "",
    open_with: str = "",
    prompt: str = "",
    branch: str = "",
) -> None:
    """Create a git worktree with optional epic scoping and editor launch."""
    if not _git_available():
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, "git is not available on PATH")
        return
    if not _is_git_repo():
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, "Not inside a git repository")
        return
    config = _ensure_config(ctx)
    if config is None:
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, "Config creation declined")
        return
    if prompt and open_with and open_with not in _CLI_LAUNCH_OPTIONS:
        emit_error(
            ctx,
            ErrorCode.VALIDATION_ERROR,
            f"--prompt requires an agent CLI (opencode, claude), not '{open_with}'",
        )
        return

    source = _current_branch()
    if not branch:
        branch = f"wt/{_slugify(epic)}" if epic else f"wt/{source}"
    wt_path = _resolve_worktree_path(config, branch)

    cmd: list[str] = ["git", "worktree", "add", "-b", branch, str(wt_path)]
    try:
        subprocess.run(cmd, check=True, capture_output=True, text=True)  # noqa: S603
    except subprocess.CalledProcessError as exc:
        emit_error(
            ctx, ErrorCode.VALIDATION_ERROR, f"git worktree add failed: {exc.stderr.strip()}"
        )
        return

    issue_ids: list[str] = []
    if epic:
        issue_ids = _scope_active_jsonl(wt_path, epic, ctx)

    _write_dispatch_json(wt_path, branch=branch, source=source, epic=epic, issue_ids=issue_ids)

    now = datetime.now(UTC).isoformat()
    _add_to_manifest(
        ctx,
        {
            "path": str(wt_path),
            "branch": branch,
            "source": source,
            "epic": epic,
            "issue_ids": issue_ids,
            "created": now,
        },
    )

    prompt_file: Path | None = None
    if prompt:
        prompt_file = _write_prompt_file(wt_path, prompt)

    result: dict[str, Any] = {
        "path": str(wt_path),
        "branch": branch,
        "source": source,
        "epic": epic,
        "issue_ids": issue_ids,
    }

    if open_with:
        _open_editor(
            config,
            wt_path,
            launch_with=open_with,
            prompt_file=prompt_file,
        )
        result["opened"] = open_with

    emit_success(ctx, result)


# ── worktree merge ───────────────────────────────────────────────────────────


def _count_lines(path: Path) -> int:
    """Count non-empty lines in a JSONL file."""
    if not path.exists():
        return 0
    count = 0
    with open(path, "rb") as f:
        for line in f:
            if line.strip():
                count += 1
    return count


def _merge_events(source_events: Path, wt_events: Path) -> int:
    """Append new events from worktree into source. Returns count appended."""
    if not wt_events.exists():
        return 0
    source_ids: set[str] = set()
    if source_events.exists():
        for line in open(source_events, "rb"):
            stripped = line.strip()
            if not stripped:
                continue
            try:
                evt: dict[str, Any] = json.loads(stripped)
                eid = evt.get("event_id", "")
                if eid:
                    source_ids.add(eid)
            except (json.JSONDecodeError, TypeError):
                continue

    new_lines: list[bytes] = []
    for line in open(wt_events, "rb"):
        stripped = line.strip()
        if not stripped:
            continue
        try:
            evt = json.loads(stripped)
            eid = evt.get("event_id", "")
            if eid and eid not in source_ids:
                new_lines.append(stripped)
        except (json.JSONDecodeError, TypeError):
            continue

    if new_lines:
        with open(source_events, "ab") as f:
            for line_bytes in new_lines:
                f.write(line_bytes + b"\n")
    return len(new_lines)


def _parse_memory_sections(text: str) -> dict[str, str]:
    """Parse memory.md into {header: full_section_text} mapping."""
    sections: dict[str, str] = {}
    current_header = ""
    current_lines: list[str] = []
    for line in text.splitlines():
        if line.startswith("### "):
            if current_header:
                sections[current_header] = "\n".join(current_lines)
            current_header = line
            current_lines = [line]
        elif current_header:
            current_lines.append(line)
    if current_header:
        sections[current_header] = "\n".join(current_lines)
    return sections


def _merge_memory(source_path: Path, wt_path: Path) -> int:
    """Append new ### sections from worktree memory into source. Returns count."""
    if not wt_path.exists():
        return 0
    source_text = source_path.read_text(encoding="utf-8") if source_path.exists() else ""
    wt_text = wt_path.read_text(encoding="utf-8")

    source_sections = _parse_memory_sections(source_text)
    wt_sections = _parse_memory_sections(wt_text)

    new_sections: list[str] = []
    for header, body in wt_sections.items():
        if header not in source_sections:
            new_sections.append(body)

    if new_sections and source_path.exists():
        with open(source_path, "a", encoding="utf-8") as f:
            for section in new_sections:
                f.write("\n\n" + section)
    return len(new_sections)


def _merge_references(source_dir: Path, wt_dir: Path) -> int:
    """Copy new or modified reference files from worktree to source."""
    if not wt_dir.exists():
        return 0
    source_dir.mkdir(parents=True, exist_ok=True)
    count = 0
    for wt_file in wt_dir.iterdir():
        if not wt_file.is_file():
            continue
        src_file = source_dir / wt_file.name
        if not src_file.exists():
            src_file.write_bytes(wt_file.read_bytes())
            count += 1
        elif wt_file.stat().st_mtime > src_file.stat().st_mtime:
            src_file.write_bytes(wt_file.read_bytes())
            count += 1
    return count


def _merge_single_worktree(
    ctx: AppContext,
    entry: dict[str, Any],
) -> dict[str, Any]:
    """Merge a single worktree back to its source branch."""
    wt_path = Path(entry["path"])
    branch = entry["branch"]
    source = entry["source"]

    # 1. Git merge
    try:
        subprocess.run(  # noqa: S603
            ["git", "checkout", source],  # noqa: S607
            check=True,
            capture_output=True,
            text=True,
        )
        subprocess.run(  # noqa: S603
            ["git", "merge", branch, "--no-edit"],  # noqa: S607
            check=True,
            capture_output=True,
            text=True,
        )
    except subprocess.CalledProcessError as exc:
        return {"path": str(wt_path), "error": f"git merge failed: {exc.stderr.strip()}"}

    # 2. Merge ops files
    ops = ctx.root
    wt_ops = wt_path / ".agent" / "ops"

    events_merged = _merge_events(
        ops / "issues" / "events.jsonl",
        wt_ops / "issues" / "events.jsonl",
    )
    memory_merged = _merge_memory(
        ops / "memory.md",
        wt_ops / "memory.md",
    )
    refs_merged = _merge_references(
        ops / "issues" / "references",
        wt_ops / "issues" / "references",
    )

    # 3. Rebuild active.jsonl from merged events
    from ao.codec import MsgspecCodec
    from ao.store import rebuild as do_rebuild

    do_rebuild(
        ops / "issues" / "events.jsonl",
        ops / "issues" / "active.jsonl",
        MsgspecCodec(),
    )

    # 4. Remove worktree + branch
    try:
        subprocess.run(  # noqa: S603
            ["git", "worktree", "remove", str(wt_path)],  # noqa: S607
            check=True,
            capture_output=True,
            text=True,
        )
        subprocess.run(  # noqa: S603
            ["git", "branch", "-d", branch],  # noqa: S607
            capture_output=True,
            text=True,
            check=False,
        )
    except subprocess.CalledProcessError:
        pass

    _remove_from_manifest(ctx, str(wt_path))

    return {
        "path": str(wt_path),
        "branch": branch,
        "events_merged": events_merged,
        "memory_sections_merged": memory_merged,
        "references_merged": refs_merged,
    }


def worktree_merge(
    ctx: AppContext,
    *,
    worktree_path: str = "",
) -> None:
    """Merge worktree(s) back to source branch."""
    if not _git_available():
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, "git is not available on PATH")
        return
    if not _is_git_repo():
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, "Not inside a git repository")
        return

    manifest = _load_manifest(ctx)
    if not manifest:
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, "No managed worktrees found")
        return

    if worktree_path:
        entries = [e for e in manifest if e.get("path") == worktree_path]
        if not entries:
            emit_error(
                ctx, ErrorCode.VALIDATION_ERROR, f"Worktree not found in manifest: {worktree_path}"
            )
            return
    else:
        entries = list(manifest)

    results: list[dict[str, Any]] = []
    for entry in entries:
        result = _merge_single_worktree(ctx, entry)
        results.append(result)

    emit_success(ctx, {"merged": results, "count": len(results)})
