"""AO install — install bundled AO assets into a target folder."""

from __future__ import annotations

import re
import shutil
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from git import InvalidGitRepositoryError, NoSuchPathError, Repo
from prompt_toolkit.shortcuts import (
    button_dialog,
    checkboxlist_dialog,
    message_dialog,
    radiolist_dialog,
)
from prompt_toolkit.styles import Style as PTStyle
from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.progress import BarColumn, Progress, SpinnerColumn, TextColumn
from rich.prompt import Confirm
from rich.table import Table
from rich.text import Text
from rich.tree import Tree

from ao._internal.context import AppContext, OutputFormat
from ao._internal.output import ErrorCode, emit_error, emit_success

_HAS_PROMPT_TOOLKIT = True

_AO_DIR = ".ao"
_OPTIONAL_DIRS = (".github", ".claude", ".opencode")
_CATEGORY_RE = re.compile(r"^category:\s*(.+)$", re.IGNORECASE)
_NAME_RE = re.compile(r"^name:\s*(.+)$", re.IGNORECASE)
_DESC_RE = re.compile(r"^description:\s*(.+)$", re.IGNORECASE)


def _pt_style() -> PTStyle:
    """Return modern style for prompt_toolkit dialogs."""
    return PTStyle.from_dict(
        {
            "dialog": "bg:#111827",
            "dialog.body": "bg:#111827 #e5e7eb",
            "dialog frame.label": "bg:#2563eb #f8fafc bold",
            "dialog shadow": "bg:#0f172a",
            "button": "bg:#1f2937 #cbd5e1",
            "button.focused": "bg:#2563eb #f8fafc bold",
            "checkbox": "#22c55e",
            "checkbox-selected": "#22c55e bold",
            "radio": "#38bdf8",
            "radio-selected": "#38bdf8 bold",
        }
    )


def install_assets(
    ctx: AppContext,
    target: Path | None,
    *,
    with_github: bool | None,
    with_claude: bool | None,
    with_opencode: bool | None,
    categories: list[str] | None,
    force: bool,
    skip_existing: bool,
) -> None:
    """Install AO assets into target dir.

    `.ao` core is always installed. Optional engine folders are interactive
    unless explicit flags are provided or `--yes` mode is enabled.
    """
    _apply_assets(
        ctx,
        target,
        with_github=with_github,
        with_claude=with_claude,
        with_opencode=with_opencode,
        categories=categories,
        force=force,
        skip_existing=skip_existing,
        manage_agent_ops=True,
    )


def update_assets(
    ctx: AppContext,
    target: Path | None,
    *,
    with_github: bool | None,
    with_claude: bool | None,
    with_opencode: bool | None,
    categories: list[str] | None,
    force: bool,
    skip_existing: bool,
) -> None:
    """Update AO assets without touching `.agent` files.

    Core `.ao` remains mandatory and is always refreshed/installed.
    """
    _apply_assets(
        ctx,
        target,
        with_github=with_github,
        with_claude=with_claude,
        with_opencode=with_opencode,
        categories=categories,
        force=force,
        skip_existing=skip_existing,
        manage_agent_ops=False,
    )


def _apply_assets(
    ctx: AppContext,
    target: Path | None,
    *,
    with_github: bool | None,
    with_claude: bool | None,
    with_opencode: bool | None,
    categories: list[str] | None,
    force: bool,
    skip_existing: bool,
    manage_agent_ops: bool,
) -> None:
    """Apply installer asset copy flow in install or update mode."""
    con = Console()
    asset_root = _resolve_asset_root()
    target_root = (target or Path.cwd()).resolve()
    is_rich = ctx.format not in (OutputFormat.JSON, OutputFormat.JSONL)
    if is_rich:
        _print_welcome_banner(con, target_root)
    selected, flags = _resolve_install_options(
        asset_root,
        categories,
        ctx.yes,
        con,
        with_github,
        with_claude,
        with_opencode,
        is_rich,
    )
    base_created = _ensure_agent_ops_base(target_root) if manage_agent_ops else []
    copied, skipped, overwritten = _install_with_progress(
        asset_root, target_root, selected, flags, force, skip_existing, ctx.yes, con,
        show_progress=is_rich,
    )
    index_path = _generate_skills_index(target_root / _AO_DIR, selected)
    result = _build_result(
        target_root, copied, skipped, overwritten, selected, flags, index_path, base_created
    )
    if not is_rich:
        emit_success(ctx, result)
        return
    _render_install_summary(con, result)


def _resolve_install_options(
    asset_root: Path,
    categories: list[str] | None,
    yes_mode: bool,
    con: Console,
    with_github: bool | None,
    with_claude: bool | None,
    with_opencode: bool | None,
    is_rich: bool,
) -> tuple[set[str], dict[str, bool]]:
    """Resolve install selections via wizard or fallback prompts."""
    use_wizard = _should_use_wizard(
        yes_mode, is_rich, categories, with_github, with_claude, with_opencode
    )
    if use_wizard:
        return _resolve_install_wizard(
            asset_root,
            categories,
            with_github,
            with_claude,
            with_opencode,
        )
    selected = _resolve_categories(asset_root, categories, yes_mode, con)
    flags = _resolve_optional_flags(yes_mode, with_github, with_claude, with_opencode, con)
    return selected, flags


def _should_use_wizard(
    yes_mode: bool,
    is_rich: bool,
    categories: list[str] | None,
    with_github: bool | None,
    with_claude: bool | None,
    with_opencode: bool | None,
) -> bool:
    """Return whether dialog wizard should be used."""
    if not is_rich or yes_mode or not _HAS_PROMPT_TOOLKIT:
        return False
    if categories is None:
        return True
    return any(v is None for v in (with_github, with_claude, with_opencode))


def _resolve_install_wizard(
    asset_root: Path,
    categories: list[str] | None,
    with_github: bool | None,
    with_claude: bool | None,
    with_opencode: bool | None,
) -> tuple[set[str], dict[str, bool]]:
    """Resolve categories and optional assets with a dialog wizard."""
    ao_root = asset_root / _AO_DIR
    catalog = _build_category_catalog(ao_root)
    available = sorted(_discover_categories(ao_root))
    selected = set(available) if categories is None else {c.strip().lower() for c in categories if c.strip()}
    flags, locked = _initial_optional_state(with_github, with_claude, with_opencode)
    return _run_install_wizard(selected, flags, locked, available, catalog)


def _initial_optional_state(
    with_github: bool | None,
    with_claude: bool | None,
    with_opencode: bool | None,
) -> tuple[dict[str, bool], dict[str, bool]]:
    """Create mutable optional flags and lock-state map from CLI args."""
    raw = {".github": with_github, ".claude": with_claude, ".opencode": with_opencode}
    flags = {k: bool(v) for k, v in raw.items()}
    locked = {k: v is not None for k, v in raw.items()}
    return flags, locked


def _run_install_wizard(
    selected: set[str],
    flags: dict[str, bool],
    locked: dict[str, bool],
    available: list[str],
    catalog: dict[str, list[dict[str, str]]],
) -> tuple[set[str], dict[str, bool]]:
    """Execute button-based wizard loop for install planning."""
    assert button_dialog is not None
    while True:
        text = _render_install_plan_text(selected, flags, locked, catalog)
        action = button_dialog(
            title="AO Install · Setup Wizard",
            text=text,
            buttons=[
                ("Categories", "cats"),
                ("Optional assets", "opts"),
                ("Preview category", "preview"),
                ("Continue", "done"),
            ],
            style=_pt_style(),
        ).run()
        if action in (None, "done"):
            return selected or set(available), flags
        if action == "cats":
            picked = _ptk_pick_categories(available, selected, catalog)
            if picked is not None:
                selected = picked
        if action == "opts":
            flags = _ptk_pick_optional(flags, locked)
        if action == "preview":
            _ptk_view_category(available, catalog)


def _ptk_pick_optional(flags: dict[str, bool], locked: dict[str, bool]) -> dict[str, bool]:
    """Dialog selector for optional assets honoring locked CLI values."""
    assert checkboxlist_dialog is not None
    pending = [name for name in _OPTIONAL_DIRS if not locked.get(name, False)]
    if not pending:
        return flags
    defaults = [name for name in pending if flags.get(name, False)]
    values = [(name, f"Install {name} assets") for name in pending]
    picked = checkboxlist_dialog(
        title="Optional assets",
        text="Select optional engine folders to install.",
        values=values,
        default_values=defaults,
        style=_pt_style(),
    ).run()
    if picked is None:
        return flags
    selected = set(picked)
    next_flags = dict(flags)
    for name in pending:
        next_flags[name] = name in selected
    return next_flags


def _render_install_plan_text(
    selected: set[str],
    flags: dict[str, bool],
    locked: dict[str, bool],
    catalog: dict[str, list[dict[str, str]]],
) -> str:
    """Build live plan preview text for wizard dialog."""
    lines = ["Review selections before installation.", ""]
    lines.append(f"Categories selected: {len(selected)}")
    for name in sorted(selected):
        count = len(catalog.get(name, []))
        lines.append(f"  • {name} ({count} item{'s' if count != 1 else ''})")
    lines.append("")
    lines.append("Optional assets:")
    for name in _OPTIONAL_DIRS:
        value = "on" if flags.get(name, False) else "off"
        badge = " [locked]" if locked.get(name, False) else ""
        lines.append(f"  • {name}: {value}{badge}")
    lines.append("")
    lines.append("Tip: use 'Preview category' to inspect content before continue.")
    return "\n".join(lines)


def _print_welcome_banner(con: Console, target_root: Path) -> None:
    """Print a welcoming header before interactive prompts."""
    banner = Text.assemble(
        ("AO Install\n", "bold cyan"),
        (f"Target: {target_root}\n", "dim"),
        ("Interactive mode: checklist selector + live progress", "green"),
    )
    con.print(Panel(banner, border_style="cyan", title="[bold]ao[/bold]", expand=False))
    con.print()


def _build_result(
    target_root: Path,
    copied: list[str],
    skipped: list[str],
    overwritten: list[str],
    selected: set[str],
    flags: dict[str, bool],
    index_path: Path,
    base_created: list[str],
) -> dict[str, Any]:
    return {
        "target": str(target_root),
        "copied": copied,
        "skipped": skipped,
        "overwritten": overwritten,
        "categories": sorted(selected),
        "installed_optional": {k: v for k, v in flags.items() if v},
        "generated": [str(index_path)],
        "agent_ops": {
            "root": str(target_root / ".agent" / "ops"),
            "created": base_created,
        },
    }


def _install_with_progress(
    asset_root: Path,
    target_root: Path,
    selected: set[str],
    flags: dict[str, bool],
    force: bool,
    skip_existing: bool,
    yes_mode: bool,
    con: Console,
    *,
    show_progress: bool = True,
) -> tuple[list[str], list[str], list[str]]:
    """Install .ao and optional dirs with a progress bar."""
    all_files = _collect_install_files(asset_root, target_root, selected, flags)
    copied: list[str] = []
    skipped: list[str] = []
    overwritten: list[str] = []
    if show_progress:
        with _make_progress(con) as progress:
            task = progress.add_task("Installing", total=len(all_files))
            for src, dst, keep in all_files:
                _copy_file(
                    src=src, dst=dst, keep_existing=keep, force=force,
                    skip_existing=skip_existing, yes_mode=yes_mode, con=con,
                    copied=copied, skipped=skipped, overwritten=overwritten,
                )
                progress.advance(task)
    else:
        for src, dst, keep in all_files:
            _copy_file(
                src=src, dst=dst, keep_existing=keep, force=force,
                skip_existing=skip_existing, yes_mode=yes_mode, con=con,
                copied=copied, skipped=skipped, overwritten=overwritten,
            )
    return copied, skipped, overwritten


def _collect_install_files(
    asset_root: Path,
    target_root: Path,
    selected: set[str],
    flags: dict[str, bool],
) -> list[tuple[Path, Path, bool]]:
    """Gather all (src, dst, keep_existing) tuples for the install."""
    files: list[tuple[Path, Path, bool]] = []
    _collect_ao_files(asset_root, target_root, selected, files)
    _collect_optional_files(asset_root, target_root, flags, files)
    return files


def _collect_ao_files(
    asset_root: Path,
    target_root: Path,
    selected: set[str],
    files: list[tuple[Path, Path, bool]],
) -> None:
    src_dir = asset_root / _AO_DIR
    dst_dir = target_root / _AO_DIR
    for file_path in _iter_files(src_dir):
        rel = file_path.relative_to(src_dir)
        if _is_categorized(rel) and _extract_category(file_path) not in selected:
            continue
        files.append((file_path, dst_dir / rel, _is_skill_preferences(rel)))


def _collect_optional_files(
    asset_root: Path,
    target_root: Path,
    flags: dict[str, bool],
    files: list[tuple[Path, Path, bool]],
) -> None:
    for name in _OPTIONAL_DIRS:
        if not flags.get(name, False):
            continue
        src_dir = asset_root / name
        if not src_dir.exists():
            continue
        for file_path in _iter_files(src_dir):
            rel = file_path.relative_to(src_dir)
            files.append((file_path, target_root / name / rel, False))


def _make_progress(con: Console) -> Progress:
    return Progress(
        SpinnerColumn(),
        TextColumn("[bold blue]{task.description}"),
        BarColumn(bar_width=30),
        TextColumn("[cyan]{task.completed}/{task.total}[/cyan] files"),
        console=con,
        transient=True,
    )


def _render_install_summary(con: Console, result: dict[str, Any]) -> None:
    con.print()
    title = "[bold green]\u2714 Install Complete[/bold green]"
    con.print(Panel(title, border_style="green", expand=False))
    _render_stats_table(con, result)
    _render_file_tree(con, result)
    _render_agent_ops_created(con, result)
    idx = result["generated"][0]
    con.print(f"  [bold]skills-index[/bold]: [cyan]{idx}[/cyan]")
    con.print()


def _render_stats_table(con: Console, result: dict[str, Any]) -> None:
    stats = Table(show_header=True, header_style="bold magenta", expand=False)
    stats.add_column("Metric")
    stats.add_column("Count", justify="right")
    stats.add_row("[green]Copied[/green]", str(len(result["copied"])))
    stats.add_row("[yellow]Skipped[/yellow]", str(len(result["skipped"])))
    stats.add_row("[red]Overwritten[/red]", str(len(result["overwritten"])))
    stats.add_row("Categories", str(len(result["categories"])))
    optional = result.get("installed_optional", {})
    if optional:
        stats.add_row("Engine folders", ", ".join(sorted(optional)))
    con.print(stats)


def _render_file_tree(con: Console, result: dict[str, Any]) -> None:
    tree = Tree("[bold]Installed files[/bold]")
    for path in result["copied"]:
        tree.add(f"[green]\u2714[/green] {path}")
    for path in result["overwritten"]:
        tree.add(f"[red]\u21bb[/red] {path}")
    if not result["copied"] and not result["overwritten"]:
        tree.add("[dim]No files changed[/dim]")
    con.print(tree)


def _render_agent_ops_created(con: Console, result: dict[str, Any]) -> None:
    created = result["agent_ops"]["created"]
    if not created:
        return
    tree = Tree("[bold]Created .agent/ops base[/bold]")
    for path in created:
        tree.add(f"[cyan]{path}[/cyan]")
    con.print(tree)


def _ensure_agent_ops_base(target_root: Path) -> list[str]:
    ops_root = target_root / ".agent" / "ops"
    issues_root = ops_root / "issues"
    references_root = issues_root / "references"
    created: list[str] = []
    for folder in (issues_root, references_root):
        if not folder.exists():
            folder.mkdir(parents=True, exist_ok=True)
            created.append(str(folder))
    created.extend(_write_if_missing(issues_root / "events.jsonl", ""))
    created.extend(_write_if_missing(issues_root / "active.jsonl", _default_active_meta()))
    created.extend(_write_if_missing(ops_root / "focus.json", _default_focus_json()))
    return created


def _write_if_missing(path: Path, content: str) -> list[str]:
    if path.exists():
        return []
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return [str(path)]


def _default_active_meta() -> str:
    stamp = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
    return (
        '{"_meta":true,"active_count":0,"event_count":0,'
        f'"generated_at":"{stamp}","source_last_event_id":""}}\n'
    )


def _default_focus_json() -> str:
    today = datetime.now(UTC).strftime("%Y-%m-%d")
    payload = {
        "session_info": {
            "branch": "",
            "last_updated": today,
            "last_commit": "",
        },
        "iteration_tracking": {
            "current_iteration": 0,
            "issues_in_iteration": [],
            "confidence_mix": "",
            "iteration_started": today,
        },
        "just_did": "",
        "doing_now": {"issue_id": "", "confidence": "normal", "task": ""},
        "in_progress": [],
        "next_queue": [],
        "recent_work": [],
        "next": "",
    }
    import json

    return json.dumps(payload, indent=2, ensure_ascii=False) + "\n"


def _resolve_asset_root() -> Path:
    pkg_root = Path(__file__).resolve().parents[2]
    packaged = pkg_root / "_assets"
    if (packaged / _AO_DIR).exists():
        return packaged
    dev_root = Path(__file__).resolve().parents[4]
    if (dev_root / _AO_DIR).exists():
        return dev_root
    raise FileNotFoundError("Could not find bundled AO assets (.ao)")


def _resolve_categories(
    asset_root: Path,
    provided: list[str] | None,
    yes_mode: bool,
    con: Console,
) -> set[str]:
    if provided:
        return {c.strip().lower() for c in provided if c.strip()}
    available = sorted(_discover_categories(asset_root / _AO_DIR))
    if yes_mode or not available:
        return set(available)
    catalog = _build_category_catalog(asset_root / _AO_DIR)
    modern = _ptk_select_categories(available, catalog)
    if modern is not None:
        return modern
    return _interactive_category_select(available, con, catalog)


def _interactive_category_select(
    available: list[str],
    con: Console,
    catalog: dict[str, list[dict[str, str]]],
) -> set[str]:
    """Run an interactive checklist selector for categories."""
    def preview(category: str) -> None:
        _show_category_details(con, category, catalog.get(category, []))

    selected = _run_checklist_selector(
        con,
        title="Select categories",
        options=available,
        initial=set(available),
        allow_empty=False,
        on_preview=preview,
    )
    return selected or set(available)


def _ptk_select_categories(
    available: list[str],
    catalog: dict[str, list[dict[str, str]]],
) -> set[str] | None:
    """Modern category selection with dialog UI; None if unavailable."""
    if not _HAS_PROMPT_TOOLKIT:
        return None
    assert button_dialog is not None
    try:
        selected = set(available)
        while True:
            action = button_dialog(
                title="AO Install · Categories",
                text="Select categories or inspect their contents.",
                buttons=[
                    ("Choose categories", "pick"),
                    ("View category contents", "view"),
                    ("Continue", "done"),
                    ("Cancel", "cancel"),
                ],
                style=_pt_style(),
            ).run()
            if action in (None, "cancel"):
                return set(available)
            if action == "done":
                return selected or set(available)
            if action == "pick":
                picked = _ptk_pick_categories(available, selected, catalog)
                if picked is not None:
                    selected = picked
            if action == "view":
                _ptk_view_category(available, catalog)
    except (EOFError, KeyboardInterrupt):
        return set(available)
    except Exception:
        return None


def _ptk_pick_categories(
    available: list[str],
    selected: set[str],
    catalog: dict[str, list[dict[str, str]]],
) -> set[str] | None:
    """Open checkbox dialog and return selected categories."""
    assert checkboxlist_dialog is not None
    values = []
    for name in available:
        count = len(catalog.get(name, []))
        label = f"{name}  ({count} item{'s' if count != 1 else ''})"
        values.append((name, label))
    picked = checkboxlist_dialog(
        title="Choose categories",
        text="Use arrows + space to select. Enter to confirm.",
        values=values,
        default_values=sorted(selected),
        style=_pt_style(),
    ).run()
    if picked is None:
        return None
    return set(picked) or set(available)


def _ptk_view_category(
    available: list[str],
    catalog: dict[str, list[dict[str, str]]],
) -> None:
    """Select one category and show contained assets."""
    assert radiolist_dialog is not None
    assert message_dialog is not None
    values = []
    for name in available:
        count = len(catalog.get(name, []))
        label = f"{name}  ({count} item{'s' if count != 1 else ''})"
        values.append((name, label))
    category = radiolist_dialog(
        title="View category contents",
        text="Choose a category to inspect.",
        values=values,
        style=_pt_style(),
    ).run()
    if not category:
        return
    details = _render_category_preview_text(category, catalog.get(category, []))
    message_dialog(
        title=f"Category: {category}",
        text=details,
        style=_pt_style(),
    ).run()


def _render_category_preview_text(category: str, items: list[dict[str, str]]) -> str:
    """Build readable text for category preview dialog."""
    if not items:
        return f"{category} has no categorized assets."
    lines = [f"{category} contains {len(items)} item(s):", ""]
    for item in items:
        lines.append(f"• [{item['kind']}] {item['name']}")
        lines.append(f"  {item['path']}")
    return "\n".join(lines)


def _run_checklist_selector(
    con: Console,
    title: str,
    options: list[str],
    initial: set[str],
    allow_empty: bool,
    on_preview: Callable[[str], None] | None = None,
) -> set[str]:
    """Render checklist UI and return selected option labels."""
    selected = set(initial)
    while True:
        _render_checklist(con, title, options, selected)
        raw: str = con.input("Choice (number/a/n/d): ").strip().lower()
        if _handle_preview_choice(raw, options, on_preview):
            continue
        if _handle_checklist_done(con, raw, selected, allow_empty):
            return selected
        _apply_checklist_choice(con, raw, options, selected)


def _render_checklist(
    con: Console, title: str, options: list[str], selected: set[str]
) -> None:
    con.print(Panel.fit(f"[bold]{title}[/bold]", border_style="blue"))
    table = Table(box=box.ROUNDED, expand=False)
    table.add_column("#", justify="right", style="cyan")
    table.add_column("Selected", justify="center")
    table.add_column("Option", style="white")
    for idx, option in enumerate(options, 1):
        mark = "[green]●[/green]" if option in selected else "[dim]○[/dim]"
        table.add_row(str(idx), mark, option)
    con.print(table)
    con.print("[dim]Commands:[/dim] [cyan]number[/cyan]=toggle  [cyan]a[/cyan]=all")
    con.print("[dim]          [/dim] [cyan]n[/cyan]=none  [cyan]d[/cyan]=done")
    con.print("[dim]          [/dim] [cyan]v#[/cyan]=view contents (e.g., v2)")


def _handle_preview_choice(
    raw: str,
    options: list[str],
    on_preview: Callable[[str], None] | None,
) -> bool:
    if on_preview is None or not raw.startswith("v"):
        return False
    idx_text = raw[1:]
    if not idx_text.isdigit():
        return False
    idx = int(idx_text)
    if idx < 1 or idx > len(options):
        return False
    on_preview(options[idx - 1])
    return True


def _handle_checklist_done(
    con: Console, raw: str, selected: set[str], allow_empty: bool
) -> bool:
    if raw not in {"", "d", "done"}:
        return False
    if selected or allow_empty:
        con.print()
        return True
    con.print("[yellow]Select at least one option before continuing.[/yellow]\n")
    return False


def _apply_checklist_choice(
    con: Console, raw: str, options: list[str], selected: set[str]
) -> None:
    if raw in {"a", "all"}:
        selected.update(options)
        return
    if raw in {"n", "none"}:
        selected.clear()
        return
    if raw.isdigit():
        _toggle_checklist_option(con, int(raw), options, selected)
        return
    con.print("[yellow]Unknown choice. Use number/a/n/d.[/yellow]\n")


def _toggle_checklist_option(
    con: Console, index: int, options: list[str], selected: set[str]
) -> None:
    if index < 1 or index > len(options):
        con.print("[yellow]Number out of range.[/yellow]\n")
        return
    name = options[index - 1]
    if name in selected:
        selected.remove(name)
        return
    selected.add(name)


def _resolve_optional_flags(
    yes_mode: bool,
    with_github: bool | None,
    with_claude: bool | None,
    with_opencode: bool | None,
    con: Console,
) -> dict[str, bool]:
    values: dict[str, bool | None] = {
        ".github": with_github,
        ".claude": with_claude,
        ".opencode": with_opencode,
    }
    if yes_mode:
        return {k: bool(v) for k, v in values.items()}
    modern = _ptk_select_optional(values)
    if modern is not None:
        return modern
    return _interactive_optional_select(values, con)


def _ptk_select_optional(values: dict[str, bool | None]) -> dict[str, bool] | None:
    """Modern optional assets selection with checkbox dialog."""
    if not _HAS_PROMPT_TOOLKIT:
        return None
    assert checkboxlist_dialog is not None
    try:
        resolved: dict[str, bool] = {}
        pending: list[str] = []
        for name, val in values.items():
            if val is not None:
                resolved[name] = val
                continue
            pending.append(name)
        if not pending:
            return resolved
        labels = []
        for name in pending:
            labels.append((name, f"Install {name} assets"))
        selected = checkboxlist_dialog(
            title="AO Install · Optional assets",
            text="Select optional engine assets to install.",
            values=labels,
            default_values=[],
            style=_pt_style(),
        ).run()
        if selected is None:
            selected = []
        picked = set(selected)
        for name in pending:
            resolved[name] = name in picked
        return resolved
    except (EOFError, KeyboardInterrupt):
        return {k: bool(v) for k, v in values.items()}
    except Exception:
        return None


def _interactive_optional_select(
    values: dict[str, bool | None], con: Console
) -> dict[str, bool]:
    """Prompt for optional engine folders using checklist UI."""
    resolved: dict[str, bool] = {}
    pending: list[str] = []
    for name, val in values.items():
        if val is not None:
            resolved[name] = val
            continue
        pending.append(name)
    if not pending:
        return resolved
    selected = _run_checklist_selector(
        con,
        title="Select optional engine folders",
        options=pending,
        initial=set(),
        allow_empty=True,
    )
    for name in pending:
        resolved[name] = name in selected
    return resolved





def _copy_file(
    src: Path,
    dst: Path,
    keep_existing: bool,
    force: bool,
    skip_existing: bool,
    yes_mode: bool,
    con: Console,
    copied: list[str],
    skipped: list[str],
    overwritten: list[str],
) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        if keep_existing:
            skipped.append(str(dst))
            return
        if not _files_differ(src, dst):
            skipped.append(str(dst))
            return
        if skip_existing:
            skipped.append(str(dst))
            return
        if not force and not yes_mode:
            ok = Confirm.ask(f"Overwrite [cyan]{dst}[/cyan]?", console=con, default=False)
            if not ok:
                skipped.append(str(dst))
                return
        overwritten.append(str(dst))
    shutil.copy2(src, dst)
    copied.append(str(dst))


def _iter_files(root: Path) -> list[Path]:
    return [p for p in root.rglob("*") if p.is_file()]


def _files_differ(src: Path, dst: Path) -> bool:
    return src.read_bytes() != dst.read_bytes()


def _is_skill_preferences(rel: Path) -> bool:
    parts = rel.parts
    if len(parts) < 3:
        return False
    return parts[0] == "skills" and rel.name.lower() == "preferences.md"


def _is_categorized(rel: Path) -> bool:
    parts = rel.parts
    if len(parts) < 2:
        return False
    if parts[0] == "skills" and rel.name.lower() == "skill.md":
        return True
    if parts[0] == "prompts" and rel.name.lower().endswith(".prompt.md"):
        return True
    if parts[0] == "agents" and rel.name.lower().endswith(".agent.md"):
        return True
    return False


def _discover_categories(ao_root: Path) -> set[str]:
    found: set[str] = set()
    for file_path in _iter_files(ao_root):
        rel = file_path.relative_to(ao_root)
        if _is_categorized(rel):
            found.add(_extract_category(file_path))
    return found or {"misc"}


def _extract_category(path: Path) -> str:
    lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
    block = _frontmatter(lines)
    for line in block:
        m = _CATEGORY_RE.match(line.strip())
        if m:
            return m.group(1).strip().strip("\"'").lower()
    return "misc"


def _build_category_catalog(ao_root: Path) -> dict[str, list[dict[str, str]]]:
    """Build a category->items mapping to preview category contents."""
    catalog: dict[str, list[dict[str, str]]] = {}
    for file_path in _iter_files(ao_root):
        rel = file_path.relative_to(ao_root)
        if not _is_categorized(rel):
            continue
        meta = _meta_from_file(file_path)
        item = {
            "kind": _categorized_kind(rel),
            "name": meta["name"],
            "path": str(rel),
        }
        catalog.setdefault(meta["category"], []).append(item)
    for key, items in catalog.items():
        catalog[key] = sorted(items, key=lambda x: (x["kind"], x["name"].lower()))
    return catalog


def _categorized_kind(rel: Path) -> str:
    """Return item kind name for categorized files."""
    first = rel.parts[0] if rel.parts else "misc"
    if first == "skills":
        return "skill"
    if first == "prompts":
        return "prompt"
    if first == "agents":
        return "agent"
    return first


def _show_category_details(con: Console, category: str, items: list[dict[str, str]]) -> None:
    """Render a category detail panel with contained assets."""
    header = f"[bold cyan]{category}[/bold cyan] contains [bold]{len(items)}[/bold] item(s)"
    con.print(Panel.fit(header, border_style="cyan", title="Category details"))
    if not items:
        con.print("[dim]No categorized assets found for this category.[/dim]\n")
        return
    table = Table(box=box.SIMPLE_HEAVY, expand=False)
    table.add_column("Kind", style="magenta")
    table.add_column("Name", style="white")
    table.add_column("Path", style="dim")
    for item in items:
        table.add_row(item["kind"], item["name"], item["path"])
    con.print(table)
    con.print()


def _frontmatter(lines: list[str]) -> list[str]:
    if not lines or lines[0].strip() != "---":
        return []
    out: list[str] = []
    for line in lines[1:120]:
        if line.strip() == "---":
            break
        out.append(line)
    return out


def _meta_from_file(path: Path) -> dict[str, str]:
    lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
    block = _frontmatter(lines)
    name = path.parent.name
    desc = ""
    cat = "misc"
    for raw in block:
        line = raw.strip()
        m_name = _NAME_RE.match(line)
        m_desc = _DESC_RE.match(line)
        m_cat = _CATEGORY_RE.match(line)
        if m_name:
            name = m_name.group(1).strip().strip("\"'")
        if m_desc:
            desc = m_desc.group(1).strip().strip("\"'")
        if m_cat:
            cat = m_cat.group(1).strip().strip("\"'").lower()
    return {"name": name, "description": desc, "category": cat}


def _generate_skills_index(ao_target: Path, selected: set[str]) -> Path:
    entries = _index_entries(ao_target, selected)
    content = _render_index(entries)
    out = ao_target / "skills-index.md"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(content, encoding="utf-8")
    return out


def _index_entries(
    ao_target: Path, selected: set[str]
) -> dict[str, dict[str, list[dict[str, str]]]]:
    grouped: dict[str, dict[str, list[dict[str, str]]]] = {}
    for kind, pattern in [
        ("skills", "skills/**/SKILL.md"),
        ("prompts", "prompts/*.prompt.md"),
        ("agents", "agents/*.agent.md"),
    ]:
        for path in ao_target.glob(pattern):
            meta = _meta_from_file(path)
            cat = meta["category"]
            if selected and cat not in selected:
                continue
            bucket = grouped.setdefault(cat, {"skills": [], "prompts": [], "agents": []})
            rel = path.relative_to(ao_target)
            bucket[kind].append(
                {"name": meta["name"], "description": meta["description"], "path": str(rel)}
            )
    return grouped


def _render_index(entries: dict[str, dict[str, list[dict[str, str]]]]) -> str:
    lines = ["# AO Skills Index", "", "Generated dynamically by `ao install`.", ""]
    for category in sorted(entries):
        lines.extend([f"## {category}", ""])
        for kind in ("skills", "prompts", "agents"):
            items = sorted(entries[category][kind], key=lambda i: i["name"].lower())
            if not items:
                continue
            lines.extend([f"### {kind}", ""])
            for item in items:
                desc = f" — {item['description']}" if item["description"] else ""
                lines.append(f"- `{item['name']}` (`{item['path']}`){desc}")
            lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def validate_install_target(target: Path) -> str | None:
    """Return validation error message for invalid install target, else None."""
    if target.exists() and not target.is_dir():
        return "Install target must be a directory"
    return _validate_git_clean(target)


def _validate_git_clean(target: Path) -> str | None:
    probe = _existing_ancestor(target)
    try:
        repo = Repo(probe, search_parent_directories=True)
    except (InvalidGitRepositoryError, NoSuchPathError):
        return "Install target must be inside a git repository"
    root = Path(repo.working_tree_dir or "").resolve()
    if not root.exists():
        return "Install target must be inside a git repository"
    try:
        scope = target.resolve().relative_to(root)
    except ValueError:
        return "Install target must be inside a git repository"
    if _has_dirty_scope(repo, scope):
        return "Install aborted: target folder has uncommitted or changed files"
    return None


def _existing_ancestor(path: Path) -> Path:
    current = path.resolve()
    while not current.exists() and current.parent != current:
        current = current.parent
    return current


def _has_dirty_scope(repo: Repo, scope: Path) -> bool:
    scope_text = scope.as_posix() if scope.parts else "."
    if repo.is_dirty(untracked_files=False, path=scope_text):
        return True
    return any(_path_in_scope(Path(p), scope) for p in repo.untracked_files)


def _path_in_scope(path: Path, scope: Path) -> bool:
    return not scope.parts or path == scope or scope in path.parents


def install_command(
    ctx: AppContext,
    target: Path | None,
    *,
    with_github: bool | None,
    with_claude: bool | None,
    with_opencode: bool | None,
    categories: list[str] | None,
    force: bool,
    skip_existing: bool,
) -> None:
    """Entry-point wrapper for CLI command."""
    target_path = (target or Path.cwd()).resolve()
    error = validate_install_target(target_path)
    if error:
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, error)
        return
    try:
        install_assets(
            ctx,
            target,
            with_github=with_github,
            with_claude=with_claude,
            with_opencode=with_opencode,
            categories=categories,
            force=force,
            skip_existing=skip_existing,
        )
    except FileNotFoundError as exc:
        emit_error(ctx, ErrorCode.NOT_FOUND, str(exc))


def update_command(
    ctx: AppContext,
    target: Path | None,
    *,
    with_github: bool | None,
    with_claude: bool | None,
    with_opencode: bool | None,
    categories: list[str] | None,
    force: bool,
    skip_existing: bool,
) -> None:
    """Entry-point wrapper for `ao update` command."""
    target_path = (target or Path.cwd()).resolve()
    error = validate_install_target(target_path)
    if error:
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, error)
        return
    try:
        update_assets(
            ctx,
            target,
            with_github=with_github,
            with_claude=with_claude,
            with_opencode=with_opencode,
            categories=categories,
            force=force,
            skip_existing=skip_existing,
        )
    except FileNotFoundError as exc:
        emit_error(ctx, ErrorCode.NOT_FOUND, str(exc))
