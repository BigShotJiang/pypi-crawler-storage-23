"""CLI commands for worker management."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ao._internal.output import ErrorCode, emit_error, emit_success

if TYPE_CHECKING:
    from ao._internal.context import AppContext


def worker_ls(ctx: AppContext) -> None:
    """List all registered workers."""
    from ao.api import AOClient
    from ao.store import AOPaths

    client = AOClient(AOPaths(ctx.root), codec="msgspec")
    workers = client.workers()
    emit_success(ctx, {"workers": workers, "count": len(workers)})


def worker_add(
    ctx: AppContext,
    name: str,
    engine: str,
    label: str,
    *,
    model: str = "",
    context: str = "",
    instructions: str = "",
) -> None:
    """Register a new worker."""
    from ao.api import AOClient
    from ao.errors import ValidationError
    from ao.store import AOPaths

    client = AOClient(AOPaths(ctx.root), codec="msgspec")
    try:
        result = client.worker_add(
            name,
            engine,
            label=label,
            model=model,
            context=context,
            instructions=instructions,
        )
    except ValidationError as exc:
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, str(exc))
        return
    emit_success(ctx, result)


def worker_show(ctx: AppContext, name: str) -> None:
    """Show details of a registered worker."""
    from ao.api import AOClient
    from ao.errors import ValidationError
    from ao.store import AOPaths

    client = AOClient(AOPaths(ctx.root), codec="msgspec")
    try:
        result = client.worker_get(name)
    except ValidationError as exc:
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, str(exc))
        return
    emit_success(ctx, result)


def worker_update(
    ctx: AppContext,
    name: str,
    *,
    label: str | None = None,
    model: str | None = None,
    context: str | None = None,
    instructions: str | None = None,
    engine: str | None = None,
) -> None:
    """Update fields of a registered worker."""
    from ao.api import AOClient
    from ao.errors import ValidationError
    from ao.store import AOPaths

    fields: dict[str, str] = {}
    if label is not None:
        fields["label"] = label
    if model is not None:
        fields["model"] = model
    if context is not None:
        fields["context"] = context
    if instructions is not None:
        fields["instructions"] = instructions
    if engine is not None:
        fields["engine"] = engine

    if not fields:
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, "No fields to update")
        return

    client = AOClient(AOPaths(ctx.root), codec="msgspec")
    try:
        result = client.worker_update(name, **fields)
    except ValidationError as exc:
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, str(exc))
        return
    emit_success(ctx, result)


def worker_rm(ctx: AppContext, name: str) -> None:
    """Remove a registered worker."""
    from ao.api import AOClient
    from ao.errors import ValidationError
    from ao.store import AOPaths

    client = AOClient(AOPaths(ctx.root), codec="msgspec")
    try:
        result = client.worker_remove(name)
    except ValidationError as exc:
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, str(exc))
        return
    emit_success(ctx, result)


def worker_assign(ctx: AppContext, issue_id: str, worker_name: str) -> None:
    """Assign a worker to an issue."""
    from ao.api import AOClient
    from ao.errors import ValidationError
    from ao.store import AOPaths

    client = AOClient(AOPaths(ctx.root), codec="msgspec")
    try:
        result = client.worker_assign(issue_id, worker_name)
    except ValidationError as exc:
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, str(exc))
        return
    emit_success(ctx, result)
