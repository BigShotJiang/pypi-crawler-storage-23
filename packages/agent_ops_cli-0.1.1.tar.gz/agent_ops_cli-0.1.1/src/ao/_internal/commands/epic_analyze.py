"""AO epic-analyze — AI-based epic assignment suggestions via pydantic-ai."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field

from ao._internal.commands.epic import _load_all_issues
from ao._internal.context import AppContext
from ao._internal.output import ErrorCode, emit_error, emit_success
from ao.models import TERMINAL_STATUSES, Event, Issue, Op

# ---------------------------------------------------------------------------
# Pydantic models for structured LLM output
# ---------------------------------------------------------------------------


class EpicSuggestion(BaseModel):
    """A suggested epic assignment for an issue."""

    issue_id: str = Field(description="Full issue ID (e.g. FEAT-0001@abc123)")
    suggested_epic: str = Field(description="Concise epic name (2-4 words)")
    reason: str = Field(description="Brief reason for the grouping")


class EpicAnalysisResult(BaseModel):
    """Structured output returned by the LLM analysis."""

    suggestions: list[EpicSuggestion]


# ---------------------------------------------------------------------------
# System prompt
# ---------------------------------------------------------------------------

_INSTRUCTIONS = (
    "You are an issue management assistant. Analyze the provided issues "
    "and suggest epic groupings.\n\n"
    "Rules:\n"
    "- Group similar issues that relate to the same feature area "
    "or could be worked in parallel\n"
    "- Each suggestion maps an issue_id to a suggested_epic name "
    "and a brief reason\n"
    "- Use concise, descriptive epic names (2-4 words)\n"
    "- Only suggest changes for issues that would benefit from "
    "epic assignment\n"
)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _has_pydantic_ai() -> bool:
    """Return True if pydantic-ai is installed."""
    try:
        import pydantic_ai  # noqa: F401

        return True
    except ImportError:
        return False


def _read_ai_config() -> dict[str, str]:
    """Read AI settings from ``~/.ao/config.json``."""
    cfg_path = Path.home() / ".ao" / "config.json"
    if not cfg_path.exists():
        return {}
    raw = cfg_path.read_bytes()
    data: dict[str, Any] = json.loads(raw)
    return {k: str(v) for k, v in data.items() if k.startswith("ai_")}


def _resolve_model(model: str | None) -> str | None:
    """Resolve model from explicit arg or ``ai_model`` in config."""
    if model:
        return model
    cfg = _read_ai_config()
    return cfg.get("ai_model")


def _filter_issues(
    ctx: AppContext,
    *,
    include_assigned: bool,
) -> list[Issue]:
    """Load active non-terminal issues, optionally only those without an epic."""
    issues = _load_all_issues(ctx)
    active = [i for i in issues if i.status not in TERMINAL_STATUSES]
    if include_assigned:
        return active
    return [i for i in active if not i.epic]


def _format_issue_line(iss: Issue) -> str:
    """Format a single issue as a prompt line."""
    parts = [f"- {iss.id}: {iss.title} (type={iss.type}, priority={iss.priority}"]
    if iss.epic:
        parts.append(f", epic={iss.epic}")
    if iss.labels:
        parts.append(f", labels={','.join(iss.labels)}")
    parts.append(")")
    if iss.notes:
        parts.append(f"\n  Notes: {iss.notes[:200]}")
    return "".join(parts)


def _build_user_prompt(issues: list[Issue]) -> str:
    """Serialize issues into a user prompt for the LLM."""
    lines = ["Analyze these issues and suggest epic groupings:\n"]
    lines.extend(_format_issue_line(iss) for iss in issues)
    return "\n".join(lines)


def _run_analysis(
    model: str,
    issues: list[Issue],
) -> list[EpicSuggestion]:
    """Create a pydantic-ai Agent and run the analysis."""
    from pydantic_ai import Agent

    agent: Agent[None, EpicAnalysisResult] = Agent(
        model,
        output_type=EpicAnalysisResult,
        instructions=_INSTRUCTIONS,
    )
    result = agent.run_sync(_build_user_prompt(issues))
    output: EpicAnalysisResult = result.output
    return output.suggestions


def _to_dicts(
    suggestions: list[EpicSuggestion],
) -> list[dict[str, Any]]:
    """Convert suggestions to plain dicts for output."""
    return [
        {"issue_id": s.issue_id, "epic": s.suggested_epic, "reason": s.reason}
        for s in suggestions
    ]


def _make_epic_event(
    ctx: AppContext,
    issue_id: str,
    epic: str,
    ts: str,
) -> Event:
    """Create a SET event for epic assignment."""
    from ao._internal.commands.issue import _make_event_id, _next_id

    num = _next_id(ctx)
    return Event(
        event_id=_make_event_id(num),
        issue_id=issue_id,
        op=Op.SET,
        timestamp=ts,
        payload={"epic": epic},
    )


def _apply_suggestions(
    ctx: AppContext,
    suggestions: list[EpicSuggestion],
) -> int:
    """Write SET events for each suggestion and rebuild."""
    from ao._internal.commands.issue import (
        _do_rebuild,
        _encode_and_append,
        _now_iso,
    )

    ts = _now_iso()
    for s in suggestions:
        evt = _make_epic_event(ctx, s.issue_id, s.suggested_epic, ts)
        _encode_and_append(ctx, evt)
    _do_rebuild(ctx)
    return len(suggestions)


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def epic_analyze(
    ctx: AppContext,
    model: str | None = None,
    *,
    apply: bool = False,
    include_assigned: bool = False,
) -> list[dict[str, Any]]:
    """Analyze issues and suggest epic assignments using an LLM.

    Args:
        ctx: Application context.
        model: pydantic-ai model string (e.g. ``openai:gpt-4o``).
            Falls back to ``ai_model`` in ``~/.ao/config.json`` if not provided.
        apply: If True, write SET events to assign the suggested epics.
        include_assigned: If True, also analyze issues that already have an epic.

    Returns:
        List of suggestion dicts with ``issue_id``, ``epic``, and ``reason``.
    """
    if not _has_pydantic_ai():
        msg = "pydantic-ai is not installed. Install with: uv pip install 'ao[ai]'"
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, msg)
        return []
    resolved = _resolve_model(model)
    if not resolved:
        emit_error(
            ctx,
            ErrorCode.VALIDATION_ERROR,
            "No model specified. Pass a model argument or set 'ai_model' in ~/.ao/config.json",
        )
        return []
    issues = _filter_issues(ctx, include_assigned=include_assigned)
    if not issues:
        emit_success(ctx, {"suggestions": [], "message": "No unassigned issues"})
        return []
    return _analyze_and_emit(ctx, resolved, issues, apply=apply)


def _analyze_and_emit(
    ctx: AppContext,
    model: str,
    issues: list[Issue],
    *,
    apply: bool,
) -> list[dict[str, Any]]:
    """Run LLM analysis, optionally apply results, and emit output."""
    suggestions = _run_analysis(model, issues)
    output = _to_dicts(suggestions)
    if apply:
        _apply_suggestions(ctx, suggestions)
    emit_success(ctx, {"suggestions": output, "applied": apply})
    return output
