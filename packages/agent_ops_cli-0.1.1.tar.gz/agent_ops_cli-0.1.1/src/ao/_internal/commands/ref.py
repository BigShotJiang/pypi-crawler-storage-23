"""AO ref — reference doc init, open, attach, status."""

from __future__ import annotations

import os
import subprocess
from pathlib import Path
from typing import Any

from ao._internal.commands.issue import (
    _do_rebuild,
    _encode_and_append,
    _load_issue,
    _make_event_id,
    _next_id,
    _now_iso,
)
from ao._internal.context import AppContext
from ao._internal.output import ErrorCode, emit_error, emit_success
from ao.models import Event, Op


def _ref_path(ctx: AppContext, issue_id: str) -> Path:
    """Standard reference doc path for an issue."""
    return ctx.root / "issues" / "references" / f"{issue_id}.md"


def ref_init(ctx: AppContext, issue_id: str) -> None:
    """Create reference doc from template and attach it."""
    issue = _load_issue(ctx, issue_id)
    if issue is None:
        emit_error(ctx, ErrorCode.NOT_FOUND, f"Issue {issue_id} not found")
        return

    path = _ref_path(ctx, issue_id)
    path.parent.mkdir(parents=True, exist_ok=True)

    content = _build_template(issue)
    path.write_text(content, encoding="utf-8")

    # Attach via ref_set event
    ts = _now_iso()
    num = _next_id(ctx)
    event = Event(
        event_id=_make_event_id(num),
        issue_id=issue_id,
        op=Op.REF_SET,
        timestamp=ts,
        payload={"spec_file": str(path)},
    )
    _encode_and_append(ctx, event)
    _do_rebuild(ctx)
    emit_success(ctx, {"created": True, "path": str(path), "attached": True})


def _build_template(issue: Any) -> str:
    """Build markdown template pre-filled with issue data."""
    lines = [
        f"# {issue.id}: {issue.title}",
        "",
        f"**Type:** {issue.type}",
        "",
        "## Overview",
        "",
        "<!-- Describe the purpose and context -->",
        "",
        "## Requirements",
        "",
    ]
    for i, req in enumerate(issue.requirements, 1):
        lines.append(f"{i}. {req}")
    if not issue.requirements:
        lines.append("<!-- No requirements defined yet -->")

    lines.extend(["", "## Acceptance Criteria", ""])
    for _i, ac in enumerate(issue.acceptance_criteria, 1):
        check = "x" if ac.done else " "
        lines.append(f"- [{check}] {ac.description}")
    if not issue.acceptance_criteria:
        lines.append("<!-- No acceptance criteria defined yet -->")

    lines.extend(
        [
            "",
            "## Implementation Notes",
            "",
            "<!-- Implementation details and decisions -->",
            "",
            "## Test Strategy",
            "",
            "<!-- How to test this feature -->",
            "",
            "## Risks",
            "",
            "<!-- Known risks and mitigations -->",
            "",
        ]
    )
    return "\n".join(lines)


def ref_open(ctx: AppContext, issue_id: str) -> None:
    """Open reference doc in $EDITOR or print path."""
    issue = _load_issue(ctx, issue_id)
    if issue is None:
        emit_error(ctx, ErrorCode.NOT_FOUND, f"Issue {issue_id} not found")
        return

    spec = issue.references.spec_file
    path = Path(spec) if spec else _ref_path(ctx, issue_id)

    if not path.exists():
        emit_error(ctx, ErrorCode.NOT_FOUND, f"Reference doc not found: {path}")
        return

    editor = os.environ.get("EDITOR")
    if editor:
        subprocess.run([editor, str(path)], check=False)  # noqa: S603
        emit_success(ctx, {"opened": True, "editor": editor, "path": str(path)})
    else:
        emit_success(ctx, {"opened": False, "path": str(path), "hint": "Set $EDITOR"})


def ref_attach(ctx: AppContext, issue_id: str, path: str) -> None:
    """Set spec_file to custom path."""
    ts = _now_iso()
    num = _next_id(ctx)
    event = Event(
        event_id=_make_event_id(num),
        issue_id=issue_id,
        op=Op.REF_SET,
        timestamp=ts,
        payload={"spec_file": path},
    )
    _encode_and_append(ctx, event)
    _do_rebuild(ctx)
    emit_success(ctx, {"issue_id": issue_id, "spec_file": path, "attached": True})


def ref_status(ctx: AppContext, issue_id: str) -> None:
    """Check reference doc status."""
    issue = _load_issue(ctx, issue_id)
    if issue is None:
        emit_error(ctx, ErrorCode.NOT_FOUND, f"Issue {issue_id} not found")
        return

    spec = issue.references.spec_file
    path = Path(spec) if spec else _ref_path(ctx, issue_id)
    exists = path.exists()
    linked = bool(spec)

    result: dict[str, Any] = {
        "issue_id": issue_id,
        "exists": exists,
        "path": str(path),
        "linked": linked,
    }
    if exists:
        import datetime

        mtime = path.stat().st_mtime
        result["modified"] = datetime.datetime.fromtimestamp(mtime, tz=datetime.UTC).strftime(
            "%Y-%m-%dT%H:%M:%SZ"
        )

    emit_success(ctx, result)
