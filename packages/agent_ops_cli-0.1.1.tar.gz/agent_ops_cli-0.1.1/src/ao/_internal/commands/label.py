"""AO label — label and operational-state management commands."""

from __future__ import annotations

from typing import Any

from ao._internal.commands.issue import (
    _do_rebuild,
    _encode_and_append,
    _make_event_id,
    _next_id,
    _now_iso,
    _resolve_issue_id,
)
from ao._internal.context import AppContext
from ao._internal.output import ErrorCode, emit_error, emit_success
from ao.models import Event, Op


def label_add(ctx: AppContext, issue_id: str, label: str) -> None:
    """Add a label to an issue."""
    try:
        issue_id = _resolve_issue_id(ctx, issue_id)
    except ValueError as exc:
        emit_error(ctx, ErrorCode.NOT_FOUND, str(exc))
        return
    ts = _now_iso()
    num = _next_id(ctx)
    event = Event(
        event_id=_make_event_id(num),
        issue_id=issue_id,
        op=Op.LABEL_ADD,
        timestamp=ts,
        payload={"labels": [label]},
    )
    _encode_and_append(ctx, event)
    _do_rebuild(ctx)
    emit_success(ctx, {"issue_id": issue_id, "added": label, "event_id": event.event_id})


def label_rm(ctx: AppContext, issue_id: str, label: str) -> None:
    """Remove a label from an issue."""
    try:
        issue_id = _resolve_issue_id(ctx, issue_id)
    except ValueError as exc:
        emit_error(ctx, ErrorCode.NOT_FOUND, str(exc))
        return
    ts = _now_iso()
    num = _next_id(ctx)
    event = Event(
        event_id=_make_event_id(num),
        issue_id=issue_id,
        op=Op.LABEL_RM,
        timestamp=ts,
        payload={"labels": [label]},
    )
    _encode_and_append(ctx, event)
    _do_rebuild(ctx)
    emit_success(ctx, {"issue_id": issue_id, "removed": label, "event_id": event.event_id})


def label_ls(ctx: AppContext, issue_id: str) -> None:
    """List labels on an issue."""
    from ao._internal.commands.issue import _load_issue

    issue = _load_issue(ctx, issue_id)
    if issue is None:
        emit_error(ctx, ErrorCode.NOT_FOUND, f"Issue {issue_id} not found")
        return
    emit_success(ctx, {"issue_id": issue.id, "labels": issue.labels})


def state_get(ctx: AppContext, issue_id: str, dimension: str) -> None:
    """Get the value of an operational state dimension (label with dimension:value form)."""
    from ao._internal.commands.issue import _load_issue

    issue = _load_issue(ctx, issue_id)
    if issue is None:
        emit_error(ctx, ErrorCode.NOT_FOUND, f"Issue {issue_id} not found")
        return
    prefix = f"{dimension}:"
    matches = [lb[len(prefix) :] for lb in issue.labels if lb.startswith(prefix)]
    value = matches[-1] if matches else None
    emit_success(ctx, {"issue_id": issue.id, "dimension": dimension, "value": value})


def state_set(ctx: AppContext, issue_id: str, dimension_value: str) -> None:
    """Set an operational state dimension (format: dimension:value or dimension=value).

    Replaces any existing label for the same dimension.
    """
    sep = ":" if ":" in dimension_value else "="
    parts = dimension_value.split(sep, 1)
    if len(parts) != 2:  # noqa: PLR2004
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, "Format: dimension:value or dimension=value")
        return
    dimension, value = parts[0].strip(), parts[1].strip()
    new_label = f"{dimension}:{value}"

    try:
        issue_id = _resolve_issue_id(ctx, issue_id)
    except ValueError as exc:
        emit_error(ctx, ErrorCode.NOT_FOUND, str(exc))
        return

    ts = _now_iso()
    events: list[Event] = []

    # Remove any existing label for this dimension
    from ao._internal.commands.issue import _load_issue

    issue = _load_issue(ctx, issue_id)
    if issue is not None:
        prefix = f"{dimension}:"
        old_labels = [lb for lb in issue.labels if lb.startswith(prefix)]
        if old_labels:
            num = _next_id(ctx)
            rm_event = Event(
                event_id=_make_event_id(num),
                issue_id=issue_id,
                op=Op.LABEL_RM,
                timestamp=ts,
                payload={"labels": old_labels},
            )
            _encode_and_append(ctx, rm_event)
            events.append(rm_event)

    num = _next_id(ctx)
    add_event = Event(
        event_id=_make_event_id(num),
        issue_id=issue_id,
        op=Op.LABEL_ADD,
        timestamp=ts,
        payload={"labels": [new_label]},
    )
    _encode_and_append(ctx, add_event)
    events.append(add_event)
    _do_rebuild(ctx)
    result: dict[str, Any] = {
        "issue_id": issue_id,
        "dimension": dimension,
        "value": value,
        "label": new_label,
        "events": [e.event_id for e in events],
    }
    emit_success(ctx, result)
