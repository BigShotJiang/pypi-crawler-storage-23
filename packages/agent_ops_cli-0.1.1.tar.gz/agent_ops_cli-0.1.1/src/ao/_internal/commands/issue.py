"""AO issue commands — add, show, close, log, set, patch."""

from __future__ import annotations

import hashlib
import json
import re
import sys
from datetime import UTC, datetime
from typing import Any

import msgspec
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from ao._internal.context import AppContext, OutputFormat
from ao._internal.io import append_jsonl, iter_jsonl_bytes
from ao._internal.output import ErrorCode, emit_error, emit_success
from ao.codec import MsgspecCodec
from ao.models import Event, Issue, Op


def _now_iso() -> str:
    return datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def _next_id(ctx: AppContext) -> int:
    """Derive next monotonic number from events.jsonl (max event_id + 1).

    Scans events.jsonl for the max N in evt-NNNNNNNN event_ids.  Migrates
    .counter on first run: reads value as floor, then deletes the file.
    """
    max_n = 0
    events_path = ctx.root / "issues" / "events.jsonl"
    if events_path.exists():
        for raw in iter_jsonl_bytes(events_path):
            if b'"evt-"' in raw or b"evt-" in raw:
                start = raw.find(b'"evt-')
                if start != -1:
                    end = raw.find(b'"', start + 1)
                    if end != -1:
                        token = raw[start + 1 : end]
                        if token.startswith(b"evt-") and token[4:].isdigit():
                            n = int(token[4:])
                            if n > max_n:
                                max_n = n
    # Migration: consume .counter if present, use as floor, then delete
    counter_file = ctx.root / "issues" / ".counter"
    if counter_file.exists():
        text = counter_file.read_text().strip()
        if text.isdigit():
            max_n = max(max_n, int(text))
        counter_file.unlink()
    return max_n + 1


def _make_hash(number: int) -> str:
    return hashlib.md5(str(number).encode(), usedforsecurity=False).hexdigest()[:6]


def _make_event_id(number: int) -> str:
    return f"evt-{number:08d}"


_SHORT_ID_RE = re.compile(r"^[A-Z]+-\d{1,4}$")


def _resolve_issue_id(ctx: AppContext, issue_id: str) -> str:
    """Accept TYPE-NNNN short form and resolve to full TYPE-NNNN@hhhhhh.

    Returns issue_id unchanged if it already contains '@'.
    Raises ValueError if short form given but no matching active issue found.
    """
    if "@" in issue_id:
        return issue_id
    if not _SHORT_ID_RE.match(issue_id.upper()):
        return issue_id
    prefix = issue_id.upper()
    codec = MsgspecCodec()
    if ctx.active_path.exists():
        for line in iter_jsonl_bytes(ctx.active_path):
            if b'"_meta"' in line:
                continue
            issue = codec.decode_issue(line)
            if issue.id.split("@")[0] == prefix:
                return issue.id
    raise ValueError(f"No active issue matching {issue_id!r}")


def _encode_and_append(ctx: AppContext, event: Event) -> None:
    codec = MsgspecCodec()
    ctx.events_path.parent.mkdir(parents=True, exist_ok=True)
    append_jsonl(ctx.events_path, codec.encode_event(event))


def _do_rebuild(ctx: AppContext) -> None:
    from ao._internal.rebuild import rebuild as do_rebuild

    codec = MsgspecCodec()
    show_progress = ctx.progress.value != "none"
    do_rebuild(ctx.events_path, ctx.active_path, codec, show_progress=show_progress)


def _read_stdin_json(ctx: AppContext) -> dict[str, Any]:
    """Read JSON from stdin when --in - is specified."""
    if ctx.in_path != "-":
        msg = f"Expected --in -, got: {ctx.in_path}"
        raise ValueError(msg)
    raw = sys.stdin.buffer.read()
    result: dict[str, Any] = json.loads(raw)
    return result


# ── add ───────────────────────────────────────────────────────────────────────


def issue_add(
    ctx: AppContext,
    title: str | None = None,
    type_: str = "feat",
    priority: str = "backlog",
    epic: str = "",
    owner: str = "agent",
    confidence: str = "normal",
    status: str = "todo",
) -> None:
    """Create a new issue (event-sourced)."""
    payload = _build_add_payload(ctx, title, type_, priority, epic, owner, confidence, status)
    if payload is None:
        return

    num = _next_id(ctx)
    issue_type_upper = payload["type"].upper() if payload.get("type") else "FEAT"
    issue_id = f"{issue_type_upper}-{num:04d}@{_make_hash(num)}"

    ts = _now_iso()
    event = Event(
        event_id=_make_event_id(num),
        issue_id=issue_id,
        op=Op.CREATE,
        timestamp=ts,
        payload=payload,
    )
    _encode_and_append(ctx, event)
    _do_rebuild(ctx)

    result = {
        "issue_id": issue_id,
        "event_id": event.event_id,
        "title": payload.get("title", ""),
        "paths": {
            "events": str(ctx.events_path),
            "active": str(ctx.active_path),
        },
    }
    emit_success(ctx, result)


def _build_add_payload(
    ctx: AppContext,
    title: str | None,
    type_: str,
    priority: str,
    epic: str,
    owner: str,
    confidence: str,
    status: str,
) -> dict[str, Any] | None:
    """Build the create-event payload from flags or stdin."""
    if ctx.in_path == "-":
        try:
            return _read_stdin_json(ctx)
        except (json.JSONDecodeError, ValueError) as exc:
            emit_error(ctx, ErrorCode.PARSE_ERROR, str(exc))
            return None

    if not title:
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, "Title is required")
        return None

    return {
        "title": title,
        "type": type_,
        "priority": priority,
        "status": status,
        "epic": epic,
        "owner": owner,
        "confidence": confidence,
    }


# ── close ─────────────────────────────────────────────────────────────────────


def issue_close(
    ctx: AppContext,
    issue_id: str,
    status: str = "done",
    log_msg: str | None = None,
    solution: str | None = None,
) -> None:
    """Close an issue with optional log and solution."""
    try:
        issue_id = _resolve_issue_id(ctx, issue_id)
    except ValueError as exc:
        emit_error(ctx, ErrorCode.NOT_FOUND, str(exc))
        return
    ts = _now_iso()
    events: list[Event] = []

    if log_msg:
        num = _next_id(ctx)
        log_event = Event(
            event_id=_make_event_id(num),
            issue_id=issue_id,
            op=Op.LOG_APPEND,
            timestamp=ts,
            payload={"date": ts, "message": log_msg},
        )
        _encode_and_append(ctx, log_event)
        events.append(log_event)

    if solution:
        num = _next_id(ctx)
        sol_event = Event(
            event_id=_make_event_id(num),
            issue_id=issue_id,
            op=Op.SET,
            timestamp=ts,
            payload={"notes": solution},
        )
        _encode_and_append(ctx, sol_event)
        events.append(sol_event)

    num = _next_id(ctx)
    close_event = Event(
        event_id=_make_event_id(num),
        issue_id=issue_id,
        op=Op.CLOSE,
        timestamp=ts,
        payload={"status": status},
    )
    _encode_and_append(ctx, close_event)
    events.append(close_event)

    _do_rebuild(ctx)
    emit_success(
        ctx,
        {
            "issue_id": issue_id,
            "closed": True,
            "status": status,
            "events": [e.event_id for e in events],
        },
    )


# ── log add ───────────────────────────────────────────────────────────────────


def log_add(ctx: AppContext, issue_id: str, message: str) -> None:
    """Append a log entry to an issue."""
    try:
        issue_id = _resolve_issue_id(ctx, issue_id)
    except ValueError as exc:
        emit_error(ctx, ErrorCode.NOT_FOUND, str(exc))
        return
    ts = _now_iso()
    num = _next_id(ctx)
    event = Event(
        event_id=_make_event_id(num),
        issue_id=issue_id,
        op=Op.LOG_APPEND,
        timestamp=ts,
        payload={"date": ts, "message": message},
    )
    _encode_and_append(ctx, event)
    _do_rebuild(ctx)
    emit_success(
        ctx,
        {
            "issue_id": issue_id,
            "event_id": event.event_id,
            "message": message,
        },
    )


def log_append_silent(ctx: AppContext, issue_id: str, message: str) -> str:
    """Append a log entry to an issue without emitting output.

    Args:
        ctx: Resolved application context.
        issue_id: Full issue ID (TYPE-NNNN@hhhhhh).
        message: Log message text.

    Returns:
        Event ID of the appended log entry.
    """
    ts = _now_iso()
    num = _next_id(ctx)
    event = Event(
        event_id=_make_event_id(num),
        issue_id=issue_id,
        op=Op.LOG_APPEND,
        timestamp=ts,
        payload={"date": ts, "message": message},
    )
    _encode_and_append(ctx, event)
    _do_rebuild(ctx)
    return event.event_id


# ── show ──────────────────────────────────────────────────────────────────────

_issue_encoder = msgspec.json.Encoder()


def _load_issue(ctx: AppContext, issue_id: str) -> Issue | None:
    """Load a single issue from active.jsonl by ID."""
    try:
        issue_id = _resolve_issue_id(ctx, issue_id)
    except ValueError:
        return None
    codec = MsgspecCodec()
    if not ctx.active_path.exists():
        return None
    for line in iter_jsonl_bytes(ctx.active_path):
        if b'"_meta"' in line:
            continue
        issue = codec.decode_issue(line)
        if issue.id == issue_id:
            return issue
    return None


def _issue_to_dict(issue: Issue) -> dict[str, Any]:
    """Convert an Issue struct to a plain dict for JSON output."""
    result: dict[str, Any] = msgspec.to_builtins(issue)
    return result


def issue_show(ctx: AppContext, issue_id: str) -> None:
    """Display full issue details."""
    issue = _load_issue(ctx, issue_id)
    if issue is None:
        emit_error(ctx, ErrorCode.NOT_FOUND, f"Issue {issue_id} not found")
        return

    if ctx.format in (OutputFormat.JSON, OutputFormat.JSONL):
        emit_success(ctx, {"issue": _issue_to_dict(issue)})
        return

    _render_issue_rich(issue)


def _render_issue_rich(issue: Issue) -> None:
    """Render a full issue with Rich panels and formatting."""
    con = Console()

    # Header
    header = Text()
    header.append(f"{issue.id}", style="bold cyan")
    header.append(f"  {issue.title}", style="bold")
    con.print(Panel(header, title="Issue", border_style="blue"))

    # Metadata table
    rows = [
        ("Status", str(issue.status)),
        ("Priority", str(issue.priority)),
        ("Type", str(issue.type)),
        ("Epic", issue.epic or "—"),
        ("Owner", issue.owner),
        ("Confidence", str(issue.confidence)),
        ("Created", issue.created or "—"),
        ("Updated", issue.updated or "—"),
    ]
    for label, val in rows:
        con.print(f"  [bold]{label}:[/bold] {val}")

    _render_section_scope(con, issue)
    _render_section_requirements(con, issue)
    _render_section_acceptance(con, issue)
    _render_section_deps(con, issue)
    _render_section_refs_notes(con, issue)
    _render_section_log(con, issue)
    _render_section_time(con, issue)


def _render_section_scope(con: Console, issue: Issue) -> None:
    if issue.scope.files_to_change or issue.scope.files_must_not_change:
        con.print("\n[bold underline]Scope[/bold underline]")
        for f in issue.scope.files_to_change:
            con.print(f"  [green]+[/green] {f}")
        for f in issue.scope.files_must_not_change:
            con.print(f"  [red]![/red] {f}")


def _render_section_requirements(con: Console, issue: Issue) -> None:
    if issue.requirements:
        con.print("\n[bold underline]Requirements[/bold underline]")
        for i, req in enumerate(issue.requirements, 1):
            con.print(f"  {i}. {req}")


def _render_section_acceptance(con: Console, issue: Issue) -> None:
    if issue.acceptance_criteria:
        con.print("\n[bold underline]Acceptance Criteria[/bold underline]")
        for i, ac in enumerate(issue.acceptance_criteria, 1):
            check = "x" if ac.done else " "
            con.print(f"  [{check}] {i}. {ac.description}")


def _render_section_deps(con: Console, issue: Issue) -> None:
    deps = issue.dependencies
    if deps.depends_on or deps.blocks:
        con.print("\n[bold underline]Dependencies[/bold underline]")
        for d in deps.depends_on:
            con.print(f"  depends_on: {d}")
        for b in deps.blocks:
            con.print(f"  blocks: {b}")


def _render_section_refs_notes(con: Console, issue: Issue) -> None:
    if issue.references.spec_file:
        con.print("\n[bold underline]References[/bold underline]")
        con.print(f"  spec: {issue.references.spec_file}")
    if issue.notes:
        con.print("\n[bold underline]Notes[/bold underline]")
        con.print(f"  {issue.notes}")


def _render_section_log(con: Console, issue: Issue) -> None:
    if issue.log:
        con.print("\n[bold underline]Log[/bold underline]")
        for entry in issue.log:
            con.print(f"  [{entry.date}] {entry.message}")


def _render_section_time(con: Console, issue: Issue) -> None:
    if issue.started_at or issue.completed_at:
        con.print("\n[bold underline]Time Tracking[/bold underline]")
        if issue.started_at:
            con.print(f"  Started: {issue.started_at}")
        if issue.completed_at:
            con.print(f"  Completed: {issue.completed_at}")
        if issue.duration_minutes:
            con.print(f"  Duration: {issue.duration_minutes} min")


# ── set ───────────────────────────────────────────────────────────────────────


def issue_set(
    ctx: AppContext,
    issue_id: str,
    *,
    status: str | None = None,
    priority: str | None = None,
    owner: str | None = None,
    confidence: str | None = None,
    epic: str | None = None,
    title: str | None = None,
    notes: str | None = None,
) -> None:
    """Quick scalar update — appends a single set event."""
    try:
        issue_id = _resolve_issue_id(ctx, issue_id)
    except ValueError as exc:
        emit_error(ctx, ErrorCode.NOT_FOUND, str(exc))
        return
    payload: dict[str, Any] = {}
    _add_if_set(payload, "status", status)
    _add_if_set(payload, "priority", priority)
    _add_if_set(payload, "owner", owner)
    _add_if_set(payload, "confidence", confidence)
    _add_if_set(payload, "epic", epic)
    _add_if_set(payload, "title", title)
    _add_if_set(payload, "notes", notes)

    if not payload:
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, "No fields to update")
        return

    ts = _now_iso()
    num = _next_id(ctx)
    event = Event(
        event_id=_make_event_id(num),
        issue_id=issue_id,
        op=Op.SET,
        timestamp=ts,
        payload=payload,
    )
    _encode_and_append(ctx, event)
    _do_rebuild(ctx)
    emit_success(
        ctx,
        {
            "issue_id": issue_id,
            "event_id": event.event_id,
            "updated": list(payload.keys()),
        },
    )


def _add_if_set(payload: dict[str, Any], key: str, value: str | None) -> None:
    if value is not None:
        payload[key] = value


# ── patch (JSON-first update) ─────────────────────────────────────────────────


def issue_patch(ctx: AppContext, issue_id: str) -> None:
    """Apply structured JSON patch from stdin."""
    try:
        issue_id = _resolve_issue_id(ctx, issue_id)
    except ValueError as exc:
        emit_error(ctx, ErrorCode.NOT_FOUND, str(exc))
        return
    try:
        data = _read_stdin_json(ctx)
    except (json.JSONDecodeError, ValueError) as exc:
        emit_error(ctx, ErrorCode.PARSE_ERROR, str(exc))
        return

    ts = _now_iso()
    event_ids: list[str] = []

    if "set" in data and isinstance(data["set"], dict):
        num = _next_id(ctx)
        event = Event(
            event_id=_make_event_id(num),
            issue_id=issue_id,
            op=Op.SET,
            timestamp=ts,
            payload=data["set"],
        )
        _encode_and_append(ctx, event)
        event_ids.append(event.event_id)

    if "unset" in data and isinstance(data["unset"], list):
        unset_payload = dict.fromkeys(data["unset"], "")
        num = _next_id(ctx)
        event = Event(
            event_id=_make_event_id(num),
            issue_id=issue_id,
            op=Op.SET,
            timestamp=ts,
            payload=unset_payload,
        )
        _encode_and_append(ctx, event)
        event_ids.append(event.event_id)

    event_ids.extend(_write_log_events(ctx, data, issue_id, ts))

    if not event_ids:
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, "No operations in patch")
        return

    _do_rebuild(ctx)
    emit_success(
        ctx,
        {
            "issue_id": issue_id,
            "events": event_ids,
            "rebuild": "done",
        },
    )


def _write_log_events(
    ctx: AppContext,
    data: dict[str, Any],
    issue_id: str,
    ts: str,
) -> list[str]:
    """Write log_append events from patch data. Returns event_ids."""
    event_ids: list[str] = []
    append = data.get("append")
    if not isinstance(append, dict):
        return event_ids
    logs = append.get("log")
    if not isinstance(logs, list):
        return event_ids
    for entry in logs:
        if isinstance(entry, dict):
            num = _next_id(ctx)
            event = Event(
                event_id=_make_event_id(num),
                issue_id=issue_id,
                op=Op.LOG_APPEND,
                timestamp=ts,
                payload={
                    "date": entry.get("ts", ts),
                    "message": entry.get("text", ""),
                },
            )
            _encode_and_append(ctx, event)
            event_ids.append(event.event_id)
    return event_ids
