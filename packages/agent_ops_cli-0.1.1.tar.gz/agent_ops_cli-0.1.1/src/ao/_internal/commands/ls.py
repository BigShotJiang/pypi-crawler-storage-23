"""AO ls — list issues with views, filters, and query-string support."""

from __future__ import annotations

import sys
from collections import Counter
from enum import StrEnum
from typing import Any

from rich.columns import Columns
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from ao._internal.context import AppContext, OutputFormat
from ao._internal.filters import parse_query_tokens
from ao._internal.io import iter_jsonl_bytes
from ao._internal.output import ErrorCode, emit_error, emit_success
from ao.codec import MsgspecCodec
from ao.models import TERMINAL_STATUSES, Issue, Priority, Status


class View(StrEnum):
    TABLE = "table"
    KANBAN = "kanban"
    SUMMARY = "summary"
    COUNTS = "counts"
    IDS = "ids"


# Priority sort order (lower index = higher priority).
_PRIORITY_ORDER: dict[str, int] = {
    Priority.CRITICAL: 0,
    Priority.HIGH: 1,
    Priority.MEDIUM: 2,
    Priority.LOW: 3,
    Priority.BACKLOG: 4,
}


def _load_all_issues(ctx: AppContext) -> list[Issue]:
    """Load all issues from active.jsonl."""
    codec = MsgspecCodec()
    issues: list[Issue] = []
    if not ctx.active_path.exists():
        return issues
    for line in iter_jsonl_bytes(ctx.active_path):
        if b'"_meta"' in line:
            continue
        try:
            issues.append(codec.decode_issue(line))
        except Exception:  # noqa: S112
            continue
    return issues


def _apply_filters(
    issues: list[Issue],
    filters: dict[str, str],
) -> list[Issue]:
    """Filter issues by key:value pairs (AND logic)."""
    result = issues
    for key, val in filters.items():
        result = [i for i in result if _field_matches(i, key, val)]
    return result


def _field_matches(issue: Issue, key: str, val: str) -> bool:
    """Check if a single field matches the filter value."""
    val_lower = val.lower()
    if key == "status":
        return issue.status.value == val_lower
    if key == "priority":
        return issue.priority.value == val_lower
    if key == "type":
        return issue.type.value == val_lower
    if key == "epic":
        return issue.epic.lower() == val_lower
    if key == "owner":
        return issue.owner.lower() == val_lower
    if key == "confidence":
        return issue.confidence.value == val_lower
    if key == "label":
        return any(
            lb.lower() == val_lower or lb.lower().startswith(val_lower + ":") for lb in issue.labels
        )
    if key == "text":
        return val_lower in issue.title.lower() or val_lower in issue.notes.lower()
    return True


def _default_filter(issues: list[Issue]) -> list[Issue]:
    """'Workable now' — exclude terminal and blocked."""
    excluded = {*TERMINAL_STATUSES, Status.BLOCKED}
    return [i for i in issues if i.status not in excluded]


def _sort_issues(issues: list[Issue], sort_key: str) -> list[Issue]:
    """Sort issues by the given key."""
    if sort_key == "priority":
        return sorted(issues, key=lambda i: (_PRIORITY_ORDER.get(i.priority, 99), i.updated))
    if sort_key == "updated":
        return sorted(issues, key=lambda i: i.updated, reverse=True)
    if sort_key == "id":
        return sorted(issues, key=lambda i: i.id)
    if sort_key == "confidence":
        return sorted(issues, key=lambda i: i.confidence)
    return issues


# ── public entry point ────────────────────────────────────────────────────────


def issue_ls(
    ctx: AppContext,
    *,
    query_tokens: list[str] | None = None,
    status: str | None = None,
    priority: str | None = None,
    type_: str | None = None,
    epic: str | None = None,
    owner: str | None = None,
    confidence: str | None = None,
    label: str | None = None,
    text: str | None = None,
    view: str = "table",
    sort: str = "priority",
    limit: int | None = None,
) -> None:
    """List issues with filters and views."""
    issues = _load_all_issues(ctx)
    if not issues and not ctx.active_path.exists():
        emit_error(ctx, ErrorCode.NOT_FOUND, f"{ctx.active_path} not found")
        return

    # Build combined filters from flags + query-string tokens.
    filters = _merge_filters(
        query_tokens, status, priority, type_, epic, owner, confidence, label, text
    )

    if filters:
        issues = _apply_filters(issues, filters)
    else:
        issues = _default_filter(issues)

    issues = _sort_issues(issues, sort)
    if limit is not None:
        issues = issues[:limit]

    _emit_view(ctx, issues, view)


def _merge_filters(
    query_tokens: list[str] | None,
    status: str | None,
    priority: str | None,
    type_: str | None,
    epic: str | None,
    owner: str | None,
    confidence: str | None,
    label: str | None,
    text: str | None,
) -> dict[str, str]:
    """Merge flag-based and query-string filters."""
    filters: dict[str, str] = {}
    if query_tokens:
        filters.update(parse_query_tokens(query_tokens))
    if status:
        filters["status"] = status
    if priority:
        filters["priority"] = priority
    if type_:
        filters["type"] = type_
    if epic:
        filters["epic"] = epic
    if owner:
        filters["owner"] = owner
    if confidence:
        filters["confidence"] = confidence
    if label:
        filters["label"] = label
    if text:
        filters["text"] = text
    return filters


# ── view renderers ────────────────────────────────────────────────────────────


def _emit_view(ctx: AppContext, issues: list[Issue], view: str) -> None:
    """Dispatch to the correct view renderer."""
    fmt = ctx.format
    if fmt in (OutputFormat.JSON, OutputFormat.JSONL):
        _emit_json_view(ctx, issues)
        return

    views: dict[str, Any] = {
        "table": _view_table,
        "kanban": _view_kanban,
        "summary": _view_summary,
        "counts": _view_counts,
        "ids": _view_ids,
    }
    renderer = views.get(view, _view_table)
    renderer(issues)


def _emit_json_view(ctx: AppContext, issues: list[Issue]) -> None:
    """Emit JSON/JSONL output for issues."""
    import msgspec as _ms

    dicts = [_ms.to_builtins(i) for i in issues]
    if ctx.format == OutputFormat.JSONL:
        from ao._internal.output import _write_json

        for d in dicts:
            _write_json(d)
    else:
        emit_success(ctx, {"count": len(dicts), "issues": dicts})


def _view_table(issues: list[Issue]) -> None:
    """Rich table view."""
    con = Console()
    table = Table(title=f"Issues ({len(issues)})")
    for col in ("ID", "Title", "Status", "Priority", "Type", "Epic", "Owner"):
        table.add_column(col)
    for i in issues:
        table.add_row(i.id, i.title, i.status, i.priority, i.type, i.epic, i.owner)
    con.print(table)


def _view_kanban(issues: list[Issue]) -> None:
    """Kanban view grouped by status columns."""
    con = Console()
    groups: dict[str, list[Issue]] = {}
    for status in ("todo", "in_progress", "review", "blocked"):
        groups[status] = [i for i in issues if i.status == status]

    panels: list[Panel] = []
    for status, group in groups.items():
        lines = [f"  {i.id}: {i.title}" for i in group]
        body = "\n".join(lines) if lines else "  (empty)"
        panels.append(Panel(body, title=f"{status.upper()} ({len(group)})"))

    con.print(Columns(panels, equal=True))


def _view_summary(issues: list[Issue]) -> None:
    """Summary counts by status, priority, type."""
    con = Console()
    status_counts = Counter(i.status.value for i in issues)
    prio_counts = Counter(i.priority.value for i in issues)
    type_counts = Counter(i.type.value for i in issues)

    con.print("[bold underline]By Status[/bold underline]")
    for k, v in status_counts.most_common():
        con.print(f"  {k}: {v}")
    con.print("[bold underline]By Priority[/bold underline]")
    for k, v in prio_counts.most_common():
        con.print(f"  {k}: {v}")
    con.print("[bold underline]By Type[/bold underline]")
    for k, v in type_counts.most_common():
        con.print(f"  {k}: {v}")


def _view_counts(issues: list[Issue]) -> None:
    """Simple count output."""
    sys.stdout.write(f"{len(issues)}\n")


def _view_ids(issues: list[Issue]) -> None:
    """Just issue IDs, one per line."""
    for i in issues:
        sys.stdout.write(f"{i.id}\n")
