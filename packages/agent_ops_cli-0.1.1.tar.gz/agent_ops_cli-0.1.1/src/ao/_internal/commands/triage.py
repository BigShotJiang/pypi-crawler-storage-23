"""AO triage — next and triage commands."""

from __future__ import annotations

from typing import Any

import msgspec

from ao._internal.commands.epic import _load_all_issues
from ao._internal.commands.issue import (
    _do_rebuild,
    _encode_and_append,
    _make_event_id,
    _next_id,
    _now_iso,
)
from ao._internal.context import AppContext, OutputFormat
from ao._internal.output import ErrorCode, emit_error, emit_success
from ao.models import TERMINAL_STATUSES, Event, Issue, Op, Status

_PRIORITY_ORDER: dict[str, int] = {
    "critical": 0,
    "high": 1,
    "medium": 2,
    "low": 3,
    "backlog": 4,
}

_CONFIDENCE_ORDER: dict[str, int] = {
    "high": 0,
    "normal": 1,
    "low": 2,
}


def _is_ready(issue: Issue, all_issues: dict[str, Issue]) -> bool:
    """Check if issue is ready to work (not blocked, deps satisfied)."""
    if issue.status in TERMINAL_STATUSES:
        return False
    if issue.status == Status.BLOCKED:
        return False
    for dep_id in issue.dependencies.depends_on:
        dep = all_issues.get(dep_id)
        if dep and dep.status not in TERMINAL_STATUSES:
            return False
    return True


def _sort_key(issue: Issue) -> tuple[int, int, str]:
    """Sort: priority desc → confidence desc → updated asc."""
    return (
        _PRIORITY_ORDER.get(issue.priority.value, 99),
        _CONFIDENCE_ORDER.get(issue.confidence.value, 99),
        issue.updated or "",
    )


def issue_next(
    ctx: AppContext,
    *,
    owner: str | None = None,
    limit: int = 10,
) -> None:
    """Print top N ready-to-work issues."""
    all_issues_list = _load_all_issues(ctx)
    if not all_issues_list:
        emit_error(ctx, ErrorCode.NOT_FOUND, "No issues found")
        return

    all_map = {i.id: i for i in all_issues_list}
    ready = [i for i in all_issues_list if _is_ready(i, all_map)]

    if owner:
        ready = [i for i in ready if i.owner == owner]

    ready.sort(key=_sort_key)
    ready = ready[:limit]

    if ctx.format in (OutputFormat.JSON, OutputFormat.JSONL):
        dicts = [msgspec.to_builtins(i) for i in ready]
        emit_success(ctx, {"count": len(dicts), "issues": dicts})
        return

    from rich.console import Console
    from rich.table import Table

    table = Table(title=f"Next {len(ready)} Ready Issues")
    for col in ("ID", "Title", "Priority", "Confidence", "Epic"):
        table.add_column(col)
    for i in ready:
        table.add_row(i.id, i.title, i.priority, i.confidence, i.epic or "—")
    Console().print(table)


def issue_triage(ctx: AppContext) -> None:
    """Interactive bulk assignment (human-oriented, never --yes)."""
    if ctx.yes:
        emit_error(
            ctx,
            ErrorCode.VALIDATION_ERROR,
            "Triage is interactive only — cannot use --yes mode",
        )
        return

    all_issues = _load_all_issues(ctx)
    unprocessed = [
        i for i in all_issues if i.priority.value == "backlog" or i.confidence.value == "normal"
    ]

    if not unprocessed:
        emit_success(ctx, {"triaged": 0, "message": "No unprocessed issues"})
        return

    from rich.console import Console

    con = Console()
    con.print(f"[bold]Triage: {len(unprocessed)} issues to review[/bold]")

    triaged = 0
    for issue in unprocessed:
        con.print(f"\n[bold cyan]{issue.id}[/bold cyan] {issue.title}")
        con.print(f"  Priority: {issue.priority}, Confidence: {issue.confidence}")

        priority = _prompt(con, "  Priority (critical/high/medium/low/backlog) [skip]: ")
        confidence = _prompt(con, "  Confidence (low/normal/high) [skip]: ")
        epic = _prompt(con, f"  Epic [{issue.epic or 'none'}]: ")

        payload: dict[str, str] = {}
        if priority:
            payload["priority"] = priority
        if confidence:
            payload["confidence"] = confidence
        if epic:
            payload["epic"] = epic

        if payload:
            ts = _now_iso()
            num = _next_id(ctx)
            event = Event(
                event_id=_make_event_id(num),
                issue_id=issue.id,
                op=Op.SET,
                timestamp=ts,
                payload=payload,
            )
            _encode_and_append(ctx, event)
            triaged += 1

    if triaged > 0:
        _do_rebuild(ctx)
    emit_success(ctx, {"triaged": triaged, "total": len(unprocessed)})


def _prompt(con: Any, text: str) -> str:
    """Prompt user for input, return empty string on skip."""
    try:
        val: str = con.input(text).strip()
    except (EOFError, KeyboardInterrupt):
        return ""
    return val
