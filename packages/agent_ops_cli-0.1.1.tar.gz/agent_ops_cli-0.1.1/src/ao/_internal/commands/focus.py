"""AO focus — display and update session-resume context from focus.json."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from typing import Any

from rich.console import Console
from rich.table import Table

from ao._internal.context import AppContext, OutputFormat
from ao._internal.io import iter_jsonl_bytes
from ao._internal.output import ErrorCode, emit_error, emit_success
from ao.codec import MsgspecCodec

_FOCUS_FILENAME = "focus.json"
_ISSUE_COLS = ("ID", "Title", "Priority", "Confidence", "Status")
_ISSUE_KEYS = ("id", "title", "priority", "confidence", "status")


def _load_focus(ctx: AppContext) -> dict[str, Any] | None:
    """Load focus.json from ctx.root, returning None if absent.

    Args:
        ctx: Resolved application context.

    Returns:
        Parsed focus dict or None if focus.json does not exist.
    """
    path = ctx.root / _FOCUS_FILENAME
    if not path.exists():
        return None
    data: dict[str, Any] = json.loads(path.read_text(encoding="utf-8"))
    return data


def _save_focus(ctx: AppContext, data: dict[str, Any]) -> None:
    """Atomically write focus.json to ctx.root.

    Args:
        ctx: Resolved application context.
        data: Focus dictionary to persist.
    """
    path = ctx.root / _FOCUS_FILENAME
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def _today() -> str:
    return datetime.now(UTC).strftime("%Y-%m-%d")


def update_doing_now(
    ctx: AppContext,
    issue_id: str,
    task: str | None = None,
    confidence: str | None = None,
) -> dict[str, Any]:
    """Set doing_now in focus.json and update session_info.last_updated.

    Args:
        ctx: Resolved application context.
        issue_id: Full issue ID (e.g. FEAT-0042@abc123) or empty string to clear.
        task: Short task description. If None, preserves existing value.
        confidence: Confidence level. If None, preserves existing value.

    Returns:
        Updated doing_now dict.
    """
    focus = _load_focus(ctx) or {}
    doing: dict[str, Any] = focus.get("doing_now") or {}
    doing["issue_id"] = issue_id
    if task is not None:
        doing["task"] = task
    if confidence is not None:
        doing["confidence"] = confidence
    focus["doing_now"] = doing
    si: dict[str, Any] = focus.get("session_info") or {}
    si["last_updated"] = _today()
    focus["session_info"] = si
    _save_focus(ctx, focus)
    return doing


def update_next(ctx: AppContext, text: str) -> dict[str, Any]:
    """Set the 'next' field in focus.json.

    Args:
        ctx: Resolved application context.
        text: Description of the next step.

    Returns:
        Dict with the saved value.
    """
    focus = _load_focus(ctx) or {}
    focus["next"] = text
    si: dict[str, Any] = focus.get("session_info") or {}
    si["last_updated"] = _today()
    focus["session_info"] = si
    _save_focus(ctx, focus)
    return {"next": text}


def update_just_did(ctx: AppContext, summary: str) -> dict[str, Any]:
    """Set the 'just_did' field in focus.json.

    Args:
        ctx: Resolved application context.
        summary: Summary of what was just completed.

    Returns:
        Dict with the saved value.
    """
    focus = _load_focus(ctx) or {}
    focus["just_did"] = summary
    si: dict[str, Any] = focus.get("session_info") or {}
    si["last_updated"] = _today()
    focus["session_info"] = si
    _save_focus(ctx, focus)
    return {"just_did": summary}


def update_iteration(
    ctx: AppContext,
    *,
    increment: bool = False,
    issues: list[str] | None = None,
    confidence_mix: str | None = None,
) -> dict[str, Any]:
    """Update iteration_tracking in focus.json.

    Args:
        ctx: Resolved application context.
        increment: If True, increment current_iteration by 1.
        issues: List of issue IDs for this iteration. If None, preserves existing.
        confidence_mix: Free-text confidence summary (e.g. "3 normal"). If None, preserves.

    Returns:
        Updated iteration_tracking dict.
    """
    focus = _load_focus(ctx) or {}
    it: dict[str, Any] = focus.get("iteration_tracking") or {}
    if increment:
        it["current_iteration"] = int(it.get("current_iteration") or 0) + 1
        it["iteration_started"] = _today()
    if issues is not None:
        it["issues_in_iteration"] = issues
    if confidence_mix is not None:
        it["confidence_mix"] = confidence_mix
    focus["iteration_tracking"] = it
    si: dict[str, Any] = focus.get("session_info") or {}
    si["last_updated"] = _today()
    focus["session_info"] = si
    _save_focus(ctx, focus)
    return it


def sync_queues(ctx: AppContext) -> dict[str, Any]:
    """Rebuild in_progress/next_queue/recent_work from active.jsonl.

    Queries the live issue store to update the three ID arrays in focus.json.

    Args:
        ctx: Resolved application context.

    Returns:
        Dict with the three updated lists.
    """
    index = _index_active(ctx)
    issues = list(index.values())

    in_progress_ids = [i["id"] for i in issues if i.get("status") == "in_progress"]
    next_queue_ids = [
        i["id"] for i in issues if i.get("status") == "todo" and i.get("priority") != "backlog"
    ][:10]
    done_ids = [i["id"] for i in issues if i.get("status") == "done"][:5]

    focus = _load_focus(ctx) or {}
    focus["in_progress"] = in_progress_ids
    focus["next_queue"] = next_queue_ids
    focus["recent_work"] = done_ids
    si: dict[str, Any] = focus.get("session_info") or {}
    si["last_updated"] = _today()
    focus["session_info"] = si
    _save_focus(ctx, focus)
    return {
        "in_progress": in_progress_ids,
        "next_queue": next_queue_ids,
        "recent_work": done_ids,
    }


def _index_active(ctx: AppContext) -> dict[str, dict[str, Any]]:
    """Build a lookup from issue ID to detail dict from active.jsonl.

    Args:
        ctx: Resolved application context.

    Returns:
        Dict mapping issue ID → {id, title, priority, confidence, status}.
    """
    index: dict[str, dict[str, Any]] = {}
    if not ctx.active_path.exists():
        return index
    codec = MsgspecCodec()
    for line in iter_jsonl_bytes(ctx.active_path):
        if b'"_meta"' in line:
            continue
        try:
            issue = codec.decode_issue(line)
        except Exception:  # noqa: BLE001,S112
            continue
        index[issue.id] = {
            "id": issue.id,
            "title": issue.title,
            "priority": str(issue.priority),
            "confidence": str(issue.confidence),
            "status": str(issue.status),
        }
    return index


def _resolve_issues(ctx: AppContext, ids: list[str]) -> list[dict[str, Any]]:
    """Resolve a list of issue IDs to detail dicts via active.jsonl.

    Unresolved IDs (e.g. completed issues absent from active.jsonl) return
    an id-only stub ``{"id": <id>}``.

    Args:
        ctx: Resolved application context.
        ids: Issue IDs to resolve.

    Returns:
        List of issue detail dicts in the same order as *ids*.
    """
    if not ids:
        return []
    index = _index_active(ctx)
    return [index[i] if i in index else {"id": i} for i in ids]


def show_focus(ctx: AppContext) -> None:
    """Print session-resume context: doing_now + resolved issues.

    Reads focus.json from ctx.root, resolves each issue ID in
    in_progress/next_queue/recent_work against active.jsonl, and
    outputs the combined summary.

    Args:
        ctx: Resolved application context.
    """
    focus = _load_focus(ctx)
    if focus is None:
        emit_error(ctx, ErrorCode.NOT_FOUND, "focus.json not found in .agent/ops/")
        return
    in_progress = _resolve_issues(ctx, focus.get("in_progress") or [])
    next_queue = _resolve_issues(ctx, focus.get("next_queue") or [])
    recent_work = _resolve_issues(ctx, focus.get("recent_work") or [])
    if ctx.format in (OutputFormat.JSON, OutputFormat.JSONL):
        emit_success(
            ctx,
            {
                "session_info": focus.get("session_info", {}),
                "doing_now": focus.get("doing_now", {}),
                "in_progress": in_progress,
                "next_queue": next_queue,
                "recent_work": recent_work,
                "next": focus.get("next", ""),
            },
        )
        return
    _render_focus(focus, in_progress, next_queue, recent_work)


def _render_section(con: Console, title: str, issues: list[dict[str, Any]]) -> None:
    """Render one named list of issues as a Rich table."""
    table = Table(title=title)
    for col in _ISSUE_COLS:
        table.add_column(col)
    for issue in issues:
        table.add_row(*(str(issue.get(k, "")) for k in _ISSUE_KEYS))
    con.print(table)


def _render_focus(
    focus: dict[str, Any],
    in_progress: list[dict[str, Any]],
    next_queue: list[dict[str, Any]],
    recent_work: list[dict[str, Any]],
) -> None:
    """Render full focus summary as Rich console output."""
    con = Console()
    si = focus.get("session_info") or {}
    doing = focus.get("doing_now") or {}
    branch = si.get("branch", "?")
    updated = si.get("last_updated", "?")
    con.print(f"[bold]Branch:[/bold] {branch}  [bold]Updated:[/bold] {updated}")
    issue_id = doing.get("issue_id") or "—"
    con.print(f"[bold]Doing now:[/bold] {issue_id} — {doing.get('task', 'Idle')}")
    if in_progress:
        _render_section(con, f"In Progress ({len(in_progress)})", in_progress)
    if next_queue:
        _render_section(con, f"Next Queue ({len(next_queue)})", next_queue)
    if recent_work:
        _render_section(con, f"Recent Work ({len(recent_work)})", recent_work)
    con.print(f"[dim]Next:[/dim] {focus.get('next', '')}")
