"""Execute completion actions for finished issues."""

from __future__ import annotations

import json
import os
import re
import subprocess
from pathlib import Path
from typing import TYPE_CHECKING, Any
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from ao._internal.workers import VALID_COMPLETION_ACTIONS

if TYPE_CHECKING:
    from ao.api import AOClient


def _git_add_commit(wt_path: Path, message: str) -> None:
    """Git add all + commit in worktree."""
    subprocess.run(  # noqa: S603
        ["git", "-C", str(wt_path), "add", "."],  # noqa: S607
        check=True,
        capture_output=True,
    )
    subprocess.run(  # noqa: S603
        ["git", "-C", str(wt_path), "commit", "-m", message],  # noqa: S607
        check=True,
        capture_output=True,
    )


def _git_push(wt_path: Path, branch: str) -> None:
    """Push worktree branch to origin."""
    subprocess.run(  # noqa: S603
        ["git", "-C", str(wt_path), "push", "-u", "origin", branch],  # noqa: S607
        check=True,
        capture_output=True,
    )


_REMOTE_RE = re.compile(
    r"(?:https?://github\.com/|git@github\.com:)"
    r"(?P<owner>[^/]+)/(?P<repo>[^/.]+?)(?:\.git)?$"
)


def _parse_github_remote(wt_path: Path) -> tuple[str, str]:
    """Extract (owner, repo) from git remote origin URL."""
    result = subprocess.run(  # noqa: S603
        ["git", "-C", str(wt_path), "remote", "get-url", "origin"],  # noqa: S607
        capture_output=True,
        text=True,
        check=True,
    )
    url = result.stdout.strip()
    m = _REMOTE_RE.match(url)
    if not m:
        msg = f"Cannot parse GitHub owner/repo from remote URL: {url!r}"
        raise ValueError(msg)
    return m.group("owner"), m.group("repo")


def _current_branch(wt_path: Path) -> str:
    """Get the current branch of the worktree."""
    result = subprocess.run(  # noqa: S603
        ["git", "-C", str(wt_path), "rev-parse", "--abbrev-ref", "HEAD"],  # noqa: S607
        capture_output=True,
        text=True,
        check=True,
    )
    return result.stdout.strip()


def _github_create_pr(
    owner: str,
    repo: str,
    head: str,
    base: str,
    title: str,
    body: str,
    token: str,
) -> str:
    """Create GitHub PR via REST API, return PR URL."""
    url = f"https://api.github.com/repos/{owner}/{repo}/pulls"
    payload = json.dumps({
        "title": title,
        "body": body,
        "head": head,
        "base": base,
    }).encode()
    req = Request(url, data=payload, method="POST")  # noqa: S310
    req.add_header("Authorization", f"Bearer {token}")
    req.add_header("Accept", "application/vnd.github+json")
    req.add_header("Content-Type", "application/json")
    try:
        with urlopen(req) as resp:  # noqa: S310
            data: dict[str, Any] = json.loads(resp.read())
            pr_url: str = data["html_url"]
            return pr_url
    except HTTPError as exc:
        if exc.code == 422:  # noqa: PLR2004
            err_body: dict[str, Any] = json.loads(exc.read())
            errors = err_body.get("errors", [])
            for err in errors:
                if "pull request already exists" in str(err.get("message", "")):
                    msg = f"PR already exists for {head} → {base}"
                    raise ValueError(msg) from exc
        raise


def execute_completion(
    issue_id: str,
    action: str,
    wt_path: Path | None,
    client: AOClient,
    *,
    branch: str = "",
    log: str = "",
) -> dict[str, Any]:
    """Execute completion action for an issue.

    Args:
        issue_id: The issue ID to complete.
        action: One of VALID_COMPLETION_ACTIONS.
        wt_path: Worktree path (required for commit/pull_request).
        client: AOClient instance.
        branch: Git branch name (auto-detected if empty).
        log: Optional log message.

    Returns:
        Result dict with action details.
    """
    if action not in VALID_COMPLETION_ACTIONS:
        msg = f"Invalid action: {action!r}. Valid: {', '.join(sorted(VALID_COMPLETION_ACTIONS))}"
        raise ValueError(msg)

    if action == "none":
        return {"action": "none", "issue_id": issue_id}

    if action == "close":
        client.close(issue_id, log=log)
        return {"action": "close", "issue_id": issue_id}

    if action == "review":
        client.patch(issue_id, {"set": {"status": "review"}})
        if log:
            client.log_append(issue_id, log)
        return {"action": "review", "issue_id": issue_id}

    if wt_path is None:
        msg = f"Action {action!r} requires a worktree path"
        raise ValueError(msg)

    commit_msg = log or f"Complete {issue_id}"
    _git_add_commit(wt_path, commit_msg)

    if action == "commit":
        client.patch(issue_id, {"set": {"status": "review"}})
        if log:
            client.log_append(issue_id, log)
        return {"action": "commit", "issue_id": issue_id}

    # action == "pull_request"
    token = os.environ.get("GITHUB_TOKEN", "")
    if not token:
        msg = "GITHUB_TOKEN env var required for pull_request action"
        raise ValueError(msg)

    if not branch:
        branch = _current_branch(wt_path)
    owner, repo = _parse_github_remote(wt_path)
    _git_push(wt_path, branch)
    pr_url = _github_create_pr(
        owner,
        repo,
        head=branch,
        base="main",
        title=f"[{issue_id}] {commit_msg}",
        body=f"Closes {issue_id}\n\n{log}".strip(),
        token=token,
    )
    client.patch(issue_id, {
        "set": {"status": "pull_request", "external_ref": pr_url},
    })
    if log:
        client.log_append(issue_id, log)
    return {"action": "pull_request", "issue_id": issue_id, "pr_url": pr_url}
