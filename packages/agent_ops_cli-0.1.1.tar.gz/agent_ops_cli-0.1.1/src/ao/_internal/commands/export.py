"""AO export — export active issues to JSON or JSONL files."""

from __future__ import annotations

from pathlib import Path

import msgspec

from ao._internal.commands.ls import _load_all_issues
from ao._internal.context import AppContext
from ao._internal.output import ErrorCode, emit_error, emit_success


def export_json(ctx: AppContext, out: str) -> None:
    """Export all active issues as a single JSON file."""
    issues = _load_all_issues(ctx)
    if not issues:
        emit_error(ctx, ErrorCode.NOT_FOUND, "No active issues to export")
        return

    dicts = [msgspec.to_builtins(i) for i in issues]
    data = msgspec.json.encode(dicts)

    path = Path(out)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    emit_success(ctx, {"exported": len(dicts), "format": "json", "path": str(path)})


def export_jsonl(ctx: AppContext, out: str) -> None:
    """Export all active issues as JSONL file."""
    issues = _load_all_issues(ctx)
    if not issues:
        emit_error(ctx, ErrorCode.NOT_FOUND, "No active issues to export")
        return

    path = Path(out)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("wb") as f:
        for issue in issues:
            line = msgspec.json.encode(msgspec.to_builtins(issue))
            f.write(line + b"\n")

    emit_success(ctx, {"exported": len(issues), "format": "jsonl", "path": str(path)})
