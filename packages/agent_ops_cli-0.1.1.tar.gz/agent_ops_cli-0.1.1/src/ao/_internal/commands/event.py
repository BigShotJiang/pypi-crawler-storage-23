"""AO event — raw event append API."""

from __future__ import annotations

import json
import re
import sys
from typing import Any

from ao._internal.commands.issue import _do_rebuild, _encode_and_append
from ao._internal.context import AppContext
from ao._internal.output import ErrorCode, emit_error, emit_success
from ao.models import Event, Op

_VALID_OPS: frozenset[str] = frozenset(op.value for op in Op)
_ISSUE_ID_RE = re.compile(r"^[A-Z]+\-\d{4}@[0-9a-f]{6}$")

_REQUIRED_FIELDS: tuple[str, ...] = ("event_id", "issue_id", "op", "ts", "data")


def event_append(ctx: AppContext, *, no_rebuild: bool = False) -> None:
    """Read EventInput JSON from stdin, validate, and append."""
    try:
        data = _read_event_input(ctx)
    except (json.JSONDecodeError, ValueError) as exc:
        emit_error(ctx, ErrorCode.PARSE_ERROR, str(exc))
        return

    errors = _validate_event_input(data)
    if errors:
        emit_error(ctx, ErrorCode.VALIDATION_ERROR, "; ".join(errors))
        return

    event = Event(
        event_id=data["event_id"],
        issue_id=data["issue_id"],
        op=Op(data["op"]),
        timestamp=data["ts"],
        payload=data.get("data", {}),
    )
    _encode_and_append(ctx, event)

    rebuild_status = "skipped"
    if not no_rebuild:
        _do_rebuild(ctx)
        rebuild_status = "done"

    emit_success(
        ctx,
        {
            "event_id": event.event_id,
            "appended": True,
            "rebuild": rebuild_status,
            "paths": {"events": str(ctx.events_path), "active": str(ctx.active_path)},
        },
    )


def _read_event_input(ctx: AppContext) -> dict[str, Any]:
    """Read JSON from stdin."""
    if ctx.in_path != "-":
        msg = f"Expected --in -, got: {ctx.in_path}"
        raise ValueError(msg)
    raw = sys.stdin.buffer.read()
    result: dict[str, Any] = json.loads(raw)
    return result


def _validate_event_input(data: dict[str, Any]) -> list[str]:
    """Validate EventInput schema and enums. Returns list of error messages."""
    errors: list[str] = []
    for field in _REQUIRED_FIELDS:
        if field not in data:
            errors.append(f"Missing required field: {field}")

    if errors:
        return errors

    if not isinstance(data["event_id"], str) or not data["event_id"]:
        errors.append("event_id must be a non-empty string")

    if not isinstance(data["issue_id"], str):
        errors.append("issue_id must be a string")
    elif not _ISSUE_ID_RE.match(data["issue_id"]):
        errors.append(f"Invalid issue_id format: {data['issue_id']}")

    if data["op"] not in _VALID_OPS:
        errors.append(f"Invalid op: {data['op']} (valid: {sorted(_VALID_OPS)})")

    if not isinstance(data["ts"], str) or not data["ts"]:
        errors.append("ts must be a non-empty string")

    if not isinstance(data.get("data", {}), dict):
        errors.append("data must be a dict")

    return errors
