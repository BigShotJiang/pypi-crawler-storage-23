"""AO ac — acceptance criteria subcommands."""

from __future__ import annotations

from ao._internal.commands.issue import (
    _do_rebuild,
    _encode_and_append,
    _load_issue,
    _make_event_id,
    _next_id,
    _now_iso,
)
from ao._internal.context import AppContext, OutputFormat
from ao._internal.output import ErrorCode, emit_error, emit_success
from ao.models import Event, Op


def ac_ls(ctx: AppContext, issue_id: str) -> None:
    """List acceptance criteria with numbered checkboxes."""
    issue = _load_issue(ctx, issue_id)
    if issue is None:
        emit_error(ctx, ErrorCode.NOT_FOUND, f"Issue {issue_id} not found")
        return

    criteria = [
        {"index": i + 1, "text": ac.description, "done": ac.done}
        for i, ac in enumerate(issue.acceptance_criteria)
    ]

    if ctx.format in (OutputFormat.JSON, OutputFormat.JSONL):
        emit_success(ctx, {"issue_id": issue_id, "criteria": criteria})
        return

    from rich.console import Console

    con = Console()
    if not criteria:
        con.print(f"No acceptance criteria for {issue_id}")
        return
    done = sum(1 for c in criteria if c["done"])
    con.print(f"[bold]AC for {issue_id}[/bold] ({done}/{len(criteria)} done)")
    for c in criteria:
        check = "x" if c["done"] else " "
        con.print(f"  [{check}] {c['index']}. {c['text']}")


def ac_add(ctx: AppContext, issue_id: str, text: str) -> None:
    """Append a new acceptance criterion."""
    ts = _now_iso()
    num = _next_id(ctx)
    event = Event(
        event_id=_make_event_id(num),
        issue_id=issue_id,
        op=Op.ACCEPTANCE_ADD,
        timestamp=ts,
        payload={"description": text, "done": False},
    )
    _encode_and_append(ctx, event)
    _do_rebuild(ctx)
    emit_success(ctx, {"issue_id": issue_id, "event_id": event.event_id, "text": text})


def ac_check(ctx: AppContext, issue_id: str, index: int) -> None:
    """Mark criterion done by 1-based index."""
    _toggle_ac(ctx, issue_id, index, done=True)


def ac_uncheck(ctx: AppContext, issue_id: str, index: int) -> None:
    """Mark criterion not done by 1-based index."""
    _toggle_ac(ctx, issue_id, index, done=False)


def _toggle_ac(ctx: AppContext, issue_id: str, index: int, *, done: bool) -> None:
    """Toggle acceptance criterion done status."""
    ts = _now_iso()
    num = _next_id(ctx)
    # Convert 1-based user index to 0-based internal index
    event = Event(
        event_id=_make_event_id(num),
        issue_id=issue_id,
        op=Op.ACCEPTANCE_CHECK,
        timestamp=ts,
        payload={"index": index - 1, "done": done},
    )
    _encode_and_append(ctx, event)
    _do_rebuild(ctx)
    state = "checked" if done else "unchecked"
    emit_success(
        ctx,
        {
            "issue_id": issue_id,
            "event_id": event.event_id,
            "index": index,
            "done": done,
            "state": state,
        },
    )


def ac_rm(ctx: AppContext, issue_id: str, index: int) -> None:
    """Remove criterion by 1-based index."""
    ts = _now_iso()
    num = _next_id(ctx)
    event = Event(
        event_id=_make_event_id(num),
        issue_id=issue_id,
        op=Op.ACCEPTANCE_RM,
        timestamp=ts,
        payload={"index": index - 1},
    )
    _encode_and_append(ctx, event)
    _do_rebuild(ctx)
    emit_success(
        ctx,
        {
            "issue_id": issue_id,
            "event_id": event.event_id,
            "removed_index": index,
        },
    )
