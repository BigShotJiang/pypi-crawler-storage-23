"""AO duplicate command for skill cloning across tool configs."""

from __future__ import annotations

import shutil
from pathlib import Path
from typing import Any

_RELATED_FILES: tuple[tuple[str, str], ...] = (
    (".ao/prompts", ".prompt.md"),
    (".github/prompts", ".prompt.md"),
    (".ao/agents", ".agent.md"),
    (".github/agents", ".agent.md"),
    (".opencode/commands", ".md"),
    (".claude/commands", ".md"),
    (".opencode/agents", ".md"),
    (".claude/agents", ".md"),
)


def duplicate_skill_assets(root: Path, source_name: str, new_name: str) -> dict[str, Any]:
    """Duplicate a skill and related command/prompt files.

    Args:
        root: Project root containing `.ao` and engine directories.
        source_name: Existing skill name (directory and command base name).
        new_name: New skill name to create.

    Returns:
        Summary dictionary of duplicated assets.

    Raises:
        ValueError: If source is missing or destination/collisions already exist.
    """
    source = source_name.strip()
    target = new_name.strip()
    _validate_names(source, target)
    skill_src = root / ".ao" / "skills" / source
    skill_dst = root / ".ao" / "skills" / target
    _ensure_source_exists(skill_src, source)
    _ensure_dest_absent(skill_dst, target)
    related = _collect_related_pairs(root, source, target)
    _ensure_no_collisions(skill_dst, related)
    copied = _copy_all(skill_src, skill_dst, related)
    rewritten = _rewrite_new_assets(skill_dst, related, source, target)
    return {
        "source": source,
        "new": target,
        "copied": copied,
        "rewritten": rewritten,
        "skill": str(skill_dst),
    }


def _validate_names(source: str, target: str) -> None:
    if not source or not target:
        raise ValueError("source and new skill names are required")
    if source == target:
        raise ValueError("new skill name must differ from source")


def _ensure_source_exists(skill_src: Path, source: str) -> None:
    if not skill_src.exists() or not skill_src.is_dir():
        raise ValueError(f"source skill not found: {source}")


def _ensure_dest_absent(skill_dst: Path, target: str) -> None:
    if skill_dst.exists():
        raise ValueError(f"destination skill already exists: {target}")


def _collect_related_pairs(root: Path, source: str, target: str) -> list[tuple[Path, Path]]:
    pairs: list[tuple[Path, Path]] = []
    for folder, suffix in _RELATED_FILES:
        src = root / folder / f"{source}{suffix}"
        if not src.exists():
            continue
        dst = root / folder / f"{target}{suffix}"
        pairs.append((src, dst))
    return pairs


def _ensure_no_collisions(skill_dst: Path, related: list[tuple[Path, Path]]) -> None:
    if skill_dst.exists():
        raise ValueError(f"destination already exists: {skill_dst}")
    for _, dst in related:
        if dst.exists():
            raise ValueError(f"destination already exists: {dst}")


def _copy_all(skill_src: Path, skill_dst: Path, related: list[tuple[Path, Path]]) -> list[str]:
    copied: list[str] = []
    shutil.copytree(skill_src, skill_dst)
    copied.append(str(skill_dst))
    for src, dst in related:
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        copied.append(str(dst))
    return copied


def _rewrite_new_assets(
    skill_dst: Path,
    related: list[tuple[Path, Path]],
    source: str,
    target: str,
) -> list[str]:
    rewritten: list[str] = []
    for path in _iter_text_files(skill_dst):
        _replace_token(path, source, target)
        rewritten.append(str(path))
    for _, dst in related:
        _replace_token(dst, source, target)
        rewritten.append(str(dst))
    _rewrite_skill_name_field(skill_dst / "SKILL.md", target)
    return rewritten


def _iter_text_files(root: Path) -> list[Path]:
    return [p for p in root.rglob("*") if p.is_file() and p.suffix.lower() == ".md"]


def _replace_token(path: Path, source: str, target: str) -> None:
    text = path.read_text(encoding="utf-8", errors="ignore")
    path.write_text(text.replace(source, target), encoding="utf-8")


def _rewrite_skill_name_field(path: Path, target: str) -> None:
    if not path.exists():
        return
    lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
    out: list[str] = []
    in_frontmatter = False
    for line in lines:
        if line.strip() == "---":
            in_frontmatter = not in_frontmatter
            out.append(line)
            continue
        if in_frontmatter and line.strip().startswith("name:"):
            out.append(f"name: {target}")
            continue
        out.append(line)
    path.write_text("\n".join(out) + "\n", encoding="utf-8")
