"""AO bench — benchmark decode and rebuild throughput."""

from __future__ import annotations

import time
from pathlib import Path

from rich.console import Console
from rich.table import Table

from ao._internal.io import file_byte_size, iter_jsonl_bytes
from ao._internal.rebuild import rebuild as do_rebuild
from ao.codec import get_codec

console = Console()


def bench_decode(file: Path, codec_name: str) -> None:
    """Benchmark raw decode throughput on a JSONL file."""
    codec = get_codec(codec_name)
    total_bytes = file_byte_size(file)
    records = 0

    start = time.perf_counter()
    for line in iter_jsonl_bytes(file):
        try:
            codec.decode_event(line)
            records += 1
        except Exception:  # noqa: S110
            pass
    elapsed = time.perf_counter() - start

    _print_results("Decode", codec_name, records, total_bytes, elapsed)


def bench_rebuild(events_path: Path, codec_name: str) -> None:
    """Benchmark full rebuild pipeline."""
    codec = get_codec(codec_name)
    total_bytes = file_byte_size(events_path)

    # Count records first (quick scan)
    records = sum(1 for _ in iter_jsonl_bytes(events_path))

    active_path = events_path.parent / ".bench_active.jsonl"
    start = time.perf_counter()
    issues = do_rebuild(events_path, active_path, codec, show_progress=False)
    elapsed = time.perf_counter() - start

    # Cleanup temp file
    active_path.unlink(missing_ok=True)

    _print_results("Rebuild", codec_name, records, total_bytes, elapsed, len(issues))


def _print_results(
    operation: str,
    codec_name: str,
    records: int,
    total_bytes: int,
    elapsed: float,
    active_count: int | None = None,
) -> None:
    """Print benchmark results in a table."""
    mb = total_bytes / (1024 * 1024)
    rps = records / elapsed if elapsed > 0 else 0
    mbps = mb / elapsed if elapsed > 0 else 0

    table = Table(title=f"{operation} Benchmark ({codec_name})")
    table.add_column("Metric", style="bold")
    table.add_column("Value", justify="right")
    table.add_row("Records", f"{records:,}")
    table.add_row("File size", f"{mb:.1f} MB")
    table.add_row("Time", f"{elapsed:.3f} s")
    table.add_row("Throughput", f"{rps:,.0f} records/s")
    table.add_row("Bandwidth", f"{mbps:.1f} MB/s")
    if active_count is not None:
        table.add_row("Active issues", f"{active_count:,}")

    console.print(table)
