---
name: ao-setup
description: "Run /ao-help or /ao-constitution to get started with AO workflow."
tools: ["execute", "read", "edit", "search", "agent", "web", "todo"]
handoffs:
  - label: Get to work
    agent: ao-worker
    prompt: "/ao-help"
    send: true
---

# AO Setup

> **See `.ao/AGENTS.example.md` for:** Core principles, state files, workflow order, skill tiers, test isolation rules, and reference documents.

## Getting Started

Run `/ao-help` or `/ao-constitution` to begin the AO workflow.