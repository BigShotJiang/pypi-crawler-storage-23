Use the `ao-usage` skill for deterministic, JSON-based issue management via the AO CLI.

## Quick Usage

Ensure every `ao` invocation includes `--yes --format json --progress none`. Use `ao ls` to list issues, `ao issue patch` to update, and `ao issue close` to complete work.

## When to Use

- When an agent needs to read, create, or update issues programmatically
- When automating issue lifecycle (claim → work → close) without interactive prompts
- When integrating AO into autonomous agent workflows

## Options

- **List**: `ao ls --status todo --priority high --yes --format json --progress none`
- **Show**: `ao issue show ISSUE_ID --yes --format json --progress none`
- **Create**: Pipe `IssueCreateInput` JSON to `ao issue add --in - ...`
- **Patch**: Pipe `IssuePatchInput` JSON to `ao issue patch ISSUE_ID --in - ...`
- **Close**: `ao issue close ISSUE_ID --log "..." --status done ...`
