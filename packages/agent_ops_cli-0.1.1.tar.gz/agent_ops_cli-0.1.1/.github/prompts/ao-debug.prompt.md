---
name: ao-debug
description: Systematic debugging to isolate and fix software defects
tools:
  - read_file
  - grep_search
  - semantic_search
  - run_in_terminal
  - get_errors
---

# Debug

Systematically isolate and fix the reported issue.

## Your Task

Read the skill file at `.ao/skills/ao-debugging/SKILL.md` and follow its systematic process.

## Quick Process

1. **Define**: Describe bug, reproduction steps, expected vs actual
2. **Gather**: Check logs, inspect state, review recent changes
3. **Hypothesize**: Form testable theories about root cause
4. **Test**: Add logging, use debugger, write failing test
5. **Fix**: Address root cause, add regression test, verify

## Key Questions

- Can you consistently reproduce?
- What changed recently?
- What does the error message actually say?
- Where does the code path diverge from expected?

## Remember

- **One variable at a time** — don't change multiple things
- **Root cause, not symptoms** — don't just add error handling
- **Evidence over assumptions** — verify, don't guess
- **Add regression test** — prevent the bug from returning

## Output

Update `.agent/ops/focus.json` with:
- Hypotheses tested and results
- Evidence gathered
- Root cause identified
- Fix applied and verified
