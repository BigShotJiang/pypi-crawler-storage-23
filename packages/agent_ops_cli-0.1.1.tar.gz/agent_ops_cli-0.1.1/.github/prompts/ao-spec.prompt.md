---
name: ao-spec
description: "Create or manage specification documents in .agent/ops/specs/"
---

Use skill `ao-spec` for spec management.

## Creating a spec:
1. Ask user for spec name/topic or generate from context
2. Use spec template from skill
3. Gather requirements via `ao-interview` if needed
4. Create file in `.agent/ops/specs/`
5. Link spec to issue(s) in `.agent/ops/issues/`
6. Update `.agent/ops/focus.json`

## Updating a spec:
1. Read existing spec
2. Identify what needs updating
3. Make minimal changes
4. Update changelog in spec
5. Update `.agent/ops/focus.json`

## Validating against spec:
1. Read linked spec file
2. Create traceability checklist
3. Mark each requirement as: implemented / tested / missing
4. Update spec's traceability matrix

```
