---
name: ao-validation
description: "Run pre-commit validation checks and compare against baseline"
---

Use skill `ao-validation` for quality gate checks.

## Validation tiers:

### Quick (Tier 1) — use for fast feedback:
- Syntax validation
- Fast lint
- Type check (if applicable)

### Standard (Tier 2) — use before commits:
- All Tier 1 checks
- Full build
- Unit tests
- Baseline comparison

### Comprehensive (Tier 3) — use before merge/completion:
- All Tier 2 checks
- Full test suite
- Coverage analysis
- Security scan (if configured)
- Documentation check

## Procedure:
1. Read constitution for commands
2. Run checks for requested tier
3. Compare results to baseline
4. Report: PASS / FAIL / REGRESSION
5. If regression: investigate before proceeding
6. Update `.agent/ops/focus.json` with results

## Usage:
- `/ao-validation` — runs Tier 2 (standard)
- `/ao-validation quick` — runs Tier 1 only
- `/ao-validation full` — runs Tier 3 (comprehensive)

