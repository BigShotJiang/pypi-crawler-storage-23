---
name: ao-testing
description: "Design test strategy, run tests, or analyze coverage"
---

Use skill `ao-testing` for test-related work.

## Test strategy (during planning):
1. Identify test levels needed (unit, integration, e2e)
2. Define test cases from requirements
3. Document in task/plan

## Running tests (during implementation):
1. Run incremental tests after each step
2. Run full suite at end of implementation
3. Compare to baseline
4. Investigate any new failures

## Coverage analysis:
1. Run tests with coverage enabled
2. Identify gaps in new code
3. Flag untested critical paths
4. Document acceptable gaps with rationale

## Failure investigation:
1. Isolate failing test
2. Reproduce consistently
3. Diagnose root cause
4. Categorize: agent change / pre-existing / flaky / environment
5. Fix or escalate
6. Document findings in .agent/ops/issues/