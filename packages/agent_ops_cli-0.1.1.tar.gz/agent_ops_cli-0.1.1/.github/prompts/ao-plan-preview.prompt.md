---
name: ao-plan-preview
description: "Generate stakeholder-friendly summaries from implementation plans with file change overviews and optional flow diagrams"
---

Use the `ao-plan-preview` skill for generating stakeholder-friendly summaries from implementation plans.
## Quick Usage

```
/ao-plan-preview FEAT-0042@abc123
/ao-plan-preview .agent/ops/issues/references/PLAN-0295@a1b2c3-plan.md
/ao-plan-preview  (uses plan from current context)
```

## When to Use

- Before presenting implementation plans for approval
- When tech leads or project owners need to review planned work
- To communicate changes to non-technical stakeholders
- When detailed plans need a concise executive summary

## Options

- **Issue ID**: Provide issue ID to auto-resolve plan file
- **File path**: Direct path to any plan markdown file
- **No argument**: Uses plan from current conversation context

## Output Language
## Interview

The skill will ask: language, confidence, objective emphasis, sections to include/exclude, diagram preference, and any special formatting/terminology.

## Custom Template

If a template.md exists next to the skill, it will be used instead of the built-in template.

The skill will ask for your preferred output language before generating. Common choices:
- English (default)
- Norwegian (Norsk)

## Output Actions

After generating, choose:
1. **Open in editor** — View/edit as new file
2. **Save to .agent/ops/docs/** — Persist for sharing
3. **Done** — Keep in chat only
