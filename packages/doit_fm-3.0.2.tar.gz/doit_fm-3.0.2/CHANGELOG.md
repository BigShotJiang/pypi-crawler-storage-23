# Changelog

## 2.1.0 — 2025-02

### 🚀 New
- Renamed to `doit-fm`; published on PyPI
- `doitfm init` guided wizard with auto-dependency install
- `doitfm doctor` — diagnoses + auto-fixes installation issues
- `doitfm update` — one-command PyPI update
- `doitfm stop` — graceful agent shutdown
- `--reconfigure` flag on init to change settings without full reinstall
- 97 tools across 15 categories
- Multi-turn conversation memory (plain English context across messages)
- Dynamic AI system prompt with 50+ natural language → tool examples
- Rich result formatters in Telegram (no raw JSON ever shown to users)
- Inline confirm/cancel buttons for dangerous operations
- Exponential reconnect backoff for Telegram network errors
- `check_message()` injection guard on all incoming messages
- Full src-layout PyPI packaging with correct entry points
- Auto-installs Pillow, pypdf, qrcode as core dependencies

### 🔧 Fixed
- Missing `check_message` method on InjectionGuard
- Held tasks not properly released after inline button confirmation
- AI system prompt rebuilt on every call (now cached)
- False-positive tool implementation check in test suite
- All internal imports correctly namespaced to `doit_fm.*`

## 2.0.0 — 2025-01

- Major expansion from 24 to 70+ tools
- Added: git, docker, SSH, desktop automation, dev tools, memory/notes/todos
- Multi-turn conversation context
- Telegram inline buttons for confirmation
- Dynamic tool discovery from registry

## 1.0.0 — 2024-12

- Initial release
- 24 tools: filesystem, system monitoring, network
- Telegram bot, encrypted config, SQLite persistence
- Plugin system, scheduler, crash recovery
