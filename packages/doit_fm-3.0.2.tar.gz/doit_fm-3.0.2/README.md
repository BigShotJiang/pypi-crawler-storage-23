# doit-fm v3.0

**AI Telegram bot that controls your computer.** Talk to it naturally — it understands plain English, typos included.

## Install

```bash
pip install doit-fm
doitfm init    # 2-minute setup wizard
doitfm run     # start the agent
```

## What it does

| Category | Tools |
|----------|-------|
| 📁 Files | list, read, write, delete, search |
| 💻 System | CPU/RAM/disk monitor, process list, kill |
| 🐚 Shell | run any command (`/run ls -la`) |
| 🌐 Web | search (DuckDuckGo), weather (wttr.in) |
| 🧮 Math | evaluate any expression |
| 🧠 Memory | remember facts, notes, to-dos |
| 📸 Desktop | screenshot, desktop notifications |
| 🌿 Git | status + recent commits |
| ⏰ Reminders | fire after N minutes |

## Dependencies

Only **3 required** packages:
- `psutil` — system metrics
- `click` — CLI
- `cryptography` — encrypted config

Everything else uses Python stdlib. No `aiohttp`, no `python-telegram-bot`, no complex frameworks.

## Telegram commands

| Command | Does |
|---------|------|
| `/health` | CPU/RAM/disk stats |
| `/memory` | stored facts |
| `/todos` | to-do list |
| `/notes` | your notes |
| `/tools` | all 26 tools |
| `/run cmd` | run shell command |
| `/search q` | web search |
| `/clear` | reset conversation |
| `/safe` / `/resume` | pause / resume |
| `/status` | agent status |

## Natural language examples

- *show me what's in Downloads*
- *how's my computer doing?*
- *weather in Tokyo*
- *remind me in 30 minutes to drink water*
- *remember that my server IP is 192.168.1.100*
- *find all PDF files in Documents*
- *calculate the square root of 256*
- *make a note: dentist appointment Friday 3pm*

## AI providers

Works with OpenAI, Anthropic, Groq (free tier), or Ollama (local).
