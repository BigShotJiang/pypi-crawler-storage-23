"""All paths and constants. Zero imports except stdlib."""
import os, sys
from pathlib import Path

VERSION = "3.0.0"

if sys.platform == "win32":
    BASE_DIR = Path(os.environ.get("APPDATA", Path.home())) / "doit-fm"
elif sys.platform == "darwin":
    BASE_DIR = Path.home() / "Library" / "Application Support" / "doit-fm"
else:
    BASE_DIR = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / "doit-fm"

DATA_DIR    = BASE_DIR / "data"
LOG_DIR     = BASE_DIR / "logs"
CONFIG_FILE = BASE_DIR / "config.json"
LOCK_FILE   = DATA_DIR / "agent.pid"

AI_PROVIDERS = {
    "openai": {
        "name": "OpenAI",
        "base_url": "https://api.openai.com/v1",
        "models": [
            {"id": "gpt-4o-mini", "label": "GPT-4o Mini (fast, cheap)", "free": False},
            {"id": "gpt-4o",      "label": "GPT-4o (most capable)",      "free": False},
        ],
    },
    "anthropic": {
        "name": "Anthropic (Claude)",
        "base_url": "https://api.anthropic.com/v1",
        "models": [
            {"id": "claude-haiku-4-5-20251001", "label": "Claude Haiku (fast)", "free": False},
            {"id": "claude-sonnet-4-6",          "label": "Claude Sonnet",       "free": False},
        ],
    },
    "groq": {
        "name": "Groq (fast & free tier)",
        "base_url": "https://api.groq.com/openai/v1",
        "models": [
            {"id": "llama-3.1-8b-instant",     "label": "Llama 3.1 8B (free)",  "free": True},
            {"id": "llama-3.3-70b-versatile",   "label": "Llama 3.3 70B (free)", "free": True},
        ],
    },
    "ollama": {
        "name": "Ollama (local, private, free)",
        "base_url": "http://localhost:11434/v1",
        "models": [
            {"id": "llama3.2", "label": "Llama 3.2", "free": True},
        ],
    },
}

HTTP_TIMEOUT = 60
BLOCKED_PATHS = ["/etc/shadow", "/etc/passwd"]
