"""doit-fm — AI Telegram bot that controls your computer."""
__version__ = "3.0.0"
