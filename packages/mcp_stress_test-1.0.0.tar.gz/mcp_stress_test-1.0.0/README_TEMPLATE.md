# {{PROJECT_NAME}}

{{ONE_LINE_VALUE_PROP}}

---

## Problem

{{WHY_LOAD_TESTING_IS_HARD}}

## Solution

{{HOW_THIS_PROJECT_HELPS}}

---

## Example

```bash
{{MINIMAL_EXAMPLE}}
```

---

## Use cases

- {{USE_CASE_1}}
- {{USE_CASE_2}}

---

## Status

{{ALPHA | BETA | STABLE}}

---

## License

MIT
