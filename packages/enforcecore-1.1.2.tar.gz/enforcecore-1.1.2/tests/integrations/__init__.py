# Copyright 2026 AKIOUD AI
# SPDX-License-Identifier: Apache-2.0
"""Integration adapter tests."""
