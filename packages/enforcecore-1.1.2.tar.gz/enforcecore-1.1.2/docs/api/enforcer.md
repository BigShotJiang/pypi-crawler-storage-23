# Enforcer

::: enforcecore.core.enforcer.Enforcer

::: enforcecore.core.enforcer.enforce

::: enforcecore.core.enforcer.clear_policy_cache
