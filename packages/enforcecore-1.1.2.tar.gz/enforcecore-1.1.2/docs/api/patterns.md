# Custom Patterns

::: enforcecore.redactor.patterns.PatternRegistry

::: enforcecore.redactor.patterns.CustomPattern
