import numpy as np
from .base_model import BaseModel
class Linear(BaseModel):

    def __init__(self,lr=0.01,epochs=1000):
        self.lr=lr
        self.epochs=epochs
        self.weight = None
        self.bias = None

    def fit(self,X,y):
        n_sample,n_feature=X.shape

        self.weight = np.zeros(n_feature)
        self.bias = 0

        for i in range(self.epochs):
            y_pred = X.dot(self.weight) + self.bias

            loss = (1/n_sample) * np.sum((y-y_pred)**2)

            dw = (2/n_sample) * X.T @ (y_pred-y)
            gd = (2/n_sample) * np.sum(y_pred - y)
        
            self.weight = self.weight - self.lr * dw
            self.bias = self.bias - self.lr * gd

    def predict(self,X):
        return X.dot(self.weight)+self.bias
    def score(self, X, y):
        y_pred = self.predict(X)
        ss_res = np.sum((y - y_pred)**2)
        ss_tot = np.sum((y - np.mean(y))**2)
        return 1 - (ss_res / (ss_tot + 1e-8))

