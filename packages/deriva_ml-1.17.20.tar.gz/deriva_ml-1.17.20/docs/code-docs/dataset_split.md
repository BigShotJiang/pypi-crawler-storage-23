# Dataset Splitting

Functions for splitting DerivaML datasets into training and testing subsets
with full provenance tracking. Supports random, stratified, and custom
selection strategies.

::: deriva_ml.dataset.split
    handler: python
