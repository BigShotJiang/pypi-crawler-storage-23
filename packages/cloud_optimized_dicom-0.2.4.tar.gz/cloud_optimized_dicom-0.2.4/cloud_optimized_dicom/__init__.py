from importlib.metadata import version

__version__ = version("cloud-optimized-dicom")
__author__ = "Cal Nightingale"
__credits__ = "Gradient Health"
