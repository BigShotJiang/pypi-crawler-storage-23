"""
Backtest module for Vero Algo SDK.

Provides historical simulation engine.
"""

from .engine import BacktestEngine
from ..models import PerformanceReport

__all__ = [
    "BacktestEngine",
    "PerformanceReport",
]
