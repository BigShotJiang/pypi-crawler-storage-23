"""
Report and metrics DTOs for Vero Algo SDK.

Pure data containers — no calculation or display logic.
Used by both backtest and live modes.
"""

from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any, Optional

from .position import ClosedPosition


@dataclass
class StrategyMetrics:
    """Strategy performance metrics (used in both live and backtest)."""

    # Summary
    net_profit: float = 0
    net_profit_pct: float = 0
    total_trades: int = 0
    winning_trades: int = 0
    losing_trades: int = 0
    win_rate: float = 0
    profit_factor: float = 0

    # Returns
    total_return: float = 0
    annualized_return: float = 0
    monthly_return: float = 0

    # Risk metrics
    max_drawdown: float = 0
    max_drawdown_pct: float = 0
    max_drawdown_duration_days: int = 0
    volatility: float = 0
    sharpe_ratio: float = 0
    sortino_ratio: float = 0
    calmar_ratio: float = 0
    value_at_risk: float = 0  # 95% VaR

    # Trade statistics
    avg_win: float = 0
    avg_loss: float = 0
    largest_win: float = 0
    largest_loss: float = 0
    avg_trade: float = 0
    avg_bars_in_trade: float = 0
    expectancy: float = 0

    # Streaks
    max_consecutive_wins: int = 0
    max_consecutive_losses: int = 0
    recovery_factor: float = 0

    # Performance breakdown
    gross_profit: float = 0
    gross_loss: float = 0

    # Alpha/Beta (vs benchmark)
    alpha: float = 0
    beta: float = 0

    # NAV
    current_nav: float = 0

    # Open positions snapshot
    open_position_avg_price: float = 0
    open_position_qty: int = 0
    open_position_unrealized_pnl: float = 0

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return asdict(self)


@dataclass
class PerformanceReport:
    """Performance report data container (used in both live and backtest)."""

    strategy_name: str = ""
    backtest_period: str = ""
    metrics: StrategyMetrics = field(default_factory=StrategyMetrics)
    equity_curve: List[float] = field(default_factory=list)
    equity_dates: List[int] = field(default_factory=list)
    monthly_returns: Dict[str, float] = field(default_factory=dict)
    trades: List[ClosedPosition] = field(default_factory=list)

    def print_report(self) -> None:
        """Print formatted report to console."""
        from ..report import print_report
        print_report(self)

    def to_dict(self) -> Dict[str, Any]:
        """Convert report to dictionary for JSON export."""
        return {
            "strategy_name": self.strategy_name,
            "backtest_period": self.backtest_period,
            "metrics": {
                "net_profit": self.metrics.net_profit,
                "net_profit_pct": self.metrics.net_profit_pct,
                "total_trades": self.metrics.total_trades,
                "winning_trades": self.metrics.winning_trades,
                "losing_trades": self.metrics.losing_trades,
                "win_rate": self.metrics.win_rate,
                "profit_factor": self.metrics.profit_factor,
                "total_return": self.metrics.total_return,
                "annualized_return": self.metrics.annualized_return,
                "max_drawdown_pct": self.metrics.max_drawdown_pct,
                "sharpe_ratio": self.metrics.sharpe_ratio,
                "sortino_ratio": self.metrics.sortino_ratio,
                "calmar_ratio": self.metrics.calmar_ratio,
                "avg_win": self.metrics.avg_win,
                "avg_loss": self.metrics.avg_loss,
                "expectancy": self.metrics.expectancy,
                "current_nav": self.metrics.current_nav,
                "open_position_avg_price": self.metrics.open_position_avg_price,
                "open_position_qty": self.metrics.open_position_qty,
                "open_position_unrealized_pnl": self.metrics.open_position_unrealized_pnl,
            },
            "monthly_returns": self.monthly_returns,
            "equity_curve": [
                {"time": ts, "value": value}
                for ts, value in zip(self.equity_dates, self.equity_curve)
            ],
        }
