from dataclasses import dataclass, asdict, field
from typing import ClassVar, FrozenSet, Optional, List, Any


@dataclass
class StrategyInitSettings:
    """
    Settings for initializing a strategy.
    """
    symbols: List[str] = field(default_factory=list)
    mode: object = "BACKTEST"
    board: str = "G1"
    initial_capital: float = 1000000000.0
    timeframe: object = "1d"
    from_date: Optional[int] = None  # Unix timestamp in milliseconds
    to_date: Optional[int] = None  # Unix timestamp in milliseconds
    account_id: Optional[str] = None
    api_port: Optional[int] = 8080
    jwt_token: Optional[str] = None
    callback_url: Optional[str] = None

    # Updatable fields that can be changed at runtime
    UPDATABLE_FIELDS: ClassVar[FrozenSet[str]] = frozenset({
        "timeframe", "initial_capital", "board",
    })

    @property
    def symbol(self) -> str:
        """Get primary symbol (first in list)."""
        return self.symbols[0] if self.symbols else ""

    @classmethod
    def default(cls) -> "StrategyInitSettings":
        """Get default settings."""
        return cls()

    def to_dict(self) -> dict:
        """Convert to dictionary, masking sensitive fields."""
        d = asdict(self)
        if d.get("jwt_token"):
            d["jwt_token"] = "***"
        return d

    def update(self, changes: dict) -> dict:
        """
        Apply runtime changes to updatable fields.

        Args:
            changes: Dict of field_name -> new_value

        Returns:
            Dict of actually applied changes {field: {"old": ..., "new": ...}}
        """
        applied = {}
        for key, value in changes.items():
            if key not in self.UPDATABLE_FIELDS:
                continue
            if not hasattr(self, key):
                continue
            old = getattr(self, key)
            if old == value:
                continue
            setattr(self, key, value)
            applied[key] = {"old": old, "new": value}
        return applied

