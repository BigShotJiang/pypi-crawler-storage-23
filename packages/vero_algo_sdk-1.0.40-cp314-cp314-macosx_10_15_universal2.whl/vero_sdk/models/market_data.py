from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional

@dataclass
class Candle:
    """OHLCV candle data."""
    time: int  # Unix timestamp in milliseconds
    open: float
    high: float
    low: float
    close: float
    volume: float
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Candle":
        """Create from API response dict."""
        return cls(
            time=int(data.get("unixTime", 0)),
            open=float(data.get("open", 0)),
            high=float(data.get("high", 0)),
            low=float(data.get("low", 0)),
            close=float(data.get("close", 0)),
            volume=float(data.get("volume", 0)),
        )


@dataclass
class PriceLevel:
    """Price level in order book depth."""
    price: float
    qty: int
    num_orders: int = 0
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PriceLevel":
        """Create from API response dict."""
        return cls(
            price=float(data.get("price", 0)),
            qty=int(data.get("qty", 0)),
            num_orders=int(data.get("numOrders", 0)),
        )


@dataclass
class Depth:
    """Market depth / order book data."""
    symbol: str
    bid_price_depth: List[PriceLevel] = field(default_factory=list)
    ask_price_depth: List[PriceLevel] = field(default_factory=list)
    seq: int = 0
    board_id: str = "G1"
    time: int = 0
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Depth":
        """Create from API response dict."""
        bid_depth = [PriceLevel.from_dict(p) for p in data.get("bidPriceDepth", [])]
        ask_depth = [PriceLevel.from_dict(p) for p in data.get("askPriceDepth", [])]
        return cls(
            symbol=data.get("symbol", ""),
            bid_price_depth=bid_depth,
            ask_price_depth=ask_depth,
            seq=data.get("seq", 0),
            board_id=data.get("boardID", "G1"),
            time=data.get("time", 0),
        )


@dataclass
class ProductInfo:
    """Real-time product market data (prices, volumes, foreign room, etc.)."""
    symbol: str
    id: str = ""
    seq: int = 0
    time: int = 0
    board_id: str = ""
    curr_fr: float = 0
    total_fr: float = 0
    tot_buy_fr: float = 0
    tot_sell_fr: float = 0
    nomi_prc: float = 0
    ceil_prc: float = 0
    floor_prc: float = 0
    ls_prc: float = 0
    ls_vol: float = 0
    auc_est_prc: float = 0
    auc_est_vol: float = 0
    is_auction: bool = False
    open_prc: float = 0
    close_prc: float = 0
    high_prc: float = 0
    low_prc: float = 0
    vwap: float = 0
    tot_vol: float = 0
    tot_val: float = 0
    tot_vol_pt: float = 0
    tot_val_pt: float = 0
    ls_way: int = 0
    dyn_info: str = ""
    market_making_possible: str = ""
    halt: str = ""
    liquidation_trading: str = ""
    trading_session: str = ""
    board_event_id: str = ""
    session_open_close_code: str = ""
    open_interest: float = 0

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ProductInfo":
        """Create from API response dict."""
        return cls(
            symbol=data.get("symbol", ""),
            id=data.get("id", ""),
            seq=int(data.get("seq", 0)),
            time=int(data.get("time", 0)),
            board_id=data.get("boardID", ""),
            curr_fr=float(data.get("currFR", 0)),
            total_fr=float(data.get("totalFR", 0)),
            tot_buy_fr=float(data.get("totBuyFR", 0)),
            tot_sell_fr=float(data.get("totSellFR", 0)),
            nomi_prc=float(data.get("nomiPrc", 0)),
            ceil_prc=float(data.get("ceilPrc", 0)),
            floor_prc=float(data.get("floorPrc", 0)),
            ls_prc=float(data.get("lsPrc", 0)),
            ls_vol=float(data.get("lsVol", 0)),
            auc_est_prc=float(data.get("AucEstPrc", 0)),
            auc_est_vol=float(data.get("AucEstVol", 0)),
            is_auction=bool(data.get("isAuction", False)),
            open_prc=float(data.get("openPrc", 0)),
            close_prc=float(data.get("closePrc", 0)),
            high_prc=float(data.get("highPrc", 0)),
            low_prc=float(data.get("lowPrc", 0)),
            vwap=float(data.get("vWAP", 0)),
            tot_vol=float(data.get("totVol", 0)),
            tot_val=float(data.get("totVal", 0)),
            tot_vol_pt=float(data.get("totVolPT", 0)),
            tot_val_pt=float(data.get("totValPT", 0)),
            ls_way=int(data.get("lsWay", 0)),
            dyn_info=data.get("dynInfo", ""),
            market_making_possible=data.get("marketMakingPossible", ""),
            halt=data.get("halt", ""),
            liquidation_trading=data.get("liquidationTrading", ""),
            trading_session=data.get("tradingSession", ""),
            board_event_id=data.get("boardEventID", ""),
            session_open_close_code=data.get("sessionOpenCloseCode", ""),
            open_interest=float(data.get("openInterest", 0)),
        )


@dataclass
class ProductStat:
    """Static product/instrument definition (lot size, tick, name, type)."""
    symbol: str
    id: str = ""
    type: str = ""
    lot: int = 0
    min_qty: int = 0
    max_qty: int = 0
    prc_step: float = 0
    name: str = ""
    listed_share: int = 0
    point_value: float = 1.0
    time: int = 0
    dyn_info: str = ""
    # Additional properties
    transaction_code: str = ""
    sequence_number: str = ""
    business_date: str = ""
    market_id: str = ""
    board_id: str = ""
    security_exchange: str = ""
    product_group_id: str = ""
    symbol_short_code: str = ""
    security_group_id: str = ""
    trading_currency_id: str = ""
    product_id: str = ""
    ticker_code: str = ""
    symbol_name: str = ""
    symbol_abbreviation: str = ""
    symbol_english_name: str = ""
    symbol_english_abbreviation: str = ""
    listing_date: str = ""
    trading_currency_iso_code: str = ""
    price_integer_subpart_valid_cipher: str = ""
    price_decimal_subpart_valid_cipher: str = ""
    last_settlement_method_code: str = ""
    rights_type_code: str = ""
    closing_price: str = ""
    closing_price_type_code: str = ""
    first_trading_date: str = ""
    symbol_close_info_px_type: str = ""
    random_end_triggering_condition_code: str = ""
    ex_class_type: str = ""
    # Derivative Product fields (optional)
    settlement_multiplier: Optional[float] = None
    underlying_id: Optional[str] = None
    expiration_month: Optional[str] = None
    expiration_date: Optional[str] = None
    final_settlement_date: Optional[str] = None
    exercise_type_code: Optional[str] = None
    adjustment_type_code: Optional[str] = None
    underlying_symbol_code: Optional[str] = None
    remaining_days: Optional[str] = None
    settlement_price: Optional[str] = None
    atm_type_code: Optional[str] = None
    spread_composition_code: Optional[str] = None
    spread_composition_symbol_code_1: Optional[str] = None
    spread_composition_symbol_code_2: Optional[str] = None
    put_or_call: Optional[str] = None
    settlement_method: Optional[str] = None
    strike_price: Optional[float] = None
    contract_size: Optional[float] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ProductStat":
        """Create from API response dict."""
        return cls(
            symbol=data.get("symbol", ""),
            id=data.get("id", ""),
            type=data.get("type", ""),
            lot=int(data.get("lot", 0)),
            min_qty=int(data.get("minQty", 0)),
            max_qty=int(data.get("maxQty", 0)),
            prc_step=float(data.get("prcStep", 0)),
            name=data.get("name", ""),
            listed_share=int(data.get("listedShare", 0)),
            point_value=float(data.get("pointValue", 1.0)),
            time=int(data.get("time", 0)),
            dyn_info=data.get("dynInfo", ""),
            transaction_code=data.get("transactionCode", ""),
            sequence_number=data.get("sequenceNumber", ""),
            business_date=data.get("businessDate", ""),
            market_id=data.get("marketID", ""),
            board_id=data.get("boardID", ""),
            security_exchange=data.get("securityExchange", ""),
            product_group_id=data.get("productGroupID", ""),
            symbol_short_code=data.get("symbolShortCode", ""),
            security_group_id=data.get("securityGroupID", ""),
            trading_currency_id=data.get("tradingCurrencyID", ""),
            product_id=data.get("productID", ""),
            ticker_code=data.get("tickerCode", ""),
            symbol_name=data.get("symbolName", ""),
            symbol_abbreviation=data.get("symbolAbbreviation", ""),
            symbol_english_name=data.get("symbolEnglishName", ""),
            symbol_english_abbreviation=data.get("symbolEnglishAbbreviation", ""),
            listing_date=data.get("listingDate", ""),
            trading_currency_iso_code=data.get("tradingCurrencyISOCode", ""),
            price_integer_subpart_valid_cipher=data.get("priceIntegerSubpartValidCipher", ""),
            price_decimal_subpart_valid_cipher=data.get("priceDecimalSubpartValidCipher", ""),
            last_settlement_method_code=data.get("lastSettlementMethodCode", ""),
            rights_type_code=data.get("rightsTypeCode", ""),
            closing_price=data.get("closingPrice", ""),
            closing_price_type_code=data.get("closingPriceTypeCode", ""),
            first_trading_date=data.get("firstTradingDate", ""),
            symbol_close_info_px_type=data.get("symbolCloseInfoPxType", ""),
            random_end_triggering_condition_code=data.get("randomEndTriggeringConditionCode", ""),
            ex_class_type=data.get("exClassType", ""),
            # Derivative fields
            settlement_multiplier=float(data["settlementMultiplier"]) if data.get("settlementMultiplier") is not None else None,
            underlying_id=data.get("underlyingID"),
            expiration_month=data.get("expirationMonth"),
            expiration_date=data.get("expirationDate"),
            final_settlement_date=data.get("finalSettlementDate"),
            exercise_type_code=data.get("exerciseTypeCode"),
            adjustment_type_code=data.get("adjustmentTypeCode"),
            underlying_symbol_code=data.get("underlyingSymbolCode"),
            remaining_days=data.get("remainingDays"),
            settlement_price=data.get("settlementPrice"),
            atm_type_code=data.get("atmTypeCode"),
            spread_composition_code=data.get("spreadCompositionCode"),
            spread_composition_symbol_code_1=data.get("spreadCompositionSymbolCode1"),
            spread_composition_symbol_code_2=data.get("spreadCompositionSymbolCode2"),
            put_or_call=data.get("putOrCall"),
            settlement_method=data.get("settlementMethod"),
            strike_price=float(data["strikePrice"]) if data.get("strikePrice") is not None else None,
            contract_size=float(data["contractSize"]) if data.get("contractSize") is not None else None,
        )

@dataclass
class MarginRatio:
    """Margin ratio information."""
    symbol: str
    product_group: str
    margin_ratio: float
    margin_call_rate: float
    force_close_rate: float
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MarginRatio":
        """Create from API response dict."""
        return cls(
            symbol=data.get("symbol", ""),
            product_group=data.get("productGroup", ""),
            margin_ratio=float(data.get("marginRatio", 1.0)),
            margin_call_rate=float(data.get("marginCallRate", 0.0)),
            force_close_rate=float(data.get("forceCloseRate", 0.0)),
        )


@dataclass
class ProductMaster:
    """Complete product master data."""
    symbol: str
    company_name: str = ""
    industry_name: str = ""
    logo_id: str = ""
    sector_lvl1: str = ""
    sector_lvl2: str = ""
    sector_lvl3: str = ""
    info: Optional[ProductInfo] = None
    stat: Optional[ProductStat] = None
    depth: Optional[Depth] = None
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ProductMaster":
        """Create from API response dict."""
        info = ProductInfo.from_dict(data.get("info", {})) if data.get("info") else None
        stat = ProductStat.from_dict(data.get("stat", {})) if data.get("stat") else None
        depth = Depth.from_dict(data.get("depth", {})) if data.get("depth") else None
        
        return cls(
            symbol=data.get("symbol", ""),
            company_name=data.get("companyname", ""),
            industry_name=data.get("industryname", ""),
            logo_id=data.get("logoId", ""),
            sector_lvl1=data.get("sectorLvl1", ""),
            sector_lvl2=data.get("sectorLvl2", ""),
            sector_lvl3=data.get("sectorLvl3", ""),
            info=info,
            stat=stat,
            depth=depth,
        )
