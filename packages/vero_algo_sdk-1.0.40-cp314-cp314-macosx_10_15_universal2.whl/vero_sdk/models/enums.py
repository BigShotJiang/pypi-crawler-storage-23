"""
All enums for Vero Algo SDK.
"""
from enum import Enum

from ..config import TimeResolution


class OrderSide(str, Enum):
    """Order side - Buy or Sell."""
    BUY = "B"
    SELL = "S"


class OrderType(str, Enum):
    """Order types supported by the platform."""
    LIMIT = "LO"  # Limit Order
    MARKET_TO_LIMIT = "MTL"  # Market to Limit
    AT_THE_OPENING = "ATO"  # At The Opening
    AT_THE_CLOSE = "ATC"  # At The Close


class OrderStatus(str, Enum):
    """Order status values."""
    NEW = "New"
    PARTIALLY_FILLED = "PartiallyFilled"
    FILLED = "Filled"
    CANCELLED = "Cancelled"
    REJECTED = "Rejected"
    PENDING_NEW = "PendingNew"
    PENDING_CANCEL = "PendingCancel"
    EXPIRED = "Expired"


class AlgoStatus(str, Enum):
    """Execution status of the strategy."""
    IDLE = "IDLE"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    STOPPING = "STOPPING"
    STOPPED = "STOPPED"
    ERROR = "ERROR"


class RunMode(str, Enum):
    """Strategy run mode."""
    LIVE = "LIVE"
    BACKTEST = "BACKTEST"


class PositionSide(str, Enum):
    """Position side."""
    LONG = "LONG"
    SHORT = "SHORT"


class Timeframe(str, Enum):
    """Bar timeframes."""
    MINUTE_1 = "1m"
    MINUTE_5 = "5m"
    MINUTE_15 = "15m"
    MINUTE_30 = "30m"
    HOUR_1 = "1h"
    HOUR_4 = "4h"
    DAY_1 = "1d"
    
    def to_seconds(self) -> int:
        """Convert to seconds."""
        mapping = {
            "1m": TimeResolution.MINUTE_1,
            "5m": TimeResolution.MINUTE_5,
            "15m": TimeResolution.MINUTE_15,
            "30m": TimeResolution.MINUTE_30,
            "1h": TimeResolution.HOUR_1,
            "4h": TimeResolution.HOUR_4,
            "1d": TimeResolution.DAY_1,
        }
        return mapping.get(self.value, TimeResolution.DAY_1)


class DatePreset(str, Enum):
    """Quick date range presets."""
    MONTH_1 = "1M"
    MONTH_3 = "3M"
    MONTH_6 = "6M"
    YEAR_1 = "1Y"
    YTD = "YTD"
    ALL = "ALL"
