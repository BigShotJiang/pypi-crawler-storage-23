"""
Vero Core Runner.

Provides the unified entry point for running trading algorithms in either 
LIVE or BACKTEST mode, abstracting away the underlying engine details.
"""

import time
import logging
import asyncio
from typing import Callable, Optional, List, Dict, Any
from datetime import datetime, timedelta

from .client import VeroClient
from .config import VeroConfig
from .models import OrderSide, OrderType, AlgoStatus, RunMode
from .backtest.engine import BacktestEngine
from .strategy import Symbol, Bar, Position
from .utils.logging_config import setup_logging
from .utils.defaults import enum_val
from .models import StrategyInitSettings
from ._version import __version__

logger = logging.getLogger("vero")


class Vero:
    """
    Main entry point for Vero Algo SDK.
    
    Handles initialization and execution of strategies in Live or Backtest mode.
    """
    
    _instance = None
    
    def __init__(self, settings: Optional[StrategyInitSettings] = None):
        self._check_dependencies()
        
        # Load settings from env if not provided
        if settings is None:
            settings = self._load_settings_from_env()
        
        # Validate required fields
        if not settings.symbols:
            raise ValueError("symbols is required in settings")
        
        self.settings = settings
        
        # Convenience accessors
        self.mode = RunMode(settings.mode) if isinstance(settings.mode, str) else settings.mode
        self.symbol = settings.symbol  # Primary symbol (first in list)
        self.symbols = settings.symbols
        self.board = settings.board
        self.jwt_token = settings.jwt_token or ""
        self.initial_capital = settings.initial_capital
        self.timeframe = settings.timeframe
        
        # For backwards compatibility
        self.strategy_settings = settings
        
        # Set default dates if not provided (for backtest)
        if self.mode == RunMode.BACKTEST:
            if not settings.to_date:
                settings.to_date = int(datetime.now().timestamp() * 1000)
            if not settings.from_date:
                settings.from_date = int((datetime.now() - timedelta(days=365)).timestamp() * 1000)
        
        # Initialize unified client
        config = VeroConfig(debug=False, board=self.board)
        self.client = VeroClient(vero=self, config=config)
        if self.jwt_token:
            self.client.set_jwt_token(self.jwt_token)
        
        # Runtime components
        self.backtest_engine: Optional[BacktestEngine] = None
        self.api_server = None
        self._loop = None
        
        # Resolve API Port
        cfg = VeroConfig()
        self.api_port = settings.api_port if settings.api_port is not None else cfg.control_api_port
        self.settings.api_port = self.api_port
        
        setup_logging()
        # PnL State
        self.unrealized_pnl = 0.0
        self.realized_pnl = 0.0
        self.avg_entry_price = 0.0
        self.position_qty = 0
        
        # API State
        self._status = AlgoStatus.IDLE
        self._progress = 0.0
        self._stop_event = asyncio.Event()
        self._close_positions_on_stop = False
        self._latest_report = None
        
        # Callback service
        self._callback = None
        callback_url = getattr(settings, "callback_url", None)
        if callback_url:
            from .callback import CallbackService
            self._callback = CallbackService(callback_url)

    def _check_dependencies(self):
        """Check if required packages are installed."""
        required = [
            "requests",
            "websocket", # websocket-client
            "dateutil", 
            "centrifuge", # centrifuge-python
            "backtrader",
            "talipp"
        ]
        missing = []
        import importlib.util
        for pkg in required:
            import_name = pkg
            if pkg == "websocket": import_name = "websocket" 
            if pkg == "centrifuge": import_name = "centrifuge"
            
            if not importlib.util.find_spec(import_name):
                 missing.append(pkg)
        
        if missing:
             logger.warning(f"SDK dependencies missing: {', '.join(missing)}")
             print(f"WARNING: The following SDK dependencies appear to be missing: {', '.join(missing)}")
             print("Please run: pip install .")

    def _load_settings_from_env(self) -> StrategyInitSettings:
        """Load StrategyInitSettings from environment variables."""
        import os
        
        symbols_str = os.getenv("VERO_SYMBOLS", "")
        symbols = [s.strip() for s in symbols_str.split(",") if s.strip()]
        
        return StrategyInitSettings(
            symbols=symbols,
            mode=os.getenv("VERO_MODE", "BACKTEST"),
            board=os.getenv("VERO_BOARD", "G1"),
            initial_capital=float(os.getenv("VERO_INITIAL_CAPITAL", "1000000000.0")),
            timeframe=os.getenv("VERO_TIMEFRAME", "1d"),
            from_date=int(fd) if (fd := os.getenv("VERO_FROM_DATE")) else None,
            to_date=int(td) if (td := os.getenv("VERO_TO_DATE")) else None,
            account_id=os.getenv("VERO_ACCOUNT_ID"),
            api_port=int(port_str) if (port_str := os.getenv("VERO_API_PORT")) else None,
            jwt_token=os.getenv("VERO_JWT_TOKEN"),
            callback_url=os.getenv("VERO_CALLBACK_URL"),
        )

    @classmethod
    def init(cls, *args, **kwargs):
        """Global initialization."""
        return cls(*args, **kwargs)

    async def run(
        self, 
        on_candle=None, 
        on_order=None, 
        on_trade=None,
        on_market_trade=None,
        on_depth=None,
        on_progress=None,
        on_position_closed=None
    ):
        """Run the strategy asynchronously."""
        import json
        
        # Log settings
        logger.info(f"Vero SDK v{__version__} Starting with settings: {json.dumps(self.settings.to_dict(), indent=2, default=str)}")
        self._status = AlgoStatus.RUNNING
        self._progress = 0.0
        self._stop_event.clear()
        
        # Capture loop for thread-safe operations
        self._loop = asyncio.get_running_loop()
        
        # Start API Server if configured
        if self.api_port:
            from .api_server import APIServer
            self.api_server = APIServer(self, self.api_port)
            self.api_server.start()
        
        try:
            if self.mode == RunMode.LIVE:
                await self._run_live(on_candle, on_order, on_trade, on_market_trade, on_depth)
            else:
                await self._run_backtest(on_candle, on_order, on_trade, on_progress, on_position_closed)
        except Exception as e:
            self._status = AlgoStatus.ERROR
            logger.error(f"Runtime error: {e}")
            raise
        finally:
            if self._status != AlgoStatus.ERROR:
                self._status = AlgoStatus.STOPPED
            
            # Stop API Server
            if self.api_server:
                self.api_server.shutdown()

    def run_log(self, message: str):
        """Log message from runner components."""
        logger.info(message)

    async def _run_live(
        self, 
        on_candle, 
        on_order, 
        on_trade,
        on_market_trade=None,
        on_depth=None
    ):
        """Execute live trading loop."""
        if not self.jwt_token:
            raise ValueError("jwt_token required for LIVE mode")
        
        account_id = self.settings.account_id or "user"

        logger.info(f"Connected to Vero Live Server")
        
        # Connect WebSocket (only in LIVE mode)
        stream = self.client.stream
        if stream is None:
            raise RuntimeError("Streaming client is not available in the current mode")
        
        await stream.connect()
        await asyncio.sleep(2)
        
        # Account Subscriptions
        if on_order:
            await stream.subscribe_order_execution_report(account_id, on_order)
        if on_trade:
            await stream.subscribe_algo_master(account_id, on_trade)

        # Append board suffix if needed for Market Data channels
        sub_symbol = self.symbol
        if self.board and not sub_symbol.endswith(f"-{self.board}"):
            sub_symbol = f"{sub_symbol}-{self.board}"

        if on_depth:
            await stream.subscribe_depth(sub_symbol, on_depth)
        if on_market_trade:
            await stream.subscribe_market_trades(sub_symbol, on_market_trade)
               
        logger.info(f"Subscribing to {self.symbol}...")
        
        # Determine sampling requirements
        target_tf = "1m"
        tf = self.timeframe
        if str(tf).endswith("MINUTE_1") or tf == "1m": target_tf = "1m"
        elif str(tf).endswith("DAY_1") or tf == "1d": target_tf = "1d"
        else: target_tf = str(tf)
            
        NATIVE_RESOLUTIONS = {"1m": 60, "1d": 86400}
        
        if target_tf in NATIVE_RESOLUTIONS:
            if on_candle:
                await stream.subscribe_candles(
                    symbol=self.symbol,
                    resolution=NATIVE_RESOLUTIONS[target_tf],
                    callback=on_candle
                )
        else:
            logger.info(f"Timeframe {target_tf} not native. Subscribing to 1m and aggregating.")
            if on_candle:
                await stream.subscribe_candles(
                    symbol=self.symbol,
                    resolution=60, 
                    callback=on_candle
                )
        
        logger.info("Running... Press Ctrl+C to stop.")
        try:
            while not self._stop_event.is_set():
                await asyncio.sleep(1)
        except asyncio.CancelledError:
            pass
        except KeyboardInterrupt:
            logger.info("Stopping...")

    def get_status(self) -> str:
        return enum_val(self._status)

    def get_progress(self) -> float:
        return self._progress

    async def stop(self, close_positions: bool = False):
        if self._status != AlgoStatus.RUNNING:
            logger.info("Strategy is not running (already stopped or idle).")
            return

        self._status = AlgoStatus.STOPPING
        logger.info(f"Signal received to stop strategy (Close Positions: {close_positions})")
        self._close_positions_on_stop = close_positions
        self._stop_event.set()

    def get_algo_stat_report(self) -> Dict[str, Any]:
        """Get current strategy performance report."""
        if self.mode == RunMode.BACKTEST:
             # Assuming result is generated at end, checking if available
             if self._latest_report:
                 return self._latest_report.to_dict()
             return {}
            
        elif self.mode == RunMode.LIVE:
            # Construct live metrics
            total_pnl = self.realized_pnl + self.unrealized_pnl
            return {
                "status": enum_val(self._status),
                "net_profit": total_pnl,
                "realized_pnl": self.realized_pnl,
                "unrealized_pnl": self.unrealized_pnl,
                "current_position": self.position_qty,
                "avg_entry_price": self.avg_entry_price,
            }
        return {}

    def get_settings(self) -> Dict[str, Any]:
        """Get current strategy settings as dict."""
        return self.settings.to_dict()

    def update_settings(self, changes: Dict[str, Any]) -> Dict[str, Any]:
        """
        Update strategy settings at runtime.

        Applies changes to StrategyInitSettings and propagates to the
        running strategy/backtest engine so they take effect immediately.

        Args:
            changes: Dict of field_name -> new_value

        Returns:
            Dict with 'applied' changes and any 'rejected' keys
        """
        rejected = [k for k in changes if k not in self.settings.UPDATABLE_FIELDS]
        applied = self.settings.update(changes)

        # Sync convenience accessors on Vero instance
        if "timeframe" in applied:
            self.timeframe = self.settings.timeframe
        if "initial_capital" in applied:
            self.initial_capital = self.settings.initial_capital
        if "board" in applied:
            self.board = self.settings.board

        if applied:
            logger.info(f"Settings updated: {applied}")

        result: Dict[str, Any] = {"applied": applied}
        if rejected:
            result["rejected"] = rejected
        return result


    def get_orders(self, account_id: Optional[str] = None, symbol: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get orders from the running strategy.
        
        Args:
            account_id: Optional filter by account ID
            symbol: Optional filter by symbol
            
        Returns:
            List of order dictionaries
        """
        if self.mode == RunMode.LIVE and self.client:
            try:
                orders = self.client.orders.get_orders(
                    account_id=account_id,
                    symbol=symbol
                )
                return [o.to_dict() if hasattr(o, 'to_dict') else vars(o) for o in orders]
            except Exception as e:
                logger.warning(f"Failed to fetch orders: {e}")
                return []
        
        # Backtest mode - return from engine if available
        if self.backtest_engine and hasattr(self.backtest_engine, 'strategy'):
            strategy = self.backtest_engine.strategy
            if hasattr(strategy, '_context') and strategy._context:
                # Get positions (open orders/positions)
                positions = []
                for pos in strategy._context.positions.values():
                    positions.append({
                        "id": pos.id,
                        "symbol": pos.symbol,
                        "side": "B" if pos.is_long else "S",
                        "qty": pos.quantity,
                        "entry_price": pos.entry_price,
                        "status": "OPEN"
                    })
                return positions
        return []

    def get_trades(self, account_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get trades from the running strategy.
        
        Args:
            account_id: Optional filter by account ID
            
        Returns:
            List of trade dictionaries
        """
        if self.mode == RunMode.LIVE and self.client:
            try:
                trades = self.client.orders.get_trades(account_id=account_id)
                return [t.to_dict() if hasattr(t, 'to_dict') else vars(t) for t in trades]
            except Exception as e:
                logger.warning(f"Failed to fetch trades: {e}")
                return []
        
        # Backtest mode - return closed positions as trades
        if self._latest_report and hasattr(self._latest_report, 'trades'):
            trades = self._latest_report.trades
            return [
                {
                    "id": t.id if hasattr(t, 'id') else str(i),
                    "symbol": t.symbol,
                    "side": "B" if enum_val(t.side) == "long" else "S",
                    "qty": t.quantity,
                    "entry_price": t.entry_price,
                    "exit_price": t.exit_price,
                    "pnl": t.pnl,
                    "entry_time": t.entry_time,
                    "exit_time": t.exit_time,
                }
                for i, t in enumerate(trades)
            ]
        
        # Check engine's strategy context history
        if self.backtest_engine and hasattr(self.backtest_engine, 'strategy'):
            strategy = self.backtest_engine.strategy
            if hasattr(strategy, '_context') and strategy._context:
                return [
                    {
                        "id": t.id if hasattr(t, 'id') else str(i),
                        "symbol": t.symbol,
                        "side": "B" if enum_val(t.side) == "long" else "S",
                        "qty": t.quantity,
                        "entry_price": t.entry_price,
                        "exit_price": t.exit_price,
                        "pnl": t.pnl,
                        "entry_time": t.entry_time,
                        "exit_time": t.exit_time,
                    }
                    for i, t in enumerate(strategy._context.history)
                ]
        return []

    def get_logs(self, limit: int = 100) -> List[str]:
        """Get recent log entries from the log file.
        
        Args:
            limit: Maximum number of lines to return (default 100, max 1000)
            
        Returns:
            List of log lines (most recent last)
        """
        import os
        from .utils.defaults import DEFAULT_LOG_FILE
        
        limit = min(limit, 1000)  # Cap at 1000
        
        log_file = DEFAULT_LOG_FILE
        if not os.path.exists(log_file):
            return []
        
        try:
            with open(log_file, 'r', encoding='utf-8', errors='ignore') as f:
                # Read all lines and return last N
                lines = f.readlines()
                return [line.rstrip() for line in lines[-limit:]]
        except Exception as e:
            logger.warning(f"Failed to read log file: {e}")
            return []
    
    async def _run_backtest(self, on_candle, on_order, on_trade, on_progress=None, on_position_closed=None):
        """Run backtest simulation using Internal Engine."""
        logger.info("Initializing backtest...")

        # Initialize engine if not already done
        if not self.backtest_engine:
            from .strategy.base import Strategy
            from .backtest.engine import BacktestEngine
            from .config import TimeResolution
            
            # Check if on_candle is actually a Strategy instance
            if isinstance(on_candle, Strategy):
                strategy = on_candle
            else:
                # Create a wrapper strategy that delegates to callbacks
                class CallbackStrategy(Strategy):
                    def on_start(self2):
                        pass
                        
                    def on_stop(self2):
                        pass
                        
                    def on_bar(self2, bar: Bar) -> None:
                        if on_candle:
                            if asyncio.iscoroutinefunction(on_candle):
                                asyncio.ensure_future(on_candle(bar))
                            else:
                                on_candle(bar)
                    
                    def on_position_closed(self2, position) -> None:
                        if on_position_closed:
                            if asyncio.iscoroutinefunction(on_position_closed):
                                asyncio.ensure_future(on_position_closed(position))
                            else:
                                on_position_closed(position)
                strategy = CallbackStrategy()
                strategy.name = "UserStrategy"
                # Wire callback service to strategy
                if self._callback:
                    strategy._callback = self._callback
                # Wire strategy to client so place_bracket_order can find it
                self.client._strategy = strategy
            
            # Map resolution from settings.timeframe
            tf = self.settings.timeframe
            resolution = TimeResolution.DAY_1
            if isinstance(tf, str):
                if tf == "1m": resolution = TimeResolution.MINUTE_1
                elif tf == "1h": resolution = TimeResolution.HOUR_1
            
            self.backtest_engine = BacktestEngine(
                strategy=strategy,
                symbols=self.settings.symbols,
                start_date=self.settings.from_date or 0,
                end_date=self.settings.to_date or 0,
                initial_capital=self.settings.initial_capital,
                resolution=resolution,
                jwt_token=self.jwt_token,
                account_id=self.settings.account_id or "user@local"
            )
            
        logger.info("Running backtest simulation...")
        
        def internal_progress(p):
            self._progress = p
            if on_progress:
                on_progress(p)
                
        result = await self.backtest_engine.run(on_progress=internal_progress)
        self._latest_report = result
        
        # Fire report callback via Vero's own callback service
        if self._callback:
            from .callback import CallbackEventType
            self._callback.send_event(
                CallbackEventType.REPORT,
                data=result.to_dict(),
                strategy_name="UserStrategy",
            )
            self._callback.flush()
        
        # Display results
        result.print_report()
        
        # Keep alive for API retrieval - wait for stop signal
        if self.api_port:
            self._status = AlgoStatus.COMPLETED
            logger.info("Backtest complete. Waiting for API stop signal...")
            while not self._stop_event.is_set():
                await asyncio.sleep(1)
