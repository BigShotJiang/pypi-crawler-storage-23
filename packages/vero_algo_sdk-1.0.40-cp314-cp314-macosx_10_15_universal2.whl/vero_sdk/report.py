"""
Performance report logic for Vero Algo SDK.

Shared by both backtest and live modes.
Provides print_report display and build_report factory function.
"""

from typing import List
from datetime import datetime

from .models import StrategyMetrics, PerformanceReport
from .metrics import calculate_monthly_returns


def print_report(report: PerformanceReport) -> None:
    """Print formatted report to console."""

    def fmt_pct(val: float, width: int = 7) -> str:
        abs_val = abs(val)
        if abs_val == 0:
            fmt = f"{val:>{width}.2f}%"
        elif abs_val >= 0.01:
            fmt = f"{val:>{width}.2f}%"
        elif abs_val >= 0.0001:
            fmt = f"{val:>{width}.4f}%"
        else:
            fmt = f"{val:>{width}.6f}%"
        return fmt

    print("\n" + "=" * 80)
    print(f"STRATEGY PERFORMANCE REPORT")
    print(f"{report.strategy_name}")
    print(f"Backtest Period: {report.backtest_period}")
    print("=" * 80)

    print("\n┌─────────────────────────────────────────────────────────────────────────────┐")
    print("│                              SUMMARY                                        │")
    print("├─────────────────────────────────────────────────────────────────────────────┤")
    m = report.metrics

    pct_color = "\033[32m" if m.net_profit >= 0 else "\033[31m"
    reset = "\033[0m"

    print(f"│  NET PROFIT:     {pct_color}{m.net_profit:>12,.2f}{reset}  │  WIN RATE:       {m.win_rate:>8.1f}%       │")
    print(f"│  TOTAL TRADES:   {m.total_trades:>12}  │  PROFIT FACTOR:  {m.profit_factor:>8.2f}        │")
    print(f"│  WINNING:        {m.winning_trades:>12}  │  MAX DRAWDOWN:   {fmt_pct(m.max_drawdown_pct)}        │")
    print(f"│  LOSING:         {m.losing_trades:>12}  │  SHARPE RATIO:   {m.sharpe_ratio:>8.2f}        │")
    print("└─────────────────────────────────────────────────────────────────────────────┘")

    print("\n┌─────────────────────────────────────────────────────────────────────────────┐")
    print("│  PERFORMANCE             │  TRADE STATISTICS        │  RISK METRICS        │")
    print("├──────────────────────────┼──────────────────────────┼──────────────────────┤")
    print(f"│  Total Return:  {fmt_pct(m.total_return)} │  Avg Win:     {m.avg_win:>10.2f} │  Sharpe:      {m.sharpe_ratio:>5.2f} │")
    print(f"│  Annual Return: {fmt_pct(m.annualized_return)} │  Avg Loss:    {m.avg_loss:>10.2f} │  Sortino:     {m.sortino_ratio:>5.2f} │")
    print(f"│  Monthly Return:{fmt_pct(m.monthly_return)} │  Largest Win: {m.largest_win:>10.2f} │  Calmar:      {m.calmar_ratio:>5.2f} │")
    print(f"│  Volatility:    {fmt_pct(m.volatility)} │  Largest Loss:{m.largest_loss:>10.2f} │  VaR (95%):  {fmt_pct(m.value_at_risk, 5)} │")
    print(f"│  Alpha:         {m.alpha:>7.2f}  │  Avg Trade:   {m.avg_trade:>10.2f} │  Recovery:    {m.recovery_factor:>5.2f} │")
    print(f"│  Beta:          {m.beta:>7.2f}  │  Expectancy:  {m.expectancy:>10.2f} │  Max DD Days:{m.max_drawdown_duration_days:>6} │")
    print("└──────────────────────────┴──────────────────────────┴──────────────────────┘")

    print(f"\n│  STREAKS: Max Consecutive Wins: {m.max_consecutive_wins}  │  Max Consecutive Losses: {m.max_consecutive_losses}")
    print(f"│  Gross Profit: {m.gross_profit:,.2f}  │  Gross Loss: {m.gross_loss:,.2f}")
    print(f"│  Current NAV: {m.current_nav:>12,.2f}")

    if report.monthly_returns:
        print("\n┌─────────────────────────────────────────────────────────────────────────────┐")
        print("│                           MONTHLY RETURNS                                    │")
        print("├─────────────────────────────────────────────────────────────────────────────┤")

        months_display = []
        for month, ret in sorted(report.monthly_returns.items()):
            color = "\033[32m" if ret >= 0 else "\033[31m"
            abs_ret = abs(ret)
            if abs_ret >= 0.01:
                ret_str = f"{ret:>+5.1f}%"
            elif abs_ret >= 0.0001:
                ret_str = f"{ret:>+8.4f}%"
            else:
                ret_str = f"{ret:>+5.1f}%"
            months_display.append(f"{month[-2:]}: {color}{ret_str}{reset}")

        for i in range(0, len(months_display), 6):
            row = months_display[i:i+6]
            print("│  " + "  │  ".join(row))

        print("└─────────────────────────────────────────────────────────────────────────────┘")

    print("\n" + "=" * 80)


def build_report(
    strategy_name: str,
    start_date: int,
    end_date: int,
    metrics: StrategyMetrics,
    equity_curve: List[float],
    equity_dates: List[int],
) -> PerformanceReport:
    """Create a PerformanceReport from backtest results."""
    _start_dt = datetime.utcfromtimestamp(start_date / 1000)
    _end_dt = datetime.utcfromtimestamp(end_date / 1000)
    report = PerformanceReport(
        strategy_name=strategy_name,
        backtest_period=f"{_start_dt.strftime('%b %d, %Y')} - {_end_dt.strftime('%b %d, %Y')}",
        metrics=metrics,
        equity_curve=equity_curve,
        equity_dates=equity_dates,
    )
    report.monthly_returns = calculate_monthly_returns(equity_curve, equity_dates)
    return report
