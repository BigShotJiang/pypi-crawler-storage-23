"""
Tests pour le package MCP Server Grist.
"""