#!/usr/bin/env python3
"""
Script de configuration pour le package nic01asFr-mcp-server-grist.
Ce fichier est maintenu pour la compatibilité avec les anciens outils de packaging.
La configuration principale se trouve dans pyproject.toml.
"""

from setuptools import setup

# Redirection vers pyproject.toml
setup()
