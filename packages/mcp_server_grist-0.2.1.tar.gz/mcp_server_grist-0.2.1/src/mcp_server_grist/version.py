"""
Gestion de version pour MCP Server Grist.
"""

__version__ = "0.2.1"
