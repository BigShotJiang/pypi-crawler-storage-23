NAME = "Oasys \u23F5 ELETTRA Extension"

DESCRIPTION = "Elettra widgets for Oasys"

BACKGROUND = "#FC9F3B"

ICON = "icons/elettra.png"

PRIORITY = 1.99999