NAME = "SRW \u23F5 ELETTRA Extension"

DESCRIPTION = "Elettra widgets for SRW"

BACKGROUND = "#adb0cc"

ICON = "icons/elettra.png"

PRIORITY = 6.99999