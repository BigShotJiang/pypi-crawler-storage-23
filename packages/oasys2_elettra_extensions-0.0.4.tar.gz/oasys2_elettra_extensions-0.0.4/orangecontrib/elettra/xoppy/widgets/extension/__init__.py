NAME = "XOPPY \u23F5 ELETTRA Extension"

DESCRIPTION = "Elettra widgets for XOPPY"

BACKGROUND = "#FFD39F"

ICON = "icons/elettra.png"

PRIORITY = 3.99999