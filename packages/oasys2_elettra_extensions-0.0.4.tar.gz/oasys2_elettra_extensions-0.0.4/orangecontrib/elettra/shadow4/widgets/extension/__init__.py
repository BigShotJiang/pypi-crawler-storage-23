NAME = "Shadow4 \u23F5 ELETTRA Extension"

DESCRIPTION = "Elettra widgets for Shadow4"

BACKGROUND = "#a6be6d"

ICON = "icons/elettra.png"

PRIORITY = 4.99999