NAME = "Syned \u23F5 ELETTRA Extension"

DESCRIPTION = "Elettra widgets for Syned"

BACKGROUND = "#ECCFAF"

ICON = "icons/elettra.png"

PRIORITY = 2.99999