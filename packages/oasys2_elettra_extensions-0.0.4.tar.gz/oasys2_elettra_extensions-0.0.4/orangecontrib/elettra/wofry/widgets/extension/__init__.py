NAME = "Wofry \u23F5 ELETTRA Extension"

DESCRIPTION = "Elettra widgets for Wofry"

BACKGROUND =  "#E6E6E6"

ICON = "icons/elettra.png"

PRIORITY = 5.99999