import json
from dataclasses import dataclass
from typing import Any, Dict


@dataclass
class ModelHub:
    def __init__(self):
        pass

