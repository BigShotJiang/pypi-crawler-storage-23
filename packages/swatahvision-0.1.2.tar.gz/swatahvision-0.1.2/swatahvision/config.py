APP_NAME = "swatah"
APP_AUTHOR = "swatah.ai"

APP_VERSION = "0.1.0"
CACHE_SUBDIR = "cache"

CLASS_NAME_DATA_FIELD = "class_name"
ORIENTED_BOX_COORDINATES = "xyxyxyxy"