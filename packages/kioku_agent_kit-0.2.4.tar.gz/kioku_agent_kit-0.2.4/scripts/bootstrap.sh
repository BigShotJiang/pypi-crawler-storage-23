#!/usr/bin/env bash
# bootstrap.sh — One-liner to initialize Kioku in any project for Claude Code
# Usage: curl -fsSL https://raw.githubusercontent.com/phuc-nt/kioku-agent-kit/main/scripts/bootstrap.sh | bash

set -euo pipefail

echo "🧠 Bootstrapping Kioku Agent Kit for this project..."

# 1. Download CLAUDE.md
echo "  Downloading CLAUDE.md..."
curl -sL https://raw.githubusercontent.com/phuc-nt/kioku-agent-kit/main/src/kioku/resources/CLAUDE.agent.md -o CLAUDE.md

# 2. Download SKILL.md
echo "  Downloading Kioku SKILL..."
mkdir -p .claude/skills/kioku
curl -sL https://raw.githubusercontent.com/phuc-nt/kioku-agent-kit/main/src/kioku/resources/SKILL.md -o .claude/skills/kioku/SKILL.md

echo ""
echo "✅ Bootstrap complete!"
echo "Now simply start Claude Code in this directory:"
echo "    claude"
echo ""
echo "Claude will read CLAUDE.md, realize it needs Kioku, and self-install automatically!"
