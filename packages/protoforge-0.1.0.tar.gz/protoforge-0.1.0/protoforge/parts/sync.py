import subprocess
import shutil
from pathlib import Path
from protoforge.utils.rich_utils import console

DEFAULT_COMMUNITY_REPO = "https://github.com/protoforge/community-parts.git"

def sync_community_parts(repo_url: str = DEFAULT_COMMUNITY_REPO):
    """Sync the community parts library via Git."""
    if not shutil.which("git"):
        console.print("[error]Git not found. Cannot sync community parts.[/error]")
        return

    local_path = Path.home() / ".protoforge" / "community"
    
    if local_path.exists():
        console.print("[info]Updating community parts...[/info]")
        subprocess.run(["git", "pull"], cwd=local_path, capture_output=True)
    else:
        console.print("[info]Cloning community parts library...[/info]")
        local_path.parent.mkdir(parents=True, exist_ok=True)
        subprocess.run(["git", "clone", repo_url, str(local_path)], capture_output=True)
    
    console.print("[success]Community parts synchronized.[/success]")
