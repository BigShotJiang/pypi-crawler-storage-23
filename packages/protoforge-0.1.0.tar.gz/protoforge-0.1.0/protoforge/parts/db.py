from sqlmodel import Session, select
from protoforge.parts.models import Part, get_engine, init_db
from protoforge.config import get_config

def get_session():
    config = get_config()
    db_path = str(config.db_path)
    init_db(db_path) # Ensure tables are created
    engine = get_engine(db_path)
    return Session(engine)

def save_part(part: Part):
    with get_session() as session:
        session.add(part)
        session.commit()
        session.refresh(part)
        return part

def find_part(name: str):
    with get_session() as session:
        statement = select(Part).where(Part.name == name)
        return session.exec(statement).first()

def list_parts(category: str | None = None):
    with get_session() as session:
        statement = select(Part)
        if category:
            statement = statement.where(Part.category == category)
        return session.exec(statement).all()
