from typing import Dict, Any, Optional
from sqlmodel import SQLModel, Field, create_engine, Session, select
from datetime import datetime

class Part(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(index=True, unique=True)
    category: str = Field(index=True)
    description: str
    
    # Parametric data stored as JSON-like dict/string
    # In a real app we might use a separate table, but for MVP this is fine
    parametric_code: str  # CadQuery/OpenSCAD code
    physics_params: str   # Modelica parameters (JSON)
    
    datasheet_summary: str
    created_at: datetime = Field(default_factory=datetime.now)

def get_engine(db_path: str):
    return create_engine(f"sqlite:///{db_path}")

def init_db(db_path: str):
    engine = get_engine(db_path)
    SQLModel.metadata.create_all(engine)
