import json
from protoforge.ai.assistant import ProtoAssistant
from protoforge.parts.models import Part
from protoforge.parts.db import save_part, init_db
from protoforge.config import get_config

def invent_part(description: str) -> Part:
    config = get_config()
    
    assistant = ProtoAssistant(config.ai)
    prompt = assistant.invent_part_prompt(description)
    
    response = assistant.chat([{"role": "user", "content": prompt}], json_mode=True)
    data = json.loads(response.content)
    
    part = Part(
        name=data["name"],
        category=data["category"],
        description=data["description"],
        parametric_code=data["parametric_code"],
        physics_params=data["physics_params"],
        datasheet_summary=data["datasheet_summary"]
    )
    
    return save_part(part)
