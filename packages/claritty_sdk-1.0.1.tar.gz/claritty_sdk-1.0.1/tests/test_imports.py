"""
Test that all SDK modules can be imported correctly.
"""
import pytest


def test_import_agent():
    """Test that agent decorator can be imported."""
    from clarity_sdk import agent, BaseAgent, AgentResult, AgentContext
    assert agent is not None
    assert BaseAgent is not None
    assert AgentResult is not None
    assert AgentContext is not None


def test_import_workflow():
    """Test that workflow decorators can be imported."""
    from clarity_sdk import workflow, uses_agent, ExecutionMode
    assert workflow is not None
    assert uses_agent is not None
    assert ExecutionMode is not None


def test_import_trigger():
    """Test that trigger decorators can be imported."""
    from clarity_sdk import trigger_template, TriggerTemplateType
    assert trigger_template is not None
    assert TriggerTemplateType is not None


def test_import_models():
    """Test that core models can be imported."""
    from clarity_sdk.models import AgentMetadata, WorkflowMetadata, TriggerTemplate
    assert AgentMetadata is not None
    assert WorkflowMetadata is not None
    assert TriggerTemplate is not None


def test_import_executor():
    """Test that executor can be imported."""
    from clarity_sdk.executor import WorkflowExecutor
    assert WorkflowExecutor is not None


def test_import_trigger_manager():
    """Test that trigger manager can be imported."""
    from clarity_sdk.trigger_manager import DynamicTriggerManager
    assert DynamicTriggerManager is not None


def test_sdk_version():
    """Test that SDK has version attribute."""
    import clarity_sdk
    assert hasattr(clarity_sdk, '__version__')
    assert clarity_sdk.__version__ == '1.0.0'
