"""Coverage tracking: phoneme, diphone, triphone coverage state and metrics."""
