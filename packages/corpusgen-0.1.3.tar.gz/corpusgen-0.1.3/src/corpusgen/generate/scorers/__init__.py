"""Built-in scorers for Phon-CTG generation quality evaluation."""
