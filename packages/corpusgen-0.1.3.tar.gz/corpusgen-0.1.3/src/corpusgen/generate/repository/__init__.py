"""Repository-based generation: select from curated sentence banks."""
