"""Corpus generation strategies: repository, LLM API, and local model."""
