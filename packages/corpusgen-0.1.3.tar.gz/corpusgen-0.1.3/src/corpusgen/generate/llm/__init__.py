"""LLM API-based generation: prompt external models for targeted sentences."""
