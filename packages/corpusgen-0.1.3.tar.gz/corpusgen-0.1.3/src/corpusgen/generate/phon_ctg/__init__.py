"""Phon-CTG: Phonotactically-Controlled Text Generation framework core."""
