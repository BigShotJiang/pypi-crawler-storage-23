"""Bundled data: minimal phoneme inventories and test data for offline use."""
