from page_scraper.entities.models import PageContext
from page_scraper.links.utils import get_nav_links, prepare_links
from page_scraper.core.utils import canonical_domain


class GetNavLinks:

    def run(self, page:PageContext) -> PageContext:
        soup = page.soup
        navigations = get_nav_links(soup)
        domain = canonical_domain(page.url)
        result = prepare_links(domain, navigations,"navigation")
        page.links.extend(result)
        return page
