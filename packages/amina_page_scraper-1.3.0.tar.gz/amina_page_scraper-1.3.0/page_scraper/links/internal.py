import copy

from page_scraper.entities.models import PageContext
from page_scraper.infrastructure.fetcher import HttpFetcher
from page_scraper.links.utils import get_clean_link, prepare_links
from page_scraper.core.utils import canonical_domain


class InternalScraper:
    def run(self,page:PageContext) -> PageContext:
        soup_copy = copy.copy(page.soup)
        clean_links = get_clean_link(soup_copy)

        domain = canonical_domain(page.url)
        result = prepare_links(domain, clean_links,"internal")
        page.links.extend(result)

        return page

