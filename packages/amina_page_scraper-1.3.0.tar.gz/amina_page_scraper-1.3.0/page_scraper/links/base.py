from typing import Protocol
from page_scraper.entities.models import PageContext
from page_scraper.infrastructure.fetcher import HttpFetcher


class ScraperStep(Protocol):
    def run(self, page: PageContext) -> PageContext:
        ...