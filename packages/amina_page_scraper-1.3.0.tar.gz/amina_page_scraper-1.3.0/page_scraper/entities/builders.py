from requests.structures import CaseInsensitiveDict

from page_scraper.entities.models import Entity, PageContext, ResponseMeta, PageMetaContext


def build_entity(node: dict, entity_type: str) -> Entity:
    return Entity(
        id=node.get("@id") or node.get("url"),
        type=entity_type,
        name=node.get("name"),
        alternate_name=node.get("alternateName"),
        url=node.get("url"),
        description=node.get("description"),
        raw=node,
        date_published=node.get("datePublished"),
        date_modified=node.get("dateModified"),
    )

def build_response_meta(meta:CaseInsensitiveDict) -> ResponseMeta:
    return ResponseMeta(
        content_length= meta.get("content-length"),
        content_encoding= meta.get("content-encoding"),
        cache_control= meta.get("cache-control"),
        last_modified= meta.get("last-modified"),
        etag= meta.get("etag"),
        server= meta.get("server"),
    )

def build_page_context(parsed_page:dict) -> PageContext:
    return PageContext(**parsed_page)

def build_page_meta(name, meta_type, value):
    return PageMetaContext(
        name=name,
        meta_type=meta_type,
        value=value,
    )

