# def resolve_author(article_node: dict, entities: dict):
#     author = article_node.get("author")
#
#     if isinstance(author, dict) and "@id" in author:
#         return entities.get(author["@id"])
#
#     if isinstance(author, dict):
#         return author
#
#     return None

def resolve_author(article_node: dict, entities_by_id: dict[str, dict]) -> dict | None:
    author = article_node.get("author")
    if not author:
        return None

    # Case 1 — author is a reference by @id
    if isinstance(author, dict) and "@id" in author:
        resolved = entities_by_id.get(author["@id"])
        if resolved:
            return resolved

        # Fallback: return minimal author info if Person not found
        return {
            "@type": "Person",
            "@id": author["@id"],
            "name": author.get("name"),
            "url": author.get("url"),
        }

    # Case 2 — author is inline object
    if isinstance(author, dict):
        return author

    # Case 3 — author is a string (sometimes happens)
    if isinstance(author, str):
        return {
            "@type": "Person",
            "name": author
        }

    # Case 4 - author is list
    if isinstance(author, list):
        return {
            "@type": "Person",
            "name": author[0].get("name"),
            "url": author[0].get("url"),
        }

    return None
