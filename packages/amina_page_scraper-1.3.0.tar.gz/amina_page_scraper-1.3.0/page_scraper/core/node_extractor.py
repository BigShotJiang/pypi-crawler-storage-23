def extract_nodes(data, parent=None, path=()):
    nodes = []

    if isinstance(data, list):
        for i, item in enumerate(data):
            nodes.extend(extract_nodes(item, parent, path + (i,)))

    elif isinstance(data, dict):
        if "@type" in data:
            nodes.append({
                "node": data,
                "parent": parent,
                "path": path
            })

        for key, value in data.items():
            nodes.extend(extract_nodes(value, data, path + (key,)))

    return nodes