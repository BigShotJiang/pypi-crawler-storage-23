import copy

from page_scraper.entities.models import PageContext
from page_scraper.content.utils import get_clean_tags,process_headings


class HeadingScraper:
    def run(self,page:PageContext) -> PageContext:
        soup_copy = copy.copy(page.soup)

        headings = get_clean_tags(soup_copy,"h1,h2,h3,h4,h5,h6")
        page.headings = process_headings(headings)
        return page