import copy

from page_scraper.content.utils import get_clean_tags, process_media_tags, process_video_iframe, process_video_embed
from page_scraper.core.utils import canonical_domain
from page_scraper.entities.models import PageContext



class VideoTagScraper:
    def run(self,page:PageContext) -> PageContext:
        soup_copy = copy.copy(page.soup)

        clean = get_clean_tags(soup_copy,'video')
        domain = canonical_domain(page.url)
        videos = process_media_tags(clean,domain,'VIDEO_TAG')

        page.links.extend(videos)

        page.videos_count += len(videos)

        return page

class VideoIframeScraper:
    def run(self,page:PageContext) -> PageContext:
        soup_copy = copy.copy(page.soup)

        clean = get_clean_tags(soup_copy,'iframe')
        domain = canonical_domain(page.url)

        videos = process_video_iframe(clean,domain)

        page.videos_count += len(videos)

        return page

class VideoEmbedScraper:
    def run(self,page:PageContext) -> PageContext:
        soup_copy = copy.copy(page.soup)

        clean = get_clean_tags(soup_copy,'embed,object')
        domain = canonical_domain(page.url)
        videos = process_video_embed(clean,domain)

        page.links.extend(videos)

        page.videos_count += len(videos)

        return page

