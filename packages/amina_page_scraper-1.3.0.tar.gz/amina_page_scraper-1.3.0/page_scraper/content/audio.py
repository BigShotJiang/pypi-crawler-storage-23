import copy

from page_scraper.content.utils import get_clean_tags, process_media_tags
from page_scraper.core.utils import canonical_domain
from page_scraper.entities.models import PageContext


class AudioTagScraper:
    def run(self,page:PageContext) -> PageContext:
        soup_copy = copy.copy(page.soup)

        clean = get_clean_tags(soup_copy,'audio')
        domain = canonical_domain(page.url)
        audio = process_media_tags(clean,domain,'AUDIO_TAG')

        page.links.extend(audio)

        page.audio_count += len(audio)

        return page