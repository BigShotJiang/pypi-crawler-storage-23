import copy

from page_scraper.content.utils import get_clean_tags, process_image
from page_scraper.core.utils import canonical_domain
from page_scraper.entities.models import PageContext


class ImageScraper:
    def run(self,page:PageContext) -> PageContext:
        soup_copy = copy.copy(page.soup)

        clean = get_clean_tags(soup_copy,'img')
        domain = canonical_domain(page.url)
        images = process_image(clean,domain)

        page.links.extend(images)

        page.images_count = len(images)

        return page