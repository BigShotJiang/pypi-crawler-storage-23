from traceback import print_tb

import requests
from requests.exceptions import SSLError, ConnectionError, Timeout

class HttpFetcher:
    def __init__(self, user_agent: str | None = None, timeout: int = 20):
        self.session = requests.Session()
        self.timeout = timeout

        self.default_headers = {
            "User-Agent": user_agent or "Mozilla/5.0 (Linux; Android 15; SM-S931B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.7559.96 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        }

    def get(self, url: str):
        try:
            response = self.session.get(
                url,
                headers=self.default_headers,
                timeout=self.timeout,
            )
            return response

        except SSLError:
            # retry without SSL verification
            response = self.session.get(
                url,
                headers=self.default_headers,
                timeout=self.timeout,
                verify=False,
            )
            return response

        except Timeout:
            return None  # or raise custom TimeoutError

        except ConnectionError:
            return None

    def head(self, url: str, allow_redirects=False):
        try:
            response = self.session.head(
                url,
                headers=self.default_headers,
                allow_redirects=allow_redirects,
                timeout=self.timeout,
            )
            return response

        except SSLError:
            # retry without SSL verification
            response = self.session.head(
                url,
                headers=self.default_headers,
                timeout=self.timeout,
                allow_redirects=allow_redirects,
                verify=False,
            )
            return response

        except Timeout:
            return None  # or raise custom TimeoutError

        except ConnectionError:
            return None
