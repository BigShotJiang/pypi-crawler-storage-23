from page_scraper.core.node_utils import has_type
from page_scraper.entities.models import Entity, PageContext
from page_scraper.entities.builders import build_entity

class ServiceDetector:
    def detect(self, page: PageContext) -> list[Entity]:
        services = []
        for entry  in page.nodes:
            node = entry['node']

            if not has_type(node,"Service"):
                continue
            services.append(build_entity(node, "Service"))

        return services