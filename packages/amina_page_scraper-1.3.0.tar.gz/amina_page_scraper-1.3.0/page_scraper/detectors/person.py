from page_scraper.core.node_utils import has_type, path_contains, has_attrs
from page_scraper.entities.models import Entity, PageContext
from page_scraper.entities.builders import build_entity

class PersonDetector:
    def detect(self, page: PageContext) -> list[Entity]:
        persons = []
        seen = set()

        for entry  in page.nodes:
            node = entry['node']
            path = entry['path']

            if not has_type(node, "Person"):
                continue

            if path_contains(path, "Review", "review", "aggregateRating", "offers", "reviewRating", "Person", "person"):
                continue

            if not has_attrs(node,"url","@id","name"):
                continue

            entity = build_entity(node, "Person")

            key = (entity.url, (entity.name or "").lower())

            if key in seen:
                continue

            seen.add(key)
            persons.append(entity)

        return persons