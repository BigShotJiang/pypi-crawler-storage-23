from page_scraper.core.node_utils import has_type, has_attrs
from page_scraper.entities.models import Entity, PageContext
from page_scraper.entities.builders import build_entity

class DomainDetector:
    def detect(self, page: PageContext) -> list[Entity]:
        domains = []
        seen = set()

        for entry  in page.nodes:
            node = entry['node']

            if not has_type(node, "WebSite"):
                continue

            if not has_attrs(node,"url","@id","name"):
                continue

            entity = build_entity(node, "Website")

            key = (entity.url, (entity.name or "").lower())

            if key in seen:
                continue

            seen.add(key)
            domains.append(entity)

        return domains