from page_scraper.core.node_utils import has_type
from page_scraper.entities.models import Entity, PageContext
from page_scraper.entities.builders import build_entity

class ProductDetector:
    def detect(self, page: PageContext) -> list[Entity]:
        products = []
        seen = set()

        for entry in page.nodes:
            node = entry['node']

            if not has_type(node, "Product"):
                continue

            entity = build_entity(node, "Product")

            key = (entity.url, (entity.name or "").lower())

            if key in seen:
                continue

            seen.add(key)

            products.append(entity)

        return products