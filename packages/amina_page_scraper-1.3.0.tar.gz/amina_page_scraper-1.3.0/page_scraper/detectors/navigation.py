from page_scraper.core.node_utils import has_type, has_attrs
from page_scraper.entities.models import Entity, PageContext
from page_scraper.entities.builders import build_entity

class NavDetector:
    def detect(self, page: PageContext) -> list[Entity]:
        nav = []
        seen = set()

        for entry  in page.nodes:
            node = entry['node']


            if not has_type(node, "SiteNavigationElement"):
                continue

            if not has_attrs(node,"url"):
                continue

            entity = build_entity(node, "Navigation")

            key = (entity.url, (entity.name or "").lower())

            if key in seen:
                continue

            seen.add(key)
            nav.append(entity)

        return nav