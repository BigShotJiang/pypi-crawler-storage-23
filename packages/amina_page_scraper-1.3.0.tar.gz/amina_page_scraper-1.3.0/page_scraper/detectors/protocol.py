from typing import Protocol
from page_scraper.entities.models import Entity
from page_scraper.entities.models import PageContext


class EntityDetector(Protocol):
    def detect(self, page) -> list[Entity]:
        ...

class PageStep(Protocol):
    def run(self,page: "PageContext") -> PageContext:
        ...