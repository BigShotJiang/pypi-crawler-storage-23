from page_scraper.core.node_utils import has_type, has_types
from page_scraper.entities.models import Entity, PageContext
from page_scraper.entities.builders import build_entity


class ArticleDetector:
    ARTICLE_TYPES = (
        "Article",
        "NewsArticle",
        "TechArticle",
        "ScholarlyArticle",
        "BlogPosting",
        "Report",
        "Blog"
    )

    def detect(self, page: PageContext) -> list[Entity]:
        articles = []
        for entry in page.nodes:
            node = entry['node']
            if has_types(node,*self.ARTICLE_TYPES) or (not articles and has_type(node, "WebPage") and node.get("url")):
                articles.append(build_entity(node, "Article"))

        return articles