from page_scraper.core.node_utils import has_type, has_attrs
from page_scraper.entities.models import Entity, PageContext
from page_scraper.entities.builders import build_entity

class OrgDetector:
    def detect(self, page: PageContext) -> list[Entity]:
        orgs = []
        seen = set()

        for entry  in page.nodes:
            node = entry['node']


            if not has_type(node, "Organization"):
                continue

            if not has_attrs(node,"url","@id","name"):
                continue

            entity = build_entity(node, "Organization")

            key = (entity.url, (entity.name or "").lower())

            if key in seen:
                continue

            seen.add(key)
            orgs.append(entity)

        return orgs