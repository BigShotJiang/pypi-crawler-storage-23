from page_scraper.core.node_utils import has_type
from page_scraper.entities.models import Entity, PageContext
from page_scraper.entities.builders import build_entity

class ContactPageDetector:
    def detect(self, page: PageContext) -> list[Entity]:
        contacts = []
        for entry  in page.nodes:
            node = entry['node']

            if not has_type(node, "ContactPage") and not has_type(node, "AboutPage"):
                continue

            contacts.append(build_entity(node, "Contact"))

        return contacts