from typing import Protocol
from page_scraper.entities.models import PageContext


class MetaStep(Protocol):
    def run(self, page: PageContext) -> PageContext:
        ...