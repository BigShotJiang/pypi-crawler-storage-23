import copy

from page_scraper.entities.models import PageContext
from page_scraper.meta.utils import process_title_tag, process_description_tag


class TitleScraper:
    def run(self,page:PageContext) -> PageContext:
        soup_copy = copy.copy(page.soup)

        title = process_title_tag(soup_copy)
        if title:
            page.meta_title = title
            page.is_title = True

        return page

class DescriptionScraper:
    def run(self,page:PageContext) -> PageContext:
        soup_copy = copy.copy(page.soup)

        description = process_description_tag(soup_copy)
        if description:
            page.meta_description = description
            page.is_description = True

        return page