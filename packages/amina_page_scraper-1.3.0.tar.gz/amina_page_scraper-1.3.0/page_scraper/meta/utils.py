from bs4 import Tag, BeautifulSoup

from page_scraper.core.utils import clear_text


def get_meta_by_name(soup:BeautifulSoup, name:str):
    return soup.find_all('meta', attrs={'name': name})

def process_meta_text(tag:Tag):
    content = tag.get('content')
    if not content:
        return None
    return content.strip().replace("\n", " ")

def process_title_tag(soup:BeautifulSoup) -> str | None:
    title = soup.find('title')
    # print(soup.select('title'),title)

    if not title:
        return None
    return clear_text(title.get_text())

def process_description_tag(soup:BeautifulSoup) -> str | None:
    description = soup.find('meta', attrs={'name': 'description'})
    if not description:
        return None
    return process_meta_text(description)

def process_property_tags(soup:BeautifulSoup, property_name:str) -> str | None:
    tag = soup.find('meta', attrs={'property': property_name})
    if not tag:
        return None
    return process_meta_text(tag)