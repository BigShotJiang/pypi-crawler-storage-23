import copy

from page_scraper.entities.builders import build_page_meta
from page_scraper.entities.models import PageContext
from page_scraper.meta.utils import process_property_tags


class OgTitleScraper:
    def run(self, page: PageContext) -> PageContext:
        soup_copy = copy.copy(page.soup)

        title = process_property_tags(soup_copy, 'og:title')
        if title and not page.meta_title:
            page.meta_title = title

        return page


class OgDescriptionScraper:
    def run(self, page: PageContext) -> PageContext:
        soup_copy = copy.copy(page.soup)

        description = process_property_tags(soup_copy, 'og:description')
        if description and not page.meta_description:
            page.meta_description = description

        return page

class OgTypeScraper:
    def run(self, page: PageContext) -> PageContext:
        soup_copy = copy.copy(page.soup)

        page_type = process_property_tags(soup_copy, 'og:type')
        if page_type:
            meta_context = build_page_meta('social','type', page_type)
            page.page_metas.append(meta_context)

        return page

class OgSiteNameScraper:
    def run(self, page: PageContext) -> PageContext:
        soup_copy = copy.copy(page.soup)

        page_type = process_property_tags(soup_copy, 'og:site_name')
        if page_type:
            meta_context = build_page_meta('social','site_name', page_type)
            page.page_metas.append(meta_context)

        return page

class ModifiedTimeScraper:
    def run(self, page: PageContext) -> PageContext:
        soup_copy = copy.copy(page.soup)

        modified_time = process_property_tags(soup_copy, 'article:modified_time')
        if modified_time:
            page.modified_time = modified_time

        return page