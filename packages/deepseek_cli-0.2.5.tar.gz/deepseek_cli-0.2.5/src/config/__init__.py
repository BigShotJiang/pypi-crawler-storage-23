"""Configuration package for DeepSeek"""
