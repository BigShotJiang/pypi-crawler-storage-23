"""Chou GUI Module - PySide6 Interface"""

from .main import main

__all__ = ["main"]
