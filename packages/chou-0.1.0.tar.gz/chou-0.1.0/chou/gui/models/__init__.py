"""Chou GUI Data Models"""

from .paper_model import PaperTableModel

__all__ = ["PaperTableModel"]
