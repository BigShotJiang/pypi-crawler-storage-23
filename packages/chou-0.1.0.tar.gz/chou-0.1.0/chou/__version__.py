"""
Chou (瞅) - Academic Paper PDF Renaming Tool
Version information - single source of truth
"""

__version__ = "0.1.0"
__app_name__ = "chou"
__app_name_cn__ = "瞅"
__author__ = "cycleuser"
__email__ = ""
__description__ = "Academic paper PDF renaming tool - 学术论文PDF重命名工具"
__url__ = "https://github.com/cycleuser/Chou"
