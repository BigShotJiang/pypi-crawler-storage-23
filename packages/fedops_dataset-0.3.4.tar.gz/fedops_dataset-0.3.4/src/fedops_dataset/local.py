from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Mapping

from .create import V8_DATASETS, create_v8_local_artifacts
from .errors import InvalidRequestError
from .naming import alpha_token, token


def _dir_has_pkls(path: Path) -> bool:
    return path.is_dir() and any(path.glob("*.pkl"))


class FedOpsLocalDataset:
    """
    Flower-Datasets style local data entrypoint.

    This class does not require HF repo downloads. It prepares and reads local
    FedMS2-v8 artifacts from original/raw dataset sources.
    """

    def __init__(
        self,
        *,
        dataset: str,
        alpha: float,
        sample_missing_rate: float,
        modality_missing_rate: float,
        repo_root: str | Path | None = None,
        output_dir: str | Path | None = None,
        data_root: str | Path | None = None,
        hateful_memes_root: str | Path | None = None,
        num_clients: int | None = None,
    ) -> None:
        if dataset not in V8_DATASETS:
            raise InvalidRequestError(f"Unsupported dataset '{dataset}'. Supported: {sorted(V8_DATASETS)}")

        self.dataset = dataset
        self.alpha = alpha
        self.sample_missing_rate = sample_missing_rate
        self.modality_missing_rate = modality_missing_rate
        resolved_repo_root = repo_root or os.getenv("FEDOPS_REPO_ROOT")
        self.repo_root = Path(resolved_repo_root).expanduser().resolve() if resolved_repo_root else None
        self.output_dir = Path(output_dir).expanduser().resolve() if output_dir else None
        self.data_root = Path(data_root).expanduser().resolve() if data_root else None
        self.hateful_memes_root = Path(hateful_memes_root).expanduser().resolve() if hateful_memes_root else None
        self.num_clients = num_clients

    @classmethod
    def from_runtime_config(
        cls,
        *,
        dataset: str,
        alpha: float,
        sample_missing_rate: float,
        modality_missing_rate: float,
        run_config: Mapping[str, Any] | None = None,
        node_config: Mapping[str, Any] | None = None,
    ) -> "FedOpsLocalDataset":
        """
        Build dataset object from runtime configs (Flower-style).

        Behavior:
        - Simulation mode: node_config has partition-id and num-partitions.
        - Deployment mode: node_config usually includes data-path.
        """
        run_cfg = dict(run_config or {})
        node_cfg = dict(node_config or {})

        repo_root = run_cfg.get("repo-root") or os.getenv("FEDOPS_REPO_ROOT")
        output_dir = run_cfg.get("output-dir") or os.getenv("FEDOPS_OUTPUT_DIR")

        if "data-path" in node_cfg:
            data_root = node_cfg["data-path"]
        else:
            data_root = run_cfg.get("data-root") or os.getenv("FEDOPS_DATA_ROOT")

        hateful_memes_root = (
            node_cfg.get("hateful-memes-root")
            or run_cfg.get("hateful-memes-root")
            or os.getenv("HATEFUL_MEMES_ROOT")
        )
        if hateful_memes_root is None and data_root is not None:
            hateful_memes_root = str(Path(data_root) / "hateful_memes")

        num_clients = run_cfg.get("num-clients")
        if num_clients is not None:
            num_clients = int(num_clients)

        return cls(
            dataset=dataset,
            alpha=alpha,
            sample_missing_rate=sample_missing_rate,
            modality_missing_rate=modality_missing_rate,
            repo_root=repo_root,
            output_dir=output_dir,
            data_root=data_root,
            hateful_memes_root=hateful_memes_root,
            num_clients=num_clients,
        )

    @staticmethod
    def node_mode(node_config: Mapping[str, Any] | None = None) -> str:
        node_cfg = dict(node_config or {})
        if "partition-id" in node_cfg and "num-partitions" in node_cfg:
            return "simulation"
        return "deployment"

    def _resolved_output_dir(self) -> Path:
        if self.output_dir is not None:
            return self.output_dir
        if self.repo_root is not None:
            return (self.repo_root / "fed_multimodal" / "output").resolve()

        env_out = os.getenv("FEDOPS_OUTPUT_DIR")
        if env_out:
            return Path(env_out).expanduser().resolve()

        raise InvalidRequestError(
            "output_dir is required when repo_root is not set. "
            "Set output_dir explicitly, or set FEDOPS_REPO_ROOT/FEDOPS_OUTPUT_DIR."
        )

    def artifact_paths(self) -> dict[str, Any]:
        output_dir = self._resolved_output_dir()
        alpha_tok = alpha_token(self.alpha)
        ps_tok = token(self.sample_missing_rate)
        pm_tok = token(self.modality_missing_rate)

        partition = output_dir / "partition" / self.dataset / f"partition_alpha{alpha_tok}.json"
        simulation = output_dir / "simulation_feature" / self.dataset / f"mm_ps{ps_tok}_pm{pm_tok}_alpha{alpha_tok}.json"

        if self.dataset == "crema_d":
            feature_dirs = [
                output_dir / "feature" / "audio" / "mfcc" / "crema_d" / f"alpha{alpha_tok}",
                output_dir / "feature" / "video" / "mobilenet_v2" / "crema_d" / f"alpha{alpha_tok}",
            ]
        elif self.dataset == "hateful_memes":
            feature_dirs = [
                output_dir / "feature" / "img" / "mobilenet_v2" / "hateful_memes" / f"alpha{alpha_tok}",
                output_dir / "feature" / "text" / "mobilebert" / "hateful_memes" / f"alpha{alpha_tok}",
            ]
        else:
            feature_dirs = [
                output_dir / "feature" / "I_to_AVF" / "ptb-xl" / f"alpha{alpha_tok}",
                output_dir / "feature" / "V1_to_V6" / "ptb-xl" / f"alpha{alpha_tok}",
            ]

        return {
            "output_dir": output_dir,
            "partition": partition,
            "simulation": simulation,
            "feature_dirs": feature_dirs,
        }

    def is_prepared(self) -> bool:
        paths = self.artifact_paths()
        return (
            Path(paths["partition"]).is_file()
            and Path(paths["simulation"]).is_file()
            and all(_dir_has_pkls(Path(p)) for p in paths["feature_dirs"])
        )

    def prepare(self, *, force: bool = False, dry_run: bool = False) -> dict[str, Any]:
        if self.repo_root is None and not os.getenv("FEDOPS_REPO_ROOT"):
            raise InvalidRequestError(
                "prepare() requires repo_root (or FEDOPS_REPO_ROOT) so generation scripts can be located."
            )
        return create_v8_local_artifacts(
            dataset=self.dataset,
            alpha=self.alpha,
            sample_missing_rate=self.sample_missing_rate,
            modality_missing_rate=self.modality_missing_rate,
            repo_root=self.repo_root,
            output_dir=self.output_dir,
            data_root=self.data_root,
            hateful_memes_root=self.hateful_memes_root,
            num_clients=self.num_clients,
            include_partition=True,
            include_features=True,
            include_simulation=True,
            force=force,
            dry_run=dry_run,
        )

    def _load_json_or_raise(self, path: Path, kind: str) -> dict[str, Any]:
        if not path.exists():
            raise InvalidRequestError(
                f"{kind} file not found: {path}. "
                f"Run prepare() first or call `fedops-dataset create-v8 ...`."
            )
        return json.loads(path.read_text(encoding="utf-8"))

    def load_partition(self) -> dict[str, Any]:
        partition_path = Path(self.artifact_paths()["partition"])
        return self._load_json_or_raise(partition_path, "partition")

    def load_simulation(self) -> dict[str, Any]:
        simulation_path = Path(self.artifact_paths()["simulation"])
        return self._load_json_or_raise(simulation_path, "simulation")

    def client_ids(self) -> list[str]:
        partition = self.load_partition()
        return sorted([k for k in partition.keys() if k not in {"dev", "test"}], key=lambda x: int(x))

    def client_records(self, client_id: int | str, *, use_simulation: bool = True) -> list[Any]:
        key = str(client_id)
        source = self.load_simulation() if use_simulation else self.load_partition()
        if key not in source:
            raise InvalidRequestError(f"Client id '{key}' not found for dataset '{self.dataset}'.")
        records = source[key]
        if not isinstance(records, list):
            raise InvalidRequestError(f"Client id '{key}' records are not a list.")
        return records

    def client_records_from_node_config(
        self,
        node_config: Mapping[str, Any] | None = None,
        *,
        use_simulation: bool = True,
    ) -> list[Any]:
        node_cfg = dict(node_config or {})
        if "client-id" in node_cfg:
            return self.client_records(node_cfg["client-id"], use_simulation=use_simulation)
        if "partition-id" in node_cfg:
            return self.client_records(node_cfg["partition-id"], use_simulation=use_simulation)
        raise InvalidRequestError(
            "node_config must contain either 'client-id' or 'partition-id' to resolve client records."
        )
