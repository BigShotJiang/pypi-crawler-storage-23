from __future__ import annotations

from decimal import Decimal, InvalidOperation

def token(value: float | int | str) -> str:
    """Match project naming style: str(value).replace('.', '')."""
    return str(value).replace(".", "")


def alpha_token(value: float | int | str) -> str:
    """
    Normalize alpha token used in artifact filenames.

    Keeps backward compatibility with historical naming:
    - 0.1 -> "01"
    - 5.0 -> "50"

    Also fixes float parser artifacts:
    - 50.0 -> "50" (instead of "500")
    """
    raw = str(value).strip()
    try:
        dec = Decimal(raw)
    except (InvalidOperation, ValueError):
        return token(value)

    if dec == dec.to_integral():
        integral = int(dec)
        # Treat large integral values as already-tokenized alpha (e.g. 50.0 -> 50).
        if abs(integral) >= 10:
            return str(integral)
        # Preserve legacy convention for single-digit integral alpha values (e.g. 5.0 -> 50).
        return f"{integral}0"

    normalized = format(dec.normalize(), "f")
    if "." in normalized:
        normalized = normalized.rstrip("0").rstrip(".")
    return normalized.replace(".", "")


def alpha_script_arg(value: float | int | str) -> str:
    """
    Normalize alpha value passed to upstream generation scripts.

    Upstream scripts tokenize alpha with `str(args.alpha).replace('.', '')`.
    To map user input like `50` or `50.0` to alpha token `50`, scripts must receive `5.0`.
    """
    raw = str(value).strip()
    try:
        dec = Decimal(raw)
    except (InvalidOperation, ValueError):
        return str(value)

    if dec == dec.to_integral() and abs(int(dec)) >= 10:
        dec = dec / Decimal(10)

    if dec == dec.to_integral():
        return f"{int(dec)}.0"
    return format(dec.normalize(), "f")


def alpha_suffix(alpha: float | int | str | None) -> str:
    if alpha is None:
        return ""
    return f"_alpha{alpha_token(alpha)}"
