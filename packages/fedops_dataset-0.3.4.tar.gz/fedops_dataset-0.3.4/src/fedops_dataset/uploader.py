from __future__ import annotations

import json
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .manifest import load_manifest_json
from .registry import V8_SIM_DATASETS


class UploadAttemptTimeout(Exception):
    """Raised when one upload attempt exceeds timeout."""


@dataclass(frozen=True)
class UploadTask:
    name: str
    local_dir: str
    path_in_repo: str
    allow_patterns: list[str] | None = None


def _build_upload_tasks(manifest: dict[str, Any], output_root: Path) -> list[UploadTask]:
    tasks: list[UploadTask] = []
    datasets = manifest.get("datasets", {})

    for dataset in sorted(V8_SIM_DATASETS):
        part_dir = output_root / "partition" / dataset
        if part_dir.exists():
            tasks.append(
                UploadTask(
                    name=f"partition:{dataset}",
                    local_dir=str(part_dir),
                    path_in_repo=f"output/partition/{dataset}",
                    allow_patterns=None,
                )
            )

    for dataset in sorted(V8_SIM_DATASETS):
        sim_dir = output_root / "simulation_feature" / dataset
        if sim_dir.exists():
            tasks.append(
                UploadTask(
                    name=f"simulation:{dataset}",
                    local_dir=str(sim_dir),
                    path_in_repo=f"output/simulation_feature/{dataset}",
                    allow_patterns=["mm_ps*_pm*_alpha*.json"],
                )
            )

    feature_dirs: set[str] = set()
    for dataset in sorted(V8_SIM_DATASETS):
        entry = datasets.get(dataset, {})
        for rel in entry.get("feature_dirs", []):
            feature_dirs.add(rel)
    for rel in sorted(feature_dirs):
        local_dir = output_root / rel
        if local_dir.exists():
            tasks.append(
                UploadTask(
                    name=f"feature:{rel}",
                    local_dir=str(local_dir),
                    path_in_repo=f"output/{rel}",
                    allow_patterns=None,
                )
            )

    return tasks


def _load_state(state_json: Path) -> dict[str, Any]:
    if not state_json.exists():
        return {"completed": []}
    return json.loads(state_json.read_text(encoding="utf-8"))


def _save_state(state_json: Path, state: dict[str, Any]) -> None:
    state_json.parent.mkdir(parents=True, exist_ok=True)
    state_json.write_text(json.dumps(state, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _run_subprocess_upload(payload: dict[str, Any], timeout_sec: int) -> None:
    script = """
import json
import sys
from huggingface_hub import HfApi

payload = json.loads(sys.argv[1])
token = payload.get("token")
api = HfApi(token=token if token else None)

if payload["kind"] == "folder":
    api.upload_folder(
        folder_path=payload["local_path"],
        repo_id=payload["repo_id"],
        repo_type="dataset",
        path_in_repo=payload["path_in_repo"],
        allow_patterns=payload.get("allow_patterns"),
    )
elif payload["kind"] == "file":
    api.upload_file(
        path_or_fileobj=payload["local_path"],
        path_in_repo=payload["path_in_repo"],
        repo_id=payload["repo_id"],
        repo_type="dataset",
    )
else:
    raise ValueError(f"Unknown payload kind: {payload['kind']}")
"""

    try:
        proc = subprocess.run(
            [sys.executable, "-c", script, json.dumps(payload)],
            capture_output=True,
            text=True,
            timeout=timeout_sec,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        raise UploadAttemptTimeout(f"Upload attempt timed out after {timeout_sec}s") from exc

    if proc.returncode != 0:
        details = (proc.stderr or proc.stdout or "").strip()
        raise RuntimeError(details or f"Upload subprocess failed with exit code {proc.returncode}")


def _upload_folder_once(
    *,
    repo_id: str,
    local_dir: str,
    path_in_repo: str,
    allow_patterns: list[str] | None,
    timeout_sec: int,
    token: str | None,
) -> None:
    payload = {
        "kind": "folder",
        "repo_id": repo_id,
        "local_path": local_dir,
        "path_in_repo": path_in_repo,
        "allow_patterns": allow_patterns,
        "token": token,
    }
    _run_subprocess_upload(payload, timeout_sec=timeout_sec)


def _upload_file_once(
    *,
    repo_id: str,
    local_file: str,
    path_in_repo: str,
    timeout_sec: int,
    token: str | None,
) -> None:
    payload = {
        "kind": "file",
        "repo_id": repo_id,
        "local_path": local_file,
        "path_in_repo": path_in_repo,
        "token": token,
    }
    _run_subprocess_upload(payload, timeout_sec=timeout_sec)


def upload_v8_from_manifest(
    repo_id: str,
    output_root: str | Path,
    manifest_json: str | Path,
    *,
    state_json: str | Path = ".upload_state.v8.json",
    max_retries: int = 8,
    attempt_timeout_sec: int = 180,
    sleep_base_sec: int = 15,
    token: str | None = None,
) -> dict[str, Any]:
    """
    Resumable v8 uploader for unstable networks.

    - Uses retries with backoff per task.
    - Uses per-attempt timeout to avoid hanging calls.
    - Persists completion state so reruns continue from where they stopped.
    """
    output_root = Path(output_root).expanduser().resolve()
    manifest = load_manifest_json(manifest_json)
    tasks = _build_upload_tasks(manifest, output_root)
    state_path = Path(state_json).expanduser().resolve()
    state = _load_state(state_path)
    completed = set(state.get("completed", []))

    total = len(tasks)
    for idx, task in enumerate(tasks, start=1):
        if task.name in completed:
            print(f"[{idx}/{total}] SKIP {task.name}")
            continue

        print(f"[{idx}/{total}] START {task.name}")
        success = False
        for attempt in range(1, max_retries + 1):
            try:
                _upload_folder_once(
                    repo_id=repo_id,
                    local_dir=task.local_dir,
                    path_in_repo=task.path_in_repo,
                    allow_patterns=task.allow_patterns,
                    timeout_sec=attempt_timeout_sec,
                    token=token,
                )
                print(f"[{idx}/{total}] DONE {task.name}")
                completed.add(task.name)
                state["completed"] = sorted(completed)
                _save_state(state_path, state)
                success = True
                break
            except Exception as exc:  # noqa: BLE001
                print(f"[{idx}/{total}] RETRY {attempt}/{max_retries} {task.name}: {exc}")
                if attempt == max_retries:
                    raise
                time.sleep(sleep_base_sec * attempt)

        if not success:
            raise RuntimeError(f"Task failed: {task.name}")

    print("START manifest upload")
    for attempt in range(1, max_retries + 1):
        try:
            _upload_file_once(
                path_in_repo="manifest.v8.json",
                repo_id=repo_id,
                local_file=str(Path(manifest_json).expanduser().resolve()),
                timeout_sec=attempt_timeout_sec,
                token=token,
            )
            print("DONE manifest upload")
            break
        except Exception as exc:  # noqa: BLE001
            print(f"RETRY {attempt}/{max_retries} manifest upload: {exc}")
            if attempt == max_retries:
                raise
            time.sleep(sleep_base_sec * attempt)

    return {
        "repo_id": repo_id,
        "tasks_total": total,
        "tasks_completed": len(completed),
        "state_json": str(state_path),
    }


def _build_file_list_from_manifest(manifest: dict[str, Any], output_root: Path) -> list[str]:
    rel_files: set[str] = set()
    datasets = manifest.get("datasets", {})

    for dataset in V8_SIM_DATASETS:
        entry = datasets.get(dataset, {})
        for rel in entry.get("partition_files", []):
            path = output_root / rel
            if path.is_file():
                rel_files.add(rel)

        for rel in entry.get("simulation_files", []):
            path = output_root / rel
            if path.is_file():
                rel_files.add(rel)

        for rel_dir in entry.get("feature_dirs", []):
            root = output_root / rel_dir
            if not root.is_dir():
                continue
            for p in root.rglob("*"):
                if p.is_file():
                    rel_files.add(p.relative_to(output_root).as_posix())

    return sorted(rel_files)


def upload_v8_filewise_from_manifest(
    repo_id: str,
    output_root: str | Path,
    manifest_json: str | Path,
    *,
    state_json: str | Path = ".upload_state.v8.filewise.json",
    max_retries: int = 20,
    attempt_timeout_sec: int = 120,
    sleep_base_sec: int = 8,
    max_files_per_run: int | None = None,
    token: str | None = None,
) -> dict[str, Any]:
    """
    Ultra-resilient uploader:
    - one file per commit
    - retries + backoff + hard timeout
    - resumable via state JSON
    """
    output_root = Path(output_root).expanduser().resolve()
    manifest = load_manifest_json(manifest_json)
    rel_files = _build_file_list_from_manifest(manifest, output_root)

    state_path = Path(state_json).expanduser().resolve()
    state = _load_state(state_path)
    completed = set(state.get("completed", []))

    uploaded_in_this_run = 0
    total = len(rel_files)
    for idx, rel in enumerate(rel_files, start=1):
        if rel in completed:
            if idx % 50 == 0:
                print(f"[{idx}/{total}] SKIP {rel}")
            continue

        local_file = output_root / rel
        path_in_repo = f"output/{rel}"
        print(f"[{idx}/{total}] START {rel}")
        success = False
        for attempt in range(1, max_retries + 1):
            try:
                _upload_file_once(
                    repo_id=repo_id,
                    local_file=str(local_file),
                    path_in_repo=path_in_repo,
                    timeout_sec=attempt_timeout_sec,
                    token=token,
                )
                print(f"[{idx}/{total}] DONE {rel}")
                completed.add(rel)
                state["completed"] = sorted(completed)
                _save_state(state_path, state)
                uploaded_in_this_run += 1
                success = True
                break
            except Exception as exc:  # noqa: BLE001
                print(f"[{idx}/{total}] RETRY {attempt}/{max_retries} {rel}: {exc}")
                if attempt == max_retries:
                    raise
                time.sleep(sleep_base_sec * attempt)

        if not success:
            raise RuntimeError(f"File failed: {rel}")

        if max_files_per_run is not None and uploaded_in_this_run >= max_files_per_run:
            print(f"Reached max-files-per-run={max_files_per_run}. Stopping.")
            break

    print("START manifest upload")
    for attempt in range(1, max_retries + 1):
        try:
            _upload_file_once(
                path_in_repo="manifest.v8.json",
                repo_id=repo_id,
                local_file=str(Path(manifest_json).expanduser().resolve()),
                timeout_sec=attempt_timeout_sec,
                token=token,
            )
            print("DONE manifest upload")
            break
        except Exception as exc:  # noqa: BLE001
            print(f"RETRY {attempt}/{max_retries} manifest upload: {exc}")
            if attempt == max_retries:
                raise
            time.sleep(sleep_base_sec * attempt)

    return {
        "repo_id": repo_id,
        "files_total": total,
        "files_completed": len(completed),
        "uploaded_in_this_run": uploaded_in_this_run,
        "state_json": str(state_path),
    }
