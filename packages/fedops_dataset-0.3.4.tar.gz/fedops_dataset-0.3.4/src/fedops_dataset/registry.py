from __future__ import annotations

DATASET_REGISTRY: dict[str, dict] = {
    "hateful_memes": {
        "feature_dirs": {
            "img": "feature/img/mobilenet_v2/{dataset}/alpha{alpha}",
            "text": "feature/text/mobilebert/{dataset}/alpha{alpha}",
        }
    },
    "mm-imdb": {
        "feature_dirs": {
            "img": "feature/img/mobilenet_v2/{dataset}/alpha{alpha}",
            "text": "feature/text/mobilebert/{dataset}/alpha{alpha}",
        }
    },
    "crisis-mmd": {
        "feature_dirs": {
            "img": "feature/img/mobilenet_v2/{dataset}/alpha{alpha}",
            "text": "feature/text/mobilebert/{dataset}/alpha{alpha}",
        }
    },
    "crema_d": {
        "feature_dirs": {
            "audio": "feature/audio/mfcc/{dataset}/alpha{alpha}",
            "video": "feature/video/mobilenet_v2/{dataset}/alpha{alpha}",
        }
    },
    "ptb-xl": {
        "feature_dirs": {
            "i_to_avf": "feature/I_to_AVF/{dataset}/alpha{alpha}",
            "v1_to_v6": "feature/V1_to_V6/{dataset}/alpha{alpha}",
        }
    },
    "uci-har": {
        "feature_dirs": {
            "acc": "feature/acc/{dataset}/alpha{alpha}",
            "gyro": "feature/gyro/{dataset}/alpha{alpha}",
        }
    },
}

SUPPORTED_DATASETS = tuple(sorted(DATASET_REGISTRY.keys()))

# FedMS2-v8 simulation contract scope (used experiment tracks)
V8_SIM_DATASETS = ("crema_d", "hateful_memes", "ptb-xl")
