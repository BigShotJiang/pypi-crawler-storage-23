from __future__ import annotations

import hashlib
import json
import tarfile
import time
from pathlib import Path
from typing import Any

from .manifest import load_manifest_json
from .registry import V8_SIM_DATASETS
from .uploader import _load_state, _save_state, _upload_file_once

ARCHIVE_MANIFEST_FILENAME = "archive_manifest.v8.json"
ARCHIVE_CHECKSUM_FILENAME = "SHA256SUMS.txt"


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            chunk = f.read(1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def _iter_archive_specs(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    specs: list[dict[str, Any]] = []
    datasets = manifest.get("datasets", {})

    for dataset in sorted(V8_SIM_DATASETS):
        if dataset not in datasets:
            continue
        specs.append(
            {
                "source_rel": f"partition/{dataset}",
                "archive_name": f"partition__{dataset}.tar",
                "contains_prefixes": [f"output/partition/{dataset}/"],
            }
        )
        specs.append(
            {
                "source_rel": f"simulation_feature/{dataset}",
                "archive_name": f"simulation__{dataset}.tar",
                "contains_prefixes": [f"output/simulation_feature/{dataset}/"],
            }
        )
        for rel in sorted(datasets[dataset].get("feature_dirs", [])):
            safe = rel.replace("/", "__")
            specs.append(
                {
                    "source_rel": rel,
                    "archive_name": f"feature__{safe}.tar",
                    "contains_prefixes": [f"output/{rel}/"],
                }
            )

    return specs


def build_v8_archives(
    output_root: str | Path,
    manifest_json: str | Path,
    archives_dir: str | Path,
    *,
    overwrite: bool = False,
) -> dict[str, Any]:
    output_root = Path(output_root).expanduser().resolve()
    archives_dir = Path(archives_dir).expanduser().resolve()
    archives_dir.mkdir(parents=True, exist_ok=True)

    manifest = load_manifest_json(manifest_json)
    specs = _iter_archive_specs(manifest)

    archives: list[dict[str, Any]] = []
    checksum_lines: list[str] = []
    for spec in specs:
        source = output_root / spec["source_rel"]
        if not source.exists():
            continue

        tar_path = archives_dir / spec["archive_name"]
        if tar_path.exists() and not overwrite:
            pass
        else:
            with tarfile.open(tar_path, "w") as tar:
                tar.add(source, arcname=f"output/{spec['source_rel']}")

        size_bytes = tar_path.stat().st_size
        sha256 = _sha256_file(tar_path)
        checksum_lines.append(f"{sha256}  {tar_path.name}")
        archives.append(
            {
                "name": tar_path.name,
                "path_in_repo": f"archives/{tar_path.name}",
                "source_rel": spec["source_rel"],
                "contains_prefixes": spec["contains_prefixes"],
                "size_bytes": size_bytes,
                "sha256": sha256,
            }
        )

    checksum_path = archives_dir / ARCHIVE_CHECKSUM_FILENAME
    checksum_path.write_text("\n".join(checksum_lines) + ("\n" if checksum_lines else ""), encoding="utf-8")

    archive_manifest = {
        "schema_version": 1,
        "contract": "fedms2-v8-archive",
        "generated_at_unix": int(time.time()),
        "source_output_root": str(output_root),
        "source_manifest": str(Path(manifest_json).expanduser().resolve()),
        "archives": archives,
    }
    archive_manifest_path = archives_dir / ARCHIVE_MANIFEST_FILENAME
    archive_manifest_path.write_text(json.dumps(archive_manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    return {
        "archives_dir": str(archives_dir),
        "archive_manifest_json": str(archive_manifest_path),
        "checksum_file": str(checksum_path),
        "archives_count": len(archives),
        "archives_total_bytes": sum(a["size_bytes"] for a in archives),
    }


def load_archive_manifest(archive_manifest_json: str | Path) -> dict[str, Any]:
    path = Path(archive_manifest_json).expanduser().resolve()
    return json.loads(path.read_text(encoding="utf-8"))


def find_archive_for_path(archive_manifest: dict[str, Any], path_in_repo: str) -> dict[str, Any] | None:
    normalized = path_in_repo.strip("/")
    if not normalized.startswith("output/"):
        normalized = f"output/{normalized}"

    for entry in archive_manifest.get("archives", []):
        for prefix in entry.get("contains_prefixes", []):
            if normalized.startswith(prefix):
                return entry
    return None


def upload_v8_archives(
    repo_id: str,
    archives_dir: str | Path,
    *,
    state_json: str | Path = ".upload_state.v8.archives.json",
    max_retries: int = 20,
    attempt_timeout_sec: int = 240,
    sleep_base_sec: int = 10,
    token: str | None = None,
) -> dict[str, Any]:
    archives_dir = Path(archives_dir).expanduser().resolve()
    state_path = Path(state_json).expanduser().resolve()
    state = _load_state(state_path)
    completed = set(state.get("completed", []))

    files: list[tuple[Path, str]] = []
    checksum_path = archives_dir / ARCHIVE_CHECKSUM_FILENAME
    if checksum_path.exists():
        files.append((checksum_path, f"archives/{checksum_path.name}"))

    archive_manifest_path = archives_dir / ARCHIVE_MANIFEST_FILENAME
    if archive_manifest_path.exists():
        files.append((archive_manifest_path, ARCHIVE_MANIFEST_FILENAME))

    manifest_v8_path = archives_dir / "manifest.v8.json"
    if manifest_v8_path.exists():
        files.append((manifest_v8_path, "manifest.v8.json"))

    tar_files = sorted(archives_dir.glob("*.tar"), key=lambda p: (p.stat().st_size, p.name))
    files.extend((tar_file, f"archives/{tar_file.name}") for tar_file in tar_files)

    uploaded_in_this_run = 0
    total = len(files)
    for idx, (local_file, path_in_repo) in enumerate(files, start=1):
        if path_in_repo in completed:
            print(f"[{idx}/{total}] SKIP {path_in_repo}")
            continue

        print(f"[{idx}/{total}] START {path_in_repo}")
        for attempt in range(1, max_retries + 1):
            try:
                _upload_file_once(
                    repo_id=repo_id,
                    local_file=str(local_file),
                    path_in_repo=path_in_repo,
                    timeout_sec=attempt_timeout_sec,
                    token=token,
                )
                print(f"[{idx}/{total}] DONE {path_in_repo}")
                completed.add(path_in_repo)
                state["completed"] = sorted(completed)
                _save_state(state_path, state)
                uploaded_in_this_run += 1
                break
            except Exception as exc:  # noqa: BLE001
                print(f"[{idx}/{total}] RETRY {attempt}/{max_retries} {path_in_repo}: {exc}")
                if attempt == max_retries:
                    raise
                time.sleep(sleep_base_sec * attempt)

    return {
        "repo_id": repo_id,
        "archives_dir": str(archives_dir),
        "files_total": total,
        "files_completed": len(completed),
        "uploaded_in_this_run": uploaded_in_this_run,
        "state_json": str(state_path),
    }
