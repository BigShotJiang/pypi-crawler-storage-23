from __future__ import annotations

import json
import tarfile
from pathlib import Path
from typing import Iterable, Literal

from huggingface_hub import hf_hub_download, snapshot_download

from .archives import ARCHIVE_MANIFEST_FILENAME, find_archive_for_path
from .errors import DatasetNotSupportedError, InvalidRequestError
from .models import ArtifactRef, HubConfig
from .naming import alpha_suffix, alpha_token, token
from .registry import DATASET_REGISTRY

V8_SIM_DATASETS = {"crema_d", "hateful_memes", "ptb-xl"}


class FedOpsDatasetClient:
    def __init__(self, repo_id: str, revision: str = "main", root_prefix: str = "output", local_cache_dir: str | None = None):
        self.config = HubConfig(
            repo_id=repo_id,
            revision=revision,
            root_prefix=root_prefix,
            local_cache_dir=local_cache_dir,
        )

    def _validate_dataset(self, dataset: str) -> None:
        if dataset not in DATASET_REGISTRY:
            raise DatasetNotSupportedError(
                f"Unsupported dataset '{dataset}'. Supported: {', '.join(sorted(DATASET_REGISTRY))}"
            )

    def partition_ref(
        self,
        dataset: str,
        alpha: float | None = None,
        partition_type: Literal["noniid", "iid"] = "noniid",
        fold: int | None = None,
    ) -> ArtifactRef:
        self._validate_dataset(dataset)

        base = f"{self.config.root_prefix}/partition/{dataset}"

        if dataset == "ptb-xl" and partition_type == "iid":
            rel = f"{base}/partition_iid.json"
        elif alpha is not None:
            rel = f"{base}/partition_alpha{alpha_token(alpha)}.json"
        elif fold is not None:
            rel = f"{base}/fold{fold}/partition.json"
        else:
            rel = f"{base}/partition.json"

        return ArtifactRef(
            repo_id=self.config.repo_id,
            repo_type=self.config.repo_type,
            revision=self.config.revision,
            path_in_repo=rel,
            kind="file",
        )

    def simulation_ref(
        self,
        dataset: str,
        *,
        alpha: float,
        partition_type: Literal["noniid", "iid"] = "noniid",
        fold: int | None = None,
        sample_missing_rate: float,
        modality_missing_rate: float,
    ) -> ArtifactRef:
        self._validate_dataset(dataset)
        if dataset not in V8_SIM_DATASETS:
            raise InvalidRequestError(
                "simulation_ref currently supports only v8 datasets: crema_d, hateful_memes, ptb-xl."
            )

        base = f"{self.config.root_prefix}/simulation_feature/{dataset}"
        if partition_type == "iid":
            base = f"{base}/iid"
        if fold is not None:
            base = f"{base}/fold{fold}"

        filename = (
            f"mm_ps{token(sample_missing_rate)}_pm{token(modality_missing_rate)}"
            f"{alpha_suffix(alpha)}.json"
        )

        return ArtifactRef(
            repo_id=self.config.repo_id,
            repo_type=self.config.repo_type,
            revision=self.config.revision,
            path_in_repo=f"{base}/{filename}",
            kind="file",
        )

    def feature_dir_refs(self, dataset: str, alpha: float) -> list[ArtifactRef]:
        self._validate_dataset(dataset)
        alpha_tok = alpha_token(alpha)

        refs: list[ArtifactRef] = []
        for _, tpl in DATASET_REGISTRY[dataset]["feature_dirs"].items():
            rel = f"{self.config.root_prefix}/{tpl.format(dataset=dataset, alpha=alpha_tok)}"
            refs.append(
                ArtifactRef(
                    repo_id=self.config.repo_id,
                    repo_type=self.config.repo_type,
                    revision=self.config.revision,
                    path_in_repo=rel,
                    kind="directory",
                )
            )
        return refs

    def download(self, ref: ArtifactRef, local_dir: str | None = None) -> Path:
        local_dir = local_dir or self.config.local_cache_dir

        if ref.kind == "file":
            path = hf_hub_download(
                repo_id=ref.repo_id,
                repo_type=ref.repo_type,
                revision=ref.revision,
                filename=ref.path_in_repo,
                local_dir=local_dir,
            )
            return Path(path)

        snapshot_root = snapshot_download(
            repo_id=ref.repo_id,
            repo_type=ref.repo_type,
            revision=ref.revision,
            local_dir=local_dir,
            allow_patterns=[f"{ref.path_in_repo}/*"],
        )
        return Path(snapshot_root) / ref.path_in_repo

    def download_many(self, refs: Iterable[ArtifactRef], local_dir: str | None = None) -> list[Path]:
        return [self.download(ref, local_dir=local_dir) for ref in refs]

    def _safe_extract_tar(self, tar_path: Path, destination: Path) -> None:
        destination = destination.resolve()
        destination.mkdir(parents=True, exist_ok=True)
        with tarfile.open(tar_path, "r") as tar:
            for member in tar.getmembers():
                target = (destination / member.name).resolve()
                if not str(target).startswith(str(destination) + "/") and target != destination:
                    raise InvalidRequestError(f"Unsafe tar member path: {member.name}")
            tar.extractall(destination)

    def _load_archive_manifest(self, local_dir: str | None = None, filename: str = ARCHIVE_MANIFEST_FILENAME) -> dict:
        local_dir = local_dir or self.config.local_cache_dir
        manifest_path = hf_hub_download(
            repo_id=self.config.repo_id,
            repo_type=self.config.repo_type,
            revision=self.config.revision,
            filename=filename,
            local_dir=local_dir,
        )
        return json.loads(Path(manifest_path).read_text(encoding="utf-8"))

    def download_with_archive_fallback(
        self,
        ref: ArtifactRef,
        local_dir: str | None = None,
        archive_manifest_filename: str = ARCHIVE_MANIFEST_FILENAME,
    ) -> Path:
        try:
            return self.download(ref, local_dir=local_dir)
        except Exception as primary_error:  # noqa: BLE001
            local_dir = local_dir or self.config.local_cache_dir or ".fedops_dataset_cache"
            local_root = Path(local_dir).expanduser().resolve()
            local_root.mkdir(parents=True, exist_ok=True)

            archive_manifest = self._load_archive_manifest(local_dir=str(local_root), filename=archive_manifest_filename)
            entry = find_archive_for_path(archive_manifest, ref.path_in_repo)
            if entry is None:
                raise InvalidRequestError(
                    f"No archive contains '{ref.path_in_repo}'. Original download error: {primary_error}"
                ) from primary_error

            archive_path = hf_hub_download(
                repo_id=self.config.repo_id,
                repo_type=self.config.repo_type,
                revision=self.config.revision,
                filename=entry["path_in_repo"],
                local_dir=str(local_root),
            )
            self._safe_extract_tar(Path(archive_path), local_root)

            target = local_root / ref.path_in_repo
            if not target.exists():
                raise InvalidRequestError(
                    f"Archive extracted but target path missing: {target}. Archive: {entry['path_in_repo']}"
                )
            return target
