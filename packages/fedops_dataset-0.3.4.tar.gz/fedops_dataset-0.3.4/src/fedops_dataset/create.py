from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path
from typing import Any

from .errors import InvalidRequestError
from .naming import alpha_script_arg, alpha_token, token
from .raw_data import raw_data_setup_hints, resolve_raw_dataset_roots, validate_raw_dataset_roots

V8_DATASETS = {"crema_d", "hateful_memes", "ptb-xl"}


def _dir_has_pkls(path: Path) -> bool:
    return path.is_dir() and any(path.glob("*.pkl"))


def _prepare_staging_data_root(
    *,
    staging_data_root: Path,
    crema_d_root: Path,
    ptb_xl_root: Path,
    hateful_memes_root: Path,
) -> Path:
    staging_data_root.mkdir(parents=True, exist_ok=True)
    mapping = {
        "crema_d": crema_d_root,
        "ptb-xl": ptb_xl_root,
        "hateful_memes": hateful_memes_root,
    }
    for name, src in mapping.items():
        dst = staging_data_root / name
        if dst.exists() or dst.is_symlink():
            if dst.is_symlink() and dst.resolve() == src.resolve():
                continue
            dst.unlink() if dst.is_symlink() else None
            if dst.exists() and not dst.is_symlink():
                raise InvalidRequestError(
                    f"Staging path exists and is not symlink: {dst}. Remove it manually and retry."
                )
        dst.symlink_to(src.resolve(), target_is_directory=True)
    return staging_data_root


def _run_script(
    *,
    repo_root: Path,
    script_rel: str,
    script_args: list[str],
    dry_run: bool,
    env_extra: dict[str, str] | None = None,
) -> str:
    script_path = repo_root / script_rel
    if not script_path.exists():
        raise InvalidRequestError(f"Script not found: {script_path}")

    cmd = [sys.executable, str(script_path), *script_args]
    cmd_str = " ".join(cmd)
    if dry_run:
        return f"[DRY_RUN] {cmd_str}"

    env = os.environ.copy()
    env["PYTHONPATH"] = str(repo_root) + (f":{env['PYTHONPATH']}" if "PYTHONPATH" in env else "")
    if env_extra:
        env.update(env_extra)

    subprocess.run(cmd, cwd=str(repo_root), env=env, check=True)
    return cmd_str


def _dataset_default_num_clients(dataset: str) -> int:
    if dataset == "ptb-xl":
        return 20
    return 40


def _ensure_ptb_natural_ready(
    *,
    repo_root: Path,
    raw_data_dir: Path,
    output_dir: Path,
    dry_run: bool,
    actions: list[str],
) -> None:
    partition_json = output_dir / "partition" / "ptb-xl" / "partition.json"
    i_to_avf_dir = output_dir / "feature" / "I_to_AVF" / "ptb-xl"
    v1_to_v6_dir = output_dir / "feature" / "V1_to_V6" / "ptb-xl"
    natural_ready = partition_json.exists() and _dir_has_pkls(i_to_avf_dir) and _dir_has_pkls(v1_to_v6_dir)
    if natural_ready:
        return

    actions.append(
        _run_script(
            repo_root=repo_root,
            script_rel="fed_multimodal/features/data_partitioning/ptb-xl/data_partition.py",
            script_args=[
                "--raw_data_dir",
                str(raw_data_dir),
                "--output_partition_path",
                str(output_dir),
                "--dataset",
                "ptb-xl",
            ],
            dry_run=dry_run,
        )
    )
    actions.append(
        _run_script(
            repo_root=repo_root,
            script_rel="fed_multimodal/features/feature_processing/ptb-xl/extract_feature.py",
            script_args=[
                "--raw_data_dir",
                str(raw_data_dir),
                "--output_dir",
                str(output_dir),
                "--dataset",
                "ptb-xl",
            ],
            dry_run=dry_run,
        )
    )


def create_v8_local_artifacts(
    *,
    dataset: str,
    alpha: float,
    sample_missing_rate: float,
    modality_missing_rate: float,
    repo_root: str | Path | None = None,
    output_dir: str | Path | None = None,
    data_root: str | Path | None = None,
    hateful_memes_root: str | Path | None = None,
    num_clients: int | None = None,
    include_partition: bool = True,
    include_features: bool = True,
    include_simulation: bool = True,
    force: bool = False,
    dry_run: bool = False,
) -> dict[str, Any]:
    if dataset not in V8_DATASETS:
        raise InvalidRequestError(f"Unsupported dataset '{dataset}'. Supported: {sorted(V8_DATASETS)}")

    repo_root = repo_root or os.getenv("FEDOPS_REPO_ROOT")
    if repo_root is None:
        raise InvalidRequestError(
            "repo_root is required. Pass --repo-root (CLI) or set FEDOPS_REPO_ROOT."
        )

    repo_root = Path(repo_root).expanduser().resolve()
    fed_multimodal_dir = repo_root / "fed_multimodal"
    if not fed_multimodal_dir.exists():
        raise InvalidRequestError(f"repo_root must contain fed_multimodal/: {repo_root}")

    output_dir = Path(output_dir).expanduser().resolve() if output_dir else (fed_multimodal_dir / "output").resolve()
    num_clients = num_clients or _dataset_default_num_clients(dataset)

    raw_default_root = data_root or (fed_multimodal_dir / "data")
    roots = resolve_raw_dataset_roots(data_root=raw_default_root, hateful_memes_root=hateful_memes_root)
    errors = validate_raw_dataset_roots(roots)
    if errors:
        hints = "\n".join(f"- {h}" for h in raw_data_setup_hints())
        raise InvalidRequestError("Raw dataset validation failed:\n" + "\n".join(errors) + f"\nHints:\n{hints}")

    staging_data_root = output_dir / ".fedops_dataset_staging_data"
    raw_data_dir = _prepare_staging_data_root(
        staging_data_root=staging_data_root,
        crema_d_root=roots.crema_d_root,
        ptb_xl_root=roots.ptb_xl_root,
        hateful_memes_root=roots.hateful_memes_root,
    )

    alpha_tok = alpha_token(alpha)
    alpha_script = alpha_script_arg(alpha)
    ps_tok = token(sample_missing_rate)
    pm_tok = token(modality_missing_rate)

    target_partition = output_dir / "partition" / dataset / f"partition_alpha{alpha_tok}.json"
    target_simulation = output_dir / "simulation_feature" / dataset / f"mm_ps{ps_tok}_pm{pm_tok}_alpha{alpha_tok}.json"

    if dataset == "crema_d":
        target_features = [
            output_dir / "feature" / "audio" / "mfcc" / "crema_d" / f"alpha{alpha_tok}",
            output_dir / "feature" / "video" / "mobilenet_v2" / "crema_d" / f"alpha{alpha_tok}",
        ]
    elif dataset == "hateful_memes":
        target_features = [
            output_dir / "feature" / "img" / "mobilenet_v2" / "hateful_memes" / f"alpha{alpha_tok}",
            output_dir / "feature" / "text" / "mobilebert" / "hateful_memes" / f"alpha{alpha_tok}",
        ]
    else:
        target_features = [
            output_dir / "feature" / "I_to_AVF" / "ptb-xl" / f"alpha{alpha_tok}",
            output_dir / "feature" / "V1_to_V6" / "ptb-xl" / f"alpha{alpha_tok}",
        ]

    actions: list[str] = []
    ptb_natural_prepared = False
    ptb_alpha_prepared = False

    if include_partition and (force or not target_partition.exists()):
        if dataset == "crema_d":
            actions.append(
                _run_script(
                    repo_root=repo_root,
                    script_rel="fed_multimodal/features/data_partitioning/crema_d/data_partition_alpha.py",
                    script_args=[
                        "--raw_data_dir",
                        str(raw_data_dir),
                        "--output_partition_path",
                        str(output_dir),
                        "--alpha",
                        alpha_script,
                        "--num_clients",
                        str(num_clients),
                        "--dataset",
                        "crema_d",
                    ],
                    dry_run=dry_run,
                )
            )
        elif dataset == "hateful_memes":
            actions.append(
                _run_script(
                    repo_root=repo_root,
                    script_rel="fed_multimodal/features/data_partitioning/hateful_memes/data_partition.py",
                    script_args=[
                        "--raw_data_dir",
                        str(raw_data_dir),
                        "--output_partition_path",
                        str(output_dir),
                        "--alpha",
                        alpha_script,
                        "--num_clients",
                        str(num_clients),
                        "--dataset",
                        "hateful_memes",
                    ],
                    dry_run=dry_run,
                )
            )
        else:
            _ensure_ptb_natural_ready(
                repo_root=repo_root,
                raw_data_dir=raw_data_dir,
                output_dir=output_dir,
                dry_run=dry_run,
                actions=actions,
            )
            ptb_natural_prepared = True
            actions.append(
                _run_script(
                    repo_root=repo_root,
                    script_rel="fed_multimodal/features/data_partitioning/ptb-xl/data_partition_alpha.py",
                    script_args=[
                        "--raw_data_dir",
                        str(raw_data_dir),
                        "--output_dir",
                        str(output_dir),
                        "--alpha",
                        alpha_script,
                        "--num_clients",
                        str(num_clients),
                        "--dataset",
                        "ptb-xl",
                    ],
                    dry_run=dry_run,
                )
            )
            ptb_alpha_prepared = True

    if include_features and (force or not all(_dir_has_pkls(p) for p in target_features)):
        if dataset == "crema_d":
            fold_audio_dir = output_dir / "feature" / "audio" / "mfcc" / "crema_d" / "fold1"
            fold_video_dir = output_dir / "feature" / "video" / "mobilenet_v2" / "crema_d" / "fold1"
            if force or not (_dir_has_pkls(fold_audio_dir) and _dir_has_pkls(fold_video_dir)):
                actions.append(
                    _run_script(
                        repo_root=repo_root,
                        script_rel="fed_multimodal/features/feature_processing/crema_d/extract_audio_feature.py",
                        script_args=[
                            "--raw_data_dir",
                            str(raw_data_dir),
                            "--output_dir",
                            str(output_dir),
                            "--dataset",
                            "crema_d",
                        ],
                        dry_run=dry_run,
                    )
                )
                actions.append(
                    _run_script(
                        repo_root=repo_root,
                        script_rel="fed_multimodal/features/feature_processing/crema_d/extract_frame_feature.py",
                        script_args=[
                            "--raw_data_dir",
                            str(raw_data_dir),
                            "--output_dir",
                            str(output_dir),
                            "--dataset",
                            "crema_d",
                        ],
                        dry_run=dry_run,
                    )
                )
            actions.append(
                _run_script(
                    repo_root=repo_root,
                    script_rel="fed_multimodal/features/feature_processing/crema_d/reorganize_features_alpha.py",
                    script_args=[
                        "--output_dir",
                        str(output_dir),
                        "--alpha",
                        alpha_script,
                        "--dataset",
                        "crema_d",
                    ],
                    dry_run=dry_run,
                )
            )
        elif dataset == "hateful_memes":
            base_alpha = 5.0
            base_tok = alpha_token(base_alpha)
            base_alpha_script = alpha_script_arg(base_alpha)
            base_img_dir = output_dir / "feature" / "img" / "mobilenet_v2" / "hateful_memes" / f"alpha{base_tok}"
            base_txt_dir = output_dir / "feature" / "text" / "mobilebert" / "hateful_memes" / f"alpha{base_tok}"
            base_partition = output_dir / "partition" / "hateful_memes" / f"partition_alpha{base_tok}.json"
            if alpha_tok != base_tok and (
                force or not (base_partition.exists() and _dir_has_pkls(base_img_dir) and _dir_has_pkls(base_txt_dir))
            ):
                actions.append(
                    _run_script(
                        repo_root=repo_root,
                        script_rel="fed_multimodal/features/data_partitioning/hateful_memes/data_partition.py",
                        script_args=[
                            "--raw_data_dir",
                            str(raw_data_dir),
                            "--output_partition_path",
                            str(output_dir),
                            "--alpha",
                            base_alpha_script,
                            "--num_clients",
                            str(num_clients),
                            "--dataset",
                            "hateful_memes",
                        ],
                        dry_run=dry_run,
                    )
                )
                actions.append(
                    _run_script(
                        repo_root=repo_root,
                        script_rel="fed_multimodal/features/feature_processing/hateful_memes/extract_img_feature.py",
                        script_args=[
                            "--raw_data_dir",
                            str(raw_data_dir),
                            "--output_dir",
                            str(output_dir),
                            "--alpha",
                            base_alpha_script,
                            "--dataset",
                            "hateful_memes",
                        ],
                        dry_run=dry_run,
                    )
                )
                actions.append(
                    _run_script(
                        repo_root=repo_root,
                        script_rel="fed_multimodal/features/feature_processing/hateful_memes/extract_text_feature.py",
                        script_args=[
                            "--raw_data_dir",
                            str(raw_data_dir),
                            "--output_dir",
                            str(output_dir),
                            "--alpha",
                            base_alpha_script,
                            "--dataset",
                            "hateful_memes",
                        ],
                        dry_run=dry_run,
                    )
                )

            actions.append(
                _run_script(
                    repo_root=repo_root,
                    script_rel="fed_multimodal/features/feature_processing/hateful_memes/extract_img_feature.py",
                    script_args=[
                        "--raw_data_dir",
                        str(raw_data_dir),
                        "--output_dir",
                        str(output_dir),
                        "--alpha",
                        alpha_script,
                        "--dataset",
                        "hateful_memes",
                    ],
                    dry_run=dry_run,
                )
            )
            actions.append(
                _run_script(
                    repo_root=repo_root,
                    script_rel="fed_multimodal/features/feature_processing/hateful_memes/extract_text_feature.py",
                    script_args=[
                        "--raw_data_dir",
                        str(raw_data_dir),
                        "--output_dir",
                        str(output_dir),
                        "--alpha",
                        alpha_script,
                        "--dataset",
                        "hateful_memes",
                    ],
                    dry_run=dry_run,
                )
            )
        else:
            # PTB-XL alpha features are produced by data_partition_alpha.py
            if force or not all(_dir_has_pkls(p) for p in target_features):
                if not ptb_natural_prepared:
                    _ensure_ptb_natural_ready(
                        repo_root=repo_root,
                        raw_data_dir=raw_data_dir,
                        output_dir=output_dir,
                        dry_run=dry_run,
                        actions=actions,
                    )
                    ptb_natural_prepared = True
                if not ptb_alpha_prepared:
                    actions.append(
                        _run_script(
                            repo_root=repo_root,
                            script_rel="fed_multimodal/features/data_partitioning/ptb-xl/data_partition_alpha.py",
                            script_args=[
                                "--raw_data_dir",
                                str(raw_data_dir),
                                "--output_dir",
                                str(output_dir),
                                "--alpha",
                                alpha_script,
                                "--num_clients",
                                str(num_clients),
                                "--dataset",
                                "ptb-xl",
                            ],
                            dry_run=dry_run,
                        )
                    )
                    ptb_alpha_prepared = True

    if include_simulation and (force or not target_simulation.exists()):
        if dataset == "crema_d":
            actions.append(
                _run_script(
                    repo_root=repo_root,
                    script_rel="fed_multimodal/features/simulation_features/crema_d/simulation_feature_alpha.py",
                    script_args=[
                        "--output_dir",
                        str(output_dir),
                        "--alpha",
                        alpha_script,
                        "--dataset",
                        "crema_d",
                        "--en_missing_modality",
                        "--sample_missing_rate",
                        str(sample_missing_rate),
                        "--modality_missing_rate",
                        str(modality_missing_rate),
                    ],
                    dry_run=dry_run,
                )
            )
        elif dataset == "hateful_memes":
            actions.append(
                _run_script(
                    repo_root=repo_root,
                    script_rel="fed_multimodal/features/simulation_features/hateful_memes/simulation_feature.py",
                    script_args=[
                        "--output_dir",
                        str(output_dir),
                        "--alpha",
                        alpha_script,
                        "--dataset",
                        "hateful_memes",
                        "--en_missing_modality",
                        "--sample_missing_rate",
                        str(sample_missing_rate),
                        "--modality_missing_rate",
                        str(modality_missing_rate),
                    ],
                    dry_run=dry_run,
                )
            )
        else:
            actions.append(
                _run_script(
                    repo_root=repo_root,
                    script_rel="fed_multimodal/features/simulation_features/ptb-xl/simulation_feature_alpha.py",
                    script_args=[
                        "--output_dir",
                        str(output_dir),
                        "--alpha",
                        alpha_script,
                        "--dataset",
                        "ptb-xl",
                        "--en_missing_modality",
                        "--sample_missing_rate",
                        str(sample_missing_rate),
                        "--modality_missing_rate",
                        str(modality_missing_rate),
                    ],
                    dry_run=dry_run,
                )
            )

    return {
        "dataset": dataset,
        "alpha": alpha,
        "sample_missing_rate": sample_missing_rate,
        "modality_missing_rate": modality_missing_rate,
        "repo_root": str(repo_root),
        "output_dir": str(output_dir),
        "raw_data_dir_for_scripts": str(raw_data_dir),
        "targets": {
            "partition": str(target_partition),
            "simulation": str(target_simulation),
            "feature_dirs": [str(p) for p in target_features],
        },
        "actions_executed": actions,
        "actions_count": len(actions),
        "dry_run": dry_run,
    }
