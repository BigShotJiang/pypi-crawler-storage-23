from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .errors import InvalidRequestError
from .registry import V8_SIM_DATASETS

SIMULATION_V8_FILE_RE = re.compile(
    r"^mm_ps(?P<ps>[^_]+)_pm(?P<pm>[^_]+)_alpha(?P<alpha>[^.]+)\.json$"
)


def _to_relpath(root: Path, path: Path) -> str:
    return path.relative_to(root).as_posix()


def _scan_partition_files(root: Path, dataset: str) -> tuple[list[str], set[str]]:
    partition_dir = root / "partition" / dataset
    files: list[str] = []
    alphas: set[str] = set()
    if not partition_dir.exists():
        return files, alphas

    for path in sorted(partition_dir.rglob("*.json")):
        files.append(_to_relpath(root, path))
        name = path.name
        if name.startswith("partition_alpha") and name.endswith(".json"):
            alphas.add(name[len("partition_alpha") : -len(".json")])
    return files, alphas


def _scan_feature_dirs(root: Path, dataset: str) -> tuple[list[str], set[str]]:
    feature_root = root / "feature"
    dirs: list[str] = []
    alphas: set[str] = set()
    if not feature_root.exists():
        return dirs, alphas

    for dataset_dir in feature_root.rglob(dataset):
        if not dataset_dir.is_dir():
            continue
        for alpha_dir in sorted(dataset_dir.glob("alpha*")):
            if not alpha_dir.is_dir():
                continue
            dirs.append(_to_relpath(root, alpha_dir))
            alphas.add(alpha_dir.name[len("alpha") :])
    return sorted(set(dirs)), alphas


def _scan_simulation_files(root: Path, dataset: str) -> tuple[list[str], set[str], set[str], set[str]]:
    simulation_dir = root / "simulation_feature" / dataset
    files: list[str] = []
    alphas: set[str] = set()
    ps_values: set[str] = set()
    pm_values: set[str] = set()
    if not simulation_dir.exists():
        return files, alphas, ps_values, pm_values

    for path in sorted(simulation_dir.rglob("mm_ps*_pm*_alpha*.json")):
        match = SIMULATION_V8_FILE_RE.match(path.name)
        if match is None:
            continue
        files.append(_to_relpath(root, path))
        alphas.add(match.group("alpha"))
        ps_values.add(match.group("ps"))
        pm_values.add(match.group("pm"))
    return files, alphas, ps_values, pm_values


def build_v8_manifest(output_root: str | Path) -> dict[str, Any]:
    root = Path(output_root).expanduser().resolve()
    if not root.exists():
        raise InvalidRequestError(f"Output root does not exist: {root}")
    if not root.is_dir():
        raise InvalidRequestError(f"Output root is not a directory: {root}")

    datasets: dict[str, Any] = {}
    for dataset in V8_SIM_DATASETS:
        partition_files, partition_alphas = _scan_partition_files(root, dataset)
        feature_dirs, feature_alphas = _scan_feature_dirs(root, dataset)
        simulation_files, simulation_alphas, ps_values, pm_values = _scan_simulation_files(root, dataset)

        all_alphas = sorted(partition_alphas | feature_alphas | simulation_alphas)
        datasets[dataset] = {
            "partition_files": partition_files,
            "feature_dirs": feature_dirs,
            "simulation_files": simulation_files,
            "alpha_tokens": all_alphas,
            "sample_missing_rate_tokens": sorted(ps_values),
            "modality_missing_rate_tokens": sorted(pm_values),
            "counts": {
                "partition_files": len(partition_files),
                "feature_dirs": len(feature_dirs),
                "simulation_files": len(simulation_files),
            },
        }

    return {
        "schema_version": 1,
        "contract": "fedms2-v8",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_output_root": str(root),
        "datasets": datasets,
    }


def validate_v8_manifest(manifest: dict[str, Any], require_simulation: bool = True) -> list[str]:
    errors: list[str] = []
    if manifest.get("contract") != "fedms2-v8":
        errors.append("manifest.contract must be 'fedms2-v8'")

    datasets = manifest.get("datasets")
    if not isinstance(datasets, dict):
        errors.append("manifest.datasets must be a dictionary")
        return errors

    expected = set(V8_SIM_DATASETS)
    found = set(datasets.keys())
    missing = expected - found
    extra = found - expected
    if missing:
        errors.append(f"Missing datasets in manifest: {', '.join(sorted(missing))}")
    if extra:
        errors.append(f"Unexpected datasets in manifest: {', '.join(sorted(extra))}")

    for dataset in sorted(expected & found):
        entry = datasets[dataset]
        simulation_files = entry.get("simulation_files", [])
        if require_simulation and not simulation_files:
            errors.append(f"{dataset}: simulation_files is empty")
        for rel in simulation_files:
            name = Path(rel).name
            if SIMULATION_V8_FILE_RE.match(name) is None:
                errors.append(f"{dataset}: invalid simulation filename '{name}'")
    return errors


def list_missing_files(manifest: dict[str, Any], output_root: str | Path) -> list[str]:
    root = Path(output_root).expanduser().resolve()
    missing: list[str] = []
    datasets = manifest.get("datasets", {})
    if not isinstance(datasets, dict):
        return ["manifest.datasets is not a dictionary"]

    for dataset in V8_SIM_DATASETS:
        entry = datasets.get(dataset, {})
        for key in ("partition_files", "feature_dirs", "simulation_files"):
            for rel in entry.get(key, []):
                path = root / rel
                if not path.exists():
                    missing.append(rel)
    return sorted(set(missing))


def write_manifest_json(manifest: dict[str, Any], output_json: str | Path) -> Path:
    path = Path(output_json).expanduser().resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return path


def load_manifest_json(manifest_json: str | Path) -> dict[str, Any]:
    path = Path(manifest_json).expanduser().resolve()
    if not path.exists():
        raise InvalidRequestError(f"Manifest file does not exist: {path}")
    return json.loads(path.read_text(encoding="utf-8"))
