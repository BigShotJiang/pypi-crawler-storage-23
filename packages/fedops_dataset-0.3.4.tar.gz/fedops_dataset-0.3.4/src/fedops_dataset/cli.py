from __future__ import annotations

import argparse
import os

from .archives import build_v8_archives, upload_v8_archives
from .client import FedOpsDatasetClient
from .create import V8_DATASETS, create_v8_local_artifacts
from .fetch_raw import (
    HATEFUL_DEFAULT_HF_REPO_ID,
    HATEFUL_DEFAULT_HF_REVISION,
    fetch_raw_datasets,
)
from .manifest import (
    build_v8_manifest,
    list_missing_files,
    load_manifest_json,
    validate_v8_manifest,
    write_manifest_json,
)
from .uploader import upload_v8_filewise_from_manifest, upload_v8_from_manifest
from .raw_data import raw_data_setup_hints, resolve_raw_dataset_roots, validate_raw_dataset_roots


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="fedops-dataset CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    p_partition = sub.add_parser("partition")
    p_partition.add_argument("--repo-id", required=True, help="HF dataset repo id, e.g. org/repo")
    p_partition.add_argument("--revision", default="main")
    p_partition.add_argument("--root-prefix", default="output")
    p_partition.add_argument("--dataset", required=True)
    p_partition.add_argument("--alpha", type=float, default=None)
    p_partition.add_argument("--partition-type", choices=["noniid", "iid"], default="noniid")
    p_partition.add_argument("--fold", type=int, default=None)

    p_sim = sub.add_parser("simulation")
    p_sim.add_argument("--repo-id", required=True, help="HF dataset repo id, e.g. org/repo")
    p_sim.add_argument("--revision", default="main")
    p_sim.add_argument("--root-prefix", default="output")
    p_sim.add_argument("--dataset", required=True)
    p_sim.add_argument("--alpha", type=float, required=True)
    p_sim.add_argument("--partition-type", choices=["noniid", "iid"], default="noniid")
    p_sim.add_argument("--fold", type=int, default=None)
    p_sim.add_argument("--sample-missing-rate", type=float, required=True)
    p_sim.add_argument("--modality-missing-rate", type=float, required=True)

    p_feat = sub.add_parser("feature-dirs")
    p_feat.add_argument("--repo-id", required=True, help="HF dataset repo id, e.g. org/repo")
    p_feat.add_argument("--revision", default="main")
    p_feat.add_argument("--root-prefix", default="output")
    p_feat.add_argument("--dataset", required=True)
    p_feat.add_argument("--alpha", type=float, required=True)

    p_manifest = sub.add_parser("build-manifest")
    p_manifest.add_argument(
        "--source-output-dir",
        required=True,
        help="Local output root (contains partition/, feature/, simulation_feature/).",
    )
    p_manifest.add_argument("--output-json", required=True, help="Where to write manifest JSON.")
    p_manifest.add_argument(
        "--allow-empty-simulation",
        action="store_true",
        help="Allow datasets with zero simulation files in the generated manifest.",
    )

    p_validate = sub.add_parser("validate-manifest")
    p_validate.add_argument("--manifest-json", required=True, help="Path to manifest JSON file.")
    p_validate.add_argument(
        "--source-output-dir",
        default=None,
        help="Optional local output root to verify every manifest path exists.",
    )
    p_validate.add_argument(
        "--allow-empty-simulation",
        action="store_true",
        help="Do not require simulation files per dataset.",
    )

    p_upload = sub.add_parser("upload-v8")
    p_upload.add_argument("--repo-id", required=True, help="HF dataset repo id, e.g. org/repo")
    p_upload.add_argument(
        "--source-output-dir",
        required=True,
        help="Local output root (contains partition/, feature/, simulation_feature/).",
    )
    p_upload.add_argument("--manifest-json", required=True, help="Manifest JSON path.")
    p_upload.add_argument(
        "--state-json",
        default=".upload_state.v8.json",
        help="Resumable uploader state file.",
    )
    p_upload.add_argument("--max-retries", type=int, default=8)
    p_upload.add_argument("--attempt-timeout-sec", type=int, default=180)
    p_upload.add_argument("--sleep-base-sec", type=int, default=15)

    p_upload_filewise = sub.add_parser("upload-v8-filewise")
    p_upload_filewise.add_argument("--repo-id", required=True, help="HF dataset repo id, e.g. org/repo")
    p_upload_filewise.add_argument(
        "--source-output-dir",
        required=True,
        help="Local output root (contains partition/, feature/, simulation_feature/).",
    )
    p_upload_filewise.add_argument("--manifest-json", required=True, help="Manifest JSON path.")
    p_upload_filewise.add_argument(
        "--state-json",
        default=".upload_state.v8.filewise.json",
        help="Resumable uploader state file.",
    )
    p_upload_filewise.add_argument("--max-retries", type=int, default=20)
    p_upload_filewise.add_argument("--attempt-timeout-sec", type=int, default=120)
    p_upload_filewise.add_argument("--sleep-base-sec", type=int, default=8)
    p_upload_filewise.add_argument(
        "--max-files-per-run",
        type=int,
        default=None,
        help="Optional cap on new files uploaded in one invocation.",
    )

    p_build_archives = sub.add_parser("build-v8-archives")
    p_build_archives.add_argument(
        "--source-output-dir",
        required=True,
        help="Local output root (contains partition/, feature/, simulation_feature/).",
    )
    p_build_archives.add_argument("--manifest-json", required=True, help="Manifest JSON path.")
    p_build_archives.add_argument(
        "--archives-dir",
        required=True,
        help="Local directory where .tar archives and archive manifest will be written.",
    )
    p_build_archives.add_argument(
        "--overwrite",
        action="store_true",
        help="Recreate tar files even if they already exist.",
    )

    p_upload_archives = sub.add_parser("upload-v8-archives")
    p_upload_archives.add_argument("--repo-id", required=True, help="HF dataset repo id, e.g. org/repo")
    p_upload_archives.add_argument("--archives-dir", required=True, help="Directory created by build-v8-archives.")
    p_upload_archives.add_argument(
        "--state-json",
        default=".upload_state.v8.archives.json",
        help="Resumable uploader state file.",
    )
    p_upload_archives.add_argument("--max-retries", type=int, default=20)
    p_upload_archives.add_argument("--attempt-timeout-sec", type=int, default=240)
    p_upload_archives.add_argument("--sleep-base-sec", type=int, default=10)

    p_check_raw = sub.add_parser("check-raw-datasets")
    p_check_raw.add_argument(
        "--data-root",
        default=None,
        help="Base data root containing crema_d and ptb-xl (default: FEDOPS_DATA_ROOT or ./data).",
    )
    p_check_raw.add_argument(
        "--hateful-memes-root",
        default=None,
        help="Explicit hateful_memes root (default: HATEFUL_MEMES_ROOT or <data-root>/hateful_memes).",
    )

    p_fetch_raw = sub.add_parser("fetch-raw")
    p_fetch_raw.add_argument(
        "--dataset",
        choices=["crema_d", "ptb-xl", "hateful_memes", "all"],
        default="all",
        help="Raw dataset to fetch/setup (default: all).",
    )
    p_fetch_raw.add_argument(
        "--data-root",
        default=None,
        help="Target raw data root (default: FEDOPS_DATA_ROOT or ./data).",
    )
    p_fetch_raw.add_argument(
        "--hateful-memes-source-dir",
        default=None,
        help="Prepared hateful_memes source folder. If omitted, package can download from HF repo id.",
    )
    p_fetch_raw.add_argument(
        "--hateful-memes-repo-id",
        default=HATEFUL_DEFAULT_HF_REPO_ID,
        help="HF dataset repo id for hateful_memes auto-download (default: neuralcatcher/hateful_memes).",
    )
    p_fetch_raw.add_argument(
        "--hateful-memes-revision",
        default=HATEFUL_DEFAULT_HF_REVISION,
        help="HF dataset revision for hateful_memes download (default: main).",
    )
    p_fetch_raw.add_argument(
        "--hateful-memes-token-env",
        default="HF_TOKEN",
        help="Environment variable name containing HF token (default: HF_TOKEN).",
    )
    p_fetch_raw.add_argument(
        "--hateful-memes-mode",
        choices=["symlink", "copy"],
        default="symlink",
        help="How to place hateful_memes into data-root (default: symlink).",
    )
    p_fetch_raw.add_argument(
        "--force",
        action="store_true",
        help="Allow overwrite behavior for hateful_memes target setup.",
    )
    p_fetch_raw.add_argument(
        "--dry-run",
        action="store_true",
        help="Print fetch/setup actions without executing them.",
    )

    p_create_v8 = sub.add_parser("create-v8")
    p_create_v8.add_argument("--dataset", required=True, choices=sorted(V8_DATASETS))
    p_create_v8.add_argument("--alpha", type=float, required=True)
    p_create_v8.add_argument("--sample-missing-rate", type=float, required=True)
    p_create_v8.add_argument("--modality-missing-rate", type=float, required=True)
    p_create_v8.add_argument(
        "--repo-root",
        default=None,
        help="Path to fed-multimodal repo root (contains fed_multimodal/). Default: FEDOPS_REPO_ROOT.",
    )
    p_create_v8.add_argument(
        "--output-dir",
        default=None,
        help="Output directory (default: <repo-root>/fed_multimodal/output).",
    )
    p_create_v8.add_argument(
        "--data-root",
        default=None,
        help="Raw data root containing crema_d and ptb-xl (default: FEDOPS_DATA_ROOT or <repo-root>/fed_multimodal/data).",
    )
    p_create_v8.add_argument(
        "--hateful-memes-root",
        default=None,
        help="Explicit hateful_memes raw root (default: HATEFUL_MEMES_ROOT or <data-root>/hateful_memes).",
    )
    p_create_v8.add_argument(
        "--num-clients",
        type=int,
        default=None,
        help="Override client count (defaults: crema_d/hateful_memes=40, ptb-xl=20).",
    )
    p_create_v8.add_argument(
        "--no-partition",
        action="store_true",
        help="Skip partition generation.",
    )
    p_create_v8.add_argument(
        "--no-features",
        action="store_true",
        help="Skip feature generation.",
    )
    p_create_v8.add_argument(
        "--no-simulation",
        action="store_true",
        help="Skip simulation file generation.",
    )
    p_create_v8.add_argument(
        "--force",
        action="store_true",
        help="Regenerate targets even if they already exist.",
    )
    p_create_v8.add_argument(
        "--dry-run",
        action="store_true",
        help="Print script actions without running heavy generation scripts.",
    )

    return parser


def main() -> None:
    parser = _build_parser()
    args = parser.parse_args()

    if args.command == "partition":
        client = FedOpsDatasetClient(
            repo_id=args.repo_id,
            revision=args.revision,
            root_prefix=args.root_prefix,
        )
        ref = client.partition_ref(
            dataset=args.dataset,
            alpha=args.alpha,
            partition_type=args.partition_type,
            fold=args.fold,
        )
        print(ref.path_in_repo)
        return

    if args.command == "simulation":
        client = FedOpsDatasetClient(
            repo_id=args.repo_id,
            revision=args.revision,
            root_prefix=args.root_prefix,
        )
        ref = client.simulation_ref(
            dataset=args.dataset,
            alpha=args.alpha,
            partition_type=args.partition_type,
            fold=args.fold,
            sample_missing_rate=args.sample_missing_rate,
            modality_missing_rate=args.modality_missing_rate,
        )
        print(ref.path_in_repo)
        return

    if args.command == "feature-dirs":
        client = FedOpsDatasetClient(
            repo_id=args.repo_id,
            revision=args.revision,
            root_prefix=args.root_prefix,
        )
        refs = client.feature_dir_refs(dataset=args.dataset, alpha=args.alpha)
        for ref in refs:
            print(ref.path_in_repo)
        return

    if args.command == "build-manifest":
        manifest = build_v8_manifest(args.source_output_dir)
        errors = validate_v8_manifest(
            manifest,
            require_simulation=not args.allow_empty_simulation,
        )
        if errors:
            for error in errors:
                print(f"ERROR: {error}")
            raise SystemExit(2)
        path = write_manifest_json(manifest, args.output_json)
        print(path)
        return

    if args.command == "validate-manifest":
        manifest = load_manifest_json(args.manifest_json)
        errors = validate_v8_manifest(
            manifest,
            require_simulation=not args.allow_empty_simulation,
        )
        if args.source_output_dir is not None:
            missing = list_missing_files(manifest, args.source_output_dir)
            for rel in missing:
                errors.append(f"missing path in source-output-dir: {rel}")

        if errors:
            for error in errors:
                print(f"ERROR: {error}")
            raise SystemExit(2)

        print("OK")
        return

    if args.command == "upload-v8":
        summary = upload_v8_from_manifest(
            repo_id=args.repo_id,
            output_root=args.source_output_dir,
            manifest_json=args.manifest_json,
            state_json=args.state_json,
            max_retries=args.max_retries,
            attempt_timeout_sec=args.attempt_timeout_sec,
            sleep_base_sec=args.sleep_base_sec,
        )
        print(summary)
        return

    if args.command == "upload-v8-filewise":
        summary = upload_v8_filewise_from_manifest(
            repo_id=args.repo_id,
            output_root=args.source_output_dir,
            manifest_json=args.manifest_json,
            state_json=args.state_json,
            max_retries=args.max_retries,
            attempt_timeout_sec=args.attempt_timeout_sec,
            sleep_base_sec=args.sleep_base_sec,
            max_files_per_run=args.max_files_per_run,
        )
        print(summary)
        return

    if args.command == "build-v8-archives":
        summary = build_v8_archives(
            output_root=args.source_output_dir,
            manifest_json=args.manifest_json,
            archives_dir=args.archives_dir,
            overwrite=args.overwrite,
        )
        print(summary)
        return

    if args.command == "upload-v8-archives":
        summary = upload_v8_archives(
            repo_id=args.repo_id,
            archives_dir=args.archives_dir,
            state_json=args.state_json,
            max_retries=args.max_retries,
            attempt_timeout_sec=args.attempt_timeout_sec,
            sleep_base_sec=args.sleep_base_sec,
        )
        print(summary)
        return

    if args.command == "check-raw-datasets":
        roots = resolve_raw_dataset_roots(
            data_root=args.data_root,
            hateful_memes_root=args.hateful_memes_root,
        )
        print(f"data_root={roots.data_root}")
        print(f"crema_d_root={roots.crema_d_root}")
        print(f"ptb_xl_root={roots.ptb_xl_root}")
        print(f"hateful_memes_root={roots.hateful_memes_root}")

        errors = validate_raw_dataset_roots(roots)
        if errors:
            for err in errors:
                print(f"ERROR: {err}")
            print("Hints:")
            for hint in raw_data_setup_hints():
                print(f"- {hint}")
            raise SystemExit(2)
        print("OK")
        return

    if args.command == "fetch-raw":
        hf_token = None
        if args.hateful_memes_token_env:
            hf_token = os.getenv(args.hateful_memes_token_env)
        summary = fetch_raw_datasets(
            dataset=args.dataset,
            data_root=args.data_root,
            hateful_memes_source_dir=args.hateful_memes_source_dir,
            hateful_memes_repo_id=args.hateful_memes_repo_id,
            hateful_memes_revision=args.hateful_memes_revision,
            hateful_memes_hf_token=hf_token,
            hateful_memes_mode=args.hateful_memes_mode,
            force=args.force,
            dry_run=args.dry_run,
        )
        print(summary)
        if summary.get("validation_errors"):
            for err in summary["validation_errors"]:
                print(f"ERROR: {err}")
            raise SystemExit(2)
        return

    if args.command == "create-v8":
        summary = create_v8_local_artifacts(
            dataset=args.dataset,
            alpha=args.alpha,
            sample_missing_rate=args.sample_missing_rate,
            modality_missing_rate=args.modality_missing_rate,
            repo_root=args.repo_root,
            output_dir=args.output_dir,
            data_root=args.data_root,
            hateful_memes_root=args.hateful_memes_root,
            num_clients=args.num_clients,
            include_partition=not args.no_partition,
            include_features=not args.no_features,
            include_simulation=not args.no_simulation,
            force=args.force,
            dry_run=args.dry_run,
        )
        print(summary)
        return

    parser.error(f"Unknown command: {args.command}")


if __name__ == "__main__":
    main()
