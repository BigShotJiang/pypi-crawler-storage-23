from __future__ import annotations

import os
import shutil
import subprocess
import urllib.request
import zipfile
from pathlib import Path
from typing import Any, Literal

from huggingface_hub import snapshot_download

from .errors import InvalidRequestError
from .raw_data import (
    RawDatasetRoots,
    raw_data_setup_hints,
    resolve_raw_dataset_roots,
    validate_raw_dataset_roots,
)

CREMA_D_GIT_URL = "https://github.com/CheyneyComputerScience/CREMA-D.git"
PTB_XL_ZIP_URL = (
    "https://physionet.org/static/published-projects/ptb-xl/"
    "ptb-xl-a-large-publicly-available-electrocardiography-dataset-1.0.3.zip"
)
PTB_XL_ZIP_NAME = "ptb-xl-a-large-publicly-available-electrocardiography-dataset-1.0.3.zip"
PTB_XL_EXTRACTED_DIR = "ptb-xl-a-large-publicly-available-electrocardiography-dataset-1.0.3"

HATEFUL_REQUIRED = ("train.jsonl", "dev_seen.jsonl", "test_seen.jsonl")
HATEFUL_OPTIONAL = ("dev_unseen.jsonl", "test_unseen.jsonl", "LICENSE.txt", "README.md", "valid_images.txt")
HATEFUL_DEFAULT_HF_REPO_ID = "neuralcatcher/hateful_memes"
HATEFUL_DEFAULT_HF_REVISION = "main"


def _run(cmd: list[str], *, cwd: Path | None = None, dry_run: bool = False) -> str:
    cmd_str = " ".join(cmd)
    if dry_run:
        return f"[DRY_RUN] {cmd_str}"
    subprocess.run(cmd, cwd=str(cwd) if cwd else None, check=True)
    return cmd_str


def _remove_path(path: Path, *, dry_run: bool, actions: list[str]) -> None:
    if not path.exists() and not path.is_symlink():
        return
    actions.append(f"{'[DRY_RUN] ' if dry_run else ''}rm -rf {path}")
    if dry_run:
        return
    if path.is_symlink() or path.is_file():
        path.unlink()
        return
    shutil.rmtree(path)


def _ensure_hateful_source(source_dir: Path) -> None:
    if not source_dir.exists():
        raise InvalidRequestError(f"hateful_memes source directory does not exist: {source_dir}")
    if not (source_dir / "img").is_dir():
        raise InvalidRequestError(f"hateful_memes source missing img/: {source_dir}")
    for name in HATEFUL_REQUIRED:
        if not (source_dir / name).is_file():
            raise InvalidRequestError(f"hateful_memes source missing required file '{name}': {source_dir}")


def _download_hateful_memes_from_hf(
    *,
    target_root: Path,
    repo_id: str,
    revision: str,
    hf_token: str | None,
    dry_run: bool,
    actions: list[str],
) -> None:
    allow_patterns = [
        "train.jsonl",
        "dev_seen.jsonl",
        "test_seen.jsonl",
        "dev_unseen.jsonl",
        "test_unseen.jsonl",
        "README*",
        "LICENSE*",
        "valid_images.txt",
        "img/*",
        "img/**/*",
    ]

    if dry_run:
        actions.append(
            f"[DRY_RUN] snapshot_download repo_id={repo_id} repo_type=dataset revision={revision} "
            f"local_dir={target_root} allow_patterns={allow_patterns}"
        )
        return

    target_root.mkdir(parents=True, exist_ok=True)
    snapshot_download(
        repo_id=repo_id,
        repo_type="dataset",
        revision=revision,
        local_dir=str(target_root),
        allow_patterns=allow_patterns,
        token=hf_token,
    )
    actions.append(
        f"snapshot_download repo_id={repo_id} repo_type=dataset revision={revision} local_dir={target_root}"
    )
    _ensure_hateful_source(target_root)


def _fetch_crema_d(data_root: Path, *, force: bool, dry_run: bool, actions: list[str], skipped: list[str]) -> None:
    crema_root = data_root / "crema_d"
    crema_target = crema_root / "CREMA-D"
    audio_dir = crema_target / "AudioWAV"
    video_dir = crema_target / "VideoFlash"

    if audio_dir.is_dir() and video_dir.is_dir():
        if not force:
            skipped.append("crema_d already prepared")
            return
        _remove_path(crema_target, dry_run=dry_run, actions=actions)

    if crema_target.exists() and not force:
        raise InvalidRequestError(
            f"crema_d target exists but is incomplete: {crema_target}. Use --force to recreate."
        )
    if crema_target.exists() and force:
        _remove_path(crema_target, dry_run=dry_run, actions=actions)

    crema_root.mkdir(parents=True, exist_ok=True)
    actions.append(_run(["git", "lfs", "clone", CREMA_D_GIT_URL], cwd=crema_root, dry_run=dry_run))


def _fetch_ptb_xl(data_root: Path, *, force: bool, dry_run: bool, actions: list[str], skipped: list[str]) -> None:
    ptb_root = data_root / "ptb-xl"
    ptb_dir = ptb_root / PTB_XL_EXTRACTED_DIR
    db_direct = ptb_root / "ptbxl_database.csv"
    db_nested = ptb_dir / "ptbxl_database.csv"

    if db_direct.exists() or db_nested.exists():
        if not force:
            skipped.append("ptb-xl already prepared")
            return
        _remove_path(ptb_root, dry_run=dry_run, actions=actions)
        ptb_root.mkdir(parents=True, exist_ok=True)

    if ptb_dir.exists() and not force:
        raise InvalidRequestError(
            f"ptb-xl target exists but no valid database file found: {ptb_dir}. Use --force to recreate."
        )
    if ptb_dir.exists() and force:
        _remove_path(ptb_root, dry_run=dry_run, actions=actions)
        ptb_root.mkdir(parents=True, exist_ok=True)

    zip_path = ptb_root / PTB_XL_ZIP_NAME
    if dry_run:
        actions.append(f"[DRY_RUN] download {PTB_XL_ZIP_URL} -> {zip_path}")
        actions.append(f"[DRY_RUN] unzip {zip_path} -> {ptb_root}")
        return

    ptb_root.mkdir(parents=True, exist_ok=True)
    if not zip_path.exists():
        urllib.request.urlretrieve(PTB_XL_ZIP_URL, zip_path)

    with zipfile.ZipFile(zip_path, "r") as zf:
        zf.extractall(ptb_root)

    actions.append(f"download {PTB_XL_ZIP_URL} -> {zip_path}")
    actions.append(f"unzip {zip_path} -> {ptb_root}")


def _fetch_hateful_memes(
    data_root: Path,
    *,
    source_dir: Path | None,
    repo_id: str | None,
    revision: str,
    hf_token: str | None,
    mode: Literal["symlink", "copy"],
    force: bool,
    dry_run: bool,
    actions: list[str],
    skipped: list[str],
) -> None:
    target_root = data_root / "hateful_memes"
    train_file = target_root / "train.jsonl"
    dev_file = target_root / "dev_seen.jsonl"
    test_file = target_root / "test_seen.jsonl"
    img_dir = target_root / "img"

    if train_file.is_file() and dev_file.is_file() and test_file.is_file() and img_dir.is_dir():
        skipped.append("hateful_memes already prepared")
        return

    if target_root.exists() and any(target_root.iterdir()):
        if force:
            if not dry_run:
                shutil.rmtree(target_root)
            actions.append(f"{'[DRY_RUN] ' if dry_run else ''}rm -rf {target_root}")
        else:
            raise InvalidRequestError(
                f"Target hateful_memes folder is not empty: {target_root}. Use --force or clear manually."
            )

    target_root.mkdir(parents=True, exist_ok=True)

    if source_dir is None:
        if repo_id is None:
            raise InvalidRequestError(
                "hateful_memes setup requires either --hateful-memes-source-dir or --hateful-memes-repo-id."
            )
        _download_hateful_memes_from_hf(
            target_root=target_root,
            repo_id=repo_id,
            revision=revision,
            hf_token=hf_token,
            dry_run=dry_run,
            actions=actions,
        )
        return

    _ensure_hateful_source(source_dir)

    def _materialize(name: str, is_dir: bool = False) -> None:
        src = source_dir / name
        dst = target_root / name
        if not src.exists():
            return
        if dry_run:
            actions.append(f"[DRY_RUN] {mode} {src} -> {dst}")
            return
        if mode == "symlink":
            dst.symlink_to(src.resolve(), target_is_directory=is_dir)
            return
        if is_dir:
            shutil.copytree(src, dst, dirs_exist_ok=True)
        else:
            shutil.copy2(src, dst)

    _materialize("img", is_dir=True)
    for name in HATEFUL_REQUIRED:
        _materialize(name)
    for name in HATEFUL_OPTIONAL:
        _materialize(name)


def fetch_raw_datasets(
    *,
    dataset: Literal["crema_d", "ptb-xl", "hateful_memes", "all"] = "all",
    data_root: str | Path | None = None,
    hateful_memes_source_dir: str | Path | None = None,
    hateful_memes_repo_id: str | None = None,
    hateful_memes_revision: str = HATEFUL_DEFAULT_HF_REVISION,
    hateful_memes_hf_token: str | None = None,
    hateful_memes_mode: Literal["symlink", "copy"] = "symlink",
    force: bool = False,
    dry_run: bool = False,
) -> dict[str, Any]:
    base = Path(data_root or os.getenv("FEDOPS_DATA_ROOT", "data")).expanduser().resolve()
    base.mkdir(parents=True, exist_ok=True)

    source_dir = Path(hateful_memes_source_dir).expanduser().resolve() if hateful_memes_source_dir else None

    selected = ("crema_d", "ptb-xl", "hateful_memes") if dataset == "all" else (dataset,)
    actions: list[str] = []
    skipped: list[str] = []

    if "crema_d" in selected:
        _fetch_crema_d(base, force=force, dry_run=dry_run, actions=actions, skipped=skipped)
    if "ptb-xl" in selected:
        _fetch_ptb_xl(base, force=force, dry_run=dry_run, actions=actions, skipped=skipped)
    if "hateful_memes" in selected:
        _fetch_hateful_memes(
            base,
            source_dir=source_dir,
            repo_id=hateful_memes_repo_id,
            revision=hateful_memes_revision,
            hf_token=hateful_memes_hf_token,
            mode=hateful_memes_mode,
            force=force,
            dry_run=dry_run,
            actions=actions,
            skipped=skipped,
        )

    validation_errors: list[str] = []
    hints: list[str] = []
    if not dry_run:
        roots: RawDatasetRoots = resolve_raw_dataset_roots(data_root=base, hateful_memes_root=(base / "hateful_memes"))
        validation_errors = validate_raw_dataset_roots(roots)
        hints = raw_data_setup_hints()

    return {
        "data_root": str(base),
        "dataset": dataset,
        "selected": list(selected),
        "actions_executed": actions,
        "actions_count": len(actions),
        "skipped": skipped,
        "force": force,
        "dry_run": dry_run,
        "validation_errors": validation_errors,
        "hints": hints,
    }
