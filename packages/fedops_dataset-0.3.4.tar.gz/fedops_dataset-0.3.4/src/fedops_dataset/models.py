from dataclasses import dataclass
from typing import Literal, Optional


@dataclass(frozen=True)
class HubConfig:
    repo_id: str
    repo_type: str = "dataset"
    revision: str = "main"
    root_prefix: str = "output"
    local_cache_dir: Optional[str] = None


@dataclass(frozen=True)
class ArtifactRef:
    repo_id: str
    repo_type: str
    revision: str
    path_in_repo: str
    kind: Literal["file", "directory"] = "file"
