from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class RawDatasetRoots:
    data_root: Path
    crema_d_root: Path
    ptb_xl_root: Path
    hateful_memes_root: Path


def resolve_raw_dataset_roots(
    data_root: str | Path | None = None,
    hateful_memes_root: str | Path | None = None,
) -> RawDatasetRoots:
    """
    Resolve raw dataset roots for local generation flow.

    Resolution order:
    - data root: explicit arg -> FEDOPS_DATA_ROOT -> ./data
    - hateful memes root: explicit arg -> HATEFUL_MEMES_ROOT -> <data_root>/hateful_memes
    """
    base = Path(data_root or os.getenv("FEDOPS_DATA_ROOT", "data")).expanduser().resolve()
    hateful = Path(hateful_memes_root or os.getenv("HATEFUL_MEMES_ROOT", str(base / "hateful_memes"))).expanduser()
    return RawDatasetRoots(
        data_root=base,
        crema_d_root=(base / "crema_d").resolve(),
        ptb_xl_root=(base / "ptb-xl").resolve(),
        hateful_memes_root=hateful.resolve(),
    )


def _ptbxl_has_database(root: Path) -> bool:
    if not root.exists():
        return False
    direct = root / "ptbxl_database.csv"
    nested = root / "ptb-xl-a-large-publicly-available-electrocardiography-dataset-1.0.3" / "ptbxl_database.csv"
    return direct.exists() or nested.exists()


def _crema_has_modalities(root: Path) -> bool:
    crema = root / "CREMA-D"
    return (crema / "AudioWAV").is_dir() and (crema / "VideoFlash").is_dir()


def _hateful_memes_has_minimum(root: Path) -> bool:
    required_files = ["train.jsonl", "dev_seen.jsonl", "test_seen.jsonl"]
    if not (root / "img").is_dir():
        return False
    return all((root / name).is_file() for name in required_files)


def validate_raw_dataset_roots(roots: RawDatasetRoots) -> list[str]:
    errors: list[str] = []

    if not _crema_has_modalities(roots.crema_d_root):
        errors.append(
            f"crema_d not ready at '{roots.crema_d_root}' (expected CREMA-D/AudioWAV and CREMA-D/VideoFlash)."
        )

    if not _ptbxl_has_database(roots.ptb_xl_root):
        errors.append(
            f"ptb-xl not ready at '{roots.ptb_xl_root}' (expected ptbxl_database.csv in root or official nested folder)."
        )

    if not _hateful_memes_has_minimum(roots.hateful_memes_root):
        errors.append(
            f"hateful_memes not ready at '{roots.hateful_memes_root}' (expected img/ and train/dev/test jsonl files)."
        )

    return errors


def raw_data_setup_hints() -> list[str]:
    return [
        "Set FEDOPS_DATA_ROOT to your fed_multimodal data folder (contains crema_d and ptb-xl).",
        "Set HATEFUL_MEMES_ROOT to the exact hateful_memes dataset folder (train.jsonl + img/).",
        "If using this repo layout: run fed_multimodal/data/download_cremad.sh and fed_multimodal/data/download_ptbxl.sh.",
        "For hateful_memes, provide a local prepared folder and point HATEFUL_MEMES_ROOT to it.",
    ]
