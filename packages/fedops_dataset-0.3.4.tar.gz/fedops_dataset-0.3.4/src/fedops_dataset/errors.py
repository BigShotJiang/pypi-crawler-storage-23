class FedOpsDatasetError(Exception):
    """Base package exception."""


class DatasetNotSupportedError(FedOpsDatasetError):
    """Dataset key is unknown."""


class InvalidRequestError(FedOpsDatasetError):
    """Request parameters are inconsistent."""
