from __future__ import annotations

from pathlib import Path
from typing import Iterable

from huggingface_hub import HfApi, create_repo

from .registry import DATASET_REGISTRY, V8_SIM_DATASETS


def create_dataset_repo(repo_id: str, private: bool = False, token: str | None = None) -> str:
    """Create (or reuse) a Hugging Face dataset repo."""
    return create_repo(
        repo_id=repo_id,
        repo_type="dataset",
        private=private,
        exist_ok=True,
        token=token,
    )


def upload_output_tree(
    repo_id: str,
    output_dir: str | Path,
    *,
    token: str | None = None,
    path_in_repo: str = "output",
    allow_patterns: str | list[str] | None = None,
    ignore_patterns: str | list[str] | None = None,
) -> str:
    """
    Upload a local output tree to a dataset repo.

    Typical usage:
    - output/partition
    - output/feature
    - output/simulation_feature
    """
    api = HfApi(token=token)
    return api.upload_folder(
        folder_path=str(output_dir),
        repo_id=repo_id,
        repo_type="dataset",
        path_in_repo=path_in_repo,
        allow_patterns=allow_patterns,
        ignore_patterns=ignore_patterns,
    )


def build_v8_allow_patterns() -> list[str]:
    """Allow-list patterns for FedMS2-v8 artifact publishing."""
    patterns: list[str] = []

    for dataset in V8_SIM_DATASETS:
        patterns.extend(
            [
                f"partition/{dataset}/**",
                f"simulation_feature/{dataset}/mm_ps*_pm*_alpha*.json",
                f"simulation_feature/{dataset}/**/mm_ps*_pm*_alpha*.json",
            ]
        )

        for template in DATASET_REGISTRY[dataset]["feature_dirs"].values():
            feature_prefix = template.format(dataset=dataset, alpha="*")
            patterns.append(f"{feature_prefix}/**")

    return sorted(set(patterns))


def upload_v8_output_tree(
    repo_id: str,
    output_dir: str | Path,
    *,
    token: str | None = None,
    path_in_repo: str = "output",
) -> str:
    """
    Upload only FedMS2-v8 scoped artifacts from local output root.

    Expected local layout under `output_dir`:
    - partition/<dataset>/*
    - feature/.../<dataset>/alpha*/...
    - simulation_feature/<dataset>/mm_ps*_pm*_alpha*.json
    """
    return upload_output_tree(
        repo_id=repo_id,
        output_dir=output_dir,
        token=token,
        path_in_repo=path_in_repo,
        allow_patterns=build_v8_allow_patterns(),
    )


def upload_manifest_json(
    repo_id: str,
    manifest_json: str | Path,
    *,
    token: str | None = None,
    path_in_repo: str = "manifest.v8.json",
) -> str:
    """Upload a generated v8 manifest JSON to the dataset repo root."""
    api = HfApi(token=token)
    return api.upload_file(
        path_or_fileobj=str(manifest_json),
        path_in_repo=path_in_repo,
        repo_id=repo_id,
        repo_type="dataset",
    )
