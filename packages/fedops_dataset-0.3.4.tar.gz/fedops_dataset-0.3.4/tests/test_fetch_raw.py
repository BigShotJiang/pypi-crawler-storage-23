from __future__ import annotations

from pathlib import Path

import pytest

from fedops_dataset.fetch_raw import fetch_raw_datasets


def _make_hateful_source(root: Path) -> Path:
    source = root / "source_hateful"
    (source / "img").mkdir(parents=True, exist_ok=True)
    for name in ("train.jsonl", "dev_seen.jsonl", "test_seen.jsonl"):
        (source / name).write_text("{}", encoding="utf-8")
    return source


def test_fetch_hateful_memes_symlink(tmp_path):
    data_root = tmp_path / "data"
    source = _make_hateful_source(tmp_path)

    summary = fetch_raw_datasets(
        dataset="hateful_memes",
        data_root=data_root,
        hateful_memes_source_dir=source,
        hateful_memes_mode="symlink",
        dry_run=False,
    )

    target = data_root / "hateful_memes"
    assert summary["actions_count"] >= 0
    assert (target / "img").is_dir()
    assert (target / "train.jsonl").is_file()
    assert (target / "dev_seen.jsonl").is_file()
    assert (target / "test_seen.jsonl").is_file()
    assert (target / "train.jsonl").is_symlink()
    assert (target / "img").is_symlink()


def test_fetch_hateful_memes_copy(tmp_path):
    data_root = tmp_path / "data"
    source = _make_hateful_source(tmp_path)

    summary = fetch_raw_datasets(
        dataset="hateful_memes",
        data_root=data_root,
        hateful_memes_source_dir=source,
        hateful_memes_mode="copy",
        dry_run=False,
    )

    target = data_root / "hateful_memes"
    assert summary["actions_count"] >= 0
    assert (target / "train.jsonl").is_file()
    assert not (target / "train.jsonl").is_symlink()
    assert (target / "img").is_dir()
    assert not (target / "img").is_symlink()


def test_fetch_hateful_memes_missing_source_raises(tmp_path):
    with pytest.raises(Exception):
        fetch_raw_datasets(dataset="hateful_memes", data_root=tmp_path / "data")


def test_fetch_hateful_memes_from_hf_repo(monkeypatch, tmp_path):
    data_root = tmp_path / "data"

    def _fake_snapshot_download(*, repo_id, repo_type, revision, local_dir, allow_patterns, token):
        assert repo_id == "neuralcatcher/hateful_memes"
        assert repo_type == "dataset"
        assert revision == "main"
        target = Path(local_dir)
        (target / "img").mkdir(parents=True, exist_ok=True)
        for name in ("train.jsonl", "dev_seen.jsonl", "test_seen.jsonl"):
            (target / name).write_text("{}", encoding="utf-8")
        return str(target)

    monkeypatch.setattr("fedops_dataset.fetch_raw.snapshot_download", _fake_snapshot_download)

    summary = fetch_raw_datasets(
        dataset="hateful_memes",
        data_root=data_root,
        hateful_memes_repo_id="neuralcatcher/hateful_memes",
        hateful_memes_revision="main",
        hateful_memes_hf_token=None,
    )

    target = data_root / "hateful_memes"
    assert summary["actions_count"] >= 1
    assert (target / "img").is_dir()
    assert (target / "train.jsonl").is_file()
    assert (target / "dev_seen.jsonl").is_file()
    assert (target / "test_seen.jsonl").is_file()
