import pytest

from fedops_dataset import FedOpsDatasetClient
from fedops_dataset.errors import InvalidRequestError


def test_partition_ref_alpha():
    c = FedOpsDatasetClient(repo_id="org/repo")
    ref = c.partition_ref("hateful_memes", alpha=0.1)
    assert ref.path_in_repo == "output/partition/hateful_memes/partition_alpha01.json"


def test_partition_ref_alpha_float_parser_safe():
    c = FedOpsDatasetClient(repo_id="org/repo")
    ref = c.partition_ref("hateful_memes", alpha=50.0)
    assert ref.path_in_repo == "output/partition/hateful_memes/partition_alpha50.json"


def test_simulation_ref_ps_pm():
    c = FedOpsDatasetClient(repo_id="org/repo")
    ref = c.simulation_ref(
        dataset="hateful_memes",
        alpha=5.0,
        sample_missing_rate=0.2,
        modality_missing_rate=0.8,
    )
    assert ref.path_in_repo == "output/simulation_feature/hateful_memes/mm_ps02_pm08_alpha50.json"


def test_simulation_ref_alpha_float_parser_safe():
    c = FedOpsDatasetClient(repo_id="org/repo")
    ref = c.simulation_ref(
        dataset="hateful_memes",
        alpha=50.0,
        sample_missing_rate=0.2,
        modality_missing_rate=0.8,
    )
    assert ref.path_in_repo == "output/simulation_feature/hateful_memes/mm_ps02_pm08_alpha50.json"


def test_feature_dirs_ptb():
    c = FedOpsDatasetClient(repo_id="org/repo")
    refs = c.feature_dir_refs("ptb-xl", alpha=0.1)
    got = {r.path_in_repo for r in refs}
    assert "output/feature/I_to_AVF/ptb-xl/alpha01" in got
    assert "output/feature/V1_to_V6/ptb-xl/alpha01" in got


def test_simulation_ref_rejects_non_v8_dataset():
    c = FedOpsDatasetClient(repo_id="org/repo")
    with pytest.raises(InvalidRequestError):
        c.simulation_ref(
            dataset="mm-imdb",
            alpha=0.1,
            sample_missing_rate=0.2,
            modality_missing_rate=0.8,
        )
