from fedops_dataset.naming import alpha_script_arg, alpha_token


def test_alpha_token_legacy_values():
    assert alpha_token(0.1) == "01"
    assert alpha_token(5.0) == "50"


def test_alpha_token_float_parser_safe():
    assert alpha_token(50.0) == "50"
    assert alpha_token("50.0") == "50"


def test_alpha_script_arg_normalization():
    assert alpha_script_arg(0.1) == "0.1"
    assert alpha_script_arg(5.0) == "5.0"
    assert alpha_script_arg(50.0) == "5.0"
