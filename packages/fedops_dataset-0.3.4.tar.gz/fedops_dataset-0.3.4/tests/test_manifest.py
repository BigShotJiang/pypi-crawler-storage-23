from __future__ import annotations

from fedops_dataset.manifest import build_v8_manifest, validate_v8_manifest
from fedops_dataset.publish import build_v8_allow_patterns


def test_build_v8_manifest_collects_only_alpha_simulation_files(tmp_path):
    output = tmp_path / "output"
    (output / "partition" / "hateful_memes").mkdir(parents=True)
    (output / "partition" / "hateful_memes" / "partition_alpha01.json").write_text("{}", encoding="utf-8")
    (output / "feature" / "img" / "mobilenet_v2" / "hateful_memes" / "alpha01").mkdir(parents=True)
    (output / "simulation_feature" / "hateful_memes").mkdir(parents=True)
    (output / "simulation_feature" / "hateful_memes" / "mm_ps02_pm08_alpha01.json").write_text(
        "{}",
        encoding="utf-8",
    )
    (output / "simulation_feature" / "hateful_memes" / "mm_ps02_pm08.json").write_text(
        "{}",
        encoding="utf-8",
    )

    manifest = build_v8_manifest(output)
    entry = manifest["datasets"]["hateful_memes"]
    assert "simulation_feature/hateful_memes/mm_ps02_pm08_alpha01.json" in entry["simulation_files"]
    assert "simulation_feature/hateful_memes/mm_ps02_pm08.json" not in entry["simulation_files"]
    assert entry["sample_missing_rate_tokens"] == ["02"]
    assert entry["modality_missing_rate_tokens"] == ["08"]
    assert entry["alpha_tokens"] == ["01"]


def test_validate_v8_manifest_errors_when_simulation_missing(tmp_path):
    output = tmp_path / "output"
    (output / "partition" / "crema_d").mkdir(parents=True)
    (output / "partition" / "crema_d" / "partition_alpha01.json").write_text("{}", encoding="utf-8")

    manifest = build_v8_manifest(output)
    errors = validate_v8_manifest(manifest, require_simulation=True)
    assert any("crema_d: simulation_files is empty" in error for error in errors)


def test_build_v8_allow_patterns_contains_only_v8_dataset_patterns():
    patterns = build_v8_allow_patterns()
    assert any("simulation_feature/crema_d/mm_ps" in pattern for pattern in patterns)
    assert any("simulation_feature/hateful_memes/mm_ps" in pattern for pattern in patterns)
    assert any("simulation_feature/ptb-xl/mm_ps" in pattern for pattern in patterns)
    assert not any("simulation_feature/mm-imdb" in pattern for pattern in patterns)
