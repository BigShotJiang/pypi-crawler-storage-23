from __future__ import annotations

import json
import tarfile
from pathlib import Path

from fedops_dataset.archives import (
    ARCHIVE_CHECKSUM_FILENAME,
    ARCHIVE_MANIFEST_FILENAME,
    build_v8_archives,
    find_archive_for_path,
    load_archive_manifest,
)
from fedops_dataset.client import FedOpsDatasetClient
from fedops_dataset.models import ArtifactRef


def test_build_v8_archives_and_lookup(tmp_path):
    output = tmp_path / "output"
    (output / "partition" / "crema_d").mkdir(parents=True)
    (output / "partition" / "crema_d" / "partition_alpha01.json").write_text("{}", encoding="utf-8")
    (output / "simulation_feature" / "crema_d").mkdir(parents=True)
    (output / "simulation_feature" / "crema_d" / "mm_ps02_pm08_alpha01.json").write_text("{}", encoding="utf-8")
    (output / "feature" / "audio" / "mfcc" / "crema_d" / "alpha01").mkdir(parents=True)
    (output / "feature" / "audio" / "mfcc" / "crema_d" / "alpha01" / "0.pkl").write_text("abc", encoding="utf-8")

    manifest = {
        "contract": "fedms2-v8",
        "datasets": {
            "crema_d": {
                "partition_files": ["partition/crema_d/partition_alpha01.json"],
                "feature_dirs": ["feature/audio/mfcc/crema_d/alpha01"],
                "simulation_files": ["simulation_feature/crema_d/mm_ps02_pm08_alpha01.json"],
            }
        },
    }
    manifest_path = tmp_path / "manifest.v8.json"
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")

    archives_dir = tmp_path / "archives"
    summary = build_v8_archives(output_root=output, manifest_json=manifest_path, archives_dir=archives_dir)
    assert summary["archives_count"] == 3
    assert (archives_dir / ARCHIVE_MANIFEST_FILENAME).exists()
    assert (archives_dir / ARCHIVE_CHECKSUM_FILENAME).exists()

    archive_manifest = load_archive_manifest(archives_dir / ARCHIVE_MANIFEST_FILENAME)
    entry = find_archive_for_path(archive_manifest, "output/partition/crema_d/partition_alpha01.json")
    assert entry is not None
    assert entry["path_in_repo"].startswith("archives/")

    first_tar = archives_dir / entry["name"]
    with tarfile.open(first_tar, "r") as tar:
        names = tar.getnames()
    assert any(name.startswith("output/partition/crema_d") for name in names)


def test_download_with_archive_fallback(monkeypatch, tmp_path):
    cache = tmp_path / "cache"
    cache.mkdir(parents=True)

    src = tmp_path / "src"
    (src / "output" / "partition" / "crema_d").mkdir(parents=True)
    payload = src / "output" / "partition" / "crema_d" / "partition_alpha01.json"
    payload.write_text("{}", encoding="utf-8")

    tar_path = tmp_path / "partition__crema_d.tar"
    with tarfile.open(tar_path, "w") as tar:
        tar.add(src / "output" / "partition" / "crema_d", arcname="output/partition/crema_d")

    archive_manifest = {
        "contract": "fedms2-v8-archive",
        "archives": [
            {
                "name": "partition__crema_d.tar",
                "path_in_repo": "archives/partition__crema_d.tar",
                "contains_prefixes": ["output/partition/crema_d/"],
            }
        ],
    }
    archive_manifest_path = tmp_path / "archive_manifest.v8.json"
    archive_manifest_path.write_text(json.dumps(archive_manifest), encoding="utf-8")

    def fake_hf_hub_download(*, filename: str, **kwargs):
        if filename == "archive_manifest.v8.json":
            return str(archive_manifest_path)
        if filename == "archives/partition__crema_d.tar":
            return str(tar_path)
        raise AssertionError(filename)

    client = FedOpsDatasetClient(repo_id="org/repo")
    monkeypatch.setattr("fedops_dataset.client.hf_hub_download", fake_hf_hub_download)

    def always_fail(ref, local_dir=None):
        raise RuntimeError("primary download failed")

    monkeypatch.setattr(client, "download", always_fail)

    ref = ArtifactRef(
        repo_id="org/repo",
        repo_type="dataset",
        revision="main",
        path_in_repo="output/partition/crema_d/partition_alpha01.json",
        kind="file",
    )
    out = client.download_with_archive_fallback(ref, local_dir=str(cache))
    assert out.exists()
    assert out.read_text(encoding="utf-8") == "{}"
