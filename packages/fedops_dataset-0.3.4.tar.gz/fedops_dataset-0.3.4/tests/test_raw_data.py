from __future__ import annotations

from fedops_dataset.raw_data import resolve_raw_dataset_roots, validate_raw_dataset_roots


def test_resolve_raw_roots_uses_hateful_override(tmp_path):
    data_root = tmp_path / "data"
    hateful_override = tmp_path / "hm"
    roots = resolve_raw_dataset_roots(data_root=data_root, hateful_memes_root=hateful_override)
    assert roots.crema_d_root == (data_root / "crema_d").resolve()
    assert roots.ptb_xl_root == (data_root / "ptb-xl").resolve()
    assert roots.hateful_memes_root == hateful_override.resolve()


def test_validate_raw_roots_passes_minimum_layout(tmp_path):
    data = tmp_path / "data"
    crema = data / "crema_d" / "CREMA-D"
    (crema / "AudioWAV").mkdir(parents=True)
    (crema / "VideoFlash").mkdir(parents=True)

    ptb_nested = data / "ptb-xl" / "ptb-xl-a-large-publicly-available-electrocardiography-dataset-1.0.3"
    ptb_nested.mkdir(parents=True)
    (ptb_nested / "ptbxl_database.csv").write_text("id", encoding="utf-8")

    hm = data / "hateful_memes"
    hm.mkdir(parents=True)
    (hm / "img").mkdir()
    (hm / "train.jsonl").write_text("{}", encoding="utf-8")
    (hm / "dev_seen.jsonl").write_text("{}", encoding="utf-8")
    (hm / "test_seen.jsonl").write_text("{}", encoding="utf-8")

    roots = resolve_raw_dataset_roots(data_root=data)
    errors = validate_raw_dataset_roots(roots)
    assert errors == []


def test_validate_raw_roots_reports_missing(tmp_path):
    roots = resolve_raw_dataset_roots(data_root=tmp_path / "missing_data")
    errors = validate_raw_dataset_roots(roots)
    assert len(errors) == 3
