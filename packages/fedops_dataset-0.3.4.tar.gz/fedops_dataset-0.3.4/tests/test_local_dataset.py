from __future__ import annotations

import json
from pathlib import Path

from fedops_dataset.local import FedOpsLocalDataset


def _touch_pkl(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(b"PKL")


def test_local_dataset_paths_and_loaders_hateful_memes(tmp_path):
    output = tmp_path / "output"
    dataset = "hateful_memes"

    partition = output / "partition" / dataset / "partition_alpha01.json"
    simulation = output / "simulation_feature" / dataset / "mm_ps02_pm08_alpha01.json"
    partition.parent.mkdir(parents=True, exist_ok=True)
    simulation.parent.mkdir(parents=True, exist_ok=True)

    partition.write_text(json.dumps({"0": [[1], [2]], "dev": [], "test": []}), encoding="utf-8")
    simulation.write_text(json.dumps({"0": [[3], [4]], "dev": [], "test": []}), encoding="utf-8")

    _touch_pkl(output / "feature" / "img" / "mobilenet_v2" / dataset / "alpha01" / "0.pkl")
    _touch_pkl(output / "feature" / "text" / "mobilebert" / dataset / "alpha01" / "0.pkl")

    ds = FedOpsLocalDataset(
        dataset=dataset,
        alpha=0.1,
        sample_missing_rate=0.2,
        modality_missing_rate=0.8,
        repo_root=tmp_path / "repo_root_unused_for_load",
        output_dir=output,
    )

    paths = ds.artifact_paths()
    assert paths["partition"] == partition
    assert paths["simulation"] == simulation
    assert ds.is_prepared()
    assert ds.client_ids() == ["0"]
    assert ds.client_records(0, use_simulation=True) == [[3], [4]]
    assert ds.client_records("0", use_simulation=False) == [[1], [2]]


def test_local_dataset_paths_ptbxl(tmp_path):
    output = tmp_path / "output"
    ds = FedOpsLocalDataset(
        dataset="ptb-xl",
        alpha=5.0,
        sample_missing_rate=1.0,
        modality_missing_rate=0.2,
        repo_root=tmp_path / "repo_root_unused_for_load",
        output_dir=output,
    )
    paths = ds.artifact_paths()
    assert str(paths["partition"]).endswith("partition/ptb-xl/partition_alpha50.json")
    assert str(paths["simulation"]).endswith("simulation_feature/ptb-xl/mm_ps10_pm02_alpha50.json")
    assert len(paths["feature_dirs"]) == 2


def test_local_dataset_paths_alpha_float_parser_safe(tmp_path):
    output = tmp_path / "output"
    ds = FedOpsLocalDataset(
        dataset="crema_d",
        alpha=50.0,
        sample_missing_rate=0.2,
        modality_missing_rate=0.2,
        output_dir=output,
    )
    paths = ds.artifact_paths()
    assert str(paths["partition"]).endswith("partition/crema_d/partition_alpha50.json")
    assert str(paths["simulation"]).endswith("simulation_feature/crema_d/mm_ps02_pm02_alpha50.json")


def test_local_dataset_from_runtime_config_and_node_mode(tmp_path):
    run_config = {
        "repo-root": str(tmp_path / "repo"),
        "output-dir": str(tmp_path / "output"),
        "data-root": str(tmp_path / "data"),
        "hateful-memes-root": str(tmp_path / "hm"),
        "num-clients": 40,
    }
    node_config = {"partition-id": 3, "num-partitions": 10}

    ds = FedOpsLocalDataset.from_runtime_config(
        dataset="crema_d",
        alpha=0.1,
        sample_missing_rate=0.2,
        modality_missing_rate=0.2,
        run_config=run_config,
        node_config=node_config,
    )

    assert ds.node_mode(node_config) == "simulation"
    assert ds.repo_root == (tmp_path / "repo").resolve()
    assert ds.output_dir == (tmp_path / "output").resolve()
    assert ds.data_root == (tmp_path / "data").resolve()
    assert ds.hateful_memes_root == (tmp_path / "hm").resolve()


def test_client_records_from_node_config(tmp_path):
    output = tmp_path / "output"
    dataset = "hateful_memes"

    partition = output / "partition" / dataset / "partition_alpha01.json"
    simulation = output / "simulation_feature" / dataset / "mm_ps02_pm08_alpha01.json"
    partition.parent.mkdir(parents=True, exist_ok=True)
    simulation.parent.mkdir(parents=True, exist_ok=True)

    partition.write_text(json.dumps({"0": [[1]], "dev": [], "test": []}), encoding="utf-8")
    simulation.write_text(json.dumps({"0": [[2]], "dev": [], "test": []}), encoding="utf-8")
    _touch_pkl(output / "feature" / "img" / "mobilenet_v2" / dataset / "alpha01" / "0.pkl")
    _touch_pkl(output / "feature" / "text" / "mobilebert" / dataset / "alpha01" / "0.pkl")

    ds = FedOpsLocalDataset(
        dataset=dataset,
        alpha=0.1,
        sample_missing_rate=0.2,
        modality_missing_rate=0.8,
        output_dir=output,
    )

    assert ds.client_records_from_node_config({"partition-id": 0}) == [[2]]
    assert ds.client_records_from_node_config({"client-id": 0}, use_simulation=False) == [[1]]
