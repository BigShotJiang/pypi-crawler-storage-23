"""Helper functions for processing search input into form accepted by `Metastore.search`."""

import itertools
from typing import Any, cast, TypeVar, overload
from collections.abc import Callable

import numpy as np

from openghg.util import extract_float
from openghg.types import Comparable

T = TypeVar("T", bound=Comparable)  # types with <=


def _in_interval(x: T, start: T | None, stop: T | None) -> bool:
    """Return True if start <= x <= stop; if either start or stop is None, omit
    the corresponding bound.

    Args:
        x: value to test for inclusion in the interval [start, stop]
        start: start of the interval
        stop: end of the interval

    Returns:
        True if start <= x <= stop, False otherwise
    """
    if start is None and stop is None:
        return True
    elif start is None:
        stop = cast(T, stop)  # to appease mypy
        return x <= stop
    elif stop is None:
        return x >= start
    else:
        return start <= x <= stop


def _convert_slice_to_test(s: slice, key: str | None = None) -> Callable:
    """Convert slice to a function that checks if values are in the interval specified by the slice.

    Args:
        s: slice specifying interval of values
        key: optional metadata key, used to choose value formatting

    Returns:
        function that returns True if values are in the slice interval
    """

    def formatter(x: Any) -> Any:
        """Formatting if key == 'inlet': try to extract float from strings."""
        if key in ("inlet", "height", "inlet_height_magl", "station_height_masl"):
            if isinstance(x, (int, float)):
                return x
            if isinstance(x, str):
                try:
                    result = extract_float(x)
                except ValueError:
                    return None
                else:
                    return result
            return None
        return x  # 'inlet' type of key not matched

    def test_func(x: Any) -> bool:
        """Return True if start <= formatter(x) <= stop."""
        return _in_interval(formatter(x), formatter(s.start), formatter(s.stop))  # type: ignore

    return test_func


def _is_neg_lookup_flag(x: Any) -> bool:
    """Check if x matches the `neg_lookup_flag`."""
    try:
        result = bool(np.isnan(x))
    except TypeError:
        return False
    return result


def process_special_queries(search_terms: dict, list_search: list | None = None) -> dict:
    """Separate 'function queries' and 'negative lookup keys' from normal search terms.

    Function queries apply a function to the value stored at a given key.
    Negative lookup keys are keys whose value is np.nan (or `float("nan")`).

    Args:
        search_terms: dict of search terms
        list_search: Keys which we expect to be a stored as a list and so should
            search for entries in a list rather than exact matches.
    Returns:
        dict containing search_terms dict, search_functions dict, and negative_lookup_keys list, which
        are the parameters for TinyDBMetastore.search
    """
    _search_terms = search_terms.copy()  # copy to avoid mutating search_terms while iterating over items
    search_functions = {}
    negative_lookup_keys = []
    search_list_keys = {}

    if list_search is None:
        list_search = []

    for k, v in search_terms.items():
        if k in list_search:
            search_list_keys[k] = v
            del _search_terms[k]
        elif isinstance(v, slice):
            search_functions[k] = _convert_slice_to_test(v, key=k)
            del _search_terms[k]
        elif _is_neg_lookup_flag(v):
            negative_lookup_keys.append(k)
            del _search_terms[k]

    return {
        "search_terms": _search_terms,
        "search_list_keys": search_list_keys,
        "search_functions": search_functions,
        "negative_lookup_keys": negative_lookup_keys,
    }


def flatten_search_kwargs(search_kwargs: dict, list_search: list | None = None) -> list[dict]:
    """Process search kwargs into list of flat dictionaries with the correct combinations of search queries.

    To set this up for keywords with multiple options, lists of the (key, value) pair terms are created.

    For instance, if

        species = ["ch4", "methane"]

    and

        time_resolution = {"time_resolved": "true", "high_time_resolution: "true"}

    we expect this to create search options to look for: "species" as "ch4" OR "methane" AND
    either "time_resolved" as "true" OR "high_time_resolution" as "true".

    Args:
        search_kwargs: dictionary of search terms
        list_search: Keys which we expect to be a stored as a list and so should
            search for entries in a list rather than exact matches.
    Returns:
        list of flat dictionaries containing all combinations of search terms from (nested) input search terms
    """

    if list_search is None:
        list_search = []

    single_options = {}

    # multiple_options will contain tuple pairs for the options we wish to search for. e.g. for
    # species = ["ch4", "methane"], time_resolution = {"time_resolved": "true", "high_time_resolution: "true"}
    # multiple_options is: [[("species", "ch4"), ("species", "methane")],
    #                       [("time_resolved": "true"), ("high_time_resolution": "true")]]
    multiple_options = []

    for k, v in search_kwargs.items():
        if isinstance(v, (list, tuple)) and k not in list_search:
            expand_key_values = [(k, value) for value in v]
            multiple_options.append(expand_key_values)
        elif isinstance(v, dict):
            expand_key_values = list(v.items())
            multiple_options.append(expand_key_values)
        else:
            single_options[k] = v

    expanded_search = []
    if multiple_options:
        # Ensure that all permutations of the search options are created.
        for kv_pair in itertools.product(*multiple_options):
            d = dict(kv_pair)
            if single_options:
                d.update(single_options)
            expanded_search.append(d)
    else:
        expanded_search.append(single_options)

    return expanded_search


def process_search_kwargs(search_kwargs: dict, list_search: list | None = None) -> list[dict]:
    """Flatten search kwargs and process species queries.

    Args:
        search_kwargs: dictionary of search terms
        list_search: Keys which we expect to be a stored as a list and so should
            search for entries in a list rather than exact matches.
    Returns:
        dict: Search set up details
    """
    expanded_search = flatten_search_kwargs(search_kwargs, list_search=list_search)
    return [process_special_queries(x, list_search=list_search) for x in expanded_search]


def define_list_search() -> list:
    """
    Define the metakeys we would expect to perform a list search for.

    Returns:
        list: Keys which should be searched as a list rather than an exact match

    TODO: At the moment this just looks for the informational keys but could be expanded
        to include additional metakeys as appropriate.
    """
    from openghg.store import find_info_list_metakeys

    list_search = find_info_list_metakeys()
    return list_search


@overload
def convert_to_slice(input: str | float | int | slice, rel_tolerance: float = 1e-6) -> slice | str: ...


@overload
def convert_to_slice(input: None, rel_tolerance: float = 1e-6) -> None: ...


@overload
def convert_to_slice(
    input: list[str | slice | None], rel_tolerance: float = 1e-6
) -> list[slice | str | None]: ...


def convert_to_slice(
    input: int | float | str | slice | None | list[str | slice | None], rel_tolerance: float = 1e-6
) -> slice | str | None | list[slice | str | None]:
    """
    Convert input into a slice with within the centre of a relative tolerance.

    Args:
        input : Input value to convert to a slice.
        rel_tolerance: Relative tolerance to allow for the slice. This will be set as
            - lower = input - input * rel_tolerance / 2
            - upper = input + input * rel_tolerance / 2
            The rules of slice means lower is inclusive and upper is exclusive.
    Returns:
        slice: Slice object representing the range described
        None: if None is passed this will return a None
    """

    if input is None:
        return None

    if isinstance(input, slice):
        return input

    if isinstance(input, list):
        return [convert_to_slice(x) for x in input]

    if isinstance(input, str):
        # Check if this is a special keyword that should not be converted to a slice
        # These are special inlet values like "column" (for satellite data) or "multiple"
        special_keywords = ["multiple", "column"]
        if input in special_keywords:
            return input

        input = extract_float(input)

    lower = input - input * rel_tolerance / 2
    upper = input + input * rel_tolerance / 2

    s = slice(lower, upper)

    return s
