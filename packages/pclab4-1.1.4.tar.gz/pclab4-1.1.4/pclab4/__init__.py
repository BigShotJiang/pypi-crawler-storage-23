'''
pclab4
======

A Python Library of pedal curves.

How to use
----------
We recommend you to import `pclab4`:\n
  >>> import pclab4
  >>> pclab4.deriv(lambda x: x**3, 2)
  
  
Use the built-in ``help`` function to view a function's docstring:\n
  >>> help(pclab4.deriv)
  ... # doctest: +SKIP
  
'''
from .basic import deriv, PC
from .pcplot import plot
from .pcanim import anim
from .license import mit_license, myinfo
from .install import my_setup

__version__ = '1.1.4'