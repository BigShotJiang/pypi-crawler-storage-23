'''This is a module of the library PCPyLib for animating Pedal Curves.'''

from .basic import PC
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

def anim(n, fx_str3):
    '''This is a function for animating pedal curves. 

       Parameters
       ----------
       n : num of the figure\n
       fx_str3 : str
       
       Returns
       -------
       the figure'''
    dt = 1/15
    fig = plt.figure(n, figsize=(15, 5))
    ax = fig.add_subplot(111)
    fig.subplots_adjust(bottom=0.2)
    ax.set_xlabel('x')
    ax.set_ylabel('y')
    def animate(i):
        plt.clf()
        t = float(i)*dt
        lim = t - 30
        p = PC(fx_str3, lim, lim)
        ax.set_xlim(lim-50, lim+50)
        ax.set_ylim(lim-0.3, lim+0.3)
        line, = ax.plot(p.x, p.y, color='C0')
        return line,
    ani = FuncAnimation(fig, func=animate, frames=range(720), interval=dt, 
                        blit=True)
    fig.show()
    return