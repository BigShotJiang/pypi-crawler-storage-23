'''This is a module of the library PCPyLib for plotting Pedal Curves.'''

from .basic import PC
import matplotlib.pyplot as plt

def plot(n, fx_str2, px2, py2):
    '''This is a function for plotting pedal curves. 

       Parameters
       ----------
       n : num of the figure\n
       fx_str2 : str\n
       px2, py2 : num

       Returns
       -------
       the figure'''
    fig = plt.figure(n, figsize=(5, 2))
    p = PC(fx_str2, px2, py2)
    ax1 = fig.add_subplot(1, 2, 1)
    ax1.plot(p.a, p.b)
    ax2 = fig.add_subplot(1, 2, 2)
    ax2.plot(p.x, p.y)
## texts ##
    plt.rc('mathtext', fontset='stix')
    ax1.text(1, 1, r'$y = {}$'.format(fx_str2), fontsize=15, ha='right', 
             va='top', transform=ax1.transAxes)
    ax2.text(1, 1, r'${}$'.format("Pedal Curves"), fontsize=10, ha='right', 
             va='top', transform=ax2.transAxes)
    ax2.text(1, 0.9, r'$Px = {}$'.format(px2), fontsize=10, ha='right', 
             va='top', transform=ax2.transAxes)
    ax2.text(1, 0.8, r'$Py = {}$'.format(py2),fontsize=10, ha='right', 
             va='top', transform=ax2.transAxes)
    fig.show()
    return

