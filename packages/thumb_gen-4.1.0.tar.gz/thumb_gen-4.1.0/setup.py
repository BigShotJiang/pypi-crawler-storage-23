import pathlib
import os

from setuptools import setup, find_packages

here = pathlib.Path(__file__).parent.resolve()

# Read the version safely without importing the package
version_dict = {}
with open(os.path.join(here, "thumb_gen", "version.py")) as fp:
    exec(fp.read(), version_dict)
__version__ = version_dict["__version__"]

long_description = (here / 'README.md').read_text(encoding='utf-8')

setup(
    name="thumb_gen",
    version=__version__,
    description="Python application that can be used to generate video thumbnail for mp4 and mkv file types.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="tharindu.dev",
    author_email="tharindu.nm@yahoo.com",
    url="https://github.com/truethari/thumb-gen",
    keywords="thumbnails video screenshot",
    license='MIT',
    project_urls={
        "Bug Tracker": "https://github.com/truethari/thumb-gen/issues",
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
    packages=['thumb_gen'],
    include_package_data=True,
    package_data = {'' : ['fonts/*.ttf']},
    install_requires=["Pillow>=11.0.0", "infomedia>=1.0.2", "opencv-python>=4.13.0"],
    entry_points={
        "console_scripts": [
            "thumb-gen=thumb_gen.__main__:main",
        ]
    },
)
