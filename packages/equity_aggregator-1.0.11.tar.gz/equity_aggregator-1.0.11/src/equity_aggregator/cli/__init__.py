# cli/__init__.py

from .main import main

__all__ = ["main"]
