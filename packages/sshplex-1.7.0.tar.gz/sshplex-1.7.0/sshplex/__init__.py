"""SSHplex - SSH Connection Multiplexer"""
__version__ = "1.7.0"
__author__ = "MJAHED Sabri"
__email__ = "contact@sabrimjahed.com"
