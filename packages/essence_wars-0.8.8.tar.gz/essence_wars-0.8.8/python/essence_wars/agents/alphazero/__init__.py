"""AlphaZero training for Essence Wars.

This module provides:
- NeuralMCTS: MCTS guided by neural network policy and value
- AlphaZeroTrainer: Self-play training loop with replay buffer

Key differences from vanilla MCTS:
- Prior probabilities from policy network (not uniform)
- Leaf evaluation from value network (not rollout)
- PUCT selection formula for exploration-exploitation

Based on the AlphaZero paper (Silver et al., 2017).
"""

from .buffer import DualReplayBuffer, ReplayBuffer, ReplaySample
from .config import AlphaZeroConfig
from .mcts import MCTSNode, NeuralMCTS
from .trainer import AlphaZeroTrainer

__all__ = [
    "AlphaZeroConfig",
    "AlphaZeroTrainer",
    "DualReplayBuffer",
    "MCTSNode",
    "NeuralMCTS",
    "ReplayBuffer",
    "ReplaySample",
]
