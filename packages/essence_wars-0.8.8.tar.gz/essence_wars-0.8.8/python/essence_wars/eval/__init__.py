"""Unified evaluation for Essence Wars agents.

This module provides a unified CLI for evaluating both neural network agents
and algorithmic bots (Greedy, MCTS, AlphaBeta) against each other.

Example:
    # From command line
    uv run python -m essence_wars.eval --agents ppo-generalist greedy mcts-100

    # Programmatically
    from essence_wars.eval import UnifiedEvaluator
    evaluator = UnifiedEvaluator()
    results = evaluator.evaluate(["ppo-generalist", "greedy", "mcts-100"])

CLI Usage:
    # Evaluate neural agents against algorithmic bots
    uv run python -m essence_wars.eval --agents ppo-generalist greedy mcts-100

    # Run quick validation suite
    uv run python -m essence_wars.eval --preset validate

    # Full benchmark
    uv run python -m essence_wars.eval --preset benchmark
"""

from .unified import UnifiedEvaluator, parse_agent_spec

__all__ = [
    "UnifiedEvaluator",
    "parse_agent_spec",
]
