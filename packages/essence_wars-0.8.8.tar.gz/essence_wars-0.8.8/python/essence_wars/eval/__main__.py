"""Entry point for python -m essence_wars.eval."""

import sys

from .cli import main

if __name__ == "__main__":
    sys.exit(main())
