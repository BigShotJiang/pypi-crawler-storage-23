"""Asset loading utilities for HTML reports."""

from importlib import resources


def get_css() -> str:
    """Load the CSS stylesheet."""
    return resources.files(__package__).joinpath("styles.css").read_text()


def get_js() -> str:
    """Load the JavaScript file."""
    return resources.files(__package__).joinpath("report.js").read_text()
