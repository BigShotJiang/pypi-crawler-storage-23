"""Theme constants and layout helpers for Plotly charts."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import plotly.graph_objects as go

# Faction colors matching the game's aesthetic
FACTION_COLORS = {
    "argentum": "#D4AF37",  # Gold
    "symbiote": "#7FFF00",  # Lime green
    "obsidion": "#00FFFF",  # Cyan
    "neutral": "#B87333",  # Copper
}

# Dark theme colors
DARK_THEME = {
    "bg_primary": "#1a1a2e",
    "bg_secondary": "#16213e",
    "bg_card": "#0f3460",
    "text_primary": "#eaeaea",
    "text_secondary": "#a0a0a0",
    "accent": "#e94560",
    "success": "#00d26a",
    "warning": "#ffc107",
    "danger": "#dc3545",
    "grid": "#2a2a4e",
}


def apply_theme(
    fig: go.Figure,
    *,
    height: int = 300,
    margins: dict[str, int] | None = None,
    show_legend: bool = False,
) -> None:
    """Apply dark theme to a Plotly figure.

    Args:
        fig: Plotly figure to style
        height: Chart height in pixels
        margins: Custom margins dict (t, b, l, r)
        show_legend: Whether to show legend
    """
    default_margins = {"t": 50, "b": 50, "l": 60, "r": 30}
    if margins:
        default_margins.update(margins)

    fig.update_layout(
        paper_bgcolor=DARK_THEME["bg_primary"],
        plot_bgcolor=DARK_THEME["bg_secondary"],
        font={"color": DARK_THEME["text_primary"]},
        height=height,
        margin=default_margins,
        showlegend=show_legend,
    )


def to_html(fig: go.Figure) -> str:
    """Convert Plotly figure to HTML string.

    Args:
        fig: Plotly figure to convert

    Returns:
        HTML string (without full HTML wrapper or plotly.js)
    """
    return fig.to_html(full_html=False, include_plotlyjs=False)


def get_winrate_colorscale() -> list[list[float | str]]:
    """Get standard colorscale for win rate heatmaps (0-100%).

    Returns:
        Plotly colorscale list
    """
    return [
        [0.0, "#dc3545"],  # Red for 0%
        [0.4, "#ffc107"],  # Yellow for 40%
        [0.5, "#ffffff"],  # White for 50%
        [0.6, "#28a745"],  # Green for 60%
        [1.0, "#00d26a"],  # Bright green for 100%
    ]


def style_axes(
    fig: go.Figure,
    *,
    xaxis_title: str | None = None,
    yaxis_title: str | None = None,
    row: int | None = None,
    col: int | None = None,
) -> None:
    """Apply consistent axis styling.

    Args:
        fig: Plotly figure
        xaxis_title: X-axis title
        yaxis_title: Y-axis title
        row: Subplot row (for subplots)
        col: Subplot column (for subplots)
    """
    kwargs = {}
    if row is not None and col is not None:
        kwargs = {"row": row, "col": col}

    if xaxis_title is not None:
        fig.update_xaxes(title=xaxis_title, gridcolor=DARK_THEME["grid"], **kwargs)
    else:
        fig.update_xaxes(gridcolor=DARK_THEME["grid"], **kwargs)

    if yaxis_title is not None:
        fig.update_yaxes(title=yaxis_title, gridcolor=DARK_THEME["grid"], **kwargs)
    else:
        fig.update_yaxes(gridcolor=DARK_THEME["grid"], **kwargs)
