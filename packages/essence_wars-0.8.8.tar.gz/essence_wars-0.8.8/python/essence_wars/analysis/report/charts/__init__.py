"""Plotly chart builders for HTML reports.

Provides reusable chart building functions with consistent styling.
"""

from .bar import (
    create_combat_efficiency_chart,
    create_convergence_status,
    create_deck_winrate_bar,
    create_elo_rankings_bar,
    create_faction_elo_comparison,
    create_faction_winrate_bar,
    create_p1_p2_chart,
)
from .gauge import create_faction_distribution, create_health_gauge
from .heatmap import (
    create_elo_prediction_heatmap,
    create_faction_matchup_heatmap,
    create_matchup_heatmap,
)
from .histogram import create_game_length_histogram
from .line import create_elo_timeline, create_tuning_comparison, create_tuning_curves
from .theme import DARK_THEME, FACTION_COLORS

__all__ = [
    # Theme constants
    "DARK_THEME",
    "FACTION_COLORS",
    # Bar charts
    "create_combat_efficiency_chart",
    "create_convergence_status",
    "create_deck_winrate_bar",
    "create_elo_rankings_bar",
    "create_faction_elo_comparison",
    "create_faction_winrate_bar",
    "create_p1_p2_chart",
    # Gauge/Pie charts
    "create_faction_distribution",
    "create_health_gauge",
    # Heatmaps
    "create_elo_prediction_heatmap",
    "create_faction_matchup_heatmap",
    "create_matchup_heatmap",
    # Histogram
    "create_game_length_histogram",
    # Line charts
    "create_elo_timeline",
    "create_tuning_comparison",
    "create_tuning_curves",
]
