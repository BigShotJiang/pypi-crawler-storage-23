import lap
import numpy as np

print(lap.lapjv(np.random.rand(4, 5), extend_cost=True))
