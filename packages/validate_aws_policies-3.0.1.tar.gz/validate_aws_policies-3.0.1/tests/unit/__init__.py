"""Unit tests for validate-aws-policies."""
