"""Test fixtures for AWS policy validation tests."""
