"""Integration tests for AWS policy validation CLI."""
