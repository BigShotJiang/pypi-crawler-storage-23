import logging
import os
from pathlib import Path

import psutil
from rich.console import Console

from crackerjack.config.settings import CrackerjackSettings
from crackerjack.models.protocols import OptionsProtocol

logger = logging.getLogger(__name__)


def parse_pytest_addopts(addopts: str | list) -> list[str]:
    if isinstance(addopts, list):
        return addopts

    import shlex

    try:
        return shlex.split(addopts)
    except Exception:
        return addopts.split()


class TestCommandBuilder:
    __test__ = False

    def __init__(
        self,
        pkg_path: Path | None = None,
        console: Console | None = None,
        settings: CrackerjackSettings | None = None,
    ) -> None:

        resolved_pkg_path = pkg_path
        if resolved_pkg_path is None:
            resolved_pkg_path = Path.cwd()

        try:
            self.pkg_path = Path(str(resolved_pkg_path))
        except Exception:
            self.pkg_path = Path(resolved_pkg_path)

        if console is None:
            try:
                console = Console()
            except Exception:
                console = Console()

        if settings is None:
            settings = CrackerjackSettings()

        self.console = console
        self.settings = settings

    def _get_incremental_tests(self, options: OptionsProtocol) -> list[Path] | None:

        if not getattr(options, "incremental_tests", True):
            return None

        try:
            import subprocess


            result = subprocess.run(
                ["git", "diff", "--name-only", "HEAD~10"],
                capture_output=True,
                text=True,
                check=False,
            )

            if result.returncode != 0:
                logger.debug("Not in git repo or no git changes, skipping incremental")
                return None

            changed_files = result.stdout.strip().split("\n")
            logger.debug(f"Found {len(changed_files)} changed files")


            changed_py_files = [
                f for f in changed_files
                if f.endswith(".py") and not f.startswith("tests/")
            ]

            if not changed_py_files:
                logger.info("No Python files changed in recent commits")
                return []

            logger.debug(f"Changed Python files: {changed_py_files}")


            snob_input = "\n".join(changed_py_files)
            snob_result = subprocess.run(
                ["snob"],
                input=snob_input,
                capture_output=True,
                text=True,
                check=False,
            )

            if snob_result.returncode != 0:
                logger.warning(f"snob failed: {snob_result.stderr}, falling back to full test run")
                return None

            test_paths = [Path(t) for t in snob_result.stdout.strip().split("\n") if t and t != ""]

            if not test_paths or not test_paths[0]:
                logger.info("No tests affected by changes (snob found none)")
                return []

            logger.info(
                f"snob found {len(test_paths)} tests affected by "
                f"{len(changed_py_files)} changed files"
            )

            return test_paths

        except FileNotFoundError:
            logger.warning("snob not found, falling back to full test run")
            return None
        except Exception as e:
            logger.warning(f"Incremental test selection failed: {e}, falling back to full run")
            return None

    def build_command(self, options: OptionsProtocol) -> list[str]:
        cmd = ["uv", "run", "python", "-m", "pytest"]


        incremental_tests = self._get_incremental_tests(options)

        if incremental_tests is not None:

            if not incremental_tests:

                self.console.print(
                    "[cyan]✓ No tests affected by recent changes, skipping test run[/cyan]"
                )

                return ["pytest", "--collect-only", "--co-quiet"]
            else:

                self.console.print(
                    f"[cyan]Running {len(incremental_tests)} tests affected by changes "
                    f"(snob)[/cyan]"
                )
                cmd.extend([str(t) for t in incremental_tests])


        self._add_coverage_options(cmd, options)
        self._add_worker_options(cmd, options)
        self._add_benchmark_options(cmd, options)
        self._add_timeout_options(cmd, options)
        self._add_verbosity_options(cmd, options)


        if incremental_tests is None:
            self._add_test_path(cmd)

        return cmd

    def build_xcode_command(self, options: OptionsProtocol) -> list[str]:
        project = getattr(
            options,
            "xcode_project",
            getattr(self.settings.testing, "xcode_project", "app/MdInjectApp/MdInjectApp.xcodeproj"),
        )
        scheme = getattr(
            options,
            "xcode_scheme",
            getattr(self.settings.testing, "xcode_scheme", "MdInjectApp"),
        )
        configuration = getattr(
            options,
            "xcode_configuration",
            getattr(self.settings.testing, "xcode_configuration", "Debug"),
        )
        destination = getattr(
            options,
            "xcode_destination",
            getattr(self.settings.testing, "xcode_destination", "platform=macOS"),
        )

        return [
            "xcodebuild",
            "test",
            "-project",
            project,
            "-scheme",
            scheme,
            "-configuration",
            configuration,
            "-destination",
            destination,
        ]

    def _handle_not_implemented_error(self, print_info: bool) -> int:
        if print_info and self.console:
            self.console.print(
                "[yellow]⚠️ CPU detection unavailable, using 2 workers[/yellow]",
            )
        return 2

    def _handle_general_error(self, print_info: bool, e: Exception) -> int:
        if print_info and self.console:
            self.console.print(
                f"[yellow]⚠️ Worker detection failed: {e}. Using 2 workers.[/yellow]",
            )
        return 2

    def get_optimal_workers(
        self, options: OptionsProtocol, print_info: bool = True,
    ) -> int | str:
        try:

            if self._check_emergency_rollback(print_info):
                return 1


            explicit_result = self._check_explicit_workers(options, print_info)
            if explicit_result is not None:
                return explicit_result


            auto_result = self._check_auto_detection(options, print_info)
            if auto_result is not None:
                return auto_result


            fractional_result = self._check_fractional_workers(options, print_info)
            if fractional_result is not None:
                return fractional_result


            return 2

        except NotImplementedError:
            return self._handle_not_implemented_error(print_info)
        except Exception as e:
            return self._handle_general_error(print_info, e)

    def _check_emergency_rollback(self, print_info: bool) -> bool:
        if os.getenv("CRACKERJACK_DISABLE_AUTO_WORKERS") == "1":
            if print_info and self.console:
                self.console.print(
                    "[yellow]⚠️ Auto-detection disabled via environment variable[/yellow]",
                )
            return True
        return False

    def _check_explicit_workers(
        self, options: OptionsProtocol, print_info: bool,
    ) -> int | None:
        if hasattr(options, "test_workers") and options.test_workers > 0:
            return options.test_workers
        return None

    def _check_auto_detection(
        self, options: OptionsProtocol, print_info: bool,
    ) -> str | int | None:
        if hasattr(options, "test_workers") and options.test_workers == 0:

            if self.settings and self.settings.testing.auto_detect_workers:

                if print_info and self.console:
                    self.console.print(
                        "[cyan]🔧 Using pytest-xdist auto-detection for workers[/cyan]",
                    )
                return "auto"


            return 1
        return None

    def _check_fractional_workers(
        self, options: OptionsProtocol, print_info: bool,
    ) -> int | None:
        if hasattr(options, "test_workers") and options.test_workers < 0:
            import multiprocessing

            cpu_count = multiprocessing.cpu_count()
            divisor = abs(options.test_workers)
            workers = max(1, cpu_count // divisor)


            workers = self._apply_memory_limit(workers)

            if print_info and self.console:
                self.console.print(
                    f"[cyan]🔧 Fractional workers: {cpu_count} cores ÷ {divisor} = {workers} workers[/cyan]",
                )

            return workers
        return None

    def _apply_memory_limit(self, workers: int) -> int:
        try:

            memory_per_worker = (
                self.settings.testing.memory_per_worker_gb if self.settings else 2.0
            )


            available_gb = psutil.virtual_memory().available / (1024**3)


            max_by_memory = max(1, int(available_gb / memory_per_worker))


            limited_workers = min(workers, max_by_memory)


            if limited_workers < workers and self.console:
                self.console.print(
                    f"[yellow]⚠️ Limited to {limited_workers} workers (available memory: {available_gb:.1f}GB)[/yellow]",
                )

            return limited_workers

        except Exception:

            return min(workers, 4)

    def get_test_timeout(self, options: OptionsProtocol) -> int:
        if hasattr(options, "test_timeout") and options.test_timeout:
            return options.test_timeout

        if hasattr(options, "benchmark") and options.benchmark:
            return 1800
        return 1800

    def _detect_package_name(self) -> str:

        pyproject_path = self.pkg_path / "pyproject.toml"
        if pyproject_path.exists():
            from contextlib import suppress

            with suppress(Exception):
                import tomllib

                with pyproject_path.open("rb") as f:
                    data = tomllib.load(f)
                    project_name = data.get("project", {}).get("name")
                    if project_name:

                        return project_name.replace("-", "_")


        for item in self.pkg_path.iterdir():
            if (
                item.is_dir()
                and not item.name.startswith(".")
                and item.name not in ("tests", "docs", "build", "dist", "__pycache__")
                and (item / "__init__.py").exists()
            ):
                return item.name


        return "crackerjack"

    def _add_coverage_options(self, cmd: list[str], options: OptionsProtocol) -> None:

        package_name = self._detect_package_name()

        cmd.extend(
            [
                f"--cov={package_name}",
                "--cov-report=term-missing",
                "--cov-report=html",
                "--cov-report=json",
                "--cov-fail-under=0",
            ],
        )

    def _check_project_disabled_xdist(self) -> bool:
        try:
            pyproject_path = self.pkg_path / "pyproject.toml"

            if not pyproject_path.exists():
                return False

            addopts = self._load_pytest_addopts(pyproject_path)
            if addopts:
                return self._addopts_disables_xdist(addopts)

            return False

        except Exception:
            return False

    def _load_pytest_addopts(self, pyproject_path: Path) -> str | None:
        import tomllib

        with pyproject_path.open("rb") as f:
            data = tomllib.load(f)


        pytest_config = data.get("tool", {}).get("pytest", {})


        ini_options = pytest_config.get("ini_options", {})
        addopts = ini_options.get("addopts")


        if addopts is None:
            addopts = pytest_config.get("addopts")

        return addopts

    def _addopts_disables_xdist(self, addopts: str) -> bool:
        parsed_opts = parse_pytest_addopts(addopts)


        if "-p" in parsed_opts:
            idx = parsed_opts.index("-p")
            if idx + 1 < len(parsed_opts) and parsed_opts[idx + 1] == "no: xdist":
                return True


        return self._has_compact_no_xdist_flag(parsed_opts)

    def _has_compact_no_xdist_flag(self, parsed_opts: list[str]) -> bool:
        return any(opt.startswith("-p") and "no: xdist" in opt for opt in parsed_opts)

    def _add_worker_options(self, cmd: list[str], options: OptionsProtocol) -> None:

        if self._check_project_disabled_xdist():
            self._print_xdist_disabled_message()
            return


        if self._should_skip_xdist_for_benchmark(options):
            return

        workers = self.get_optimal_workers(options)
        self._add_worker_count_options(cmd, workers)

    def _print_xdist_disabled_message(self) -> None:
        if self.console:
            self.console.print(
                "[yellow]⚠️ Project has disabled pytest-xdist in configuration[/yellow]",
            )
            self.console.print(
                "[cyan]🧪 Tests running sequentially (respecting project config)[/cyan]",
            )

    def _should_skip_xdist_for_benchmark(self, options: OptionsProtocol) -> bool:
        if hasattr(options, "benchmark") and options.benchmark:
            if self.console:
                self.console.print(
                    "[yellow]⚠️ Benchmarks running sequentially (parallel execution skews results)[/yellow]",
                )
            return True
        return False

    def _add_worker_count_options(self, cmd: list[str], workers: str | int) -> None:
        dist_mode = self.settings.testing.xdist_dist_mode

        if workers == "auto":
            self._add_auto_workers(cmd, dist_mode)
        elif isinstance(workers, int) and workers > 1:
            self._add_explicit_workers(cmd, workers, dist_mode)
        else:
            self._print_sequential_message()

    def _add_auto_workers(self, cmd: list[str], dist_mode: str) -> None:
        if dist_mode != "no":
            cmd.extend(["-n", "auto", f"--dist={dist_mode}"])
            self._print_worker_message("auto-detected workers", dist_mode)
        else:
            cmd.extend(["-n", "auto"])
            self._print_worker_message("auto-detected workers")

    def _add_explicit_workers(self, cmd: list[str], workers: int, dist_mode: str) -> None:
        if dist_mode != "no":
            cmd.extend(["-n", str(workers), f"--dist={dist_mode}"])
            self._print_worker_message(f"{workers} workers", dist_mode)
        else:
            cmd.extend(["-n", str(workers)])
            self._print_worker_message(f"{workers} workers")

    def _print_worker_message(self, worker_count: str, dist_mode: str | None = None) -> None:
        if not self.console:
            return

        if dist_mode:
            self.console.print(
                f"[cyan]🚀 Tests running with {worker_count} (--dist={dist_mode})[/cyan]",
            )
        else:
            self.console.print(
                f"[cyan]🚀 Tests running with {worker_count}[/cyan]",
            )

    def _print_sequential_message(self) -> None:
        if self.console:
            self.console.print("[cyan]🧪 Tests running sequentially[/cyan]")

    def _add_benchmark_options(self, cmd: list[str], options: OptionsProtocol) -> None:
        if hasattr(options, "benchmark") and options.benchmark:
            cmd.extend(
                [
                    "--benchmark-only",
                    "--benchmark-sort=mean",
                    "--benchmark-columns=min, max, mean, stddev",
                ],
            )

    def _add_timeout_options(self, cmd: list[str], options: OptionsProtocol) -> None:
        timeout = self.get_test_timeout(options)
        cmd.extend(["--timeout", str(timeout)])

    def _add_verbosity_options(self, cmd: list[str], options: OptionsProtocol) -> None:

        if options.verbose:
            if getattr(options, "ai_debug", False):
                cmd.append("-vvv")
                self.console.print("[cyan]🔍 Using extra verbose mode (-vvv)[/cyan]")
            else:
                cmd.append("-vv")
                self.console.print("[cyan]🔍 Using verbose mode (-vv)[/cyan]")
        else:
            cmd.append("-v")

        cmd.extend(
            [

                "--tb=long" if options.verbose else "--tb=short",

                "-ra",
                "--strict-markers",
                "--strict-config",
            ],
        )

    def _add_test_path(self, cmd: list[str]) -> None:
        test_paths = ["tests", "test"]

        for test_path in test_paths:
            full_path = self.pkg_path / test_path
            if full_path.exists() and full_path.is_dir():
                cmd.append(str(full_path))
                return

        cmd.append(str(self.pkg_path))

    def build_specific_test_command(self, test_pattern: str) -> list[str]:
        cmd = ["uv", "run", "python", "-m", "pytest", "-v"]


        package_name = self._detect_package_name()
        cmd.extend(
            [
                f"--cov={package_name}",
                "--cov-report=term-missing",
            ],
        )

        cmd.extend(["-k", test_pattern])

        self._add_test_path(cmd)

        return cmd

    def build_validation_command(self) -> list[str]:
        return [
            "uv",
            "run",
            "python",
            "-m",
            "pytest",
            "--collect-only",
            "--no-cov",
            "tests" if (self.pkg_path / "tests").exists() else ".",
        ]
