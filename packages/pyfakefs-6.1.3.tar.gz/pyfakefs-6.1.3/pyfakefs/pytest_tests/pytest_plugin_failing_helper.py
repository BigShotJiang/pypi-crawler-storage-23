"""Failing test to test stacktrace output - see
``pytest_check_failed_plugin_test.py``."""


def test_fs(fs):
    assert 1 == 2
