# FakeRVLDataRU 🇷🇺

[![PyPI version](https://badge.fury.io/py/FakeRVLDataRU.svg)](https://pypi.org/project/FakeRVLDataRU/)
[![Python](https://img.shields.io/badge/python-3.10%2B-blue)](https://python.org)
[![License](https://img.shields.io/badge/license-MIT-green)](LICENSE)

Генератор **фейковых русских данных** для тестирования и прототипирования.  
Без внешних зависимостей. Полностью на Python.

## ✨ Что генерирует

| Поле | Пример |
|------|--------|
| `full_name` | Иванова Мария Сергеевна |
| `inn` | 771234567890 |
| `snils` | 123-456-789 01 |
| `phone` | +7 (916) 123-45-67 |
| `address` | 101000, Москва, ул. Тверская, д. 15, кв. 42 |
| `email` | maria.ivanova@mail.ru |
| `passport` | `{"series": "45 23", "number": "678901", ...}` |
| `birth_date` | 15.03.1985 |
| `age` | 39 |
| `profession` | Инженер |
| `education` | Высшее (специалист) |
| `marital_status` | Замужем |
| `bank_account` | 40817810... |
| `bank_name` | Сбербанк |

## 📦 Установка

```bash
pip install FakeRVLDataRU
```

## 🚀 Быстрый старт

```python
from fakeruldata import Person, PersonGenerator

# ── Один человек (самый простой способ)
p = Person()
print(p.full_name)    # Иванова Мария Сергеевна
print(p.inn)          # 771234567890
print(p.snils)        # 123-456-789 01
print(p.phone)        # +7 (916) 123-45-67
print(p.address)      # 101000, Москва, ул. Тверская, д. 15, кв. 42
print(p)              # Красивый вывод всех данных

# ── Указать пол
m = Person(gender='male')
f = Person(gender='female')

# ── Генератор — несколько записей с фильтрами
gen = PersonGenerator()

# 10 женщин
women = gen.generate(count=10, gender='female')

# 5 мужчин из Москвы
moscow_men = gen.generate(count=5, gender='male', city='Москва')

# 20 человек, фамилия начинается на 'К'
k_people = gen.generate(count=20, surname_starts='К')

# Возраст 25–35 лет
young = gen.generate(count=10, min_age=25, max_age=35)

# Один человек (удобный метод)
one = gen.one(gender='female', city='Санкт-Петербург')
```

## 📋 Экспорт в словари

```python
gen = PersonGenerator()

# Все поля
data = gen.generate_dicts(count=3)
# [{"full_name": "...", "inn": "...", "address": "...", ...}, ...]

# Только нужные поля
minimal = gen.generate_dicts(
    count=10,
    gender='male',
    fields=['full_name', 'inn', 'phone', 'address']
)
```

## 🎯 Воспроизводимые результаты

```python
# seed гарантирует одинаковые данные при каждом запуске
gen = PersonGenerator(seed=42)
people = gen.generate(count=5)
```

## ⚡ Специализированные функции

```python
from fakeruldata import (
    fake_inn,           # ИНН физлица (12 цифр)
    fake_inn_org,       # ИНН юрлица (10 цифр)
    fake_snils,         # СНИЛС
    fake_phone,         # Мобильный телефон
    fake_passport,      # Паспортные данные (dict)
    fake_bank_account,  # Номер счёта
    fake_ogrn,          # ОГРН
    fake_kpp,           # КПП
    fake_address,       # Адрес (строка)
)

print(fake_inn())           # 771234567890
print(fake_snils())         # 123-456-789 01
print(fake_phone())         # +7 (916) 123-45-67
print(fake_address('Казань'))  # 420000, Казань, ул. Ленина, д. 5, кв. 3

passport = fake_passport()
# {
#   "series": "45 23",
#   "number": "678901",
#   "issued_by": "УМВД России по г. Москве",
#   "issue_date": "15.06.2018",
#   "department_code": "450-123"
# }
```

## 🔢 Валидация данных

Все данные алгоритмически корректны:

- **ИНН** — проходит проверку контрольных цифр
- **СНИЛС** — корректная контрольная сумма
- **Паспорт** — реальный формат серий
- **Телефон** — реальные коды операторов РФ

## 🏙️ Доступные города

Москва, Санкт-Петербург, Новосибирск, Екатеринбург, Казань, Нижний Новгород,
Челябинск, Самара, Уфа, Ростов-на-Дону, Краснодар, Пермь, Воронеж, Волгоград,
Красноярск, Саратов, Тюмень, Тольятти, Ижевск, Барнаул, Ульяновск, Иркутск,
Хабаровск, Ярославль, Владивосток, Томск, Оренбург, Кемерово и другие (40+).

## 📊 Пример — DataFrame (pandas)

```python
import pandas as pd
from fakeruldata import PersonGenerator

gen = PersonGenerator()
data = gen.generate_dicts(
    count=100,
    fields=['full_name', 'gender', 'age', 'city', 'inn', 'phone', 'profession']
)

df = pd.DataFrame(data)
print(df.head())
print(df.groupby('gender').size())
```

## 📊 Пример — JSON-экспорт

```python
import json
from fakeruldata import PersonGenerator

gen = PersonGenerator()
data = gen.generate_dicts(count=5)

with open("fake_data.json", "w", encoding="utf-8") as f:
    json.dump(data, f, ensure_ascii=False, indent=2)
```

## 🔗 REST API

Также доступен REST API: **https://api.prosrochkapatrol.ru**

```
GET /?endpoint=person&gender=female&count=5&city=Москва&fields=full_name,inn
```

## 📄 Лицензия

MIT © 2026 FakeRVLDataRU

---

> ⚠️ Данные полностью вымышленные. Используйте только для тестирования и разработки.
