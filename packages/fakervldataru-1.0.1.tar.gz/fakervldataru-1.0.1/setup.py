from setuptools import setup, find_packages

with open("README.md", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="FakeRVLDataRU",
    version="1.0.0",
    author="FakeRVLDataRU",
    author_email="support@prosrochkapatrol.ru",
    description="Генератор фейковых русских данных — ФИО, ИНН, СНИЛС, адреса, паспорта и многое другое",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/fakeruldata/FakeRVLDataRU",
    project_urls={
        "API Документация": "https://api.prosrochkapatrol.ru",
        "Баг-трекер": "https://github.com/fakeruldata/FakeRVLDataRU/issues",
    },
    packages=find_packages(exclude=["tests*", "docs*"]),
    python_requires=">=3.10",
    install_requires=[],  # Нет внешних зависимостей!
    extras_require={
        "dev": [
            "pytest>=7.0",
            "pytest-cov>=4.0",
        ],
    },
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Testing",
        "Topic :: Utilities",
        "Natural Language :: Russian",
        "Operating System :: OS Independent",
    ],
    keywords=[
        "fake", "data", "russia", "russian", "generator",
        "inn", "snils", "passport", "test", "mock",
        "фейк", "данные", "россия", "генератор",
    ],
    include_package_data=True,
    zip_safe=True,
)
