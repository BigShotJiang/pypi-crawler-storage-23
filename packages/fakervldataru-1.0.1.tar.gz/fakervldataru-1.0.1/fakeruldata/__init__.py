"""
FakeRVLDataRU
=============
Генератор фейковых русских данных для тестирования.

Установка:
    pip install FakeRVLDataRU

Быстрый старт:
    from fakeruldata import Person, PersonGenerator

    # Один человек
    p = Person()
    print(p.full_name)     # Иванова Мария Сергеевна
    print(p.inn)           # 771234567890
    print(p.snils)         # 123-456-789 01
    print(p.phone)         # +7 (916) 123-45-67
    print(p.address)       # 101000, Москва, ул. Ленина, д. 5, кв. 12

    # Генератор с фильтрами
    gen = PersonGenerator()
    people = gen.generate(count=10, gender='female', city='Москва')
    data = gen.generate_dicts(count=5, fields=['full_name', 'inn', 'phone'])

    # Специализированные функции
    from fakeruldata import fake_inn, fake_snils, fake_phone, fake_passport

    print(fake_inn())       # 771234567890
    print(fake_snils())     # 123-456-789 01
    print(fake_phone())     # +7 (916) 123-45-67
"""

__version__ = "1.0.0"
__author__ = "FakeRVLDataRU"
__license__ = "MIT"

from fakeruldata.person import (
    Person,
    PersonGenerator,
    fake_inn,
    fake_inn_org,
    fake_snils,
    fake_phone,
    fake_passport,
    fake_bank_account,
    fake_ogrn,
    fake_kpp,
    fake_address,
)

__all__ = [
    "Person",
    "PersonGenerator",
    "fake_inn",
    "fake_inn_org",
    "fake_snils",
    "fake_phone",
    "fake_passport",
    "fake_bank_account",
    "fake_ogrn",
    "fake_kpp",
    "fake_address",
]
