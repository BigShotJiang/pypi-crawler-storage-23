"""
FakeRVLDataRU — основной модуль.
Генерация фейковых данных для тестирования (Россия).

Использование:
    from fakeruldata import Person, PersonGenerator

    # Один человек
    p = Person()
    print(p.full_name)
    print(p.inn)

    # Генератор
    gen = PersonGenerator()
    people = gen.generate(count=10, gender='female', city='Москва')
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field, asdict
from datetime import date
from typing import Literal, Optional

from fakeruldata.data import (
    MALE_FIRST_NAMES, FEMALE_FIRST_NAMES,
    MALE_PATRONYMICS, FEMALE_PATRONYMICS,
    MALE_SURNAMES, FEMALE_SURNAMES,
    PROFESSIONS, EDUCATION_LEVELS,
    MARITAL_STATUS_MALE, MARITAL_STATUS_FEMALE,
    NATIONALITIES, BLOOD_GROUPS, BANK_NAMES,
)
from fakeruldata.generators import (
    generate_inn, generate_snils, generate_phone,
    generate_passport, generate_bank_account,
    generate_bik, generate_kpp, generate_ogrn,
    generate_birth_date, generate_address, generate_email,
    generate_inn_org,
)


GenderType = Literal["male", "female"]


@dataclass
class Person:
    """Объект с фейковыми данными одного человека."""

    # Основные данные
    gender: str = field(default_factory=lambda: random.choice(["male", "female"]))

    # Генерируется в __post_init__
    first_name: str = field(init=False)
    last_name: str = field(init=False)
    patronymic: str = field(init=False)
    full_name: str = field(init=False)

    birth_date: str = field(init=False)
    age: int = field(init=False)

    address: str = field(init=False)
    city: str = field(init=False)

    inn: str = field(init=False)
    snils: str = field(init=False)
    phone: str = field(init=False)
    email: str = field(init=False)

    profession: str = field(init=False)
    education: str = field(init=False)
    marital_status: str = field(init=False)
    nationality: str = field(init=False)
    blood_group: str = field(init=False)

    passport: dict = field(init=False)
    bank_name: str = field(init=False)
    bank_account: str = field(init=False)
    bik: str = field(init=False)

    _city_filter: Optional[str] = field(default=None, repr=False)

    def __post_init__(self):
        g = self.gender

        if g == "male":
            self.first_name = random.choice(MALE_FIRST_NAMES)
            self.last_name = random.choice(MALE_SURNAMES)
            self.patronymic = random.choice(MALE_PATRONYMICS)
            self.marital_status = random.choice(MARITAL_STATUS_MALE)
            self.nationality = random.choice(NATIONALITIES[:10])
        else:
            self.first_name = random.choice(FEMALE_FIRST_NAMES)
            self.last_name = random.choice(FEMALE_SURNAMES)
            self.patronymic = random.choice(FEMALE_PATRONYMICS)
            self.marital_status = random.choice(MARITAL_STATUS_FEMALE)
            self.nationality = random.choice(NATIONALITIES[10:])

        self.full_name = f"{self.last_name} {self.first_name} {self.patronymic}"

        bd = generate_birth_date()
        self.birth_date = bd.strftime("%d.%m.%Y")
        today = date.today()
        self.age = (
            today.year - bd.year
            - ((today.month, today.day) < (bd.month, bd.day))
        )

        self.address, self.city = generate_address(self._city_filter)
        self.inn = generate_inn()
        self.snils = generate_snils()
        self.phone = generate_phone()
        self.email = generate_email(self.first_name, self.last_name)
        self.profession = random.choice(PROFESSIONS)
        self.education = random.choice(EDUCATION_LEVELS)
        self.blood_group = random.choice(BLOOD_GROUPS)
        self.passport = generate_passport()
        self.bank_name = random.choice(BANK_NAMES)
        self.bank_account = generate_bank_account()
        self.bik = generate_bik()

    def to_dict(self, fields: Optional[list[str]] = None) -> dict:
        """
        Сериализует в словарь.

        Args:
            fields: список полей (None = все поля)

        Returns:
            dict с данными
        """
        all_data = {
            "full_name": self.full_name,
            "first_name": self.first_name,
            "last_name": self.last_name,
            "patronymic": self.patronymic,
            "gender": self.gender,
            "birth_date": self.birth_date,
            "age": self.age,
            "address": self.address,
            "city": self.city,
            "inn": self.inn,
            "snils": self.snils,
            "phone": self.phone,
            "email": self.email,
            "profession": self.profession,
            "education": self.education,
            "marital_status": self.marital_status,
            "nationality": self.nationality,
            "blood_group": self.blood_group,
            "passport": self.passport,
            "bank_name": self.bank_name,
            "bank_account": self.bank_account,
            "bik": self.bik,
        }

        if fields:
            unknown = [f for f in fields if f not in all_data]
            if unknown:
                raise ValueError(
                    f"Неизвестные поля: {unknown}. "
                    f"Доступные: {list(all_data.keys())}"
                )
            return {k: v for k, v in all_data.items() if k in fields}

        return all_data

    def __repr__(self) -> str:
        return f"<Person: {self.full_name}, {self.birth_date}, {self.city}>"

    def __str__(self) -> str:
        return (
            f"ФИО:     {self.full_name}\n"
            f"Пол:     {'Мужской' if self.gender == 'male' else 'Женский'}\n"
            f"Дата рождения: {self.birth_date} ({self.age} лет)\n"
            f"Адрес:   {self.address}\n"
            f"ИНН:     {self.inn}\n"
            f"СНИЛС:   {self.snils}\n"
            f"Телефон: {self.phone}\n"
            f"Email:   {self.email}\n"
            f"Профессия: {self.profession}\n"
            f"Образование: {self.education}\n"
            f"Банк:    {self.bank_name}\n"
            f"Счёт:    {self.bank_account}\n"
        )


class PersonGenerator:
    """
    Генератор людей с поддержкой фильтров.

    Примеры:
        gen = PersonGenerator()

        # 5 женщин из Москвы
        people = gen.generate(count=5, gender='female', city='Москва')

        # 10 мужчин, фамилия начинается на 'К'
        people = gen.generate(count=10, gender='male', surname_starts='К')

        # Только нужные поля
        data = gen.generate_dicts(count=3, fields=['full_name', 'inn', 'phone'])
    """

    def __init__(self, seed: Optional[int] = None):
        """
        Args:
            seed: зерно для воспроизводимых результатов
        """
        if seed is not None:
            random.seed(seed)

    def generate(
        self,
        count: int = 1,
        gender: Optional[GenderType] = None,
        city: Optional[str] = None,
        surname_starts: Optional[str] = None,
        min_age: int = 18,
        max_age: int = 80,
    ) -> list[Person]:
        """
        Генерирует список объектов Person.

        Args:
            count: количество записей (1–10 000)
            gender: 'male', 'female' или None (случайный)
            city: фильтр по городу (e.g., 'Москва')
            surname_starts: первая буква фамилии (e.g., 'К')
            min_age: минимальный возраст
            max_age: максимальный возраст

        Returns:
            Список объектов Person

        Raises:
            ValueError: некорректные параметры
        """
        if count < 1:
            raise ValueError("count должен быть >= 1")
        if count > 10_000:
            raise ValueError("count не может превышать 10 000")
        if gender not in (None, "male", "female"):
            raise ValueError("gender должен быть 'male', 'female' или None")
        if min_age >= max_age:
            raise ValueError("min_age должен быть меньше max_age")

        results = []
        max_attempts = count * 20
        attempts = 0

        while len(results) < count and attempts < max_attempts:
            g = gender or random.choice(["male", "female"])
            p = Person(gender=g, _city_filter=city)

            if surname_starts and not p.last_name.upper().startswith(
                surname_starts.upper()
            ):
                attempts += 1
                continue

            results.append(p)
            attempts += 1

        if len(results) < count:
            import warnings
            warnings.warn(
                f"Не удалось сгенерировать {count} записей с текущими фильтрами. "
                f"Получено: {len(results)}. Попробуйте ослабить условия.",
                RuntimeWarning,
                stacklevel=2,
            )

        return results

    def generate_dicts(
        self,
        count: int = 1,
        gender: Optional[GenderType] = None,
        city: Optional[str] = None,
        surname_starts: Optional[str] = None,
        fields: Optional[list[str]] = None,
        min_age: int = 18,
        max_age: int = 80,
    ) -> list[dict]:
        """
        Генерирует список словарей с данными.

        Args:
            count: количество записей
            gender: 'male', 'female' или None
            city: фильтр по городу
            surname_starts: первая буква фамилии
            fields: список нужных полей (None = все)
            min_age: минимальный возраст
            max_age: максимальный возраст

        Returns:
            Список словарей
        """
        people = self.generate(
            count=count,
            gender=gender,
            city=city,
            surname_starts=surname_starts,
            min_age=min_age,
            max_age=max_age,
        )
        return [p.to_dict(fields=fields) for p in people]

    def one(
        self,
        gender: Optional[GenderType] = None,
        city: Optional[str] = None,
    ) -> Person:
        """
        Быстрый метод для генерации одного человека.

        Args:
            gender: 'male', 'female' или None
            city: фильтр по городу

        Returns:
            Объект Person
        """
        return self.generate(count=1, gender=gender, city=city)[0]


# ─────────────────────────────────────────
#  Специализированные генераторы
# ─────────────────────────────────────────

def fake_inn() -> str:
    """Быстрая генерация ИНН физлица."""
    return generate_inn()


def fake_inn_org() -> str:
    """Быстрая генерация ИНН юрлица."""
    return generate_inn_org()


def fake_snils() -> str:
    """Быстрая генерация СНИЛС."""
    return generate_snils()


def fake_phone() -> str:
    """Быстрая генерация телефона."""
    return generate_phone()


def fake_passport() -> dict:
    """Быстрая генерация паспортных данных."""
    return generate_passport()


def fake_bank_account() -> str:
    """Быстрая генерация номера счёта."""
    return generate_bank_account()


def fake_ogrn() -> str:
    """Быстрая генерация ОГРН."""
    return generate_ogrn()


def fake_kpp() -> str:
    """Быстрая генерация КПП."""
    return generate_kpp()


def fake_address(city: Optional[str] = None) -> str:
    """
    Быстрая генерация адреса.

    Args:
        city: город (None = случайный)
    """
    addr, _ = generate_address(city)
    return addr
