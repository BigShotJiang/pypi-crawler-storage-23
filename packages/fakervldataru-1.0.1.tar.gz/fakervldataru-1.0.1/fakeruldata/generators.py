"""
Генераторы конкретных данных — ИНН, СНИЛС, счета, даты и т.д.
"""

import random
import string
from datetime import date, timedelta


# ─────────────────────────────────────────
#  ИНН (физическое лицо, 12 цифр)
# ─────────────────────────────────────────

def _inn_checksum(digits: list[int], weights: list[int]) -> int:
    """Контрольная цифра ИНН."""
    return sum(d * w for d, w in zip(digits, weights)) % 11 % 10


def generate_inn() -> str:
    """Генерирует корректный ИНН физического лица (12 цифр)."""
    d = [random.randint(0, 9) for _ in range(10)]
    n11 = _inn_checksum(d, [7, 2, 4, 10, 3, 5, 9, 4, 6, 8])
    n12 = _inn_checksum(d + [n11], [3, 7, 2, 4, 10, 3, 5, 9, 4, 6, 8])
    return "".join(map(str, d + [n11, n12]))


def generate_inn_org() -> str:
    """Генерирует корректный ИНН юридического лица (10 цифр)."""
    d = [random.randint(0, 9) for _ in range(9)]
    n10 = _inn_checksum(d, [2, 4, 10, 3, 5, 9, 4, 6, 8])
    return "".join(map(str, d + [n10]))


# ─────────────────────────────────────────
#  СНИЛС
# ─────────────────────────────────────────

def generate_snils() -> str:
    """Генерирует корректный СНИЛС в формате XXX-XXX-XXX XX."""
    while True:
        num = random.randint(1_000_000_000, 9_999_999_999)
        digits = [int(d) for d in str(num)[:9]]
        checksum = sum(d * (9 - i) for i, d in enumerate(digits)) % 101
        if checksum < 100:
            parts = str(num)[:9]
            return f"{parts[:3]}-{parts[3:6]}-{parts[6:9]} {checksum:02d}"


# ─────────────────────────────────────────
#  Паспорт
# ─────────────────────────────────────────

def generate_passport() -> dict:
    """Генерирует данные паспорта РФ."""
    region = random.randint(1, 99)
    year = random.randint(0, 25)
    series = f"{region:02d} {year:02d}"
    number = f"{random.randint(100_000, 999_999)}"
    issue_date = random_date(date(2000, 1, 1), date(2024, 12, 31))
    issued_by = random.choice([
        "УМВД России по г. Москве",
        "МВД России по Республике Татарстан",
        "ГУ МВД России по Санкт-Петербургу",
        "УМВД России по Екатеринбургу",
        "МВД России по Краснодарскому краю",
        "УМВД России по Новосибирской области",
        "УМВД России по Ростовской области",
        "МВД России по Республике Башкортостан",
        "ГУ МВД России по Самарской области",
        "УМВД России по Воронежской области",
    ])
    return {
        "series": series,
        "number": number,
        "issued_by": issued_by,
        "issue_date": issue_date.strftime("%d.%m.%Y"),
        "department_code": f"{region:02d}0-{random.randint(100, 999)}",
    }


# ─────────────────────────────────────────
#  Банковские данные
# ─────────────────────────────────────────

def generate_bank_account() -> str:
    """Генерирует номер банковского счёта (20 цифр)."""
    return "408" + "17810" + "".join([str(random.randint(0, 9)) for _ in range(12)])


def generate_bik() -> str:
    """Генерирует БИК банка."""
    return "04" + "".join([str(random.randint(0, 9)) for _ in range(7)])


def generate_kpp() -> str:
    """Генерирует КПП организации."""
    return (
        f"{random.randint(10, 99)}"
        f"{random.randint(10, 99)}"
        f"{random.randint(1, 43):02d}"
        f"{random.randint(100, 999)}"
    )


def generate_ogrn() -> str:
    """Генерирует ОГРН (13 цифр)."""
    d = [random.randint(0, 9) for _ in range(12)]
    num = int("".join(map(str, d)))
    control = num % 11 % 10
    return "".join(map(str, d)) + str(control)


# ─────────────────────────────────────────
#  Телефон
# ─────────────────────────────────────────

def generate_phone() -> str:
    """Генерирует российский мобильный номер телефона."""
    from fakeruldata.data import PHONE_CODES
    code = random.choice(PHONE_CODES)
    number = "".join([str(random.randint(0, 9)) for _ in range(7)])
    return f"+7 ({code}) {number[:3]}-{number[3:5]}-{number[5:]}"


# ─────────────────────────────────────────
#  Даты
# ─────────────────────────────────────────

def random_date(start: date, end: date) -> date:
    """Случайная дата в диапазоне."""
    delta = (end - start).days
    return start + timedelta(days=random.randint(0, delta))


def generate_birth_date(min_age: int = 18, max_age: int = 80) -> date:
    """Дата рождения случайного возраста."""
    today = date.today()
    start = today.replace(year=today.year - max_age)
    end = today.replace(year=today.year - min_age)
    return random_date(start, end)


# ─────────────────────────────────────────
#  Email
# ─────────────────────────────────────────

def generate_email(first_name: str, last_name: str) -> str:
    """Генерирует email на основе имени и фамилии."""
    from fakeruldata.data import EMAIL_DOMAINS

    # Упрощённая транслитерация
    translit_map = {
        'а': 'a', 'б': 'b', 'в': 'v', 'г': 'g', 'д': 'd', 'е': 'e',
        'ё': 'yo', 'ж': 'zh', 'з': 'z', 'и': 'i', 'й': 'y', 'к': 'k',
        'л': 'l', 'м': 'm', 'н': 'n', 'о': 'o', 'п': 'p', 'р': 'r',
        'с': 's', 'т': 't', 'у': 'u', 'ф': 'f', 'х': 'kh', 'ц': 'ts',
        'ч': 'ch', 'ш': 'sh', 'щ': 'shch', 'ъ': '', 'ы': 'y', 'ь': '',
        'э': 'e', 'ю': 'yu', 'я': 'ya',
    }

    def to_lat(s: str) -> str:
        return "".join(translit_map.get(c.lower(), c) for c in s)

    variants = [
        f"{to_lat(first_name).lower()}.{to_lat(last_name).lower()}",
        f"{to_lat(last_name).lower()}{to_lat(first_name[0]).lower()}",
        f"{to_lat(first_name[0]).lower()}{to_lat(last_name).lower()}",
        f"{to_lat(last_name).lower()}_{random.randint(1, 999)}",
    ]
    local = random.choice(variants)
    domain = random.choice(EMAIL_DOMAINS)
    return f"{local}@{domain}"


# ─────────────────────────────────────────
#  Адрес
# ─────────────────────────────────────────

def generate_address(city: str | None = None) -> tuple[str, str]:
    """
    Генерирует адрес.
    Возвращает (полный_адрес, название_города).
    """
    from fakeruldata.data import CITIES, STREET_TYPES, STREET_NAMES

    if city:
        city_data = None
        for c, d in CITIES.items():
            if city.lower() in c.lower():
                city_name = c
                city_data = d
                break
        if city_data is None:
            city_name = city
            city_data = {"region": "Россия", "zip_prefix": "10"}
    else:
        city_name, city_data = random.choice(list(CITIES.items()))

    zip_suffix = "".join([str(random.randint(0, 9)) for _ in range(4)])
    postal = f"{city_data['zip_prefix']}{zip_suffix}"

    street_type = random.choice(STREET_TYPES)
    street_name = random.choice(STREET_NAMES)
    building = random.randint(1, 300)
    apt = random.randint(1, 500)

    address = f"{postal}, {city_name}, {street_type} {street_name}, д. {building}, кв. {apt}"
    return address, city_name
