#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Unified hint module for dependency missing, parameter errors, etc.
"""

from easy_encryption_tool.rich_ui import hint, warning


def hint_missing_gmssl(feature: str) -> None:
    """
    Hint when GM/T (Chinese standard) crypto dependency is missing.
    :param feature: Feature name, e.g. "SM3", "SM4", "SM2", "ZUC", "GM cert parse"
    """
    warning(f"{feature} requires easy_gmssl")
    hint("Install: pip install easy_gmssl")
    hint("Or: pip install easy-encryption-tool[gmssl]")


def hint_invalid_b64(context: str = "") -> None:
    """Hint when base64 decode fails"""
    prefix = f"{context}: " if context else ""
    hint(f"{prefix}For decrypt, -i must be base64 cipher; if input is already base64, add -e")
    hint("Example: easy_encryption_tool aes -A decrypt -i 'cipher...' -e")


def hint_input_file_or_b64_conflict() -> None:
    """Hint when -e and -f conflict"""
    warning("-e and -f are mutually exclusive: input cannot be both file and base64")
    hint("-e: -i is base64 encoded; -f: -i is file path")
