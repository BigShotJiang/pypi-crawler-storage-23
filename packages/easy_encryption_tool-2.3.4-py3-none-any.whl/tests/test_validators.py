#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
验证器单元测试：validators 模块。
"""
from __future__ import annotations

import pytest

from easy_encryption_tool import validators


class TestValidateB64OrFile:
    """validate_b64_or_file 单元测试"""

    def test_both_true_returns_false(self):
        ok, msg = validators.validate_b64_or_file(
            is_base64=True, is_file=True
        )
        assert ok is False
        assert "mutually exclusive" in msg

    def test_either_false_returns_true(self):
        ok, msg = validators.validate_b64_or_file(
            is_base64=True, is_file=False
        )
        assert ok is True
        assert msg is None

        ok, msg = validators.validate_b64_or_file(
            is_base64=False, is_file=True
        )
        assert ok is True
        assert msg is None

    def test_context_in_message(self):
        ok, msg = validators.validate_b64_or_file(
            is_base64=True, is_file=True, context="AES"
        )
        assert "AES" in msg


class TestValidateFileOutputRequired:
    """validate_file_output_required 单元测试"""

    def test_file_input_without_output_returns_false(self):
        ok, msg = validators.validate_file_output_required(
            is_file=True, output_file=""
        )
        assert ok is False
        assert "Output file" in msg

    def test_file_input_with_output_returns_true(self):
        ok, msg = validators.validate_file_output_required(
            is_file=True, output_file="/path/out.txt"
        )
        assert ok is True
        assert msg is None

    def test_non_file_input_returns_true(self):
        ok, msg = validators.validate_file_output_required(
            is_file=False, output_file=""
        )
        assert ok is True


class TestLooksLikeBase64:
    """looks_like_base64 单元测试"""

    def test_empty_returns_false(self):
        assert validators.looks_like_base64("") is False

    def test_too_short_returns_false(self):
        assert validators.looks_like_base64("abc") is False

    def test_valid_base64_like_returns_true(self):
        s = "SGVsbG8gV29ybGQ="  # "Hello World" in base64
        assert validators.looks_like_base64(s) is True

    def test_invalid_chars_returns_false(self):
        assert validators.looks_like_base64("!!!invalid!!!") is False

    def test_length_not_multiple_of_4_returns_false(self):
        assert validators.looks_like_base64("abcde") is False

    def test_length_mod4_eq_2_returns_true_when_valid(self):
        # len % 4 in (0, 2) is allowed; need len >= 16
        s = "SGVsbG8gV29ybGQgV29ybGQ="  # len 24, valid base64-like
        assert validators.looks_like_base64(s) is True

    def test_context_in_hint_decrypt(self):
        # 需要 len >= 16 才能触发 looks_like_base64
        long_b64 = "SGVsbG8gV29ybGQgV29ybGQhIQ=="  # "Hello World World!!"
        hint = validators.hint_decrypt_maybe_b64(long_b64, context="AES")
        assert "AES" in hint or "decrypt" in hint.lower()


class TestHintDecryptMaybeB64:
    """hint_decrypt_maybe_b64 单元测试"""

    def test_base64_like_returns_hint(self):
        hint = validators.hint_decrypt_maybe_b64("SGVsbG8gV29ybGQ=")
        assert "base64" in hint
        assert "-e" in hint

    def test_non_base64_returns_empty(self):
        hint = validators.hint_decrypt_maybe_b64("plain text")
        assert hint == ""
