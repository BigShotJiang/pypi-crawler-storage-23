#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
ZUC 命令单元测试（需 easy_gmssl）。
"""
from __future__ import annotations

import base64
import os

import pytest
from click.testing import CliRunner

from .conftest import extract_base64, strip_ansi
from easy_encryption_tool import cipherhub_defaults
from easy_encryption_tool import zuc_command


runner = CliRunner()
GMSSL_AVAILABLE = getattr(zuc_command, "EASY_GMSSL_AVAILABLE", False)


@pytest.mark.skipif(not GMSSL_AVAILABLE, reason="easy_gmssl not installed")
class TestZucCommand:
    """ZUC 加解密测试"""

    def test_encrypt_plaintext(self):
        result = runner.invoke(
            zuc_command.zuc_command,
            [
                "-A", "encrypt",
                "-k", cipherhub_defaults.DEFAULT_ZUC_KEY,
                "-v", cipherhub_defaults.DEFAULT_ZUC_IV,
                "-i", "hello",
            ],
        )
        assert result.exit_code == 0
        out = strip_ansi(result.output)
        assert "cipher" in out

    def test_encrypt_decrypt_roundtrip(self):
        enc = runner.invoke(
            zuc_command.zuc_command,
            [
                "-A", "encrypt",
                "-k", cipherhub_defaults.DEFAULT_ZUC_KEY,
                "-v", cipherhub_defaults.DEFAULT_ZUC_IV,
                "-i", "secret data",
            ],
        )
        assert enc.exit_code == 0
        out = strip_ansi(enc.output)
        cipher_b64 = extract_base64(out, min_len=16)
        if not cipher_b64:
            for line in out.split("\n"):
                if "cipher:" in line:
                    parts = line.split("cipher:", 1)
                    if len(parts) > 1:
                        cipher_b64 = parts[1].strip()
                        break
        assert cipher_b64
        dec = runner.invoke(
            zuc_command.zuc_command,
            [
                "-A", "decrypt",
                "-k", cipherhub_defaults.DEFAULT_ZUC_KEY,
                "-v", cipherhub_defaults.DEFAULT_ZUC_IV,
                "-i", cipher_b64, "-e",
            ],
        )
        assert dec.exit_code == 0
        dec_out = strip_ansi(dec.output)
        assert "secret data" in dec_out or "plain" in dec_out.lower()


@pytest.mark.skipif(not GMSSL_AVAILABLE, reason="easy_gmssl not installed")
class TestZucFileMode:
    """ZUC 文件模式"""

    def test_encrypt_file(self, tmp_file):
        content = b"file content"
        path = tmp_file(content)
        out_path = path + ".enc"
        result = runner.invoke(
            zuc_command.zuc_command,
            [
                "-A", "encrypt",
                "-k", cipherhub_defaults.DEFAULT_ZUC_KEY,
                "-v", cipherhub_defaults.DEFAULT_ZUC_IV,
                "-i", path, "-f", "-o", out_path,
            ],
        )
        assert result.exit_code == 0
        assert os.path.exists(out_path)
        assert os.path.getsize(out_path) == len(content)

    def test_encrypt_decrypt_file_roundtrip(self, tmp_file):
        """ZUC 文件加解密往返"""
        from pathlib import Path

        content = b"zuc file secret data"
        plain_path = tmp_file(content)
        enc_path = plain_path + ".enc"
        dec_path = plain_path + ".dec"
        enc = runner.invoke(
            zuc_command.zuc_command,
            [
                "-A", "encrypt",
                "-k", cipherhub_defaults.DEFAULT_ZUC_KEY,
                "-v", cipherhub_defaults.DEFAULT_ZUC_IV,
                "-i", plain_path, "-f", "-o", enc_path,
            ],
        )
        assert enc.exit_code == 0
        dec = runner.invoke(
            zuc_command.zuc_command,
            [
                "-A", "decrypt",
                "-k", cipherhub_defaults.DEFAULT_ZUC_KEY,
                "-v", cipherhub_defaults.DEFAULT_ZUC_IV,
                "-i", enc_path, "-f", "-o", dec_path,
            ],
        )
        assert dec.exit_code == 0
        assert Path(dec_path).read_bytes() == content


@pytest.mark.skipif(GMSSL_AVAILABLE, reason="gmssl installed, skip no-gmssl tests")
class TestZucWithoutGmssl:
    """无 easy_gmssl 时的行为"""

    def test_command_fails_with_hint(self):
        result = runner.invoke(
            zuc_command.zuc_command,
            ["-A", "encrypt", "-i", "x"],
        )
        assert result.exit_code != 0 or "easy_gmssl" in result.output or "gmssl" in result.output.lower()
