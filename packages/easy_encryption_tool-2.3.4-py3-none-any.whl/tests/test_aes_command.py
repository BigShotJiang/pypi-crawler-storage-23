#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
AES 命令单元测试。
"""
from __future__ import annotations

import base64
import os
from pathlib import Path

import pytest
from click.testing import CliRunner

from easy_encryption_tool import aes_command
from easy_encryption_tool import cipherhub_defaults


runner = CliRunner()


class TestAesOperator:
    """aes_operator 类单元测试"""

    def test_cbc_encrypt_decrypt_roundtrip(self):
        from easy_encryption_tool.aes_command import (
            aes_operator,
            padding_data,
            remove_padding_data,
        )
        key = cipherhub_defaults.DEFAULT_KEY_32.encode("utf-8")
        iv = cipherhub_defaults.DEFAULT_IV_16.encode("utf-8")
        plain = b"hello world"
        padded = padding_data(plain)
        op_enc = aes_operator(
            mode="cbc", action="encrypt",
            key=key, iv=iv, tags=b"", aad=None
        )
        cipher = op_enc.process_data(padded)
        last, tag = op_enc.finalize()
        full_cipher = cipher + last
        op_dec = aes_operator(
            mode="cbc", action="decrypt",
            key=key, iv=iv, tags=b"", aad=None
        )
        dec = op_dec.process_data(full_cipher)
        dec_last, _ = op_dec.finalize()
        assert remove_padding_data(dec + dec_last) == plain

    def test_gcm_encrypt_decrypt_roundtrip(self):
        from easy_encryption_tool.aes_command import aes_operator
        key = cipherhub_defaults.DEFAULT_KEY_32.encode("utf-8")
        iv = cipherhub_defaults.DEFAULT_NONCE_12.encode("utf-8")
        aad = cipherhub_defaults.DEFAULT_AAD.encode("utf-8")
        plain = b"hello"
        op_enc = aes_operator(
            mode="gcm", action="encrypt",
            key=key, iv=iv, tags=b"", aad=aad
        )
        cipher = op_enc.process_data(plain)
        last, tag = op_enc.finalize()
        cipher_with_tag = cipher + last + tag
        op_dec = aes_operator(
            mode="gcm", action="decrypt",
            key=key, iv=iv, tags=tag, aad=aad
        )
        dec = op_dec.process_data(cipher + last)
        dec_last, _ = op_dec.finalize()
        assert dec + dec_last == plain


class TestAesCommandCbc:
    """AES CBC 模式 CLI 测试"""

    def test_encrypt_plaintext(self):
        result = runner.invoke(
            aes_command.aes_command,
            [
                "-m", "cbc", "-A", "encrypt",
                "-k", cipherhub_defaults.DEFAULT_KEY_32,
                "-v", cipherhub_defaults.DEFAULT_IV_16,
                "-i", "hello",
            ],
        )
        assert result.exit_code == 0
        assert "cipher:" in result.output or "cipher" in result.output.lower()

    def test_encrypt_decrypt_roundtrip(self):
        """使用程序化 API 验证 CBC 加解密往返（CLI 输出可能被 Rich 截断）"""
        import base64
        from easy_encryption_tool.aes_command import (
            aes_operator,
            padding_data,
            remove_padding_data,
        )
        key = cipherhub_defaults.DEFAULT_KEY_32.encode("utf-8")
        iv = cipherhub_defaults.DEFAULT_IV_16.encode("utf-8")
        plain = b"secret"
        padded = padding_data(plain)
        op_enc = aes_operator(mode="cbc", action="encrypt", key=key, iv=iv, tags=b"", aad=None)
        cipher = op_enc.process_data(padded)
        last, _ = op_enc.finalize()
        cipher_b64 = base64.b64encode(cipher + last).decode("utf-8")
        dec = runner.invoke(
            aes_command.aes_command,
            [
                "-m", "cbc", "-A", "decrypt",
                "-k", cipherhub_defaults.DEFAULT_KEY_32,
                "-v", cipherhub_defaults.DEFAULT_IV_16,
                "-i", cipher_b64, "-e",
            ],
        )
        assert dec.exit_code == 0
        assert "secret" in dec.output or "plain" in dec.output.lower()

    def test_decrypt_without_b64_flag_fails(self):
        result = runner.invoke(
            aes_command.aes_command,
            [
                "-m", "cbc", "-A", "decrypt",
                "-k", cipherhub_defaults.DEFAULT_KEY_32,
                "-v", cipherhub_defaults.DEFAULT_IV_16,
                "-i", "hello",  # plaintext, not cipher
            ],
        )
        assert result.exit_code != 0 or "base64" in result.output.lower()

    def test_b64_and_file_mutually_exclusive(self):
        result = runner.invoke(
            aes_command.aes_command,
            ["-A", "encrypt", "-i", "x", "-e", "-f"],
        )
        assert "mutually" in result.output.lower() and "exclusive" in result.output.lower()

    def test_empty_input_fails(self):
        result = runner.invoke(
            aes_command.aes_command,
            ["-m", "cbc", "-A", "encrypt", "-k", "k" * 32, "-v", "v" * 16, "-i", ""],
        )
        assert result.exit_code != 0 or "no input" in result.output.lower()

    def test_decrypt_without_b64_or_file_fails(self):
        result = runner.invoke(
            aes_command.aes_command,
            [
                "-m", "cbc", "-A", "decrypt",
                "-k", cipherhub_defaults.DEFAULT_KEY_32,
                "-v", cipherhub_defaults.DEFAULT_IV_16,
                "-i", "plaintext",
            ],
        )
        assert result.exit_code != 0 or "decrypt requires" in result.output.lower()

    def test_file_mode_without_output_fails(self, tmp_file):
        path = tmp_file(b"x")
        result = runner.invoke(
            aes_command.aes_command,
            ["-m", "cbc", "-A", "encrypt", "-k", "k" * 32, "-v", "v" * 16, "-i", path, "-f"],
        )
        assert result.exit_code != 0 or "output" in result.output.lower() or "required" in result.output.lower()

    def test_random_key_iv(self):
        result = runner.invoke(
            aes_command.aes_command,
            ["-m", "cbc", "-A", "encrypt", "-r", "-i", "hello"],
        )
        assert result.exit_code == 0
        assert "cipher" in result.output.lower()

    def test_key_b64_iv_b64_encrypt_decrypt_roundtrip(self):
        """--key-b64 and --iv-b64: base64-encoded key/iv for advanced usage"""
        import base64
        from easy_encryption_tool.aes_command import aes_operator, padding_data, remove_padding_data
        key_32 = b"01234567890123456789012345678901"
        iv_16 = b"0123456789012345"
        key_b64 = base64.b64encode(key_32).decode("utf-8")
        iv_b64 = base64.b64encode(iv_16).decode("utf-8")
        # Encrypt programmatically to get cipher
        plain = b"hello"
        padded = padding_data(plain)
        op_enc = aes_operator(mode="cbc", action="encrypt", key=key_32, iv=iv_16, tags=b"", aad=None)
        cipher = op_enc.process_data(padded)
        last, _ = op_enc.finalize()
        cipher_b64 = base64.b64encode(cipher + last).decode("utf-8")
        # Decrypt via CLI with --key-b64 and --iv-b64
        dec = runner.invoke(
            aes_command.aes_command,
            [
                "-m", "cbc", "-A", "decrypt",
                "--key-b64", key_b64,
                "--iv-b64", iv_b64,
                "-i", cipher_b64, "-e",
            ],
        )
        assert dec.exit_code == 0
        assert "hello" in dec.output or "plain" in dec.output.lower()
        # Encrypt via CLI with --key-b64 and --iv-b64
        enc = runner.invoke(
            aes_command.aes_command,
            [
                "-m", "cbc", "-A", "encrypt",
                "--key-b64", key_b64,
                "--iv-b64", iv_b64,
                "-i", "hello",
            ],
        )
        assert enc.exit_code == 0
        assert "cipher" in enc.output.lower()

    def test_key_b64_invalid_base64_fails(self):
        """Invalid base64 key should fail with clear error"""
        result = runner.invoke(
            aes_command.aes_command,
            ["-m", "cbc", "-A", "encrypt", "--key-b64", "invalid!!!base64!!!", "-i", "x"],
        )
        assert "base64" in result.output.lower() or "invalid" in result.output.lower()

    def test_key_b64_wrong_length_fails(self):
        """Key base64 decoded length must be exactly 32 bytes"""
        import base64
        short_key_b64 = base64.b64encode(b"short").decode("utf-8")
        result = runner.invoke(
            aes_command.aes_command,
            ["-m", "cbc", "-A", "encrypt", "--key-b64", short_key_b64, "-i", "x"],
        )
        assert "32" in result.output or "length" in result.output.lower()

    def test_key_and_key_b64_mutually_exclusive(self):
        """-k and --key-b64 cannot be used together"""
        import base64
        key_b64 = base64.b64encode(b"01234567890123456789012345678901").decode("utf-8")
        result = runner.invoke(
            aes_command.aes_command,
            [
                "-m", "cbc", "-A", "encrypt",
                "-k", "01234567890123456789012345678901",
                "--key-b64", key_b64,
                "-i", "hello",
            ],
        )
        assert "mutually exclusive" in result.output.lower()

    def test_gcm_cipher_too_short_fails(self):
        import base64
        # 有效 base64 但解码后 < 16 字节，触发 "too short for gcm tag"
        short_b64 = base64.b64encode(b"x" * 10).decode("utf-8")
        result = runner.invoke(
            aes_command.aes_command,
            [
                "-m", "gcm", "-A", "decrypt",
                "-k", cipherhub_defaults.DEFAULT_KEY_32,
                "-v", cipherhub_defaults.DEFAULT_NONCE_12,
                "-i", short_b64, "-e",
            ],
        )
        assert result.exit_code != 0 or "too short" in result.output.lower() or "invalid" in result.output.lower()

    def test_gcm_decrypt_format_error(self):
        import base64
        bad_b64 = base64.b64encode(b"x" * 10).decode("utf-8")
        result = runner.invoke(
            aes_command.aes_command,
            [
                "-m", "gcm", "-A", "decrypt",
                "-k", cipherhub_defaults.DEFAULT_KEY_32,
                "-v", cipherhub_defaults.DEFAULT_NONCE_12,
                "-i", bad_b64, "-e",
            ],
        )
        assert result.exit_code != 0 or "gcm" in result.output.lower()

    def test_output_file_unwritable(self, tmp_file):
        plain_path = tmp_file(b"x")
        result = runner.invoke(
            aes_command.aes_command,
            [
                "-m", "cbc", "-A", "encrypt",
                "-k", cipherhub_defaults.DEFAULT_KEY_32,
                "-v", cipherhub_defaults.DEFAULT_IV_16,
                "-i", plain_path, "-f", "-o", "/nonexistent/parent/out.enc",
            ],
        )
        assert result.exit_code != 0 or "writable" in result.output.lower() or "error" in result.output.lower()

    def test_file_nonexistent_fails(self):
        result = runner.invoke(
            aes_command.aes_command,
            [
                "-m", "cbc", "-A", "decrypt",
                "-k", cipherhub_defaults.DEFAULT_KEY_32,
                "-v", cipherhub_defaults.DEFAULT_IV_16,
                "-i", "/nonexistent/file.enc", "-f", "-o", "/tmp/out.dec",
            ],
        )
        assert result.exit_code != 0 or "exist" in result.output.lower() or "unreadable" in result.output.lower()


class TestAesCommandGcm:
    """AES GCM 模式 CLI 测试"""

    def test_encrypt_plaintext(self):
        result = runner.invoke(
            aes_command.aes_command,
            [
                "-m", "gcm", "-A", "encrypt",
                "-k", cipherhub_defaults.DEFAULT_KEY_32,
                "-v", cipherhub_defaults.DEFAULT_NONCE_12,
                "-i", "hello",
            ],
        )
        assert result.exit_code == 0

    def test_encrypt_decrypt_roundtrip(self):
        """使用程序化 API 验证 GCM 加解密往返"""
        import base64
        from easy_encryption_tool.aes_command import aes_operator
        key = cipherhub_defaults.DEFAULT_KEY_32.encode("utf-8")
        iv = cipherhub_defaults.DEFAULT_NONCE_12.encode("utf-8")
        aad = cipherhub_defaults.DEFAULT_AAD.encode("utf-8")
        plain = b"data"
        op_enc = aes_operator(mode="gcm", action="encrypt", key=key, iv=iv, tags=b"", aad=aad)
        cipher = op_enc.process_data(plain)
        last, tag = op_enc.finalize()
        cipher_with_tag = cipher + last + tag
        cipher_b64 = base64.b64encode(cipher_with_tag).decode("utf-8")
        dec = runner.invoke(
            aes_command.aes_command,
            [
                "-m", "gcm", "-A", "decrypt",
                "-k", cipherhub_defaults.DEFAULT_KEY_32,
                "-v", cipherhub_defaults.DEFAULT_NONCE_12,
                "-i", cipher_b64, "-e",
            ],
        )
        assert dec.exit_code == 0
        assert "data" in dec.output or "plain" in dec.output.lower()

    def test_gcm_with_padding_roundtrip(self):
        """GCM --gcm-pad 加解密往返（程序化验证）"""
        import base64
        from easy_encryption_tool.aes_command import aes_operator, padding_data, remove_padding_data

        key = cipherhub_defaults.DEFAULT_KEY_32.encode("utf-8")
        iv = cipherhub_defaults.DEFAULT_NONCE_12.encode("utf-8")
        aad = cipherhub_defaults.DEFAULT_AAD.encode("utf-8")
        plain = b"padded plaintext"
        padded = padding_data(plain)
        op_enc = aes_operator(mode="gcm", action="encrypt", key=key, iv=iv, tags=b"", aad=aad)
        cipher = op_enc.process_data(padded)
        last, tag = op_enc.finalize()
        cipher_with_tag = cipher + last + tag
        cipher_b64 = base64.b64encode(cipher_with_tag).decode("utf-8")

        dec = runner.invoke(
            aes_command.aes_command,
            [
                "-m", "gcm", "-A", "decrypt", "--gcm-pad",
                "-k", cipherhub_defaults.DEFAULT_KEY_32,
                "-v", cipherhub_defaults.DEFAULT_NONCE_12,
                "-i", cipher_b64, "-e",
            ],
        )
        assert dec.exit_code == 0
        assert "padded plaintext" in dec.output or "plain" in dec.output.lower()


class TestAesHelperFunctions:
    """AES 辅助函数单元测试"""

    def test_padding_data(self):
        from easy_encryption_tool.aes_command import padding_data, remove_padding_data
        data = b"hello"
        padded = padding_data(data)
        assert len(padded) > len(data)
        assert remove_padding_data(padded) == data

    def test_remove_padding_empty(self):
        from easy_encryption_tool.aes_command import remove_padding_data
        assert remove_padding_data(b"") == b""
        assert remove_padding_data(None) == b""

    def test_process_key_iv(self):
        from easy_encryption_tool.aes_command import process_key_iv
        key, iv = process_key_iv(
            False, cipherhub_defaults.DEFAULT_KEY_32,
            cipherhub_defaults.DEFAULT_IV_16, "cbc"
        )
        assert len(key) == 32
        assert len(iv) == 16

    def test_generate_random_key_iv(self):
        from easy_encryption_tool.aes_command import process_key_iv
        key, iv = process_key_iv(True, "", "", "cbc")
        assert len(key) == 32
        assert len(iv) == 16


class TestAesFileMode:
    """AES 文件模式测试"""

    def test_encrypt_file_to_file(self, tmp_file):
        plain_path = tmp_file(b"file content here")
        out_path = plain_path + ".enc"
        result = runner.invoke(
            aes_command.aes_command,
            [
                "-m", "cbc", "-A", "encrypt",
                "-k", cipherhub_defaults.DEFAULT_KEY_32,
                "-v", cipherhub_defaults.DEFAULT_IV_16,
                "-i", plain_path, "-f", "-o", out_path,
            ],
        )
        assert result.exit_code == 0
        assert os.path.exists(out_path)
        assert os.path.getsize(out_path) > 0

    def test_encrypt_decrypt_file_roundtrip_cbc(self, tmp_file):
        plain_path = tmp_file(b"secret file content")
        enc_path = plain_path + ".enc"
        dec_path = plain_path + ".dec"
        enc = runner.invoke(
            aes_command.aes_command,
            [
                "-m", "cbc", "-A", "encrypt",
                "-k", cipherhub_defaults.DEFAULT_KEY_32,
                "-v", cipherhub_defaults.DEFAULT_IV_16,
                "-i", plain_path, "-f", "-o", enc_path,
            ],
        )
        assert enc.exit_code == 0
        dec = runner.invoke(
            aes_command.aes_command,
            [
                "-m", "cbc", "-A", "decrypt",
                "-k", cipherhub_defaults.DEFAULT_KEY_32,
                "-v", cipherhub_defaults.DEFAULT_IV_16,
                "-i", enc_path, "-f", "-o", dec_path,
            ],
        )
        assert dec.exit_code == 0
        assert Path(dec_path).read_bytes() == b"secret file content"

    def test_encrypt_decrypt_file_roundtrip_gcm(self, tmp_file):
        plain_path = tmp_file(b"gcm file data")
        enc_path = plain_path + ".enc"
        dec_path = plain_path + ".dec"
        enc = runner.invoke(
            aes_command.aes_command,
            [
                "-m", "gcm", "-A", "encrypt",
                "-k", cipherhub_defaults.DEFAULT_KEY_32,
                "-v", cipherhub_defaults.DEFAULT_NONCE_12,
                "-i", plain_path, "-f", "-o", enc_path,
            ],
        )
        assert enc.exit_code == 0
        dec = runner.invoke(
            aes_command.aes_command,
            [
                "-m", "gcm", "-A", "decrypt",
                "-k", cipherhub_defaults.DEFAULT_KEY_32,
                "-v", cipherhub_defaults.DEFAULT_NONCE_12,
                "-i", enc_path, "-f", "-o", dec_path,
            ],
        )
        assert dec.exit_code == 0
        assert Path(dec_path).read_bytes() == b"gcm file data"
