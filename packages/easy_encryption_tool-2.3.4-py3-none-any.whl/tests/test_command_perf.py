#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
command_perf 模块单元测试。
"""
from __future__ import annotations

from unittest.mock import patch

import pytest

from easy_encryption_tool import command_perf


def _dummy_func():
    return 42


class TestTimingDecorator:
    def test_decorator_returns_result(self):
        decorated = command_perf.timing_decorator(_dummy_func)
        assert decorated() == 42

    def test_decorator_with_debug_timing(self, monkeypatch):
        monkeypatch.setenv("EET_DEBUG_TIMING", "1")
        decorated = command_perf.timing_decorator(_dummy_func)
        with patch("easy_encryption_tool.command_perf.timing_begin"), \
             patch("easy_encryption_tool.command_perf.timing_end"):
            result = decorated()
        assert result == 42
