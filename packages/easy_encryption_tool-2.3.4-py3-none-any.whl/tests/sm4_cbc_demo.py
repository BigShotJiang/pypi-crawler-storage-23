#!/usr/bin/env python
# coding=utf-8
"""SM4-CBC 加解密示例：明文 UTF-8 编码后直接 Update + Finish，由 Finish 完成 PKCS7 padding"""
from easy_gmssl import EasySm4CBC, EasySm4GCM, EasySm4CTR
from easy_gmssl.gmssl import SM4_BLOCK_SIZE, SM4_CBC_IV_SIZE, SM4_CTR_IV_SIZE
import base64

key = "0123456789012345".encode("utf-8")
print(key.hex())
iv = "0123456789012345".encode("utf-8")
print(iv.hex())
plain = "你好，密码学人 CipherHUB!"
plain_bytes = plain.encode("utf-8")
print(plain_bytes.hex())
print(len(plain_bytes))
enc = EasySm4CBC(key, iv, True)
cipher = enc.Update(plain_bytes) + enc.Finish()
print(cipher.hex())
print(len(cipher))
cipher_b64 = base64.b64encode(cipher).decode("utf-8")
print(cipher_b64)
