#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Random string 命令单元测试。
"""
from __future__ import annotations

import os
from pathlib import Path

import pytest
from click.testing import CliRunner

from .conftest import strip_ansi
from easy_encryption_tool import random_str


runner = CliRunner()


class TestGenerateRandomStr:
    """generate_random_str 函数测试"""

    def test_generate_length(self):
        s = random_str.generate_random_str(32)
        assert len(s) == 32
        assert isinstance(s, str)

    def test_generate_different_each_time(self):
        a = random_str.generate_random_str(64)
        b = random_str.generate_random_str(64)
        assert a != b

    def test_generate_contains_allowed_chars(self):
        from easy_encryption_tool.random_str import characters
        s = random_str.generate_random_str(100)
        for c in s:
            assert c in characters


class TestGenerateRandomBytes:
    """generate_random_bytes 函数测试"""

    def test_generate_bytes_length(self):
        b = random_str.generate_random_bytes(16)
        assert len(b) == 16
        assert isinstance(b, bytes)


class TestGetRandomStrCommand:
    """get_random_str CLI 命令测试"""

    def test_default_length(self):
        result = runner.invoke(random_str.get_random_str, [])
        assert result.exit_code == 0
        clean = strip_ansi(result.output).strip()
        assert len(clean) == 32

    def test_custom_length(self):
        result = runner.invoke(
            random_str.get_random_str,
            ["-l", "64"],
        )
        assert result.exit_code == 0
        clean = strip_ansi(result.output).strip()
        assert len(clean) == 64

    def test_output_to_file(self, tmp_dir):
        out_path = os.path.join(tmp_dir, "random_out.txt")
        result = runner.invoke(
            random_str.get_random_str,
            ["-l", "16", "-o", out_path],
        )
        assert result.exit_code == 0
        assert os.path.exists(out_path)
        with open(out_path, "rb") as f:
            content = f.read()
        assert len(content) == 16

    def test_output_to_file_no_force_fails_on_existing(self, tmp_dir):
        out_path = os.path.join(tmp_dir, "existing.txt")
        Path(out_path).write_bytes(b"old")
        result = runner.invoke(
            random_str.get_random_str,
            ["-l", "16", "-o", out_path, "--no-force"],
        )
        # 已存在文件且 no_force 时不应覆盖
        assert Path(out_path).read_bytes() == b"old"

    def test_long_string_chunked_output(self):
        result = runner.invoke(
            random_str.get_random_str,
            ["-l", "100"],
        )
        assert result.exit_code == 0
        clean = strip_ansi(result.output).strip()
        assert len(clean) == 100
