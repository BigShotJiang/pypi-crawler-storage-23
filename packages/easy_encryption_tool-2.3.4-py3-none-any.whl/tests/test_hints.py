#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
hints 模块单元测试。
"""
from __future__ import annotations

from unittest.mock import patch

import pytest

from .conftest import strip_ansi
from easy_encryption_tool import hints


class TestHintMissingGmssl:
    def test_hint_missing_gmssl(self):
        with patch("easy_encryption_tool.hints.warning") as mock_warn, \
             patch("easy_encryption_tool.hints.hint") as mock_hint:
            hints.hint_missing_gmssl("SM3")
            mock_warn.assert_called_once()
            assert "SM3" in mock_warn.call_args[0][0]
            assert mock_hint.call_count >= 1


class TestHintInvalidB64:
    def test_hint_invalid_b64_no_context(self):
        with patch("easy_encryption_tool.hints.hint") as mock_hint:
            hints.hint_invalid_b64()
            calls = [c[0][0] for c in mock_hint.call_args_list]
            assert any("base64" in s.lower() or "解密" in s or "-e" in s for s in calls)

    def test_hint_invalid_b64_with_context(self):
        with patch("easy_encryption_tool.hints.hint") as mock_hint:
            hints.hint_invalid_b64(context="decrypt")
            mock_hint.assert_called()
            assert "decrypt" in mock_hint.call_args[0][0].lower()


class TestHintInputFileOrB64Conflict:
    def test_hint_input_file_or_b64_conflict(self):
        with patch("easy_encryption_tool.hints.warning") as mock_warn, \
             patch("easy_encryption_tool.hints.hint") as mock_hint:
            hints.hint_input_file_or_b64_conflict()
            mock_warn.assert_called_once()
            assert "-e" in mock_warn.call_args[0][0] and "-f" in mock_warn.call_args[0][0]
            mock_hint.assert_called()
