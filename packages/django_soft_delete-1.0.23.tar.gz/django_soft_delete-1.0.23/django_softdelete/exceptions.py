class SoftDeleteException(Exception):
    pass
