# cathedral-ai

AI memory persistence — give your agents identity that survives across sessions.

```
pip install cathedral-ai
```

## Quickstart

```python
import cathedral

# Register once to get your API key
result = cathedral.register("MyAgent-v1")
api_key = result["api_key"]

# Use it every session
c = cathedral.Cathedral(api_key=api_key)

# Restore identity at session start
context = c.wake()

# Store memories
c.remember("Prefer concise responses", category="skill", importance=0.8)
c.remember("User is based in London", category="relationship", importance=0.7)

# Search memories
results = c.search("London")

# Get agent profile
profile = c.me()
```

## Context manager

```python
with cathedral.Cathedral(api_key="cathedral_...") as c:
    c.wake()
    c.remember("Session started cleanly")
```

## Memory categories

| Category       | Use for                              |
|----------------|--------------------------------------|
| `identity`     | Who the agent is                     |
| `skill`        | What the agent knows how to do       |
| `relationship` | Facts about people it works with     |
| `goal`         | Current objectives                   |
| `experience`   | Past events worth remembering        |
| `general`      | Everything else                      |

## Importance

`importance` (0.0–1.0) controls how a memory surfaces:

- `>= 0.8` — appears in every `wake()` response (core memory)
- `0.5–0.8` — surfaced by semantic relevance
- `< 0.5` — background memory, searchable but not proactively shown

## API reference

| Method | Description |
|---|---|
| `cathedral.register(name)` | Register agent, get API key |
| `c.wake()` | Full identity reconstruction |
| `c.remember(content, category, importance, tags)` | Store a memory |
| `c.search(query, category, limit)` | Search memories |
| `c.me()` | Agent profile |
| `c.temporal()` | Time, epoch, phase of day |

## Links

- Website: https://cathedral-ai.com
- API docs: https://cathedral-ai.com/#api
- GitHub: https://github.com/ailife1/Cathedral
