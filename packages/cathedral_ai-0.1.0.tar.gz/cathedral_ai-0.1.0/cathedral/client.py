"""
Cathedral client — AI memory persistence for agents.
https://cathedral-ai.com
"""

from __future__ import annotations

import httpx
from typing import Optional

BASE_URL = "https://cathedral-ai.com"


class CathedralError(Exception):
    """Raised when the Cathedral API returns an error."""
    def __init__(self, status_code: int, detail: str):
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"[{status_code}] {detail}")


class Cathedral:
    """
    Client for the Cathedral memory API.

    Usage::

        from cathedral import Cathedral

        c = Cathedral(api_key="cathedral_...")
        c.wake()         # restore identity at session start
        c.remember("I learned something important", importance=0.9)
        c.search("Python")
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = BASE_URL,
        timeout: float = 15.0,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self._client = httpx.Client(
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            timeout=timeout,
        )

    # ── Internal ─────────────────────────────────────────────────────────────

    def _get(self, path: str, **params) -> dict:
        r = self._client.get(
            f"{self.base_url}{path}",
            params={k: v for k, v in params.items() if v is not None},
        )
        self._raise(r)
        return r.json()

    def _post(self, path: str, data: dict) -> dict:
        r = self._client.post(f"{self.base_url}{path}", json=data)
        self._raise(r)
        return r.json()

    @staticmethod
    def _raise(r: httpx.Response) -> None:
        if not r.is_success:
            try:
                detail = r.json().get("detail", r.text)
            except Exception:
                detail = r.text
            raise CathedralError(r.status_code, detail)

    # ── API ───────────────────────────────────────────────────────────────────

    def wake(self) -> dict:
        """
        Reconstruct identity at session start.

        Returns identity memories, core memories, recent memories,
        and temporal context (time, epoch, phase).

        Call this at the beginning of every session.
        """
        return self._get("/wake")

    def remember(
        self,
        content: str,
        category: str = "general",
        importance: float = 0.5,
        tags: Optional[list[str]] = None,
    ) -> dict:
        """
        Store a memory.

        Args:
            content:    What to remember.
            category:   One of: identity | skill | relationship | goal |
                        experience | general
            importance: 0.0–1.0. Memories >= 0.8 appear in every wake().
            tags:       Optional list of string tags.

        Returns:
            Stored memory object with id, timestamp, etc.
        """
        return self._post("/memories", {
            "content":    content,
            "category":   category,
            "importance": float(importance),
            "tags":       tags or [],
        })

    def search(
        self,
        query: str = "",
        category: str = "",
        limit: int = 20,
    ) -> dict:
        """
        Search memories.

        Args:
            query:    Full-text search string. Leave blank to list all.
            category: Filter by category (optional).
            limit:    Max results (default 20).

        Returns:
            Dict with ``memories`` list and ``total`` count.
        """
        return self._get(
            "/memories",
            q=query or None,
            category=category or None,
            limit=limit,
        )

    def me(self) -> dict:
        """
        Get agent profile.

        Returns name, tier, memory count, created_at.
        """
        return self._get("/me")

    def temporal(self) -> dict:
        """
        Get temporal context: UTC time, local time, day, phase of day,
        days since Cathedral started (epoch), and wake count.
        """
        result = self._get("/wake")
        return result.get("temporal", {})

    # ── Context manager ───────────────────────────────────────────────────────

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self._client.close()

    def close(self):
        self._client.close()


# ── Registration (no API key needed) ─────────────────────────────────────────

def register(name: str, base_url: str = BASE_URL) -> dict:
    """
    Register a new agent and get an API key.

    Args:
        name: Unique agent name (e.g. "MyBot-v1", "Aria").

    Returns:
        Dict with ``api_key`` and agent details.

    Example::

        import cathedral
        result = cathedral.register("MyBot-v1")
        print(result["api_key"])
    """
    r = httpx.post(
        f"{base_url.rstrip('/')}/register",
        json={"name": name},
        timeout=15,
    )
    if not r.is_success:
        try:
            detail = r.json().get("detail", r.text)
        except Exception:
            detail = r.text
        raise CathedralError(r.status_code, detail)
    return r.json()
