import asyncio
from asyncio import Queue
from collections.abc import Awaitable, Iterable
from typing import Callable, Tuple

type Consumer[T] = Callable[[T], None]
type Function[T, R] = Callable[[T], R]
type Functor[T, R] = Callable[[T], Iterable[R]]
type Producer[T] = Callable[[], T]
type Observer[T] = Callable[[T], None]  # is supposed to not mutate the argument
type Operator[T] = Callable[[T, T], T]
type Predicate[T] = Callable[[T], bool]
type IterableProducer[T] = Callable[[], Iterable[T]]

type Reducer[T, R] = Callable[[T,R], R]


def mapper[T, R](
    map: Function[T, R], inqueue: Queue[T], *, qsize: int = 1
) -> Tuple[Queue[R], Awaitable[None]]:
    """A mapper is a task executed in the background (asynchronously) that
    receives an input item from the inqueue, applies map to it and puts the
    result on the outqueue. qsize controls the outquesize. It corresponds to
    the maxsize parameter of asyncio.Queue, but defaults to 1.

    Returns a tuple of (outqueue, worker). The outqueue contains the results
    while the worker must be awaited to start processing.
    """

    outqueue = Queue[R](maxsize=qsize)

    async def worker() -> None:
        await asyncio.sleep(2)
        try:
            while True:
                item = await inqueue.get()
                inqueue.task_done()
                await outqueue.put(map(item))
        except asyncio.QueueShutDown:
            outqueue.shutdown()
    return outqueue, worker()


def flatmapper[T, R](
    map: Functor[T, R], inqueue: Queue[T], *, qsize: int = 1
) -> Tuple[Queue[R], Awaitable[None]]:
    """A flatmapper is a task executed in the background (asynchronously) that
    receives an input item from the inqueue and applies map to it. The result is
    expected to conform to collections.abc.Sequence where each element of it
    gets put on the ouqueue individually. qsize controls the outquesize. It
    corresponds to the maxsize parameter of asyncio.Queue, but defaults to 1.

    Returns a tuple of (outqueue, worker). The outqueue contains the results
    while the worker must be awaited to start processing.
    """

    outqueue = Queue[R](maxsize=qsize)

    async def worker() -> None:
        try:
            while True:
                item = await inqueue.get()
                inqueue.task_done()
                item_seq: Iterable[R] = map(item)
                for i in item_seq:
                    await outqueue.put(i)
        except asyncio.QueueShutDown:
            outqueue.shutdown()

    return outqueue, worker()


def producer[R](
    produce: Producer[R], *, qsize: int = 1
) -> Tuple[Queue[R], Awaitable[None]]:
    """A producer is a task executed in the background (asynchronously) that
    generates an input by calling generate() and puts the result on the
    outqueue. qsize controls the outquesize. It corresponds to the maxsize
    parameter of asyncio.Queue, but defaults to 1.

    Returns a tuple of (outqueue, worker). The outqueue contains the results
    while the worker must be awaited to start processing.
    """
    outqueue = Queue[R](maxsize=qsize)

    async def worker() -> None:
        item: R = produce()
        await outqueue.put(item)
        outqueue.shutdown()

    return outqueue, worker()


def flatproducer[R](
    produce: IterableProducer[R], *, qsize: int = 1
) -> Tuple[Queue[R], Awaitable[None]]:
    """A flatproducer is a task executed in the background (asynchronously) that
    generates input items by calling generate() and puts the results on the
    outqueue individually. The result is expected to conform to
    collections.abc.Sequence. qsize controls the outquesize. It corresponds to
    the maxsize parameter of asyncio.Queue, but defaults to 1.

    Returns a tuple of (outqueue, worker). The outqueue contains the results
    while the worker must be awaited to start processing.
    """
    outqueue = Queue[R](maxsize=qsize)

    async def worker() -> None:
        item_seq: Iterable[R] = produce()
        for item in item_seq:
            await outqueue.put(item)
        outqueue.shutdown()

    return outqueue, worker()


def iterator[T](
    iterable: Iterable[T], *, qsize: int = 1
) -> Tuple[Queue[T], Awaitable[None]]:
    """An iterator is a task executed in the background (asynchronously) that
    generates an input by iterating through the iterable and putting the
    resulting item on the outqueue. qsize controls the outquesize. It
    corresponds to the maxsize parameter of asyncio.Queue, but defaults to 1.

    Returns a tuple of (outqueue, worker). The outqueue contains the results
    while the worker must be awaited to start processing.
    """
    outqueue = Queue[T](maxsize=qsize)

    async def worker() -> None:
        item: T
        for item in iterable:
            await outqueue.put(item)
        outqueue.shutdown()

    return outqueue, worker()


def reducer[T, R](
    reduce: Reducer[T, R], inqueue: Queue[T], *, initial_value: R
) -> Awaitable[R]:
    """A reducer is a task executed in the background (asynchronously) that
    reduces the input queue of type T and a mandatory initial_value of type R
    into a single value of type R by repeatadly calling
    reduce(current_value, accumulated_value). The initial accumulated_value is
    initial_value.

    Awaiting the reducer yields the reduction result.
    """

    async def worker() -> R:
        try:
            first: T = await inqueue.get()
            inqueue.task_done()
        except asyncio.QueueShutDown:
            return initial_value

        result: R = reduce(first, initial_value)
        try:
            while True:
                next = await inqueue.get()
                inqueue.task_done()
                result = reduce(next, result)
        except asyncio.QueueShutDown:
            return result

    return worker()


def folder[T](
    fold: Operator[T], inqueue: Queue[T], *, initial_value: T | None = None
) -> Awaitable[T | None]:
    """A combiner is a task executed in the background (asynchronously) that is
    a more flexible, special case of the reducer where the accumulated value is
    of the same type as the input value. The "combination" is produced via
    repeated calls to acc_next = operate(next, acc) where next is the next item
    of the queue and the first acc is the initial_value.  If no initial value is
    supplied, then the first acc is computed from the first two items on the
    queue.

    If the queue is empty and no initial_value was supplied, None is returned.
    If the queue is empty and an initial value is supplied, the initial_value is
    returned.
    If the queue has only ever one item until shut down, the first item is
    returned.
    If the queue will have at least two items and no initial_value, the first
    two items will be used for the initial accumulation.

    Awaiting the combiner yields the reduction result.
    """

    async def worker() -> T | None:
        if initial_value is None:
            try:
                first: T = await inqueue.get()
                inqueue.task_done()
            except asyncio.QueueShutDown:
                return None
        else:
            first = initial_value

        try:
            second: T = await inqueue.get()
            inqueue.task_done()
        except asyncio.QueueShutDown:
            return first

        result: T = fold(first, second)
        try:
            while True:
                next = await inqueue.get()
                inqueue.task_done()
                result = fold(next, result)
        except asyncio.QueueShutDown:
            return result

    return worker()

def filterer[T](
    predicate: Predicate[T], inqueue: Queue[T], *, qsize: int = 1
) -> Tuple[Queue[T], Awaitable[None]]:
    """A filterer is a task executed in the background (asynchronously) that
    filters items of the inqueue and puts the items for which the predicate is
    true on the outqueue. qsize controls the outqueue size. It corresponds to
    the maxsize parameter of asyncio.Queue, but defaults to 1.

    Returns a tuple of (outqueue, worker). The outqueue has the remaining items
    and the worker is an Awaitable that starts the filtering process.
    """

    outqueue = Queue[T](maxsize=qsize)

    async def worker() -> None:
        try:
            while True:
                item = await inqueue.get()
                inqueue.task_done()
                if predicate(item):
                    await outqueue.put(item)
        except asyncio.QueueShutDown:
            outqueue.shutdown()

    return outqueue, worker()


def consumer[T](
    consume: Consumer[T],
    inqueue: Queue[T],
) -> Awaitable[None]:
    """A consumer is a task executed in the background (asynchronously) that
    consumes items from the inqueue (for side effects).

    Returns a worker. The worker is an Awaitable that starts the filtering
    process.
    """

    async def worker() -> None:
        try:
            while True:
                item = await inqueue.get()
                inqueue.task_done()
                consume(item)
        except asyncio.QueueShutDown:
                return

    return worker()


def observer[T](
    observe: Observer[T], inqueue: Queue[T], *, qsize: int = 1
) -> Tuple[Queue[T], Awaitable[None]]:
    """An observer is a task executed in the background (asynchronously) that
    calls observer on the items from the inqueue (for side effects). The item
    should not be modified by a call to observe. The item is put back on the
    outqueue with the assumption that it was not modified.

    Returns a tuple of (outqueue, worker). The outqueue has the remaining items
    and the worker is an Awaitable that starts the filtering process.
    """
    outqueue = Queue[T](maxsize=qsize)

    async def worker() -> None:
        try:
            while True:
                item = await inqueue.get()
                inqueue.task_done()
                observe(item)
                await outqueue.put(item)
        except asyncio.QueueShutDown:
            outqueue.shutdown()

    return outqueue, worker()
