# voxd

Voice dictation daemon for Linux with modular architecture:

- `core`: recording, Sarvam AI transcription, and clipboard integration
- `wrapper.dwm`: X11-focused wrapper for `dwm`
- `wrapper.hyprland`: Wayland-focused wrapper for `hyprland`

Press keybind once to start recording, press again to stop. Transcribed text is copied to clipboard.

## Install

```bash
pip install voxd
```

System dependencies:

- `ffmpeg` (audio capture)
- `xclip` or `xsel` (clipboard on X11)
- `wl-clipboard` (clipboard on Wayland)

## Setup

### 1. Configure API key

```bash
voxd config set api_key YOUR_SARVAM_API_KEY
```

### 2. (Optional) Set language

```bash
voxd config set language hi-IN  # Hindi
voxd config set language en-IN  # English (default)
```

### 3. Start daemon at boot

**dwm / X11** - Add to `~/.xinitrc` (before `exec dwm`):

```bash
voxd-daemon &
```

**hyprland / Wayland** - Add to `~/.config/hypr/hyprland.conf`:

```ini
exec-once = voxd-daemon
```

### 4. Setup keybind

**dwm** - Edit your `config.h`:

```c
{ MODKEY, XK_semicolon, spawn, SHCMD("voxd-dwm toggle") },
```

Then recompile: `sudo make clean install`

**hyprland** - Add to `~/.config/hypr/hyprland.conf`:

```ini
bind = SUPER, semicolon, exec, voxd-hypr toggle
```

Reload: `hyprctl reload`

## Usage

Press your keybind once to start recording, press again to stop. The transcribed text is copied to clipboard - paste with Ctrl+V!

Terminal commands:

```bash
voxd toggle              # Toggle recording
voxd status              # Check status
voxd quit                # Stop daemon
voxd config list         # Show config
voxd config set key val  # Set config value
```

## Configuration

Config is stored in `~/.config/voxd/config.json`

Available settings:
- `api_key` - Sarvam AI API key
- `model` - STT model (default: saaras:v3)
- `language` - Language code (default: en-IN)
- `output_mode` - Output mode (auto/x11/wayland)

## Architecture

```text
src/voxd/
  core/
    config.py          # env + runtime paths
    config_manager.py  # persistent config
    recorder.py        # ffmpeg process lifecycle
    sarvam_client.py   # Sarvam SDK integration
    injector.py        # clipboard integration
    service.py         # unix socket daemon + toggle logic
  wrappers/
    dwm.py             # X11 wrapper (output mode x11)
    hyprland.py        # Wayland wrapper (output mode wayland)
  cli.py               # daemon server + client commands
```

## Notes

- Socket path: `${XDG_RUNTIME_DIR}/voxd/control.sock`
- Captured `.wav` files: `${XDG_RUNTIME_DIR}/voxd/`
- Status file: `${XDG_RUNTIME_DIR}/voxd/status`
- Notifications show recording state via `notify-send`
