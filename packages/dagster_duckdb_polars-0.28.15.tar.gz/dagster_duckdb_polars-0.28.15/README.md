# dagster-duckdb-polars

The docs for `dagster-duckdb-polars` can be found
[here](https://docs.dagster.io/integrations/libraries/duckdb/dagster-duckdb-polars).
