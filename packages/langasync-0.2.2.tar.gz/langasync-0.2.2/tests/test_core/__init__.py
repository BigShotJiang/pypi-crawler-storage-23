"""Tests for core functionality."""
