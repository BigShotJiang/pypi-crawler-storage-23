"""Allow running muban_cli as a module: python -m muban_cli"""

from muban_cli.cli import main

if __name__ == "__main__":
    main()
