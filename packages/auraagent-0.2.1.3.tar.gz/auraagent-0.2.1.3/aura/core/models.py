"""
Modèles Pydantic partagés entre les composants carbon et web.
"""

import platform
import socket
from datetime import datetime
from typing import Optional
from pydantic import BaseModel


# ─── Authentification ─────────────────────────────────────────────────────────

class LoginRequest(BaseModel):
    """
        Requête de vérification envoyée à POST /api/auth/verify/

        Le server_url n'est pas saisi par l'utilisateur :
        il est hardcodé dans aura.core.constants.AURA_SERVER_URL.
    """
    email: str
    api_key: str


class LoginResponse(BaseModel):
    """
        Réponse du serveur après vérification réussie.

        Le serveur retourne l'api_endpoint cible (pour les émissions),
        ainsi que les métadonnées utilisateur.
    """
    api_endpoint: str           # URL complète vers laquelle envoyer les émissions
    user_id: str
    organization: Optional[str] = None
    default_project: Optional[str] = None


# ─── Machine ──────────────────────────────────────────────────────────────────

class MachineInfo(BaseModel):
    """
        Informations sur la machine locale, collectées automatiquement
        et envoyées à POST /api/machines/register/
    """
    hostname: str
    os: str                     # "Darwin", "Linux", "Windows"
    os_version: str             # "macOS 14.2", "Ubuntu 22.04", etc.
    cpu_model: Optional[str] = None
    cpu_count: Optional[int] = None
    gpu_model: Optional[str] = None
    ram_total_gb: Optional[float] = None
    python_version: str
    aura_version: str

    @classmethod
    def collect(cls) -> "MachineInfo":
        """
            Collecte automatiquement les informations de la machine locale.
            N'échoue jamais — les champs inconnus sont mis à None.
        """
        import sys

        cpu_model = None
        cpu_count = None
        ram_total_gb = None
        gpu_model = None

        # CPU
        try:
            import cpuinfo
            info = cpuinfo.get_cpu_info()
            cpu_model = info.get("brand_raw")
        except Exception:
            pass

        try:
            import psutil
            cpu_count = psutil.cpu_count(logical=False)
            ram_total_gb = round(psutil.virtual_memory().total / (1024 ** 3), 1)
        except Exception:
            pass

        # GPU (NVIDIA)
        try:
            import pynvml
            pynvml.nvmlInit()
            handle = pynvml.nvmlDeviceGetHandleByIndex(0)
            gpu_model = pynvml.nvmlDeviceGetName(handle)
        except Exception:
            pass

        # Version Aura (le package PyPI s'appelle "auraagent")
        try:
            from importlib.metadata import version
            aura_version = version("auraagent")
        except Exception:
            aura_version = "unknown"

        return cls(
            hostname=socket.gethostname(),
            os=platform.system(),
            os_version=platform.platform(),
            cpu_model=cpu_model,
            cpu_count=cpu_count,
            gpu_model=gpu_model,
            ram_total_gb=ram_total_gb,
            python_version=sys.version.split()[0],
            aura_version=aura_version,
        )


class MachineRegisterResponse(BaseModel):
    """Réponse du serveur après enregistrement de la machine."""
    machine_id: str             # UUID à stocker dans ~/.aura.config


# ─── Emissions ────────────────────────────────────────────────────────────────

class EmissionPayload(BaseModel):
    """Données d'émissions envoyées au serveur Aura."""

    # Identifiants
    run_id: str
    project_name: str
    machine_id: Optional[str] = None       # UUID machine depuis ~/.aura.config
    experiment_id: Optional[str] = None

    # Mesures principales
    timestamp: datetime
    duration: float                        # secondes
    emissions: float                       # kg CO2eq
    emissions_rate: float                  # kg CO2eq/s
    energy_consumed: float                 # kWh

    # Puissance par composant (Watts)
    cpu_power: float
    gpu_power: float
    ram_power: float

    # Énergie par composant (kWh)
    cpu_energy: float
    gpu_energy: float
    ram_energy: float

    # Utilisation
    cpu_utilization_percent: Optional[float] = None
    gpu_utilization_percent: Optional[float] = None
    ram_utilization_percent: Optional[float] = None
    ram_used_gb: Optional[float] = None

    # Géographie
    country_name: Optional[str] = None
    country_iso_code: Optional[str] = None
    region: Optional[str] = None
    cloud_provider: Optional[str] = None
    cloud_region: Optional[str] = None
    on_cloud: Optional[str] = None

    # Système
    os: Optional[str] = None
    python_version: Optional[str] = None
    codecarbon_version: Optional[str] = None
    cpu_model: Optional[str] = None
    cpu_count: Optional[int] = None
    gpu_model: Optional[str] = None
    gpu_count: Optional[int] = None
    ram_total_size: Optional[float] = None

    # Data center
    tracking_mode: Optional[str] = None
    pue: Optional[float] = 1.0
    wue: Optional[float] = 0.0


# ─── Tracker status ───────────────────────────────────────────────────────────

class TrackerStatus(BaseModel):
    """Statut courant du tracker (utilisé par l'API web locale)."""
    running: bool
    project_name: Optional[str] = None
    started_at: Optional[datetime] = None
    emissions: Optional[float] = None      # kg CO2eq
    energy_consumed: Optional[float] = None  # kWh
    duration: Optional[float] = None       # secondes
