"""Exceptions personnalisées du package Aura."""


class AuraError(Exception):
    """Exception de base pour toutes les erreurs Aura."""
    pass


class AuraConfigError(AuraError):
    """Erreur liée à la configuration (~/.aura.config manquant ou invalide)."""
    pass


class AuraAuthError(AuraError):
    """Erreur d'authentification avec le serveur Aura."""
    pass


class AuraAPIError(AuraError):
    """Erreur lors d'un appel à l'API Aura."""

    def __init__(self, message: str, status_code: int = None):
        super().__init__(message)
        self.status_code = status_code
