"""
Aura — Carbon tracking and AI bias analysis toolkit.

Composants disponibles :
    - aura.carbon  : Mesure d'émissions CO2 (wrapper CodeCarbon)
    - aura.bias    : Analyse de biais pour modèles IA
    - aura.core    : Utilitaires partagés (config, auth, logging)

Configuration :
    Créez ~/.aura.config :
        [aura]
        api_endpoint = https://votre-serveur.com
        api_key = votre_cle_api
        default_project = mon-projet

    Ou passez les paramètres directement :
        BiasAnalyzer(api_key="...", api_url="https://...")

Usage rapide :

    # Tracking carbone
    from aura.carbon import AuraCarbon

    tracker = AuraCarbon()
    tracker.start()
    # ... ton code ...
    tracker.stop()

    # Analyse de biais
    from aura.bias import BiasAnalyzer

    def my_model(question: str) -> str:
        return "A"  # Logique de votre modèle

    analyzer = BiasAnalyzer(
        api_key="votre_cle",
        api_url="https://cevia.ai"
    )
    results = analyzer.analyze(
        model_callable=my_model,
        model_name="Mon Modèle",
        number_of_tests=60
    )
"""

__version__ = "0.2.0"
__author__ = "CEVIA"
__email__ = "info@cevia.ai"

# Exports publics principaux
from aura.carbon import AuraCarbon
from aura.carbon.decorators import track_emissions
from aura.bias import BiasAnalyzer

__all__ = [
    "AuraCarbon",
    "BiasAnalyzer",
    "track_emissions",
    "__version__",
]
