"""
    AuraOutput — Sortie HTTP vers le serveur Aura/Django.

    Hérite de BaseOutput (CodeCarbon) et envoie les données
    d'émissions à l'endpoint /api/emissions/ du serveur.
"""

import requests
from typing import Optional

from codecarbon.output_methods.base_output import BaseOutput
from codecarbon.output_methods.emissions_data import EmissionsData

from aura.core.config import AuraConfig
from aura.core.exceptions import AuraAPIError


class AuraOutput(BaseOutput):
    """
        Output CodeCarbon qui envoie les données vers le serveur Aura.

        Appelé automatiquement par CodeCarbon à chaque :
            - live_out() : toutes les api_call_interval mesures (temps réel)
            - out()      : à stop() ou flush()
    """

    def __init__(
        self,
        config: Optional[AuraConfig] = None,
        project_id: Optional[str] = None,
        execution_id: Optional[str] = None
    ):
        """
            Args:
                config: AuraConfig chargée. Si None, chargée automatiquement
                        depuis ~/.aura.config.
                project_id: UUID du projet d'audit parent (optionnel).
                execution_id: Identifiant d'exécution pour regrouper les runs (optionnel).
        """
        if config is None:
            config = AuraConfig().load()

        self._endpoint = f"{config.api_endpoint.rstrip('/')}/api/emissions/"
        self._headers = {
            "Authorization": f"Token {config.api_key}",
            "Content-Type": "application/json",
        }
        self._project_id = project_id
        self._execution_id = execution_id

    # ─── Interface BaseOutput ─────────────────────────────────────────────────

    def out(self, total: EmissionsData, delta: EmissionsData) -> None:
        """Appelé à stop() ou flush() — envoie les données cumulatives."""
        self._send(total)

    def live_out(self, total: EmissionsData, delta: EmissionsData) -> None:
        """Appelé périodiquement pendant le run — envoie le delta."""
        self._send(delta)

    def task_out(self, data, experiment_name: str) -> None:
        """Appelé à stop() si des tâches ont été trackées."""
        # Optionnel : envoyer les tâches séparément
        pass

    def exit(self) -> None:
        """Cleanup à la fin du tracking."""
        pass

    # ─── Envoi HTTP ───────────────────────────────────────────────────────────

    def _send(self, data: EmissionsData) -> None:
        """
            Envoie un objet EmissionsData au serveur.

            En cas d'erreur réseau ou serveur, on logue sans planter
            le code utilisateur.
        """
        try:
            payload = self._to_dict(data)
            response = requests.post(
                self._endpoint,
                json=payload,
                headers=self._headers,
                timeout=10,
            )
            if not response.ok:
                print(
                    f"[Aura] Avertissement : l'envoi des émissions a échoué "
                    f"({response.status_code})"
                )
        except requests.ConnectionError:
            print("[Aura] Avertissement : impossible de joindre le serveur.")
        except requests.Timeout:
            print("[Aura] Avertissement : timeout lors de l'envoi des émissions.")
        except Exception as e:
            print(f"[Aura] Avertissement : erreur inattendue lors de l'envoi : {e}")

    def _to_dict(self, data: EmissionsData) -> dict:
        """
        Convertit EmissionsData en dict JSON-sérialisable.
        Mappe les noms de champs CodeCarbon vers les noms attendus par Django.
        """
        payload = {
            # Identifiants
            "run_id": str(data.run_id),
            "project_name": data.project_name,
            "experiment_id": str(data.experiment_id) if data.experiment_id else None,

            # Mesures principales (mapping CodeCarbon → Django)
            "timestamp": data.timestamp,
            "duration_seconds": data.duration,  # duration → duration_seconds
            "energy_kwh": data.energy_consumed,  # energy_consumed → energy_kwh
            "co2_kg": data.emissions,  # emissions → co2_kg
            "co2_rate": data.emissions_rate,  # emissions_rate → co2_rate

            # Puissance
            "cpu_power": data.cpu_power,
            "gpu_power": data.gpu_power,
            "ram_power": data.ram_power,

            # Énergie par composant
            "cpu_energy": data.cpu_energy,
            "gpu_energy": data.gpu_energy,
            "ram_energy": data.ram_energy,

            # Utilisation (mapping avec suffix _percent → sans suffix)
            "cpu_utilization": getattr(data, "cpu_utilization_percent", None),
            "gpu_utilization": getattr(data, "gpu_utilization_percent", None),
            "ram_utilization": getattr(data, "ram_utilization_percent", None),
            "ram_used_gb": getattr(data, "ram_used_gb", None),

            # Géographie
            "country_name": data.country_name,
            "country_iso_code": data.country_iso_code,
            "region": data.region,
            "cloud_provider": data.cloud_provider,
            "cloud_region": data.cloud_region,
            "on_cloud": data.on_cloud,

            # Data center
            "tracking_mode": data.tracking_mode,
            "pue": data.pue,
            "wue": getattr(data, "wue", 0.0),
        }

        # Ajouter project_id et execution_id si fournis
        if self._project_id:
            payload["project_id"] = self._project_id
        if self._execution_id:
            payload["execution_id"] = self._execution_id

        return payload
