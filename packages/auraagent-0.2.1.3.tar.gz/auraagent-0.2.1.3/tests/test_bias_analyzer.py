"""
Tests pour le module BiasAnalyzer.
"""

import pytest
from unittest.mock import Mock, patch, MagicMock
from aura.bias import BiasAnalyzer


def test_bias_analyzer_import():
    """Test que BiasAnalyzer peut être importé."""
    from aura import BiasAnalyzer as BA
    assert BA is not None


def test_bias_analyzer_init_no_config(tmp_path):
    """Test l'initialisation sans configuration."""
    # Créer un fichier de config temporaire
    config_file = tmp_path / ".aura.config"
    config_file.write_text("""
api_key = "test_key_12345"
api_endpoint = "http://localhost:8000"
default_project = "test-project"
""")

    with patch('aura.bias.analyzer.AuraConfig') as mock_config:
        mock_instance = Mock()
        mock_instance.api_key = "test_key_12345"
        mock_instance.api_endpoint = "http://localhost:8000"
        mock_config.return_value.load.return_value = mock_instance

        analyzer = BiasAnalyzer()
        assert analyzer._api_key == "test_key_12345"
        assert analyzer._api_url == "http://localhost:8000"


def test_bias_analyzer_init_with_api_key():
    """Test l'initialisation avec une API key directe."""
    with patch('aura.bias.analyzer.AuraConfig') as mock_config:
        mock_instance = Mock()
        mock_instance.api_endpoint = "https://cevia.ai"
        mock_config.return_value.load.return_value = mock_instance

        analyzer = BiasAnalyzer(api_key="custom_key")
        assert analyzer._api_key == "custom_key"


@patch('aura.bias.analyzer.requests.post')
@patch('aura.bias.analyzer.AuraConfig')
def test_create_audit(mock_config, mock_post):
    """Test la création d'un audit."""
    # Setup mock config
    mock_instance = Mock()
    mock_instance.api_key = "test_key"
    mock_instance.api_endpoint = "http://test.com"
    mock_config.return_value.load.return_value = mock_instance

    # Setup mock response
    mock_response = Mock()
    mock_response.json.return_value = {'audit_id': 'test-uuid-123'}
    mock_response.raise_for_status = Mock()
    mock_post.return_value = mock_response

    analyzer = BiasAnalyzer()
    audit_id = analyzer.create_audit("Test Model", "local", 10)

    assert audit_id == 'test-uuid-123'
    mock_post.assert_called_once()


@patch('aura.bias.analyzer.requests.get')
@patch('aura.bias.analyzer.AuraConfig')
def test_get_questions(mock_config, mock_get):
    """Test la récupération des questions."""
    # Setup mocks
    mock_instance = Mock()
    mock_instance.api_key = "test_key"
    mock_instance.api_endpoint = "http://test.com"
    mock_config.return_value.load.return_value = mock_instance

    mock_response = Mock()
    mock_response.json.return_value = {
        'questions': [
            {'id': 0, 'category': 'Age', 'pos_list': 1, 'question': 'Test?'},
            {'id': 1, 'category': 'Gender', 'pos_list': 2, 'question': 'Test2?'}
        ]
    }
    mock_response.raise_for_status = Mock()
    mock_get.return_value = mock_response

    analyzer = BiasAnalyzer()
    questions = analyzer.get_questions('test-uuid')

    assert len(questions) == 2
    assert questions[0]['category'] == 'Age'


@patch('aura.bias.analyzer.requests.post')
@patch('aura.bias.analyzer.AuraConfig')
def test_submit_results(mock_config, mock_post):
    """Test la soumission des résultats."""
    # Setup mocks
    mock_instance = Mock()
    mock_instance.api_key = "test_key"
    mock_instance.api_endpoint = "http://test.com"
    mock_config.return_value.load.return_value = mock_instance

    mock_response = Mock()
    mock_response.json.return_value = {
        'audit_id': 'test-uuid',
        'status': 'completed',
        'overall_bias_score': 0.25,
        'total_tests_run': 60,
        'total_tests_failed': 15,
        'scores_by_category': {'Age': 75.0},
        'carbon_metrics': {'emissions_kg': 0.001}
    }
    mock_response.raise_for_status = Mock()
    mock_post.return_value = mock_response

    analyzer = BiasAnalyzer()
    results = analyzer.submit_results(
        'test-uuid',
        [{'id': 0, 'category': 'Age', 'pos_list': 1, 'response': 'A'}],
        {'emissions_kg': 0.001}
    )

    assert results['status'] == 'completed'
    assert results['overall_bias_score'] == 0.25


def test_repr():
    """Test la représentation string."""
    with patch('aura.bias.analyzer.AuraConfig') as mock_config:
        mock_instance = Mock()
        mock_instance.api_key = "test_key"
        mock_instance.api_endpoint = "http://test.com"
        mock_config.return_value.load.return_value = mock_instance

        analyzer = BiasAnalyzer()
        repr_str = repr(analyzer)
        assert "BiasAnalyzer" in repr_str
        assert "http://test.com" in repr_str
