# auraagent

---

## Installation

```bash
# Package de base (tracking uniquement)
pip install auraagent

```

Requires Python 3.9+

---

## Premiers pas

### 1. Lancer l'interface de configuration

```bash
aura init
```

### Tester en local / réseau privé

---
Testez l'analyse de biais avec un modèle simple.

```
# Définir un modèle simple pour le test
def simple_model(question: str) -> str:
    """
    Modèle de test qui répond toujours 'A'.
    
    Dans un cas réel, vous remplacerez ceci par votre modèle d'IA.
    Le modèle doit retourner "A", "B", "C" ou "D".
    """
    return "A"


# BiasAnalyzer 
from aura import BiasAnalyzer, AuraCarbon
analyzer = BiasAnalyzer()  # ✅ Pas de paramètres !

print("🚀 Lancement de l'analyse de biais...")
print("   (Cela prendra environ 10-30 secondes pour 2 tests/catégorie)")
print()

bias_results = analyzer.analyze(
    model_callable=simple_model,
    model_name="Test Notebook Model",
    number_of_tests=2,   # 2 × 6 catégories = 12 tests (rapide)
    track_carbon=False,  # On teste le carbone séparément
    verbose=True,
    execution_id=EXECUTION_ID  # ✅ execution_id va dans analyze() !
)

print(f"\n✅ Analyse terminée ! {bias_results['total_tests_run']} tests exécutés")
```

## Architecture

```
auraagent/
├── aura/
│   ├── biais/
│   │   └── analyzer.py     # @track_emissions
│   ├── carbon/
│   │   ├── tracker.py      # AuraCarbon — wrapper CodeCarbon
│   │   ├── output.py       # AuraOutput — envoi HTTP vers le serveur
│   │   └── decorators.py   # @track_emissions
│   └── core/
│       ├── constants.py    # AURA_SERVER_URL (surchargeable via env)
│       ├── config.py       # Lecture/écriture ~/.aura.config
│       ├── auth.py         # Vérification email + clé API
│       ├── models.py       # Modèles Pydantic
│       └── exceptions.py   # AuraError, AuraAuthError, etc.
└── tests/
```

## Dépendances

| Dépendance | Rôle |
|---|---|
| `codecarbon` | Mesure de la consommation électrique |
| `requests` | Envoi HTTP des émissions |
| `pydantic` | Validation des modèles de données |
| `click` | Interface CLI |
| `rich` | Affichage terminal |
| `fastapi` *(web)* | Interface web locale |
| `uvicorn` *(web)* | Serveur ASGI |
---

## Licence

MIT — [CEVIA](https://cevia.ai)