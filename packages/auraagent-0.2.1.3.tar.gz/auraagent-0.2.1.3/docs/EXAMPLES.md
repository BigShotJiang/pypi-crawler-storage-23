# 🚀 Exemples d'Utilisation - Aura

Ce guide vous montre comment utiliser **auraagent** pour tracker le carbone et analyser les biais de vos modèles d'IA.

---

## 📋 Installation & Configuration

### 1. Installation

```bash
pip install auraagent
```

### 2. Configuration

Exécutez la commande d'initialisation :

```bash
aura init
```

Vous serez guidé pour :
- Entrer votre clé API CEVIA
- Vérifier la connexion au serveur
- Sauvegarder la configuration dans `~/.aura.config`

### 3. Vérification

```bash
aura status
```

Vous devriez voir :
```
Configuration Aura
┌─────────────────┬───────────────────────┐
│ api_endpoint    │ http://localhost:8000 │
│ api_key         │ ●●●●●●●●              │
│ default_project │ aura-default          │
└─────────────────┴───────────────────────┘
```

---

## 🎯 Exemples Fournis

### 1. **Notebook Jupyter** (`example_aura_demo.ipynb`)

Notebook interactif avec :
- ✅ Tracking carbone (2 méthodes)
- ✅ Analyse de biais
- ✅ Exemples de modèles réels (HuggingFace, OpenAI, custom)
- ✅ Visualisation des résultats

**Lancement :**
```bash
jupyter notebook example_aura_demo.ipynb
```

### 2. **Script Python** (`example_demo.py`)

Script complet exécutable directement.

**Lancement :**
```bash
python example_demo.py
```

**Sortie attendue :**
```
🚀 DEMO AURA - Carbon Tracking & Bias Analysis
================================================================================

🌱 PARTIE 1 : TRACKING CARBONE
--------------------------------------------------------------------------------
🔥 Démarrage du tracking carbone...
⚙️  Simulation d'entraînement de modèle...
⚙️  Traitement de données...
   ✓ Résultat calculé : 333333283333335000000
   ✓ 5000000 éléments triés
✅ Tracking carbone terminé !
   👉 Consultez le dashboard : http://localhost:8000/carbon/

================================================================================
🎯 PARTIE 2 : ANALYSE DE BIAIS
--------------------------------------------------------------------------------
...
```

---

## 📊 Vérifier les Résultats

### Dashboard Carbone

**URL :** `http://localhost:8000/carbon/`

Vous y verrez :
- 📈 Graphiques d'émissions CO2
- 🔍 Détails par projet
- ⏱️ Historique des exécutions

### Dashboard Biais

**URL :** `http://localhost:8000/audits/biais/`

Vous y verrez :
- 🎯 Scores de biais par catégorie
- 📊 Résultats détaillés des tests
- 📝 Recommandations d'amélioration

---

## 💡 Intégration dans Votre Code

### Tracking Carbone

#### Méthode 1 : Context Manager (recommandé)

```python
from aura import AuraCarbon

with AuraCarbon(project_name="mon-projet") as tracker:
    # Votre code d'entraînement
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

# Les émissions sont automatiquement envoyées au serveur
```

#### Méthode 2 : Start/Stop

```python
from aura import AuraCarbon

tracker = AuraCarbon(
    project_name="mon-projet",
    measure_power_secs=5  # Mesure toutes les 5 secondes
)

tracker.start()

# Votre code
model.fit(X_train, y_train)

emissions = tracker.stop()
print(f"Émissions : {emissions} kg CO2")
```

#### Méthode 3 : Décorateur

```python
from aura.carbon import track_emissions

@track_emissions(project_name="mon-projet")
def train_model(X, y):
    model = MyModel()
    model.fit(X, y)
    return model

# Les émissions sont trackées automatiquement
trained_model = train_model(X_train, y_train)
```

### Analyse de Biais

```python
from aura import BiasAnalyzer

# 1. Définir votre modèle
def my_model(question: str) -> str:
    """
    Votre modèle doit :
    - Prendre une question en entrée (str)
    - Retourner une réponse : "A", "B", "C" ou "D"
    """
    # Votre logique ici
    result = your_ai_model.predict(question)
    return result  # Doit être "A", "B", "C" ou "D"

# 2. Lancer l'analyse
analyzer = BiasAnalyzer()

results = analyzer.analyze(
    model_callable=my_model,
    model_name="Mon Modèle v1.0",
    number_of_tests=60,      # 60 questions × 6 catégories = 360 tests
    track_carbon=True,       # Mesurer aussi le CO2
    verbose=True             # Afficher la progression
)

# 3. Exploiter les résultats
print(f"Score de biais : {results['overall_bias_score']:.2f}")
for category, score in results['scores_by_category'].items():
    print(f"{category}: {score:.2f}%")
```

---

## 🎨 Exemples de Modèles Réels

### Avec HuggingFace

```python
from transformers import pipeline

classifier = pipeline("sentiment-analysis")

def my_huggingface_model(question: str) -> str:
    result = classifier(question)[0]

    # Convertir le résultat en A/B/C/D selon votre logique
    if result['label'] == 'POSITIVE' and result['score'] > 0.8:
        return "A"
    elif result['label'] == 'POSITIVE':
        return "B"
    elif result['score'] > 0.5:
        return "C"
    else:
        return "D"

# Analyser
analyzer = BiasAnalyzer()
results = analyzer.analyze(
    model_callable=my_huggingface_model,
    model_name="BERT Sentiment",
    number_of_tests=60
)
```

### Avec OpenAI API

```python
import openai

def my_openai_model(question: str) -> str:
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "Answer with only A, B, C, or D"},
            {"role": "user", "content": question}
        ]
    )

    answer = response.choices[0].message.content.strip()
    return answer[0] if answer[0] in ['A', 'B', 'C', 'D'] else 'A'

# Analyser avec tracking carbone
with AuraCarbon(project_name="openai-bias-test"):
    analyzer = BiasAnalyzer()
    results = analyzer.analyze(
        model_callable=my_openai_model,
        model_name="GPT-3.5 Turbo",
        number_of_tests=60,
        track_carbon=False  # Déjà dans le context manager
    )
```

### Avec un Modèle Custom (sklearn, joblib, etc.)

```python
import joblib

# Charger votre modèle
model = joblib.load('mon_modele.pkl')
vectorizer = joblib.load('vectorizer.pkl')

def my_custom_model(question: str) -> str:
    # Preprocessing
    features = vectorizer.transform([question])

    # Prédiction
    prediction = model.predict(features)[0]

    # Convertir en A/B/C/D
    mapping = {0: 'A', 1: 'B', 2: 'C', 3: 'D'}
    return mapping.get(prediction, 'A')

# Analyser
analyzer = BiasAnalyzer()
results = analyzer.analyze(
    model_callable=my_custom_model,
    model_name="Custom sklearn Model",
    number_of_tests=60
)
```

---

## 🔧 Configuration Avancée

### Changer l'URL du serveur

Éditez `~/.aura.config` :

```ini
[aura]
api_endpoint = https://votre-serveur.com
api_key = votre_cle_api
default_project = mon-projet
```

### Configuration programmatique

```python
from aura import BiasAnalyzer, AuraCarbon

# Sans fichier de config
analyzer = BiasAnalyzer(
    api_key="votre_cle_api",
    api_url="http://localhost:8000"
)

# Avec config custom
from aura.core.config import AuraConfig

config = AuraConfig()
config._parser.add_section("aura")
config._parser.set("aura", "api_endpoint", "http://localhost:8000")
config._parser.set("aura", "api_key", "votre_cle")

tracker = AuraCarbon(config=config)
```

---

## 🆘 Aide & Support

### Commandes CLI

```bash
aura init      # Configurer Aura
aura status    # Voir la configuration
aura logout    # Supprimer la configuration
aura --help    # Aide
```

### Dépannage

**Erreur : "Configuration manquante"**
```bash
aura init
```

**Erreur : "Impossible de contacter le serveur"**
- Vérifiez que le serveur Django tourne : `http://localhost:8000`
- Vérifiez l'URL dans `~/.aura.config`

**Erreur : "Authentication credentials were not provided"**
- Vérifiez votre clé API dans `~/.aura.config`
- Testez avec `curl` :
  ```bash
  curl -H "Authorization: Token votre_cle" http://localhost:8000/api/auth/verify-token/
  ```

---

## 📖 Documentation

- **Configuration** : Voir `CONFIGURATION.md`
- **API Reference** : Voir docstrings dans le code
- **Dashboard** : `http://localhost:8000`

---

**Version :** auraagent 0.2.0
**Support :** info@cevia.ai
