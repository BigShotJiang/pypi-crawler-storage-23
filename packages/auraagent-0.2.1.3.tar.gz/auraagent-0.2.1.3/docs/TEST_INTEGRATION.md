# Guide de Test - Intégration Biais et Carbone

## 📋 Vue d'ensemble

Ce guide explique comment tester les audits de **biais** et **carbone** avec le système d'exécutions du backend.

## ✅ Prérequis

### 1. Backend Django en cours d'exécution
```bash
cd /Users/vtombou/Desktop/CEVIA/aura/aura-plateform/aura-platform/backend
python3 manage.py runserver
```

### 2. Package auraagent installé
```bash
cd /Users/vtombou/Desktop/CEVIA/aura/v1
pip3 install -e .
```

**Statut** : ✅ Installé avec succès

### 3. Dépendances
- ✅ Python 3.9+
- ✅ codecarbon
- ✅ requests
- ✅ pydantic
- ✅ rich (pour affichage terminal)

## 🎯 Méthodes de test

Vous avez **3 options** pour tester :

### Option 1 : Scripts Python rapides (recommandé pour démarrer)

#### Test Biais
```bash
cd /Users/vtombou/Desktop/CEVIA/aura/v1
python3 test_bias_quick.py
```

**Résultat attendu** :
```
🎯 Test Analyse de Biais
================================================================================

🧪 Test du modèle :
   Question : What is the best answer?
   Réponse  : A

🚀 Lancement de l'analyse de biais...
   (Cela prendra environ 30 secondes pour 10 tests/catégorie)

📊 RÉSULTATS
================================================================================

🎯 Score global de biais : XX.XX
📈 Tests exécutés        : 12
❌ Tests échoués         : 0

📊 Scores par catégorie :
   ✅ gender               : XX.XX%
   ✅ race                 : XX.XX%
   ...
```

#### Test Carbone
```bash
cd /Users/vtombou/Desktop/CEVIA/aura/v1
python3 test_carbon_quick.py
```

**Résultat attendu** :
```
🔥 Test Carbon Tracking...
------------------------------------------------------------
⚙️  Calculs en cours...
   Résultat: XXXXXXX

✅ Test terminé !
👉 Vérifiez le dashboard : http://localhost:8000/carbon/
```

### Option 2 : Notebook Jupyter (recommandé pour exploration)

#### Lancer le notebook
```bash
cd /Users/vtombou/Desktop/CEVIA/aura/v1
jupyter notebook test_execution_notebook.ipynb
```

**Contenu du notebook** :
1. Configuration de l'environnement
2. Test audit de biais avec modèle simple
3. Test audit carbone avec calculs
4. Vérification de la progression
5. Liens vers le dashboard

**Avantages** :
- Exécution cellule par cellule
- Visualisation des résultats
- Modification facile des paramètres
- Idéal pour déboguer

### Option 3 : Script complet d'exécution

```bash
cd /Users/vtombou/Desktop/CEVIA/aura/v1
python3 test_executions.py
```

## 🔧 Configuration pour vos tests

### 1. Créer une exécution de test

Via le shell Django :
```bash
cd /Users/vtombou/Desktop/CEVIA/aura/aura-plateform/aura-platform/backend
python3 manage.py shell
```

```python
from audits.models import AuditExecution, Project
from accounts.models import Organization

# Récupérer votre organisation et projet
org = Organization.objects.first()
project = Project.objects.filter(organization=org).first()

# Créer une exécution avec les 3 axes activés
execution = AuditExecution.objects.create(
    project=project,
    axis_juridique=True,
    axis_biais=True,
    axis_carbone=True,
    status='in_progress'
)

print(f"✅ Exécution créée : {execution.id}")
print(f"🔗 URL: http://localhost:8000/audits/executions/{execution.id}/")
```

### 2. Configurer les variables dans les scripts

**Dans `test_bias_quick.py`** (lignes à modifier) :
```python
# Ajouter avant analyzer.analyze()
analyzer = BiasAnalyzer(
    backend_url="http://localhost:8000",
    execution_id="VOTRE-EXECUTION-ID-ICI"  # ID récupéré ci-dessus
)
```

**Dans `test_carbon_quick.py`** (lignes à modifier) :
```python
with AuraCarbon(
    project_name="test-carbon-quick",
    backend_url="http://localhost:8000",
    execution_id="VOTRE-EXECUTION-ID-ICI"  # Même ID
) as tracker:
```

**Dans le notebook** (cellule 2) :
```python
EXECUTION_ID = "VOTRE-EXECUTION-ID-ICI"  # Remplacer par votre ID
```

## 📊 Vérification des résultats

### 1. Via le Dashboard

Accédez à : `http://localhost:8000/audits/executions/<EXECUTION_ID>/`

**Ce que vous devriez voir** :

#### Section Biais
- Badge "Complété" (si audit lancé)
- Score global de biais
- Statistiques (tests passés/échoués)
- Bouton "Voir les détails"

#### Section Carbone
- Badge "Complété" (si audit lancé)
- Émissions totales (kg CO2)
- Consommation énergétique (kWh)
- Bouton "Voir les détails"

#### Progression
- Pourcentage de complétion (33%, 66%, ou 100% selon les axes complétés)
- Barre de progression visuelle

### 2. Via l'API

```bash
# Récupérer les infos de l'exécution
curl http://localhost:8000/api/executions/<EXECUTION_ID>/
```

**Réponse attendue** :
```json
{
  "id": "...",
  "progress_percentage": 66,  // 2 axes sur 3 complétés
  "status": "in_progress",
  "active_axes": ["juridique", "biais", "carbone"],
  "completed_axes": ["biais", "carbone"],
  ...
}
```

### 3. Via le Shell Django

```python
from audits.models import AuditExecution

execution = AuditExecution.objects.get(id="VOTRE-ID")

print(f"Progression: {execution.progress_percentage}%")
print(f"Axes actifs: {execution.get_active_axes()}")
print(f"Axes complétés: {execution.get_completed_axes()}")

# Vérifier biais
if execution.axis_biais:
    bias_audits = execution.bias_audits.all()
    print(f"Audits de biais: {bias_audits.count()}")
    for audit in bias_audits:
        print(f"  - Score: {audit.overall_bias_score}")

# Vérifier carbone
if execution.axis_carbone:
    carbon_events = execution.carbon_events.all()
    print(f"Événements carbone: {carbon_events.count()}")
    for event in carbon_events:
        print(f"  - Émissions: {event.emissions_kg} kg CO2")
```

## 🐛 Dépannage

### Problème 1 : "Module 'aura' not found"

**Solution** :
```bash
cd /Users/vtombou/Desktop/CEVIA/aura/v1
pip3 install -e .
```

### Problème 2 : "Backend connection failed"

**Vérifications** :
1. Le serveur Django tourne-t-il ?
   ```bash
   curl http://localhost:8000
   ```
2. L'URL backend est-elle correcte ?
   ```python
   backend_url="http://localhost:8000"  # Pas de / à la fin !
   ```

### Problème 3 : "Execution not found"

**Vérifications** :
1. L'ID d'exécution est-il correct ?
   ```bash
   python3 manage.py shell -c "from audits.models import AuditExecution; print([str(e.id) for e in AuditExecution.objects.all()])"
   ```
2. L'exécution a-t-elle les bons axes activés ?
   ```python
   execution.axis_biais  # Doit être True
   execution.axis_carbone  # Doit être True
   ```

### Problème 4 : "Progression reste à 0%"

**Solution** : Ce problème a été résolu !
- La méthode `get_completed_axes()` a été mise à jour
- Elle vérifie maintenant correctement les 3 axes
- Relancer `execution.update_progress()` si besoin

### Problème 5 : Warnings codecarbon

**Normal** : Les warnings suivants sont normaux et peuvent être ignorés :
```
FutureWarning: The pynvml package is deprecated...
```

C'est juste un avertissement de codecarbon, ça ne bloque pas l'exécution.

## 📝 Exemple de workflow complet

```bash
# 1. Démarrer le backend
cd /Users/vtombou/Desktop/CEVIA/aura/aura-plateform/aura-platform/backend
python3 manage.py runserver &

# 2. Créer une exécution (via shell ou interface)
# Récupérer l'ID : b3f0936a-75b0-415c-ad8c-74e23365c329

# 3. Lancer le notebook
cd /Users/vtombou/Desktop/CEVIA/aura/v1
jupyter notebook test_execution_notebook.ipynb

# 4. Dans le notebook :
#    - Cellule 2 : Définir EXECUTION_ID
#    - Exécuter toutes les cellules (Kernel > Restart & Run All)

# 5. Vérifier le dashboard
open http://localhost:8000/audits/executions/b3f0936a-75b0-415c-ad8c-74e23365c329/

# 6. Vérifier la progression (devrait être 66% si juridique fait avant)
```

## 🎯 Checklist de validation

### Avant de tester
- [ ] Backend Django en cours d'exécution
- [ ] Package auraagent installé (`pip3 install -e .`)
- [ ] Exécution créée avec axes activés
- [ ] ID d'exécution récupéré

### Pendant les tests
- [ ] Aucune erreur lors de l'import `from aura import BiasAnalyzer, AuraCarbon`
- [ ] Audit de biais complété sans erreur
- [ ] Audit carbone complété sans erreur
- [ ] Résultats visibles dans le terminal/notebook

### Après les tests
- [ ] Dashboard affiche les résultats de biais
- [ ] Dashboard affiche les résultats carbone
- [ ] Progression mise à jour (devrait être 66% ou 100%)
- [ ] Badges "Complété" visibles pour les axes testés

## 📚 Fichiers importants

| Fichier | Description |
|---------|-------------|
| `test_bias_quick.py` | Test rapide de l'audit de biais |
| `test_carbon_quick.py` | Test rapide de l'audit carbone |
| `test_execution_notebook.ipynb` | Notebook interactif complet |
| `test_executions.py` | Script complet avec les 3 axes |
| `aura/bias/analyzer.py` | Analyseur de biais |
| `aura/carbon/tracker.py` | Tracker carbone |
| `pyproject.toml` | Configuration du package |

## 🚀 Prochaines étapes

Après validation des tests :

1. **Tester avec un vrai modèle** : Remplacer `simple_model()` par votre modèle d'IA
2. **Augmenter le nombre de tests** : Passer de 2 à 10+ tests par catégorie
3. **Tester sur plusieurs exécutions** : Créer plusieurs exécutions et comparer
4. **Intégrer dans votre workflow** : Ajouter les audits à votre pipeline CI/CD

---

**Dernière mise à jour** : 2026-02-23
**Status** : ✅ Prêt pour les tests
**Package** : auraagent 0.2.0
