"""AnimeFLV package."""

from ani_scrapy.animeflv.scraper import AnimeFLVScraper

__all__ = ["AnimeFLVScraper"]
