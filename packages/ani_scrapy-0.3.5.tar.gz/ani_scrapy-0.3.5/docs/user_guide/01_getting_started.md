# Getting Started

## Installation

```bash
pip install ani-scrapy
```

Development install:

```bash
git clone https://github.com/ElPitagoras14/ani-scrapy.git
cd ani-scrapy
pip install -e ".[dev]"
playwright install chromium
```
