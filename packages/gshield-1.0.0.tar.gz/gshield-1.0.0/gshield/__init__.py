"""
Gshield SDK - 流式文本安全检测 Python 客户端
"""
from .client import GshieldStreamClient, SyncGshieldStreamClient
from .session import StreamSession
from .models import (
    ClassificationResult,
    StreamClassificationEvent,
    SessionConfig,
)
from .exceptions import (
    GshieldError,
    GshieldConnectionError,
    SessionError,
    SessionNotFoundError,
    SessionExistsError,
    ClassifyError,
    ProtocolError,
)

__version__ = "1.0.0"

__all__ = [
    # Client
    "GshieldStreamClient",
    "SyncGshieldStreamClient",
    # Session
    "StreamSession",
    # Models
    "ClassificationResult",
    "StreamClassificationEvent",
    "SessionConfig",
    # Exceptions
    "GshieldError",
    "GshieldConnectionError",
    "SessionError",
    "SessionNotFoundError",
    "SessionExistsError",
    "ClassifyError",
    "ProtocolError",
]
