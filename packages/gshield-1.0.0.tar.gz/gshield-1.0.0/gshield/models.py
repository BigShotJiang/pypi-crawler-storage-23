"""
Gshield SDK 数据模型
"""
from typing import Optional
from pydantic import BaseModel, Field


# ============================================================
# 分类结果
# ============================================================

class ClassificationResult(BaseModel):
    """单次分类结果"""
    main_label: str = Field(..., description="主类标签 (normal/porn/politics/violence/illegal/discrimination/unethitical)")
    main_confidence: float = Field(..., description="主类置信度 (0.0-1.0)")
    sub_label: Optional[str] = Field(None, description="子类标签")
    sub_confidence: Optional[float] = Field(None, description="子类置信度")


class StreamClassificationEvent(BaseModel):
    """流式检测事件（服务端推送的 classification.result）"""
    session_id: str
    seq: int = Field(..., description="结果序号，从 1 递增")
    text_length: int = Field(..., description="当前累积文本长度")
    result: ClassificationResult
    is_final: bool = Field(False, description="是否为终检结果")


# ============================================================
# 会话配置
# ============================================================

class SessionConfig(BaseModel):
    """流式检测会话配置"""
    classify_every_n_chars: int = Field(100, ge=0, description="每累积 N 个新字符触发一次检测 (0=禁用)")
    classify_interval_secs: float = Field(3.0, ge=0.0, description="每隔 N 秒触发一次检测 (0=禁用)")


# ============================================================
# WebSocket 消息
# ============================================================

class SessionCreatedMsg(BaseModel):
    """session.created 消息"""
    type: str = "session.created"
    session_id: str
    config: SessionConfig


class TextReceivedMsg(BaseModel):
    """text.received 消息"""
    type: str = "text.received"
    session_id: str
    current_length: int


class SessionEndedMsg(BaseModel):
    """session.ended 消息"""
    type: str = "session.ended"
    session_id: str
    final_result: Optional[ClassificationResult] = None


class ErrorMsg(BaseModel):
    """error 消息"""
    type: str = "error"
    session_id: Optional[str] = None
    code: str
    message: str
