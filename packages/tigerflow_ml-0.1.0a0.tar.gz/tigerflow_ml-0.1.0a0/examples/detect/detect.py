from tigerflow_ml.image.detect.local import Detect

if __name__ == "__main__":
    Detect.cli()
