from tigerflow_ml.audio.transcribe.local import Transcribe

if __name__ == "__main__":
    Transcribe.cli()
