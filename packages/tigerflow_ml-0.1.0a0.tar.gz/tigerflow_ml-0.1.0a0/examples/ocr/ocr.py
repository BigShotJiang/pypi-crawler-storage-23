from tigerflow_ml.text.ocr.local import OCR

if __name__ == "__main__":
    OCR.cli()
