from tigerflow_ml.text.translate.local import Translate

if __name__ == "__main__":
    Translate.cli()
