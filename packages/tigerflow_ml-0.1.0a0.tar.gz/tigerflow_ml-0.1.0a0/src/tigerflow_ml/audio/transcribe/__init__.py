from tigerflow_ml.audio.transcribe.slurm import Transcribe

__all__ = ["Transcribe"]
