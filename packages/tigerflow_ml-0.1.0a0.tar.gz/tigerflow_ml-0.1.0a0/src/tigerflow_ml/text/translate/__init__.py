from tigerflow_ml.text.translate.slurm import Translate

__all__ = ["Translate"]
