from tigerflow_ml.text.ocr.slurm import OCR

__all__ = ["OCR"]
