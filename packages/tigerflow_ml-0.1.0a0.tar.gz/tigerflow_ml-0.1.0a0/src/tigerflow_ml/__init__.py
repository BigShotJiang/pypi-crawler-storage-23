# ML tasks for TigerFlow
from tigerflow_ml.audio.transcribe import Transcribe
from tigerflow_ml.image.detect import Detect
from tigerflow_ml.text.ocr import OCR
from tigerflow_ml.text.translate import Translate

__all__ = ["Detect", "OCR", "Transcribe", "Translate"]
