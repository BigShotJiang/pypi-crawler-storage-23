from tigerflow_ml.image.detect.slurm import Detect

__all__ = ["Detect"]
