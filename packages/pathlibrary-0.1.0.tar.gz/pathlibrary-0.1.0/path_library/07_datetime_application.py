import datetime

while True:

    print("1 Current Date Time")
    print("2 Day of week")
    print("3 Date difference")
    print("4 Exit")

    ch=input("Choice:")

    if ch=="1":
        now=datetime.datetime.now()
        print(now)

    elif ch=="2":
        d=input("Enter date YYYY-MM-DD:")
        date=datetime.datetime.strptime(d,"%Y-%m-%d")
        print(date.strftime("%A"))

    elif ch=="3":
        d1=input("Date1:")
        d2=input("Date2:")

        date1=datetime.datetime.strptime(d1,"%Y-%m-%d")
        date2=datetime.datetime.strptime(d2,"%Y-%m-%d")

        diff=abs((date2-date1).days)
        print("Difference:",diff)

    elif ch=="4":
        break