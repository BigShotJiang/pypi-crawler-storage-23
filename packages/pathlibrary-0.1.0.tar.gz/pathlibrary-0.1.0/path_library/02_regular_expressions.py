import re

# Pattern Matching
text = "Latest version: Python 3.10 released"
match = re.search(r"\d+\.\d+", text)
print("Version:", match.group())

# Find words
text = "Data123 Science_2025 is awesome"
words = re.findall(r"\w+", text)
print("Words:", words)

# Non digits
text = "CS101 - Introduction to AI"
non_digits = re.findall(r"\D+", text)
print("Non digits:", non_digits)

# Quantifiers
text = "The rain in Spain stays mainly in the plain"
vowels = re.findall(r"[aeiouAEIOU]{2,}", text)
print("Vowel sequences:", vowels)

# Words 3-5 characters
text = "Data science is fun and useful"
result = re.findall(r"\b\w{3,5}\b", text)
print(result)

# Capital words
sentence = "Dr John and Mr Smith went to Washington"
cap = re.findall(r"\b[A-Z][a-z]*\b", sentence)
print(cap)

# Numbers
data = "Prices: 12, 45.67, 89"
numbers = re.findall(r"\d+\.\d+|\d+", data)
print(numbers)

# Email extraction
sample = """
contact: john@gmail.com
sales: sales@company.com
"""

emails = re.findall(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b", sample)
print("Emails:", emails)