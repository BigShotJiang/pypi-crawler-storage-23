class Student:

    school="ABC School"

    def __init__(self,name,age):
        self.name=name
        self.age=age

    def show(self):
        print(self.name,self.age)

    @classmethod
    def school_name(cls):
        print(cls.school)

    @staticmethod
    def is_adult(age):
        return age>=18

s=Student("Ali",20)

s.show()
Student.school_name()
print(Student.is_adult(20))