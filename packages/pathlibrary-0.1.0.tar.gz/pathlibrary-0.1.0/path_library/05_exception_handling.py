try:
    x = 10/0
except ZeroDivisionError as e:
    print("Error:",e)

try:
    age = int("twenty")
except ValueError as e:
    print("Error:",e)

try:
    lst=[1,2,3]
    print(lst[5])
except IndexError as e:
    print("Error:",e)

try:
    with open("file.txt") as f:
        data=f.read()
except FileNotFoundError as e:
    print("Error:",e)

try:
    a=int(input("Enter number:"))
    b=int(input("Enter number:"))
    print(a/b)
except (ValueError,ZeroDivisionError):
    print("Invalid input")