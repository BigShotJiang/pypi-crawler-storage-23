import sqlite3

def connect_db():
    conn = sqlite3.connect("college.db")
    print("Connected to database")
    return conn

def create_table(conn):
    cursor = conn.cursor()
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS students(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        age INTEGER,
        grade TEXT
    )
    """)
    conn.commit()

def insert_student(conn,name,age,grade):
    cursor = conn.cursor()
    cursor.execute("INSERT INTO students(name,age,grade) VALUES(?,?,?)",(name,age,grade))
    conn.commit()

def update_student(conn,id,grade):
    cursor = conn.cursor()
    cursor.execute("UPDATE students SET grade=? WHERE id=?",(grade,id))
    conn.commit()

def show_students(conn):
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM students")
    rows = cursor.fetchall()
    for row in rows:
        print(row)

conn = connect_db()
create_table(conn)

while True:
    print("1 Insert")
    print("2 Update")
    print("3 Show")
    print("4 Exit")

    ch = input("Choice: ")

    if ch=="1":
        name=input("Name:")
        age=int(input("Age:"))
        grade=input("Grade:")
        insert_student(conn,name,age,grade)

    elif ch=="2":
        id=int(input("ID:"))
        grade=input("New Grade:")
        update_student(conn,id,grade)

    elif ch=="3":
        show_students(conn)

    elif ch=="4":
        break

conn.close()