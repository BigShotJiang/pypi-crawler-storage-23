import os
import csv
import json
from pathlib import Path

# 1. Create and Write to File
with open("sample.txt", "w") as f:
    f.write("Hello, this is the first line.\n")
    f.write("This is the second line.")
print("Text file created.")

# 2. Read File
with open("sample.txt", "r") as f:
    content = f.read()
    print("Content:\n", content)

# 3. Append
with open("sample.txt", "a") as f:
    f.write("\nAppended line.")
print("Line appended.")

# 4. Read Line by Line
with open("sample.txt", "r") as f:
    for line in f:
        print(line.strip())

# 5. File Pointer
with open("sample.txt", "r") as f:
    print("Pointer:", f.tell())
    print(f.read(10))
    print("After reading:", f.tell())
    f.seek(5)
    print("Reset pointer:", f.tell())
    print(f.read(10))

# 6. Rename & Delete
if os.path.exists("sample.txt"):
    os.rename("sample.txt", "renamed_sample.txt")
    print("File renamed.")

if os.path.exists("renamed_sample.txt"):
    os.remove("renamed_sample.txt")
    print("File deleted.")

# 7. Create Folder + File
folder = "demo_folder"
os.makedirs(folder, exist_ok=True)

with open(f"{folder}/nested.txt", "w") as f:
    f.write("File inside folder.")

print("Folder and file created.")

# 8. List Files
print("Files:", os.listdir("."))

# 9. Write CSV
data = [["Name", "Age"], ["Ali", 21], ["John", 22]]

with open("data.csv", "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerows(data)

# 10. Read CSV
with open("data.csv", "r") as f:
    reader = csv.reader(f)
    for row in reader:
        print(row)

# 11. Write JSON
info = {"name": "Ali", "age": 21}

with open("data.json", "w") as f:
    json.dump(info, f, indent=4)

# 12. Read JSON
with open("data.json", "r") as f:
    data = json.load(f)
    print(data)

# 13. Pathlib Example
file = Path("pathlib_demo.txt")
file.write_text("Written using pathlib.")
print(file.read_text())