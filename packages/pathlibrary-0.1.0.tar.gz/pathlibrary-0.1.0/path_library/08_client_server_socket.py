server
import socket

server=socket.socket()
server.bind(("127.0.0.1",1234))
server.listen(1)

print("Waiting for client")

conn,addr=server.accept()

data=conn.recv(1024).decode()
print("Client:",data)

conn.send("Hello from server".encode())

conn.close()


client
import socket

client=socket.socket()
client.connect(("127.0.0.1",1234))

client.send("Hello server".encode())

msg=client.recv(1024).decode()
print("Server:",msg)

client.close()