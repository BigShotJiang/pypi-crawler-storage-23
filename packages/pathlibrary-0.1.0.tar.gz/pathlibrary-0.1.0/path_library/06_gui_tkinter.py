import tkinter as tk

root=tk.Tk()
root.title("GUI Demo")
root.geometry("400x300")

label=tk.Label(root,text="GUI Example",font=("Arial",20),fg="blue")
label.pack()

name=tk.Entry(root)
name.pack()

age=tk.Entry(root)
age.pack()

def show():
    print("Name:",name.get(),"Age:",age.get())

btn=tk.Button(root,text="Submit",command=show)
btn.pack()

root.mainloop()