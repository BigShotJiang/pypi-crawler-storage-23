From https://github.com/langchain-ai/langgraph/blob/23961cff61a42b52525f3b20b4094d8d2fba1744/docs/docs/tutorials/customer-support/customer-support.ipynb


```bash
export ANTHROPIC_API_KEY=...
export OPENAI_API_KEY=...
export TAVILY_API_KEY=...

# From the repo root:
cd examples/langchain
uv pip install -e .  # install example dependencies into the current environment
python customer_support.py
```
