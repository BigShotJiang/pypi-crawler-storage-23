"""Entry point for running mkado as a module."""

from mkado.cli import main

if __name__ == "__main__":
    main()
