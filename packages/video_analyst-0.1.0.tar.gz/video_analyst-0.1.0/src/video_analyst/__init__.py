"""Video Analyst - Analyze videos and produce AI reproduction plans."""

__version__ = "0.1.0"
