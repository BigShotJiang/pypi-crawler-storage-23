"""
RAGSentinel - RAG Evaluation Framework using Ragas and MLflow.

A pip-installable package for evaluating Retrieval-Augmented Generation (RAG)
applications using Ragas metrics with MLflow tracking.

Features:
    - Evaluate RAG pipelines with Faithfulness, AnswerRelevancy,
      ContextPrecision, and AnswerCorrectness metrics
    - Support for Azure OpenAI, OpenAI, and Ollama LLM providers
    - Automatic MLflow server management and result tracking
    - Flexible authentication (Cookie, Bearer, Custom Header)

Usage:
    $ pip install rag-sentinel
    $ rag-sentinel init
    $ rag-sentinel run

Author: RAGSentinel Team
License: MIT
"""

__version__ = "0.1.7"

