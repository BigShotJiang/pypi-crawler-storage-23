"""Endpoint wrapper namespace.

For broad API-version coverage, use the generic versioned request methods:
- Workspace: `WorkspaceClient.request_versioned(...)`
- Account: `AccountClient.request_account(...)`

You can add generated wrappers per API family/version in this package.
"""
