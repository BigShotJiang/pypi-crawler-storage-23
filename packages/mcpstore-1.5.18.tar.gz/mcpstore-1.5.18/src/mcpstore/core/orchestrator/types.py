"""
MCPOrchestrator Types
Orchestrator-related type definitions
"""

# Orchestrator-related type definitions can be added here
# Currently kept simple, reserved for future expansion
