from pathlib import Path

import pytest
import typer

from chromeappcap.cli import (
    normalize_capture_mode,
    normalize_output_format,
    normalize_url,
    resolve_capture_order,
)


def test_normalize_url_adds_https_when_missing_scheme() -> None:
    assert normalize_url("example.com") == "https://example.com"


def test_normalize_url_rejects_invalid_scheme() -> None:
    with pytest.raises(typer.BadParameter):
        normalize_url("ftp://example.com")


def test_normalize_output_format_from_flag_and_suffix() -> None:
    assert normalize_output_format("jpg", Path("shot.any")) == "jpeg"
    assert normalize_output_format(None, Path("shot.webp")) == "webp"
    assert normalize_output_format(None, Path("shot")) == "png"


def test_normalize_capture_mode_validation() -> None:
    assert normalize_capture_mode("AUTO") == "auto"
    with pytest.raises(typer.BadParameter):
        normalize_capture_mode("banana")


def test_resolve_capture_order_page_mode() -> None:
    assert resolve_capture_order("page") == ["page"]


def test_resolve_capture_order_app_mode() -> None:
    assert resolve_capture_order("app") == ["app"]
