from pathlib import Path

from chromeappcap.cli import default_output_path, resolve_output_path


def test_default_output_path_uses_invocation_directory(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    output = default_output_path("https://example.com")
    assert output == tmp_path / "example.com.png"


def test_resolve_output_path_makes_relative_paths_cwd_absolute(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    output = resolve_output_path(Path("shots/homepage"))
    assert output == tmp_path / "shots/homepage"


def test_resolve_output_path_keeps_absolute_path(tmp_path):
    absolute = tmp_path / "x.png"
    output = resolve_output_path(absolute)
    assert output == absolute
