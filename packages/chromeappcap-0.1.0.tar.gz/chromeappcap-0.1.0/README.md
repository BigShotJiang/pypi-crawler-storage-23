# chromeappcap

Screenshots that look like you meant to share them.

`chromeappcap` is a CLI for polished website/app screenshots with native Chrome app-window capture on macOS and Playwright fallback everywhere else.

## Install

### `pipx` (recommended)

```bash
pipx install chromeappcap
```

### `uvx` (zero install)

```bash
uvx --from git+https://github.com/William-Blackie/chromeappcap.git chromeappcap https://example.com
```

### local dev

```bash
git clone https://github.com/William-Blackie/chromeappcap.git
cd chromeappcap
python3 -m venv .venv
source .venv/bin/activate
pip install -e .[dev]
playwright install chromium
```

Or:

```bash
make dev-install
make playwright-install
```

## Quick Start

```bash
chromeappcap https://example.com
```

By default, output is saved in your current shell directory.

## Common Commands

Native app-window capture (macOS):

```bash
chromeappcap https://example.com --capture-mode app -o native.png
```

High-quality compressed WebP:

```bash
chromeappcap https://example.com --capture-mode app --device-scale 2.5 --format webp --compress --quality 85 -o shot.webp
```

Cross-platform page fallback with no synthetic frame:

```bash
chromeappcap https://example.com --capture-mode page --no-frame -o raw.png
```

## Notes

- `--capture-mode auto` prefers app mode on macOS and falls back to page mode.
- `--capture-mode page` requires Playwright Chromium:

```bash
playwright install chromium
```

- macOS app mode requires Screen Recording permission:
  - `System Settings > Privacy & Security > Screen Recording`

## Help

```bash
chromeappcap --help
```
