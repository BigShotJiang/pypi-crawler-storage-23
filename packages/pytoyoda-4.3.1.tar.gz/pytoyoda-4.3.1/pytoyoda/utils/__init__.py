"""Utils for pytoyoda lib."""
