"""Models for pytoyoda lib."""
