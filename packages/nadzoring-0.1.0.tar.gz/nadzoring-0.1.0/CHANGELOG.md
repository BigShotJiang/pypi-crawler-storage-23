commit c0c74257ad27c31bef2522a541db32834c9e0444
Author: Alexeev Bronislav <alexeev.dev@mail.ru>
Date:   Fri Feb 20 17:49:24 2026 +0700

    update docs

commit dac508e4371aec6586445fd6fa547e373a53cabf
Author: Alexeev Bronislav <alexeev.dev@mail.ru>
Date:   Fri Feb 20 17:49:08 2026 +0700

    update tests

commit ef5dec057758497001394b010dcfe6c7def62f0c
Author: Alexeev Bronislav <alexeev.dev@mail.ru>
Date:   Thu Feb 19 21:32:38 2026 +0700

    create basic structure

commit d1462c8621dbffbf488084260507937dcedc6f39
Author: Alexeev Bronislav <alexeev.dev@mail.ru>
Date:   Thu Feb 19 17:57:08 2026 +0700

    Initial commit
