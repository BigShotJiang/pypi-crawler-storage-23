<!-- Please explain the changes you made -->

<!--
Please, make sure:
- you have read the contributing guidelines:
  https://github.com/alexeev-prog/nadzoring/blob/main/CONTRIBUTING.md
- you have formatted the code using ruff & black.
- you have checked that all tests pass with 100% coverage
-->
