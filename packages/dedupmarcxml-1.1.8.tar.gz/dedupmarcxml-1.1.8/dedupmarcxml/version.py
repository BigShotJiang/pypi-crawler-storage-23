__version__ = '1.1.8'
commit_message = f'Improve books model'
