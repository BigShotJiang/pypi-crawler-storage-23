import lamindb as ln

ln.track("Ro1gl7n8YrdH0001")
