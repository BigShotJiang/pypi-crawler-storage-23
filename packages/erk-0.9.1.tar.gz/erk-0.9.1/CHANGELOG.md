# Changelog

All notable changes to erk will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.9.1] - 2026-03-01 16:06 PT

### Added

- Add `erk doctor workflow` subcommand with smoke testing for verifying GitHub workflow health
- Support external learned docs repository via `[docs] path` config in `.erk/config.local.toml`
- Add cmux workspace integration to dashboard and CLI, enabled via `cmux_integration = true` config
- Add auto-resolution of pre-existing bot threads in code-move PRs via `pr-address` and `pr-preview-address` commands
- Add "p" keybinding to open objective issue page in Objectives view
- Add "rewrite" command to TUI command palette for remote PR rebase and AI summary regeneration
- Add `gt submit` to TUI sync checkout command for streamlined branch submission
- Add `erk init --upgrade` flag for self-service upgrades after version changes
- Add `dispatch_ref` config to override workflow dispatch branch for testing workflow changes on feature branches
- Add `launch one-shot` command for triggering one-shot workflows with `--prompt`/`-f` options
- Display learn plan PR link in `erk land` output
- Add session preprocessing stats to `erk land` discovery output
- Add one-shot prompt modal to `erk dash` (`x` keybinding) for quick dispatch without leaving the TUI
- Add visible AI-generated summary to plan PRs, displayed above collapsed plan details for quick overview
- Show toast notification when learn plan is created during TUI landing

### Changed

- Rename "fix-conflicts" to "rebase" across CLI, TUI, workflows, and config -- `erk pr rebase` now always rebases
- Accumulate sessions across lifecycle stages on git branches for cross-machine learning
- Improve session discovery logging in `erk land` with per-session type badges and sizes
- Fix sync command clipboard text to include full command in TUI command palette
- Delay impl-context cleanup until submit phase to preserve plan tracking during implementation
- Rebase slot worktree placeholder branch onto master after `erk land` to keep slots fresh
- Rename "Fix Conflicts Remote" to "Rebase Remote" in TUI and always perform rebase
- Require `--summary` flag on `erk pr create` instead of auto-generating summaries
- Use LLM-generated branch name slugs for plan PRs, producing more descriptive branch names
- Move `erk run` under `erk workflow run` command hierarchy for consolidated workflow management
- Fix rebase shortcut key in TUI launch screen from 'f' to 'r' for mnemonic consistency

### Fixed

- Fix `erk pr dispatch` failure when plan branch is already checked out in a worktree slot
- Fix double activation when direnv triggers during `erk pr checkout --script`
- Fix `erk pr submit` silent hang with no output in piped environments
- Fix duplicate `gt submit` execution in cmux sync workflow
- Fix misleading data when GraphQL enrichment fails in `erk pr list` -- unenriched PRs now excluded from linkages with explicit degradation warnings
- Make `--script` mode resilient to errors in `erk br co` -- failures now produce a valid error script instead of empty stdout
- Fix workflow-started metadata block rendering to prevent parse failures during `erk land`
- Add resilient plan-header recovery for PR submission when metadata block is destroyed by implementation runs
- Fix CI check counts where skipped checks were counted as passing — planned PRs now show "0/0" instead of "13/13"
- Fix stacked plan branch checkout by rebasing onto parent before `gt track`
- Consolidate all plan creation paths to use draft PR workflow, completing migration away from issue-based plans
- Fix stale stack indicator showing incorrectly when parent PR is already merged

### Removed

- Remove erkdesk Electron desktop app and all references

## [0.9.0] - 2026-02-27 14:23 PT

### Release Overview

This release completes the migration to draft PRs as the sole plan backend, consolidates CLI commands under `erk pr`, and delivers major TUI dashboard improvements for filtering, async operations, and objective visibility.

#### Draft PR as Sole Plan Backend

**What it solves:** Dual plan backends (GitHub issues vs draft PRs) created complexity — every workflow needed to support both paths, and the issue-based backend lacked native diff views and CI integration.

**How it works:** Draft PRs are now the only plan backend. The `PlanBackendType` enum, `get_plan_backend()`, and all issue-based code paths have been removed. Plan metadata is consolidated to `plan-ref.json`, replacing the legacy `.impl/issue.json`.

**Key features:** No configuration needed — draft PR is the default and only option. Simplified plan-save, plan-implement, and learn pipelines.

#### CLI Consolidation under `erk pr`

**What it solves:** Plan management commands were spread across `erk plan` and `erk pr`, creating confusion about where to find commands.

**How it works:** All plan management commands (create, list, submit, checkout, close, view, log, replan, duplicate-check) are now under `erk pr <verb>`. The `erk plan` group has been removed. Branch names no longer encode plan IDs — plans are linked to branches via `plan-ref.json`.

**Key features:** `erk pr list`, `erk pr checkout`, `erk pr close`, `erk pr replan`, `erk pr duplicate-check`.

#### TUI Dashboard Polish

**What it solves:** The dashboard needed better filtering, async feedback, and objective visibility for managing large numbers of plans.

**How it works:** New filtering modes (by objective with `o`, by stack), persistent status bar messages for async operations, fire-and-forget dispatch, sparkline progress indicators for objectives, and clickable tab labels for mouse-driven navigation.

**Key features:** Objective filter (`o`), stack filter, failing CI checks modal (`h`), clickable ViewBar tabs, "blockers" column in Objectives dashboard, stacked PR indicators.

#### Non-Blocking TUI Operations

**What it solves:** Remote operations (dispatch, address, fix-conflicts) blocked the TUI with modal dialogs, preventing other work during long-running operations.

**How it works:** All remote operations now use a toast+worker pattern — they return immediately with a status notification, and results appear as persistent messages when complete.

**Key features:** Fire-and-forget dispatch, non-blocking fix-conflicts, persistent status bar messages.

---

_The sections below document changes since 0.8.1:_

### Major Changes

- Consolidate all plan management commands under `erk pr` — commands previously under `erk plan` (create, list, submit, checkout, close, view, log, replan, duplicate-check) are now at `erk pr <verb>`. The `erk plan` group has been removed.
- Remove plan ID encoding from branch names — plans are now linked to branches via `plan-ref.json` instead of embedding issue numbers in branch names (e.g., `plnd/1234-description` format is gone).
- Remove plan review PR feature — sunsets the ephemeral plan review PR workflow
- Switch default plan backend to draft PR — `draft_pr` is now the default instead of `github`

### Added

- Add persistent status bar messages for workflow operations in the TUI — async results (dispatch, address, fix-conflicts) now appear as persistent messages instead of disappearing notifications.
- Add inline objective filter to `erk dash` TUI — press `o` to filter the plan list to a specific objective.
- Add stack filter to `erk dash` TUI — filter plans by Graphite stack.
- Add `--sync` flag to `erk pr checkout` — automatically submits the checked-out PR to Graphite after checkout.
- Add ObjectivePlansScreen modal to `erk dash` TUI — view all plans linked to an objective in an embedded plan table overlay.
- Add automatic tmux session persistence to `erk codespace connect` — sessions now persist in tmux without requiring an explicit flag.
- Add `erk admin claude-ci` command for managing Claude CI workflows
- Add "implement locally" copyable command to TUI command palette
- Add copyable variants for close_plan, fix_conflicts_remote, and address_remote in TUI command palette
- Add `copy_land` command to TUI command palette
- Add `--plan-only` flag to `erk one-shot` for generating plans without implementation
- Add `-d` short flag for `--delete-current` option in `erk up`/`erk down` commands
- Bundle missing capability workflows (one-shot, pr-address, pr-fix-conflicts) for external dispatch
- Add local review marker to skip CI reviews when local code review passes
- Add stacked PR emoji indicator to dashboard for PRs targeting non-master branches
- Add `erk plan duplicate-check` for semantic duplicate detection using LLM inference
- Add "blockers" column to TUI Objectives dashboard with clickable plan numbers
- Add `-d` and `-u` short aliases for `--down` and `--up` flags in `erk land`
- Add diagnostics for dispatch metadata failures with improved TUI feedback
- Add keyboard shortcut (`n`) to open GitHub Actions run URL from TUI main list
- Link PR numbers to objective roadmap nodes automatically at submit time
- Add clickable tab labels to ViewBar in `erk dash` TUI for mouse-driven view switching
- Add `h` keybinding to `erk dash` TUI for viewing failing CI check runs on the selected PR

### Changed

- Fix-conflicts workflow in plan detail screen now uses toast+async pattern instead of a blocking modal with live subprocess output.
- Change TUI Dispatch/Queue keyboard shortcut from `s` to `d`.
- Move metadata blocks to the bottom of planned PR bodies.
- Rename `erk pr sync-divergence` command to `erk pr reconcile-with-remote`.
- `erk pr dispatch` now auto-detects the PR number from the current branch when no argument is provided.
- Remove "Closes #N" footer from PR bodies — plans no longer auto-close linked issues on merge via PR body footer.
- Speed up `erk dash` Plans and Learn tabs using a REST+GraphQL two-step fetch.
- Increase log panel height in plan detail screen.
- Rename `deps-state`/`deps` columns to `head-state`/`head` in Objectives dashboard.
- Eliminate `.worker-impl/` directory, consolidating onto `.erk/impl-context/`
- Redesign `erk plan list` to match dashboard layout
- Replace `erk pr submit --skip-description` with composable `erk exec push-and-create-pr`
- Change `erk land` default to direct execution without navigation
- Collapse "impling" and "impld" stage labels to "impl" in plan lifecycle display
- Redesign objectives TUI with sparkline progress indicators
- Move plan-header metadata block to bottom of PR descriptions
- Wrap review comment details in collapsible blocks
- Fire-and-forget workflow dispatch — TUI remote operations return immediately instead of blocking until workflow completes
- Replace `gh pr/issue view --web` commands with clickable URLs in next-steps output
- Strip `.erk/impl-context/` before restack in `erk pr sync` to avoid merge conflicts
- Consolidate PR validation into `--stage=impl` flag on `erk pr check`
- Convert submit pipeline to git plumbing, eliminating race conditions in shared worktrees
- Increase workflow dispatch polling timeout to ~62 seconds for `erk plan submit` reliability
- Convert TUI dispatch commands from blocking modals to non-blocking toast+worker pattern
- Remove backend label from statusline output
- Remove non-slot worktree after landing instead of leaving detached HEAD state
- Eliminate tmux from codespace remote execution — commands now run directly over SSH
- Simplify learn triggering in `erk land` with direct issue creation instead of async gist-based pipeline
- Improve success output for `erk pr submit` and `erk pr replan` with structured formatting
- Remove `.impl/issue.json` legacy support and consolidate plan metadata to `plan-ref.json`

### Fixed

- Fix modal keystroke leakage to the underlying view in TUI screens.
- Error correctly when `--new-slot` is used but the branch already exists in another worktree.
- Fix Graphite tracking divergence in `erk pr dispatch`.
- Fix objective head column in dashboard (plan field missing from RoadmapNode/ObjectiveNode).
- Fix learn PRs incorrectly appearing in the Planned PRs tab.
- Fix TUI dispatch command CLI path and user-facing labels after command rename.
- Fix learn plan PRs being auto-closed when their ephemeral base branch is deleted.
- Fix `erk pr submit` producing zero output on timeout.
- Fix silent plan-header metadata loss during PR submit.
- Fix PR diff accuracy in `get_diff_to_branch` by switching to three-dot (`...`) git syntax.
- Fix TUI plan submit command crash caused by invalid `-f` flag.
- Fix plan-save always basing the new branch off trunk instead of the current branch.
- Fix `lifecycle_stage` not being updated in all code paths of the PR submit pipeline.
- Fix `erk land` crash when branch is checked out in another worktree
- Fix plan-save to include branch_name in skipped_duplicate response
- Fix branch checkout in stack-in-place path
- Fix WARNING comment accumulation on metadata block updates
- Clear error when trigger_workflow finds skipped/cancelled run
- Fix plan-save branches incorrectly stacking on current branch instead of trunk
- Fix `impl-signal started` to include lifecycle_stage transition, preventing stuck "planned" status
- Fix objective update after landing for `plnd/` branches
- Fix `erk br co --for-plan` stacking plan branches on current branch instead of trunk
- Fix `erk land` crash when run from root worktree
- Fix session discovery for draft-PR plans by using header_fields
- Fix `erk plan check` for draft-PR plan format and simplify branch force-update logic
- Fix rocket emoji appearing on draft PRs in lifecycle display
- Fix Graphite tracking divergence by retracking immediately after SHA changes
- Fix objective update after land with deleted worktree path
- Fix `gt track` and `gt retrack` to use repo root instead of worktree path
- Fix objective-link preservation in replan flow
- Fix `erk br co --for-plan` output to include activation instructions
- Fix plan-header metadata block lost silently in CI update flow
- Fix auto-match roadmap nodes by PR reference in objective update
- Fix modal dismiss keys (Esc/q/Space) not working in TUI screens
- Fix `plan_id` not being threaded through land execution pipeline, preventing learn issue creation
- Fix `erk implement` showing "None" for plan content when PR body contained null `plan_comment_id`

### Removed

- Delete `erk pr sync` command. Use `erk pr reconcile-with-remote` for conflict resolution.
- Delete `-t/--tmux` explicit flag from `erk codespace connect` — tmux persistence is now automatic.
- Eliminate `--objective-issue` flag from plan-save commands.
- Eliminate `--no-wait` flag from dispatch workflow commands.
- Remove GitHub repository variables feature and related infrastructure
- Remove run_url gate from land PR command
- Remove `get_plan_backend()` and `PlanBackendType`, hardcoding draft PR as the only plan backend
- Remove `plan_backend` parameter and collapse dead github-backend code branches

## [0.8.1] - 2026-02-22 08:14 PT

### Added

- LLM-generated branch name slugs with shortened `plnd/` prefix for meaningful, compact branch names
- Add `--env` flag to `erk codespace connect` for setting environment variables in remote sessions
- Add `-f/--force` flag to `erk up`/`erk down` to skip interactive prompts and auto-close PRs during destructive operations

### Changed

- Restore abbreviated stage names (impling, impld) in TUI dashboard to fit column width
- Split status indicators into a separate "sts" column in the TUI dashboard
- Enhance objective view with parallel in-flight status, planning indicator, and multiple unblocked nodes

### Fixed

- Fix objective prose reconciliation reading metadata-only body instead of comment's objective-body block

## [0.8.0] - 2026-02-22 03:40 PT

### Release Overview

This release introduces dual plan backends, evolves objectives into a dependency graph, and streamlines branch management with stack-in-place workflows.

#### Draft PR Plan Backend

**What it solves:** Issue-based plans have limitations for code-heavy workflows — no native diff view, no CI integration, and awkward code review. Draft PRs provide a natural home for plans that will become code.

**How it works:** Plans can now be stored as GitHub draft PRs instead of issues, with `ERK_PLAN_BACKEND=draft_pr` controlling the backend. All workflows (plan-save, plan-implement, learn, CI) support both backends transparently.

**Key features:** `ERK_PLAN_BACKEND` environment variable, draft PR auto-publishing during `erk pr submit`, backend-agnostic plan checkout via `erk br co --for-plan`.

#### Objective Dependency Graph

**What it solves:** Objectives with linear roadmaps couldn't express real-world dependencies — some nodes can run in parallel, others must wait. The flat step list forced artificial sequencing.

**How it works:** Objectives now use a graph-based model (schema v3) with `depends_on` support between nodes. The vocabulary shifted from "steps" to "nodes" to reflect the graph structure. `erk objective view` displays the dependency graph, and `--all-unblocked` enables parallel dispatch of independent nodes.

**Key features:** `depends_on` field in objective roadmaps, "deps" column in TUI Objectives dashboard, `--all-unblocked` dispatch, `erk objective view` with dependency graph display.

#### Autonomous One-Shot Dispatch

**What it solves:** The plan-then-implement workflow requires human involvement at each stage. For well-defined tasks, this overhead isn't justified.

**How it works:** `erk one-shot` dispatches fully autonomous remote execution — an agent creates a plan, implements it, and submits a PR without user intervention. Extended to objectives via `erk objective next-plan --one-shot` for auto-dispatching the next unblocked roadmap node.

**Key features:** `erk one-shot` with `--file` and `--model` flags, `erk objective next-plan --one-shot`, automatic "Closes #N" PR references.

#### Stack-in-Place Branch Management

**What it solves:** Each stacked branch previously required its own worktree slot, limiting parallelism and wasting disk space.

**How it works:** `erk br create` in assigned worktree slots now updates the assignment tip in place, enabling stacked branches to share a single worktree. Plan checkout unified under `erk br co --for-plan` with `--new-slot` option.

**Key features:** `erk br co --for-plan`, `--new-slot` flag, `erk wt create-from` for adopting existing branches. `erk prepare` removed.

#### TUI Dashboard Evolution

**What it solves:** The dashboard was a single-view plans list. Users needed to switch between plans, learn sessions, and objectives constantly.

**How it works:** The dashboard now supports Plans, Learn, and Objectives views (toggled via 1/2/3 keys or arrow keys), with a launch screen for two-keystroke command execution. PR status indicators, author filtering, and lifecycle labels provide at-a-glance visibility.

**Key features:** View switching (1/2/3 keys), launch screen, branch and author columns, PR status display (draft/conflicts/review), non-blocking toast notifications.

---

_The sections below document changes since 0.7.4:_

### Major Changes

- Add draft PR plan backend: plans can now be stored as GitHub draft PRs instead of issues, with all workflows (plan-save, plan-implement, learn, CI) supporting both backends via environment-driven configuration
- Add objective dependency graph with `depends_on` support: roadmaps support explicit cross-phase dependencies, with a new "deps" column in Objectives dashboard and `--all-unblocked` dispatch for parallel node implementation
- Overhaul objective vocabulary and structure toward graph-based model: rename 'step' to 'node' with schema v3, merge `objective inspect` into `objective view` with dependency graph display, rename `objective-implement` to `objective-plan`, and fix node status validation
- Stack-in-place branch creation and `prepare` command removal: `erk br create` in assigned worktree slots now updates the assignment tip in place, enabling stacked branches to share a single worktree. `erk prepare` removed; use `erk br create --for-plan` instead

### Added

- Add objective tracking to TUI land flow and plan detail screen
- Add "codespace run objective plan" to objectives command palette in TUI
- Add `erk admin gh-actions-api-key` command for managing GitHub Actions API key secrets
- Add Claude inference kill switch via `CLAUDE_ENABLED` repository variable
- Add `--up` option to `erk stack consolidate` for upstack-only consolidation
- Add `--file` option to `erk one-shot` for passing long instructions via file
- Add `erk wt create-from` command for allocating worktree slots to existing branches with automatic remote branch fetching and `--force` flag
- Add branch column to TUI dashboard between "title" and "created"
- Add remote divergence pre-check before `gt submit` with actionable error messages
- Add launch screen to TUI dashboard for two-keystroke ACTION command execution
- Add `--oauth` flag to `erk admin gh-actions-api-key` for managing dual authentication secrets

### Changed

- Convert "Submit to Queue" and "Land PR" from modal dialogs to non-blocking toast pattern
- Show real-time progress in TUI status bar during "Land PR" operation with diagnostic error messages
- Batch objective node updates into single atomic write for reliability
- Refresh workspace packages automatically on activation to keep CLI current across worktree switches
- Rename `objective-implement` command to `objective-plan` to reflect planning-focused purpose
- Canonicalize branch naming to encode objective IDs consistently across submit and one-shot codepaths
- Add "Closes #N" reference to one-shot dispatch PR bodies at creation time for immediate TUI linkage
- Migrate session and learn material storage from GitHub Gists to git branches
- Rename "instruction" to "prompt" throughout `erk one-shot` feature
- Replace "issue" with "plan" in implement command output for backend-agnostic messaging
- Infer "implementing" lifecycle stage when plan has active workflow run
- Auto-force push for plan implementation branches in `erk pr submit`
- Restore PR status indicators (merge conflicts, review decisions) in dashboard
- Fix shell activation in draft PR next steps to use `source "$(erk br co ...)"` pattern
- Use branch name instead of PR number in draft PR checkout next steps
- Publish draft PRs during `erk pr submit` with mutation-safe tracking
- Unify plan checkout with `erk br co --for-plan` and `--new-slot`, replacing `erk br create --for-plan`
- Show full lifecycle labels ("implementing", "implemented") instead of abbreviations in dashboard; add `--show-runs`/`--show-prs` flags for conditional data fetching; consolidate PR status into lifecycle column
- Add PR status display (draft/conflicts/review) and reorganize TUI dashboard column layout
- Simplify plan backend configuration from 3-tier to 2-tier: `ERK_PLAN_BACKEND` env var or default, removing config-file tier
- Enable learn prompts for remote plan branches during `erk land`

### Fixed

- Fix submit pipeline error handling and add network timeout protection
- Fix misleading "PR rewritten" success message in `erk pr rewrite`
- Fix `erk prepare` to handle pre-existing branches with draft PR plan backend
- Fix plan reference loss when updating objective roadmap steps with PR numbers
- Fix `learned-docs` capability installation check to require all three directories and preserve user documentation on uninstall
- Fix local session fallback in `/erk:learn` to filter by branch name, preventing unrelated sessions from other branches
- Fix missing `branch_name` in plan-header metadata causing PR lookup failure during async learn
- Fix `erk-remote-setup` GitHub Action to accept either `ANTHROPIC_API_KEY` or `CLAUDE_CODE_OAUTH_TOKEN` instead of requiring both
- Fix draft PR plan list label duplication causing `erk plan list` to return "No plans found"
- Fix `erk one-shot` dispatch metadata writing for draft_pr backend
- Fix learn pipeline for draft-PR plans with direct PR lookup and metadata fallback
- Fix non-fast-forward push in draft-PR plan submission by adding rebase sync
- Fix `submit` command crashing when `.worker-impl/` already exists
- Fix `extract_metadata_prefix` falsely matching footer separator in PR bodies
- Fix `.erk/impl-context/` cleanup by deferring git removal to plan-implement
- Implement lazy tip sync for worktree pool to fix stale assignment state
- Fix `ci-update-pr-body` losing plan-header metadata on draft PR plans
- Fix Objectives screen columns being polluted by Plans screen columns
- Fix `erk land` cleanup crashing when branch is checked out in another worktree
- Fix learn pipeline by migrating from branch-based to gist-based materials storage

### Removed

- Remove `erk prepare` command — use `erk br create --for-plan` instead
- Remove `erk:prepare` command; use `erk br co --for-plan` instead

## [0.7.4] - 2026-02-16 05:33 PT

### Major Changes

- **Objective v2 format**: Objectives now use structured machine-parseable metadata blocks (objective-header and objective-roadmap) instead of fragile regex table parsing. Note: existing objectives must be recreated via `erk objective create` to migrate to v2 format
- **View switching in `erk dash` TUI**: The dashboard now supports Plans, Learn, and Objectives views toggled via 1/2/3 keys, with cached data for instant switching
- **Autonomous one-shot objective dispatch**: `erk one-shot` enables fully autonomous remote planning and implementation — an agent creates a plan, implements it, and submits a PR without user intervention. New in this release, `erk objective next-plan --one-shot` extends this to objective roadmap steps, auto-detecting the next pending step and dispatching it through the same pipeline
- **V2-only objective format enforcement**: All legacy v1 format support removed. Legacy objectives show a migration error directing users to recreate via `erk objective create`

### Added

- Add left/right arrow key bindings for cycling through dashboard views
- Add author column and author-based filtering to `erk dash` TUI
- Add progress logging to `erk docs sync`
- Add workflow run URL to PR body after `erk one-shot` and `erk plan submit`
- Display plan text in exit plan mode hook before save/implement decision
- Display one-shot instruction text in `erk objective next-plan --one-shot` output

### Changed

- Improve one-shot plan issue titles to use `One-shot: {instruction}` format
- Update all GitHub workflow default models to `claude-opus-4-6`
- Improve `erk objective view` roadmap alignment using Rich tables

### Fixed

- Fix TUI dashboard race condition when switching tabs during data fetch
- Fix rebase script comparing branch against itself instead of target branch
- Fix table plan column not cleared when PR is set in objective roadmap
- Fix `erk pr sync` missing push step after restacking
- Fix missing `ANTHROPIC_API_KEY` in pr-address workflow summary step

## [0.7.3] - 2026-02-15 03:30 PT

### Major Changes

- **One-shot autonomous remote execution**: New `erk one-shot` command dispatches fully autonomous remote planning and implementation — creates branch, draft PR, and triggers GitHub Actions workflow where Claude explores, plans, implements, and submits without local planning. Supports `--model` flag.

### Added

- Add `erk objective view` command for displaying objective metadata and roadmap
- Add YAML frontmatter as primary roadmap data source for objective issues, with table fallback
- Gate learn commands and docs command group behind `learned-docs` capability
- Add schema-driven `interactive_claude` configuration to `erk config` commands
- Add `--machine` flag to `erk codespace setup` and set default 16-core machine in devcontainer
- Embed implementation plan in remote queue draft PRs created via `erk plan submit`
- Add multi-step support to `update-roadmap-step` command
- Add `erk pr rewrite` command combining squash, AI message generation, commit amend, push, and remote PR update into a single operation
- Add "created" column to `erk dash` TUI showing relative creation time for each plan
- Add `erk pr update-description` command for updating PR title and body with AI-generated content
- Add "Run `erk learn` manually" option to the `erk land` learn-check menu
- Add unified `erk docs check` command merging `erk docs sync --check` and `erk docs validate`
- Add separate Plan and PR columns to objective roadmap tables

### Changed

- Update installation instructions from `uv tool install` to local venv workflow
- Simplify branch reuse prompt in `erk plan submit` to a single binary choice
- Remove unnecessary confirmation prompt in `erk learn` for gist-URL path; `-d` flag now implies auto-launch
- Update default model in plan-implement workflow from Sonnet to Opus

### Fixed

- Fix nested Claude Code subprocess calls failing by stripping CLAUDECODE environment variable
- Fix TUI dashboard failing to load any plans when a single issue has a missing plan-header metadata block
- Improve error message for Graphite restack conflicts in `erk pr submit`
- Fix `pr-fix-conflicts` workflow "Argument list too long" error by capturing Claude output internally
- Fix codespace creation by using REST API to bypass broken GitHub machines endpoint
- Fix `erk land` ignoring "n" answer to cleanup confirmation
- Fix remote implementation sessions being silently skipped during learn preprocessing

### Removed

- Remove `erk objective reconcile` command (duplicate of `erk objective next-plan`)
- Remove `erk pr summarize` command, replaced by `erk pr rewrite`

## [0.7.2] - 2026-02-02 14:13 PT

### Fixed

- Fix statusline causing dangling `git index.lock` files by disabling optional git locks in the statusline process

## [0.7.1] - 2026-02-02 08:48 PT

### Major Changes

- **Plan Review via Temporary PR**: New workflow for asynchronous plan review through draft PRs. Plans can be submitted as temporary PRs for review, with feedback incorporated back into the plan issue. Includes automatic branch management, PR lifecycle handling, and integration with `/erk:pr-address`.
- **Top-level `erk launch` command**: Unified workflow launcher moved from `erk workflow launch` to `erk launch`, providing shorter commands for triggering remote workflows.

### Added

- Consolidate `erk init capability list` and `erk init capability check` into unified `erk init capability list [name]` command
- Add plan context feedback to `erk pr summarize`, showing which plan issue is being incorporated
- Prevent duplicate inline review comments by deduplicating during review execution
- Add `erk objective check` command for validating objective roadmap status, labels, and consistency
- Add `-d/--dangerous` flag to `erk objective next-plan` for skipping permissions during plan creation
- Embed implementation plan in PR description as a collapsible `<details>` section
- Make Files Changed and Implementation Plan sections collapsible in PR body
- Add Quick Start section to plan review PRs with copy-pasteable `erk prepare` and `erk implement` commands

### Changed

- Move code reviews to Haiku model with flag-only prompts, no fix suggestions
- Fix discover-reviews for large PRs by switching to REST API with pagination
- Auto-fix Graphite tracking divergence in sync and branch creation
- Fix detached HEAD state after landing PR from root worktree
- Remove `--docker` and `--codespace` flags from `implement`/`prepare` commands; standalone `erk codespace` commands preserved
- Encode objective ID in branch names with `P{issue}-O{objective}-{slug}-{timestamp}` pattern
- Automatically close review PRs when plan implementation starts via `erk implement`
- Objective roadmap tables now show explicit status values (`done`, `in-progress`, `pending`) instead of `-`

### Fixed

- Fix objective reconcile plan quality by using Claude with codebase context instead of Haiku
- Fix TUI workflow launch commands
- Fix `erk br delete` not force-deleting merged PR branches
- Fix objective-save-to-issue plan lookup bug
- Fix remote implementation creates wrong branch
- Fix pr-fix-conflicts "Argument list too long" error in PR comment formatting
- Fix hardcoded PR URL in plan-create-review-pr, making it portable across repositories
- Fix Graphite tracking divergence after commit amend in `erk pr submit` finalization
- Fix placeholder branch creation failing in multi-worktree scenarios by bypassing Graphite for ephemeral stub branches

### Removed

- Remove fallback indicator from statusline

## [0.7.0] - 2026-01-24 15:12 PT

### Release Overview

This release adds remote execution capabilities, plan replanning workflows, and numerous TUI improvements for managing plans and PRs.

#### GitHub Codespaces Integration

**What it solves:** Running Claude implementations locally can be resource-intensive and requires keeping your machine available.

**How it works:** Create and manage Codespaces that can execute Claude implementations remotely. Codespaces are provisioned with erk and Claude Code pre-configured.

**Key features:** `erk codespace setup`, `erk codespace connect`, `--codespace` flag for `erk implement` and `erk prepare`.

#### Remote PR Review Addressing

**What it solves:** Addressing PR review comments previously required checking out the branch locally.

**How it works:** Triggers GitHub Actions to run Claude in CI, which reads review comments, makes changes, and pushes commits.

**Key features:** `erk pr address-remote` command, available in TUI via command palette.

#### Plan Replanning

**What it solves:** Plans can become stale as the codebase evolves, requiring re-evaluation against current state.

**How it works:** Re-reads the original plan context and generates an updated implementation plan considering recent changes.

**Key features:** `erk plan replan` CLI command, TUI shortcut "6" for replanning selected plans.

#### Branch Sync Intelligence

**What it solves:** Diverged branches cause confusing errors during stack operations.

**How it works:** Detects divergence between local and remote branches, offering intelligent sync/rebase options.

**Key features:** `/erk:sync-divergence` command, automatic divergence detection in land and sync commands.

---

_The sections below document all changes since 0.6.0:_

### Added

- Add `erk pr address-remote` to TUI command palette
- Add Claude-generated summaries to PR comments for `pr-address` workflow
- Add workflow run URL backlink to plans created from GitHub Actions
- Add `erk pr address-remote` command to trigger PR review comment addressing via GitHub Actions
- Add `/erk:sync-divergence` command to resolve diverged branches with intelligent sync/rebase
- Add `-f/--force` flag to `erk plan submit` for non-interactive branch cleanup
- Add PR cache polling for immediate status line display after submit
- Add objective column to TUI plan table with click-to-open functionality
- Add branch reuse detection in `erk plan submit` with interactive prompt to reuse existing branches
- Add multi-plan consolidation support to `erk plan replan` command
- Add automatic trunk sync validation in `erk plan submit`
- Add `get-pr-commits` and `close-issue-with-comment` exec commands
- Add `pr-sync-commit` exec command to sync PR title/body from latest commit message
- Display all available config keys in `erk config list` including interactive_claude settings
- Add `erk plan replan` CLI command for re-evaluating existing plans
- Add replan option to TUI command menu with keyboard shortcut "6"
- Show workflow URL for in-progress learn status in `erk plan view`
- Add prepare-and-implement one-liner to plan save output
- Enhance `erk plan view` with branch inference and improved learn status display
- Add closed PR detection to slot diagnostics and repair
- Auto-detect objective from branch in `erk exec land-execute` command
- Add `--codespace` isolation mode to `erk prepare` and `erk branch create` commands
- Add GitHub Codespaces integration for remote Claude execution with `erk codespace` commands (setup, connect, list, remove, set-default) and `--codespace` flag for `erk implement`
- Add `erk objective close` command to close completed objective issues
- Add `--allow-dangerously-skip-permissions` flag support for interactive Claude config
- Add direnv configuration for automatic virtual environment setup

### Changed

- Improve Claude CLI error reporting with exit code, stderr, and stdout context
- Move `[erk-plan]` marker to start of PR titles for consistency with `[erk-learn]` format
- Replace text prefixes with emoji category indicators in TUI command palette
- Move `[erk-learn]` prefix to beginning of plan issue titles for improved visibility
- Learn workflow now runs automatically in CI after implementation instead of requiring `--async` flag
- `erk pr sync` now syncs and restacks already-tracked branches instead of exiting silently
- Detect diverged branches in land command and handle pull safely
- Fix Graphite branch tracking when parent branch diverged from remote
- GraphiteBranchManager now has GitHub fallback for PR lookups when branches aren't in Graphite cache
- Split `--codespace` into separate `--codespace` (boolean) and `--codespace-name` (string) options
- Add `--no-session-persistence` flag to Claude CLI invocations for session isolation
- Skip git push when Graphite handles PR submission
- Make erk hooks resilient to erk unavailability by gracefully exiting if erk is not in PATH
- Fix TUI land command to execute PR merge instead of just generating script

### Fixed

- Strip "Documentation Plan: " prefix from learn plan titles
- Fix `pr-address` workflow to detect unpushed commits before pushing
- Update PR title with `[no-changes]` prefix when implementation produces no code changes
- Fix TUI generating invalid "erk br co None" checkout commands for plans without worktrees
- Fix `erk plan list` not displaying `[erk-learn]` prefix in titles
- Fix TUI not displaying `[erk-learn]` prefix in plan titles
- Fix branch not visible in `gt ls` after `erk plan submit` due to stale Graphite cache
- Fix diverged local branches during Graphite stack operations with automatic force-update
- Fix learn-dispatch workflow with missing `--verbose` flag
- Fix `setup-impl-from-issue` to checkout newly created branch
- Fix `erk plan submit` to validate parent branch is tracked by Graphite before stacking
- Fix stale pool.json state handling in branch checkout and slot allocation
- Fix gist filename handling by using stdin input for `gh gist create`
- Fix `download-remote-session` gist URL handling for webpage URLs
- Fix `update_slot_objective` to create new slot entries (upsert behavior)
- Fix `.erk/bin/` description in `erk init` to say "generated shell scripts"

### Removed

- Remove `erk planner` command group and associated infrastructure

## [0.6.0] - 2026-01-20 07:57 PT

### Major Changes

- **Convention-based code review system**: Introduces automatic code review discovery and execution based on conventions. Capabilities can define review workflows that run automatically on PRs. Users benefit from consistent, automated review checks without manual configuration.

- **Clickable activation commands with clipboard support**: Activation commands now display as clickable OSC 8 hyperlinks and automatically copy to clipboard via OSC 52. `erk implement` now defaults to `--here` mode (in-place implementation) removing pool slot management. Users can click activation commands directly or paste from clipboard instead of manual copy-paste.

- **Shell integration removed**: The shell integration system (shell wrappers, automatic directory switching, ERK_SHELL env var) has been completely eliminated. Navigation commands now print activation script instructions instead of automatically switching directories. Users source activation scripts manually or use `cd`. This simplifies the architecture while keeping core erk functionality intact.

- **Remote conflict resolution workflow**: Added `erk pr fix-conflicts-remote` command to trigger AI-powered conflict resolution on GitHub Actions without checking out branches locally. Squashes commits, rebases onto base branch, and uses Claude to resolve conflicts. Available in TUI via "5" key.

### Added

- Add activation script generation when allocating worktree slots
- Add shell completion (bash/zsh) to worktree activation script
- Add `--local` mode to code review for pre-PR review execution
- Add Docker isolated implementation mode with filesystem isolation
- Add `-d` short flag alias to all `--dangerous` flags
- Add post-init prompt hook support for new developer setup
- Add clipboard copy support for shell integration message in land command
- Add `erk plan co` command for checking out plan branches with flexible identifier formats (plain numbers, P-prefixed, or URLs) and automatic worktree creation
- Add unresolved PR comment count column to `erk dash` TUI
- Add git index lock retry logic to prevent conflicts during concurrent worktree operations
- Add navigation guide for branches and worktrees documentation
- Add `erk prepare` command as shorthand for `erk br create --for-plan PLAN`
- Auto-detect plan number from branch name with `erk implement --here`
- Add `--for-plan` option to `erk br create` for creating branches directly from GitHub issues
- Add `objective_id` field to Plan dataclass for direct access to parent objectives
- Add "Fix Conflicts Remote" action to TUI dashboard with keyboard shortcut "5"

### Changed

- Sort capabilities list alphabetically by name
- Rename `/erk:system:impl-execute` command to `/erk:plan-implement`
- Simplify activation output when deleting branch with force flag
- Remove shell integration requirement from land command
- Always copy activation commands to clipboard
- Increase land action timeout to 10 minutes in TUI
- Show branch name in `erk plan view` output when implementation is active
- Expand implementation plan details blocks by default in GitHub issues
- Enable CI autofix agent to automatically fix type errors
- Remove `erk-plan` label from objectives, keeping only `erk-objective` for clearer distinction
- Simplify plan workflow to use `erk prepare` instead of three-mode `erk implement`
- Update PR checkout instructions to use shell script pattern for proper worktree activation
- Rewrite first-plan.md tutorial clarifying two-step workflow: `erk prepare` then `erk implement --here`
- Branch delete hint now only shown when `--force` flag is provided
- Land command now displays PR number and branch name in source command for transparency

### Fixed

- Fix duplicate activation output in `erk land --up` execute mode
- Fix land command confirmation prompts moved to execute phase
- Fix Graphite branch deletion to handle diverged branches correctly
- Fix child branch tracking in land operation by re-parenting in Graphite before merge
- Fix activation script output when landing without learning
- Fix learn prompt to require explicit confirmation before landing without learning
- Fix PR landing action to execute post-land callback in TUI
- Fix land command to output script path when landing from different directory
- Fix `erk-bootstrap` to distinguish between "not in project" and "erk not installed" with targeted error messages
- Fix artifact sync to respect installed capabilities when syncing workflows and actions
- Fix `--local` config to write to repo root instead of worktree, so config is shared across worktrees
- Fix `erk land` hanging on confirmation prompts in script mode
- Fix `--here` mode to use process replacement instead of subshell fallback
- Fix `land.sh` script sourcing with process substitution for reliable temp file handling
- Fix `land.sh` to use `source` instead of `eval`
- Remove redundant "Error: " prefix from `erk land` shell integration message
- Fix session preprocessing to correctly handle embedded `tool_result` blocks

### Removed

- Delete `erk-sh-bootstrap` package and related documentation

## [0.5.5] - 2026-01-15 06:53 PT

### Major Changes

- **Per-user local configuration**: Add `.erk/config.local.toml` for personal settings that override shared repo config. Configuration now supports three-level hierarchy (Global < Repo < Local) with `--repo` and `--local` flags for `erk config set`. The `config list` command shows source annotations like "(repo)" and "(local)" to clarify override origins.

### Added

- Add `--here` flag to `erk implement` for in-place implementation without worktree switching
- Add pre-flight validation for Graphite-tracked branches with clear remediation guidance
- Rename `plan get` to `plan view` with structured header metadata display and `--full` flag

### Changed

- Update PR submit Phase 1 message to say "Creating or Updating PR" for clarity
- Add `.erk/config.local.toml` to gitignore and health checks

### Fixed

- Fix FileNotFoundError when invoking erk from shell integration in venv environments
- Fix `erk pr sync` failure for stacked PRs with locally restacked parents
- Fix automatic Graphite branch tracking during worktree creation when Graphite is enabled
- Fix `erk doctor` to show remediation steps for artifact warnings, not just failures
- Fix `erk artifact sync` to update hook commands in settings.json, ensuring hooks stay current across erk versions
- Fix `erk pr land` learn prompt to default to continuing (press Enter to proceed)

## [0.5.4] - 2026-01-13 12:29 PT

### Added

- Add composite action extension point for customizing erk-impl workflow (Python version, system dependencies, environment variables)

### Changed

- Add secret validation to erk-impl workflow with clear error messages when ERK_QUEUE_GH_PAT is missing

### Fixed

- Fix `erk init` skipping global config creation when repo already erkified
- Fix erk-impl workflow silent failure on implementation errors
- Fix spurious learn warning when landing remote PRs without local worktrees

### Removed

- Remove `erk upgrade` command (version management now handled via `uv tool`)

## [0.5.3] - 2026-01-13 06:04 PT

### Major Changes

- **Shell integration bootstrap system**: Introduce `erk-sh-bootstrap`, a lightweight package that enables running erk via `uvx erk-sh-bootstrap` without requiring a global installation. Shell wrappers now delegate to project-local erk binaries, improving per-project version isolation.

### Added

- Add `--max-tokens` option to `preprocess-session` for automatic chunking of large session logs into multiple files
- Add `--dangerous` flag to `erk learn` command for skipping permission prompts

### Fixed

- Fix child PRs being auto-closed when landing parent branch by querying GitHub directly for dependent PRs
- Fix `erk submit` to track branches with Graphite, enabling proper PR stacking and preventing auto-closure of dependent PRs
- Fix hook updates not applying when hooks are re-installed (old hooks with stale commands now get replaced)
- Fix dignified-python-review capability workflow to use centralized Claude Code setup action

## [0.5.2] - 2026-01-12 07:54 PT

### Added

- Add `erk init capability remove` command for uninstalling capabilities
- Add `prompt_learn_on_land` config setting to disable learn prompts during PR landing

### Changed

- Make artifact health checks capability-aware to avoid false warnings for uninstalled capabilities

## [0.5.1] - 2026-01-12 01:42 PT

### Added

- Add learn event tracking to plan-header metadata for better session-plan correlation
- Add `-f` flag to TUI land PR commands for non-interactive mode

### Fixed

- Fix preprocess-session to filter agent logs by session ID, reducing output bloat
- Fix closing reference preservation when `.impl/issue.json` is missing
- Fix GitHub Actions code injection vulnerability in learn-dispatch workflow

## [0.5.0] - 2026-01-11 23:58 PT

### Release Overview

The 0.5.0 release consolidates four major systems that transform erk from a plan execution tool into a comprehensive platform for AI-assisted software engineering.

#### Objective System

Erk plans solve the single-PR problem well, but real engineering work often spans multiple related PRs toward a coherent goal. The Objective System provides coordination infrastructure for multi-PR initiatives.

**What it solves:** Context loss between related implementations. When work spans multiple sessions and PRs, design decisions, lessons learned, and progress tracking were previously scattered or lost entirely.

**How it works:** An objective is a GitHub issue (labeled `erk-objective`) that acts as a coordination document and changelog. It contains a phased roadmap breaking work into shippable PRs, design decisions that guide all related work, and action comments that capture lessons learned as each piece lands. Objectives can be completeable –– a defined set of substeps or phases –– or a permanent objective, that can be continuously evaluated against a system for all of time (e.g. ensure all files are less than 20k tokens).

**Key workflow:**

- `erk objective create` - Interactive creation with structure recommendations (steelthread-first development)
- `erk objective next-plan` - Pick a roadmap step and generate an implementation plan
- `erk land` integration - Automatically prompts to update objectives when landing related PRs

Objectives are human-first markdown documents optimized for session handoff—any future session can pick up implementation without re-exploring context.

#### Learning System

AI agents discover valuable insights during implementation: API quirks, architectural patterns, edge cases, and design rationale. This knowledge typically evaporates once the PR lands. The Learning System systematically captures and codifies these discoveries.

**What it solves:** Knowledge loss from implementation sessions. Claude reads files, discovers patterns, encounters gotchas, and makes decisions—but none of this persists beyond the session.

**How it works:** `erk learn` discovers all Claude Code sessions associated with a plan (planning session, implementation sessions) and launches Claude to analyze them. The `/erk:learn` skill performs deep session analysis, extracting documentation items that fill genuine knowledge gaps rather than duplicating existing documentation.

**Key features:**

- Session discovery from GitHub metadata and local logs
- Compressed XML preprocessing for efficient context
- Categorization: Learning gaps (external knowledge) vs Teaching gaps (documenting new features)
- Automated workflow via `learn-workflow` capability for hands-off documentation generation

The system creates a virtuous cycle: each implementation makes future implementations faster through accumulated documentation.

#### Capability-Based Architecture

As erk's feature set grew, initialization became unwieldy—a monolithic process that installed everything or nothing. The Capability System introduces modular, pluggable optional features.

**What it solves:** All-or-nothing feature installation. Different repositories need different features: some want code review workflows, others want the statusline, some want reminder systems. Previously this required manual file management.

**How it works:** Each capability is a self-contained unit with declarative installation, dependency checking, and status tracking. Capabilities span multiple types: skills, workflows, agents, reminders, and infrastructure settings. They can be project-scoped (per-repository) or user-scoped (global).

**Key commands:**

- `erk init capability list` - Show all available capabilities
- `erk init capability check` - Verify installation status
- `erk init capability add <name>` - Install one or more capabilities

Available capabilities include `dignified-python`, `fake-driven-testing`, `dignified-review`, `learn-workflow`, `statusline`, `shell-integration`, and reminder systems for coding standards enforcement.

#### Worktree Pool System

Git worktrees enable parallel development, but naive worktree management caused significant problems: slow creation, `index.lock` race conditions, shell state contamination, and unbounded resource consumption.

**What it solves:** The pool system addresses performance (worktree creation is slow), resource management (worktrees accumulating on disk), `index.lock` contention (concurrent git operations conflicting), and shell state isolation (clean separation of session artifacts).

**How it works:** Instead of creating and destroying worktrees on-demand, erk maintains a configurable pool of pre-allocated slots (`erk-slot-01` through `erk-slot-04` by default). Branches are assigned to slots dynamically, with LRU eviction when the pool is full. Placeholder branches hold unassigned slots ready for instant reuse.

**Key commands:**

- `erk slot init-pool` - Pre-allocate all slots
- `erk slot list` - Unified pool health view (assignments, status, issues)
- `erk slot repair` - Auto-fix stale assignments and orphaned state

The system includes comprehensive diagnostics detecting orphaned state, missing branches, and branch mismatches, with automatic repair capabilities.

---

In this specific version:

### Added

- Add `--no-delete` flag to `erk land` to preserve branch and worktree slot after merging PR
- Add `-f/--force` hint to error message when deleting branch with open PR
- Add `learn-workflow` as installable capability via `erk init capability add learn-workflow`
- Add opt-in reminder system for coding standards enforcement via capability markers in `.erk/state.toml`
- Add configurable Claude CLI launcher with `[interactive-claude]` config section for model, permission mode, and other settings
- Expand tutorial and topic documentation with installation guides and design explanations

### Changed

- Suppress slot warning when `--force` flag is specified in land command

### Fixed

- Fix `erk dash -l` hanging by setting subprocess stdin to DEVNULL
- Fix token reduction metric in session preprocessing to include agent logs in calculation
- Fix `erk land` failing when branch is checked out in stale pool state
- Skip dirty slots in `find_inactive_slot()` instead of failing, enabling concurrent slot allocation

### Removed

- Remove `erk plan start` command

## [0.4.7] - 2026-01-11 02:19 PT

### Major Changes

- **Shell integration is now optional**: `erk implement` works without shell integration configured. When ERK_SHELL is not set, erk spawns a subshell in the worktree and launches Claude automatically.
- **Simplified worktree preservation in `erk land`**: The command now always preserves slot worktrees when landing PRs, only deleting the branch. This prevents accidental worktree loss and makes the workflow more predictable for users with persistent worktree setups.
- **Reorganized init process into capabilities**: The init command now uses a capability-based architecture with `erk init capability` subcommands. Capabilities can be managed at project or user scope, and include skills, workflows, agents, and groups.

### Added

- Add PR review thread counts to statusline
- Add tripwires-review as an installable capability
- Add ShellIntegrationCapability for shell wrapper installation
- Add sync status display to branch and PR checkout commands showing ahead/behind/diverged state with bot commit detection
- Add ruff auto-format capability for automatic Python formatting on Write/Edit
- Add "Exists" column to `erk slot list` showing physical worktree directory status
- Add error message when submitting stacked PR without parent PR, guiding users to `gt submit -s`
- Offer to close plan issues missing closing references during `erk land`
- Add `erk admin test-erk-impl-gh-workflow` command for testing workflow changes before merge
- Validate Claude credentials in erk-impl workflow before execution
- Add Anthropic API authentication secret health check to `erk doctor`
- Add conditional erk-shared installation for monorepo flexibility
- Add `--dry-run` flag to `erk slot repair` for previewing repairs; repair now automatically fixes all four issue types
- Add branch context header to plan mode exit prompt
- Render plan content as Markdown in TUI dashboard
- Add `v` key binding to view full plan text in modal in TUI
- Add slot allocation support to `erk branch checkout` command
- Add slot allocation support to `erk pr checkout` with `--no-slot` and `--force` options
- Add health check for legacy slot naming convention in `erk doctor`
- Make `erk pr sync` work without Graphite using git-only mode
- Add automatic PS1 prompt modification for worktree subshells
- Fail on unresolved comments in non-interactive mode for `erk land`

### Changed

- Improve capability list formatting with scope grouping
- Refactor capability check output formatting
- Replace `--statusline` and `--with-dignified-review` flags with `erk init capability add` commands
- Graphite branch delete now falls back to git when branch is untracked or diverged
- Improve capability display formatting in init command output
- Support `erk land` without Graphite enabled
- Migrate diff extraction from GitHub API to local git to handle large diffs exceeding GitHub's ~20k line limit
- Fix PR submit output to distinguish between created and existing PRs
- Default to Yes for `erk init` settings confirmation
- Update TUI checkout command to use branch-based checkout
- Standardize "slot" terminology for worktree pool throughout CLI

### Fixed

- Fix false branch-mismatch error for stacked branches in slot list
- Fix index.lock race condition in erk land
- Fix CI autofix prompt variable substitution
- Fix statusline crash when creating RealGitHub instances without repo_info
- Fix GitHub integration by properly resolving Graphite implementation based on config
- Improve plan issue closure detection with retry logic and closing reference validation
- Fix `erk land` failing from non-slot worktrees by checking out trunk before branch deletion
- Fix `erk land` to preserve slot worktrees when branches are checked out via `gt get`
- Fix slot detection in `erk land` to use branch name instead of path comparison
- Fix actions bundling to be optional when workflows aren't installed
- Fix PR column in `erk wt ls` by using GitHub API instead of Graphite cache
- Make `erk dash` resilient to GitHub API failures
- Allow landing PRs for locally existing branches in TUI
- Fix `erk land -f` to execute objective update
- Fix version warning to use LBYL pattern for git repo detection

### Removed

- Remove `erk slot check` command; functionality merged into `erk slot repair`
- Remove `show_pr_info` configuration flag; PR info now always fetched efficiently
- Delete presets feature from init command

## [0.4.6] - 2026-01-06 12:21 PT

### Added

- Add `erk branch delete` command with worktree-aware cleanup
- Add HTTP client gateway for faster in-process plan closing in TUI
- Add prompt to close open PR when deleting branch
- Add 30-second timeout for streaming commands in TUI
- Update upstack PR base branches to trunk when landing stacked PRs
- Add MkDocs documentation build with GitHub Pages deployment
- Bundle GitHub Actions and CI autofix prompt in package distribution for external repo erk-impl support
- Add `erk doctor` health check for ERK_QUEUE_GH_PAT secret configuration

### Changed

- Restructure README into comprehensive documentation hub in `docs/`

## [0.4.5] - 2026-01-05 17:19 PT

### Changed

- `erk init` now sets up plans repo labels and Claude permissions automatically

### Fixed

- Fix submit command to use trunk as base when on placeholder or unpushed branches
- Handle `gh api` target repo substitution and validate erk-managed repos
- Handle terminal editors (vim, nano, etc.) in plan edit flow
- Silence version check warning outside git repos

## [0.4.4] - 2026-01-05 10:45 PT

### Added

- Add `--clear-hook-logs` option to `erk doctor` command
- Add check counts to status line display
- Add logging to statusline for debugging GitHub data fetches and cache behavior

### Changed

- Handle merge conflicts in erk-impl workflow by attempting rebase with Claude assistance
- Clarify plan-save command output handling to preserve dangerous option in instructions

### Fixed

- Fix keyword argument passing to create_branch_manager factory function

## [0.4.3] - 2026-01-05 07:55 PT

### Added

- Add `erk upgrade` command to update local installation to repo's required version
- Display plan issue closure status after landing PR
- Display plan title and file path in exit plan mode prompt for better context

### Changed

- Handle restack conflicts gracefully in `pr sync` with user-friendly guidance
- Prioritize Claude Code `/erk:plan-submit` slash command in plan submission next steps
- Condense `erk doctor` output with collapsible sub-groups and opt-in `--dogfooder` flag

## [0.4.2] - 2026-01-04 21:19 PT

### Added

- Add Python 3.11 support and fix forward reference compatibility

### Changed

- Implement always gets new slot for maximum parallelism

### Fixed

- Fix CI to use correct Python version in uv during unit tests

## [0.4.1] - 2026-01-04 19:40 PT

### Added

- Add `erk admin upgrade-repo` command to update repo to installed erk version
- Add `erk doctor` check for post-plan-implement CI hook configuration

### Fixed

- Fix orphaned worktree discovery to use git instead of pool state
- Fix branch creation with `--force` to reuse existing slots via checkout
- Fix hook state tracking to record all installed hooks in `erk sync`

## [0.4.0] - 2026-01-04 18:09 PT

### Major Changes

- **Worktree Pool System**: Pre-initialized worktree slots replace ephemeral worktree creation. Creating and deleting worktrees on larger repositories caused significant problems: shells left on deleted working directories, an epidemic of git `index.lock` issues, and slow worktree operations. The pool system maintains a configurable number of persistent slots that are reused across assignments. Commands: `erk slot init`, `erk slot list`, and `erk slot repair`.

- **`erk br` namespace for branch management**: Consolidated branch lifecycle commands (`create`, `assign`, `unassign`) under `erk br` (short alias for `branch`). The `slot` group now focuses exclusively on pool infrastructure. Includes `--no-slot` flag for creating branches without slot assignment.

- **`erk pr fix-conflicts` command**: AI-powered merge conflict resolution. When rebasing causes conflicts, this command uses Claude to analyze and resolve conflicts automatically.

### Added

- Detect uncommitted changes before checkout in slot assignment with user-friendly error messages
- Add `erk slot repair` command to remove stale assignments from pool state
- Create `/erk:implement-stacked-plan` command for stacked branch implementation
- Add visible URL column to objective list command output
- Add `pool.max_slots` configuration and worktree slot pre-initialization
- Add same-slot stacking for `erk implement` - stacks new branches on current branch instead of consuming a new slot
- Add "Changes" column to `erk slot list` showing dirty/clean status for each worktree
- Add `--dry-run` flag to `erk land` command to preview deletions without executing
- Bundle `dignified-python` skill with `erk sync` command by default

### Changed

- Clarify slot list UX with improved status ("available", "assigned", "error") and reason terminology
- Simplify slot unassign to accept only worktree names
- Rename objective plan creation command from `objective-create-plan` to `objective-next-plan`
- Rename pooled sync to pooled check
- Use `gt create` for branch creation when Graphite enabled
- Update CI workflows to use claude-haiku-4 instead of claude-opus-4-5

### Fixed

- Fix erk land UX issues: improve confirmation prompt clarity and prevent unwanted navigation
- Fix erk land to properly unassign pool slots instead of deleting them
- Fix pool_size config override when loading existing pool state
- Fix pooled implement shell integration registration
- Fix pooled unassign to checkout placeholder branch and validate worktree state
- Fix `erk pr land` failing when deleting remote branches from git worktrees
- Fix UserPromptSubmit hook matcher to apply to all prompts
- Fix delete remote branch for landing PRs via gh pr merge --delete-branch
- Suppress "branch not found" message during fork PR cleanup
- Fix erk land objective update flow and shell integration output routing
- Fix statusline detection to accept commands with or without uvx prefix
- Fix CLI crash when running outside git repository
- Fix slot selection to exclude initialized worktrees during on-demand creation

### Removed

- Delete auto-restack feature and related infrastructure
- Delete 9 dead erk exec commands
- Remove step progress tracking from implementation system - plans no longer require step metadata

## [0.3.3] - 2026-01-02 13:44 PT

### Changed

- Move erk-statusline from dev to core dependencies

### Fixed

- Fix BranchMetadata forward reference

## [0.3.2] - 2026-01-02 12:30 PT

### Major Changes

- **dignified-review**: Added AI-assisted code review as an optionally installed GitHub Action. Ensures compliance with dignified-python standards during code review by leaving comments on PRs. Comments are designed to be resolved via `/erk:pr-address`.

- **Top-level `erk land` command**: Promoted land from `erk pr land` to `erk land`. Now accepts PR numbers, URLs, or branch names. Includes shell aliases `br land` and `branch land`. Landing PRs is a high-frequency operation that deserves top-level access.

- **Cross-repo plan storage**: Plans can now be stored in a separate repository. Configure via `.erk/config.toml` with `[plans] repo = "owner/repo"`. This avoids polluting the main codebase with plan issues, particularly valuable for open source repos like dagster where we don't want erk-specific artifacts.

- **erk-statusline**: Added the erk statusline. Optionally installable via `erk init --statusline`. Displays current branch, worktree, GitHub checks status, PR info, and more. Provides at-a-glance visibility into your development state without running commands.

- **Graphite opt-in**: Graphite is now optional. Not everyone uses Graphite, so although you don't get stacking features, Graphite-less operation is now a fully supported workflow. Commands gracefully degrade to standard git operations.

### Added

- Add command logging for CLI audit trail
- Add step-based progress tracking with GitHub metadata sync
- Add per-artifact version and hash tracking for health monitoring
- Add dynamic tripwire enforcement system
- Add erk-statusline configuration to init and health checks
- Add copy-pasteable commands section to plan issues
- Add auto-rebase when local branch is behind remote before push
- Add `--session-id` flag to marker CLI commands for explicit session ID
- Add configurable `default` parameter to `user_confirm` function

### Changed

- Restructure init command with stepped flow and status line setup
- Standardize GitHub Actions workflow naming to kebab-case

### Fixed

- Fix `erk pr checkout` for stacked PRs
- Fix dignified-python skill LBYL vs try/except guidance
- Fix `erk wt delete --all` to show accurate PR/plan status in planning phase
- Fix confirmation prompt output to stderr for consistency
- Fix pr-address skill handling of outdated review threads
- Fix changelog commit hash marker parsing to expect backtick formatting
- Fix frontmatter deprecation warning cluttering test output
- Fix GitHub Actions shell specification in review workflows
- Fix Claude Code installation path in Docker image
- Fix status comparison: compare against `StatusData.loading()` not `is None`

## [0.3.1] - 2025-12-31 15:52 PT

### Fixed

- Make step extraction gracefully degrade to empty list on empty LLM output

### Changed

- Update release process documentation and consolidate into RELEASING.md

## [0.3.0] - 2025-12-31 14:13 PT

### Release Overview

This release dramatically simplifies erk's architecture by eliminating the kit system and consolidating artifact management into a single, automated workflow.

#### Kit System Eliminated

The kit system has been completely removed. Previously, users installed and managed "kits" (bundles of skills, commands, and agents) per-project. Now erk owns its artifacts directly:

- No `erk kit install`, `erk kit sync`, or kit registry commands
- Artifacts are bundled with erk itself and synced automatically
- One less concept to understand, one less thing to manage

#### Unified Artifact Management

erk now maintains a set of **bundled artifacts** that it syncs to target projects:

- **Skills**: `dignified-python`, `learned-docs`, `erk-diff-analysis`
- **Commands**: All `/erk:*` namespace commands (`/erk:plan-implement`, `/erk:pr-submit`, etc.)
- **Agents**: `devrun` (for running pytest/ty/ruff/make)
- **Workflows**: `erk-impl.yml` (for remote plan implementation via GitHub Actions)
- **Hooks**: `user-prompt-hook` and `exit-plan-mode-hook` (session management and plan tracking)

Running `erk init` or `erk artifact sync`:

1. Copies file-based artifacts to `.claude/` and `.github/workflows/`
2. Adds hook configurations to `.claude/settings.json`
3. Stamps the version in `.erk/state.toml` for staleness detection

`erk doctor` and `erk artifact check` detect stale, missing, or orphaned artifacts—including missing hook configurations. Projects keep full ownership of `.claude/`; erk only manages its namespaced artifacts.

#### Repo-Level Constraint

erk now requires Claude to be launched from the git repository root. This simplifies worktree detection, artifact paths, and context creation. If you previously ran Claude from subdirectories, launch from the repo root instead. This matches how most users already work and provides a stable foundation.

#### Global Install Required (UVX Not Supported)

We explored using `uvx erk` for zero-install usage, but this isn't feasible due to shell integration. Commands like `erk implement`, `erk up`, `erk down`, and `erk wt checkout` change your shell's working directory—something only a shell function can do. This requires a shell wrapper function (installed via `erk init --shell`) that calls a persistent `erk` binary in your PATH.

**The solution is simple**: Install erk globally with `uv tool install erk`. erk handles the rest:

- Each repo has a `.erk/required-erk-uv-tool-version` file specifying the required version
- If your installed version doesn't match, erk warns you immediately with the fix: `uv tool upgrade erk`
- One person on the team updates the version file; everyone else follows the prompt

You don't install erk into each project—just keep your global tool current and artifacts synced. erk tells you when action is needed.

---

### Major Changes

- Extend artifact management to GitHub workflows with model configurability and OAuth support
- The kit system has been completely eliminated. erk installs its own artifacts directly with no user management required.
- We have moved back everything to be at repo-level. You must run claude at git repo root. This has simplified the architecture
- Migrate to static `erk exec` architecture, eliminating dynamic kit script loading
- Merge git kit into erk artifacts with unified `/erk:git-pr-push` command namespace
- Merge gt kit into erk artifacts, consolidating Graphite stack management
- Delete kit infrastructure entirely, relocating utilities to erk core packages
- Add unified artifact distribution system with discovery, sync, and staleness detection
- Relocate all erk documentation from `.erk/docs/agent` to `docs/learned/`

### Added

- Add uvx/`uv tool run` detection with warning and confirmation prompt for shell integration commands
- Add missing artifact detection to complement orphan detection for bidirectional artifact health checks
- Add doctor checks for exit-plan-hook and required-version validation
- Add erk-managed indicator badges to artifact list command output
- Add retry logic with exponential backoff to prompt executor for transient API failures
- Add `impl` command alias for `implement` in shell integration
- Establish `.erk/prompt-hooks/` directory for AI-readable hook instructions
- Add "Edit the plan" option to exit plan mode hook
- Add `-f`/`--force` flag to `erk pr submit` for diverged branches
- Add `show_hidden_commands` config option to control visibility of deprecated commands
- Add hook initialization support to `erk init` command with `--hooks` flag
- Add backup file creation when modifying settings.json
- Add legacy pattern detection health checks for early dogfooders
- Add tool version checking to warn when installed erk is outdated
- Add automatic `--pull/--no-pull` option to `erk pr land` command
- Always show last commit time in branch list by default
- Add `reply-to-discussion-comment` exec command for formatted PR comment replies
- Implement LLM-based step extraction for plan implementation folders

### Changed

- Restrict artifact sync to only copy bundled items, preventing dev-only artifacts from leaking into projects
- Make missing artifacts detection fail instead of warn
- Rename `/erk:save-plan` command to `/erk:plan-save` for consistency
- Integrate artifact syncing into `erk init` command
- Rename agent-docs skill to learned-docs
- Flatten agent folders to top-level artifacts
- Move `/gt:pr-submit` to `/erk:pr-submit`, from the gt kit to the erk kit
- Move erk scripts to top-level `erk exec` from `erk kit exec erk`
- Remove kit registry subsystem
- Remove `kit list`, `remove`, `search`, and `show` commands - consolidated into `dot-agent`
- Rename `auto_restack_skip_dangerous` config to `auto_restack_require_dangerous_flag` with flipped default
- Convert devrun from kit to single agent file
- Remove dignified-python kit - consolidated into vanilla skill
- Consolidate dignified-python skill into single version-aware implementation
- Rename `gt-graphite` skill to `gt` with simplified directory structure
- Streamline devrun agent to use Sonnet model with minimal documentation
- Standardize erk hook ID to `user-prompt-hook` via `erk exec` command
- Rename health check names to kebab-case format
- Scrub all kit references from repository
- Remove support for standalone docs in `.claude/docs/` directory; use skills instead
- Make PR parsing stricter by requiring github.com URLs
- Eliminate kit.yaml manifest files, use frontmatter-based artifact discovery
- Remove `erk kit` CLI commands and simplify artifact management

### Fixed

- Fix missing error handling for deleted plan comment references with graceful fallback
- Fix artifact check to display only installed artifacts instead of bundled defaults
- Fix artifact sync path detection for editable installs
- Fix function name import and call in post_plan_comment script
- Fix `erk stack list` to show branches without worktrees using ancestor worktree
- Fix: Validate GitHub PR base branch matches local trunk before landing
- Fix AskUserQuestion option formatting in exit plan mode hook
- Fix hook subdirectory bug by using shared scratch directory utilities
- Fix shell completion context creation in resilient parsing mode
- Re-implement branch divergence check for PR submission with pre-flight validation
- Fix LLM step extraction robustness by upgrading to Sonnet model
- Fix LLM empty output handling in step extraction with diagnostic logging
- Add issue title to plan save output

### Removed

- Remove objectives feature
- Disable session context embedding in plan save-to-issue command

## [0.2.8] - 2025-12-18 06:51 PT

### Fixed

- Fix Bun crash when launching Claude Code CLI from tmux by conditionally redirecting TTY only when needed

## [0.2.7] - 2025-12-15 06:59 PT

### Major Changes

- Reorganize CLI commands for consistency with unified `list` and `checkout` patterns across worktrees, branches, and PRs
  - Move `submit` to `erk plan submit`
  - Add `erk branch` command group with `checkout` (`co`) and `list` (`ls`) subcommands
  - Rename `erk wt goto` to `erk wt checkout` with `co` alias
  - Remove top-level `list` and `delete` commands, now `erk wt list` and `erk wt delete`
- Remove standalone `erk kit sync` command, consolidated into `erk kit install --force`

### Added

- Add `.impl/` preservation guardrail to plan-implement workflow to prevent agents from deleting implementation plans - note: this may cause hard failures, please report if encountered
- Add `--all` flag to `erk wt delete` to close associated PR and plan
- Add copy logs button (`y` key) to plan detail screen
- Add config option `auto_restack_skip_dangerous` to skip `--dangerous` flag requirement
- Add `impl` alias for `erk implement` command
- Add prefix matching (PXXXX) for worktree-to-issue association
- Add PR URL display in quick-submit output

### Changed

- Clean up CLI help string organization and improve command grouping
- Improve devrun hook message to increase agent adherence to devrun pattern
- Move CHANGELOG.md to repository root for PyPI distribution
- Migrate PR and issue queries from GraphQL to REST API for rate limit avoidance
- Rename `/erk:submit-plan` command to `/erk:plan-submit` for consistency

### Fixed

- Fix release notes banner showing repeatedly when switching between worktrees with different erk versions
- Fix branch divergence error handling in PR submission with actionable remediation message
- Fix PR submissions to use Graphite parent branch instead of trunk

### Removed

- Remove SESSION_CONTEXT environment variable for session ID passing

## [0.2.5] - 2025-12-12 14:30 PT

### Major Changes

- Publish `erk` and `erk-shared` packages to PyPI - install via `uv pip install erk` or run directly with `uvx erk`
- Relocate all erk-managed documentation from `docs/agent/` and `.claude/docs/` to unified `.erk/docs/` structure
- Add hook execution logging system with new "Hooks" section in `erk doctor` for health monitoring
- Add integrated release notes system with version change detection and `erk info release-notes` command

### Added

- Add link indicator to PR display in plan dashboard for quick GitHub access
- Add `--force` flag to bypass open PR checks with confirmation in navigation commands
- Add `--dangerous` flag to `erk pr auto-restack` and `erk pr sync` commands for explicit opt-in to risky operations

### Changed

- Remove legacy `dot-agent.toml` configuration and migrate to `kits.toml`
- Add `erk doctor` checks for legacy documentation locations

### Fixed

- Fix release notes banner incorrectly shown on version downgrade in multi-worktree setups
- Fix nested bullet indentation in release notes parsing and display

### Removed

- Remove outdated erk skill documentation from `.claude/skills/erk/`

## [0.2.3] - 2025-12-12

### Added

- Add orphaned artifact detection for `.claude/` directory
- Add hooks disabled check to `erk doctor` command with warning indicator
- Add critical safety guardrail against automatic remote pushes

### Changed

- Eliminated the `dot-agent-kit` package entirely and consolidated config:
  - Repository config moved to `.erk/config.toml` with legacy fallback support
  - Consolidate into `erk-kits` + `erk.kits`
  - Remove `dot-agent.toml` requirement, use `kits.toml` for project detection
  - Fix `dev_mode` config to use `[tool.erk]` instead of deprecated `[tool.dot-agent]`
- Consolidate PR submission into unified two-layer architecture (core + Graphite)

### Fixed

- Fix detect no-work-events failure mode in auto-restack command
- Fix OSError "argument list too long" by passing prompt via stdin instead of command line
- Fix PR summary generation by passing `PR_NUMBER` through workflow environment
- Fix `erk pr check` step numbering in plan-implement command
- Fix `gt quick-submit` hanging by adding `--no-edit` and `--no-interactive` flags
- Fix GitHub GraphQL array and object variable passing in gh CLI commands

## [0.2.2] - 2025-12-11

### Added

- Release notes system with version change detection and `erk info release-notes` command
- Sort plans by recent branch activity with `--sort` flag in `erk plan list`

### Changed

- Improved `erk doctor` with GitHub workflow permission checks
- Eliminated dot-agent CLI, consolidated all commands into erk
