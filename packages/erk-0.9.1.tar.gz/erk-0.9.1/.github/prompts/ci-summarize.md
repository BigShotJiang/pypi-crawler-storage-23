Summarize this CI job failure log concisely in 2-5 bullet points.

Focus on:

1. What specific check/test failed (file names, test names)
2. The error message or root cause
3. Which files are affected

Rules:

- One line per bullet point
- Use backticks for file paths and commands
- Do NOT suggest fixes
- Do NOT include timestamps, run IDs, or GitHub URLs

## Job: {{ JOB_NAME }}

## Log output:

{{ LOG_CONTENT }}
