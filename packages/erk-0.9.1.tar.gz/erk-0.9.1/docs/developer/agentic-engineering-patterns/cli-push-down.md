# CLI Push Down Pattern

This pattern is documented in the `cli-push-down` skill.

Load it with: `$cli-push-down`

See `.claude/skills/cli-push-down/SKILL.md` for the full pattern documentation including decision rules, implementation checklist, case studies, and anti-patterns.
