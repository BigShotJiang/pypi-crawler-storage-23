---
title: CLI Commands Documentation
read_when:
  - "looking for CLI command reference"
  - "understanding specific erk commands"
last_audited: "2026-02-17 00:00 PT"
audit_result: clean
---

# CLI Commands Documentation

Reference documentation for specific erk CLI commands.

## Documents in This Category

### erk pr reconcile-with-remote

**File:** [pr-reconcile-with-remote.md](pr-reconcile-with-remote.md)

Reconciles a diverged local branch with its remote tracking branch using Claude.

## Related Topics

- [CLI Output Styling](../output-styling.md) - Output formatting conventions
- [Exec Command Patterns](../exec-command-patterns.md) - Patterns for exec scripts
