<!-- AUTO-GENERATED FILE - DO NOT EDIT DIRECTLY -->
<!-- Edit source frontmatter, then run 'erk docs sync' to regenerate. -->

# Erk Documentation

- **[branch-cleanup.md](branch-cleanup.md)** — cleaning up branches, removing dormant worktrees, managing branch lifecycle
- **[branch-naming.md](branch-naming.md)** — creating or modifying branch name generation, extracting issue or objective numbers from branch names, working with generate_planned_pr_branch_name(), or extract functions
- **[codespace-machine-types.md](codespace-machine-types.md)** — creating or configuring codespaces, choosing a machine type for codespace setup, debugging codespace creation failures
- **[codespace-remote-execution.md](codespace-remote-execution.md)** — modifying the codespace environment bootstrap sequence, debugging why a remote erk command fails before reaching the actual command, deciding whether a new remote command needs build_codespace_ssh_command
- **[dispatch-ref-config.md](dispatch-ref-config.md)** — configuring which branch workflow_dispatch targets, working with .erk/config.toml dispatch settings, debugging workflow dispatch targeting the wrong branch
- **[four-path-cleanup.md](four-path-cleanup.md)** — modifying land_cmd.py cleanup logic, adding a new cleanup path for branch deletion, debugging branch deletion failures after landing
- **[graphite-branch-setup.md](graphite-branch-setup.md)** — submitting a PR with Graphite, encountering no_parent error, setting up branch tracking for gt
- **[graphite-divergence-detection.md](graphite-divergence-detection.md)** — debugging remote divergence errors during erk pr submit, understanding the Graphite-first submit flow's pre-checks, resolving 'branch is behind remote' errors, using --force flag with erk pr submit
- **[graphite-stack-troubleshooting.md](graphite-stack-troubleshooting.md)** — debugging Graphite stack operation failures, recovering from gt sync or gt submit errors, fixing stack ordering or parent tracking issues
- **[issue-pr-linkage-storage.md](issue-pr-linkage-storage.md)** — understanding how plans link to PRs, debugging why a PR isn't linked to its issue, working with .erk/impl-context/plan-ref.json or .erk/impl-context/ref.json, creating PRs that close issues
- **[placeholder-branches.md](placeholder-branches.md)** — working with worktree pool slots or slot commands, understanding why placeholder branches bypass BranchManager, debugging slot cleanup during erk land
- **[pr-address-workflows.md](pr-address-workflows.md)** — addressing PR review comments, choosing between local and remote PR addressing, understanding erk launch pr-address, understanding /erk:pr-address command
- **[pr-commands.md](pr-commands.md)** — generating or modifying PR body footers, debugging `erk pr check` footer validation failures
- **[pr-feedback-classifier-schema.md](pr-feedback-classifier-schema.md)** — working with PR feedback classification output, debugging classifier-to-dash alignment issues, understanding informational_count vs actionable_threads
- **[remote-workflow-template.md](remote-workflow-template.md)** — creating a new remote workflow command, triggering GitHub Actions from CLI, building commands like erk launch pr-address
- **[slot-pool-architecture.md](slot-pool-architecture.md)** — understanding slot pool design, implementing slot-related features, debugging slot assignment issues
- **[workspace-activation.md](workspace-activation.md)** — modifying worktree activation scripts, debugging stale package versions in worktrees, understanding how workspace packages are refreshed, changing activation script generation
