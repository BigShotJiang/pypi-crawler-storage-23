######
images
######

``images`` is a package in the `LSST Science Pipelines <https://pipelines.lsst.io>`_.

.. Add a brief (few sentence) description of what this package provides.
