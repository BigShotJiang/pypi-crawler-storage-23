# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
from setuptools import setup, find_packages
package_name = 'sapiens_attention'
version = '1.0.8'
setup(
    name=package_name,
    version=version,
    author='SAPIENS TECHNOLOGY',
    packages=find_packages(),
    install_requires=['langdetect', 'yake'],
    url='https://github.com/sapiens-technology/SapiensAttention',
    license='Proprietary Software'
)
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
