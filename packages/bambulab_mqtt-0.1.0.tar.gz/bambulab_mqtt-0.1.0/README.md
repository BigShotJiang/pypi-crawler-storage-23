# Bambulab MQTT python library
A library for bambulab printers with mqtt
