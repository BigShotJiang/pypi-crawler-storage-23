latest_status = None

def update_status(data):
    global latest_status
    latest_status = data
