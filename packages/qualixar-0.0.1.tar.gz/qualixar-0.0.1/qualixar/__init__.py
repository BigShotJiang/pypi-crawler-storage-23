# Qualixar — The Complete Agent Development Platform
# Copyright (c) 2026 Varun Pratap Bhardwaj. All rights reserved.
# Licensed under AGPL-3.0-or-later. See LICENSE.
__version__ = "0.0.1"
__author__ = "Varun Pratap Bhardwaj"
