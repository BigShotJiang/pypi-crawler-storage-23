from .typing import TypedDict


class AppSlimDict(TypedDict):
    pass


class AppDetailedDict(AppSlimDict):
    pass
