from karrio.server.settings.base import *


KARRIO_URLS += ["karrio.server.orders.urls"]
INSTALLED_APPS += ["karrio.server.orders"]
