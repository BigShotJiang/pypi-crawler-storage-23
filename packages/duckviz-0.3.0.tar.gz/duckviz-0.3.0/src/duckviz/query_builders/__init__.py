from .query_builder import DuckDBQueryBuilder

PROVIDERS = {
    'duckdb' : DuckDBQueryBuilder()
}

def get_query_builder(name : str):
    p = PROVIDERS.get(name)
    if p is None:
        raise NotImplementedError(f'{name} not implemented or misspelled.')
    
    return p