import smtplib
from email.message import EmailMessage
import plotly.graph_objects as go


def send_dashboard_email(
    fig: go.Figure,
    sender_email: str,
    recipient_email: str | list[str],
    subject: str,
    body: str,
    app_password: str,
    smtp_host: str,
    renderer,
    smtp_port: int = 465,
):
    """
    Render dashboard using EmailDashboardRenderer
    and send as PNG attachment (no distortion).
    """

    img_bytes = renderer.render(fig)

    if isinstance(recipient_email, str):
        recipient_email = [recipient_email]

    msg = EmailMessage()
    msg["From"] = sender_email
    msg["To"] = ", ".join(recipient_email)
    msg["Subject"] = subject
    msg.set_content(body)

    # Attach PNG
    msg.add_attachment(
        img_bytes,
        maintype="image",
        subtype="png",
        filename="dashboard.png",
    )

    with smtplib.SMTP_SSL(smtp_host, smtp_port) as smtp:
        smtp.login(sender_email, app_password)
        smtp.send_message(msg)

