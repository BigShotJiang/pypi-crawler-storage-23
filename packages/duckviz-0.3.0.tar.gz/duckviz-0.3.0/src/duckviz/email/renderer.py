class EmailDashboardRenderer:
    """
    Preserve figure layout.
    If width/height are not defined, infer sensible defaults.
    """

    def __init__(self, scale: int = 2, fallback_width: int = 1200):
        self.scale = scale
        self.fallback_width = fallback_width

    def render(self, fig):

        width = fig.layout.width
        height = fig.layout.height

        # If width/height not set, compute proportional height
        if width is None or height is None:
            width = self.fallback_width

            # Estimate height based on subplot rows
            rows = getattr(fig.layout.grid, "rows", None)

            if rows:
                height = rows * 350 + 200
            else:
                height = 900  # safe default

            fig.update_layout(
                autosize=False,
                width=width,
                height=height,
                showlegend = False
            )

        return fig.to_image(
            format="png",
            width=width,
            height=height,
            scale=self.scale,
        )
