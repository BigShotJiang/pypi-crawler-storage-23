import pandas as pd

class PandasDatasource:
    """
    Wraps an existing pandas DataFrame.
    """

    def __init__(self, df: pd.DataFrame):
        self._df = df

    def get_data(self) -> pd.DataFrame:
        return self._df.copy()
