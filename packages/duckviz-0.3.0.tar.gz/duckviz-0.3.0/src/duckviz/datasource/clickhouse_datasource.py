import pandas as pd
from clickhouse_connect import get_client

class ClickHouseDatasource:
    """
    ClickHouse datasource.
    """

    def __init__(self, host: str, database: str, query: str,
                 username: str = "default", password: str = ""):
        self.host = host
        self.database = database
        self.query = query
        self.username = username
        self.password = password

    def get_data(self) -> pd.DataFrame:
        client = get_client(
            host=self.host,
            username=self.username,
            password=self.password,
            database=self.database
        )

        result = client.query_df(self.query)
        return result
