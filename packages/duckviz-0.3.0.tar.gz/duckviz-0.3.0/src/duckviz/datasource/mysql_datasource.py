import pandas as pd
from sqlalchemy import create_engine

class MySQLDatasource:
    """
    MySQL datasource.
    Requires connection string and SQL query.
    """

    def __init__(self, connection_string: str, query: str):
        self.connection_string = connection_string
        self.query = query

    def get_data(self) -> pd.DataFrame:
        engine = create_engine(self.connection_string)
        with engine.connect() as conn:
            df = pd.read_sql(self.query, conn)
        return df
