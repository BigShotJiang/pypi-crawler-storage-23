from typing import Protocol, List, Optional, Dict, Union

class QueryBuilderProtocol(Protocol):
    def build(
        self,
        x: Optional[str] = None,
        y: Optional[Union[str, List[str]]] = None,
        agg: Optional[Union[str, List[str]]] = "sum",
        where: Optional[str] = None,
        group: bool = True,
    ) -> Dict: ...