from typing import Protocol
import pandas as pd


class DatasetProtocol(Protocol):
    """
    All datasource implementations must return a pandas DataFrame.
    """

    def get_data(self) -> pd.DataFrame:
        """
        Return a pandas DataFrame containing the dataset.
        """
        ...
