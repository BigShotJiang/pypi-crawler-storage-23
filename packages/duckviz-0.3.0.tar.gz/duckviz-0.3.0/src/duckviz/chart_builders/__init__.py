from .altair import AltairChartBuilder
from .matplotlib import MatplotlibChartBuilder
from .plotly import PlotlyChartBuilder
from .seaborn import SeabornChartBuilder

PROVIDERS = {
    'altair' : AltairChartBuilder(),
    'matplotlib' : MatplotlibChartBuilder(),
    'plotly' : PlotlyChartBuilder(),
    'seaborn' : SeabornChartBuilder()
}

def get_chart_builder(name):
    p = PROVIDERS.get(name)

    if p is None:
        raise NotImplementedError(f'{name} is not yet implemented or does not exist.')
    
    return p