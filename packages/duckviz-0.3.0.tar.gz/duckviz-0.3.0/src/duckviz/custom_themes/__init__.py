from .saas import saas_theme
from .executive_light import executive_light
from .finance_pro import finance_pro
from .mono_clean import mono_clean
from .saas_dark import saas_dark
from .startup import startup_vibrant
from .email_clean import email_clean
from .email_clean_dark import email_clean_dark

from ..themes import ThemeManager

tm = ThemeManager()

tm.register(saas_theme)
tm.register(saas_dark)
tm.register(executive_light)
tm.register(finance_pro)
tm.register(mono_clean)
tm.register(startup_vibrant)
tm.register(email_clean)
tm.register(email_clean_dark)