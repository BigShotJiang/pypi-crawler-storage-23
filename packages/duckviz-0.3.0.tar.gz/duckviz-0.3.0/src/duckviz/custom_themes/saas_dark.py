from ..themes.specs import *

saas_dark = ThemeSpec(
    name="custom_saas_dark",

    palette=PaletteSpec(
        style="vibrant",
        colors=[
            "#3B82F6",
            "#22C55E",
            "#F97316",
            "#EF4444",
            "#A855F7",
            "#06B6D4",
        ],
    ),

    typography=TypographySpec(
        family="Inter, system-ui, -apple-system, Segoe UI, Roboto, sans-serif",
        size=14,
        title_size=22,
        tick_size=12,
        color="#E5E7EB",
    ),

    surface=SurfaceSpec(
        mode="dark",
        paper_bg="#0B1220",
        plot_bg="#111B2E",
        card_border="#1E293B",
    ),

    axes=AxesSpec(
        style="modern",
        grid=True,
        grid_color="#22304A",
        line_color="#22304A",
        tick_color="#94A3B8",
        showspikes=True,
    ),

    legend=LegendSpec(
        style="compact_bottom",
        font_size=12,
    ),

    traces=TraceSpec(
        bar=BarSpec(opacity=0.95),
        line=LineSpec(width=3),
        pie=PieSpec(donut_hole=0.45),
        kpi=KpiSpec(number_size=48, delta_size=18, inc_color="#22C55E", dec_color="#EF4444"),
    ),

    layout_density="comfortable",
    cards=True,
)
