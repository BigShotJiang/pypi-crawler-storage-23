from ..themes.specs import *

email_clean = ThemeSpec(
    name="email_clean",

    # -------------------------
    # Palette
    # -------------------------
    palette=PaletteSpec(
        colors=[
            "#2563EB",  # blue
            "#059669",  # green
            "#F59E0B",  # amber
            "#DC2626",  # red
            "#7C3AED",  # violet
        ],
    ),

    # -------------------------
    # Typography (larger for PNG clarity)
    # -------------------------
    typography=TypographySpec(
        family="Inter, Arial, sans-serif",
        size=16,
        title_size=26,
        tick_size=14,
        color="#111827",
    ),

    # -------------------------
    # Surface
    # -------------------------
    surface=SurfaceSpec(
        mode="light",
        paper_bg="#FFFFFF",
        plot_bg="#FFFFFF",
        card_border="#FFFFFF",  # no visible border
    ),

    # -------------------------
    # Axes
    # -------------------------
    axes=AxesSpec(
        style="modern",
        grid=True,
        grid_color="#E5E7EB",
        line_color="#D1D5DB",
        tick_color="#6B7280",
        showspikes=False,  # spikes useless in static image
    ),

    # -------------------------
    # Legend (DISABLED)
    # -------------------------
    legend=LegendSpec(
        style="none",
    ),

    # -------------------------
    # Trace Defaults (thicker for image)
    # -------------------------
    traces=TraceSpec(
        bar=BarSpec(opacity=0.95, remove_marker_line=True),
        line=LineSpec(width=3.5, marker_size=6, mode="lines+markers"),
        pie=PieSpec(donut_hole=0.45, textinfo="percent+label"),
        kpi=KpiSpec(number_size=56, delta_size=20),
    ),

    layout_density="comfortable",

    cards=False,  # cards unnecessary in email image
)
