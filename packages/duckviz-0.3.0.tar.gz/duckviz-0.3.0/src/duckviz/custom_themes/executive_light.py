from ..themes.specs import *

executive_light = ThemeSpec(
    name="executive_light",

    palette=PaletteSpec(
        colors=[
            "#1F2937",
            "#374151",
            "#6B7280",
            "#9CA3AF",
        ],
    ),

    typography=TypographySpec(
        family="Georgia, serif",
        size=15,
        title_size=24,
        tick_size=13,
    ),

    surface=SurfaceSpec(
        mode="light",
        paper_bg="#FFFFFF",
        plot_bg="#FFFFFF",
        card_border="#D1D5DB",
    ),

    axes=AxesSpec(
        style="minimal",
        grid=True,
        grid_color="#F3F4F6",
    ),

    legend=LegendSpec(
        style="top",
        font_size=13,
    ),

    traces=TraceSpec(
        bar=BarSpec(opacity=0.85),
        line=LineSpec(width=2),
        pie=PieSpec(donut_hole=0.4),
        kpi=KpiSpec(number_size=50, delta_size=18),
    ),

    layout_density="comfortable",
    cards=True,
)

