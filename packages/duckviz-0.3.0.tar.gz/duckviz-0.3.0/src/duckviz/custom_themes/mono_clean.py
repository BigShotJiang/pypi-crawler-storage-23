from ..themes.specs import *

mono_clean = ThemeSpec(
    name="mono_clean",

    palette=PaletteSpec(
        colors=["#111827"],
    ),

    typography=TypographySpec(
        family="Helvetica Neue, Arial, sans-serif",
        size=14,
        title_size=22,
    ),

    surface=SurfaceSpec(
        mode="light",
        paper_bg="#FFFFFF",
        plot_bg="#FFFFFF",
        card_border="#F3F4F6",
    ),

    axes=AxesSpec(
        style="minimal",
        grid=True,
        grid_color="#F3F4F6",
    ),

    legend=LegendSpec(
        style="none",
    ),

    traces=TraceSpec(
        bar=BarSpec(opacity=0.85),
        line=LineSpec(width=2),
        pie=PieSpec(donut_hole=0.6),
        kpi=KpiSpec(number_size=44, delta_size=16),
    ),

    layout_density="compact",
    cards=False,
)
