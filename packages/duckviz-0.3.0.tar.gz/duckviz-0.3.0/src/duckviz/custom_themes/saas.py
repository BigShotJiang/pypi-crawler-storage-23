
from ..themes.specs import *
# Initialize Theme Manager

# Define your brand theme
saas_theme = ThemeSpec(
    name="custom_saas",

    # -------------------------
    # Palette
    # -------------------------
    palette=PaletteSpec(
        style="brand",
        colors=[
            "#1D4ED8",  # primary blue
            "#059669",  # green
            "#F59E0B",  # amber
            "#DC2626",  # red
            "#7C3AED",  # violet
            "#0EA5E9",  # sky
        ],
    ),

    # -------------------------
    # Typography
    # -------------------------
    typography=TypographySpec(
        family="Inter, system-ui, -apple-system, Segoe UI, Roboto, sans-serif",
        size=14,
        title_size=22,
        tick_size=12,
    ),

    # -------------------------
    # Surface / Background
    # -------------------------
    surface=SurfaceSpec(
        mode="light",
        paper_bg="#F3F6FA",  # subtle tinted app background
        plot_bg="#FFFFFF",
        card_border="#E2E8F0",
    ),

    # -------------------------
    # Axes Styling
    # -------------------------
    axes=AxesSpec(
        style="modern",
        grid=True,
        grid_color="#E2E8F0",
        line_color="#CBD5E1",
        tick_color="#94A3B8",
        showspikes=True,
    ),

    # -------------------------
    # Legend Styling
    # -------------------------
    legend=LegendSpec(
        style="inside_top_right",
        font_size=12,
    ),

    # -------------------------
    # Trace Defaults
    # -------------------------
    traces=TraceSpec(
        bar=BarSpec(opacity=0.92, remove_marker_line=True),
        line=LineSpec(width=2.5, marker_size=5, mode="lines+markers"),
        pie=PieSpec(donut_hole=0.5, textinfo="percent+label"),
        kpi=KpiSpec(number_size=48, delta_size=18),
    ),

    # -------------------------
    # Layout Density
    # -------------------------
    layout_density="comfortable",

    # Enable card-style default
    cards=True,
)
