from ..themes.specs import *

email_clean_dark = ThemeSpec(
    name="email_clean_dark",

    # -------------------------
    # Palette (brightened for dark)
    # -------------------------
    palette=PaletteSpec(
        colors=[
            "#3B82F6",  # bright blue
            "#22C55E",  # green
            "#F97316",  # orange
            "#EF4444",  # red
            "#A855F7",  # violet
        ],
    ),

    # -------------------------
    # Typography (larger for PNG)
    # -------------------------
    typography=TypographySpec(
        family="Inter, Arial, sans-serif",
        size=16,
        title_size=26,
        tick_size=14,
        color="#F3F4F6",  # light gray text
    ),

    # -------------------------
    # Surface
    # -------------------------
    surface=SurfaceSpec(
        mode="dark",
        paper_bg="#111827",   # softer than pure black
        plot_bg="#1F2937",    # slightly lighter panel
        card_border="#111827",
    ),

    # -------------------------
    # Axes
    # -------------------------
    axes=AxesSpec(
        style="modern",
        grid=True,
        grid_color="#374151",
        line_color="#374151",
        tick_color="#9CA3AF",
        showspikes=False,
    ),

    # -------------------------
    # Legend (DISABLED)
    # -------------------------
    legend=LegendSpec(
        style="none",
    ),

    # -------------------------
    # Trace Defaults
    # -------------------------
    traces=TraceSpec(
        bar=BarSpec(opacity=0.95, remove_marker_line=True),
        line=LineSpec(width=3.5, marker_size=6, mode="lines+markers"),
        pie=PieSpec(donut_hole=0.45, textinfo="percent+label"),
        kpi=KpiSpec(
            number_size=56,
            delta_size=20,
            inc_color="#22C55E",
            dec_color="#EF4444",
        ),
    ),

    layout_density="comfortable",

    cards=False,
)
