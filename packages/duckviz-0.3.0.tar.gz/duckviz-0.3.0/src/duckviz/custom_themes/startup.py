from ..themes.specs import *

startup_vibrant = ThemeSpec(
    name="startup_vibrant",

    palette=PaletteSpec(
        style="vibrant",
    ),

    typography=TypographySpec(
        family="Inter, sans-serif",
        size=14,
        title_size=23,
    ),

    surface=SurfaceSpec(
        mode="light",
        paper_bg="#F8FAFC",
        plot_bg="#FFFFFF",
        card_border="#E5E7EB",
    ),

    axes=AxesSpec(
        style="modern",
        grid=True,
        showspikes=False,
    ),

    legend=LegendSpec(
        style="compact_bottom",
    ),

    traces=TraceSpec(
        bar=BarSpec(opacity=0.95),
        line=LineSpec(width=3.5),
        pie=PieSpec(donut_hole=0.5),
        kpi=KpiSpec(number_size=52, delta_size=20),
    ),

    layout_density="comfortable",
    cards=True,
)
