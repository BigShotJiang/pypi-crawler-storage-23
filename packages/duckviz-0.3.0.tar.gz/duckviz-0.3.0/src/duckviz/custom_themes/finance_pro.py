from ..themes.specs import *

finance_pro = ThemeSpec(
    name="finance_pro",

    palette=PaletteSpec(
        colors=[
            "#2563EB",  # blue
            "#16A34A",  # green
            "#DC2626",  # red
            "#F59E0B",  # amber
            "#7C3AED",  # violet
        ],
    ),

    typography=TypographySpec(
        family="Roboto Mono, monospace",
        size=13,
        title_size=20,
        tick_size=12,
    ),

    surface=SurfaceSpec(
        mode="dark",
        paper_bg="#0F172A",
        plot_bg="#111827",
        card_border="#1F2937",
    ),

    axes=AxesSpec(
        style="modern",
        grid=True,
        grid_color="#1F2937",
        line_color="#1F2937",
        tick_color="#64748B",
        showspikes=True,
    ),

    legend=LegendSpec(
        style="inside_top_right",
    ),

    traces=TraceSpec(
        bar=BarSpec(opacity=0.9),
        line=LineSpec(width=2.5),
        pie=PieSpec(donut_hole=0.3),
        kpi=KpiSpec(number_size=46, delta_size=16),
    ),

    layout_density="compact",
    cards=True,
)
