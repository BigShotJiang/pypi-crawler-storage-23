import plotly.io as pio
import plotly.graph_objects as go


def register_duckviz_pro_theme():

    pro_template = go.layout.Template(

        layout=dict(

            # App background
            paper_bgcolor="#F5F7FA",

            # Chart panel background
            plot_bgcolor="#FFFFFF",

            # Typography
            font=dict(
                family="Inter, -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif",
                size=14,
                color="#111827"
            ),

            title=dict(
                x=0.02,
                xanchor="left",
                font=dict(size=20, color="#111827")
            ),

            # Axes
            xaxis=dict(
                showgrid=True,
                gridcolor="#E5E7EB",
                zeroline=False,
                linecolor="#E5E7EB",
                ticks="outside",
                tickcolor="#D1D5DB",
                showline=True,
            ),

            yaxis=dict(
                showgrid=True,
                gridcolor="#E5E7EB",
                zeroline=False,
                linecolor="#E5E7EB",
                ticks="outside",
                tickcolor="#D1D5DB",
                showline=True,
            ),

            # Legend
            legend=dict(
                bgcolor="rgba(0,0,0,0)",
                borderwidth=0,
                orientation="h",
                yanchor="bottom",
                y=-0.2,
                xanchor="left",
                x=0
            ),

            colorway=[
                "#2563EB",
                "#059669",
                "#D97706",
                "#DC2626",
                "#7C3AED",
                "#0891B2",
            ],

            margin=dict(
                t=70,
                l=50,
                r=40,
                b=60
            ),
        ),

        # Default trace styling
        data=dict(

            bar=[
                go.Bar(
                    marker=dict(line=dict(width=0)),
                    opacity=0.9
                )
            ],

            scatter=[
                go.Scatter(
                    line=dict(width=3),
                    marker=dict(size=6)
                )
            ],

            pie=[
                go.Pie(
                    hole=0.45,
                    textinfo="percent+label"
                )
            ],

            indicator=[
                go.Indicator(
                    number=dict(font=dict(size=42)),
                    delta=dict(font=dict(size=16))
                )
            ]
        )
    )

    pio.templates["duckviz_pro"] = pro_template
