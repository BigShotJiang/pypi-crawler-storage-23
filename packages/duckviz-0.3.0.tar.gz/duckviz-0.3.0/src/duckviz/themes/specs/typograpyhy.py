from dataclasses import dataclass
from typing import Optional

@dataclass(frozen=True)
class TypographySpec:
    family: str = "Inter, system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif"
    size: int = 14
    color: str = "#111827"
    title_size: int = 20
    subtitle_size: int = 14

    # Optional: axis tick label size override
    tick_size: Optional[int] = 12
