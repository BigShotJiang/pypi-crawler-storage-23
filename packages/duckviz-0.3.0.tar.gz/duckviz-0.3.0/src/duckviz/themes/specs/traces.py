from dataclasses import dataclass, field

@dataclass(frozen=True)
class BarSpec:
    opacity: float = 0.9
    remove_marker_line: bool = True
    marker_line_width: int = 0


@dataclass(frozen=True)
class LineSpec:
    width: int = 3
    marker_size: int = 6
    mode: str = "lines"  # can be "lines+markers"


@dataclass(frozen=True)
class PieSpec:
    donut_hole: float = 0.45
    textinfo: str = "percent+label"
    pull: float = 0.0


@dataclass(frozen=True)
class KpiSpec:
    number_size: int = 44
    delta_size: int = 16
    inc_color: str = "#059669"
    dec_color: str = "#DC2626"


@dataclass(frozen=True)
class TraceSpec:
    bar: BarSpec = field(default_factory=BarSpec)
    line: LineSpec = field(default_factory=LineSpec)
    pie: PieSpec = field(default_factory=PieSpec)
    kpi: KpiSpec = field(default_factory=KpiSpec)