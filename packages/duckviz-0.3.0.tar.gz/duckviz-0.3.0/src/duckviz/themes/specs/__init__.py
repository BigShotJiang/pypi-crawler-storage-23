from .palette import PaletteSpec
from .typograpyhy import TypographySpec
from .surface import SurfaceSpec
from .axis import AxesSpec
from .legend import LegendSpec
from .traces import TraceSpec, BarSpec, LineSpec, PieSpec, KpiSpec

from .theme import ThemeSpec