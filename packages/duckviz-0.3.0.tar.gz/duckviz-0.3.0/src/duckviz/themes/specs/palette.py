from typing import Literal, Optional, List, Dict
from dataclasses import dataclass

PaletteStyle = Literal["modern", "muted", "minimal", "brand", "finance", "vibrant"]


@dataclass(frozen=True)
class PaletteSpec:
    style: PaletteStyle = "modern"
    colors: Optional[List[str]] = None  # if provided, overrides style palette
    sequential: Optional[List[str]] = None
    diverging: Optional[List[str]] = None

    def resolve_colorway(self) -> List[str]:
        if self.colors:
            return self.colors

        presets: Dict[str, List[str]] = {
            "modern": ["#2563EB", "#059669", "#D97706", "#DC2626", "#7C3AED", "#0891B2", "#4B5563"],
            "muted": ["#4F46E5", "#10B981", "#F59E0B", "#EF4444", "#6366F1", "#6B7280", "#0EA5E9"],
            "minimal": ["#111827", "#374151", "#6B7280", "#9CA3AF"],
            "finance": ["#0F766E", "#2563EB", "#16A34A", "#F59E0B", "#DC2626", "#7C3AED"],
            "vibrant": ["#3B82F6", "#22C55E", "#F97316", "#EF4444", "#A855F7", "#06B6D4", "#84CC16"],
            "brand": ["#0EA5E9", "#22C55E", "#F97316", "#EF4444", "#A855F7", "#14B8A6"],
        }
        return presets[self.style]