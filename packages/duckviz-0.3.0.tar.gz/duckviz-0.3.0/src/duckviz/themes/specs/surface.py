from typing import Literal, Dict, Any

from dataclasses import dataclass
from .typograpyhy import TypographySpec

SurfaceMode = Literal["light", "dark"]


@dataclass(frozen=True)
class SurfaceSpec:
    mode: SurfaceMode = "light"
    paper_bg: str = "#F5F7FA"     # app background
    plot_bg: str = "#FFFFFF"      # chart panel background
    card_bg: str = "#FFFFFF"      # card background
    card_border: str = "#E5E7EB"  # subtle border
    card_radius: int = 14         # used for "illusory" rounded corners (Plotly doesn't round shapes)
    # Dark-mode defaults (used if mode="dark" and values not overridden)
    paper_bg_dark: str = "#0B1220"
    plot_bg_dark: str = "#111B2E"
    font_color_dark: str = "#E5E7EB"
    grid_dark: str = "#22304A"
    axis_line_dark: str = "#22304A"

    def resolved(self, typography: TypographySpec) -> Dict[str, Any]:
        if self.mode == "dark":
            return {
                "paper_bgcolor": self.paper_bg_dark if self.paper_bg == "#F5F7FA" else self.paper_bg,
                "plot_bgcolor": self.plot_bg_dark if self.plot_bg == "#FFFFFF" else self.plot_bg,
                "font": dict(
                    family=typography.family,
                    size=typography.size,
                    color=self.font_color_dark,
                ),
            }
        return {
        "paper_bgcolor": self.paper_bg,
        "plot_bgcolor": self.plot_bg,
        "font": dict(
            family=typography.family,
            size=typography.size,
            color=typography.color,
        ),
    }