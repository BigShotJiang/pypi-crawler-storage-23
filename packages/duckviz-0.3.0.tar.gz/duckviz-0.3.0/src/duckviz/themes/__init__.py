from .pro_theme import register_duckviz_pro_theme
from .manager import ThemeManager