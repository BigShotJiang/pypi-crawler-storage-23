class ClientAuthenticationError(Exception):
    pass


class PipelineRequestError(Exception):
    pass
