[![CI](https://github.com/Defend-AI-Tech-Inc/agent-discover-scanner/actions/workflows/ci.yml/badge.svg)](https://github.com/Defend-AI-Tech-Inc/agent-discover-scanner/actions/workflows/ci.yml)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Tests](https://img.shields.io/badge/tests-33%20passing-brightgreen.svg)](tests/)
