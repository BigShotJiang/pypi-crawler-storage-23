# This file is auto-generated during build from root pyproject.toml
# Do not edit manually

__version__ = "2.0.0rc1"
__author__ = "MariaDB Corporation"
__version_info__ = (2, 0, 0, 'rc1')
