use foyer::{Cache, CacheBuilder};
use pyo3::exceptions::{PyOverflowError, PyTypeError};
use pyo3::prelude::*;
use pyo3::types::{PyAny, PyBytes, PyInt, PyModule, PyString};

#[derive(Clone, Debug, Hash, PartialEq, Eq)]
enum PyCacheKey {
    Bytes(Vec<u8>),
    Str(String),
    Int(i128),
}

fn parse_key(key: &Bound<'_, PyAny>) -> PyResult<PyCacheKey> {
    if let Ok(bytes) = key.downcast::<PyBytes>() {
        return Ok(PyCacheKey::Bytes(bytes.as_bytes().to_vec()));
    }
    if let Ok(s) = key.downcast::<PyString>() {
        return Ok(PyCacheKey::Str(s.to_str()?.to_owned()));
    }
    if key.is_instance_of::<PyInt>() {
        return key
            .extract::<i128>()
            .map(PyCacheKey::Int)
            .map_err(|_| PyOverflowError::new_err("int key is out of supported i128 range"));
    }
    Err(PyTypeError::new_err("key must be bytes, str, or int"))
}

fn parse_value(value: &Bound<'_, PyAny>) -> PyResult<Vec<u8>> {
    value
        .downcast::<PyBytes>()
        .map(|bytes| bytes.as_bytes().to_vec())
        .map_err(|_| PyTypeError::new_err("value must be bytes"))
}

#[pyclass]
struct MemoryCache {
    inner: Cache<PyCacheKey, Vec<u8>>,
}

#[pymethods]
impl MemoryCache {
    #[new]
    fn new(capacity: usize) -> Self {
        Self {
            inner: CacheBuilder::new(capacity).build(),
        }
    }

    fn insert(&self, key: &Bound<'_, PyAny>, value: &Bound<'_, PyAny>) -> PyResult<()> {
        let key = parse_key(key)?;
        let value = parse_value(value)?;
        self.inner.insert(key, value);
        Ok(())
    }

    fn get<'py>(&self, py: Python<'py>, key: &Bound<'py, PyAny>) -> PyResult<Option<Py<PyBytes>>> {
        let key = parse_key(key)?;
        let value = self
            .inner
            .get(&key)
            .map(|entry| PyBytes::new(py, entry.value()).into());
        Ok(value)
    }

    fn remove<'py>(&self, py: Python<'py>, key: &Bound<'py, PyAny>) -> PyResult<Option<Py<PyBytes>>> {
        let key = parse_key(key)?;
        let value = self
            .inner
            .remove(&key)
            .map(|entry| PyBytes::new(py, entry.value()).into());
        Ok(value)
    }

    fn contains(&self, key: &Bound<'_, PyAny>) -> PyResult<bool> {
        let key = parse_key(key)?;
        Ok(self.inner.contains(&key))
    }

    fn clear(&self) {
        self.inner.clear();
    }

    fn __len__(&self) -> usize {
        self.inner.entries()
    }

    #[getter]
    fn capacity(&self) -> usize {
        self.inner.capacity()
    }

    #[getter]
    fn usage(&self) -> usize {
        self.inner.usage()
    }

    #[getter]
    fn entries(&self) -> usize {
        self.inner.entries()
    }
}

#[pymodule]
fn _foyer(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<MemoryCache>()?;
    m.add("__version__", env!("CARGO_PKG_VERSION"))?;
    Ok(())
}
