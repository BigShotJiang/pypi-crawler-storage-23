"""Python bindings for foyer."""

from ._foyer import MemoryCache, __version__

__all__ = ["MemoryCache", "__version__"]
