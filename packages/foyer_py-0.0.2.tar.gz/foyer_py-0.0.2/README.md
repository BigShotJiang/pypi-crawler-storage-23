# foyer-py

Python bindings for the Rust [`foyer`](https://github.com/foyer-rs/foyer) hybrid cache library.

`foyer-py` is published on PyPI and imported as `foyer`.

## Current status

- Sync in-memory cache bindings are available.
- Keys: `bytes`, `str`, `int`.
- Values: `bytes`.

## Quick start

```python
import foyer

cache = foyer.MemoryCache(16)
cache.insert("hello", b"world")

assert cache.get("hello") == b"world"
assert cache.contains("hello")
assert cache.entries == 1
```
