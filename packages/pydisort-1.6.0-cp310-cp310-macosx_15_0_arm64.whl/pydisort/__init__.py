import torch
from .pydisort import *

__version__ = "1.6.0"
