"""
Empirica TUI Dashboard - Terminal-based project monitoring
"""

from .dashboard import EmpiricaDashboard

__all__ = ['EmpiricaDashboard']
