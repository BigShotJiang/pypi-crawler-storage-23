#!/usr/bin/env python3
"""
Dashboard Command Handler - Launch TUI Dashboard
"""

import sys
from ..cli_utils import handle_cli_error


def handle_dashboard_command(args):
    """Handle dashboard command - launch TUI"""
    try:
        from empirica.tui.dashboard import run_dashboard

        # Check if textual is installed
        try:
            import textual
        except ImportError:
            print("❌ Error: textual library not installed")
            print("\nInstall with: pip install textual")
            sys.exit(1)

        # Launch dashboard with optional entity context
        entity_type = getattr(args, 'entity_type', 'project')
        entity_id = getattr(args, 'entity_id', None)
        run_dashboard(entity_type=entity_type, entity_id=entity_id)

    except KeyboardInterrupt:
        print("\n👋 Dashboard closed")
    except Exception as e:
        handle_cli_error(e, "Dashboard", getattr(args, 'verbose', False))
        sys.exit(1)
