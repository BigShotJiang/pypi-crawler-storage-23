"""A fake implementation of Vuforia Web Services for use with respx."""
