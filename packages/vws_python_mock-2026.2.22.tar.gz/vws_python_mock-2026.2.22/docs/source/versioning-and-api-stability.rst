Versioning, Support and API Stability
=====================================

This is a mock of Vuforia Web Services.
These is a moving target.
For this reason, `CalVer <https://calver.org/>`__ is used as a date at which the repository is last known to have been an accurate mock.

There is no guarantee of API stability at this point.
All backwards incompatible changes will be documented in the :doc:`changelog`.
