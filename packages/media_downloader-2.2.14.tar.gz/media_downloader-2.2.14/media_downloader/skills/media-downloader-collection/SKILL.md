---
name: media-downloader-collection
description: Media Downloader Tools
---

### Overview
Managed media collection.

### Tools
- `download_media`: Download a video or audio file from a URL.

### Usage
Use this skill to download media content to the local system.
