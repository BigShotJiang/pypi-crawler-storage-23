# pyfigma-types

[![Package - Version](https://img.shields.io/pypi/v/pyfigma-types)](https://pypi.python.org/pypi/pyfigma-types)
[![Package - Supported Python Versions](https://img.shields.io/pypi/pyversions/pyfigma-types)](https://codeberg.org/naiwaaa/pyfigma)
[![Package - License](https://img.shields.io/pypi/l/pyfigma-types)](https://codeberg.org/naiwaaa/pyfigma/src/branch/main/LICENSE)

Pydantic models, type definitions, and response schemas for the Figma REST API. Use
`pyfigma-types` to parse Figma responses, making it easy to build clients, tools, MCP
servers, or automation that interact with Figma programmatically.

## Installation

Install `pyfigma-types` using your preferred package manager:

### Using uv (recommended)

```bash
uv add pyfigma-types
```

### Using pip

```bash
pip install pyfigma-types
```

## Resources

- [Figma REST API Documentation](https://developers.figma.com/docs/rest-api/)
- [Figma OpenAPI specification and TypeScript types](https://github.com/figma/rest-api-spec)
