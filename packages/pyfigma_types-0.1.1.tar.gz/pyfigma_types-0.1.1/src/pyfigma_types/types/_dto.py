from __future__ import annotations

from typing import Literal

from pydantic import AwareDatetime

from .models._files import FileBranch, LinkAccess, Role
from .models._nodes import DocumentNode
from .models._properties import Component, ComponentSet, Style
from .models._user import User


class FigmaGetFileResponseDTO(BaseFigmaDTO):
    """Response for GET /v1/files/:key endpoint."""

    branches: list[FileBranch] | None = None
    """A list of branches for this file."""

    components: dict[str, Component] | None
    """A mapping from component IDs to component metadata."""

    component_sets: dict[str, ComponentSet] | None
    """A mapping from component set IDs to component set metadata."""

    document: DocumentNode | None
    """The root document node of this file."""

    editor_type: Literal["figma", "figjam"] | None
    """The type of editor associated with this file."""

    last_modified: AwareDatetime | None
    """The UTC ISO 8601 time at which the file was last modified."""

    link_access: LinkAccess | None
    """The share permission level of the file link."""

    main_file_key: str | None = None
    """The key of the main file for this file. If present, this file is a component or
    component set."""

    name: str | None
    """The name of the file as it appears in the editor."""

    role: Role | None
    """The role of the user making the API request in relation to the file."""

    schema_version: int | None
    """The version of the file schema that this file uses."""

    styles: dict[str, Style] | None
    """A mapping from style IDs to style metadata."""

    thumbnail_url: str | None
    """A URL to a thumbnail image of the file."""

    version: str | None
    """The version number of the file. This number is incremented when a file is modified
    and can be used to check if the file has changed between requests."""


class FigmaGetFileMetadataResponseDTO(BaseFigmaDTO):
    """Response for GET /v1/files/:key/meta endpoint."""

    creator: User | None
    """The user who created the file."""

    editor_type: Literal["figma", "figjam"] | None
    """The type of editor associated with this file."""

    folder_name: str | None
    """The name of the project containing the file."""

    last_touched_at: str | None
    """The UTC ISO 8601 time at which the file content was last modified."""

    last_touched_by: User | None
    """The user who last modified the file contents."""

    link_access: LinkAccess | None
    """Access policy for users who have the link to the file."""

    name: str | None
    """The name of the file."""

    role: Role | None
    """The role of the user making the API request in relation to the file."""

    thumbnail_url: str | None
    """A URL to a thumbnail image of the file."""

    url: str | None
    """The URL of the file."""

    version: str | None
    """The version number of the file. This number is incremented when a file is modified
    and can be used to check if the file has changed between requests."""
