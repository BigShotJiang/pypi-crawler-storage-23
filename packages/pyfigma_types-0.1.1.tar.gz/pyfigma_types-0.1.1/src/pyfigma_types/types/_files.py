from __future__ import annotations

from dataclasses import dataclass
from typing import Annotated, Literal

from pydantic import AwareDatetime  # noqa: TC002


LinkAccess = Annotated[
    Literal["view", "edit", "org_view", "org_edit", "inherit"],
    """Access policy for users who have the link to the resource.""",
]


Role = Annotated[
    Literal["owner", "editor", "viewer"],
    """The role of the user making the API request in relation to the resource.""",
]


@dataclass(frozen=True)
class FileBranch:
    key: str
    """The key of the branch."""

    name: str
    """The name of the branch."""

    thumbnail_url: str
    """A URL to a thumbnail image of the branch."""

    last_modified: AwareDatetime
    """The UTC ISO 8601 time at which the branch was last modified."""
