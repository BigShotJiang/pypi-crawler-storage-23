from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal

from ._properties import (  # noqa: TC001
    FlowStartingPoint,
    Measurement,
    PrototypeDevice,
    RGBAColor,
)
from ._traits import HasExportSettingsTrait, IsLayerTrait


SubcanvasNode = Any


@dataclass(frozen=True, kw_only=True)
class CanvasNode(IsLayerTrait, HasExportSettingsTrait):
    type: Literal["CANVAS"]
