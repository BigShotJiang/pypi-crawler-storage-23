from __future__ import annotations

import pydantic
from pydantic.alias_generators import to_camel


class BaseModel(pydantic.BaseModel):
    model_config = pydantic.ConfigDict(
        frozen=True,
        use_attribute_docstrings=True,
        validate_by_name=True,
        alias_generator=pydantic.AliasGenerator(validation_alias=to_camel),
    )
