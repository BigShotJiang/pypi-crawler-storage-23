from __future__ import annotations

from pyfigma_types._models import BaseModel


class GetFileResponse(BaseModel):
    """Response schema for the `GET /v1/files/:key` endpoint."""


class GetFileNodesResponse(BaseModel):
    """Response schema for the `GET /v1/files/:key/nodes` endpoint."""


class GetImageResponse(BaseModel):
    """Response schema for the `GET /v1/images/:key` endpoint."""


class GetImageFillsResponse(BaseModel):
    """Response schema for the `GET /v1/files/:key/images` endpoint."""


class GetFileMetadataResponse(BaseModel):
    """Response schema for the `GET /v1/files/:key/meta` endpoint."""
