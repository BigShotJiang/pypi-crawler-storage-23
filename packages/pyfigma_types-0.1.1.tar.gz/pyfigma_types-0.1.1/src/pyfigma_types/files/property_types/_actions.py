"""[Figma Property types - Action](https://developers.figma.com/docs/rest-api/file-property-types/#action-type)."""

from __future__ import annotations

from typing import Annotated, Literal

from pydantic import Field, HttpUrl

from pyfigma_types._models import BaseModel

from ._base import Navigation, Transition, VariableData, Vector


class BackAction(BaseModel):
    """An action that navigates to the previously viewed frame."""

    type: Literal["BACK"] = "BACK"


class CloseAction(BaseModel):
    """An action that closes the current topmost overlay (applicable only on overlays)."""

    type: Literal["CLOSE"] = "CLOSE"


class OpenURLAction(BaseModel):
    """An action that opens a URL."""

    type: Literal["URL"] = "URL"
    url: HttpUrl


class UpdateMediaRuntimeActionPlayPauseMute(BaseModel):
    type: Literal["UPDATE_MEDIA_RUNTIME"] = "UPDATE_MEDIA_RUNTIME"
    destination_id: str | None = None
    media_action: Literal[
        "PLAY",
        "PAUSE",
        "TOGGLE_PLAY_PAUSE",
        "MUTE",
        "UNMUTE",
        "TOGGLE_MUTE_UNMUTE",
    ]


class UpdateMediaRuntimeActionSkip(BaseModel):
    type: Literal["UPDATE_MEDIA_RUNTIME"] = "UPDATE_MEDIA_RUNTIME"
    destination_id: str | None = None
    media_action: Literal["SKIP_FORWARD", "SKIP_BACKWARD"]
    amount_to_skip: float


class UpdateMediaRuntimeActionSkipTo(BaseModel):
    type: Literal["UPDATE_MEDIA_RUNTIME"] = "UPDATE_MEDIA_RUNTIME"
    destination_id: str | None = None
    media_action: Literal["SKIP_TO"] = "SKIP_TO"
    new_timestamp: float


UpdateMediaRuntimeAction = Annotated[
    UpdateMediaRuntimeActionPlayPauseMute
    | UpdateMediaRuntimeActionSkip
    | UpdateMediaRuntimeActionSkipTo,
    Field(discriminator="media_action"),
    """
    An action that affects a video node in the Figma viewer. For example, to play, pause,
    or skip.
    """,
]


class SetVariableAction(BaseModel):
    """An action that sets a variable to a specific value."""

    type: Literal["SET_VARIABLE"] = "SET_VARIABLE"
    variable_id: str | None = None
    variable_value: VariableData | None = None


class SetVariableModeAction(BaseModel):
    """An action that sets a variable to a specific mode."""

    type: Literal["SET_VARIABLE_MODE"] = "SET_VARIABLE_MODE"
    variable_collection_id: str | None = None
    variable_mode_id: str | None = None


class ConditionalAction(BaseModel):
    """An action that checks if a condition is met before performing certain actions by using an if/else conditional statement."""  # noqa: E501

    type: Literal["CONDITIONAL"] = "CONDITIONAL"

    conditional_blocks: list[ConditionalBlock]


class ConditionalBlock(BaseModel):
    """Either the if or else conditional block.

    The if block contains a condition to check. If that condition is met then it will run
    those list of actions, else it will run the actions in the else block.
    """

    condition: VariableData | None = None
    actions: list[Action]


class NodeAction(BaseModel):
    """An action that navigates to a specific node in the prototype."""

    type: Literal["NODE"] = "NODE"

    destination_id: str | None = None
    navigation: Navigation
    transition: Transition | None = None

    preserve_scroll_position: bool | None = None
    """
    Whether the scroll offsets of any scrollable elements in the current screen or overlay
    are preserved when navigating to the destination. This is applicable only if the
    layout of both the current frame and its destination are the same.
    """

    overlay_relative_position: Vector | None = None
    """
    Applicable only when `navigation` is `"OVERLAY"` and the destination is a frame with
    `overlayPosition` equal to `"MANUAL"`. This value represents the offset by which the
    overlay is opened relative to this node.
    """

    reset_video_position: bool | None = None
    """
    When true, all videos within the destination frame will reset their memorized playback
    position to 00:00 before starting to play.
    """

    reset_scroll_position: bool | None = None
    """
    Whether the scroll offsets of any scrollable elements in the current screen or overlay
    reset when navigating to the destination. This is applicable only if the layout of
    both the current frame and its destination are the same.
    """

    reset_interactive_components: bool | None = None
    """
    Whether the state of any interactive components in the current screen or overlay reset
    when navigating to the destination. This is applicable if there are interactive
    components in the destination frame.
    """


Action = Annotated[
    BackAction
    | CloseAction
    | OpenURLAction
    | UpdateMediaRuntimeAction
    | SetVariableAction
    | SetVariableModeAction
    | ConditionalAction
    | NodeAction,
    Field(discriminator="type"),
    """
    An action that is performed when a trigger is activated.
    """,
]
