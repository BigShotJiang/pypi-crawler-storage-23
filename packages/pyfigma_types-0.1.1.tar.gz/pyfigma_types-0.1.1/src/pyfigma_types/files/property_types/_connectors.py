"""[Figma property types - Effect](https://developers.figma.com/docs/rest-api/file-property-types/#effect-type)."""

from __future__ import annotations

from typing import Annotated, Literal

from pyfigma_types._models import BaseModel

from ._base import Vector
from ._traits import CornerTrait, MinimalFillsTrait


class ConnectorEndpoint(BaseModel):
    """Stores canvas location for a connector start/end point."""

    endpoint_node_id: str
    """
    Node ID that this endpoint attaches to.
    """

    position: Vector | None = None
    """
    The position of the endpoint relative to the node.
    """

    magnet: Literal["AUTO", "TOP", "BOTTOM", "LEFT", "RIGHT", "CENTER"] | None = None
    """
    The magnet type.
    """


ConnectorLineType = Annotated[
    Literal["STRAIGHT", "ELBOWED", "CURVED"],
    """
    Connector line type.
    """,
]


class ConnectorTextBackground(CornerTrait, MinimalFillsTrait):
    pass
