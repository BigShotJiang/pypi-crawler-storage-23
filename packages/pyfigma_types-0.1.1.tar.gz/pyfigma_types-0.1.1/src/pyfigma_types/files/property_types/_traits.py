from __future__ import annotations

from typing import Annotated

from pydantic import Field

from pyfigma_types._models import BaseModel
from pyfigma_types.files.property_types._paints import Paint


class CornerTrait(BaseModel):
    corner_radius: float | None = None
    """
    Radius of each corner if a single radius is set for all corners.
    """

    corner_smoothing: Annotated[float | None, Field(ge=0.0, le=1.0)] = None
    """
    A value that lets you control how "smooth" the corners are. Ranges from 0 to 1.
    - 0 is the default and means that the corner is perfectly circular.
    - A value of 0.6 means the corner matches the iOS 7 "squircle" icon shape.
    - Other values produce various other curves.
    """

    rectangle_corner_radii: list[float] | None = None
    """
    Array of length 4 of the radius of each corner of the frame, starting in the top left
    and proceeding clockwise.
    Values are given in the order top-left, top-right, bottom-right, bottom-left.
    """


class MinimalFillsTrait(BaseModel):
    fills: list[Paint]
    """
    An array of fill paints applied to the node.
    """

    styles: dict[str, str] | None = None
    """
    A mapping of a StyleType to style ID of styles present on this node. The style ID can
    be used to look up more information about the style in the top-level styles field.
    """
