"""[Figma Property types](https://developers.figma.com/docs/rest-api/file-property-types)."""

from __future__ import annotations

from typing import Annotated, Literal

from pydantic import Field, HttpUrl

from pyfigma_types._models import BaseModel


class RGBA(BaseModel):
    """An RGBA color."""

    r: Annotated[float, Field(ge=0.0, le=1.0)]
    """
    Red channel value, between 0 and 1.
    """

    g: Annotated[float, Field(ge=0.0, le=1.0)]
    """
    Green channel value, between 0 and 1.
    """

    b: Annotated[float, Field(ge=0.0, le=1.0)]
    """
    Blue channel value, between 0 and 1.
    """

    a: Annotated[float, Field(ge=0.0, le=1.0)]
    """
    Alpha channel value, between 0 and 1.
    """


class RGB(BaseModel):
    """An RGB color."""

    r: Annotated[float, Field(ge=0.0, le=1.0)]
    """
    Red channel value, between 0 and 1.
    """

    g: Annotated[float, Field(ge=0.0, le=1.0)]
    """
    Green channel value, between 0 and 1.
    """

    b: Annotated[float, Field(ge=0.0, le=1.0)]
    """
    Blue channel value, between 0 and 1.
    """


class ExportSetting(BaseModel):
    """Format and size to export an asset at."""

    suffix: str
    """
    File suffix to append to all filenames.
    """

    format: Literal["JPG", "PNG", "SVG", "PDF"]
    """
    Image type.
    """

    constraint: Constraint
    """
    Constraint that determines sizing of exported asset.
    """


class Constraint(BaseModel):
    """Sizing constraint for exports."""

    type: Literal["SCALE", "WIDTH", "HEIGHT"]
    """
    Type of constraint to apply.

    - `SCALE`: Scale by `value`.
    - `WIDTH`: Scale proportionally and set width to `value`.
    - `HEIGHT`: Scale proportionally and set height to `value`.
    """

    value: float
    """
    See `type` property for effect of this field.
    """


class Rectangle(BaseModel):
    """A rectangle that expresses a bounding box in absolute coordinates."""

    x: float
    """
    X coordinate of top left corner of the rectangle.
    """

    y: float
    """
    Y coordinate of top left corner of the rectangle.
    """

    width: float
    """
    Width of the rectangle.
    """

    height: float
    """
    Height of the rectangle.
    """


class ArcData(BaseModel):
    """Information about the arc properties of an ellipse.

    0° is the x axis and increasing angles rotate clockwise.
    """

    starting_angle: float
    """
    Start of the sweep in radians.
    """

    ending_angle: float
    """
    End of the sweep in radians.
    """

    inner_radius: Annotated[float, Field(ge=0.0, le=1.0)]
    """
    Inner radius value between 0 and 1.
    """


BlendMode = Annotated[
    Literal[
        # Normal blends
        "PASS_THROUGH",  # only applicable to objects with children
        "NORMAL",
        # Darken
        "DARKEN",
        "MULTIPLY",
        "LINEAR_BURN",
        "COLOR_BURN",
        # Lighten
        "LIGHTEN",
        "SCREEN",
        "LINEAR_DODGE",
        "COLOR_DODGE",
        # Contrast
        "OVERLAY",
        "SOFT_LIGHT",
        "HARD_LIGHT",
        # Inversion
        "DIFFERENCE",
        "EXCLUSION",
        # Component
        "HUE",
        "SATURATION",
        "COLOR",
        "LUMINOSITY",
    ],
    """
    Describes how layer blends with layers below.
    """,
]


MaskType = Annotated[
    Literal["ALPHA", "VECTOR", "LUMINANCE"],
    """
    Describes how mask layer operates on the pixels of the layers it masks.

    - `ALPHA`: The mask node's alpha channel will be used to determine the opacity of each
      pixel in the masked result.
    - `VECTOR`: If the mask node has visible fill paints, every pixel inside the node's
      fill regions will be fully visible in the masked result. If the mask has visible
      stroke paints, every pixel inside the node's stroke regions will be fully visible
      in the masked result.
    - `LUMINANCE`: The luminance value of each pixel of the mask node will be used to
      determine the opacity of that pixel in the masked result.
    """,
]


EasingType = Annotated[
    Literal[
        "EASE_IN",
        "EASE_OUT",
        "EASE_IN_AND_OUT",
        "LINEAR",
        "EASE_IN_BACK",
        "EASE_OUT_BACK",
        "EASE_IN_AND_OUT_BACK",
        "CUSTOM_CUBIC_BEZIER",
        "GENTLE",
        "QUICK",
        "BOUNCY",
        "SLOW",
        "CUSTOM_SPRING",
    ],
    """
    Describes animation easing curves.

    - `EASE_IN`: Ease in with an animation curve similar to CSS ease-in.
    - `EASE_OUT`: Ease out with an animation curve similar to CSS ease-out.
    - `EASE_IN_AND_OUT`: Ease in and then out with an animation curve similar to CSS
      ease-in-out.
    - `LINEAR`: No easing, similar to CSS linear.
    - `EASE_IN_BACK`: Ease in with an animation curve that moves past the initial
      keyframe's value and then accelerates as it reaches the end.
    - `EASE_OUT_BACK`: Ease out with an animation curve that starts fast, then slows and
      goes past the ending keyframe's value.
    - `EASE_IN_AND_OUT_BACK`: Ease in and then out with an animation curve that overshoots
      the initial keyframe's value, then accelerates quickly before it slows and
      overshoots the ending keyframes value.
    - `CUSTOM_CUBIC_BEZIER`: User-defined cubic bezier curve.
    - `GENTLE`: Gentle animation similar to react-spring.
    - `QUICK`: Quick spring animation, great for toasts and notifications.
    - `BOUNCY`: Bouncy spring, for delightful animations like a heart bounce.
    - `SLOW`: Slow spring, useful as a steady, natural way to scale up fullscreen content.
    - `CUSTOM_SPRING`: User-defined spring animation.
    """,
]


class FlowStartingPoint(BaseModel):
    """A flow starting point used when launching a prototype to enter Presentation view."""  # noqa: E501

    node_id: str
    """
    Unique identifier specifying the frame.
    """

    name: str
    """
    Name of flow.
    """


class LayoutConstraint(BaseModel):
    """Layout constraint relative to containing Frame."""

    vertical: Literal["TOP", "BOTTOM", "CENTER", "TOP_BOTTOM", "SCALE"]
    """
    Vertical constraint (relative to containing frame).

    - `TOP`: Node is laid out relative to top of the containing frame.
    - `BOTTOM`: Node is laid out relative to bottom of the containing frame.
    - `CENTER`: Node is vertically centered relative to containing frame.
    - `TOP_BOTTOM`: Both top and bottom of node are constrained relative to containing
      frame (node stretches with frame).
    - `SCALE`: Node scales vertically with containing frame.
    """

    horizontal: Literal["LEFT", "RIGHT", "CENTER", "LEFT_RIGHT", "SCALE"]
    """
    Horizontal constraint (relative to containing frame).

    - `LEFT`: Node is laid out relative to left of the containing frame.
    - `RIGHT`: Node is laid out relative to right of the containing frame.
    - `CENTER`: Node is horizontally centered relative to containing frame.
    - `LEFT_RIGHT`: Both left and right of node are constrained relative to containing
      frame (node stretches with frame).
    - `SCALE`: Node scales horizontally with containing frame.
    """


class LayoutGrid(BaseModel):
    """Guides to align and place objects within a frames."""

    pattern: Literal["COLUMNS", "ROWS", "GRID"]
    """
    Orientation of the grid.

    - `COLUMNS`: Vertical grid.
    - `ROWS`: Horizontal grid.
    - `GRID`: Square grid.
    """

    section_size: float
    """
    Width of column grid or height of row grid or square grid spacing.
    """

    visible: bool
    """
    Is the grid currently visible?
    """

    color: RGBA
    """
    Color of the grid.
    """

    alignment: Literal["MIN", "MAX", "STRETCH", "CENTER"]
    """
    Positioning of grid as a string enum.

    - `MIN`: Grid starts at the left or top of the frame.
    - `MAX`: Grid starts at the right or bottom of the frame.
    - `STRETCH`: Grid is stretched to fit the frame.
    - `CENTER`: Grid is center aligned.
    """

    gutter_size: float
    """
    Spacing in between columns and rows.
    """

    offset: float
    """
    Spacing before the first column or row.
    """

    count: int
    """
    Number of columns or rows.
    """

    bound_variables: LayoutGridBoundVariables | None = None
    """
    The variables bound to a particular field on this layout grid.
    """


class LayoutGridBoundVariables(BaseModel):
    gutter_size: VariableAlias | None = None
    num_sections: VariableAlias | None = None
    section_size: VariableAlias | None = None
    offset: VariableAlias | None = None


class Hyperlink(BaseModel):
    """A link to either a URL or another frame (node) in the document."""

    type: Literal["URL", "NODE"]
    """
    The type of hyperlink. Can be either `URL` or `NODE`.
    """

    url: HttpUrl | None = None
    """
    The URL that the hyperlink points to, if `type` is `URL`.
    """

    node_id: str | None = None
    """
    The ID of the node that the hyperlink points to, if `type` is `NODE`.
    """


class DocumentationLink(BaseModel):
    """Represents a link to documentation for a component or component set."""

    uri: HttpUrl
    """
    Should be a valid URI (e.g. https://www.figma.com).
    """


class Path(BaseModel):
    """Defines a single path."""

    path: str
    """
    A series of path commands that encodes how to draw the path.
    """

    winding_rule: Literal["NONZERO", "EVENODD"]
    """
    The winding rule for the path (same as in SVGs).

    This determines whether a given point in space is inside or outside the path.
    """

    override_id: Annotated[float | None, Field(validation_alias="overrideID")] = None
    """
    If there is a per-region fill, this refers to an ID in the `fillOverrideTable`.
    """


class Vector(BaseModel):
    """A 2D vector."""

    x: float
    """
    X coordinate of the vector.
    """

    y: float
    """
    Y coordinate of the vector.
    """


class Size(BaseModel):
    """A width and a height."""

    width: float
    """
    The width of a size.
    """

    height: float
    """
    The height of a size.
    """


Transform = Annotated[
    list[list[float]],
    """
    A 2x3 2D affine transformation matrix that can be used to calculate the affine
    transforms applied to a layer, including scaling, rotation, shearing, and translation.

    A transformation matrix is standard way in computer graphics to represent translation
    and rotation. These are the top two rows of a 3x3 matrix. The bottom row of the matrix
    is assumed to be [0, 0, 1]. This is known as an affine transform and is enough to
    represent translation, rotation, and skew.

    The identity transform is [[1, 0, 0], [0, 1, 0]].

    A translation matrix will typically look like:

        [
            [1, 0, tx],
            [0, 1, ty],
        ]

    And a rotation matrix will typically look like:

        [
            [cos(angle), sin(angle), 0],
            [-sin(angle), cos(angle), 0],
        ]

    Another way to think about this transform is as three vectors:

    - The x axis (t[0][0], t[1][0])
    - The y axis (t[0][1], t[1][1])
    - The translation offset (t[0][2], t[1][2])

    The most common usage of the Transform matrix is the `relativeTransform property`.
    This particular usage of the matrix has a few additional restrictions. The translation
    offset can take on any value but we do enforce that the axis vectors are unit vectors
    (i.e. have length 1). The axes are not required to be at 90° angles to each other.
    """,
]


class ImageFilters(BaseModel):
    """Image filters to apply to the node.

    Defines the image filters applied to an image paint. All values are from -1 to 1.
    """

    exposure: Annotated[float | None, Field(ge=-1.0, le=1.0)] = None
    contrast: Annotated[float | None, Field(ge=-1.0, le=1.0)] = None
    saturation: Annotated[float | None, Field(ge=-1.0, le=1.0)] = None
    temperature: Annotated[float | None, Field(ge=-1.0, le=1.0)] = None
    tint: Annotated[float | None, Field(ge=-1.0, le=1.0)] = None
    highlights: Annotated[float | None, Field(ge=-1.0, le=1.0)] = None
    shadows: Annotated[float | None, Field(ge=-1.0, le=1.0)] = None


class ColorStop(BaseModel):
    """A single color stop with its position along the gradient axis, color, and bound variables if any."""  # noqa: E501

    position: Annotated[float, Field(ge=0.0, le=1.0)]
    """
    Value between 0 and 1 representing position along gradient axis.
    """

    color: RGBA
    """
    Color attached to corresponding position.
    """

    bound_variables: ColorStopBoundVariables | None = None
    """
    The variables bound to a particular gradient stop.
    """


class ColorStopBoundVariables(BaseModel):
    color: VariableAlias | None = None


class Component(BaseModel):
    """A description of a main component.

    Helps you identify which component instances are attached to.
    """

    key: str
    """
    The key of the component.
    """

    name: str
    """
    Name of the component.
    """

    description: str
    """
    The description of the component as entered in the editor.
    """

    component_set_id: str | None
    """
    The ID of the component set if the component belongs to one.
    """

    documentation_links: list[DocumentationLink]
    """
    An array of documentation links attached to this component.
    """

    remote: bool
    """
    Whether this component is a remote component that doesn't live in this file.
    """


class ComponentSet(BaseModel):
    """A description of a component set, which is a node containing a set of variants of a component."""  # noqa: E501

    key: str
    """
    The key of the component set.
    """

    name: str
    """
    Name of the component set.
    """

    description: str
    """
    The description of the component set as entered in the editor.
    """

    documentation_links: list[DocumentationLink] | None = None
    """
    An array of documentation links attached to this component set.
    """

    remote: bool = False
    """
    Whether this component set is a remote component set that doesn't live in this file.
    """


class Style(BaseModel):
    """A set of properties that can be applied to nodes and published.

    Styles for a property can be created in the corresponding property's panel while
    editing a file.
    """

    key: str
    """
    The key of the style.
    """

    name: str
    """
    Name of the style.
    """

    description: str
    """
    Description of the style.
    """

    remote: bool
    """
    Whether this style is a remote style that doesn't live in this file.
    """

    style_type: StyleType
    """
    The type of style.
    """


StyleType = Annotated[
    Literal["FILL", "TEXT", "EFFECT", "GRID"],
    """
    The type of style.
    """,
]


ShapeType = Annotated[
    Literal[
        "SQUARE",
        "ELLIPSE",
        "ROUNDED_RECTANGLE",
        "DIAMOND",
        "TRIANGLE_UP",
        "TRIANGLE_DOWN",
        "PARALLELOGRAM_RIGHT",
        "PARALLELOGRAM_LEFT",
        "ENG_DATABASE",  # Cylinder
        "ENG_QUEUE",  # Horizontal cylinder
        "ENG_FILE",
        "ENG_FOLDER",
        "TRAPEZOID",
        "PREDEFINED_PROCESS",
        "SHIELD",
        "DOCUMENT_SINGLE",
        "DOCUMENT_MULTIPLE",
        "MANUAL_INPUT",
        "HEXAGON",
        "CHEVRON",
        "PENTAGON",
        "OCTAGON",
        "STAR",
        "PLUS",
        "ARROW_LEFT",
        "ARROW_RIGHT",
        "SUMMING_JUNCTION",
        "OR",
        "SPEECH_BUBBLE",
        "INTERNAL_STORAGE",
    ],
    """
    Geometric shape type.
    """,
]


class ComponentPropertyDefinition(BaseModel):
    type: ComponentPropertyType
    """
    Type of this component property.
    """

    default_value: bool | str
    """
    Initial value of this property for instances.
    """

    variant_options: list[str] | None = None
    """
    * All possible values for this property. Only exists on VARIANT properties.
    """

    preferred_values: list[InstanceSwapPreferredValue] | None = None
    """
    * Preferred values for this property. Only applicable if type is `INSTANCE_SWAP`.
    """


class ComponentProperty(BaseModel):
    type: ComponentPropertyType
    """
    Type of this component property.
    """

    value: bool | str
    """
    Value of the property for this component instance.
    """

    preferred_values: list[InstanceSwapPreferredValue] | None = None
    """
    * Preferred values for this property. Only applicable if type is `INSTANCE_SWAP`.
    """

    bound_variables: ComponentPropertyBoundVariables | None = None
    """
    The variables bound to a particular field on this component property
    """


class ComponentPropertyBoundVariables(BaseModel):
    value: VariableAlias | None = None


ComponentPropertyType = Annotated[
    Literal["bool", "INSTANCE_SWAP", "TEXT", "VARIANT"],
    """
    Component property type.
    """,
]


class InstanceSwapPreferredValue(BaseModel):
    """Instance swap preferred value."""

    type: Literal["COMPONENT", "COMPONENT_SET"]
    """
    Type of node for this preferred value.
    """

    key: str
    """
    Key of this component or component set.
    """


class PrototypeDevice(BaseModel):
    """The device used to view a prototype."""

    type: Literal["NONE", "PRESET", "CUSTOM", "PRESENTATION"]
    """
    The type of the device.
    """

    size: Size | None = None

    preset_identifier: str | None = None

    rotation: Literal["NONE", "CCW_90"]
    """
    Rotation of the device.
    """


class Measurement(BaseModel):
    """A pinned distance between two nodes in Dev Mode."""

    id: str
    start: MeasurementStartEnd
    end: MeasurementStartEnd
    offset: MeasurementOffset

    free_text: str | None = None
    """
    When manually overridden, the displayed value of the measurement.
    """


class MeasurementStartEnd(BaseModel):
    """The node and side a measurement is pinned to."""

    node_id: str
    side: Literal["TOP", "RIGHT", "BOTTOM", "LEFT"]


class MeasurementOffsetInner(BaseModel):
    """Measurement offset relative to the inside of the start node."""

    type: Literal["INNER"] = "INNER"
    relative: float


class MeasurementOffsetOuter(BaseModel):
    """Measurement offset relative to the outside of the start node."""

    type: Literal["OUTER"] = "OUTER"
    fixed: float


MeasurementOffset = Annotated[
    MeasurementOffsetInner | MeasurementOffsetOuter,
    Field(discriminator="type"),
]


class StrokeWeights(BaseModel):
    """Individual stroke weights."""

    top: float
    """
    The top stroke weight.
    """

    right: float
    """
    The right stroke weight.
    """

    bottom: float
    """
    The bottom stroke weight.
    """

    left: float
    """
    The left stroke weight.
    """


class Overrides(BaseModel):
    """Fields directly overridden on an instance. Inherited overrides are not included."""

    id: str
    """
    A unique ID for a node.
    """

    overridden_fields: list[str]
    """
    An array of properties.
    """


class VariableAlias(BaseModel):
    """Contains a variable alias."""

    type: Literal["VARIABLE_ALIAS"] = "VARIABLE_ALIAS"

    id: str
    """
    The id of the variable that the current variable is aliased to.
    This variable can be a local or remote variable, and both can be retrieved via the
    [`GET /v1/files/:file_key/variables/local` endpoint](https://developers.figma.com/docs/rest-api/variables-endpoints/#get-local-variables-endpoint).
    """


class DevStatus(BaseModel):
    """Represents a handoff (or dev) status applied to a node."""

    type: Literal["NONE", "READY_FOR_DEV", "COMPLETED"]

    description: str | None = None
    """
    An optional field where the designer can add more information about the design and
    what has changed.
    """


Navigation = Annotated[
    Literal["NAVIGATE", "SWAP", "OVERLAY", "SCROLL_TO", "CHANGE_TO"],
    """
    The method of navigation.

    - `NAVIGATE`: Replaces the current screen with the destination, also closing all
      overlays.
    - `OVERLAY`: Opens the destination as an overlay on the current screen.
    - `SWAP`: Replaces the current (topmost) overlay with the destination.
    - `SCROLL_TO`: Scrolls to the destination on the current screen.
    - `CHANGE_TO`: Changes the closest ancestor instance of source node to the specified
      variant.
    """,
]


class SimpleTransition(BaseModel):
    """Describes an animation used when navigating in a prototype."""

    type: Literal["DISSOLVE", "SMART_ANIMATE", "SCROLL_ANIMATE"]

    duration: int
    """
    The duration of the transition in milliseconds.
    """

    easing: Easing
    """
    The easing curve of the transition.
    """


class DirectionalTransition(BaseModel):
    """Describes an animation used when navigating in a prototype."""

    type: Literal["MOVE_IN", "MOVE_OUT", "PUSH", "SLIDE_IN", "SLIDE_OUT"]

    direction: Literal["LEFT", "RIGHT", "TOP", "BOTTOM"]

    duration: int
    """
    The duration of the transition in milliseconds.
    """

    easing: Easing
    """
    The easing curve of the transition.
    """

    match_layers: bool | None = Field(None, alias="matchLayers")
    """
    When the transition `type` is `SMART_ANIMATE` or when `match_layers` is `True`, then
    the transition will be performed using smart animate, which attempts to match
    corresponding layers an interpolate other properties during the animation.
    """


Transition = Annotated[
    SimpleTransition | DirectionalTransition,
    Field(discriminator="type"),
    """
    Describes an animation used when navigating in a prototype.
    """,
]


class Easing(BaseModel):
    """Describes an easing curve."""

    type: EasingType
    """
    The type of easing curve.
    """

    easing_function_cubic_bezier: EasingFunctionCubicBezier | None = None
    """
    A cubic bezier curve that defines the easing.
    """

    easing_function_spring: EasingFunctionSpring | None = None
    """
    A spring function that defines the easing.
    """


class EasingFunctionCubicBezier(BaseModel):
    """A cubic bezier curve that defines the easing."""

    x1: float
    """
    The x component of the first control point.
    """

    y1: float
    """
    The y component of the first control point.
    """

    x2: float
    """
    The x component of the second control point.
    """

    y2: float
    """
    The y component of the second control point.
    """


class EasingFunctionSpring(BaseModel):
    """A spring function that defines the easing."""

    mass: float
    stiffness: float
    damping: float


class VariableData(BaseModel):
    """A value to set a variable to during prototyping."""

    type: VariableDataType | None = None
    resolved_type: VariableResolvedDataType | None = None
    value: bool | int | float | str | RGBA | RGB | VariableAlias | Expression | None = (
        None
    )


VariableDataType = Annotated[
    Literal["BOOLEAN", "FLOAT", "STRING", "COLOR", "VARIABLE_ALIAS", "EXPRESSION"],
    """
    Defines the types of data a VariableData object can hold.
    """,
]

VariableResolvedDataType = Annotated[
    Literal["BOOLEAN", "FLOAT", "STRING", "COLOR"],
    """
    Defines the types of data a VariableData object can eventually equal.
    """,
]


class Expression(BaseModel):
    """Defines the [Expression](https://help.figma.com/hc/en-us/articles/15253194385943) object, which contains a list of `VariableData` objects strung together by operators (`ExpressionFunction`)."""  # noqa: E501

    expression_function: ExpressionFunction
    expression_arguments: list[VariableData]


ExpressionFunction = Annotated[
    Literal[
        "ADDITION",
        "SUBTRACTION",
        "MULTIPLICATION",
        "DIVISION",
        "EQUALS",
        "NOT_EQUAL",
        "LESS_THAN",
        "LESS_THAN_OR_EQUAL",
        "GREATER_THAN",
        "GREATER_THAN_OR_EQUAL",
        "AND",
        "OR",
        "VAR_MODE_LOOKUP",
        "NEGATE",
        "NOT",
    ],
    """
    Defines the list of operators available to use in an Expression.
    """,
]
