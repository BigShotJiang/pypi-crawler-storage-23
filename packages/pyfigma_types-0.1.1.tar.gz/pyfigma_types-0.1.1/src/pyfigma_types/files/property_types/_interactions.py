from __future__ import annotations

from pyfigma_types._models import BaseModel

from ._actions import Action
from ._triggers import Trigger


class Interaction(BaseModel):
    """An interaction in the Figma viewer, containing a trigger and one or more actions."""  # noqa: E501

    trigger: Trigger | None = None
    """
    The user event that initiates the interaction.
    """

    actions: list[Action] | None = None
    """
    The actions that are performed when the trigger is activated.
    """
