"""[Figma property types - Effect](https://developers.figma.com/docs/rest-api/file-property-types/#effect-type)."""

from __future__ import annotations

from typing import Annotated, Literal

from pydantic import Field

from pyfigma_types._models import BaseModel

from ._base import (
    RGBA,
    BlendMode,
    VariableAlias,
    Vector,
)


class BaseShadowEffect(BaseModel):
    """Base properties shared by all shadow effects."""

    color: RGBA
    """
    The color of the shadow.
    """

    blend_mode: BlendMode
    """
    Blend mode of the shadow.
    """

    offset: Vector
    """
    How far the shadow is projected in the x and y directions.
    """

    radius: float
    """
    Radius of the blur effect (applies to shadows as well).
    """

    spread: float | None
    """
    The distance by which to expand (or contract) the shadow.

    - For drop shadows, a positive `spread` value creates a shadow larger than the node,
      whereas a negative value creates a shadow smaller than the node.
    - For inner shadows, a positive `spread` value contracts the shadow. Spread values are
      only accepted on rectangles and ellipses, or on frames, components, and instances
      with visible fill paints and `clipsContent` enabled. When left unspecified, the
      default value is 0.
    """

    visible: bool
    """
    Whether this shadow is visible.
    """

    bound_variables: BaseShadowEffectBoundVariables | None = None
    """
    The variables bound to a particular field on this shadow effect.
    """


class BaseShadowEffectBoundVariables(BaseModel):
    radius: VariableAlias | None = None
    spread: VariableAlias | None = None
    color: VariableAlias | None = None
    offset_x: VariableAlias | None = None
    offset_y: VariableAlias | None = None


class DropShadowEffect(BaseShadowEffect):
    type: Literal["DROP_SHADOW"] = "DROP_SHADOW"
    """
    A string literal representing the effect's type.
    Always check the type before reading other properties.
    """

    show_shadow_behind_node: bool
    """
    Whether to show the shadow behind translucent or transparent pixels.
    """


class InnerShadowEffect(BaseShadowEffect):
    type: Literal["INNER_SHADOW"] = "INNER_SHADOW"
    """
    A string literal representing the effect's type.
    Always check the type before reading other properties.
    """


class BaseBlurEffect(BaseModel):
    """Base properties shared by all blur effects."""

    type: Literal["LAYER_BLUR", "BACKGROUND_BLUR"]
    """
    A string literal representing the effect's type.
    Always check the type before reading other properties.
    """

    visible: bool
    """
    Whether this blur is active.
    """

    radius: float
    """
    Radius of the blur effect.
    """

    bound_variables: BaseBlurEffectBoundVariables | None = None
    """
    The variables bound to a particular field on this blur effect.
    """


class BaseBlurEffectBoundVariables(BaseModel):
    radius: VariableAlias | None = None


class NormalBlurEffect(BaseBlurEffect):
    blur_type: Literal["NORMAL"] = "NORMAL"
    """
    The string literal `NORMAL` representing the blur type.
    Always check the blurType before reading other properties.
    """


class ProgressiveBlurEffect(BaseBlurEffect):
    blur_type: Literal["PROGRESSIVE"] = "PROGRESSIVE"
    """
    The string literal `PROGRESSIVE` representing the blur type.
    Always check the blurType before reading other properties.
    """

    start_radius: float
    """
    The starting radius of the progressive blur.
    """

    start_offset: Vector
    """
    The starting offset of the progressive blur.
    """

    end_offset: Vector
    """
    The ending offset of the progressive blur.
    """


BlurEffect = Annotated[
    NormalBlurEffect | ProgressiveBlurEffect,
    Field(discriminator="blur_type"),
]


class TextureEffect(BaseModel):
    """A texture effect."""

    type: Literal["TEXTURE"] = "TEXTURE"
    """
    A string literal representing the effect's type.
    Always check the type before reading other properties.
    """

    visible: bool
    """
    Whether the texture effect is visible.
    """

    noise_size: float
    """
    The size of the texture effect.
    """

    radius: float
    """
    The radius of the texture effect.
    """

    clip_to_shape: bool
    """
    Whether the texture is clipped to the shape.
    """


class BaseNoiseEffect(BaseModel):
    """A noise effect."""

    type: Literal["NOISE"] = "NOISE"
    """
    A string literal representing the effect's type.
    Always check the type before reading other properties.
    """

    color: RGBA
    """
    The color of the noise effect.
    """

    visible: bool
    """
    Whether the noise effect is visible.
    """

    blend_mode: BlendMode
    """
    Blend mode of the noise effect.
    """

    noise_size: float
    """
    The size of the noise effect.
    """

    density: float
    """
    The density of the noise effect.
    """


class MonotoneNoiseEffect(BaseNoiseEffect):
    noise_type: Literal["MONOTONE"] = "MONOTONE"


class MultitoneNoiseEffect(BaseNoiseEffect):
    noise_type: Literal["MULTITONE"] = "MULTITONE"

    opacity: float
    """
    The opacity of the noise effect.
    """


class DuotoneNoiseEffect(BaseNoiseEffect):
    noise_type: Literal["DUOTONE"] = "DUOTONE"

    secondary_color: RGBA
    """
    The secondary color of the noise effect.
    """


NoiseEffect = Annotated[
    MonotoneNoiseEffect | MultitoneNoiseEffect | DuotoneNoiseEffect,
    Field(discriminator="noise_type"),
]


Effect = Annotated[
    DropShadowEffect | InnerShadowEffect | BlurEffect | TextureEffect | NoiseEffect,
    Field(discriminator="type"),
    """
    A visual effect such as a shadow, blur, texture, or noise.
    """,
]
