from __future__ import annotations

from typing import Any, Literal

from pyfigma_types.files.property_types import (
    RGBA,
    FlowStartingPoint,
    Measurement,
    PrototypeDevice,
)

from . import HasExportSettingsTrait, IsLayerTrait


class DocumentNode(IsLayerTrait):
    type: Literal["DOCUMENT"] = "DOCUMENT"
    children: list[CanvasNode]


class CanvasNode(IsLayerTrait, HasExportSettingsTrait):
    type: Literal["CANVAS"] = "CANVAS"
    children: list[SubcanvasNode]

    background_color: RGBA
    """
    Background color of the canvas.
    """

    flow_starting_points: list[FlowStartingPoint]
    """
    An array of flow starting points sorted by its position in the prototype settings
    panel.
    """

    prototype_device: PrototypeDevice
    """
    The device used to view a prototype.
    """

    prototype_backgrounds: list[RGBA] | None = None
    """
    The background color of the prototype (currently only supports a single solid color
    paint).
    """

    measurements: list[Measurement] | None = None


SubcanvasNode = Any
