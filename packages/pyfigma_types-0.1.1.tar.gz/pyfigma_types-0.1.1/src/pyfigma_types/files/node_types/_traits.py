from __future__ import annotations

from typing import Annotated, Any, Literal

from pydantic import Field

from pyfigma_types._models import BaseModel
from pyfigma_types.files._traits import (
    MinimalFillsTrait,
    MinimalStrokesTrait,
)
from pyfigma_types.files.property_types._base import (
    BlendMode,
    ExportSetting,
    LayoutConstraint,
    LayoutGrid,
    Path,
    Rectangle,
    Transform,
    Vector,
)


class IsLayerTrait(BaseModel):
    id: str
    """A string uniquely identifying this node within the document."""

    name: str
    """The name given to the node by the user in the tool."""

    visible: bool = False
    """Whether or not the node is visible on the canvas."""

    locked: bool = False
    """If True, layer is locked and cannot be edited."""

    is_fixed: Annotated[bool, Field(deprecated=True)] = False
    """Whether the layer is fixed while the parent is scrolling."""

    scroll_behavior: Literal["SCROLLS", "FIXED", "STICKY_SCROLLS"]
    """How layer should be treated when the frame is resized."""

    rotation: float | None = None
    """The rotation of the node, if not 0."""

    component_property_references: dict[str, str] | None = None
    """A mapping of a layer's property to component property name of component properties
    attached to this node. The component property name can be used to look up more
    information on the corresponding component's or component set's
    `componentPropertyDefinitions`.
    """

    plugin_data: Any
    """
    Data written by plugins that is visible only to the plugin that wrote it. Requires the
    `plugin_data` to include the ID of the plugin.
    """

    shared_plugin_data: Any
    """
    Data written by plugins that is visible to all plugins. Requires the `plugin_data`
    parameter to include the string "shared".
    """

    bound_variables: dict[str, Any] | None = None
    """A mapping of field to the variables applied to this field."""

    explicit_variable_modes: dict[str, str] | None = None
    """
    A mapping of variable collection ID to mode ID representing explicitly set modes
    for this node.
    """


class HasChildrenTrait(BaseModel):
    children: list[SubcanvasNode]
    """An array of nodes that are direct children of this node."""


class HasLayoutTrait(BaseModel):
    absolute_bounding_box: Rectangle | None
    """
    Bounding box of the node in absolute space coordinates.
    """

    absolute_render_bounds: Rectangle | None
    """
    The actual bounds of a node accounting for drop shadows, thick strokes, and anything
    else that may fall outside the node's regular bounding box defined in `x`, `y`,
    `width`, and `height`. The `x` and `y` inside this property represent the absolute
    position of the node on the page. This value will be `null` if the node is invisible.
    """

    preserve_ratio: bool | None
    """
    Keep height and width constrained to same ratio.
    """

    constraints: LayoutConstraint | None = None
    """
    Horizontal and vertical layout constraints for node.
    """

    relative_transform: Transform | None
    """
    The top two rows of a matrix that represents the 2D transform of this node relative to
    its parent. The bottom row of the matrix is implicitly always (0, 0, 1). Use to
    transform coordinates in geometry. Only present if `geometry=paths` is passed.
    """

    size: Vector | None = None
    """
    Width and height of element. This is different from the width and height of the
    bounding box in that the absolute bounding box represents the element after scaling
    and rotation. Only present if `geometry=paths` is passed.
    """

    layout_align: Literal["INHERIT", "STRETCH", "MIN", "CENTER", "MAX"] | None
    """
    Determines if the layer should stretch along the parent's counter axis. This property is only
    provided for direct children of auto-layout frames.

    - `INHERIT`
    - `STRETCH`

    In previous versions of auto layout, determined how the layer is aligned inside an auto-layout
    frame. This property is only provided for direct children of auto-layout frames.

    - `MIN`
    - `CENTER`
    - `MAX`
    - `STRETCH`

    In horizontal auto-layout frames, "MIN" and "MAX" correspond to "TOP" and "BOTTOM". In vertical
    auto-layout frames, "MIN" and "MAX" correspond to "LEFT" and "RIGHT".
    """

    layout_grow: Literal[0, 1] | None
    """
    This property is applicable only for direct children of auto-layout frames, ignored
    otherwise. Determines whether a layer should stretch along the parent's primary axis.
    A `0` corresponds to a fixed size and `1` corresponds to stretch.
    """

    layout_positioning: Literal["AUTO", "ABSOLUTE"] | None
    """
    Determines whether a layer's size and position should be determined by auto-layout or
    manually adjustable.
    """

    min_width: float | None
    """
    The minimum width of the frame. This property is only applicable for auto-layout frames or direct
    children of auto-layout frames.
    """

    max_width: float | None
    """
    The maximum width of the frame.
    """

    min_height: float | None
    """
    The minimum height of the frame. This property is only applicable for auto-layout frames or
    direct children of auto-layout frames.
    """

    max_height: float | None
    """
    The maximum height of the frame. This property is only applicable for auto-layout frames or
    direct children of auto-layout frames.
    """

    layout_sizing_horizontal: Literal["FIXED", "HUG", "FILL"] | None
    """
    The horizontal sizing setting on this auto-layout frame or frame child.

    - `FIXED`
    - `HUG`: only valid on auto-layout frames and text nodes
    - `FILL`: only valid on auto-layout frame children
    """

    layout_sizing_vertical: Literal["FIXED", "HUG", "FILL"] | None
    """
    The vertical sizing setting on this auto-layout frame or frame child.

    - `FIXED`
    - `HUG`: only valid on auto-layout frames and text nodes
    - `FILL`: only valid on auto-layout frame children
    """

    grid_row_count: int | None
    """
    The number of rows in the grid layout. This property is only applicable for auto-layout frames
    with `layoutMode: "GRID"`.
    """

    grid_column_count: int | None
    """
    The number of columns in the grid layout. This property is only applicable for auto-layout frames
    with `layoutMode: "GRID"`.
    """

    grid_row_gap: float | None
    """
    The distance between rows in the grid layout.
    """

    grid_column_gap: float | None
    """
    The distance between columns in the grid layout.
    """

    grid_columns_sizing: str | None
    """
    The string for the CSS grid-template-columns property.
    """

    grid_rows_sizing: str | None
    """
    The string for the CSS grid-template-rows property.
    """

    grid_child_horizontal_align: Literal["AUTO", "MIN", "CENTER", "MAX"] | None
    """
    Determines how a GRID frame's child should be aligned horizontally within its grid area.
    """

    grid_child_vertical_align: Literal["AUTO", "MIN", "CENTER", "MAX"] | None
    """
    Determines how a GRID frame's child should be aligned vertically within its grid area.
    """

    grid_row_span: int | None
    """
    The number of rows that a GRID frame's child should span.
    """

    grid_column_span: int | None
    """
    The number of columns that a GRID frame's child should span.
    """

    grid_row_anchor_index: int | None
    """
    The index of the row that a GRID frame's child should be anchored to.
    """

    grid_column_anchor_index: int | None
    """
    The index of the column that a GRID frame's child should be anchored to.
    """


class HasFramePropertiesTrait(BaseModel):
    """Trait for nodes that have frame-specific properties."""

    clips_content: bool
    """
    Whether or not this node clips content outside of its bounds.
    """

    background: list[Any] | None = None
    """
    Background of the node. Deprecated - use fills field instead.
    """

    background_color: Any | None
    """
    Background color of the node. Deprecated - use fills field instead.
    """

    layout_grids: list[LayoutGrid] | None
    """
    An array of layout grids attached to this node.
    """

    overflow_direction: (
        Literal[
            "HORIZONTAL_SCROLLING",
            "VERTICAL_SCROLLING",
            "HORIZONTAL_AND_VERTICAL_SCROLLING",
            "NONE",
        ]
        | None
    ) = Field(None, alias="overflowDirection")
    """
    Whether a node has primary axis scrolling, horizontal or vertical.
    """

    layout_mode: Literal["NONE", "HORIZONTAL", "VERTICAL", "GRID"] | None
    """
    Whether this layer uses auto-layout to position its children.
    """

    primary_axis_sizing_mode: Literal["FIXED", "AUTO"] | None
    """
    Whether the primary axis has a fixed or automatic length.
    """

    counter_axis_sizing_mode: Literal["FIXED", "AUTO"] | None
    """
    Whether the counter axis has a fixed or automatic length.
    """

    primary_axis_align_items: Literal["MIN", "CENTER", "MAX", "SPACE_BETWEEN"] | None
    """
    How the auto-layout frame's children should be aligned in the primary axis direction.
    """

    counter_axis_align_items: Literal["MIN", "CENTER", "MAX", "BASELINE"] | None
    """
    How the auto-layout frame's children should be aligned in the counter axis direction.
    """

    padding_left: float | None
    """
    The padding between the left border of the frame and its children.
    """

    padding_right: float | None
    """
    The padding between the right border of the frame and its children.
    """

    padding_top: float | None
    """
    The padding between the top border of the frame and its children.
    """

    padding_bottom: float | None
    """
    The padding between the bottom border of the frame and its children.
    """

    item_spacing: float | None
    """
    The distance between children of the frame. Can be negative.
    """

    item_reverse_z_index: bool | None
    """
    Determines the canvas stacking order of layers in this frame.
    """

    strokes_included_in_layout: bool | None
    """
    Determines whether strokes are included in layout calculations.
    """

    layout_wrap: Literal["NO_WRAP", "WRAP"] | None
    """
    Whether this auto-layout frame has wrapping enabled.
    """

    counter_axis_spacing: float | None
    """
    The distance between wrapped tracks of an auto-layout frame.
    """

    counter_axis_align_content: Literal["AUTO", "SPACE_BETWEEN"] | None
    """
    How the auto-layout frame's wrapped tracks should be aligned in the counter axis direction.
    """


class HasGeometryTrait(MinimalFillsTrait, MinimalStrokesTrait):
    """Trait for nodes that have geometry (paths, fills, strokes)."""

    fill_override_table: dict[str, Any | None] | None
    """
    Map from ID to PaintOverride for looking up fill overrides.
    """

    fill_geometry: list[Path] | None
    """
    An array of paths representing the object fill. Only specified if `geometry=paths` is used.
    """

    stroke_geometry: list[Path] | None
    """
    An array of paths representing the object stroke. Only specified if `geometry=paths` is used.
    """

    stroke_cap: (
        Literal[
            "NONE",
            "ROUND",
            "SQUARE",
            "LINE_ARROW",
            "TRIANGLE_ARROW",
            "DIAMOND_FILLED",
            "CIRCLE_FILLED",
            "TRIANGLE_FILLED",
            "WASHI_TAPE_1",
            "WASHI_TAPE_2",
            "WASHI_TAPE_3",
            "WASHI_TAPE_4",
            "WASHI_TAPE_5",
            "WASHI_TAPE_6",
        ]
        | None
    )
    """
    A string enum describing the end caps of vector paths.
    """

    stroke_miter_angle: float | None
    """
    The corner angle (in degrees) below which strokeJoin will be set to BEVEL. Default is 28.96.
    """


class HasBlendModeAndOpacityTrait(BaseModel):
    blend_mode: BlendMode
    """
    How this node blends with nodes behind it in the scene.
    """

    opacity: float | None = None
    """
    Opacity of the node.
    """


class HasExportSettingsTrait(BaseModel):
    export_settings: list[ExportSetting] | None = None
    """Settings for exports of this node."""


class SubcanvasNode(BaseModel):
    pass
