from __future__ import annotations

from pyfigma_types._models import BaseModel


class User(BaseModel):
    """A description of a user."""

    id: str
    """
    Unique stable id of the user.
    """

    handle: str
    """
    Name of the user.
    """

    img_url: str
    """
    URL link to the user's profile image.
    """
