from __future__ import annotations

from ._types import User


class GetMeResponse(User):
    """Response schema for the `GET /v1/me` endpoint."""

    email: str
    """
    Email associated with the user's account.
    This property is only present on the /v1/me endpoint.
    """
