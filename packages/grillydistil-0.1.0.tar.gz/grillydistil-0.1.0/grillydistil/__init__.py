"""GrillyDistil — Temperature-scaled distillation with SA-KD.

Optional grilly extension providing:
- SAKDTemperature: Adaptive temperature via simulated annealing
- DistillationTrainer: Knowledge distillation training loop
- PromptGenerator: Expanded domain-specific prompt generation
- FusedKLDivLoss: Fused KL-divergence with decompression
"""

from .temperature import SAKDTemperature, LinearAnnealing
from .trainer import DistillationTrainer
from .prompts import PromptGenerator

__version__ = "0.1.0"

__all__ = [
    "SAKDTemperature",
    "LinearAnnealing",
    "DistillationTrainer",
    "PromptGenerator",
]
