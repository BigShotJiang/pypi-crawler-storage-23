"""SA-KD: Simulated Annealing-based Adaptive Temperature for distillation.

Replaces fixed temperature with adaptive schedule:
- Metropolis acceptance: P = min(1, exp(-dE / T_SA))
- SA cooling: T_SA *= alpha each meta-iteration
- Fallback: linear annealing T_start=8 -> T_end=2 over first 30% of steps

High-T phases produce smoother teacher logits -> 2-3x better compression ratios.
"""

from __future__ import annotations

import logging
import math
import random

import numpy as np

logger = logging.getLogger(__name__)


class SAKDTemperature:
    """Adaptive temperature via simulated annealing for knowledge distillation.

    The SA-KD algorithm:
    1. Start with T_init (distillation temperature) and T_SA (SA temperature)
    2. Each step, propose T' = T + random perturbation
    3. Accept T' with Metropolis probability if it reduces validation loss
    4. Cool T_SA by factor alpha each meta-iteration

    Args:
        T_init: Initial distillation temperature (default 8.0).
        T_sa_init: Initial SA temperature (default 5.0).
        alpha: SA cooling rate (default 0.97).
        T_min: Minimum distillation temperature (default 1.0).
        T_max: Maximum distillation temperature (default 20.0).
        perturbation_scale: Scale of random perturbation (default 0.5).
    """

    def __init__(
        self,
        T_init: float = 8.0,
        T_sa_init: float = 5.0,
        alpha: float = 0.97,
        T_min: float = 1.0,
        T_max: float = 20.0,
        perturbation_scale: float = 0.5,
    ):
        self.T = T_init
        self.T_sa = T_sa_init
        self.alpha = alpha
        self.T_min = T_min
        self.T_max = T_max
        self.perturbation_scale = perturbation_scale

        self._best_T = T_init
        self._best_loss = float("inf")
        self._step_count = 0
        self._accept_count = 0
        self._history: list[tuple[int, float, float]] = []

    def step(self, validation_loss: float) -> float:
        """Propose and possibly accept a new temperature.

        Args:
            validation_loss: Current validation/distillation loss.

        Returns:
            Current distillation temperature T.
        """
        self._step_count += 1

        # Propose new temperature
        perturbation = random.gauss(0, self.perturbation_scale)
        T_proposed = np.clip(self.T + perturbation, self.T_min, self.T_max)

        # Metropolis acceptance
        delta_E = validation_loss - self._best_loss
        if delta_E < 0:
            # Better: always accept
            accept = True
        else:
            # Worse: accept with probability exp(-dE / T_SA)
            accept_prob = math.exp(-delta_E / max(self.T_sa, 1e-8))
            accept = random.random() < accept_prob

        if accept:
            self.T = T_proposed
            self._accept_count += 1
            if validation_loss < self._best_loss:
                self._best_loss = validation_loss
                self._best_T = self.T

        # SA cooling
        self.T_sa *= self.alpha

        self._history.append((self._step_count, self.T, validation_loss))

        if self._step_count % 50 == 0:
            accept_rate = self._accept_count / self._step_count
            logger.info(
                "SA-KD step %d: T=%.2f, T_SA=%.4f, loss=%.4f, accept_rate=%.2f",
                self._step_count, self.T, self.T_sa, validation_loss, accept_rate,
            )

        return self.T

    @property
    def current_temperature(self) -> float:
        return self.T

    @property
    def best_temperature(self) -> float:
        return self._best_T

    def get_stats(self) -> dict:
        return {
            "current_T": self.T,
            "best_T": self._best_T,
            "best_loss": self._best_loss,
            "T_sa": self.T_sa,
            "steps": self._step_count,
            "accept_rate": self._accept_count / max(self._step_count, 1),
        }


class LinearAnnealing:
    """Simple linear temperature annealing fallback.

    T_start=8 -> T_end=2 over first 30% of steps, then constant T_end.
    """

    def __init__(
        self,
        T_start: float = 8.0,
        T_end: float = 2.0,
        warmup_fraction: float = 0.3,
        total_steps: int = 1000,
    ):
        self.T_start = T_start
        self.T_end = T_end
        self.warmup_steps = int(total_steps * warmup_fraction)
        self.total_steps = total_steps
        self._step = 0

    def step(self, validation_loss: float | None = None) -> float:
        """Get current temperature and advance step.

        Args:
            validation_loss: Ignored (for API compatibility with SAKDTemperature).

        Returns:
            Current temperature.
        """
        self._step += 1

        if self._step <= self.warmup_steps:
            # Linear interpolation
            progress = self._step / self.warmup_steps
            T = self.T_start + (self.T_end - self.T_start) * progress
        else:
            T = self.T_end

        return T

    @property
    def current_temperature(self) -> float:
        if self._step <= self.warmup_steps:
            progress = self._step / max(self.warmup_steps, 1)
            return self.T_start + (self.T_end - self.T_start) * progress
        return self.T_end
