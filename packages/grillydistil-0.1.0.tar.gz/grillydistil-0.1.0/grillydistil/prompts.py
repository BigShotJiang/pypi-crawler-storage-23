"""Expanded domain-specific prompt generation for distillation.

Increases seed prompts from 15 to 50-100 per domain.
Supports temperature > 0 in teacher inference for response diversity.
"""

from __future__ import annotations

import logging
import random

logger = logging.getLogger(__name__)

# 50 seed prompts per domain (expanded from 15)
SEED_PROMPTS = {
    "code": [
        "Implement a binary search algorithm in Python with detailed comments.",
        "Write an LRU cache with O(1) get and put operations.",
        "Create a retry decorator with exponential backoff.",
        "Implement a publish-subscribe event bus in Python.",
        "Write a memory profiler that tracks allocations.",
        "Implement Python generators for lazy evaluation of large datasets.",
        "Parse cron expressions and compute next execution time.",
        "Build a trie data structure for autocomplete.",
        "Write a file watcher that detects changes using polling.",
        "Create an async HTTP client with connection pooling.",
        "Debug a race condition in a multithreaded producer-consumer queue.",
        "Refactor a 500-line function into clean, testable modules.",
        "Write a SQL query optimizer that detects N+1 problems.",
        "Implement a token bucket rate limiter.",
        "Write comprehensive unit tests for a REST API.",
        "Implement a B-tree with insert, search, and delete operations.",
        "Create a dependency injection container in Python.",
        "Write a JSON schema validator from scratch.",
        "Implement a thread pool with work stealing.",
        "Build a simple regex engine supporting *, +, and ?.",
        "Write a memory-mapped file reader for large CSV processing.",
        "Implement consistent hashing for distributed caching.",
        "Create a circuit breaker pattern for microservice calls.",
        "Write a custom logging framework with structured output.",
        "Implement a concurrent skip list.",
        "Build a simple HTTP/1.1 server from raw sockets.",
        "Write a diff algorithm for text comparison.",
        "Implement a bloom filter with configurable false positive rate.",
        "Create a task scheduler with priority queues and deadlines.",
        "Write a Python metaclass for automatic serialization.",
        "Implement a copy-on-write data structure.",
        "Build a simple garbage collector using reference counting.",
        "Write a parser combinator library.",
        "Implement a lock-free queue using CAS operations.",
        "Create a database connection pool with health checking.",
        "Write a Python decorator for memoization with TTL.",
        "Implement a red-black tree with all rotations.",
        "Build a simple key-value store with WAL for durability.",
        "Write a coroutine-based async framework from scratch.",
        "Implement a Vulkan compute shader dispatch wrapper in Python.",
        "Create a neural network layer using pure NumPy.",
        "Write a custom pickle protocol for large numpy arrays.",
        "Implement a simple JIT compiler for arithmetic expressions.",
        "Build a WebSocket server with message framing.",
        "Write a Python REPL with tab completion and history.",
        "Implement a persistent data structure (functional queue).",
        "Create a load balancer with round-robin and least-connections.",
        "Write a simple container runtime using Linux namespaces.",
        "Implement a gossip protocol for cluster membership.",
        "Build a simple distributed hash table.",
    ],
    "reasoning": [
        "Explain how multi-head attention works and why it's better than single-head.",
        "Compare LoRA vs full fine-tuning: when to use each.",
        "When should you use SQLite vs PostgreSQL? Analyze tradeoffs.",
        "Analyze the time and space complexity of merge sort vs quicksort.",
        "How do sparse representations save memory in neural networks?",
        "Compare FAISS, Annoy, and ScaNN for vector similarity search.",
        "What is dark knowledge in knowledge distillation?",
        "Explain microservices vs monolith: when each makes sense.",
        "Why does cosine similarity work better than dot product for embeddings?",
        "Walk through gradient descent step by step for a 2-layer network.",
        "Compare async/await vs threading for I/O-bound tasks.",
        "How do you choose LoRA rank and alpha for a specific model?",
        "Explain the dentate gyrus pattern separation mechanism.",
        "Compare INT8, FP16, and BF16 quantization tradeoffs.",
        "What are the differences between cross-attention and self-attention?",
        "Explain why transformers struggle with length generalization.",
        "How does Flash Attention reduce memory from O(N^2) to O(N)?",
        "Compare RoPE vs ALiBi vs learned position embeddings.",
        "Why does SwiGLU outperform GELU in transformer FFN layers?",
        "Explain the lottery ticket hypothesis and its implications.",
        "How do mixture of experts (MoE) models achieve efficiency?",
        "Compare KV-cache eviction strategies: LRU vs H2O vs sliding window.",
        "Explain why batch normalization fails in transformers.",
        "How does speculative decoding speed up autoregressive generation?",
        "Compare PagedAttention vs static KV allocation tradeoffs.",
        "Explain the scaling laws for large language models.",
        "Why does RMSNorm work better than LayerNorm for Llama?",
        "How do vector symbolic architectures (VSA) represent structure?",
        "Compare teacher-student distillation vs self-distillation.",
        "Explain why GQA is more efficient than MHA for inference.",
        "How does SmoothQuant handle activation outliers?",
        "Compare GPTQ, AWQ, and SmoothQuant quantization methods.",
        "Explain the information bottleneck theory in deep learning.",
        "Why do larger models distill better than smaller ones?",
        "How does RDNA2's WMMA differ from NVIDIA's Tensor Cores?",
        "Compare Vulkan compute shaders vs CUDA for ML workloads.",
        "Explain cooperative matrix operations on AMD GPUs.",
        "How does paged memory management help KV-cache efficiency?",
        "Compare ring attention vs sequence parallelism.",
        "Explain why int4 quantization needs per-group scales.",
        "How does activation checkpointing trade compute for memory?",
        "Compare SGD with momentum vs Adam for transformer training.",
        "Explain the connection between attention and kernel methods.",
        "How do hardware-aware algorithms improve GPU utilization?",
        "Compare Megatron-LM vs FSDP for distributed training.",
        "Explain how Mamba/state space models differ from transformers.",
        "Why does layer offloading work for inference but not training?",
        "How do you measure perplexity and what does it tell you?",
        "Compare top-k, top-p, and temperature sampling strategies.",
        "Explain the reversal curse in language models.",
    ],
    "creative": [
        "Design a novel AI architecture that mimics human dream consolidation.",
        "Invent a context compression algorithm inspired by hippocampal replay.",
        "Propose an attention mechanism that uses phase-coded neural oscillations.",
        "Design a multi-agent system where agents evolve communication protocols.",
        "Imagine an AI that generates and verifies its own training data.",
        "Design a reinforcement learning agent that uses episodic memory replay.",
        "Propose a documentation AI that learns project conventions automatically.",
        "Design a continual learning system that prevents catastrophic forgetting.",
        "Imagine a code generation AI that understands program semantics, not syntax.",
        "Design a multi-agent voting system for code review.",
        "Propose a neural scheduler that optimizes GPU kernel dispatch.",
        "Design metrics that measure understanding, not just accuracy.",
        "Imagine a paper-writing AI that does genuine literature review.",
        "Design a RAG system that generates better queries, not just retrieves.",
        "Propose a new programming language designed for AI-human collaboration.",
        "Design a GPU memory manager that predicts allocation patterns.",
        "Imagine a debugger that uses causal reasoning to find root causes.",
        "Design a neural network that learns its own architecture.",
        "Propose a version control system optimized for AI-generated code.",
        "Design an AI pair programmer that adapts to developer style.",
        "Imagine a testing framework where tests write themselves.",
        "Design a knowledge graph that evolves with new information.",
        "Propose a new loss function inspired by cognitive science.",
        "Design a compiler that optimizes for neural network inference.",
        "Imagine an IDE that predicts your next refactoring step.",
        "Design a distributed training system using evolutionary strategies.",
        "Propose a memory architecture inspired by the prefrontal cortex.",
        "Design an AI that explains its reasoning like a teacher.",
        "Imagine a search engine powered by hyperdimensional computing.",
        "Design a self-healing distributed system inspired by immune networks.",
        "Propose a novel tokenizer that captures semantic units.",
        "Design an AI writing assistant that preserves author voice.",
        "Imagine a GPU scheduler inspired by biological neural circuits.",
        "Design a privacy-preserving AI that learns from encrypted data.",
        "Propose a benchmark suite for measuring AI common sense.",
        "Design an AI that can transfer skills between modalities.",
        "Imagine a collaborative canvas where humans and AIs co-create art.",
        "Design a recommendation system based on curiosity, not clicks.",
        "Propose an architecture that unifies language and vision reasoning.",
        "Design a federated learning system for edge GPU devices.",
        "Imagine a programming language where types are neural concepts.",
        "Design an AI tutor that identifies knowledge gaps automatically.",
        "Propose a new attention pattern inspired by biological vision.",
        "Design a model compression technique that preserves reasoning ability.",
        "Imagine an AI that generates hardware-optimal neural architectures.",
        "Design a conversational AI with true episodic memory.",
        "Propose a training method that makes LLMs more calibrated.",
        "Design an AI agent that learns from watching human developers.",
        "Imagine a compute fabric that dynamically reshapes for workloads.",
        "Design a neural network visualization that reveals learned concepts.",
    ],
    "instruction": [
        "Convert this JSON API response into Python dataclasses with validation.",
        "Summarize the key differences between REST and GraphQL APIs.",
        "Set up a new Python project with proper packaging and CI.",
        "Rewrite this paragraph to be more concise and technical.",
        "Extract all function signatures from this Python module.",
        "Classify these error messages by severity and category.",
        "Create a markdown table comparing 5 database technologies.",
        "Convert this Python script to TypeScript with proper types.",
        "Identify anti-patterns in this codebase and suggest fixes.",
        "Write a one-paragraph summary of the transformers architecture.",
        "Convert these requirements into user stories with acceptance criteria.",
        "Write a systemd service file for deploying a Python web app.",
        "Parse these log files and extract error patterns.",
        "Refactor this synchronous code to use async/await.",
        "Categorize these Python libraries by domain and maturity.",
        "Write a Dockerfile for a multi-stage Python build.",
        "Convert this config file from YAML to TOML format.",
        "Create API documentation from these function signatures.",
        "Write a migration script for database schema changes.",
        "Generate a project README from the codebase structure.",
        "Create a changelog entry from these git commits.",
        "Write pre-commit hooks for linting and formatting.",
        "Convert this Makefile to a pyproject.toml build config.",
        "Create a monitoring dashboard spec from these metrics.",
        "Write a runbook for common production incidents.",
        "Generate TypeScript interfaces from this Python API.",
        "Create a security audit checklist for this web application.",
        "Write a performance testing plan for this API.",
        "Convert these manual testing steps to automated tests.",
        "Create a data model diagram from these SQL tables.",
        "Write a technical specification from these requirements.",
        "Generate OpenAPI spec from these Flask routes.",
        "Create a dependency update plan for this project.",
        "Write environment setup instructions for new developers.",
        "Convert these Python type annotations to JSON Schema.",
        "Create a rollback plan for this database migration.",
        "Write a load testing script using locust.",
        "Generate test fixtures from these API response examples.",
        "Create a feature flag configuration for gradual rollout.",
        "Write a terraform config for deploying to AWS.",
        "Create a CI/CD pipeline configuration for GitHub Actions.",
        "Write a backup and restore procedure for this database.",
        "Generate mock data generators from these schema definitions.",
        "Create an incident response template.",
        "Write a capacity planning document for this service.",
        "Convert this monolithic app into a service architecture plan.",
        "Create a code style guide from the existing codebase patterns.",
        "Write a zero-downtime deployment strategy.",
        "Generate a compliance checklist from these regulations.",
        "Create a technical debt assessment with prioritized fixes.",
    ],
}


class PromptGenerator:
    """Generate diverse prompts for distillation training.

    Increases seed prompts from 15 to 50 per domain.
    Supports prompts_per_domain up to 500 (2,000 total samples).

    Args:
        prompts_per_domain: Number of prompts to generate per domain.
        domains: List of domain names (default: all 4).
        temperature: Teacher inference temperature for diversity.
    """

    def __init__(
        self,
        prompts_per_domain: int = 500,
        domains: list[str] | None = None,
        temperature: float = 0.8,
    ):
        self.prompts_per_domain = prompts_per_domain
        self.domains = domains or list(SEED_PROMPTS.keys())
        self.temperature = temperature

    def generate(self) -> dict[str, list[str]]:
        """Generate prompts for all domains.

        Cycles through seed prompts, adding diversity via:
        - Random suffix variations
        - Context-specific modifications
        - Cross-domain combinations

        Returns:
            Dict mapping domain names to prompt lists.
        """
        all_prompts = {}

        for domain in self.domains:
            seeds = SEED_PROMPTS.get(domain, [])
            if not seeds:
                logger.warning("No seed prompts for domain: %s", domain)
                continue

            prompts = []
            for i in range(self.prompts_per_domain):
                seed = seeds[i % len(seeds)]

                if i < len(seeds):
                    # Use seed prompts directly first
                    prompts.append(seed)
                else:
                    # Add variations
                    variation = self._vary_prompt(seed, i)
                    prompts.append(variation)

            all_prompts[domain] = prompts
            logger.info("Generated %d prompts for domain: %s", len(prompts), domain)

        total = sum(len(p) for p in all_prompts.values())
        logger.info("Total prompts generated: %d across %d domains", total, len(all_prompts))
        return all_prompts

    def _vary_prompt(self, seed: str, index: int) -> str:
        """Create a variation of a seed prompt."""
        variations = [
            lambda s: f"{s} Provide a detailed explanation.",
            lambda s: f"{s} Include code examples.",
            lambda s: f"{s} Compare at least 3 approaches.",
            lambda s: f"{s} Focus on performance implications.",
            lambda s: f"{s} Consider edge cases.",
            lambda s: f"Given a production system, {s.lower()}",
            lambda s: f"For a beginner audience, {s.lower()}",
            lambda s: f"In the context of machine learning, {s.lower()}",
            lambda s: f"Step by step, {s.lower()}",
            lambda s: f"With real-world examples, {s.lower()}",
        ]

        variation_fn = variations[index % len(variations)]
        return variation_fn(seed)

    def generate_flat(self) -> list[tuple[str, str]]:
        """Generate all prompts as flat list of (domain, prompt) tuples."""
        all_prompts = self.generate()
        flat = []
        for domain, prompts in all_prompts.items():
            for prompt in prompts:
                flat.append((domain, prompt))
        random.shuffle(flat)
        return flat
