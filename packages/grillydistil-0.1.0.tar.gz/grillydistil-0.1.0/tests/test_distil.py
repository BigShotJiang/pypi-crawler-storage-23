"""Tests for GrillyDistil: temperature scheduling, distillation trainer, and prompt generation."""

from __future__ import annotations

import math
import random

import numpy as np
import pytest

from grillydistil.temperature import SAKDTemperature, LinearAnnealing
from grillydistil.trainer import DistillationTrainer, _kl_divergence
from grillydistil.prompts import PromptGenerator, SEED_PROMPTS


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _seed_rng():
    """Pin all RNGs so tests are deterministic."""
    np.random.seed(42)
    random.seed(42)


class _MockModel:
    """Minimal mock model that returns fixed-shape random logits."""

    def __init__(self, vocab_size: int = 32, seq_len: int = 8):
        self.vocab_size = vocab_size
        self.seq_len = seq_len

    def forward(self, input_ids: np.ndarray) -> np.ndarray:
        batch = input_ids.shape[0]
        return np.random.randn(batch, self.seq_len, self.vocab_size).astype(np.float32)


# ===========================================================================
# 1. TestSAKDTemperature
# ===========================================================================

class TestSAKDTemperature:
    """Tests for the simulated-annealing adaptive temperature scheduler."""

    def test_initial_temperature_default(self):
        """Default T_init should be 8.0."""
        sched = SAKDTemperature()
        assert sched.current_temperature == 8.0

    def test_initial_temperature_custom(self):
        """Custom T_init should be respected."""
        sched = SAKDTemperature(T_init=5.0)
        assert sched.current_temperature == 5.0

    def test_step_returns_temperature(self):
        """step() must return a float temperature value."""
        sched = SAKDTemperature()
        result = sched.step(validation_loss=1.0)
        assert isinstance(result, (float, np.floating))

    def test_temperature_changes_with_losses(self):
        """Temperature should differ after steps with varying losses."""
        sched = SAKDTemperature()
        temps = []
        for loss in [5.0, 3.0, 4.5, 2.0, 1.0, 0.5, 3.0, 1.5]:
            t = sched.step(loss)
            temps.append(t)
        # With varying losses the schedule should not stay perfectly constant.
        assert len(set(round(t, 6) for t in temps)) > 1

    def test_cooling_over_many_steps(self):
        """SA temperature T_sa should decay, reducing acceptance of bad moves."""
        sched = SAKDTemperature(T_init=10.0, T_sa_init=5.0, alpha=0.97)
        initial_t_sa = sched.T_sa
        for _ in range(200):
            sched.step(validation_loss=np.random.uniform(0.5, 2.0))
        # T_sa must have cooled substantially
        assert sched.T_sa < initial_t_sa * 0.5

    def test_metropolis_accepts_worse_solutions(self):
        """At high T_sa the algorithm should sometimes accept worse solutions."""
        # High SA temperature -> high acceptance probability
        sched = SAKDTemperature(T_init=8.0, T_sa_init=100.0, alpha=1.0)
        # Give a very good loss first, then many bad losses
        sched.step(validation_loss=0.01)
        accepts_before = sched._accept_count
        for _ in range(100):
            sched.step(validation_loss=10.0)
        # With T_sa=100, exp(-dE/100) is close to 1 so nearly all should be accepted
        new_accepts = sched._accept_count - accepts_before
        assert new_accepts > 50, (
            f"Expected most proposals accepted at high T_sa, got {new_accepts}/100"
        )

    def test_get_stats_keys(self):
        """get_stats() should contain all expected keys."""
        sched = SAKDTemperature()
        sched.step(validation_loss=1.0)
        stats = sched.get_stats()
        expected_keys = {"current_T", "best_T", "best_loss", "T_sa", "steps", "accept_rate"}
        assert expected_keys == set(stats.keys())

    def test_temperature_bounded(self):
        """Temperature must stay within [T_min, T_max]."""
        sched = SAKDTemperature(T_min=2.0, T_max=15.0, perturbation_scale=50.0)
        for _ in range(300):
            t = sched.step(validation_loss=np.random.uniform(0, 5))
            assert 2.0 <= t <= 15.0


# ===========================================================================
# 2. TestLinearAnnealing
# ===========================================================================

class TestLinearAnnealing:
    """Tests for the linear temperature annealing fallback."""

    def test_initial_temperature(self):
        """First step should return a temperature near T_start."""
        sched = LinearAnnealing(T_start=8.0, T_end=2.0, total_steps=1000)
        t = sched.step()
        # After 1 step out of 300 warmup steps: T_start + (T_end-T_start)*(1/300)
        expected = 8.0 + (2.0 - 8.0) * (1 / 300)
        assert pytest.approx(t, abs=1e-4) == expected

    def test_final_temperature(self):
        """At 100% progress, temperature should equal T_end."""
        sched = LinearAnnealing(T_start=8.0, T_end=2.0, total_steps=100)
        for _ in range(100):
            t = sched.step()
        assert pytest.approx(t, abs=1e-6) == 2.0

    def test_midpoint_temperature(self):
        """At 50% of warmup, temperature should be halfway between T_start and T_end."""
        total = 1000
        warmup_steps = int(total * 0.3)  # 300
        sched = LinearAnnealing(T_start=8.0, T_end=2.0, total_steps=total)
        # Step to the midpoint of the warmup region (step 150)
        for _ in range(warmup_steps // 2):
            t = sched.step()
        expected = 8.0 + (2.0 - 8.0) * (warmup_steps // 2 / warmup_steps)
        assert pytest.approx(t, abs=1e-4) == expected

    def test_temperature_at_warmup_boundary(self):
        """At exactly 30% (end of warmup), temperature should equal T_end."""
        total = 1000
        warmup_steps = int(total * 0.3)  # 300
        sched = LinearAnnealing(T_start=8.0, T_end=2.0, total_steps=total)
        for _ in range(warmup_steps):
            t = sched.step()
        # progress = 300/300 = 1.0 -> T = 8 + (2-8)*1 = 2.0
        assert pytest.approx(t, abs=1e-6) == 2.0

    def test_temperature_after_warmup_stays_constant(self):
        """After warmup (>30%), temperature should stay at T_end."""
        total = 100
        sched = LinearAnnealing(T_start=8.0, T_end=2.0, total_steps=total)
        temps_after_warmup = []
        for i in range(total):
            t = sched.step()
            if i >= int(total * 0.3):
                temps_after_warmup.append(t)
        assert all(pytest.approx(t, abs=1e-6) == 2.0 for t in temps_after_warmup)

    def test_current_temperature_property(self):
        """current_temperature property should agree with the last returned step() value."""
        sched = LinearAnnealing(T_start=10.0, T_end=3.0, total_steps=500)
        for _ in range(50):
            last_t = sched.step()
        # After stepping, the property should reflect the same internal step
        assert pytest.approx(sched.current_temperature, abs=1e-6) == last_t


# ===========================================================================
# 3. TestDistillationTrainer
# ===========================================================================

class TestDistillationTrainer:
    """Tests for the knowledge distillation trainer."""

    def test_initialization_sakd_mode(self):
        """Trainer should initialize with SAKDTemperature in 'sakd' mode."""
        student = _MockModel()
        teacher = _MockModel()
        trainer = DistillationTrainer(
            student_model=student,
            teacher_model=teacher,
            temperature_mode="sakd",
        )
        assert isinstance(trainer.temperature, SAKDTemperature)
        assert trainer.alpha_ce == 0.5
        assert trainer.alpha_kd == 0.5

    def test_initialization_linear_mode(self):
        """Trainer should initialize with LinearAnnealing in 'linear' mode."""
        student = _MockModel()
        trainer = DistillationTrainer(
            student_model=student,
            temperature_mode="linear",
        )
        assert isinstance(trainer.temperature, LinearAnnealing)

    def test_kl_divergence_identical_logits(self):
        """KL divergence between identical logits should be near zero."""
        logits = np.array([[2.0, 1.0, 0.5, -1.0]])
        kl = _kl_divergence(logits, logits, temperature=4.0)
        assert pytest.approx(kl, abs=1e-6) == 0.0

    def test_kl_divergence_known_values(self):
        """KL divergence with known logits should be positive and finite."""
        teacher_logits = np.array([[2.0, 1.0, 0.1]])
        student_logits = np.array([[0.5, 0.5, 0.5]])
        kl = _kl_divergence(student_logits, teacher_logits, temperature=4.0)
        assert kl > 0.0
        assert np.isfinite(kl)

    def test_kl_divergence_temperature_scaling(self):
        """Higher temperature should change the KL magnitude (T^2 factor)."""
        teacher_logits = np.array([[3.0, 1.0, -1.0]])
        student_logits = np.array([[1.0, 1.0, 1.0]])
        kl_low_T = _kl_divergence(student_logits, teacher_logits, temperature=1.0)
        kl_high_T = _kl_divergence(student_logits, teacher_logits, temperature=8.0)
        # Both should be positive
        assert kl_low_T > 0.0
        assert kl_high_T > 0.0
        # They should differ due to the T^2 scaling and softmax flattening
        assert kl_low_T != pytest.approx(kl_high_T, abs=1e-4)

    def test_combined_loss_weights(self):
        """Total loss = alpha_ce * CE + alpha_kd * KD with supplied logits."""
        student = _MockModel(vocab_size=10, seq_len=4)
        trainer = DistillationTrainer(
            student_model=student,
            teacher_model=None,
            temperature_mode="linear",
            alpha_ce=0.3,
            alpha_kd=0.7,
        )
        input_ids = np.zeros((2, 4), dtype=np.int64)
        teacher_logits = np.random.randn(2, 4, 10).astype(np.float32)
        labels = np.random.randint(0, 10, size=(2, 4)).astype(np.int64)

        result = trainer.train_step(input_ids, teacher_logits=teacher_logits, labels=labels)

        # Verify structural keys
        assert "loss" in result
        assert "kd_loss" in result
        assert "ce_loss" in result
        assert "temperature" in result
        assert "step" in result

        # Verify combined loss relationship
        expected_total = 0.7 * result["kd_loss"] + 0.3 * result["ce_loss"]
        assert pytest.approx(result["loss"], abs=1e-6) == expected_total

    def test_train_step_kd_only(self):
        """With no labels, CE loss should be zero; total = alpha_kd * KD."""
        student = _MockModel(vocab_size=10, seq_len=4)
        trainer = DistillationTrainer(
            student_model=student,
            temperature_mode="linear",
            alpha_ce=0.5,
            alpha_kd=0.5,
        )
        input_ids = np.zeros((1, 4), dtype=np.int64)
        teacher_logits = np.random.randn(1, 4, 10).astype(np.float32)

        result = trainer.train_step(input_ids, teacher_logits=teacher_logits, labels=None)
        assert result["ce_loss"] == 0.0
        assert pytest.approx(result["loss"], abs=1e-8) == 0.5 * result["kd_loss"]

    def test_train_step_increments_step(self):
        """Each call to train_step should increment the internal step counter."""
        student = _MockModel(vocab_size=10, seq_len=4)
        trainer = DistillationTrainer(student_model=student, temperature_mode="linear")
        input_ids = np.zeros((1, 4), dtype=np.int64)
        teacher_logits = np.random.randn(1, 4, 10).astype(np.float32)

        trainer.train_step(input_ids, teacher_logits=teacher_logits)
        trainer.train_step(input_ids, teacher_logits=teacher_logits)
        assert trainer._step == 2

    def test_temperature_scaling_effect(self):
        """Higher temperature should flatten softmax, changing KL magnitude."""
        teacher = np.array([[5.0, 0.0, -5.0]])
        student = np.array([[0.0, 0.0, 0.0]])

        kl_t1 = _kl_divergence(student, teacher, temperature=1.0)
        kl_t10 = _kl_divergence(student, teacher, temperature=10.0)

        # At T=1 the teacher distribution is very peaked, creating large KL.
        # At T=10 the teacher is flattened; KL(p||q) * T^2 may be larger or
        # smaller depending on the balance, but they must differ meaningfully.
        assert abs(kl_t1 - kl_t10) > 0.01


# ===========================================================================
# 4. TestPromptGenerator
# ===========================================================================

class TestPromptGenerator:
    """Tests for the domain-specific prompt generator."""

    def test_init_creates_all_domains(self):
        """Default init should include all 4 domains."""
        gen = PromptGenerator()
        assert set(gen.domains) == {"code", "reasoning", "creative", "instruction"}

    def test_generate_prompt_count(self):
        """generate() should produce prompts_per_domain prompts for each domain."""
        gen = PromptGenerator(prompts_per_domain=60)
        result = gen.generate()
        for domain in gen.domains:
            assert len(result[domain]) == 60

    def test_generated_prompts_are_strings(self):
        """Every generated prompt must be a str."""
        gen = PromptGenerator(prompts_per_domain=20)
        result = gen.generate()
        for domain, prompts in result.items():
            for p in prompts:
                assert isinstance(p, str), f"Non-string prompt in {domain}: {type(p)}"

    def test_prompts_per_domain_parameter(self):
        """prompts_per_domain controls the count for each domain."""
        for count in [1, 10, 100]:
            gen = PromptGenerator(prompts_per_domain=count)
            result = gen.generate()
            for domain in gen.domains:
                assert len(result[domain]) == count

    def test_all_domains_have_seed_prompts(self):
        """SEED_PROMPTS should contain entries for all 4 expected domains."""
        expected = {"code", "reasoning", "creative", "instruction"}
        assert expected == set(SEED_PROMPTS.keys())
        for domain in expected:
            assert len(SEED_PROMPTS[domain]) > 0, f"No seed prompts for {domain}"

    def test_get_domain_prompts(self):
        """generate() result, indexed by domain, returns only that domain's prompts."""
        gen = PromptGenerator(prompts_per_domain=30)
        result = gen.generate()

        code_prompts = result["code"]
        reasoning_prompts = result["reasoning"]

        # Each set should have the right count
        assert len(code_prompts) == 30
        assert len(reasoning_prompts) == 30

        # First N prompts (where N = len(seeds)) come directly from seeds
        code_seeds = SEED_PROMPTS["code"]
        for i in range(min(30, len(code_seeds))):
            assert code_prompts[i] == code_seeds[i]

    def test_generate_flat_produces_tuples(self):
        """generate_flat() should produce (domain, prompt) tuples."""
        gen = PromptGenerator(prompts_per_domain=10)
        flat = gen.generate_flat()
        assert len(flat) == 10 * 4  # 4 domains
        for domain, prompt in flat:
            assert domain in gen.domains
            assert isinstance(prompt, str)

    def test_variations_generated_beyond_seeds(self):
        """When prompts_per_domain > seed count, variations should be generated."""
        gen = PromptGenerator(prompts_per_domain=100)
        result = gen.generate()
        code_seeds = SEED_PROMPTS["code"]
        code_prompts = result["code"]

        # Prompts beyond the seed count should be variations, not raw seeds
        for i in range(len(code_seeds), 100):
            prompt = code_prompts[i]
            # Variations either append a suffix or prepend a prefix to the seed
            seed = code_seeds[i % len(code_seeds)]
            assert seed in prompt or seed.lower() in prompt.lower(), (
                f"Variation at index {i} does not contain seed text"
            )

    def test_custom_domain_subset(self):
        """Generator should work with a subset of domains."""
        gen = PromptGenerator(prompts_per_domain=5, domains=["code", "reasoning"])
        result = gen.generate()
        assert set(result.keys()) == {"code", "reasoning"}
        assert "creative" not in result
