"""GPU integration tests for GrillyDistil.

Tests the distillation pipeline with actual GPU-accelerated computation via
the grilly Vulkan backend. Uses tiny dimensions (hidden=32-64, vocab=128-256,
seq=8-16, 1-2 layers) with random weights -- no real model downloads.
"""

from __future__ import annotations

import math
import random

import numpy as np
import pytest

try:
    import grilly
    VULKAN_AVAILABLE = grilly.VULKAN_AVAILABLE
except Exception:
    VULKAN_AVAILABLE = False

try:
    import grillyinference
    INFERENCE_AVAILABLE = True
except Exception:
    INFERENCE_AVAILABLE = False

from grillydistil.temperature import SAKDTemperature, LinearAnnealing
from grillydistil.trainer import DistillationTrainer, _kl_divergence
from grillydistil.prompts import PromptGenerator, SEED_PROMPTS

pytestmark = [
    pytest.mark.gpu,
    pytest.mark.skipif(not VULKAN_AVAILABLE, reason="Vulkan not available"),
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _seed_rng():
    """Pin RNGs for deterministic tests."""
    np.random.seed(123)
    random.seed(123)


def _gpu_softmax(logits: np.ndarray, temperature: float = 1.0) -> np.ndarray:
    """Compute softmax on GPU via grilly.Compute().activation_softmax."""
    compute = grilly.Compute()
    scaled = (logits.astype(np.float64) / temperature).astype(np.float32)
    result = compute.activation_softmax(scaled)
    return np.asarray(result, dtype=np.float64)


def _cpu_softmax(logits: np.ndarray, temperature: float = 1.0) -> np.ndarray:
    """Reference CPU softmax in float64."""
    x = logits.astype(np.float64) / temperature
    x_max = np.max(x, axis=-1, keepdims=True)
    exp_x = np.exp(x - x_max)
    return exp_x / np.sum(exp_x, axis=-1, keepdims=True)


class _GPUModel:
    """Tiny model that runs a GPU forward pass: embed -> linear -> output logits.

    Architecture:
        - Embedding table: (vocab_size, hidden_dim)
        - Hidden linear: (hidden_dim, hidden_dim)  [optional extra layers]
        - Output head: (hidden_dim, vocab_size)      -- transposed for Compute.linear

    Uses grilly.Compute() for matmul (linear) and activation on the GPU.
    """

    def __init__(
        self,
        vocab_size: int = 128,
        hidden_dim: int = 32,
        seq_len: int = 8,
        n_layers: int = 1,
    ):
        self.vocab_size = vocab_size
        self.hidden_dim = hidden_dim
        self.seq_len = seq_len
        self.n_layers = n_layers
        self._compute = grilly.Compute()

        # Random weights (xavier-ish scale)
        scale = 1.0 / math.sqrt(hidden_dim)
        self.embed = np.random.randn(vocab_size, hidden_dim).astype(np.float32) * scale
        self.layers = []
        for _ in range(n_layers):
            w = np.random.randn(hidden_dim, hidden_dim).astype(np.float32) * scale
            b = np.zeros(hidden_dim, dtype=np.float32)
            self.layers.append((w, b))
        # Output head: (vocab_size, hidden_dim) for Compute.linear convention
        self.head_w = np.random.randn(vocab_size, hidden_dim).astype(np.float32) * scale
        self.head_b = np.zeros(vocab_size, dtype=np.float32)

    def forward(self, input_ids: np.ndarray) -> np.ndarray:
        """Forward pass returning (batch, seq_len, vocab_size) logits."""
        batch = input_ids.shape[0]
        seq = input_ids.shape[1] if input_ids.ndim > 1 else self.seq_len

        # Embedding lookup (CPU -- simple indexing)
        ids_clipped = np.clip(input_ids, 0, self.vocab_size - 1)
        h = self.embed[ids_clipped]  # (batch, seq, hidden)

        # Reshape for 2D matmul: (batch*seq, hidden)
        h_flat = h.reshape(-1, self.hidden_dim)

        # Hidden layers on GPU
        for w, b in self.layers:
            h_flat = np.asarray(
                self._compute.linear(h_flat, w, b), dtype=np.float32
            )
            # ReLU activation
            h_flat = np.maximum(h_flat, 0.0)

        # Output projection on GPU
        logits_flat = np.asarray(
            self._compute.linear(h_flat, self.head_w, self.head_b),
            dtype=np.float32,
        )

        return logits_flat.reshape(batch, seq, self.vocab_size)


# ===========================================================================
# 1. TestKLDivergenceGPU
# ===========================================================================

class TestKLDivergenceGPU:
    """Test KL divergence computation with GPU softmax tensors."""

    @pytest.mark.parametrize("temperature", [1.0, 4.0, 8.0])
    def test_gpu_softmax_matches_cpu(self, temperature):
        """GPU softmax should closely match the CPU reference at each temperature."""
        logits = np.random.randn(4, 16).astype(np.float32)
        gpu_result = _gpu_softmax(logits, temperature)
        cpu_result = _cpu_softmax(logits, temperature)
        np.testing.assert_allclose(gpu_result, cpu_result, atol=1e-5, rtol=1e-5)

    @pytest.mark.parametrize("temperature", [1.0, 4.0, 8.0])
    def test_kl_div_gpu_vs_cpu_reference(self, temperature):
        """KL divergence computed with GPU softmax should match CPU reference."""
        teacher_logits = np.random.randn(2, 64).astype(np.float32)
        student_logits = np.random.randn(2, 64).astype(np.float32)

        # CPU reference via trainer._kl_divergence
        kl_cpu = _kl_divergence(student_logits, teacher_logits, temperature)

        # GPU path: manually compute KL using GPU softmax
        p = _gpu_softmax(teacher_logits, temperature)
        q = _gpu_softmax(student_logits, temperature)
        kl_gpu = float(np.mean(
            np.sum(p * (np.log(p + 1e-10) - np.log(q + 1e-10)), axis=-1)
        )) * temperature ** 2

        assert np.isfinite(kl_gpu)
        assert np.isfinite(kl_cpu)
        np.testing.assert_allclose(kl_gpu, kl_cpu, atol=1e-4, rtol=1e-4)

    def test_kl_div_identical_logits_near_zero(self):
        """KL divergence of identical logits should be approximately zero."""
        logits = np.random.randn(4, 32).astype(np.float32)
        kl = _kl_divergence(logits, logits, temperature=4.0)
        assert abs(kl) < 1e-6

    def test_kl_div_identical_logits_gpu_softmax_near_zero(self):
        """KL divergence from GPU softmax on identical logits should be near zero."""
        logits = np.random.randn(4, 32).astype(np.float32)
        p = _gpu_softmax(logits, 4.0)
        q = _gpu_softmax(logits, 4.0)
        kl = float(np.mean(np.sum(p * (np.log(p + 1e-10) - np.log(q + 1e-10)), axis=-1)))
        assert abs(kl) < 1e-6

    def test_kl_div_symmetry_property(self):
        """KL(P||Q) and KL(Q||P) should both be non-negative but generally differ."""
        a = np.random.randn(2, 16).astype(np.float32)
        b = np.random.randn(2, 16).astype(np.float32)

        kl_ab = _kl_divergence(a, b, temperature=4.0)
        kl_ba = _kl_divergence(b, a, temperature=4.0)

        assert kl_ab >= -1e-6, "KL(P||Q) must be non-negative"
        assert kl_ba >= -1e-6, "KL(Q||P) must be non-negative"
        # KL divergence is generally asymmetric
        assert kl_ab != pytest.approx(kl_ba, abs=1e-3), (
            "KL should be asymmetric for different distributions"
        )

    def test_kl_div_3d_logits_on_gpu(self):
        """KL divergence should work with 3D (batch, seq, vocab) logits."""
        teacher = np.random.randn(2, 8, 64).astype(np.float32)
        student = np.random.randn(2, 8, 64).astype(np.float32)
        kl = _kl_divergence(student, teacher, temperature=4.0)
        assert np.isfinite(kl)
        assert kl > 0.0

    def test_gpu_softmax_sums_to_one(self):
        """GPU softmax output should sum to 1 along the last axis."""
        logits = np.random.randn(4, 128).astype(np.float32)
        probs = _gpu_softmax(logits, temperature=2.0)
        row_sums = np.sum(probs, axis=-1)
        np.testing.assert_allclose(row_sums, 1.0, atol=1e-5)

    def test_gpu_softmax_3d_sums_to_one(self):
        """GPU softmax on 3D input should sum to 1 along last axis."""
        logits = np.random.randn(2, 8, 64).astype(np.float32)
        probs = _gpu_softmax(logits, temperature=4.0)
        sums = np.sum(probs, axis=-1)
        np.testing.assert_allclose(sums, 1.0, atol=1e-5)


# ===========================================================================
# 2. TestDistillationTrainerGPU
# ===========================================================================

class TestDistillationTrainerGPU:
    """Test training step with GPU models."""

    def _make_trainer(self, mode="sakd", vocab=128, hidden=32, seq=8,
                      teacher_layers=2, student_layers=1):
        teacher = _GPUModel(vocab_size=vocab, hidden_dim=hidden,
                            seq_len=seq, n_layers=teacher_layers)
        student = _GPUModel(vocab_size=vocab, hidden_dim=hidden,
                            seq_len=seq, n_layers=student_layers)
        return DistillationTrainer(
            student_model=student,
            teacher_model=teacher,
            temperature_mode=mode,
        )

    def test_train_step_produces_finite_loss(self):
        """A single train_step with GPU models should produce finite loss."""
        trainer = self._make_trainer()
        input_ids = np.random.randint(0, 128, size=(2, 8), dtype=np.int64)
        result = trainer.train_step(input_ids)
        assert np.isfinite(result["loss"]), f"Loss is not finite: {result['loss']}"
        assert np.isfinite(result["kd_loss"])

    def test_train_step_loss_keys(self):
        """train_step result should contain all expected keys."""
        trainer = self._make_trainer()
        input_ids = np.random.randint(0, 128, size=(1, 8), dtype=np.int64)
        result = trainer.train_step(input_ids)
        expected = {"loss", "kd_loss", "ce_loss", "temperature", "step"}
        assert expected == set(result.keys())

    def test_train_step_with_labels_ce_loss(self):
        """With labels provided, CE loss should be positive and finite."""
        trainer = self._make_trainer()
        input_ids = np.random.randint(0, 128, size=(2, 8), dtype=np.int64)
        labels = np.random.randint(0, 128, size=(2, 8), dtype=np.int64)
        result = trainer.train_step(input_ids, labels=labels)
        assert result["ce_loss"] > 0.0, "CE loss should be positive with random logits"
        assert np.isfinite(result["ce_loss"])
        assert np.isfinite(result["loss"])

    def test_temperature_annealing_sakd_across_steps(self):
        """SAKD temperature should change across multiple steps."""
        trainer = self._make_trainer(mode="sakd")
        input_ids = np.random.randint(0, 128, size=(2, 8), dtype=np.int64)
        temps = []
        for _ in range(20):
            result = trainer.train_step(input_ids)
            temps.append(result["temperature"])
        # Temperature should not remain perfectly constant across 20 steps
        unique_temps = set(round(t, 6) for t in temps)
        assert len(unique_temps) > 1, "Temperature should vary with SAKD"

    def test_temperature_annealing_linear_across_steps(self):
        """Linear annealing temperature should monotonically decrease during warmup."""
        trainer = self._make_trainer(mode="linear")
        input_ids = np.random.randint(0, 128, size=(2, 8), dtype=np.int64)
        temps = []
        for _ in range(10):
            result = trainer.train_step(input_ids)
            temps.append(result["temperature"])
        # Linear annealing: T_start=8 -> T_end=2, should decrease
        for i in range(1, len(temps)):
            assert temps[i] <= temps[i - 1] + 1e-6, (
                f"Linear annealing should decrease: step {i}: {temps[i]} > {temps[i-1]}"
            )

    def test_combined_ce_kd_loss(self):
        """Total loss = alpha_kd * kd_loss + alpha_ce * ce_loss with GPU models."""
        student = _GPUModel(vocab_size=128, hidden_dim=32, seq_len=8, n_layers=1)
        teacher = _GPUModel(vocab_size=128, hidden_dim=32, seq_len=8, n_layers=2)
        trainer = DistillationTrainer(
            student_model=student,
            teacher_model=teacher,
            temperature_mode="linear",
            alpha_ce=0.3,
            alpha_kd=0.7,
        )
        input_ids = np.random.randint(0, 128, size=(2, 8), dtype=np.int64)
        labels = np.random.randint(0, 128, size=(2, 8), dtype=np.int64)
        result = trainer.train_step(input_ids, labels=labels)

        expected_total = 0.7 * result["kd_loss"] + 0.3 * result["ce_loss"]
        assert pytest.approx(result["loss"], abs=1e-6) == expected_total

    def test_multiple_steps_step_counter(self):
        """Step counter should increment correctly across GPU train steps."""
        trainer = self._make_trainer()
        input_ids = np.random.randint(0, 128, size=(1, 8), dtype=np.int64)
        for i in range(5):
            result = trainer.train_step(input_ids)
            assert result["step"] == i + 1

    def test_kd_only_no_labels(self):
        """Without labels, CE loss should be zero; total = alpha_kd * kd_loss."""
        trainer = self._make_trainer()
        input_ids = np.random.randint(0, 128, size=(2, 8), dtype=np.int64)
        result = trainer.train_step(input_ids, labels=None)
        assert result["ce_loss"] == 0.0
        assert pytest.approx(result["loss"], abs=1e-8) == 0.5 * result["kd_loss"]


# ===========================================================================
# 3. TestSAKDTemperatureGPU
# ===========================================================================

class TestSAKDTemperatureGPU:
    """Test SA-KD temperature with actual loss values from GPU forward passes."""

    def _get_gpu_loss(self, model, input_ids):
        """Run a GPU forward pass and compute a scalar loss (mean abs logits)."""
        logits = model.forward(input_ids)
        # Use mean absolute logit as a proxy "loss"
        return float(np.mean(np.abs(logits)))

    def test_sakd_with_real_gpu_losses(self):
        """Feed actual GPU forward pass losses into SAKDTemperature."""
        model = _GPUModel(vocab_size=128, hidden_dim=32, seq_len=8, n_layers=1)
        sched = SAKDTemperature(T_init=8.0, T_sa_init=5.0, alpha=0.97)

        input_ids = np.random.randint(0, 128, size=(2, 8), dtype=np.int64)
        for _ in range(50):
            loss = self._get_gpu_loss(model, input_ids)
            t = sched.step(loss)
            assert np.isfinite(t), "Temperature must be finite"
            assert sched.T_min <= t <= sched.T_max

    def test_sakd_temperature_adapts_with_decreasing_losses(self):
        """When losses consistently decrease, temperature should adapt."""
        sched = SAKDTemperature(T_init=8.0, T_sa_init=5.0)
        model = _GPUModel(vocab_size=128, hidden_dim=32, seq_len=8, n_layers=1)

        input_ids = np.random.randint(0, 128, size=(2, 8), dtype=np.int64)
        # Simulate decreasing losses
        base_loss = self._get_gpu_loss(model, input_ids)
        initial_T = sched.current_temperature

        for i in range(30):
            # Artificially decrease loss over time
            loss = base_loss * (1.0 - i * 0.02)
            sched.step(loss)

        # After many improving steps, best_loss should be lower than initial
        assert sched._best_loss < base_loss

    def test_metropolis_acceptance_with_real_losses(self):
        """Metropolis acceptance should work with actual GPU loss landscape."""
        sched = SAKDTemperature(
            T_init=8.0, T_sa_init=10.0, alpha=1.0, perturbation_scale=1.0,
        )
        model = _GPUModel(vocab_size=128, hidden_dim=32, seq_len=8)

        input_ids = np.random.randint(0, 128, size=(4, 8), dtype=np.int64)
        for _ in range(100):
            loss = self._get_gpu_loss(model, input_ids)
            # Add some noise to simulate varying validation loss
            noisy_loss = loss + np.random.normal(0, 0.1)
            sched.step(noisy_loss)

        stats = sched.get_stats()
        assert stats["steps"] == 100
        # With high T_sa=10 and alpha=1 (no cooling), acceptance rate should be high
        assert stats["accept_rate"] > 0.3, (
            f"Acceptance rate too low: {stats['accept_rate']}"
        )

    def test_convergence_over_many_steps(self):
        """SA-KD should converge: T_sa should decrease, acceptance becomes selective."""
        sched = SAKDTemperature(
            T_init=8.0, T_sa_init=5.0, alpha=0.95, perturbation_scale=0.5,
        )
        model = _GPUModel(vocab_size=128, hidden_dim=32, seq_len=8)
        input_ids = np.random.randint(0, 128, size=(2, 8), dtype=np.int64)

        for _ in range(200):
            loss = self._get_gpu_loss(model, input_ids) + np.random.normal(0, 0.05)
            sched.step(loss)

        # T_sa should have cooled significantly: 5.0 * 0.95^200 ~ 0.00018
        assert sched.T_sa < 0.01, f"T_sa should have cooled: {sched.T_sa}"
        # History should be recorded
        assert len(sched._history) == 200

    def test_best_temperature_tracks_best_loss(self):
        """best_temperature should correspond to the step with lowest loss."""
        sched = SAKDTemperature(T_init=8.0, T_sa_init=5.0)
        model = _GPUModel(vocab_size=128, hidden_dim=32, seq_len=8)
        input_ids = np.random.randint(0, 128, size=(2, 8), dtype=np.int64)

        losses = []
        for _ in range(50):
            loss = self._get_gpu_loss(model, input_ids) + np.random.normal(0, 0.3)
            sched.step(loss)
            losses.append(loss)

        # best_loss should equal the minimum loss that was accepted
        assert sched._best_loss <= min(losses) + 1e-6


# ===========================================================================
# 4. TestDistillationIntegrationGPU
# ===========================================================================

class TestDistillationIntegrationGPU:
    """End-to-end GPU distillation test with tiny models."""

    def test_end_to_end_distillation_finite(self):
        """Full distillation run with GPU models should produce finite losses."""
        teacher = _GPUModel(vocab_size=128, hidden_dim=64, seq_len=8, n_layers=2)
        student = _GPUModel(vocab_size=128, hidden_dim=32, seq_len=8, n_layers=1)

        trainer = DistillationTrainer(
            student_model=student,
            teacher_model=teacher,
            temperature_mode="sakd",
            T_init=8.0,
            alpha_ce=0.5,
            alpha_kd=0.5,
        )

        for step in range(10):
            input_ids = np.random.randint(0, 128, size=(2, 8), dtype=np.int64)
            labels = np.random.randint(0, 128, size=(2, 8), dtype=np.int64)
            result = trainer.train_step(input_ids, labels=labels)

            assert np.isfinite(result["loss"]), f"Step {step}: loss not finite"
            assert np.isfinite(result["kd_loss"]), f"Step {step}: kd_loss not finite"
            assert np.isfinite(result["ce_loss"]), f"Step {step}: ce_loss not finite"
            assert np.isfinite(result["temperature"]), f"Step {step}: temp not finite"

    def test_temperature_adapts_across_distillation(self):
        """Temperature should adapt across an end-to-end distillation run."""
        teacher = _GPUModel(vocab_size=128, hidden_dim=64, seq_len=8, n_layers=2)
        student = _GPUModel(vocab_size=128, hidden_dim=32, seq_len=8, n_layers=1)

        trainer = DistillationTrainer(
            student_model=student,
            teacher_model=teacher,
            temperature_mode="sakd",
            T_init=8.0,
        )

        temps = []
        for _ in range(15):
            input_ids = np.random.randint(0, 128, size=(2, 8), dtype=np.int64)
            result = trainer.train_step(input_ids)
            temps.append(result["temperature"])

        unique_temps = set(round(t, 6) for t in temps)
        assert len(unique_temps) > 1, "Temperature should vary across steps"

    def test_teacher_student_kl_positive(self):
        """KL divergence between different teacher and student should be positive."""
        teacher = _GPUModel(vocab_size=256, hidden_dim=64, seq_len=16, n_layers=2)
        student = _GPUModel(vocab_size=256, hidden_dim=32, seq_len=16, n_layers=1)

        input_ids = np.random.randint(0, 256, size=(2, 16), dtype=np.int64)
        teacher_logits = teacher.forward(input_ids)
        student_logits = student.forward(input_ids)

        kl = _kl_divergence(student_logits, teacher_logits, temperature=4.0)
        assert kl > 0.0, "KL div between different models should be positive"
        assert np.isfinite(kl)

    def test_distillation_with_linear_annealing(self):
        """Distillation should work end-to-end with linear annealing mode."""
        teacher = _GPUModel(vocab_size=128, hidden_dim=64, seq_len=8, n_layers=2)
        student = _GPUModel(vocab_size=128, hidden_dim=32, seq_len=8, n_layers=1)

        trainer = DistillationTrainer(
            student_model=student,
            teacher_model=teacher,
            temperature_mode="linear",
            T_init=8.0,
        )

        assert isinstance(trainer.temperature, LinearAnnealing)

        for step in range(10):
            input_ids = np.random.randint(0, 128, size=(2, 8), dtype=np.int64)
            result = trainer.train_step(input_ids)
            assert np.isfinite(result["loss"])

        # Linear temp should have decreased from 8.0
        assert result["temperature"] < 8.0

    def test_train_method_full_loop(self):
        """The full train() loop should complete and return loss history."""
        teacher = _GPUModel(vocab_size=128, hidden_dim=32, seq_len=8, n_layers=1)
        student = _GPUModel(vocab_size=128, hidden_dim=32, seq_len=8, n_layers=1)

        trainer = DistillationTrainer(
            student_model=student,
            teacher_model=teacher,
            temperature_mode="linear",
            T_init=6.0,
        )

        # Build tiny dataset
        dataset = []
        for _ in range(8):
            ids = np.random.randint(0, 128, size=(8,), dtype=np.int64)
            teacher_logits = teacher.forward(ids.reshape(1, -1))[0]
            labels = np.random.randint(0, 128, size=(8,), dtype=np.int64)
            dataset.append({
                "input_ids": ids,
                "teacher_logits": teacher_logits,
                "labels": labels,
            })

        losses = trainer.train(dataset, epochs=2, batch_size=4)
        assert len(losses) > 0
        for entry in losses:
            assert np.isfinite(entry["loss"])

    def test_get_stats_after_gpu_training(self):
        """get_stats() should return valid statistics after GPU training."""
        teacher = _GPUModel(vocab_size=128, hidden_dim=32, seq_len=8)
        student = _GPUModel(vocab_size=128, hidden_dim=32, seq_len=8)
        trainer = DistillationTrainer(
            student_model=student,
            teacher_model=teacher,
            temperature_mode="sakd",
        )

        for _ in range(5):
            input_ids = np.random.randint(0, 128, size=(2, 8), dtype=np.int64)
            trainer.train_step(input_ids)

        stats = trainer.get_stats()
        assert stats["steps"] == 5
        assert np.isfinite(stats["avg_loss"])
        temp_stats = stats["temperature_stats"]
        assert "current_T" in temp_stats
        assert "best_T" in temp_stats
        assert "accept_rate" in temp_stats


# ===========================================================================
# 5. TestPromptDataGPU
# ===========================================================================

class TestPromptDataGPU:
    """Test prompt generation feeds into GPU pipeline."""

    @staticmethod
    def _mock_tokenize(prompt: str, vocab_size: int = 128, seq_len: int = 8):
        """Mock tokenizer: deterministic hash-based token IDs."""
        ids = []
        for i, ch in enumerate(prompt[:seq_len]):
            ids.append(ord(ch) % vocab_size)
        while len(ids) < seq_len:
            ids.append(0)
        return np.array(ids, dtype=np.int64)

    def test_prompt_to_tokens_to_gpu_logits(self):
        """Full pipeline: generate prompt -> tokenize -> GPU forward -> logits."""
        gen = PromptGenerator(prompts_per_domain=5, domains=["code"])
        prompts = gen.generate()["code"]
        assert len(prompts) == 5

        model = _GPUModel(vocab_size=128, hidden_dim=32, seq_len=8, n_layers=1)

        for prompt in prompts:
            tokens = self._mock_tokenize(prompt)
            logits = model.forward(tokens.reshape(1, -1))
            assert logits.shape == (1, 8, 128)
            assert np.all(np.isfinite(logits))

    def test_prompt_to_kl_loss(self):
        """Full pipeline: prompt -> tokens -> teacher/student GPU logits -> KL loss."""
        gen = PromptGenerator(prompts_per_domain=3, domains=["reasoning"])
        prompts = gen.generate()["reasoning"]

        teacher = _GPUModel(vocab_size=128, hidden_dim=64, seq_len=8, n_layers=2)
        student = _GPUModel(vocab_size=128, hidden_dim=32, seq_len=8, n_layers=1)

        for prompt in prompts:
            tokens = self._mock_tokenize(prompt).reshape(1, -1)
            t_logits = teacher.forward(tokens)
            s_logits = student.forward(tokens)
            kl = _kl_divergence(s_logits, t_logits, temperature=4.0)
            assert np.isfinite(kl)
            assert kl >= 0.0

    def test_prompt_driven_distillation_step(self):
        """DistillationTrainer.train_step should work with prompt-derived tokens."""
        gen = PromptGenerator(prompts_per_domain=4, domains=["creative"])
        prompts = gen.generate()["creative"]

        teacher = _GPUModel(vocab_size=128, hidden_dim=32, seq_len=8, n_layers=2)
        student = _GPUModel(vocab_size=128, hidden_dim=32, seq_len=8, n_layers=1)

        trainer = DistillationTrainer(
            student_model=student,
            teacher_model=teacher,
            temperature_mode="sakd",
        )

        for prompt in prompts:
            tokens = self._mock_tokenize(prompt).reshape(1, -1)
            labels = np.random.randint(0, 128, size=(1, 8), dtype=np.int64)
            result = trainer.train_step(tokens, labels=labels)
            assert np.isfinite(result["loss"])
            assert result["kd_loss"] >= 0.0
            assert result["ce_loss"] > 0.0

    def test_all_domains_produce_valid_gpu_logits(self):
        """Prompts from all 4 domains should produce valid GPU logits."""
        gen = PromptGenerator(prompts_per_domain=2)
        all_prompts = gen.generate()
        model = _GPUModel(vocab_size=128, hidden_dim=32, seq_len=8)

        for domain, prompts in all_prompts.items():
            for prompt in prompts:
                tokens = self._mock_tokenize(prompt).reshape(1, -1)
                logits = model.forward(tokens)
                assert logits.shape == (1, 8, 128), (
                    f"Bad shape for domain {domain}: {logits.shape}"
                )
                assert np.all(np.isfinite(logits)), (
                    f"Non-finite logits for domain {domain}"
                )

    def test_generate_flat_feeds_gpu_pipeline(self):
        """generate_flat() tuples should work in the GPU distillation pipeline."""
        gen = PromptGenerator(prompts_per_domain=3, domains=["code", "instruction"])
        flat = gen.generate_flat()
        assert len(flat) == 6  # 3 per domain * 2 domains

        teacher = _GPUModel(vocab_size=128, hidden_dim=32, seq_len=8, n_layers=1)
        student = _GPUModel(vocab_size=128, hidden_dim=32, seq_len=8, n_layers=1)

        trainer = DistillationTrainer(
            student_model=student,
            teacher_model=teacher,
            temperature_mode="linear",
        )

        for domain, prompt in flat:
            assert domain in ("code", "instruction")
            tokens = self._mock_tokenize(prompt).reshape(1, -1)
            result = trainer.train_step(tokens)
            assert np.isfinite(result["loss"])

    def test_batch_prompts_through_gpu(self):
        """Batch multiple prompts together and run through GPU model."""
        gen = PromptGenerator(prompts_per_domain=4, domains=["code"])
        prompts = gen.generate()["code"]

        batch_tokens = np.stack([
            self._mock_tokenize(p) for p in prompts
        ])  # (4, 8)

        model = _GPUModel(vocab_size=128, hidden_dim=32, seq_len=8, n_layers=1)
        logits = model.forward(batch_tokens)
        assert logits.shape == (4, 8, 128)
        assert np.all(np.isfinite(logits))


# ===========================================================================
# 6. TestGPUModelForwardPass (additional GPU integration coverage)
# ===========================================================================

class TestGPUModelForwardPass:
    """Additional tests for the GPU model forward pass correctness."""

    def test_forward_shape(self):
        """Forward pass should return (batch, seq, vocab) shape."""
        model = _GPUModel(vocab_size=256, hidden_dim=64, seq_len=16, n_layers=2)
        ids = np.random.randint(0, 256, size=(3, 16), dtype=np.int64)
        logits = model.forward(ids)
        assert logits.shape == (3, 16, 256)

    def test_forward_deterministic(self):
        """Same input should produce same output (no dropout in test model)."""
        model = _GPUModel(vocab_size=128, hidden_dim=32, seq_len=8, n_layers=1)
        ids = np.array([[1, 5, 10, 20, 30, 50, 70, 100]], dtype=np.int64)
        out1 = model.forward(ids)
        out2 = model.forward(ids)
        np.testing.assert_array_equal(out1, out2)

    def test_different_inputs_different_outputs(self):
        """Different inputs should produce different outputs."""
        model = _GPUModel(vocab_size=128, hidden_dim=32, seq_len=8, n_layers=1)
        ids_a = np.array([[0, 1, 2, 3, 4, 5, 6, 7]], dtype=np.int64)
        ids_b = np.array([[100, 101, 102, 103, 104, 105, 106, 107]], dtype=np.int64)
        out_a = model.forward(ids_a)
        out_b = model.forward(ids_b)
        assert not np.allclose(out_a, out_b), "Different inputs should yield different logits"

    def test_single_layer_vs_multilayer(self):
        """Models with different layer counts should produce different outputs."""
        np.random.seed(42)
        model_1 = _GPUModel(vocab_size=128, hidden_dim=32, seq_len=8, n_layers=1)
        np.random.seed(42)
        model_2 = _GPUModel(vocab_size=128, hidden_dim=32, seq_len=8, n_layers=2)
        ids = np.array([[10, 20, 30, 40, 50, 60, 70, 80]], dtype=np.int64)
        out_1 = model_1.forward(ids)
        out_2 = model_2.forward(ids)
        # They share embedding but have different layer structures
        assert not np.allclose(out_1, out_2)

    def test_vulkan_tensor_roundtrip(self):
        """Data uploaded to VulkanTensor and downloaded should match original."""
        data = np.random.randn(4, 32).astype(np.float32)
        vt = grilly.VulkanTensor(data)
        vt.upload()
        recovered = vt.numpy()
        np.testing.assert_array_equal(data, recovered)

    def test_grilly_matmul_matches_numpy(self):
        """grilly.matmul should match numpy matmul for small matrices."""
        a = np.random.randn(4, 8).astype(np.float32)
        b = np.random.randn(8, 16).astype(np.float32)
        expected = a @ b
        result = grilly.matmul(a, b).numpy()
        np.testing.assert_allclose(result, expected, atol=1e-4, rtol=1e-4)

    def test_grilly_cross_entropy_finite(self):
        """grilly.cross_entropy_loss should return finite loss."""
        logits = np.random.randn(4, 128).astype(np.float32)
        targets = np.random.randint(0, 128, size=(4,), dtype=np.int64)
        ce = grilly.cross_entropy_loss(logits, targets)
        assert np.isfinite(ce.numpy())
