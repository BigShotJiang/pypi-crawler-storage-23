"""Allow running as `python -m good_egg`."""
from __future__ import annotations

from good_egg.cli import main

main()
