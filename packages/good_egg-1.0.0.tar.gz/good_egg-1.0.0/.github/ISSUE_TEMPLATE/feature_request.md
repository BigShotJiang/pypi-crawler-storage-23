---
name: Feature Request
about: Suggest a feature for Good Egg
labels: enhancement
---

## Problem

What problem does this solve? What use case does it address?

## Proposed Solution

Describe what you'd like to happen.

## Alternatives Considered

Any alternative solutions or features you've considered.

## Additional Context

Any other context, screenshots, or examples.
