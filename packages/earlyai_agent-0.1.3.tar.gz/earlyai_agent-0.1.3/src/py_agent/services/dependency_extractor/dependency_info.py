from uuid import UUID

from py_agent.models.base import CustomBaseModel
from py_agent.models.code_comments import CodeComments
from py_agent.models.type_metadata import TypeMetadata


class DependencyInfo(CustomBaseModel):
    is_known: bool
    type_metadata: TypeMetadata
    code: str
    is_data_object: bool
    parameter_id: UUID
    nested_level: int
    code_comments: CodeComments | None = None
