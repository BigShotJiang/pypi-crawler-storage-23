from py_agent.models.parameter import KnownTypeMetadata, Parameter, RawTypeMetadata
from py_agent.models.parameter_type_kind import ParameterTypeKind
from py_agent.models.type_metadata import TypeMetadata


class TypeMetadataConverter:
    @staticmethod
    def convert(parameter: Parameter, parameter_type: RawTypeMetadata) -> TypeMetadata:
        return TypeMetadata(
            name=parameter_type.name,
            is_core_module=parameter_type.is_core_module,
            resolved=parameter.resolved,
            import_path=parameter_type.import_from.as_posix(),
            module_name=parameter_type.module_name,
            kind=parameter_type.kind,
            is_primitive=parameter.is_primitive
            or parameter_type.kind == ParameterTypeKind.PRIMITIVE,
            is_enum=parameter_type.kind == ParameterTypeKind.ENUM,
            is_data_object=parameter_type.is_leaf_DTO,
        )

    @staticmethod
    def convert_known_type(parameter_type: KnownTypeMetadata) -> TypeMetadata:
        return TypeMetadata(
            name=parameter_type.name,
            is_core_module=parameter_type.is_core_module,
            resolved=parameter_type.is_known,
            import_path=parameter_type.import_from.as_posix(),
            module_name=parameter_type.module_name,
            kind=parameter_type.kind,
            is_primitive=parameter_type.kind == ParameterTypeKind.PRIMITIVE,
            is_enum=parameter_type.kind == ParameterTypeKind.ENUM,
            is_data_object=parameter_type.is_DTO,
        )
