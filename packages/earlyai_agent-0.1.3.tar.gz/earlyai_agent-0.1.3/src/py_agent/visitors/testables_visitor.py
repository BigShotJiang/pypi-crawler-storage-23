import libcst as cst
from libcst import MetadataWrapper
from libcst.metadata import ByteSpanPositionProvider, PositionProvider

from py_agent.models.testable import Position, Testable


def get_current_class_name(current_class_node: cst.ClassDef | None) -> str | None:
    if current_class_node is None:
        return None
    return current_class_node.name.value


class TestablesVisitor(cst.CSTVisitor):
    METADATA_DEPENDENCIES = (PositionProvider, ByteSpanPositionProvider)

    def __init__(
        self,
        module: cst.Module,
        metadata_wrapper: MetadataWrapper,
        absolute_file_path: str,
        relative_file_path: str,
        project_path: str,
    ):
        super().__init__()
        self.module = module
        self.metadata_wrapper = metadata_wrapper
        self.testables: list[Testable] = []
        self.current_class_node: cst.ClassDef | None = None
        self.absolute_file_path = absolute_file_path
        self.relative_file_path = relative_file_path
        self.project_path = project_path
        self.class_stack: list[cst.ClassDef] = []
        self.function_stack: list[cst.FunctionDef] = []

    def visit_FunctionDef(self, function_node: cst.FunctionDef) -> bool | None:
        self.function_stack.append(function_node)
        if len(self.function_stack) > 1:
            return False

        class_name = get_current_class_name(self.current_class_node)
        position_metadata = self.get_metadata(PositionProvider, function_node)
        bytespan_metadata = self.get_metadata(ByteSpanPositionProvider, function_node)
        position = Position.from_metadata(position_metadata, bytespan_metadata)
        testable = Testable(
            type=Testable.get_type("function", class_name),
            name=function_node.name.value,
            position=position,
            parent_name=class_name,
            file_path=self.absolute_file_path,
        )
        self.testables.append(testable)
        return None

    def leave_FunctionDef(self, node: cst.FunctionDef) -> None:
        self.function_stack.pop()

    def visit_ClassDef(self, class_node: cst.ClassDef) -> bool | None:
        self.class_stack.append(class_node)
        if len(self.class_stack) > 1:
            return False
        self.current_class_node = class_node
        position_metadata = self.get_metadata(PositionProvider, class_node)
        bytespan_metadata = self.get_metadata(ByteSpanPositionProvider, class_node)
        position = Position.from_metadata(position_metadata, bytespan_metadata)
        testable = Testable(
            type="class",
            name=class_node.name.value,
            position=position,
            file_path=self.absolute_file_path,
        )
        self.testables.append(testable)
        return None

    def leave_ClassDef(self, class_node: cst.ClassDef) -> None:
        self.class_stack.pop()
        self.current_class_node = None
