PRIMITIVE_TYPES = ["int", "float", "str", "bool", "datetime", "UUID"]
