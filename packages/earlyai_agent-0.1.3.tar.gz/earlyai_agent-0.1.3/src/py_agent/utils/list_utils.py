from collections.abc import Callable
from typing import TypeVar

T = TypeVar("T")


def flatten(lst: list[list[T]]) -> list[T]:
    return [item for sublist in lst for item in sublist]


def uniq_with(lst: list[T], predicate: Callable[[T, T], bool]) -> list[T]:
    result: list[T] = []
    for item in lst:
        if not any(predicate(item, existing) for existing in result):
            result.append(item)
    return result
