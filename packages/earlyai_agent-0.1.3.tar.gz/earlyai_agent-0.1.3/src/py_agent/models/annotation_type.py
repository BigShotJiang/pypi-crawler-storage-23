from dataclasses import dataclass

from py_agent.models.parameter_type_kind import ParameterTypeKind


@dataclass(eq=True, frozen=True)
class AnnotationType:
    name: str
    kind: ParameterTypeKind
    namespace: str | None
    full_name: str
    line: int | None = -1
    col: int | None = -1
