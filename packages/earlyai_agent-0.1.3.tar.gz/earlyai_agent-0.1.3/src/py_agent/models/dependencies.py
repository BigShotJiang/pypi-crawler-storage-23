from pydantic import Field

from py_agent.models.base import CustomBaseModel
from py_agent.models.code_dependency import CodeDependency
from py_agent.models.missing_dependency import MissingDependency


class DependenciesDTO(CustomBaseModel):
    code_dependencies: list[CodeDependency] = Field(alias="codeDependencies", default_factory=list)
    missing_dependencies: list[MissingDependency] = Field(
        alias="missingDependencies", default_factory=list
    )
