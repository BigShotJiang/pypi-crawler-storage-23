from enum import Enum


class ParameterTypeKind(Enum):
    CLASS = "class"
    TYPE = "type"
    INTERFACE = "interface"
    ENUM = "enum"
    GENERIC_TYPE_PARAMETER = "generic-type-parameter"
    ANY = "any"
    PRIMITIVE = "primitive"
    FUNCTION = "function"
    REACT_FUNCTION_COMPONENT = "react-function-component"
    REACT_CLASS_COMPONENT = "react-class-component"
    REACT_HOOK = "react-hook"
    REACT_CSS_IN_JS = "react-css-in-js"
    REACT_FORWARD_REF_COMPONENT = "react-forward-ref-component"
    STYLE = "style"
