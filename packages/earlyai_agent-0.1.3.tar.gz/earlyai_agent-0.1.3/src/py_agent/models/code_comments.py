from pydantic import Field

from py_agent.models.base import CustomBaseModel


class CodeComment(CustomBaseModel):
    name: str
    comment: str


class CodeComments(CustomBaseModel):
    main_comment: str | None = Field(alias="mainComment", default=None)
    method_comments: list[CodeComment] | None = Field(alias="methodComments", default=None)
