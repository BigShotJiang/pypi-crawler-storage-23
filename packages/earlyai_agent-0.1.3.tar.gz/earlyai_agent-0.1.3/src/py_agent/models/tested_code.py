from typing import Any

from pydantic import Field

from py_agent.models.base import CustomBaseModel
from py_agent.models.class_metadata import ClassMetadata
from py_agent.models.dependencies import DependenciesDTO
from py_agent.models.enum_metadata import EnumMetadata
from py_agent.models.parameter import Parameter
from py_agent.models.testable import Position


class ExtractedDataDTO(CustomBaseModel):
    file_code: str = Field(..., alias="fileCode")
    function_code: str = Field(..., alias="functionCode")
    position: Position
    parameters: list[Parameter]
    ctor_parameters: list[Parameter] = Field(default_factory=list, exclude=True)
    return_parameter: Parameter | None = Field(default=None, alias="returnParam")
    class_metadata: ClassMetadata | None = Field(alias="classMetadata", default=None)
    external_function_calls: dict[str, Any] = Field(default_factory=dict, exclude=True)
    enums: list[EnumMetadata] = Field(default_factory=list, exclude=True)
    is_async: bool = Field(alias="isAsync")
    is_static: bool = Field(alias="isStatic")
    signature: str = ""


class TestedCodeDTO(CustomBaseModel):
    file_path: str = Field(..., alias="filePath")
    function_name: str = Field(..., alias="functionName")
    extracted_data: ExtractedDataDTO | None = Field(alias="extractedData", default=None)
    module_name: str | None = Field(alias="moduleName", default=None)
    dependencies: DependenciesDTO | None = Field(alias="dependencies", default=None)
