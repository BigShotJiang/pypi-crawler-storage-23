from py_agent.models.base import CustomBaseModel
from py_agent.models.parameter_type_kind import ParameterTypeKind


class TypeMetadata(CustomBaseModel):
    name: str
    is_core_module: bool
    resolved: bool
    import_path: str
    module_name: str
    kind: ParameterTypeKind
    is_primitive: bool
    is_enum: bool
    is_data_object: bool
