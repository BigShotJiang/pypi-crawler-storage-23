from py_agent.models.base import CustomBaseModel


class EnumMetadata(CustomBaseModel):
    name: str
    code: str
    module_path: str
    module_name: str
