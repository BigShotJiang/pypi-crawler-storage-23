"""Integration tests for Lattice."""
