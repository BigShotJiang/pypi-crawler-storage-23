"""Status types for Lattice."""

from __future__ import annotations

from dataclasses import dataclass

import deal


@dataclass(frozen=True)
class StatusReport:
    """Status report from lattice status command.

    >>> report = StatusReport(
    ...     pending_proposals=2,
    ...     total_rules=5,
    ...     total_tokens=1500,
    ...     sessions_pending_evolution=10,
    ... )
    >>> report.pending_proposals
    2
    """

    pending_proposals: int
    total_rules: int
    total_tokens: int
    sessions_pending_evolution: int
    warn_threshold: int = 3000
    alert_threshold: int = 5000

    @deal.post(lambda result: result in ("ok", "warn", "alert"))
    def token_status(self) -> str:
        """Return token status indicator.

        >>> StatusReport(pending_proposals=0, total_rules=0, total_tokens=1000,
        ...              sessions_pending_evolution=0).token_status()
        'ok'
        >>> StatusReport(pending_proposals=0, total_rules=0, total_tokens=4000,
        ...              sessions_pending_evolution=0).token_status()
        'warn'
        >>> StatusReport(pending_proposals=0, total_rules=0, total_tokens=6000,
        ...              sessions_pending_evolution=0).token_status()
        'alert'
        """
        if self.total_tokens >= self.alert_threshold:
            return "alert"
        if self.total_tokens >= self.warn_threshold:
            return "warn"
        return "ok"
