"""Search types for Lattice."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from lattice.core.types.enums import Role


@dataclass(frozen=True)
class FtsResult:
    """Full-text search result from FTS5.

    >>> result = FtsResult(rowid=1, rank=-0.5)
    >>> result.rowid
    1
    """

    rowid: int
    rank: float


@dataclass(frozen=True)
class VecResult:
    """Vector search result from sqlite-vec.

    >>> result = VecResult(rowid=1, distance=0.1)
    >>> result.rowid
    1
    """

    rowid: int
    distance: float


@dataclass(frozen=True)
class RankedItem:
    """An item with its RRF (Reciprocal Rank Fusion) score.

    >>> item = RankedItem(rowid=1, rrf_score=0.033)
    >>> item.rowid
    1
    """

    rowid: int
    rrf_score: float


@dataclass(frozen=True)
class SearchResult:
    """A search result with content.

    >>> result = SearchResult(
    ...     rowid=1,
    ...     external_id="uuid-123",
    ...     session_id="session-abc",
    ...     timestamp="2026-02-17T10:00:00Z",
    ...     role=Role.USER,
    ...     content="Hello world",
    ...     rrf_score=0.033,
    ... )
    >>> result.role
    <Role.USER: 'user'>
    """

    rowid: int
    external_id: str
    session_id: str
    timestamp: str
    role: Role
    content: str
    rrf_score: float
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class FusedResult:
    """Result from hybrid search (BM25 + Vector + RRF).

    Combines rowid from search with content from logs table.

    >>> result = FusedResult(
    ...     rowid=1,
    ...     content="Test content",
    ...     bm25_rank=1,
    ...     vec_rank=2,
    ...     rrf_score=0.033,
    ... )
    >>> result.rrf_score
    0.033
    """

    rowid: int
    content: str
    bm25_rank: int | None = None
    vec_rank: int | None = None
    rrf_score: float = 0.0
