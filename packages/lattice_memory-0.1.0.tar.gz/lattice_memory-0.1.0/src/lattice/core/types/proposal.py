"""Proposal types for Lattice."""

from __future__ import annotations

from dataclasses import dataclass, field

import deal

from lattice.core.types.enums import PatternType, ProposalAction


@dataclass(frozen=True)
class ProposeRuleInput:
    """Input for propose_rule() SDK/MCP method.

    Structured schema reduces prompt injection surface.

    >>> inp = ProposeRuleInput(
    ...     pattern=PatternType.CONVENTION,
    ...     observation="Always use explicit imports",
    ...     evidence=["session-1", "session-2"],
    ...     suggested_action="explicit-imports",
    ... )
    >>> inp.pattern
    <PatternType.CONVENTION: 'convention'>
    """

    pattern: PatternType
    observation: str  # max 200 chars
    evidence: list[str]  # session IDs
    suggested_action: str  # max 100 chars

    @deal.post(lambda result: result is None)
    def __post_init__(self) -> None:
        """Validate constraints.

        >>> ProposeRuleInput(
        ...     pattern=PatternType.CONVENTION,
        ...     observation="x" * 201,
        ...     evidence=[],
        ...     suggested_action="test",
        ... )
        Traceback (most recent call last):
            ...
        ValueError: observation must be <= 200 chars
        """
        if len(self.observation) > 200:
            raise ValueError("observation must be <= 200 chars")
        if len(self.suggested_action) > 100:
            raise ValueError("suggested_action must be <= 100 chars")


@dataclass(frozen=True)
class Proposal:
    """A rule proposal from Compiler or propose_rule().

    >>> proposal = Proposal(
    ...     proposal_id="20260217_explicit_imports",
    ...     pattern=PatternType.CONVENTION,
    ...     action=ProposalAction.ADD,
    ...     title="Use Explicit Imports",
    ...     content="Always use explicit imports instead of wildcards.",
    ...     evidence_session_ids=["session-1", "session-2"],
    ... )
    >>> proposal.action
    <ProposalAction.ADD: 'add'>
    """

    proposal_id: str
    pattern: PatternType
    action: ProposalAction
    title: str
    content: str
    evidence_session_ids: list[str] = field(default_factory=list)
    created_at: str = ""  # Caller must provide timestamp (Shell layer responsibility)
    applied: bool = False
