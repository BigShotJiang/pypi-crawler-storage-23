"""
QuarterBit - AXIOM Full-Stack Memory-Efficient Training
========================================================

BREAKTHROUGH: Train 70B on H100 80GB with 100% trainable weights!

FULL STACK (6x+ memory reduction):
    - VLA TRAINABLE: INT4 + INT2 error = 0.75 bytes/param (100% trainable!)
    - AXIOM optimizer: 1333x optimizer state compression
    - Gradient compression: 16x via register_hooks()
    - Train 70B models on single H100!

Memory for 70B:
    - Weights:    52.5 GB (VLA Ultra)
    - Optimizer:   0.4 GB (AXIOM)
    - Gradients:   8.8 GB (compressed)
    - TOTAL:      ~67 GB - FITS H100 80GB!

Quick Start (70B on H100):
    from quarterbit import AXIOM_Trainer, TrainerConfig

    # VLA auto-enables for models > 1B params
    config = TrainerConfig(lr=1e-4)
    trainer = AXIOM_Trainer(model, train_loader, config=config)
    results = trainer.fit(steps=2000)

VLA Modes:
    vla_trainable="auto"     # Enable for >1B params (default)
    vla_trainable="ultra"    # 0.75 bytes/param, 92% quality
    vla_trainable="quality"  # 1.0 bytes/param, 100% quality
    vla_trainable="extreme"  # 0.625 bytes/param, 82% quality

License:
    Free account required: https://quarterbit.dev
    Run: quarterbit login
"""

__version__ = "19.1.3"  # FP16 shadow weights for memory reduction
__author__ = "Clouthier Simulation Labs"

# License check on import
from .license import check_license, LicenseError

_LICENSE_VALID = False
try:
    check_license(silent=True)
    _LICENSE_VALID = True
except LicenseError:
    import sys
    print("\n" + "="*60)
    print("QuarterBit requires a free account.")
    print("")
    print("Sign up (free): https://quarterbit.dev")
    print("Then run:       quarterbit login")
    print("="*60 + "\n")

# Check PyTorch
try:
    import torch as _torch
    _HAS_TORCH = True
    if not _torch.cuda.is_available():
        import warnings
        warnings.warn(
            "QuarterBit: CUDA not available. GPU required for full performance.",
            RuntimeWarning
        )
except ImportError:
    _HAS_TORCH = False
    import warnings
    warnings.warn(
        "QuarterBit: PyTorch not found. Install from https://pytorch.org/get-started/locally/",
        ImportWarning
    )

# Main optimizer (requires PyTorch AND license)
if _HAS_TORCH and _LICENSE_VALID:
    from .optimizer import AXIOM
    from .extensions import AXIOM_CHECKPOINT, AXIOM_DDP
    from .trainer import AXIOM_Trainer, TrainerConfig
    from .vla_trainable import (
        make_vla_trainable,
        get_vla_layers,
        VLATrainableLinear,
        VLATrainableEmbedding,
        VLATrainableConv2d,
        VLATrainableConv1d,
        VLAQuantizer,
    )
    from .vla_loader import (
        load_vla_model,
        estimate_vla_memory,
    )

    __all__ = [
        # Core optimizer
        "AXIOM",
        # VLA TRAINABLE (0.75 bytes/param, 100% trainable!) - BREAKTHROUGH
        "make_vla_trainable",
        "get_vla_layers",
        "VLATrainableLinear",
        "VLATrainableEmbedding",
        "VLATrainableConv2d",
        "VLATrainableConv1d",
        "VLAQuantizer",
        # VLA LOADER (stream load 70B directly to GPU in VLA format)
        "load_vla_model",
        "estimate_vla_memory",
        # Full-stack trainer
        "AXIOM_Trainer",
        "TrainerConfig",
        # Extensions
        "AXIOM_CHECKPOINT",
        "AXIOM_DDP",
        "__version__",
    ]
elif _HAS_TORCH and not _LICENSE_VALID:
    # License required - provide stub that raises on use
    def _license_required(*args, **kwargs):
        raise LicenseError(
            "License required. Sign up free at quarterbit.dev then run: quarterbit login"
        )

    class _LicenseRequiredClass:
        def __init__(self, *args, **kwargs):
            raise LicenseError(
                "License required. Sign up free at quarterbit.dev then run: quarterbit login"
            )

    AXIOM = _LicenseRequiredClass
    AXIOM_Trainer = _LicenseRequiredClass
    TrainerConfig = _LicenseRequiredClass
    AXIOM_CHECKPOINT = _LicenseRequiredClass
    AXIOM_DDP = _LicenseRequiredClass
    make_vla_trainable = _license_required
    get_vla_layers = _license_required
    load_vla_model = _license_required
    estimate_vla_memory = _license_required

    __all__ = [
        "AXIOM",
        "make_vla_trainable",
        "get_vla_layers",
        "load_vla_model",
        "estimate_vla_memory",
        "AXIOM_Trainer",
        "TrainerConfig",
        "AXIOM_CHECKPOINT",
        "AXIOM_DDP",
        "__version__",
    ]
else:
    __all__ = ["__version__"]
