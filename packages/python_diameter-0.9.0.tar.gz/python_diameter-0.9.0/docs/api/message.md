---
shallow_toc: 3
---
API reference for `diameter.message`.

::: diameter.message
    options:
      show_root_heading: false
      show_root_toc_entry: false
      show_root_full_path: false
      members:
        - Message
        - MessageHeader
        - DefinedMessage
        - UndefinedMessage
        - dump
      show_submodules: false