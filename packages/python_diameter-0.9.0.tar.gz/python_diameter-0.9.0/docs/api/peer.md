---
shallow_toc: 3
---
API reference for `diameter.node.peer`.

::: diameter.node.peer
    options:
      show_root_heading: false
      show_root_toc_entry: false
      show_submodules: false
      members_order: source   