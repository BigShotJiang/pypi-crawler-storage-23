"""
WASP2: Allele-Specific Pipeline, Version 2.

A Python package for allele-specific analysis of sequencing data.
"""

__version__ = "1.3.3"
