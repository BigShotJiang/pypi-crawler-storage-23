"""Tests for task 35.1: DuckDB metrics reporting."""

from __future__ import annotations

import duckdb

from rivet_core.metrics import (
    IOMetrics,
    MemoryMetrics,
    ParallelismMetrics,
    PluginMetrics,
    QueryPlanningMetrics,
    ScanMetrics,
)
from rivet_duckdb.engine import DuckDBComputeEnginePlugin

# ── collect_metrics returns PluginMetrics ──────────────────────────────────


def test_collect_metrics_returns_plugin_metrics_with_empty_context():
    plugin = DuckDBComputeEnginePlugin()
    result = plugin.collect_metrics({})
    assert isinstance(result, PluginMetrics)


def test_collect_metrics_returns_plugin_metrics_with_none_context():
    plugin = DuckDBComputeEnginePlugin()
    result = plugin.collect_metrics(None)
    assert isinstance(result, PluginMetrics)


def test_collect_metrics_never_raises_on_bad_context():
    plugin = DuckDBComputeEnginePlugin()
    # Should not raise regardless of context type
    result = plugin.collect_metrics("not a dict")
    assert result is None or isinstance(result, PluginMetrics)


def test_collect_metrics_engine_field():
    plugin = DuckDBComputeEnginePlugin()
    result = plugin.collect_metrics({})
    assert result.engine == "duckdb"


# ── Well-known categories present ─────────────────────────────────────────


def test_collect_metrics_has_query_planning_category():
    plugin = DuckDBComputeEnginePlugin()
    result = plugin.collect_metrics({})
    assert "query_planning" in result.well_known
    assert isinstance(result.well_known["query_planning"], QueryPlanningMetrics)


def test_collect_metrics_has_io_category():
    plugin = DuckDBComputeEnginePlugin()
    result = plugin.collect_metrics({})
    assert "io" in result.well_known
    assert isinstance(result.well_known["io"], IOMetrics)


def test_collect_metrics_has_memory_category():
    plugin = DuckDBComputeEnginePlugin()
    result = plugin.collect_metrics({})
    assert "memory" in result.well_known
    assert isinstance(result.well_known["memory"], MemoryMetrics)


def test_collect_metrics_has_parallelism_category():
    plugin = DuckDBComputeEnginePlugin()
    result = plugin.collect_metrics({})
    assert "parallelism" in result.well_known
    assert isinstance(result.well_known["parallelism"], ParallelismMetrics)


def test_collect_metrics_has_scan_category():
    plugin = DuckDBComputeEnginePlugin()
    result = plugin.collect_metrics({})
    assert "scan" in result.well_known
    assert isinstance(result.well_known["scan"], ScanMetrics)


# ── Memory metrics from live DuckDB connection ─────────────────────────────


def test_collect_metrics_memory_from_connection():
    plugin = DuckDBComputeEnginePlugin()
    conn = duckdb.connect(":memory:")
    conn.execute("SELECT sum(x) FROM range(10000) t(x)")
    result = plugin.collect_metrics({"connection": conn})
    mem = result.well_known["memory"]
    assert isinstance(mem, MemoryMetrics)
    # peak_bytes may be 0 for small queries but should not be negative
    assert mem.peak_bytes is None or mem.peak_bytes >= 0
    conn.close()


def test_collect_metrics_memory_spilled_false_for_small_query():
    plugin = DuckDBComputeEnginePlugin()
    conn = duckdb.connect(":memory:")
    conn.execute("SELECT 1")
    result = plugin.collect_metrics({"connection": conn})
    mem = result.well_known["memory"]
    # Small query should not spill
    assert mem.spilled is False
    conn.close()


# ── Parallelism metrics from live DuckDB connection ────────────────────────


def test_collect_metrics_parallelism_threads_from_connection():
    plugin = DuckDBComputeEnginePlugin()
    conn = duckdb.connect(":memory:")
    conn.execute("SET threads=2")
    result = plugin.collect_metrics({"connection": conn})
    par = result.well_known["parallelism"]
    assert isinstance(par, ParallelismMetrics)
    assert par.threads_used == 2
    conn.close()


def test_collect_metrics_parallelism_threads_from_context():
    plugin = DuckDBComputeEnginePlugin()
    result = plugin.collect_metrics({"threads_used": 4})
    par = result.well_known["parallelism"]
    assert par.threads_used == 4


# ── Query planning metrics from timing context ─────────────────────────────


def test_collect_metrics_query_planning_from_timing():
    from rivet_core.metrics import PhasedTiming

    plugin = DuckDBComputeEnginePlugin()
    timing = PhasedTiming(
        total_ms=100.0,
        engine_ms=42.5,
        materialize_ms=10.0,
        residual_ms=5.0,
        check_ms=2.5,
    )
    result = plugin.collect_metrics({"timing": timing})
    qp = result.well_known["query_planning"]
    assert qp.planning_time_ms == 42.5


def test_collect_metrics_query_planning_actual_rows_from_context():
    plugin = DuckDBComputeEnginePlugin()
    result = plugin.collect_metrics({"rows_out": 500})
    qp = result.well_known["query_planning"]
    assert qp.actual_rows == 500


# ── IO metrics from context ────────────────────────────────────────────────


def test_collect_metrics_io_bytes_read_from_context():
    plugin = DuckDBComputeEnginePlugin()
    result = plugin.collect_metrics({"bytes_read": 1024})
    io = result.well_known["io"]
    assert io.bytes_read == 1024


def test_collect_metrics_io_bytes_written_from_context():
    plugin = DuckDBComputeEnginePlugin()
    result = plugin.collect_metrics({"bytes_written": 2048})
    io = result.well_known["io"]
    assert io.bytes_written == 2048


# ── Scan metrics from context ──────────────────────────────────────────────


def test_collect_metrics_scan_rows_scanned_from_context():
    plugin = DuckDBComputeEnginePlugin()
    result = plugin.collect_metrics({"rows_scanned": 1000})
    scan = result.well_known["scan"]
    assert scan.rows_scanned == 1000


def test_collect_metrics_scan_filter_selectivity_computed():
    plugin = DuckDBComputeEnginePlugin()
    result = plugin.collect_metrics({"rows_scanned": 1000, "rows_filtered": 200})
    scan = result.well_known["scan"]
    assert scan.filter_selectivity is not None
    assert abs(scan.filter_selectivity - 0.8) < 1e-9


# ── Extensions: loaded DuckDB extensions ──────────────────────────────────


def test_collect_metrics_extensions_loaded_extensions_key():
    plugin = DuckDBComputeEnginePlugin()
    conn = duckdb.connect(":memory:")
    result = plugin.collect_metrics({"connection": conn})
    assert "duckdb.loaded_extensions" in result.extensions
    conn.close()


def test_collect_metrics_extensions_loaded_extensions_is_list():
    plugin = DuckDBComputeEnginePlugin()
    conn = duckdb.connect(":memory:")
    result = plugin.collect_metrics({"connection": conn})
    assert isinstance(result.extensions["duckdb.loaded_extensions"], list)
    conn.close()


def test_collect_metrics_extensions_keys_are_namespaced():
    """All extension keys must contain a dot (PluginMetrics contract)."""
    plugin = DuckDBComputeEnginePlugin()
    conn = duckdb.connect(":memory:")
    result = plugin.collect_metrics({"connection": conn})
    for key in result.extensions:
        assert "." in key, f"Extension key '{key}' is not namespaced"
    conn.close()


def test_collect_metrics_no_connection_no_extensions():
    plugin = DuckDBComputeEnginePlugin()
    result = plugin.collect_metrics({})
    # Without a connection, no extensions should be populated
    assert result.extensions == {}


# ── Property 16: collect_metrics returns PluginMetrics or None, never raises ──


def test_collect_metrics_returns_plugin_metrics_or_none_for_various_contexts():
    plugin = DuckDBComputeEnginePlugin()
    contexts = [
        {},
        None,
        {"connection": duckdb.connect(":memory:")},
        {"timing": None},
        {"rows_scanned": 0, "rows_filtered": 0},
        {"bytes_read": 0, "bytes_written": 0},
    ]
    for ctx in contexts:
        result = plugin.collect_metrics(ctx)
        assert result is None or isinstance(result, PluginMetrics), (
            f"collect_metrics({ctx!r}) returned {result!r}, expected PluginMetrics or None"
        )
