"""Open-source readiness validation tests.

Validates package configuration, community health files, README content,
CI/CD workflows, and .gitignore for open-source release compliance.

Requirements: 1.1–1.6, 2.1–2.9, 3.1–3.5, 4.1–4.3, 5.1–5.9, 6.1–6.7,
              7.1–7.7, 8.1–8.4, 9.1–9.5
"""

import pathlib
import tomllib

import pytest

REPO_ROOT = pathlib.Path(__file__).resolve().parent.parent.parent
RIVET_DIR = REPO_ROOT / "rivet"
SRC = RIVET_DIR / "src"
CORE_PYPROJECT = RIVET_DIR / "pyproject.toml"
MAIN_PYPROJECT = RIVET_DIR / "pyproject.rivetsql.toml"

PLUGINS = ["duckdb", "postgres", "polars", "pyspark", "databricks", "aws"]
PLUGIN_DIRS = {name: SRC / f"rivet_{name}" for name in PLUGINS}


def _parse_toml(path: pathlib.Path) -> dict:
    return tomllib.loads(path.read_text())


# ---------------------------------------------------------------------------
# rivetsql-core pyproject.toml
# ---------------------------------------------------------------------------

class TestCorePackage:
    """Validate rivetsql-core pyproject.toml metadata and configuration."""

    @pytest.fixture(autouse=True)
    def _load(self):
        self.data = _parse_toml(CORE_PYPROJECT)
        self.project = self.data["project"]

    def test_name(self):
        assert self.project["name"] == "rivetsql-core"

    def test_requires_python(self):
        assert self.project["requires-python"] == ">=3.11"

    def test_license_mit(self):
        assert self.project["license"] == "MIT"

    def test_readme(self):
        assert "readme" in self.project

    def test_authors(self):
        assert len(self.project["authors"]) >= 1

    def test_keywords(self):
        assert len(self.project["keywords"]) >= 1

    def test_classifiers_python_versions(self):
        classifiers = self.project["classifiers"]
        for ver in ("3.11", "3.12", "3.13"):
            assert any(ver in c for c in classifiers), f"Missing classifier for Python {ver}"

    def test_classifiers_mit(self):
        assert any("MIT" in c for c in self.project["classifiers"])

    def test_urls(self):
        urls = self.project["urls"]
        for key in ("Homepage", "Documentation", "Repository", "Changelog"):
            assert key in urls, f"Missing url: {key}"

    def test_dependencies(self):
        deps = self.project["dependencies"]
        dep_names = [d.split(">=")[0].split(">")[0].split("==")[0] for d in deps]
        for expected in ("pyarrow", "sqlglot", "pyyaml"):
            assert expected in dep_names, f"Missing dependency: {expected}"


# ---------------------------------------------------------------------------
# rivetsql (main package) pyproject.rivetsql.toml
# ---------------------------------------------------------------------------

class TestMainPackage:
    """Validate rivetsql main package configuration."""

    @pytest.fixture(autouse=True)
    def _load(self):
        if not MAIN_PYPROJECT.exists():
            pytest.skip("pyproject.rivetsql.toml not yet created")
        self.data = _parse_toml(MAIN_PYPROJECT)
        self.project = self.data["project"]

    def test_name(self):
        assert self.project["name"] == "rivetsql"

    def test_depends_on_core(self):
        deps = self.project["dependencies"]
        assert any("rivetsql-core" in d for d in deps)

    def test_scripts_entry_point(self):
        scripts = self.project.get("scripts", {})
        assert "rivet" in scripts

    @pytest.mark.parametrize("plugin", PLUGINS)
    def test_plugin_extra(self, plugin):
        extras = self.project.get("optional-dependencies", {})
        assert plugin in extras, f"Missing extra: {plugin}"
        pkgs = extras[plugin]
        assert any(f"rivetsql-{plugin}" in p for p in pkgs)

    def test_all_extra_contains_all_plugins(self):
        extras = self.project.get("optional-dependencies", {})
        assert "all" in extras
        all_pkgs = " ".join(extras["all"])
        for plugin in PLUGINS:
            assert f"rivetsql-{plugin}" in all_pkgs, f"'all' extra missing rivetsql-{plugin}"


# ---------------------------------------------------------------------------
# Plugin packages
# ---------------------------------------------------------------------------

class TestPluginPackages:
    """Validate each plugin pyproject.toml."""

    @pytest.mark.parametrize("plugin", PLUGINS)
    def test_plugin_name_convention(self, plugin):
        path = PLUGIN_DIRS[plugin] / "pyproject.toml"
        if not path.exists():
            pytest.skip(f"{path} not found")
        data = _parse_toml(path)
        assert data["project"]["name"] == f"rivetsql-{plugin}"

    @pytest.mark.parametrize("plugin", PLUGINS)
    def test_plugin_depends_on_core_only(self, plugin):
        path = PLUGIN_DIRS[plugin] / "pyproject.toml"
        if not path.exists():
            pytest.skip(f"{path} not found")
        data = _parse_toml(path)
        deps = data["project"].get("dependencies", [])
        rivet_deps = [d for d in deps if "rivetsql" in d]
        assert all("rivetsql-core" in d for d in rivet_deps), (
            f"Plugin {plugin} has non-core rivetsql dependency: {rivet_deps}"
        )

    @pytest.mark.parametrize("plugin", PLUGINS)
    def test_plugin_entry_point(self, plugin):
        path = PLUGIN_DIRS[plugin] / "pyproject.toml"
        if not path.exists():
            pytest.skip(f"{path} not found")
        data = _parse_toml(path)
        eps = data["project"].get("entry-points", {}).get("rivet.plugins", {})
        assert len(eps) >= 1, f"Plugin {plugin} has no rivet.plugins entry points"

    @pytest.mark.parametrize("plugin", PLUGINS)
    def test_plugin_metadata(self, plugin):
        path = PLUGIN_DIRS[plugin] / "pyproject.toml"
        if not path.exists():
            pytest.skip(f"{path} not found")
        data = _parse_toml(path)
        proj = data["project"]
        assert "authors" in proj, f"Plugin {plugin} missing authors"
        assert "keywords" in proj, f"Plugin {plugin} missing keywords"
        assert "urls" in data["project"], f"Plugin {plugin} missing urls"


# ---------------------------------------------------------------------------
# Community health files
# ---------------------------------------------------------------------------

COMMUNITY_FILES = ["LICENSE", "CONTRIBUTING.md", "CODE_OF_CONDUCT.md", "SECURITY.md", "CHANGELOG.md"]


class TestCommunityHealthFiles:
    """Validate community health files exist at repo root."""

    @pytest.mark.parametrize("filename", COMMUNITY_FILES)
    def test_file_exists(self, filename):
        assert (REPO_ROOT / filename).exists(), f"Missing community file: {filename}"


# ---------------------------------------------------------------------------
# GitHub templates
# ---------------------------------------------------------------------------

GITHUB_FILES = [
    ".github/ISSUE_TEMPLATE/bug_report.yml",
    ".github/ISSUE_TEMPLATE/feature_request.yml",
    ".github/PULL_REQUEST_TEMPLATE.md",
    ".github/dependabot.yml",
]


class TestGitHubTemplates:
    """Validate GitHub issue/PR templates and Dependabot config exist."""

    @pytest.mark.parametrize("filepath", GITHUB_FILES)
    def test_file_exists(self, filepath):
        assert (REPO_ROOT / filepath).exists(), f"Missing: {filepath}"


# ---------------------------------------------------------------------------
# README content
# ---------------------------------------------------------------------------

class TestReadme:
    """Validate README contains required sections and content."""

    @pytest.fixture(autouse=True)
    def _load(self):
        readme_path = REPO_ROOT / "README.md"
        assert readme_path.exists(), "README.md not found"
        self.content = readme_path.read_text()

    def test_badges(self):
        assert "img.shields.io" in self.content

    def test_features_heading(self):
        assert "## Features" in self.content

    def test_quick_start_heading(self):
        assert "## Quick Start" in self.content

    def test_installation_heading(self):
        assert "## Installation" in self.content

    def test_plugins_heading(self):
        assert "## Plugins" in self.content

    def test_mermaid_diagram(self):
        assert "```mermaid" in self.content


# ---------------------------------------------------------------------------
# CI workflow
# ---------------------------------------------------------------------------

class TestCIWorkflow:
    """Validate CI workflow configuration."""

    @pytest.fixture(autouse=True)
    def _load(self):
        ci_path = REPO_ROOT / ".github" / "workflows" / "ci.yml"
        if not ci_path.exists():
            pytest.skip("ci.yml not yet created")
        import yaml
        self.data = yaml.safe_load(ci_path.read_text())
        self.content = ci_path.read_text()

    def test_triggers_on_pull_request(self):
        assert "pull_request" in self.data.get(True, self.data.get("on", {}))

    def test_triggers_on_push(self):
        assert "push" in self.data.get(True, self.data.get("on", {}))

    def test_matrix_python_versions(self):
        for ver in ("3.11", "3.12", "3.13"):
            assert ver in self.content, f"CI missing Python {ver}"

    def test_matrix_macos(self):
        assert "macos" in self.content

    def test_step_ruff(self):
        assert "ruff" in self.content

    def test_step_mypy(self):
        assert "mypy" in self.content

    def test_step_pytest(self):
        assert "pytest" in self.content

    def test_step_pip_audit(self):
        assert "pip-audit" in self.content


# ---------------------------------------------------------------------------
# Publish workflow
# ---------------------------------------------------------------------------

class TestPublishWorkflow:
    """Validate publish workflow uses OIDC."""

    @pytest.fixture(autouse=True)
    def _load(self):
        pub_path = REPO_ROOT / ".github" / "workflows" / "publish.yml"
        if not pub_path.exists():
            pytest.skip("publish.yml not yet created")
        self.content = pub_path.read_text()

    def test_oidc_token(self):
        assert "id-token" in self.content


# ---------------------------------------------------------------------------
# .gitignore
# ---------------------------------------------------------------------------

class TestGitignore:
    """Validate .gitignore excludes required patterns."""

    @pytest.fixture(autouse=True)
    def _load(self):
        path = REPO_ROOT / ".gitignore"
        assert path.exists(), ".gitignore not found"
        self.content = path.read_text()

    def test_env_excluded(self):
        assert ".env" in self.content

    def test_dist_excluded(self):
        assert "dist/" in self.content

    def test_build_excluded(self):
        assert "build/" in self.content

    def test_pycache_excluded(self):
        assert "__pycache__/" in self.content
