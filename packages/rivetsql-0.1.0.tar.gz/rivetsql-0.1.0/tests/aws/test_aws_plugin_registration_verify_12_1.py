"""Task 12.1: Verify AWSPlugin(registry) registers all 6 components and entry point resolves.

Verifies:
- 2 catalog plugins: s3, glue
- 2 source plugins: s3, glue
- 2 sink plugins: s3, glue
- Entry point 'aws' under 'rivet.plugins' resolves to rivet_aws:AWSPlugin
"""

from __future__ import annotations

import importlib
import pathlib
import tomllib

from rivet_core.plugins import (
    CatalogPlugin,
    PluginRegistry,
    SinkPlugin,
    SourcePlugin,
)

SRC = pathlib.Path(__file__).resolve().parent.parent.parent / "src"


def _fresh_registry() -> PluginRegistry:
    return PluginRegistry()


class TestAWSPluginRegistersAllSixComponents:
    def setup_method(self):
        from rivet_aws import AWSPlugin
        self.registry = _fresh_registry()
        AWSPlugin(self.registry)

    def test_s3_catalog_registered(self):
        plugin = self.registry.get_catalog_plugin("s3")
        assert plugin is not None
        assert isinstance(plugin, CatalogPlugin)
        assert plugin.type == "s3"

    def test_glue_catalog_registered(self):
        plugin = self.registry.get_catalog_plugin("glue")
        assert plugin is not None
        assert isinstance(plugin, CatalogPlugin)
        assert plugin.type == "glue"

    def test_s3_source_registered(self):
        source = self.registry._sources.get("s3")
        assert source is not None
        assert isinstance(source, SourcePlugin)

    def test_glue_source_registered(self):
        source = self.registry._sources.get("glue")
        assert source is not None
        assert isinstance(source, SourcePlugin)

    def test_s3_sink_registered(self):
        sink = self.registry._sinks.get("s3")
        assert sink is not None
        assert isinstance(sink, SinkPlugin)

    def test_glue_sink_registered(self):
        sink = self.registry._sinks.get("glue")
        assert sink is not None
        assert isinstance(sink, SinkPlugin)

    def test_exactly_two_catalogs(self):
        assert set(self.registry._catalog_plugins.keys()) == {"s3", "glue"}

    def test_exactly_two_sources(self):
        assert set(self.registry._sources.keys()) == {"s3", "glue"}

    def test_exactly_two_sinks(self):
        assert set(self.registry._sinks.keys()) == {"s3", "glue"}

    def test_no_engine_registered(self):
        assert self.registry.get_engine_plugin("s3") is None
        assert self.registry.get_engine_plugin("glue") is None
        assert self.registry.get_engine_plugin("aws") is None


class TestAWSEntryPointResolvesCorrectly:
    def test_entry_point_group_and_name(self):
        """pyproject.toml declares aws = 'rivet_aws:AWSPlugin' under rivet.plugins."""
        pyproject = SRC / "rivet_aws" / "pyproject.toml"
        data = tomllib.loads(pyproject.read_text())
        eps = data["project"]["entry-points"]["rivet.plugins"]
        assert "aws" in eps, "Entry point 'aws' not found under rivet.plugins"
        assert eps["aws"] == "rivet_aws:AWSPlugin"

    def test_entry_point_module_importable(self):
        """rivet_aws module is importable."""
        mod = importlib.import_module("rivet_aws")
        assert hasattr(mod, "AWSPlugin")

    def test_entry_point_callable(self):
        """AWSPlugin is callable and accepts a registry."""
        from rivet_aws import AWSPlugin
        registry = _fresh_registry()
        AWSPlugin(registry)  # must not raise
        # Verify registration happened
        assert registry.get_catalog_plugin("s3") is not None
        assert registry.get_catalog_plugin("glue") is not None
