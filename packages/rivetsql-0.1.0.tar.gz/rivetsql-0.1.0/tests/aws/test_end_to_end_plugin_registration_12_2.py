"""Task 12.2: End-to-end plugin registration and option validation unit tests.

Tests:
- AWSPlugin registers all expected plugin types (2 catalogs, 2 sources, 2 sinks)
- S3 catalog validation with valid and invalid options
- Glue catalog validation with valid and invalid options
- Credential resolution with mocked boto3

Requirements: 1.3, 3.2, 3.3, 6.2, 6.3
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from rivet_aws import AWSPlugin
from rivet_aws.credentials import AWSCredentialResolver
from rivet_aws.glue_catalog import GlueCatalogPlugin
from rivet_aws.s3_catalog import S3CatalogPlugin
from rivet_core.errors import PluginValidationError
from rivet_core.models import Catalog
from rivet_core.plugins import CatalogPlugin, PluginRegistry, SinkPlugin, SourcePlugin

# ── Plugin registration ───────────────────────────────────────────────────────

class TestAWSPluginRegistration:
    def setup_method(self):
        self.registry = PluginRegistry()
        AWSPlugin(self.registry)

    def test_registers_s3_catalog(self):
        plugin = self.registry.get_catalog_plugin("s3")
        assert isinstance(plugin, CatalogPlugin)
        assert plugin.type == "s3"

    def test_registers_glue_catalog(self):
        plugin = self.registry.get_catalog_plugin("glue")
        assert isinstance(plugin, CatalogPlugin)
        assert plugin.type == "glue"

    def test_registers_s3_source(self):
        source = self.registry._sources.get("s3")
        assert isinstance(source, SourcePlugin)

    def test_registers_glue_source(self):
        source = self.registry._sources.get("glue")
        assert isinstance(source, SourcePlugin)

    def test_registers_s3_sink(self):
        sink = self.registry._sinks.get("s3")
        assert isinstance(sink, SinkPlugin)

    def test_registers_glue_sink(self):
        sink = self.registry._sinks.get("glue")
        assert isinstance(sink, SinkPlugin)

    def test_exactly_six_components(self):
        assert len(self.registry._catalog_plugins) == 2
        assert len(self.registry._sources) == 2
        assert len(self.registry._sinks) == 2


# ── S3 catalog validation ─────────────────────────────────────────────────────

class TestS3CatalogValidation:
    def setup_method(self):
        self.plugin = S3CatalogPlugin()

    def test_valid_minimal_options(self):
        self.plugin.validate({"bucket": "my-bucket"})  # must not raise

    def test_valid_all_optional_options(self):
        self.plugin.validate({
            "bucket": "my-bucket",
            "prefix": "data/",
            "region": "eu-west-1",
            "endpoint_url": "https://s3.example.com",
            "format": "parquet",
            "path_style_access": True,
        })

    def test_valid_credential_options(self):
        self.plugin.validate({
            "bucket": "my-bucket",
            "access_key_id": "AKID",
            "secret_access_key": "SECRET",
            "session_token": "TOK",
            "profile": "default",
            "role_arn": "arn:aws:iam::123456789012:role/MyRole",
            "role_session_name": "session",
            "web_identity_token_file": "/var/run/secrets/token",
            "credential_cache": True,
        })

    def test_rejects_missing_bucket(self):
        with pytest.raises(PluginValidationError) as exc_info:
            self.plugin.validate({})
        assert exc_info.value.error.code == "RVT-201"
        assert "bucket" in exc_info.value.error.message

    def test_rejects_unknown_option(self):
        with pytest.raises(PluginValidationError) as exc_info:
            self.plugin.validate({"bucket": "b", "not_a_real_option": "x"})
        assert exc_info.value.error.code == "RVT-201"
        assert "not_a_real_option" in exc_info.value.error.message

    def test_rejects_invalid_format(self):
        with pytest.raises(PluginValidationError) as exc_info:
            self.plugin.validate({"bucket": "b", "format": "avro"})
        assert exc_info.value.error.code == "RVT-201"
        assert "avro" in exc_info.value.error.message

    def test_accepts_all_valid_formats(self):
        for fmt in ("parquet", "csv", "json", "orc", "delta"):
            self.plugin.validate({"bucket": "b", "format": fmt})

    def test_instantiate_returns_catalog(self):
        catalog = self.plugin.instantiate("my_s3", {"bucket": "my-bucket"})
        assert isinstance(catalog, Catalog)
        assert catalog.name == "my_s3"
        assert catalog.type == "s3"
        assert catalog.options["bucket"] == "my-bucket"

    def test_instantiate_rejects_invalid_options(self):
        with pytest.raises(PluginValidationError):
            self.plugin.instantiate("bad", {"bucket": "b", "format": "avro"})


# ── Glue catalog validation ───────────────────────────────────────────────────

class TestGlueCatalogValidation:
    def setup_method(self):
        self.plugin = GlueCatalogPlugin()

    def test_valid_minimal_options(self):
        self.plugin.validate({"database": "my_db"})  # must not raise

    def test_valid_all_optional_options(self):
        self.plugin.validate({
            "database": "my_db",
            "region": "us-west-2",
            "catalog_id": "123456789012",
            "lf_enabled": True,
        })

    def test_valid_credential_options(self):
        self.plugin.validate({
            "database": "my_db",
            "access_key_id": "AKID",
            "secret_access_key": "SECRET",
        })

    def test_accepts_empty_options(self):
        self.plugin.validate({})

    def test_rejects_invalid_auth_type(self):
        with pytest.raises(PluginValidationError) as exc_info:
            self.plugin.validate({"auth_type": "bad"})
        assert exc_info.value.error.code == "RVT-201"

    def test_rejects_unknown_option(self):
        with pytest.raises(PluginValidationError) as exc_info:
            self.plugin.validate({"database": "db", "not_a_real_option": "x"})
        assert exc_info.value.error.code == "RVT-201"
        assert "not_a_real_option" in exc_info.value.error.message

    def test_instantiate_returns_catalog(self):
        catalog = self.plugin.instantiate("my_glue", {"database": "my_db"})
        assert isinstance(catalog, Catalog)
        assert catalog.name == "my_glue"
        assert catalog.type == "glue"
        assert catalog.options["database"] == "my_db"

    def test_instantiate_rejects_invalid_options(self):
        with pytest.raises(PluginValidationError):
            self.plugin.instantiate("bad", {"unknown_key": "x"})


# ── Credential resolution with mocked boto3 ──────────────────────────────────

class TestCredentialResolutionMocked:
    def test_resolves_explicit_credentials(self):
        resolver = AWSCredentialResolver(
            {"access_key_id": "AKID", "secret_access_key": "SECRET"},
            region="us-east-1",
        )
        creds = resolver.resolve()
        assert creds.access_key_id == "AKID"
        assert creds.secret_access_key == "SECRET"
        assert creds.source == "explicit_options"

    def test_resolves_explicit_with_session_token(self):
        resolver = AWSCredentialResolver(
            {"access_key_id": "AKID", "secret_access_key": "SECRET", "session_token": "TOK"},
            region="us-east-1",
        )
        creds = resolver.resolve()
        assert creds.session_token == "TOK"

    @patch("rivet_aws.credentials.boto3.Session")
    def test_create_boto3_session_uses_resolved_creds(self, mock_session_cls):
        mock_session = MagicMock()
        mock_session_cls.return_value = mock_session

        resolver = AWSCredentialResolver(
            {"access_key_id": "AKID", "secret_access_key": "SECRET"},
            region="eu-west-1",
        )
        resolver.create_boto3_session()

        mock_session_cls.assert_called_once_with(
            aws_access_key_id="AKID",
            aws_secret_access_key="SECRET",
            aws_session_token=None,
            region_name="eu-west-1",
        )

    @patch("rivet_aws.credentials.boto3.Session")
    def test_create_client_passes_region(self, mock_session_cls):
        mock_session = MagicMock()
        mock_session_cls.return_value = mock_session

        resolver = AWSCredentialResolver(
            {"access_key_id": "AKID", "secret_access_key": "SECRET"},
            region="ap-southeast-1",
        )
        resolver.create_client("s3")

        mock_session.client.assert_called_once_with("s3", region_name="ap-southeast-1")

    @patch("rivet_aws.credentials.boto3.Session")
    def test_credential_caching(self, mock_session_cls):
        """Resolved credentials are cached and reused on second call."""
        resolver = AWSCredentialResolver(
            {"access_key_id": "AKID", "secret_access_key": "SECRET"},
            region="us-east-1",
        )
        creds1 = resolver.resolve()
        creds2 = resolver.resolve()
        assert creds1 is creds2  # same object returned from cache

    @patch("rivet_aws.credentials.boto3.Session")
    def test_profile_resolution(self, mock_session_cls):
        frozen = MagicMock()
        frozen.access_key = "PROF_KEY"
        frozen.secret_key = "PROF_SECRET"
        frozen.token = None
        mock_creds = MagicMock()
        mock_creds.get_frozen_credentials.return_value = frozen
        mock_session = MagicMock()
        mock_session.get_credentials.return_value = mock_creds
        mock_session_cls.return_value = mock_session

        resolver = AWSCredentialResolver({"profile": "myprofile"}, region="us-east-1")
        creds = resolver.resolve()

        assert creds.access_key_id == "PROF_KEY"
        assert creds.secret_access_key == "PROF_SECRET"
        assert creds.source == "aws_profile"
