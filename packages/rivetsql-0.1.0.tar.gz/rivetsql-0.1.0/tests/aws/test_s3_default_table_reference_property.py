"""Property test for S3 default table reference format.

Feature: cross-storage-adapters, Property 5: S3 default table reference format
Generate random bucket names, prefixes, logical names, formats; verify output pattern.
Validates: Requirements 3.4
"""

from __future__ import annotations

from hypothesis import given, settings
from hypothesis import strategies as st

from rivet_aws.s3_catalog import S3CatalogPlugin

_VALID_FORMATS = ["parquet", "csv", "json", "orc", "delta"]

# S3 bucket names: 3-63 chars, lowercase letters/digits/hyphens, start/end with letter or digit
_bucket_st = st.from_regex(r"[a-z0-9][a-z0-9\-]{1,61}[a-z0-9]", fullmatch=True)
# Prefix: empty or non-empty path segment (no leading/trailing slash)
_prefix_st = st.one_of(
    st.just(""),
    st.from_regex(r"[a-z0-9][a-z0-9/_\-]{0,30}", fullmatch=True),
)
# Logical name: non-empty identifier
_name_st = st.from_regex(r"[a-z][a-z0-9_]{0,29}", fullmatch=True)
_format_st = st.sampled_from(_VALID_FORMATS)

_plugin = S3CatalogPlugin()


@settings(max_examples=100, deadline=None)
@given(
    bucket=_bucket_st,
    prefix=_prefix_st,
    logical_name=_name_st,
    fmt=_format_st,
)
def test_property_s3_default_table_reference_format(
    bucket: str, prefix: str, logical_name: str, fmt: str
) -> None:
    """Property 5: default_table_reference always produces s3://{bucket}/{prefix}/{name}.{format}.

    When prefix is empty, the prefix segment is omitted.
    """
    options: dict = {"bucket": bucket, "format": fmt}
    if prefix:
        options["prefix"] = prefix

    ref = _plugin.default_table_reference(logical_name, options)

    # Must start with s3://
    assert ref.startswith("s3://"), f"Expected s3:// scheme, got: {ref!r}"

    # Must end with .{format}
    assert ref.endswith(f".{fmt}"), f"Expected .{fmt} suffix, got: {ref!r}"

    # Must contain the bucket
    assert f"s3://{bucket}/" in ref, f"Expected bucket {bucket!r} in ref: {ref!r}"

    # Must contain the logical name before the extension
    stem = ref[len("s3://"):]  # strip scheme
    path_without_ext = stem[: -len(f".{fmt}")]
    assert path_without_ext.endswith(logical_name), (
        f"Expected path to end with {logical_name!r}, got: {path_without_ext!r}"
    )

    # Verify exact structure
    if prefix:
        expected = f"s3://{bucket}/{prefix}/{logical_name}.{fmt}"
    else:
        expected = f"s3://{bucket}/{logical_name}.{fmt}"

    assert ref == expected, f"Expected {expected!r}, got {ref!r}"
