"""Property test for rivet_aws import boundary enforcement.

Property 1: Import boundary enforcement
Validates Requirements 1.4, 1.5 — rivet_aws must only import from rivet_core
(no other rivet_* modules, no engine-specific dependencies).
"""

from __future__ import annotations

import ast
import re
from pathlib import Path

from hypothesis import given, settings
from hypothesis import strategies as st

RIVET_AWS_SRC = Path(__file__).resolve().parent.parent.parent / "src" / "rivet_aws"

# Forbidden engine-specific modules (Requirement 1.4)
FORBIDDEN_MODULES = frozenset(
    ["duckdb", "polars", "pyspark", "databricks", "databricks_sdk"]
)

# Only rivet_core is allowed from the rivet_* namespace (Requirement 1.5)
_RIVET_IMPORT_RE = re.compile(r"(?:from|import)\s+(rivet_[a-z_]+)")


def _collect_rivet_aws_py_files() -> list[Path]:
    return sorted(RIVET_AWS_SRC.rglob("*.py"))


def _extract_imports(source: str) -> list[str]:
    """Return all top-level module names imported in *source*."""
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []
    modules: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                modules.append(alias.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                modules.append(node.module.split(".")[0])
    return modules


# --- Static tests (run unconditionally) ---


def test_rivet_aws_src_exists():
    """Sanity: the rivet_aws source directory must exist."""
    assert RIVET_AWS_SRC.is_dir(), f"rivet_aws source not found at {RIVET_AWS_SRC}"


def test_no_forbidden_engine_imports():
    """No rivet_aws file may import engine-specific packages (duckdb, polars, etc.)."""
    violations: list[str] = []
    for py_file in _collect_rivet_aws_py_files():
        source = py_file.read_text()
        for module in _extract_imports(source):
            if module in FORBIDDEN_MODULES:
                violations.append(f"{py_file.name}: imports '{module}'")
    assert violations == [], (
        "rivet_aws imports forbidden engine-specific modules:\n"
        + "\n".join(f"  {v}" for v in violations)
    )


def test_no_cross_plugin_rivet_imports():
    """No rivet_aws file may import any rivet_* module other than rivet_core or rivet_aws."""
    violations: list[str] = []
    for py_file in _collect_rivet_aws_py_files():
        source = py_file.read_text()
        for m in _RIVET_IMPORT_RE.finditer(source):
            imported = m.group(1)
            if imported not in ("rivet_core", "rivet_aws"):
                violations.append(f"{py_file.name}: imports '{imported}'")
    assert violations == [], (
        "rivet_aws imports forbidden rivet_* modules:\n"
        + "\n".join(f"  {v}" for v in violations)
    )


# --- Property test using hypothesis ---


@settings(max_examples=100, deadline=None)
@given(
    forbidden=st.sampled_from(sorted(FORBIDDEN_MODULES)),
)
def test_property_forbidden_module_not_in_any_file(forbidden: str):
    """Property: for every forbidden module name, no rivet_aws .py file imports it."""
    for py_file in _collect_rivet_aws_py_files():
        source = py_file.read_text()
        imported_modules = _extract_imports(source)
        assert forbidden not in imported_modules, (
            f"{py_file.name} imports forbidden module '{forbidden}'"
        )


@settings(max_examples=100, deadline=None)
@given(
    py_file=st.sampled_from(_collect_rivet_aws_py_files()),
)
def test_property_each_file_only_imports_allowed_rivet_modules(py_file: Path):
    """Property: every rivet_aws .py file only imports rivet_core (not other plugins)."""
    source = py_file.read_text()
    for m in _RIVET_IMPORT_RE.finditer(source):
        imported = m.group(1)
        assert imported in ("rivet_core", "rivet_aws"), (
            f"{py_file.name} imports forbidden rivet module '{imported}'"
        )
