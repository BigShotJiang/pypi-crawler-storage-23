"""Property 16: Error payload structure.

Trigger various validation errors from rivet_aws modules; verify each payload
contains plugin_name = "rivet_aws", an RVT-2xx code, and non-empty remediation.

Validates: Requirements 11.1, 11.2
"""

from __future__ import annotations

import re

import pytest
from hypothesis import given, settings
from hypothesis import strategies as st

from rivet_aws.glue_catalog import GlueCatalogPlugin
from rivet_aws.glue_sink import UNSUPPORTED_STRATEGIES, _validate_sink_options
from rivet_aws.s3_catalog import _VALID_FORMATS as S3_VALID_FORMATS
from rivet_aws.s3_catalog import S3CatalogPlugin
from rivet_core.errors import PluginValidationError

_RVT_2XX = re.compile(r"^RVT-2\d{2}$")

_s3_plugin = S3CatalogPlugin()
_glue_plugin = GlueCatalogPlugin()


def _assert_valid_payload(exc: PluginValidationError) -> None:
    """Assert the error payload satisfies Requirements 11.1 and 11.2."""
    err = exc.error
    assert err.context.get("plugin_name") == "rivet_aws", (
        f"Expected plugin_name='rivet_aws', got {err.context.get('plugin_name')!r}"
    )
    assert _RVT_2XX.match(err.code), f"Expected RVT-2xx code, got {err.code!r}"
    assert err.remediation, "remediation must be non-empty"


# ── S3 catalog: invalid format ────────────────────────────────────────

_invalid_s3_format = st.text(min_size=1).filter(lambda s: s not in S3_VALID_FORMATS)


@settings(max_examples=100, deadline=None)
@given(fmt=_invalid_s3_format)
def test_s3_invalid_format_payload(fmt: str) -> None:
    """S3 invalid format → PluginValidationError with correct payload."""
    with pytest.raises(PluginValidationError) as exc_info:
        _s3_plugin.validate({"bucket": "my-bucket", "format": fmt})
    _assert_valid_payload(exc_info.value)


# ── S3 catalog: missing required option ──────────────────────────────

def test_s3_missing_bucket_payload() -> None:
    """S3 missing bucket → PluginValidationError with correct payload."""
    with pytest.raises(PluginValidationError) as exc_info:
        _s3_plugin.validate({})
    _assert_valid_payload(exc_info.value)


# ── Glue catalog: invalid auth_type ──────────────────────────────────

def test_glue_invalid_auth_type_payload() -> None:
    """Glue invalid auth_type → PluginValidationError with correct payload."""
    with pytest.raises(PluginValidationError) as exc_info:
        _glue_plugin.validate({"auth_type": "bad"})
    _assert_valid_payload(exc_info.value)


# ── Glue sink: unsupported strategies ────────────────────────────────

@settings(max_examples=100, deadline=None)
@given(strategy=st.sampled_from(sorted(UNSUPPORTED_STRATEGIES)))
def test_glue_sink_unsupported_strategy_payload(strategy: str) -> None:
    """Glue sink merge/scd2 → PluginValidationError with correct payload."""
    with pytest.raises(PluginValidationError) as exc_info:
        _validate_sink_options({"table": "t", "write_strategy": strategy})
    _assert_valid_payload(exc_info.value)


# ── Glue sink: unknown option ─────────────────────────────────────────

_known_glue_sink_opts = {
    "table", "write_strategy", "partition_by", "format",
    "compression", "create_table", "update_schema", "lf_tags",
}
_unknown_glue_opt = st.text(
    alphabet=st.characters(whitelist_categories=("Ll",), whitelist_characters="_"),
    min_size=1,
    max_size=20,
).filter(lambda s: s not in _known_glue_sink_opts)


@settings(max_examples=100, deadline=None)
@given(opt=_unknown_glue_opt)
def test_glue_sink_unknown_option_payload(opt: str) -> None:
    """Glue sink unknown option → PluginValidationError with correct payload."""
    with pytest.raises(PluginValidationError) as exc_info:
        _validate_sink_options({"table": "t", opt: "value"})
    _assert_valid_payload(exc_info.value)
