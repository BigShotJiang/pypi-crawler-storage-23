"""Tests for rivet_aws.glue_utils shared Glue resolution utilities."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from rivet_aws.glue_utils import matches_partition_filter, resolve_glue_table
from rivet_core.errors import ExecutionError

# ── matches_partition_filter ──────────────────────────────────────────────────


class TestMatchesPartitionFilter:
    def test_exact_match(self):
        assert matches_partition_filter({"year": "2024"}, {"year": "2024"})

    def test_no_match(self):
        assert not matches_partition_filter({"year": "2023"}, {"year": "2024"})

    def test_multiple_keys(self):
        assert matches_partition_filter(
            {"year": "2024", "month": "01"}, {"year": "2024", "month": "01"}
        )

    def test_partial_match_fails(self):
        assert not matches_partition_filter(
            {"year": "2024", "month": "02"}, {"year": "2024", "month": "01"}
        )

    def test_empty_filter_matches_all(self):
        assert matches_partition_filter({"year": "2024"}, {})

    def test_value_coerced_to_string(self):
        assert matches_partition_filter({"year": "2024"}, {"year": 2024})

    def test_missing_key_fails(self):
        assert not matches_partition_filter({}, {"year": "2024"})


# ── resolve_glue_table ───────────────────────────────────────────────────────


def _glue_table_response(
    location: str = "s3://bucket/db/tbl",
    input_format: str = "org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat",
    partition_keys: list[dict] | None = None,
) -> dict:
    return {
        "Table": {
            "StorageDescriptor": {"Location": location, "InputFormat": input_format},
            "PartitionKeys": partition_keys or [],
        }
    }


class TestResolveGlueTable:
    def test_unpartitioned_table(self):
        client = MagicMock()
        client.get_table.return_value = _glue_table_response()

        location, fmt, pk, plocs = resolve_glue_table(
            client, "test_db", "tbl", None
        )
        assert location == "s3://bucket/db/tbl"
        assert "parquet" in fmt.lower()
        assert pk == []
        assert plocs == []

    def test_partitioned_table_no_filter(self):
        client = MagicMock()
        client.get_table.return_value = _glue_table_response(
            partition_keys=[{"Name": "year"}]
        )
        paginator = MagicMock()
        paginator.paginate.return_value = [
            {"Partitions": [
                {"Values": ["2023"], "StorageDescriptor": {"Location": "s3://b/year=2023"}},
                {"Values": ["2024"], "StorageDescriptor": {"Location": "s3://b/year=2024"}},
            ]}
        ]
        client.get_paginator.return_value = paginator

        _, _, pk, plocs = resolve_glue_table(client, "db", "tbl", None)
        assert pk == ["year"]
        assert len(plocs) == 2

    def test_partitioned_table_with_filter(self):
        client = MagicMock()
        client.get_table.return_value = _glue_table_response(
            partition_keys=[{"Name": "year"}]
        )
        paginator = MagicMock()
        paginator.paginate.return_value = [
            {"Partitions": [
                {"Values": ["2023"], "StorageDescriptor": {"Location": "s3://b/year=2023"}},
                {"Values": ["2024"], "StorageDescriptor": {"Location": "s3://b/year=2024"}},
            ]}
        ]
        client.get_paginator.return_value = paginator

        _, _, _, plocs = resolve_glue_table(client, "db", "tbl", {"year": "2024"})
        assert plocs == ["s3://b/year=2024"]

    def test_table_not_found_raises(self):
        client = MagicMock()
        client.get_table.side_effect = Exception("Not found")

        with pytest.raises(ExecutionError) as exc_info:
            resolve_glue_table(client, "db", "missing", None)
        assert exc_info.value.error.code == "RVT-503"

    def test_catalog_id_passed(self):
        client = MagicMock()
        client.get_table.return_value = _glue_table_response()

        resolve_glue_table(client, "db", "tbl", None, catalog_id="123")
        call_kwargs = client.get_table.call_args[1]
        assert call_kwargs["CatalogId"] == "123"

    def test_custom_plugin_name_in_error(self):
        client = MagicMock()
        client.get_table.side_effect = Exception("fail")

        with pytest.raises(ExecutionError) as exc_info:
            resolve_glue_table(
                client, "db", "tbl", None, plugin_name="rivet_duckdb"
            )
        assert "rivet_duckdb" in str(exc_info.value.error.context.get("plugin_name", ""))
