"""Property test for explicit region on all boto3 clients.

Feature: cross-storage-adapters, Property 4: Explicit region on all boto3 clients

For any call to AWSCredentialResolver.create_client() or create_boto3_session(),
the resulting boto3 client or session SHALL have an explicit region_name set (never None).

Validates: Requirements 2.6
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from hypothesis import given, settings
from hypothesis import strategies as st

from rivet_aws.credentials import AWSCredentialResolver

# Valid AWS region names to test with
AWS_REGIONS = [
    "us-east-1",
    "us-east-2",
    "us-west-1",
    "us-west-2",
    "eu-west-1",
    "eu-west-2",
    "eu-central-1",
    "ap-southeast-1",
    "ap-southeast-2",
    "ap-northeast-1",
    "sa-east-1",
    "ca-central-1",
]

AWS_SERVICES = ["s3", "glue", "sts", "lakeformation", "iam"]

region_strategy = st.sampled_from(AWS_REGIONS)
service_strategy = st.sampled_from(AWS_SERVICES)


@settings(max_examples=100, deadline=None)
@given(region=region_strategy)
def test_property_create_boto3_session_always_has_region(region: str):
    """Property 4: create_boto3_session always passes explicit region_name."""
    with patch("rivet_aws.credentials.boto3.Session") as mock_session_cls:
        mock_session_cls.return_value = MagicMock()
        resolver = AWSCredentialResolver(
            {"access_key_id": "AKID", "secret_access_key": "SECRET", "credential_cache": False},
            region=region,
        )
        resolver.create_boto3_session()

    # Verify Session was called with the explicit region_name
    assert mock_session_cls.called
    _, kwargs = mock_session_cls.call_args
    assert "region_name" in kwargs, "region_name must be explicitly passed to boto3.Session"
    assert kwargs["region_name"] == region, f"Expected region '{region}', got '{kwargs['region_name']}'"
    assert kwargs["region_name"] is not None, "region_name must not be None"


@settings(max_examples=100, deadline=None)
@given(region=region_strategy, service=service_strategy)
def test_property_create_client_always_has_region(region: str, service: str):
    """Property 4: create_client always passes explicit region_name to the client call."""
    mock_client = MagicMock()
    mock_session = MagicMock()
    mock_session.client.return_value = mock_client

    with patch("rivet_aws.credentials.boto3.Session") as mock_session_cls:
        mock_session_cls.return_value = mock_session
        resolver = AWSCredentialResolver(
            {"access_key_id": "AKID", "secret_access_key": "SECRET", "credential_cache": False},
            region=region,
        )
        result = resolver.create_client(service)

    # Verify client was called with explicit region_name
    mock_session.client.assert_called_once()
    args, kwargs = mock_session.client.call_args
    assert "region_name" in kwargs, "region_name must be explicitly passed to session.client()"
    assert kwargs["region_name"] == region, f"Expected region '{region}', got '{kwargs['region_name']}'"
    assert kwargs["region_name"] is not None, "region_name must not be None"
    assert result is mock_client


@settings(max_examples=100, deadline=None)
@given(region=region_strategy)
def test_property_session_region_matches_resolver_region(region: str):
    """Property 4: The region passed to boto3.Session matches the resolver's configured region."""
    with patch("rivet_aws.credentials.boto3.Session") as mock_session_cls:
        mock_session_cls.return_value = MagicMock()
        resolver = AWSCredentialResolver(
            {"access_key_id": "K", "secret_access_key": "S", "credential_cache": False},
            region=region,
        )
        resolver.create_boto3_session()

    _, kwargs = mock_session_cls.call_args
    # The region in the session must exactly match what was configured
    assert kwargs["region_name"] == region


@settings(max_examples=100, deadline=None)
@given(region=region_strategy, service=service_strategy)
def test_property_client_region_matches_resolver_region(region: str, service: str):
    """Property 4: The region passed to session.client() matches the resolver's configured region."""
    mock_session = MagicMock()
    mock_session.client.return_value = MagicMock()

    with patch("rivet_aws.credentials.boto3.Session") as mock_session_cls:
        mock_session_cls.return_value = mock_session
        resolver = AWSCredentialResolver(
            {"access_key_id": "K", "secret_access_key": "S", "credential_cache": False},
            region=region,
        )
        resolver.create_client(service)

    _, kwargs = mock_session.client.call_args
    assert kwargs["region_name"] == region
