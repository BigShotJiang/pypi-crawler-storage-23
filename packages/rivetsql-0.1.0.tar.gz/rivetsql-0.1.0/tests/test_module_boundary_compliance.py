"""Test module boundary compliance across rivet/src/.

# Feature: codebase-cleanup, Property 8: Module boundary compliance
# Feature: project-grooming, Property 1: Module boundary compliance

Validates Requirements 4.4, 8.1, 8.2, 8.3 — every `from rivet_*` import in source
must comply with the allowed-imports map defined in the architecture.
"""

from __future__ import annotations

import sys
from pathlib import Path

# Ensure the scripts directory is importable
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))

from check_module_boundaries import (  # noqa: E402
    ALLOWED_RIVET_IMPORTS,
    scan_boundary_violations,
)

SRC_DIR = Path(__file__).resolve().parent.parent / "src"

# --- Known violations that remain after boundary fixes (tasks 9.1–9.6) ---
KNOWN_VIOLATIONS: set[tuple[str, str, str]] = set()


def test_boundary_rules_cover_all_modules():
    """Every rivet_* directory under src/ must have an entry in ALLOWED_RIVET_IMPORTS."""
    for d in sorted(SRC_DIR.iterdir()):
        if d.is_dir() and d.name.startswith("rivet_"):
            assert d.name in ALLOWED_RIVET_IMPORTS, (
                f"Module {d.name} has no boundary rule in ALLOWED_RIVET_IMPORTS"
            )


def test_no_unknown_boundary_violations():
    """All violations must be in the known-violations set (no NEW violations)."""
    violations = scan_boundary_violations(SRC_DIR)
    unknown = [
        v
        for v in violations
        if (v.file, v.source_module, v.imported_module) not in KNOWN_VIOLATIONS
    ]
    assert unknown == [], (
        "Unexpected boundary violations:\n"
        + "\n".join(
            f"  {v.file}:{v.line_no} [{v.source_module} → {v.imported_module}] {v.line_text}"
            for v in unknown
        )
    )


def test_known_violations_documented():
    """The scanner finds exactly the known violations (no more, no fewer)."""
    violations = scan_boundary_violations(SRC_DIR)
    found = {(v.file, v.source_module, v.imported_module) for v in violations}
    # Every known violation should still be present (until fixed by tasks 5.2–5.5)
    missing = KNOWN_VIOLATIONS - found
    # It's OK if some are already fixed — just ensure no *new* unknowns
    extra = found - KNOWN_VIOLATIONS
    assert extra == set(), f"New unknown violations: {extra}"
    # Report which known violations are already fixed (informational)
    if missing:
        print(f"INFO: {len(missing)} known violation(s) already fixed: {missing}")


def test_scanner_returns_correct_violation_count():
    """Sanity check: scanner finds the expected number of violations."""
    violations = scan_boundary_violations(SRC_DIR)
    # We expect 14 violations based on the scan (some files have multiple lines)
    assert len(violations) >= len(KNOWN_VIOLATIONS), (
        f"Expected at least {len(KNOWN_VIOLATIONS)} violations, got {len(violations)}"
    )


def test_no_boundary_violations_from_import_reordering():
    """Verify ruff auto-fix import reordering introduced no new boundary violations.

    # Feature: project-grooming, Property 1: Module boundary compliance
    Validates Requirement 4.4.

    After `ruff check --fix` reorders imports, every violation found must be
    in the pre-existing KNOWN_VIOLATIONS set.  Any new entry means the auto-fix
    moved an import across a module boundary.
    """
    violations = scan_boundary_violations(SRC_DIR)
    new_violations = [
        v
        for v in violations
        if (v.file, v.source_module, v.imported_module) not in KNOWN_VIOLATIONS
    ]
    assert new_violations == [], (
        "Import reordering introduced new module boundary violations:\n"
        + "\n".join(
            f"  {v.file}:{v.line_no} [{v.source_module} → {v.imported_module}] {v.line_text}"
            for v in new_violations
        )
    )
