"""Tests for run text renderer (rendering/run_text.py)."""

from __future__ import annotations

import re

from rivet_cli.rendering.colors import CYAN, GREEN, MAGENTA, RED, YELLOW
from rivet_cli.rendering.run_text import render_run_text
from rivet_core.checks import CompiledCheck
from rivet_core.compiler import (
    CompiledAssembly,
    CompiledCatalog,
    CompiledEngine,
    CompiledJoint,
    OptimizationResult,
)
from rivet_core.executor import (
    CheckExecutionResult,
    ExecutionResult,
    JointExecutionResult,
)
from rivet_core.lineage import ColumnLineage
from rivet_core.metrics import PhasedTiming
from rivet_core.models import Schema

ANSI_RE = re.compile(r"\033\[")


def _joint(name: str, type: str = "sql", *, engine: str = "duckdb_1",
           checks: list[CompiledCheck] | None = None,
           optimizations: list[OptimizationResult] | None = None,
           schema: Schema | None = None,
           lineage: list[ColumnLineage] | None = None) -> CompiledJoint:
    return CompiledJoint(
        name=name, type=type, catalog=None, catalog_type=None,
        engine=engine, engine_resolution="project_default", adapter=None,
        sql=None, sql_translated=None, sql_resolved=None, sql_dialect=None,
        engine_dialect=None, upstream=[], eager=False, table=None,
        write_strategy=None, function=None, source_file=None, logical_plan=None,
        output_schema=schema, column_lineage=lineage or [],
        optimizations=optimizations or [], checks=checks or [],
        fused_group_id=None, tags=[], description=None,
        fusion_strategy_override=None, materialization_strategy_override=None,
    )


def _compiled(joints: list[CompiledJoint] | None = None) -> CompiledAssembly:
    return CompiledAssembly(
        success=True, profile_name="default",
        catalogs=[CompiledCatalog(name="cat", type="fs")],
        engines=[CompiledEngine(name="duckdb_1", engine_type="duckdb", native_catalog_types=[])],
        adapters=[], joints=joints or [], fused_groups=[], materializations=[],
        execution_order=[], errors=[], warnings=[],
    )


def _exec_result(joint_results: list[JointExecutionResult] | None = None,
                 success: bool = True, total_failures: int = 0) -> ExecutionResult:
    jrs = joint_results or []
    return ExecutionResult(
        success=success, status="success" if success else "failure",
        joint_results=jrs, group_results=[],
        total_time_ms=100.0, total_materializations=0,
        total_failures=total_failures, total_check_failures=0, total_check_warnings=0,
    )


def _jr(name: str = "j1", success: bool = True, rows_out: int = 50,
        check_results: list[CheckExecutionResult] | None = None,
        materialized: bool = False) -> JointExecutionResult:
    return JointExecutionResult(
        name=name, success=success, rows_in=None, rows_out=rows_out,
        timing=PhasedTiming(total_ms=10.0, engine_ms=8.0, materialize_ms=1.0, residual_ms=0.5, check_ms=0.5),
        fused_group_id=None, materialized=materialized,
        materialization_trigger="engine_change" if materialized else None,
        materialization_stats=None, check_results=check_results or [],
        plugin_metrics=None, error=None,
    )


class TestRenderRunText:
    def test_joint_status_ok(self):
        out = render_run_text(_exec_result([_jr()]), _compiled([_joint("j1")]), 0, False)
        assert "j1" in out
        assert "OK" in out

    def test_joint_status_fail(self):
        out = render_run_text(_exec_result([_jr(success=False)], success=False, total_failures=1),
                              _compiled([_joint("j1")]), 0, False)
        assert "FAIL" in out

    def test_rows_and_timing(self):
        out = render_run_text(_exec_result([_jr(rows_out=42)]), _compiled([_joint("j1")]), 0, False)
        assert "42 rows" in out
        assert "10ms" in out

    def test_materialization_indicator(self):
        out = render_run_text(_exec_result([_jr(materialized=True)]), _compiled([_joint("j1")]), 0, False)
        assert "⚡" in out
        assert "materialized" in out

    def test_summary_line(self):
        out = render_run_text(_exec_result([_jr()]), _compiled([_joint("j1")]), 0, False)
        assert "100ms" in out
        assert "1 joints" in out

    def test_assertion_result(self):
        cr = CheckExecutionResult(type="not_null", severity="error", passed=True,
                                  message="ok", phase="assertion")
        out = render_run_text(_exec_result([_jr(check_results=[cr])]),
                              _compiled([_joint("j1")]), 0, False)
        assert "◆" in out
        assert "PASS" in out

    def test_audit_result(self):
        cr = CheckExecutionResult(type="row_count", severity="warning", passed=False,
                                  message="mismatch", phase="audit")
        out = render_run_text(_exec_result([_jr(check_results=[cr])]),
                              _compiled([_joint("j1")]), 0, False)
        assert "●" in out
        assert "FAIL" in out

    def test_assertion_failure_details(self):
        cr = CheckExecutionResult(type="not_null", severity="error", passed=False,
                                  message="null found", phase="assertion")
        out = render_run_text(_exec_result([_jr(check_results=[cr])]),
                              _compiled([_joint("j1")]), 0, False)
        assert "RVT-601" in out
        assert "violation" in out

    def test_quality_summary(self):
        cr = CheckExecutionResult(type="not_null", severity="error", passed=True,
                                  message="ok", phase="assertion")
        out = render_run_text(_exec_result([_jr(check_results=[cr])]),
                              _compiled([_joint("j1")]), 0, False)
        assert "Quality:" in out
        assert "1 checks" in out


class TestProperty3RunText:
    def test_no_ansi_when_color_false(self):
        cr = CheckExecutionResult(type="not_null", severity="error", passed=False,
                                  message="null", phase="assertion")
        out = render_run_text(
            _exec_result([_jr(check_results=[cr], materialized=True)]),
            _compiled([_joint("j1")]), 0, False,
        )
        assert not ANSI_RE.search(out)


class TestProperty6RunText:
    def test_success_green(self):
        out = render_run_text(_exec_result([_jr()]), _compiled([_joint("j1")]), 0, True)
        assert GREEN in out

    def test_failure_red(self):
        out = render_run_text(_exec_result([_jr(success=False)], success=False, total_failures=1),
                              _compiled([_joint("j1")]), 0, True)
        assert RED in out

    def test_assertion_cyan(self):
        cr = CheckExecutionResult(type="not_null", severity="error", passed=True,
                                  message="ok", phase="assertion")
        out = render_run_text(_exec_result([_jr(check_results=[cr])]),
                              _compiled([_joint("j1")]), 0, True)
        assert CYAN in out

    def test_audit_magenta(self):
        cr = CheckExecutionResult(type="row_count", severity="warning", passed=True,
                                  message="ok", phase="audit")
        out = render_run_text(_exec_result([_jr(check_results=[cr])]),
                              _compiled([_joint("j1")]), 0, True)
        assert MAGENTA in out

    def test_materialization_yellow(self):
        out = render_run_text(_exec_result([_jr(materialized=True)]),
                              _compiled([_joint("j1")]), 0, True)
        assert YELLOW in out
