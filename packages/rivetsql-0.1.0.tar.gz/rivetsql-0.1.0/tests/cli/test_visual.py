"""Tests for visual renderer (rendering/visual.py).

Validates Property 3, Property 6, and Property 12.
"""

from __future__ import annotations

import re

from rivet_cli.rendering.colors import CYAN, GREEN, MAGENTA, YELLOW
from rivet_cli.rendering.visual import render_visual
from rivet_core.checks import CompiledCheck
from rivet_core.compiler import (
    CompiledAdapter,
    CompiledAssembly,
    CompiledCatalog,
    CompiledEngine,
    CompiledJoint,
    EngineBoundary,
    Materialization,
    OptimizationResult,
)
from rivet_core.lineage import ColumnLineage
from rivet_core.models import Column, Schema
from rivet_core.optimizer import FusedGroup

ANSI_RE = re.compile(r"\033\[")


def _joint(
    name: str,
    type: str = "sql",
    *,
    catalog: str | None = None,
    catalog_type: str | None = None,
    engine: str = "duckdb_1",
    upstream: list[str] | None = None,
    sql: str | None = None,
    schema: Schema | None = None,
    checks: list[CompiledCheck] | None = None,
    optimizations: list[OptimizationResult] | None = None,
    lineage: list[ColumnLineage] | None = None,
    fused_group_id: str | None = None,
    logical_plan: str | None = None,
) -> CompiledJoint:
    return CompiledJoint(
        name=name, type=type, catalog=catalog, catalog_type=catalog_type,
        engine=engine, engine_resolution="project_default", adapter=None,
        sql=sql, sql_translated=None, sql_resolved=None, sql_dialect=None,
        engine_dialect=None, upstream=upstream or [], eager=False, table=None,
        write_strategy=None, function=None, source_file=None,
        logical_plan=logical_plan, output_schema=schema,
        column_lineage=lineage or [], optimizations=optimizations or [],
        checks=checks or [], fused_group_id=fused_group_id, tags=[],
        description=None, fusion_strategy_override=None,
        materialization_strategy_override=None,
    )


def _assembly(
    joints: list[CompiledJoint],
    fused_groups: list[FusedGroup] | None = None,
    materializations: list[Materialization] | None = None,
    execution_order: list[str] | None = None,
) -> CompiledAssembly:
    return CompiledAssembly(
        success=True, profile_name="default",
        catalogs=[CompiledCatalog(name="my_cat", type="filesystem")],
        engines=[CompiledEngine(name="duckdb_1", engine_type="duckdb", native_catalog_types=["filesystem"])],
        adapters=[CompiledAdapter(engine_type="duckdb", catalog_type="filesystem", source="builtin")],
        joints=joints, fused_groups=fused_groups or [],
        materializations=materializations or [],
        execution_order=execution_order or [],
        errors=[], warnings=[],
    )


class TestRenderVisualBasic:
    def test_contains_header(self):
        out = render_visual(_assembly([]), 0, False)
        assert "Compilation Result" in out
        assert "Profile: default" in out

    def test_contains_catalogs_and_engines(self):
        out = render_visual(_assembly([]), 0, False)
        assert "my_cat" in out
        assert "duckdb_1" in out

    def test_contains_summary(self):
        out = render_visual(_assembly([]), 1, False)
        assert "Summary" in out
        assert "Joints: 0" in out

    def test_single_joint_no_fused_border(self):
        j = _joint("j1", fused_group_id="g1")
        fg = FusedGroup(id="g1", joints=["j1"], engine="duckdb_1", engine_type="duckdb",
                        adapters={"j1": None}, fused_sql=None)
        out = render_visual(_assembly([j], [fg], execution_order=["g1"]), 0, False)
        assert "j1" in out
        assert "Fused Group" not in out

    def test_fused_group_border(self):
        j1 = _joint("a", fused_group_id="g1")
        j2 = _joint("b", upstream=["a"], fused_group_id="g1")
        fg = FusedGroup(id="g1", joints=["a", "b"], engine="duckdb_1", engine_type="duckdb",
                        adapters={"a": None, "b": None}, fused_sql="WITH a AS (...) SELECT * FROM a")
        out = render_visual(_assembly([j1, j2], [fg], execution_order=["g1"]), 0, False)
        assert "Fused Group" in out
        assert "╔" in out
        assert "╚" in out


class TestProperty12:
    """Property 12: Visual output contains all fused groups and materializations."""

    def test_fused_group_count(self):
        j1 = _joint("a", fused_group_id="g1")
        j2 = _joint("b", upstream=["a"], fused_group_id="g1")
        j3 = _joint("c", engine="spark_1", fused_group_id="g2")
        j4 = _joint("d", engine="spark_1", upstream=["c"], fused_group_id="g2")
        fg1 = FusedGroup(id="g1", joints=["a", "b"], engine="duckdb_1", engine_type="duckdb",
                         adapters={"a": None, "b": None}, fused_sql="sql1")
        fg2 = FusedGroup(id="g2", joints=["c", "d"], engine="spark_1", engine_type="spark",
                         adapters={"c": None, "d": None}, fused_sql="sql2")
        mat = Materialization(from_joint="b", to_joint="c", trigger="engine_instance_change",
                              detail="engine changes", strategy="arrow")
        asm = _assembly([j1, j2, j3, j4], [fg1, fg2], [mat], ["g1", "g2"])
        asm = CompiledAssembly(
            success=asm.success, profile_name=asm.profile_name, catalogs=asm.catalogs,
            engines=[
                CompiledEngine(name="duckdb_1", engine_type="duckdb", native_catalog_types=["filesystem"]),
                CompiledEngine(name="spark_1", engine_type="spark", native_catalog_types=[]),
            ],
            adapters=asm.adapters, joints=asm.joints, fused_groups=asm.fused_groups,
            materializations=asm.materializations, execution_order=asm.execution_order,
            errors=[], warnings=[],
        )
        out = render_visual(asm, 0, False)
        assert out.count("Fused Group") == 2

    def test_materialization_count(self):
        j1 = _joint("a", fused_group_id="g1")
        j2 = _joint("b", engine="spark_1", upstream=["a"], fused_group_id="g2")
        fg1 = FusedGroup(id="g1", joints=["a"], engine="duckdb_1", engine_type="duckdb",
                         adapters={"a": None}, fused_sql=None)
        fg2 = FusedGroup(id="g2", joints=["b"], engine="spark_1", engine_type="spark",
                         adapters={"b": None}, fused_sql=None)
        mat = Materialization(from_joint="a", to_joint="b", trigger="engine_instance_change",
                              detail="engine changes", strategy="arrow")
        out = render_visual(_assembly([j1, j2], [fg1, fg2], [mat], ["g1", "g2"]), 0, False)
        assert "⚡" in out
        assert "materialization" in out


class TestProperty3Visual:
    """Property 3: No-color mode produces no ANSI escape codes."""

    def test_no_ansi_when_color_false(self):
        j = _joint("j1", checks=[
            CompiledCheck(type="not_null", severity="error", config={"column": "id"}, phase="assertion"),
            CompiledCheck(type="row_count", severity="warning", config={}, phase="audit"),
        ], optimizations=[
            OptimizationResult(rule="pushdown", status="applied", detail="ok"),
        ])
        out = render_visual(_assembly([j]), 0, False)
        assert not ANSI_RE.search(out)


class TestProperty6Visual:
    """Property 6: Color output uses correct ANSI codes per element type."""

    def test_assertion_uses_cyan(self):
        j = _joint("j1", checks=[
            CompiledCheck(type="not_null", severity="error", config={"column": "id"}, phase="assertion"),
        ])
        out = render_visual(_assembly([j]), 1, True)
        assert CYAN in out

    def test_audit_uses_magenta(self):
        j = _joint("j1", checks=[
            CompiledCheck(type="row_count", severity="warning", config={}, phase="audit"),
        ])
        out = render_visual(_assembly([j]), 1, True)
        assert MAGENTA in out

    def test_success_uses_green(self):
        out = render_visual(_assembly([]), 0, True)
        # Summary validation line uses green for success
        assert GREEN in out

    def test_materialization_uses_yellow(self):
        j1 = _joint("a", fused_group_id="g1")
        j2 = _joint("b", upstream=["a"], fused_group_id="g2")
        fg1 = FusedGroup(id="g1", joints=["a"], engine="duckdb_1", engine_type="duckdb",
                         adapters={"a": None}, fused_sql=None)
        fg2 = FusedGroup(id="g2", joints=["b"], engine="duckdb_1", engine_type="duckdb",
                         adapters={"b": None}, fused_sql=None)
        mat = Materialization(from_joint="a", to_joint="b", trigger="engine_instance_change",
                              detail="engine changes", strategy="arrow")
        out = render_visual(_assembly([j1, j2], [fg1, fg2], [mat], ["g1", "g2"]), 0, True)
        assert YELLOW in out


class TestVisualVerbosity:
    def test_verbosity1_shows_schema(self):
        j = _joint("j1", schema=Schema(columns=[Column(name="id", type="int64", nullable=False)]))
        out = render_visual(_assembly([j]), 1, False)
        assert "schema:" in out
        # Without schema_confidence set, schema displays as unverified
        assert "(unverified)" in out

    def test_verbosity1_shows_optimizations(self):
        j = _joint("j1", optimizations=[
            OptimizationResult(rule="pushdown", status="applied", detail="ok"),
        ])
        out = render_visual(_assembly([j]), 1, False)
        assert "pushdown" in out

    def test_verbosity2_shows_logical_plan(self):
        j = _joint("j1", logical_plan="Scan -> Filter -> Project")
        out = render_visual(_assembly([j]), 2, False)
        assert "logical plan" in out

    def test_verbosity2_shows_fused_sql(self):
        j1 = _joint("a", fused_group_id="g1")
        j2 = _joint("b", upstream=["a"], fused_group_id="g1")
        fg = FusedGroup(id="g1", joints=["a", "b"], engine="duckdb_1", engine_type="duckdb",
                        adapters={"a": None, "b": None}, fused_sql="WITH a AS (...) SELECT * FROM a")
        out = render_visual(_assembly([j1, j2], [fg], execution_order=["g1"]), 2, False)
        assert "Fused SQL" in out


class TestEnhancedDagRendering:
    """Task 5.3: Enhanced DAG rendering in AssemblyFormatter.render."""

    def test_joint_type_icons(self):
        """Req 6.1: Joint type icons on DAG nodes."""
        src = _joint("s1", "source")
        sql = _joint("q1", "sql", upstream=["s1"])
        py = _joint("p1", "python", upstream=["q1"])
        sink = _joint("k1", "sink", upstream=["p1"])
        out = render_visual(_assembly([src, sql, py, sink]), 0, False)
        assert "📥" in out
        assert "🔧" in out
        assert "🐍" in out
        assert "📤" in out

    def test_engine_label_on_joint_line_compact(self):
        """Req 6.1: Engine label on each joint line, even at compact verbosity."""
        j = _joint("j1", engine="duckdb_1")
        out = render_visual(_assembly([j]), 0, False)
        assert "[duckdb_1]" in out

    def test_engine_label_on_joint_line_normal(self):
        """Req 6.1: Engine label on each joint line at normal verbosity."""
        j = _joint("j1", engine="duckdb_1")
        out = render_visual(_assembly([j]), 1, False)
        assert "[duckdb_1]" in out

    def test_fused_group_box_drawing(self):
        """Req 6.2: Fused group boundaries with box drawing characters."""
        j1 = _joint("a", fused_group_id="g1")
        j2 = _joint("b", upstream=["a"], fused_group_id="g1")
        fg = FusedGroup(id="g1", joints=["a", "b"], engine="duckdb_1", engine_type="duckdb",
                        adapters={"a": None, "b": None}, fused_sql="SELECT 1")
        out = render_visual(_assembly([j1, j2], [fg], execution_order=["g1"]), 1, False)
        assert "╔" in out
        assert "║" in out
        assert "╚" in out
        assert "Fused Group: g1" in out

    def test_materialization_trigger_and_strategy(self):
        """Req 6.3: Materialization edges annotated with trigger + strategy."""
        j1 = _joint("a", fused_group_id="g1")
        j2 = _joint("b", upstream=["a"], fused_group_id="g2")
        fg1 = FusedGroup(id="g1", joints=["a"], engine="duckdb_1", engine_type="duckdb",
                         adapters={"a": None}, fused_sql=None)
        fg2 = FusedGroup(id="g2", joints=["b"], engine="duckdb_1", engine_type="duckdb",
                         adapters={"b": None}, fused_sql=None)
        mat = Materialization(from_joint="a", to_joint="b", trigger="eager",
                              detail="joint is eager", strategy="arrow")
        out = render_visual(_assembly([j1, j2], [fg1, fg2], [mat], ["g1", "g2"]), 1, False)
        assert "eager" in out
        assert "strategy: arrow" in out

    def test_schema_annotation_introspected(self):
        """Req 6.5: Schema annotations when confidence is introspected."""
        schema = Schema(columns=[Column(name="id", type="int64", nullable=False),
                                 Column(name="name", type="varchar", nullable=True)])
        j = _joint("j1", schema=schema)
        # Need to set schema_confidence via replace
        from dataclasses import replace
        j = replace(j, schema_confidence="introspected")
        out = render_visual(_assembly([j]), 1, False)
        assert "schema (introspected):" in out
        assert "2 columns" in out

    def test_schema_annotation_inferred(self):
        """Req 6.5: Schema annotations when confidence is inferred."""
        schema = Schema(columns=[Column(name="x", type="float", nullable=False)])
        j = _joint("j1", schema=schema)
        from dataclasses import replace
        j = replace(j, schema_confidence="inferred")
        out = render_visual(_assembly([j]), 1, False)
        assert "schema (inferred):" in out

    def test_schema_not_shown_when_confidence_none(self):
        """Req 6.5: No schema annotation when confidence is none."""
        schema = Schema(columns=[Column(name="id", type="int64", nullable=False)])
        j = _joint("j1", schema=schema)
        out = render_visual(_assembly([j]), 1, False)
        assert "schema (introspected)" not in out
        assert "schema (inferred)" not in out

    def test_engine_boundary_adapter_strategy(self):
        """Req 6.4: Cross-engine adapter strategy at engine boundaries."""
        eb = EngineBoundary(
            producer_group_id="g1", consumer_group_id="g2",
            producer_engine_type="duckdb", consumer_engine_type="spark",
            boundary_joints=["j1"],
            adapter_strategy="arrow_passthrough",
        )
        asm = CompiledAssembly(
            success=True, profile_name="default",
            catalogs=[], engines=[], adapters=[],
            joints=[], fused_groups=[], materializations=[],
            execution_order=[], errors=[], warnings=[],
            engine_boundaries=[eb],
        )
        out = render_visual(asm, 1, False)
        assert "Engine Boundaries" in out
        assert "arrow_passthrough" in out
        assert "duckdb" in out
        assert "spark" in out


class TestEngineBoundaryDisplay:
    """Task 12.1: Visual output shows engine boundaries with strategy info."""

    def _assembly_with_boundaries(self, boundaries: list[EngineBoundary]) -> CompiledAssembly:
        return CompiledAssembly(
            success=True, profile_name="default",
            catalogs=[], engines=[], adapters=[],
            joints=[], fused_groups=[], materializations=[],
            execution_order=[], errors=[], warnings=[],
            engine_boundaries=boundaries,
        )

    def test_no_boundaries_no_section(self):
        out = render_visual(self._assembly_with_boundaries([]), 1, False)
        assert "Engine Boundaries" not in out

    def test_boundary_shows_engine_types_and_joints(self):
        eb = EngineBoundary(
            producer_group_id="g1", consumer_group_id="g2",
            producer_engine_type="duckdb", consumer_engine_type="databricks",
            boundary_joints=["src_joint"],
            adapter_strategy="default: arrow_passthrough",
        )
        out = render_visual(self._assembly_with_boundaries([eb]), 1, False)
        assert "Engine Boundaries" in out
        assert "duckdb" in out
        assert "databricks" in out
        assert "src_joint" in out

    def test_boundary_shows_default_strategy_when_no_adapter(self):
        eb = EngineBoundary(
            producer_group_id="g1", consumer_group_id="g2",
            producer_engine_type="duckdb", consumer_engine_type="databricks",
            boundary_joints=["j1"],
            adapter_strategy="default: arrow_passthrough",
        )
        out = render_visual(self._assembly_with_boundaries([eb]), 1, False)
        assert "default: arrow_passthrough" in out

    def test_boundary_shows_adapter_strategy_when_registered(self):
        eb = EngineBoundary(
            producer_group_id="g1", consumer_group_id="g2",
            producer_engine_type="databricks", consumer_engine_type="databricks",
            boundary_joints=["j1"],
            adapter_strategy="DatabricksCrossJointAdapter",
        )
        out = render_visual(self._assembly_with_boundaries([eb]), 1, False)
        assert "DatabricksCrossJointAdapter" in out

    def test_multiple_boundaries_all_shown(self):
        ebs = [
            EngineBoundary(
                producer_group_id="g1", consumer_group_id="g2",
                producer_engine_type="duckdb", consumer_engine_type="databricks",
                boundary_joints=["j1"],
                adapter_strategy="default: arrow_passthrough",
            ),
            EngineBoundary(
                producer_group_id="g2", consumer_group_id="g3",
                producer_engine_type="databricks", consumer_engine_type="postgres",
                boundary_joints=["j2"],
                adapter_strategy="default: arrow_passthrough",
            ),
        ]
        out = render_visual(self._assembly_with_boundaries(ebs), 1, False)
        assert out.count("→") == 2

    def test_boundary_multiple_joints(self):
        eb = EngineBoundary(
            producer_group_id="g1", consumer_group_id="g2",
            producer_engine_type="duckdb", consumer_engine_type="databricks",
            boundary_joints=["j1", "j2"],
            adapter_strategy="default: arrow_passthrough",
        )
        out = render_visual(self._assembly_with_boundaries([eb]), 1, False)
        assert "j1, j2" in out

    def test_summary_includes_boundary_count(self):
        eb = EngineBoundary(
            producer_group_id="g1", consumer_group_id="g2",
            producer_engine_type="duckdb", consumer_engine_type="databricks",
            boundary_joints=["j1"],
        )
        out = render_visual(self._assembly_with_boundaries([eb]), 1, False)
        assert "Engine boundaries: 1" in out

    def test_summary_zero_boundaries(self):
        out = render_visual(self._assembly_with_boundaries([]), 1, False)
        assert "Engine boundaries: 0" in out
