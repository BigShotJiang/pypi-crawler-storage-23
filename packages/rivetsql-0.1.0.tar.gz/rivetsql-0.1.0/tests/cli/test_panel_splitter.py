"""Tests for panel splitter controls and visibility.

Validates Requirements 3.4 and 3.5:
  - Catalog panel: draggable splitter, default 20% width, min 15 chars, max 40%
  - Editor/Results split: draggable horizontal splitter, default 50/50,
    collapsible to full-editor or full-results
"""

from __future__ import annotations

from rivet_cli.repl.widgets.splitter import HorizontalSplitter, VerticalSplitter


class TestVerticalSplitterConstraints:
    """Requirement 3.4: catalog panel width constraints."""

    def test_min_width_constant(self):
        assert VerticalSplitter._CATALOG_MIN == 15

    def test_max_width_pct_constant(self):
        assert VerticalSplitter._CATALOG_MAX_PCT == 0.40

    def test_clamp_below_min(self):
        """Width below 15 chars is clamped to 15."""
        splitter = VerticalSplitter.__new__(VerticalSplitter)
        splitter._CATALOG_MIN = 15
        splitter._CATALOG_MAX_PCT = 0.40
        container_width = 100
        max_width = max(15, int(container_width * 0.40))
        result = max(15, min(max_width, 5))
        assert result == 15

    def test_clamp_above_max(self):
        """Width above 40% of container is clamped to 40%."""
        VerticalSplitter.__new__(VerticalSplitter)
        container_width = 200
        max_width = max(15, int(container_width * 0.40))  # 80
        result = max(15, min(max_width, 150))
        assert result == 80

    def test_within_bounds_unchanged(self):
        """Width within [15, 40%] is unchanged."""
        container_width = 200
        max_width = max(15, int(container_width * 0.40))  # 80
        result = max(15, min(max_width, 50))
        assert result == 50

    def test_default_css_has_width_1(self):
        assert "width: 1" in VerticalSplitter.DEFAULT_CSS

    def test_default_css_has_full_height(self):
        assert "height: 100%" in VerticalSplitter.DEFAULT_CSS

    def test_catalog_id_stored(self):
        splitter = VerticalSplitter.__new__(VerticalSplitter)
        splitter._catalog_id = "catalog-panel"
        assert splitter._catalog_id == "catalog-panel"

    def test_initial_not_dragging(self):
        splitter = VerticalSplitter.__new__(VerticalSplitter)
        splitter._dragging = False
        assert not splitter._dragging


class TestHorizontalSplitterConstraints:
    """Requirement 3.5: editor/results split constraints."""

    def test_default_css_has_height_1(self):
        assert "height: 1" in HorizontalSplitter.DEFAULT_CSS

    def test_default_css_has_full_width(self):
        assert "width: 100%" in HorizontalSplitter.DEFAULT_CSS

    def test_top_id_stored(self):
        splitter = HorizontalSplitter.__new__(HorizontalSplitter)
        splitter._top_id = "editor-panel"
        assert splitter._top_id == "editor-panel"

    def test_bottom_id_stored(self):
        splitter = HorizontalSplitter.__new__(HorizontalSplitter)
        splitter._bottom_id = "results-panel"
        assert splitter._bottom_id == "results-panel"

    def test_initial_not_dragging(self):
        splitter = HorizontalSplitter.__new__(HorizontalSplitter)
        splitter._dragging = False
        assert not splitter._dragging

    def test_collapse_to_zero_allowed(self):
        """Collapsing to 0 (full-screen other panel) is allowed."""
        total = 40
        new_top = max(0, min(total, 0))
        new_bottom = total - new_top
        assert new_top == 0
        assert new_bottom == 40

    def test_collapse_to_full_allowed(self):
        """Collapsing bottom to 0 (full-screen editor) is allowed."""
        total = 40
        new_top = max(0, min(total, 40))
        new_bottom = total - new_top
        assert new_top == 40
        assert new_bottom == 0

    def test_50_50_split(self):
        """Default 50/50 split is within valid range."""
        total = 40
        new_top = max(0, min(total, 20))
        new_bottom = total - new_top
        assert new_top == 20
        assert new_bottom == 20


class TestSplitterInAppCSS:
    """Verify app.py CSS includes splitter-compatible layout."""

    def test_app_imports_splitters(self):
        """app.py must import both splitter classes."""
        import importlib
        import importlib.util
        spec = importlib.util.find_spec("rivet_cli.repl.app")
        assert spec is not None
        # Read source to verify imports
        import pathlib
        src = pathlib.Path(spec.origin).read_text()
        assert "VerticalSplitter" in src
        assert "HorizontalSplitter" in src

    def test_app_composes_vertical_splitter(self):
        """app.py compose() must yield VerticalSplitter."""
        import importlib.util
        import pathlib
        spec = importlib.util.find_spec("rivet_cli.repl.app")
        src = pathlib.Path(spec.origin).read_text()
        assert "VerticalSplitter" in src
        assert "catalog-splitter" in src

    def test_app_composes_horizontal_splitter(self):
        """app.py compose() must yield HorizontalSplitter."""
        import importlib.util
        import pathlib
        spec = importlib.util.find_spec("rivet_cli.repl.app")
        src = pathlib.Path(spec.origin).read_text()
        assert "HorizontalSplitter" in src
        assert "editor-results-splitter" in src

    def test_catalog_panel_default_width_20pct(self):
        """Catalog panel CSS defaults to 20% width."""
        import importlib.util
        import pathlib
        spec = importlib.util.find_spec("rivet_cli.repl.app")
        src = pathlib.Path(spec.origin).read_text()
        assert "20%" in src

    def test_catalog_panel_min_width_15(self):
        """Catalog panel CSS has min-width: 15."""
        import importlib.util
        import pathlib
        spec = importlib.util.find_spec("rivet_cli.repl.app")
        src = pathlib.Path(spec.origin).read_text()
        assert "min-width: 15" in src

    def test_catalog_panel_max_width_40pct(self):
        """Catalog panel CSS has max-width: 40%."""
        import importlib.util
        import pathlib
        spec = importlib.util.find_spec("rivet_cli.repl.app")
        src = pathlib.Path(spec.origin).read_text()
        assert "40%" in src
