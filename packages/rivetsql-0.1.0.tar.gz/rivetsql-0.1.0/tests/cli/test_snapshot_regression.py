"""Snapshot regression tests for compile visual and mermaid output.

Captures output snapshots for each sample project and compares against
stored snapshots. Run with ``--update-snapshots`` to regenerate.

Requirements: 5.1, 7.1
"""

from __future__ import annotations

import re
from pathlib import Path
from unittest.mock import patch

import pytest
import yaml

from rivet_cli.app import GlobalOptions
from rivet_cli.commands.compile import run_compile
from rivet_cli.exit_codes import SUCCESS
from rivet_core import PluginRegistry

SNAPSHOTS_DIR = Path(__file__).parent / "snapshots"

# UUID pattern used in mermaid subgraph IDs
_UUID_RE = re.compile(r"[0-9a-f]{8}_[0-9a-f]{4}_[0-9a-f]{4}_[0-9a-f]{4}_[0-9a-f]{12}")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)


def _write_yaml(path: Path, data: object) -> None:
    _write(path, yaml.dump(data, default_flow_style=False))


def _globals(project_path: Path) -> GlobalOptions:
    return GlobalOptions(profile="default", project_path=project_path, verbosity=0, color=False)


def _registry_with_builtins() -> PluginRegistry:
    r = PluginRegistry()
    r.register_builtins()
    return r


def _normalize_mermaid(text: str) -> str:
    """Replace UUID-based subgraph IDs with a stable placeholder."""
    return _UUID_RE.sub("<UUID>", text)


_DURATION_RE = re.compile(r" in \d+ms")


def _normalize_visual(text: str) -> str:
    """Replace variable compilation duration with a stable placeholder."""
    return _DURATION_RE.sub(" in <T>ms", text)


def _assert_snapshot(
    actual: str,
    snapshot_path: Path,
    update: bool,
    normalize: bool = False,
    normalize_fn=None,
) -> None:
    """Compare *actual* against the snapshot file, or update it."""
    if normalize:
        actual = _normalize_mermaid(actual)
    if normalize_fn:
        actual = normalize_fn(actual)
    if update:
        snapshot_path.parent.mkdir(parents=True, exist_ok=True)
        snapshot_path.write_text(actual, encoding="utf-8")
        return
    assert snapshot_path.exists(), f"Snapshot not found: {snapshot_path}. Run with --update-snapshots."
    expected = snapshot_path.read_text(encoding="utf-8")
    assert actual == expected, (
        f"Snapshot mismatch for {snapshot_path.name}.\n"
        f"Run with --update-snapshots to regenerate.\n\n"
        f"--- expected ---\n{expected}\n--- actual ---\n{actual}"
    )


@pytest.fixture(autouse=True)
def _patch_registry():
    with patch(
        "rivet_cli.commands.compile.PluginRegistry",
        side_effect=lambda: _registry_with_builtins(),
    ):
        yield


# ---------------------------------------------------------------------------
# Sample project fixtures (reused from test_sample_integration.py)
# ---------------------------------------------------------------------------


@pytest.fixture()
def sample_01(tmp_path: Path) -> Path:
    root = tmp_path / "01-minimal"
    root.mkdir()
    _write_yaml(root / "rivet.yaml", {
        "profiles": "profiles.yaml", "sources": "sources",
        "joints": "joints", "sinks": "sinks",
    })
    _write_yaml(root / "profiles.yaml", {"default": {
        "default_engine": "eng1",
        "catalogs": {"main": {"type": "arrow"}},
        "engines": [{"name": "eng1", "type": "arrow", "catalogs": ["arrow"]}],
    }})
    (root / "sources").mkdir()
    _write_yaml(root / "sources" / "raw_orders.yaml", {
        "name": "raw_orders", "type": "source", "catalog": "main",
        "columns": ["id", "customer_id", "amount"],
    })
    (root / "joints").mkdir()
    _write(root / "joints" / "total_orders.sql", (
        "-- rivet:name: total_orders\n"
        "-- rivet:upstream: [raw_orders]\n"
        "SELECT customer_id, SUM(amount) AS total\nFROM raw_orders\n"
    ))
    (root / "sinks").mkdir()
    _write_yaml(root / "sinks" / "write_totals.yaml", {
        "name": "write_totals", "type": "sink", "catalog": "main",
        "table": "totals", "upstream": ["total_orders"],
    })
    return root


@pytest.fixture()
def sample_02(tmp_path: Path) -> Path:
    root = tmp_path / "02-multi-source-assertions"
    root.mkdir()
    _write_yaml(root / "rivet.yaml", {
        "profiles": "profiles.yaml", "sources": "sources",
        "joints": "joints", "sinks": "sinks", "quality": "quality",
    })
    _write_yaml(root / "profiles.yaml", {"default": {
        "default_engine": "eng1",
        "catalogs": {"warehouse": {"type": "arrow"}},
        "engines": [{"name": "eng1", "type": "arrow", "catalogs": ["arrow"]}],
    }})
    (root / "sources").mkdir()
    _write_yaml(root / "sources" / "raw_products.yaml", {
        "name": "raw_products", "type": "source", "catalog": "warehouse",
        "columns": ["id", "name", "price"],
    })
    _write_yaml(root / "sources" / "raw_categories.yaml", {
        "name": "raw_categories", "type": "source", "catalog": "warehouse",
    })
    (root / "joints").mkdir()
    _write(root / "joints" / "enriched_products.sql", (
        "-- rivet:name: enriched_products\n"
        "-- rivet:upstream: [raw_products, raw_categories]\n"
        "-- rivet:assert: not_null(id, name)\n"
        "-- rivet:assert: unique(id)\n"
        "SELECT p.*, c.name AS category\n"
        "FROM raw_products p\nJOIN raw_categories c ON p.category_id = c.id\n"
    ))
    (root / "sinks").mkdir()
    _write_yaml(root / "sinks" / "write_products.yaml", {
        "name": "write_products", "type": "sink", "catalog": "warehouse",
        "table": "products", "upstream": ["enriched_products"],
    })
    (root / "quality").mkdir()
    _write_yaml(root / "quality" / "raw_products.yaml", [
        {"type": "not_null", "columns": ["id", "name"]},
        {"type": "row_count", "min": 1},
    ])
    return root


@pytest.fixture()
def sample_03(tmp_path: Path) -> Path:
    root = tmp_path / "03-multi-engine"
    root.mkdir()
    _write_yaml(root / "rivet.yaml", {
        "profiles": "profiles.yaml", "sources": "sources",
        "joints": "joints", "sinks": "sinks",
    })
    _write_yaml(root / "profiles.yaml", {"default": {
        "default_engine": "eng1",
        "catalogs": {"lake": {"type": "arrow"}, "warehouse": {"type": "arrow"}},
        "engines": [
            {"name": "eng1", "type": "arrow", "catalogs": ["arrow"]},
            {"name": "eng2", "type": "arrow", "catalogs": ["arrow"]},
        ],
    }})
    (root / "sources").mkdir()
    _write_yaml(root / "sources" / "events.yaml", {
        "name": "events", "type": "source", "catalog": "lake",
    })
    (root / "joints").mkdir()
    _write(root / "joints" / "agg_events.sql", (
        "-- rivet:name: agg_events\n"
        "-- rivet:engine: eng2\n"
        "-- rivet:upstream: [events]\n"
        "SELECT event_type, COUNT(*) AS cnt FROM events GROUP BY event_type\n"
    ))
    (root / "sinks").mkdir()
    _write_yaml(root / "sinks" / "write_agg.yaml", {
        "name": "write_agg", "type": "sink", "catalog": "warehouse",
        "table": "agg_events", "upstream": ["agg_events"],
        "write_strategy": {"mode": "replace"},
    })
    return root


@pytest.fixture()
def sample_04(tmp_path: Path) -> Path:
    root = tmp_path / "04-full-featured"
    root.mkdir()
    _write_yaml(root / "rivet.yaml", {
        "profiles": "profiles.yaml", "sources": "sources",
        "joints": "joints", "sinks": "sinks", "quality": "quality",
    })
    _write_yaml(root / "profiles.yaml", {"default": {
        "default_engine": "eng1",
        "catalogs": {"main": {"type": "arrow"}, "pg": {"type": "arrow"}},
        "engines": [{"name": "eng1", "type": "arrow", "catalogs": ["arrow"]}],
    }})
    (root / "sources").mkdir()
    _write_yaml(root / "sources" / "raw_users.yaml", {
        "name": "raw_users", "type": "source", "catalog": "main",
        "columns": ["id", "email", "created_at"],
        "description": "Raw user data", "tags": ["pii", "raw"],
    })
    _write_yaml(root / "sources" / "raw_events.yaml", {
        "name": "raw_events", "type": "source", "catalog": "main",
    })
    (root / "joints").mkdir()
    _write(root / "joints" / "active_users.sql", (
        "-- rivet:name: active_users\n"
        "-- rivet:upstream: [raw_users, raw_events]\n"
        "-- rivet:tags: [analytics]\n"
        "-- rivet:description: Users with recent activity\n"
        "-- rivet:assert: not_null(id)\n"
        "SELECT u.id, u.email\nFROM raw_users u\n"
        "JOIN raw_events e ON u.id = e.user_id\n"
        "WHERE e.created_at > CURRENT_DATE - INTERVAL '30 days'\n"
    ))
    _write_yaml(root / "joints" / "user_summary.yaml", {
        "name": "user_summary", "type": "sql",
        "sql": "SELECT id, COUNT(*) AS event_count FROM raw_events GROUP BY id",
        "upstream": ["raw_events"],
    })
    (root / "sinks").mkdir()
    _write_yaml(root / "sinks" / "write_users.yaml", {
        "name": "write_users", "type": "sink", "catalog": "pg",
        "table": "dim_users", "upstream": ["active_users"],
        "write_strategy": {"mode": "merge", "key": "id"},
    })
    (root / "quality").mkdir()
    _write_yaml(root / "quality" / "raw_users.yaml", [
        {"type": "not_null", "columns": ["id", "email"]},
        {"type": "unique", "columns": ["id"]},
    ])
    return root


# ---------------------------------------------------------------------------
# Visual snapshot tests
# ---------------------------------------------------------------------------


class TestVisualSnapshots:
    def _compile_visual(self, project: Path, capsys) -> str:
        rc = run_compile(
            sink_name=None, tags=[], tag_all=False,
            format="visual", output=None, globals=_globals(project),
        )
        assert rc == SUCCESS
        return capsys.readouterr().out

    def test_01_minimal(self, sample_01, capsys, update_snapshots) -> None:
        out = self._compile_visual(sample_01, capsys)
        _assert_snapshot(out, SNAPSHOTS_DIR / "visual_01_minimal.txt", update_snapshots, normalize_fn=_normalize_visual)

    def test_02_multi_source_assertions(self, sample_02, capsys, update_snapshots) -> None:
        out = self._compile_visual(sample_02, capsys)
        _assert_snapshot(out, SNAPSHOTS_DIR / "visual_02_multi_source_assertions.txt", update_snapshots, normalize_fn=_normalize_visual)

    def test_03_multi_engine(self, sample_03, capsys, update_snapshots) -> None:
        out = self._compile_visual(sample_03, capsys)
        _assert_snapshot(out, SNAPSHOTS_DIR / "visual_03_multi_engine.txt", update_snapshots, normalize_fn=_normalize_visual)

    def test_04_full_featured(self, sample_04, capsys, update_snapshots) -> None:
        out = self._compile_visual(sample_04, capsys)
        _assert_snapshot(out, SNAPSHOTS_DIR / "visual_04_full_featured.txt", update_snapshots, normalize_fn=_normalize_visual)


# ---------------------------------------------------------------------------
# Mermaid snapshot tests
# ---------------------------------------------------------------------------


class TestMermaidSnapshots:
    def _compile_mermaid(self, project: Path, capsys) -> str:
        rc = run_compile(
            sink_name=None, tags=[], tag_all=False,
            format="mermaid", output=None, globals=_globals(project),
        )
        assert rc == SUCCESS
        return capsys.readouterr().out

    def test_01_minimal(self, sample_01, capsys, update_snapshots) -> None:
        out = self._compile_mermaid(sample_01, capsys)
        _assert_snapshot(out, SNAPSHOTS_DIR / "mermaid_01_minimal.txt", update_snapshots, normalize=True)

    def test_02_multi_source_assertions(self, sample_02, capsys, update_snapshots) -> None:
        out = self._compile_mermaid(sample_02, capsys)
        _assert_snapshot(out, SNAPSHOTS_DIR / "mermaid_02_multi_source_assertions.txt", update_snapshots, normalize=True)

    def test_03_multi_engine(self, sample_03, capsys, update_snapshots) -> None:
        out = self._compile_mermaid(sample_03, capsys)
        _assert_snapshot(out, SNAPSHOTS_DIR / "mermaid_03_multi_engine.txt", update_snapshots, normalize=True)

    def test_04_full_featured(self, sample_04, capsys, update_snapshots) -> None:
        out = self._compile_mermaid(sample_04, capsys)
        _assert_snapshot(out, SNAPSHOTS_DIR / "mermaid_04_full_featured.txt", update_snapshots, normalize=True)
