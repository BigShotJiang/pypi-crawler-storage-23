"""Tests for doctor text renderer (rendering/doctor_text.py)."""

from __future__ import annotations

import re

from rivet_cli.rendering.colors import GREEN, RED, YELLOW
from rivet_cli.rendering.doctor_text import DoctorCheckResult, render_doctor_text

ANSI_RE = re.compile(r"\033\[")


class TestRenderDoctorText:
    def test_pass_check(self):
        checks = [DoctorCheckResult(level=1, name="YAML syntax", status="pass",
                                    message="All files valid")]
        out = render_doctor_text(checks, False)
        assert "✓" in out
        assert "YAML syntax" in out

    def test_warning_check(self):
        checks = [DoctorCheckResult(level=5, name="Unused source", status="warning",
                                    message="source 'raw' not consumed")]
        out = render_doctor_text(checks, False)
        assert "⚠" in out
        assert "Unused source" in out

    def test_error_check(self):
        checks = [DoctorCheckResult(level=1, name="YAML syntax", status="error",
                                    message="Invalid YAML in joints/a.yaml")]
        out = render_doctor_text(checks, False)
        assert "✗" in out

    def test_details_displayed(self):
        checks = [DoctorCheckResult(level=4, name="DAG cycle", status="error",
                                    message="Cycle detected", details="a -> b -> a")]
        out = render_doctor_text(checks, False)
        assert "a -> b -> a" in out

    def test_summary_errors_and_warnings(self):
        checks = [
            DoctorCheckResult(level=1, name="c1", status="error", message="e"),
            DoctorCheckResult(level=1, name="c2", status="warning", message="w"),
            DoctorCheckResult(level=1, name="c3", status="pass", message="ok"),
        ]
        out = render_doctor_text(checks, False)
        assert "1 error(s)" in out
        assert "1 warning(s)" in out

    def test_summary_all_pass(self):
        checks = [DoctorCheckResult(level=1, name="c1", status="pass", message="ok")]
        out = render_doctor_text(checks, False)
        assert "All checks passed" in out


class TestProperty3DoctorText:
    def test_no_ansi_when_color_false(self):
        checks = [
            DoctorCheckResult(level=1, name="c1", status="pass", message="ok"),
            DoctorCheckResult(level=2, name="c2", status="warning", message="w"),
            DoctorCheckResult(level=3, name="c3", status="error", message="e"),
        ]
        out = render_doctor_text(checks, False)
        assert not ANSI_RE.search(out)


class TestProperty6DoctorText:
    def test_pass_green(self):
        checks = [DoctorCheckResult(level=1, name="c1", status="pass", message="ok")]
        out = render_doctor_text(checks, True)
        assert GREEN in out

    def test_warning_yellow(self):
        checks = [DoctorCheckResult(level=1, name="c1", status="warning", message="w")]
        out = render_doctor_text(checks, True)
        assert YELLOW in out

    def test_error_red(self):
        checks = [DoctorCheckResult(level=1, name="c1", status="error", message="e")]
        out = render_doctor_text(checks, True)
        assert RED in out
