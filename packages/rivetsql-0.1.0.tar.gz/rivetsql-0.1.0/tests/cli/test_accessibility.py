"""Tests for accessibility features — ARIA labels, tab order, keyboard navigation.

Requirements: 35.1, 35.2, 35.3, 35.4
"""

from __future__ import annotations

import pytest

from rivet_cli.repl.accessibility import (
    ARIA_AUTOCOMPLETE_LIST,
    ARIA_CATALOG_PANEL,
    ARIA_CATALOG_SEARCH,
    ARIA_CATALOG_TREE,
    ARIA_COMMAND_INPUT,
    ARIA_COMMAND_PALETTE,
    ARIA_EDITOR_AREA,
    ARIA_EDITOR_PANEL,
    ARIA_FIND_INPUT,
    ARIA_REPLACE_INPUT,
    ARIA_RESULTS_FOOTER,
    ARIA_RESULTS_PANEL,
    ARIA_RESULTS_TABLE,
    ARIA_RESULTS_TABS,
    ARIA_STATUS_BAR,
    ARIA_TAB_BAR,
    PANEL_TAB_ORDER,
)

# ---------------------------------------------------------------------------
# Requirement 35.1 — ARIA-style labels are non-empty strings
# ---------------------------------------------------------------------------


class TestAriaLabels:
    """All ARIA label constants must be non-empty descriptive strings."""

    @pytest.mark.parametrize(
        "label",
        [
            ARIA_CATALOG_PANEL,
            ARIA_CATALOG_TREE,
            ARIA_CATALOG_SEARCH,
            ARIA_EDITOR_PANEL,
            ARIA_EDITOR_AREA,
            ARIA_TAB_BAR,
            ARIA_FIND_INPUT,
            ARIA_REPLACE_INPUT,
            ARIA_AUTOCOMPLETE_LIST,
            ARIA_RESULTS_PANEL,
            ARIA_RESULTS_TABLE,
            ARIA_RESULTS_TABS,
            ARIA_RESULTS_FOOTER,
            ARIA_COMMAND_INPUT,
            ARIA_COMMAND_PALETTE,
            ARIA_STATUS_BAR,
        ],
    )
    def test_label_is_non_empty_string(self, label):
        assert isinstance(label, str)
        assert len(label) > 0

    def test_all_labels_are_unique(self):
        """Each interactive element has a distinct label."""
        labels = [
            ARIA_CATALOG_PANEL,
            ARIA_CATALOG_TREE,
            ARIA_CATALOG_SEARCH,
            ARIA_EDITOR_PANEL,
            ARIA_EDITOR_AREA,
            ARIA_TAB_BAR,
            ARIA_FIND_INPUT,
            ARIA_REPLACE_INPUT,
            ARIA_AUTOCOMPLETE_LIST,
            ARIA_RESULTS_PANEL,
            ARIA_RESULTS_TABLE,
            ARIA_RESULTS_TABS,
            ARIA_RESULTS_FOOTER,
            ARIA_COMMAND_INPUT,
            ARIA_COMMAND_PALETTE,
            ARIA_STATUS_BAR,
        ]
        assert len(labels) == len(set(labels)), "Duplicate ARIA labels found"


# ---------------------------------------------------------------------------
# Requirement 35.2 — Tab order: CatalogPanel → EditorPanel → ResultsPanel
# ---------------------------------------------------------------------------


class TestTabOrder:
    def test_panel_tab_order_has_three_entries(self):
        assert len(PANEL_TAB_ORDER) == 3

    def test_catalog_panel_is_first(self):
        assert PANEL_TAB_ORDER[0] == "#catalog-panel"

    def test_editor_panel_is_second(self):
        assert PANEL_TAB_ORDER[1] == "#editor-panel"

    def test_results_panel_is_third(self):
        assert PANEL_TAB_ORDER[2] == "#results-panel"

    def test_all_entries_are_css_id_selectors(self):
        for entry in PANEL_TAB_ORDER:
            assert entry.startswith("#"), f"{entry!r} is not a CSS ID selector"


# ---------------------------------------------------------------------------
# Requirement 35.3 — Panel focus cycling logic (pure, no Textual app needed)
# ---------------------------------------------------------------------------


class TestPanelFocusCycling:
    """Test the focus cycling logic used by action_focus_next_panel and
    action_focus_prev_panel without spinning up a full Textual app."""

    def _cycle_next(self, visible: list[str], current: str | None) -> str:
        """Replicate the logic from RivetRepl.action_focus_next_panel."""
        if not visible:
            return ""
        if current is None or current not in visible:
            return visible[0]
        idx = visible.index(current)
        return visible[(idx + 1) % len(visible)]

    def _cycle_prev(self, visible: list[str], current: str | None) -> str:
        """Replicate the logic from RivetRepl.action_focus_prev_panel."""
        if not visible:
            return ""
        if current is None or current not in visible:
            return visible[-1]
        idx = visible.index(current)
        return visible[(idx - 1) % len(visible)]

    def test_next_from_catalog_goes_to_editor(self):
        visible = ["catalog-panel", "editor-panel", "results-panel"]
        assert self._cycle_next(visible, "catalog-panel") == "editor-panel"

    def test_next_from_editor_goes_to_results(self):
        visible = ["catalog-panel", "editor-panel", "results-panel"]
        assert self._cycle_next(visible, "editor-panel") == "results-panel"

    def test_next_from_results_wraps_to_catalog(self):
        visible = ["catalog-panel", "editor-panel", "results-panel"]
        assert self._cycle_next(visible, "results-panel") == "catalog-panel"

    def test_prev_from_catalog_wraps_to_results(self):
        visible = ["catalog-panel", "editor-panel", "results-panel"]
        assert self._cycle_prev(visible, "catalog-panel") == "results-panel"

    def test_prev_from_results_goes_to_editor(self):
        visible = ["catalog-panel", "editor-panel", "results-panel"]
        assert self._cycle_prev(visible, "results-panel") == "editor-panel"

    def test_next_with_no_current_focus_starts_at_first(self):
        visible = ["catalog-panel", "editor-panel", "results-panel"]
        assert self._cycle_next(visible, None) == "catalog-panel"

    def test_prev_with_no_current_focus_starts_at_last(self):
        visible = ["catalog-panel", "editor-panel", "results-panel"]
        assert self._cycle_prev(visible, None) == "results-panel"

    def test_next_skips_hidden_panels(self):
        """When catalog is hidden, Tab goes editor → results → editor."""
        visible = ["editor-panel", "results-panel"]
        assert self._cycle_next(visible, "editor-panel") == "results-panel"
        assert self._cycle_next(visible, "results-panel") == "editor-panel"

    def test_single_visible_panel_cycles_to_itself(self):
        visible = ["editor-panel"]
        assert self._cycle_next(visible, "editor-panel") == "editor-panel"
        assert self._cycle_prev(visible, "editor-panel") == "editor-panel"


# ---------------------------------------------------------------------------
# Requirement 35.4 — High-contrast theme file exists and uses icon+color
# ---------------------------------------------------------------------------


class TestHighContrastTheme:
    def _theme_content(self) -> str:
        from pathlib import Path

        theme_path = (
            Path(__file__).parent.parent.parent
            / "src"
            / "rivet_cli"
            / "repl"
            / "themes"
            / "high_contrast.tcss"
        )
        return theme_path.read_text()

    def test_theme_file_exists(self):
        from pathlib import Path

        theme_path = (
            Path(__file__).parent.parent.parent
            / "src"
            / "rivet_cli"
            / "repl"
            / "themes"
            / "high_contrast.tcss"
        )
        assert theme_path.exists(), "high_contrast.tcss theme file not found"

    def test_theme_has_bold_borders(self):
        content = self._theme_content()
        assert "heavy" in content, "High-contrast theme must use bold (heavy) borders"

    def test_theme_has_error_status(self):
        """Error status uses both color AND a comment indicating icon usage."""
        content = self._theme_content()
        assert "status-error" in content

    def test_theme_has_success_status(self):
        content = self._theme_content()
        assert "status-success" in content

    def test_theme_has_warning_status(self):
        content = self._theme_content()
        assert "status-warning" in content

    def test_theme_diff_uses_icon_comments(self):
        """Diff indicators reference icons in comments (no color-only)."""
        content = self._theme_content()
        assert "diff-added" in content
        assert "diff-removed" in content
        assert "diff-changed" in content

    def test_theme_focus_indicator_is_high_visibility(self):
        """Focus indicator must be clearly visible (not just a subtle change)."""
        content = self._theme_content()
        assert ":focus" in content
