"""Tests for the StatusBar widget.

Validates: Requirements 3.2, 10.3, 18.3, 19.2, 23.4

Tests cover:
- Initial state display (profile, engine, compile status, connection, watch)
- ProjectCompiled message handling (success and failure)
- ExecutionStarted message handling
- ExecutionProgress message handling (with and without row count)
- ExecutionComplete message handling (success, failure, cancellation)
- ProfileChanged message handling
- set_watching() and set_recompiling() public API
"""

from __future__ import annotations

from rivet_cli.repl.widgets.status_bar import (
    ExecutionComplete,
    ExecutionProgress,
    ExecutionStarted,
    ProfileChanged,
    ProjectCompiled,
    StatusBar,
)


class TestStatusBarInitialState:
    def test_default_profile(self) -> None:
        sb = StatusBar()
        assert sb._profile == "default"

    def test_custom_profile(self) -> None:
        sb = StatusBar(profile="production")
        assert sb._profile == "production"

    def test_default_engine_empty(self) -> None:
        sb = StatusBar()
        assert sb._adhoc_engine is None
        assert sb._engine_names == ()

    def test_custom_engine(self) -> None:
        sb = StatusBar(engine="duckdb")
        assert sb._adhoc_engine == "duckdb"

    def test_watching_default_true(self) -> None:
        sb = StatusBar()
        assert sb._watching is True

    def test_watching_false(self) -> None:
        sb = StatusBar(watching=False)
        assert sb._watching is False

    def test_initial_compile_label(self) -> None:
        sb = StatusBar()
        assert "compiled" in sb._compile_label

    def test_initial_connected_true(self) -> None:
        sb = StatusBar()
        assert sb._connected is True

    def test_initial_exec_label_empty(self) -> None:
        sb = StatusBar()
        assert sb._exec_label == ""


class TestProjectCompiled:
    def test_success_updates_compile_label(self) -> None:
        sb = StatusBar()
        sb.on_project_compiled(ProjectCompiled(success=True, elapsed_ms=1234.0))
        assert "compiled" in sb._compile_label
        assert "1.2s" in sb._compile_label

    def test_success_sets_ok_class(self) -> None:
        sb = StatusBar()
        sb.on_project_compiled(ProjectCompiled(success=True, elapsed_ms=500.0))
        assert sb._compile_class == "status-compile-ok"

    def test_failure_updates_compile_label(self) -> None:
        sb = StatusBar()
        sb.on_project_compiled(ProjectCompiled(success=False, error="syntax error"))
        assert "error" in sb._compile_label.lower()

    def test_failure_sets_error_class(self) -> None:
        sb = StatusBar()
        sb.on_project_compiled(ProjectCompiled(success=False))
        assert sb._compile_class == "status-compile-error"

    def test_clears_exec_label_on_compile(self) -> None:
        sb = StatusBar()
        sb._exec_label = "⏳ executing something"
        sb.on_project_compiled(ProjectCompiled(success=True, elapsed_ms=100.0))
        assert sb._exec_label == ""

    def test_zero_elapsed(self) -> None:
        sb = StatusBar()
        sb.on_project_compiled(ProjectCompiled(success=True, elapsed_ms=0.0))
        assert "0.0s" in sb._compile_label


class TestExecutionStarted:
    def test_sets_exec_label(self) -> None:
        sb = StatusBar()
        sb.on_execution_started(ExecutionStarted(joint_name="transform_orders", total=5))
        assert "transform_orders" in sb._exec_label
        assert "1/5" in sb._exec_label

    def test_exec_label_contains_executing_indicator(self) -> None:
        sb = StatusBar()
        sb.on_execution_started(ExecutionStarted(joint_name="my_joint", total=3))
        assert "⏳" in sb._exec_label or "executing" in sb._exec_label.lower()

    def test_single_joint(self) -> None:
        sb = StatusBar()
        sb.on_execution_started(ExecutionStarted(joint_name="sink", total=1))
        assert "1/1" in sb._exec_label


class TestExecutionProgress:
    def test_updates_joint_name(self) -> None:
        sb = StatusBar()
        sb.on_execution_progress(
            ExecutionProgress(joint_name="step2", current=2, total=4, rows=None, elapsed_ms=200.0)
        )
        assert "step2" in sb._exec_label

    def test_updates_progress_counter(self) -> None:
        sb = StatusBar()
        sb.on_execution_progress(
            ExecutionProgress(joint_name="j", current=3, total=7, rows=None, elapsed_ms=100.0)
        )
        assert "3/7" in sb._exec_label

    def test_includes_row_count_when_provided(self) -> None:
        sb = StatusBar()
        sb.on_execution_progress(
            ExecutionProgress(joint_name="j", current=1, total=2, rows=42_000, elapsed_ms=500.0)
        )
        assert "42,000" in sb._exec_label or "42000" in sb._exec_label

    def test_no_row_count_when_none(self) -> None:
        sb = StatusBar()
        sb.on_execution_progress(
            ExecutionProgress(joint_name="j", current=1, total=2, rows=None, elapsed_ms=100.0)
        )
        # Should not crash and should not show a row count
        assert "rows" not in sb._exec_label

    def test_includes_elapsed_time(self) -> None:
        sb = StatusBar()
        sb.on_execution_progress(
            ExecutionProgress(joint_name="j", current=1, total=2, rows=None, elapsed_ms=2500.0)
        )
        assert "2.5s" in sb._exec_label


class TestExecutionComplete:
    def test_success_clears_exec_label(self) -> None:
        sb = StatusBar()
        sb._exec_label = "⏳ executing something"
        sb.on_execution_complete(ExecutionComplete(success=True, elapsed_ms=1000.0))
        assert sb._exec_label == ""

    def test_failure_clears_exec_label(self) -> None:
        sb = StatusBar()
        sb._exec_label = "⏳ executing something"
        sb.on_execution_complete(ExecutionComplete(success=False, error="engine error"))
        assert sb._exec_label == ""

    def test_canceled_shows_canceled_message(self) -> None:
        sb = StatusBar()
        sb.on_execution_complete(ExecutionComplete(success=False, canceled=True))
        assert "cancel" in sb._exec_label.lower()

    def test_canceled_label_contains_warning(self) -> None:
        sb = StatusBar()
        sb.on_execution_complete(ExecutionComplete(success=False, canceled=True))
        assert sb._exec_label != ""

    def test_flash_shows_row_count_and_elapsed(self) -> None:
        sb = StatusBar()
        sb.on_execution_complete(ExecutionComplete(success=True, elapsed_ms=1234.0, rows=42))
        assert "✓" in sb._exec_label
        assert "42" in sb._exec_label
        assert "1234ms" in sb._exec_label

    def test_flash_formats_large_row_count(self) -> None:
        sb = StatusBar()
        sb.on_execution_complete(ExecutionComplete(success=True, elapsed_ms=500.0, rows=1_000_000))
        assert "1,000,000" in sb._exec_label

    def test_flash_zero_rows(self) -> None:
        sb = StatusBar()
        sb.on_execution_complete(ExecutionComplete(success=True, elapsed_ms=100.0, rows=0))
        assert "✓" in sb._exec_label
        assert "0" in sb._exec_label

    def test_no_flash_when_rows_none(self) -> None:
        sb = StatusBar()
        sb.on_execution_complete(ExecutionComplete(success=True, elapsed_ms=1000.0, rows=None))
        assert sb._exec_label == ""

    def test_no_flash_on_failure_with_rows(self) -> None:
        sb = StatusBar()
        sb.on_execution_complete(ExecutionComplete(success=False, elapsed_ms=500.0, rows=10))
        assert sb._exec_label == ""

    def test_execution_complete_rows_field(self) -> None:
        m = ExecutionComplete(success=True, elapsed_ms=100.0, rows=55)
        assert m.rows == 55

    def test_execution_complete_rows_default_none(self) -> None:
        m = ExecutionComplete(success=True)
        assert m.rows is None

    def test_clear_flash_restores_steady_state(self) -> None:
        sb = StatusBar()
        sb._exec_label = "✓ 42 rows · 100ms"
        sb._clear_flash()
        assert sb._exec_label == ""


class TestProfileChanged:
    def test_updates_profile_name(self) -> None:
        sb = StatusBar(profile="default")
        sb.on_profile_changed(ProfileChanged(profile_name="staging", engine_name="duckdb"))
        assert sb._profile == "staging"

    def test_updates_engine_name(self) -> None:
        sb = StatusBar(engine="polars")
        sb.on_profile_changed(ProfileChanged(profile_name="prod", engine_name="spark"))
        assert sb._adhoc_engine == "spark"

    def test_updates_connected_true(self) -> None:
        sb = StatusBar()
        sb._connected = False
        sb.on_profile_changed(ProfileChanged(profile_name="p", connected=True))
        assert sb._connected is True

    def test_updates_connected_false(self) -> None:
        sb = StatusBar()
        sb.on_profile_changed(ProfileChanged(profile_name="p", connected=False))
        assert sb._connected is False

    def test_empty_engine_name(self) -> None:
        sb = StatusBar(engine="duckdb")
        sb.on_profile_changed(ProfileChanged(profile_name="p", engine_name=""))
        assert sb._adhoc_engine == "duckdb"  # empty string does not clear adhoc


class TestPublicAPI:
    def test_set_watching_false(self) -> None:
        sb = StatusBar(watching=True)
        sb.set_watching(False)
        assert sb._watching is False

    def test_set_watching_true(self) -> None:
        sb = StatusBar(watching=False)
        sb.set_watching(True)
        assert sb._watching is True

    def test_set_recompiling(self) -> None:
        sb = StatusBar()
        sb.set_recompiling()
        assert "recompil" in sb._compile_label.lower()
        assert sb._compile_class == "status-compiling"


class TestMessageDataclasses:
    """Verify message dataclasses carry the right fields."""

    def test_project_compiled_success(self) -> None:
        m = ProjectCompiled(success=True, elapsed_ms=500.0)
        assert m.success is True
        assert m.elapsed_ms == 500.0
        assert m.error is None

    def test_project_compiled_failure(self) -> None:
        m = ProjectCompiled(success=False, error="oops")
        assert m.success is False
        assert m.error == "oops"

    def test_execution_started(self) -> None:
        m = ExecutionStarted(joint_name="j", total=3)
        assert m.joint_name == "j"
        assert m.total == 3

    def test_execution_progress(self) -> None:
        m = ExecutionProgress(joint_name="j", current=2, total=5, rows=100, elapsed_ms=300.0)
        assert m.current == 2
        assert m.rows == 100

    def test_execution_complete_defaults(self) -> None:
        m = ExecutionComplete(success=True)
        assert m.canceled is False
        assert m.error is None

    def test_profile_changed_defaults(self) -> None:
        m = ProfileChanged(profile_name="dev")
        assert m.engine_name == ""
        assert m.connected is True


from rivet_cli.repl.widgets.status_bar import ActivityChanged
from rivet_core.interactive.types import Activity_State


class TestActivityChanged:
    """Validate ActivityChanged message and StatusBar handler.

    Requirements: 9a.5, 9b.4
    """

    def test_activity_changed_compiling(self) -> None:
        sb = StatusBar()
        sb.on_activity_changed(ActivityChanged(state=Activity_State.COMPILING))
        assert sb._activity_label == "⟳ Compiling…"

    def test_activity_changed_executing(self) -> None:
        sb = StatusBar()
        sb.on_activity_changed(ActivityChanged(state=Activity_State.EXECUTING))
        assert sb._activity_label == "⟳ Executing…"

    def test_activity_changed_idle(self) -> None:
        sb = StatusBar()
        sb._activity_label = "⟳ Compiling…"
        sb.on_activity_changed(ActivityChanged(state=Activity_State.IDLE))
        assert sb._activity_label == ""

    def test_activity_changed_message_carries_state(self) -> None:
        m = ActivityChanged(state=Activity_State.COMPILING)
        assert m.state == Activity_State.COMPILING

    def test_activity_label_initially_empty(self) -> None:
        sb = StatusBar()
        assert sb._activity_label == ""

    def test_activity_transitions_compiling_to_idle(self) -> None:
        sb = StatusBar()
        sb.on_activity_changed(ActivityChanged(state=Activity_State.COMPILING))
        assert sb._activity_label == "⟳ Compiling…"
        sb.on_activity_changed(ActivityChanged(state=Activity_State.IDLE))
        assert sb._activity_label == ""

    def test_activity_transitions_executing_to_idle(self) -> None:
        sb = StatusBar()
        sb.on_activity_changed(ActivityChanged(state=Activity_State.EXECUTING))
        assert sb._activity_label == "⟳ Executing…"
        sb.on_activity_changed(ActivityChanged(state=Activity_State.IDLE))
        assert sb._activity_label == ""


from rivet_cli.repl.widgets.status_bar import ExecutionRejected


class TestExecutionRejected:
    """Validate ExecutionRejected message and StatusBar handler.

    Requirements: 1.4
    """

    def test_execution_rejected_message_carries_reason(self) -> None:
        m = ExecutionRejected(reason="Execution in progress — cancel first (Ctrl+C)")
        assert m.reason == "Execution in progress — cancel first (Ctrl+C)"

    def test_execution_rejected_handler_calls_notify(self) -> None:
        sb = StatusBar()
        notifications: list[tuple[str, str]] = []
        sb.notify = lambda msg, severity="information": notifications.append((msg, severity))
        sb.on_execution_rejected(ExecutionRejected(reason="busy"))
        assert len(notifications) == 1
        assert "Execution in progress" in notifications[0][0]
        assert "cancel first" in notifications[0][0]
        assert "Ctrl+C" in notifications[0][0]
        assert notifications[0][1] == "warning"

    def test_execution_rejected_notification_contains_warning_icon(self) -> None:
        sb = StatusBar()
        notifications: list[str] = []
        sb.notify = lambda msg, severity="information": notifications.append(msg)
        sb.on_execution_rejected(ExecutionRejected(reason="busy"))
        assert "⚠" in notifications[0]


from rivet_cli.repl.widgets.status_bar import OpenDialectSelector


class TestDialectDisplay:
    """Validate dialect display segment in StatusBar.

    Requirements: 3.4, 7.1, 7.2
    """

    def test_no_dialect_no_inferred_returns_empty(self) -> None:
        sb = StatusBar()
        assert sb._dialect_text() == ""

    def test_explicit_dialect_shown_without_suffix(self) -> None:
        sb = StatusBar(dialect="spark")
        assert sb._dialect_text() == "📝 spark"
        assert "(auto)" not in sb._dialect_text()

    def test_inferred_dialect_shown_with_auto_suffix(self) -> None:
        sb = StatusBar(inferred_dialect="duckdb")
        assert sb._dialect_text() == "📝 duckdb (auto)"

    def test_explicit_dialect_overrides_inferred(self) -> None:
        sb = StatusBar(dialect="trino", inferred_dialect="duckdb")
        assert sb._dialect_text() == "📝 trino"

    def test_set_dialect_explicit(self) -> None:
        sb = StatusBar()
        sb.set_dialect(dialect="bigquery")
        assert sb._dialect == "bigquery"
        assert sb._dialect_text() == "📝 bigquery"

    def test_set_dialect_inferred(self) -> None:
        sb = StatusBar()
        sb.set_dialect(inferred_dialect="postgres")
        assert sb._inferred_dialect == "postgres"
        assert sb._dialect_text() == "📝 postgres (auto)"

    def test_set_dialect_clears_explicit(self) -> None:
        sb = StatusBar(dialect="spark")
        sb.set_dialect(dialect=None)
        assert sb._dialect is None

    def test_engine_default_suffix_when_no_override(self) -> None:
        sb = StatusBar(engine_names=["duckdb"])
        assert "(default)" in sb._engine_text()

    def test_engine_no_default_suffix_when_override_set(self) -> None:
        sb = StatusBar(adhoc_engine="spark")
        assert "(default)" not in sb._engine_text()

    def test_open_dialect_selector_message_exists(self) -> None:
        # Verify the message class is importable and instantiable
        msg = OpenDialectSelector()
        assert msg is not None


from rivet_cli.repl.widgets.status_bar import OpenEngineSelector


class TestClickableLabels:
    """Validate engine and dialect labels are clickable (Requirement 7.4)."""

    def test_app_has_on_open_engine_selector_handler(self) -> None:
        from rivet_cli.repl.app import RivetRepl
        assert hasattr(RivetRepl, "on_open_engine_selector")

    def test_app_has_on_open_dialect_selector_handler(self) -> None:
        from rivet_cli.repl.app import RivetRepl
        assert hasattr(RivetRepl, "on_open_dialect_selector")

    def test_open_engine_selector_message_exists(self) -> None:
        msg = OpenEngineSelector()
        assert msg is not None

    def test_open_dialect_selector_message_exists(self) -> None:
        msg = OpenDialectSelector()
        assert msg is not None

    def test_status_bar_has_on_click_handler(self) -> None:
        assert hasattr(StatusBar, "on_click")


from rivet_core.compiler import CompilationStats


class TestCompilationSummaryLine:
    """Validate compilation summary line in status bar using CompilationStats.

    Requirements: 7.3, 8.2
    """

    def _make_stats(self, **overrides):
        defaults = dict(
            compile_duration_ms=340,
            joints_with_schema=8,
            joints_total=12,
            introspection_attempted=10,
            introspection_succeeded=6,
            introspection_failed=2,
            introspection_skipped=2,
        )
        defaults.update(overrides)
        return CompilationStats(**defaults)

    def test_compile_label_shows_schema_coverage(self) -> None:
        sb = StatusBar()
        cs = self._make_stats()
        sb.on_project_compiled(ProjectCompiled(success=True, elapsed_ms=340.0, compilation_stats=cs))
        assert "8/12 schemas" in sb._compile_label

    def test_compile_label_shows_duration_ms(self) -> None:
        sb = StatusBar()
        cs = self._make_stats(compile_duration_ms=500)
        sb.on_project_compiled(ProjectCompiled(success=True, elapsed_ms=500.0, compilation_stats=cs))
        assert "500ms" in sb._compile_label

    def test_compile_label_shows_introspection_status(self) -> None:
        sb = StatusBar()
        cs = self._make_stats()
        sb.on_project_compiled(ProjectCompiled(success=True, elapsed_ms=340.0, compilation_stats=cs))
        assert "6 ok" in sb._compile_label
        assert "2 failed" in sb._compile_label
        assert "2 skipped" in sb._compile_label

    def test_compile_label_contains_compiled_indicator(self) -> None:
        sb = StatusBar()
        cs = self._make_stats()
        sb.on_project_compiled(ProjectCompiled(success=True, elapsed_ms=340.0, compilation_stats=cs))
        assert "compiled" in sb._compile_label

    def test_fallback_without_compilation_stats(self) -> None:
        sb = StatusBar()
        sb.on_project_compiled(ProjectCompiled(success=True, elapsed_ms=1234.0))
        assert "1.2s" in sb._compile_label
        assert "schemas" not in sb._compile_label

    def test_failure_ignores_compilation_stats(self) -> None:
        sb = StatusBar()
        cs = self._make_stats()
        sb.on_project_compiled(ProjectCompiled(success=False, error="bad", compilation_stats=cs))
        assert "error" in sb._compile_label.lower()
        assert sb._compile_class == "status-compile-error"

    def test_compile_class_ok_with_stats(self) -> None:
        sb = StatusBar()
        cs = self._make_stats()
        sb.on_project_compiled(ProjectCompiled(success=True, elapsed_ms=100.0, compilation_stats=cs))
        assert sb._compile_class == "status-compile-ok"

    def test_project_compiled_message_carries_stats(self) -> None:
        cs = self._make_stats()
        m = ProjectCompiled(success=True, elapsed_ms=100.0, compilation_stats=cs)
        assert m.compilation_stats is cs

    def test_project_compiled_message_stats_default_none(self) -> None:
        m = ProjectCompiled(success=True, elapsed_ms=100.0)
        assert m.compilation_stats is None

    def test_zero_introspection(self) -> None:
        sb = StatusBar()
        cs = self._make_stats(
            introspection_attempted=0,
            introspection_succeeded=0,
            introspection_failed=0,
            introspection_skipped=5,
        )
        sb.on_project_compiled(ProjectCompiled(success=True, elapsed_ms=100.0, compilation_stats=cs))
        assert "0 ok" in sb._compile_label
        assert "5 skipped" in sb._compile_label
