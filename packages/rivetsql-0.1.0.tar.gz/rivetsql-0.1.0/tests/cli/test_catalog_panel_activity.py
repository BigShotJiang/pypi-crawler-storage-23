# Feature: repl-query-guard, Task 6.2: CatalogPanel ActivityChanged handling
"""Tests for CatalogPanel ActivityChanged message handling.

Validates: Requirements 4.2, 4.3
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from rivet_cli.repl.widgets.catalog import CatalogPanel
from rivet_cli.repl.widgets.status_bar import ActivityChanged
from rivet_core.interactive.types import Activity_State


def _make_panel() -> CatalogPanel:
    session = MagicMock()
    session.get_catalogs.return_value = []
    session.get_joints.return_value = []
    return CatalogPanel(session=session)


class TestCatalogPanelActivityChanged:
    """Validate CatalogPanel disables execute on EXECUTING and re-enables on IDLE."""

    def test_initially_not_executing(self) -> None:
        panel = _make_panel()
        assert panel._executing is False

    def test_executing_sets_flag(self) -> None:
        panel = _make_panel()
        panel.on_activity_changed(ActivityChanged(state=Activity_State.EXECUTING))
        assert panel._executing is True

    def test_idle_clears_flag(self) -> None:
        panel = _make_panel()
        panel.on_activity_changed(ActivityChanged(state=Activity_State.EXECUTING))
        with patch.object(panel, "_rebuild_joints_section"):
            panel.on_activity_changed(ActivityChanged(state=Activity_State.IDLE))
        assert panel._executing is False

    def test_compiling_does_not_block(self) -> None:
        panel = _make_panel()
        with patch.object(panel, "_rebuild_joints_section"):
            panel.on_activity_changed(ActivityChanged(state=Activity_State.COMPILING))
        assert panel._executing is False

    def test_execute_action_blocked_when_executing(self) -> None:
        """action_execute_node should not post ExecuteJointRequested when executing."""
        panel = _make_panel()
        panel._executing = True

        messages: list = []
        panel.post_message = lambda msg: messages.append(msg)  # type: ignore[assignment]

        panel.action_execute_node()
        assert len(messages) == 0

    def test_idle_clears_executing_joint_statuses(self) -> None:
        """Transitioning to IDLE should clear 'executing' statuses."""
        panel = _make_panel()
        panel._joint_statuses = {"joint_a": "executing", "joint_b": "success"}
        with patch.object(panel, "_rebuild_joints_section"):
            panel.on_activity_changed(ActivityChanged(state=Activity_State.IDLE))
        assert "joint_a" not in panel._joint_statuses
        assert panel._joint_statuses["joint_b"] == "success"

    def test_executing_preserves_existing_statuses(self) -> None:
        """Transitioning to EXECUTING should not clear existing statuses."""
        panel = _make_panel()
        panel._joint_statuses = {"joint_a": "success"}
        panel.on_activity_changed(ActivityChanged(state=Activity_State.EXECUTING))
        assert panel._joint_statuses["joint_a"] == "success"

    def test_transition_executing_to_idle_allows_execute(self) -> None:
        """After EXECUTING → IDLE, action_execute_node should be unblocked."""
        panel = _make_panel()
        panel.on_activity_changed(ActivityChanged(state=Activity_State.EXECUTING))
        assert panel._executing is True
        with patch.object(panel, "_rebuild_joints_section"):
            panel.on_activity_changed(ActivityChanged(state=Activity_State.IDLE))
        assert panel._executing is False
