"""Tests for CLI metrics collection and module boundary enforcement."""

from __future__ import annotations

import ast
import logging
from pathlib import Path

import pytest

from rivet_cli.metrics import CLIMetrics, record_metrics

# ---------------------------------------------------------------------------
# CLIMetrics dataclass
# ---------------------------------------------------------------------------


class TestCLIMetrics:
    def test_command_and_exit_code(self):
        m = CLIMetrics(command="compile", command_duration_ms=100.0, exit_code=0)
        assert m.command == "compile"
        assert m.exit_code == 0

    def test_optional_durations_default_none(self):
        m = CLIMetrics(command="init", command_duration_ms=50.0, exit_code=0)
        assert m.compile_duration_ms is None
        assert m.execution_duration_ms is None
        assert m.test_duration_ms is None

    def test_compile_duration_recorded(self):
        m = CLIMetrics(
            command="compile",
            command_duration_ms=200.0,
            compile_duration_ms=150.0,
            exit_code=0,
        )
        assert m.compile_duration_ms == 150.0

    def test_execution_duration_recorded_for_run(self):
        m = CLIMetrics(
            command="run",
            command_duration_ms=500.0,
            compile_duration_ms=100.0,
            execution_duration_ms=350.0,
            exit_code=0,
        )
        assert m.execution_duration_ms == 350.0

    def test_test_duration_recorded(self):
        m = CLIMetrics(
            command="test",
            command_duration_ms=300.0,
            compile_duration_ms=80.0,
            test_duration_ms=200.0,
            exit_code=3,
        )
        assert m.test_duration_ms == 200.0
        assert m.exit_code == 3


# ---------------------------------------------------------------------------
# record_metrics — logging output
# ---------------------------------------------------------------------------


class TestRecordMetrics:
    def test_logs_command_and_exit_code(self, caplog):
        m = CLIMetrics(command="compile", command_duration_ms=123.4, exit_code=0)
        with caplog.at_level(logging.INFO, logger="rivet.cli.metrics"):
            record_metrics(m)
        assert "command=compile" in caplog.text
        assert "exit_code=0" in caplog.text

    def test_logs_compile_duration(self, caplog):
        m = CLIMetrics(
            command="run",
            command_duration_ms=500.0,
            compile_duration_ms=200.0,
            execution_duration_ms=250.0,
            exit_code=0,
        )
        with caplog.at_level(logging.INFO, logger="rivet.cli.metrics"):
            record_metrics(m)
        assert "compile_ms=200.0" in caplog.text
        assert "execution_ms=250.0" in caplog.text

    def test_logs_na_for_missing_durations(self, caplog):
        m = CLIMetrics(command="init", command_duration_ms=10.0, exit_code=0)
        with caplog.at_level(logging.INFO, logger="rivet.cli.metrics"):
            record_metrics(m)
        assert "compile_ms=n/a" in caplog.text
        assert "execution_ms=n/a" in caplog.text
        assert "test_ms=n/a" in caplog.text

    def test_logs_nonzero_exit_code(self, caplog):
        m = CLIMetrics(command="run", command_duration_ms=100.0, exit_code=4)
        with caplog.at_level(logging.INFO, logger="rivet.cli.metrics"):
            record_metrics(m)
        assert "exit_code=4" in caplog.text


# ---------------------------------------------------------------------------
# Module boundary enforcement (Property 10)
# ---------------------------------------------------------------------------

# Allowed top-level imports for rivet_cli source files.
# Includes declared project dependencies from pyproject.toml that are used
# across the codebase (yaml for config parsing, sqlglot for SQL checking).
_ALLOWED_PACKAGES = frozenset({
    "rivet_cli",
    "rivet_core",
    "rivet_config",
    "rivet_bridge",
    "yaml",
    "sqlglot",
    "textual",
    "pyarrow",
})

# Python stdlib top-level module names used in the codebase (non-exhaustive
# but covers everything the CLI actually imports).  We use sys.stdlib_module_names
# at runtime for a complete check.
_STDLIB_MODULES: frozenset[str] = frozenset()


def _get_stdlib_modules() -> frozenset[str]:
    import sys
    return frozenset(sys.stdlib_module_names)


def _top_level_name(module_name: str) -> str:
    """Return the top-level package from a dotted module name."""
    return module_name.split(".")[0]


def _collect_imports(source: str) -> list[str]:
    """Parse Python source and return all imported top-level module names."""
    tree = ast.parse(source)
    names: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                names.append(_top_level_name(alias.name))
        elif isinstance(node, ast.ImportFrom):
            if node.module and node.level == 0:  # absolute imports only
                names.append(_top_level_name(node.module))
    return names


class TestModuleBoundary:
    """Verify rivet_cli imports only allowed modules (Property 10)."""

    @pytest.fixture(scope="class")
    def cli_source_files(self) -> list[Path]:
        cli_pkg = Path(__file__).resolve().parents[2] / "src" / "rivet_cli"
        return sorted(cli_pkg.rglob("*.py"))

    @pytest.fixture(scope="class")
    def stdlib_modules(self) -> frozenset[str]:
        return _get_stdlib_modules()

    def test_no_disallowed_imports(self, cli_source_files, stdlib_modules):
        violations: list[str] = []
        for path in cli_source_files:
            source = path.read_text()
            for mod in _collect_imports(source):
                if mod in stdlib_modules or mod in _ALLOWED_PACKAGES:
                    continue
                violations.append(f"{path.name}: disallowed import '{mod}'")
        assert violations == [], "Module boundary violations:\n" + "\n".join(violations)

    def test_cli_files_found(self, cli_source_files):
        # Sanity: we actually found source files to check
        assert len(cli_source_files) >= 10
