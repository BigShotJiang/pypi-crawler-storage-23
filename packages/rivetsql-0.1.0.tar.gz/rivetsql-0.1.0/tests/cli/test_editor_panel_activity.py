# Feature: repl-query-guard, Task 6.1: EditorPanel ActivityChanged handling
"""Tests for EditorPanel ActivityChanged message handling.

Validates: Requirements 4.1, 4.3
"""

from __future__ import annotations

from rivet_cli.repl.widgets.editor import EditorPanel
from rivet_cli.repl.widgets.status_bar import ActivityChanged
from rivet_core.interactive.types import Activity_State


class TestEditorPanelActivityChanged:
    """Validate EditorPanel disables execute on EXECUTING and re-enables on IDLE."""

    def _make_panel(self) -> EditorPanel:
        return EditorPanel(session=None)

    def test_initially_not_executing(self) -> None:
        panel = self._make_panel()
        assert panel._executing is False

    def test_executing_disables_execute(self) -> None:
        panel = self._make_panel()
        panel.on_activity_changed(ActivityChanged(state=Activity_State.EXECUTING))
        assert panel._executing is True

    def test_idle_re_enables_execute(self) -> None:
        panel = self._make_panel()
        panel.on_activity_changed(ActivityChanged(state=Activity_State.EXECUTING))
        assert panel._executing is True
        panel.on_activity_changed(ActivityChanged(state=Activity_State.IDLE))
        assert panel._executing is False

    def test_compiling_does_not_block_execute(self) -> None:
        panel = self._make_panel()
        panel.on_activity_changed(ActivityChanged(state=Activity_State.COMPILING))
        assert panel._executing is False

    def test_execute_action_blocked_when_executing(self) -> None:
        """action_execute_current should not post QuerySubmitted when executing."""
        panel = self._make_panel()
        panel._tabs = []  # ensure _add_tab is called on mount
        # Manually add a tab with content
        from rivet_cli.repl.widgets.editor import EditorTab, TabKind
        panel._tabs.append(EditorTab(kind=TabKind.AD_HOC, title="Q1", content="SELECT 1"))
        panel._executing = True

        messages: list = []
        panel.post_message = lambda msg: messages.append(msg)  # type: ignore[assignment]

        panel.action_execute_current()
        assert len(messages) == 0, "Should not post QuerySubmitted while executing"

    def test_execute_action_allowed_when_idle(self) -> None:
        """action_execute_current should post QuerySubmitted when idle."""
        panel = self._make_panel()
        from rivet_cli.repl.widgets.editor import EditorTab, TabKind
        panel._tabs.append(EditorTab(kind=TabKind.AD_HOC, title="Q1", content="SELECT 1"))

        messages: list = []
        panel.post_message = lambda msg: messages.append(msg)  # type: ignore[assignment]

        # get_selected_sql falls back to tab content when no TextArea is mounted
        panel.action_execute_current()
        assert len(messages) == 1
        assert isinstance(messages[0], EditorPanel.QuerySubmitted)
        assert messages[0].sql == "SELECT 1"

    def test_transition_executing_to_idle_allows_execute(self) -> None:
        """After transitioning from EXECUTING to IDLE, execute should work."""
        panel = self._make_panel()
        from rivet_cli.repl.widgets.editor import EditorTab, TabKind
        panel._tabs.append(EditorTab(kind=TabKind.AD_HOC, title="Q1", content="SELECT 1"))

        panel.on_activity_changed(ActivityChanged(state=Activity_State.EXECUTING))
        assert panel._executing is True

        panel.on_activity_changed(ActivityChanged(state=Activity_State.IDLE))
        assert panel._executing is False

        messages: list = []
        panel.post_message = lambda msg: messages.append(msg)  # type: ignore[assignment]
        panel.action_execute_current()
        assert len(messages) == 1
