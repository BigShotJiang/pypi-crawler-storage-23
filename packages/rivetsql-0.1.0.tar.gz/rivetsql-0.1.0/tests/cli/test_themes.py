"""Tests for REPL theme files and theme loader.

Validates: Requirements 27.1, 27.2, 27.3, 27.4
"""

from __future__ import annotations

import logging
from pathlib import Path

import pytest

from rivet_cli.repl.themes import BUILTIN_THEMES, resolve_theme


class TestBuiltinThemes:
    def test_rivet_theme_exists(self) -> None:
        assert BUILTIN_THEMES["rivet"].is_file()

    def test_rivet_light_theme_exists(self) -> None:
        assert BUILTIN_THEMES["rivet-light"].is_file()

    def test_high_contrast_theme_exists(self) -> None:
        assert BUILTIN_THEMES["rivet-high-contrast"].is_file()

    def test_all_builtin_themes_are_tcss(self) -> None:
        for name, path in BUILTIN_THEMES.items():
            assert path.suffix == ".tcss", f"{name} should be a .tcss file"

    def test_all_builtin_themes_are_non_empty(self) -> None:
        for name, path in BUILTIN_THEMES.items():
            content = path.read_text(encoding="utf-8")
            assert len(content) > 0, f"{name} theme file is empty"


class TestThemeColorConventions:
    """Verify color convention tokens are present in each theme (Req 27.2)."""

    # These CSS variable names encode the required color conventions.
    _REQUIRED_TOKENS = [
        "$keyword",
        "$string",
        "$number",
        "$comment",
        "$assertion",
        "$audit",
        "$error",
        "$warning",
        "$success",
        "$joint-name",
        "$type-label",
        "$null-value",
    ]

    @pytest.mark.parametrize("theme_name", list(BUILTIN_THEMES.keys()))
    def test_theme_defines_all_color_tokens(self, theme_name: str) -> None:
        content = BUILTIN_THEMES[theme_name].read_text(encoding="utf-8")
        for token in self._REQUIRED_TOKENS:
            assert token in content, (
                f"Theme '{theme_name}' is missing color token '{token}'"
            )


class TestHighContrastTheme:
    """Verify WCAG AAA requirements for high_contrast theme (Req 27.1, 35.4)."""

    def _content(self) -> str:
        return BUILTIN_THEMES["rivet-high-contrast"].read_text(encoding="utf-8")

    def test_uses_bold_borders(self) -> None:
        content = self._content()
        # Must use 'heavy' border style for bold borders between panels
        assert "heavy" in content, "high_contrast theme must use bold (heavy) borders"

    def test_no_color_only_indicators(self) -> None:
        content = self._content()
        # The theme comments must document that icons accompany color indicators
        assert "not color-only" in content, (
            "high_contrast theme must document that status indicators use icon + color"
        )

    def test_black_background(self) -> None:
        content = self._content()
        assert "#000000" in content, "high_contrast theme should use pure black background"


class TestResolveTheme:
    def test_resolve_builtin_rivet(self) -> None:
        path = resolve_theme("rivet")
        assert path == BUILTIN_THEMES["rivet"]
        assert path.is_file()

    def test_resolve_builtin_rivet_light(self) -> None:
        path = resolve_theme("rivet-light")
        assert path == BUILTIN_THEMES["rivet-light"]

    def test_resolve_builtin_high_contrast(self) -> None:
        path = resolve_theme("rivet-high-contrast")
        assert path == BUILTIN_THEMES["rivet-high-contrast"]

    def test_unknown_theme_falls_back_to_default(self, caplog: pytest.LogCaptureFixture) -> None:
        with caplog.at_level(logging.ERROR):
            path = resolve_theme("nonexistent-theme")
        assert path == BUILTIN_THEMES["rivet"]
        assert "RVT-863" in caplog.text

    def test_custom_theme_path_valid(self, tmp_path: Path) -> None:
        custom = tmp_path / "my_theme.tcss"
        custom.write_text("Screen { background: #ff0000; }", encoding="utf-8")
        path = resolve_theme("custom", theme_path=str(custom))
        assert path == custom

    def test_custom_theme_path_missing_falls_back(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        missing = str(tmp_path / "missing.tcss")
        with caplog.at_level(logging.ERROR):
            path = resolve_theme("custom", theme_path=missing)
        assert path == BUILTIN_THEMES["rivet"]
        assert "RVT-863" in caplog.text

    def test_no_theme_path_uses_name(self) -> None:
        path = resolve_theme("rivet-light", theme_path=None)
        assert path == BUILTIN_THEMES["rivet-light"]


class TestReplConfigThemePath:
    """Verify ReplConfig supports theme_path field (Req 27.3)."""

    def test_theme_path_default_is_none(self) -> None:
        from rivet_cli.repl.config import ReplConfig
        cfg = ReplConfig()
        assert cfg.theme_path is None

    def test_theme_path_parsed_from_dict(self) -> None:
        from rivet_cli.repl.config import ReplConfig
        cfg = ReplConfig.from_dict({"theme_path": "/path/to/my.tcss"})
        assert cfg.theme_path == "/path/to/my.tcss"

    def test_theme_path_absent_is_none(self) -> None:
        from rivet_cli.repl.config import ReplConfig
        cfg = ReplConfig.from_dict({})
        assert cfg.theme_path is None
