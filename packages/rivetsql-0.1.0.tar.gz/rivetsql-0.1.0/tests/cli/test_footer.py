"""Tests for the ReplFooter widget.

Validates: Requirements 3.3, 24.2

Tests cover:
- Default hint text (no focused panel)
- Context-sensitive hints per panel (catalog, editor, results)
- Debug mode replaces normal hints with debug controls
- set_focused_panel() and set_debug_mode() public API
- FocusedPanelChanged and DebugModeChanged messages
"""

from __future__ import annotations

from rivet_cli.repl.widgets.footer import (
    _DEBUG_HINTS,
    _PANEL_HINTS,
    DebugModeChanged,
    FocusedPanelChanged,
    ReplFooter,
)


class TestPanelHints:
    """Context-sensitive hints are defined for each panel."""

    def test_catalog_panel_hint_defined(self) -> None:
        assert "catalog-panel" in _PANEL_HINTS
        assert _PANEL_HINTS["catalog-panel"]

    def test_editor_panel_hint_defined(self) -> None:
        assert "editor-panel" in _PANEL_HINTS
        assert _PANEL_HINTS["editor-panel"]

    def test_results_panel_hint_defined(self) -> None:
        assert "results-panel" in _PANEL_HINTS
        assert _PANEL_HINTS["results-panel"]

    def test_default_hint_defined(self) -> None:
        assert "" in _PANEL_HINTS
        assert _PANEL_HINTS[""]

    def test_debug_hints_non_empty(self) -> None:
        assert _DEBUG_HINTS

    def test_debug_hints_contain_step(self) -> None:
        assert "F10" in _DEBUG_HINTS or "step" in _DEBUG_HINTS.lower()

    def test_debug_hints_contain_continue(self) -> None:
        assert "F5" in _DEBUG_HINTS or "continue" in _DEBUG_HINTS.lower()

    def test_debug_hints_contain_stop(self) -> None:
        assert "stop" in _DEBUG_HINTS.lower() or "Shift+F5" in _DEBUG_HINTS


class TestReplFooterInit:
    """ReplFooter initialises with correct defaults."""

    def test_initial_focused_panel_empty(self) -> None:
        footer = ReplFooter()
        assert footer._focused_panel == ""

    def test_initial_debug_inactive(self) -> None:
        footer = ReplFooter()
        assert footer._debug_active is False


class TestReplFooterSetFocusedPanel:
    """set_focused_panel() updates state."""

    def test_set_catalog_panel(self) -> None:
        footer = ReplFooter()
        footer._focused_panel = "catalog-panel"
        assert footer._focused_panel == "catalog-panel"

    def test_set_editor_panel(self) -> None:
        footer = ReplFooter()
        footer._focused_panel = "editor-panel"
        assert footer._focused_panel == "editor-panel"

    def test_set_results_panel(self) -> None:
        footer = ReplFooter()
        footer._focused_panel = "results-panel"
        assert footer._focused_panel == "results-panel"

    def test_set_unknown_panel_falls_back_to_default(self) -> None:
        footer = ReplFooter()
        footer._focused_panel = "unknown-panel"
        # _PANEL_HINTS.get with fallback to "" key
        hint = _PANEL_HINTS.get(footer._focused_panel, _PANEL_HINTS[""])
        assert hint == _PANEL_HINTS[""]


class TestReplFooterDebugMode:
    """set_debug_mode() updates state."""

    def test_enable_debug_mode(self) -> None:
        footer = ReplFooter()
        footer._debug_active = True
        assert footer._debug_active is True

    def test_disable_debug_mode(self) -> None:
        footer = ReplFooter()
        footer._debug_active = True
        footer._debug_active = False
        assert footer._debug_active is False


class TestFocusedPanelChangedMessage:
    """FocusedPanelChanged message carries panel_id."""

    def test_panel_id_stored(self) -> None:
        msg = FocusedPanelChanged("editor-panel")
        assert msg.panel_id == "editor-panel"

    def test_empty_panel_id(self) -> None:
        msg = FocusedPanelChanged("")
        assert msg.panel_id == ""


class TestDebugModeChangedMessage:
    """DebugModeChanged message carries active flag."""

    def test_active_true(self) -> None:
        msg = DebugModeChanged(True)
        assert msg.active is True

    def test_active_false(self) -> None:
        msg = DebugModeChanged(False)
        assert msg.active is False


class TestHintLogic:
    """Hint selection logic is correct."""

    def test_debug_mode_overrides_panel_hint(self) -> None:
        footer = ReplFooter()
        footer._focused_panel = "editor-panel"
        footer._debug_active = True
        # When debug is active, debug hints should be used
        expected = _DEBUG_HINTS
        # Verify the logic: debug takes priority
        hint = _DEBUG_HINTS if footer._debug_active else _PANEL_HINTS.get(footer._focused_panel, _PANEL_HINTS[""])
        assert hint == expected

    def test_normal_mode_uses_panel_hint(self) -> None:
        footer = ReplFooter()
        footer._focused_panel = "catalog-panel"
        footer._debug_active = False
        hint = _DEBUG_HINTS if footer._debug_active else _PANEL_HINTS.get(footer._focused_panel, _PANEL_HINTS[""])
        assert hint == _PANEL_HINTS["catalog-panel"]

    def test_no_panel_uses_default_hint(self) -> None:
        footer = ReplFooter()
        footer._focused_panel = ""
        footer._debug_active = False
        hint = _DEBUG_HINTS if footer._debug_active else _PANEL_HINTS.get(footer._focused_panel, _PANEL_HINTS[""])
        assert hint == _PANEL_HINTS[""]
