"""Tests for CompilationView widget.

Validates: Requirements 3.1, 3.2, 3.3, 3.4, 3.5, 3.6
"""

from __future__ import annotations

from unittest.mock import MagicMock

from rivet_cli.repl.widgets.compilation_view import CompilationView, _CompilationViewState


def _mock_assembly() -> MagicMock:
    """Create a minimal mock CompiledAssembly."""
    asm = MagicMock()
    asm.joints = []
    asm.fused_groups = []
    asm.materializations = []
    asm.execution_order = []
    asm.engines = []
    asm.catalogs = []
    asm.adapters = []
    asm.engine_boundaries = []
    asm.success = True
    asm.profile_name = "default"
    asm.errors = []
    asm.warnings = []
    return asm


# ---------------------------------------------------------------------------
# State-only tests (no Textual needed)
# ---------------------------------------------------------------------------


class TestCompilationViewState:
    """Test the pure state management layer."""

    def test_initial_state_is_placeholder(self) -> None:
        cv = _CompilationViewState()
        cv._init_state()
        assert cv._placeholder is True
        assert cv._errors == []
        assert cv._assembly is None

    def test_show_errors_clears_placeholder(self) -> None:
        cv = _CompilationViewState()
        cv._init_state()
        cv.show_errors(["syntax error near SELECT"])
        assert cv._placeholder is False
        assert cv._errors == ["syntax error near SELECT"]
        assert cv._assembly is None

    def test_show_assembly_clears_errors(self) -> None:
        cv = _CompilationViewState()
        cv._init_state()
        cv.show_errors(["err"])
        asm = _mock_assembly()
        cv.show_assembly(asm)
        assert cv._placeholder is False
        assert cv._errors == []
        assert cv._assembly is asm

    def test_show_placeholder_resets_all(self) -> None:
        cv = _CompilationViewState()
        cv._init_state()
        cv.show_errors(["err"])
        cv.show_placeholder()
        assert cv._placeholder is True
        assert cv._errors == []
        assert cv._assembly is None

    def test_show_assembly_clears_placeholder(self) -> None:
        cv = _CompilationViewState()
        cv._init_state()
        asm = _mock_assembly()
        cv.show_assembly(asm)
        assert cv._placeholder is False

    def test_show_assembly_stores_verbosity(self) -> None:
        cv = _CompilationViewState()
        cv._init_state()
        asm = _mock_assembly()
        cv.show_assembly(asm, verbosity=2)
        assert cv._verbosity == 2

    def test_show_errors_copies_list(self) -> None:
        """Errors list should be a copy, not a reference."""
        cv = _CompilationViewState()
        cv._init_state()
        original = ["err1", "err2"]
        cv.show_errors(original)
        original.append("err3")
        assert len(cv._errors) == 2

    def test_on_state_changed_called(self) -> None:
        cv = _CompilationViewState()
        cv._init_state()
        calls: list[str] = []
        cv._on_state_changed = lambda: calls.append("changed")  # type: ignore[assignment]

        cv.show_placeholder()
        cv.show_errors(["e"])
        asm = _mock_assembly()
        cv.show_assembly(asm)
        assert len(calls) == 3


class TestCompilationViewHeadless:
    """Test the headless fallback (CompilationView without Textual)."""

    def test_headless_show_assembly(self) -> None:
        """CompilationView should work as headless state container."""
        cv = CompilationView(session=None)
        asm = _mock_assembly()
        cv.show_assembly(asm)
        assert cv._assembly is asm
        assert cv._placeholder is False

    def test_headless_show_errors(self) -> None:
        cv = CompilationView(session=None)
        cv.show_errors(["bad SQL"])
        assert cv._errors == ["bad SQL"]

    def test_headless_show_placeholder(self) -> None:
        cv = CompilationView(session=None)
        cv.show_errors(["err"])
        cv.show_placeholder()
        assert cv._placeholder is True
        assert cv._errors == []

    def test_headless_session_stored(self) -> None:
        session = MagicMock()
        cv = CompilationView(session=session)
        assert cv._session is session
