"""Tests for ProgressIndicator widget.

Validates: Requirements 2.1, 2.2, 2.3
"""

from __future__ import annotations

from rivet_cli.repl.widgets.progress_indicator import _PHASE_LABELS, _ProgressIndicatorState
from rivet_core.interactive.types import QueryProgress


def _make_state() -> _ProgressIndicatorState:
    s = _ProgressIndicatorState()
    s._init_state()
    return s


class TestProgressIndicatorState:
    """Test the pure state management layer."""

    def test_initial_state(self) -> None:
        s = _make_state()
        assert s.phase == "Compiling\u2026"
        assert s.joint_name == ""
        assert s.current == 0
        assert s.total == 0

    def test_update_compiling(self) -> None:
        s = _make_state()
        s.update_progress(QueryProgress(
            joint_name="my_joint", status="compiling",
            current=0, total=5, rows=None, elapsed_ms=100.0,
        ))
        assert s.phase == "Compiling\u2026"
        assert s.joint_name == "my_joint"
        assert s.current == 0
        assert s.total == 5

    def test_update_executing(self) -> None:
        s = _make_state()
        s.update_progress(QueryProgress(
            joint_name="step_2", status="executing",
            current=2, total=5, rows=100, elapsed_ms=500.0,
        ))
        assert s.phase == "Executing\u2026"
        assert s.joint_name == "step_2"
        assert s.current == 2
        assert s.total == 5

    def test_update_done(self) -> None:
        s = _make_state()
        s.update_progress(QueryProgress(
            joint_name="final", status="done",
            current=5, total=5, rows=1000, elapsed_ms=2000.0,
        ))
        assert s.phase == "Done"
        assert s.current == 5
        assert s.total == 5

    def test_update_failed(self) -> None:
        s = _make_state()
        s.update_progress(QueryProgress(
            joint_name="broken", status="failed",
            current=3, total=5, rows=None, elapsed_ms=1500.0,
        ))
        assert s.phase == "Failed"
        assert s.joint_name == "broken"

    def test_phase_labels_cover_all_statuses(self) -> None:
        for status in ("compiling", "executing", "done", "failed"):
            assert status in _PHASE_LABELS

    def test_sequential_updates(self) -> None:
        s = _make_state()
        for i in range(4):
            s.update_progress(QueryProgress(
                joint_name=f"joint_{i}", status="executing",
                current=i, total=3, rows=None, elapsed_ms=float(i * 100),
            ))
        assert s.joint_name == "joint_3"
        assert s.current == 3

    def test_on_state_changed_called(self) -> None:
        calls: list[bool] = []
        s = _make_state()
        s._on_state_changed = lambda: calls.append(True)  # type: ignore[assignment]
        s.update_progress(QueryProgress(
            joint_name="x", status="executing",
            current=1, total=2, rows=None, elapsed_ms=0.0,
        ))
        assert len(calls) == 1
