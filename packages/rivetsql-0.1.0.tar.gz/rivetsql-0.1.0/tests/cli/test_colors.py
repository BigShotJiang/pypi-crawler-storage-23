"""Unit tests for color utilities (Property 3)."""

from hypothesis import given, settings
from hypothesis import strategies as st

from rivet_cli.rendering.colors import (
    BLUE,
    BOLD,
    CYAN,
    DIM,
    GREEN,
    MAGENTA,
    RED,
    RESET,
    SYM_ASSERT,
    SYM_AUDIT,
    SYM_CHECK,
    SYM_ERROR,
    SYM_MATERIALIZE,
    SYM_NOT_APPLICABLE,
    SYM_WARN,
    YELLOW,
    colorize,
)


class TestColorConstants:
    def test_ansi_codes(self) -> None:
        assert GREEN == "\033[32m"
        assert YELLOW == "\033[33m"
        assert RED == "\033[31m"
        assert BLUE == "\033[34m"
        assert DIM == "\033[2m"
        assert CYAN == "\033[36m"
        assert MAGENTA == "\033[35m"
        assert BOLD == "\033[1m"
        assert RESET == "\033[0m"

    def test_symbols(self) -> None:
        assert SYM_CHECK == "✓"
        assert SYM_WARN == "⚠"
        assert SYM_ERROR == "✗"
        assert SYM_ASSERT == "◆"
        assert SYM_AUDIT == "●"
        assert SYM_MATERIALIZE == "⚡"
        assert SYM_NOT_APPLICABLE == "·"


class TestColorize:
    def test_enabled(self) -> None:
        result = colorize("hello", GREEN, enabled=True)
        assert result == f"{GREEN}hello{RESET}"

    def test_disabled(self) -> None:
        result = colorize("hello", GREEN, enabled=False)
        assert result == "hello"

    def test_different_colors(self) -> None:
        for color in [GREEN, YELLOW, RED, BLUE, DIM, CYAN, MAGENTA, BOLD]:
            result = colorize("x", color, enabled=True)
            assert result.startswith(color)
            assert result.endswith(RESET)

    @given(text=st.text(min_size=0, max_size=100))
    @settings(max_examples=100)
    def test_property3_no_color_no_ansi(self, text: str) -> None:
        """Property 3: No-color mode produces no ANSI escape codes."""
        result = colorize(text, GREEN, enabled=False)
        assert "\033[" not in result
        assert result == text
