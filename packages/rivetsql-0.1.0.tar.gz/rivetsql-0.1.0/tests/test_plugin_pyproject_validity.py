"""Verify per-plugin pyproject.toml files are valid independent distributions.

Each plugin under rivet/src/ that has its own pyproject.toml must:
1. Be an independent distribution (NOT in the root rivetsql-core wheel).
2. Define valid entry points that resolve to existing modules/symbols.
"""

import pathlib

import pytest

SRC = pathlib.Path(__file__).resolve().parent.parent / "src"
ROOT_PYPROJECT = pathlib.Path(__file__).resolve().parent.parent / "pyproject.toml"

# Plugins that have their own pyproject.toml
PLUGIN_DIRS = sorted(
    d for d in SRC.iterdir()
    if d.is_dir() and (d / "pyproject.toml").exists()
)


def _parse_toml(path: pathlib.Path) -> dict:
    """Minimal TOML parser for pyproject.toml (stdlib tomllib, Python 3.11+)."""
    import tomllib
    return tomllib.loads(path.read_text())


def _root_wheel_packages() -> list[str]:
    data = _parse_toml(ROOT_PYPROJECT)
    return data["tool"]["hatch"]["build"]["targets"]["wheel"]["packages"]


class TestPluginPyprojectValidity:
    """Per-plugin pyproject.toml files are valid independent distributions."""

    @pytest.mark.parametrize("plugin_dir", PLUGIN_DIRS, ids=lambda d: d.name)
    def test_plugin_not_in_root_wheel_packages(self, plugin_dir: pathlib.Path):
        """Plugins are independent distributions, not bundled in rivetsql-core."""
        packages = _root_wheel_packages()
        unexpected = f"src/{plugin_dir.name}"
        assert unexpected not in packages, (
            f"{plugin_dir.name} should be an independent distribution, "
            f"not bundled in the root rivetsql-core wheel"
        )

    @pytest.mark.parametrize("plugin_dir", PLUGIN_DIRS, ids=lambda d: d.name)
    def test_plugin_entry_points_resolve(self, plugin_dir: pathlib.Path):
        """Entry points in per-plugin pyproject.toml reference importable modules."""
        data = _parse_toml(plugin_dir / "pyproject.toml")
        entry_points = data.get("project", {}).get("entry-points", {})
        for group, eps in entry_points.items():
            for name, target in eps.items():
                module_path = target.split(":")[0]
                parts = module_path.split(".")
                mod_dir = SRC / parts[0]
                if len(parts) > 1:
                    mod_file = mod_dir / f"{parts[1]}.py"
                    assert mod_file.exists(), (
                        f"Entry point '{name}' in group '{group}' references "
                        f"'{module_path}' but {mod_file} does not exist"
                    )
                else:
                    assert (mod_dir / "__init__.py").exists(), (
                        f"Entry point '{name}' in group '{group}' references "
                        f"'{module_path}' but {mod_dir}/__init__.py does not exist"
                    )

    @pytest.mark.parametrize("plugin_dir", PLUGIN_DIRS, ids=lambda d: d.name)
    def test_plugin_has_build_system(self, plugin_dir: pathlib.Path):
        """Each per-plugin pyproject.toml declares a build system."""
        data = _parse_toml(plugin_dir / "pyproject.toml")
        assert "build-system" in data, (
            f"{plugin_dir.name}/pyproject.toml missing [build-system]"
        )
