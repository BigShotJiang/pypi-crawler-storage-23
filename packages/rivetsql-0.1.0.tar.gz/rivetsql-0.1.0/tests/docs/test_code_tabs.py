"""Property test for code_tabs: output contains all four tabs in correct order."""

from __future__ import annotations

import sys
from pathlib import Path

from hypothesis import given, settings
from hypothesis import strategies as st

# docs/scripts is not a package in the rivet src tree; add it to path.
sys.path.insert(0, str(Path(__file__).parents[3] / "docs" / "scripts"))

from code_tabs import code_tabs  # noqa: E402

_code = st.text(min_size=0, max_size=200)
_title = st.one_of(st.just(""), st.text(min_size=1, max_size=40))

EXPECTED_TABS = ["SQL", "YAML", "Python Declarations", "Python API"]


@given(sql=_code, yaml=_code, python_decl=_code, python_api=_code, title=_title)
@settings(max_examples=100)
def test_code_tabs_contains_all_four_tabs_in_order(
    sql: str, yaml: str, python_decl: str, python_api: str, title: str
) -> None:
    """Property 1: code_tabs output contains all four tabs in correct order."""
    result = code_tabs(sql, yaml, python_decl, python_api, title=title)

    # All four tab labels must appear
    for label in EXPECTED_TABS:
        assert f'=== "{label}"' in result, f'Missing tab: {label!r}'

    # Tabs must appear in the correct order: SQL < YAML < Python Declarations < Python API
    positions = [result.index(f'=== "{label}"') for label in EXPECTED_TABS]
    assert positions == sorted(positions), (
        f"Tabs out of order: {list(zip(EXPECTED_TABS, positions))}"
    )
