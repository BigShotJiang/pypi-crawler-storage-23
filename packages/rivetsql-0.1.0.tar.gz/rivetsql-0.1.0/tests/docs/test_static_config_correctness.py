"""Unit tests for static configuration correctness.

Feature: doc-site, Task 11.2
Validates: Requirements 1.4, 1.5, 1.7, 1.8, 10.3, 11.1–11.4, 12.1, 13.2
"""

from __future__ import annotations

import ast
from pathlib import Path

import yaml

# Project root: rivet/ sits inside the worktree; docs/ and mkdocs.yml are siblings.
_PROJECT_ROOT = Path(__file__).resolve().parents[2].parent  # tests -> rivet -> project root


class _PermissiveLoader(yaml.SafeLoader):
    """SafeLoader that treats !!python/name tags as plain strings."""

_PermissiveLoader.add_multi_constructor(
    "tag:yaml.org,2002:python/",
    lambda loader, suffix, node: loader.construct_scalar(node),
)


def _load_mkdocs() -> dict:
    with open(_PROJECT_ROOT / "mkdocs.yml") as f:
        return yaml.load(f, Loader=_PermissiveLoader)  # noqa: S506


# ── Requirement 1.4: mkdocs.yml contains all required nav sections ──────────


class TestMkDocsNavSections:
    def test_nav_has_required_top_level_sections(self) -> None:
        cfg = _load_mkdocs()
        nav = cfg["nav"]
        top_keys: list[str] = []
        for entry in nav:
            if isinstance(entry, dict):
                top_keys.extend(entry.keys())
        required = {"Home", "Getting Started", "Concepts", "Guides", "Plugins", "Reference"}
        assert required.issubset(set(top_keys))


# ── Requirement 1.5: search plugin enabled ───────────────────────────────────


class TestMkDocsSearch:
    def test_search_plugin_enabled(self) -> None:
        cfg = _load_mkdocs()
        plugins = cfg.get("plugins", [])
        plugin_names: list[str] = []
        for p in plugins:
            if isinstance(p, str):
                plugin_names.append(p)
            elif isinstance(p, dict):
                plugin_names.extend(p.keys())
        assert "search" in plugin_names


# ── Requirements 1.7, 1.8: GitHub Actions workflow ──────────────────────────


class TestDocsWorkflow:
    def test_workflow_file_exists(self) -> None:
        assert (_PROJECT_ROOT / ".github" / "workflows" / "docs.yml").is_file()

    def test_workflow_has_correct_steps(self) -> None:
        with open(_PROJECT_ROOT / ".github" / "workflows" / "docs.yml") as f:
            wf = yaml.safe_load(f)
        steps = wf["jobs"]["deploy"]["steps"]
        run_commands = [s["run"] for s in steps if "run" in s]
        assert any("pip install" in c for c in run_commands)
        assert any("generate_reference" in c for c in run_commands)
        assert any("mkdocs" in c and "deploy" in c for c in run_commands)


# ── Requirements 11.1–11.4, 12.1: expected guide files exist ────────────────


class TestGuideFilesExist:
    EXPECTED_GUIDES = [
        "guides/testing.md",
        "guides/quality-checks.md",
        "guides/write-strategies.md",
        "guides/repl.md",
        "plugins/development.md",
    ]

    def test_guide_files_present(self) -> None:
        docs_dir = _PROJECT_ROOT / "docs"
        for rel in self.EXPECTED_GUIDES:
            assert (docs_dir / rel).is_file(), f"Missing guide: {rel}"


# ── Requirement 13.2: home page contains mermaid diagram ────────────────────


class TestHomePage:
    def test_home_page_has_mermaid(self) -> None:
        content = (_PROJECT_ROOT / "docs" / "index.md").read_text()
        assert "```mermaid" in content


# ── Requirement 10.3: build script exposes main() and on_pre_build() ────────


class TestBuildScriptEntryPoints:
    def test_generate_reference_exposes_main_and_hook(self) -> None:
        script = _PROJECT_ROOT / "docs" / "scripts" / "generate_reference.py"
        tree = ast.parse(script.read_text())
        func_names = {
            node.name for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)
        }
        assert "main" in func_names
        assert "on_pre_build" in func_names
