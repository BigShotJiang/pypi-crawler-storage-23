"""Property test for CLI extractor subcommand coverage.

Property 7: CLI extractor produces a DocEntry for every parser subcommand.
Validates: Requirements 9.1 — When the Doc_Extractor processes the argparse
parser tree, it SHALL generate a reference page for each CLI command and
subcommand.
"""

from __future__ import annotations

import argparse

from hypothesis import given, settings
from hypothesis import strategies as st

from rivet_cli.docs.extractors.cli_extractor import _walk_parser
from rivet_cli.docs.models import DocEntry

# ── Helpers ───────────────────────────────────────────────────────────────────


def _collect_all_subcommand_names(parser: argparse.ArgumentParser) -> set[str]:
    """Recursively collect every subcommand name registered in the parser tree."""
    names: set[str] = set()
    for action in parser._actions:
        if isinstance(action, argparse._SubParsersAction):
            for name, sub in (action._name_parser_map or {}).items():
                names.add(name)
                names.update(_collect_all_subcommand_names(sub))
    return names


def _build_parser_from_spec(spec: dict) -> argparse.ArgumentParser:
    """Build an argparse parser from a nested spec dict.

    spec format: {"name": str, "children": [spec, ...]}
    """
    parser = argparse.ArgumentParser(prog=spec["name"])
    children = spec.get("children", [])
    if children:
        subs = parser.add_subparsers()
        for child in children:
            child_parser = subs.add_parser(child["name"])
            # Recursively attach grandchildren
            grandchildren = child.get("children", [])
            if grandchildren:
                child_subs = child_parser.add_subparsers()
                for gc in grandchildren:
                    child_subs.add_parser(gc["name"])
    return parser


# ── Strategies ────────────────────────────────────────────────────────────────

_CMD_NAME = st.from_regex(r"[a-z][a-z0-9_]{1,10}", fullmatch=True)


@st.composite
def parser_spec(draw) -> dict:
    """Generate a nested parser spec with up to 2 levels of subcommands."""
    root_name = draw(_CMD_NAME)
    num_children = draw(st.integers(min_value=0, max_value=5))
    children = []
    child_names: set[str] = set()
    for _ in range(num_children):
        name = draw(_CMD_NAME.filter(lambda n: n not in child_names))
        child_names.add(name)
        num_grandchildren = draw(st.integers(min_value=0, max_value=3))
        grandchildren = []
        gc_names: set[str] = set()
        for _ in range(num_grandchildren):
            gc_name = draw(_CMD_NAME.filter(lambda n, _s=gc_names: n not in _s))
            gc_names.add(gc_name)
            grandchildren.append({"name": gc_name, "children": []})
        children.append({"name": name, "children": grandchildren})
    return {"name": root_name, "children": children}


# ── Property tests ────────────────────────────────────────────────────────────


@given(spec=parser_spec())
@settings(max_examples=100)
def test_every_subcommand_has_doc_entry(spec: dict) -> None:
    """Property 7: _walk_parser produces a DocEntry for every subcommand in the tree."""
    parser = _build_parser_from_spec(spec)
    entries: list[DocEntry] = []
    _walk_parser(parser, parent_ref=None, entries=entries)

    ref_ids = {e.ref_id for e in entries}
    subcommand_names = _collect_all_subcommand_names(parser)

    # Every subcommand name must appear in at least one ref_id
    for name in subcommand_names:
        assert any(name in ref_id for ref_id in ref_ids), (
            f"Subcommand '{name}' has no corresponding DocEntry (ref_ids: {ref_ids})"
        )


@given(spec=parser_spec())
@settings(max_examples=100)
def test_entry_count_matches_node_count(spec: dict) -> None:
    """One DocEntry is produced per parser node (root + each subcommand)."""
    parser = _build_parser_from_spec(spec)
    entries: list[DocEntry] = []
    _walk_parser(parser, parent_ref=None, entries=entries)

    # Count total nodes: root + all subcommands at all levels
    def count_nodes(s: dict) -> int:
        return 1 + sum(count_nodes(c) for c in s.get("children", []))

    expected = count_nodes(spec)
    assert len(entries) == expected, (
        f"Expected {expected} entries for spec {spec}, got {len(entries)}"
    )


@given(spec=parser_spec())
@settings(max_examples=100)
def test_all_entries_are_cli_command_kind(spec: dict) -> None:
    """Every DocEntry produced by _walk_parser has kind='cli_command'."""
    parser = _build_parser_from_spec(spec)
    entries: list[DocEntry] = []
    _walk_parser(parser, parent_ref=None, entries=entries)

    for e in entries:
        assert e.kind == "cli_command", (
            f"Entry '{e.ref_id}' has kind='{e.kind}', expected 'cli_command'"
        )


@given(spec=parser_spec())
@settings(max_examples=100)
def test_all_entries_tagged_cli(spec: dict) -> None:
    """Every DocEntry produced by _walk_parser is tagged with 'cli'."""
    parser = _build_parser_from_spec(spec)
    entries: list[DocEntry] = []
    _walk_parser(parser, parent_ref=None, entries=entries)

    for e in entries:
        assert "cli" in e.tags, (
            f"Entry '{e.ref_id}' missing 'cli' tag (tags: {e.tags})"
        )


@given(spec=parser_spec())
@settings(max_examples=100)
def test_ref_ids_are_unique(spec: dict) -> None:
    """All ref_ids produced by _walk_parser are unique."""
    parser = _build_parser_from_spec(spec)
    entries: list[DocEntry] = []
    _walk_parser(parser, parent_ref=None, entries=entries)

    ref_ids = [e.ref_id for e in entries]
    assert len(ref_ids) == len(set(ref_ids)), (
        f"Duplicate ref_ids: {[r for r in ref_ids if ref_ids.count(r) > 1]}"
    )


@given(spec=parser_spec())
@settings(max_examples=100)
def test_parent_child_relationships_consistent(spec: dict) -> None:
    """Parent/child references in DocEntries are mutually consistent."""
    parser = _build_parser_from_spec(spec)
    entries: list[DocEntry] = []
    _walk_parser(parser, parent_ref=None, entries=entries)

    by_ref = {e.ref_id: e for e in entries}

    for e in entries:
        # If entry has a parent, the parent must list this entry as a child
        if e.parent is not None:
            assert e.parent in by_ref, (
                f"Entry '{e.ref_id}' references non-existent parent '{e.parent}'"
            )
            assert e.ref_id in by_ref[e.parent].children, (
                f"Parent '{e.parent}' does not list '{e.ref_id}' as a child"
            )
        # Every listed child must exist
        for child_ref in e.children:
            assert child_ref in by_ref, (
                f"Entry '{e.ref_id}' lists non-existent child '{child_ref}'"
            )
