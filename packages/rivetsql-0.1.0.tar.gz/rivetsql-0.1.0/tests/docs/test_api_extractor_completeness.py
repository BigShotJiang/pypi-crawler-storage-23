"""Property test for API extractor completeness.

Property 2: API extractor produces complete DocEntry for every public symbol.
Validates: Requirements 6.1, 6.3, 6.4
"""

from __future__ import annotations

import ast
import keyword
import tempfile
import textwrap
import warnings
from pathlib import Path

import pytest
from hypothesis import given, settings
from hypothesis import strategies as st

from rivet_cli.docs.extractors.api_extractor import extract_module, extract_package

# ---------------------------------------------------------------------------
# Strategies for generating Python source code
# ---------------------------------------------------------------------------

_IDENT = st.from_regex(r"[a-z][a-z0-9_]{0,12}", fullmatch=True).filter(
    lambda s: not keyword.iskeyword(s)
)
_TYPE = st.sampled_from(["str", "int", "float", "bool", "list[str]", "None"])
_DEFAULT = st.sampled_from(["None", "42", "True", '"hello"'])


@st.composite
def _params_src(draw, max_count: int = 3) -> str:
    """Generate a valid parameter list string (unique names, defaults at end)."""
    count = draw(st.integers(min_value=0, max_value=max_count))
    names = draw(
        st.lists(_IDENT, min_size=count, max_size=count, unique=True)
    )
    types = draw(st.lists(_TYPE, min_size=count, max_size=count))
    # Decide how many trailing params have defaults (0..count)
    n_defaults = draw(st.integers(min_value=0, max_value=count))
    parts: list[str] = []
    for i, (name, typ) in enumerate(zip(names, types)):
        if i >= count - n_defaults:
            default = draw(_DEFAULT)
            parts.append(f"{name}: {typ} = {default}")
        else:
            parts.append(f"{name}: {typ}")
    return ", ".join(parts)


@st.composite
def _function_src(draw, name: str | None = None) -> str:
    """Generate a public function source with docstring."""
    fname = name or draw(_IDENT.filter(lambda s: not s.startswith("_")))
    param_str = draw(_params_src(max_count=3))
    ret = draw(_TYPE)
    return textwrap.dedent(f"""\
        def {fname}({param_str}) -> {ret}:
            \"\"\"Docstring for {fname}.\"\"\"
            ...
    """)


@st.composite
def _class_src(draw, name: str | None = None) -> str:
    """Generate a public class source with docstring and methods."""
    cname = name or draw(
        st.from_regex(r"[A-Z][A-Za-z0-9]{0,12}", fullmatch=True)
    )
    method_count = draw(st.integers(min_value=0, max_value=3))
    method_lines: list[str] = []
    used_names: set[str] = set()
    for _ in range(method_count):
        mname = draw(_IDENT.filter(lambda s: s not in used_names))
        used_names.add(mname)
        param_str = draw(_params_src(max_count=2))
        ret = draw(_TYPE)
        full_params = f"self, {param_str}" if param_str else "self"
        # Each method is indented 4 spaces inside the class
        method_lines.append(f'    def {mname}({full_params}) -> {ret}:')
        method_lines.append(f'        """Docstring for {mname}."""')
        method_lines.append('        ...')
    body = "\n".join(method_lines) if method_lines else "    ..."
    return f'class {cname}:\n    """Docstring for {cname}."""\n{body}\n'


# ---------------------------------------------------------------------------
# Property tests
# ---------------------------------------------------------------------------


@given(func_src=_function_src())
@settings(max_examples=100)
def test_every_public_function_produces_entry(func_src: str) -> None:
    """Req 6.1: Every public function yields exactly one DocEntry."""
    with tempfile.TemporaryDirectory() as tmp:
        module_file = Path(tmp) / "mod.py"
        module_file.write_text(func_src)

        tree = ast.parse(func_src)
        public_funcs = [
            n.name
            for n in ast.walk(tree)
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
            and not n.name.startswith("_")
        ]

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            entries = extract_module(module_file, "testpkg")

        entry_names = {e.name for e in entries}
        for fname in public_funcs:
            assert fname in entry_names, f"Missing entry for public function {fname!r}"


@given(class_src=_class_src())
@settings(max_examples=100)
def test_every_public_class_produces_entry(class_src: str) -> None:
    """Req 6.1: Every public class yields a DocEntry with kind='class'."""
    with tempfile.TemporaryDirectory() as tmp:
        module_file = Path(tmp) / "mod.py"
        module_file.write_text(class_src)

        tree = ast.parse(class_src)
        public_classes = [
            n.name
            for n in ast.walk(tree)
            if isinstance(n, ast.ClassDef) and not n.name.startswith("_")
        ]

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            entries = extract_module(module_file, "testpkg")

        class_entries = {e.name for e in entries if e.kind == "class"}
        for cname in public_classes:
            assert cname in class_entries, f"Missing class entry for {cname!r}"


@given(func_src=_function_src())
@settings(max_examples=100)
def test_entry_has_signature_and_return_type(func_src: str) -> None:
    """Req 6.1, 6.3: Each function DocEntry has a non-empty signature and return type."""
    with tempfile.TemporaryDirectory() as tmp:
        module_file = Path(tmp) / "mod.py"
        module_file.write_text(func_src)

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            entries = extract_module(module_file, "testpkg")

        for entry in entries:
            if entry.kind == "function":
                assert entry.signature, f"Entry {entry.ref_id!r} missing signature"
                assert entry.returns, f"Entry {entry.ref_id!r} missing return type"


@given(func_src=_function_src())
@settings(max_examples=100)
def test_typed_params_have_type_hints(func_src: str) -> None:
    """Req 6.3: Parameters with type annotations are captured in DocParam.type_hint."""
    with tempfile.TemporaryDirectory() as tmp:
        module_file = Path(tmp) / "mod.py"
        module_file.write_text(func_src)

        tree = ast.parse(func_src)

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            entries = extract_module(module_file, "testpkg")

        for entry in entries:
            if entry.kind != "function":
                continue
            for node in ast.walk(tree):
                if (
                    isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
                    and node.name == entry.name
                ):
                    for arg in node.args.args:
                        if arg.arg in ("self", "cls"):
                            continue
                        if arg.annotation is not None:
                            expected_type = ast.unparse(arg.annotation)
                            param = next(
                                (p for p in entry.params if p.name == arg.arg), None
                            )
                            assert param is not None, (
                                f"Param {arg.arg!r} missing from entry {entry.ref_id!r}"
                            )
                            assert param.type_hint == expected_type, (
                                f"Type hint mismatch for {arg.arg!r}: "
                                f"expected {expected_type!r}, got {param.type_hint!r}"
                            )


def test_missing_docstring_produces_placeholder(tmp_path: Path) -> None:
    """Req 6.4: Symbols without docstrings get a placeholder docstring."""
    src = textwrap.dedent("""\
        def no_docs(x: int) -> int:
            return x
    """)
    module_file = tmp_path / "mod.py"
    module_file.write_text(src)

    with pytest.warns(UserWarning, match="Missing docstring"):
        entries = extract_module(module_file, "testpkg")

    assert len(entries) == 1
    assert entries[0].docstring is not None
    assert "No documentation available" in entries[0].docstring


@given(
    func_names=st.lists(
        _IDENT.filter(lambda s: not s.startswith("_")),
        min_size=1,
        max_size=5,
        unique=True,
    )
)
@settings(max_examples=100)
def test_entry_count_matches_public_symbol_count(func_names: list[str]) -> None:
    """Req 6.1: Number of top-level entries equals number of public functions."""
    lines = []
    for fname in func_names:
        lines.append(f'def {fname}() -> None:\n    """Docstring."""\n    ...\n')
    src = "\n".join(lines)

    with tempfile.TemporaryDirectory() as tmp:
        module_file = Path(tmp) / "mod.py"
        module_file.write_text(src)

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            entries = extract_module(module_file, "testpkg")

    assert len(entries) == len(func_names), (
        f"Expected {len(func_names)} entries, got {len(entries)}"
    )


@given(func_src=_function_src())
@settings(max_examples=100)
def test_entry_ref_id_contains_package_and_name(func_src: str) -> None:
    """Req 6.1: ref_id is fully qualified (package.module.name)."""
    with tempfile.TemporaryDirectory() as tmp:
        module_file = Path(tmp) / "mymod.py"
        module_file.write_text(func_src)

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            entries = extract_module(module_file, "mypkg")

        for entry in entries:
            assert entry.ref_id.startswith("mypkg."), (
                f"ref_id {entry.ref_id!r} does not start with package name"
            )
            assert entry.name in entry.ref_id, (
                f"Symbol name {entry.name!r} not in ref_id {entry.ref_id!r}"
            )


def test_private_symbols_excluded(tmp_path: Path) -> None:
    """Req 6.1: Private symbols (underscore-prefixed) are not extracted."""
    src = textwrap.dedent("""\
        def _private() -> None:
            \"\"\"Private.\"\"\"
            ...

        def public() -> None:
            \"\"\"Public.\"\"\"
            ...
    """)
    module_file = tmp_path / "mod.py"
    module_file.write_text(src)

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        entries = extract_module(module_file, "testpkg")

    names = {e.name for e in entries}
    assert "public" in names
    assert "_private" not in names


def test_syntax_error_returns_empty(tmp_path: Path) -> None:
    """Req 6.1: Syntax errors in source files yield no entries (resilience)."""
    src = "def broken(\n"
    module_file = tmp_path / "mod.py"
    module_file.write_text(src)

    entries = extract_module(module_file, "testpkg")
    assert entries == []


@given(class_src=_class_src())
@settings(max_examples=100)
def test_class_methods_have_parent_ref(class_src: str) -> None:
    """Req 6.1: Method entries have parent set to the enclosing class ref_id."""
    with tempfile.TemporaryDirectory() as tmp:
        module_file = Path(tmp) / "mod.py"
        module_file.write_text(class_src)

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            entries = extract_module(module_file, "testpkg")

        class_entries = {e.ref_id: e for e in entries if e.kind == "class"}
        method_entries = [e for e in entries if e.kind == "method"]

        for method in method_entries:
            assert method.parent is not None, (
                f"Method {method.ref_id!r} has no parent"
            )
            assert method.parent in class_entries, (
                f"Method {method.ref_id!r} parent {method.parent!r} not a known class"
            )


def test_package_walk_covers_all_modules(tmp_path: Path) -> None:
    """Req 6.1: extract_package walks all .py files and collects entries."""
    pkg = tmp_path / "mypkg"
    pkg.mkdir()
    (pkg / "__init__.py").write_text('"""Package."""\n')
    (pkg / "mod_a.py").write_text(
        'def func_a() -> None:\n    """Function A."""\n    ...\n'
    )
    sub = pkg / "sub"
    sub.mkdir()
    (sub / "__init__.py").write_text("")
    (sub / "mod_b.py").write_text(
        'def func_b() -> None:\n    """Function B."""\n    ...\n'
    )

    entries = extract_package(pkg)
    names = {e.name for e in entries}
    assert "func_a" in names
    assert "func_b" in names
