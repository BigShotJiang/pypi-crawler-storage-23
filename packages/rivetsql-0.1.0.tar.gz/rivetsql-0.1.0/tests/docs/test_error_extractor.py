"""Tests for the error extractor."""

from __future__ import annotations

import textwrap
import warnings
from pathlib import Path

import pytest

from rivet_cli.docs.extractors.error_extractor import (
    _code_group,
    extract_error_catalog,
)


@pytest.fixture()
def src_dir(tmp_path: Path) -> Path:
    d = tmp_path / "src"
    d.mkdir()
    return d


class TestCodeGroup:
    def test_known_ranges(self) -> None:
        assert _code_group("RVT-101") == "engine"
        assert _code_group("RVT-201") == "plugin"
        assert _code_group("RVT-301") == "DAG"
        assert _code_group("RVT-401") == "materialization"
        assert _code_group("RVT-501") == "execution"
        assert _code_group("RVT-601") == "assertion/audit"
        assert _code_group("RVT-701") == "SQL"
        assert _code_group("RVT-801") == "CLI"

    def test_unknown_range(self) -> None:
        assert _code_group("RVT-901") == "unknown"


class TestExtractErrorCatalog:
    def test_extracts_rivet_error_keyword_args(self, src_dir: Path) -> None:
        (src_dir / "a.py").write_text(
            textwrap.dedent("""\
                from rivet_core.errors import RivetError
                e = RivetError(
                    code="RVT-301",
                    message="Duplicate joint",
                    remediation="Fix it",
                )
            """)
        )
        entries = extract_error_catalog([src_dir])
        assert len(entries) == 1
        e = entries[0]
        assert e.ref_id == "error.RVT-301"
        assert e.kind == "error_code"
        assert e.name == "RVT-301"
        assert e.metadata["message"] == "Duplicate joint"
        assert e.metadata["remediation"] == "Fix it"
        assert e.metadata["group"] == "DAG"

    def test_extracts_positional_args(self, src_dir: Path) -> None:
        (src_dir / "b.py").write_text(
            textwrap.dedent("""\
                from rivet_core.errors import RivetError
                e = RivetError("RVT-101", "Engine failed")
            """)
        )
        entries = extract_error_catalog([src_dir])
        assert len(entries) == 1
        assert entries[0].metadata["code"] == "RVT-101"
        assert entries[0].metadata["message"] == "Engine failed"

    def test_extracts_plugin_error(self, src_dir: Path) -> None:
        (src_dir / "c.py").write_text(
            textwrap.dedent("""\
                from rivet_core.errors import plugin_error
                e = plugin_error(
                    "RVT-201",
                    "Bad plugin",
                    plugin_name="x",
                    plugin_type="catalog",
                    remediation="Fix plugin",
                )
            """)
        )
        entries = extract_error_catalog([src_dir])
        assert len(entries) == 1
        assert entries[0].metadata["code"] == "RVT-201"
        assert entries[0].metadata["remediation"] == "Fix plugin"

    def test_deduplicates_by_code(self, src_dir: Path) -> None:
        (src_dir / "d.py").write_text(
            textwrap.dedent("""\
                from rivet_core.errors import RivetError
                e1 = RivetError(code="RVT-301", message="First")
                e2 = RivetError(code="RVT-301", message="Second")
            """)
        )
        entries = extract_error_catalog([src_dir])
        assert len(entries) == 1
        assert entries[0].metadata["message"] == "First"

    def test_warns_missing_remediation(self, src_dir: Path) -> None:
        (src_dir / "e.py").write_text(
            textwrap.dedent("""\
                from rivet_core.errors import RivetError
                e = RivetError(code="RVT-501", message="No fix")
            """)
        )
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            extract_error_catalog([src_dir])
        assert any("RVT-501" in str(x.message) and "missing remediation" in str(x.message) for x in w)

    def test_groups_by_code_range(self, src_dir: Path) -> None:
        (src_dir / "f.py").write_text(
            textwrap.dedent("""\
                from rivet_core.errors import RivetError
                a = RivetError(code="RVT-101", message="a", remediation="r")
                b = RivetError(code="RVT-301", message="b", remediation="r")
                c = RivetError(code="RVT-701", message="c", remediation="r")
            """)
        )
        entries = extract_error_catalog([src_dir])
        groups = {e.metadata["code"]: e.metadata["group"] for e in entries}
        assert groups == {"RVT-101": "engine", "RVT-301": "DAG", "RVT-701": "SQL"}

    def test_skips_syntax_errors(self, src_dir: Path) -> None:
        (src_dir / "good.py").write_text(
            'from rivet_core.errors import RivetError\ne = RivetError(code="RVT-101", message="ok", remediation="r")\n'
        )
        (src_dir / "bad.py").write_text("def broken(\n")
        entries = extract_error_catalog([src_dir])
        assert len(entries) == 1
        assert entries[0].metadata["code"] == "RVT-101"

    def test_empty_source_roots(self) -> None:
        entries = extract_error_catalog([])
        assert entries == []

    def test_nonexistent_dir(self, tmp_path: Path) -> None:
        entries = extract_error_catalog([tmp_path / "nonexistent"])
        assert entries == []

    def test_fstring_message(self, src_dir: Path) -> None:
        (src_dir / "g.py").write_text(
            textwrap.dedent("""\
                from rivet_core.errors import RivetError
                name = "x"
                e = RivetError(code="RVT-302", message=f"Bad {name}", remediation="fix")
            """)
        )
        entries = extract_error_catalog([src_dir])
        assert len(entries) == 1
        assert entries[0].metadata["message"] == "<f-string>"

    def test_sorted_output(self, src_dir: Path) -> None:
        (src_dir / "h.py").write_text(
            textwrap.dedent("""\
                from rivet_core.errors import RivetError
                a = RivetError(code="RVT-801", message="a", remediation="r")
                b = RivetError(code="RVT-101", message="b", remediation="r")
                c = RivetError(code="RVT-401", message="c", remediation="r")
            """)
        )
        entries = extract_error_catalog([src_dir])
        codes = [e.name for e in entries]
        assert codes == sorted(codes)

    def test_tags_and_kind(self, src_dir: Path) -> None:
        (src_dir / "i.py").write_text(
            'from rivet_core.errors import RivetError\ne = RivetError(code="RVT-601", message="m", remediation="r")\n'
        )
        entries = extract_error_catalog([src_dir])
        assert entries[0].tags == ["error"]
        assert entries[0].kind == "error_code"


# ---------------------------------------------------------------------------
# Property 6: Error extractor produces correctly grouped entries for all error codes
# Validates: Requirements 8.1, 8.2
# ---------------------------------------------------------------------------

import textwrap as _textwrap

from hypothesis import given, settings
from hypothesis import strategies as st

from rivet_cli.docs.extractors.error_extractor import CODE_RANGE_GROUPS

_VALID_CODE_RANGES = st.sampled_from(list(CODE_RANGE_GROUPS.keys()))


@st.composite
def _error_files(draw) -> list[tuple[str, str]]:
    """Generate (filename, source) pairs with unique RVT-Nxx error codes."""
    ranges = draw(st.lists(_VALID_CODE_RANGES, min_size=1, max_size=8, unique=True))
    files = []
    for i, range_digit in enumerate(ranges):
        suffix = draw(st.integers(min_value=0, max_value=99))
        code = f"RVT-{range_digit}{suffix:02d}"
        source = _textwrap.dedent(f"""\
            from rivet_core.errors import RivetError
            e = RivetError(code="{code}", message="msg", remediation="fix")
        """)
        files.append((f"err_{i}.py", source, code, range_digit))
    return files


@given(error_files=_error_files())
@settings(max_examples=100)
def test_property6_error_extractor_grouping(error_files) -> None:
    """Property 6: Every DocEntry produced by extract_error_catalog has the correct
    group derived from its error code range (Req 8.1, 8.2)."""
    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        src = Path(tmp) / "src"
        src.mkdir()

        expected: dict[str, str] = {}
        for filename, source, code, range_digit in error_files:
            (src / filename).write_text(source)
            expected[code] = CODE_RANGE_GROUPS[range_digit]

        entries = extract_error_catalog([src])

        # All generated codes must appear in the output
        produced_codes = {e.name for e in entries}
        for code in expected:
            assert code in produced_codes, f"Missing entry for {code}"

        # Each entry must have the correct group
        for entry in entries:
            if entry.name in expected:
                assert entry.metadata["group"] == expected[entry.name], (
                    f"Wrong group for {entry.name}: "
                    f"expected {expected[entry.name]!r}, got {entry.metadata['group']!r}"
                )

        # All entries must have kind="error_code" and tags=["error"]
        for entry in entries:
            assert entry.kind == "error_code"
            assert "error" in entry.tags

        # Output must be sorted by code
        codes = [e.name for e in entries]
        assert codes == sorted(codes)
