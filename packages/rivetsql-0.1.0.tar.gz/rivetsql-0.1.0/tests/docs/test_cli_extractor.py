"""Tests for CLI extractor."""

from __future__ import annotations

import argparse

from rivet_cli.docs.extractors.cli_extractor import (
    _extract_params,
    _walk_parser,
    extract_cli_reference,
)
from rivet_cli.docs.models import DocEntry


class TestExtractParams:
    """Unit tests for _extract_params."""

    def test_positional_arg(self) -> None:
        p = argparse.ArgumentParser()
        p.add_argument("name", help="The name")
        params = _extract_params(p)
        assert len(params) == 1
        assert params[0].name == "name"
        assert params[0].description == "The name"

    def test_optional_flag(self) -> None:
        p = argparse.ArgumentParser()
        p.add_argument("--verbose", "-v", action="store_true", help="Be verbose")
        params = _extract_params(p)
        assert len(params) == 1
        assert params[0].name == "--verbose"
        assert params[0].type_hint == "bool"

    def test_typed_arg_with_default(self) -> None:
        p = argparse.ArgumentParser()
        p.add_argument("--port", type=int, default=8000, help="Port number")
        params = _extract_params(p)
        assert len(params) == 1
        assert params[0].type_hint == "int"
        assert params[0].default == "8000"

    def test_choices(self) -> None:
        p = argparse.ArgumentParser()
        p.add_argument("--format", choices=["json", "text"], help="Output format")
        params = _extract_params(p)
        assert "choices: json, text" in (params[0].description or "")

    def test_env_override_annotation(self) -> None:
        p = argparse.ArgumentParser()
        p.add_argument("--profile", help="Profile name")
        params = _extract_params(p)
        assert "[env: RIVET_PROFILE]" in (params[0].description or "")


class TestWalkParser:
    """Unit tests for _walk_parser."""

    def test_simple_command(self) -> None:
        root = argparse.ArgumentParser(prog="rivet")
        subs = root.add_subparsers()
        subs.add_parser("build", help="Build things")
        entries: list[DocEntry] = []
        _walk_parser(root, parent_ref=None, entries=entries)
        refs = {e.ref_id for e in entries}
        assert "cli" in refs
        assert "cli.build" in refs

    def test_nested_subcommands(self) -> None:
        root = argparse.ArgumentParser(prog="rivet")
        subs = root.add_subparsers()
        cat = subs.add_parser("catalog")
        cat_subs = cat.add_subparsers()
        cat_subs.add_parser("list", help="List catalogs")
        entries: list[DocEntry] = []
        _walk_parser(root, parent_ref=None, entries=entries)
        refs = {e.ref_id for e in entries}
        assert "cli.catalog" in refs
        assert "cli.catalog.list" in refs
        # Check parent-child
        cat_entry = next(e for e in entries if e.ref_id == "cli.catalog")
        assert "cli.catalog.list" in cat_entry.children
        list_entry = next(e for e in entries if e.ref_id == "cli.catalog.list")
        assert list_entry.parent == "cli.catalog"

    def test_all_entries_are_cli_command_kind(self) -> None:
        root = argparse.ArgumentParser(prog="rivet")
        subs = root.add_subparsers()
        subs.add_parser("run")
        entries: list[DocEntry] = []
        _walk_parser(root, parent_ref=None, entries=entries)
        assert all(e.kind == "cli_command" for e in entries)
        assert all("cli" in e.tags for e in entries)


class TestExtractCliReference:
    """Integration test using the real rivet parser."""

    def test_produces_entries(self) -> None:
        entries = extract_cli_reference()
        assert len(entries) > 0

    def test_root_entry_exists(self) -> None:
        entries = extract_cli_reference()
        refs = {e.ref_id for e in entries}
        assert "cli" in refs

    def test_known_commands_present(self) -> None:
        entries = extract_cli_reference()
        refs = {e.ref_id for e in entries}
        for cmd in ["cli.compile", "cli.run", "cli.test", "cli.init", "cli.catalog", "cli.doctor"]:
            assert cmd in refs, f"Missing {cmd}"

    def test_catalog_subcommands(self) -> None:
        entries = extract_cli_reference()
        refs = {e.ref_id for e in entries}
        for sub in ["cli.catalog.list", "cli.catalog.describe", "cli.catalog.search", "cli.catalog.generate", "cli.catalog.create"]:
            assert sub in refs, f"Missing {sub}"

    def test_parent_child_relationships(self) -> None:
        entries = extract_cli_reference()
        by_ref = {e.ref_id: e for e in entries}
        cat = by_ref["cli.catalog"]
        assert "cli.catalog.list" in cat.children
        assert by_ref["cli.catalog.list"].parent == "cli.catalog"

    def test_global_options_entry(self) -> None:
        entries = extract_cli_reference()
        by_ref = {e.ref_id: e for e in entries}
        assert "cli.global_options" in by_ref
        go = by_ref["cli.global_options"]
        param_names = {p.name for p in go.params}
        assert "RIVET_PROFILE" in param_names
        assert "RIVET_PROJECT" in param_names
        assert "RIVET_NO_COLOR" in param_names

    def test_command_params_extracted(self) -> None:
        entries = extract_cli_reference()
        by_ref = {e.ref_id: e for e in entries}
        compile_entry = by_ref["cli.compile"]
        param_names = {p.name for p in compile_entry.params}
        assert "sink_name" in param_names or "--format" in param_names

    def test_all_entries_tagged_cli(self) -> None:
        entries = extract_cli_reference()
        assert all("cli" in e.tags for e in entries)

    def test_unique_ref_ids(self) -> None:
        entries = extract_cli_reference()
        refs = [e.ref_id for e in entries]
        assert len(refs) == len(set(refs)), "Duplicate ref_ids found"
