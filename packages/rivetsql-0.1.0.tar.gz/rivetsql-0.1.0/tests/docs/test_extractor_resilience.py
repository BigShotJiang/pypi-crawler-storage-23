"""Property test for extractor resilience to syntax errors.

Property 8: Extractor resilience to syntax errors.
Validates: Requirement 10.4 — IF a source file contains a syntax error,
THEN the Doc_Extractor SHALL log the error with file path and line number
and continue processing remaining files.
"""

from __future__ import annotations

import tempfile
import textwrap
from pathlib import Path

from hypothesis import given, settings
from hypothesis import strategies as st

from rivet_cli.docs.extractors.api_extractor import extract_package
from rivet_cli.docs.extractors.error_extractor import extract_error_catalog

# ── Strategies ────────────────────────────────────────────────────────────────

_VALID_FUNCTION_NAMES = st.from_regex(r"[a-z][a-z0-9_]{1,10}", fullmatch=True)
_VALID_ERROR_CODES = st.from_regex(r"RVT-[1-8][0-9]{2}", fullmatch=True)


@st.composite
def valid_python_files(draw) -> list[tuple[str, str]]:
    """Generate a list of (filename, source) pairs with valid Python."""
    n = draw(st.integers(min_value=1, max_value=5))
    files = []
    for i in range(n):
        name = draw(_VALID_FUNCTION_NAMES)
        files.append((
            f"valid_{i}.py",
            f'def {name}() -> None:\n    """Docstring."""\n    pass\n',
        ))
    return files


@st.composite
def valid_error_files(draw) -> list[tuple[str, str]]:
    """Generate a list of (filename, source) pairs with valid RivetError calls."""
    n = draw(st.integers(min_value=1, max_value=5))
    files = []
    for i in range(n):
        code = draw(_VALID_ERROR_CODES)
        files.append((
            f"valid_err_{i}.py",
            textwrap.dedent(f"""\
                from rivet_core.errors import RivetError
                e = RivetError(code="{code}", message="msg", remediation="fix")
            """),
        ))
    return files


_SYNTAX_ERRORS = st.sampled_from([
    "def broken(\n",
    "class Bad\n",
    "x = (\n",
    "import\n",
    "def f(:\n",
])


# ── Property tests ────────────────────────────────────────────────────────────


@given(valid_files=valid_python_files(), bad_source=_SYNTAX_ERRORS)
@settings(max_examples=100)
def test_api_extractor_continues_after_syntax_error(
    valid_files: list[tuple[str, str]], bad_source: str
) -> None:
    """extract_package skips files with syntax errors and processes valid ones."""
    with tempfile.TemporaryDirectory() as tmp:
        pkg = Path(tmp) / "mypkg"
        pkg.mkdir()
        (pkg / "__init__.py").write_text("")

        for filename, source in valid_files:
            (pkg / filename).write_text(source)

        (pkg / "syntax_error.py").write_text(bad_source)

        entries = extract_package(pkg)
        # Must return entries from valid files — not crash
        assert len(entries) >= len(valid_files)
        assert all(e.source_file is not None for e in entries)


@given(valid_files=valid_error_files(), bad_source=_SYNTAX_ERRORS)
@settings(max_examples=100)
def test_error_extractor_continues_after_syntax_error(
    valid_files: list[tuple[str, str]], bad_source: str
) -> None:
    """extract_error_catalog skips files with syntax errors and processes valid ones."""
    with tempfile.TemporaryDirectory() as tmp:
        src = Path(tmp) / "src"
        src.mkdir()

        for filename, source in valid_files:
            (src / filename).write_text(source)

        (src / "syntax_error.py").write_text(bad_source)

        entries = extract_error_catalog([src])
        # Must return entries from valid files — not crash; deduplicated by code
        assert len(entries) >= 1
        for e in entries:
            assert e.source_file is not None
            assert "syntax_error.py" not in e.source_file


@given(bad_sources=st.lists(_SYNTAX_ERRORS, min_size=1, max_size=10))
@settings(max_examples=100)
def test_api_extractor_all_syntax_errors_returns_empty(
    bad_sources: list[str],
) -> None:
    """extract_package returns empty list when all files have syntax errors."""
    with tempfile.TemporaryDirectory() as tmp:
        pkg = Path(tmp) / "mypkg"
        pkg.mkdir()
        (pkg / "__init__.py").write_text("")

        for i, source in enumerate(bad_sources):
            (pkg / f"bad_{i}.py").write_text(source)

        entries = extract_package(pkg)
        assert entries == []


@given(bad_sources=st.lists(_SYNTAX_ERRORS, min_size=1, max_size=10))
@settings(max_examples=100)
def test_error_extractor_all_syntax_errors_returns_empty(
    bad_sources: list[str],
) -> None:
    """extract_error_catalog returns empty list when all files have syntax errors."""
    with tempfile.TemporaryDirectory() as tmp:
        src = Path(tmp) / "src"
        src.mkdir()

        for i, source in enumerate(bad_sources):
            (src / f"bad_{i}.py").write_text(source)

        entries = extract_error_catalog([src])
        assert entries == []
