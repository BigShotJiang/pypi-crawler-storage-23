"""Shared fixtures for auto-documentation tests."""
