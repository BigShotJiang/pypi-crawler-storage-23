"""Tests for the API extractor."""

from __future__ import annotations

import textwrap
from pathlib import Path

import pytest

from rivet_cli.docs.extractors.api_extractor import extract_module, extract_package


@pytest.fixture()
def tmp_module(tmp_path: Path):
    """Helper to write a Python module and return its path."""
    def _write(source: str, name: str = "example.py") -> Path:
        p = tmp_path / name
        p.write_text(textwrap.dedent(source))
        return p
    return _write


class TestExtractModule:
    """Tests for extract_module."""

    def test_extracts_public_function(self, tmp_module):
        p = tmp_module('''
            def greet(name: str, greeting: str = "hello") -> str:
                """Say hello.

                Args:
                    name (str): The person's name.
                    greeting (str): The greeting word.

                Returns:
                    A greeting string.
                """
                return f"{greeting} {name}"
        ''')
        entries = extract_module(p, "mypkg")
        assert len(entries) == 1
        e = entries[0]
        assert e.ref_id == "mypkg.example.greet"
        assert e.kind == "function"
        assert e.returns == "str"
        assert len(e.params) == 2
        assert e.params[0].name == "name"
        assert e.params[0].type_hint == "str"
        assert e.params[1].default == "'hello'"
        assert e.tags == ["api"]

    def test_extracts_class_and_methods(self, tmp_module):
        p = tmp_module('''
            class MyClass:
                """A sample class."""

                def __init__(self, x: int) -> None:
                    """Init.

                    Args:
                        x (int): A number.
                    """
                    self.x = x

                def compute(self) -> int:
                    """Compute something.

                    Returns:
                        The computed value.
                    """
                    return self.x * 2

                def _private(self):
                    """Private method."""
                    pass
        ''')
        entries = extract_module(p, "mypkg")
        names = [e.name for e in entries]
        assert "MyClass" in names
        assert "__init__" in names
        assert "compute" in names
        assert "_private" not in names

        cls = next(e for e in entries if e.kind == "class")
        assert cls.ref_id == "mypkg.example.MyClass"
        assert len(cls.params) == 1  # from __init__
        assert cls.params[0].name == "x"

    def test_all_filtering(self, tmp_module):
        p = tmp_module('''
            __all__ = ["exported_func"]

            def exported_func():
                """Exported."""
                pass

            def not_exported():
                """Not exported."""
                pass

            class NotExported:
                """Not exported class."""
                pass
        ''')
        entries = extract_module(p, "mypkg")
        assert len(entries) == 1
        assert entries[0].name == "exported_func"

    def test_missing_docstring_warning(self, tmp_module):
        p = tmp_module('''
            def no_docs(x: int) -> int:
                return x
        ''')
        with pytest.warns(UserWarning, match="Missing docstring"):
            entries = extract_module(p, "mypkg")
        assert len(entries) == 1
        assert "No documentation available" in entries[0].docstring

    def test_syntax_error_resilience(self, tmp_module):
        p = tmp_module('''
            def broken(
        ''')
        entries = extract_module(p, "mypkg")
        assert entries == []

    def test_skips_private_symbols(self, tmp_module):
        p = tmp_module('''
            def _private():
                """Private."""
                pass

            def public():
                """Public."""
                pass
        ''')
        entries = extract_module(p, "mypkg")
        assert len(entries) == 1
        assert entries[0].name == "public"

    def test_abc_class_metadata(self, tmp_module):
        p = tmp_module('''
            from abc import ABC, abstractmethod

            class MyABC(ABC):
                """An abstract class."""

                @abstractmethod
                def do_thing(self) -> None:
                    """Do the thing."""
                    ...
        ''')
        entries = extract_module(p, "mypkg")
        cls = next(e for e in entries if e.kind == "class")
        assert cls.metadata["is_abc"] is True
        assert "ABC" in cls.metadata["bases"]

    def test_google_docstring_raises(self, tmp_module):
        p = tmp_module('''
            def risky(x: int) -> int:
                """Do something risky.

                Args:
                    x (int): Input value.

                Returns:
                    The result.

                Raises:
                    ValueError: If x is negative.
                    TypeError: If x is not int.
                """
                if x < 0:
                    raise ValueError
                return x
        ''')
        entries = extract_module(p, "mypkg")
        assert entries[0].raises == ["ValueError", "TypeError"]

    def test_init_module(self, tmp_path):
        pkg = tmp_path / "mypkg"
        pkg.mkdir()
        init = pkg / "__init__.py"
        init.write_text(textwrap.dedent('''
            """Package init."""

            def init_func() -> None:
                """Init function."""
                pass
        '''))
        entries = extract_module(init, "mypkg")
        assert entries[0].ref_id == "mypkg.init_func"
        assert entries[0].module == "mypkg"

    def test_kwonly_and_varargs(self, tmp_module):
        p = tmp_module('''
            def complex_sig(a: int, *args: str, key: bool = False, **kwargs: int) -> None:
                """Complex signature.

                Args:
                    a (int): First arg.
                    *args (str): Var args.
                    key (bool): A keyword arg.
                    **kwargs (int): Extra kwargs.
                """
                pass
        ''')
        entries = extract_module(p, "mypkg")
        e = entries[0]
        param_names = [p.name for p in e.params]
        assert param_names == ["a", "*args", "key", "**kwargs"]
        assert e.params[2].default == "False"


class TestExtractPackage:
    """Tests for extract_package."""

    def test_walks_package(self, tmp_path):
        pkg = tmp_path / "mypkg"
        pkg.mkdir()
        (pkg / "__init__.py").write_text('"""Package."""\n')
        (pkg / "mod_a.py").write_text(textwrap.dedent('''
            def func_a() -> None:
                """Function A."""
                pass
        '''))
        sub = pkg / "sub"
        sub.mkdir()
        (sub / "__init__.py").write_text("")
        (sub / "mod_b.py").write_text(textwrap.dedent('''
            def func_b() -> None:
                """Function B."""
                pass
        '''))

        entries = extract_package(pkg)
        names = {e.name for e in entries}
        assert "func_a" in names
        assert "func_b" in names

    def test_skips_pycache(self, tmp_path):
        pkg = tmp_path / "mypkg"
        pkg.mkdir()
        (pkg / "__init__.py").write_text("")
        cache = pkg / "__pycache__"
        cache.mkdir()
        (cache / "cached.py").write_text("def cached(): pass\n")

        entries = extract_package(pkg)
        assert all("cached" not in e.name for e in entries)

    def test_missing_package(self, tmp_path):
        entries = extract_package(tmp_path / "nonexistent")
        assert entries == []

    def test_syntax_error_in_one_file(self, tmp_path):
        pkg = tmp_path / "mypkg"
        pkg.mkdir()
        (pkg / "__init__.py").write_text("")
        (pkg / "good.py").write_text(textwrap.dedent('''
            def good_func() -> None:
                """Good function."""
                pass
        '''))
        (pkg / "bad.py").write_text("def broken(\n")

        entries = extract_package(pkg)
        names = {e.name for e in entries}
        assert "good_func" in names
