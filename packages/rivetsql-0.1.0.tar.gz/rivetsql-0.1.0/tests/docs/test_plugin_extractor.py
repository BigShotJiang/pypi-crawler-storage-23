"""Tests for the plugin extractor."""

from __future__ import annotations

from rivet_cli.docs.extractors.plugin_extractor import extract_plugin_guide


def test_extract_plugin_guide_produces_entries_for_all_abcs():
    """All five plugin ABCs should have a plugin_abc entry."""
    entries = extract_plugin_guide()
    abc_entries = [e for e in entries if e.kind == "plugin_abc"]
    abc_names = {e.name for e in abc_entries}
    assert abc_names == {
        "CatalogPlugin",
        "ComputeEnginePlugin",
        "ComputeEngineAdapter",
        "SourcePlugin",
        "SinkPlugin",
    }


def test_abstract_methods_documented():
    """Each ABC entry should list its abstract methods as children."""
    entries = extract_plugin_guide()
    by_id = {e.ref_id: e for e in entries}

    catalog = by_id["plugin.CatalogPlugin"]
    assert len(catalog.children) > 0
    for child_ref in catalog.children:
        assert child_ref in by_id
        child = by_id[child_ref]
        assert child.kind == "method"
        assert child.parent == "plugin.CatalogPlugin"


def test_required_attributes_as_params():
    """CatalogPlugin should document required attributes (type, required_options, etc.)."""
    entries = extract_plugin_guide()
    catalog = next(e for e in entries if e.ref_id == "plugin.CatalogPlugin")
    param_names = {p.name for p in catalog.params}
    assert "type" in param_names
    assert "required_options" in param_names


def test_builtin_implementations_discovered():
    """Built-in implementations should appear as class entries with parent refs."""
    entries = extract_plugin_guide()
    builtins = [e for e in entries if "builtin" in e.tags]
    assert len(builtins) > 0
    builtin_names = {e.name for e in builtins}
    assert "ArrowCatalogPlugin" in builtin_names
    assert "FilesystemCatalogPlugin" in builtin_names
    for b in builtins:
        assert b.parent is not None
        assert b.parent.startswith("plugin.")


def test_entry_point_groups_documented():
    """There should be a guide entry documenting entry point groups."""
    entries = extract_plugin_guide()
    ep = next(e for e in entries if e.ref_id == "plugin.entry_points")
    assert ep.kind == "guide"
    assert "rivet.catalogs" in ep.docstring
    assert "rivet.compute_engines" in ep.docstring
    assert "pyproject.toml" in ep.docstring


def test_import_boundary_documented():
    """There should be a guide entry documenting the import boundary rule."""
    entries = extract_plugin_guide()
    ib = next(e for e in entries if e.ref_id == "plugin.import_boundary")
    assert ib.kind == "guide"
    assert "rivet_core" in ib.docstring


def test_method_entries_have_signatures():
    """Abstract method entries should have signatures and params."""
    entries = extract_plugin_guide()
    methods = [e for e in entries if e.kind == "method"]
    assert len(methods) > 0
    for m in methods:
        assert m.signature is not None
        assert m.parent is not None
