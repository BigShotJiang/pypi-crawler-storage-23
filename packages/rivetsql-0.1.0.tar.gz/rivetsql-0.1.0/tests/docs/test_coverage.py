"""Tests for the coverage checker."""

from __future__ import annotations

from rivet_cli.docs.models import DocEntry, DocParam
from rivet_cli.docs.validators.coverage import check_coverage


def _entry(
    name: str = "my_func",
    kind: str = "function",
    module: str = "rivet_core.models",
    docstring: str | None = "A docstring.",
    params: list[DocParam] | None = None,
    returns: str | None = None,
    raises: list[str] | None = None,
    source_file: str | None = "src/rivet_core/models.py",
) -> DocEntry:
    return DocEntry(
        ref_id=f"{module}.{name}",
        kind=kind,
        name=name,
        module=module,
        docstring=docstring,
        params=params or [],
        returns=returns,
        raises=raises or [],
        source_file=source_file,
    )


class TestCheckCoverage:
    def test_all_documented_passes(self):
        entries = [_entry(name="a"), _entry(name="b")]
        report = check_coverage(entries, threshold=80.0)
        assert report.passed is True
        assert len(report.results) == 1
        assert report.results[0].coverage_pct == 100.0

    def test_none_documented_fails(self):
        entries = [_entry(name="a", docstring=None), _entry(name="b", docstring=None)]
        report = check_coverage(entries, threshold=80.0)
        assert report.passed is False
        assert report.results[0].coverage_pct == 0.0

    def test_partial_coverage_below_threshold(self):
        entries = [
            _entry(name="a", docstring="doc"),
            _entry(name="b", docstring=None),
            _entry(name="c", docstring=None),
            _entry(name="d", docstring=None),
        ]
        report = check_coverage(entries, threshold=50.0)
        assert report.passed is False
        assert report.results[0].coverage_pct == 25.0

    def test_partial_coverage_meets_threshold(self):
        entries = [
            _entry(name="a", docstring="doc"),
            _entry(name="b", docstring="doc"),
            _entry(name="c", docstring="doc"),
            _entry(name="d", docstring=None),
        ]
        report = check_coverage(entries, threshold=75.0)
        assert report.passed is True

    def test_excludes_private_symbols(self):
        entries = [
            _entry(name="_private", docstring=None),
            _entry(name="public", docstring="doc"),
        ]
        report = check_coverage(entries, threshold=100.0)
        assert report.passed is True
        assert report.results[0].total_symbols == 1

    def test_excludes_test_files(self):
        entries = [
            _entry(name="func", docstring=None, source_file="tests/test_foo.py"),
            _entry(name="other", docstring="doc", source_file="src/rivet_core/x.py"),
        ]
        report = check_coverage(entries, threshold=100.0)
        assert report.passed is True
        assert report.results[0].total_symbols == 1

    def test_excludes_pycache(self):
        entries = [
            _entry(name="func", docstring=None, source_file="src/__pycache__/foo.py"),
            _entry(name="other", docstring="doc"),
        ]
        report = check_coverage(entries, threshold=100.0)
        assert report.passed is True

    def test_excludes_non_symbol_kinds(self):
        entries = [
            _entry(name="cmd", kind="cli_command", docstring=None),
            _entry(name="key", kind="config_key", docstring=None),
            _entry(name="func", kind="function", docstring="doc"),
        ]
        report = check_coverage(entries, threshold=100.0)
        assert report.passed is True
        assert report.results[0].total_symbols == 1

    def test_groups_by_package(self):
        entries = [
            _entry(name="a", module="rivet_core.models", docstring="doc"),
            _entry(name="b", module="rivet_config.models", docstring=None),
        ]
        report = check_coverage(entries, threshold=100.0)
        assert len(report.results) == 2
        pkgs = {r.package for r in report.results}
        assert pkgs == {"rivet_core", "rivet_config"}
        assert report.passed is False  # rivet_config has 0%

    def test_empty_entries_passes(self):
        report = check_coverage([], threshold=80.0)
        assert report.passed is True
        assert report.results == []

    def test_incomplete_docstring_missing_args(self):
        entries = [
            _entry(
                name="func",
                docstring="Does something.",
                params=[DocParam(name="x", type_hint="int", description=None)],
            ),
        ]
        report = check_coverage(entries, threshold=0.0)
        assert len(report.results[0].incomplete_symbols) == 1
        assert "func" in report.results[0].incomplete_symbols[0]

    def test_incomplete_docstring_missing_returns(self):
        entries = [
            _entry(
                name="func",
                docstring="Does something.",
                returns="str",
            ),
        ]
        report = check_coverage(entries, threshold=0.0)
        assert len(report.results[0].incomplete_symbols) == 1

    def test_incomplete_docstring_missing_raises(self):
        entries = [
            _entry(
                name="func",
                docstring="Does something.",
                raises=["ValueError"],
            ),
        ]
        report = check_coverage(entries, threshold=0.0)
        assert len(report.results[0].incomplete_symbols) == 1

    def test_complete_docstring_not_flagged(self):
        entries = [
            _entry(
                name="func",
                docstring="Does something.\n\nArgs:\n    x: value\n\nReturns:\n    result\n\nRaises:\n    ValueError: bad",
                params=[DocParam(name="x", type_hint="int", description="value")],
                returns="str",
                raises=["ValueError"],
            ),
        ]
        report = check_coverage(entries, threshold=0.0)
        assert report.results[0].incomplete_symbols == []

    def test_threshold_stored_in_report(self):
        report = check_coverage([], threshold=42.5)
        assert report.threshold == 42.5

    def test_zero_total_symbols_package_is_100_pct(self):
        # If all entries in a package are excluded, that package won't appear
        entries = [_entry(name="_private", docstring=None)]
        report = check_coverage(entries, threshold=100.0)
        assert report.results == []
        assert report.passed is True

    def test_incomplete_includes_file_path(self):
        entries = [
            _entry(
                name="func",
                docstring="Does something.",
                params=[DocParam(name="x", type_hint="int", description=None)],
                source_file="src/rivet_core/models.py",
            ),
        ]
        report = check_coverage(entries, threshold=0.0)
        assert "src/rivet_core/models.py::func" in report.results[0].incomplete_symbols
