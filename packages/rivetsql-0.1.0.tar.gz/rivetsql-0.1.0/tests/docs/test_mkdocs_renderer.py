"""Property test for MkDocsRenderer output routing.

Property 3: Renderer routes DocEntries to correct output directories by kind.
Validates: Requirements 6.2, 6.5, 7.4
"""

from __future__ import annotations

import sys
import tempfile
from pathlib import Path

from hypothesis import given, settings
from hypothesis import strategies as st

sys.path.insert(0, str(Path(__file__).parents[3] / "docs" / "scripts"))

from mkdocs_renderer import MkDocsRenderer, _sanitize  # noqa: E402

from .strategies import doc_entries  # noqa: E402


@given(entries=st.lists(doc_entries(), min_size=1, max_size=20))
@settings(max_examples=100)
def test_api_reference_routes_to_api_dir(entries) -> None:
    """API entries are written under output_dir/api/."""
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp)
        MkDocsRenderer(out).render_api_reference(entries)
        api_dir = out / "api"
        assert api_dir.exists()
        assert (api_dir / "index.md").exists()
        for e in entries:
            assert (api_dir / f"{_sanitize(e.module)}.md").exists()


@given(entries=st.lists(doc_entries(), min_size=1, max_size=20))
@settings(max_examples=100)
def test_cli_reference_routes_to_cli_dir(entries) -> None:
    """CLI entries are written under output_dir/cli/."""
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp)
        MkDocsRenderer(out).render_cli_reference(entries)
        cli_dir = out / "cli"
        assert cli_dir.exists()
        assert (cli_dir / "index.md").exists()
        for e in entries:
            assert (cli_dir / f"{_sanitize(e.name)}.md").exists()


@given(entries=st.lists(doc_entries(), min_size=1, max_size=20))
@settings(max_examples=100)
def test_config_reference_routes_to_config_dir(entries) -> None:
    """Config entries are written under output_dir/config/."""
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp)
        MkDocsRenderer(out).render_config_reference(entries)
        config_dir = out / "config"
        assert config_dir.exists()
        assert (config_dir / "index.md").exists()
        for e in entries:
            assert (config_dir / f"{_sanitize(e.module)}.md").exists()


@given(entries=st.lists(doc_entries(), min_size=1, max_size=20))
@settings(max_examples=100)
def test_error_reference_routes_to_errors_md(entries) -> None:
    """Error entries are written to output_dir/errors.md (single file)."""
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp)
        MkDocsRenderer(out).render_error_reference(entries)
        assert (out / "errors.md").exists()


@given(entries=st.lists(doc_entries(), min_size=1, max_size=20))
@settings(max_examples=100)
def test_plugin_reference_routes_to_plugins_dir(entries) -> None:
    """Plugin entries are written under output_dir/plugins/."""
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp)
        MkDocsRenderer(out).render_plugin_reference(entries)
        plugins_dir = out / "plugins"
        assert plugins_dir.exists()
        assert (plugins_dir / "index.md").exists()
        for e in entries:
            assert (plugins_dir / f"{_sanitize(e.name)}.md").exists()
