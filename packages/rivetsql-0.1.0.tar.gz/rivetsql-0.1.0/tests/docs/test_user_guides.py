"""Tests for user guide templates."""

from rivet_cli.docs.extractors.user_guides import get_user_guides


class TestUserGuides:
    def test_returns_four_guides(self):
        assert len(get_user_guides()) == 4

    def test_all_kind_guide(self):
        for entry in get_user_guides():
            assert entry.kind == "guide"

    def test_all_have_user_guides_tag(self):
        for entry in get_user_guides():
            assert "user-guides" in entry.tags
            assert "guide" in entry.tags

    def test_ref_ids_are_unique(self):
        ref_ids = [e.ref_id for e in get_user_guides()]
        assert len(ref_ids) == len(set(ref_ids))

    def test_all_have_docstring(self):
        for entry in get_user_guides():
            assert entry.docstring
            assert len(entry.docstring) > 0

    def test_expected_ref_ids(self):
        ref_ids = {e.ref_id for e in get_user_guides()}
        assert ref_ids == {
            "guide.getting-started",
            "guide.declaration-styles",
            "guide.testing-framework",
            "guide.repl",
        }

    def test_getting_started_content(self):
        entries = {e.ref_id: e for e in get_user_guides()}
        doc = entries["guide.getting-started"].docstring
        assert "rivet init" in doc
        assert "rivet.yaml" in doc
        assert "profiles.yaml" in doc
        assert "sources/" in doc
        assert "joints/" in doc
        assert "sinks/" in doc
        assert "rivet run" in doc
        assert "pip install" in doc

    def test_declaration_styles_content(self):
        entries = {e.ref_id: e for e in get_user_guides()}
        doc = entries["guide.declaration-styles"].docstring
        assert "SQL Annotations" in doc
        assert "YAML Declarations" in doc
        assert "Mixed Mode" in doc
        assert "@rivet" in doc

    def test_testing_framework_content(self):
        entries = {e.ref_id: e for e in get_user_guides()}
        doc = entries["guide.testing-framework"].docstring
        assert "rivet test" in doc
        assert "fixture" in doc.lower()
        assert "snapshot" in doc.lower()
        assert "Assertion" in doc
        assert "Audit" in doc

    def test_repl_guide_content(self):
        entries = {e.ref_id: e for e in get_user_guides()}
        doc = entries["guide.repl"].docstring
        assert "rivet repl" in doc
        assert "SELECT" in doc
        assert "SHOW CATALOGS" in doc
        assert "EXPORT" in doc
