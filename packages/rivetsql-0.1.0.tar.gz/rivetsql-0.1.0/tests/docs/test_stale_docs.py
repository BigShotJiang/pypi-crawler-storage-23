"""Tests for the stale documentation reference flagger."""

# Import the module under test
import sys
from pathlib import Path
from unittest.mock import patch

SCRIPTS_DIR = Path(__file__).resolve().parent.parent.parent / "scripts"
sys.path.insert(0, str(SCRIPTS_DIR))
import flag_stale_docs


class TestCollectSourceSymbols:
    def test_finds_classes_and_functions(self, tmp_path):
        pkg = tmp_path / "rivet_core"
        pkg.mkdir()
        (pkg / "__init__.py").write_text("")
        (pkg / "models.py").write_text("class Foo:\n    def bar(self): ...\ndef baz(): ...\n")
        symbols = flag_stale_docs.collect_source_symbols(tmp_path)
        assert "rivet_core" in symbols
        assert "rivet_core.models.Foo" in symbols
        assert "rivet_core.models.Foo.bar" in symbols
        assert "rivet_core.models.baz" in symbols

    def test_handles_nested_packages(self, tmp_path):
        pkg = tmp_path / "rivet_core" / "interactive"
        pkg.mkdir(parents=True)
        (tmp_path / "rivet_core" / "__init__.py").write_text("")
        (pkg / "__init__.py").write_text("")
        (pkg / "session.py").write_text("class Session:\n    pass\n")
        symbols = flag_stale_docs.collect_source_symbols(tmp_path)
        assert "rivet_core.interactive.session.Session" in symbols


class TestCollectDocSymbols:
    def test_extracts_from_filenames(self, tmp_path):
        (tmp_path / "rivet_core.models.Foo.md").write_text("")
        (tmp_path / "rivet_core.models.Foo.bar.md").write_text("")
        result = flag_stale_docs.collect_doc_symbols(tmp_path)
        assert "rivet_core.models.Foo" in result
        assert "rivet_core.models.Foo.bar" in result

    def test_empty_dir(self, tmp_path):
        assert flag_stale_docs.collect_doc_symbols(tmp_path) == []

    def test_nonexistent_dir(self, tmp_path):
        assert flag_stale_docs.collect_doc_symbols(tmp_path / "nope") == []


class TestFlagStaleReferences:
    def test_detects_stale_symbol(self, tmp_path):
        src = tmp_path / "src"
        api = tmp_path / "api"
        src.mkdir()
        api.mkdir()
        pkg = src / "rivet_core"
        pkg.mkdir()
        (pkg / "__init__.py").write_text("")
        (pkg / "models.py").write_text("class Foo: ...\n")
        (api / "rivet_core.models.Foo.md").write_text("")
        (api / "rivet_core.models.Deleted.md").write_text("")
        with patch.object(flag_stale_docs, "SRC_DIR", src), \
             patch.object(flag_stale_docs, "DOCS_API_DIR", api):
            stale = flag_stale_docs.flag_stale_references()
        assert "rivet_core.models.Deleted" in stale
        assert "rivet_core.models.Foo" not in stale

    def test_skips_plugin_prefixed_docs(self, tmp_path):
        src = tmp_path / "src"
        api = tmp_path / "api"
        src.mkdir()
        api.mkdir()
        (api / "plugin.CatalogPlugin.md").write_text("")
        with patch.object(flag_stale_docs, "SRC_DIR", src), \
             patch.object(flag_stale_docs, "DOCS_API_DIR", api):
            stale = flag_stale_docs.flag_stale_references()
        assert stale == []


class TestIntegration:
    """Verify the script runs against the real codebase."""

    def test_script_runs_without_error(self):
        """The script should execute and return a list (possibly with stale refs)."""
        stale = flag_stale_docs.flag_stale_references()
        assert isinstance(stale, list)
        # Known stale: reference_resolver was moved
        for sym in stale:
            assert isinstance(sym, str)
            assert not sym.startswith("plugin.")
