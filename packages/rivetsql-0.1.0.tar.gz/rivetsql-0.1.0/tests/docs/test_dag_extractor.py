"""Tests for the DAG extractor."""

from __future__ import annotations

from dataclasses import dataclass, field
from unittest.mock import patch

from rivet_cli.docs.extractors.dag_extractor import extract_dag_diagram


def test_returns_empty_when_no_project_root():
    """No project root → empty list."""
    assert extract_dag_diagram(None) == []


def test_returns_empty_on_compile_failure(tmp_path):
    """Compilation failure → empty list, no crash."""
    assert extract_dag_diagram(tmp_path) == []


def test_returns_diagram_entry_for_valid_project(tmp_path):
    """A successful compilation produces a single diagram DocEntry."""
    # Build a minimal CompiledAssembly stub
    @dataclass
    class _Joint:
        name: str
        type: str = "sql"
        catalog: str | None = None
        upstream: list[str] = field(default_factory=list)
        optimizations: list = field(default_factory=list)

    @dataclass
    class _FusedGroup:
        id: str
        joints: list[str]
        engine: str

    @dataclass
    class _Assembly:
        success: bool = True
        profile_name: str = "default"
        catalogs: list = field(default_factory=list)
        engines: list = field(default_factory=list)
        adapters: list = field(default_factory=list)
        joints: list = field(default_factory=list)
        fused_groups: list = field(default_factory=list)
        materializations: list = field(default_factory=list)
        execution_order: list = field(default_factory=list)
        errors: list = field(default_factory=list)
        warnings: list = field(default_factory=list)

    assembly = _Assembly(
        joints=[
            _Joint(name="src", type="source"),
            _Joint(name="transform", upstream=["src"]),
        ],
        fused_groups=[_FusedGroup(id="g1", joints=["transform"], engine="duckdb")],
    )

    with patch(
        "rivet_cli.docs.extractors.dag_extractor._compile_project",
        return_value=assembly,
    ):
        entries = extract_dag_diagram(tmp_path)

    assert len(entries) == 1
    entry = entries[0]
    assert entry.kind == "diagram"
    assert entry.ref_id == "diagram.project_dag"
    assert "graph TD" in entry.docstring
    assert "src" in entry.docstring
    assert "transform" in entry.docstring
    assert entry.metadata["format"] == "mermaid"


def test_returns_empty_when_no_joints(tmp_path):
    """Compiled assembly with no joints → empty list."""

    @dataclass
    class _Assembly:
        success: bool = True
        joints: list = field(default_factory=list)
        fused_groups: list = field(default_factory=list)
        materializations: list = field(default_factory=list)

    with patch(
        "rivet_cli.docs.extractors.dag_extractor._compile_project",
        return_value=_Assembly(),
    ):
        assert extract_dag_diagram(tmp_path) == []


def test_returns_empty_when_compile_unsuccessful(tmp_path):
    """Unsuccessful compilation → empty list."""

    @dataclass
    class _Assembly:
        success: bool = False
        joints: list = field(default_factory=list)

    with patch(
        "rivet_cli.docs.extractors.dag_extractor._compile_project",
        return_value=_Assembly(),
    ):
        assert extract_dag_diagram(tmp_path) == []
