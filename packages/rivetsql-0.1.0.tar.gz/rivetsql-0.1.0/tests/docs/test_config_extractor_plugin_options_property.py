"""Property test for config extractor plugin options.

Property 5: Config extractor includes all declared plugin options.
Validates: Requirements 5.3, 7.3 — When a CatalogPlugin declares
required_options, optional_options, or credential_options, the
Doc_Extractor SHALL include those options in the catalog type's
configuration reference.
"""

from __future__ import annotations

from unittest.mock import MagicMock

from hypothesis import given, settings
from hypothesis import strategies as st

from rivet_cli.docs.extractors.config_extractor import _extract_plugin_options

# ── Strategies ────────────────────────────────────────────────────────────────

_OPTION_NAME = st.from_regex(r"[a-z][a-z0-9_]{1,15}", fullmatch=True)
_CATALOG_TYPE = st.from_regex(r"[a-z][a-z0-9_]{1,10}", fullmatch=True)
_ENGINE_TYPE = st.from_regex(r"[a-z][a-z0-9_]{1,10}", fullmatch=True)

_OPTIONAL_VALUE = st.one_of(
    st.integers(min_value=0, max_value=9999),
    st.booleans(),
    st.text(min_size=0, max_size=20),
)


@st.composite
def catalog_plugin_spec(draw) -> tuple[str, list[str], dict[str, object], list[str]]:
    """Generate (catalog_type, required_options, optional_options, credential_options)."""
    cat_type = draw(_CATALOG_TYPE)
    required = draw(st.lists(_OPTION_NAME, min_size=0, max_size=5, unique=True))
    optional_keys = draw(st.lists(_OPTION_NAME, min_size=0, max_size=5, unique=True))
    # Ensure no overlap between required and optional keys
    optional_keys = [k for k in optional_keys if k not in required]
    optional = {k: draw(_OPTIONAL_VALUE) for k in optional_keys}
    cred_keys = draw(st.lists(_OPTION_NAME, min_size=0, max_size=3, unique=True))
    cred_keys = [k for k in cred_keys if k not in required and k not in optional]
    return cat_type, required, optional, cred_keys


@st.composite
def registry_with_catalog_plugins(draw) -> tuple[MagicMock, dict]:
    """Generate a mock registry with one or more catalog plugins."""
    specs = draw(st.lists(catalog_plugin_spec(), min_size=1, max_size=4))

    # Deduplicate by catalog_type
    seen: set[str] = set()
    unique_specs = []
    for spec in specs:
        if spec[0] not in seen:
            seen.add(spec[0])
            unique_specs.append(spec)

    registry = MagicMock()
    catalog_plugins: dict[str, MagicMock] = {}
    for cat_type, required, optional, creds in unique_specs:
        plugin = MagicMock()
        plugin.required_options = required
        plugin.optional_options = optional
        plugin.credential_options = creds
        catalog_plugins[cat_type] = plugin

    registry._catalog_plugins = catalog_plugins
    registry._engine_plugins = {}

    expected = {
        cat_type: {
            "required": required,
            "optional": list(optional.keys()),
            "credential": creds,
        }
        for cat_type, required, optional, creds in unique_specs
    }
    return registry, expected


# ── Property tests ────────────────────────────────────────────────────────────


@given(registry_and_expected=registry_with_catalog_plugins())
@settings(max_examples=100)
def test_all_required_options_included(
    registry_and_expected: tuple[MagicMock, dict],
) -> None:
    """Every required_option declared by a plugin appears in the extractor output."""
    registry, expected = registry_and_expected
    entries = _extract_plugin_options(registry)

    for cat_type, opts in expected.items():
        required_names = {
            e.name
            for e in entries
            if e.metadata.get("required") is True
            and e.metadata.get("catalog_type") == cat_type
        }
        for opt in opts["required"]:
            assert opt in required_names, (
                f"Required option '{opt}' for catalog '{cat_type}' missing from extractor output"
            )


@given(registry_and_expected=registry_with_catalog_plugins())
@settings(max_examples=100)
def test_all_optional_options_included(
    registry_and_expected: tuple[MagicMock, dict],
) -> None:
    """Every optional_option declared by a plugin appears in the extractor output."""
    registry, expected = registry_and_expected
    entries = _extract_plugin_options(registry)

    for cat_type, opts in expected.items():
        optional_names = {
            e.name
            for e in entries
            if e.metadata.get("required") is False
            and e.metadata.get("catalog_type") == cat_type
        }
        for opt in opts["optional"]:
            assert opt in optional_names, (
                f"Optional option '{opt}' for catalog '{cat_type}' missing from extractor output"
            )


@given(registry_and_expected=registry_with_catalog_plugins())
@settings(max_examples=100)
def test_all_credential_options_included(
    registry_and_expected: tuple[MagicMock, dict],
) -> None:
    """Every credential_option declared by a plugin appears in the extractor output."""
    registry, expected = registry_and_expected
    entries = _extract_plugin_options(registry)

    for cat_type, opts in expected.items():
        cred_names = {
            e.name
            for e in entries
            if e.metadata.get("credential") is True
            and e.metadata.get("catalog_type") == cat_type
        }
        for opt in opts["credential"]:
            assert opt in cred_names, (
                f"Credential option '{opt}' for catalog '{cat_type}' missing from extractor output"
            )


@given(registry_and_expected=registry_with_catalog_plugins())
@settings(max_examples=100)
def test_no_extra_options_invented(
    registry_and_expected: tuple[MagicMock, dict],
) -> None:
    """The extractor does not invent options that were not declared by any plugin."""
    registry, expected = registry_and_expected
    entries = _extract_plugin_options(registry)

    for cat_type, opts in expected.items():
        all_declared = set(opts["required"]) | set(opts["optional"]) | set(opts["credential"])
        cat_entries = [
            e for e in entries
            if e.metadata.get("catalog_type") == cat_type
            and e.kind == "config_key"
            and "engine" not in e.tags
        ]
        for e in cat_entries:
            assert e.name in all_declared, (
                f"Extractor invented undeclared option '{e.name}' for catalog '{cat_type}'"
            )


@given(registry_and_expected=registry_with_catalog_plugins())
@settings(max_examples=100)
def test_all_entries_tagged_plugin(
    registry_and_expected: tuple[MagicMock, dict],
) -> None:
    """All plugin option entries are tagged with 'plugin'."""
    registry, _ = registry_and_expected
    entries = _extract_plugin_options(registry)
    for e in entries:
        assert "plugin" in e.tags, f"Entry '{e.ref_id}' missing 'plugin' tag"


@given(registry_and_expected=registry_with_catalog_plugins())
@settings(max_examples=100)
def test_ref_ids_are_unique_per_registry(
    registry_and_expected: tuple[MagicMock, dict],
) -> None:
    """All ref_ids produced for a given registry are unique."""
    registry, _ = registry_and_expected
    entries = _extract_plugin_options(registry)
    ref_ids = [e.ref_id for e in entries]
    assert len(ref_ids) == len(set(ref_ids)), (
        f"Duplicate ref_ids: {[r for r in ref_ids if ref_ids.count(r) > 1]}"
    )
