"""Shared Hypothesis strategies for auto-documentation tests."""

from __future__ import annotations

from hypothesis import strategies as st

from rivet_cli.docs.models import (
    CoverageReport,
    CoverageResult,
    DocEntry,
    DocParam,
    FreshnessReport,
    StaleEntry,
)

KINDS = st.sampled_from([
    "class", "function", "method", "cli_command", "config_key",
    "error_code", "plugin_abc", "guide", "diagram",
])

TAGS = st.sampled_from(["api", "cli", "config", "error", "plugin", "guide"])

REASONS = st.sampled_from(["signature_changed", "new_symbol", "removed_symbol"])


def doc_params() -> st.SearchStrategy[DocParam]:
    return st.builds(
        DocParam,
        name=st.from_regex(r"[a-z][a-z0-9_]{0,15}", fullmatch=True),
        type_hint=st.none() | st.sampled_from(["str", "int", "float", "bool", "list[str]"]),
        default=st.none() | st.sampled_from(["None", "'hello'", "42", "True"]),
        description=st.none() | st.text(min_size=1, max_size=60),
    )


def doc_entries() -> st.SearchStrategy[DocEntry]:
    return st.builds(
        DocEntry,
        ref_id=st.from_regex(r"[a-z][a-z0-9_.]{0,30}", fullmatch=True),
        kind=KINDS,
        name=st.from_regex(r"[A-Za-z][A-Za-z0-9_]{0,20}", fullmatch=True),
        module=st.from_regex(r"[a-z][a-z0-9_.]{0,20}", fullmatch=True),
        signature=st.none() | st.text(min_size=1, max_size=80),
        docstring=st.none() | st.text(min_size=1, max_size=200),
        params=st.lists(doc_params(), max_size=5),
        returns=st.none() | st.sampled_from(["str", "int", "None", "list[str]"]),
        raises=st.lists(st.sampled_from(["ValueError", "TypeError", "RuntimeError"]), max_size=3),
        parent=st.none(),
        children=st.just([]),
        tags=st.lists(TAGS, max_size=3),
        source_file=st.none() | st.just("src/example.py"),
        source_line=st.none() | st.integers(min_value=1, max_value=5000),
        metadata=st.just({}),
    )


def coverage_results() -> st.SearchStrategy[CoverageResult]:
    return st.builds(
        CoverageResult,
        package=st.sampled_from(["rivet_core", "rivet_config", "rivet_bridge", "rivet_cli"]),
        total_symbols=st.integers(min_value=0, max_value=500),
        documented_symbols=st.integers(min_value=0, max_value=500),
        incomplete_symbols=st.lists(st.text(min_size=1, max_size=30), max_size=10),
    ).filter(lambda cr: cr.documented_symbols <= cr.total_symbols)


def coverage_reports() -> st.SearchStrategy[CoverageReport]:
    return st.builds(
        CoverageReport,
        results=st.lists(coverage_results(), min_size=1, max_size=4),
        threshold=st.floats(min_value=0.0, max_value=100.0, allow_nan=False),
        passed=st.booleans(),
    )


def stale_entries() -> st.SearchStrategy[StaleEntry]:
    return st.builds(
        StaleEntry,
        ref_id=st.from_regex(r"[a-z][a-z0-9_.]{0,30}", fullmatch=True),
        source_file=st.just("src/example.py"),
        doc_file=st.just("docs/example.md"),
        reason=REASONS,
    )


def freshness_reports() -> st.SearchStrategy[FreshnessReport]:
    return st.builds(
        FreshnessReport,
        stale_entries=st.lists(stale_entries(), max_size=5),
        passed=st.booleans(),
    )
