"""End-to-end integration tests for the auto-documentation system.

Tests the full pipeline: extractors → renderers → validators, verifying
that generated output contains expected sections and structure.
"""

from __future__ import annotations

import json
import textwrap
from pathlib import Path

from rivet_cli.docs.extractors.api_extractor import extract_package
from rivet_cli.docs.extractors.cli_extractor import extract_cli_reference
from rivet_cli.docs.extractors.config_extractor import extract_config_reference
from rivet_cli.docs.extractors.error_extractor import extract_error_catalog
from rivet_cli.docs.models import DocEntry, DocParam
from rivet_cli.docs.renderers.html_renderer import render_html
from rivet_cli.docs.renderers.markdown_renderer import render_markdown
from rivet_cli.docs.validators.coverage import check_coverage

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _build_sample_package(root: Path) -> Path:
    """Create a sample Python package with documented and undocumented symbols."""
    pkg = root / "sample_pkg"
    pkg.mkdir(exist_ok=True)
    (pkg / "__init__.py").write_text('"""Sample package."""\n')
    (pkg / "core.py").write_text(textwrap.dedent('''\
        """Core module with documented symbols."""

        __all__ = ["Widget", "process"]


        class Widget:
            """A sample widget.

            Args:
                name: Widget name.
            """

            def __init__(self, name: str) -> None:
                self.name = name

            def run(self, times: int = 1) -> str:
                """Run the widget.

                Args:
                    times (int): How many times to run.

                Returns:
                    Result string.
                """
                return self.name * times


        def process(data: list[str], verbose: bool = False) -> int:
            """Process a list of data items.

            Args:
                data (list[str]): Items to process.
                verbose (bool): Enable verbose output.

            Returns:
                Number of items processed.

            Raises:
                ValueError: If data is empty.
            """
            if not data:
                raise ValueError("empty")
            return len(data)
    '''))
    (pkg / "errors_sample.py").write_text(textwrap.dedent('''\
        """Module with RivetError calls for error catalog testing."""

        class RivetError(Exception):
            def __init__(self, code, message, remediation=None):
                self.code = code
                super().__init__(message)

        def maybe_fail():
            raise RivetError(
                code="RVT-301",
                message="DAG cycle detected",
                remediation="Remove circular dependencies between joints.",
            )

        def another_fail():
            raise RivetError(
                code="RVT-501",
                message="Execution timeout",
            )
    '''))
    return pkg


def _collect_all_entries(sample_pkg: Path) -> list[DocEntry]:
    """Run all extractors that don't require a live Rivet project."""
    entries: list[DocEntry] = []
    entries.extend(extract_package(sample_pkg))
    entries.extend(extract_cli_reference())
    entries.extend(extract_config_reference())
    entries.extend(extract_error_catalog([sample_pkg]))
    return entries


def _make_documented_entries() -> list[DocEntry]:
    """Create DocEntry objects simulating a fully-documented package."""
    return [
        DocEntry(
            ref_id="mypkg.mod.MyClass",
            kind="class",
            name="MyClass",
            module="mypkg.mod",
            docstring="A well-documented class.",
            source_file="src/mypkg/mod.py",
            source_line=1,
        ),
        DocEntry(
            ref_id="mypkg.mod.MyClass.run",
            kind="method",
            name="run",
            module="mypkg.mod",
            docstring="Run the thing.\n\nArgs:\n    x: input.\n\nReturns:\n    result.",
            params=[DocParam(name="x", type_hint="int", description="input.")],
            returns="str",
            parent="mypkg.mod.MyClass",
            source_file="src/mypkg/mod.py",
            source_line=5,
        ),
        DocEntry(
            ref_id="mypkg.mod.helper",
            kind="function",
            name="helper",
            module="mypkg.mod",
            docstring="A helper function.\n\nReturns:\n    Nothing.",
            returns="None",
            source_file="src/mypkg/mod.py",
            source_line=15,
        ),
    ]


def _make_undocumented_entries() -> list[DocEntry]:
    """Create DocEntry objects simulating a poorly-documented package."""
    return [
        DocEntry(
            ref_id="badpkg.mod.func_a",
            kind="function",
            name="func_a",
            module="badpkg.mod",
            docstring=None,
            source_file="src/badpkg/mod.py",
        ),
        DocEntry(
            ref_id="badpkg.mod.func_b",
            kind="function",
            name="func_b",
            module="badpkg.mod",
            docstring=None,
            source_file="src/badpkg/mod.py",
        ),
        DocEntry(
            ref_id="badpkg.mod.ClassX",
            kind="class",
            name="ClassX",
            module="badpkg.mod",
            docstring="Documented.",
            source_file="src/badpkg/mod.py",
        ),
    ]


# ---------------------------------------------------------------------------
# Tests: Markdown build produces expected directory structure
# ---------------------------------------------------------------------------


class TestMarkdownBuild:
    """Test that markdown rendering produces expected structure."""

    def test_produces_expected_directories(self, tmp_path: Path):
        pkg = _build_sample_package(tmp_path)
        entries = _collect_all_entries(pkg)
        out = tmp_path / "docs_build"
        render_markdown(entries, out)

        assert out.exists()
        assert (out / "index.md").exists()
        assert (out / "api").is_dir()
        assert (out / "cli").is_dir()

    def test_markdown_contains_api_reference(self, tmp_path: Path):
        pkg = _build_sample_package(tmp_path)
        entries = _collect_all_entries(pkg)
        out = tmp_path / "docs_build"
        render_markdown(entries, out)

        api_files = list((out / "api").glob("*.md"))
        assert len(api_files) > 0
        all_text = "\n".join(f.read_text() for f in api_files)
        assert "Widget" in all_text
        assert "process" in all_text

    def test_markdown_contains_cli_reference(self, tmp_path: Path):
        pkg = _build_sample_package(tmp_path)
        entries = _collect_all_entries(pkg)
        out = tmp_path / "docs_build"
        render_markdown(entries, out)

        assert (out / "cli").is_dir()
        cli_files = list((out / "cli").glob("*.md"))
        assert len(cli_files) > 0
        all_text = "\n".join(f.read_text() for f in cli_files)
        assert "rivet" in all_text.lower()

    def test_markdown_contains_config_reference(self, tmp_path: Path):
        pkg = _build_sample_package(tmp_path)
        entries = _collect_all_entries(pkg)
        out = tmp_path / "docs_build"
        render_markdown(entries, out)

        assert (out / "config").is_dir()
        config_files = list((out / "config").glob("*.md"))
        assert len(config_files) > 0

    def test_markdown_contains_error_catalog(self, tmp_path: Path):
        pkg = _build_sample_package(tmp_path)
        entries = _collect_all_entries(pkg)
        out = tmp_path / "docs_build"
        render_markdown(entries, out)

        assert (out / "errors").is_dir()
        error_files = list((out / "errors").glob("*.md"))
        assert len(error_files) > 0
        all_text = "\n".join(f.read_text() for f in error_files)
        assert "RVT-301" in all_text


# ---------------------------------------------------------------------------
# Tests: HTML build produces expected structure
# ---------------------------------------------------------------------------


class TestHtmlBuild:
    """Test that HTML rendering produces correct output."""

    def test_html_contains_navigation_sidebar(self, tmp_path: Path):
        pkg = _build_sample_package(tmp_path)
        entries = _collect_all_entries(pkg)
        out = tmp_path / "html_build"
        render_html(entries, out)

        index = out / "index.html"
        assert index.exists()
        content = index.read_text()
        assert "<nav>" in content
        assert "nav-links" in content

    def test_html_contains_search_index_json(self, tmp_path: Path):
        pkg = _build_sample_package(tmp_path)
        entries = _collect_all_entries(pkg)
        out = tmp_path / "html_build"
        render_html(entries, out)

        search_idx_path = out / "search_index.json"
        assert search_idx_path.exists()
        search_idx = json.loads(search_idx_path.read_text())
        assert isinstance(search_idx, list)
        assert len(search_idx) > 0
        idx_ref_ids = {item["ref_id"] for item in search_idx}
        for entry in entries:
            assert entry.ref_id in idx_ref_ids, f"{entry.ref_id} missing from search index"

    def test_html_contains_cross_reference_hyperlinks(self, tmp_path: Path):
        entries = [
            DocEntry(
                ref_id="pkg.module.ClassA",
                kind="class",
                name="ClassA",
                module="pkg.module",
                docstring="See `pkg.module.ClassB` for details.",
                tags=["api"],
            ),
            DocEntry(
                ref_id="pkg.module.ClassB",
                kind="class",
                name="ClassB",
                module="pkg.module",
                docstring="Companion to `pkg.module.ClassA`.",
                tags=["api"],
            ),
        ]
        out = tmp_path / "xref_build"
        render_html(entries, out)

        page_a = (out / "pkg_module_ClassA.html").read_text()
        assert "pkg_module_ClassB.html" in page_a
        assert "<a href=" in page_a

    def test_html_index_lists_all_symbols(self, tmp_path: Path):
        pkg = _build_sample_package(tmp_path)
        entries = _collect_all_entries(pkg)
        out = tmp_path / "html_build"
        render_html(entries, out)

        index_content = (out / "index.html").read_text()
        for entry in entries:
            assert entry.name in index_content, f"{entry.name} missing from index"


# ---------------------------------------------------------------------------
# Tests: Validate with full docstrings → exit 0
# ---------------------------------------------------------------------------


class TestValidatePass:
    """Test that validation passes on a well-documented project."""

    def test_coverage_passes_with_full_docstrings(self):
        entries = _make_documented_entries()
        report = check_coverage(entries, threshold=80.0)
        assert report.passed is True

    def test_coverage_report_has_results(self):
        entries = _make_documented_entries()
        report = check_coverage(entries, threshold=80.0)
        assert len(report.results) > 0
        for result in report.results:
            assert result.coverage_pct >= 80.0


# ---------------------------------------------------------------------------
# Tests: Validate with missing docstrings → exit 1
# ---------------------------------------------------------------------------


class TestValidateFail:
    """Test that validation fails on a project with missing docstrings."""

    def test_coverage_fails_with_missing_docstrings(self):
        entries = _make_undocumented_entries()
        report = check_coverage(entries, threshold=80.0)
        assert report.passed is False

    def test_coverage_report_shows_low_percentage(self):
        entries = _make_undocumented_entries()
        report = check_coverage(entries, threshold=80.0)
        assert len(report.results) == 1
        # 1 documented out of 3 = 33.3%
        assert report.results[0].coverage_pct < 80.0


# ---------------------------------------------------------------------------
# Tests: DAG diagram in generated output
# ---------------------------------------------------------------------------


class TestDagDiagram:
    """Test that DAG diagrams appear in generated output."""

    def test_diagram_entry_renders_in_markdown(self, tmp_path: Path):
        diagram_entry = DocEntry(
            ref_id="diagram.project_dag",
            kind="diagram",
            name="Project DAG",
            module="dag",
            docstring="graph TD\n    A --> B\n    B --> C",
            tags=["diagram"],
            metadata={"format": "mermaid"},
        )
        out = tmp_path / "md_dag"
        render_markdown([diagram_entry], out)

        dag_files = list((out / "diagrams").glob("*.md"))
        assert len(dag_files) == 1
        content = dag_files[0].read_text()
        assert "Project DAG" in content
        assert "graph TD" in content

    def test_diagram_entry_renders_in_html(self, tmp_path: Path):
        diagram_entry = DocEntry(
            ref_id="diagram.project_dag",
            kind="diagram",
            name="Project DAG",
            module="dag",
            docstring="graph TD\n    A --> B\n    B --> C",
            tags=["diagram"],
            metadata={"format": "mermaid"},
        )
        out = tmp_path / "html_dag"
        render_html([diagram_entry], out)

        html_files = list(out.glob("*.html"))
        assert len(html_files) > 0
        all_text = "\n".join(f.read_text() for f in html_files)
        assert "mermaid" in all_text.lower()
        assert "Project DAG" in all_text

    def test_diagram_included_in_full_build(self, tmp_path: Path):
        """When a diagram entry is part of a full build, it appears in output."""
        pkg = _build_sample_package(tmp_path)
        entries = _collect_all_entries(pkg)
        entries.append(DocEntry(
            ref_id="diagram.test_dag",
            kind="diagram",
            name="Test DAG",
            module="dag",
            docstring="graph TD\n    src --> joint1\n    joint1 --> sink1",
            tags=["diagram"],
            metadata={"format": "mermaid"},
        ))
        out = tmp_path / "full_build"
        render_markdown(entries, out)

        assert (out / "diagrams").is_dir()
        dag_files = list((out / "diagrams").glob("*.md"))
        assert any("Test DAG" in f.read_text() for f in dag_files)


# ---------------------------------------------------------------------------
# Tests: rivet docs serve handler
# ---------------------------------------------------------------------------


class TestDocsServe:
    """Test the rivet docs serve handler logic."""

    def test_serve_triggers_build_when_output_missing(self, tmp_path: Path, monkeypatch):
        """When output dir doesn't exist, serve should run a build first."""
        import argparse
        from unittest.mock import MagicMock, patch

        from rivet_cli.app import GlobalOptions
        from rivet_cli.commands.docs import _run_serve

        monkeypatch.chdir(tmp_path)
        args = argparse.Namespace(port=9999)
        globals_opts = GlobalOptions()

        mock_server = MagicMock()
        mock_server.serve_forever.side_effect = KeyboardInterrupt

        def fake_build(a, g):
            # Simulate build creating output
            out = tmp_path / "docs" / "_build"
            out.mkdir(parents=True, exist_ok=True)
            (out / "index.html").write_text("<html></html>")
            return 0

        with patch("rivet_cli.commands.docs._run_build", side_effect=fake_build) as mock_build, \
             patch("http.server.HTTPServer", return_value=mock_server):
            rc = _run_serve(args, globals_opts)

        mock_build.assert_called_once()
        assert rc == 0

    def test_serve_skips_build_when_output_exists(self, tmp_path: Path, monkeypatch):
        """When output dir exists and is non-empty, serve should not rebuild."""
        import argparse
        from unittest.mock import MagicMock, patch

        from rivet_cli.app import GlobalOptions
        from rivet_cli.commands.docs import _run_serve

        monkeypatch.chdir(tmp_path)
        # Pre-create output directory with content
        out = tmp_path / "docs" / "_build"
        out.mkdir(parents=True)
        (out / "index.html").write_text("<html></html>")

        args = argparse.Namespace(port=9999)
        globals_opts = GlobalOptions()

        mock_server = MagicMock()
        mock_server.serve_forever.side_effect = KeyboardInterrupt

        with patch("rivet_cli.commands.docs._run_build") as mock_build, \
             patch("http.server.HTTPServer", return_value=mock_server):
            rc = _run_serve(args, globals_opts)

        mock_build.assert_not_called()
        assert rc == 0

    def test_serve_prints_url(self, tmp_path: Path, monkeypatch, capsys):
        """Serve should print the URL to stdout."""
        import argparse
        from unittest.mock import MagicMock, patch

        from rivet_cli.app import GlobalOptions
        from rivet_cli.commands.docs import _run_serve

        monkeypatch.chdir(tmp_path)
        out = tmp_path / "docs" / "_build"
        out.mkdir(parents=True)
        (out / "index.html").write_text("<html></html>")

        args = argparse.Namespace(port=8080)
        globals_opts = GlobalOptions()

        mock_server = MagicMock()
        mock_server.serve_forever.side_effect = KeyboardInterrupt

        with patch("http.server.HTTPServer", return_value=mock_server):
            _run_serve(args, globals_opts)

        captured = capsys.readouterr()
        assert "http://localhost:8080/" in captured.out

    def test_serve_returns_build_error_on_failure(self, tmp_path: Path, monkeypatch):
        """If build fails, serve should propagate the error code."""
        import argparse
        from unittest.mock import patch

        from rivet_cli.app import GlobalOptions
        from rivet_cli.commands.docs import _run_serve

        monkeypatch.chdir(tmp_path)
        args = argparse.Namespace(port=9999)
        globals_opts = GlobalOptions()

        with patch("rivet_cli.commands.docs._run_build") as mock_build, \
             patch("http.server.HTTPServer") as mock_http:
            mock_build.return_value = 2  # PARTIAL_FAILURE
            rc = _run_serve(args, globals_opts)

        assert rc == 2
        mock_http.assert_not_called()
