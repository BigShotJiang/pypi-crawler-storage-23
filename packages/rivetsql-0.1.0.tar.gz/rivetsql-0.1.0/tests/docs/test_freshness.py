"""Tests for the freshness detector."""

from __future__ import annotations

import json
from pathlib import Path

from rivet_cli.docs.models import DocEntry, DocParam
from rivet_cli.docs.validators.freshness import SIGNATURES_FILE, check_freshness


def _entry(ref_id: str, name: str = "foo", params: list[DocParam] | None = None,
           returns: str | None = None, source_file: str | None = "src/mod.py") -> DocEntry:
    return DocEntry(
        ref_id=ref_id, kind="function", name=name, module="pkg",
        params=params or [], returns=returns, source_file=source_file,
    )


class TestFirstRun:
    def test_no_hash_file_all_fresh(self, tmp_path: Path) -> None:
        entries = [_entry("a.foo"), _entry("a.bar", name="bar")]
        report = check_freshness(entries, tmp_path)
        assert report.passed is True
        assert report.stale_entries == []
        assert (tmp_path / SIGNATURES_FILE).exists()

    def test_creates_signatures_file(self, tmp_path: Path) -> None:
        check_freshness([_entry("x.y")], tmp_path)
        data = json.loads((tmp_path / SIGNATURES_FILE).read_text())
        assert "x.y" in data
        assert "hash" in data["x.y"]


class TestUnchangedSignatures:
    def test_same_entries_all_fresh(self, tmp_path: Path) -> None:
        entries = [_entry("a.f", params=[DocParam(name="x", type_hint="int")], returns="str")]
        check_freshness(entries, tmp_path)
        report = check_freshness(entries, tmp_path)
        assert report.passed is True
        assert report.stale_entries == []


class TestSignatureChanged:
    def test_param_type_change_detected(self, tmp_path: Path) -> None:
        v1 = [_entry("a.f", params=[DocParam(name="x", type_hint="int")])]
        check_freshness(v1, tmp_path)
        v2 = [_entry("a.f", params=[DocParam(name="x", type_hint="str")])]
        report = check_freshness(v2, tmp_path)
        assert report.passed is False
        assert len(report.stale_entries) == 1
        assert report.stale_entries[0].ref_id == "a.f"
        assert report.stale_entries[0].reason == "signature_changed"

    def test_return_type_change_detected(self, tmp_path: Path) -> None:
        v1 = [_entry("a.f", returns="int")]
        check_freshness(v1, tmp_path)
        v2 = [_entry("a.f", returns="str")]
        report = check_freshness(v2, tmp_path)
        assert report.passed is False
        assert report.stale_entries[0].reason == "signature_changed"

    def test_new_param_detected(self, tmp_path: Path) -> None:
        v1 = [_entry("a.f")]
        check_freshness(v1, tmp_path)
        v2 = [_entry("a.f", params=[DocParam(name="x", type_hint="int")])]
        report = check_freshness(v2, tmp_path)
        assert report.passed is False


class TestNewAndRemovedSymbols:
    def test_new_symbol_flagged(self, tmp_path: Path) -> None:
        check_freshness([_entry("a.f")], tmp_path)
        report = check_freshness([_entry("a.f"), _entry("a.g", name="g")], tmp_path)
        assert report.passed is False
        new = [e for e in report.stale_entries if e.reason == "new_symbol"]
        assert len(new) == 1
        assert new[0].ref_id == "a.g"

    def test_removed_symbol_flagged(self, tmp_path: Path) -> None:
        check_freshness([_entry("a.f"), _entry("a.g", name="g")], tmp_path)
        report = check_freshness([_entry("a.f")], tmp_path)
        assert report.passed is False
        removed = [e for e in report.stale_entries if e.reason == "removed_symbol"]
        assert len(removed) == 1
        assert removed[0].ref_id == "a.g"


class TestCorruptHashFile:
    def test_corrupt_json_all_stale(self, tmp_path: Path) -> None:
        (tmp_path / SIGNATURES_FILE).write_text("NOT VALID JSON{{{")
        entries = [_entry("a.f"), _entry("a.g", name="g")]
        report = check_freshness(entries, tmp_path)
        assert report.passed is False
        assert len(report.stale_entries) == 2

    def test_non_dict_json_all_stale(self, tmp_path: Path) -> None:
        (tmp_path / SIGNATURES_FILE).write_text("[1, 2, 3]")
        entries = [_entry("a.f")]
        report = check_freshness(entries, tmp_path)
        assert report.passed is False


class TestJsonReport:
    def test_report_to_json_roundtrip(self, tmp_path: Path) -> None:
        v1 = [_entry("a.f", returns="int")]
        check_freshness(v1, tmp_path)
        v2 = [_entry("a.f", returns="str")]
        report = check_freshness(v2, tmp_path)
        data = json.loads(report.to_json())
        assert data["passed"] is False
        assert len(data["stale_entries"]) == 1
        assert data["stale_entries"][0]["ref_id"] == "a.f"


class TestEmptyEntries:
    def test_empty_entries_first_run(self, tmp_path: Path) -> None:
        report = check_freshness([], tmp_path)
        assert report.passed is True

    def test_empty_entries_after_previous(self, tmp_path: Path) -> None:
        check_freshness([_entry("a.f")], tmp_path)
        report = check_freshness([], tmp_path)
        # Previous symbol removed
        assert report.passed is False
        assert report.stale_entries[0].reason == "removed_symbol"
