"""Tests for architecture doc templates."""

from rivet_cli.docs.extractors.architecture import get_architecture_guides


class TestArchitectureGuides:
    def test_returns_five_guides(self):
        entries = get_architecture_guides()
        assert len(entries) == 5

    def test_all_kind_guide(self):
        for entry in get_architecture_guides():
            assert entry.kind == "guide"

    def test_all_have_architecture_tag(self):
        for entry in get_architecture_guides():
            assert "architecture" in entry.tags
            assert "guide" in entry.tags

    def test_ref_ids_are_unique(self):
        entries = get_architecture_guides()
        ref_ids = [e.ref_id for e in entries]
        assert len(ref_ids) == len(set(ref_ids))

    def test_all_have_docstring(self):
        for entry in get_architecture_guides():
            assert entry.docstring is not None
            assert len(entry.docstring) > 0

    def test_expected_ref_ids(self):
        ref_ids = {e.ref_id for e in get_architecture_guides()}
        assert ref_ids == {
            "guide.core-concepts",
            "guide.module-boundaries",
            "guide.compilation-pipeline",
            "guide.materialization-contract",
            "guide.assertions-audits-tests",
        }

    def test_core_concepts_content(self):
        entries = {e.ref_id: e for e in get_architecture_guides()}
        doc = entries["guide.core-concepts"].docstring
        assert "Joint" in doc
        assert "ComputeEngine" in doc
        assert "Catalog" in doc
        assert "Assembly" in doc

    def test_module_boundaries_has_mermaid(self):
        entries = {e.ref_id: e for e in get_architecture_guides()}
        doc = entries["guide.module-boundaries"].docstring
        assert "```mermaid" in doc
        assert "rivet_core" in doc
        assert "rivet_cli" in doc

    def test_compilation_pipeline_stages(self):
        entries = {e.ref_id: e for e in get_architecture_guides()}
        doc = entries["guide.compilation-pipeline"].docstring
        assert "Config Parsing" in doc
        assert "Bridge Forward" in doc
        assert "CompiledAssembly" in doc

    def test_materialization_contract_content(self):
        entries = {e.ref_id: e for e in get_architecture_guides()}
        doc = entries["guide.materialization-contract"].docstring
        assert "MaterializedRef" in doc
        assert ".to_arrow()" in doc

    def test_assertions_audits_tests_content(self):
        entries = {e.ref_id: e for e in get_architecture_guides()}
        doc = entries["guide.assertions-audits-tests"].docstring
        assert "Assertion" in doc
        assert "Audit" in doc
        assert "Test" in doc
        assert "Pre-write" in doc
        assert "Post-write" in doc
