"""Tests for the config extractor."""

from __future__ import annotations

from unittest.mock import MagicMock

from rivet_cli.docs.extractors.config_extractor import (
    _extract_dataclass_fields,
    _extract_plugin_options,
    extract_config_reference,
)
from rivet_cli.docs.models import DocEntry
from rivet_config.models import CatalogConfig, EngineConfig, ProjectManifest, ResolvedProfile


class TestDataclassFieldExtraction:
    def test_project_manifest_fields(self) -> None:
        entries = _extract_dataclass_fields(ProjectManifest, "config.rivet_yaml", "rivet.yaml")
        names = {e.name for e in entries}
        assert "project_root" in names
        assert "profiles_path" in names
        assert "sources_dir" in names
        assert "joints_dir" in names
        assert "sinks_dir" in names
        for e in entries:
            assert e.kind == "config_key"
            assert e.ref_id.startswith("config.rivet_yaml.")
            assert "config" in e.tags

    def test_resolved_profile_fields(self) -> None:
        entries = _extract_dataclass_fields(ResolvedProfile, "config.profiles", "profiles.yaml")
        names = {e.name for e in entries}
        assert "name" in names
        assert "default_engine" in names
        assert "catalogs" in names
        assert "engines" in names

    def test_catalog_config_fields(self) -> None:
        entries = _extract_dataclass_fields(CatalogConfig, "config.profiles.catalog", "profiles.yaml catalogs")
        names = {e.name for e in entries}
        assert "name" in names
        assert "type" in names
        assert "options" in names

    def test_engine_config_fields(self) -> None:
        entries = _extract_dataclass_fields(EngineConfig, "config.profiles.engine", "profiles.yaml engines")
        names = {e.name for e in entries}
        assert "name" in names
        assert "type" in names
        assert "catalogs" in names
        assert "options" in names

    def test_entries_are_frozen(self) -> None:
        entries = _extract_dataclass_fields(CatalogConfig, "test", "test")
        assert len(entries) > 0
        for e in entries:
            assert isinstance(e, DocEntry)


class TestPluginOptionsExtraction:
    def _make_registry(self) -> MagicMock:
        registry = MagicMock()

        cat_plugin = MagicMock()
        cat_plugin.required_options = ["host", "port"]
        cat_plugin.optional_options = {"timeout": 30, "ssl": False}
        cat_plugin.credential_options = ["password"]

        engine_plugin = MagicMock()
        engine_plugin.supported_catalog_types = {
            "test_cat": ["read", "write"],
        }

        registry._catalog_plugins = {"test_cat": cat_plugin}
        registry._engine_plugins = {"test_engine": engine_plugin}
        return registry

    def test_required_options_extracted(self) -> None:
        registry = self._make_registry()
        entries = _extract_plugin_options(registry)
        required = [e for e in entries if e.metadata.get("required")]
        assert len(required) == 2
        names = {e.name for e in required}
        assert names == {"host", "port"}

    def test_optional_options_extracted(self) -> None:
        registry = self._make_registry()
        entries = _extract_plugin_options(registry)
        optional = [e for e in entries if e.metadata.get("required") is False]
        assert len(optional) == 2
        names = {e.name for e in optional}
        assert names == {"timeout", "ssl"}

    def test_credential_options_extracted(self) -> None:
        registry = self._make_registry()
        entries = _extract_plugin_options(registry)
        creds = [e for e in entries if e.metadata.get("credential")]
        assert len(creds) == 1
        assert creds[0].name == "password"

    def test_engine_supported_catalog_types(self) -> None:
        registry = self._make_registry()
        entries = _extract_plugin_options(registry)
        engine_entries = [e for e in entries if "engine" in e.tags]
        assert len(engine_entries) == 1
        assert engine_entries[0].metadata["supported_catalog_types"] == {
            "test_cat": ["read", "write"],
        }

    def test_all_entries_are_config_key_kind(self) -> None:
        registry = self._make_registry()
        entries = _extract_plugin_options(registry)
        for e in entries:
            assert e.kind == "config_key"


class TestExtractConfigReference:
    def test_returns_entries(self) -> None:
        entries = extract_config_reference()
        assert len(entries) > 0
        assert all(isinstance(e, DocEntry) for e in entries)

    def test_contains_rivet_yaml_keys(self) -> None:
        entries = extract_config_reference()
        rivet_yaml = [e for e in entries if e.ref_id.startswith("config.rivet_yaml.")]
        assert len(rivet_yaml) > 0

    def test_contains_profiles_keys(self) -> None:
        entries = extract_config_reference()
        profiles = [e for e in entries if e.ref_id.startswith("config.profiles.")]
        assert len(profiles) > 0

    def test_all_entries_are_config_key(self) -> None:
        entries = extract_config_reference()
        for e in entries:
            assert e.kind == "config_key"

    def test_all_entries_tagged_config(self) -> None:
        entries = extract_config_reference()
        for e in entries:
            assert "config" in e.tags

    def test_unique_ref_ids(self) -> None:
        entries = extract_config_reference()
        ref_ids = [e.ref_id for e in entries]
        assert len(ref_ids) == len(set(ref_ids)), f"Duplicate ref_ids: {[r for r in ref_ids if ref_ids.count(r) > 1]}"

    def test_builtin_plugin_options_included(self) -> None:
        """Built-in arrow and filesystem plugins should produce config entries."""
        entries = extract_config_reference()
        ref_ids = {e.ref_id for e in entries}
        # Arrow catalog has optional options like memory_limit
        assert any("arrow" in rid for rid in ref_ids)
        # Filesystem catalog has required option 'path'
        assert any("filesystem" in rid for rid in ref_ids)

    def test_engine_catalog_compatibility_included(self) -> None:
        entries = extract_config_reference()
        engine_entries = [e for e in entries if "engine" in e.tags]
        assert len(engine_entries) > 0
        # Arrow engine should have supported_catalog_types
        arrow_engines = [e for e in engine_entries if "arrow" in e.ref_id]
        assert len(arrow_engines) > 0


# ---------------------------------------------------------------------------
# Property 4: Config extractor produces a DocEntry for every dataclass field
# Validates: Requirements 7.1, 7.2
# ---------------------------------------------------------------------------

import dataclasses

from hypothesis import given, settings
from hypothesis import strategies as st


def _dataclass_strategy() -> st.SearchStrategy[type]:
    """Generate arbitrary frozen dataclasses with 1–8 fields."""
    field_name = st.from_regex(r"[a-z][a-z0-9_]{0,10}", fullmatch=True)
    field_names = st.lists(field_name, min_size=1, max_size=8, unique=True)

    @st.composite
    def _build(draw):
        names = draw(field_names)
        {n: str for n in names}
        cls = dataclasses.make_dataclass(
            "Generated",
            [(n, str) for n in names],
            frozen=True,
        )
        return cls, names

    return _build()


@given(cls_and_names=_dataclass_strategy())
@settings(max_examples=100)
def test_property4_every_field_has_doc_entry(cls_and_names) -> None:
    """Property 4: _extract_dataclass_fields produces one DocEntry per dataclass field."""
    cls, field_names = cls_and_names
    entries = _extract_dataclass_fields(cls, "test.prefix", "test.module")

    # One entry per field
    assert len(entries) == len(field_names)

    entry_names = [e.name for e in entries]
    for name in field_names:
        assert name in entry_names

    for e in entries:
        assert e.kind == "config_key"
        assert e.ref_id == f"test.prefix.{e.name}"
        assert "config" in e.tags
        assert isinstance(e, DocEntry)
