"""Tests for rivet_core.logging."""

import json
from io import StringIO
from unittest.mock import patch

from rivet_core.logging import LogEvent, LogLevel, RivetLogger


def test_log_levels_ordering() -> None:
    assert LogLevel.DEBUG < LogLevel.INFO < LogLevel.WARNING < LogLevel.ERROR


def test_log_event_to_dict_strips_none() -> None:
    event = LogEvent(
        timestamp="2025-01-01T00:00:00Z",
        level="INFO",
        phase="compilation",
        event_type="start",
        message="Starting compilation",
    )
    d = event.to_dict()
    assert "joint" not in d
    assert "context" not in d
    assert d["level"] == "INFO"


def test_log_event_to_dict_includes_joint() -> None:
    event = LogEvent(
        timestamp="2025-01-01T00:00:00Z",
        level="DEBUG",
        phase="execution",
        event_type="materialize",
        message="Materializing",
        joint="my_joint",
    )
    d = event.to_dict()
    assert d["joint"] == "my_joint"


def test_logger_filters_below_level() -> None:
    logger = RivetLogger(level=LogLevel.WARNING)
    result = logger.debug("compilation", "test", "should be filtered")
    assert result is None


def test_logger_emits_at_level() -> None:
    logger = RivetLogger(level=LogLevel.INFO)
    buf = StringIO()
    with patch("sys.stderr", buf):
        event = logger.info("compilation", "start", "Compiling")
    assert event is not None
    assert event.level == "INFO"
    output = buf.getvalue().strip()
    parsed = json.loads(output)
    assert parsed["message"] == "Compiling"
    assert parsed["phase"] == "compilation"


def test_logger_outputs_to_stderr() -> None:
    logger = RivetLogger(level=LogLevel.DEBUG)
    buf = StringIO()
    with patch("sys.stderr", buf):
        logger.error("execution", "failure", "Something broke", joint="j1")
    output = buf.getvalue().strip()
    parsed = json.loads(output)
    assert parsed["level"] == "ERROR"
    assert parsed["joint"] == "j1"


def test_logger_level_setter() -> None:
    logger = RivetLogger(level=LogLevel.ERROR)
    assert logger.level == LogLevel.ERROR
    logger.level = LogLevel.DEBUG
    assert logger.level == LogLevel.DEBUG


def test_logger_warning() -> None:
    logger = RivetLogger(level=LogLevel.WARNING)
    buf = StringIO()
    with patch("sys.stderr", buf):
        event = logger.warning("compilation", "schema_mismatch", "Types differ")
    assert event is not None
    assert event.level == "WARNING"


def test_logger_context_included() -> None:
    logger = RivetLogger(level=LogLevel.DEBUG)
    buf = StringIO()
    with patch("sys.stderr", buf):
        logger.debug("execution", "pushdown", "Pushed predicate", context={"pred": "x > 1"})
    parsed = json.loads(buf.getvalue().strip())
    assert parsed["context"]["pred"] == "x > 1"
