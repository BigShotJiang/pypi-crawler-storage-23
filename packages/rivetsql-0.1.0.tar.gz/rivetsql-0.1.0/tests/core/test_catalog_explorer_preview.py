"""Unit and property tests for CatalogExplorer.preview_table().

Validates: Requirements 8.1, 8.2, 8.3, 8.4, 8.5, 8.6

Feature: catalog-explorer, Property 17: Preview pipeline produces valid PreviewResult
- Verify transient assembly structure (source + sql + arrow sink)
- Verify compile() and Executor.run() called
- Verify PreviewResult fields populated
"""

from __future__ import annotations

from unittest.mock import MagicMock

import pyarrow
import pytest
from hypothesis import given, settings
from hypothesis import strategies as st

from rivet_core.builtins.arrow_catalog import _get_shared_store
from rivet_core.catalog_explorer import (
    RVT_875,
    CatalogExplorer,
    CatalogExplorerError,
    PreviewResult,
)
from rivet_core.models import ComputeEngine
from rivet_core.plugins import PluginRegistry

# ── Helpers ───────────────────────────────────────────────────────────────


def _make_mock_registry(*catalog_plugins):
    registry = MagicMock()
    plugin_map = {t: p for t, p in catalog_plugins}
    registry.get_catalog_plugin.side_effect = lambda t: plugin_map.get(t)
    return registry


def _make_mock_plugin(*, list_tables_return=None):
    plugin = MagicMock()
    plugin.list_tables.return_value = list_tables_return or []
    plugin.list_children.side_effect = Exception("not overridden")
    return plugin


def _setup_arrow_explorer(table_data: dict[str, pyarrow.Table] | None = None):
    """Create a CatalogExplorer backed by a real arrow catalog with test data."""
    registry = PluginRegistry()
    registry.register_builtins()

    # Clean up any leftover state
    keys_to_remove = [k for k in _get_shared_store() if k[0] == "test_cat"]
    for k in keys_to_remove:
        del _get_shared_store()[k]

    if table_data:
        for table_name, table in table_data.items():
            _get_shared_store()[("test_cat", table_name)] = table

    plugin = registry.get_catalog_plugin("arrow")
    cat = plugin.instantiate("test_cat", {})
    engine = ComputeEngine(name="arrow_engine", engine_type="arrow", config={})

    explorer = CatalogExplorer(
        catalogs={"test_cat": cat},
        engines={"arrow_engine": engine},
        registry=registry,
    )
    return explorer


# ── Validation Tests ──────────────────────────────────────────────────────


class TestPreviewTableValidation:
    """Test input validation for preview_table()."""

    def test_empty_path_raises(self):
        plugin = _make_mock_plugin()
        registry = _make_mock_registry(("arrow", plugin))
        explorer = CatalogExplorer(catalogs={}, engines={}, registry=registry)
        with pytest.raises(CatalogExplorerError) as exc_info:
            explorer.preview_table([])
        assert exc_info.value.error.code == RVT_875

    def test_single_element_path_raises(self):
        plugin = _make_mock_plugin()
        registry = _make_mock_registry(("arrow", plugin))
        explorer = CatalogExplorer(catalogs={}, engines={}, registry=registry)
        with pytest.raises(CatalogExplorerError) as exc_info:
            explorer.preview_table(["mycat"])
        assert exc_info.value.error.code == RVT_875

    def test_unknown_catalog_raises(self):
        plugin = _make_mock_plugin()
        registry = _make_mock_registry(("arrow", plugin))
        explorer = CatalogExplorer(catalogs={}, engines={}, registry=registry)
        with pytest.raises(CatalogExplorerError) as exc_info:
            explorer.preview_table(["nonexistent", "table"])
        assert exc_info.value.error.code == RVT_875


# ── Pipeline Integration Tests ────────────────────────────────────────────


class TestPreviewTablePipeline:
    """Test that preview_table() constructs and executes a transient pipeline.

    Property 17: Preview pipeline produces valid PreviewResult.
    Uses real arrow catalog to verify end-to-end behavior.
    """

    def test_preview_returns_valid_preview_result(self):
        """Verify PreviewResult fields are populated correctly (Req 8.5)."""
        explorer = _setup_arrow_explorer({
            "users": pyarrow.table({"id": [1, 2, 3], "name": ["a", "b", "c"]}),
        })

        result = explorer.preview_table(["test_cat", "users"], limit=100)

        assert isinstance(result, PreviewResult)
        assert result.row_count == 3
        assert result.column_names == ["id", "name"]
        assert result.column_types == ["int64", "string"]
        assert result.truncated is False
        assert result.elapsed_ms >= 0
        assert result.table.num_rows == 3

    def test_preview_truncated_when_at_limit(self):
        """Truncated should be True when row_count >= limit (Req 8.5)."""
        explorer = _setup_arrow_explorer({
            "big": pyarrow.table({"x": list(range(100))}),
        })

        result = explorer.preview_table(["test_cat", "big"], limit=5)
        assert result.truncated is True
        assert result.row_count == 5
        assert result.table.num_rows == 5

    def test_preview_not_truncated_when_under_limit(self):
        explorer = _setup_arrow_explorer({
            "small": pyarrow.table({"x": [1, 2, 3]}),
        })

        result = explorer.preview_table(["test_cat", "small"], limit=100)
        assert result.truncated is False
        assert result.row_count == 3

    def test_preview_uses_compile_and_executor(self):
        """Verify the standard compile→execute path is used (Req 8.2, 8.3, 8.6)."""
        explorer = _setup_arrow_explorer({
            "t": pyarrow.table({"a": [1]}),
        })

        # If compile or executor weren't called, we'd get no data
        result = explorer.preview_table(["test_cat", "t"])
        assert result.row_count == 1
        assert result.column_names == ["a"]

    def test_preview_extracts_arrow_table(self):
        """Verify MaterializedRef.to_arrow() extraction (Req 8.4)."""
        explorer = _setup_arrow_explorer({
            "t": pyarrow.table({"col1": [10, 20], "col2": ["x", "y"]}),
        })

        result = explorer.preview_table(["test_cat", "t"])
        assert isinstance(result.table, pyarrow.Table)
        assert result.table.column("col1").to_pylist() == [10, 20]
        assert result.table.column("col2").to_pylist() == ["x", "y"]

    def test_preview_with_dotted_path(self):
        """Verify preview works with multi-segment table paths."""
        _get_shared_store()[("test_cat", "public.orders")] = pyarrow.table(
            {"order_id": [1, 2], "amount": [10.5, 20.3]}
        )
        registry = PluginRegistry()
        registry.register_builtins()
        plugin = registry.get_catalog_plugin("arrow")
        cat = plugin.instantiate("test_cat", {})
        engine = ComputeEngine(name="e", engine_type="arrow", config={})
        explorer = CatalogExplorer(
            catalogs={"test_cat": cat}, engines={"e": engine}, registry=registry,
        )

        result = explorer.preview_table(["test_cat", "public", "orders"])
        assert result.row_count == 2
        assert result.column_names == ["order_id", "amount"]

    def test_preview_cleans_up_arrow_table_store(self):
        """Verify the preview result is popped from the shared table store."""
        explorer = _setup_arrow_explorer({
            "t": pyarrow.table({"a": [1]}),
        })

        explorer.preview_table(["test_cat", "t"])

        # The preview sink entry should have been removed
        assert ("__preview_arrow", "__preview_sink") not in _get_shared_store()

    def test_preview_nonexistent_table_raises(self):
        """Preview of a table that doesn't exist should raise RVT-875."""
        explorer = _setup_arrow_explorer({})

        with pytest.raises(CatalogExplorerError) as exc_info:
            explorer.preview_table(["test_cat", "nonexistent"])
        assert exc_info.value.error.code == RVT_875

    def test_preview_column_types_populated(self):
        """Verify column_types matches the arrow schema types."""
        explorer = _setup_arrow_explorer({
            "typed": pyarrow.table({
                "i": pyarrow.array([1], type=pyarrow.int32()),
                "f": pyarrow.array([1.0], type=pyarrow.float64()),
                "s": pyarrow.array(["x"], type=pyarrow.string()),
                "b": pyarrow.array([True], type=pyarrow.bool_()),
            }),
        })

        result = explorer.preview_table(["test_cat", "typed"])
        assert result.column_types == ["int32", "double", "string", "bool"]


# ── Property 17: Preview pipeline produces valid PreviewResult ────────────

# Strategy: generate a list of (column_name, pyarrow_type, values) triples
_ARROW_TYPES = [
    (pyarrow.int64(), st.integers(min_value=-(2**31), max_value=2**31 - 1)),
    (pyarrow.float64(), st.floats(allow_nan=False, allow_infinity=False, min_value=-1e6, max_value=1e6)),
    (pyarrow.string(), st.text(alphabet=st.characters(whitelist_categories=("Lu", "Ll", "Nd")), max_size=20)),
    (pyarrow.bool_(), st.booleans()),
]

_col_name_st = st.text(
    alphabet=st.characters(whitelist_categories=("Ll",)),
    min_size=1,
    max_size=10,
)

_col_def_st = st.tuples(
    _col_name_st,
    st.integers(min_value=0, max_value=len(_ARROW_TYPES) - 1),
)


def _build_arrow_table(col_defs: list[tuple[str, int]], row_count: int) -> pyarrow.Table | None:
    """Build a pyarrow.Table from column definitions, or None if names collide."""
    seen: set[str] = set()
    arrays = {}
    for name, type_idx in col_defs:
        if name in seen:
            return None
        seen.add(name)
        arrow_type, value_st = _ARROW_TYPES[type_idx]
        # Draw values deterministically using a fixed seed approach via list
        # We can't use st.draw here, so we use a simple fixed value per type
        if arrow_type == pyarrow.int64():
            vals = list(range(row_count))
        elif arrow_type == pyarrow.float64():
            vals = [float(i) for i in range(row_count)]
        elif arrow_type == pyarrow.string():
            vals = [name[:1] * (i % 5 + 1) for i in range(row_count)]
        else:  # bool
            vals = [i % 2 == 0 for i in range(row_count)]
        arrays[name] = pyarrow.array(vals, type=arrow_type)
    if not arrays:
        return None
    return pyarrow.table(arrays)


@given(
    col_defs=st.lists(_col_def_st, min_size=1, max_size=5),
    row_count=st.integers(min_value=0, max_value=20),
    limit=st.integers(min_value=1, max_value=15),
)
@settings(max_examples=50)
def test_property_17_preview_pipeline_valid_result(col_defs, row_count, limit):
    """Feature: catalog-explorer, Property 17: Preview pipeline produces valid PreviewResult.

    For any valid table path, preview_table(path, limit) should:
    - Return a PreviewResult with row_count, column_names, column_types populated
    - Set truncated=True when limit was applied (row_count >= limit)
    - Return elapsed_ms >= 0
    - Return a pyarrow.Table with the correct shape

    Validates: Requirements 8.1, 8.2, 8.3, 8.4, 8.5
    """
    arrow_table = _build_arrow_table(col_defs, row_count)
    if arrow_table is None:
        return  # skip duplicate column names

    # Clean up any leftover state
    keys_to_remove = [k for k in _get_shared_store() if k[0] == "prop17_cat"]
    for k in keys_to_remove:
        del _get_shared_store()[k]

    table_name = "prop17_tbl"
    _get_shared_store()[("prop17_cat", table_name)] = arrow_table

    registry = PluginRegistry()
    registry.register_builtins()
    plugin = registry.get_catalog_plugin("arrow")
    cat = plugin.instantiate("prop17_cat", {})
    engine = ComputeEngine(name="e", engine_type="arrow", config={})
    explorer = CatalogExplorer(
        catalogs={"prop17_cat": cat},
        engines={"e": engine},
        registry=registry,
    )

    result = explorer.preview_table(["prop17_cat", table_name], limit=limit)

    # PreviewResult must be the right type
    assert isinstance(result, PreviewResult)

    # elapsed_ms must be non-negative (Req 8.5)
    assert result.elapsed_ms >= 0

    # column_names and column_types must be populated (Req 8.5)
    assert result.column_names == arrow_table.column_names
    assert len(result.column_types) == len(arrow_table.column_names)

    # row_count must match actual rows returned
    expected_rows = min(row_count, limit)
    assert result.row_count == expected_rows
    assert result.table.num_rows == expected_rows

    # truncated must be True when limit was applied (Req 8.5)
    assert result.truncated == (row_count >= limit)

    # The returned table must be a pyarrow.Table (Req 8.4)
    assert isinstance(result.table, pyarrow.Table)

    # Cleanup
    _get_shared_store().pop(("__preview_arrow", "__preview_sink"), None)
