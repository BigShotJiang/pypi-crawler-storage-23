"""Tests for rivet_core.metrics."""

import pytest

from rivet_core.metrics import (
    CacheMetrics,
    ColumnExecutionStats,
    IOMetrics,
    MaterializationStats,
    MemoryMetrics,
    ParallelismMetrics,
    PhasedTiming,
    PluginMetrics,
    QueryPlanningMetrics,
    ScanMetrics,
)


def test_phased_timing_frozen() -> None:
    t = PhasedTiming(total_ms=100.0, engine_ms=60.0, materialize_ms=20.0, residual_ms=10.0, check_ms=10.0)
    assert t.total_ms == 100.0
    with pytest.raises(AttributeError):
        t.total_ms = 200.0  # type: ignore[misc]


def test_column_execution_stats() -> None:
    cs = ColumnExecutionStats(
        column="id", null_count=0, distinct_count_estimate=1000, min_value="1", max_value="1000"
    )
    assert cs.column == "id"
    assert cs.distinct_count_estimate == 1000


def test_materialization_stats() -> None:
    col = ColumnExecutionStats(column="x", null_count=5, distinct_count_estimate=50, min_value=None, max_value=None)
    ms = MaterializationStats(row_count=100, byte_size=4096, column_stats=[col])
    assert ms.row_count == 100
    assert len(ms.column_stats) == 1


def test_query_planning_metrics_defaults() -> None:
    qpm = QueryPlanningMetrics()
    assert qpm.planning_time_ms is None
    assert qpm.estimated_rows is None


def test_io_metrics() -> None:
    io = IOMetrics(bytes_read=1024, files_read=3)
    assert io.bytes_read == 1024
    assert io.bytes_written is None


def test_memory_metrics_defaults() -> None:
    mm = MemoryMetrics()
    assert mm.spilled is False
    assert mm.peak_bytes is None


def test_parallelism_metrics() -> None:
    pm = ParallelismMetrics(threads_used=4, thread_time_ms=250.0)
    assert pm.threads_used == 4


def test_cache_metrics() -> None:
    cm = CacheMetrics(hits=90, misses=10, hit_ratio=0.9)
    assert cm.hit_ratio == 0.9
    assert cm.evictions is None


def test_scan_metrics() -> None:
    sm = ScanMetrics(rows_scanned=10000, rows_filtered=8000, filter_selectivity=0.2)
    assert sm.filter_selectivity == 0.2


def test_plugin_metrics_valid_extensions() -> None:
    pm = PluginMetrics(
        well_known={"io": IOMetrics(bytes_read=100)},
        extensions={"duckdb.temp_files": 3},
        engine="duckdb",
    )
    assert pm.extensions["duckdb.temp_files"] == 3


def test_plugin_metrics_rejects_unnamespaced_extension() -> None:
    with pytest.raises(ValueError, match="must be namespaced"):
        PluginMetrics(
            extensions={"bad_key": 42},
            engine="arrow",
        )


def test_plugin_metrics_empty() -> None:
    pm = PluginMetrics(engine="arrow")
    assert pm.well_known == {}
    assert pm.extensions == {}
    assert pm.adapter is None
