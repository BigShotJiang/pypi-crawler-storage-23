"""Unit tests for error types and data models (Task 1.4).

Tests BridgeError, BridgeValidationError, and all frozen data model dataclasses.
Requirements: 17.1, 17.7
"""

from __future__ import annotations

import dataclasses
from pathlib import Path

import pytest

from rivet_bridge.errors import BridgeError, BridgeValidationError
from rivet_bridge.models import (
    BridgeResult,
    FileOutput,
    ProjectOutput,
    RoundtripDifference,
    RoundtripResult,
)
from rivet_config import CatalogConfig, EngineConfig, ResolvedProfile
from rivet_core import Assembly, Catalog, ComputeEngine, Joint

# --- BridgeError ---


class TestBridgeError:
    def test_required_fields(self):
        err = BridgeError(code="BRG-100", message="config failed")
        assert err.code == "BRG-100"
        assert err.message == "config failed"

    def test_optional_defaults_none(self):
        err = BridgeError(code="BRG-100", message="x")
        assert err.joint_name is None
        assert err.source_file is None
        assert err.remediation is None

    def test_optional_fields_set(self):
        err = BridgeError(
            code="BRG-207",
            message="unknown engine",
            joint_name="my_joint",
            source_file="joints/my_joint.yaml",
            remediation="Check engine name",
        )
        assert err.joint_name == "my_joint"
        assert err.source_file == "joints/my_joint.yaml"
        assert err.remediation == "Check engine name"

    def test_immutability(self):
        err = BridgeError(code="BRG-100", message="x")
        with pytest.raises(dataclasses.FrozenInstanceError):
            err.code = "BRG-999"  # type: ignore[misc]

    def test_is_frozen_dataclass(self):
        assert dataclasses.is_dataclass(BridgeError)
        assert dataclasses.fields(BridgeError)[0].name == "code"


# --- BridgeValidationError ---


class TestBridgeValidationError:
    def test_stores_errors(self):
        errs = [BridgeError(code="BRG-201", message="a"), BridgeError(code="BRG-202", message="b")]
        exc = BridgeValidationError(errs)
        assert exc.errors is errs
        assert len(exc.errors) == 2

    def test_message_format(self):
        exc = BridgeValidationError([BridgeError(code="BRG-100", message="x")])
        assert str(exc) == "1 bridge error(s)"

    def test_message_format_multiple(self):
        exc = BridgeValidationError([BridgeError(code="BRG-100", message="x")] * 3)
        assert str(exc) == "3 bridge error(s)"

    def test_is_exception(self):
        exc = BridgeValidationError([])
        assert isinstance(exc, Exception)

    def test_raisable(self):
        with pytest.raises(BridgeValidationError) as exc_info:
            raise BridgeValidationError([BridgeError(code="BRG-100", message="fail")])
        assert len(exc_info.value.errors) == 1


# --- FileOutput ---


class TestFileOutput:
    def test_field_access(self):
        f = FileOutput(relative_path="sources/a.yaml", content="name: a", joint_name="a")
        assert f.relative_path == "sources/a.yaml"
        assert f.content == "name: a"
        assert f.joint_name == "a"

    def test_joint_name_default_none(self):
        f = FileOutput(relative_path="rivet.yaml", content="")
        assert f.joint_name is None

    def test_immutability(self):
        f = FileOutput(relative_path="x", content="y")
        with pytest.raises(dataclasses.FrozenInstanceError):
            f.content = "z"  # type: ignore[misc]


# --- BridgeResult ---


class TestBridgeResult:
    def _make(self) -> BridgeResult:
        joints = [
            Joint(name="src", joint_type="source", sql="SELECT * FROM src"),
        ]
        return BridgeResult(
            assembly=Assembly(joints),
            catalogs={"c": Catalog(name="c", type="arrow")},
            engines={"e": ComputeEngine(name="e", engine_type="arrow")},
            profile_snapshot=ResolvedProfile(
                name="test",
                default_engine="e",
                catalogs={"c": CatalogConfig(name="c", type="arrow", options={})},
                engines=[EngineConfig(name="e", type="arrow", catalogs=["c"], options={})],
            ),
            source_formats={"src": "yaml"},
        )

    def test_field_access(self):
        br = self._make()
        assert br.assembly is not None
        assert "c" in br.catalogs
        assert "e" in br.engines
        assert br.profile_snapshot.name == "test"
        assert br.source_formats == {"src": "yaml"}

    def test_immutability(self):
        br = self._make()
        with pytest.raises(dataclasses.FrozenInstanceError):
            br.source_formats = {}  # type: ignore[misc]


# --- ProjectOutput ---


class TestProjectOutput:
    def test_field_access(self):
        rivet = FileOutput(relative_path="rivet.yaml", content="")
        profile = FileOutput(relative_path="profiles.yaml", content="")
        decl = FileOutput(relative_path="sources/a.yaml", content="", joint_name="a")
        qf = FileOutput(relative_path="quality/a.yaml", content="", joint_name="a")
        po = ProjectOutput(
            rivet_yaml=rivet,
            profile=profile,
            declarations=[decl],
            quality_files=[qf],
            output_dir=Path("/tmp/out"),
        )
        assert po.rivet_yaml is rivet
        assert po.profile is profile
        assert po.declarations == [decl]
        assert po.quality_files == [qf]
        assert po.output_dir == Path("/tmp/out")

    def test_immutability(self):
        po = ProjectOutput(
            rivet_yaml=FileOutput(relative_path="r", content=""),
            profile=FileOutput(relative_path="p", content=""),
            declarations=[],
            quality_files=[],
            output_dir=Path("."),
        )
        with pytest.raises(dataclasses.FrozenInstanceError):
            po.output_dir = Path("/other")  # type: ignore[misc]


# --- RoundtripDifference ---


class TestRoundtripDifference:
    def test_field_access(self):
        d = RoundtripDifference(joint_name="j", field="sql", description="sql differs")
        assert d.joint_name == "j"
        assert d.field == "sql"
        assert d.description == "sql differs"

    def test_immutability(self):
        d = RoundtripDifference(joint_name="j", field="sql", description="x")
        with pytest.raises(dataclasses.FrozenInstanceError):
            d.field = "upstream"  # type: ignore[misc]


# --- RoundtripResult ---


class TestRoundtripResult:
    def test_equivalent_true(self):
        r = RoundtripResult(equivalent=True, differences=[])
        assert r.equivalent is True
        assert r.differences == []

    def test_equivalent_false_with_diffs(self):
        diff = RoundtripDifference(joint_name="j", field="sql", description="x")
        r = RoundtripResult(equivalent=False, differences=[diff])
        assert r.equivalent is False
        assert len(r.differences) == 1
        assert r.differences[0].joint_name == "j"

    def test_immutability(self):
        r = RoundtripResult(equivalent=True, differences=[])
        with pytest.raises(dataclasses.FrozenInstanceError):
            r.equivalent = False  # type: ignore[misc]
