"""Verify adapters/unity.py imports only from rivet_core and rivet_databricks.

Feature: databricks-unity-adapter, Task 5.1: Module boundary compliance
Validates: Requirements 7.1, 7.2, 7.3
"""

from __future__ import annotations

import ast
from pathlib import Path

_SRC_DIR = Path(__file__).resolve().parent.parent.parent / "src"
_UNITY_ADAPTER = _SRC_DIR / "rivet_databricks" / "adapters" / "unity.py"

_ALLOWED_RIVET_MODULES = {"rivet_core", "rivet_databricks"}
_FORBIDDEN_RIVET_MODULES = {
    "rivet_config",
    "rivet_bridge",
    "rivet_cli",
    "rivet_duckdb",
    "rivet_polars",
    "rivet_pyspark",
    "rivet_aws",
    "rivet_postgres",
}


def _extract_rivet_imports(source: str) -> list[tuple[int, str]]:
    """Return (line_number, top-level rivet_* module) pairs from source."""
    tree = ast.parse(source)
    results: list[tuple[int, str]] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name.startswith("rivet_"):
                    results.append((node.lineno, alias.name.split(".")[0]))
        elif isinstance(node, ast.ImportFrom) and node.module and node.module.startswith("rivet_"):
            results.append((node.lineno, node.module.split(".")[0]))
    return results


def test_unity_adapter_exists_in_rivet_databricks() -> None:
    """Req 7.2: adapters/unity.py resides in rivet_databricks."""
    assert _UNITY_ADAPTER.exists(), (
        f"adapters/unity.py not found at {_UNITY_ADAPTER}; "
        "it must reside in the rivet_databricks package."
    )


def test_unity_adapter_no_forbidden_imports() -> None:
    """Req 7.1, 7.3: No imports from rivet_config, rivet_bridge, rivet_cli, or other plugins."""
    if not _UNITY_ADAPTER.exists():
        raise FileNotFoundError(f"{_UNITY_ADAPTER} does not exist yet — task 1 must run first.")

    source = _UNITY_ADAPTER.read_text()
    violations = [
        f"  line {lineno}: imports {mod}"
        for lineno, mod in _extract_rivet_imports(source)
        if mod in _FORBIDDEN_RIVET_MODULES
    ]
    assert not violations, (
        "adapters/unity.py has forbidden imports:\n" + "\n".join(violations)
    )


def test_unity_adapter_only_allowed_rivet_imports() -> None:
    """Req 7.1: All rivet_* imports resolve to rivet_core or rivet_databricks only."""
    if not _UNITY_ADAPTER.exists():
        raise FileNotFoundError(f"{_UNITY_ADAPTER} does not exist yet — task 1 must run first.")

    source = _UNITY_ADAPTER.read_text()
    violations = [
        f"  line {lineno}: imports {mod}"
        for lineno, mod in _extract_rivet_imports(source)
        if mod not in _ALLOWED_RIVET_MODULES
    ]
    assert not violations, (
        "adapters/unity.py imports disallowed rivet_* modules:\n" + "\n".join(violations)
    )
