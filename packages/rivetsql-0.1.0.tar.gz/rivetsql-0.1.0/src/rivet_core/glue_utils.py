"""Shared Glue table resolution utilities.

Consolidates the partition-filter matching and Glue table metadata
resolution logic used by engine plugin adapters (rivet_duckdb, rivet_polars).
"""

from __future__ import annotations

from typing import Any

from rivet_core.errors import ExecutionError, plugin_error


def matches_partition_filter(
    partition_values: dict[str, str], partition_filter: dict[str, Any]
) -> bool:
    """Return True if partition_values satisfies all key=value constraints."""
    return all(partition_values.get(key) == str(value) for key, value in partition_filter.items())


def resolve_glue_table(
    client: Any,
    database: str,
    table_name: str,
    partition_filter: dict[str, Any] | None,
    *,
    catalog_id: str | None = None,
    plugin_name: str = "rivet_aws",
    adapter_name: str = "glue",
) -> tuple[str, str, list[str], list[str]]:
    """Resolve Glue table to (location, input_format, partition_keys, filtered_locations).

    Uses a pre-built boto3 Glue client for GetTable/GetPartitions calls.
    Returns the raw InputFormat string — callers handle format-specific mapping.
    """
    kwargs: dict[str, Any] = {"DatabaseName": database, "Name": table_name}
    if catalog_id:
        kwargs["CatalogId"] = catalog_id

    try:
        resp = client.get_table(**kwargs)
    except Exception as exc:
        raise ExecutionError(
            plugin_error(
                "RVT-503",
                f"Glue table '{table_name}' not found in database '{database}': {exc}",
                plugin_name=plugin_name,
                plugin_type="adapter",
                adapter=adapter_name,
                remediation="Check that the table exists in the Glue catalog.",
                table=table_name,
                database=database,
            )
        ) from exc

    tbl = resp["Table"]
    sd = tbl.get("StorageDescriptor", {})
    location = sd.get("Location", "")
    input_format = sd.get("InputFormat", "")
    partition_keys = [pk["Name"] for pk in tbl.get("PartitionKeys", [])]

    partition_locations: list[str] = []
    if partition_keys:
        part_kwargs: dict[str, Any] = {"DatabaseName": database, "TableName": table_name}
        if catalog_id:
            part_kwargs["CatalogId"] = catalog_id

        paginator = client.get_paginator("get_partitions")
        for page in paginator.paginate(**part_kwargs):
            for part in page.get("Partitions", []):
                values_list = part.get("Values", [])
                values_dict = dict(zip(partition_keys, values_list))
                if partition_filter is None or matches_partition_filter(
                    values_dict, partition_filter
                ):
                    psd = part.get("StorageDescriptor", {})
                    ploc = psd.get("Location", "")
                    if ploc:
                        partition_locations.append(ploc)

    return location, input_format, partition_keys, partition_locations
