"""Docs command: generate, serve, and validate documentation."""

from __future__ import annotations

import argparse

from rivet_cli.app import GlobalOptions


def register_docs_parser(subs: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    """Register the ``rivet docs`` subcommand with build/serve/validate sub-actions."""
    docs_p = subs.add_parser("docs", help="Generate, serve, and validate documentation")

    docs_subs = docs_p.add_subparsers(dest="docs_action")

    # --- build ---
    build_p = docs_subs.add_parser("build", help="Build documentation")
    build_p.add_argument(
        "--format",
        dest="docs_format",
        default="markdown",
        choices=["markdown", "html"],
        help="Output format (default: markdown)",
    )
    build_p.add_argument(
        "--output",
        default="docs/_build/",
        help="Output directory (default: docs/_build/)",
    )

    # --- serve ---
    serve_p = docs_subs.add_parser("serve", help="Serve documentation locally")
    serve_p.add_argument(
        "--port",
        type=int,
        default=8000,
        help="Port to serve on (default: 8000)",
    )

    # --- validate ---
    validate_p = docs_subs.add_parser("validate", help="Validate documentation coverage and freshness")
    validate_p.add_argument(
        "--threshold",
        type=float,
        default=80,
        help="Minimum coverage percentage (default: 80)",
    )
    validate_p.add_argument(
        "--ci",
        action="store_true",
        help="CI mode: non-zero exit on stale docs or low coverage",
    )


def run_docs(args: argparse.Namespace, globals: GlobalOptions) -> int:
    """Dispatch docs sub-actions."""
    from rivet_cli.exit_codes import USAGE_ERROR

    action = getattr(args, "docs_action", None)
    if not action:
        from rivet_cli.errors import CLIError, format_cli_error

        err = CLIError(
            code="RVT-851",
            message="Missing docs subcommand.",
            remediation="Available subcommands: build, serve, validate.",
        )
        print(format_cli_error(err, globals.color), file=__import__("sys").stderr)
        return USAGE_ERROR

    if action == "build":
        return _run_build(args, globals)
    if action == "serve":
        return _run_serve(args, globals)
    if action == "validate":
        return _run_validate(args, globals)

    from rivet_cli.errors import CLIError, format_cli_error

    err = CLIError(
        code="RVT-851",
        message=f"Unknown docs subcommand: '{action}'.",
        remediation="Available subcommands: build, serve, validate.",
    )
    print(format_cli_error(err, globals.color), file=__import__("sys").stderr)
    return USAGE_ERROR


def _run_build(args: argparse.Namespace, globals: GlobalOptions) -> int:
    """Run all extractors, then dispatch to the chosen renderer."""
    import logging
    import sys
    import warnings
    from pathlib import Path

    from rivet_cli.exit_codes import PARTIAL_FAILURE, SUCCESS

    logging.getLogger(__name__)
    output_dir = Path(args.output)
    fmt = args.docs_format
    src_root = Path(__import__("rivet_cli").__file__).resolve().parent.parent  # type: ignore[arg-type]

    entries: list = []  # type: ignore[type-arg]

    # Capture warnings from extractors (e.g. missing docstrings, missing remediation)
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")

        # API extraction — walk each known package
        from rivet_cli.docs.extractors.api_extractor import PACKAGES, extract_package

        for pkg_name in PACKAGES:
            pkg_path = src_root / pkg_name
            entries.extend(extract_package(pkg_path))

        # CLI reference
        from rivet_cli.docs.extractors.cli_extractor import extract_cli_reference

        entries.extend(extract_cli_reference())

        # Config reference
        from rivet_cli.docs.extractors.config_extractor import extract_config_reference

        entries.extend(extract_config_reference())

        # Error catalog
        from rivet_cli.docs.extractors.error_extractor import extract_error_catalog

        entries.extend(extract_error_catalog([src_root / p for p in PACKAGES]))

        # Plugin guide
        from rivet_cli.docs.extractors.plugin_extractor import extract_plugin_guide

        entries.extend(extract_plugin_guide())

        # DAG diagram (only when inside a Rivet project)
        from rivet_cli.docs.extractors.dag_extractor import extract_dag_diagram

        entries.extend(extract_dag_diagram(globals.project_path))

        # Architecture guides
        from rivet_cli.docs.extractors.architecture import get_architecture_guides

        entries.extend(get_architecture_guides())

    # Log captured warnings
    for w in caught:
        print(f"rivet | WARN {w.message}", file=sys.stderr)

    if not entries:
        print("rivet | ERROR No parseable source files found.", file=sys.stderr)
        return PARTIAL_FAILURE

    # Render
    from rivet_cli.docs.renderers.html_renderer import render_html
    from rivet_cli.docs.renderers.markdown_renderer import render_markdown

    if fmt == "html":
        render_html(entries, output_dir)
    else:
        render_markdown(entries, output_dir)

    print(f"Documentation built: {output_dir} ({len(entries)} entries, format={fmt})")
    return SUCCESS


def _run_serve(args: argparse.Namespace, globals: GlobalOptions) -> int:
    """Serve generated documentation via a local HTTP server."""
    import functools
    import http.server
    from pathlib import Path

    from rivet_cli.exit_codes import SUCCESS

    output_dir = Path("docs/_build/")

    # Run build if output directory is missing or empty
    if not output_dir.exists() or not any(output_dir.iterdir()):
        # Build HTML for serving
        build_ns = argparse.Namespace(
            output=str(output_dir),
            docs_format="html",
        )
        rc = _run_build(build_ns, globals)
        if rc != SUCCESS:
            return rc

    port = args.port
    handler = functools.partial(
        http.server.SimpleHTTPRequestHandler,
        directory=str(output_dir),
    )
    server = http.server.HTTPServer(("localhost", port), handler)
    print(f"Serving documentation at http://localhost:{port}/")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return SUCCESS


def _run_validate(args: argparse.Namespace, globals: GlobalOptions) -> int:
    """Run coverage and freshness validation, print reports, return exit code."""
    import sys
    import warnings
    from pathlib import Path

    from rivet_cli.exit_codes import GENERAL_ERROR, SUCCESS

    src_root = Path(__import__("rivet_cli").__file__).resolve().parent.parent  # type: ignore[arg-type]
    entries: list = []  # type: ignore[type-arg]
    remediation_warnings: list[str] = []

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")

        from rivet_cli.docs.extractors.api_extractor import PACKAGES, extract_package

        for pkg_name in PACKAGES:
            entries.extend(extract_package(src_root / pkg_name))

        from rivet_cli.docs.extractors.cli_extractor import extract_cli_reference

        entries.extend(extract_cli_reference())

        from rivet_cli.docs.extractors.config_extractor import extract_config_reference

        entries.extend(extract_config_reference())

        from rivet_cli.docs.extractors.error_extractor import extract_error_catalog

        entries.extend(extract_error_catalog([src_root / p for p in PACKAGES]))

        from rivet_cli.docs.extractors.plugin_extractor import extract_plugin_guide

        entries.extend(extract_plugin_guide())

        from rivet_cli.docs.extractors.dag_extractor import extract_dag_diagram

        entries.extend(extract_dag_diagram(globals.project_path))

        from rivet_cli.docs.extractors.architecture import get_architecture_guides

        entries.extend(get_architecture_guides())

    # Collect remediation warnings from extractor warnings
    for w in caught:
        msg = str(w.message)
        if "missing remediation" in msg:
            remediation_warnings.append(msg)
        print(f"rivet | WARN {w.message}", file=sys.stderr)

    # Coverage check
    from rivet_cli.docs.validators.coverage import check_coverage

    coverage = check_coverage(entries, threshold=args.threshold)

    # Freshness check
    from rivet_cli.docs.validators.freshness import check_freshness

    output_dir = Path(getattr(args, "output", "docs/_build/"))
    freshness = check_freshness(entries, output_dir)

    # Print coverage report
    print("=== Coverage Report ===")
    for r in coverage.results:
        status = "OK" if r.coverage_pct >= coverage.threshold else "FAIL"
        print(f"  {r.package}: {r.coverage_pct:.1f}% ({r.documented_symbols}/{r.total_symbols}) [{status}]")
        for sym in r.incomplete_symbols:
            print(f"    incomplete: {sym}")
    print(f"  Threshold: {coverage.threshold}%  Passed: {coverage.passed}")

    # Print freshness report
    print("=== Freshness Report ===")
    if freshness.stale_entries:
        for e in freshness.stale_entries:
            print(f"  STALE {e.ref_id} ({e.reason}) — {e.source_file}")
    else:
        print("  All documentation is fresh.")
    print(f"  Passed: {freshness.passed}")

    # Print remediation warnings
    if remediation_warnings:
        print("=== Missing Remediation ===")
        for w in remediation_warnings:  # type: ignore[assignment]
            print(f"  {w}")

    # Determine exit code
    ci = getattr(args, "ci", False)
    if ci and (not coverage.passed or not freshness.passed):
        return GENERAL_ERROR
    return SUCCESS
