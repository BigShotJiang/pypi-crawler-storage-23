"""Freshness detector — flags stale documentation by tracking signature hashes."""

from __future__ import annotations

import hashlib
import json
import logging
from pathlib import Path

from rivet_cli.docs.models import DocEntry, FreshnessReport, SignatureHash, StaleEntry

logger = logging.getLogger(__name__)

SIGNATURES_FILE = ".rivet-docs-signatures.json"


def _signature_string(entry: DocEntry) -> str:
    """Build a canonical string from a symbol's name, params, and return type."""
    params = ",".join(
        f"{p.name}:{p.type_hint or ''}" for p in entry.params
    )
    return f"{entry.name}({params})->{entry.returns or ''}"


def _compute_hash(entry: DocEntry) -> SignatureHash:
    sig = _signature_string(entry)
    h = hashlib.sha256(sig.encode()).hexdigest()
    return SignatureHash(ref_id=entry.ref_id, hash=h, source_file=entry.source_file or "")


def _load_stored_hashes(path: Path) -> dict[str, dict[str, str]] | None:
    """Load previously stored hashes. Returns None on missing file, raises on corrupt JSON."""
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text())
        if not isinstance(data, dict):
            raise ValueError("not a dict")
        return data
    except (json.JSONDecodeError, ValueError):
        logger.warning("Corrupt signature file %s — treating all docs as stale", path)
        raise


def _save_hashes(hashes: list[SignatureHash], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    data = {
        h.ref_id: {"hash": h.hash, "source_file": h.source_file}
        for h in hashes
    }
    path.write_text(json.dumps(data, indent=2, sort_keys=True))


def check_freshness(entries: list[DocEntry], docs_dir: Path) -> FreshnessReport:
    """Compare current signature hashes against stored ones and report staleness."""
    sig_path = docs_dir / SIGNATURES_FILE
    current = [_compute_hash(e) for e in entries]

    # Try loading stored hashes
    try:
        stored = _load_stored_hashes(sig_path)
    except (json.JSONDecodeError, ValueError):
        # Corrupt file → all stale
        stale = [
            StaleEntry(
                ref_id=h.ref_id,
                source_file=h.source_file,
                doc_file=str(sig_path),
                reason="signature_changed",
            )
            for h in current
        ]
        _save_hashes(current, sig_path)
        return FreshnessReport(stale_entries=stale, passed=len(stale) == 0)

    if stored is None:
        # First run — no baseline, everything is fresh
        _save_hashes(current, sig_path)
        return FreshnessReport(stale_entries=[], passed=True)

    stale: list[StaleEntry] = []  # type: ignore[no-redef]
    for h in current:
        prev = stored.get(h.ref_id)
        if prev is None:
            stale.append(StaleEntry(
                ref_id=h.ref_id,
                source_file=h.source_file,
                doc_file=str(sig_path),
                reason="new_symbol",
            ))
        elif prev.get("hash") != h.hash:
            stale.append(StaleEntry(
                ref_id=h.ref_id,
                source_file=h.source_file,
                doc_file=str(sig_path),
                reason="signature_changed",
            ))

    # Detect removed symbols
    current_ids = {h.ref_id for h in current}
    for ref_id, info in stored.items():
        if ref_id not in current_ids:
            stale.append(StaleEntry(
                ref_id=ref_id,
                source_file=info.get("source_file", ""),
                doc_file=str(sig_path),
                reason="removed_symbol",
            ))

    _save_hashes(current, sig_path)
    return FreshnessReport(stale_entries=stale, passed=len(stale) == 0)
