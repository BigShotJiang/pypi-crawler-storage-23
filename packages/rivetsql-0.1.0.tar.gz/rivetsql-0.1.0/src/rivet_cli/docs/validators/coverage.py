"""Coverage checker for documentation completeness.

Counts public symbols with/without docstrings per package and reports
incomplete docstrings (missing Args/Returns/Raises sections).
"""

from __future__ import annotations

from collections import defaultdict

from rivet_cli.docs.models import CoverageReport, CoverageResult, DocEntry

# Kinds that represent documentable symbols
_SYMBOL_KINDS = {"class", "function", "method"}


def _is_excluded(entry: DocEntry) -> bool:
    """Return True if entry should be excluded from coverage counts."""
    if entry.name.startswith("_"):
        return True
    sf = entry.source_file or ""
    if "__pycache__" in sf:
        return True
    # Exclude test files: paths containing /tests/ or /test_ or starting with test_
    parts = sf.replace("\\", "/").split("/")
    return any(part == "tests" or part.startswith("test_") for part in parts)


def _is_incomplete(entry: DocEntry) -> bool:
    """Return True if a documented symbol has an incomplete docstring.

    A docstring is incomplete when the symbol has parameters but the
    docstring lacks corresponding Args documentation, or when the symbol
    has a return type but lacks Returns documentation, or when the symbol
    raises exceptions but lacks Raises documentation.
    """
    if not entry.docstring:
        return False
    has_params = any(p.name != "self" for p in entry.params)
    if has_params and not any(p.description for p in entry.params if p.name != "self"):
        return True
    if entry.returns and entry.returns != "None" and "Returns:" not in entry.docstring and "Return:" not in entry.docstring:
        return True
    if entry.raises and "Raises:" not in entry.docstring and "Raise:" not in entry.docstring:
        return True
    return False


def check_coverage(
    entries: list[DocEntry], threshold: float = 80.0
) -> CoverageReport:
    """Check documentation coverage across packages.

    Args:
        entries: List of DocEntry objects from extractors.
        threshold: Minimum coverage percentage required (default 80%).

    Returns:
        CoverageReport with per-package results and pass/fail status.
    """
    by_package: dict[str, list[DocEntry]] = defaultdict(list)
    for entry in entries:
        if entry.kind not in _SYMBOL_KINDS:
            continue
        if _is_excluded(entry):
            continue
        pkg = entry.module.split(".")[0] if entry.module else ""
        by_package[pkg].append(entry)

    results: list[CoverageResult] = []
    for pkg in sorted(by_package):
        pkg_entries = by_package[pkg]
        total = len(pkg_entries)
        documented = sum(1 for e in pkg_entries if e.docstring)
        incomplete = [
            f"{e.source_file}::{e.name}" if e.source_file else e.name
            for e in pkg_entries
            if e.docstring and _is_incomplete(e)
        ]
        results.append(
            CoverageResult(
                package=pkg,
                total_symbols=total,
                documented_symbols=documented,
                incomplete_symbols=incomplete,
            )
        )

    passed = all(r.coverage_pct >= threshold for r in results) if results else True
    return CoverageReport(results=results, threshold=threshold, passed=passed)
