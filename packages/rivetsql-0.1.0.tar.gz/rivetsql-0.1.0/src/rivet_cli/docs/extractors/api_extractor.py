"""AST-based API extractor for Python modules.

Walks Python source files using ast.parse() to extract public classes,
functions, and methods with their docstrings, type hints, and signatures.
"""

from __future__ import annotations

import ast
import logging
import re
import warnings
from pathlib import Path
from typing import Any

from rivet_cli.docs.models import DocEntry, DocParam

logger = logging.getLogger(__name__)

# Packages to organize output by
PACKAGES = ("rivet_core", "rivet_config", "rivet_bridge", "rivet_cli")


def _unparse_annotation(node: ast.expr) -> str:
    """Convert an AST annotation node to a string."""
    return ast.unparse(node)


def _get_all_list(tree: ast.Module) -> list[str] | None:
    """Extract __all__ list from a module AST, or None if not present."""
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == "__all__":
                    if isinstance(node.value, (ast.List, ast.Tuple)):
                        return [
                            elt.value
                            for elt in node.value.elts
                            if isinstance(elt, ast.Constant) and isinstance(elt.value, str)
                        ]
    return None


def _is_public(name: str) -> bool:
    """Return True if name is public (not prefixed with _)."""
    return not name.startswith("_")


def _parse_google_docstring(docstring: str) -> dict[str, Any]:
    """Parse a Google-style docstring into structured sections.

    Returns dict with keys: description, args, returns, raises.
    """
    result: dict[str, Any] = {"description": "", "args": [], "returns": None, "raises": []}
    lines = docstring.split("\n")

    current_section: str | None = None
    buffer: list[str] = []

    section_map = {
        "args:": "args",
        "arguments:": "args",
        "parameters:": "args",
        "returns:": "returns",
        "return:": "returns",
        "raises:": "raises",
        "raise:": "raises",
    }

    def _flush() -> None:
        nonlocal current_section, buffer
        if current_section == "args":
            _parse_args_block(buffer, result)
        elif current_section == "returns":
            result["returns"] = " ".join(line.strip() for line in buffer if line.strip())
        elif current_section == "raises":
            _parse_raises_block(buffer, result)
        elif current_section is None:
            desc = "\n".join(buffer).strip()
            if desc:
                result["description"] = desc
        buffer = []

    for line in lines:
        stripped = line.strip().lower()
        if stripped in section_map:
            _flush()
            current_section = section_map[stripped]
            len(line) - len(line.lstrip())
        else:
            buffer.append(line)

    _flush()
    return result


def _parse_args_block(lines: list[str], result: dict[str, Any]) -> None:
    """Parse an Args block into DocParam-compatible dicts."""
    # Pattern: "name (type): description" or "name: description"
    param_re = re.compile(r"^\s+(\*{0,2}\w+)\s*(?:\(([^)]+)\))?\s*:\s*(.*)")
    current: dict[str, str | None] | None = None

    for line in lines:
        m = param_re.match(line)
        if m:
            if current is not None:
                result["args"].append(current)
            current = {
                "name": m.group(1),
                "type_hint": m.group(2),
                "description": m.group(3).strip() if m.group(3) else None,
            }
        elif current is not None and line.strip():
            # Continuation line
            desc = current.get("description") or ""
            current["description"] = (desc + " " + line.strip()).strip()

    if current is not None:
        result["args"].append(current)


def _parse_raises_block(lines: list[str], result: dict[str, Any]) -> None:
    """Parse a Raises block into a list of exception type strings."""
    raises_re = re.compile(r"^\s+(\w+)\s*:")
    for line in lines:
        m = raises_re.match(line)
        if m:
            result["raises"].append(m.group(1))


def _extract_function(
    node: ast.FunctionDef | ast.AsyncFunctionDef,
    module_path: str,
    package: str,
    source_file: str,
    parent_ref: str | None = None,
) -> DocEntry:
    """Extract a DocEntry from a function/method AST node."""
    kind = "method" if parent_ref else "function"
    ref_id = f"{module_path}.{node.name}" if not parent_ref else f"{parent_ref}.{node.name}"

    docstring = ast.get_docstring(node)
    parsed = _parse_google_docstring(docstring) if docstring else {"args": [], "returns": None, "raises": []}

    # Build params from AST arguments
    params = _extract_params(node, parsed)

    # Return type from annotation
    returns = _unparse_annotation(node.returns) if node.returns else parsed.get("returns")

    # Build signature
    sig = _build_signature(node)

    if not docstring:
        warnings.warn(f"Missing docstring: {ref_id}", stacklevel=2)

    return DocEntry(
        ref_id=ref_id,
        kind=kind,
        name=node.name,
        module=module_path,
        signature=sig,
        docstring=docstring if docstring else f"No documentation available for {node.name}.",
        params=params,
        returns=returns,
        raises=parsed.get("raises", []),
        parent=parent_ref,
        tags=["api"],
        source_file=source_file,
        source_line=node.lineno,
        metadata={"is_async": isinstance(node, ast.AsyncFunctionDef)},
    )


def _extract_params(
    node: ast.FunctionDef | ast.AsyncFunctionDef,
    parsed_doc: dict[str, Any],
) -> list[DocParam]:
    """Extract parameters from function AST node, merging with docstring info."""
    params: list[DocParam] = []
    args = node.args

    # Map docstring arg descriptions by name
    doc_args = {a["name"]: a for a in parsed_doc.get("args", [])}

    # Calculate defaults offset
    num_args = len(args.args)
    num_defaults = len(args.defaults)
    default_offset = num_args - num_defaults

    for i, arg in enumerate(args.args):
        if arg.arg == "self" or arg.arg == "cls":
            continue
        type_hint = _unparse_annotation(arg.annotation) if arg.annotation else None
        doc_info = doc_args.get(arg.arg, {})
        # Prefer AST type hint, fall back to docstring type
        if type_hint is None:
            type_hint = doc_info.get("type_hint")

        default = None
        default_idx = i - default_offset
        if default_idx >= 0 and default_idx < num_defaults:
            default = ast.unparse(args.defaults[default_idx])

        params.append(DocParam(
            name=arg.arg,
            type_hint=type_hint,
            default=default,
            description=doc_info.get("description"),
        ))

    # *args
    if args.vararg:
        arg = args.vararg
        type_hint = _unparse_annotation(arg.annotation) if arg.annotation else None
        doc_info = doc_args.get(f"*{arg.arg}", {})
        params.append(DocParam(name=f"*{arg.arg}", type_hint=type_hint, description=doc_info.get("description")))

    # keyword-only args
    for i, arg in enumerate(args.kwonlyargs):
        type_hint = _unparse_annotation(arg.annotation) if arg.annotation else None
        doc_info = doc_args.get(arg.arg, {})
        if type_hint is None:
            type_hint = doc_info.get("type_hint")
        default = None
        if i < len(args.kw_defaults) and args.kw_defaults[i] is not None:
            default = ast.unparse(args.kw_defaults[i])  # type: ignore[arg-type]
        params.append(DocParam(
            name=arg.arg,
            type_hint=type_hint,
            default=default,
            description=doc_info.get("description"),
        ))

    # **kwargs
    if args.kwarg:
        arg = args.kwarg
        type_hint = _unparse_annotation(arg.annotation) if arg.annotation else None
        doc_info = doc_args.get(f"**{arg.arg}", {})
        params.append(DocParam(name=f"**{arg.arg}", type_hint=type_hint, description=doc_info.get("description")))

    return params


def _build_signature(node: ast.FunctionDef | ast.AsyncFunctionDef) -> str:
    """Build a human-readable signature string from a function AST node."""
    parts: list[str] = []
    args = node.args

    for i, arg in enumerate(args.args):
        p = arg.arg
        if arg.annotation:
            p += f": {ast.unparse(arg.annotation)}"
        default_idx = i - (len(args.args) - len(args.defaults))
        if default_idx >= 0 and default_idx < len(args.defaults):
            p += f" = {ast.unparse(args.defaults[default_idx])}"
        parts.append(p)

    if args.vararg:
        p = f"*{args.vararg.arg}"
        if args.vararg.annotation:
            p += f": {ast.unparse(args.vararg.annotation)}"
        parts.append(p)
    elif args.kwonlyargs:
        parts.append("*")

    for i, arg in enumerate(args.kwonlyargs):
        p = arg.arg
        if arg.annotation:
            p += f": {ast.unparse(arg.annotation)}"
        if i < len(args.kw_defaults) and args.kw_defaults[i] is not None:
            p += f" = {ast.unparse(args.kw_defaults[i])}"  # type: ignore[arg-type]
        parts.append(p)

    if args.kwarg:
        p = f"**{args.kwarg.arg}"
        if args.kwarg.annotation:
            p += f": {ast.unparse(args.kwarg.annotation)}"
        parts.append(p)

    ret = ""
    if node.returns:
        ret = f" -> {ast.unparse(node.returns)}"

    prefix = "async def" if isinstance(node, ast.AsyncFunctionDef) else "def"
    return f"{prefix} {node.name}({', '.join(parts)}){ret}"


def _extract_class(
    node: ast.ClassDef,
    module_path: str,
    package: str,
    source_file: str,
) -> list[DocEntry]:
    """Extract DocEntry for a class and its public methods."""
    ref_id = f"{module_path}.{node.name}"
    docstring = ast.get_docstring(node)

    bases = [ast.unparse(b) for b in node.bases]
    is_abc = any("ABC" in b for b in bases)

    children: list[str] = []
    entries: list[DocEntry] = []

    # Extract __init__ params for the class entry
    init_params: list[DocParam] = []
    for item in node.body:
        if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if item.name == "__init__":
                parsed = _parse_google_docstring(ast.get_docstring(item) or "")
                init_params = _extract_params(item, parsed)
            if _is_public(item.name) or item.name == "__init__":
                method_entry = _extract_function(item, module_path, package, source_file, parent_ref=ref_id)
                children.append(method_entry.ref_id)
                entries.append(method_entry)

    if not docstring:
        warnings.warn(f"Missing docstring: {ref_id}", stacklevel=2)

    class_entry = DocEntry(
        ref_id=ref_id,
        kind="class",
        name=node.name,
        module=module_path,
        signature=f"class {node.name}({', '.join(bases)})" if bases else f"class {node.name}",
        docstring=docstring if docstring else f"No documentation available for {node.name}.",
        params=init_params,
        children=[c for c in children],
        tags=["api"],
        source_file=source_file,
        source_line=node.lineno,
        metadata={"bases": bases, "is_abc": is_abc},
    )

    return [class_entry] + entries


def extract_module(module_path: Path, package: str) -> list[DocEntry]:
    """Extract DocEntry list from a single Python module file.

    Args:
        module_path: Path to the .py file.
        package: Package name (e.g. "rivet_core").

    Returns:
        List of DocEntry objects for public symbols in the module.
    """
    source_file = str(module_path)
    try:
        source = module_path.read_text(encoding="utf-8")
    except OSError as e:
        logger.error("Failed to read %s: %s", module_path, e)
        return []

    try:
        tree = ast.parse(source, filename=str(module_path))
    except SyntaxError as e:
        logger.error("%s:%s: SyntaxError: %s", module_path, e.lineno, e.msg)
        return []

    all_list = _get_all_list(tree)

    # Determine module dotted path
    mod_name = module_path.stem
    if mod_name == "__init__":
        dotted = package
    else:
        dotted = f"{package}.{mod_name}"

    entries: list[DocEntry] = []

    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.ClassDef):
            if all_list is not None and node.name not in all_list:
                continue
            if all_list is None and not _is_public(node.name):
                continue
            entries.extend(_extract_class(node, dotted, package, source_file))

        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if all_list is not None and node.name not in all_list:
                continue
            if all_list is None and not _is_public(node.name):
                continue
            entries.append(_extract_function(node, dotted, package, source_file))

    return entries


def extract_package(package_root: Path) -> list[DocEntry]:
    """Walk all modules in a package and extract DocEntry objects.

    Args:
        package_root: Root directory of the package.

    Returns:
        List of DocEntry objects for all public symbols in the package.
    """
    if not package_root.is_dir():
        logger.warning("Package directory not found: %s", package_root)
        return []

    package = package_root.name
    entries: list[DocEntry] = []

    for py_file in sorted(package_root.rglob("*.py")):
        rel_parts = py_file.relative_to(package_root).parts
        if "__pycache__" in rel_parts:
            continue
        if py_file.name.startswith("test_"):
            continue

        # Build the dotted package name for this file's parent directory
        rel_dir = py_file.relative_to(package_root).parent
        pkg_name = package if not rel_dir.parts else f"{package}.{'.'.join(rel_dir.parts)}"

        entries.extend(extract_module(py_file, pkg_name))

    return entries
