"""CLI reference extractor — introspects argparse parser tree."""

from __future__ import annotations

import argparse

from rivet_cli.docs.models import DocEntry, DocParam

_ENV_OVERRIDES: dict[str, str] = {
    "--profile": "RIVET_PROFILE",
    "--project": "RIVET_PROJECT",
    "--no-color": "RIVET_NO_COLOR",
}


def _extract_params(parser: argparse.ArgumentParser) -> list[DocParam]:
    """Extract arguments/flags from a parser as DocParam entries."""
    params: list[DocParam] = []
    for action in parser._actions:
        if isinstance(action, (argparse._HelpAction, argparse._VersionAction, argparse._SubParsersAction)):
            continue
        name = action.option_strings[0] if action.option_strings else action.dest
        type_hint = action.type.__name__ if action.type else None  # type: ignore[union-attr]
        if isinstance(action, (argparse._StoreTrueAction, argparse._StoreFalseAction)):
            type_hint = "bool"
        elif isinstance(action, argparse._CountAction):
            type_hint = "int"
        elif isinstance(action, argparse.BooleanOptionalAction):
            type_hint = "bool"
        default = repr(action.default) if action.default is not None else None
        desc = action.help or None
        if action.choices:
            desc = f"{desc} (choices: {', '.join(str(c) for c in action.choices)})" if desc else f"choices: {', '.join(str(c) for c in action.choices)}"
        env = _ENV_OVERRIDES.get(name)
        if env:
            desc = f"{desc} [env: {env}]" if desc else f"[env: {env}]"
        params.append(DocParam(name=name, type_hint=type_hint, default=default, description=desc))
    return params


def _walk_parser(
    parser: argparse.ArgumentParser,
    parent_ref: str | None,
    entries: list[DocEntry],
) -> None:
    """Recursively walk a parser tree, producing DocEntry per command."""
    prog = parser.prog or ""
    # ref_id: "cli.rivet" -> "cli.compile" -> "cli.catalog.list"
    parts = prog.split()
    ref_id = "cli." + ".".join(parts[1:]) if len(parts) > 1 else "cli"

    # Find child subparsers
    child_refs: list[str] = []
    sub_actions: list[argparse._SubParsersAction] = [  # type: ignore[type-arg]
        a for a in parser._actions if isinstance(a, argparse._SubParsersAction)
    ]
    for sub_action in sub_actions:
        for name, _sub_parser in (sub_action._name_parser_map or {}).items():
            child_ref = f"{ref_id}.{name}"
            child_refs.append(child_ref)

    entries.append(
        DocEntry(
            ref_id=ref_id,
            kind="cli_command",
            name=prog,
            module="cli",
            signature=prog,
            docstring=parser.description,
            params=_extract_params(parser),
            parent=parent_ref,
            children=child_refs,
            tags=["cli"],
        )
    )

    # Recurse into subcommands
    for sub_action in sub_actions:
        for _name, sub_parser in (sub_action._name_parser_map or {}).items():
            _walk_parser(sub_parser, parent_ref=ref_id, entries=entries)


def extract_cli_reference() -> list[DocEntry]:
    """Extract CLI reference documentation from the argparse parser tree."""
    from rivet_cli.app import build_parser

    parser = build_parser()
    entries: list[DocEntry] = []
    _walk_parser(parser, parent_ref=None, entries=entries)

    # Add global options entry with env var overrides
    global_params = [
        DocParam(name="RIVET_PROFILE", description="Override the active profile name"),
        DocParam(name="RIVET_PROJECT", description="Override the project directory path"),
        DocParam(name="RIVET_NO_COLOR", type_hint="bool", description="Set to '1' to disable colored output"),
    ]
    entries.append(
        DocEntry(
            ref_id="cli.global_options",
            kind="cli_command",
            name="Global Options",
            module="cli",
            docstring="Environment variable overrides for global CLI options.",
            params=global_params,
            tags=["cli"],
        )
    )

    return entries
