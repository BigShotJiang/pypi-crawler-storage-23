"""DAG extractor: generates Mermaid diagrams from compiled assemblies."""

from __future__ import annotations

import logging
from pathlib import Path

from rivet_cli.docs.models import DocEntry

logger = logging.getLogger(__name__)


def extract_dag_diagram(project_root: Path | None = None) -> list[DocEntry]:
    """Extract DAG diagram from a Rivet project.

    When *project_root* points to a valid Rivet project, the project is
    compiled and its DAG is rendered as a Mermaid diagram wrapped in a
    ``DocEntry`` with ``kind="diagram"``.

    Returns an empty list when no project is available or compilation fails.
    """
    if project_root is None:
        return []

    try:
        compiled = _compile_project(project_root)
    except Exception:
        logger.warning("Could not compile project at %s for DAG extraction.", project_root)
        return []

    if compiled is None or not compiled.success or not compiled.joints:
        return []

    from rivet_cli.rendering.mermaid import render_mermaid

    mermaid_src = render_mermaid(compiled)

    return [
        DocEntry(
            ref_id="diagram.project_dag",
            kind="diagram",
            name="Project DAG",
            module="dag",
            docstring=mermaid_src,
            tags=["diagram"],
            source_file=str(project_root),
            metadata={"format": "mermaid"},
        )
    ]


def _compile_project(project_root: Path):  # type: ignore[no-untyped-def]
    """Load config, build assembly, and compile."""
    from rivet_bridge import build_assembly, register_optional_plugins
    from rivet_config import load_config
    from rivet_core import PluginRegistry, compile

    config_result = load_config(project_root, strict=False)
    if not config_result.success or config_result.profile is None:
        return None

    registry = PluginRegistry()
    registry.register_builtins()
    register_optional_plugins(registry)

    bridge_result = build_assembly(config_result, registry)

    return compile(
        assembly=bridge_result.assembly,
        catalogs=list(bridge_result.catalogs.values()),
        engines=list(bridge_result.engines.values()),
        registry=registry,
    )
