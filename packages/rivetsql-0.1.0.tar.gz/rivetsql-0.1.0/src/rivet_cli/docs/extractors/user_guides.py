"""User guide templates: getting started, declaration styles, testing, and REPL."""

from __future__ import annotations

from rivet_cli.docs.models import DocEntry

_GETTING_STARTED = """\
This guide walks you through installing Rivet, creating your first project, and running
a pipeline end-to-end.

## Installation

Install Rivet from PyPI:

```bash
pip install rivet-sql
```

Verify the installation:

```bash
rivet --version
```

## Initialize a Project

Create a new Rivet project with `rivet init`:

```bash
rivet init my-project
cd my-project
```

This scaffolds the standard project layout.

## Project Structure

A Rivet project follows this directory layout:

```
my-project/
├── rivet.yaml          # Project manifest (name, version, default profile)
├── profiles.yaml       # Catalog and engine configuration per profile
├── sources/            # Source joint declarations (data ingestion)
├── joints/             # Transform joint declarations (SQL transformations)
├── sinks/              # Sink joint declarations (data output)
└── tests/              # Test fixtures and assertions
```

- `rivet.yaml` defines the project name and default profile.
- `profiles.yaml` configures catalogs (where data lives) and engines (how SQL runs).
- `sources/`, `joints/`, and `sinks/` contain your pipeline declarations.
- `tests/` holds test fixtures for `rivet test`.

## Running Your First Pipeline

1. Define a source in `sources/raw_data.sql`:

```sql
-- @rivet source
-- @catalog my_catalog
SELECT * FROM raw_table
```

2. Define a transform in `joints/cleaned.sql`:

```sql
-- @rivet joint
-- @upstream raw_data
SELECT id, TRIM(name) AS name FROM raw_data WHERE id IS NOT NULL
```

3. Run the pipeline:

```bash
rivet run
```

Rivet compiles the DAG, resolves dependencies, and executes joints in order.
"""

_DECLARATION_STYLES = """\
Rivet supports three ways to declare joints: SQL annotations, YAML declarations, and
mixed mode. Choose the style that fits your workflow.

## SQL Annotations

Embed metadata directly in SQL files using `-- @rivet` comment annotations:

```sql
-- @rivet joint
-- @upstream source_a
-- @upstream source_b
-- @description Joins source_a and source_b on id
SELECT a.id, a.name, b.value
FROM source_a a
JOIN source_b b ON a.id = b.id
```

Supported annotations:
- `@rivet source | joint | sink` — declares the joint kind.
- `@upstream <name>` — declares an upstream dependency (repeatable).
- `@catalog <name>` — specifies the target catalog.
- `@description <text>` — human-readable description.
- `@tags <tag1, tag2>` — comma-separated tags for filtering.

## YAML Declarations

Define joints in YAML files for a configuration-driven approach:

```yaml
name: cleaned_data
kind: joint
upstream:
  - raw_data
catalog: my_catalog
description: Clean and normalize raw data
sql: |
  SELECT id, TRIM(name) AS name
  FROM raw_data
  WHERE id IS NOT NULL
```

YAML declarations support the same fields as SQL annotations and are useful when you
want to separate metadata from SQL logic.

## Mixed Mode

Combine both styles in the same project. SQL annotations take precedence when a joint
is defined in both formats. Use mixed mode to keep simple transforms as annotated SQL
and complex multi-step pipelines as YAML.

Place SQL files in `sources/`, `joints/`, or `sinks/` and YAML files alongside them.
Rivet merges declarations from both formats during compilation.
"""

_TESTING_FRAMEWORK = """\
Rivet includes a built-in testing framework for validating pipeline logic without
writing to real targets.

## Test Fixture Format

Test fixtures live in the `tests/` directory. Each fixture is a directory containing
input data files and expected output:

```
tests/
└── test_cleaned/
    ├── input/
    │   └── raw_data.csv      # Input fixture data
    └── expected/
        └── cleaned.csv       # Expected output
```

Input files provide data for source joints. Expected files define the correct output
for comparison.

## Running Tests

Run all tests with:

```bash
rivet test
```

Run a specific test:

```bash
rivet test test_cleaned
```

Rivet compiles the pipeline, substitutes fixture data for sources, executes transforms,
and compares results against expected output.

## Snapshot Testing

Generate snapshots of joint output for regression testing:

```bash
rivet test --update-snapshots
```

This writes current output as the new expected baseline. Subsequent runs compare against
these snapshots.

## Assertions and Audits in Tests

Configure assertions and audits in your test fixtures to validate data quality:

- **Assertions** run before writes and block on failure — use them for row-level checks.
- **Audits** run after writes and verify the persisted result — use them for aggregate checks.

Both mechanisms integrate with `rivet test` and report failures with actionable messages
including the joint name, check description, and failing rows or conditions.
"""

_REPL_GUIDE = """\
The Rivet REPL provides an interactive environment for exploring data, running queries,
and browsing catalogs.

## Starting the REPL

Launch the REPL with:

```bash
rivet repl
```

Optionally specify a profile:

```bash
rivet repl --profile dev
```

The REPL loads your project configuration and connects to the configured catalogs.

## Query Execution

Run SQL queries interactively:

```
rivet> SELECT * FROM my_catalog.raw_table LIMIT 10
```

Results display as formatted tables. The REPL uses the compute engine configured in
your active profile.

## Catalog Browsing

List available catalogs and their contents:

```
rivet> SHOW CATALOGS
rivet> SHOW TABLES IN my_catalog
rivet> DESCRIBE my_catalog.raw_table
```

These commands introspect the catalog metadata without executing full queries.

## Export

Export query results to files:

```
rivet> EXPORT SELECT * FROM my_catalog.raw_table TO 'output.csv'
```

Supported formats include CSV, Parquet, and JSON. The export command writes results
directly to the specified path.
"""


def get_user_guides() -> list[DocEntry]:
    """Return user guide DocEntry objects for rendering."""
    return [
        DocEntry(
            ref_id="guide.getting-started",
            kind="guide",
            name="Getting Started",
            module="user-guides",
            docstring=_GETTING_STARTED,
            tags=["guide", "user-guides"],
        ),
        DocEntry(
            ref_id="guide.declaration-styles",
            kind="guide",
            name="Declaration Styles: SQL, YAML, and Mixed Mode",
            module="user-guides",
            docstring=_DECLARATION_STYLES,
            tags=["guide", "user-guides"],
        ),
        DocEntry(
            ref_id="guide.testing-framework",
            kind="guide",
            name="Testing Framework",
            module="user-guides",
            docstring=_TESTING_FRAMEWORK,
            tags=["guide", "user-guides"],
        ),
        DocEntry(
            ref_id="guide.repl",
            kind="guide",
            name="Interactive REPL",
            module="user-guides",
            docstring=_REPL_GUIDE,
            tags=["guide", "user-guides"],
        ),
    ]
