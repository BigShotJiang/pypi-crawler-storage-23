"""Plugin extractor: introspects plugin ABCs and built-in implementations."""

from __future__ import annotations

import inspect
import logging
from typing import get_type_hints

from rivet_cli.docs.models import DocEntry, DocParam

logger = logging.getLogger(__name__)

_ENTRY_POINT_GROUPS: dict[str, str] = {
    "CatalogPlugin": "rivet.catalogs",
    "ComputeEnginePlugin": "rivet.compute_engines",
    "ComputeEngineAdapter": "rivet.compute_engine_adapters",
    "SourcePlugin": "rivet.sources",
    "SinkPlugin": "rivet.sinks",
}

_PYPROJECT_TEMPLATE = """\
[project.entry-points."rivet.{group}"]
my_plugin = "my_package:MyPlugin"\
"""


def _get_abstract_methods(cls: type) -> list[str]:
    """Return names of abstract methods defined directly on *cls*."""
    return sorted(
        name
        for name, obj in vars(cls).items()
        if getattr(obj, "__isabstractmethod__", False)
    )


def _get_required_attributes(cls: type) -> list[str]:
    """Return class-level annotation names that look like required attributes."""
    hints = {}
    try:
        hints = get_type_hints(cls)
    except Exception:
        hints = getattr(cls, "__annotations__", {})
    return sorted(
        name for name in hints if not name.startswith("_") and name not in vars(cls)
    )


def _method_params(cls: type, method_name: str) -> list[DocParam]:
    """Extract DocParam list from a method's signature."""
    method = getattr(cls, method_name, None)
    if method is None:
        return []
    try:
        sig = inspect.signature(method)
    except (ValueError, TypeError):
        return []
    params: list[DocParam] = []
    for pname, param in sig.parameters.items():
        if pname == "self":
            continue
        type_hint = str(param.annotation) if param.annotation is not inspect.Parameter.empty else None
        default = repr(param.default) if param.default is not inspect.Parameter.empty else None
        params.append(DocParam(name=pname, type_hint=type_hint, default=default))
    return params


def _method_return(cls: type, method_name: str) -> str | None:
    """Extract return annotation string from a method."""
    method = getattr(cls, method_name, None)
    if method is None:
        return None
    try:
        sig = inspect.signature(method)
    except (ValueError, TypeError):
        return None
    if sig.return_annotation is inspect.Signature.empty:
        return None
    return str(sig.return_annotation)


def _extract_abc(cls: type) -> list[DocEntry]:
    """Produce DocEntry nodes for a single plugin ABC."""
    cls_name = cls.__name__
    ref_id = f"plugin.{cls_name}"
    abstract_methods = _get_abstract_methods(cls)
    required_attrs = _get_required_attributes(cls)
    entry_group = _ENTRY_POINT_GROUPS.get(cls_name, "")

    # Attribute params
    attr_params = [DocParam(name=a, description="Required attribute.") for a in required_attrs]

    children = [f"{ref_id}.{m}" for m in abstract_methods]

    entries: list[DocEntry] = [
        DocEntry(
            ref_id=ref_id,
            kind="plugin_abc",
            name=cls_name,
            module="rivet_core.plugins",
            docstring=inspect.getdoc(cls),
            params=attr_params,
            children=children,
            tags=["plugin"],
            metadata={
                "entry_point_group": entry_group,
                "pyproject_example": _PYPROJECT_TEMPLATE.format(group=entry_group) if entry_group else "",
                "abstract_methods": abstract_methods,
                "required_attributes": required_attrs,
                "import_boundary": "Plugins import only rivet_core public API.",
            },
        )
    ]

    # One child entry per abstract method
    for method_name in abstract_methods:
        method = getattr(cls, method_name, None)
        entries.append(
            DocEntry(
                ref_id=f"{ref_id}.{method_name}",
                kind="method",
                name=method_name,
                module="rivet_core.plugins",
                signature=f"{cls_name}.{method_name}{inspect.signature(method)}" if method else None,
                docstring=inspect.getdoc(method),
                params=_method_params(cls, method_name),
                returns=_method_return(cls, method_name),
                parent=ref_id,
                tags=["plugin"],
            )
        )

    return entries


def _discover_builtins(abc_cls: type) -> list[DocEntry]:
    """Find built-in subclasses and produce reference example entries."""
    entries: list[DocEntry] = []
    for sub in abc_cls.__subclasses__():
        # Skip other ABCs
        if inspect.isabstract(sub):
            continue
        ref_id = f"plugin.builtin.{sub.__name__}"
        entries.append(
            DocEntry(
                ref_id=ref_id,
                kind="class",
                name=sub.__name__,
                module=sub.__module__,
                docstring=inspect.getdoc(sub),
                parent=f"plugin.{abc_cls.__name__}",
                tags=["plugin", "builtin"],
                source_file=inspect.getfile(sub) if hasattr(sub, "__module__") else None,
                metadata={"base_abc": abc_cls.__name__},
            )
        )
    return entries


def extract_plugin_guide() -> list[DocEntry]:
    """Extract plugin development guide documentation from plugin ABCs."""
    from rivet_core.plugins import (
        CatalogPlugin,
        ComputeEngineAdapter,
        ComputeEnginePlugin,
        SinkPlugin,
        SourcePlugin,
    )

    # Force built-in imports so subclasses are visible
    try:
        from rivet_core.plugins import PluginRegistry
        reg = PluginRegistry()
        reg.register_builtins()
    except Exception:
        logger.debug("Could not load built-in plugins for subclass discovery.")

    abcs = [CatalogPlugin, ComputeEnginePlugin, ComputeEngineAdapter, SourcePlugin, SinkPlugin]
    entries: list[DocEntry] = []

    for abc_cls in abcs:
        entries.extend(_extract_abc(abc_cls))
        entries.extend(_discover_builtins(abc_cls))

    # Entry point registration guide
    groups_doc = "\n".join(
        f"- {group}: register a {name}" for name, group in _ENTRY_POINT_GROUPS.items()
    )
    entries.append(
        DocEntry(
            ref_id="plugin.entry_points",
            kind="guide",
            name="Plugin Entry Points",
            module="rivet_core.plugins",
            docstring=(
                "Plugins are discovered via Python entry point groups.\n\n"
                f"{groups_doc}\n\n"
                "Example pyproject.toml:\n"
                '[project.entry-points."rivet.catalogs"]\n'
                'my_catalog = "my_package:MyCatalogPlugin"'
            ),
            tags=["plugin", "guide"],
            metadata={"entry_point_groups": {v: k for k, v in _ENTRY_POINT_GROUPS.items()}},
        )
    )

    # Import boundary rule
    entries.append(
        DocEntry(
            ref_id="plugin.import_boundary",
            kind="guide",
            name="Plugin Import Boundary",
            module="rivet_core.plugins",
            docstring=(
                "Plugins must import only from rivet_core public API. "
                "No plugin imports another plugin. "
                "No plugin imports rivet_config or rivet_bridge."
            ),
            tags=["plugin", "guide"],
        )
    )

    return entries
