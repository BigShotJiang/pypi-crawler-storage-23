"""Config extractor: documents rivet.yaml and profiles.yaml schemas."""

from __future__ import annotations

import dataclasses
import logging
from typing import Any

from rivet_cli.docs.models import DocEntry, DocParam

logger = logging.getLogger(__name__)


def _type_name(val: Any) -> str:
    """Return a human-readable type string for a value."""
    if val is None:
        return "str"
    return type(val).__name__


def _extract_dataclass_fields(cls: type, ref_prefix: str, module: str) -> list[DocEntry]:
    """Extract DocEntry objects for each field of a frozen dataclass."""
    entries: list[DocEntry] = []
    for f in dataclasses.fields(cls):
        type_hint = str(f.type) if f.type is not dataclasses.MISSING else None
        default = None
        if f.default is not dataclasses.MISSING:
            default = repr(f.default)
        elif f.default_factory is not dataclasses.MISSING:
            default = repr(f.default_factory())
        entries.append(DocEntry(
            ref_id=f"{ref_prefix}.{f.name}",
            kind="config_key",
            name=f.name,
            module=module,
            docstring=f"Configuration key '{f.name}'.",
            params=[DocParam(name=f.name, type_hint=type_hint, default=default, description=None)],
            tags=["config"],
            metadata={"type": type_hint, "default": default},
        ))
    return entries


def _extract_plugin_options(registry: Any) -> list[DocEntry]:
    """Extract config entries from registered CatalogPlugin and ComputeEnginePlugin instances."""
    entries: list[DocEntry] = []

    for cat_type, plugin in sorted(registry._catalog_plugins.items()):
        prefix = f"config.profiles.catalogs.{cat_type}"
        for opt in getattr(plugin, "required_options", []):
            entries.append(DocEntry(
                ref_id=f"{prefix}.{opt}",
                kind="config_key",
                name=opt,
                module=f"profiles.yaml catalogs.{cat_type}",
                docstring=f"Required option for {cat_type} catalog.",
                params=[DocParam(name=opt, type_hint="str", default=None, description="Required.")],
                tags=["config", "plugin"],
                metadata={"required": True, "catalog_type": cat_type},
            ))
        for opt, default in sorted(getattr(plugin, "optional_options", {}).items()):
            entries.append(DocEntry(
                ref_id=f"{prefix}.{opt}",
                kind="config_key",
                name=opt,
                module=f"profiles.yaml catalogs.{cat_type}",
                docstring=f"Optional option for {cat_type} catalog.",
                params=[DocParam(
                    name=opt,
                    type_hint=_type_name(default),
                    default=repr(default),
                    description="Optional.",
                )],
                tags=["config", "plugin"],
                metadata={"required": False, "catalog_type": cat_type, "default": default},
            ))
        for opt in getattr(plugin, "credential_options", []):
            entries.append(DocEntry(
                ref_id=f"{prefix}.credentials.{opt}",
                kind="config_key",
                name=opt,
                module=f"profiles.yaml catalogs.{cat_type}",
                docstring=f"Credential option for {cat_type} catalog.",
                params=[DocParam(name=opt, type_hint="str", default=None, description="Credential.")],
                tags=["config", "plugin", "credential"],
                metadata={"credential": True, "catalog_type": cat_type},
            ))

    for eng_type, plugin in sorted(registry._engine_plugins.items()):
        caps = getattr(plugin, "supported_catalog_types", {})
        if caps:
            entries.append(DocEntry(
                ref_id=f"config.engines.{eng_type}.supported_catalog_types",
                kind="config_key",
                name=f"{eng_type} supported catalog types",
                module=f"profiles.yaml engines.{eng_type}",
                docstring=f"Catalog types supported by the {eng_type} engine and their capabilities.",
                tags=["config", "plugin", "engine"],
                metadata={"engine_type": eng_type, "supported_catalog_types": caps},
            ))

    return entries


def extract_config_reference() -> list[DocEntry]:
    """Extract configuration reference documentation for rivet.yaml and profiles.yaml."""
    from rivet_config.models import (
        CatalogConfig,
        EngineConfig,
        ProjectManifest,
        ResolvedProfile,
    )
    from rivet_core.plugins import PluginRegistry

    entries: list[DocEntry] = []

    # rivet.yaml keys from ProjectManifest
    entries.extend(_extract_dataclass_fields(
        ProjectManifest, "config.rivet_yaml", "rivet.yaml",
    ))

    # profiles.yaml structure
    entries.extend(_extract_dataclass_fields(
        ResolvedProfile, "config.profiles", "profiles.yaml",
    ))
    entries.extend(_extract_dataclass_fields(
        CatalogConfig, "config.profiles.catalog", "profiles.yaml catalogs",
    ))
    entries.extend(_extract_dataclass_fields(
        EngineConfig, "config.profiles.engine", "profiles.yaml engines",
    ))

    # Plugin options from registry
    try:
        registry = PluginRegistry()
        registry.register_builtins()
        registry.discover_plugins()
    except Exception:
        logger.warning("Failed to initialize plugin registry; skipping plugin options.")
    else:
        entries.extend(_extract_plugin_options(registry))

    return entries
