"""Architecture doc templates: static guide content for Rivet's core architecture."""

from __future__ import annotations

from rivet_cli.docs.models import DocEntry

_CORE_CONCEPTS = """\
Rivet separates **what** to compute, **how** to compute it, and **where** data lives.

## Joints (What)

A Joint declares a named computation — a SQL query, a source, or a sink. Joints do not
execute logic themselves; they are pure declarations that form the nodes of the pipeline DAG.

- **Source joints** have no upstream dependencies and represent external data ingestion.
- **Sink joints** have upstream dependencies and represent data output destinations.
- **Transform joints** sit between sources and sinks, declaring SQL transformations.

Each joint is uniquely named within an assembly. Joints may declare schema, tags, and
descriptions without changing execution semantics.

## ComputeEngines (How)

A ComputeEngine decides how to execute the SQL declared by joints. Engines are deterministic
and do not perform introspection. Adjacent joints on the same engine instance are fused by
default unless an explicit boundary requires otherwise.

## Catalogs (Where)

A Catalog decides where data lives — file systems, databases, object stores. Catalog names
are globally unique, the `type` field is required, and configuration is opaque to core
(validated by the plugin or built-in implementation).

## Assembly

An Assembly is the collection of all joints, engines, and catalogs for a project. After
compilation it becomes a `CompiledAssembly` — the single immutable source of truth that
drives CLI display, execution, testing, and inspection.
"""

_MODULE_BOUNDARIES = """\
Rivet enforces strict import boundaries between packages. Violations are treated as build
failures, not warnings.

## Dependency Graph

```mermaid
graph TD
    rivet_core["rivet_core<br/>(stdlib + PyArrow + sqlglot)"]
    rivet_config["rivet_config"]
    rivet_bridge["rivet_bridge"]
    rivet_cli["rivet_cli"]
    plugins["Plugins"]

    rivet_config --> rivet_core
    rivet_bridge --> rivet_core
    rivet_bridge --> rivet_config
    rivet_cli --> rivet_core
    rivet_cli --> rivet_config
    rivet_cli --> rivet_bridge
    plugins --> rivet_core
```

## Rules

- `rivet_core` imports only stdlib, PyArrow, and sqlglot.
- `rivet_config` imports `rivet_core` public API only.
- `rivet_bridge` imports `rivet_core` and `rivet_config` public APIs.
- `rivet_cli` imports `rivet_core`, `rivet_config`, and `rivet_bridge` public APIs.
- Plugins import only `rivet_core` public API.
- No plugin imports another plugin, `rivet_config`, or `rivet_bridge`.
"""

_COMPILATION_PIPELINE = """\
Compilation transforms a project's configuration and declarations into an executable plan.
Compilation is **pure** — it performs no data operations (no reads, no writes, no runtime
introspection requirements).

## Pipeline Stages

1. **Config Parsing** — Read `rivet.yaml` and `profiles.yaml`, resolve profile selection,
   validate configuration against known schemas.
2. **Bridge Forward** — Translate parsed configuration into core primitives: instantiate
   catalog and engine objects, resolve plugin entry points.
3. **Assembly Building** — Collect all joint declarations (SQL files, YAML declarations),
   resolve upstream references, and build the joint DAG.
4. **Compilation** — Validate the DAG (acyclic, all references exist, sinks have upstream,
   sources have none), assign execution order, fuse adjacent joints on the same engine,
   and produce the immutable `CompiledAssembly`.
5. **Execution** — The executor takes only the `CompiledAssembly`, follows `execution_order`
   exactly, and never re-resolves engines, adapters, or targets at runtime.

## Key Invariant

`CompiledAssembly` is the single source of truth. Every downstream consumer — CLI display,
execution, testing, inspection — reads from this one immutable object.
"""

_MATERIALIZATION_CONTRACT = """\
Every materialization in Rivet produces a `MaterializedRef` that supports a single
guaranteed consumer interface: **`.to_arrow()`**.

## Contract

- `.to_arrow()` must always be available on a `MaterializedRef`.
- Eviction (removing a materialized result) must fail with an actionable error if the
  reference is still needed.
- The materialization strategy is recorded in the `CompiledAssembly` so that execution
  is fully deterministic and reproducible.

## Implications

- Consumers never need to know the underlying storage format — Arrow is the universal
  interchange.
- Engines produce `MaterializedRef` objects; downstream joints and sinks consume them
  via `.to_arrow()`.
- Introspection of materialized data is best-effort: it improves UX and compilation
  fidelity but must not block execution.
"""

_ASSERTIONS_AUDITS_TESTS = """\
Rivet distinguishes three verification mechanisms with different timing and semantics.

## Assertions

Inline, pre-write validation on computed data. Assertions run **before** a joint's result
is written to its target. If an assertion fails, the write is skipped and the pipeline
reports the failure.

Use assertions for data quality checks that must pass before persisting results.

## Audits

Post-write verification by reading back from the target. Audits run **after** a joint's
result has been written. They verify that the data in the target matches expectations.

Use audits for end-to-end validation that includes the write path (e.g., checking row
counts or schema in the actual destination).

## Tests

Offline fixtures that validate logic without writing to real targets. Tests use the
`rivet test` command and operate on fixture data, snapshot comparisons, and deterministic
inputs.

Use tests for development-time validation of SQL logic and transformation correctness.

## Summary

| Mechanism  | Timing      | Reads Target | Blocks Write |
|------------|-------------|--------------|--------------|
| Assertion  | Pre-write   | No           | Yes          |
| Audit      | Post-write  | Yes          | No           |
| Test       | Offline     | No           | N/A          |
"""


def get_architecture_guides() -> list[DocEntry]:
    """Return architecture guide DocEntry objects for rendering."""
    return [
        DocEntry(
            ref_id="guide.core-concepts",
            kind="guide",
            name="Core Concepts: Joints, Engines, and Catalogs",
            module="architecture",
            docstring=_CORE_CONCEPTS,
            tags=["guide", "architecture"],
        ),
        DocEntry(
            ref_id="guide.module-boundaries",
            kind="guide",
            name="Module Boundary Diagram",
            module="architecture",
            docstring=_MODULE_BOUNDARIES,
            tags=["guide", "architecture"],
        ),
        DocEntry(
            ref_id="guide.compilation-pipeline",
            kind="guide",
            name="Compilation Pipeline",
            module="architecture",
            docstring=_COMPILATION_PIPELINE,
            tags=["guide", "architecture"],
        ),
        DocEntry(
            ref_id="guide.materialization-contract",
            kind="guide",
            name="Materialization Contract",
            module="architecture",
            docstring=_MATERIALIZATION_CONTRACT,
            tags=["guide", "architecture"],
        ),
        DocEntry(
            ref_id="guide.assertions-audits-tests",
            kind="guide",
            name="Assertions vs Audits vs Tests",
            module="architecture",
            docstring=_ASSERTIONS_AUDITS_TESTS,
            tags=["guide", "architecture"],
        ),
    ]
