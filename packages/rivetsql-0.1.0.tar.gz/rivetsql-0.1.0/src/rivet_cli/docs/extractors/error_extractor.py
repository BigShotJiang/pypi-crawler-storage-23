"""Error catalog extractor — scans source for RivetError/plugin_error calls."""

from __future__ import annotations

import ast
import logging
import warnings
from pathlib import Path
from typing import Any

from rivet_cli.docs.models import DocEntry

logger = logging.getLogger(__name__)

CODE_RANGE_GROUPS: dict[str, str] = {
    "1": "engine",
    "2": "plugin",
    "3": "DAG",
    "4": "materialization",
    "5": "execution",
    "6": "assertion/audit",
    "7": "SQL",
    "8": "CLI",
}


def _code_group(code: str) -> str:
    """Return the group name for an error code like 'RVT-301'."""
    numeric = code.split("-")[-1] if "-" in code else code
    if numeric and numeric[0] in CODE_RANGE_GROUPS:
        return CODE_RANGE_GROUPS[numeric[0]]
    return "unknown"


def _const_value(node: ast.expr) -> Any:
    """Extract a constant value from an AST node, or return None."""
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.JoinedStr):
        return "<f-string>"
    return None


def _extract_from_call(node: ast.Call) -> dict[str, Any] | None:
    """Extract code/message/remediation from a RivetError or plugin_error call."""
    func = node.func
    name = None
    if isinstance(func, ast.Name):
        name = func.id
    elif isinstance(func, ast.Attribute):
        name = func.attr

    if name not in ("RivetError", "plugin_error"):
        return None

    info: dict[str, Any] = {}

    # Positional args: code is first, message is second
    if len(node.args) >= 1:
        info["code"] = _const_value(node.args[0])
    if len(node.args) >= 2:
        info["message"] = _const_value(node.args[1])

    # Keyword args override positional
    for kw in node.keywords:
        if kw.arg in ("code", "message", "remediation"):
            info[kw.arg] = _const_value(kw.value)

    if "code" not in info or info["code"] is None:
        return None

    return info


class _ErrorVisitor(ast.NodeVisitor):
    """AST visitor that collects RivetError/plugin_error calls."""

    def __init__(self, source_file: str) -> None:
        self.source_file = source_file
        self.errors: list[dict[str, Any]] = []

    def visit_Call(self, node: ast.Call) -> None:  # noqa: N802
        info = _extract_from_call(node)
        if info is not None:
            info["source_file"] = self.source_file
            info["source_line"] = node.lineno
            self.errors.append(info)
        self.generic_visit(node)


def extract_error_catalog(source_roots: list[Path]) -> list[DocEntry]:
    """Scan source roots for RivetError/plugin_error calls and produce DocEntries."""
    seen: dict[str, dict[str, Any]] = {}  # code -> info (first occurrence wins)

    for root in source_roots:
        if not root.is_dir():
            continue
        for py_file in sorted(root.rglob("*.py")):
            try:
                source = py_file.read_text(encoding="utf-8")
                tree = ast.parse(source, filename=str(py_file))
            except SyntaxError as exc:
                logger.warning("%s:%s: %s", py_file, getattr(exc, "lineno", "?"), exc)
                continue

            visitor = _ErrorVisitor(str(py_file))
            visitor.visit(tree)

            for info in visitor.errors:
                code = info["code"]
                if code not in seen:
                    seen[code] = info

    # Flag missing remediation
    for code, info in seen.items():
        if not info.get("remediation"):
            warnings.warn(
                f"Error {code} at {info.get('source_file')}:{info.get('source_line')} "
                f"missing remediation",
                stacklevel=1,
            )

    # Build DocEntries sorted by code
    entries: list[DocEntry] = []
    for code in sorted(seen):
        info = seen[code]
        group = _code_group(code)
        entries.append(
            DocEntry(
                ref_id=f"error.{code}",
                kind="error_code",
                name=code,
                module="errors",
                docstring=info.get("message"),
                tags=["error"],
                source_file=info.get("source_file"),
                source_line=info.get("source_line"),
                metadata={
                    "code": code,
                    "message": info.get("message"),
                    "remediation": info.get("remediation"),
                    "group": group,
                },
            )
        )

    return entries
