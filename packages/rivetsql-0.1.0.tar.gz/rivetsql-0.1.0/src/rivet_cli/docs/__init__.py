"""Auto-documentation system for the Rivet SQL framework."""
