"""Intermediate representation models for the auto-documentation system."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class DocParam:
    """A single parameter in a documented symbol."""

    name: str
    type_hint: str | None = None
    default: str | None = None
    description: str | None = None


@dataclass(frozen=True)
class DocEntry:
    """Central IR node produced by extractors and consumed by renderers."""

    ref_id: str
    kind: str
    name: str
    module: str
    signature: str | None = None
    docstring: str | None = None
    params: list[DocParam] = field(default_factory=list)
    returns: str | None = None
    raises: list[str] = field(default_factory=list)
    parent: str | None = None
    children: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    source_file: str | None = None
    source_line: int | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class CoverageResult:
    """Coverage result for a single package."""

    package: str
    total_symbols: int
    documented_symbols: int
    incomplete_symbols: list[str] = field(default_factory=list)

    @property
    def coverage_pct(self) -> float:
        if self.total_symbols == 0:
            return 100.0
        return self.documented_symbols / self.total_symbols * 100


@dataclass(frozen=True)
class CoverageReport:
    """Aggregate coverage report across packages."""

    results: list[CoverageResult]
    threshold: float
    passed: bool


@dataclass(frozen=True)
class StaleEntry:
    """A documentation entry that is out of date."""

    ref_id: str
    source_file: str
    doc_file: str
    reason: str


@dataclass(frozen=True)
class FreshnessReport:
    """Report of stale documentation entries."""

    stale_entries: list[StaleEntry]
    passed: bool

    def to_json(self) -> str:
        import json

        return json.dumps(
            {
                "stale_entries": [
                    {
                        "ref_id": e.ref_id,
                        "source_file": e.source_file,
                        "doc_file": e.doc_file,
                        "reason": e.reason,
                    }
                    for e in self.stale_entries
                ],
                "passed": self.passed,
            }
        )


@dataclass(frozen=True)
class SignatureHash:
    """Hash of a symbol's signature for freshness detection."""

    ref_id: str
    hash: str
    source_file: str
