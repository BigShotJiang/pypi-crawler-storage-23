"""HTML renderer for auto-documentation.

Wraps documentation entries in static HTML with navigation sidebar,
client-side search index, cross-reference hyperlinks, and Mermaid.js
diagram support.  Uses only stdlib ``string.Template`` — no Jinja2.
"""

from __future__ import annotations

import html
import json
import os
import re
from pathlib import Path
from string import Template

from rivet_cli.docs.models import DocEntry, DocParam

# ---------------------------------------------------------------------------
# HTML templates
# ---------------------------------------------------------------------------

_PAGE_TEMPLATE = Template("""\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<title>${title}</title>
<style>
body{margin:0;font-family:system-ui,sans-serif;display:flex}
nav{width:220px;padding:12px;background:#f5f5f5;overflow-y:auto;height:100vh;position:sticky;top:0;box-sizing:border-box}
nav a{display:block;padding:2px 0;color:#0366d6;text-decoration:none;font-size:0.9em}
nav a:hover{text-decoration:underline}
main{flex:1;padding:24px;max-width:800px}
pre{background:#f6f8fa;padding:12px;overflow-x:auto;border-radius:4px}
code{font-size:0.9em}
table{border-collapse:collapse;width:100%}
th,td{border:1px solid #ddd;padding:6px 10px;text-align:left}
#search{width:100%;padding:4px;margin-bottom:8px;box-sizing:border-box}
</style>
</head>
<body>
<nav>
<input id="search" placeholder="Search…" aria-label="Search documentation"/>
<div id="nav-links">${nav}</div>
</nav>
<main>
${body}
</main>
<script src="https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js"></script>
<script>mermaid.initialize({startOnLoad:true});</script>
<script>
(function(){
var idx=[];
try{var r=new XMLHttpRequest();r.open("GET","search_index.json",false);r.send();idx=JSON.parse(r.responseText);}catch(e){}
var input=document.getElementById("search");
var links=document.getElementById("nav-links");
var orig=links.innerHTML;
input.addEventListener("input",function(){
  var q=this.value.toLowerCase();
  if(!q){links.innerHTML=orig;return;}
  var html="";
  idx.forEach(function(e){if((e.name+' '+e.text).toLowerCase().indexOf(q)>=0){
    html+='<a href="'+e.file+'">'+e.name+'</a>';}});
  links.innerHTML=html||"<em>No results</em>";
});
})();
</script>
</body>
</html>
""")

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_REF_PATTERN = re.compile(r"`([a-zA-Z_][a-zA-Z0-9_.]*(?:\.[a-zA-Z_][a-zA-Z0-9_]*)+)`")


def _sanitize_filename(ref_id: str) -> str:
    return ref_id.replace(".", "_").replace("-", "_") + ".html"


def _entry_filename(entry: DocEntry) -> str:
    return _sanitize_filename(entry.ref_id)


def _esc(text: str | None) -> str:
    return html.escape(text or "")


def _resolve_refs(text: str, ref_map: dict[str, str]) -> str:
    """Replace `ref_id` back-tick references with <a> hyperlinks."""
    def _replace(m: re.Match[str]) -> str:
        rid = m.group(1)
        if rid in ref_map:
            return f'<a href="{ref_map[rid]}">{_esc(rid)}</a>'
        return m.group(0)
    return _REF_PATTERN.sub(_replace, text)


def _render_params_table(params: list[DocParam]) -> str:
    if not params:
        return ""
    rows = "".join(
        f"<tr><td><code>{_esc(p.name)}</code></td>"
        f"<td>{_esc(p.type_hint)}</td>"
        f"<td>{_esc(p.default)}</td>"
        f"<td>{_esc(p.description)}</td></tr>"
        for p in params
    )
    return (
        "<table><thead><tr><th>Name</th><th>Type</th><th>Default</th>"
        f"<th>Description</th></tr></thead><tbody>{rows}</tbody></table>"
    )


def _render_entry_body(entry: DocEntry, ref_map: dict[str, str]) -> str:
    parts: list[str] = [f"<h1>{_esc(entry.name)}</h1>"]
    parts.append(f"<p><em>{_esc(entry.kind)}</em> — <code>{_esc(entry.module)}</code></p>")
    if entry.signature:
        parts.append(f"<pre><code>{_esc(entry.signature)}</code></pre>")
    if entry.docstring:
        resolved = _resolve_refs(_esc(entry.docstring), ref_map)
        parts.append(f"<p>{resolved}</p>")
    if entry.params:
        parts.append("<h2>Parameters</h2>")
        parts.append(_render_params_table(entry.params))
    if entry.returns:
        parts.append(f"<h2>Returns</h2><p><code>{_esc(entry.returns)}</code></p>")
    if entry.raises:
        parts.append("<h2>Raises</h2><ul>" + "".join(f"<li>{_esc(r)}</li>" for r in entry.raises) + "</ul>")
    if entry.kind == "diagram" and entry.metadata.get("mermaid"):
        parts.append(f'<div class="mermaid">{_esc(entry.metadata["mermaid"])}</div>')
    return "\n".join(parts)


def _build_nav(entries: list[DocEntry]) -> str:
    lines: list[str] = []
    for entry in sorted(entries, key=lambda e: e.name.lower()):
        fname = _entry_filename(entry)
        lines.append(f'<a href="{fname}">{_esc(entry.name)}</a>')
    lines.append('<a href="index.html"><strong>Index</strong></a>')
    return "\n".join(lines)


def _build_search_index(entries: list[DocEntry]) -> list[dict[str, str]]:
    return [
        {
            "ref_id": e.ref_id,
            "name": e.name,
            "text": (e.docstring or "")[:200],
            "file": _entry_filename(e),
        }
        for e in entries
    ]


def _build_index_page(entries: list[DocEntry], nav_html: str) -> str:
    items = "".join(
        f'<li><a href="{_entry_filename(e)}">{_esc(e.name)}</a> '
        f"<em>({_esc(e.kind)})</em></li>"
        for e in sorted(entries, key=lambda e: e.name.lower())
    )
    body = f"<h1>Index</h1><ul>{items}</ul>"
    return _PAGE_TEMPLATE.substitute(title="Index", nav=nav_html, body=body)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def render_html(entries: list[DocEntry], output_dir: Path) -> None:
    """Render *entries* as a static HTML site under *output_dir*."""
    os.makedirs(output_dir, exist_ok=True)

    ref_map: dict[str, str] = {e.ref_id: _entry_filename(e) for e in entries}
    nav_html = _build_nav(entries)

    # Individual entry pages
    for entry in entries:
        body = _render_entry_body(entry, ref_map)
        page = _PAGE_TEMPLATE.substitute(
            title=entry.name, nav=nav_html, body=body,
        )
        (output_dir / _entry_filename(entry)).write_text(page, encoding="utf-8")

    # Search index JSON
    search_index = _build_search_index(entries)
    (output_dir / "search_index.json").write_text(
        json.dumps(search_index, indent=2), encoding="utf-8",
    )

    # Global alphabetical index page
    index_page = _build_index_page(entries, nav_html)
    (output_dir / "index.html").write_text(index_page, encoding="utf-8")
