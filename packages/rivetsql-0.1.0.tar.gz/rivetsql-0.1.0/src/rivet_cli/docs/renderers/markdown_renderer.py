"""Markdown renderer for auto-documentation system.

Produces one .md file per module/command/guide, generates index pages
per section, and embeds Mermaid diagrams as fenced code blocks.
"""

from __future__ import annotations

import os
from collections import defaultdict
from pathlib import Path

from rivet_cli.docs.models import DocEntry

# Maps entry kind to section name and directory
_SECTION_MAP: dict[str, tuple[str, str]] = {
    "class": ("API Reference", "api"),
    "function": ("API Reference", "api"),
    "method": ("API Reference", "api"),
    "cli_command": ("CLI Reference", "cli"),
    "config_key": ("Configuration Reference", "config"),
    "error_code": ("Error Reference", "errors"),
    "plugin_abc": ("Plugin Reference", "plugins"),
    "guide": ("Guides", "guides"),
    "diagram": ("Diagrams", "diagrams"),
}


def _sanitize_filename(ref_id: str) -> str:
    """Convert a ref_id to a safe filename."""
    return ref_id.replace("/", "_").replace(" ", "_")


def _render_entry(entry: DocEntry) -> str:
    """Render a single DocEntry to Markdown content."""
    lines: list[str] = []
    lines.append(f"# {entry.name}\n")

    if entry.kind == "diagram":
        if entry.docstring:
            lines.append(f"{entry.docstring}\n")
        content = entry.metadata.get("mermaid", "") or entry.signature or ""
        if content:
            lines.append("```mermaid")
            lines.append(content)
            lines.append("```\n")
        return "\n".join(lines)

    if entry.signature:
        lines.append(f"```python\n{entry.signature}\n```\n")

    if entry.docstring:
        lines.append(f"{entry.docstring}\n")

    if entry.params:
        lines.append("## Parameters\n")
        for p in entry.params:
            type_str = f" (`{p.type_hint}`)" if p.type_hint else ""
            default_str = f" — default: `{p.default}`" if p.default else ""
            desc_str = f": {p.description}" if p.description else ""
            lines.append(f"- **{p.name}**{type_str}{default_str}{desc_str}")
        lines.append("")

    if entry.returns:
        lines.append(f"## Returns\n\n`{entry.returns}`\n")

    if entry.raises:
        lines.append("## Raises\n")
        for exc in entry.raises:
            lines.append(f"- `{exc}`")
        lines.append("")

    if entry.source_file:
        loc = entry.source_file
        if entry.source_line:
            loc += f":{entry.source_line}"
        lines.append(f"*Source: `{loc}`*\n")

    return "\n".join(lines)


def _render_index(section_title: str, entries: list[DocEntry], section_dir: str) -> str:
    """Render an index page for a section."""
    lines: list[str] = [f"# {section_title}\n"]
    for entry in sorted(entries, key=lambda e: e.name):
        fname = _sanitize_filename(entry.ref_id)
        lines.append(f"- [{entry.name}]({section_dir}/{fname}.md)")
    lines.append("")
    return "\n".join(lines)


def render_markdown(entries: list[DocEntry], output_dir: Path) -> None:
    """Render DocEntry list to Markdown files.

    Produces one .md file per entry, plus index pages per section.
    Creates output_dir if it doesn't exist.
    """
    os.makedirs(output_dir, exist_ok=True)

    # Group entries by section
    sections: dict[str, list[DocEntry]] = defaultdict(list)
    for entry in entries:
        section_title, section_dir = _SECTION_MAP.get(entry.kind, ("Other", "other"))
        sections[(section_title, section_dir)].append(entry)  # type: ignore[index]

    # Write individual entry files and section indexes
    for (section_title, section_dir), section_entries in sections.items():  # type: ignore[misc]
        sec_path = output_dir / section_dir
        os.makedirs(sec_path, exist_ok=True)

        for entry in section_entries:
            fname = _sanitize_filename(entry.ref_id) + ".md"
            (sec_path / fname).write_text(_render_entry(entry))

        # Write section index
        index_content = _render_index(section_title, section_entries, section_dir)
        (output_dir / f"{section_dir}.md").write_text(index_content)

    # Write top-level index
    top_lines: list[str] = ["# Documentation\n"]
    for (section_title, section_dir) in sorted(sections.keys()):  # type: ignore[misc]
        top_lines.append(f"- [{section_title}]({section_dir}.md)")
    top_lines.append("")
    (output_dir / "index.md").write_text("\n".join(top_lines))
