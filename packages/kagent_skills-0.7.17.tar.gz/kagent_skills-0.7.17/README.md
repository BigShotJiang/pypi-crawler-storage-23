# KAgent Skills

Core library for discovering, parsing, and loading KAgent skills from the filesystem.

For example usage, see `kagent-adk` and `kagent-openai` packages.
