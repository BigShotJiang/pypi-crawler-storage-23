from pathlib import Path
from typing import Iterable
from time import perf_counter

from textual import on
from textual.app import App, ComposeResult
from textual.containers import Container
from textual.widgets import Button, DirectoryTree, Footer, Header, Log, Select

from cidc_api.code_systems.importer import delete_data, import_data, load_app


class FilteredDirectoryTree(DirectoryTree):
    def filter_paths(self, paths: Iterable[Path]) -> Iterable[Path]:
        return [path for path in paths if path.name.endswith(".csv")]

    def on_directory_tree_file_selected(self, event: DirectoryTree.FileSelected) -> None:
        """Called when a file is selected in the directory tree."""
        # log = self.app.query_one(Log)
        # log.write_line(f"Selected file: {event.path.parent.name}/{event.path.name}")


class CodeSystems(App):
    """A Textual app to manage code systems."""

    CSS = """
    Select { width: 40%; margin: 1;}
    FilteredDirectoryTree { margin-left: 2; }
    Button, Log { margin: 1 2; }
    Container { height: 10; }
    #results { margin: 1; text-style: bold; }
    """

    BINDINGS = [("d", "toggle_dark", "Toggle dark mode"), ("q", "quit", "Quit the app")]
    SELECT_OPTIONS = [(code, code) for code in ["Ctcae60", "Icdo3"]]

    def compose(self) -> ComposeResult:
        """Create child widgets for the app."""
        yield Header()
        yield Select(self.SELECT_OPTIONS, prompt="Select code system")
        with Container(id="tree-container"):
            yield FilteredDirectoryTree(Path(__file__).resolve().parent / "data")
        yield Button("Import data", variant="primary", disabled=True)
        yield Log()
        yield Footer()

    @on(Select.Changed)
    async def check_select(self, event: Select.Changed):

        old_tree = self.query_one(FilteredDirectoryTree)
        await old_tree.remove()

        folder_name = event.value
        new_path = Path(__file__).resolve().parent / "data" / folder_name
        new_tree = FilteredDirectoryTree(str(new_path))
        await self.query_one("#tree-container").mount(new_tree)
        new_tree.focus()  # optional: set focus to the new tree

        self.maybe_enable_button()

    @on(DirectoryTree.FileSelected)
    def check_tree(self, _event: DirectoryTree.FileSelected):
        self.maybe_enable_button()

    def maybe_enable_button(self):
        button_widget = self.query_one(Button)
        code_system_widget = self.query_one(Select)
        file_path_widget = self.query_one(FilteredDirectoryTree)
        button_widget.disabled = not (
            code_system_widget.value != Select.BLANK and file_path_widget.cursor_node.data.path.is_file()
        )

    # def on_ready(self) -> None:
    #     log = self.query_one(Log)
    #     log.write_line("Hello!")

    def action_toggle_dark(self) -> None:
        """An action to toggle dark mode."""
        self.theme = "textual-dark" if self.theme == "textual-light" else "textual-light"

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        """Event handler called when the button is pressed."""
        code_system_widget = self.query_one(Select)
        file_path_widget = self.query_one(FilteredDirectoryTree)
        log_widget = self.query_one(Log)

        log_widget.clear()
        code_system = code_system_widget.value
        file_path = file_path_widget.cursor_node.data.path

        button = event.button
        button.disabled = True
        old_label = button.label
        button.label = "Running task, please wait..."
        await self.run_task(log_widget, code_system, file_path)
        button.disabled = False
        button.label = old_label

    async def run_task(self, log_widget: Log, code_system: str, file_path: Path) -> None:
        log_widget.write_line("Loading app ...")
        start = perf_counter()

        flask_app, db, model = await load_app(code_system)
        table_name = model.__tablename__
        schema = model.__table__.schema
        log_widget.write_line(f"{perf_counter() - start:.3f} seconds to load app.\n\n")

        with flask_app.app_context():
            engine = db.engine

            log_widget.write_line("Deleting data ...")
            start = perf_counter()
            msg = await delete_data(engine, f"{schema}.{table_name}")
            log_widget.write_line(msg)
            log_widget.write_line(f"{perf_counter() - start:.3f} seconds to delete data.\n\n")

            log_widget.write_line("Importing data ...")
            start = perf_counter()
            msg = await import_data(engine, file_path, f"{schema}.{table_name}")
            log_widget.write_line(msg)
            log_widget.write_line(f"{perf_counter() - start:.3f} seconds to import data.")


if __name__ == "__main__":
    app = CodeSystems()
    app.run()
