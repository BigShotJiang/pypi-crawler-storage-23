# pylint: disable=import-outside-toplevel,broad-except,invalid-name,redefined-outer-name

from os import environ
from pathlib import Path
import asyncio
import importlib


async def load_app(model):
    print("Loading app ...")

    # async load to allow reporting progress in UI
    flask_app_mod = await asyncio.to_thread(importlib.import_module, "cidc_api.app")
    db_mod = await asyncio.to_thread(importlib.import_module, "cidc_api.config.db")
    code_systems = await asyncio.to_thread(importlib.import_module, "cidc_api.models.code_systems")

    return flask_app_mod.app, db_mod.db, getattr(code_systems, model)


async def import_data(engine, file_path, table_name):
    print("Importing data ...")

    conn = engine.raw_connection()
    cursor = conn.cursor()

    try:
        with open(file_path, "r", encoding="utf-8") as file:
            # define the COPY command, specifying STDIN for the file-like object
            sql = f"COPY {table_name} FROM STDIN WITH CSV HEADER"

            # execute the copy operation
            cursor.copy_expert(sql, file)

        msg = f"Number of rows copied: {cursor.rowcount}"
        conn.commit()

    except Exception as exc:
        conn.rollback()
        msg = f"Error during COPY command: {exc}"

    finally:
        cursor.close()
        conn.close()

    return msg


async def delete_data(engine, table_name):
    print("Deleting data ...")

    conn = engine.raw_connection()
    cursor = conn.cursor()

    try:
        cursor.execute(f"TRUNCATE TABLE {table_name} RESTART IDENTITY")
        msg = "Table truncated successfully."
        conn.commit()

    except Exception as exc:
        conn.rollback()
        msg = f"Error during TRUNCATE command: {exc}"

    finally:
        cursor.close()
        conn.close()

    return msg


async def call_local(table_name, file_path):
    from dotenv import load_dotenv
    from sqlalchemy import create_engine

    load_dotenv()

    engine = create_engine(environ.get("POSTGRES_URI"))
    msg = await import_data(engine, file_path, table_name)

    return msg


if __name__ == "__main__":
    model = "Ctcae60"
    file_path = Path(__file__).resolve().parent / "data/ctcae_6.0.csv"

    # model = "Icdo3"
    # file_path = Path(__file__).resolve().parent / "data/icdo3.csv"

    # direct connection with conn string from env
    # from dotenv import load_dotenv
    # from sqlalchemy import create_engine
    # load_dotenv()
    # engine = create_engine(environ.get("POSTGRES_URI"))
    # msg = asyncio.run(import_data(engine, file_path, table_name))

    app, db, model = asyncio.run(load_app(model))
    table_name = model.__tablename__
    schema = model.__table__.schema
    table_name = f"{schema}.{table_name}"

    with app.app_context():
        engine = db.engine

        msg = asyncio.run(delete_data(engine, table_name))
        print(msg)

        msg = asyncio.run(import_data(engine, file_path, table_name))
        print(msg)
