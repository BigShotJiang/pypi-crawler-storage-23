from __future__ import annotations
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.types import JSON
from sqlalchemy import ForeignKeyConstraint
from cidc_api.models.db.stage1.base_orm import BaseORM
from cidc_api.models.db.stage1.trial_orm import TrialORM


class CustomDataORM(BaseORM):
    __tablename__ = "custom_data"
    __repr_attrs__ = ["data_category", "custom_row_data"]
    __data_category__ = "custom_data"
    __table_args__ = (
        ForeignKeyConstraint(["trial_id", "version"], [TrialORM.trial_id, TrialORM.version], ondelete="CASCADE"),
    )

    custom_data_id: Mapped[int] = mapped_column(primary_key=True)

    data_category: Mapped[str]
    custom_row_data: Mapped[dict] = mapped_column(JSON)

    trial: Mapped[TrialORM] = relationship(back_populates="custom_data", cascade="all, delete")
