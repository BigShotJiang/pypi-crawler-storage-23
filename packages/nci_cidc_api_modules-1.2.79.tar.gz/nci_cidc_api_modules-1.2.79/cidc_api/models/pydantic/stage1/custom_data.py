from cidc_api.models.pydantic.base import Base
from cidc_api.models.pydantic.base import forced_validator, forced_validators
from cidc_api.models.errors import ValueLocError


@forced_validators
class CustomData(Base):
    __data_category__ = "custom_data"
    __cardinality__ = None

    custom_data_id: int | None = None

    # The custom data category this data belongs to. e.g. "lesions".
    data_category: str

    @forced_validator
    @classmethod
    def validate_participant_id_in_row_data(cls, data, info) -> None:
        custom_row_data = data.get("custom_row_data", None)
        data_category = data.get("data_category", None)

        if custom_row_data is None or "participant_id" not in custom_row_data:
            raise ValueLocError(
                'Received custom row data without an associated "participant_id" field.',
                loc=data_category,
            )
