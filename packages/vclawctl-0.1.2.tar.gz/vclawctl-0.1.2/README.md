# vclawctl

`vclawctl` is an independent control-plane CLI for managing v-claw data.

All command outputs are JSON on stdout. On non-UTF-8 terminals (for example
Windows GBK), non-ASCII characters are auto-escaped to keep output stable.

## Quick Start

```bash
uv tool install vclawctl
vclawctl --help
```

## Control Channel Modes

`vclawctl` supports three execution modes:

```bash
vclawctl --mode api   ...   # API only
vclawctl --mode auto  ...   # API first, fallback to DB
vclawctl --mode db    ...   # DB only
```

Default mode is `api`.

## API Auth

When using API mode, provide:

- `VCLAWCTL_API_BASE_URL` (for example `http://127.0.0.1:7799/api/control/v1`)
- `VCLAWCTL_AUTH_TOKEN`

or pass flags directly:

```bash
vclawctl \
  --mode api \
  --api-base-url "http://127.0.0.1:7799/api/control/v1" \
  --auth-token "YOUR_TOKEN" \
  schedule status
```

## Examples

```bash
# List schedule tasks (default api mode)
vclawctl schedule list

# Create one-time schedule task
vclawctl schedule create --params-json '{"name":"once-hi","prompt":"Hi","schedule_type":"once","schedule_config":{"at":"2026-03-01T12:00:00Z"}}'

# Quick create one-time task after a delay
vclawctl schedule create --name "once-hi" --prompt "Hi" --after 10m
# --after supports: 30s / 5m / 2h / 1d / 90 (seconds)

# Generic method call
vclawctl call --method settings.get_value --params-json '{"key":"chat.default_agent_id"}'
```

## Inspect Task/Session Messages

```bash
# List messages by task
vclawctl task messages --task-id task-main

# Search message content inside one task/session
vclawctl task search-messages --task-id task-main --query "error"
vclawctl session search-messages --session-id sess-1 --query "timeout"

# Get last message quickly (useful to check current progress)
vclawctl task last-message --task-id task-main
vclawctl session last-message --session-id sess-1
```

Every `task/session` response now includes `data.meta.id_model` to reduce
identity confusion in human/agent workflows:

- `requested_by`: which id type was used (`task_id` or `session_id`)
- `relation`: persisted relation note between task/session
- `task_id_meaning` / `session_id_meaning`: semantic intent of each id
