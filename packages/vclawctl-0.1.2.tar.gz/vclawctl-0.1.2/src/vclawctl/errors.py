"""Error types and exit codes for vclawctl."""

from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum


class ExitCode(IntEnum):
    """CLI process exit codes."""

    OK = 0
    ERROR = 1
    BUSINESS_ERROR = 2


@dataclass(slots=True)
class CLIError(Exception):
    """Structured CLI error with stable JSON code and exit mapping."""

    message: str
    code: str = "cli_error"
    exit_code: ExitCode = ExitCode.BUSINESS_ERROR

    def __str__(self) -> str:  # pragma: no cover - trivial
        return self.message
