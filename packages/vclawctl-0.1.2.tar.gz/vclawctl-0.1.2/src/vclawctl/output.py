"""JSON output helpers."""

from __future__ import annotations

import json
from typing import Any


def success_payload(data: Any) -> dict[str, Any]:
    return {
        "ok": True,
        "data": data,
        "error": "",
        "code": "",
    }


def error_payload(*, message: str, code: str) -> dict[str, Any]:
    return {
        "ok": False,
        "data": {},
        "error": message,
        "code": code,
    }


def _dumps(payload: dict[str, Any], *, pretty: bool, ensure_ascii: bool) -> str:
    if pretty:
        return json.dumps(payload, ensure_ascii=ensure_ascii, indent=2, sort_keys=True)
    return json.dumps(payload, ensure_ascii=ensure_ascii)


def emit(payload: dict[str, Any], *, pretty: bool) -> None:
    text = _dumps(payload, pretty=pretty, ensure_ascii=False)
    if pretty:
        try:
            print(text)
        except UnicodeEncodeError:
            # Fallback for non-UTF-8 terminals (for example GBK on Windows).
            print(_dumps(payload, pretty=pretty, ensure_ascii=True))
        return
    try:
        print(text)
    except UnicodeEncodeError:
        print(_dumps(payload, pretty=pretty, ensure_ascii=True))
