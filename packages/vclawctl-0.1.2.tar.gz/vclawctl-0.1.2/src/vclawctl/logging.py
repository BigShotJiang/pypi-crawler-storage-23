"""Logging setup for vclawctl."""

from __future__ import annotations

import logging
import sys


def configure_logger(verbose: bool) -> logging.Logger:
    logger = logging.getLogger("vclawctl")
    logger.handlers.clear()
    logger.setLevel(logging.DEBUG if verbose else logging.INFO)

    handler = logging.StreamHandler(sys.stderr)
    handler.setLevel(logging.DEBUG if verbose else logging.INFO)
    handler.setFormatter(logging.Formatter("[%(asctime)s] %(levelname)s %(name)s: %(message)s"))
    logger.addHandler(handler)
    logger.propagate = False
    return logger
