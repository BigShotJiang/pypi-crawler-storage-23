"""Agent profile command handlers."""

from __future__ import annotations

import json
import time
import uuid
from typing import Any

from vclawctl.adapters.sqlite.db import connect, loads_json
from vclawctl.commands.transport import invoke
from vclawctl.context import CLIContext
from vclawctl.domain.validators import normalize_positive_int, parse_bool, parse_json_object
from vclawctl.errors import CLIError

_DEFAULT_TOOLS = [
    "screen_capture",
    "memory_search",
    "memory_save",
    "browser_navigate",
    "browser_list_tabs",
    "browser_focus_tab",
    "browser_snapshot",
    "browser_screenshot",
    "browser_click",
    "browser_fill",
    "browser_type",
    "browser_press",
    "browser_scroll",
    "browser_get_dom",
    "browser_close_tab",
]


def _normalize_tool_list(raw: Any) -> list[str]:
    if not isinstance(raw, list):
        return []
    seen: set[str] = set()
    tools: list[str] = []
    for item in raw:
        name = str(item or "").strip()
        if not name or name in seen:
            continue
        if name == "schedule_task":
            continue
        seen.add(name)
        tools.append(name)
    return tools


def _normalize_agent_id_list(raw: Any) -> list[str]:
    if not isinstance(raw, list):
        return []
    seen: set[str] = set()
    normalized: list[str] = []
    for item in raw:
        value = str(item or "").strip()
        if not value or value in seen:
            continue
        seen.add(value)
        normalized.append(value)
    return normalized


def _row_to_agent(row: Any) -> dict[str, Any]:
    tools = _normalize_tool_list(loads_json(row["tools_json"], list(_DEFAULT_TOOLS)))
    if not tools:
        tools = list(_DEFAULT_TOOLS)
    return {
        "agent_id": str(row["agent_id"]),
        "name": str(row["name"]),
        "description": str(row["description"] or ""),
        "system_prompt": str(row["system_prompt"] or ""),
        "model_backend": str(row["model_backend"] or "moonshot"),
        "model_name": str(row["model_name"] or "kimi-k2.5"),
        "max_cycles": int(row["max_cycles"] or 20),
        "language": str(row["language"] or "zh-CN"),
        "allow_interruption": bool(int(row["allow_interruption"] or 0)),
        "use_workspace": bool(int(row["use_workspace"] or 0)),
        "load_user_memory": bool(int(row["load_user_memory"] or 0)),
        "default_workspace_path": str(row["default_workspace_path"] or ""),
        "tools": tools,
        "skills": loads_json(row["skills_json"], []),
        "callable_sub_agents": _normalize_agent_id_list(
            loads_json(row["callable_sub_agents_json"], [])
        ),
        "created_at": float(row["created_at"] or time.time()),
        "updated_at": float(row["updated_at"] or time.time()),
    }


def _upsert(conn: Any, payload: dict[str, Any]) -> None:
    conn.execute(
        """
        INSERT INTO agent_profiles(
            agent_id, name, description, system_prompt,
            model_backend, model_name, max_cycles, language,
            allow_interruption, use_workspace, load_user_memory,
            default_workspace_path, tools_json, skills_json,
            mcp_servers_json, callable_sub_agents_json,
            created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(agent_id) DO UPDATE SET
            name = excluded.name,
            description = excluded.description,
            system_prompt = excluded.system_prompt,
            model_backend = excluded.model_backend,
            model_name = excluded.model_name,
            max_cycles = excluded.max_cycles,
            language = excluded.language,
            allow_interruption = excluded.allow_interruption,
            use_workspace = excluded.use_workspace,
            load_user_memory = excluded.load_user_memory,
            default_workspace_path = excluded.default_workspace_path,
            tools_json = excluded.tools_json,
            skills_json = excluded.skills_json,
            mcp_servers_json = excluded.mcp_servers_json,
            callable_sub_agents_json = excluded.callable_sub_agents_json,
            created_at = excluded.created_at,
            updated_at = excluded.updated_at
        """,
        (
            payload["agent_id"],
            payload["name"],
            payload["description"],
            payload["system_prompt"],
            payload["model_backend"],
            payload["model_name"],
            int(payload["max_cycles"]),
            payload["language"],
            int(payload["allow_interruption"]),
            int(payload["use_workspace"]),
            int(payload["load_user_memory"]),
            payload["default_workspace_path"],
            json.dumps(payload["tools"], ensure_ascii=False),
            json.dumps(payload["skills"], ensure_ascii=False),
            json.dumps([], ensure_ascii=False),
            json.dumps(payload["callable_sub_agents"], ensure_ascii=False),
            float(payload["created_at"]),
            float(payload["updated_at"]),
        ),
    )


def list_agents(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    del params
    with connect(ctx.db_path) as conn:
        rows = conn.execute("SELECT * FROM agent_profiles ORDER BY created_at ASC").fetchall()
    return {"agents": [_row_to_agent(row) for row in rows]}


def get_agent(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    agent_id = str(params.get("agent_id") or "").strip()
    if not agent_id:
        raise CLIError("agent_id required", code="missing_required")
    with connect(ctx.db_path) as conn:
        row = conn.execute(
            "SELECT * FROM agent_profiles WHERE agent_id = ? LIMIT 1",
            (agent_id,),
        ).fetchone()
    if not row:
        raise CLIError("Agent not found", code="not_found")
    return {"agent": _row_to_agent(row)}


def create_agent(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    now = time.time()
    agent_id = str(params.get("agent_id") or "").strip() or uuid.uuid4().hex[:8]
    payload = {
        "agent_id": agent_id,
        "name": str(params.get("name") or "未命名智能体").strip() or "未命名智能体",
        "description": str(params.get("description") or ""),
        "system_prompt": str(params.get("system_prompt") or ""),
        "model_backend": str(params.get("model_backend") or "moonshot") or "moonshot",
        "model_name": str(params.get("model_name") or "kimi-k2.5") or "kimi-k2.5",
        "max_cycles": normalize_positive_int(params.get("max_cycles"), default=20),
        "language": str(params.get("language") or "zh-CN") or "zh-CN",
        "allow_interruption": parse_bool(params.get("allow_interruption"), default=True),
        "use_workspace": parse_bool(params.get("use_workspace"), default=True),
        "load_user_memory": parse_bool(params.get("load_user_memory"), default=True),
        "default_workspace_path": str(params.get("default_workspace_path") or ""),
        "tools": _normalize_tool_list(params.get("tools", list(_DEFAULT_TOOLS))) or list(
            _DEFAULT_TOOLS
        ),
        "skills": list(params.get("skills", []) or []),
        "callable_sub_agents": _normalize_agent_id_list(params.get("callable_sub_agents", [])),
        "created_at": now,
        "updated_at": now,
    }

    with connect(ctx.db_path, write=True) as conn:
        _upsert(conn, payload)
    return {"agent": payload}


def update_agent(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    agent_id = str(params.get("agent_id") or "").strip()
    updates = params.get("updates", {})
    if not agent_id:
        raise CLIError("agent_id required", code="missing_required")
    if not isinstance(updates, dict):
        raise CLIError("updates must be object", code="invalid_updates")

    with connect(ctx.db_path, write=True) as conn:
        row = conn.execute(
            "SELECT * FROM agent_profiles WHERE agent_id = ? LIMIT 1",
            (agent_id,),
        ).fetchone()
        if not row:
            raise CLIError("Agent not found", code="not_found")

        current = _row_to_agent(row)
        for key, value in updates.items():
            if key in {"agent_id", "created_at"}:
                continue
            if key not in current:
                continue
            current[key] = value

        current["agent_id"] = agent_id
        current["max_cycles"] = normalize_positive_int(current.get("max_cycles"), default=20)
        current["allow_interruption"] = parse_bool(current.get("allow_interruption"), default=True)
        current["use_workspace"] = parse_bool(current.get("use_workspace"), default=True)
        current["load_user_memory"] = parse_bool(current.get("load_user_memory"), default=True)
        current["tools"] = _normalize_tool_list(current.get("tools")) or list(_DEFAULT_TOOLS)
        current["callable_sub_agents"] = _normalize_agent_id_list(
            current.get("callable_sub_agents")
        )
        current["updated_at"] = time.time()

        _upsert(conn, current)
        return {"agent": current}


def delete_agent(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    agent_id = str(params.get("agent_id") or "").strip()
    if not agent_id:
        raise CLIError("agent_id required", code="missing_required")
    if agent_id == "default":
        raise CLIError("Cannot delete default agent", code="forbidden")

    with connect(ctx.db_path, write=True) as conn:
        cur = conn.execute("DELETE FROM agent_profiles WHERE agent_id = ?", (agent_id,))
    return {"ok": bool(cur.rowcount)}


def dispatch(method: str, params: dict[str, Any], ctx: CLIContext) -> dict[str, Any]:
    handlers = {
        "list": list_agents,
        "get": get_agent,
        "create": create_agent,
        "update": update_agent,
        "delete": delete_agent,
    }
    handler = handlers.get(method)
    if not handler:
        raise CLIError(f"Unknown agent method: {method}", code="unknown_method")
    return handler(ctx, params)


def _invoke_agent(method: str, params: dict[str, Any], ctx: CLIContext) -> dict[str, Any]:
    return invoke(
        method=f"agent_profile.{method}",
        params=params,
        ctx=ctx,
        local_call=lambda: dispatch(method, params, ctx),
    )


def register(subparsers: Any) -> None:
    parser = subparsers.add_parser("agent", help="Manage agent profiles")
    agent_sub = parser.add_subparsers(dest="agent_cmd", required=True)

    list_parser = agent_sub.add_parser("list", help="List agents")
    list_parser.set_defaults(func=_cmd_list)

    get_parser = agent_sub.add_parser("get", help="Get an agent")
    get_parser.add_argument("--agent-id", required=True)
    get_parser.set_defaults(func=_cmd_get)

    create_parser = agent_sub.add_parser("create", help="Create an agent")
    create_parser.add_argument("--params-json", required=True)
    create_parser.set_defaults(func=_cmd_create)

    update_parser = agent_sub.add_parser("update", help="Update an agent")
    update_parser.add_argument("--agent-id", required=True)
    update_parser.add_argument("--updates-json", required=True)
    update_parser.set_defaults(func=_cmd_update)

    delete_parser = agent_sub.add_parser("delete", help="Delete an agent")
    delete_parser.add_argument("--agent-id", required=True)
    delete_parser.add_argument("--yes", action="store_true")
    delete_parser.set_defaults(func=_cmd_delete)


def _cmd_list(args: Any, ctx: CLIContext) -> dict[str, Any]:
    del args
    return _invoke_agent("list", {}, ctx)


def _cmd_get(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {"agent_id": args.agent_id}
    return _invoke_agent("get", params, ctx)


def _cmd_create(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = parse_json_object(args.params_json, field_name="params_json")
    return _invoke_agent("create", params, ctx)


def _cmd_update(args: Any, ctx: CLIContext) -> dict[str, Any]:
    updates = parse_json_object(args.updates_json, field_name="updates_json")
    params = {"agent_id": args.agent_id, "updates": updates}
    return _invoke_agent("update", params, ctx)


def _cmd_delete(args: Any, ctx: CLIContext) -> dict[str, Any]:
    if not args.yes:
        raise CLIError("delete requires --yes", code="confirmation_required")
    params = {"agent_id": args.agent_id}
    return _invoke_agent("delete", params, ctx)
