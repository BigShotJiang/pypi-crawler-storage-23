"""Session command handlers."""

from __future__ import annotations

from typing import Any

from vclawctl.adapters.sqlite.db import connect, loads_json
from vclawctl.commands import chat as chat_cmd
from vclawctl.commands import task as task_cmd
from vclawctl.commands.transport import invoke
from vclawctl.context import CLIContext
from vclawctl.domain.validators import normalize_positive_int
from vclawctl.errors import CLIError


def _row_to_status(row: Any) -> dict[str, Any]:
    token_usage = loads_json(row["token_usage_json"], {})
    progress = loads_json(row["progress_json"], [])
    return {
        "session_id": str(row["session_id"]),
        "task_id": str(row["task_id"]),
        "agent_id": str(row["agent_id"]),
        "session_kind": str(row["session_kind"] or "task"),
        "status": str(row["status"] or ""),
        "cycles_count": int(row["cycles_count"] or 0),
        "token_usage": token_usage,
        "workspace_path": str(row["workspace_path"] or ""),
        "workspace_source": str(row["workspace_source"] or ""),
        "final_answer": str(row["final_answer"] or ""),
        "progress": progress,
        "created_at": float(row["created_at"]),
        "finished_at": float(row["finished_at"]) if row["finished_at"] is not None else None,
    }


def _task_to_status(task: dict[str, Any], session_id: str) -> dict[str, Any]:
    token_usage = task.get("token_usage", {})
    progress = task.get("progress", [])
    raw_finished_at = task.get("finished_at")
    return {
        "session_id": str(task.get("session_id") or session_id),
        "task_id": str(task.get("task_id") or ""),
        "agent_id": str(task.get("agent_id") or ""),
        "session_kind": str(task.get("session_kind") or "task"),
        "status": str(task.get("status") or ""),
        "cycles_count": int(task.get("cycles_count") or 0),
        "token_usage": token_usage if isinstance(token_usage, dict) else {},
        "workspace_path": str(task.get("workspace_path") or ""),
        "workspace_source": str(task.get("workspace_source") or ""),
        "final_answer": str(task.get("final_answer") or ""),
        "progress": progress if isinstance(progress, list) else [],
        "created_at": float(task.get("created_at") or 0),
        "finished_at": (
            float(raw_finished_at)
            if raw_finished_at is not None
            else None
        ),
    }


def status(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    session_id = str(params.get("session_id") or "").strip()
    if not session_id:
        raise CLIError("session_id required", code="missing_required")

    with connect(ctx.db_path) as conn:
        row = conn.execute(
            "SELECT * FROM task_history WHERE session_id = ? LIMIT 1",
            (session_id,),
        ).fetchone()
    if not row:
        raise CLIError("Session not found", code="not_found")
    return {
        "status": _row_to_status(row),
        "meta": {"id_model": task_cmd.build_id_model_meta(requested_by="session_id")},
    }


def token(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    payload = status(ctx, {"session_id": params.get("session_id"), "live": False})
    status_payload = payload.get("status", {})
    token_usage = status_payload.get("token_usage", {})
    return {
        "session_id": status_payload.get("session_id", ""),
        "token_usage": token_usage,
        "meta": {"id_model": task_cmd.build_id_model_meta(requested_by="session_id")},
    }


def reset_current(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    del params
    return chat_cmd.dispatch("reset_session", {}, ctx)


def cancel(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    session_id = str(params.get("session_id") or "").strip()
    if not session_id:
        raise CLIError("session_id required", code="missing_required")

    raise CLIError(
        "offline cancel is not supported; pass --live to use runtime channel",
        code="runtime_required",
    )


def messages(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    session_id = str(params.get("session_id") or "").strip()
    if not session_id:
        raise CLIError("session_id required", code="missing_required")
    return task_cmd.messages(
        ctx,
        {
            "session_id": session_id,
            "limit": params.get("limit"),
            "offset": params.get("offset"),
            "role": params.get("role"),
        },
    )


def search_messages(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    session_id = str(params.get("session_id") or "").strip()
    if not session_id:
        raise CLIError("session_id required", code="missing_required")
    return task_cmd.search_messages(
        ctx,
        {
            "session_id": session_id,
            "query": params.get("query"),
            "limit": params.get("limit"),
            "offset": params.get("offset"),
            "role": params.get("role"),
        },
    )


def last_message(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    session_id = str(params.get("session_id") or "").strip()
    if not session_id:
        raise CLIError("session_id required", code="missing_required")
    return task_cmd.last_message(
        ctx,
        {
            "session_id": session_id,
            "role": params.get("role"),
        },
    )


def dispatch(method: str, params: dict[str, Any], ctx: CLIContext) -> dict[str, Any]:
    handlers = {
        "status": status,
        "token": token,
        "reset_current": reset_current,
        "cancel": cancel,
        "messages": messages,
        "search_messages": search_messages,
        "last_message": last_message,
    }
    handler = handlers.get(method)
    if not handler:
        raise CLIError(f"Unknown session method: {method}", code="unknown_method")
    return handler(ctx, params)


def register(subparsers: Any) -> None:
    parser = subparsers.add_parser("session", help="Inspect and control sessions")
    session_sub = parser.add_subparsers(dest="session_cmd", required=True)

    status_parser = session_sub.add_parser("status", help="Get session status")
    status_parser.add_argument("--session-id", required=True)
    status_parser.add_argument("--live", action="store_true")
    status_parser.set_defaults(func=_cmd_status)

    token_parser = session_sub.add_parser("token", help="Get token usage by session")
    token_parser.add_argument("--session-id", required=True)
    token_parser.set_defaults(func=_cmd_token)

    reset_parser = session_sub.add_parser(
        "reset-current",
        help="Reset current chat main session in config",
    )
    reset_parser.add_argument("--yes", action="store_true")
    reset_parser.set_defaults(func=_cmd_reset_current)

    cancel_parser = session_sub.add_parser("cancel", help="Cancel a live session")
    cancel_parser.add_argument("--session-id", required=True)
    cancel_parser.add_argument("--live", action="store_true")
    cancel_parser.set_defaults(func=_cmd_cancel)

    messages_parser = session_sub.add_parser("messages", help="List messages by session")
    messages_parser.add_argument("--session-id", required=True)
    messages_parser.add_argument(
        "--role",
        default="",
        help="Filter role: user|assistant|system|tool",
    )
    messages_parser.add_argument("--limit", type=int, default=50)
    messages_parser.add_argument("--offset", type=int, default=0)
    messages_parser.set_defaults(func=_cmd_messages)

    search_parser = session_sub.add_parser(
        "search-messages",
        help="Search messages by session",
    )
    search_parser.add_argument("--session-id", required=True)
    search_parser.add_argument("--query", required=True)
    search_parser.add_argument(
        "--role",
        default="",
        help="Filter role: user|assistant|system|tool",
    )
    search_parser.add_argument("--limit", type=int, default=50)
    search_parser.add_argument("--offset", type=int, default=0)
    search_parser.set_defaults(func=_cmd_search_messages)

    last_parser = session_sub.add_parser("last-message", help="Show last message by session")
    last_parser.add_argument("--session-id", required=True)
    last_parser.add_argument("--role", default="", help="Filter role: user|assistant|system|tool")
    last_parser.set_defaults(func=_cmd_last_message)


def _normalize_offset(raw_offset: Any) -> int:
    try:
        parsed = int(raw_offset or 0)
    except Exception:  # noqa: BLE001
        parsed = 0
    return max(parsed, 0)


def _cmd_status(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {"session_id": args.session_id}
    if not args.live:
        result = invoke(
            method="task_history.get_by_session",
            params=params,
            ctx=ctx,
            local_call=lambda: dispatch("status", params, ctx),
        )
        if "status" in result:
            if "meta" not in result:
                result["meta"] = {
                    "id_model": task_cmd.build_id_model_meta(requested_by="session_id")
                }
            return result
        task_payload = result.get("task")
        if isinstance(task_payload, dict):
            return {
                "status": _task_to_status(task_payload, args.session_id),
                "meta": {
                    "id_model": task_cmd.build_id_model_meta(requested_by="session_id")
                },
            }
        return dispatch("status", params, ctx)

    return invoke(
        method="agent.get_status",
        params=params,
        ctx=ctx,
        local_call=lambda: dispatch("status", params, ctx),
    )


def _cmd_token(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {"session_id": args.session_id}
    result = invoke(
        method="task_history.get_by_session",
        params=params,
        ctx=ctx,
        local_call=lambda: dispatch("token", params, ctx),
    )
    if "token_usage" in result and "session_id" in result:
        if "meta" not in result:
            result["meta"] = {
                "id_model": task_cmd.build_id_model_meta(requested_by="session_id")
            }
        return result
    task_payload = result.get("task")
    if isinstance(task_payload, dict):
        token_usage = task_payload.get("token_usage", {})
        return {
            "session_id": str(task_payload.get("session_id") or args.session_id),
            "token_usage": token_usage if isinstance(token_usage, dict) else {},
            "meta": {"id_model": task_cmd.build_id_model_meta(requested_by="session_id")},
        }
    return dispatch("token", params, ctx)


def _cmd_reset_current(args: Any, ctx: CLIContext) -> dict[str, Any]:
    if not args.yes:
        raise CLIError("reset-current requires --yes", code="confirmation_required")
    return invoke(
        method="settings.update_config",
        params={"config": {"chat": {"main_session_id": ""}}},
        ctx=ctx,
        local_call=lambda: dispatch("reset_current", {}, ctx),
    )


def _cmd_cancel(args: Any, ctx: CLIContext) -> dict[str, Any]:
    if not args.live:
        raise CLIError("cancel requires --live", code="runtime_required")
    params = {"session_id": args.session_id}
    return invoke(
        method="agent.cancel",
        params=params,
        ctx=ctx,
        local_call=lambda: dispatch("cancel", params, ctx),
    )


def _cmd_messages(args: Any, ctx: CLIContext) -> dict[str, Any]:
    task = task_cmd.resolve_task_record(ctx, {"session_id": args.session_id})
    return task_cmd.build_message_list_payload(
        task,
        role=args.role,
        limit=normalize_positive_int(args.limit, default=50),
        offset=_normalize_offset(args.offset),
        requested_by="session_id",
    )


def _cmd_search_messages(args: Any, ctx: CLIContext) -> dict[str, Any]:
    query = str(args.query or "").strip()
    if not query:
        raise CLIError("query required", code="missing_required")
    task = task_cmd.resolve_task_record(ctx, {"session_id": args.session_id})
    return task_cmd.build_message_list_payload(
        task,
        role=args.role,
        query=query,
        limit=normalize_positive_int(args.limit, default=50),
        offset=_normalize_offset(args.offset),
        requested_by="session_id",
    )


def _cmd_last_message(args: Any, ctx: CLIContext) -> dict[str, Any]:
    task = task_cmd.resolve_task_record(ctx, {"session_id": args.session_id})
    return task_cmd.build_last_message_payload(
        task,
        role=args.role,
        requested_by="session_id",
    )
