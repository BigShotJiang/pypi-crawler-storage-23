"""Execution context for command handlers."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(slots=True)
class CLIContext:
    data_dir: Path
    db_path: Path
    pretty: bool
    mode: str
    api_base_url: str
    auth_token: str
    timeout_seconds: float
    logger: Any
