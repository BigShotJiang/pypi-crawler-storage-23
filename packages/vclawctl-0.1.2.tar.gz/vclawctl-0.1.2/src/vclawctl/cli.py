"""vclawctl CLI entrypoint."""

from __future__ import annotations

import argparse
import os
from typing import Any

from vclawctl.commands import agent, call, chat, config, schedule, session, task
from vclawctl.context import CLIContext
from vclawctl.errors import CLIError, ExitCode
from vclawctl.logging import configure_logger
from vclawctl.output import emit, error_payload, success_payload
from vclawctl.paths import resolve_data_dir, resolve_db_path


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="vclawctl",
        description="Control-plane CLI for v-claw",
    )
    parser.add_argument("--data-dir", default="", help="v-claw data directory")
    parser.add_argument("--pretty", action="store_true", help="Pretty-print JSON output")
    parser.add_argument("--verbose", action="store_true", help="Enable verbose logs on stderr")
    parser.add_argument(
        "--mode",
        choices=["api", "auto", "db"],
        default="api",
        help="Control channel mode: api, auto(api->db), db",
    )
    parser.add_argument(
        "--api-base-url",
        default="",
        help="Base URL of v-claw control API (e.g. http://127.0.0.1:7799/api/control/v1)",
    )
    parser.add_argument("--auth-token", default="", help="Bearer token for control API")
    parser.add_argument(
        "--auth-token-file",
        default="",
        help="Read bearer token from file",
    )
    parser.add_argument("--timeout", type=float, default=10.0, help="Runtime call timeout seconds")

    subparsers = parser.add_subparsers(dest="command", required=True)
    schedule.register(subparsers)
    agent.register(subparsers)
    task.register(subparsers)
    config.register(subparsers)
    chat.register(subparsers)
    session.register(subparsers)
    call.register(subparsers)

    return parser


def _handle(args: Any, ctx: CLIContext) -> dict[str, Any]:
    func = getattr(args, "func", None)
    if not callable(func):
        raise CLIError("command handler missing", code="handler_missing", exit_code=ExitCode.ERROR)
    return func(args, ctx)


def _resolve_auth_token(args: Any) -> str:
    direct = str(getattr(args, "auth_token", "") or "").strip()
    if direct:
        return direct

    token_file = str(getattr(args, "auth_token_file", "") or "").strip()
    if token_file:
        try:
            with open(token_file, encoding="utf-8") as fp:
                file_token = fp.read().strip()
        except OSError as exc:
            raise CLIError(
                f"failed to read auth token file: {exc}",
                code="auth_token_file_error",
            ) from exc
        if file_token:
            return file_token

    return str(os.environ.get("VCLAWCTL_AUTH_TOKEN", "") or "").strip()


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    logger = configure_logger(bool(args.verbose))
    data_dir = resolve_data_dir(args.data_dir or None)
    db_path = resolve_db_path(data_dir)
    api_base_url = (
        str(args.api_base_url or "").strip()
        or str(os.environ.get("VCLAWCTL_API_BASE_URL", "") or "").strip()
    )
    auth_token = _resolve_auth_token(args)
    ctx = CLIContext(
        data_dir=data_dir,
        db_path=db_path,
        pretty=bool(args.pretty),
        mode=str(args.mode or "api").strip().lower() or "api",
        api_base_url=api_base_url,
        auth_token=auth_token,
        timeout_seconds=float(args.timeout or 10.0),
        logger=logger,
    )

    try:
        result = _handle(args, ctx)
        emit(success_payload(result), pretty=ctx.pretty)
        return int(ExitCode.OK)
    except CLIError as exc:
        emit(error_payload(message=exc.message, code=exc.code), pretty=ctx.pretty)
        return int(exc.exit_code)
    except Exception as exc:  # noqa: BLE001
        logger.exception("Unhandled CLI failure")
        emit(error_payload(message=str(exc), code="internal_error"), pretty=ctx.pretty)
        return int(ExitCode.ERROR)


__all__ = ["main"]
