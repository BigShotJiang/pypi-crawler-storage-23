"""Shared lightweight typed aliases."""

from __future__ import annotations

from typing import Any

JSONDict = dict[str, Any]
