from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path

import pytest


@pytest.fixture()
def data_dir(tmp_path: Path) -> Path:
    data = tmp_path / "data"
    data.mkdir(parents=True, exist_ok=True)
    db_path = data / "v_claw.db"
    conn = sqlite3.connect(db_path)

    conn.execute(
        """
        CREATE TABLE config (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            config_json TEXT NOT NULL,
            updated_at REAL NOT NULL
        )
        """
    )
    conn.execute(
        """
        INSERT INTO config(id, config_json, updated_at)
        VALUES(1, ?, ?)
        """,
        (
            json.dumps(
                {
                    "chat": {
                        "default_agent_id": "default",
                        "main_session_id": "",
                        "session_max_cycles": 999,
                    },
                    "agent": {"language": "zh-CN"},
                },
                ensure_ascii=False,
            ),
            time.time(),
        ),
    )

    conn.execute(
        """
        CREATE TABLE agent_profiles (
            agent_id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT NOT NULL,
            system_prompt TEXT NOT NULL,
            model_backend TEXT NOT NULL,
            model_name TEXT NOT NULL,
            max_cycles INTEGER NOT NULL,
            language TEXT NOT NULL,
            allow_interruption INTEGER NOT NULL,
            use_workspace INTEGER NOT NULL,
            load_user_memory INTEGER NOT NULL,
            default_workspace_path TEXT NOT NULL,
            tools_json TEXT NOT NULL,
            skills_json TEXT NOT NULL,
            mcp_servers_json TEXT NOT NULL,
            callable_sub_agents_json TEXT NOT NULL DEFAULT '[]',
            created_at REAL NOT NULL,
            updated_at REAL NOT NULL
        )
        """
    )

    now = time.time()
    conn.execute(
        """
        INSERT INTO agent_profiles(
            agent_id, name, description, system_prompt,
            model_backend, model_name, max_cycles, language,
            allow_interruption, use_workspace, load_user_memory,
            default_workspace_path, tools_json, skills_json,
            mcp_servers_json, callable_sub_agents_json,
            created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            "default",
            "默认助手",
            "",
            "",
            "moonshot",
            "kimi-k2.5",
            20,
            "zh-CN",
            1,
            1,
            1,
            "",
            json.dumps(["memory_search"], ensure_ascii=False),
            "[]",
            "[]",
            "[]",
            now,
            now,
        ),
    )

    conn.execute(
        """
        CREATE TABLE task_history (
            task_id TEXT PRIMARY KEY,
            agent_id TEXT NOT NULL,
            session_id TEXT NOT NULL UNIQUE,
            title TEXT NOT NULL,
            prompt TEXT NOT NULL,
            session_kind TEXT NOT NULL DEFAULT 'task',
            workspace_path TEXT NOT NULL DEFAULT '',
            workspace_source TEXT NOT NULL DEFAULT 'global_default',
            status TEXT NOT NULL,
            cycles_count INTEGER NOT NULL DEFAULT 0,
            created_at REAL NOT NULL,
            finished_at REAL,
            is_favorite INTEGER NOT NULL DEFAULT 0,
            progress_json TEXT NOT NULL,
            final_answer TEXT NOT NULL DEFAULT '',
            token_usage_json TEXT NOT NULL DEFAULT '{}',
            agent_name TEXT NOT NULL DEFAULT '',
            model_name TEXT NOT NULL DEFAULT '',
            parent_task_id TEXT NOT NULL DEFAULT '',
            is_sub_task INTEGER NOT NULL DEFAULT 0
        )
        """
    )

    conn.execute(
        """
        CREATE TABLE scheduled_tasks (
            task_id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            schedule_type TEXT NOT NULL,
            schedule_config_json TEXT NOT NULL,
            prompt TEXT NOT NULL,
            agent_profile TEXT NOT NULL,
            max_cycles INTEGER NOT NULL,
            enabled INTEGER NOT NULL,
            timezone TEXT NOT NULL,
            target_main_session_id TEXT NOT NULL DEFAULT '',
            notify_policy TEXT NOT NULL DEFAULT 'announce',
            notify_on_success INTEGER NOT NULL DEFAULT 1,
            notify_on_error INTEGER NOT NULL DEFAULT 1,
            last_run_at REAL,
            last_status TEXT,
            next_run_at REAL,
            created_at REAL NOT NULL
        )
        """
    )

    conn.execute(
        """
        CREATE TABLE schedule_executions (
            execution_id TEXT PRIMARY KEY,
            task_id TEXT NOT NULL,
            started_at REAL NOT NULL,
            finished_at REAL,
            status TEXT NOT NULL,
            result TEXT NOT NULL DEFAULT '',
            error TEXT NOT NULL DEFAULT '',
            run_session_id TEXT NOT NULL DEFAULT '',
            run_task_id TEXT NOT NULL DEFAULT '',
            delivery_requested INTEGER NOT NULL DEFAULT 0,
            delivery_attempted INTEGER NOT NULL DEFAULT 0,
            delivery_status TEXT NOT NULL DEFAULT '',
            delivery_error TEXT NOT NULL DEFAULT '',
            delivered_at REAL
        )
        """
    )

    conn.commit()
    conn.close()
    return data
