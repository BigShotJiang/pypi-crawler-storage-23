from __future__ import annotations

import io
import sys

from vclawctl.output import emit


def _with_gbk_stdout(monkeypatch):
    buffer = io.BytesIO()
    stream = io.TextIOWrapper(buffer, encoding="gbk", errors="strict")
    monkeypatch.setattr(sys, "stdout", stream)
    return buffer, stream


def test_emit_falls_back_to_ascii_on_gbk(monkeypatch):
    buffer, stream = _with_gbk_stdout(monkeypatch)

    emit({"ok": True, "msg": "hello😊"}, pretty=False)
    stream.flush()
    text = buffer.getvalue().decode("gbk")

    assert '"ok": true' in text
    assert "\\ud83d\\ude0a" in text


def test_emit_pretty_falls_back_to_ascii_on_gbk(monkeypatch):
    buffer, stream = _with_gbk_stdout(monkeypatch)

    emit({"ok": True, "msg": "hello😊"}, pretty=True)
    stream.flush()
    text = buffer.getvalue().decode("gbk")

    assert '"ok": true' in text
    assert "\\ud83d\\ude0a" in text
    assert "\n" in text
