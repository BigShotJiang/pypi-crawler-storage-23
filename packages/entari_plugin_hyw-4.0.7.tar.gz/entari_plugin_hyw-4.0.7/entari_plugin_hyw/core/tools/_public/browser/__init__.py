"""
hyw_core.browser_control - Browser automation and rendering

This subpackage provides:
- BrowserManager: Shared browser instance management
- PageService: Page fetching and screenshot capabilities
- RenderService: Vue-based card rendering
- Search engines: DuckDuckGo adapter
"""

from .manager import (
    SharedBrowserManager,
    get_shared_browser_manager,
    close_shared_browser,
)

from .service import (
    ScreenshotService,
    get_screenshot_service,
    close_screenshot_service,
    prestart_browser,
)

from .renderer import (
    ContentRenderer,
    get_content_renderer,
    set_global_renderer,
)

from .engines.base import SearchEngine
from .engines.duckduckgo import DuckDuckGoEngine
from .engines.default import DefaultEngine

# Aliases for cleaner API
BrowserManager = SharedBrowserManager
PageService = ScreenshotService
BrowserService = ScreenshotService  # Added alias for compatibility
RenderService = ContentRenderer

__all__ = [
    # Browser Management
    "BrowserManager",
    "SharedBrowserManager",
    "get_shared_browser_manager",
    "close_shared_browser",

    # Page Service
    "PageService",
    "BrowserService",  # Export alias
    "ScreenshotService",
    "get_screenshot_service",
    "close_screenshot_service",
    "prestart_browser",
    
    # Render Service
    "RenderService",
    "ContentRenderer",
    "get_content_renderer",
    "set_global_renderer",
    
    # Search Engines
    "SearchEngine",
    "DuckDuckGoEngine",
    "DefaultEngine",
]
