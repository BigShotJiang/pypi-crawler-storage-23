#
#  Copyright ©2024-2026. Levo, Inc. All Rights Reserved.
#  You may not copy, reproduce, distribute, publish, display, perform, modify, create derivative works, transmit,
#  or in any way exploit any such software/code, nor may you distribute any part of this software/code over any network,
#  including a local area network, sell or offer it for commercial purposes.
#
import base64

import pytest
import requests

from levo_commons.models import Response
from levo_commons.request_utils import (
    get_error_code_from_response_body,
    is_4xx_error_response,
    is_valid_2xx_response,
    set_error_code_config_provider,
)


def test_is_4xx_error_response():
    response = Response(
        status_code=400,
        body="{}",
        headers={},
        method="GET",
        uri="/test",
        message="Bad Request",
        http_version="HTTP/1.1",
        encoding=None,
    )
    response.status_code = 400
    assert is_4xx_error_response(response) is True

    # Add json body to the response and verify
    response.body = '{"error": "Bad Request"}'
    assert is_4xx_error_response(response) is True

    # Set status code to 200 but indicate error in the body
    response.status_code = 200
    response.body = '{"error": {"code": 400, "message": "Bad Request"}}'
    assert is_4xx_error_response(response) is True

    response.body = '{"status_code": 400, "message": "Bad Request"}'
    assert is_4xx_error_response(response) is True

    response.status_code = 500
    assert is_4xx_error_response(response) is False


def test_is_valid_2xx_response():
    response = Response(
        status_code=200,
        body="{}",
        headers={},
        method="GET",
        uri="/test",
        message="OK",
        http_version="HTTP/1.1",
        encoding=None,
    )
    assert is_valid_2xx_response(response) is True

    response.status_code = 201
    assert is_valid_2xx_response(response) is True

    response.status_code = 204
    assert is_valid_2xx_response(response) is True

    response.status_code = 400
    assert is_valid_2xx_response(response) is False

    response.status_code = 500
    assert is_valid_2xx_response(response) is False

    response.status_code = 200
    response.body = '{"errorCode": 400, "errorMessage": "Bad Request"}'
    assert is_valid_2xx_response(response) is False

    response.body = '{"statusCode": 400, "errorMessage": "Bad Request"}'
    assert is_valid_2xx_response(response) is False

    response.body = '{"error": {"statusCode": 400, "errorMessage": "Bad Request"}}'
    assert is_valid_2xx_response(response) is False

    response.body = base64.b64encode(
        '{"error": {"statusCode": 400, "errorMessage": "Bad Request"}}'.encode()
    )
    assert is_valid_2xx_response(response) is False


def test_string_error_code():
    response = requests.Response()
    response._content = '{"success":false,"code":"unauthorized","data":null,"msg":"Authorization failed"}'
    assert get_error_code_from_response_body(response) == 401

    response._content = '{"success":false,"code":"invalid_input","data":null,"msg":"Invalid auth token provided"}'
    assert get_error_code_from_response_body(response) == 400

    response._content = (
        '{"success":false,"code":"RETRY","data":{"msg":"Please try again."},"msg":""}'
    )
    assert get_error_code_from_response_body(response) == 503

    response._content = (
        '{"success":true,"code":"OK","data":{"IS_FUTURE_ENABLED":false},"msg":""}'
    )
    assert get_error_code_from_response_body(response) is None

    response._content = '{"success":true,"code":"200","data":{"express_kyc_status":"NOT_STARTED"},"msg":""}'
    assert get_error_code_from_response_body(response) == 200

    response._content = (
        '{"success":false,"status":"retry","error":{"code":401},"data":{'
        '"express_kyc_status":"NOT_STARTED"},"msg":""}'
    )
    assert get_error_code_from_response_body(response) == 401

    response._content = '{"success":true,"code":"401","data":{"express_kyc_status":"NOT_STARTED"},"msg":""}'
    assert get_error_code_from_response_body(response) == 401

    response._content = '{"result":41406, "data":{"error":"wrong_params"},"msg":""}'
    assert get_error_code_from_response_body(response) == 400

    response._content = (
        '{"result":41406, "code":"403", "data":{"error":"invalid_token"},"msg":""}'
    )
    assert get_error_code_from_response_body(response) == 403

    response._content = '{"result":41406, "data":{"error":"invalid_token"},"msg":""}'
    assert get_error_code_from_response_body(response) == 401


@pytest.mark.parametrize("res_body", ["[]", "12345"])
def test_non_dict_json_body(res_body):
    response = requests.Response()
    response._content = res_body
    try:
        assert get_error_code_from_response_body(response) is None
    except AttributeError:
        pytest.fail("Should not raise AttributeError")


# --- Tests for custom error_code_keys and string_code_to_status config ---


def test_custom_error_code_keys_via_explicit_params():
    """Custom keys via explicit params work without provider."""
    response = requests.Response()
    response._content = b'{"resultCode": "rate_limited"}'

    # Without custom config, resultCode is not in default keys - returns None
    assert get_error_code_from_response_body(response) is None

    # With custom keys and string_code_to_status, matches
    code = get_error_code_from_response_body(
        response,
        error_code_keys=["resultCode"],
        string_code_to_status={"rate_limited": 429},
    )
    assert code == 429


def test_custom_string_code_exact_match():
    """Exact match for long strings like 'Invalid Req' works."""
    response = requests.Response()
    response._content = b'{"error": "Invalid Req"}'

    code = get_error_code_from_response_body(
        response,
        string_code_to_status={"Invalid Req": 401},
    )
    assert code == 401


def test_custom_string_code_no_substring_match():
    """Partial/substring match is NOT supported - only exact match."""
    response = requests.Response()
    response._content = b'{"error": "Invalid Req - please try again"}'

    # "Invalid Req" is substring of the value - should NOT match (exact match only)
    code = get_error_code_from_response_body(
        response,
        string_code_to_status={"Invalid Req": 401},
    )
    assert code is None


def test_config_provider_is_invoked():
    """Provider is invoked when no explicit params passed."""
    try:
        set_error_code_config_provider(lambda: (["resultCode"], {"rate_limited": 429}))
        response = requests.Response()
        response._content = b'{"resultCode": "rate_limited"}'

        code = get_error_code_from_response_body(response)
        assert code == 429
    finally:
        set_error_code_config_provider(lambda: (None, None))


def test_custom_overrides_default_string_code():
    """Custom string_code_to_status overrides default for same key."""
    response = requests.Response()
    response._content = b'{"code": "invalid_token"}'

    # Default: invalid_token -> 401
    assert get_error_code_from_response_body(response) == 401

    # Custom override: invalid_token -> 403
    code = get_error_code_from_response_body(
        response,
        string_code_to_status={"invalid_token": 403},
    )
    assert code == 403


def test_custom_keys_prepended_to_defaults():
    """Custom keys are checked first, then defaults."""
    response = requests.Response()
    response._content = b'{"apiError": "throttled"}'

    # apiError not in default keys
    assert get_error_code_from_response_body(response) is None

    # With custom key + custom status, matches
    code = get_error_code_from_response_body(
        response,
        error_code_keys=["apiError"],
        string_code_to_status={"throttled": 429},
    )
    assert code == 429
