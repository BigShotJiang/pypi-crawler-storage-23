<div align="center">

# CoPaw

[![Documentation](https://img.shields.io/badge/docs-website-green.svg?logo=readthedocs)](http://copaw.agentscope.com/)
[![Python 3.10–3.13](https://img.shields.io/badge/python-3.10--3.13-blue.svg?logo=python)](https://www.python.org/downloads/)
[![ModelScope](https://img.shields.io/badge/ModelScope-One--click-orange.svg)](https://modelscope.cn/studios/fork?target=AgentScope/CoPaw)
[![License](https://img.shields.io/badge/license-Apache%202.0-red.svg?logo=apache)](LICENSE)

[[Documentation](http://copaw.agentscope.com/)] [[Try ModelScope](https://modelscope.cn/studios/fork?target=AgentScope/CoPaw)] [[中文 README](README_zh.md)]

<p align="center">
  <img src="https://img.alicdn.com/imgextra/i1/O1CN01tvT5rg1JHQNRP8tXR_!!6000000001003-2-tps-1632-384.png" alt="CoPaw Logo" width="120">
</p>

<p align="center"><b>Works for you, grows with you.</b></p>

Your Personal AI Assistant; easy to install, deploy on your own machine or on the cloud; supports multiple chat apps with easily extensible capabilities.

> **Core capabilities:**
>
> **Every channel** — DingTalk, Feishu, QQ, Discord, iMessage, and more. One assistant, connect as you need.
>
> **Under your control** — Memory and personalization under your control. Deploy locally or in the cloud; scheduled reminders to any channel.
>
> **Skills** — Built-in cron; custom skills in your workspace, auto-loaded. No lock-in.
>
> <details>
> <summary><b>What you can do</b></summary>
>
> <br>
>
> Social: daily digest of hot posts (Xiaohongshu, Zhihu, Reddit), Bilibili/YouTube summaries.
> Productivity: newsletter digests to DingTalk/Feishu/QQ, contacts from email/calendar.
> Creative: describe your goal, run overnight, get a draft next day.
> Research: track tech/AI news, personal knowledge base.
> Desktop: organize files, read/summarize docs, request files in chat.
> Explore: combine Skills and cron into your own agentic app.
>
> </details>

</div>

---

## Table of Contents

> **Recommended reading:**
>
> - **I want to run CoPaw in 3 commands**: [Quick Start](#-quick-start) → open Console in browser.
> - **I want to chat in DingTalk / Feishu / QQ**: [Quick Start](#-quick-start) → [Channels](http://copaw.agentscope.com/docs/channels).
> - **I don’t want to install Python**: [ModelScope one-click](https://modelscope.cn/studios/fork?target=AgentScope/CoPaw).

- [Quick Start](#-quick-start)
- [Documentation](#-documentation)
- [Install from source](#-install-from-source)
- [Why CoPaw?](#-why-copaw)
- [Built by](#-built-by)
- [License](#-license)

---

## Quick Start

### Prerequisites

- Python 3.10 – 3.13
- pip

### Installation

```bash
pip install copaw
copaw init --defaults   # or: copaw init (interactive)
copaw app
```

Then open **http://127.0.0.1:8088/** in your browser for the Console (chat with CoPaw, configure the agent). To talk in DingTalk, Feishu, QQ, etc., add a channel in the [docs](http://copaw.agentscope.com/docs/channels).

![Console](https://img.alicdn.com/imgextra/i4/O1CN01jQ8IKh1oWJL5C0v5x_!!6000000005232-2-tps-3494-1644.png)

**No Python?** [ModelScope Studio](https://modelscope.cn/studios/fork?target=AgentScope/CoPaw) one-click setup (no local install). Set your Studio to **non-public** so others cannot control your CoPaw.

---

## Documentation

| Topic | Description |
|-------|-------------|
| [Introduction](http://copaw.agentscope.com/docs/intro) | What CoPaw is and how you use it |
| [Quick start](http://copaw.agentscope.com/docs/quickstart) | Install and run (local or ModelScope Studio) |
| [Console](http://copaw.agentscope.com/docs/console) | Web UI for chat and agent config |
| [Channels](http://copaw.agentscope.com/docs/channels) | DingTalk, Feishu, QQ, Discord, iMessage, and more |
| [Heartbeat](http://copaw.agentscope.com/docs/heartbeat) | Scheduled check-in or digest |
| [CLI](http://copaw.agentscope.com/docs/cli) | Init, cron jobs, skills, clean |
| [Skills](http://copaw.agentscope.com/docs/skills) | Extend and customize capabilities |
| [Config](http://copaw.agentscope.com/docs/config) | Working directory and config file |

Full docs in this repo: [website/public/docs/](website/public/docs/).

---

## Install from source

```bash
git clone https://github.com/agentscope-ai/CoPaw.git
cd CoPaw
pip install -e .
```

- **Dev** (tests, formatting): `pip install -e ".[dev]"`
- **Console** (build frontend): `cd console && npm ci && npm run build`, then `copaw app` from project root.

---

## Why CoPaw?

CoPaw represents both a **Co Personal Agent Workstation** and a "co-paw"—a partner always by your side. More than just a cold tool, CoPaw is a warm "little paw" always ready to lend a hand (or a paw!). It is the ultimate teammate for your digital life.

---

## Built by

[AgentScope team](https://github.com/agentscope-ai) · [AgentScope](https://github.com/agentscope-ai/agentscope) · [AgentScope Runtime](https://github.com/agentscope-ai/agentscope-runtime) · [ReMe](https://github.com/agentscope-ai/ReMe)

---

## License

CoPaw is released under the [Apache License 2.0](LICENSE).
