---
summary: "HEARTBEAT.md 工作区模板"
read_when:
  - 手动引导工作区
---

# HEARTBEAT.md

# 保持此文件为空（或只有注释）可跳过 heartbeat API 调用。

# 想让 agent 定期检查什么，就在下面加任务。
