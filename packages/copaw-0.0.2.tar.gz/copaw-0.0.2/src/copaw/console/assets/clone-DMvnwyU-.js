import{at as r}from"./index-D__Q0Ua-.js";var a=4;function n(o){return r(o,a)}export{n as c};
