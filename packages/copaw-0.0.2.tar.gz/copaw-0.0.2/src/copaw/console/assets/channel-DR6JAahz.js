import{ar as o,as as s}from"./index-D__Q0Ua-.js";const t=(r,a)=>o.lang.round(s.parse(r)[a]);export{t as c};
