"""GhostQA Viewer — Local web dashboard for browsing test run evidence."""
