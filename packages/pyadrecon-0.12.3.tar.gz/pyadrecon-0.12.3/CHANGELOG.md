## [0.12.3](https://github.com/l4rm4nd/PyADRecon/compare/v0.12.2...v0.12.3) (2026-02-21)


### Bug Fixes

* add krbtgt rotation and protected users group to dashboard ([03e3046](https://github.com/l4rm4nd/PyADRecon/commit/03e30466f1f1f9033e0aa3341dba7521f855a62e))

## [0.12.2](https://github.com/l4rm4nd/PyADRecon/compare/v0.12.1...v0.12.2) (2026-02-21)


### Bug Fixes

* Update Dockerfile ([783e6ea](https://github.com/l4rm4nd/PyADRecon/commit/783e6eab3f3396107f52c1183a135efaa5766561))

## [0.12.1](https://github.com/l4rm4nd/PyADRecon/compare/v0.12.0...v0.12.1) (2026-02-21)


### Bug Fixes

* column sorting bug ([d160142](https://github.com/l4rm4nd/PyADRecon/commit/d160142e94d919421f5996c57e83187ac217a70b))

## [0.12.0](https://github.com/l4rm4nd/PyADRecon/compare/v0.11.14...v0.12.0) (2026-02-21)


### Features

* Implement dashboard generation toggle in arguments ([887ea40](https://github.com/l4rm4nd/PyADRecon/commit/887ea403d7a30a21bbc8feaa67d58eccee88302d))

## [0.11.14](https://github.com/l4rm4nd/PyADRecon/compare/v0.11.13...v0.11.14) (2026-02-20)


### Bug Fixes

* initialize sid mappings earlier to support individual --collect adcs runs ([b036a8f](https://github.com/l4rm4nd/PyADRecon/commit/b036a8fde34eae88cb14e570f9feb92a4a0e0fb3))

