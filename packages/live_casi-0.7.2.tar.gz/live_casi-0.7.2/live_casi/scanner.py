#!/usr/bin/env python3
"""
Firmware/Binary Scanner — Phase 2 of live-casi v0.2.0

Sliding-window CASI across any binary file. Identifies encrypted vs
plaintext regions with cipher identification for weak/encrypted regions.

Usage:
    from live_casi.scanner import scan_binary
    regions = scan_binary(data, window_size=32768, step_size=4096)
    for r in regions:
        print(f"{r['offset_hex']}: {r['verdict']} (CASI {r['casi']:.1f})")
"""

import os
import time
import numpy as np

from .core import (
    compute_signal, STRATEGY_NAMES, LiveCASIWithStorage,
    casi_verdict, casi_color,
    BOLD, RESET, DIM, GREEN, YELLOW, RED, CYAN,
)


# ═══════════════════════════════════════════════════════════════
# SLIDING WINDOW ENGINE
# ═══════════════════════════════════════════════════════════════

def _classify_casi(casi):
    """Classify a CASI score into region type."""
    if casi is None:
        return 'UNKNOWN'
    if casi > 10.0:
        return 'PLAINTEXT'
    if casi > 2.0:
        return 'WEAK'
    if casi > 1.5:
        return 'BORDERLINE'
    return 'ENCRYPTED'


def _region_color(verdict):
    """Color for region verdict."""
    if verdict == 'PLAINTEXT':
        return RED
    if verdict == 'WEAK':
        return YELLOW
    if verdict in ('ENCRYPTED', 'BORDERLINE'):
        return GREEN
    return DIM


def scan_binary(data, window_size=32768, step_size=4096, key_size=32):
    """Scan a binary blob with sliding-window CASI.

    Args:
        data: bytes — the binary data to scan
        window_size: int — window size in bytes (default 32KB)
        step_size: int — step between windows (default 4KB)
        key_size: int — key size for CASI (default 32)

    Returns:
        list of dicts, each with:
            offset: int — byte offset of window start
            offset_hex: str — hex representation
            casi: float — CASI score
            verdict: str — PLAINTEXT/WEAK/ENCRYPTED/BORDERLINE
            dominant_strategy: str — highest signal strategy
            signal_total: int — total signal count
    """
    if len(data) < window_size:
        # If data is smaller than window, analyze the whole thing
        window_size = (len(data) // key_size) * key_size
        if window_size < key_size * 100:
            return []

    # Compute baseline once
    n_baseline_keys = min(window_size // key_size, 10000)
    baseline_keys = np.frombuffer(
        os.urandom(n_baseline_keys * key_size),
        dtype=np.uint8
    ).reshape(-1, key_size)
    baseline_signal = compute_signal(baseline_keys)
    baseline_total = max(baseline_signal['total'], 1)

    results = []
    for offset in range(0, len(data) - window_size + 1, step_size):
        window = data[offset:offset + window_size]
        n_keys = len(window) // key_size
        if n_keys < 100:
            continue

        keys = np.frombuffer(window[:n_keys * key_size], dtype=np.uint8).reshape(n_keys, key_size)
        signal = compute_signal(keys)
        casi = signal['total'] / baseline_total

        # Find dominant strategy
        strat_vals = [(s, signal.get(s, 0)) for s in STRATEGY_NAMES]
        strat_vals.sort(key=lambda x: -x[1])
        dominant = strat_vals[0][0] if strat_vals[0][1] > 0 else 'none'

        verdict = _classify_casi(casi)

        results.append({
            'offset': offset,
            'offset_hex': f'0x{offset:06X}',
            'casi': casi,
            'verdict': verdict,
            'dominant_strategy': dominant,
            'signal_total': signal['total'],
        })

    return results


def detect_regions(scan_results):
    """Group consecutive scan results with similar verdicts into regions.

    Args:
        scan_results: list from scan_binary()

    Returns:
        list of region dicts with:
            verdict: str
            start_offset: int
            end_offset: int
            size: int
            avg_casi: float
            min_casi: float
            max_casi: float
    """
    if not scan_results:
        return []

    regions = []
    current = {
        'verdict': scan_results[0]['verdict'],
        'start_offset': scan_results[0]['offset'],
        'end_offset': scan_results[0]['offset'],
        'casi_values': [scan_results[0]['casi']],
    }

    for i in range(1, len(scan_results)):
        r = scan_results[i]
        # Merge ENCRYPTED and BORDERLINE into same region
        cur_v = current['verdict']
        new_v = r['verdict']
        same_type = (cur_v == new_v or
                     (cur_v in ('ENCRYPTED', 'BORDERLINE') and new_v in ('ENCRYPTED', 'BORDERLINE')))

        if same_type:
            current['end_offset'] = r['offset']
            current['casi_values'].append(r['casi'])
        else:
            # Finalize current region
            vals = current['casi_values']
            regions.append({
                'verdict': current['verdict'],
                'start_offset': current['start_offset'],
                'end_offset': current['end_offset'],
                'start_hex': f'0x{current["start_offset"]:06X}',
                'end_hex': f'0x{current["end_offset"]:06X}',
                'size': current['end_offset'] - current['start_offset'],
                'avg_casi': sum(vals) / len(vals),
                'min_casi': min(vals),
                'max_casi': max(vals),
            })
            current = {
                'verdict': r['verdict'],
                'start_offset': r['offset'],
                'end_offset': r['offset'],
                'casi_values': [r['casi']],
            }

    # Finalize last region
    vals = current['casi_values']
    regions.append({
        'verdict': current['verdict'],
        'start_offset': current['start_offset'],
        'end_offset': current['end_offset'],
        'start_hex': f'0x{current["start_offset"]:06X}',
        'end_hex': f'0x{current["end_offset"]:06X}',
        'size': current['end_offset'] - current['start_offset'],
        'avg_casi': sum(vals) / len(vals),
        'min_casi': min(vals),
        'max_casi': max(vals),
    })

    return regions


def _size_fmt(n):
    """Format byte count as human-readable string."""
    if n >= 1024 * 1024:
        return f'{n / (1024*1024):.1f} MB'
    if n >= 1024:
        return f'{n / 1024:.0f} KB'
    return f'{n} B'


# ═══════════════════════════════════════════════════════════════
# CLI: --scan
# ═══════════════════════════════════════════════════════════════

def run_scan(args):
    """CLI handler for --scan mode."""
    import json as json_mod
    import sys

    filepath = args.scan
    quiet = getattr(args, 'quiet', False)
    json_out = getattr(args, 'json', False)
    window_size = getattr(args, 'window_size', 32768)
    step_size = getattr(args, 'step_size', 4096)

    try:
        with open(filepath, 'rb') as f:
            data = f.read()
    except FileNotFoundError:
        print(f'{RED}Error: file not found: {filepath}{RESET}')
        sys.exit(2)

    if len(data) < args.key_size * 100:
        print(f'{RED}Error: file too small ({len(data)} bytes, need at least {args.key_size * 100}){RESET}')
        sys.exit(2)

    t0 = time.time()
    scan_results = scan_binary(data, window_size=window_size,
                                step_size=step_size, key_size=args.key_size)
    regions = detect_regions(scan_results)
    dt = time.time() - t0

    # Optional: cipher identification for weak/encrypted regions
    try_identify = not quiet
    cipher_ids = {}
    if try_identify and regions:
        try:
            from .identify import identify_cipher
            for i, reg in enumerate(regions):
                if reg['verdict'] in ('WEAK', 'ENCRYPTED', 'BORDERLINE'):
                    start = reg['start_offset']
                    end = min(reg['end_offset'] + window_size, len(data))
                    region_data = data[start:end]
                    if len(region_data) >= args.key_size * 100:
                        result = identify_cipher(region_data, key_size=args.key_size)
                        if result['confidence'] > 0.5:
                            cipher_ids[i] = result
        except ImportError:
            pass

    if json_out:
        out = {
            'source': filepath,
            'bytes': len(data),
            'window_size': window_size,
            'step_size': step_size,
            'regions': [],
            'scan_points': len(scan_results),
            'elapsed_seconds': round(dt, 2),
        }
        for i, reg in enumerate(regions):
            rd = {
                'verdict': reg['verdict'],
                'start_offset': reg['start_offset'],
                'end_offset': reg['end_offset'],
                'size': reg['size'],
                'avg_casi': round(reg['avg_casi'], 2),
            }
            if i in cipher_ids:
                rd['cipher'] = cipher_ids[i]['cipher']
                rd['cipher_confidence'] = cipher_ids[i]['confidence']
            out['regions'].append(rd)
        print(json_mod.dumps(out, indent=2))
        return

    if quiet:
        for reg in regions:
            print(f'{reg["start_hex"]}-{reg["end_hex"]} {reg["verdict"]} {reg["avg_casi"]:.1f}')
        return

    # Full display
    print()
    print(f'{BOLD}{CYAN}CASI Binary Scanner{RESET}')
    print(f'{DIM}Scanning {filepath} ({_size_fmt(len(data))}, '
          f'window={_size_fmt(window_size)}, step={_size_fmt(step_size)}){RESET}')
    print()

    if not regions:
        print(f'  {DIM}No regions detected (file too small?){RESET}')
        return

    # Region table
    print(f'  {"Region":<12s}  {"Offset":<22s}  {"Size":>8s}  {"CASI":>6s}  {"Verdict":<12s}  {"Cipher"}')
    print(f'  {"─"*12}  {"─"*22}  {"─"*8}  {"─"*6}  {"─"*12}  {"─"*20}')

    encrypted_size = 0
    plaintext_size = 0

    for i, reg in enumerate(regions):
        color = _region_color(reg['verdict'])
        size_str = _size_fmt(reg['size']) if reg['size'] > 0 else _size_fmt(window_size)

        cipher_str = ''
        if i in cipher_ids:
            ci = cipher_ids[i]
            cipher_str = f'{ci["cipher"]} ({ci["confidence"]:.0%})'

        print(f'  {color}{reg["verdict"]:<12s}{RESET}  '
              f'{reg["start_hex"]}-{reg["end_hex"]}  '
              f'{size_str:>8s}  '
              f'{color}{reg["avg_casi"]:>6.1f}{RESET}  '
              f'{color}{reg["verdict"]:<12s}{RESET}  '
              f'{cipher_str}')

        if reg['verdict'] in ('ENCRYPTED', 'BORDERLINE'):
            encrypted_size += max(reg['size'], window_size)
        elif reg['verdict'] == 'PLAINTEXT':
            plaintext_size += max(reg['size'], window_size)

    print()
    print(f'  {DIM}Summary: {RESET}', end='')
    parts = []
    if encrypted_size > 0:
        parts.append(f'{GREEN}{_size_fmt(encrypted_size)} encrypted{RESET}')
    if plaintext_size > 0:
        parts.append(f'{RED}{_size_fmt(plaintext_size)} plaintext{RESET}')
    weak_size = len(data) - encrypted_size - plaintext_size
    if weak_size > 0 and any(r['verdict'] == 'WEAK' for r in regions):
        parts.append(f'{YELLOW}{_size_fmt(weak_size)} weak crypto{RESET}')
    print(', '.join(parts) if parts else 'No clear regions')

    print(f'  {DIM}Elapsed: {dt:.2f}s ({len(scan_results)} scan points){RESET}')
    print()
