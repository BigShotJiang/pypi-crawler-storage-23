#!/usr/bin/env python3
"""
CASI vs NIST SP 800-22 — Head-to-head comparison.

Implements 5 NIST SP 800-22 randomness tests and compares their detection
power against CASI on the same byte streams. Identifies cases where CASI
detects weakness that NIST misses (and vice versa).

This is a key selling point: CASI detects cryptanalytic structural weakness
that statistical tests cannot (and vice versa — NIST catches implementation
bugs that CASI's crypto strategies ignore).

NIST Tests implemented:
  1. Frequency (Monobit) Test
  2. Frequency Test within a Block
  3. Runs Test
  4. Longest Run of Ones in a Block
  5. Binary Matrix Rank Test

Usage:
    from live_casi.nist_compare import compare_all
    report = compare_all()
"""

import math
import numpy as np
from scipy import special as sp_special
from scipy import stats as sp_stats

from .ciphers import CIPHERS
from .core import compute_crypto_signal, compute_signal


# ═══════════════════════════════════════════════════════════════
# NIST SP 800-22 Tests
# ═══════════════════════════════════════════════════════════════

def nist_frequency(bits):
    """NIST Test 1: Frequency (Monobit) Test.
    Tests whether the number of 0s and 1s are approximately equal."""
    n = len(bits)
    s = np.sum(2 * bits.astype(np.int32) - 1)
    s_obs = abs(s) / math.sqrt(n)
    p_value = sp_special.erfc(s_obs / math.sqrt(2))
    return p_value


def nist_block_frequency(bits, block_size=128):
    """NIST Test 2: Frequency Test within a Block.
    Tests proportion of ones in M-bit blocks."""
    n = len(bits)
    n_blocks = n // block_size
    if n_blocks < 1:
        return 1.0

    blocks = bits[:n_blocks * block_size].reshape(n_blocks, block_size)
    proportions = np.mean(blocks, axis=1)
    chi_sq = 4.0 * block_size * np.sum((proportions - 0.5) ** 2)
    p_value = sp_special.gammaincc(n_blocks / 2.0, chi_sq / 2.0)
    return p_value


def nist_runs(bits):
    """NIST Test 3: Runs Test.
    Tests the total number of runs (consecutive sequences of identical bits)."""
    n = len(bits)
    pi = np.mean(bits)

    # Pre-test: frequency within bounds
    tau = 2.0 / math.sqrt(n)
    if abs(pi - 0.5) >= tau:
        return 0.0  # Frequency test already fails

    # Count runs
    transitions = np.sum(bits[1:] != bits[:-1])
    v_obs = transitions + 1

    p_value = sp_special.erfc(
        abs(v_obs - 2.0 * n * pi * (1 - pi)) /
        (2.0 * math.sqrt(2.0 * n) * pi * (1 - pi))
    )
    return p_value


def nist_longest_run(bits, block_size=128):
    """NIST Test 4: Longest Run of Ones in a Block.
    Tests the longest run of ones in M-bit blocks."""
    n = len(bits)
    n_blocks = n // block_size
    if n_blocks < 8:
        return 1.0

    # Use first n_blocks blocks
    blocks = bits[:n_blocks * block_size].reshape(n_blocks, block_size)

    # Find longest run of ones in each block
    longest_runs = np.zeros(n_blocks, dtype=np.int32)
    for i in range(n_blocks):
        max_run = 0
        current_run = 0
        for b in blocks[i]:
            if b == 1:
                current_run += 1
                max_run = max(max_run, current_run)
            else:
                current_run = 0
        longest_runs[i] = max_run

    # For block_size=128: K=5, expected distribution parameters
    # Bin boundaries: <=4, 5, 6, 7, 8, >=9
    if block_size == 128:
        K = 5
        bins = [4, 5, 6, 7, 8]
        pi_vals = [0.1174, 0.2430, 0.2493, 0.1752, 0.1027, 0.1124]
    else:
        # Fallback: simple chi-squared against expected
        expected_longest = math.log2(block_size)
        std_lr = math.sqrt(expected_longest)
        z = abs(np.mean(longest_runs) - expected_longest) / (std_lr / math.sqrt(n_blocks))
        return sp_special.erfc(z / math.sqrt(2))

    # Count how many blocks fall in each bin
    v = np.zeros(K + 1, dtype=np.float64)
    for lr in longest_runs:
        if lr <= bins[0]:
            v[0] += 1
        elif lr >= bins[-1] + 1:
            v[K] += 1
        else:
            for k in range(1, K):
                if lr == bins[k]:
                    v[k] += 1
                    break

    # Chi-squared
    chi_sq = np.sum((v - n_blocks * np.array(pi_vals)) ** 2 /
                     (n_blocks * np.array(pi_vals)))
    p_value = sp_special.gammaincc(K / 2.0, chi_sq / 2.0)
    return p_value


def nist_matrix_rank(bits, M=32, Q=32):
    """NIST Test 5: Binary Matrix Rank Test.
    Constructs MxQ binary matrices and computes their rank."""
    n = len(bits)
    n_matrices = n // (M * Q)
    if n_matrices < 10:
        return 1.0

    matrices = bits[:n_matrices * M * Q].reshape(n_matrices, M, Q)

    # Compute rank of each matrix (over GF(2))
    ranks = np.zeros(n_matrices, dtype=np.int32)
    for i in range(n_matrices):
        ranks[i] = _gf2_rank(matrices[i])

    # Expected proportions for random MxQ binary matrices
    # P(rank=M) ≈ 0.2888, P(rank=M-1) ≈ 0.5776, P(rank<=M-2) ≈ 0.1336
    fm = np.sum(ranks == M)
    fm1 = np.sum(ranks == M - 1)
    rest = n_matrices - fm - fm1

    chi_sq = ((fm - 0.2888 * n_matrices) ** 2 / (0.2888 * n_matrices) +
              (fm1 - 0.5776 * n_matrices) ** 2 / (0.5776 * n_matrices) +
              (rest - 0.1336 * n_matrices) ** 2 / (0.1336 * n_matrices))
    p_value = math.exp(-chi_sq / 2.0)
    return p_value


def _gf2_rank(matrix):
    """Compute rank of a binary matrix over GF(2)."""
    m = matrix.copy().astype(np.uint8)
    rows, cols = m.shape
    rank = 0
    for col in range(min(rows, cols)):
        # Find pivot
        pivot = None
        for row in range(rank, rows):
            if m[row, col] == 1:
                pivot = row
                break
        if pivot is None:
            continue
        # Swap
        m[[rank, pivot]] = m[[pivot, rank]]
        # Eliminate
        for row in range(rows):
            if row != rank and m[row, col] == 1:
                m[row] ^= m[rank]
        rank += 1
    return rank


# ═══════════════════════════════════════════════════════════════
# Comparison Engine
# ═══════════════════════════════════════════════════════════════

def nist_approximate_entropy(bits, m=5):
    """NIST Test 10: Approximate Entropy Test.
    Compares frequency of overlapping m-bit and (m+1)-bit patterns."""
    n = len(bits)

    def _phi(block_size):
        if block_size == 0:
            return 0.0
        padded = np.concatenate([bits, bits[:block_size - 1]])
        counts = {}
        for i in range(n):
            pattern = tuple(padded[i:i + block_size])
            counts[pattern] = counts.get(pattern, 0) + 1
        total = sum(c * math.log(c / n) for c in counts.values() if c > 0)
        return total / n

    phi_m = _phi(m)
    phi_m1 = _phi(m + 1)
    ap_en = phi_m - phi_m1
    chi_sq = 2.0 * n * (math.log(2) - ap_en)
    p_value = sp_special.gammaincc(2 ** (m - 1), chi_sq / 2.0)
    return p_value


def nist_serial(bits, m=5):
    """NIST Test 11: Serial Test.
    Tests uniformity of overlapping m-bit patterns."""
    n = len(bits)

    def _psi_sq(block_size):
        if block_size == 0:
            return 0.0
        padded = np.concatenate([bits, bits[:block_size - 1]])
        counts = np.zeros(2 ** block_size)
        for i in range(n):
            val = 0
            for j in range(block_size):
                val = (val << 1) | int(padded[i + j])
            counts[val] += 1
        return (2 ** block_size / n) * np.sum(counts ** 2) - n

    psi_m = _psi_sq(m)
    psi_m1 = _psi_sq(m - 1)
    psi_m2 = _psi_sq(m - 2) if m >= 2 else 0.0

    delta1 = psi_m - psi_m1
    delta2 = psi_m - 2 * psi_m1 + psi_m2

    p1 = sp_special.gammaincc(2 ** (m - 2), delta1 / 2.0)
    p2 = sp_special.gammaincc(2 ** (m - 3), delta2 / 2.0) if m >= 3 else 1.0
    return min(p1, p2)


def nist_cumulative_sums(bits):
    """NIST Test 13: Cumulative Sums (Cusum) Test.
    Tests max excursion of random walk formed by +1/-1 mapping of bits."""
    n = len(bits)
    x = 2 * bits.astype(np.int32) - 1
    S = np.cumsum(x)
    z = float(max(abs(np.max(S)), abs(np.min(S))))
    if z == 0:
        return 1.0
    p_value = sp_special.erfc(z / math.sqrt(2.0 * n))
    return p_value


NIST_TESTS = {
    'frequency': nist_frequency,
    'block_frequency': nist_block_frequency,
    'runs': nist_runs,
    'longest_run': nist_longest_run,
    'matrix_rank': nist_matrix_rank,
    'approx_entropy': nist_approximate_entropy,
    'serial': nist_serial,
    'cumulative_sums': nist_cumulative_sums,
}

NIST_ALPHA = 0.01  # Significance level (NIST standard)


def compare_cipher(cipher_key, rounds_list=None, n_keys=10000, seed=42):
    """Run NIST + CASI on a cipher at multiple round counts.

    Returns list of dicts, one per round count, with all test results.
    """
    cipher = CIPHERS.get(cipher_key)
    if not cipher:
        return []

    gen = cipher['generator']
    if rounds_list is None:
        rounds_list = cipher.get('test_rounds', [1, cipher['full_rounds']])

    results = []
    for rounds in rounds_list:
        data = gen(n_keys, rounds=rounds, seed=seed)
        keys = np.frombuffer(data, dtype=np.uint8).reshape(n_keys, 32)

        # CASI (crypto strategies)
        baseline_data = np.random.RandomState(0xBA5E).bytes(n_keys * 32)
        baseline_keys = np.frombuffer(baseline_data, dtype=np.uint8).reshape(n_keys, 32)
        signal = compute_crypto_signal(keys)
        baseline = compute_crypto_signal(baseline_keys)
        casi = signal['total'] / max(baseline['total'], 1)

        # Also compute full CASI (all 12 strategies)
        signal_full = compute_signal(keys)
        baseline_full = compute_signal(baseline_keys)
        casi_full = signal_full['total'] / max(baseline_full['total'], 1)

        # NIST tests — convert to bits
        bits = np.unpackbits(keys.ravel())
        n_bits = len(bits)

        nist_results = {}
        for name, test_fn in NIST_TESTS.items():
            p = test_fn(bits)
            nist_results[name] = {
                'p_value': round(p, 6),
                'pass': p >= NIST_ALPHA,
            }

        nist_pass_count = sum(1 for v in nist_results.values() if v['pass'])
        nist_all_pass = nist_pass_count == len(NIST_TESTS)

        # Classify detection
        casi_detects = casi >= 2.0
        nist_detects = not nist_all_pass

        if casi_detects and not nist_detects:
            advantage = 'CASI'
        elif nist_detects and not casi_detects:
            advantage = 'NIST'
        elif casi_detects and nist_detects:
            advantage = 'BOTH'
        else:
            advantage = 'NONE'

        results.append({
            'cipher': cipher['name'],
            'cipher_key': cipher_key,
            'rounds': rounds,
            'full_rounds': cipher['full_rounds'],
            'casi_crypto': round(casi, 2),
            'casi_full': round(casi_full, 2),
            'nist': nist_results,
            'nist_pass': nist_pass_count,
            'nist_total': len(NIST_TESTS),
            'nist_all_pass': nist_all_pass,
            'casi_detects': casi_detects,
            'nist_detects': nist_detects,
            'advantage': advantage,
            'n_keys': n_keys,
            'n_bits': n_bits,
        })

    return results


def compare_all(n_keys=10000, seed=42, skip_slow=False):
    """Run comparison across all ciphers at their test rounds.

    Returns list of all results + summary statistics.
    """
    all_results = []
    for key, cipher in CIPHERS.items():
        if skip_slow and cipher.get('slow'):
            continue
        results = compare_cipher(key, n_keys=n_keys, seed=seed)
        all_results.extend(results)
    return all_results


def format_comparison_table(results):
    """Format comparison results as a readable table."""
    lines = []
    lines.append("")
    lines.append("CASI vs NIST SP 800-22 Comparison")
    lines.append("=" * 95)
    lines.append(f"{'Cipher':<15} {'Rounds':>6} {'CASI':>6} {'NIST':>10} {'Advantage':>10} "
                 f"{'freq':>6} {'block':>6} {'runs':>6} {'lrun':>6} {'rank':>6}")
    lines.append("-" * 95)

    casi_only = 0
    nist_only = 0
    both = 0
    neither = 0

    for r in results:
        nist = r['nist']
        p_strs = []
        for name in ['frequency', 'block_frequency', 'runs', 'longest_run', 'matrix_rank']:
            p = nist[name]['p_value']
            passed = nist[name]['pass']
            marker = '' if passed else '*'
            p_strs.append(f"{p:.3f}{marker}")

        casi_str = f"{r['casi_crypto']:.1f}"
        nist_str = f"{r['nist_pass']}/{r['nist_total']}"
        adv = r['advantage']

        lines.append(
            f"{r['cipher']:<15} R{r['rounds']:<5} {casi_str:>6} {nist_str:>10} "
            f"{adv:>10} {'  '.join(p_strs)}"
        )

        if adv == 'CASI':
            casi_only += 1
        elif adv == 'NIST':
            nist_only += 1
        elif adv == 'BOTH':
            both += 1
        else:
            neither += 1

    lines.append("-" * 95)
    lines.append(f"\nSummary ({len(results)} configurations tested):")
    lines.append(f"  CASI detects, NIST misses:  {casi_only}")
    lines.append(f"  NIST detects, CASI misses:  {nist_only}")
    lines.append(f"  Both detect:                {both}")
    lines.append(f"  Neither detects:            {neither}")
    lines.append(f"\n  * = NIST test failed (p < {NIST_ALPHA})")
    lines.append("")
    return "\n".join(lines)
