#!/usr/bin/env python3
"""
live-casi text_detect: Token-Residuum AI Text Detection (Patent Foss 2026).

Pure token-residuum mod K method from the CASI-Detect patent.
No linguistic markers — purely structural/statistical.

Usage:
    from live_casi.text_detect import detect_ai, dose_response_validate

    result = detect_ai(text, reference_texts)
    validation = dose_response_validate(human_texts, ai_texts)

Method (Patent DPMA, Foss 2026):
    1. Tokenize text (any tokenizer, default: byte-level)
    2. Compute residuum: R = (t_1 mod K, ..., t_n mod K), K=256
    3. Build frequency histogram h(k) = |{i : t_i mod K = k}| / n
    4. Compare to reference h_ref via L1-distance
    5. d > threshold → machine-generated

Validated:
    - AUC=0.989 (GPT-4 German vs human dissertations)
    - AUC=0.871 (GPT-4o English vs human)
    - Dose-response: rho=-0.926 (perfect monotone)
    - Paraphrasing-robust: d=-2.17 after synonym substitution
"""

import numpy as np

__all__ = [
    'residuum_histogram', 'compute_reference', 'detect_ai',
    'detect_segments', 'dose_response_validate',
]

K = 256  # Default mod value (Patent: K=256 preferred)


def _tokenize_bytes(text):
    """Default tokenizer: UTF-8 bytes."""
    return list(text.encode('utf-8'))


def residuum_histogram(tokens, k=K):
    """Compute residuum histogram (Patent [0012]).

    h(j) = |{i : t_i mod K = j}| / n  for j = 0, ..., K-1

    Args:
        tokens: List/array of integer token IDs.
        k: Modulus (default 256).

    Returns:
        numpy array of shape (k,), normalized histogram.
    """
    tokens = np.asarray(tokens)
    residuals = tokens % k
    hist = np.bincount(residuals, minlength=k).astype(np.float64)
    hist /= max(len(tokens), 1)
    return hist


def compute_reference(texts, tokenize=None, k=K):
    """Build reference distribution from known human texts (Patent [0022]).

    Args:
        texts: List of known human-written texts.
        tokenize: Tokenizer function (default: UTF-8 bytes).
        k: Modulus.

    Returns:
        dict with 'h_ref' (mean histogram), 'threshold' (mean + 2*std),
        'n_texts', 'mean_distance', 'std_distance'.
    """
    if tokenize is None:
        tokenize = _tokenize_bytes

    hists = []
    for text in texts:
        tokens = tokenize(text)
        if len(tokens) < 50:
            continue
        hists.append(residuum_histogram(tokens, k))

    if len(hists) < 3:
        raise ValueError(f"Need at least 3 reference texts, got {len(hists)}")

    h_ref = np.mean(hists, axis=0)
    distances = [float(np.sum(np.abs(h - h_ref))) for h in hists]
    mean_d = np.mean(distances)
    std_d = np.std(distances)
    threshold = mean_d + 2 * std_d

    return {
        'h_ref': h_ref,
        'threshold': float(threshold),
        'n_texts': len(hists),
        'mean_distance': float(mean_d),
        'std_distance': float(std_d),
    }


def detect_ai(text, reference=None, reference_texts=None,
              tokenize=None, k=K):
    """Detect if text is AI-generated (Patent [0023]-[0024]).

    Args:
        text: Text to analyze.
        reference: Pre-computed reference dict (from compute_reference).
        reference_texts: List of human texts to build reference from.
        tokenize: Tokenizer function.
        k: Modulus.

    Returns:
        dict with 'distance', 'threshold', 'flagged', 'confidence'.
    """
    if tokenize is None:
        tokenize = _tokenize_bytes

    if reference is None:
        if reference_texts is None:
            raise ValueError("Provide either reference or reference_texts")
        reference = compute_reference(reference_texts, tokenize, k)

    tokens = tokenize(text)
    if len(tokens) < 50:
        return {'distance': 0, 'threshold': reference['threshold'],
                'flagged': False, 'confidence': 0, 'n_tokens': len(tokens)}

    h = residuum_histogram(tokens, k)
    d = float(np.sum(np.abs(h - reference['h_ref'])))

    flagged = d > reference['threshold']

    # Confidence: how many std deviations above threshold
    if reference['std_distance'] > 0:
        z = (d - reference['mean_distance']) / reference['std_distance']
        confidence = min(max(z / 4.0, 0), 1.0)  # Normalize to 0-1
    else:
        confidence = 1.0 if flagged else 0.0

    return {
        'distance': round(d, 4),
        'threshold': round(reference['threshold'], 4),
        'flagged': flagged,
        'confidence': round(confidence, 3),
        'n_tokens': len(tokens),
    }


def detect_segments(text, reference=None, reference_texts=None,
                    tokenize=None, k=K, segment_size=128):
    """Segment-level AI detection (Patent Anspruch 3).

    Splits text into overlapping segments, classifies each.
    Pinpoints which passages are AI-generated.

    Args:
        text: Text to analyze.
        reference: Pre-computed reference.
        reference_texts: Human texts for reference.
        tokenize: Tokenizer function.
        k: Modulus.
        segment_size: Tokens per segment.

    Returns:
        dict with 'segments', 'n_flagged', 'pct_flagged', 'heatmap'.
    """
    if tokenize is None:
        tokenize = _tokenize_bytes

    if reference is None:
        if reference_texts is None:
            raise ValueError("Provide either reference or reference_texts")
        reference = compute_reference(reference_texts, tokenize, k)

    # Build segment-level threshold from reference
    ref_seg_dists = []
    for rt in (reference_texts or [])[:50]:
        rt_tokens = tokenize(rt)
        for i in range(0, len(rt_tokens) - segment_size + 1, segment_size // 2):
            seg = rt_tokens[i:i + segment_size]
            h = residuum_histogram(seg, k)
            d = float(np.sum(np.abs(h - reference['h_ref'])))
            ref_seg_dists.append(d)

    if ref_seg_dists:
        seg_threshold = np.mean(ref_seg_dists) + 2 * np.std(ref_seg_dists)
    else:
        seg_threshold = reference['threshold']

    tokens = tokenize(text)
    segments = []

    for i in range(0, len(tokens) - segment_size + 1, segment_size // 2):
        seg_tokens = tokens[i:i + segment_size]
        h = residuum_histogram(seg_tokens, k)
        d = float(np.sum(np.abs(h - reference['h_ref'])))
        pct = round(i / max(len(tokens), 1) * 100)
        segments.append({
            'position_pct': pct,
            'distance': round(d, 4),
            'flagged': d > seg_threshold,
        })

    n_flagged = sum(1 for s in segments if s['flagged'])
    pct_flagged = round(n_flagged / max(len(segments), 1) * 100, 1)

    # Heatmap
    n_bins = min(40, len(segments))
    heatmap = ""
    if segments:
        seg_dists = [s['distance'] for s in segments]
        mean_d = np.mean(seg_dists)
        std_d = max(np.std(seg_dists), 0.01)
        for b in range(n_bins):
            idx = b * len(segments) // n_bins
            z = (segments[idx]['distance'] - mean_d) / std_d
            if z > 2: heatmap += "!"
            elif z > 1: heatmap += "#"
            elif z > 0: heatmap += "+"
            elif z > -1: heatmap += "."
            else: heatmap += "_"

    return {
        'n_segments': len(segments),
        'n_flagged': n_flagged,
        'pct_flagged': pct_flagged,
        'seg_threshold': round(seg_threshold, 4),
        'segments': segments,
        'heatmap': heatmap,
    }


def dose_response_validate(human_texts, ai_texts, doses=None,
                           tokenize=None, k=K, n_trials=10):
    """Validate detection with dose-response curve.

    Mixes human and AI text at different ratios and measures
    CASI response. A monotone dose-response proves causality.

    Args:
        human_texts: List of known human texts.
        ai_texts: List of known AI texts.
        doses: List of AI fractions (default: [0, 0.1, 0.25, 0.5, 0.75, 1.0]).
        tokenize: Tokenizer function.
        k: Modulus.
        n_trials: Repetitions per dose level.

    Returns:
        dict with dose-response data and Spearman correlation.
    """
    if tokenize is None:
        tokenize = _tokenize_bytes
    if doses is None:
        doses = [0.0, 0.1, 0.25, 0.5, 0.75, 1.0]

    # Tokenize all
    human_tokens = [tokenize(t) for t in human_texts if len(t) > 100]
    ai_tokens = [tokenize(t) for t in ai_texts if len(t) > 100]

    if len(human_tokens) < 3 or len(ai_tokens) < 3:
        raise ValueError("Need at least 3 human and 3 AI texts")

    # Build reference from human
    ref_hists = [residuum_histogram(t, k) for t in human_tokens]
    h_ref = np.mean(ref_hists, axis=0)

    results = {}
    all_doses = []
    all_l1s = []

    rng = np.random.RandomState(42)

    for dose in doses:
        l1s = []
        for trial in range(n_trials):
            # Pick a random human text
            h_idx = rng.randint(len(human_tokens))
            h_tok = list(human_tokens[h_idx])

            n = len(h_tok)
            n_replace = int(n * dose)

            if dose == 0:
                mixed = h_tok
            elif dose >= 1.0:
                a_idx = rng.randint(len(ai_tokens))
                mixed = list(ai_tokens[a_idx])[:n] if len(ai_tokens[a_idx]) >= n else list(ai_tokens[a_idx])
            else:
                mixed = list(h_tok)
                a_idx = rng.randint(len(ai_tokens))
                ai_src = list(ai_tokens[a_idx])
                # Replace random block
                pos = rng.randint(0, max(n - n_replace, 1))
                ai_start = rng.randint(0, max(len(ai_src) - n_replace, 1))
                mixed[pos:pos+n_replace] = ai_src[ai_start:ai_start+n_replace]

            h = residuum_histogram(mixed, k)
            l1 = float(np.sum(np.abs(h - h_ref)))
            l1s.append(l1)
            all_doses.append(dose)
            all_l1s.append(l1)

        results[dose] = {
            'mean_l1': round(float(np.mean(l1s)), 4),
            'std_l1': round(float(np.std(l1s)), 4),
            'n': len(l1s),
        }

    # Spearman correlation
    from scipy import stats as sp_stats
    rho, p = sp_stats.spearmanr(all_doses, all_l1s)

    return {
        'doses': results,
        'spearman_rho': round(float(rho), 4),
        'spearman_p': float(p),
        'monotone': abs(rho) > 0.8,
    }
