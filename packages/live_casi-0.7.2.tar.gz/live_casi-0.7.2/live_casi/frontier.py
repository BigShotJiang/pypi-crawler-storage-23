#!/usr/bin/env python3
"""
CASI Frontier Sweeper — Automated detection boundary finder.

For each cipher family, binary-searches the exact round where CASI
crosses the 2.0 threshold (SECURE/WEAK boundary). Produces a
publishable table of detection frontiers.

Usage:
    from live_casi.frontier import sweep_all_frontiers
    results = sweep_all_frontiers()

    # CLI:
    python -m live_casi --frontier
    python -m live_casi --frontier --keys 50000
"""

import json
import time
import numpy as np

from .ciphers import CIPHERS
from .core import compute_crypto_signal, compute_signal


def compute_casi(data_bytes, n_keys, key_size=32, crypto_only=True):
    """Compute CASI score from raw cipher output bytes.

    Args:
        data_bytes: Raw bytes from cipher generator (n_keys * key_size bytes)
        n_keys: Number of keys generated
        key_size: Bytes per key (default 32)
        crypto_only: If True, use only 4 cryptanalytic strategies (paper-compatible)

    Returns:
        (casi_score, signal_dict)
    """
    keys = np.frombuffer(data_bytes, dtype=np.uint8).reshape(n_keys, key_size)

    # Compute baseline from true random
    baseline_keys = np.frombuffer(
        np.random.RandomState(0xBA5E).bytes(n_keys * key_size),
        dtype=np.uint8,
    ).reshape(n_keys, key_size)

    signal_fn = compute_crypto_signal if crypto_only else compute_signal
    signal = signal_fn(keys)
    baseline = signal_fn(baseline_keys)

    baseline_total = max(baseline['total'], 1)
    casi = signal['total'] / baseline_total
    return casi, signal


def find_frontier(cipher_key, n_keys=10000, seed=42, crypto_only=True):
    """Binary search for the exact round where CASI crosses 2.0.

    Args:
        cipher_key: Key in CIPHERS registry (e.g., 'chacha', 'speck')
        n_keys: Number of keys per measurement (default 10000)
        seed: RNG seed for reproducibility
        crypto_only: Use only 4 crypto strategies (paper mode)

    Returns:
        dict with frontier data, or None if cipher not found
    """
    cipher = CIPHERS.get(cipher_key)
    if not cipher:
        return None

    gen = cipher['generator']
    full_rounds = cipher['full_rounds']

    # Collect CASI at every tested round
    round_data = {}

    def measure(r):
        if r in round_data:
            return round_data[r]
        data = gen(n_keys, rounds=r, seed=seed)
        casi, sig = compute_casi(data, n_keys, crypto_only=crypto_only)
        round_data[r] = {'casi': casi, 'signal_total': sig['total'], 'signal': sig}
        return round_data[r]

    # Always measure R1 (broken) and full rounds (secure)
    r1 = measure(1)
    r_full = measure(full_rounds)

    # Binary search for crossing point
    low, high = 1, full_rounds
    while low < high:
        mid = (low + high) // 2
        m = measure(mid)
        if m['casi'] >= 2.0:
            low = mid + 1
        else:
            high = mid

    frontier_round = low

    # Measure one below frontier for comparison
    if frontier_round > 1:
        measure(frontier_round - 1)

    # Build complete round profile around the frontier
    for r in range(max(1, frontier_round - 2), min(full_rounds + 1, frontier_round + 3)):
        measure(r)

    casi_at_frontier = round_data[frontier_round]['casi']
    casi_below = round_data.get(frontier_round - 1, {}).get('casi', float('inf'))

    return {
        'cipher': cipher['name'],
        'cipher_key': cipher_key,
        'family': cipher['family'],
        'full_rounds': full_rounds,
        'known_frontier': cipher.get('frontier'),
        'casi_frontier': frontier_round,
        'casi_at_frontier': round(casi_at_frontier, 2),
        'casi_at_frontier_minus_1': round(casi_below, 2),
        'casi_at_r1': round(r1['casi'], 2),
        'casi_at_full': round(r_full['casi'], 2),
        'n_keys': n_keys,
        'crypto_only': crypto_only,
        'round_profile': {
            r: round(d['casi'], 3) for r, d in sorted(round_data.items())
        },
    }


def sweep_all_frontiers(n_keys=10000, seed=42, crypto_only=True, skip_slow=False):
    """Sweep all cipher families and find CASI frontiers.

    Args:
        n_keys: Keys per measurement
        seed: RNG seed
        crypto_only: Use 4 crypto strategies only
        skip_slow: Skip slow ciphers (3DES, RC4, Camellia)

    Returns:
        List of frontier results
    """
    results = []
    for key, cipher in CIPHERS.items():
        if skip_slow and cipher.get('slow'):
            continue
        t0 = time.time()
        result = find_frontier(key, n_keys=n_keys, seed=seed, crypto_only=crypto_only)
        if result:
            result['time_s'] = round(time.time() - t0, 1)
            results.append(result)
    return results


def format_frontier_table(results):
    """Format results as a readable table."""
    lines = []
    lines.append("")
    lines.append("CASI Detection Frontiers (crypto strategies, z > 3.5)")
    lines.append("=" * 85)
    lines.append(f"{'Cipher':<15} {'Family':<15} {'CASI':<8} {'Known':<8} {'Match':<7} "
                 f"{'R1 CASI':>8} {'Full':>6} {'Time':>6}")
    lines.append("-" * 85)

    for r in results:
        known = r.get('known_frontier', '?')
        casi_f = r['casi_frontier']
        match = 'YES' if known and abs(casi_f - known) <= 1 else '~'
        lines.append(
            f"{r['cipher']:<15} {r['family']:<15} R{casi_f:<6} R{known:<6} "
            f"{match:<7} {r['casi_at_r1']:>8.1f} {r['casi_at_full']:>5.2f} "
            f"{r.get('time_s', 0):>5.1f}s"
        )

    lines.append("-" * 85)
    lines.append("")

    # Round profiles
    lines.append("Round Profiles (CASI score at each round):")
    for r in results:
        profile = r.get('round_profile', {})
        prof_str = "  ".join(f"R{rd}={c:.1f}" for rd, c in profile.items())
        lines.append(f"  {r['cipher']}: {prof_str}")

    lines.append("")
    return "\n".join(lines)


def save_frontiers_json(results, path='casi_frontiers.json'):
    """Save results as JSON."""
    # Remove non-serializable signal dicts from round_profile
    clean = []
    for r in results:
        c = dict(r)
        clean.append(c)
    with open(path, 'w') as f:
        json.dump(clean, f, indent=2)
    return path
