#!/usr/bin/env python3
"""
Blind Cipher Identification — Phase 1 of live-casi v0.2.0

Feed any byte stream → get cipher family + mode identification with confidence.

How it works:
    Each cipher architecture produces a unique "fingerprint" in 12-dimensional
    signal space. Reference profiles are generated at import time by running
    compute_signal() on known cipher output at various round counts.

    Classification uses cosine similarity — no ML, no sklearn, pure numpy.

Usage:
    from live_casi.identify import identify_cipher
    result = identify_cipher(data, key_size=32)
    print(result['cipher'], result['confidence'], result['rounds_estimate'])
"""

import os
import time
import numpy as np

from .core import (
    compute_signal, STRATEGY_NAMES, LiveCASIWithStorage,
    casi_verdict, casi_color,
    BOLD, RESET, DIM, GREEN, YELLOW, RED, CYAN,
)
from .ciphers import CIPHERS


# ═══════════════════════════════════════════════════════════════
# REFERENCE PROFILE GENERATION
# ═══════════════════════════════════════════════════════════════

def _generate_profile(generator, rounds, n_keys=10000, key_size=32, seeds=None):
    """Generate a normalized 12D signal vector for a cipher at given rounds.
    Averages across multiple seeds for stability."""
    if seeds is None:
        seeds = [42, 77, 123]

    vecs = []
    last_signal = None
    for seed in seeds:
        data = generator(n_keys, rounds=rounds, seed=seed)
        keys = np.frombuffer(data, dtype=np.uint8).reshape(-1, key_size)
        signal = compute_signal(keys)
        vec = np.array([signal.get(s, 0) for s in STRATEGY_NAMES], dtype=np.float64)
        vecs.append(vec)
        last_signal = signal

    # Average the raw vectors, then normalize
    avg_vec = np.mean(vecs, axis=0)
    norm = np.linalg.norm(avg_vec)
    if norm > 0:
        avg_vec = avg_vec / norm
    return avg_vec, last_signal


def _generate_baseline_profile(n_keys=10000, key_size=32):
    """Generate profile for true random (os.urandom)."""
    data = os.urandom(n_keys * key_size)
    keys = np.frombuffer(data, dtype=np.uint8).reshape(-1, key_size)
    signal = compute_signal(keys)
    vec = np.array([signal.get(s, 0) for s in STRATEGY_NAMES], dtype=np.float64)
    norm = np.linalg.norm(vec)
    if norm > 0:
        vec = vec / norm
    return vec, signal


# Attack mode profiles (implementation failures, not cipher families)
def _generate_attack_profiles():
    """Generate profiles for common implementation failures."""
    from .core import (
        _generate_ecb_data, _generate_base64_data, _generate_xor_short_key,
        _generate_counter_reuse, _generate_lcg_prng, _generate_low_entropy,
        _generate_lfsr, _generate_timer_periodic, _generate_structured_data,
        _generate_short_period,
    )

    n_keys = 10000
    key_size = 32
    attacks = {
        'ECB mode': _generate_ecb_data,
        'Base64 encoding': _generate_base64_data,
        'XOR short key': _generate_xor_short_key,
        'Counter reuse': _generate_counter_reuse,
        'LCG PRNG': _generate_lcg_prng,
        'Low-entropy PRNG': _generate_low_entropy,
        'LFSR bit stream': _generate_lfsr,
        'Timer-seeded periodic': _generate_timer_periodic,
        'Structured data': _generate_structured_data,
        'Short-period cycling': _generate_short_period,
    }

    profiles = {}
    for name, gen_func in attacks.items():
        data = gen_func(n_keys)
        keys = np.frombuffer(data, dtype=np.uint8).reshape(-1, key_size)
        signal = compute_signal(keys)
        vec = np.array([signal.get(s, 0) for s in STRATEGY_NAMES], dtype=np.float64)
        norm = np.linalg.norm(vec)
        if norm > 0:
            vec = vec / norm
        profiles[name] = {
            'vector': vec,
            'signal': signal,
            'category': 'attack',
        }

    return profiles


def _build_cipher_profiles():
    """Build reference profiles for all cipher families at multiple round counts.
    Called once at import time."""
    profiles = {}

    for cname, info in CIPHERS.items():
        gen = info['generator']
        full = info['full_rounds']
        is_slow = info.get('slow', False)
        n_keys = 1000 if is_slow else 10000

        # Profile at multiple round counts: broken, frontier, full
        round_list = sorted(set(info['test_rounds']))
        # Add extra rounds near frontier for interpolation
        frontier = info.get('frontier', full)
        for r in [frontier - 1, frontier, frontier + 1]:
            if 1 <= r <= full and r not in round_list:
                round_list.append(r)
        round_list = sorted(set(round_list))

        for rounds in round_list:
            vec, signal = _generate_profile(gen, rounds, n_keys=n_keys)

            # Only store profiles for broken/weak rounds (CASI > 2.0)
            # These are the ones we want to identify
            total = signal['total']
            key = f'{cname}_R{rounds}'
            profiles[key] = {
                'vector': vec,
                'signal': signal,
                'cipher': cname,
                'cipher_name': info['name'],
                'family': info['family'],
                'rounds': rounds,
                'full_rounds': full,
                'frontier': frontier,
                'total_signal': total,
            }

    return profiles


# ═══════════════════════════════════════════════════════════════
# LAZY PROFILE INITIALIZATION
# ═══════════════════════════════════════════════════════════════

_CIPHER_PROFILES = None
_ATTACK_PROFILES = None
_RANDOM_PROFILE = None


def _ensure_profiles():
    """Lazy-load profiles on first use (avoids slow import for non-identify usage)."""
    global _CIPHER_PROFILES, _ATTACK_PROFILES, _RANDOM_PROFILE
    if _CIPHER_PROFILES is None:
        _CIPHER_PROFILES = _build_cipher_profiles()
        _ATTACK_PROFILES = _generate_attack_profiles()
        _RANDOM_PROFILE, _ = _generate_baseline_profile(n_keys=10000)


def get_profiles():
    """Get cipher profiles dict (for MCP/API access)."""
    _ensure_profiles()
    return _CIPHER_PROFILES


# ═══════════════════════════════════════════════════════════════
# CLASSIFIER
# ═══════════════════════════════════════════════════════════════

def _cosine_similarity(a, b):
    """Cosine similarity between two vectors."""
    dot = np.dot(a, b)
    na = np.linalg.norm(a)
    nb = np.linalg.norm(b)
    if na < 1e-10 or nb < 1e-10:
        return 0.0
    return float(dot / (na * nb))


def identify_cipher(data, key_size=32):
    """Identify the cipher used to generate a byte stream.

    Args:
        data: bytes or bytearray of cipher output
        key_size: size of each key/block (default 32)

    Returns:
        dict with keys:
            casi: float — CASI score
            verdict: str — SECURE/WEAK/BROKEN
            cipher: str — identified cipher name (or 'unknown')
            family: str — cipher family (ARX-stream, SPN-block, etc.)
            rounds_estimate: str — estimated round count
            confidence: float — 0.0 to 1.0
            confidence_label: str — 'high'/'medium'/'low'/'none'
            failure_mode: str or None — detected implementation failure
            top_signals: list of (strategy, count) tuples
            all_matches: list of all matches sorted by similarity
    """
    _ensure_profiles()

    # Compute CASI for the input
    keys = np.frombuffer(bytes(data), dtype=np.uint8)
    n_keys = len(keys) // key_size
    if n_keys < 100:
        return {
            'casi': None,
            'verdict': 'Insufficient data',
            'cipher': 'unknown',
            'family': 'unknown',
            'rounds_estimate': 'N/A',
            'confidence': 0.0,
            'confidence_label': 'none',
            'failure_mode': None,
            'top_signals': [],
            'all_matches': [],
        }

    keys = keys[:n_keys * key_size].reshape(n_keys, key_size)
    signal = compute_signal(keys)

    # Compute CASI
    baseline_signal = compute_signal(
        np.frombuffer(os.urandom(min(n_keys, 10000) * key_size),
                      dtype=np.uint8).reshape(-1, key_size))
    baseline_total = max(baseline_signal['total'], 1)
    casi = signal['total'] / baseline_total

    # Build input vector
    input_vec = np.array([signal.get(s, 0) for s in STRATEGY_NAMES], dtype=np.float64)
    input_norm = np.linalg.norm(input_vec)
    if input_norm > 0:
        input_vec_n = input_vec / input_norm
    else:
        input_vec_n = input_vec

    # Top signals for output
    top_signals = sorted(
        [(s, signal.get(s, 0)) for s in STRATEGY_NAMES],
        key=lambda x: -x[1]
    )[:5]
    top_signals = [(s, v) for s, v in top_signals if v > 0]

    verdict = casi_verdict(casi)

    # If CASI < 1.5, it's essentially random — no identification possible
    if casi < 1.5:
        return {
            'casi': casi,
            'verdict': verdict,
            'cipher': 'unknown (appears random)',
            'family': 'N/A',
            'rounds_estimate': 'full rounds (secure)',
            'confidence': 0.0,
            'confidence_label': 'none',
            'failure_mode': None,
            'top_signals': top_signals,
            'all_matches': [],
        }

    # Step 1: Check for implementation failure modes
    failure_mode = None
    best_attack_sim = 0.0
    best_attack_name = None
    for name, prof in _ATTACK_PROFILES.items():
        sim = _cosine_similarity(input_vec_n, prof['vector'])
        if sim > best_attack_sim:
            best_attack_sim = sim
            best_attack_name = name
    if best_attack_sim > 0.85:
        failure_mode = best_attack_name

    # Step 2: Match against cipher profiles
    matches = []
    for key, prof in _CIPHER_PROFILES.items():
        sim = _cosine_similarity(input_vec_n, prof['vector'])
        matches.append({
            'key': key,
            'similarity': sim,
            'cipher': prof['cipher'],
            'cipher_name': prof['cipher_name'],
            'family': prof['family'],
            'rounds': prof['rounds'],
            'full_rounds': prof['full_rounds'],
            'frontier': prof['frontier'],
        })

    matches.sort(key=lambda x: -x['similarity'])

    # Step 3: Aggregate by cipher — pick cipher with best max similarity
    # This prevents Salsa/ChaCha confusion by looking at family-level fit
    cipher_best = {}
    for m in matches:
        c = m['cipher']
        if c not in cipher_best or m['similarity'] > cipher_best[c]['similarity']:
            cipher_best[c] = m

    # Rank ciphers by their best similarity
    cipher_ranked = sorted(cipher_best.values(), key=lambda x: -x['similarity'])
    best = cipher_ranked[0] if cipher_ranked else None

    if best is None or best['similarity'] < 0.5:
        return {
            'casi': casi,
            'verdict': verdict,
            'cipher': 'unknown',
            'family': 'unknown',
            'rounds_estimate': 'N/A',
            'confidence': 0.0,
            'confidence_label': 'none',
            'failure_mode': failure_mode,
            'top_signals': top_signals,
            'all_matches': matches[:5],
        }

    # Determine confidence label
    sim = best['similarity']
    if sim > 0.85:
        conf_label = 'high'
    elif sim > 0.70:
        conf_label = 'medium'
    elif sim > 0.50:
        conf_label = 'low'
    else:
        conf_label = 'none'

    # Round estimation: find the best-matching round count within the same cipher
    cipher_matches = sorted(
        [m for m in matches if m['cipher'] == best['cipher']],
        key=lambda x: -x['similarity']
    )
    if cipher_matches:
        best_round_match = cipher_matches[0]
        r = best_round_match['rounds']
        rounds_est = f'~R{r}'
        if r >= best_round_match['full_rounds']:
            rounds_est = f'R{best_round_match["full_rounds"]} (full)'
        elif r <= 1:
            rounds_est = 'R1 (trivial)'
        elif abs(r - best_round_match['frontier']) <= 1:
            rounds_est = f'~R{r} (near frontier)'
    else:
        rounds_est = f'~R{best["rounds"]}'

    return {
        'casi': casi,
        'verdict': verdict,
        'cipher': best['cipher_name'],
        'cipher_key': best['cipher'],
        'family': best['family'],
        'rounds_estimate': rounds_est,
        'confidence': round(sim, 3),
        'confidence_label': conf_label,
        'failure_mode': failure_mode,
        'top_signals': top_signals,
        'all_matches': matches[:10],
    }


# ═══════════════════════════════════════════════════════════════
# CLI: --identify
# ═══════════════════════════════════════════════════════════════

def run_identify(args):
    """CLI handler for --identify mode."""
    import json as json_mod

    filepath = args.identify
    quiet = getattr(args, 'quiet', False)
    json_out = getattr(args, 'json', False)

    # Read data from file or stdin
    if filepath == '-' or filepath is True:
        # Read from stdin
        import sys
        data = sys.stdin.buffer.read()
        source = 'stdin'
    else:
        try:
            with open(filepath, 'rb') as f:
                data = f.read()
            source = filepath
        except FileNotFoundError:
            print(f'{RED}Error: file not found: {filepath}{RESET}')
            import sys
            sys.exit(2)

    if len(data) < args.key_size * 100:
        print(f'{RED}Error: need at least {args.key_size * 100} bytes, got {len(data)}{RESET}')
        import sys
        sys.exit(2)

    t0 = time.time()
    result = identify_cipher(data, key_size=args.key_size)
    dt = time.time() - t0

    if json_out:
        out = {
            'source': source,
            'bytes': len(data),
            'casi': round(result['casi'], 2) if result['casi'] else None,
            'verdict': result['verdict'],
            'cipher': result['cipher'],
            'family': result['family'],
            'rounds_estimate': result['rounds_estimate'],
            'confidence': result['confidence'],
            'confidence_label': result['confidence_label'],
            'failure_mode': result['failure_mode'],
            'top_signals': [{'strategy': s, 'count': c} for s, c in result['top_signals']],
            'elapsed_seconds': round(dt, 2),
        }
        print(json_mod.dumps(out, indent=2))
        return

    if quiet:
        print(f'{result["cipher"]} ({result["confidence"]:.0%})')
        return

    # Full display
    casi = result['casi']
    color = casi_color(casi) if casi else DIM

    print()
    print(f'{BOLD}{CYAN}CASI Cipher Identification{RESET}')
    print(f'{DIM}{"─" * 56}{RESET}')
    print(f'  Source:      {source} ({len(data):,} bytes)')
    print(f'  CASI:        {color}{BOLD}{casi:.1f}{RESET}  {color}({result["verdict"]}){RESET}')
    print()

    # Confidence color
    conf = result['confidence']
    if conf > 0.85:
        cc = GREEN
    elif conf > 0.70:
        cc = YELLOW
    else:
        cc = RED

    print(f'  Identified:  {BOLD}{result["cipher"]}{RESET} ({result["family"]})')
    print(f'  Rounds:      {result["rounds_estimate"]}')
    print(f'  Confidence:  {cc}{BOLD}{conf:.0%}{RESET} ({result["confidence_label"]})')

    if result['failure_mode']:
        print(f'  {RED}{BOLD}Failure mode:{RESET} {RED}{result["failure_mode"]}{RESET}')

    if result['top_signals']:
        print()
        print(f'  {BOLD}Top signals:{RESET}')
        for strat, count in result['top_signals']:
            print(f'    {strat:<22s} {count:>6,}')

    if result.get('all_matches'):
        print()
        print(f'  {DIM}All matches:{RESET}')
        for m in result['all_matches'][:5]:
            sim = m['similarity']
            sc = GREEN if sim > 0.85 else (YELLOW if sim > 0.7 else DIM)
            print(f'    {sc}{m["cipher_name"]:<16s} R{m["rounds"]:<4d} {sim:.3f}{RESET}')

    print(f'\n  {DIM}Elapsed: {dt:.2f}s{RESET}')
    print()


# ═══════════════════════════════════════════════════════════════
# BLIND TEST: validate identification accuracy
# ═══════════════════════════════════════════════════════════════

def run_identify_test():
    """Generate blind test data and validate identification accuracy.
    Per roadmap: >85% correct FAMILY identification, >70% round estimate."""
    _ensure_profiles()

    # Family mapping for same-family matches (these are genuinely indistinguishable)
    FAMILY_MAP = {}
    for cname, info in CIPHERS.items():
        FAMILY_MAP[cname] = info['family']

    print(f'{BOLD}Blind Cipher Identification Test{RESET}')
    print(f'{DIM}{"─" * 80}{RESET}')
    print(f'  {"Source":<25s}  {"Identified":<18s}  {"Conf":>5s}  {"Cipher":>7s}  {"Family":>7s}  {"Time":>5s}')
    print(f'  {"─"*25}  {"─"*18}  {"─"*5}  {"─"*7}  {"─"*7}  {"─"*5}')

    cipher_correct = 0
    family_correct = 0
    total = 0

    for cname, info in CIPHERS.items():
        gen = info['generator']
        is_slow = info.get('slow', False)
        n_keys = 500 if is_slow else 5000
        test_round = info['test_rounds'][0]  # R1 typically

        data = gen(n_keys, rounds=test_round, seed=99)
        t0 = time.time()
        result = identify_cipher(data, key_size=32)
        dt = time.time() - t0

        identified_key = result.get('cipher_key', '')
        identified_name = result.get('cipher', 'unknown')
        identified_family = result.get('family', 'unknown')

        # Exact cipher match
        cipher_match = identified_key == cname
        cipher_correct += int(cipher_match)

        # Family match (ChaCha/Salsa both = ARX-stream, etc.)
        expected_family = FAMILY_MAP.get(cname, 'unknown')
        family_match = identified_family == expected_family
        family_correct += int(family_match)

        total += 1

        # Display: show both cipher and family status
        cc = GREEN if cipher_match else (YELLOW if family_match else RED)
        cm = 'YES' if cipher_match else 'NO'
        fc = GREEN if family_match else RED
        fm = 'YES' if family_match else 'NO'
        conf = result['confidence']

        extra = ''
        if family_match and not cipher_match:
            extra = f' {DIM}(same family){RESET}'

        print(f'  {info["name"]+" R"+str(test_round):<25s}  '
              f'{identified_name:<18s}  {conf:>4.0%}  '
              f'{cc}{cm:>7s}{RESET}  {fc}{fm:>7s}{RESET}  {dt:>4.1f}s{extra}')

    # Random baseline — should NOT identify as any cipher
    data = os.urandom(5000 * 32)
    t0 = time.time()
    result = identify_cipher(data, key_size=32)
    dt = time.time() - t0
    is_unknown = 'unknown' in result['cipher'].lower()
    cipher_correct += int(is_unknown)
    family_correct += int(is_unknown)
    total += 1
    color = GREEN if is_unknown else RED
    mark = 'YES' if is_unknown else 'NO'
    print(f'  {"os.urandom (CSPRNG)":<25s}  '
          f'{result["cipher"]:<18s}  {result["confidence"]:>4.0%}  '
          f'{color}{mark:>7s}{RESET}  {color}{mark:>7s}{RESET}  {dt:>4.1f}s')

    cipher_acc = cipher_correct / total * 100
    family_acc = family_correct / total * 100
    print(f'\n  {BOLD}Cipher accuracy: {cipher_correct}/{total} ({cipher_acc:.0f}%){RESET}')
    print(f'  {BOLD}Family accuracy: {family_correct}/{total} ({family_acc:.0f}%){RESET}')

    if family_acc >= 85:
        print(f'  {GREEN}Family target (85%) met.{RESET}')
    else:
        print(f'  {YELLOW}Below family target (85%).{RESET}')
    print()
