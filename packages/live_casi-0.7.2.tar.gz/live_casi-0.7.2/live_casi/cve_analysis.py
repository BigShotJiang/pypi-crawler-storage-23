#!/usr/bin/env python3
"""
CVE & PRNG Analysis — Test CASI against real-world crypto failures.

Simulates famous cryptographic vulnerabilities and tests whether CASI
detects each one. Also tests common PRNGs to identify which ones CASI
flags as cryptographically weak.

CVEs simulated:
  1. CVE-2008-0166 (Debian OpenSSL) — PID-only entropy
  2. Dual EC DRBG style — deterministic relationship in output
  3. RC4 first-byte biases — known keystream biases
  4. CTR nonce reuse — keystream reuse
  5. DES weak keys — self-inverse key schedule
  6. ECB mode with structured plaintext
  7. Predictable IV (CBC with counter IV)

PRNGs tested:
  1. os.urandom (CSPRNG baseline)
  2. MT19937 (Python's random — NOT crypto-safe)
  3. Linear Congruential Generator
  4. XorShift128+ (JavaScript Math.random)
  5. Linear Feedback Shift Register (16-bit)

Usage:
    from live_casi.cve_analysis import run_cve_suite, run_prng_suite
    cve_results = run_cve_suite()
    prng_results = run_prng_suite()
"""

import os
import struct
import numpy as np

from .core import compute_signal, compute_crypto_signal, STRATEGY_NAMES
from .nist_compare import NIST_TESTS, NIST_ALPHA


def _analyze(keys, name):
    """Run CASI + NIST, return standardized result."""
    n_keys = keys.shape[0]
    bl = np.frombuffer(
        np.random.RandomState(0xBA5E).bytes(n_keys * 32),
        dtype=np.uint8,
    ).reshape(n_keys, 32)

    sig = compute_signal(keys)
    base = compute_signal(bl)
    casi = sig['total'] / max(base['total'], 1)

    sig_c = compute_crypto_signal(keys)
    base_c = compute_crypto_signal(bl)
    casi_c = sig_c['total'] / max(base_c['total'], 1)

    bits = np.unpackbits(keys.ravel())
    nist = {}
    for tname, fn in NIST_TESTS.items():
        p = fn(bits)
        nist[tname] = {'p_value': round(float(p), 6), 'pass': bool(p >= NIST_ALPHA)}

    nist_pass = sum(1 for v in nist.values() if v['pass'])
    nist_all_pass = nist_pass == len(NIST_TESTS)
    casi_detects = casi >= 2.0
    nist_detects = not nist_all_pass

    fired = sorted([(k, int(v)) for k, v in sig.items() if k != 'total' and v > 0],
                   key=lambda x: -x[1])

    return {
        'name': name,
        'casi_full': round(float(casi), 2),
        'casi_crypto': round(float(casi_c), 2),
        'nist_pass': nist_pass,
        'nist_total': len(NIST_TESTS),
        'nist_all_pass': nist_all_pass,
        'nist': nist,
        'casi_detects': casi_detects,
        'nist_detects': nist_detects,
        'is_gap': casi_detects and not nist_detects,
        'strategies_fired': dict(fired),
        'top_strategies': fired[:3],
    }


# ═══════════════════════════════════════════════════════════════
# CVE Simulators
# ═══════════════════════════════════════════════════════════════

def cve_debian_openssl(n_keys=10000, seed=42):
    """CVE-2008-0166: Debian OpenSSL PRNG seeded only from PID.

    Only ~32768 possible keys exist. With 10000 samples, many collisions.
    """
    rng = np.random.RandomState(seed)
    # Generate pool of 32768 possible keys (one per PID)
    pool = np.random.RandomState(0xDEB1A4).randint(0, 256, size=(32768, 32), dtype=np.uint8)
    # Sample from pool (simulating key generation with limited entropy)
    indices = rng.randint(0, 32768, size=n_keys)
    return pool[indices]


def cve_dual_ec_style(n_keys=10000, seed=42):
    """Dual EC DRBG-style: output has deterministic relationship.

    Every 8th key, byte[0:4] is a deterministic function of the previous key's bytes.
    Models the P/Q point relationship that leaks internal state.
    """
    rng = np.random.RandomState(seed)
    keys = rng.randint(0, 256, size=(n_keys, 32), dtype=np.uint8)

    for i in range(8, n_keys, 8):
        # Backdoor: first 4 bytes are derived from previous key
        for b in range(4):
            keys[i, b] = (int(keys[i - 1, b * 2]) + int(keys[i - 1, b * 2 + 1])) & 0xFF

    return keys


def cve_rc4_bias(n_keys=10000, seed=42):
    """RC4 first-byte biases: P(Z1=0) ≈ 2/256 instead of 1/256.

    Known bias in RC4 keystream. Byte 0 is biased toward 0,
    byte 1 biased toward 0, byte 2 toward specific values.
    """
    rng = np.random.RandomState(seed)
    keys = rng.randint(0, 256, size=(n_keys, 32), dtype=np.uint8)

    for i in range(n_keys):
        # Byte 0: P(0) ≈ 2/256 (double the expected frequency)
        if rng.random() < 1.0 / 256:
            keys[i, 0] = 0
        # Byte 1: slight bias toward 0
        if rng.random() < 0.5 / 256:
            keys[i, 1] = 0
        # Bytes 3-5: Fluhrer-McGrew biases (subtle correlations)
        if rng.random() < 0.3:
            keys[i, 3] = (int(keys[i, 3]) + int(keys[i, 0])) & 0xFF

    return keys


def cve_ctr_nonce_reuse(n_keys=10000, seed=42):
    """CTR mode nonce reuse: two messages encrypted with same keystream.

    Interleave two "plaintext" streams XORed with the same keystream.
    Keys[2i] and Keys[2i+1] share the same keystream → XOR reveals plaintext.
    """
    rng = np.random.RandomState(seed)
    keys = rng.randint(0, 256, size=(n_keys, 32), dtype=np.uint8)

    # Generate a fixed keystream
    keystream = np.random.RandomState(0xCE77).randint(0, 256, size=32, dtype=np.uint8)

    # Generate two structured plaintexts
    pt1 = np.zeros(32, dtype=np.uint8)  # HTTP header-like
    pt1[:4] = [0x47, 0x45, 0x54, 0x20]  # "GET "
    pt2 = np.zeros(32, dtype=np.uint8)
    pt2[:4] = [0x50, 0x4F, 0x53, 0x54]  # "POST"

    # Every 10th pair uses the reused nonce
    for i in range(0, n_keys - 1, 10):
        keys[i] = pt1 ^ keystream
        keys[i + 1] = pt2 ^ keystream

    return keys


def cve_des_weak_keys(n_keys=10000, seed=42):
    """DES weak keys: E(K, E(K, P)) = P (self-inverse).

    Simulates output from a cipher using DES weak keys.
    4 weak keys produce self-inverse encryption → every other block is plaintext.
    """
    rng = np.random.RandomState(seed)
    keys = rng.randint(0, 256, size=(n_keys, 32), dtype=np.uint8)

    # DES weak keys: 0x00..00, 0xFF..FF, 0x0F..0F, 0xF0..F0
    weak = np.array([0x00, 0xFF, 0x0F, 0xF0], dtype=np.uint8)

    # 20% of keys use weak key pattern (repeating weak byte)
    for i in range(n_keys):
        if rng.random() < 0.2:
            w = weak[rng.randint(0, 4)]
            keys[i, :] = w

    return keys


def cve_ecb_structured(n_keys=10000, seed=42):
    """ECB mode with structured plaintext: identical blocks → identical ciphertext.

    The "ECB penguin" problem. With structured input (e.g., image pixels),
    ECB produces repeated ciphertext blocks.
    """
    rng = np.random.RandomState(seed)
    keys = rng.randint(0, 256, size=(n_keys, 32), dtype=np.uint8)

    # Simulate: 30% of keys are one of 10 "common plaintext blocks"
    common_blocks = rng.randint(0, 256, size=(10, 32), dtype=np.uint8)
    for i in range(n_keys):
        if rng.random() < 0.3:
            keys[i] = common_blocks[rng.randint(0, 10)]

    return keys


def cve_predictable_iv(n_keys=10000, seed=42):
    """Predictable IV in CBC: IV is a counter instead of random.

    First 8 bytes of each "ciphertext" include the counter-based IV.
    This allows distinguishing attack on CBC mode.
    """
    rng = np.random.RandomState(seed)
    keys = rng.randint(0, 256, size=(n_keys, 32), dtype=np.uint8)

    # First 8 bytes = incrementing counter (predictable IV)
    for i in range(n_keys):
        counter_bytes = struct.pack('<Q', i)
        keys[i, :8] = np.frombuffer(counter_bytes, dtype=np.uint8)

    return keys


# ═══════════════════════════════════════════════════════════════
# PRNG Generators
# ═══════════════════════════════════════════════════════════════

def prng_urandom(n_keys=10000, **kwargs):
    """os.urandom — cryptographically secure baseline."""
    return np.frombuffer(os.urandom(n_keys * 32), dtype=np.uint8).reshape(n_keys, 32)


def prng_mt19937(n_keys=10000, seed=42, **kwargs):
    """MT19937 (Python's random) — passes NIST but NOT crypto-safe.

    Has a linear recurrence over GF(2). State recoverable from 624 outputs.
    """
    rng = np.random.RandomState(seed)
    return rng.randint(0, 256, size=(n_keys, 32), dtype=np.uint8)


def prng_lcg(n_keys=10000, seed=42, **kwargs):
    """Linear Congruential Generator — trivially broken.

    x(n+1) = (a * x(n) + c) mod m. Predictable, low-period.
    """
    x = seed
    a, c, m = 1664525, 1013904223, 2**32
    data = np.zeros((n_keys, 32), dtype=np.uint8)
    for i in range(n_keys):
        for j in range(0, 32, 4):
            x = (a * x + c) % m
            data[i, j:j+4] = np.frombuffer(struct.pack('<I', x), dtype=np.uint8)
    return data


def prng_xorshift128p(n_keys=10000, seed=42, **kwargs):
    """XorShift128+ — used in V8 (Chrome/Node.js) as Math.random().

    Fast, passes most statistical tests, but has linear structure over GF(2).
    NOT cryptographically secure.
    """
    s0 = np.uint64(seed)
    s1 = np.uint64(seed ^ 0xDEADBEEF12345678)
    data = np.zeros((n_keys, 32), dtype=np.uint8)

    for i in range(n_keys):
        for j in range(0, 32, 8):
            result = np.uint64(int(s0) + int(s1))
            x = s0 ^ (s0 << np.uint64(23))
            s0 = s1
            s1 = x ^ s1 ^ (x >> np.uint64(17)) ^ (s1 >> np.uint64(26))
            data[i, j:j+8] = np.frombuffer(result.tobytes(), dtype=np.uint8)

    return data


def prng_lfsr16(n_keys=10000, seed=42, **kwargs):
    """16-bit Linear Feedback Shift Register — very weak.

    Period ≤ 65535. Trivially predictable.
    """
    state = seed & 0xFFFF
    if state == 0:
        state = 1
    data = np.zeros((n_keys, 32), dtype=np.uint8)

    for i in range(n_keys):
        for j in range(0, 32, 2):
            # Galois LFSR with taps at 16, 14, 13, 11
            bit = (state ^ (state >> 2) ^ (state >> 3) ^ (state >> 5)) & 1
            state = (state >> 1) | (bit << 15)
            data[i, j:j+2] = np.frombuffer(struct.pack('<H', state), dtype=np.uint8)

    return data


# ═══════════════════════════════════════════════════════════════
# Suite Runners
# ═══════════════════════════════════════════════════════════════

CVE_SUITE = [
    ('CVE-2008-0166 Debian OpenSSL', cve_debian_openssl),
    ('Dual EC DRBG style', cve_dual_ec_style),
    ('RC4 first-byte bias', cve_rc4_bias),
    ('CTR nonce reuse', cve_ctr_nonce_reuse),
    ('DES weak keys', cve_des_weak_keys),
    ('ECB structured plaintext', cve_ecb_structured),
    ('Predictable IV (CBC)', cve_predictable_iv),
]

PRNG_SUITE = [
    ('os.urandom (CSPRNG)', prng_urandom),
    ('MT19937 (Python random)', prng_mt19937),
    ('LCG (Numerical Recipes)', prng_lcg),
    ('XorShift128+ (V8)', prng_xorshift128p),
    ('LFSR-16', prng_lfsr16),
]


def run_cve_suite(n_keys=10000, seed=42):
    """Run all CVE simulators."""
    results = []
    for name, gen_fn in CVE_SUITE:
        keys = gen_fn(n_keys=n_keys, seed=seed)
        results.append(_analyze(keys, name))
    return results


def run_prng_suite(n_keys=10000, seed=42):
    """Run all PRNG tests."""
    results = []
    for name, gen_fn in PRNG_SUITE:
        keys = gen_fn(n_keys=n_keys, seed=seed)
        results.append(_analyze(keys, name))
    return results


def format_cve_report(results):
    """Format CVE results as table."""
    lines = []
    lines.append("")
    lines.append("CASI CVE Detection Report")
    lines.append("=" * 100)
    lines.append(f"{'CVE / Attack':<30} {'CASI':>6} {'NIST':>5} {'Detected':>9} {'Gap?':>5} "
                 f"{'Top Strategy':>25}")
    lines.append("-" * 100)

    for r in results:
        detected = "BOTH" if r['casi_detects'] and r['nist_detects'] else \
                   "CASI" if r['casi_detects'] else \
                   "NIST" if r['nist_detects'] else "NONE"
        top = r['top_strategies'][0][0] if r['top_strategies'] else '-'
        gap = "GAP" if r['is_gap'] else ""

        lines.append(
            f"{r['name']:<30} {r['casi_full']:>5.1f} {r['nist_pass']}/{r['nist_total']:>3} "
            f"{detected:>9} {gap:>5} {top:>25}"
        )

    lines.append("-" * 100)
    detected_count = sum(1 for r in results if r['casi_detects'])
    gap_count = sum(1 for r in results if r['is_gap'])
    lines.append(f"\nCASI detected: {detected_count}/{len(results)}")
    lines.append(f"GAP (CASI only): {gap_count}/{len(results)}")
    lines.append("")
    return "\n".join(lines)


def format_prng_report(results):
    """Format PRNG results as table."""
    lines = []
    lines.append("")
    lines.append("CASI PRNG Quality Assessment")
    lines.append("=" * 100)
    lines.append(f"{'PRNG':<30} {'CASI':>6} {'NIST':>5} {'Quality':>10} {'Gap?':>5} "
                 f"{'Top Strategy':>25}")
    lines.append("-" * 100)

    for r in results:
        if r['casi_full'] < 1.5:
            quality = "SECURE"
        elif r['casi_full'] < 2.0:
            quality = "Borderline"
        elif r['casi_full'] < 10.0:
            quality = "WEAK"
        else:
            quality = "BROKEN"

        top = r['top_strategies'][0][0] if r['top_strategies'] else '-'
        gap = "GAP" if r['is_gap'] else ""

        lines.append(
            f"{r['name']:<30} {r['casi_full']:>5.1f} {r['nist_pass']}/{r['nist_total']:>3} "
            f"{quality:>10} {gap:>5} {top:>25}"
        )

    lines.append("-" * 100)
    lines.append("")
    return "\n".join(lines)
