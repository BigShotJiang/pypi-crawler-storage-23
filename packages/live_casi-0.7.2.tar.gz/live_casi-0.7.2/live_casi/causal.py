#!/usr/bin/env python3
"""
CASI Cryptanalytic Knowledge Graph — live-casi v0.4.0

Generates a .causal knowledge graph from live-casi benchmark data.
Runs the dotcausal 3-pass inference engine to discover cross-cipher
structural patterns invisible from individual cipher analysis.

Usage:
    from live_casi.causal import generate_causal_graph
    stats = generate_causal_graph("output.causal", n_keys=10000)

CLI:
    live-casi --causal output.causal
    live-casi --causal output.causal --keys 50000
    live-casi --causal output.causal --quick
"""

import os
import sys
import time
import numpy as np

from .core import (
    compute_signal, compute_crypto_signal,
    STRATEGY_NAMES, CRYPTO_STRATEGY_NAMES, IMPL_STRATEGY_NAMES,
    Z_THRESHOLD,
)
from .ciphers import CIPHERS
from .benchmark import ACADEMIC_FRONTIERS, compute_casi_at_rounds

# ═══════════════════════════════════════════════════════════════
# DOMAIN KNOWLEDGE — Cipher Architecture Ontology
# ═══════════════════════════════════════════════════════════════

# Map cipher families to structural properties
FAMILY_PROPERTIES = {
    'ARX-stream': {
        'operations': ['modular_addition', 'bitwise_rotation', 'xor'],
        'structure': 'quarter_round_state_update',
        'diffusion': 'diagonal_column_alternation',
        'weakness_class': 'differential_propagation_through_addition',
    },
    'SPN-block': {
        'operations': ['substitution_box', 'permutation_layer', 'key_mixing'],
        'structure': 'substitution_permutation_network',
        'diffusion': 'full_state_mixing_per_round',
        'weakness_class': 'impossible_differential_distinguisher',
    },
    'ARX-Feistel': {
        'operations': ['modular_addition', 'bitwise_rotation', 'xor'],
        'structure': 'feistel_with_arx_round_function',
        'diffusion': 'half_state_per_round',
        'weakness_class': 'neural_differential_distinguisher',
    },
    'Feistel-keydep': {
        'operations': ['key_dependent_sbox', 'feistel_xor'],
        'structure': 'feistel_with_keydep_sboxes',
        'diffusion': 'half_state_per_round',
        'weakness_class': 'differential_cryptanalysis',
    },
    'Feistel-fixed': {
        'operations': ['fixed_sbox', 'permutation', 'feistel_xor'],
        'structure': 'triple_des_feistel',
        'diffusion': 'half_state_per_round',
        'weakness_class': 'linear_differential_attack',
    },
    'byte-stream': {
        'operations': ['key_scheduling_swap', 'prga_index_addition'],
        'structure': 'state_table_permutation',
        'diffusion': 'incremental_state_evolution',
        'weakness_class': 'ksa_bias_attack',
    },
    'SPN-Feistel': {
        'operations': ['substitution_box', 'feistel_xor', 'fl_function'],
        'structure': 'hybrid_spn_feistel',
        'diffusion': 'mixed_spn_feistel_per_round',
        'weakness_class': 'impossible_differential_distinguisher',
    },
}

# Map signal strategies to what they detect
STRATEGY_SEMANTICS = {
    'bit_correlation': {
        'detects': 'incomplete_diffusion',
        'mechanism': 'bit_level_dependency_between_positions',
        'family_affinity': ['ARX-stream', 'ARX-Feistel'],  # ARX has bit-level structure
    },
    'xor_distribution': {
        'detects': 'non_uniform_mixing',
        'mechanism': 'xor_distribution_bias_from_weak_diffusion',
        'family_affinity': ['ARX-stream', 'SPN-block'],
    },
    'parity_chain': {
        'detects': 'linear_propagation',
        'mechanism': 'parity_correlation_through_feistel_structure',
        'family_affinity': ['Feistel-keydep', 'Feistel-fixed', 'ARX-Feistel'],
    },
    'cross_bit': {
        'detects': 'rotation_addition_bias',
        'mechanism': 'cross_byte_bit_dependency_from_rotation',
        'family_affinity': ['ARX-stream', 'ARX-Feistel'],
    },
    'block_repetition': {
        'detects': 'deterministic_output',
        'mechanism': 'identical_blocks_from_nonce_or_counter_failure',
        'family_affinity': [],  # implementation bug, not family-specific
    },
    'byte_frequency': {
        'detects': 'distribution_bias',
        'mechanism': 'non_uniform_byte_distribution',
        'family_affinity': [],
    },
    'seq_correlation': {
        'detects': 'sequential_dependency',
        'mechanism': 'correlation_between_consecutive_outputs',
        'family_affinity': ['byte-stream'],
    },
    'entropy': {
        'detects': 'low_entropy_output',
        'mechanism': 'insufficient_randomness_in_output',
        'family_affinity': [],
    },
    'runs': {
        'detects': 'bit_run_bias',
        'mechanism': 'non_random_bit_run_distribution',
        'family_affinity': ['byte-stream'],
    },
    'spectral': {
        'detects': 'periodic_structure',
        'mechanism': 'frequency_domain_pattern_from_structure',
        'family_affinity': [],
    },
    'compression': {
        'detects': 'compressible_output',
        'mechanism': 'structural_redundancy_in_output',
        'family_affinity': [],
    },
    'autocorrelation': {
        'detects': 'periodic_repetition',
        'mechanism': 'self_correlation_from_short_period',
        'family_affinity': ['byte-stream'],
    },
}


# ═══════════════════════════════════════════════════════════════
# SIGNAL COLLECTION
# ═══════════════════════════════════════════════════════════════

def collect_signals(n_keys=10000, quick=False):
    """Collect 12D signal vectors for all ciphers × rounds.

    Args:
        n_keys: keys per test (more = more precise signals)
        quick: if True, test fewer rounds (faster)

    Returns:
        list of dicts: {cipher, round, strategy, z_score, fires, crypto_casi, full_casi}
    """
    observations = []
    cipher_order = ['chacha', 'salsa', 'aes', 'speck', 'blowfish', 'tdes', 'rc4', 'camellia']

    for cipher_name in cipher_order:
        info = CIPHERS[cipher_name]
        full_rounds = info['full_rounds']
        is_slow = info.get('slow', False)
        keys = min(n_keys, 1000) if is_slow else n_keys
        key_size = 32

        # Determine which rounds to test
        if quick:
            # Test: R1, frontier, full rounds
            test_rounds = sorted(set([1, max(1, info['frontier']), full_rounds]))
        else:
            # Test every round up to frontier+2, then full
            max_test = min(info['frontier'] + 2, full_rounds)
            test_rounds = list(range(1, max_test + 1)) + [full_rounds]
            test_rounds = sorted(set(test_rounds))

        for r in test_rounds:
            try:
                crypto_casi, full_casi, crypto_signal, full_signal = compute_casi_at_rounds(
                    cipher_name, r, n_keys=keys, key_size=key_size, seed=42
                )
            except Exception:
                continue

            # Record per-strategy signals
            for strategy in STRATEGY_NAMES:
                count = full_signal.get(strategy, 0)
                observations.append({
                    'cipher': cipher_name,
                    'cipher_name': info['name'],
                    'family': info['family'],
                    'round': r,
                    'full_rounds': full_rounds,
                    'strategy': strategy,
                    'signal_count': count,
                    'fires': count > 0,
                    'is_crypto_strategy': strategy in CRYPTO_STRATEGY_NAMES,
                    'crypto_casi': crypto_casi,
                    'full_casi': full_casi,
                })

    return observations


# ═══════════════════════════════════════════════════════════════
# TRIPLET GENERATION
# ═══════════════════════════════════════════════════════════════

def _signal_strength(count):
    """Classify signal strength from count."""
    if count == 0:
        return None
    elif count < 10:
        return 'marginal'
    elif count < 100:
        return 'moderate'
    elif count < 1000:
        return 'strong'
    else:
        return 'extreme'


def generate_triplets(observations):
    """Convert signal observations + domain knowledge into causal triplets.

    Returns:
        list of dicts ready for CausalWriter.add_triplet()
    """
    triplets = []

    # --- 1. OBSERVATION TRIPLETS (from signal data) ---
    for obs in observations:
        if not obs['fires']:
            continue  # skip zero-signal observations

        strength = _signal_strength(obs['signal_count'])
        cipher_round = f"{obs['cipher_name']}_R{obs['round']}"
        strategy = obs['strategy']
        semantics = STRATEGY_SEMANTICS[strategy]

        # Core observation: cipher_round has signal from strategy
        triplets.append({
            'trigger': cipher_round,
            'mechanism': f"{strategy}_signal({strength},n={obs['signal_count']})",
            'outcome': semantics['detects'],
            'confidence': min(1.0, obs['signal_count'] / 500.0),
            'domain': 'cryptanalysis',
            'evidence': f"{obs['cipher_name']} round {obs['round']}: "
                        f"{strategy} fired {obs['signal_count']} times "
                        f"(crypto-CASI={obs['crypto_casi']:.1f}, full-CASI={obs['full_casi']:.1f})",
            'source': 'live-casi',
        })

        # Link signal to detection mechanism
        triplets.append({
            'trigger': semantics['detects'],
            'mechanism': semantics['mechanism'],
            'outcome': f"{obs['family']}_structural_weakness",
            'confidence': min(0.95, obs['signal_count'] / 1000.0),
            'domain': 'cryptanalysis',
            'evidence': f"{strategy} detects {semantics['detects']} via {semantics['mechanism']}",
            'source': 'live-casi',
        })

    # --- 2. ARCHITECTURE TRIPLETS (domain knowledge) ---
    for family, props in FAMILY_PROPERTIES.items():
        # Family uses operations
        for op in props['operations']:
            triplets.append({
                'trigger': family,
                'mechanism': f"uses_{op}",
                'outcome': props['structure'],
                'confidence': 1.0,
                'domain': 'cipher_architecture',
                'evidence': f"{family} ciphers use {op} in {props['structure']}",
                'source': 'domain_knowledge',
            })

        # Family structure implies diffusion pattern
        triplets.append({
            'trigger': props['structure'],
            'mechanism': f"provides_{props['diffusion']}",
            'outcome': f"diffusion_characteristic_{family}",
            'confidence': 1.0,
            'domain': 'cipher_architecture',
            'evidence': f"{props['structure']} provides {props['diffusion']}",
            'source': 'domain_knowledge',
        })

        # Family diffusion linked to weakness class
        triplets.append({
            'trigger': f"diffusion_characteristic_{family}",
            'mechanism': 'when_insufficient_rounds',
            'outcome': props['weakness_class'],
            'confidence': 0.9,
            'domain': 'cipher_architecture',
            'evidence': f"Insufficient rounds of {props['diffusion']} allows {props['weakness_class']}",
            'source': 'domain_knowledge',
        })

    # Cipher → family membership
    for cipher_name, info in CIPHERS.items():
        triplets.append({
            'trigger': info['name'],
            'mechanism': 'is_member_of',
            'outcome': info['family'],
            'confidence': 1.0,
            'domain': 'cipher_architecture',
            'evidence': f"{info['name']} belongs to the {info['family']} family",
            'source': 'domain_knowledge',
        })

    # Strategy → family affinity
    for strategy, sem in STRATEGY_SEMANTICS.items():
        for family in sem['family_affinity']:
            triplets.append({
                'trigger': strategy,
                'mechanism': 'has_elevated_sensitivity_to',
                'outcome': family,
                'confidence': 0.85,
                'domain': 'signal_theory',
                'evidence': f"{strategy} has elevated sensitivity to {family} cipher structures",
                'source': 'live-casi',
            })

    # --- 3. FRONTIER TRIPLETS (benchmark results) ---
    seen_ciphers = set()
    for obs in observations:
        cn = obs['cipher']
        if cn in seen_ciphers:
            continue
        seen_ciphers.add(cn)

        info = CIPHERS[cn]
        academic = ACADEMIC_FRONTIERS.get(cn, {})

        # CASI frontier
        # Determine crypto frontier from observations
        crypto_frontier = 0
        impl_frontier = 0
        for o in observations:
            if o['cipher'] != cn:
                continue
            if o['strategy'] == STRATEGY_NAMES[0]:  # just check once per round
                if o['crypto_casi'] > 2.0:
                    crypto_frontier = max(crypto_frontier, o['round'])
                if o['full_casi'] > 2.0:
                    impl_frontier = max(impl_frontier, o['round'])

        if crypto_frontier > 0:
            triplets.append({
                'trigger': info['name'],
                'mechanism': f'crypto_casi_frontier_R{crypto_frontier}',
                'outcome': f'secure_above_R{crypto_frontier}',
                'confidence': 0.95,
                'domain': 'benchmark',
                'evidence': f"{info['name']} Crypto-CASI detectable through R{crypto_frontier}",
                'source': 'live-casi',
            })

        if academic:
            triplets.append({
                'trigger': info['name'],
                'mechanism': f"academic_frontier_{academic['frontier']}",
                'outcome': f"academic_attack_by_{academic['method'].replace(' ', '_').lower()}",
                'confidence': 1.0,
                'domain': 'academic',
                'evidence': f"{info['name']}: {academic['method']} ({academic['source']})",
                'source': academic['source'],
            })

            # Compare CASI vs academic
            gap = academic['frontier_mid'] - crypto_frontier
            if gap > 0:
                triplets.append({
                    'trigger': f"{info['name']}_casi_frontier",
                    'mechanism': f'gap_of_{int(gap)}_rounds_below',
                    'outcome': f"{info['name']}_academic_frontier",
                    'confidence': 0.9,
                    'domain': 'comparison',
                    'evidence': f"CASI frontier R{crypto_frontier} vs academic {academic['frontier']} "
                                f"(gap ~{gap:.0f} rounds — expected for black-box vs targeted analysis)",
                    'source': 'live-casi',
                })

    return triplets


# ═══════════════════════════════════════════════════════════════
# KNOWLEDGE GRAPH ASSEMBLY + INFERENCE
# ═══════════════════════════════════════════════════════════════

def generate_causal_graph(output_path, n_keys=10000, quick=False, verbose=True):
    """Generate a CASI cryptanalytic knowledge graph.

    Args:
        output_path: path for the .causal output file
        n_keys: keys per cipher test (default 10000)
        quick: if True, test fewer rounds per cipher
        verbose: print progress to stderr

    Returns:
        dict with stats: explicit_triplets, inferred_triplets, entities, discoveries
    """
    try:
        from dotcausal import CausalFile, CausalReader
    except ImportError:
        print("Error: dotcausal package required. Install with: pip install dotcausal", file=sys.stderr)
        sys.exit(1)

    t0 = time.time()

    # Step 1: Collect signals
    if verbose:
        print(f"[1/4] Collecting signals: 8 ciphers × multiple rounds, {n_keys} keys each...",
              file=sys.stderr)

    observations = collect_signals(n_keys=n_keys, quick=quick)
    n_obs = len(observations)
    firing = sum(1 for o in observations if o['fires'])

    if verbose:
        print(f"       {n_obs} observations, {firing} signals detected", file=sys.stderr)

    # Step 2: Generate triplets
    if verbose:
        print(f"[2/4] Generating causal triplets...", file=sys.stderr)

    triplets = generate_triplets(observations)

    if verbose:
        print(f"       {len(triplets)} explicit triplets generated", file=sys.stderr)

    # Step 3: Assemble .causal file
    if verbose:
        print(f"[3/4] Assembling .causal knowledge graph...", file=sys.stderr)

    cf = CausalFile()

    # Add custom inference rules for cryptanalytic reasoning
    cf._writer.add_rule(
        name="signal_transitivity",
        description="If cipher X shows signal S, and S detects weakness W, then X has weakness W",
        pattern=["signal", "detects"],
        conclusion="has_weakness",
        confidence_modifier=0.85,
    )
    cf._writer.add_rule(
        name="family_vulnerability_inheritance",
        description="If family F has weakness W, and cipher C is member of F, then C may have W",
        pattern=["member_of", "structural_weakness"],
        conclusion="inherited_vulnerability",
        confidence_modifier=0.70,
    )

    for t in triplets:
        cf.add_triplet(**t)

    stats = cf.save(output_path)

    if verbose:
        print(f"       Saved: {output_path} ({os.path.getsize(output_path):,} bytes)", file=sys.stderr)

    # Step 4: Run inference and analyze
    if verbose:
        print(f"[4/4] Running 3-pass inference engine...", file=sys.stderr)

    reader = CausalReader(output_path)
    all_triplets = reader.get_all_triplets(include_inferred=True)
    explicit_triplets = reader.get_all_triplets(include_inferred=False)
    n_inferred = len(all_triplets) - len(explicit_triplets)

    # Analyze discoveries
    discoveries = _analyze_discoveries(all_triplets, explicit_triplets)

    elapsed = time.time() - t0

    if verbose:
        print(f"\n{'='*60}", file=sys.stderr)
        print(f"CASI Cryptanalytic Knowledge Graph", file=sys.stderr)
        print(f"{'='*60}", file=sys.stderr)
        print(f"  Explicit triplets:  {len(explicit_triplets)}", file=sys.stderr)
        print(f"  Inferred triplets:  {n_inferred}", file=sys.stderr)
        print(f"  Amplification:      {len(all_triplets)/max(len(explicit_triplets),1):.1f}x", file=sys.stderr)
        print(f"  Unique entities:    {stats.get('entities', '?')}", file=sys.stderr)
        print(f"  Time:               {elapsed:.1f}s", file=sys.stderr)
        print(f"  Output:             {output_path}", file=sys.stderr)

        if discoveries:
            print(f"\nDiscoveries ({len(discoveries)}):", file=sys.stderr)
            for d in discoveries[:10]:
                print(f"  → {d}", file=sys.stderr)

    return {
        'output_path': output_path,
        'explicit_triplets': len(explicit_triplets),
        'inferred_triplets': n_inferred,
        'total_triplets': len(all_triplets),
        'amplification': len(all_triplets) / max(len(explicit_triplets), 1),
        'entities': stats.get('entities', 0),
        'observations': n_obs,
        'signals_detected': firing,
        'discoveries': discoveries,
        'elapsed_seconds': elapsed,
    }


def _analyze_discoveries(all_triplets, explicit_triplets):
    """Extract interesting inferred patterns from the knowledge graph."""
    discoveries = []
    explicit_set = set()
    for t in explicit_triplets:
        trigger = t.get('trigger', t.get('s_idx', ''))
        outcome = t.get('outcome', t.get('o_idx', ''))
        explicit_set.add((str(trigger), str(outcome)))

    # Find inferred triplets that connect different cipher families
    for t in all_triplets:
        trigger = str(t.get('trigger', t.get('s_idx', '')))
        mechanism = str(t.get('mechanism', t.get('m_idx', '')))
        outcome = str(t.get('outcome', t.get('o_idx', '')))

        if (trigger, outcome) in explicit_set:
            continue  # skip explicit triplets

        # Cross-family pattern: trigger mentions one cipher, outcome mentions another family
        cipher_names = [info['name'] for info in CIPHERS.values()]
        family_names = list(FAMILY_PROPERTIES.keys())

        trigger_cipher = None
        outcome_family = None
        for cn in cipher_names:
            if cn in trigger:
                trigger_cipher = cn
                break
        for fn in family_names:
            if fn in outcome:
                outcome_family = fn
                break

        if trigger_cipher and outcome_family:
            # Check if this is a cross-family inference
            trigger_family = None
            for info in CIPHERS.values():
                if info['name'] == trigger_cipher:
                    trigger_family = info['family']
                    break
            if trigger_family and trigger_family != outcome_family:
                discoveries.append(
                    f"Cross-family: {trigger_cipher} ({trigger_family}) "
                    f"→ {mechanism} → {outcome_family} weakness pattern"
                )

        # Shared vulnerability pattern
        if 'weakness' in outcome.lower() or 'vulnerability' in outcome.lower():
            conf = t.get('confidence', 0)
            if conf > 0.5:
                discoveries.append(
                    f"Inferred: {trigger} → {mechanism} → {outcome} (conf={conf:.2f})"
                )

    # Deduplicate and limit
    seen = set()
    unique = []
    for d in discoveries:
        if d not in seen:
            seen.add(d)
            unique.append(d)

    return unique[:20]


# ═══════════════════════════════════════════════════════════════
# CLI HANDLER
# ═══════════════════════════════════════════════════════════════

def run_causal(args):
    """CLI handler for --causal."""
    output_path = args.causal
    n_keys = getattr(args, 'keys', 10000) or 10000
    quick = getattr(args, 'quick', False)

    stats = generate_causal_graph(
        output_path=output_path,
        n_keys=n_keys,
        quick=quick,
        verbose=True,
    )

    # JSON output if requested
    if getattr(args, 'json', False):
        import json
        print(json.dumps(stats, indent=2, default=str))
