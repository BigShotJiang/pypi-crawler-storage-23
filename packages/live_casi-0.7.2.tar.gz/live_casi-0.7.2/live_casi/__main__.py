"""Allow running as: python -m live_casi"""
from .core import main

if __name__ == '__main__':
    main()
