"""
live-casi: Real-time Causal Amplification Security Index Monitor

Analyze byte streams and compute a CASI score that quantifies how far
a cipher implementation is from cryptographic randomness.

Quick usage:
    from live_casi import LiveCASI, compute_signal
    engine = LiveCASI(key_size=32, window_keys=10000)
    engine.feed(data)
    engine.force_update()
    print(engine.current_casi)  # ~1.0 = SECURE, >2.0 = WEAK, >10.0 = BROKEN

v0.2.0 additions:
    from live_casi import identify_cipher, scan_binary
    result = identify_cipher(data)           # Blind cipher identification
    regions = scan_binary(firmware_blob)      # Firmware/binary scanner

v0.3.0 additions:
    from live_casi import analyze_pcap, live_monitor
    conns = analyze_pcap('capture.pcap')     # pcap analysis (requires scapy)
    conns = live_monitor(interface='en0')    # Live network monitor (requires sudo)

v0.4.0 additions:
    from live_casi import generate_causal_graph
    from live_casi import generate_probe, verify_probe
    stats = generate_causal_graph('out.causal')  # Cryptanalytic knowledge graph (requires dotcausal)
    generate_probe('probe.bin')                   # Channel probe generator
    result = verify_probe('received.bin')         # Channel probe verifier

v0.5.0 additions:
    from live_casi import pqc_analyze, pqc_compare
    result = pqc_analyze('mlkem', 768)            # Single PQC config (requires pqcrypto)
    report = pqc_compare()                        # All 9 PQC configs vs classical

v0.5.1 additions:
    from live_casi import find_frontier, sweep_all_frontiers
    from live_casi import compare_all, format_comparison_table
    from live_casi import compute_signal_with_ci
    result = find_frontier('chacha')               # Binary-search detection boundary
    results = sweep_all_frontiers()                # All cipher frontiers
    nist = compare_all()                           # CASI vs NIST SP 800-22
    ci = compute_signal_with_ci(keys)              # Bootstrap confidence intervals

v0.6.0 additions:
    from live_casi import compute_deep_signal, compute_casi_score
    from live_casi import DEEP_STRATEGY_NAMES, DEEP_BASELINE_FLOOR
    score = compute_casi_score(keys)               # Max-sensitivity CASI score
    deep = compute_deep_signal(keys)               # Deep cryptanalytic strategies only
    # 14 deep strategies: avalanche, linear_bias, higher_order, differential,
    # integral, truncated_diff, rotational, algebraic_degree, diff_linear,
    # boomerang, impossible_diff, zero_correlation, division_property, slide
    # 26 total strategies (4 classic + 14 deep + 8 implementation)

v0.6.1 additions:
    from live_casi import compute_amplified_score
    result = compute_amplified_score(keys)         # PCR-style causal amplification
    # Three-pass inference (inspired by .causal format, Foss 2026):
    #   Pass 1: Exact (avalanche/differential at 8 strides)
    #   Pass 2: Semantic (cross-position correlation + linear bias)
    #   Pass 3: Fuzzy (2nd-order diff, nibble, dibit, GF(2) combination)
    # Fisher's combined test amplifies distributed weak signals.
    # Extends Salsa20 frontier from R3 to R4 at N=50K.

v0.7.0 additions:
    from live_casi.academia import analyze_text, analyze_pdf
    result = analyze_text(text, language='de')     # AI detection for academic text
    result = analyze_pdf('thesis.pdf')             # PDF analysis
    # 5-layer detection: Token-residuum + CASI profile + ChatGPT markers +
    # DeepL/translationese + intra-document consistency.
    # Validated: AUC=0.989 (GPT-4 DE), AUC=0.871 (GPT-4o EN),
    # dose-response rho=-0.926, paraphrasing-robust (d=-2.17).
    # Patent: CASI-Detect (Foss 2026, DPMA).
"""

__version__ = '0.7.2'

from .core import (
    LiveCASI,
    LiveCASIWithStorage,
    compute_signal,
    compute_crypto_signal,
    compute_deep_signal,
    compute_casi_score,
    compute_amplified_score,
    compute_signal_with_ci,
    STRATEGY_NAMES,
    CRYPTO_STRATEGY_NAMES,
    DEEP_STRATEGY_NAMES,
    IMPL_STRATEGY_NAMES,
    DEEP_BASELINE_FLOOR,
    Z_THRESHOLD,
    casi_verdict,
    main,
)
from .ciphers import CIPHERS
from .identify import identify_cipher, get_profiles as get_cipher_profiles
from .scanner import scan_binary, detect_regions
from .benchmark import run_frontier_benchmark, ACADEMIC_FRONTIERS
from .probe import generate_probe, verify_probe, compare_probes
from .frontier import find_frontier, sweep_all_frontiers, format_frontier_table
from .nist_compare import compare_cipher, compare_all, format_comparison_table

# Network tools — optional (require scapy)
try:
    from .network import analyze_pcap, live_monitor
except ImportError:
    pass  # scapy not installed, network features unavailable

# Causal knowledge graph — optional (requires dotcausal)
try:
    from .causal import generate_causal_graph
except ImportError:
    pass  # dotcausal not installed, causal features unavailable

# PQC analysis — optional (requires pqcrypto)
try:
    from .pqc import pqc_analyze, pqc_compare, pqc_causal, PQC_FAMILIES, PQC_CONFIGS
except ImportError:
    pass  # pqcrypto not installed, PQC features unavailable

# Academia AI detection
from .academia import analyze_text, analyze_pdf, AcademiaResult

# Author fingerprinting
from .fingerprint import (
    byte_vector, full_vector, rank_fusion_match,
    Fingerprinter,
)

# Text AI detection (Patent Foss 2026)
from .text_detect import (
    residuum_histogram, compute_reference, detect_ai,
    detect_segments, dose_response_validate,
)
