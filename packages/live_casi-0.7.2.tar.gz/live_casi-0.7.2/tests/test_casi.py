#!/usr/bin/env python3
"""
Comprehensive test suite for live-casi.

Tests the core CASI metric, all cipher generators, frontier detection,
bootstrap CI, NIST comparison, and the LiveCASI streaming engine.

Run: pytest tests/test_casi.py -v
"""

import os
import pytest
import numpy as np

from live_casi.core import (
    compute_signal, compute_crypto_signal, compute_signal_with_ci,
    compute_deep_signal, compute_casi_score, compute_amplified_score,
    LiveCASI, LiveCASIWithStorage,
    strategy_bit_correlation, strategy_xor_distribution,
    strategy_parity_chain, strategy_cross_bit,
    strategy_avalanche, strategy_linear_bias,
    strategy_higher_order, strategy_differential,
    strategy_block_repetition, strategy_byte_frequency,
    strategy_compression, strategy_entropy,
    STRATEGY_NAMES, CRYPTO_STRATEGY_NAMES, DEEP_STRATEGY_NAMES,
    DEEP_BASELINE_FLOOR,
    casi_verdict,
)
from live_casi.ciphers import CIPHERS


# ═══════════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════════

def _generate_keys(cipher_key, rounds, n_keys=10000, seed=42):
    """Generate keys and return as numpy array."""
    gen = CIPHERS[cipher_key]['generator']
    data = gen(n_keys, rounds=rounds, seed=seed)
    return np.frombuffer(data, dtype=np.uint8).reshape(n_keys, 32)


def _compute_casi(keys):
    """Compute CASI score from key array."""
    baseline = np.frombuffer(
        np.random.RandomState(0xBA5E).bytes(keys.shape[0] * 32),
        dtype=np.uint8,
    ).reshape(keys.shape[0], 32)
    sig = compute_crypto_signal(keys)
    base = compute_crypto_signal(baseline)
    return sig['total'] / max(base['total'], 1)


# ═══════════════════════════════════════════════════════════════
# 1. Random Baseline Tests
# ═══════════════════════════════════════════════════════════════

class TestRandomBaseline:
    """True random (os.urandom) should always score CASI < 1.5."""

    def test_urandom_crypto_signal(self):
        keys = np.frombuffer(os.urandom(10000 * 32), dtype=np.uint8).reshape(10000, 32)
        casi = _compute_casi(keys)
        assert casi < 1.5, f"os.urandom CASI={casi:.2f}, expected < 1.5"

    def test_urandom_full_signal(self):
        keys = np.frombuffer(os.urandom(10000 * 32), dtype=np.uint8).reshape(10000, 32)
        sig = compute_signal(keys)
        baseline = compute_signal(
            np.frombuffer(np.random.RandomState(0xBA5E).bytes(10000 * 32),
                          dtype=np.uint8).reshape(10000, 32)
        )
        casi = sig['total'] / max(baseline['total'], 1)
        assert casi < 2.0, f"os.urandom full CASI={casi:.2f}, expected < 2.0"

    def test_verdict_secure(self):
        assert casi_verdict(0.9) == 'SECURE'
        assert casi_verdict(1.4) == 'SECURE'

    def test_verdict_broken(self):
        assert casi_verdict(100.0) == 'BROKEN'
        assert casi_verdict(10.1) == 'BROKEN'

    def test_verdict_weak(self):
        assert casi_verdict(5.0) == 'WEAK'

    def test_verdict_borderline(self):
        assert casi_verdict(1.8) == 'Borderline'


# ═══════════════════════════════════════════════════════════════
# 2. Cipher Detection Tests — Broken ciphers must be detected
# ═══════════════════════════════════════════════════════════════

class TestBrokenCiphers:
    """Round 1 of every cipher should have CASI >> 2.0 (BROKEN)."""

    @pytest.mark.parametrize("cipher_key", ['chacha', 'salsa', 'aes', 'speck', 'blowfish'])
    def test_round1_detected(self, cipher_key):
        keys = _generate_keys(cipher_key, rounds=1, n_keys=10000)
        casi = _compute_casi(keys)
        assert casi > 5.0, f"{cipher_key} R1 CASI={casi:.2f}, expected > 5.0"

    @pytest.mark.parametrize("cipher_key", ['chacha', 'salsa', 'aes', 'speck', 'blowfish'])
    def test_round1_signal_nonzero(self, cipher_key):
        keys = _generate_keys(cipher_key, rounds=1, n_keys=10000)
        sig = compute_crypto_signal(keys)
        assert sig['total'] > 0, f"{cipher_key} R1 should have nonzero signal"


# ═══════════════════════════════════════════════════════════════
# 3. Cipher Detection Tests — Secure ciphers must pass
# ═══════════════════════════════════════════════════════════════

class TestSecureCiphers:
    """Full-round ciphers should have CASI < 2.0 (SECURE)."""

    @pytest.mark.parametrize("cipher_key,full_rounds", [
        ('chacha', 20), ('salsa', 20), ('aes', 10),
        ('speck', 22), ('blowfish', 16),
    ])
    def test_full_rounds_secure(self, cipher_key, full_rounds):
        keys = _generate_keys(cipher_key, rounds=full_rounds, n_keys=10000)
        casi = _compute_casi(keys)
        assert casi < 2.0, f"{cipher_key} R{full_rounds} CASI={casi:.2f}, expected < 2.0"


# ═══════════════════════════════════════════════════════════════
# 4. Individual Strategy Tests
# ═══════════════════════════════════════════════════════════════

class TestStrategies:
    """Each crypto strategy should fire on broken ciphers."""

    def test_bit_correlation_fires_on_chacha_r1(self):
        keys = _generate_keys('chacha', rounds=1, n_keys=10000)
        count = strategy_bit_correlation(keys)
        assert count > 0, "bit_correlation should detect ChaCha R1"

    def test_xor_distribution_fires_on_aes_r1(self):
        keys = _generate_keys('aes', rounds=1, n_keys=10000)
        count = strategy_xor_distribution(keys)
        assert count > 0, "xor_distribution should detect AES R1"

    def test_parity_chain_fires_on_speck_r1(self):
        keys = _generate_keys('speck', rounds=1, n_keys=10000)
        count = strategy_parity_chain(keys)
        assert count > 0, "parity_chain should detect Speck R1"

    def test_cross_bit_fires_on_salsa_r1(self):
        keys = _generate_keys('salsa', rounds=1, n_keys=10000)
        count = strategy_cross_bit(keys)
        assert count > 0, "cross_bit should detect Salsa R1"

    def test_block_repetition_on_random(self):
        keys = np.frombuffer(os.urandom(10000 * 32), dtype=np.uint8).reshape(10000, 32)
        count = strategy_block_repetition(keys)
        assert count == 0, "Random data should have no block repetitions"

    def test_byte_frequency_on_random(self):
        keys = np.frombuffer(os.urandom(10000 * 32), dtype=np.uint8).reshape(10000, 32)
        count = strategy_byte_frequency(keys)
        # Statistical test — may fire occasionally on truly random data
        assert count < 150, f"Random byte frequency signal too high: {count}"

    def test_compression_on_random(self):
        keys = np.frombuffer(os.urandom(10000 * 32), dtype=np.uint8).reshape(10000, 32)
        count = strategy_compression(keys)
        assert count == 0, "Random data should not compress"

    def test_entropy_on_random(self):
        keys = np.frombuffer(os.urandom(10000 * 32), dtype=np.uint8).reshape(10000, 32)
        count = strategy_entropy(keys)
        assert count < 5, f"Random entropy signal too high: {count}"

    def test_all_strategies_exist(self):
        for name in STRATEGY_NAMES:
            assert callable(globals().get(f'strategy_{name}', None) or
                            getattr(__import__('live_casi.core', fromlist=[f'strategy_{name}']),
                                    f'strategy_{name}')), f"Missing strategy: {name}"


# ═══════════════════════════════════════════════════════════════
# 5. Attack Detection Tests
# ═══════════════════════════════════════════════════════════════

class TestAttackDetection:
    """Common implementation bugs must be detected."""

    def test_ecb_detected(self):
        """ECB mode produces identical ciphertext for identical plaintext."""
        # Simulate ECB: same 32 bytes repeated
        block = os.urandom(32)
        keys = np.frombuffer(block * 10000, dtype=np.uint8).reshape(10000, 32)
        sig = compute_signal(keys)
        assert sig['block_repetition'] > 0, "ECB (repeated blocks) not detected"

    def test_xor_with_short_key(self):
        """XOR with a short repeating key is trivially broken."""
        short_key = os.urandom(4)  # 4-byte key
        plaintext = os.urandom(10000 * 32)
        # XOR each byte with repeating key
        encrypted = bytearray(plaintext)
        for i in range(len(encrypted)):
            encrypted[i] ^= short_key[i % 4]
        keys = np.frombuffer(bytes(encrypted), dtype=np.uint8).reshape(10000, 32)
        sig = compute_signal(keys)
        # Short XOR key creates autocorrelation at lag=4
        assert sig['total'] > 0, "XOR with short key not detected"

    def test_lcg_detected(self):
        """Linear congruential generator (constant diff pattern)."""
        # Simple LCG: x = (a*x + c) mod m
        rng = np.random.RandomState(42)
        x = rng.randint(0, 2**32)
        a, c = 1664525, 1013904223  # Numerical Recipes LCG
        data = bytearray()
        for _ in range(10000):
            x = (a * x + c) & 0xFFFFFFFF
            data.extend(x.to_bytes(4, 'little') * 8)  # Pad to 32 bytes
        keys = np.frombuffer(bytes(data), dtype=np.uint8).reshape(10000, 32)
        sig = compute_signal(keys)
        assert sig['total'] > 100, f"LCG not strongly detected: signal={sig['total']}"

    def test_constant_stream_detected(self):
        """Constant output = catastrophic failure."""
        keys = np.zeros((10000, 32), dtype=np.uint8)
        sig = compute_signal(keys)
        assert sig['total'] > 1000, "Constant stream not strongly detected"


# ═══════════════════════════════════════════════════════════════
# 6. Bootstrap Confidence Interval Tests
# ═══════════════════════════════════════════════════════════════

class TestBootstrapCI:
    """Bootstrap CI should produce valid intervals."""

    def test_ci_on_random(self):
        keys = np.frombuffer(os.urandom(10000 * 32), dtype=np.uint8).reshape(10000, 32)
        result = compute_signal_with_ci(keys, n_bootstrap=50, crypto_only=False)
        assert result['ci_lower'] <= result['mean'] <= result['ci_upper']
        assert result['std'] >= 0
        assert result['mean'] < 2.0, f"Random CASI mean={result['mean']:.2f}"

    def test_ci_on_broken(self):
        keys = _generate_keys('chacha', rounds=1, n_keys=5000)
        result = compute_signal_with_ci(keys, n_bootstrap=50, crypto_only=True)
        assert result['ci_lower'] > 2.0, f"ChaCha R1 CI lower={result['ci_lower']:.2f}"
        assert len(result['scores']) == 50

    def test_ci_width_reasonable(self):
        keys = _generate_keys('speck', rounds=1, n_keys=5000)
        result = compute_signal_with_ci(keys, n_bootstrap=50, crypto_only=True)
        width = result['ci_upper'] - result['ci_lower']
        assert width > 0, "CI width should be positive"
        assert width < result['mean'] * 0.5, f"CI too wide: {width:.2f} vs mean {result['mean']:.2f}"


# ═══════════════════════════════════════════════════════════════
# 7. Cipher Generator Tests
# ═══════════════════════════════════════════════════════════════

class TestCipherGenerators:
    """All cipher generators must produce correct output."""

    @pytest.mark.parametrize("cipher_key", list(CIPHERS.keys()))
    def test_generator_output_size(self, cipher_key):
        gen = CIPHERS[cipher_key]['generator']
        data = gen(100, rounds=1, seed=42)
        assert len(data) == 100 * 32, f"{cipher_key}: expected {100*32} bytes, got {len(data)}"

    @pytest.mark.parametrize("cipher_key", list(CIPHERS.keys()))
    def test_generator_deterministic(self, cipher_key):
        gen = CIPHERS[cipher_key]['generator']
        d1 = gen(100, rounds=1, seed=42)
        d2 = gen(100, rounds=1, seed=42)
        assert d1 == d2, f"{cipher_key}: same seed should produce same output"

    @pytest.mark.parametrize("cipher_key", list(CIPHERS.keys()))
    def test_generator_different_seeds(self, cipher_key):
        gen = CIPHERS[cipher_key]['generator']
        d1 = gen(100, rounds=1, seed=42)
        d2 = gen(100, rounds=1, seed=99)
        assert d1 != d2, f"{cipher_key}: different seeds should produce different output"

    def test_all_ciphers_in_registry(self):
        expected = {'chacha', 'salsa', 'aes', 'speck', 'blowfish', 'tdes', 'rc4', 'camellia'}
        assert set(CIPHERS.keys()) == expected


# ═══════════════════════════════════════════════════════════════
# 8. Frontier Sweeper Tests
# ═══════════════════════════════════════════════════════════════

class TestFrontierSweeper:
    """Frontier sweeper should find correct boundaries."""

    def test_frontier_import(self):
        from live_casi.frontier import find_frontier, sweep_all_frontiers
        assert callable(find_frontier)
        assert callable(sweep_all_frontiers)

    def test_chacha_frontier(self):
        from live_casi.frontier import find_frontier
        result = find_frontier('chacha', n_keys=5000, crypto_only=True)
        assert result is not None
        # ChaCha frontier should be around R3
        assert 2 <= result['casi_frontier'] <= 5, \
            f"ChaCha frontier R{result['casi_frontier']}, expected R2-5"

    def test_speck_frontier(self):
        from live_casi.frontier import find_frontier
        result = find_frontier('speck', n_keys=5000, crypto_only=True)
        assert result is not None
        # Speck frontier should be around R5-8 (Gohr zone)
        assert 3 <= result['casi_frontier'] <= 10, \
            f"Speck frontier R{result['casi_frontier']}, expected R3-10"

    def test_frontier_has_profile(self):
        from live_casi.frontier import find_frontier
        result = find_frontier('aes', n_keys=5000, crypto_only=True)
        assert 'round_profile' in result
        assert len(result['round_profile']) >= 3


# ═══════════════════════════════════════════════════════════════
# 9. LiveCASI Streaming Engine Tests
# ═══════════════════════════════════════════════════════════════

class TestLiveCASIEngine:
    """The streaming CASI engine should work correctly."""

    def test_engine_init(self):
        engine = LiveCASIWithStorage(key_size=32, window_keys=1000)
        assert engine.keys_total == 0
        assert engine.current_casi is None

    def test_engine_feed_random(self):
        engine = LiveCASIWithStorage(key_size=32, window_keys=1000, update_every=500)
        data = os.urandom(2000 * 32)
        engine.feed(data)
        assert engine.keys_total == 2000
        assert engine.current_casi is not None
        assert engine.current_casi < 2.0

    def test_engine_feed_broken(self):
        engine = LiveCASIWithStorage(key_size=32, window_keys=1000, update_every=500)
        data = CIPHERS['chacha']['generator'](2000, rounds=1, seed=42)
        engine.feed(data)
        assert engine.keys_total == 2000
        assert engine.current_casi is not None
        assert engine.current_casi > 2.0

    def test_engine_history(self):
        engine = LiveCASIWithStorage(key_size=32, window_keys=1000, update_every=500)
        data = os.urandom(2000 * 32)
        engine.feed(data)
        assert len(engine.history) >= 1
        assert 'casi' in engine.history[0]
        assert 'time' in engine.history[0]


# ═══════════════════════════════════════════════════════════════
# 10. NIST Comparison Tests
# ═══════════════════════════════════════════════════════════════

class TestNISTComparison:
    """NIST tests should produce valid p-values."""

    def test_nist_imports(self):
        from live_casi.nist_compare import (
            nist_frequency, nist_block_frequency, nist_runs,
            nist_longest_run, nist_matrix_rank,
        )

    def test_nist_frequency_random(self):
        from live_casi.nist_compare import nist_frequency
        bits = np.unpackbits(np.frombuffer(os.urandom(10000), dtype=np.uint8))
        p = nist_frequency(bits)
        assert 0.0 <= p <= 1.0
        assert p > 0.01, f"Random should pass frequency test, p={p}"

    def test_nist_frequency_biased(self):
        from live_casi.nist_compare import nist_frequency
        # All ones = maximally biased
        bits = np.ones(80000, dtype=np.uint8)
        p = nist_frequency(bits)
        assert p < 0.01, f"All-ones should fail frequency test, p={p}"

    def test_nist_runs_random(self):
        from live_casi.nist_compare import nist_runs
        bits = np.unpackbits(np.frombuffer(os.urandom(10000), dtype=np.uint8))
        p = nist_runs(bits)
        assert 0.0 <= p <= 1.0
        assert p > 0.01, f"Random should pass runs test, p={p}"

    def test_nist_approx_entropy_random(self):
        from live_casi.nist_compare import nist_approximate_entropy
        bits = np.unpackbits(np.frombuffer(os.urandom(10000), dtype=np.uint8))
        p = nist_approximate_entropy(bits)
        assert 0.0 <= p <= 1.0

    def test_nist_serial_random(self):
        from live_casi.nist_compare import nist_serial
        bits = np.unpackbits(np.frombuffer(os.urandom(10000), dtype=np.uint8))
        p = nist_serial(bits)
        assert 0.0 <= p <= 1.0

    def test_nist_cumsum_random(self):
        from live_casi.nist_compare import nist_cumulative_sums
        bits = np.unpackbits(np.frombuffer(os.urandom(10000), dtype=np.uint8))
        p = nist_cumulative_sums(bits)
        assert 0.0 <= p <= 1.0
        assert p > 0.01, f"Random should pass cusum test, p={p}"

    def test_nist_8_tests_exist(self):
        from live_casi.nist_compare import NIST_TESTS
        assert len(NIST_TESTS) == 8

    def test_compare_cipher(self):
        from live_casi.nist_compare import compare_cipher
        results = compare_cipher('chacha', rounds_list=[1, 20], n_keys=5000)
        assert len(results) == 2
        assert results[0]['casi_detects'] is True
        assert results[1]['casi_detects'] is False


# ═══════════════════════════════════════════════════════════════
# 11. Backdoor Detection Tests
# ═══════════════════════════════════════════════════════════════

class TestBackdoorDetection:
    """CASI must detect backdoors that NIST misses."""

    def test_backdoor_imports(self):
        from live_casi.backdoor_analysis import (
            generate_backdoor_multi_pair, run_backdoor_showcase,
            sweep_bias_threshold,
        )

    def test_multi_pair_gap_at_040(self):
        """THE KEY TEST: bias=0.40 must produce CASI > 2.0 with all NIST passing."""
        from live_casi.backdoor_analysis import generate_backdoor_multi_pair, _run_analysis
        keys = generate_backdoor_multi_pair(n_keys=10000, seed=42, bias=0.40)
        result = _run_analysis(keys, "test")
        assert result['casi_full'] > 2.0, f"CASI={result['casi_full']}, expected > 2.0"
        assert result['nist_all_pass'], "NIST should pass for this backdoor"
        assert result['is_gap'], "This should be a gap instance"

    def test_multi_pair_gap_at_030(self):
        from live_casi.backdoor_analysis import generate_backdoor_multi_pair, _run_analysis
        keys = generate_backdoor_multi_pair(n_keys=10000, seed=42, bias=0.30)
        result = _run_analysis(keys, "test")
        assert result['casi_full'] >= 2.0
        assert result['nist_all_pass']

    def test_multi_pair_no_gap_at_005(self):
        """Very low bias should not be detected."""
        from live_casi.backdoor_analysis import generate_backdoor_multi_pair, _run_analysis
        keys = generate_backdoor_multi_pair(n_keys=10000, seed=42, bias=0.05)
        result = _run_analysis(keys, "test")
        assert result['casi_full'] < 2.0, f"Bias=0.05 should not be detected, CASI={result['casi_full']}"

    def test_showcase_finds_gaps(self):
        from live_casi.backdoor_analysis import run_backdoor_showcase
        results = run_backdoor_showcase(n_keys=10000, seed=42)
        gaps = [r for r in results if r['is_gap']]
        assert len(gaps) >= 3, f"Expected >=3 gap instances, got {len(gaps)}"

    def test_bias_sweep_has_gap_window(self):
        from live_casi.backdoor_analysis import sweep_bias_threshold
        results = sweep_bias_threshold(n_keys=10000, seed=42,
                                        bias_values=[0.10, 0.30, 0.50, 0.70])
        gaps = [r for r in results if r['is_gap']]
        assert len(gaps) >= 1, "Sweep should find at least 1 gap"


# ═══════════════════════════════════════════════════════════════
# 12. CVE Detection Tests
# ═══════════════════════════════════════════════════════════════

class TestCVEDetection:
    """CVE simulators must produce expected CASI results."""

    def test_cve_imports(self):
        from live_casi.cve_analysis import run_cve_suite, run_prng_suite

    def test_debian_openssl_detected(self):
        from live_casi.cve_analysis import cve_debian_openssl, _analyze
        keys = cve_debian_openssl(n_keys=10000, seed=42)
        result = _analyze(keys, "test")
        assert result['casi_full'] > 100, f"Debian OpenSSL CASI={result['casi_full']}, expected >> 2.0"
        assert result['nist_all_pass'], "NIST should pass (each key looks random)"
        assert result['is_gap'], "Debian OpenSSL should be a GAP instance"

    def test_ecb_detected(self):
        from live_casi.cve_analysis import cve_ecb_structured, _analyze
        keys = cve_ecb_structured(n_keys=10000, seed=42)
        result = _analyze(keys, "test")
        assert result['casi_detects'], f"ECB not detected, CASI={result['casi_full']}"

    def test_predictable_iv_detected(self):
        from live_casi.cve_analysis import cve_predictable_iv, _analyze
        keys = cve_predictable_iv(n_keys=10000, seed=42)
        result = _analyze(keys, "test")
        assert result['casi_detects'], f"Predictable IV not detected, CASI={result['casi_full']}"

    def test_urandom_secure(self):
        from live_casi.cve_analysis import prng_urandom, _analyze
        keys = prng_urandom(n_keys=10000)
        result = _analyze(keys, "test")
        assert result['casi_full'] < 2.0, f"os.urandom CASI={result['casi_full']}, should be < 2.0"

    def test_lcg_detected(self):
        from live_casi.cve_analysis import prng_lcg, _analyze
        keys = prng_lcg(n_keys=10000, seed=42)
        result = _analyze(keys, "test")
        assert result['casi_full'] > 2.0, f"LCG CASI={result['casi_full']}, should be > 2.0"

    def test_lfsr_detected(self):
        from live_casi.cve_analysis import prng_lfsr16, _analyze
        keys = prng_lfsr16(n_keys=10000, seed=42)
        result = _analyze(keys, "test")
        assert result['casi_full'] > 5.0, f"LFSR CASI={result['casi_full']}, should be > 5.0"


# ═══════════════════════════════════════════════════════════════
# 13. Gap Analysis Tests
# ═══════════════════════════════════════════════════════════════

class TestGapAnalysis:
    """Gap analysis module must work correctly."""

    def test_gap_imports(self):
        from live_casi.gap_analysis import sweep_gap, sweep_cipher

    def test_sweep_single_cipher(self):
        from live_casi.gap_analysis import sweep_cipher
        results = sweep_cipher('chacha', n_keys=5000, seed=42)
        assert len(results) == 20  # ChaCha has 20 rounds
        assert results[0]['round'] == 1
        assert results[-1]['round'] == 20
        assert results[0]['casi_crypto'] > 10.0  # R1 should be broken


# ═══════════════════════════════════════════════════════════════
# 14. Deep Strategy Tests (v0.6.0)
# ═══════════════════════════════════════════════════════════════

class TestDeepStrategies:
    """Tests for the 4 new deep cryptanalytic strategies."""

    def test_avalanche_fires_on_broken(self):
        """Avalanche should detect R1 ciphers (massive per-bit bias)."""
        keys = _generate_keys('chacha', rounds=1, n_keys=10000)
        count = strategy_avalanche(keys)
        assert count > 10, f"avalanche should fire on ChaCha R1, got {count}"

    def test_avalanche_clean_on_random(self):
        """Avalanche should be near-zero on random data."""
        keys = np.frombuffer(os.urandom(10000 * 32), dtype=np.uint8).reshape(10000, 32)
        count = strategy_avalanche(keys)
        assert count < 5, f"avalanche on random: {count}, expected < 5"

    def test_avalanche_multi_stride(self):
        """Avalanche tests multiple strides to catch different block packings."""
        keys = _generate_keys('speck', rounds=1, n_keys=10000)
        count = strategy_avalanche(keys)
        assert count > 0, f"avalanche should detect Speck R1 via multi-stride"

    def test_linear_bias_fires_on_broken(self):
        """Linear bias should detect residual linear trails at low rounds."""
        keys = _generate_keys('aes', rounds=1, n_keys=10000)
        count = strategy_linear_bias(keys)
        assert count > 0, f"linear_bias should fire on AES R1, got {count}"

    def test_linear_bias_clean_on_random(self):
        keys = np.frombuffer(os.urandom(10000 * 32), dtype=np.uint8).reshape(10000, 32)
        count = strategy_linear_bias(keys)
        assert count < 5, f"linear_bias on random: {count}, expected < 5"

    def test_higher_order_fires_on_broken(self):
        """Higher-order should detect 3-way bit correlations at low rounds."""
        keys = _generate_keys('speck', rounds=1, n_keys=10000)
        count = strategy_higher_order(keys)
        assert count > 0, f"higher_order should fire on Speck R1, got {count}"

    def test_higher_order_clean_on_random(self):
        keys = np.frombuffer(os.urandom(10000 * 32), dtype=np.uint8).reshape(10000, 32)
        count = strategy_higher_order(keys)
        assert count < 5, f"higher_order on random: {count}, expected < 5"

    def test_differential_fires_on_broken(self):
        """Differential should detect non-uniform XOR distributions at low rounds."""
        keys = _generate_keys('blowfish', rounds=1, n_keys=10000)
        count = strategy_differential(keys)
        assert count > 10, f"differential should fire on Blowfish R1, got {count}"

    def test_differential_clean_on_random(self):
        keys = np.frombuffer(os.urandom(10000 * 32), dtype=np.uint8).reshape(10000, 32)
        count = strategy_differential(keys)
        assert count < 5, f"differential on random: {count}, expected < 5"

    def test_differential_multi_stride(self):
        """Differential tests multiple strides like avalanche."""
        keys = _generate_keys('chacha', rounds=1, n_keys=10000)
        count = strategy_differential(keys)
        assert count > 0, f"differential should detect ChaCha R1"

    def test_deep_strategy_names(self):
        """DEEP_STRATEGY_NAMES should contain exactly the 4 new strategies."""
        assert set(DEEP_STRATEGY_NAMES) == {'avalanche', 'linear_bias', 'higher_order', 'differential', 'integral', 'truncated_diff', 'rotational', 'algebraic_degree', 'diff_linear', 'boomerang', 'impossible_diff', 'zero_correlation', 'division_property', 'slide'}

    def test_all_deep_in_crypto(self):
        """All deep strategies should also be in CRYPTO_STRATEGY_NAMES."""
        for name in DEEP_STRATEGY_NAMES:
            assert name in CRYPTO_STRATEGY_NAMES, f"{name} missing from CRYPTO_STRATEGY_NAMES"

    def test_integral_fires_on_broken(self):
        """Integral strategy should fire strongly on R1 ciphers."""
        from live_casi.core import strategy_integral
        keys = _generate_keys('chacha', rounds=1, n_keys=10000)
        count = strategy_integral(keys)
        assert count > 1000, f"integral should detect ChaCha R1, got {count}"

    def test_integral_clean_on_random(self):
        """Integral strategy should have near-zero signal on random data."""
        from live_casi.core import strategy_integral
        keys = np.frombuffer(os.urandom(10000 * 32), dtype=np.uint8).reshape(10000, 32)
        count = strategy_integral(keys)
        assert count < 20, f"integral FP={count}, expected < 20"

    def test_integral_xor_sum_balance(self):
        """R1 should break XOR-sum balance property massively."""
        from live_casi.core import strategy_integral
        # AES R1 has extreme balance violations
        keys = _generate_keys('aes', rounds=1, n_keys=10000)
        count = strategy_integral(keys)
        assert count > 5000, f"AES R1 integral should be huge, got {count}"

    def test_integral_full_rounds_clean(self):
        """Full-round ciphers should have minimal integral signal."""
        from live_casi.core import strategy_integral
        for cname, full_rounds in [('chacha', 20), ('aes', 10), ('speck', 22)]:
            keys = _generate_keys(cname, rounds=full_rounds, n_keys=10000)
            count = strategy_integral(keys)
            assert count < 20, f"{cname} R{full_rounds} integral={count}, expected < 20"

    def test_truncated_diff_fires_on_broken(self):
        """Truncated diff should fire strongly on R1 ciphers."""
        from live_casi.core import strategy_truncated_diff
        keys = _generate_keys('aes', rounds=1, n_keys=10000)
        count = strategy_truncated_diff(keys)
        assert count > 10000, f"truncated_diff should detect AES R1, got {count}"

    def test_truncated_diff_clean_on_random(self):
        """Truncated diff should have near-zero signal on random data."""
        from live_casi.core import strategy_truncated_diff
        keys = np.frombuffer(os.urandom(10000 * 32), dtype=np.uint8).reshape(10000, 32)
        count = strategy_truncated_diff(keys)
        assert count < 20, f"truncated_diff FP={count}, expected < 20"

    def test_truncated_diff_full_rounds_clean(self):
        """Full-round ciphers should have minimal truncated_diff signal."""
        from live_casi.core import strategy_truncated_diff
        for cname, full_rounds in [('chacha', 20), ('aes', 10), ('speck', 22)]:
            keys = _generate_keys(cname, rounds=full_rounds, n_keys=10000)
            count = strategy_truncated_diff(keys)
            assert count < 20, f"{cname} R{full_rounds} truncated_diff={count}, expected < 20"

    def test_rotational_fires_on_broken(self):
        """Rotational strategy should detect R1 ARX ciphers strongly."""
        from live_casi.core import strategy_rotational
        keys = _generate_keys('chacha', rounds=1, n_keys=10000)
        count = strategy_rotational(keys)
        assert count > 100, f"rotational should detect ChaCha R1, got {count}"

    def test_rotational_clean_on_random(self):
        """Rotational strategy should have near-zero signal on random data."""
        from live_casi.core import strategy_rotational
        keys = np.frombuffer(os.urandom(10000 * 32), dtype=np.uint8).reshape(10000, 32)
        count = strategy_rotational(keys)
        assert count < 20, f"rotational FP={count}, expected < 20"

    def test_rotational_full_rounds_clean(self):
        """Full-round ciphers should have minimal rotational signal."""
        from live_casi.core import strategy_rotational
        for cname, full_rounds in [('chacha', 20), ('speck', 22), ('salsa', 20)]:
            keys = _generate_keys(cname, rounds=full_rounds, n_keys=10000)
            count = strategy_rotational(keys)
            assert count < 20, f"{cname} R{full_rounds} rotational={count}, expected < 20"

    def test_algebraic_degree_fires_on_broken(self):
        """Algebraic degree test should fire strongly on R1 ciphers."""
        from live_casi.core import strategy_algebraic_degree
        keys = _generate_keys('aes', rounds=1, n_keys=10000)
        count = strategy_algebraic_degree(keys)
        assert count > 1000, f"algebraic_degree should detect AES R1, got {count}"

    def test_algebraic_degree_clean_on_random(self):
        """Algebraic degree should have near-zero signal on random data."""
        from live_casi.core import strategy_algebraic_degree
        keys = np.frombuffer(os.urandom(10000 * 32), dtype=np.uint8).reshape(10000, 32)
        count = strategy_algebraic_degree(keys)
        assert count < 20, f"algebraic_degree FP={count}, expected < 20"

    def test_algebraic_degree_full_rounds_clean(self):
        """Full-round ciphers should have minimal algebraic_degree signal."""
        from live_casi.core import strategy_algebraic_degree
        for cname, full_rounds in [('chacha', 20), ('aes', 10), ('speck', 22)]:
            keys = _generate_keys(cname, rounds=full_rounds, n_keys=10000)
            count = strategy_algebraic_degree(keys)
            assert count < 20, f"{cname} R{full_rounds} algebraic_degree={count}, expected < 20"

    def test_diff_linear_fires_on_broken(self):
        """Diff-linear hybrid should fire on R1 ciphers."""
        from live_casi.core import strategy_diff_linear
        keys = _generate_keys('chacha', rounds=1, n_keys=10000)
        count = strategy_diff_linear(keys)
        assert count > 100, f"diff_linear should detect ChaCha R1, got {count}"

    def test_diff_linear_clean_on_random(self):
        """Diff-linear should have near-zero signal on random data."""
        from live_casi.core import strategy_diff_linear
        keys = np.frombuffer(os.urandom(10000 * 32), dtype=np.uint8).reshape(10000, 32)
        count = strategy_diff_linear(keys)
        assert count < 20, f"diff_linear FP={count}, expected < 20"

    def test_diff_linear_full_rounds_clean(self):
        """Full-round ciphers should have minimal diff_linear signal."""
        from live_casi.core import strategy_diff_linear
        for cname, full_rounds in [('chacha', 20), ('aes', 10), ('speck', 22)]:
            keys = _generate_keys(cname, rounds=full_rounds, n_keys=10000)
            count = strategy_diff_linear(keys)
            assert count < 20, f"{cname} R{full_rounds} diff_linear={count}, expected < 20"

    def test_boomerang_fires_on_broken(self):
        """Boomerang should fire on R1 ciphers."""
        from live_casi.core import strategy_boomerang
        keys = _generate_keys('aes', rounds=1, n_keys=10000)
        count = strategy_boomerang(keys)
        assert count > 1000, f"boomerang should detect AES R1, got {count}"

    def test_boomerang_clean_on_random(self):
        """Boomerang should have near-zero signal on random data."""
        from live_casi.core import strategy_boomerang
        keys = np.frombuffer(os.urandom(10000 * 32), dtype=np.uint8).reshape(10000, 32)
        count = strategy_boomerang(keys)
        assert count < 20, f"boomerang FP={count}, expected < 20"

    def test_boomerang_full_rounds_clean(self):
        """Full-round ciphers should have minimal boomerang signal."""
        from live_casi.core import strategy_boomerang
        for cname, full_rounds in [('chacha', 20), ('aes', 10), ('speck', 22)]:
            keys = _generate_keys(cname, rounds=full_rounds, n_keys=10000)
            count = strategy_boomerang(keys)
            assert count < 20, f"{cname} R{full_rounds} boomerang={count}, expected < 20"

    def test_impossible_diff_fires_on_broken(self):
        """Impossible differential should detect R1 ciphers (massive signal)."""
        from live_casi.core import strategy_impossible_diff
        keys = _generate_keys('aes', rounds=1, n_keys=10000)
        count = strategy_impossible_diff(keys)
        assert count > 100000, f"impossible_diff should detect AES R1, got {count}"

    def test_impossible_diff_clean_on_random(self):
        """Impossible differential should have ZERO signal on random data."""
        from live_casi.core import strategy_impossible_diff
        keys = np.frombuffer(os.urandom(10000 * 32), dtype=np.uint8).reshape(10000, 32)
        count = strategy_impossible_diff(keys)
        assert count == 0, f"impossible_diff FP={count}, expected 0"

    def test_impossible_diff_full_rounds_clean(self):
        """Full-round ciphers should have zero impossible differential signal."""
        from live_casi.core import strategy_impossible_diff
        for cname, full_rounds in [('chacha', 20), ('aes', 10), ('speck', 22), ('blowfish', 16)]:
            keys = _generate_keys(cname, rounds=full_rounds, n_keys=10000)
            count = strategy_impossible_diff(keys)
            assert count == 0, f"{cname} R{full_rounds} impossible_diff={count}, expected 0"

    def test_zero_correlation_fires_on_broken(self):
        """Zero-correlation linear should detect R1 ciphers."""
        from live_casi.core import strategy_zero_correlation
        keys = _generate_keys('aes', rounds=1, n_keys=10000)
        count = strategy_zero_correlation(keys)
        assert count > 5000, f"zero_correlation should detect AES R1, got {count}"

    def test_zero_correlation_clean_on_random(self):
        """Zero-correlation should have minimal signal on random data."""
        from live_casi.core import strategy_zero_correlation
        keys = np.frombuffer(os.urandom(10000 * 32), dtype=np.uint8).reshape(10000, 32)
        count = strategy_zero_correlation(keys)
        assert count < 20, f"zero_correlation FP={count}, expected < 20"

    def test_zero_correlation_full_rounds_clean(self):
        """Full-round ciphers should have minimal zero-correlation signal."""
        from live_casi.core import strategy_zero_correlation
        for cname, full_rounds in [('chacha', 20), ('aes', 10), ('speck', 22), ('blowfish', 16)]:
            keys = _generate_keys(cname, rounds=full_rounds, n_keys=10000)
            count = strategy_zero_correlation(keys)
            assert count < 10, f"{cname} R{full_rounds} zero_correlation={count}, expected < 10"

    def test_division_property_fires_on_broken(self):
        """Division property should detect R1 ciphers."""
        from live_casi.core import strategy_division_property
        keys = _generate_keys('aes', rounds=1, n_keys=10000)
        count = strategy_division_property(keys)
        assert count > 500, f"division_property should detect AES R1, got {count}"

    def test_division_property_clean_on_random(self):
        """Division property should have zero signal on random data."""
        from live_casi.core import strategy_division_property
        keys = np.frombuffer(os.urandom(10000 * 32), dtype=np.uint8).reshape(10000, 32)
        count = strategy_division_property(keys)
        assert count == 0, f"division_property FP={count}, expected 0"

    def test_division_property_full_rounds_clean(self):
        """Full-round ciphers should have zero division property signal."""
        from live_casi.core import strategy_division_property
        for cname, full_rounds in [('chacha', 20), ('aes', 10), ('speck', 22), ('blowfish', 16)]:
            keys = _generate_keys(cname, rounds=full_rounds, n_keys=10000)
            count = strategy_division_property(keys)
            assert count == 0, f"{cname} R{full_rounds} division_property={count}, expected 0"

    def test_slide_fires_on_broken(self):
        """Slide should detect R1 ciphers (massive signal)."""
        from live_casi.core import strategy_slide
        keys = _generate_keys('aes', rounds=1, n_keys=10000)
        count = strategy_slide(keys)
        assert count > 100000, f"slide should detect AES R1, got {count}"

    def test_slide_clean_on_random(self):
        """Slide should have minimal signal on random data."""
        from live_casi.core import strategy_slide
        keys = np.frombuffer(os.urandom(10000 * 32), dtype=np.uint8).reshape(10000, 32)
        count = strategy_slide(keys)
        assert count < 10, f"slide FP={count}, expected < 10"

    def test_slide_full_rounds_clean(self):
        """Full-round ciphers should have minimal slide signal."""
        from live_casi.core import strategy_slide
        for cname, full_rounds in [('chacha', 20), ('aes', 10), ('speck', 22), ('blowfish', 16)]:
            keys = _generate_keys(cname, rounds=full_rounds, n_keys=10000)
            count = strategy_slide(keys)
            assert count < 10, f"{cname} R{full_rounds} slide={count}, expected < 10"


# ═══════════════════════════════════════════════════════════════
# 15. compute_deep_signal and compute_casi_score Tests (v0.6.0)
# ═══════════════════════════════════════════════════════════════

class TestDeepScoring:
    """Tests for the deep scoring system that pushes frontiers +1 round."""

    def test_compute_deep_signal_structure(self):
        """compute_deep_signal should return dict with all 4 strategies + total."""
        keys = np.frombuffer(os.urandom(10000 * 32), dtype=np.uint8).reshape(10000, 32)
        result = compute_deep_signal(keys)
        for name in DEEP_STRATEGY_NAMES:
            assert name in result, f"Missing key: {name}"
        assert 'total' in result
        assert result['total'] == sum(result[n] for n in DEEP_STRATEGY_NAMES)

    def test_compute_deep_signal_low_on_random(self):
        """Deep signal on random data should be very low."""
        keys = np.frombuffer(os.urandom(10000 * 32), dtype=np.uint8).reshape(10000, 32)
        result = compute_deep_signal(keys)
        assert result['total'] < 30, f"Deep signal on random: {result['total']}, expected < 30"

    def test_compute_deep_signal_high_on_broken(self):
        """Deep signal on R1 cipher should be significant."""
        keys = _generate_keys('chacha', rounds=1, n_keys=10000)
        result = compute_deep_signal(keys)
        assert result['total'] > 50, f"Deep signal on ChaCha R1: {result['total']}, expected > 50"

    def test_compute_casi_score_structure(self):
        """compute_casi_score should return dict with all expected keys."""
        keys = np.frombuffer(os.urandom(10000 * 32), dtype=np.uint8).reshape(10000, 32)
        result = compute_casi_score(keys)
        expected_keys = {'casi', 'casi_classic', 'casi_deep', 'signal_classic',
                         'signal_deep', 'baseline_classic', 'baseline_deep', 'deep_strategies'}
        for k in expected_keys:
            assert k in result, f"Missing key: {k}"

    def test_compute_casi_score_random_secure(self):
        """Random data should have CASI < 1.5 from compute_casi_score."""
        keys = np.frombuffer(os.urandom(10000 * 32), dtype=np.uint8).reshape(10000, 32)
        result = compute_casi_score(keys)
        assert result['casi'] < 1.5, f"Random CASI={result['casi']:.2f}, expected < 1.5"

    def test_compute_casi_score_broken_detected(self):
        """R1 cipher should have CASI >> 2.0."""
        keys = _generate_keys('speck', rounds=1, n_keys=10000)
        result = compute_casi_score(keys)
        assert result['casi'] > 5.0, f"Speck R1 CASI={result['casi']:.2f}, expected > 5.0"

    def test_casi_score_is_max_of_classic_and_deep(self):
        """CASI should be max(classic, deep)."""
        keys = _generate_keys('chacha', rounds=1, n_keys=10000)
        result = compute_casi_score(keys)
        assert result['casi'] == max(result['casi_classic'], result['casi_deep'])

    def test_deep_scoring_detects_frontier_round(self):
        """Deep scoring should detect at frontier round where classic ratio might miss.

        This is THE key test: at frontier round, deep strategies provide signal
        while classic strategies (drowned by xor_distribution noise) show ratio ~1.0.
        """
        # AES R3 is reliably detected via deep scoring at 10K keys
        keys = _generate_keys('aes', rounds=3, n_keys=10000)
        result = compute_casi_score(keys)
        assert result['casi_deep'] > 1.5, \
            f"AES R3 deep score={result['casi_deep']:.2f}, expected > 1.5"

    def test_deep_baseline_floor(self):
        """DEEP_BASELINE_FLOOR prevents division by near-zero baseline."""
        assert DEEP_BASELINE_FLOOR == 14
        # Verify it's used: random baseline deep signal should be small
        keys = np.frombuffer(os.urandom(10000 * 32), dtype=np.uint8).reshape(10000, 32)
        deep = compute_deep_signal(keys)
        # With 14 deep strategies, occasional FP noise can reach ~30.
        # Floor ensures CASI ratio stays bounded: 30/14 = 2.14 < 2.5 threshold.
        assert deep['total'] < DEEP_BASELINE_FLOOR * 3, \
            f"Random deep signal {deep['total']} too high for floor {DEEP_BASELINE_FLOOR}"

    def test_full_rounds_secure_with_deep_scoring(self):
        """Full-round ciphers must be SECURE even with deep scoring."""
        for cipher_key, full_rounds in [('chacha', 20), ('salsa', 20), ('aes', 10),
                                         ('speck', 22), ('blowfish', 16)]:
            keys = _generate_keys(cipher_key, rounds=full_rounds, n_keys=10000)
            result = compute_casi_score(keys)
            assert result['casi'] < 2.0, \
                f"{cipher_key} R{full_rounds} CASI={result['casi']:.2f}, expected < 2.0"


# ═══════════════════════════════════════════════════════════════
# 16. Frontier Validation (v0.6.0)
# ═══════════════════════════════════════════════════════════════

class TestFrontierValues:
    """Verify that ciphers.py frontier values match actual detection."""

    @pytest.mark.parametrize("cipher_key,expected_frontier", [
        ('chacha', 3),
        ('aes', 3),
        ('speck', 7),
        ('blowfish', 3),
        ('camellia', 6),
    ])
    def test_frontier_matches_registry(self, cipher_key, expected_frontier):
        """Registered frontier should match the value in CIPHERS dict."""
        assert CIPHERS[cipher_key]['frontier'] == expected_frontier

    def test_salsa_frontier(self):
        """Salsa20 frontier should be 4 (v0.6.1: causal amplification)."""
        assert CIPHERS['salsa']['frontier'] == 4


class TestAmplifiedScore:
    """Tests for PCR-style causal amplification (compute_amplified_score)."""

    def test_amplified_score_structure(self):
        """Result dict should contain all expected keys."""
        rng = np.random.RandomState(42)
        keys = np.frombuffer(rng.bytes(1000 * 32), dtype=np.uint8).reshape(1000, 32)
        result = compute_amplified_score(keys)
        assert 'casi' in result
        assert 'casi_standard' in result
        assert 'casi_amplified' in result
        assert 'amplified_z' in result
        assert 'n_tests' in result
        assert 'pass_counts' in result
        assert len(result['pass_counts']) == 3

    def test_amplified_random_is_low(self):
        """Random data should produce low amplified z-score."""
        rng = np.random.RandomState(42)
        keys = np.frombuffer(rng.bytes(5000 * 32), dtype=np.uint8).reshape(5000, 32)
        result = compute_amplified_score(keys)
        assert result['amplified_z'] < 5.0, \
            f"Random data amplified_z={result['amplified_z']:.2f} should be < 5.0"

    def test_amplified_detects_broken(self):
        """R1 cipher should produce very high amplified z-score."""
        raw = CIPHERS['chacha']['generator'](5000, rounds=1, seed=42)
        keys = np.frombuffer(raw, dtype=np.uint8).reshape(5000, 32)
        result = compute_amplified_score(keys)
        assert result['amplified_z'] > 10.0, \
            f"ChaCha R1 amplified_z={result['amplified_z']:.2f} should be > 10.0"

    def test_amplified_casi_is_max(self):
        """CASI should be max of standard and amplified."""
        raw = CIPHERS['chacha']['generator'](5000, rounds=1, seed=42)
        keys = np.frombuffer(raw, dtype=np.uint8).reshape(5000, 32)
        result = compute_amplified_score(keys)
        assert result['casi'] == max(result['casi_standard'], result['casi_amplified'])
