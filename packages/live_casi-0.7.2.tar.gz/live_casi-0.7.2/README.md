# live-casi

**Real-time Causal Amplification Security Index Monitor**

Black-box encryption validator: feed any byte stream, get a single number that tells you if it's *actually* encrypted. Detects reduced-round cryptographic weaknesses, implementation failures (ECB mode, nonce reuse, fake encryption), and architectural fingerprints across 8 cipher families using 12 statistical strategies.

**v0.2.0** adds blind cipher identification, firmware/binary scanning, and frontier benchmarking against academic SOTA.

**Author:** David Tom Foss ([ORCID: 0009-0004-0289-7154](https://orcid.org/0009-0004-0289-7154))

## What is CASI?

CASI (Causal Amplification Security Index) measures the ratio of detectable statistical signals in cipher output compared to true random data:

```
CASI = S_signal(cipher) / S_signal(random)
```

- **CASI ~ 1.0** → Output is indistinguishable from random → **SECURE**
- **CASI > 2.0** → Detectable structural patterns → **WEAK**
- **CASI > 10.0** → Strong statistical bias → **BROKEN**

Based on the .causal cryptanalysis framework:

> Foss, D. T. (2026). ".causal Cryptanalysis: Black-Box Security Margins and Blind Cipher Identification." [doi:10.5281/zenodo.18591406](https://doi.org/10.5281/zenodo.18591406)

## Install

```bash
pip install live-casi
```

**Requirements:** Python 3.8+, NumPy

## Quick Start

```bash
# Self-test: 26 cipher scenarios across 8 families
live-casi --test

# Attack detection: 10 synthetic implementation failures
live-casi --test-attacks

# Visual demo
live-casi --demo --cipher aes

# Analyze any byte stream
openssl rand 320000 | live-casi

# CI/CD: exit 0 if CASI < 2.0, exit 1 otherwise
./encrypt | live-casi --quiet --exit-code 2.0

# Known-plaintext analysis (XOR to extract keystream)
live-casi --known-pt plaintext.bin < ciphertext.bin

# Compare two streams (regression testing)
live-casi --compare old_output.bin new_output.bin
```

### v0.2.0 Features

```bash
# Blind cipher identification: what cipher generated this data?
live-casi --identify encrypted.bin

# Firmware/binary scanner: find encrypted regions in any binary
live-casi --scan firmware.bin

# Frontier benchmark: compare live-casi detection limits vs academic SOTA
live-casi --benchmark

# Benchmark a specific cipher
live-casi --benchmark --cipher speck
```

### v0.3.0 Network Analysis

```bash
# Install with network support
pip install live-casi[network]

# Analyze a pcap file — CASI score per connection
live-casi --pcap capture.pcap

# Only show problematic connections (weak/plaintext)
live-casi --pcap capture.pcap --problems-only

# Live network monitor (requires sudo)
sudo live-casi --monitor --interface en1

# Monitor for 60 seconds
sudo live-casi --monitor --duration 60

# JSON output for dashboards
live-casi --pcap capture.pcap --json
```

Detects per connection: TLS version, cipher suite, SNI, protocol (TLS/HTTP/DNS/raw).
Flags: PLAINTEXT (unencrypted), WEAK (poor crypto), SECURE (properly encrypted).

## Supported Ciphers

| Cipher | Family | Full Rounds | CASI Frontier | R1 CASI |
|--------|--------|-------------|---------------|---------|
| ChaCha20 | ARX-stream | 20 | R3 (SECURE) | 6,428 |
| Salsa20 | ARX-stream | 20 | R3 (WEAK @ 8) | 12,308 |
| AES-128 | SPN-block | 10 | R3 (SECURE) | 18,647 |
| Speck 32/64 | ARX-Feistel | 22 | R5 (SECURE) | 50 |
| Blowfish | Feistel-keydep | 16 | R4 (SECURE) | 90 |
| 3DES EDE | Feistel-fixed | 16 | R4 (SECURE) | 47 |
| RC4 | byte-stream | 256 KSA | KSA-64 (SECURE) | 93 |
| Camellia-128 | SPN-Feistel | 18 | R4 (WEAK @ 9) | 1,324 |

**Key findings:**
- Salsa20 R3 = WEAK (CASI 8) while ChaCha20 R3 = SECURE (CASI 0.9) — detects the known architectural superiority of diagonal quarter-rounds
- Speck 32/64 Crypto-CASI frontier at R4 with 10K keys (the [.causal paper](https://doi.org/10.5281/zenodo.18591406) reaches R7 with 100K keys and graph topology)
- RC4 with reduced KSA (< 64 iterations) is immediately detected as BROKEN
- All Crypto-CASI frontiers are weaker than or match academic SOTA — honest, expected for black-box statistical tests vs targeted attacks

## 12 Signal Strategies

**Reduced-round detection** (cryptographic weakness):

| # | Strategy | Catches |
|---|----------|---------|
| 1 | `bit_correlation` | Incomplete ARX mixing, bit-level dependencies |
| 2 | `xor_distribution` | Non-uniform XOR distributions from weak diffusion |
| 3 | `parity_chain` | Linear parity propagation through Feistel/ARX |
| 4 | `cross_bit` | Bit-level dependency cascades from rotation/addition |

**Implementation failure detection** (real-world bugs):

| # | Strategy | Catches |
|---|----------|---------|
| 5 | `block_repetition` | ECB mode, nonce reuse, counter wrap-around |
| 6 | `byte_frequency` | Plaintext-as-ciphertext, Base64, XOR with short keys |
| 7 | `seq_correlation` | Counter bugs, bad PRNG seeding, LCG patterns |

**Statistical depth** (universal detection):

| # | Strategy | Catches |
|---|----------|---------|
| 8 | `entropy` | Low-entropy PRNGs, truncated output, encoding artifacts |
| 9 | `runs` | LFSR output, biased bit runs, shift register patterns |
| 10 | `spectral` | Periodic structure from timer seeding, counter leaks |
| 11 | `compression` | Any structured data (universal safety net) |
| 12 | `autocorrelation` | Short-period generators, cycling counters |

## Attack Detection

```bash
live-casi --test-attacks
```

| Attack | CASI | Primary Strategy |
|--------|------|-----------------|
| ECB mode (structured PT) | 20,306 | block_repetition |
| Base64 encoding | 38 | byte_frequency |
| XOR with 4-byte key | 34 | byte_frequency |
| Counter reuse | 20,116 | seq_correlation |
| LCG PRNG output | 17,966 | seq_correlation |
| Low-entropy PRNG | 38 | entropy |
| Biased bit runs | 290 | runs |
| Timer-seeded periodic | 18,325 | spectral |
| Structured data (JSON) | 21,335 | compression |
| Short-period cycling | 19,725 | autocorrelation |
| os.urandom (baseline) | **1.0** | — (clean) |

## Unique Features

**Known-Plaintext Mode** — No other CLI tool offers this:
```bash
# XOR plaintext with ciphertext → analyze keystream directly
live-casi --known-pt plaintext.bin --file ciphertext.bin
```

**Differential Mode** — Compare before/after:
```bash
# Regression testing: did the crypto library update break anything?
live-casi --compare old_firmware.bin new_firmware.bin
```

## CI/CD Integration

```bash
# Exit code: 0 = pass, 1 = fail
./encrypt | live-casi --quiet --exit-code 2.0

# JSON output for dashboards
./encrypt | live-casi --json

# Just the number
CASI=$(./encrypt | live-casi --quiet)

# Combined
./encrypt | live-casi --json --exit-code 2.0
```

Example JSON output:
```json
{
  "casi": 1.06,
  "verdict": "SECURE",
  "keys_analyzed": 10000,
  "signal_total": 312,
  "strategies": {
    "bit_correlation": 0,
    "xor_distribution": 79,
    "parity_chain": 0,
    "cross_bit": 0,
    "block_repetition": 0,
    "byte_frequency": 73,
    "seq_correlation": 5,
    "entropy": 0,
    "runs": 5,
    "spectral": 150,
    "compression": 0,
    "autocorrelation": 0
  },
  "elapsed_seconds": 1.02
}
```

## Library API

```python
from live_casi import LiveCASIWithStorage, compute_signal, STRATEGY_NAMES
import os

# Create engine
engine = LiveCASIWithStorage(key_size=32, window_keys=10000, update_every=1000)

# Feed data
engine.feed(os.urandom(320000))
engine.force_update()

# Read results
print(f"CASI: {engine.current_casi:.2f}")  # ~1.0 for random
print(f"Verdict: secure" if engine.current_casi < 2.0 else "WEAK")

# Direct signal computation on numpy array
import numpy as np
keys = np.frombuffer(os.urandom(10000 * 32), dtype=np.uint8).reshape(-1, 32)
signals = compute_signal(keys)
print(f"Total signal: {signals['total']}")
```

## Architecture

```
live_casi/
├── __init__.py     — Public API, version
├── core.py         — Engine, 12 strategies, TUI, CLI
├── ciphers.py      — 8 cipher implementations + registry
├── identify.py     — Blind cipher identification (cosine similarity, 12D signal space)
├── scanner.py      — Firmware/binary scanner (sliding-window CASI)
├── benchmark.py    — Frontier benchmark vs academic SOTA
└── __main__.py     — python -m live_casi support
```

- **Sliding window:** Analyzes the most recent N keys (default 10,000)
- **Periodic recomputation:** Updates CASI every M new keys (default 500)
- **z-score threshold:** 3.5 (≈ 0.02% false positive per test)
- **Baseline calibration:** Computes random baseline at startup for normalization

## Performance

| Cipher | 10K keys | Rate |
|--------|----------|------|
| ChaCha20 R20 | 0.4s | 25K keys/s |
| Salsa20 R20 | 0.1s | 100K keys/s |
| AES-128 R10 | 0.1s | 100K keys/s |
| Speck 32/64 R22 | 0.1s | 100K keys/s |
| Blowfish R16 | 0.2s | 50K keys/s |
| 3DES EDE R16 | 1.4s | 700 keys/s |
| RC4 (full KSA) | 0.1s | 10K keys/s |
| Camellia-128 R18 | 0.1s | 10K keys/s |

## Crypto-CASI vs Implementation-CASI

live-casi distinguishes between two measurement modes:

**Crypto-CASI** (4 strategies: bit_correlation, xor_distribution, parity_chain, cross_bit)
- Detects structural cryptographic weaknesses
- Comparable to academic cryptanalysis results (Gohr, Aumasson, etc.)
- Use `compute_crypto_signal()` or `--benchmark` to see these frontiers

**Implementation-CASI** (all 12 strategies)
- Includes implementation-bug detectors (block_repetition, byte_frequency, etc.)
- These fire trivially at low rounds — NOT comparable to academic attack frontiers
- Use `compute_signal()` or standard CASI analysis for full detection

The `--benchmark` mode shows both frontiers side by side. Only Crypto-CASI should be compared to published academic results.

## Related

- Paper: [doi:10.5281/zenodo.18591406](https://doi.org/10.5281/zenodo.18591406)
- .causal format: [pypi.org/project/dotcausal/](https://pypi.org/project/dotcausal/)
- GitHub: [github.com/DT-Foss/dotcausal](https://github.com/DT-Foss/dotcausal)

## License

MIT
