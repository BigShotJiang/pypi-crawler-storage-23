"""
允许 python -m webthief 方式运行
"""

from .cli import main

if __name__ == "__main__":
    main()
