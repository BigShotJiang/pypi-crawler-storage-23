"""claude-priors: Persistent agent memory for AI coding assistants."""
__version__ = "0.1.0"
