# API Reference

::: peapods.Ising
