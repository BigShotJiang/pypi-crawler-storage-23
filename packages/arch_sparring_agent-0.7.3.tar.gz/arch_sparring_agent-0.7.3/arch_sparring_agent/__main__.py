"""Allow running the package with ``python -m arch_sparring_agent``."""

from .cli import cli

cli()
