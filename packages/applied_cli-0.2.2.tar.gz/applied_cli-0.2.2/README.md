# Applied Labs CLI

CLI and Claude Code plugin for managing Applied Labs AI support agents.

## Installation

### As a Claude Code Plugin

```bash
# From a marketplace (once published)
/plugin install applied-labs@marketplace-name

# Or test locally
claude --plugin-dir /path/to/applied-cli
```

### As a standalone CLI

```bash
pip install applied-cli

# Or with MCP server support
pip install "applied-cli[mcp]"
```

## Authentication

```bash
applied-cli auth login          # Opens browser for approval
applied-cli auth status         # Check current shop
applied-cli auth shops          # List available shops
applied-cli auth use-shop NAME  # Switch shops
```

## Quick Start

### 1. Set up a new shop

```bash
# Generate spec template
applied-cli shop template > my-shop.yaml

# Edit the spec with your configuration...

# Run setup
applied-cli shop setup --spec my-shop.yaml --json
```

### 2. Test your agent

```bash
applied-cli chat --agent-id <uuid> --message "Hello"
```

### 3. Fix failing scenarios

```bash
# Get context for failures
applied-cli test fix context --benchmark-id <uuid> --json

# Update knowledge base
applied-cli knowledge upsert --agent-id <uuid> --type qa \
  --question "What is your return policy?" \
  --answer "30 day returns on all items."

# Batch test fixes
applied-cli test fix batch --source <failing-benchmark> --target <validation-benchmark>

# Check progress
applied-cli test fix status --source <source> --target <target>
```

## Command Reference

```
applied-cli
├── auth            # Login, logout, switch shops
├── shop            # Bootstrap new shops from YAML spec
├── agent           # List, create, update agents
├── chat            # Send a message to an agent
├── conversations   # List, show, import conversations
├── insights        # Generate analytics reports
├── knowledge       # Q&A entries, escalation rules
├── taxonomy        # Topic/intent classification
├── test            # Testing workflows
│   ├── benchmarks  # Scenario collections
│   ├── scenarios   # Individual test cases (includes rate)
│   ├── runs        # Execution records
│   ├── coverage    # Coverage summaries
│   └── fix         # Fix failing scenarios
└── simulate        # Generate test conversations
```

## MCP Server

The CLI includes an MCP server for Claude integrations:

```bash
# Run directly (after pip install)
applied-cli-mcp

# Or via uvx (after publishing to PyPI)
uvx --from "applied-cli[mcp]" applied-cli-mcp
```

### Claude Desktop Configuration

Add to `~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "applied-labs": {
      "command": "applied-cli-mcp"
    }
  }
}
```

## Plugin Skills

When installed as a Claude Code plugin, these skills are available:

- `/applied-labs:setup-shop` - Guided shop setup workflow
- `/applied-labs:fix-scenarios` - Fix failing test scenarios

## Environment Variables

| Variable | Description |
|----------|-------------|
| `APPLIED_ENDPOINT` | `prod`, `dev`, `local`, or full URL |
| `APPLIED_SHOP_ID` | Pre-select shop UUID |
| `APPLIED_API_TOKEN` | Skip browser auth |
| `APPLIED_PROFILE` | Named credential profile |

## Development

```bash
# Install in development mode
pip install -e ".[mcp]"

# Test CLI
applied-cli --help

# Test MCP server
applied-cli-mcp

# Test as Claude Code plugin
claude --plugin-dir .
```

## License

MIT
