import os
from typing import Optional

from applied_cli.auth_store import load_credentials
from applied_cli.config import DEFAULT_BASE_URL, normalize_base_url
from applied_cli.http import APIError


def resolve_runtime(
    *,
    base_url: Optional[str],
    shop_id: Optional[str],
    api_token: Optional[str],
) -> tuple[str, str, str]:
    requested_profile = os.getenv("APPLIED_PROFILE")
    creds = load_credentials(profile=requested_profile)
    resolved_base_url = normalize_base_url(
        base_url
        or os.getenv("APPLIED_BASE_URL")
        or os.getenv("APPLIED_ENDPOINT")
        or (creds.base_url if creds else "")
        or DEFAULT_BASE_URL
    )
    resolved_shop_id = shop_id or os.getenv("APPLIED_SHOP_ID") or (
        creds.shop_id if creds else ""
    )
    resolved_token = api_token or os.getenv("APPLIED_API_TOKEN") or (
        creds.api_token if creds else ""
    )

    if not resolved_base_url:
        raise APIError(
            "Missing base URL.",
            code="MISSING_BASE_URL",
            hint="Set via --base-url, APPLIED_BASE_URL, or run `applied-cli auth login`.",
            retryable=False,
        )
    if not resolved_shop_id:
        raise APIError(
            "Missing shop ID.",
            code="MISSING_SHOP_ID",
            hint="Set via --shop-id, APPLIED_SHOP_ID, or run `applied-cli auth login`.",
            retryable=False,
        )
    if not resolved_token:
        raise APIError(
            "Missing API token.",
            code="MISSING_API_TOKEN",
            hint="Set via --api-token, APPLIED_API_TOKEN, or run `applied-cli auth login`.",
            retryable=False,
        )

    return resolved_base_url, resolved_shop_id, resolved_token
