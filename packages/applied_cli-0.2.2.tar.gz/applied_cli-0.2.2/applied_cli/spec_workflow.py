import json
import re
import uuid
from pathlib import Path
from typing import Any, Optional

from applied_cli.commands._normalize import (
    AGENT_TYPE_ALIASES,
    MODALITY_ALIASES,
    RESPONSE_TYPE_ALIASES,
)
from applied_cli.http import (
    APIError,
    create_agent,
    create_response,
    list_responses,
    patch_response,
    update_agent,
)
from applied_cli.runtime import resolve_runtime as _resolve_runtime

ALLOWED_RESPONSE_TYPES = {"escalation", "exact", "qa", "context"}
ALLOWED_CHANNELS = {"chat", "email", "sms"}


def _spec_error(path: str, message: str) -> None:
    raise ValueError(f"spec.{path}: {message}")


def _validate_string(value: Any, *, path: str, required: bool = False) -> str:
    if value is None:
        if required:
            _spec_error(path, "is required")
        return ""
    if not isinstance(value, str):
        _spec_error(path, "must be a string")
    normalized = value.strip()
    if required and not normalized:
        _spec_error(path, "cannot be empty")
    return normalized


def _validate_string_list(value: Any, *, path: str) -> list[str]:
    if value is None:
        return []
    if not isinstance(value, list):
        _spec_error(path, "must be an array of strings")
    out: list[str] = []
    for idx, item in enumerate(value):
        if not isinstance(item, str):
            _spec_error(f"{path}[{idx}]", "must be a string")
        normalized = item.strip()
        if not normalized:
            _spec_error(f"{path}[{idx}]", "cannot be empty")
        out.append(normalized)
    return out


def _validate_bool(value: Any, *, path: str, default: bool) -> bool:
    if value is None:
        return default
    if not isinstance(value, bool):
        _spec_error(path, "must be a boolean")
    return value


def _validate_dict(value: Any, *, path: str) -> dict[str, Any]:
    if value is None:
        return {}
    if not isinstance(value, dict):
        _spec_error(path, "must be an object")
    return value


def _normalize_question(text: str) -> str:
    return re.sub(r"\s+", " ", text.strip().lower())


def load_and_validate_spec(spec_path: str) -> dict[str, Any]:
    try:
        raw_text = Path(spec_path).read_text(encoding="utf-8")
    except OSError as exc:
        raise ValueError(f"spec: unable to read file ({exc})") from exc
    try:
        payload = json.loads(raw_text)
    except json.JSONDecodeError as exc:
        raise ValueError(f"spec: invalid JSON ({exc})") from exc
    if not isinstance(payload, dict):
        _spec_error("", "root must be an object")

    agent_raw = payload.get("agent")
    if not isinstance(agent_raw, dict):
        _spec_error("agent", "is required and must be an object")

    agent: dict[str, Any] = {
        "name": _validate_string(agent_raw.get("name"), path="agent.name", required=True),
        "modality": _validate_string(
            agent_raw.get("modality"), path="agent.modality", required=True
        ),
    }
    modality_key = agent["modality"].strip().lower()
    if modality_key not in MODALITY_ALIASES:
        _spec_error(
            "agent.modality",
            "must be one of: all, call, sms, email, chat, internal",
        )
    agent["modality"] = MODALITY_ALIASES[modality_key]
    for field in (
        "description",
        "model",
        "type",
        "email",
        "phone",
        "escalation_mode",
        "escalation_wait_time_mode",
        "prompt",
        "guardrail",
    ):
        if field in agent_raw and agent_raw.get(field) is not None:
            agent[field] = _validate_string(
                agent_raw.get(field), path=f"agent.{field}", required=False
            )
    if "type" in agent:
        normalized_type_key = agent["type"].strip().lower()
        if normalized_type_key not in AGENT_TYPE_ALIASES:
            _spec_error(
                "agent.type",
                "must be one of: generic, customer_support, conversion, sales, marketing, engineering, product",
            )
        agent["type"] = AGENT_TYPE_ALIASES[normalized_type_key]
    if "metadata" in agent_raw:
        agent["metadata"] = _validate_dict(agent_raw.get("metadata"), path="agent.metadata")
    if "suggestions" in agent_raw:
        agent["suggestions"] = _validate_string_list(
            agent_raw.get("suggestions"), path="agent.suggestions"
        )
    if "personality" in agent_raw:
        agent["personality"] = _validate_string_list(
            agent_raw.get("personality"), path="agent.personality"
        )
    for bool_field in ("auto_reply", "use_guardrails"):
        if bool_field in agent_raw:
            agent[bool_field] = _validate_bool(
                agent_raw.get(bool_field), path=f"agent.{bool_field}", default=False
            )
    if "response_delay_in_seconds" in agent_raw:
        delay = agent_raw.get("response_delay_in_seconds")
        if not isinstance(delay, int) or delay < 0:
            _spec_error("agent.response_delay_in_seconds", "must be a non-negative integer")
        agent["response_delay_in_seconds"] = delay

    responses_raw = payload.get("responses", [])
    if responses_raw is None:
        responses_raw = []
    if not isinstance(responses_raw, list):
        _spec_error("responses", "must be an array")
    responses: list[dict[str, Any]] = []
    for idx, response in enumerate(responses_raw):
        if not isinstance(response, dict):
            _spec_error(f"responses[{idx}]", "must be an object")
        response_type = _validate_string(
            response.get("type"), path=f"responses[{idx}].type", required=True
        ).lower()
        if response_type not in ALLOWED_RESPONSE_TYPES:
            _spec_error(
                f"responses[{idx}].type",
                f"must be one of: {', '.join(sorted(ALLOWED_RESPONSE_TYPES))}",
            )
        question = _validate_string(
            response.get("question"), path=f"responses[{idx}].question", required=True
        )
        answer = _validate_string(
            response.get("answer"), path=f"responses[{idx}].answer", required=True
        )
        entry: dict[str, Any] = {
            "type": RESPONSE_TYPE_ALIASES[response_type],
            "question": question,
            "answer": answer,
            "active": _validate_bool(
                response.get("active"), path=f"responses[{idx}].active", default=True
            ),
        }
        if "guardrail" in response:
            entry["guardrail"] = _validate_string(
                response.get("guardrail"), path=f"responses[{idx}].guardrail"
            )
        if "fields_to_extract" in response:
            fields = response.get("fields_to_extract")
            if not isinstance(fields, list):
                _spec_error(f"responses[{idx}].fields_to_extract", "must be an array")
            entry["fields_to_extract"] = fields
        responses.append(entry)

    tests_raw = payload.get("tests", [])
    if tests_raw is None:
        tests_raw = []
    if not isinstance(tests_raw, list):
        _spec_error("tests", "must be an array")
    tests: list[dict[str, Any]] = []
    for idx, test in enumerate(tests_raw):
        if not isinstance(test, dict):
            _spec_error(f"tests[{idx}]", "must be an object")
        channel = _validate_string(
            test.get("channel"), path=f"tests[{idx}].channel", required=True
        ).lower()
        if channel not in ALLOWED_CHANNELS:
            _spec_error(
                f"tests[{idx}].channel",
                f"must be one of: {', '.join(sorted(ALLOWED_CHANNELS))}",
            )
        turns = _validate_string_list(test.get("turns"), path=f"tests[{idx}].turns")
        if not turns:
            _spec_error(f"tests[{idx}].turns", "must include at least one message")
        test_entry: dict[str, Any] = {
            "name": _validate_string(
                test.get("name"), path=f"tests[{idx}].name", required=False
            )
            or f"test-{idx + 1}",
            "channel": channel,
            "turns": turns,
            "include_references": _validate_bool(
                test.get("include_references"),
                path=f"tests[{idx}].include_references",
                default=True,
            ),
            "auto_rate": _validate_bool(
                test.get("auto_rate"), path=f"tests[{idx}].auto_rate", default=True
            ),
        }
        for text_field in ("pass_status", "feedback", "reference_notes"):
            if text_field in test and test.get(text_field) is not None:
                test_entry[text_field] = _validate_string(
                    test.get(text_field), path=f"tests[{idx}].{text_field}"
                )
        for float_field in ("csat_score", "reference_score"):
            if float_field in test and test.get(float_field) is not None:
                value = test.get(float_field)
                if not isinstance(value, (int, float)):
                    _spec_error(f"tests[{idx}].{float_field}", "must be a number")
                test_entry[float_field] = float(value)
        tests.append(test_entry)

    benchmark_name = _validate_string(
        payload.get("benchmark_name"), path="benchmark_name", required=False
    )
    return {
        "agent": agent,
        "responses": responses,
        "tests": tests,
        "benchmark_name": benchmark_name or "CLI Self-Rated Conversations",
    }


def resolve_runtime(
    *,
    base_url: Optional[str],
    shop_id: Optional[str],
    api_token: Optional[str],
) -> tuple[str, str, str]:
    # Compatibility wrapper; prefer importing from applied_cli.runtime directly.
    return _resolve_runtime(base_url=base_url, shop_id=shop_id, api_token=api_token)


def build_agent_payload(spec: dict[str, Any]) -> dict[str, Any]:
    agent = dict(spec["agent"])
    payload: dict[str, Any] = {
        "name": agent["name"],
        "modality": agent["modality"],
    }
    for key in (
        "description",
        "model",
        "type",
        "email",
        "phone",
        "metadata",
        "suggestions",
        "personality",
        "auto_reply",
        "use_guardrails",
        "escalation_mode",
        "escalation_wait_time_mode",
        "response_delay_in_seconds",
        "prompt",
        "guardrail",
    ):
        if key in agent:
            payload[key] = agent[key]
    return payload


def _agent_attached(response_row: dict[str, Any], *, agent_id: str) -> bool:
    agents = response_row.get("agents")
    if not isinstance(agents, list):
        return False
    for item in agents:
        if isinstance(item, dict) and str(item.get("id")) == agent_id:
            return True
    return False


def _response_payload(spec_response: dict[str, Any], *, agent_id: str) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "type": spec_response["type"],
        "question": spec_response["question"],
        "answer": spec_response["answer"],
        "active": bool(spec_response.get("active", True)),
        "agent_ids": [agent_id],
    }
    if spec_response.get("guardrail"):
        payload["guardrail"] = spec_response["guardrail"]
    if "fields_to_extract" in spec_response:
        payload["fields_to_extract"] = spec_response["fields_to_extract"]
    return payload


def upsert_spec_responses(
    *,
    base_url: str,
    shop_id: str,
    api_token: str,
    agent_id: str,
    responses: list[dict[str, Any]],
    dry_run: bool = False,
) -> dict[str, Any]:
    if dry_run:
        try:
            uuid.UUID(agent_id)
        except ValueError:
            return {
                "created_ids": [],
                "updated_ids": [],
                "created_count": len(responses),
                "updated_count": 0,
            }

    existing = list_responses(
        base_url=base_url,
        shop_id=shop_id,
        api_token=api_token,
        agent_id=agent_id,
        limit=500,
    )
    existing_by_key: dict[tuple[str, str], dict[str, Any]] = {}
    for row in existing:
        if not _agent_attached(row, agent_id=agent_id):
            continue
        response_type = str(row.get("type") or "").strip().lower()
        question = _normalize_question(str(row.get("question") or ""))
        if response_type and question:
            existing_by_key[(response_type, question)] = row

    created: list[str] = []
    updated: list[str] = []
    planned_create = 0
    planned_update = 0
    for spec_response in responses:
        key = (
            spec_response["type"],
            _normalize_question(spec_response["question"]),
        )
        payload = _response_payload(spec_response, agent_id=agent_id)
        matched = existing_by_key.get(key)
        if matched:
            if dry_run:
                planned_update += 1
                continue
            updated_row = patch_response(
                base_url=base_url,
                shop_id=shop_id,
                api_token=api_token,
                response_id=str(matched.get("id")),
                payload=payload,
            )
            updated.append(str(updated_row.get("id")))
        else:
            if dry_run:
                planned_create += 1
                continue
            created_row = create_response(
                base_url=base_url,
                shop_id=shop_id,
                api_token=api_token,
                payload=payload,
            )
            created.append(str(created_row.get("id")))
    return {
        "created_ids": created,
        "updated_ids": updated,
        "created_count": len(created) if not dry_run else planned_create,
        "updated_count": len(updated) if not dry_run else planned_update,
    }


def create_agent_from_spec(
    *,
    base_url: str,
    shop_id: str,
    api_token: str,
    spec: dict[str, Any],
    dry_run: bool = False,
) -> dict[str, Any]:
    payload = build_agent_payload(spec)
    if dry_run:
        return {"id": "dry-run", "payload": payload}
    return create_agent(
        base_url=base_url,
        shop_id=shop_id,
        api_token=api_token,
        payload=payload,
    )


def apply_agent_settings_from_spec(
    *,
    base_url: str,
    shop_id: str,
    api_token: str,
    agent_id: str,
    spec: dict[str, Any],
    dry_run: bool = False,
) -> dict[str, Any]:
    payload = build_agent_payload(spec)
    if dry_run:
        return {"id": agent_id, "payload": payload}
    return update_agent(
        base_url=base_url,
        shop_id=shop_id,
        api_token=api_token,
        agent_id=agent_id,
        payload=payload,
    )
