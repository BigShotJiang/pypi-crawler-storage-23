import json
from pathlib import Path
from typing import Optional

from applied_cli.config import Credentials

SERVICE_NAME = "applied-cli"
ACCOUNT_NAME = "default"
STORE_VERSION = 2


def _fallback_path() -> Path:
    return Path.home() / ".config" / "applied-cli" / "credentials.json"


def _credentials_to_dict(credentials: Credentials) -> dict[str, str]:
    return {
        "base_url": credentials.base_url,
        "shop_id": credentials.shop_id,
        "api_token": credentials.api_token,
    }


def _credentials_from_dict(data: dict[str, object]) -> Optional[Credentials]:
    base_url = str(data.get("base_url", "")).strip()
    shop_id = str(data.get("shop_id", "")).strip()
    api_token = str(data.get("api_token", "")).strip()
    if not base_url or not shop_id or not api_token:
        return None
    return Credentials(base_url=base_url, shop_id=shop_id, api_token=api_token)


def _normalize_store(raw: object) -> dict[str, object]:
    if not isinstance(raw, dict):
        return {"version": STORE_VERSION, "active_profile": None, "profiles": {}}

    # Legacy single-profile shape:
    # {"base_url": "...", "shop_id": "...", "api_token": "..."}
    legacy = _credentials_from_dict(raw)
    if legacy:
        return {
            "version": STORE_VERSION,
            "active_profile": "default",
            "profiles": {"default": _credentials_to_dict(legacy)},
        }

    profiles_raw = raw.get("profiles")
    profiles: dict[str, dict[str, str]] = {}
    if isinstance(profiles_raw, dict):
        for profile_name, payload in profiles_raw.items():
            if not isinstance(profile_name, str) or not profile_name.strip():
                continue
            if not isinstance(payload, dict):
                continue
            creds = _credentials_from_dict(payload)
            if creds is None:
                continue
            profiles[profile_name.strip()] = _credentials_to_dict(creds)

    active_profile_raw = raw.get("active_profile")
    active_profile = (
        active_profile_raw.strip()
        if isinstance(active_profile_raw, str) and active_profile_raw.strip()
        else None
    )
    if active_profile and active_profile not in profiles:
        active_profile = None
    if not active_profile and profiles:
        active_profile = sorted(profiles.keys())[0]

    return {
        "version": STORE_VERSION,
        "active_profile": active_profile,
        "profiles": profiles,
    }


def _serialize_store(store: dict[str, object]) -> str:
    return json.dumps(
        {
            "version": STORE_VERSION,
            "active_profile": store.get("active_profile"),
            "profiles": store.get("profiles", {}),
        }
    )


def _load_store_from_keyring() -> Optional[dict[str, object]]:
    try:
        import keyring
    except Exception:
        return None

    try:
        raw = keyring.get_password(SERVICE_NAME, ACCOUNT_NAME)
    except Exception:
        return None

    if not raw:
        return None

    try:
        return _normalize_store(json.loads(raw))
    except Exception:
        return None


def _save_store_to_keyring(store: dict[str, object]) -> bool:
    try:
        import keyring
    except Exception:
        return False

    try:
        keyring.set_password(
            SERVICE_NAME,
            ACCOUNT_NAME,
            _serialize_store(store),
        )
        return True
    except Exception:
        return False


def _clear_keyring() -> None:
    try:
        import keyring

        keyring.delete_password(SERVICE_NAME, ACCOUNT_NAME)
    except Exception:
        return


def _load_store_from_file() -> Optional[dict[str, object]]:
    path = _fallback_path()
    if not path.exists():
        return None

    try:
        return _normalize_store(json.loads(path.read_text()))
    except Exception:
        return None


def _save_store_to_file(store: dict[str, object]) -> None:
    path = _fallback_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(_serialize_store(store))
    path.chmod(0o600)


def _clear_file() -> None:
    path = _fallback_path()
    if path.exists():
        path.unlink()


def _load_store() -> dict[str, object]:
    store = _load_store_from_keyring()
    if store:
        return store
    store = _load_store_from_file()
    if store:
        return store
    return {"version": STORE_VERSION, "active_profile": None, "profiles": {}}


def _save_store(store: dict[str, object]) -> str:
    if _save_store_to_keyring(store):
        return "keyring"

    _save_store_to_file(store)
    return "file"


def save_credentials(
    credentials: Credentials,
    *,
    profile: str = "default",
    set_active: bool = True,
) -> str:
    profile_name = profile.strip() or "default"
    store = _load_store()
    profiles = store.get("profiles")
    if not isinstance(profiles, dict):
        profiles = {}
    profiles[profile_name] = _credentials_to_dict(credentials)
    store["profiles"] = profiles
    if set_active:
        store["active_profile"] = profile_name
    return _save_store(store)


def load_profiles() -> dict[str, Credentials]:
    store = _load_store()
    profiles = store.get("profiles")
    if not isinstance(profiles, dict):
        return {}
    out: dict[str, Credentials] = {}
    for profile_name, payload in profiles.items():
        if not isinstance(profile_name, str) or not isinstance(payload, dict):
            continue
        creds = _credentials_from_dict(payload)
        if creds is not None:
            out[profile_name] = creds
    return out


def list_profiles() -> list[str]:
    return sorted(load_profiles().keys())


def get_active_profile_name() -> Optional[str]:
    store = _load_store()
    active = store.get("active_profile")
    return active if isinstance(active, str) and active.strip() else None


def set_active_profile(profile: str) -> bool:
    profile_name = profile.strip()
    if not profile_name:
        return False
    store = _load_store()
    profiles = store.get("profiles")
    if not isinstance(profiles, dict) or profile_name not in profiles:
        return False
    store["active_profile"] = profile_name
    _save_store(store)
    return True


def delete_profile(profile: str) -> bool:
    profile_name = profile.strip()
    if not profile_name:
        return False
    store = _load_store()
    profiles = store.get("profiles")
    if not isinstance(profiles, dict) or profile_name not in profiles:
        return False
    del profiles[profile_name]
    store["profiles"] = profiles
    active = store.get("active_profile")
    if active == profile_name:
        store["active_profile"] = sorted(profiles.keys())[0] if profiles else None
    _save_store(store)
    return True


def load_credentials(*, profile: Optional[str] = None) -> Optional[Credentials]:
    profiles = load_profiles()
    if not profiles:
        return None
    if profile and profile in profiles:
        return profiles[profile]
    active = get_active_profile_name()
    if active and active in profiles:
        return profiles[active]
    return profiles.get("default")


def clear_credentials() -> None:
    _clear_keyring()
    _clear_file()
