from difflib import get_close_matches
from typing import Iterable


def suggest_value(raw: str, options: Iterable[str]) -> str | None:
    value = raw.strip().lower()
    normalized = [item.strip().lower() for item in options if item.strip()]
    if not value or not normalized:
        return None
    matches = get_close_matches(value, normalized, n=1, cutoff=0.6)
    return matches[0] if matches else None
