import json
import uuid
from typing import Any, Optional

import httpx
import typer

from applied_cli.commands.chat import (
    _create_conversation,
    _stream_v1_completion,
    _verify_agent_scope,
)
from applied_cli.commands.rate import conversation as rate_conversation_command
from applied_cli.error_reporting import render_api_error
from applied_cli.http import APIError
from applied_cli.spec_workflow import (
    apply_agent_settings_from_spec,
    create_agent_from_spec,
    load_and_validate_spec,
    upsert_spec_responses,
)
from applied_cli.runtime import resolve_runtime

app = typer.Typer(help="Run spec-driven bootstrap/test/rate workflow.")


def _run_test_case(
    *,
    client: httpx.Client,
    base_url: str,
    shop_id: str,
    api_token: str,
    agent_id: str,
    test_case: dict[str, Any],
) -> dict[str, Any]:
    channel = str(test_case["channel"])
    conversation_id = _create_conversation(
        client,
        base_url=base_url,
        agent_id=agent_id,
        channel=channel,
    )
    transcript_results: list[dict[str, Any]] = []
    for turn in test_case["turns"]:
        transcript = [
            {
                "id": str(uuid.uuid4()),
                "role": "user",
                "content": turn,
                "text": turn,
                "format": "TEXT",
                "entity": {"type": "user"},
            }
        ]
        payload: dict[str, object] = {
            "conversation_id": conversation_id,
            "context": "EVALUATE",
            "transcript": transcript,
            "metadata": {
                "source": "applied-cli-spec",
                "isTest": True,
                "channel": channel,
                "test_name": test_case["name"],
            },
            "draft": False,
        }
        assistant_text = _stream_v1_completion(
            client,
            base_url=base_url,
            shop_id=shop_id,
            api_token=api_token,
            agent_id=agent_id,
            payload=payload,
        )
        transcript_results.append(
            {"user": turn, "assistant": assistant_text, "assistant_chars": len(assistant_text)}
        )
    return {
        "name": test_case["name"],
        "channel": channel,
        "conversation_id": conversation_id,
        "turns": transcript_results,
    }


@app.command("run")
def run(
    spec: str = typer.Option(..., "--spec", help="Path to spec JSON."),
    agent_id: Optional[str] = typer.Option(
        None, "--agent-id", help="Reuse existing agent id instead of creating one."
    ),
    base_url: Optional[str] = typer.Option(None, help="Applied base URL."),
    shop_id: Optional[str] = typer.Option(None, help="Target shop UUID."),
    api_token: Optional[str] = typer.Option(None, help="Applied API token."),
    dry_run: bool = typer.Option(False, help="Validate and print plan without writes."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt."),
    output_json: bool = typer.Option(False, "--json", help="Emit JSON output."),
) -> None:
    if agent_id:
        try:
            uuid.UUID(agent_id)
        except ValueError as exc:
            raise typer.BadParameter("agent-id must be a valid UUID.") from exc
    try:
        validated_spec = load_and_validate_spec(spec)
        resolved_base_url, resolved_shop_id, resolved_token = resolve_runtime(
            base_url=base_url,
            shop_id=shop_id,
            api_token=api_token,
        )
    except ValueError as exc:
        typer.echo(f"Spec validation failed: {exc}", err=True)
        raise typer.Exit(code=2) from exc
    except APIError as exc:
        typer.echo(render_api_error(exc, action="resolve runtime for spec run"), err=True)
        raise typer.Exit(code=1) from exc

    typer.echo("Plan:")
    typer.echo(f"- base_url: {resolved_base_url}")
    typer.echo(f"- shop_id: {resolved_shop_id}")
    typer.echo(f"- tests: {len(validated_spec['tests'])}")
    typer.echo(f"- responses: {len(validated_spec['responses'])}")
    typer.echo(f"- dry_run: {dry_run}")
    if not yes and not typer.confirm("Continue?"):
        raise typer.Exit(code=1)

    working_agent_id = agent_id
    try:
        if working_agent_id:
            apply_agent_settings_from_spec(
                base_url=resolved_base_url,
                shop_id=resolved_shop_id,
                api_token=resolved_token,
                agent_id=working_agent_id,
                spec=validated_spec,
                dry_run=dry_run,
            )
            upsert_spec_responses(
                base_url=resolved_base_url,
                shop_id=resolved_shop_id,
                api_token=resolved_token,
                agent_id=working_agent_id,
                responses=validated_spec["responses"],
                dry_run=dry_run,
            )
        else:
            created = create_agent_from_spec(
                base_url=resolved_base_url,
                shop_id=resolved_shop_id,
                api_token=resolved_token,
                spec=validated_spec,
                dry_run=dry_run,
            )
            working_agent_id = str(created.get("id"))
            upsert_spec_responses(
                base_url=resolved_base_url,
                shop_id=resolved_shop_id,
                api_token=resolved_token,
                agent_id=working_agent_id,
                responses=validated_spec["responses"],
                dry_run=dry_run,
            )
    except APIError as exc:
        typer.echo(render_api_error(exc, action="bootstrap spec run"), err=True)
        raise typer.Exit(code=1) from exc

    report: dict[str, Any] = {
        "agent_id": working_agent_id,
        "benchmark_name": validated_spec["benchmark_name"],
        "tests": [],
        "dry_run": dry_run,
    }
    if dry_run:
        if output_json:
            typer.echo(json.dumps(report, indent=2))
        else:
            typer.echo("Dry run complete. No tests executed.")
        raise typer.Exit(code=0)

    if not working_agent_id or working_agent_id == "dry-run":
        typer.echo("Unable to resolve agent id for execution.", err=True)
        raise typer.Exit(code=1)

    with httpx.Client() as client:
        try:
            _verify_agent_scope(
                client,
                base_url=resolved_base_url,
                shop_id=resolved_shop_id,
                api_token=resolved_token,
                agent_id=working_agent_id,
            )
            for test_case in validated_spec["tests"]:
                typer.echo(f"\nRunning test: {test_case['name']}")
                result = _run_test_case(
                    client=client,
                    base_url=resolved_base_url,
                    shop_id=resolved_shop_id,
                    api_token=resolved_token,
                    agent_id=working_agent_id,
                    test_case=test_case,
                )
                report["tests"].append(result)
        except APIError as exc:
            typer.echo(render_api_error(exc, action="run spec tests"), err=True)
            raise typer.Exit(code=1) from exc

    for test_result, test_case in zip(report["tests"], validated_spec["tests"]):
        try:
            rate_conversation_command(
                conversation_id=test_result["conversation_id"],
                agent_id=working_agent_id,
                benchmark_name=validated_spec["benchmark_name"],
                auto=bool(test_case.get("auto_rate", True)),
                include_references=bool(test_case.get("include_references", True)),
                pass_status=test_case.get("pass_status"),
                csat_score=test_case.get("csat_score"),
                feedback=test_case.get("feedback"),
                reference_score=test_case.get("reference_score"),
                reference_notes=test_case.get("reference_notes"),
                base_url=resolved_base_url,
                shop_id=resolved_shop_id,
                api_token=resolved_token,
                dry_run=False,
                yes=True,
            )
        except Exception as exc:
            typer.echo(
                f"Rating failed for conversation {test_result['conversation_id']}: {exc}",
                err=True,
            )

    if output_json:
        typer.echo(json.dumps(report, indent=2, default=str))
    else:
        typer.echo("\nSpec run complete:")
        typer.echo(f"- agent_id: {working_agent_id}")
        typer.echo(f"- tests_executed: {len(report['tests'])}")
