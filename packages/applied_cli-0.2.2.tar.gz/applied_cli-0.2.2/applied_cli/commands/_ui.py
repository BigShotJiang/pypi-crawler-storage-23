import json
from typing import Any

import typer


def show_target(fields: dict[str, Any]) -> None:
    typer.echo("Target:")
    for key, value in fields.items():
        typer.echo(f"- {key}: {value}")


def confirm_or_exit(*, yes: bool, prompt: str = "Continue?") -> None:
    if not yes and not typer.confirm(prompt):
        raise typer.Exit(code=1)


def emit_dry_run(*, payload: dict[str, Any], output_json: bool) -> None:
    typer.echo(json.dumps(payload, indent=2) if output_json else str(payload))
    raise typer.Exit(code=0)


def emit_success(
    *,
    output_json: bool,
    payload: Any,
    fields: dict[str, Any],
) -> None:
    if output_json:
        typer.echo(json.dumps(payload, indent=2, default=str))
        return
    items = [f"{key}={value}" for key, value in fields.items()]
    typer.echo("result=success | " + " | ".join(items))
