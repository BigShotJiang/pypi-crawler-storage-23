import re
from typing import Optional

import typer

from applied_cli.commands._hints import suggest_value

MODALITY_ALIASES = {
    "all": "All",
    "call": "Call",
    "sms": "SMS",
    "email": "Email",
    "chat": "Chat",
    "internal": "Internal",
}

AGENT_TYPE_ALIASES = {
    "generic": "Generic",
    "customer_support": "Customer Support",
    "customer support": "Customer Support",
    "conversion": "Conversion",
    "sales": "Sales",
    "marketing": "Marketing",
    "engineering": "Engineering",
    "product": "Product",
}

RESPONSE_TYPE_ALIASES = {
    "escalation": "escalate",
    "escalate": "escalate",
    "exact": "exact",
    "qa": "qa",
    "context": "context",
    "greeting": "greeting",
    "signature": "signature",
}


def normalize_question(text: str) -> str:
    return re.sub(r"\s+", " ", text.strip().lower())


def normalize_response_type(
    raw: str,
    *,
    field_label: str = "type",
    include_suggestion: bool = False,
) -> str:
    key = raw.strip().lower()
    if key not in RESPONSE_TYPE_ALIASES:
        suffix = ""
        if include_suggestion:
            suggestion = suggest_value(key, RESPONSE_TYPE_ALIASES.keys())
            if suggestion:
                suffix = f" Did you mean '{suggestion}'?"
        raise typer.BadParameter(
            f"{field_label} must be one of: escalation, exact, qa, context, greeting, signature.{suffix}"
        )
    return RESPONSE_TYPE_ALIASES[key]


def normalize_modality(raw: Optional[str]) -> Optional[str]:
    if raw is None:
        return None
    key = raw.strip().lower()
    if key not in MODALITY_ALIASES:
        raise typer.BadParameter("modality must be one of: all, call, sms, email, chat, internal")
    return MODALITY_ALIASES[key]


def normalize_agent_type(raw: Optional[str]) -> Optional[str]:
    if raw is None:
        return None
    key = raw.strip().lower()
    if key not in AGENT_TYPE_ALIASES:
        raise typer.BadParameter(
            "type must be one of: generic, customer_support, conversion, sales, marketing, engineering, product"
        )
    return AGENT_TYPE_ALIASES[key]
