import json
from typing import Any, Optional

import typer

from applied_cli.commands._parsers import parse_json_dict, validate_uuid
from applied_cli.error_reporting import render_api_error
from applied_cli.http import APIError, simulate_agent_conversation
from applied_cli.runtime import resolve_runtime

app = typer.Typer(
    help="Generate simulated conversations (including backdated timestamps)."
)


@app.command(
    "run",
    help=(
        "Simulate conversations for an agent with sensible defaults. Example: "
        "applied-cli simulate run --agent-id <uuid> --count 10 "
        "--created-at-from 2026-01-26T00:00:00Z --created-at-to 2026-02-26T23:59:59Z "
        "--is-test false --conversation-type web_chat"
    ),
)
@app.command(
    "conversations",
    hidden=True,
    help="Alias for `simulate run`.",
)
def conversations_cmd(
    agent_id: str = typer.Option(
        ...,
        "--agent-id",
        "--agent",
        "--id",
        help="Target agent UUID.",
    ),
    count: int = typer.Option(
        1,
        "--count",
        help="Number of conversations to simulate.",
    ),
    max_turns: int = typer.Option(
        6,
        "--max-turns",
        help="Maximum turns per simulated conversation (1-10).",
    ),
    agent_subtype: Optional[str] = typer.Option(
        None,
        "--agent-subtype",
        help="Optional agent subtype forwarded to simulate endpoint.",
    ),
    conversation_type: Optional[str] = typer.Option(
        None,
        "--conversation-type",
        help="Optional conversation type (e.g. web_chat, email, sms).",
    ),
    direction: Optional[str] = typer.Option(
        None,
        "--direction",
        help="Optional direction (e.g. inbound, outbound).",
    ),
    is_test: bool = typer.Option(
        True,
        "--is-test/--no-is-test",
        help="Mark simulated conversations as test data.",
    ),
    is_historical: bool = typer.Option(
        True,
        "--is-historical/--no-is-historical",
        help="Mark simulated conversations as historical.",
    ),
    remote_platform: Optional[str] = typer.Option(
        None,
        "--remote-platform",
        help="Optional remote platform tag (for example: instagram).",
    ),
    created_at: Optional[str] = typer.Option(
        None,
        "--created-at",
        help="Explicit timestamp (ISO-8601) for each simulation run.",
    ),
    created_at_from: Optional[str] = typer.Option(
        None,
        "--created-at-from",
        help="Start timestamp (ISO-8601) for random timestamp simulation.",
    ),
    created_at_to: Optional[str] = typer.Option(
        None,
        "--created-at-to",
        help="End timestamp (ISO-8601) for random timestamp simulation.",
    ),
    created_at_distribution: str = typer.Option(
        "daily_peaks",
        "--created-at-distribution",
        help="Timestamp distribution: flat, daily_peaks, weekly_peaks.",
    ),
    label_id: Optional[str] = typer.Option(
        None,
        "--label-id",
        help="Optional topic UUID.",
    ),
    sublabel_id: Optional[str] = typer.Option(
        None,
        "--sublabel-id",
        help="Optional intent UUID.",
    ),
    metadata_json: Optional[str] = typer.Option(
        None,
        "--metadata-json",
        help='Optional conversation metadata JSON object. Example: \'{"source":"cli"}\'',
    ),
    simulate_experiments: bool = typer.Option(
        False,
        "--simulate-experiments/--no-simulate-experiments",
        help="Enable experiment traffic simulation fields.",
    ),
    experiment_id: Optional[str] = typer.Option(
        None,
        "--experiment-id",
        help="Optional experiment UUID when simulating experiments.",
    ),
    traffic_rule_id: Optional[str] = typer.Option(
        None,
        "--traffic-rule-id",
        help="Optional traffic rule UUID when simulating experiments.",
    ),
    populate_workforce_actions: bool = typer.Option(
        False,
        "--populate-workforce-actions/--no-populate-workforce-actions",
        help="Emit workforce-style actions/metrics in simulation.",
    ),
    assigned_user_id: Optional[str] = typer.Option(
        None,
        "--assigned-user-id",
        help="Optional assignee UUID for workforce simulation.",
    ),
    user_model: Optional[str] = typer.Option(
        None,
        "--user-model",
        help="Optional simulated user model (for example: openai:gpt-5-nano).",
    ),
    user_temperature: Optional[float] = typer.Option(
        None,
        "--user-temperature",
        help="Optional simulated user temperature (0.0-2.0).",
    ),
    seed: Optional[int] = typer.Option(
        None,
        "--seed",
        help="Optional deterministic seed for user LLM timestamp sampling.",
    ),
    output_json: bool = typer.Option(False, "--json", help="Emit JSON output."),
    continue_on_error: bool = typer.Option(
        False,
        "--continue-on-error/--no-continue-on-error",
        help="Continue remaining simulations even if one fails.",
    ),
    base_url: Optional[str] = typer.Option(None, help="Applied base URL."),
    shop_id: Optional[str] = typer.Option(None, help="Target shop UUID."),
    api_token: Optional[str] = typer.Option(None, help="Applied API token."),
) -> None:
    validate_uuid(agent_id, field_name="agent-id")
    if experiment_id:
        validate_uuid(experiment_id, field_name="experiment-id")
    if traffic_rule_id:
        validate_uuid(traffic_rule_id, field_name="traffic-rule-id")
    if assigned_user_id:
        validate_uuid(assigned_user_id, field_name="assigned-user-id")
    if label_id:
        validate_uuid(label_id, field_name="label-id")
    if sublabel_id:
        validate_uuid(sublabel_id, field_name="sublabel-id")
    metadata = parse_json_dict(metadata_json, field_name="metadata-json")
    if count < 1:
        raise typer.BadParameter("count must be >= 1.")
    if not (1 <= max_turns <= 10):
        raise typer.BadParameter("max-turns must be between 1 and 10.")
    if user_temperature is not None and not (0.0 <= user_temperature <= 2.0):
        raise typer.BadParameter("user-temperature must be between 0.0 and 2.0.")
    if conversation_type and conversation_type not in {"web_chat", "email", "sms", "phone_call"}:
        raise typer.BadParameter(
            "conversation-type must be one of: web_chat, email, sms, phone_call."
        )
    if direction and direction not in {"inbound", "outbound"}:
        raise typer.BadParameter("direction must be one of: inbound, outbound.")
    if bool(created_at_from) != bool(created_at_to):
        raise typer.BadParameter(
            "Provide both --created-at-from and --created-at-to, or neither."
        )
    if created_at and (created_at_from or created_at_to):
        raise typer.BadParameter(
            "Use either --created-at OR --created-at-from/--created-at-to."
        )
    if created_at_distribution not in {"flat", "daily_peaks", "weekly_peaks"}:
        raise typer.BadParameter(
            "created-at-distribution must be one of: flat, daily_peaks, weekly_peaks."
        )

    try:
        resolved_base_url, resolved_shop_id, resolved_token = resolve_runtime(
            base_url=base_url,
            shop_id=shop_id,
            api_token=api_token,
        )
    except APIError as exc:
        typer.echo(render_api_error(exc, action="resolve runtime for simulation"), err=True)
        raise typer.Exit(code=1) from exc

    successes: list[dict[str, Any]] = []
    failures: list[dict[str, Any]] = []
    for idx in range(count):
        payload: dict[str, Any] = {
            "max_turns": max_turns,
            "is_test": is_test,
            "is_historical": is_historical,
            "created_at_distribution": created_at_distribution,
            "simulate_experiments": simulate_experiments,
            "populate_workforce_actions": populate_workforce_actions,
        }
        if agent_subtype:
            payload["agent_subtype"] = agent_subtype
        if conversation_type:
            payload["conversation_type"] = conversation_type
        if direction:
            payload["direction"] = direction
        if remote_platform:
            payload["remote_platform"] = remote_platform
        if created_at:
            payload["created_at"] = created_at
        if created_at_from and created_at_to:
            payload["created_at_from"] = created_at_from
            payload["created_at_to"] = created_at_to
        if label_id:
            payload["label_id"] = label_id
        if sublabel_id:
            payload["sublabel_id"] = sublabel_id
        if metadata is not None:
            payload["metadata"] = metadata
        if experiment_id:
            payload["experiment_id"] = experiment_id
        if traffic_rule_id:
            payload["traffic_rule_id"] = traffic_rule_id
        if assigned_user_id:
            payload["assigned_user_id"] = assigned_user_id
        if seed is not None or user_model is not None or user_temperature is not None:
            payload["user_llm"] = {}
            if seed is not None:
                payload["user_llm"]["seed"] = seed + idx
            if user_model is not None:
                payload["user_llm"]["model"] = user_model
            if user_temperature is not None:
                payload["user_llm"]["temperature"] = user_temperature

        try:
            result = simulate_agent_conversation(
                base_url=resolved_base_url,
                shop_id=resolved_shop_id,
                api_token=resolved_token,
                agent_id=agent_id,
                payload=payload,
            )
            successes.append(result)
        except APIError as exc:
            failure = {
                "attempt": idx + 1,
                "error": render_api_error(exc, action="simulate conversation"),
            }
            failures.append(failure)
            if not continue_on_error:
                if output_json:
                    typer.echo(
                        json.dumps(
                            {
                                "result": "failed",
                                "success_count": len(successes),
                                "failure_count": len(failures),
                                "failures": failures,
                            },
                            indent=2,
                        )
                    )
                else:
                    typer.echo(failure["error"], err=True)
                raise typer.Exit(code=1) from exc

    summary = {
        "result": "success" if not failures else "partial_success",
        "agent_id": agent_id,
        "count_requested": count,
        "success_count": len(successes),
        "failure_count": len(failures),
        "is_test": is_test,
        "is_historical": is_historical,
        "simulate_experiments": simulate_experiments,
        "populate_workforce_actions": populate_workforce_actions,
        "created_at": created_at,
        "created_at_from": created_at_from,
        "created_at_to": created_at_to,
        "created_at_distribution": created_at_distribution,
        "simulations": successes if output_json else None,
        "failures": failures if failures else None,
    }

    if output_json:
        typer.echo(json.dumps(summary, indent=2, default=str))
        return
    conversation_ids = [
        str(row.get("conversation_id"))
        for row in successes
        if isinstance(row, dict) and row.get("conversation_id")
    ]
    preview_ids = ",".join(conversation_ids[:5]) if conversation_ids else ""

    typer.echo(
        "result="
        + summary["result"]
        + " | "
        + " | ".join(
            [
                f"agent_id={agent_id}",
                f"requested={count}",
                f"success={len(successes)}",
                f"failed={len(failures)}",
                f"is_test={is_test}",
                f"is_historical={is_historical}",
                f"conversation_ids={preview_ids}" if preview_ids else "conversation_ids=(none)",
            ]
        )
    )
