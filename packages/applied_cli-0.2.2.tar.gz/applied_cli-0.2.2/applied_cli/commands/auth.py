import json
import os
import time
import uuid
import webbrowser
from typing import Optional
from urllib.parse import urlsplit, urlunsplit

import typer

from applied_cli.auth_store import (
    clear_credentials,
    get_active_profile_name,
    list_profiles,
    load_credentials,
    save_credentials,
)
from applied_cli.config import (
    DEFAULT_BASE_URL,
    Credentials,
    mask_token,
    normalize_base_url,
)
from applied_cli.error_reporting import render_api_error
from applied_cli.http import (
    APIError,
    list_accessible_shops,
    poll_cli_device_login,
    start_cli_device_login,
    validate_api_token,
)

app = typer.Typer(
    help=(
        "Authenticate applied-cli with an API token.\n\n"
        "Login requires a human to approve in the browser:\n"
        "  applied-cli auth login\n\n"
        "After login, check status and switch shops:\n"
        "  applied-cli auth status              # who you're logged in as and which shop is active\n"
        "  applied-cli auth shops               # list all shops your token can access\n"
        "  applied-cli auth use-shop \"<name>\"  # switch the active shop"
    )
)


def _select_shop_interactively(shops: list[dict[str, object]]) -> tuple[str, str]:
    """Return (shop_id, shop_name) after prompting the user to pick a shop."""
    if not shops:
        raise typer.BadParameter(
            "No accessible shops returned for this token. Pass --shop-id explicitly."
        )
    if len(shops) == 1:
        only = shops[0]
        selected = str(only.get("id") or "")
        name = str(only.get("name") or "(unnamed)")
        if selected:
            typer.echo(f"Using shop: {name} ({selected})")
            return selected, name
        raise typer.BadParameter(
            "Shop response did not include an id. Pass --shop-id explicitly."
        )

    typer.echo("Select a default shop:")
    for idx, shop in enumerate(shops, start=1):
        shop_id = str(shop.get("id") or "")
        name = str(shop.get("name") or "(unnamed)")
        typer.echo(f"{idx}) {name} ({shop_id})")
    choice = typer.prompt("Enter number", default="1").strip()
    try:
        selected_index = int(choice)
    except ValueError as exc:
        raise typer.BadParameter("Selection must be a number.") from exc
    if selected_index < 1 or selected_index > len(shops):
        raise typer.BadParameter("Selection out of range.")
    selected_shop = shops[selected_index - 1]
    selected_shop_id = str(selected_shop.get("id") or "")
    selected_shop_name = str(selected_shop.get("name") or "(unnamed)")
    if not selected_shop_id:
        raise typer.BadParameter(
            "Selected shop does not include an id. Pass --shop-id explicitly."
        )
    return selected_shop_id, selected_shop_name


def _resolve_base_url_for_auth(
    *, endpoint: Optional[str], base_url: Optional[str], existing: Optional[Credentials]
) -> str:
    raw_base_url = (
        base_url
        or endpoint
        or os.getenv("APPLIED_BASE_URL")
        or os.getenv("APPLIED_ENDPOINT")
        or (existing.base_url if existing else "")
        or DEFAULT_BASE_URL
    )
    return normalize_base_url(raw_base_url)


def _looks_like_uuid(value: str) -> bool:
    try:
        uuid.UUID(value)
        return True
    except ValueError:
        return False


def _resolve_profile_name(profile: Optional[str]) -> str:
    return (profile or os.getenv("APPLIED_PROFILE") or get_active_profile_name() or "default").strip()


def _default_token_page_url(base_url: str) -> str:
    parsed = urlsplit(base_url)
    host = parsed.hostname or ""
    if host in {"localhost", "127.0.0.1"}:
        local_host = "localhost" if host == "localhost" else "127.0.0.1"
        return f"http://{local_host}:3000/settings/account/api-tokens"
    return urlunsplit((parsed.scheme, parsed.netloc, "/settings/account/api-tokens", "", ""))


@app.command("login")
def login(
    endpoint: Optional[str] = typer.Option(
        None,
        "--endpoint",
        help="Endpoint alias or URL: prod, dev, local, or full host.",
        envvar="APPLIED_ENDPOINT",
    ),
    shop_id: Optional[str] = typer.Option(
        None, "--shop-id", help="Pre-select a shop UUID instead of prompting.", envvar="APPLIED_SHOP_ID"
    ),
    token: Optional[str] = typer.Option(
        None, "--token", help="Skip browser auth and use this API token directly.", envvar="APPLIED_API_TOKEN"
    ),
    output_json: bool = typer.Option(False, "--json", help="Emit JSON output."),
    # Hidden power-user / compat options
    profile: Optional[str] = typer.Option(None, "--profile", envvar="APPLIED_PROFILE", hidden=True),
    base_url: Optional[str] = typer.Option(None, envvar="APPLIED_BASE_URL", hidden=True),
    token_page_url: Optional[str] = typer.Option(None, envvar="APPLIED_TOKEN_PAGE_URL", hidden=True),
    device: bool = typer.Option(True, "--device/--no-device", hidden=True),
    no_browser: bool = typer.Option(False, "--no-browser", hidden=True),
    device_timeout: float = typer.Option(180.0, hidden=True),
    poll_interval: float = typer.Option(2.0, hidden=True),
    timeout: float = typer.Option(10.0, hidden=True),
) -> None:
    """Sign in or switch to a different shop — opens a browser for human approval, then saves credentials."""
    profile_name = _resolve_profile_name(profile)
    existing = load_credentials(profile=profile_name)
    resolved_base_url = _resolve_base_url_for_auth(
        endpoint=endpoint,
        base_url=base_url,
        existing=existing,
    )
    explicit_shop_id = shop_id or os.getenv("APPLIED_SHOP_ID")
    resolved_shop_id = explicit_shop_id or ""
    resolved_shop_name = ""

    token_page = token_page_url or _default_token_page_url(resolved_base_url)
    browser_opened = False
    resolved_token = token or os.getenv("APPLIED_API_TOKEN")
    if not resolved_token and device:
        try:
            device_start = start_cli_device_login(
                base_url=resolved_base_url,
                timeout_seconds=timeout,
            )
        except APIError as exc:
            if exc.status_code == 404:
                if output_json:
                    typer.echo(
                        json.dumps(
                            {
                                "error": "endpoint_not_found",
                                "message": f"Device login endpoint not found at {resolved_base_url}.",
                                "hint": (
                                    "Specify an endpoint: "
                                    "applied-cli auth login --endpoint prod  "
                                    "or  applied-cli auth login --endpoint local"
                                ),
                            },
                            indent=2,
                        ),
                        err=True,
                    )
                else:
                    typer.echo(
                        f"Device login endpoint not found at {resolved_base_url}.\n"
                        "Is the endpoint correct? Try:\n"
                        "  applied-cli auth login --endpoint prod\n"
                        "  applied-cli auth login --endpoint local",
                        err=True,
                    )
            else:
                typer.echo(render_api_error(exc, action="start device login"), err=True)
            raise typer.Exit(code=1) from exc
        token_page = str(
            device_start.get("verification_uri_complete")
            or device_start.get("verification_uri")
            or device_start.get("verification_url")
            or token_page
        ).strip()
        device_code = str(device_start.get("device_code") or "").strip()
        user_code = str(device_start.get("user_code") or "").strip()
        expires_in = int(device_start.get("expires_in") or 180)
        poll_seconds = float(device_start.get("interval") or poll_interval or 2.0)
        if output_json:
            # Emit approval info immediately so an agent can relay URL+code to the
            # human before blocking on the poll loop. Final result is a second JSON line.
            typer.echo(
                json.dumps(
                    {
                        "status": "pending_approval",
                        "approval_url": token_page,
                        "user_code": user_code or None,
                        "expires_in": expires_in,
                    }
                )
            )
        else:
            typer.echo(f"Approval URL:       {token_page}")
            if user_code:
                typer.echo(f"Verification code:  {user_code}")
                typer.echo("Enter this code in the browser when prompted.")
        if no_browser:
            pass  # URL already printed above
        else:
            browser_opened = webbrowser.open(token_page)
            if not output_json:
                if browser_opened:
                    typer.echo("(Browser opened automatically.)")
                else:
                    typer.echo("(Could not open browser — open the URL above manually.)")
        if not device_code:
            err = APIError(
                "Device login start response missing device code.",
                code="DEVICE_LOGIN_INVALID_RESPONSE",
                hint="Retry `applied-cli auth login`.",
                retryable=True,
            )
            typer.echo(render_api_error(err, action="start device login"), err=True)
            raise typer.Exit(code=1)
        if not output_json:
            typer.echo("Waiting for browser approval...")
        deadline = time.monotonic() + min(device_timeout, float(expires_in))
        _auth_start = time.monotonic()
        _last_progress = _auth_start
        while time.monotonic() < deadline:
            try:
                poll = poll_cli_device_login(
                    base_url=resolved_base_url,
                    device_code=device_code,
                    timeout_seconds=timeout,
                )
            except APIError as exc:
                typer.echo(render_api_error(exc, action="poll device login"), err=True)
                raise typer.Exit(code=1) from exc
            status_value = str(poll.get("status") or "pending").strip().lower()
            if status_value == "approved":
                resolved_token = str(poll.get("api_token") or "").strip()
                discovered_shop_id = str(poll.get("shop_id") or "").strip()
                if discovered_shop_id and not resolved_shop_id:
                    resolved_shop_id = discovered_shop_id
                break
            if status_value in {"expired", "denied"}:
                err = APIError(
                    f"Device login {status_value}.",
                    code=f"DEVICE_LOGIN_{status_value.upper()}",
                    hint="Run `applied-cli auth login` and approve in browser again.",
                    retryable=False,
                )
                typer.echo(render_api_error(err, action="log in"), err=True)
                raise typer.Exit(code=1)
            _now = time.monotonic()
            if not output_json and _now - _last_progress >= 15:
                _elapsed = int(_now - _auth_start)
                typer.echo(
                    f"Still waiting for browser approval... ({_elapsed}s elapsed)"
                )
                _last_progress = _now
            time.sleep(max(0.5, poll_seconds))
        if not resolved_token:
            err = APIError(
                "Timed out waiting for browser approval.",
                code="DEVICE_LOGIN_TIMEOUT",
                hint="Approve login in browser sooner or increase --device-timeout.",
                retryable=True,
            )
            typer.echo(render_api_error(err, action="log in"), err=True)
            raise typer.Exit(code=1)
    elif not resolved_token:
        if no_browser:
            if not output_json:
                typer.echo(f"Open this page to create a token:\n{token_page}")
        else:
            browser_opened = webbrowser.open(token_page)
            if not output_json:
                if browser_opened:
                    typer.echo(f"Opened token page:\n{token_page}")
                else:
                    typer.echo(f"Could not open browser. Create token here:\n{token_page}")
        resolved_token = typer.prompt(
            "Paste API token",
            hide_input=True,
            confirmation_prompt=False,
        ).strip()

    # Best-effort: if we already have a shop_id but no name (e.g. from device auth poll),
    # try to resolve the name from the accessible-shops list now that we have a token.
    if resolved_shop_id and not resolved_shop_name:
        try:
            shops_for_name = list_accessible_shops(
                base_url=resolved_base_url,
                api_token=resolved_token,
                timeout_seconds=timeout,
            )
            name_match = next(
                (r for r in shops_for_name if str(r.get("id")) == resolved_shop_id), None
            )
            if name_match:
                resolved_shop_name = str(name_match.get("name") or "")
        except APIError:
            pass  # Name is nice-to-have; continue without it

    used_existing_shop_fallback = False
    if not resolved_shop_id:
        try:
            shops = list_accessible_shops(
                base_url=resolved_base_url,
                api_token=resolved_token,
                timeout_seconds=timeout,
            )
        except APIError:
            shops = []
        if shops:
            if output_json:
                if len(shops) == 1 and shops[0].get("id"):
                    resolved_shop_id = str(shops[0]["id"])
                    resolved_shop_name = str(shops[0].get("name") or "")
                else:
                    raise APIError(
                        "Multiple shops available; choose one with --shop-id.",
                        code="MISSING_SHOP_ID",
                        hint="Pass --shop-id explicitly or run interactive auth login.",
                        retryable=False,
                    )
            else:
                resolved_shop_id, resolved_shop_name = _select_shop_interactively(shops)
        if not resolved_shop_id:
            # Last resort fallback: use profile default if available, else prompt.
            if existing and existing.shop_id:
                resolved_shop_id = existing.shop_id
                used_existing_shop_fallback = True
                if not output_json:
                    typer.echo(
                        f"Using existing profile default shop: {resolved_shop_id}"
                    )
            else:
                resolved_shop_id = typer.prompt("Shop ID").strip()

    if not output_json:
        typer.echo("Validating token against Applied API...")
    try:
        validate_api_token(
            base_url=resolved_base_url,
            shop_id=resolved_shop_id,
            api_token=resolved_token,
            timeout_seconds=timeout,
        )
    except APIError as exc:
        # Common local UX issue: stored default shop does not match pasted token.
        # If we auto-selected the existing shop and auth fails, prompt once for a new shop.
        if (
            not output_json
            and used_existing_shop_fallback
            and exc.status_code in {401, 403}
            and not explicit_shop_id
        ):
            typer.echo(
                "Token is not valid for the current default shop. "
                "Please enter a shop ID for this token."
            )
            resolved_shop_id = typer.prompt("Shop ID").strip()
            if not resolved_shop_id:
                typer.echo(render_api_error(exc, action="log in"), err=True)
                raise typer.Exit(code=1) from exc
            if not output_json:
                typer.echo("Re-validating token with provided shop...")
            try:
                validate_api_token(
                    base_url=resolved_base_url,
                    shop_id=resolved_shop_id,
                    api_token=resolved_token,
                    timeout_seconds=timeout,
                )
            except APIError as retry_exc:
                typer.echo(render_api_error(retry_exc, action="log in"), err=True)
                raise typer.Exit(code=1) from retry_exc
        else:
            typer.echo(render_api_error(exc, action="log in"), err=True)
            raise typer.Exit(code=1) from exc

    save_credentials(
        Credentials(
            base_url=resolved_base_url,
            shop_id=resolved_shop_id,
            api_token=resolved_token,
        ),
        profile=profile_name,
        set_active=True,
    )
    shop_label = (
        f"{resolved_shop_name} ({resolved_shop_id})" if resolved_shop_name else resolved_shop_id
    )
    if output_json:
        _login_result: dict = {
            "logged_in": True,
            "endpoint": resolved_base_url,
            "shop_id": resolved_shop_id,
            "token_masked": mask_token(resolved_token),
        }
        if resolved_shop_name:
            _login_result["shop_name"] = resolved_shop_name
        typer.echo(json.dumps(_login_result, indent=2))
        return
    typer.echo("Login successful.")
    typer.echo(f"- shop: {shop_label}")
    typer.echo(f"- endpoint: {resolved_base_url}")
    typer.echo(f"- token: {mask_token(resolved_token)}")
    typer.echo("")
    typer.echo("To see all shops:   applied-cli auth shops")
    typer.echo("To switch shops:    applied-cli auth use-shop \"<shop name or uuid>\"")


@app.command("status")
def status(
    output_json: bool = typer.Option(False, "--json", help="Emit JSON output."),
    # Hidden options
    profile: Optional[str] = typer.Option(None, "--profile", envvar="APPLIED_PROFILE", hidden=True),
    verify: bool = typer.Option(True, "--verify/--no-verify", hidden=True),
    timeout: float = typer.Option(10.0, hidden=True),
) -> None:
    """Show current authentication state and active shop."""
    profile_name = _resolve_profile_name(profile)
    creds = load_credentials(profile=profile_name)
    if not creds:
        if output_json:
            typer.echo(
                json.dumps(
                    {"logged_in": False, "verified": False, "message": "Not logged in."},
                    indent=2,
                )
            )
        else:
            typer.echo("Not logged in. Run: applied-cli auth login")
        raise typer.Exit(code=1)

    if not output_json:
        typer.echo("Logged in:")
        typer.echo(f"- endpoint: {creds.base_url}")
        typer.echo(f"- shop_id: {creds.shop_id}")
        typer.echo(f"- token: {mask_token(creds.api_token)}")

    if not verify:
        if output_json:
            typer.echo(
                json.dumps(
                    {
                        "logged_in": True,
                        "endpoint": creds.base_url,
                        "shop_id": creds.shop_id,
                        "token_masked": mask_token(creds.api_token),
                        "verified": False,
                    },
                    indent=2,
                )
            )
        return

    if not output_json:
        typer.echo("Verifying token...")
    try:
        validate_api_token(
            base_url=creds.base_url,
            shop_id=creds.shop_id,
            api_token=creds.api_token,
            timeout_seconds=timeout,
        )
    except APIError as exc:
        typer.echo(render_api_error(exc, action="check auth status"), err=True)
        raise typer.Exit(code=1) from exc

    if output_json:
        typer.echo(
            json.dumps(
                {
                    "logged_in": True,
                    "endpoint": creds.base_url,
                    "shop_id": creds.shop_id,
                    "token_masked": mask_token(creds.api_token),
                    "verified": True,
                },
                indent=2,
            )
        )
        return
    typer.echo("Token is valid.")
    typer.echo("")
    typer.echo("To see all shops:   applied-cli auth shops")
    typer.echo("To switch shops:    applied-cli auth use-shop \"<shop name or uuid>\"")


@app.command("shops")
def shops(
    output_json: bool = typer.Option(False, "--json", help="Emit JSON output."),
    # Hidden options
    profile: Optional[str] = typer.Option(None, "--profile", envvar="APPLIED_PROFILE", hidden=True),
    endpoint: Optional[str] = typer.Option(None, "--endpoint", envvar="APPLIED_ENDPOINT", hidden=True),
    base_url: Optional[str] = typer.Option(None, envvar="APPLIED_BASE_URL", hidden=True),
    token: Optional[str] = typer.Option(None, "--token", envvar="APPLIED_API_TOKEN", hidden=True),
    timeout: float = typer.Option(10.0, hidden=True),
) -> None:
    """List all shops your token can access."""
    profile_name = _resolve_profile_name(profile)
    creds = load_credentials(profile=profile_name)
    resolved_base_url = _resolve_base_url_for_auth(
        endpoint=endpoint,
        base_url=base_url,
        existing=creds,
    )
    resolved_token = token or os.getenv("APPLIED_API_TOKEN") or (
        creds.api_token if creds else ""
    )
    if not resolved_token:
        raise typer.BadParameter(
            "Not logged in. Run `applied-cli auth login` first."
        )
    try:
        shops_rows = list_accessible_shops(
            base_url=resolved_base_url,
            api_token=resolved_token,
            timeout_seconds=timeout,
        )
    except APIError as exc:
        if exc.status_code in {401, 403}:
            if output_json:
                typer.echo(
                    json.dumps(
                        {
                            "error": "permission_denied",
                            "message": "Your token does not have permission to list shops.",
                            "hint": (
                                "To switch shops, re-authenticate: applied-cli auth login  "
                                "or if you know the shop UUID: applied-cli auth use-shop <uuid>"
                            ),
                        },
                        indent=2,
                    ),
                    err=True,
                )
            else:
                typer.echo(
                    "Your token does not have permission to list shops.\n"
                    "To switch shops, re-authenticate and select the shop in the browser:\n"
                    "  applied-cli auth login\n"
                    "Or if you know the shop UUID:\n"
                    "  applied-cli auth use-shop <uuid>",
                    err=True,
                )
        else:
            typer.echo(render_api_error(exc, action="list accessible shops"), err=True)
        raise typer.Exit(code=1) from exc

    if output_json:
        typer.echo(
            json.dumps(
                {
                    "endpoint": resolved_base_url,
                    "count": len(shops_rows),
                    "shops": shops_rows,
                },
                indent=2,
            )
        )
        return
    if not shops_rows:
        typer.echo("No accessible shops returned for this token.")
        return
    current_shop_id = creds.shop_id if creds else ""
    for row in shops_rows:
        active_marker = "  (active)" if str(row.get("id")) == current_shop_id else ""
        typer.echo(f"id={row.get('id')} | name={row.get('name') or '(unnamed)'}{active_marker}")
    typer.echo("")
    typer.echo("To switch: applied-cli auth use-shop \"<shop name or uuid>\"")


@app.command("use-shop")
def use_shop(
    shop: str = typer.Argument(..., help="Shop name or UUID."),
    output_json: bool = typer.Option(False, "--json", help="Emit JSON output."),
    # Hidden options
    profile: Optional[str] = typer.Option(None, "--profile", envvar="APPLIED_PROFILE", hidden=True),
    endpoint: Optional[str] = typer.Option(None, "--endpoint", envvar="APPLIED_ENDPOINT", hidden=True),
    base_url: Optional[str] = typer.Option(None, envvar="APPLIED_BASE_URL", hidden=True),
    token: Optional[str] = typer.Option(None, "--token", envvar="APPLIED_API_TOKEN", hidden=True),
    timeout: float = typer.Option(10.0, hidden=True),
) -> None:
    """Switch the active shop by name or UUID."""
    profile_name = _resolve_profile_name(profile)
    existing = load_credentials(profile=profile_name)
    if not existing and not token:
        raise typer.BadParameter(
            "Not logged in. Run `applied-cli auth login` first."
        )
    resolved_base_url = _resolve_base_url_for_auth(
        endpoint=endpoint,
        base_url=base_url,
        existing=existing,
    )
    resolved_token = token or os.getenv("APPLIED_API_TOKEN") or (
        existing.api_token if existing else ""
    )
    if not resolved_token:
        raise typer.BadParameter("Not logged in. Run `applied-cli auth login` first.")

    selected_shop_id = ""
    selected_shop_name = ""
    try:
        shops_rows = list_accessible_shops(
            base_url=resolved_base_url,
            api_token=resolved_token,
            timeout_seconds=timeout,
        )
    except APIError:
        shops_rows = []

    if shops_rows:
        if _looks_like_uuid(shop):
            matched = next((row for row in shops_rows if str(row.get("id")) == shop), None)
        else:
            matched = next(
                (
                    row
                    for row in shops_rows
                    if str(row.get("name") or "").strip().lower() == shop.strip().lower()
                ),
                None,
            )
        if matched:
            selected_shop_id = str(matched.get("id") or "")
            selected_shop_name = str(matched.get("name") or "")
        else:
            raise typer.BadParameter(
                "Shop not found in accessible shops for this token. "
                "Run `applied-cli auth shops` to see valid choices."
            )
    else:
        if not _looks_like_uuid(shop):
            raise typer.BadParameter(
                "Could not fetch shops from API. Pass a shop UUID instead of name."
            )
        selected_shop_id = shop

    # Validate the token works for the selected shop before committing the change.
    try:
        validate_api_token(
            base_url=resolved_base_url,
            shop_id=selected_shop_id,
            api_token=resolved_token,
            timeout_seconds=timeout,
        )
    except APIError as exc:
        if exc.status_code in {401, 403}:
            if output_json:
                typer.echo(
                    json.dumps(
                        {
                            "error": "token_invalid_for_shop",
                            "message": f"Your current token is not valid for shop {selected_shop_id}.",
                            "hint": "Run `applied-cli auth login` to re-authenticate for a different shop.",
                        },
                        indent=2,
                    ),
                    err=True,
                )
            else:
                typer.echo(
                    f"Your current token is not valid for shop {selected_shop_id}.\n"
                    "To switch shops, re-authenticate and select the shop in the browser:\n"
                    "  applied-cli auth login",
                    err=True,
                )
        else:
            typer.echo(render_api_error(exc, action="validate shop access"), err=True)
        raise typer.Exit(code=1) from exc

    save_credentials(
        Credentials(
            base_url=resolved_base_url,
            shop_id=selected_shop_id,
            api_token=resolved_token,
        ),
        profile=profile_name,
        set_active=True,
    )

    shop_label = (
        f"{selected_shop_name} ({selected_shop_id})" if selected_shop_name else selected_shop_id
    )
    if output_json:
        _use_shop_result: dict = {
            "updated": True,
            "shop_id": selected_shop_id,
        }
        if selected_shop_name:
            _use_shop_result["shop_name"] = selected_shop_name
        typer.echo(json.dumps(_use_shop_result, indent=2))
        return
    typer.echo(f"Active shop: {shop_label}")
    typer.echo("")
    typer.echo("To see all shops:   applied-cli auth shops")
    typer.echo("To switch again:    applied-cli auth use-shop \"<shop name or uuid>\"")


@app.command("login-start")
def login_start(
    endpoint: Optional[str] = typer.Option(
        None,
        "--endpoint",
        help="Endpoint alias or URL: prod, dev, local, or full host.",
        envvar="APPLIED_ENDPOINT",
    ),
    output_json: bool = typer.Option(False, "--json", help="Emit JSON output."),
    # Hidden options
    base_url: Optional[str] = typer.Option(None, envvar="APPLIED_BASE_URL", hidden=True),
    timeout: float = typer.Option(10.0, hidden=True),
) -> None:
    """Start device login flow and return approval URL (non-blocking).

    This command starts the OAuth device flow and immediately returns the
    approval URL and device code. Use `login-complete` to finish authentication
    after the user approves in their browser.

    Example:
        applied-cli auth login-start --json
        # User visits URL and approves
        applied-cli auth login-complete --device-code <code> --json
    """
    resolved_base_url = _resolve_base_url_for_auth(
        endpoint=endpoint,
        base_url=base_url,
        existing=None,
    )

    try:
        device_start = start_cli_device_login(
            base_url=resolved_base_url,
            timeout_seconds=timeout,
        )
    except APIError as exc:
        if exc.status_code == 404:
            if output_json:
                typer.echo(
                    json.dumps(
                        {
                            "success": False,
                            "error": "endpoint_not_found",
                            "message": f"Device login endpoint not found at {resolved_base_url}.",
                            "hint": "Specify an endpoint: --endpoint prod or --endpoint local",
                        },
                        indent=2,
                    ),
                    err=True,
                )
            else:
                typer.echo(
                    f"Device login endpoint not found at {resolved_base_url}.\n"
                    "Try: applied-cli auth login-start --endpoint prod",
                    err=True,
                )
            raise typer.Exit(code=1) from exc
        typer.echo(render_api_error(exc, action="start device login"), err=True)
        raise typer.Exit(code=1) from exc

    approval_url = str(
        device_start.get("verification_uri_complete")
        or device_start.get("verification_uri")
        or device_start.get("verification_url")
        or ""
    ).strip()
    device_code = str(device_start.get("device_code") or "").strip()
    user_code = str(device_start.get("user_code") or "").strip()
    expires_in = int(device_start.get("expires_in") or 180)

    if not device_code:
        err_msg = "Device login start response missing device code."
        if output_json:
            typer.echo(
                json.dumps({"success": False, "error": "invalid_response", "message": err_msg}),
                err=True,
            )
        else:
            typer.echo(err_msg, err=True)
        raise typer.Exit(code=1)

    result = {
        "success": True,
        "status": "pending_approval",
        "approval_url": approval_url,
        "device_code": device_code,
        "user_code": user_code or None,
        "expires_in": expires_in,
        "endpoint": resolved_base_url,
        "next_step": "Visit the approval URL, then run: applied-cli auth login-complete --device-code <device_code>",
    }

    if output_json:
        typer.echo(json.dumps(result, indent=2))
    else:
        typer.echo(f"Approval URL: {approval_url}")
        if user_code:
            typer.echo(f"User code: {user_code}")
        typer.echo(f"Device code: {device_code}")
        typer.echo(f"Expires in: {expires_in} seconds")
        typer.echo("")
        typer.echo("After approving in browser, run:")
        typer.echo(f"  applied-cli auth login-complete --device-code {device_code}")


@app.command("login-complete")
def login_complete(
    device_code: str = typer.Option(..., "--device-code", help="Device code from login-start."),
    endpoint: Optional[str] = typer.Option(
        None,
        "--endpoint",
        help="Endpoint alias or URL (must match login-start).",
        envvar="APPLIED_ENDPOINT",
    ),
    shop_id: Optional[str] = typer.Option(
        None, "--shop-id", help="Pre-select a shop UUID.", envvar="APPLIED_SHOP_ID"
    ),
    output_json: bool = typer.Option(False, "--json", help="Emit JSON output."),
    # Hidden options
    profile: Optional[str] = typer.Option(None, "--profile", envvar="APPLIED_PROFILE", hidden=True),
    base_url: Optional[str] = typer.Option(None, envvar="APPLIED_BASE_URL", hidden=True),
    timeout: float = typer.Option(10.0, hidden=True),
    max_attempts: int = typer.Option(3, hidden=True),
    poll_interval: float = typer.Option(2.0, hidden=True),
) -> None:
    """Complete device login after user approves in browser.

    Polls the API to check if the user has approved the login request.
    If approved, saves credentials and selects a shop.

    Example:
        applied-cli auth login-complete --device-code abc123 --json
    """
    profile_name = _resolve_profile_name(profile)
    resolved_base_url = _resolve_base_url_for_auth(
        endpoint=endpoint,
        base_url=base_url,
        existing=None,
    )
    explicit_shop_id = shop_id or os.getenv("APPLIED_SHOP_ID")

    # Poll for approval (with limited attempts for non-blocking behavior)
    resolved_token = None
    resolved_shop_id = explicit_shop_id or ""
    resolved_shop_name = ""

    for attempt in range(max_attempts):
        try:
            poll = poll_cli_device_login(
                base_url=resolved_base_url,
                device_code=device_code,
                timeout_seconds=timeout,
            )
        except APIError as exc:
            if output_json:
                typer.echo(
                    json.dumps(
                        {"success": False, "error": "poll_failed", "message": str(exc)},
                        indent=2,
                    ),
                    err=True,
                )
            else:
                typer.echo(render_api_error(exc, action="poll device login"), err=True)
            raise typer.Exit(code=1) from exc

        status_value = str(poll.get("status") or "pending").strip().lower()

        if status_value == "approved":
            resolved_token = str(poll.get("api_token") or "").strip()
            discovered_shop_id = str(poll.get("shop_id") or "").strip()
            if discovered_shop_id and not resolved_shop_id:
                resolved_shop_id = discovered_shop_id
            break
        elif status_value in {"expired", "denied"}:
            err_result = {
                "success": False,
                "error": f"login_{status_value}",
                "message": f"Device login {status_value}.",
                "hint": "Run `applied-cli auth login-start` again to get a new approval URL.",
            }
            if output_json:
                typer.echo(json.dumps(err_result, indent=2), err=True)
            else:
                typer.echo(f"Device login {status_value}. Start a new login flow.", err=True)
            raise typer.Exit(code=1)
        else:
            # Still pending
            if attempt < max_attempts - 1:
                time.sleep(poll_interval)

    if not resolved_token:
        pending_result = {
            "success": False,
            "status": "pending",
            "message": "Login not yet approved. User must visit the approval URL first.",
            "hint": "Wait for user to approve in browser, then retry this command.",
        }
        if output_json:
            typer.echo(json.dumps(pending_result, indent=2))
        else:
            typer.echo("Login not yet approved. Please approve in browser first.")
        raise typer.Exit(code=1)

    # Resolve shop name if we have an ID
    if resolved_shop_id and not resolved_shop_name:
        try:
            shops_for_name = list_accessible_shops(
                base_url=resolved_base_url,
                api_token=resolved_token,
                timeout_seconds=timeout,
            )
            name_match = next(
                (r for r in shops_for_name if str(r.get("id")) == resolved_shop_id), None
            )
            if name_match:
                resolved_shop_name = str(name_match.get("name") or "")
        except APIError:
            pass

    # If no shop_id yet, try to auto-select (single shop) or require explicit selection
    if not resolved_shop_id:
        try:
            shops = list_accessible_shops(
                base_url=resolved_base_url,
                api_token=resolved_token,
                timeout_seconds=timeout,
            )
        except APIError:
            shops = []

        if shops:
            if len(shops) == 1 and shops[0].get("id"):
                resolved_shop_id = str(shops[0]["id"])
                resolved_shop_name = str(shops[0].get("name") or "")
            elif output_json:
                # Multiple shops - return them for selection
                typer.echo(
                    json.dumps(
                        {
                            "success": False,
                            "error": "shop_selection_required",
                            "message": "Multiple shops available. Specify --shop-id.",
                            "available_shops": shops,
                        },
                        indent=2,
                    )
                )
                raise typer.Exit(code=1)
            else:
                resolved_shop_id, resolved_shop_name = _select_shop_interactively(shops)

    if not resolved_shop_id:
        err_result = {
            "success": False,
            "error": "missing_shop_id",
            "message": "Could not determine shop. Pass --shop-id explicitly.",
        }
        if output_json:
            typer.echo(json.dumps(err_result, indent=2), err=True)
        else:
            typer.echo("Could not determine shop. Pass --shop-id.", err=True)
        raise typer.Exit(code=1)

    # Validate token against shop
    try:
        validate_api_token(
            base_url=resolved_base_url,
            shop_id=resolved_shop_id,
            api_token=resolved_token,
            timeout_seconds=timeout,
        )
    except APIError as exc:
        if output_json:
            typer.echo(
                json.dumps(
                    {
                        "success": False,
                        "error": "validation_failed",
                        "message": str(exc),
                    },
                    indent=2,
                ),
                err=True,
            )
        else:
            typer.echo(render_api_error(exc, action="validate token"), err=True)
        raise typer.Exit(code=1) from exc

    # Save credentials
    save_credentials(
        Credentials(
            base_url=resolved_base_url,
            shop_id=resolved_shop_id,
            api_token=resolved_token,
        ),
        profile=profile_name,
        set_active=True,
    )

    shop_label = (
        f"{resolved_shop_name} ({resolved_shop_id})" if resolved_shop_name else resolved_shop_id
    )

    if output_json:
        result: dict = {
            "success": True,
            "logged_in": True,
            "endpoint": resolved_base_url,
            "shop_id": resolved_shop_id,
            "token_masked": mask_token(resolved_token),
        }
        if resolved_shop_name:
            result["shop_name"] = resolved_shop_name
        typer.echo(json.dumps(result, indent=2))
        return

    typer.echo("Login successful!")
    typer.echo(f"- shop: {shop_label}")
    typer.echo(f"- endpoint: {resolved_base_url}")
    typer.echo(f"- token: {mask_token(resolved_token)}")


@app.command("logout")
def logout(
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt."),
    output_json: bool = typer.Option(False, "--json", help="Emit JSON output."),
) -> None:
    """Remove all stored credentials and log out."""
    had_credentials = bool(list_profiles())
    if had_credentials and not yes and not output_json:
        if not typer.confirm("Remove stored credentials and log out?"):
            raise typer.Exit(code=1)
    clear_credentials()
    if output_json:
        typer.echo(
            json.dumps({"logged_out": True}, indent=2)
        )
        return
    typer.echo("Logged out.")
