import json
import uuid
from typing import Any, Optional

import typer


def validate_uuid(value: str, *, field_name: str) -> None:
    try:
        uuid.UUID(value)
    except ValueError as exc:
        raise typer.BadParameter(f"{field_name} must be a valid UUID.") from exc


def parse_optional_bool(raw: Optional[str], *, field_name: str) -> Optional[bool]:
    if raw is None:
        return None
    normalized = raw.strip().lower()
    if normalized in {"1", "true", "t", "yes", "y"}:
        return True
    if normalized in {"0", "false", "f", "no", "n"}:
        return False
    raise typer.BadParameter(f"{field_name} expected one of: true/false/1/0/yes/no")


def parse_json_dict(raw: Optional[str], *, field_name: str) -> Optional[dict[str, Any]]:
    if raw is None:
        return None
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise typer.BadParameter(f"{field_name} must be valid JSON.") from exc
    if not isinstance(parsed, dict):
        raise typer.BadParameter(f"{field_name} must decode to a JSON object.")
    return parsed


def parse_json_array(raw: Optional[str], *, field_name: str) -> Optional[list[Any]]:
    if raw is None:
        return None
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise typer.BadParameter(f"{field_name} must be valid JSON.") from exc
    if not isinstance(parsed, list):
        raise typer.BadParameter(f"{field_name} must decode to a JSON array.")
    return parsed


def parse_csv_list(raw: Optional[str]) -> list[str]:
    if not raw:
        return []
    return [token.strip() for token in raw.split(",") if token.strip()]


def validate_uuid_list(values: list[str], *, field_name: str) -> None:
    for value in values:
        validate_uuid(value, field_name=field_name)
