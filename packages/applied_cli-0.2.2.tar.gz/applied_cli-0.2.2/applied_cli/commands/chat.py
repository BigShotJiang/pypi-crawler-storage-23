import json
import re
import uuid
from typing import Optional

import httpx
import typer

from applied_cli.commands._hints import suggest_value
from applied_cli.commands._ui import confirm_or_exit, emit_success, show_target
from applied_cli.error_reporting import render_api_error
from applied_cli.http import APIError
from applied_cli.runtime import resolve_runtime

app = typer.Typer(help="Chat with an agent using v1 completion.")

MESSAGE_REGEX = re.compile(
    r"(\{(?:(\{(?:(\{(?:(\{(?:(\{(?:(\{(?:(\{(?:(\{(?:(\{[^}{]*\})|[^}{])*\})|[^}{])*\})|[^}{])*\})|[^}{])*\})|[^}{])*\})|[^}{])*\})|[^}{])*\})|[^}{])*\})"
)


def _headers(shop_id: str, api_token: str) -> dict[str, str]:
    return {
        "Authorization": f"Bearer {api_token}",
        "X-Shop-Id": shop_id,
        "Content-Type": "application/json",
    }


def _verify_agent_scope(
    client: httpx.Client,
    *,
    base_url: str,
    shop_id: str,
    api_token: str,
    agent_id: str,
) -> dict[str, object]:
    try:
        response = client.get(
            f"{base_url}/v1/agents/{agent_id}/",
            headers=_headers(shop_id, api_token),
            timeout=10.0,
        )
    except httpx.HTTPError as exc:
        raise APIError(
            f"Agent scope check failed to reach server: {exc}",
            code="NETWORK_ERROR",
            hint="Check APPLIED_BASE_URL and confirm the server is reachable.",
            retryable=True,
            method="GET",
            url=f"{base_url}/v1/agents/{agent_id}/",
            suggestions=[
                "Verify `applied-cli auth status` succeeds.",
                "If running locally, confirm server is up on http://localhost:8000.",
            ],
        ) from exc
    if response.status_code >= 400:
        try:
            detail = response.json()
        except Exception:
            detail = response.text
        code = "AGENT_SCOPE_CHECK_FAILED"
        hint = "Verify --agent-id, --shop-id, and token permissions."
        suggestions = [
            "Run `applied-cli auth status` to verify token validity.",
            "Confirm the agent belongs to the selected shop.",
        ]
        if response.status_code == 401:
            code = "AUTH_INVALID_TOKEN"
            hint = "Token rejected while reading agent scope."
            suggestions.insert(0, "Run `applied-cli auth login` with a fresh token.")
        elif response.status_code == 403:
            code = "SHOP_SCOPE_FORBIDDEN"
            hint = "Token does not have permission for this shop or agent."
        elif response.status_code == 404:
            code = "AGENT_NOT_FOUND"
            hint = "Agent was not found in the selected shop scope."
        raise APIError(
            f"Agent/shop scope check failed ({response.status_code}).",
            status_code=response.status_code,
            code=code,
            hint=hint,
            retryable=response.status_code >= 500,
            method="GET",
            url=f"{base_url}/v1/agents/{agent_id}/",
            detail=detail,
            suggestions=suggestions,
        )
    try:
        data = response.json()
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def _create_conversation(
    client: httpx.Client,
    *,
    base_url: str,
    agent_id: str,
    channel: str,
) -> str:
    payload: dict[str, object] = {
        "agent_id": agent_id,
        "is_test": True,
        "metadata": {
            "isTest": True,
            "source": "applied-cli",
            "context": {"channel": channel},
        },
    }
    if channel == "email":
        payload["type"] = "email"
    elif channel == "sms":
        payload["type"] = "sms"

    try:
        response = client.post(
            f"{base_url}/v1/c/",
            json=payload,
            headers={"Content-Type": "application/json"},
            timeout=10.0,
        )
    except httpx.HTTPError as exc:
        raise APIError(
            f"Conversation init failed to reach server: {exc}",
            code="NETWORK_ERROR",
            hint="Check APPLIED_BASE_URL and confirm the server is reachable.",
            retryable=True,
            method="POST",
            url=f"{base_url}/v1/c/",
            suggestions=[
                "Verify local server availability.",
                "Retry after confirming token/shop scope.",
            ],
        ) from exc
    if response.status_code >= 400:
        try:
            detail = response.json()
        except Exception:
            detail = response.text
        raise APIError(
            f"Conversation init failed ({response.status_code}).",
            status_code=response.status_code,
            code="CONVERSATION_CREATE_FAILED",
            hint="Conversation bootstrap failed before completion call.",
            retryable=response.status_code >= 500,
            method="POST",
            url=f"{base_url}/v1/c/",
            detail=detail,
            suggestions=[
                "Verify agent modality and requested --channel are compatible.",
                "Check token/shop scope can create test conversations.",
            ],
        )

    data = response.json()
    conversation_id = data.get("id")
    if not conversation_id:
        raise APIError("Conversation init succeeded but no conversation id returned.")
    return str(conversation_id)


def _stream_v1_completion(
    client: httpx.Client,
    *,
    base_url: str,
    shop_id: str,
    api_token: str,
    agent_id: str,
    payload: dict[str, object],
) -> str:
    generated_text = ""
    buffer = ""
    content_complete_seen = False
    read_after_complete = False
    with client.stream(
        "POST",
        f"{base_url}/v1/agents/{agent_id}/complete/",
        headers=_headers(shop_id, api_token),
        json=payload,
        timeout=60.0,
    ) as response:
        if response.status_code >= 400:
            try:
                detail = response.json()
            except Exception:
                detail = response.text
            raise APIError(
                f"Completion failed ({response.status_code}).",
                status_code=response.status_code,
                code="COMPLETION_REQUEST_FAILED",
                hint="Completion endpoint returned an error for this payload.",
                retryable=response.status_code >= 500,
                method="POST",
                url=f"{base_url}/v1/agents/{agent_id}/complete/",
                detail=detail,
                suggestions=[
                    "Verify `context` and transcript payload shape.",
                    "Confirm agent is active and has a valid completion configuration.",
                ],
            )

        for chunk in response.iter_text():
            if not chunk:
                continue
            buffer += chunk
            last_consumed = 0
            for match in MESSAGE_REGEX.finditer(buffer):
                raw = match.group(1)
                if not raw:
                    continue
                try:
                    data = json.loads(raw)
                except json.JSONDecodeError:
                    continue
                last_consumed = match.end()
                content = data.get("content")
                if isinstance(content, str) and content:
                    generated_text += content
                    typer.echo(content, nl=False)
                if bool(data.get("content_complete")):
                    content_complete_seen = True
            if last_consumed > 0:
                buffer = buffer[last_consumed:]
            if content_complete_seen:
                if read_after_complete:
                    break
                # Read one additional chunk to allow server-side post-stream save hooks.
                read_after_complete = True

    return generated_text


@app.command(
    "send",
    help=(
        "Send one message to an agent. Example: applied-cli chat send --agent-id <uuid> "
        "--channel chat --message 'How much does a Ripple cost?'"
    ),
)
def send(
    agent_id: str = typer.Option(
        ..., "--agent-id", "--agent", "--id", help="Target agent UUID."
    ),
    message: Optional[str] = typer.Option(
        None, "--message", "-m", help="User message. If omitted, prompt interactively."
    ),
    channel: str = typer.Option(
        "chat", help="Channel mode: chat, email, or sms.", case_sensitive=False
    ),
    context: str = typer.Option(
        "EVALUATE", help="Completion context (e.g., EVALUATE, LIVE, DEVELOPMENT)."
    ),
    conversation_id: Optional[str] = typer.Option(
        None,
        "--conversation-id",
        "--conversation",
        help="Existing conversation UUID. If omitted, create a test conversation.",
    ),
    draft: bool = typer.Option(False, help="Do not persist completion when possible."),
    base_url: Optional[str] = typer.Option(None, help="Applied base URL."),
    shop_id: Optional[str] = typer.Option(None, help="Target shop UUID."),
    api_token: Optional[str] = typer.Option(None, help="Applied API token."),
    yes: bool = typer.Option(
        False,
        "--yes",
        "-y",
        help="Skip safety confirmation prompt.",
    ),
) -> None:
    try:
        uuid.UUID(agent_id)
    except ValueError as exc:
        raise typer.BadParameter(
            "agent-id must be a valid UUID (example: 7ef9c71d-6ea8-42a9-9878-b496ed5f830d)"
        ) from exc

    normalized_channel = channel.lower().strip()
    if normalized_channel not in {"chat", "email", "sms"}:
        suggestion = suggest_value(normalized_channel, ["chat", "email", "sms"])
        hint = f" Did you mean '{suggestion}'?" if suggestion else ""
        raise typer.BadParameter(f"channel must be one of: chat, email, sms.{hint}")

    prompt_message = (message or "").strip()
    if not prompt_message:
        prompt_message = typer.prompt("Message").strip()
    if not prompt_message:
        raise typer.BadParameter("message cannot be empty")

    try:
        resolved_base_url, resolved_shop_id, resolved_token = resolve_runtime(
            base_url=base_url,
            shop_id=shop_id,
            api_token=api_token,
        )
    except APIError as exc:
        typer.echo(render_api_error(exc, action="resolve runtime for chat"), err=True)
        raise typer.Exit(code=1) from exc

    show_target(
        {
            "base_url": resolved_base_url,
            "shop_id": resolved_shop_id,
            "agent_id": agent_id,
            "channel": normalized_channel,
        }
    )
    confirm_or_exit(yes=yes)

    with httpx.Client() as client:
        try:
            agent_payload = _verify_agent_scope(
                client,
                base_url=resolved_base_url,
                shop_id=resolved_shop_id,
                api_token=resolved_token,
                agent_id=agent_id,
            )
            if agent_payload.get("auto_reply") is False:
                typer.echo(
                    "Warning: target agent has auto_reply disabled. "
                    "Behavior tests may fail until `agent settings reply --auto-reply` is set."
                )
            active_conversation_id = conversation_id or _create_conversation(
                client,
                base_url=resolved_base_url,
                agent_id=agent_id,
                channel=normalized_channel,
            )
        except APIError as exc:
            typer.echo(render_api_error(exc, action="prepare chat conversation"), err=True)
            raise typer.Exit(code=1) from exc

        transcript = [
            {
                "id": str(uuid.uuid4()),
                "role": "user",
                "content": prompt_message,
                "text": prompt_message,
                "format": "TEXT",
                "entity": {"type": "user"},
            }
        ]

        payload: dict[str, object] = {
            "conversation_id": active_conversation_id,
            "context": context,
            "transcript": transcript,
            "metadata": {
                "source": "applied-cli",
                "isTest": True,
                "channel": normalized_channel,
            },
            "draft": draft,
        }

        typer.echo("\nAssistant:")
        try:
            text = _stream_v1_completion(
                client,
                base_url=resolved_base_url,
                shop_id=resolved_shop_id,
                api_token=resolved_token,
                agent_id=agent_id,
                payload=payload,
            )
        except APIError as exc:
            typer.echo(f"\n{render_api_error(exc, action='chat completion')}", err=True)
            raise typer.Exit(code=1) from exc

    emit_success(
        output_json=False,
        payload={},
        fields={
            "conversation_id": active_conversation_id,
            "chars": len(text),
        },
    )
