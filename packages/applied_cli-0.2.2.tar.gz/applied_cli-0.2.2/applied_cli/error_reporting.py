from typing import Any

from applied_cli.http import APIError


def _extract_request_id(detail: Any) -> str | None:
    if not isinstance(detail, dict):
        return None
    if isinstance(detail.get("request_id"), str):
        return detail["request_id"]
    error_payload = detail.get("error")
    if isinstance(error_payload, dict) and isinstance(
        error_payload.get("request_id"), str
    ):
        return error_payload["request_id"]
    return None


def render_api_error(exc: APIError, *, action: str) -> str:
    lines: list[str] = []
    lines.append(f"Error during {action}.")
    if exc.code:
        lines.append(f"- code: {exc.code}")
    if exc.status_code is not None:
        lines.append(f"- http_status: {exc.status_code}")
    if exc.method and exc.url:
        lines.append(f"- request: {exc.method} {exc.url}")
    lines.append(f"- message: {exc}")
    if exc.hint:
        lines.append(f"- fix: {exc.hint}")
    request_id = _extract_request_id(exc.detail)
    if request_id:
        lines.append(f"- request_id: {request_id}")
    if exc.suggestions:
        lines.append("- next_steps:")
        for step in exc.suggestions:
            lines.append(f"  - {step}")
    return "\n".join(lines)
