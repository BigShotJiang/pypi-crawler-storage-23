from dataclasses import dataclass
from urllib.parse import urlsplit


@dataclass
class Credentials:
    base_url: str
    shop_id: str
    api_token: str


DEFAULT_BASE_URL = "https://api.appliedlabs.ai"
ENDPOINT_ALIASES = {
    "prod": "https://api.appliedlabs.ai",
    "production": "https://api.appliedlabs.ai",
    "api.appliedlabs.ai": "https://api.appliedlabs.ai",
    "dev": "https://api.appliedlabs.dev",
    "development": "https://api.appliedlabs.dev",
    "api.appliedlabs.dev": "https://api.appliedlabs.dev",
    "local": "http://localhost:8000",
    "localhost": "http://localhost:8000",
    "127.0.0.1": "http://127.0.0.1:8000",
}


def normalize_base_url(value: str) -> str:
    raw = value.strip()
    if not raw:
        return ""
    alias = ENDPOINT_ALIASES.get(raw.lower())
    if alias:
        return alias

    with_scheme = raw
    if not with_scheme.startswith(("http://", "https://")):
        if with_scheme.startswith(("localhost", "127.0.0.1")):
            with_scheme = f"http://{with_scheme}"
        else:
            with_scheme = f"https://{with_scheme}"

    parsed = urlsplit(with_scheme)
    if parsed.scheme and parsed.netloc:
        return f"{parsed.scheme}://{parsed.netloc}".rstrip("/")
    return with_scheme.rstrip("/")


def mask_token(token: str) -> str:
    if len(token) <= 10:
        return token[:2] + "..." if len(token) > 2 else "***"
    return f"{token[:4]}...{token[-4:]}"
