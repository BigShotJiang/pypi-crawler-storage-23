import typer

from applied_cli.commands.auth import app as auth_app
from applied_cli.commands.agent import app as agent_app
from applied_cli.commands.chat import send as chat_send
from applied_cli.commands.discover import (
    benchmarks_app,
    conversations_app,
    runs_app,
    scenarios_app,
)
from applied_cli.commands.coverage import app as coverage_app
from applied_cli.commands.fix import app as fix_app
from applied_cli.commands.insights import app as insights_app
from applied_cli.commands.intents import app as taxonomy_app
from applied_cli.commands.responses import app as knowledge_app
from applied_cli.commands.shop import app as shop_app
from applied_cli.commands.simulate import app as simulate_app

app = typer.Typer(
    help=(
        "Applied Labs CLI for agent-safe workflows.\n\n"
        "Login (requires human approval in browser):\n"
        "  applied-cli auth login\n\n"
        "Check status and switch shops:\n"
        "  applied-cli auth status\n"
        "  applied-cli auth shops\n"
        "  applied-cli auth use-shop \"<shop name or uuid>\"\n\n"
        "Then run workflows like:\n"
        "  applied-cli chat --agent-id <uuid> --message \"Hello\"\n"
        "  applied-cli test fix context --benchmark-id <uuid>\n"
        "  applied-cli insights run --query \"top issues\""
    ),
    no_args_is_help=True,
    add_completion=False,
)

# ─────────────────────────────────────────────────────────────────────────────
# Core
# ─────────────────────────────────────────────────────────────────────────────
app.add_typer(auth_app, name="auth", help="Login, logout, switch shops.")
app.add_typer(shop_app, name="shop", help="Bootstrap new shops from YAML spec.")
app.add_typer(agent_app, name="agent", help="List, create, update agents.")

# ─────────────────────────────────────────────────────────────────────────────
# Operations
# ─────────────────────────────────────────────────────────────────────────────
app.command(
    "chat",
    help=(
        "Send a message to an agent. "
        "Example: applied-cli chat --agent-id <uuid> --message 'Hello'"
    ),
)(chat_send)
app.add_typer(conversations_app, name="conversations", help="List, show, import conversations.")
app.add_typer(insights_app, name="insights", help="Generate analytics reports.")

# ─────────────────────────────────────────────────────────────────────────────
# Knowledge & Configuration
# ─────────────────────────────────────────────────────────────────────────────
app.add_typer(knowledge_app, name="knowledge", help="Q&A entries, escalation rules, context.")
app.add_typer(taxonomy_app, name="taxonomy", help="Topic/intent classification scheme.")

# ─────────────────────────────────────────────────────────────────────────────
# Testing (benchmarks → scenarios → runs)
# ─────────────────────────────────────────────────────────────────────────────
test_app = typer.Typer(
    help=(
        "Test agent behavior with benchmarks and scenarios.\n\n"
        "Hierarchy: benchmarks contain scenarios, scenarios have runs.\n"
        "Coverage summarizes scenarios over intents.\n"
        "Fix helps identify and resolve failing scenarios."
    ),
    no_args_is_help=True,
)
test_app.add_typer(benchmarks_app, name="benchmarks", help="Scenario collections.")
test_app.add_typer(scenarios_app, name="scenarios", help="Individual test cases.")
test_app.add_typer(runs_app, name="runs", help="Scenario execution records.")
test_app.add_typer(coverage_app, name="coverage", help="Coverage summaries by intent.")
test_app.add_typer(fix_app, name="fix", help="Fix failing scenarios.")
app.add_typer(test_app, name="test", help="Benchmarks, scenarios, and fix workflows.")

# ─────────────────────────────────────────────────────────────────────────────
# Simulation
# ─────────────────────────────────────────────────────────────────────────────
app.add_typer(simulate_app, name="simulate", help="Generate test conversations.")


if __name__ == "__main__":
    app()
