"""applied-cli package."""

