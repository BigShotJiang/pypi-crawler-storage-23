import unittest
from unittest.mock import patch

from applied_cli.commands import insights
from applied_cli.commands._parsers import parse_csv_list, validate_uuid_list


class ParserHelpersTests(unittest.TestCase):
    def test_parse_csv_list_trims_and_filters_empty(self) -> None:
        self.assertEqual(parse_csv_list(" a, b ,,c "), ["a", "b", "c"])
        self.assertEqual(parse_csv_list(""), [])
        self.assertEqual(parse_csv_list(None), [])

    def test_validate_uuid_list_accepts_valid_values(self) -> None:
        validate_uuid_list(
            [
                "7ef9c71d-6ea8-42a9-9878-b496ed5f830d",
                "dcc24632-a570-46fc-bd37-3e735f001953",
            ],
            field_name="ids",
        )

    def test_validate_uuid_list_rejects_invalid_values(self) -> None:
        with self.assertRaises(Exception):
            validate_uuid_list(["not-a-uuid"], field_name="ids")


class InsightsWaitHelperTests(unittest.TestCase):
    def test_wait_for_report_completion_returns_completed_status(self) -> None:
        with patch.object(
            insights,
            "get_insights_status",
            side_effect=[{"status": "generating"}, {"status": "completed"}],
        ):
            result = insights._wait_for_report_completion(
                base_url="http://localhost:8000",
                shop_id="shop",
                api_token="token",
                report_id="report",
                poll_seconds=0.001,
                max_wait_seconds=0.2,
            )
        self.assertEqual(result.get("status"), "completed")


if __name__ == "__main__":
    unittest.main()
