#!/usr/bin/env python3
"""CLI интерфейс для генератора FastAPI проекта"""
import argparse
import sys
from .generator import FastAPICleanArchGenerator


def main():
    parser = argparse.ArgumentParser(
        prog="clean",
        description="Генератор FastAPI проекта"
    )
    parser.add_argument(
        "project_name",
        type=str,
        help="Название проекта"
    )
    parser.add_argument(
        "-o", "--output",
        type=str,
        default=".",
        help="Директория для создания проекта (по умолчанию: текущая)"
    )

    args = parser.parse_args()

    print(f" ")

    try:
        generator = FastAPICleanArchGenerator(args.project_name, args.output)
        generator.create_structure()
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()