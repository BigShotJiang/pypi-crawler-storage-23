import os
from pathlib import Path


class FastAPICleanArchGenerator:
    def __init__(self, project_name: str, output_dir: str = "."):
        self.project_name = project_name
        self.output_dir = Path(output_dir) / "src"

    def create_structure(self):
        directories = [
            self.output_dir,
            self.output_dir / "core",
            self.output_dir / "models" / "dto",
            self.output_dir / "models" / "schemas",
            self.output_dir / "views" / "interfaces",
            self.output_dir / "views" / "routing",
            self.output_dir / "views" / "services",
        ]

        for dir_path in directories:
            dir_path.mkdir(parents=True, exist_ok=True)
            (dir_path / "__init__.py").touch()

        self._create_files()

    def _create_files(self):
        # ТОЛЬКО те файлы, что ты скинул:

        self._write_file(self.output_dir / "core" / "auth.py", self._auth_py())
        self._write_file(self.output_dir / "core" / "exceptions.py", self._exceptions_py())
        self._write_file(self.output_dir / "core" / "settings.py", self._settings_py())
        self._write_file(self.output_dir / "core" / "utils.py", self._utils_py())

        self._write_file(self.output_dir / "views" / "interfaces" / "auth.py", self._auth_interface_py())
        self._write_file(self.output_dir / "views" / "routing" / "auth.py", self._auth_router_py())
        self._write_file(self.output_dir / "views" / "routing" / "product.py", self._product_router_py())
        self._write_file(self.output_dir / "views" / "services" / "auth.py", self._auth_service_py())

        self._write_file(self.output_dir / "dependencies.py", self._dependencies_py())
        self._write_file(self.output_dir / "main.py", self._main_py())

    def _write_file(self, path: Path, content: str):
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)

    def _auth_py(self) -> str:
        return '''from datetime import datetime, timedelta, timezone
from typing import Any

from src.core.settings import get_settings
import bcrypt
import jwt

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from src.models.schemas.user import User
from src.core.database import get_session

security = HTTPBearer()


def hash_password(password: str) -> str:
    pwd_bytes = password.encode("utf-8")[:72]
    return bcrypt.hashpw(pwd_bytes, bcrypt.gensalt()).decode("utf-8")


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return bcrypt.checkpw(
        plain_password.encode("utf-8"),
        hashed_password.encode("utf-8"),
    )


def create_access_token(
        subject: str | int,
        extra: dict[str, Any] | None = None,
) -> str:
    settings = get_settings()
    now = datetime.now(timezone.utc)
    expires = now + timedelta(minutes=10)
    payload = {
        "sub": str(subject),
        "exp": expires,
        "iat": now,
    }
    if extra:
        payload.update(extra)
    return jwt.encode(
        payload, settings.SECRET_KEY, algorithm=settings.JWT_ALGORITHM
    )


def decode_access_token(token: str) -> dict | None:
    settings = get_settings()
    try:
        return jwt.decode(
            token,
            settings.SECRET_KEY,
            algorithms=[settings.JWT_ALGORITHM],
        )
    except jwt.PyJWTError:
        return None


async def get_current_user(
        credentials: HTTPAuthorizationCredentials = Depends(security),
        session: AsyncSession = Depends(get_session),
) -> User:
    token = credentials.credentials
    payload = decode_access_token(token)
    if not payload or "sub" not in payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
        )
    user_id = int(payload["sub"])
    res = await session.execute(select(User).where(User.id == user_id))
    user = res.scalar_one_or_none()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found",
        )
    return user
'''

    def _exceptions_py(self) -> str:
        return '''class DoesNotExists(ValueError):...

class UniqueConstraint(ValueError):...
'''

    def _settings_py(self) -> str:
        return '''from pydantic_settings import BaseSettings, SettingsConfigDict
import os
import dotenv


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file='.env',
        env_file_encoding='utf-8',
        extra='ignore'
    )
    DATABASE_URL: str = os.environ.get("DATABASE_URL", "sqlite+aiosqlite:///./database.db")
    DATABASE_ECHO: bool = os.environ.get("DATABASE_ECHO", False)
    SECRET_KEY: str = os.environ.get("SECRET_KEY", "default-secret-key")
    JWT_ALGORITHM: str = os.environ.get("JWT_ALGORITHM", "HS256")


def get_settings():
    return Settings()
'''

    def _utils_py(self) -> str:
        return '''from typing import Callable
from fastapi import HTTPException
from src.core.exceptions import (
    DoesNotExists, UniqueConstraint
)
async def response (*, func: Callable, **kwargs):
    try:
        return await func(**kwargs)
    except DoesNotExists as e:
        print(e)
        raise HTTPException(
            status_code=404,
            detail=str(e)
        )
    except UniqueConstraint as e:
        print(e)
        raise HTTPException(
            status_code=400,
            detail=str(e)
        )
    except Exception as e:
        print(e)
        raise HTTPException(
            status_code=500,
            detail=str(e)
        )
'''

    def _auth_interface_py(self) -> str:
        return '''from abc import ABC, abstractmethod
from sqlalchemy.ext.asyncio import AsyncSession


class AuthInterface(ABC):
    @abstractmethod
    async def login(self, payload, session: AsyncSession): ...

    @abstractmethod
    async def registration(self, payload, session: AsyncSession): ...
'''

    def _auth_router_py(self) -> str:
        return '''from src.models.dto.user import UserCreate, UserLogin, UserResponse
from fastapi import APIRouter, Depends, status
from src.dependencies import get_session, get_auth_service
from sqlalchemy.ext.asyncio import AsyncSession
from src.models.schemas.user import User
from src.views.interfaces.auth import AuthInterface
from src.core.utils import response

router = APIRouter(
    prefix='/auth'
)


@router.post('/login', response_model=UserResponse)
async def login(
        payload: UserLogin,
        session: AsyncSession = Depends(get_session),
        repo: AuthInterface = Depends(get_auth_service)
):
    return await response(
        func=repo.login,
        payload=payload,
        session=session
    )


@router.post('/register')
async def register(
        payload: UserCreate,
        session: AsyncSession = Depends(get_session),
        repo: AuthInterface = Depends(get_auth_service)
):
    return await response(
        func=repo.registration,
        payload=payload,
        session=session
    )
'''

    def _product_router_py(self) -> str:
        return '''from src.models.dto.product import ProductResponse
from src.dependencies import get_product_service, get_session, get_current_user
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from src.models.schemas.user import User
from src.views.interfaces.crud import CRUDInferface
from src.core.utils import response

router = APIRouter(prefix="/products")


@router.get("", response_model=list[ProductResponse])
async def list_product(
    _: User = Depends(get_current_user),
    repo: CRUDInferface = Depends(get_product_service),
    session: AsyncSession = Depends(get_session),
) -> list[ProductResponse]:
    return await response(func=repo.list, session=session)
'''

    def _auth_service_py(self) -> str:
        return '''from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.core.auth import (
    hash_password, verify_password, create_access_token
)
from src.models.schemas.user import User
from src.core.exceptions import DoesNotExists, UniqueConstraint
from src.models.dto.user import (
    UserCreate, UserLogin
)
from src.views.interfaces.auth import AuthInterface


class AuthService(AuthInterface):

    async def login(self, payload: UserLogin, session: AsyncSession):
        res = await session.execute(
            select(User).where(User.username == payload.username)
        )
        user = res.scalar_one_or_none()
        if not user or not verify_password(payload.password, user.hashed_password):
            raise DoesNotExists(
                "User with such credentials does not exist"
            )
        token = create_access_token(subject=user.id, extra={"username": user.username})
        return {
            'access_token': token,
            'user_id': user.id
        }

    async def registration(self, payload: UserCreate, session: AsyncSession):
        res = await session.execute(
            select(User).where(User.username == payload.username)
        )
        if res.scalar_one_or_none():
            raise UniqueConstraint(
                "User with this username already exists"
            )
        user = User(
            username=payload.username,
            hashed_password=hash_password(payload.password)
        )
        session.add(user)
        await session.flush()
        await session.refresh(user)
        token = create_access_token(subject=user.id, extra={"username": user.username})
        return {
            'access_token': token,
            'user_id': user.id
        }
'''

    def _dependencies_py(self) -> str:
        return '''from src.views.services.auth import AuthService


def get_auth_service() -> AuthService:
    return AuthService()
'''

    def _main_py(self) -> str:
        return '''from fastapi import FastAPI
from src.views.routing.auth import router as auth_router
from src.views.routing.product import router as product_router
import uvicorn

app = FastAPI()
app.include_router(auth_router)
app.include_router(product_router)

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        reload=True
    )
'''