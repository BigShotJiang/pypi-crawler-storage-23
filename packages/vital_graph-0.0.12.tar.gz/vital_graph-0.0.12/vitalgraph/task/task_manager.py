
class TaskManager:
    pass


# web app websocket notifications when task status change
# handled by signal manager

# meant to handle the celery implementation



