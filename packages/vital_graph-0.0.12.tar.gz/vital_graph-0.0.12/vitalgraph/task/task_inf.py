
class TaskInf:
    pass


# in ops package, provide implementations
# this interface meant to handle the specifics of celery tasks


# tasks

# individual and recurring

# importing dataset (s3/file --> staged --> primary)
# exporting data (primary --> s3/file)
# cleaning term table
# updating indexes
# updating text indexes







