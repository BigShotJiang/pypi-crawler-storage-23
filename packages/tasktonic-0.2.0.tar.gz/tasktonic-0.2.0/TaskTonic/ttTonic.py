from sys import prefix

from .ttSparkleStack import ttSparkleStack
from .ttLiquid import ttLiquid
import re, threading, copy


class ttTonic(ttLiquid):
    """
    A robust, passive framework class for creating task-oriented objects (Tonics).

    This class automatically discovers methods (sparkles) based on naming conventions,
    handles state management, and provides a structured logging system. All sparkle
    types (ttsc, ttse, tts, _tts) are handled uniformly by placing a 'work order'
    on a queue, which is then processed by an external execution loop.
    """

    def __init__(self, name=None, log_mode=None, catalyst=None):
        """
        Initializes the Tonic instance, discovers sparkles, and calls startup methods.

        :param context: The context in which this tonic operates.
        :param name: An optional name for the tonic. Defaults to the class name.
        :param fixed_id: An optional fixed ID for the tonic.
        """
        super().__init__(name=name, log_mode=log_mode)
        self.catalyst = catalyst
        # Discover all sparkles and build the execution system.
        self.state = -1  # Start with no state (-1)
        self._pending_state = -1
        self._sparkle_init()

    def _tt_post_init_action(self):
        # Prevent _tt_post_init_action  to runs twice
        # (e.g., due to the complex initialization order in ttPysideWidget
        # involving metaclasses and multiple inheritance).
        if getattr(self, '_post_init_done', False):
            return
        self._post_init_done = True
        # -----------------------
        # bind to catalyst
        if not hasattr(self, 'catalyst_queue'):
            self.catalyst = \
                self.catalyst if self.catalyst is not None \
                else self.base.catalyst if hasattr(self.base, 'catalyst') and self.base.catalyst is not None\
                else self.ledger.get_tonic_by_name('tt_main_catalyst')
            self.catalyst_queue = self.catalyst.catalyst_queue  # copy queue for (a bit) faster acces
            self.log(flags={'catalyst': self.catalyst.name})
            self.catalyst._ttss__add_tonic_to_catalyst(self.id)

        super()._tt_post_init_action()

        # After initialization is completed, queue the synchronous startup sparkles.
        if hasattr(self, '_ttss__on_start'):
            self._ttss__on_start()
        if hasattr(self, 'ttse__on_start'):
            self.ttse__on_start()

        if hasattr(self, '_auto_bind'):
            for auto_bind in self._auto_bind:
                prefix, sparkle, binder = auto_bind
                binder(prefix, sparkle)

    def _get_custom_prefixes(self):
        """
        Hook for syntax extension with new prefixes and the binding method to call
         for binding an event to the sparkle (ea. {'ttqt': self.qt_event_binder}).
        """
        return {}


    def _sparkle_init(self):
        """
        Performs a one-time, intensive setup to discover all sparkles, build
        the dispatch system, and create the public-facing callable methods. This
        is the core of the Tonic's introspection and setup logic.

        Called from the Essence metaclass after completion of __init__
        """

        # Prevent _sparkle_init  to runs twice
        # (e.g., due to the complex initialization order in ttPysideWidget
        # involving metaclasses and multiple inheritance).
        if getattr(self, '_sparkle_init_done', False): return
        self._sparkle_init_done = True

        sp_stck = ttSparkleStack()

        prefix_extension = self._get_custom_prefixes()
        prefixes = ['ttsc', 'ttse', 'tts', '_tts', '_ttss']
        prefixes.extend(prefix_extension.keys())
        prefix_pattern = "|".join(prefixes)

        # Define the regular expressions used to identify different sparkle types.
        # state_pattern = re.compile(f'^({prefix_pattern})_([a-zA-Z0-9_]+)__([a-zA-Z0-9_]+)$')
        # general_pattern = re.compile(f'^({prefix_pattern})__([a-zA-Z0-9_]+)$')
        general_pattern = re.compile(f'^({prefix_pattern})__(.+)$')
        state_pattern = re.compile(f'^({prefix_pattern})_(.+?)__(.+)$')

        # --- Phase 1: Discover all implementations from the class hierarchy (MRO) ---
        state_impls, generic_impls = {}, {}
        states, sparkle_names = set(), set()
        prefixes_by_cmd = {}

        # Iterate through the MRO (Method Resolution Order) in reverse to ensure
        # that methods in child classes correctly override those in parent classes.
        for cls in reversed(self.__class__.__mro__):
            if cls in (ttLiquid, object):
                continue
            for name, method in cls.__dict__.items():
                s_match = state_pattern.match(name)
                g_match = general_pattern.match(name)
                if g_match:
                    # Found a generic sparkle (e.g., 'ttsc__initialize')
                    prefix, sp_name = g_match.groups()
                    generic_impls[(prefix, sp_name)] = method
                    sparkle_names.add(sp_name)
                    prefixes_by_cmd.setdefault(sp_name, set()).add(prefix)
                elif s_match:
                    # Found a state-specific sparkle (e.g., 'ttsc_waiting__process')
                    prefix, state_name, sp_name = s_match.groups()
                    state_impls[(prefix, state_name, sp_name)] = method
                    states.add(state_name)
                    sparkle_names.add(sp_name)
                    prefixes_by_cmd.setdefault(sp_name, set()).add(prefix)


        # --- Phase 2: Build fast lookup tables for states ---
        self._state_to_index = {name: i for i, name in enumerate(sorted(list(states)))}
        self._index_to_state = sorted(list(states))
        num_states = len(self._index_to_state)

        # --- Phase 3A: Create fallback methods for state on_enter and on_exit
        if num_states:
            self._direct_execute_ttse__on_enter = self.ttse__on_enter
            self._direct_execute_ttse__on_exit = self.ttse__on_exit
        # --- Phase 3B: Create and bind all public-facing dispatcher methods ---
        sparkle_list = []
        for sp_name in sparkle_names:
            is_state_aware = any(sp_name == key[2] for key in state_impls.keys())
            for prefix in prefixes_by_cmd[sp_name]:
                interface_name = f"{prefix}__{sp_name}"
                sparkle_list.append(interface_name)

                # --- Path A: This is a state-aware command ---
                if is_state_aware:
                    # For state-aware commands, we build a list of methods, one for each state.
                    handler_list = [self._noop] * num_states
                    generic_handler = generic_impls.get((prefix, sp_name))
                    if generic_handler:
                        handler_list = [generic_handler] * num_states
                    for state_idx, state_name in enumerate(self._index_to_state):
                        state_handler = state_impls.get((prefix, state_name, sp_name))
                        if state_handler:
                            handler_list[state_idx] = state_handler

                    def create_put_state_sparkle(_list, _name):
                        # Create a state execution that will select the correct method by state from the list at
                        #  runtime and create the put_state_sparkle to put if on the queue
                        def create_executer():
                            def execute_state_sparkle(self, *args, **kwargs):
                                state_sparkle = _list[self.state]
                                self.log(flags={'state': self.state})
                                state_sparkle(self, *args, **kwargs)
                            execute_state_sparkle.__name__ = _name
                            return execute_state_sparkle

                        def put_state_sparkle(self, *args, **kwargs):
                            if threading.get_ident() != self.catalyst.thread_id:
                                args = tuple((arg if callable(arg) else copy.deepcopy(arg)) for arg in args)
                                kwargs = {key: (value if callable(value) else copy.deepcopy(value))
                                          for key, value in kwargs.items()}
                            self.catalyst_queue.put((self, create_executer(), args, kwargs, sp_stck.get_stack()))
                        return put_state_sparkle

                    # Bind the new put_state_sparkle function to the instance, making it a method.
                    setattr(self, interface_name, create_put_state_sparkle(handler_list, interface_name).__get__(self))

                    # Create direct-execute methods only for 'on_enter' and 'on_exit'
                    if interface_name in ['ttse__on_enter', 'ttse__on_exit']:
                        direct_method_name = f"_direct_execute_{interface_name}"

                        # This factory creates the direct execution method
                        # It needs to capture the handler_list (_list)
                        def create_direct_executor(_list, _name):
                            # This is the exact logic copied from 'execute_state_sparkle'
                            def direct_execute_method(self, *args, **kwargs):
                                state_sparkle = _list[self.state]
                                self.log(flags={'state': self.state})
                                state_sparkle(self, *args, **kwargs)
                            direct_execute_method.__name__ = _name
                            return direct_execute_method

                        # Bind the new direct method to the instance
                        setattr(self,
                                direct_method_name,
                                create_direct_executor(handler_list, interface_name).__get__(self))

                # --- Path B: This is a generic-only command ---
                else:
                    handler_method = generic_impls[(prefix, sp_name)]

                    def create_put_sparkle(_method):
                        # This put_sparkle always uses the one generic method.
                        def put_sparkle(self, *args, **kwargs):
                            if threading.get_ident() != self.catalyst.thread_id:
                                args = tuple((arg if callable(arg) else copy.deepcopy(arg)) for arg in args)
                                kwargs = {key: (value if callable(value) else copy.deepcopy(value))
                                          for key, value in kwargs.items()}
                            self.catalyst_queue.put((self, _method, args, kwargs, sp_stck.get_stack()))
                        return put_sparkle

                    # Bind the new put_sparkle function to the instance, making it a method.
                    setattr(self, interface_name, create_put_sparkle(handler_method).__get__(self))

        # --- Phase 4: Build fast lookup tables for sparkles ---
        self.sparkles = sorted(sparkle_list)

        # --- Phase 5: patch the _execute_sparkle function to normal mode ---
        self._execute_sparkle = self.__exec_sparkle

        # --- Phase 6: prpare for auto binding sparkles for extended syntax
        auto_bind = []
        for sparkle in self.sparkles:
            for prefix, binder in prefix_extension.items():
                if sparkle.startswith(prefix):
                    auto_bind.append((prefix, sparkle, binder))
        if auto_bind: self._auto_bind = auto_bind

        # Log the results of the discovery process.
        self.log(system_flags={'states': self._index_to_state, 'sparkles': self.sparkles})

    def _noop(self, *args, **kwargs):
        """A do-nothing method used as a default for unbound sparkles."""
        pass

    def to_state(self, state):
        """
        Requests a state transition. The change is handled by the _execute_sparkle
        method after the current sparkle finishes.

        :param state: The name (str) or index (int) of the target state. When target == -1, stop machine stops
        """
        to_state = -1  # no action
        if isinstance(state, str):
            to_state = self._state_to_index.get(state, None)
            if to_state is None: return
        elif isinstance(state, int) and 0 <= state < len(self._index_to_state):
            to_state = state
        elif isinstance(state, int) and state == -1:
            to_state = -1
        else:
            return

        if self.state >= 0:
            self.catalyst._execute_extra_sparkle(self, self._direct_execute_ttse__on_exit)
        if to_state >= 0:
            self.catalyst._execute_extra_sparkle(self, self._ttinternal_state_change_to, to_state)
            self.catalyst._execute_extra_sparkle(self, self._direct_execute_ttse__on_enter)
        else:
            self.catalyst._execute_extra_sparkle(self, self._ttinternal_state_machine_stop)

    def _ttinternal_state_change_to(self, state):
        self.log(system_flags={'state': self.state, 'new_state': state})
        self.state = state

    def _ttinternal_state_machine_stop(self):
        self.log(system_flags={'state': self.state, 'new_state': None})
        self.state = -1
        pass

    def get_active_state(self):
        if self.state == -1: return '--'
        return self._index_to_state[self.state]

    def _execute_sparkle(self, sparkle_method, *args, **kwargs):
        """
        The single, central method for executing any sparkle from the queue. It
        is called by the external execution loop. It also handles logging and
        state transitions.

        This is the placeholder. On tonic startup this is replaced by __exec_sparkle, with this functionality.
        On finishing the tonic __exec_system_sparkle which only handles the system calls, and filters out user sparkles

        :param sparkle_method: The unbound method of the sparkle to execute.
        :param args: Positional arguments for the sparkle.
        :param kwargs: Keyword arguments for the sparkle.
        """
        pass

    def __exec_sparkle(self, sparkle_method, *args, **kwargs):
        """
        sparkle execution in running mode
        """
        interface_name = sparkle_method.__name__
        sp_stck = ttSparkleStack()
        self.log(flags={'sparkle': interface_name,
                        'source': f'{sp_stck.source_tonic_name}.{sp_stck.source_sparkle_name}'})
        # Execute the user's actual sparkle code, passing self to bind it.
        sparkle_method(self, *args, **kwargs)
        self.log(close_log=True)

    def __exec_system_sparkle(self, sparkle_method, *args, **kwargs):
        """
        sparkle execution in normal mode
        """
        if self.id < 0: return  # Tonic already unregistered (probably old sparkle in queue)

        interface_name = sparkle_method.__name__

        if interface_name.startswith('_ttss') \
        or interface_name in [
            'ttse__on_finished', 'ttse__on_exit',
            'ttse__on_service_base_completed', '_ttinternal_state_machine_stop',
        ]:
            self.__exec_sparkle(sparkle_method, *args, **kwargs)

    def get_current_state_name(self):
        """
        Gets the name of the current state.

        :return: The name of the state (str) or "None".
        """
        if self.state == -1: return "--"
        return self._index_to_state[self.state]

    # standard tonic sparkle
    def ttse__on_start(self): pass
    def ttse__on_finished(self): pass
    def ttse__on_enter(self): pass
    def ttse__on_exit(self): pass

    # --- System Lifecycle Sparkles ---
    def _ttss__on_start(self):
        """System-level sparkle for internal framework setup."""
        pass

    def finish(self):
        # Finish on tonic level, will first stop the tonic, and after that finish admin in the essence
        if self.finishing: return
        self.ttsc__finish()

    def ttsc__finish(self):
        if self.finishing: return

        calling_tonic = ttSparkleStack().source_tonic

        # check on valid tonic finish
        if calling_tonic in [self.base, self]:
            if hasattr(self, 'service_bases') and calling_tonic in self.service_bases:
                self.service_bases.remove(calling_tonic)

            if self.base:
                self.base._ttss__on_infusion_completed(self)

            # start finishing the tonic
            self.finishing = True
            self._execute_sparkle = self.__exec_system_sparkle # patch the _execute_sparkle function to finish mode
            if self.state != -1: self.to_state(-1)  # stop state machine if active
            self.ttse__on_finished()  # stop tonic (user level)
            self._ttss__on_finished()  # cleanup tonic (system level)


        # check if service finish
        elif hasattr(self, 'service_bases') and calling_tonic in self.service_bases:
            self.service_bases.remove(calling_tonic)
            # notify
            try: getattr(self, 'ttse__on_service_base_removed')(calling_tonic.id, len(self.service_bases))
            except AttributeError: pass
            try: getattr(calling_tonic, f'ttse__on_{self.name}_completed')()
            except AttributeError: pass
            try: getattr(calling_tonic, '_ttss__on_infusion_completed')(self.id)
            except AttributeError: pass

            if len(self.service_bases) <= 0: self.finish()

    def _ttss__on_finished(self):
        """System-level sparkle for final cleanup."""
        #notify and remove service bases left
        try:
            for sb in self.service_bases:
                try: getattr(sb, f'ttse__on_{self.name}_completed')()
                except AttributeError: pass
                try: getattr(sb, '_ttss__on_infusion_completed')(self.id)
                except AttributeError: pass
            self.service_bases.clear()
        except AttributeError: pass

        # finish all infusions
        sp_stck = ttSparkleStack()
        sp_stck.push(self, 'finish')
        for tonic in self.infusions.copy():
            tonic.ttsc__finish()
        sp_stck.pop()
        self.infusions=[]

        # # complete
        # self.catalyst._ttss__remove_tonic_from_catalyst(self.id)
        # self.ledger.unregister(self.id)
        # self.id = -1  # finished

        # finish the Tonic
        # if not self.infusions:
        #     self._ttss__on_completion()
        # else:
        #     sp_stck = ttSparkleStack()
        #     sp_stck.push(self, 'finish')
        #     for tonic in self.infusions.copy():
        #         tonic.ttsc__finish()
        #     sp_stck.pop()

        self._ttss__on_completion()

    def _ttss__on_infusion_completed(self, tonic):
        if tonic in self.infusions:
            self.infusions.remove(tonic)
            # if self.finishing and not self.infusions:
            #     self._ttss__on_completion()

    def _ttss__on_completion(self):
        self.catalyst._ttss__remove_tonic_from_catalyst(self.id)
        self.ledger.unregister(self.id)
        self.id = -1  # finished

