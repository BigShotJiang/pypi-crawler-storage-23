﻿import os
class PPT_VIDEO:
    def __init__(self):
        pass
if __name__ == '__main__':
    pass