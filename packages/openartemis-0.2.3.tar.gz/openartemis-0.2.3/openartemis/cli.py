"""CLI for OpenArtemis — Claude-like, user-friendly design."""

import json
import logging
import os
import re
import subprocess
import sys
from datetime import datetime
from pathlib import Path

from openartemis.config import load_config

load_config()

# Reduce harvester log noise so Rich output stays clean
logging.getLogger("openartemis").setLevel(logging.WARNING)

import questionary
import typer
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from openartemis.auth import (
    init_db,
    get_user_count,
    create_admin,
    get_session_user,
    create_session,
    revoke_session,
    login,
    redeem_invite_code,
    create_invite_code,
    create_chat_session,
    get_chat_sessions,
    get_chat_messages,
)
from openartemis.harvesters.social import SocialHarvester
from openartemis.harvesters.youtube import YouTubeHarvester

app = typer.Typer(
    name="openartemis",
    help="Harvest transcripts from YouTube, TikTok, Instagram, and X. User-friendly, no coding required.",
    add_completion=False,
)
console = Console()

VALID_PLATFORMS = ["youtube", "tiktok", "instagram", "x"]
WHISPER_MODELS = ["tiny", "base", "small", "medium", "large"]


def _welcome(chat: bool = False, model: str | None = None) -> None:
    """Print welcome banner."""
    if chat:
        model_line = f"  Model: [cyan]{model or 'Artemis-1-Mini'}[/cyan] (type [bold]/model[/bold] to change)\n" if model else ""
        banner = f"""
[bold cyan]OpenArtemis[/bold cyan] — Chat with [bold]Artemis[/bold]
{model_line}
  • Ask anything — Artemis will help
  • Say "research X" for in-depth answers
  • Type [bold]/[/bold] for menu
"""
    else:
        banner = """
[bold cyan]OpenArtemis[/bold cyan] — Find videos and get their text

  • Search YouTube, TikTok, Instagram, X
  • Save as text files
"""
    console.print(Panel(banner.strip(), border_style="cyan", padding=(1, 2)))


def _run_harvest(
    query: str,
    platforms: list[str],
    max_results: int,
    out_dir: Path,
    youtube_api_key: str | None,
    scrapingdog_api_key: str | None,
    whisper_model: str,
) -> int:
    """Run the harvest pipeline. Returns total posts harvested."""
    total = 0
    out_dir = out_dir.resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    transcriptapi_key = os.environ.get("TRANSCRIPTAPI_API_KEY")
    for platform in platforms:
        if platform == "youtube":
            if not youtube_api_key and not transcriptapi_key:
                console.print(
                    "[red]YouTube requires an API key.[/red] Set [bold]YOUTUBE_API_KEY[/bold] (Google) "
                    "or [bold]TRANSCRIPTAPI_API_KEY[/bold] (TranscriptAPI.com). Skipping YouTube."
                )
                continue
            harvester = YouTubeHarvester(
                api_key=youtube_api_key,
                scrapingdog_api_key=scrapingdog_api_key,
                transcriptapi_api_key=transcriptapi_key,
            )
        else:
            harvester = SocialHarvester(platform=platform)

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task(f"Harvesting [cyan]{platform}[/cyan]...", total=None)
            count = 0
            for _ in harvester.harvest(
                query=query,
                max_results=max_results,
                out_dir=out_dir,
                whisper_model=whisper_model,
            ):
                count += 1
                total += 1
            progress.update(task, description=f"[green]✓[/green] {platform}: {count} posts")

    return total


def _interactive_mode() -> None:
    """Run in interactive mode — guided prompts for non-coders."""
    _welcome()

    try:
        query = questionary.text(
            "What would you like to find out?",
            default="",
            instruction="(e.g. mr beast, cooking tutorial, news clip)",
        ).ask()
        if not query or not query.strip():
            console.print(
                "[yellow]No query entered.[/yellow]\n"
                "[dim]Tip: Try again with something you'd like to find out about.[/dim]"
            )
            raise typer.Exit(1)

        platform_choices = [
            questionary.Choice("YouTube", value="youtube"),
            questionary.Choice("TikTok", value="tiktok"),
            questionary.Choice("Instagram", value="instagram"),
            questionary.Choice("X (Twitter)", value="x"),
        ]
        platforms = questionary.checkbox(
            "Which platforms do you want to search?",
            choices=platform_choices,
            default=[platform_choices[0]],  # YouTube selected by default
        ).ask()
        if not platforms:
            console.print("[yellow]No platforms selected. Exiting.[/yellow]")
            raise typer.Exit(1)

        max_results_str = questionary.text(
            "How many results per platform?",
            default="5",
        ).ask()
        try:
            max_results = int(max_results_str or "5")
        except ValueError:
            max_results = 5

        out_dir_str = questionary.path(
            "Where should we save the transcripts?",
            default="./transcripts",
        ).ask()
        out_dir = Path(out_dir_str or "./transcripts")

        youtube_api_key = os.environ.get("YOUTUBE_API_KEY")
        scrapingdog_api_key = os.environ.get("SCRAPINGDOG_API_KEY")

        if "youtube" in platforms and not youtube_api_key:
            youtube_api_key = questionary.password(
                "YouTube Data API key (get one at console.cloud.google.com):",
            ).ask()
            if not youtube_api_key:
                console.print("[yellow]YouTube skipped — no API key.[/yellow]")
                platforms = [p for p in platforms if p != "youtube"]

        console.print()
        console.print(Panel(
            f"[bold]Query:[/bold] {query}\n"
            f"[bold]Platforms:[/bold] {', '.join(platforms)}\n"
            f"[bold]Max results:[/bold] {max_results}\n"
            f"[bold]Output:[/bold] {out_dir}",
            title="Starting harvest",
            border_style="green",
        ))
        console.print()

        total = _run_harvest(
            query=query,
            platforms=platforms,
            max_results=max_results,
            out_dir=out_dir,
            youtube_api_key=youtube_api_key or None,
            scrapingdog_api_key=scrapingdog_api_key or None,
            whisper_model="base",
        )

        console.print()
        console.print(Panel(
            f"[bold green]Done![/bold green]\n\n"
            f"Harvested [bold]{total}[/bold] posts.\n"
            f"Saved to: [cyan]{out_dir}[/cyan]",
            title="Success",
            border_style="green",
        ))
    except (KeyboardInterrupt, EOFError):
        console.print("\n[yellow]Cancelled.[/yellow]")
        raise typer.Exit(0)


AGENT_OUTPUT_DIR = Path.home() / ".openartemis" / "agent_output"


def _agent_output_path(request: str) -> Path:
    """Generate output path for agent report."""
    safe = re.sub(r"[^\w\s-]", "", request)[:40].strip() or "task"
    safe = re.sub(r"[-\s]+", "_", safe)
    ts = datetime.now().strftime("%Y-%m-%d_%H-%M")
    return AGENT_OUTPUT_DIR / f"{ts}_{safe}.md"


def _run_agent_foreground(req: str) -> None:
    """Run agent in foreground with progress."""
    from openartemis.agent.agent_orchestrator import run_agent_mode

    output_path = _agent_output_path(req)
    def on_status(s: str) -> None:
        console.print(f"  [dim]{s}[/dim]")
    try:
        console.print("[dim]This may take a while. You can leave it running.[/dim]\n")
        with Progress(SpinnerColumn(), TextColumn("[dim]Agent working...[/dim]"), console=console) as progress:
            task = progress.add_task("", total=None)
            report = run_agent_mode(req, on_status=on_status, output_path=output_path)
            progress.update(task, description="[green]Done[/green]")
        console.print(Panel(Markdown(report or "(no output)"), title="[green]Agent Report[/green]", border_style="green"))
        console.print(f"[dim]Saved to {output_path}[/dim]")
        console.print("[dim]Workspace: ~/.openartemis/agent_workspace/[/dim]\n")
    except Exception as e:
        console.print(f"[red]Failed: {e}[/red]")


def _run_agent_background(req: str) -> None:
    """Run agent in background subprocess."""
    output_path = _agent_output_path(req)
    AGENT_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    # Write pending marker
    (AGENT_OUTPUT_DIR / f"{output_path.name}.running").write_text(req, encoding="utf-8")
    cmd = [sys.executable, "-m", "openartemis", "agent-run", req, str(output_path)]
    if sys.platform == "win32":
        subprocess.Popen(
            cmd,
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            cwd=os.getcwd(),
        )
    else:
        subprocess.Popen(
            cmd,
            start_new_session=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            cwd=os.getcwd(),
        )
    console.print(Panel(
        f"[green]Agent started in background.[/green]\n\n"
        f"Results will be saved to:\n[cyan]{output_path}[/cyan]\n\n"
        f"Run [bold]openartemis agent-status[/bold] to check progress.",
        title="Background Task",
        border_style="green",
    ))


def _run_agent_mode_flow() -> None:
    """Run Agent Mode: Plan, Agent, or Ask."""
    agent_sub = questionary.select(
        "Agent Mode:",
        choices=[
            questionary.Choice("Plan — Figure out how to build it", value="plan"),
            questionary.Choice("Agent — Write code and run it", value="agent"),
            questionary.Choice("Ask — Ask questions about your code", value="ask"),
        ],
    ).ask()
    if agent_sub == "plan":
        req = questionary.text("What would you like to build?").ask()
        if req:
            from openartemis.agent import ResearchPipeline
            from openartemis.config import resolve_artemis_model
            pipeline = ResearchPipeline(
                youtube_api_key=os.environ.get("YOUTUBE_API_KEY"),
                scrapingdog_api_key=os.environ.get("SCRAPINGDOG_API_KEY"),
                transcriptapi_api_key=os.environ.get("TRANSCRIPTAPI_API_KEY"),
                model=resolve_artemis_model("artemis-1"),
                out_dir=Path("./detective_output"),
            )
            try:
                with Progress(SpinnerColumn(), TextColumn("[dim]Artemis is researching...[/dim]"), console=console) as progress:
                    progress.add_task("", total=None)
                    report = pipeline.run(f"How do I build: {req}", on_tool_call=lambda n, a: None)
                console.print(Panel(Markdown(report or "(no report)"), title="[green]Build Plan[/green]", border_style="green"))
            except Exception as e:
                console.print(f"[red]Failed: {e}[/red]")
        console.print()
    elif agent_sub == "agent":
        allow = questionary.confirm("Agent needs access to its workspace to write and run code. Allow?", default=True).ask()
        if allow:
            req = questionary.text("What would you like to build?").ask()
            if req:
                run_in_bg = questionary.confirm(
                    "Run in background? (You can close this and check results later)",
                    default=False,
                ).ask()
                if run_in_bg:
                    _run_agent_background(req)
                else:
                    _run_agent_foreground(req)
        console.print()
    elif agent_sub == "ask":
        from openartemis.agent.agent_tools import AGENT_WORKSPACE, list_dir, read_file
        from openartemis.config import resolve_artemis_model
        from openai import OpenAI
        AGENT_WORKSPACE.mkdir(parents=True, exist_ok=True)
        q = questionary.text("Ask about your code (e.g. How do I start it?)").ask()
        if q:
            try:
                files = list_dir(".")
                ctx = f"Workspace contents:\n{files}\n\n"
                for f in ["index.html", "README.md", "package.json", "main.py"]:
                    try:
                        ctx += f"\n--- {f} ---\n{read_file(f)}\n"
                    except Exception:
                        pass
                client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
                resp = client.chat.completions.create(
                    model=resolve_artemis_model("artemis-1-mini"),
                    messages=[
                        {"role": "system", "content": "Answer the user's question about their code. Use the workspace context provided."},
                        {"role": "user", "content": f"Context:\n{ctx}\n\nQuestion: {q}"},
                    ],
                )
                ans = resp.choices[0].message.content or "(no answer)"
                console.print(Panel(Markdown(ans), title="[green]Answer[/green]", border_style="green"))
            except Exception as e:
                console.print(f"[red]Failed: {e}[/red]")
        console.print()


def _get_authenticated_user() -> dict:
    """Get current user. Returns user dict if authenticated, else runs auth flow."""
    init_db()
    user = get_session_user()
    if user and user.get("approved"):
        return user
    return _auth_flow()


def _auth_flow() -> dict | None:
    """Run login or invite-code flow. Returns user or exits."""
    if get_user_count() == 0:
        return _create_first_admin()
    choice = questionary.select(
        "Sign in:",
        choices=[
            questionary.Choice("Enter invite code", value="code"),
            questionary.Choice("Login", value="login"),
            questionary.Choice("Exit", value="exit"),
        ],
    ).ask()
    if choice == "exit":
        raise typer.Exit(0)
    if choice == "code":
        return _do_redeem_code()
    return _do_login()


def _create_first_admin() -> dict:
    """Create first admin account."""
    console.print(Panel("[bold]No users found. Create admin account.[/bold]", border_style="cyan"))
    console.print("[dim]Password must be at least 8 characters.[/dim]")
    email = questionary.text("Admin email:", default="gamtrain400@gmail.com").ask() or "gamtrain400@gmail.com"
    username = questionary.text("Admin username:").ask()
    password = questionary.password("Admin password (min 8 chars):").ask()
    if not username or not password:
        console.print("[red]Username and password required.[/red]")
        raise typer.Exit(1)
    if len(password) < 8:
        console.print("[red]Password must be at least 8 characters.[/red]")
        raise typer.Exit(1)
    create_admin(email, username, password)
    from openartemis.auth.db import get_user_by_username
    user = get_user_by_username(username)
    if user:
        create_session(user["id"])
        console.print("[green]Admin account created.[/green]\n")
        return user
    raise typer.Exit(1)


def _do_redeem_code() -> dict:
    """Redeem invite code and create account. Returns user dict."""
    console.print("[dim]Email gamtrain400@gmail.com to request an invite code.[/dim]")
    console.print("[dim]Password must be at least 8 characters.[/dim]\n")
    code = questionary.text("Invite code:").ask()
    if not code or not code.strip():
        console.print("[red]Code required.[/red]")
        raise typer.Exit(1)
    email = questionary.text("Email:").ask()
    username = questionary.text("Username:").ask()
    password = questionary.password("Password (min 8 chars):").ask()
    if not email or not username or not password:
        console.print("[red]All fields required.[/red]")
        raise typer.Exit(1)
    user, err = redeem_invite_code(code, email, username, password)
    if user:
        create_session(user["id"])
        console.print(f"[green]Account created. Welcome, {username}![/green]\n")
        return user
    console.print(f"[red]{err}[/red]")
    raise typer.Exit(1)


def _do_login() -> dict:
    """Handle login. Returns user or re-prompts."""
    username = questionary.text("Username:").ask()
    password = questionary.password("Password:").ask()
    if not username or not password:
        console.print("[red]Username and password required.[/red]")
        raise typer.Exit(1)
    user = login(username, password)
    if not user:
        console.print("[red]Invalid credentials or account not yet approved.[/red]")
        raise typer.Exit(1)
    create_session(user["id"])
    console.print(f"[green]Logged in as {username}[/green]\n")
    return user


def _chat_mode(user: dict) -> None:
    """Chat CLI — Artemis with research tools. Type / for mode menu."""
    from openartemis.config import load_config
    load_config()  # Ensure defaults applied (in case import order differed)
    openai_key = os.environ.get("OPENAI_API_KEY")
    if not openai_key:
        console.print(
            "[red]OPENAI_API_KEY required for chat.[/red] Set it in .env or your environment."
        )
        raise typer.Exit(1)

    from openartemis.chat import ChatSession

    def on_tool(name: str, args: dict) -> None:
        if name == "harvest_transcripts":
            q = args.get("query", "")
            p = args.get("platforms", ["youtube"])
            console.print(f"  [dim]→ Finding videos: [bold]{q}[/bold] on {', '.join(p)}[/dim]")
        elif name == "read_transcript":
            console.print(f"  [dim]→ Reading transcript...[/dim]")
        elif name == "brave_search":
            console.print(f"  [dim]→ Brave search: [bold]{args.get('q', '')}[/bold][/dim]")
        elif name == "fetch_webpage":
            console.print(f"  [dim]→ Fetching: [bold]{args.get('url', '')}[/bold][/dim]")
        elif name == "browse_webpage":
            console.print(f"  [dim]→ Browsing: [bold]{args.get('url', '')}[/bold][/dim]")

    is_admin = user.get("role") == "admin"
    session_id: int | None = None

    choice = questionary.select(
        "Start:",
        choices=[
            questionary.Choice("New chat", value="new"),
            questionary.Choice("Continue previous chat", value="continue"),
        ],
        default="new",
    ).ask()

    if choice == "continue":
        sessions_list = get_chat_sessions(user["id"], limit=15)
        if not sessions_list:
            console.print("[dim]No previous chats. Starting new chat.[/dim]\n")
            session_id = create_chat_session(user["id"])
            session = ChatSession(
                on_tool_call=on_tool,
                user_id=user["id"],
                is_admin=is_admin,
                session_id=session_id,
            )
        else:
            for s in sessions_list:
                title = (s.get("title") or "(no title)")[:50]
                console.print(f"  [{s['id']}] {title} — {s.get('updated_at', '')[:16]}")
            sid_str = questionary.text("Chat number to load (or Enter for new):").ask()
            if sid_str and sid_str.strip().isdigit():
                sid = int(sid_str.strip())
                if any(s["id"] == sid for s in sessions_list):
                    session_id = sid
                    msgs = get_chat_messages(session_id)
                    session = ChatSession(
                        on_tool_call=on_tool,
                        user_id=user["id"],
                        is_admin=is_admin,
                        session_id=session_id,
                    )
                    session.messages = [{"role": "system", "content": session.messages[0]["content"]}]
                    for m in msgs:
                        msg = {"role": m["role"], "content": m.get("content", "")}
                        if m.get("tool_calls"):
                            msg["tool_calls"] = m["tool_calls"]
                        session.messages.append(msg)
                    session._last_persisted = len(session.messages)
                else:
                    session_id = create_chat_session(user["id"])
                    session = ChatSession(
                        on_tool_call=on_tool,
                        user_id=user["id"],
                        is_admin=is_admin,
                        session_id=session_id,
                    )
            else:
                session_id = create_chat_session(user["id"])
                session = ChatSession(
                    on_tool_call=on_tool,
                    user_id=user["id"],
                    is_admin=is_admin,
                    session_id=session_id,
                )
    else:
        session_id = create_chat_session(user["id"])
        session = ChatSession(
            on_tool_call=on_tool,
            user_id=user["id"],
            is_admin=is_admin,
            session_id=session_id,
        )

    _welcome(chat=True, model=session.model_display)

    while True:
        try:
            user_input = questionary.text("You:", default="").ask()
        except (KeyboardInterrupt, EOFError):
            console.print("\n[yellow]Bye.[/yellow]")
            raise typer.Exit(0)

        if not user_input or not user_input.strip():
            continue

        # Slash command
        if user_input.strip().startswith("/"):
            cmd = user_input.strip().lower().split()[0] if user_input.strip().split() else user_input.strip().lower()
            if cmd in ("/help", "/?"):
                console.print(Panel(
                    "[bold]Commands[/bold]\n\n"
                    "[cyan]/history[/cyan] — See your recent chats\n"
                    "[cyan]/load <number>[/cyan] — Open a previous chat\n"
                    "[cyan]/research <query>[/cyan] — Ask Artemis to research something in depth\n"
                    "[cyan]/agent[/cyan] — Agent Mode (Plan, Agent, Ask)\n"
                    "[cyan]/model[/cyan] — Change model (Artemis-1 or Artemis-1-Mini)\n"
                    "[cyan]/save[/cyan] — Save chat to a file\n"
                    "[cyan]/export[/cyan] — Export chat as markdown\n"
                    "[cyan]/logout[/cyan] — Sign out\n"
                    "[cyan]/exit[/cyan] — Quit\n\n"
                    "[dim]Just type your question to chat with Artemis.[/dim]",
                    title="Help",
                    border_style="cyan",
                ))
                console.print()
                continue
            if cmd in ("/exit", "/quit", "/q"):
                console.print("[yellow]Bye.[/yellow]")
                raise typer.Exit(0)
            if cmd == "/logout":
                revoke_session()
                console.print("[green]Logged out.[/green]\n")
                raise typer.Exit(0)
            if cmd == "/history":
                sessions_list = get_chat_sessions(user["id"], limit=15)
                if not sessions_list:
                    console.print("[dim]No chat history.[/dim]\n")
                else:
                    for s in sessions_list:
                        title = (s.get("title") or "(no title)")[:50]
                        console.print(f"  [{s['id']}] {title} — {s.get('updated_at', '')[:16]}")
                    console.print("[dim]Use /load <number> to open a chat.[/dim]\n")
                continue
            if cmd.startswith("/load"):
                parts = user_input.strip().split(maxsplit=1)
                sid_str = parts[1].strip() if len(parts) > 1 else ""
                if sid_str.isdigit():
                    sid = int(sid_str)
                    sessions_list = get_chat_sessions(user["id"], limit=100)
                    if any(s["id"] == sid for s in sessions_list):
                        session.session_id = sid
                        msgs = get_chat_messages(sid)
                        session.messages = [{"role": "system", "content": session.messages[0]["content"]}]
                        for m in msgs:
                            msg = {"role": m["role"], "content": m.get("content", "")}
                            if m.get("tool_calls"):
                                msg["tool_calls"] = m["tool_calls"]
                            session.messages.append(msg)
                        session._last_persisted = len(session.messages)
                        console.print(f"[green]Loaded chat {sid}.[/green]\n")
                    else:
                        console.print("[yellow]Chat not found.[/yellow]\n")
                else:
                    console.print("[yellow]Usage: /load <number>[/yellow]\n")
                continue
            if cmd == "/save":
                save_dir = Path.home() / ".openartemis"
                save_dir.mkdir(parents=True, exist_ok=True)
                save_path = save_dir / "session.json"
                with open(save_path, "w", encoding="utf-8") as f:
                    json.dump(session.messages, f, indent=2, ensure_ascii=False)
                console.print(f"[green]Chat saved to {save_path}[/green]\n")
                continue
            if cmd == "/export":
                export_dir = Path("./detective_output")
                export_dir.mkdir(parents=True, exist_ok=True)
                ts = datetime.now().strftime("%Y-%m-%d_%H-%M")
                export_path = export_dir / f"chat_export_{ts}.md"
                lines = ["# Chat Export\n"]
                for m in session.messages:
                    role = m.get("role", "unknown")
                    content = m.get("content", "")
                    if role == "system":
                        continue
                    if role == "user":
                        lines.append(f"\n## You\n\n{content}\n")
                    elif role == "assistant":
                        lines.append(f"\n## Artemis\n\n{content}\n")
                    elif role == "tool":
                        lines.append(f"\n*[Tool result]*\n")
                export_path.write_text("\n".join(lines), encoding="utf-8")
                console.print(f"[green]Exported to {export_path}[/green]\n")
                continue
            if cmd == "/harvest":
                parts = user_input.strip().split(maxsplit=1)
                url = parts[1].strip() if len(parts) > 1 else ""
                if not url:
                    console.print("[yellow]/harvest requires a YouTube URL. Example: /harvest https://youtube.com/watch?v=xxx[/yellow]\n")
                    continue
                try:
                    with Progress(SpinnerColumn(), TextColumn("[dim]Harvesting...[/dim]"), console=console) as progress:
                        progress.add_task("", total=None)
                        result = session.agent.harvest_url(url)
                except Exception as e:
                    console.print(f"[red]Harvest failed: {e}[/red]\n")
                    continue
                if result.get("harvested_count") and not is_admin:
                    session.credits_used += 1
                    from openartemis.auth.db import log_usage
                    log_usage(user["id"], 1, "harvest")
                if result.get("harvested_count"):
                    console.print(f"[green]Harvested transcript: {result.get('title', '')}[/green]")
                    console.print(f"  [dim]Saved to {result.get('out_dir', '')}[/dim]")
                else:
                    console.print(f"[red]{result.get('error', 'Harvest failed')}[/red]")
                if session.credits_used > 0 and not is_admin:
                    console.print(f"  [dim][Credits used: {session.credits_used}][/dim]")
                console.print()
                continue
            if cmd == "/summarize":
                console.print(Panel("Summarize your last response in 2-3 sentences.", title="[cyan]You[/cyan]", border_style="cyan"))
                try:
                    with Progress(SpinnerColumn(), TextColumn("[dim]Artemis is thinking...[/dim]"), console=console) as progress:
                        progress.add_task("", total=None)
                        response = session.send("Summarize your last response in 2-3 sentences.")
                except Exception as e:
                    console.print(f"[red]Error: {e}[/red]\n")
                    continue
                console.print(Panel(Markdown(response or "(no response)"), title="[green]Artemis[/green]", border_style="green"))
                if session.credits_used > 0:
                    console.print(f"  [dim][Credits used: {session.credits_used}][/dim]")
                console.print()
                continue
            if cmd == "/model":
                from openartemis.config import resolve_artemis_model
                parts = user_input.strip().split(maxsplit=1)
                new_model = parts[1].strip() if len(parts) > 1 else ""
                if new_model:
                    alias = new_model.strip().lower()
                    if alias in ("artemis-1", "artemis-1-mini"):
                        session.model_display = "Artemis-1" if alias == "artemis-1" else "Artemis-1-Mini"
                        session.model = resolve_artemis_model(session.model_display)
                        console.print(f"[green]Model set to {session.model_display}[/green]\n")
                    else:
                        console.print("[yellow]Use Artemis-1 or Artemis-1-Mini[/yellow]\n")
                else:
                    console.print(f"[dim]Current model: {session.model_display}[/dim]")
                    console.print("[dim]Usage: /model Artemis-1 or /model Artemis-1-Mini[/dim]\n")
                continue
            if cmd == "/agent":
                _run_agent_mode_flow()
                continue
            if cmd == "/research":
                parts = user_input.strip().split(maxsplit=1)
                query = parts[1].strip() if len(parts) > 1 else ""
                if not query:
                    console.print("[yellow]/research requires a query. Example: /research Find out about recent AI developments[/yellow]\n")
                    continue
                from openartemis.agent import ResearchPipeline
                pipeline = ResearchPipeline(
                    youtube_api_key=os.environ.get("YOUTUBE_API_KEY"),
                    scrapingdog_api_key=os.environ.get("SCRAPINGDOG_API_KEY"),
                    transcriptapi_api_key=os.environ.get("TRANSCRIPTAPI_API_KEY"),
                    model=session.model,
                    out_dir=Path("./detective_output"),
                )
                def on_tool(name: str, args: dict) -> None:
                    if name == "harvest_transcripts":
                        console.print(f"  [dim]→ Harvesting: [bold]{args.get('query', '')}[/bold][/dim]")
                    elif name == "brave_search":
                        console.print(f"  [dim]→ Brave search: [bold]{args.get('q', '')}[/bold][/dim]")
                    elif name == "fetch_webpage":
                        console.print(f"  [dim]→ Fetching: [bold]{args.get('url', '')}[/bold][/dim]")
                    elif name == "browse_webpage":
                        console.print(f"  [dim]→ Browsing: [bold]{args.get('url', '')}[/bold][/dim]")
                try:
                    with Progress(SpinnerColumn(), TextColumn("[dim]Artemis is researching...[/dim]"), console=console) as progress:
                        progress.add_task("", total=None)
                        report = pipeline.run(query, on_tool_call=on_tool)
                    console.print(Panel(Markdown(report or "(no report)"), title="[green]Research Report[/green]", border_style="green"))
                except Exception as e:
                    console.print(f"[red]Research failed: {e}[/red]\n")
                console.print()
                continue

            mode_choice = questionary.select(
                "Select mode:",
                choices=[
                    questionary.Choice("Continue chat", value="chat"),
                    questionary.Choice("Research mode (Artemis will use tools)", value="research"),
                    questionary.Choice("Agent Mode", value="agent"),
                    questionary.Choice("Find videos (guided)", value="harvest"),
                    questionary.Choice("Exit", value="exit"),
                ],
                default="chat",
            ).ask()

            if mode_choice == "exit":
                console.print("[yellow]Bye.[/yellow]")
                raise typer.Exit(0)
            if mode_choice == "harvest":
                _interactive_mode()
                _welcome(chat=True)
                continue
            if mode_choice == "agent":
                _run_agent_mode_flow()
                continue
            if mode_choice == "research":
                console.print("[green]Research mode.[/green] Ask Artemis to research something.\n")
            continue

        # User message
        console.print(Panel(user_input, title="[cyan]You[/cyan]", border_style="cyan"))

        # Artemis response
        try:
            with Progress(
                SpinnerColumn(),
                TextColumn("[dim]Artemis is thinking...[/dim]"),
                console=console,
            ) as progress:
                progress.add_task("", total=None)
                response = session.send(user_input)
                session.persist()
        except Exception as e:
            err_msg = str(e)
            if "402" in err_msg or "insufficient" in err_msg.lower():
                console.print("[red]Something went wrong with credits. Please try again later.[/red]")
            elif "401" in err_msg or "authentication" in err_msg.lower():
                console.print("[red]Something went wrong. Check your settings and try again.[/red]")
            elif "rate" in err_msg.lower() or "429" in err_msg:
                console.print("[red]Too many requests. Please wait a moment and try again.[/red]")
            else:
                console.print("[red]Something went wrong. Try again or type /help.[/red]")
            console.print()
            continue
        console.print(Panel(Markdown(response or "(no response)"), title="[green]Artemis[/green]", border_style="green"))
        if session.credits_used > 0 and not is_admin:
            console.print(f"  [dim][Credits used: {session.credits_used}][/dim]")
            if session.credits_used >= 50:
                console.print(
                    "  [yellow]You've used many credits this session. Check your balance at transcriptapi.com[/yellow]"
                )
        console.print()


@app.callback(invoke_without_command=True)
def main(ctx: typer.Context) -> None:
    """Chat with Artemis — uses research tools when you ask. Type / for menu."""
    if ctx.invoked_subcommand is not None:
        return
    user = _get_authenticated_user()
    _chat_mode(user)


@app.command()
def harvest() -> None:
    """Guided harvest — step-by-step transcript download."""
    _get_authenticated_user()
    _interactive_mode()


@app.command()
def investigate(
    prompt: str = typer.Argument(None, help="What to find out (e.g. 'Find everything about what happened to John Smith')"),
    openai_api_key: str | None = typer.Option(
        None,
        "--openai-api-key",
        envvar="OPENAI_API_KEY",
        help="OpenAI API key",
    ),
    model: str = typer.Option(
        "artemis-1-mini",
        "--model", "-m",
        help="Artemis model (Artemis-1-Mini or Artemis-1)",
    ),
    out_dir: Path = typer.Option(
        Path("./detective_output"),
        "--out-dir", "-o",
        help="Where to save transcripts and report",
        path_type=Path,
    ),
) -> None:
    """Artemis detective — tell it what to find, it harvests and researches for you."""
    user = _get_authenticated_user()
    if not prompt or not prompt.strip():
        _welcome()
        prompt = questionary.text(
            "What would you like Artemis to find out?",
            default="",
            instruction="(e.g. Find everything about what happened to [person name])",
        ).ask()
        if not prompt or not prompt.strip():
            console.print("[yellow]No prompt entered.[/yellow]")
            raise typer.Exit(1)

    if not openai_api_key:
        console.print(
            "[red]OpenAI API key required.[/red] Set [bold]OPENAI_API_KEY[/bold] or use [bold]--openai-api-key[/bold].\n"
            "[dim]Get a key at platform.openai.com — gpt-4o-mini is ~$0.15/1M input tokens.[/dim]"
        )
        raise typer.Exit(1)

    _welcome()
    console.print(Panel(
        f"[bold]Your request:[/bold] {prompt}\n\n"
        f"[dim]Artemis will search YouTube, TikTok, Instagram, X, read transcripts, and follow leads until it has answers.[/dim]",
        title="[cyan]Detective mode[/cyan]",
        border_style="cyan",
    ))
    console.print()

    from openartemis.agent import ResearchPipeline

    def on_tool(name: str, args: dict) -> None:
        if name == "harvest_transcripts":
            q = args.get("query", "")
            p = args.get("platforms", ["youtube"])
            console.print(f"  [dim]→ Finding videos: [bold]{q}[/bold] on {', '.join(p)}[/dim]")
        elif name == "read_transcript":
            console.print(f"  [dim]→ Reading transcript...[/dim]")
        elif name == "brave_search":
            console.print(f"  [dim]→ Brave search: [bold]{args.get('q', '')}[/bold][/dim]")
        elif name == "fetch_webpage":
            console.print(f"  [dim]→ Fetching: [bold]{args.get('url', '')}[/bold][/dim]")
        elif name == "browse_webpage":
            console.print(f"  [dim]→ Browsing: [bold]{args.get('url', '')}[/bold][/dim]")

    from openartemis.config import resolve_artemis_model
    pipeline = ResearchPipeline(
        openai_api_key=openai_api_key,
        youtube_api_key=os.environ.get("YOUTUBE_API_KEY"),
        scrapingdog_api_key=os.environ.get("SCRAPINGDOG_API_KEY"),
        transcriptapi_api_key=os.environ.get("TRANSCRIPTAPI_API_KEY"),
        model=resolve_artemis_model(model),
        out_dir=out_dir,
    )

    def _on_tool(name: str, args: dict) -> None:
        on_tool(name, args)
        if name == "harvest_transcripts" and user.get("role") != "admin":
            from openartemis.auth.db import log_usage
            log_usage(user["id"], 1, "investigate")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Artemis is researching...", total=None)
        report = pipeline.run(prompt, on_tool_call=_on_tool)
        progress.update(task, description="[green]✓[/green] Done")

    report_path = out_dir / "report.md"
    report_path.write_text(report, encoding="utf-8")

    console.print()
    console.print(Panel(
        f"[bold green]Report saved to:[/bold green] [cyan]{report_path}[/cyan]\n\n"
        f"[dim]Transcripts: {out_dir}[/dim]",
        title="Done",
        border_style="green",
    ))
    console.print()
    console.print(Panel(report[:2000] + ("..." if len(report) > 2000 else ""), title="Report preview", border_style="dim"))


@app.command()
def admin() -> None:
    """Admin panel — manage users, approve requests, view usage."""
    init_db()
    if get_user_count() == 0:
        console.print("[yellow]No users. Run openartemis first to create admin.[/yellow]")
        raise typer.Exit(1)
    user = get_session_user()
    if not user or user.get("role") != "admin":
        console.print("[bold]Admin login[/bold]")
        username = questionary.text("Username:").ask()
        password = questionary.password("Password:").ask()
        if not username or not password:
            raise typer.Exit(1)
        user = login(username, password)
        if not user or user.get("role") != "admin":
            console.print("[red]Admin access required.[/red]")
            raise typer.Exit(1)
        create_session(user["id"])
    _admin_loop(user)


def _admin_loop(admin_user: dict) -> None:
    """Admin menu loop."""
    from openartemis.auth.db import (
        list_users,
        revoke_user,
        create_user_direct,
        get_usage_by_user,
    )
    while True:
        choice = questionary.select(
            "Admin:",
            choices=[
                questionary.Choice("Generate invite code", value="invite"),
                questionary.Choice("List all users", value="users"),
                questionary.Choice("View usage (credits per user)", value="usage"),
                questionary.Choice("Create user (direct)", value="create"),
                questionary.Choice("Revoke user access", value="revoke"),
                questionary.Choice("Logout", value="logout"),
            ],
        ).ask()
        if choice == "logout":
            revoke_session()
            console.print("[green]Logged out.[/green]")
            raise typer.Exit(0)
        if choice == "invite":
            email = questionary.text("Email for code (optional):").ask() or None
            code, expires = create_invite_code(admin_user["id"], email)
            console.print(Panel(
                f"[bold green]Invite code:[/bold green] [cyan]{code}[/cyan]\n\n"
                f"Expires: {expires.strftime('%Y-%m-%d %H:%M')} UTC\n\n"
                f"[dim]Send this code to the user. They enter it at sign-in.[/dim]",
                title="Invite Code",
                border_style="green",
            ))
            console.print()
        elif choice == "users":
            users = list_users()
            for u in users:
                role = "[admin]" if u["role"] == "admin" else ""
                approved = "✓" if u["approved"] else "pending"
                console.print(f"  {u['id']}: {u['username']} {u['email']} {role} [{approved}]")
            console.print()
        elif choice == "usage":
            usage = get_usage_by_user()
            for u in usage:
                console.print(f"  {u['username']}: {u['total_credits']} credits")
            console.print()
        elif choice == "create":
            email = questionary.text("Email:").ask()
            username = questionary.text("Username:").ask()
            password = questionary.password("Password:").ask()
            if email and username and password:
                ok, msg = create_user_direct(email, username, password, approved=True)
                console.print(f"[green]{msg}[/green]" if ok else f"[red]{msg}[/red]")
            console.print()
        elif choice == "revoke":
            users = list_users()
            for u in users:
                if u["role"] != "admin":
                    console.print(f"  {u['id']}: {u['username']}")
            uid_str = questionary.text("User id to revoke:").ask()
            if uid_str:
                try:
                    uid = int(uid_str)
                    if revoke_user(uid):
                        console.print("[green]Revoked.[/green]")
                    else:
                        console.print("[red]Failed.[/red]")
                except ValueError:
                    console.print("[red]Invalid id.[/red]")
            console.print()


@app.command()
def agent(
    prompt: str = typer.Argument(..., help="What to build (e.g. 'Build a Flappy Bird game')"),
    background: bool = typer.Option(False, "--background", "-b", help="Run in background; check results later"),
) -> None:
    """Agent Mode — build things with AI. Runs until done; supports long tasks."""
    _get_authenticated_user()
    if background:
        _run_agent_background(prompt)
    else:
        _run_agent_foreground(prompt)


@app.command(hidden=True)
def agent_run(
    prompt: str = typer.Argument(...),
    output_path: str = typer.Argument(...),
) -> None:
    """Internal: run agent in background. Do not call directly."""
    load_config()
    from openartemis.agent.agent_orchestrator import run_agent_mode

    path = Path(output_path)
    running_marker = path.parent / f"{path.name}.running"
    try:
        run_agent_mode(prompt, output_path=path)
    except Exception as e:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(f"# Error\n\n{str(e)}", encoding="utf-8")
    finally:
        if running_marker.exists():
            running_marker.unlink(missing_ok=True)


@app.command()
def agent_status() -> None:
    """Show recent agent runs and their status."""
    AGENT_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    running = list(AGENT_OUTPUT_DIR.glob("*.running"))
    completed = sorted(AGENT_OUTPUT_DIR.glob("*.md"), key=lambda p: p.stat().st_mtime, reverse=True)[:10]
    if running:
        console.print("[yellow]Running:[/yellow]")
        for r in running:
            req = r.read_text(encoding="utf-8", errors="replace")[:60]
            console.print(f"  • {req}...")
        console.print()
    if completed:
        console.print("[green]Recent results:[/green]")
        for p in completed:
            mtime = datetime.fromtimestamp(p.stat().st_mtime).strftime("%Y-%m-%d %H:%M")
            console.print(f"  • {mtime} — [cyan]{p.name}[/cyan]")
        console.print(f"\n[dim]Results: {AGENT_OUTPUT_DIR}[/dim]")
    elif not running:
        console.print("[dim]No agent runs yet.[/dim]")


@app.command()
def logout() -> None:
    """Log out of current session."""
    revoke_session()
    console.print("[green]Logged out.[/green]")


@app.command()
def config() -> None:
    """Show configuration help and required env vars."""
    _welcome()
    table = Table(title="Configuration")
    table.add_column("Variable", style="cyan")
    table.add_column("Required for", style="green")
    table.add_column("Where to get it", style="dim")
    table.add_row(
        "ffmpeg (system)",
        "TikTok, Instagram, X, Whisper audio",
        "winget install ffmpeg | brew install ffmpeg | apt install ffmpeg",
    )
    table.add_row(
        "YOUTUBE_API_KEY",
        "YouTube (Google API, if not using TranscriptAPI)",
        "Google Cloud Console → APIs & Services → YouTube Data API v3",
    )
    table.add_row(
        "TRANSCRIPTAPI_API_KEY",
        "YouTube search + transcripts (TranscriptAPI.com)",
        "transcriptapi.com — replaces Google API",
    )
    table.add_row(
        "SCRAPINGDOG_API_KEY",
        "YouTube transcripts (optional, if not using TranscriptAPI)",
        "scrapingdog.com",
    )
    table.add_row(
        "OPENAI_API_KEY",
        "Artemis chat (investigate command)",
        "platform.openai.com",
    )
    table.add_row(
        "BRAVE_SEARCH_API_KEY",
        "Web search in research (brave_search tool)",
        "search.brave.com — free tier available",
    )
    console.print(table)
    console.print("\n[dim]Set in your shell or use the corresponding --*-api-key flags[/dim]")


def main() -> None:
    """Entry point for openartemis command."""
    app()


if __name__ == "__main__":
    main()
