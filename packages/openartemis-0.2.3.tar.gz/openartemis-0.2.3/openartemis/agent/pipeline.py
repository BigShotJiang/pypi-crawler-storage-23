"""Multi-agent pipeline — plan, run workers in parallel, synthesize report."""

import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Callable

from dotenv import load_dotenv
from openai import OpenAI

load_dotenv(Path(__file__).resolve().parents[2] / ".env")

from openartemis.agent.detective import DetectiveAgent
from openartemis.agent.orchestrator import create_plan
from openartemis.agent.worker import run_worker

SYNTHESIS_PROMPT = """You are synthesizing research results from multiple parallel workers into one coherent report.

The user asked: {user_request}

Here are the worker results (each worker researched a different angle):

{worker_results}

Synthesize these into a single, well-structured report. Include:
- Executive summary
- Key findings (with sources)
- Conclusions
- Sources/URLs

Be concise but comprehensive. Do not invent information not present in the worker results."""


class ResearchPipeline:
    """Multi-agent research: plan → 5 parallel workers → synthesize."""

    def __init__(
        self,
        openai_api_key: str | None = None,
        youtube_api_key: str | None = None,
        scrapingdog_api_key: str | None = None,
        transcriptapi_api_key: str | None = None,
        model: str = "gpt-4o-mini",
        out_dir: Path | None = None,
        max_workers: int = 5,
    ):
        self.agent = DetectiveAgent(
            openai_api_key=openai_api_key,
            youtube_api_key=youtube_api_key or os.environ.get("YOUTUBE_API_KEY"),
            scrapingdog_api_key=scrapingdog_api_key or os.environ.get("SCRAPINGDOG_API_KEY"),
            transcriptapi_api_key=transcriptapi_api_key or os.environ.get("TRANSCRIPTAPI_API_KEY"),
            model=model,
            out_dir=out_dir or Path("./detective_output"),
        )
        self.client = OpenAI(api_key=openai_api_key or os.environ.get("OPENAI_API_KEY"))
        self.model = model
        self.max_workers = max_workers

    def run(
        self,
        user_request: str,
        on_tool_call: Callable[[str, dict], None] | None = None,
    ) -> str:
        """Run full pipeline: plan → workers (parallel) → synthesize. Returns final report."""
        tasks = create_plan(user_request, model=self.model)
        if not tasks:
            return "Could not create a research plan. Please try rephrasing your request."

        worker_results: list[dict[str, Any]] = []

        def run_one(task: dict) -> dict[str, Any]:
            return run_worker(task, self.agent, on_tool_call=on_tool_call)

        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = {executor.submit(run_one, t): t for t in tasks}
            for future in as_completed(futures):
                try:
                    result = future.result()
                    worker_results.append(result)
                except Exception as e:
                    task = futures[future]
                    worker_results.append({
                        "task_id": task.get("id", 0),
                        "summary": f"Error: {e}",
                        "findings": [],
                        "sources": [],
                    })

        # Sort by task_id for consistent ordering
        worker_results.sort(key=lambda r: r.get("task_id", 0))

        # Build synthesis input
        results_text = "\n\n---\n\n".join(
            f"Task {r['task_id']}:\n{r['summary']}\n\nFindings: {r.get('findings', [])}\nSources: {r.get('sources', [])}"
            for r in worker_results
        )

        synthesis_resp = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": "You synthesize research into clear reports."},
                {"role": "user", "content": SYNTHESIS_PROMPT.format(
                    user_request=user_request,
                    worker_results=results_text,
                )},
            ],
        )
        report = (synthesis_resp.choices[0].message.content or "").strip()
        return report
