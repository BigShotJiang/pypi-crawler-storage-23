"""Worker agent — runs one task with full tool access, returns summary and findings."""

import json
import os
from pathlib import Path
from typing import Any, Callable

from dotenv import load_dotenv
from openai import OpenAI

load_dotenv(Path(__file__).resolve().parents[2] / ".env")

from openartemis.agent.detective import TOOLS, DetectiveAgent

WORKER_SYSTEM = """You are a research worker. You receive ONE task and must complete it using your tools.

Tools: harvest_transcripts, list_transcripts, read_transcript, brave_search, fetch_webpage, browse_webpage.

When done, provide a concise summary and list key findings with sources (URLs). Be thorough but focused on the task."""


def run_worker(
    task: dict,
    agent: DetectiveAgent,
    on_tool_call: Callable[[str, dict], None] | None = None,
    max_turns: int = 10,
) -> dict[str, Any]:
    """Run a single worker on one task. Returns {task_id, summary, findings, sources}."""
    task_id = task.get("id", 0)
    description = task.get("description", "")
    hint = task.get("hint", "")
    url = task.get("url", "")

    # Build user message with task context
    user_msg = f"Task: {description}"
    if hint:
        user_msg += f"\nHint: use {hint}"
    if url:
        user_msg += f"\nURL: {url}"

    messages = [
        {"role": "system", "content": WORKER_SYSTEM},
        {"role": "user", "content": user_msg},
    ]

    for _ in range(max_turns):
        response = agent.client.chat.completions.create(
            model=agent.model,
            messages=messages,
            tools=TOOLS,
            tool_choice="auto",
        )
        msg = response.choices[0].message
        msg_dict = (
            msg.model_dump() if hasattr(msg, "model_dump") else
            {"role": msg.role, "content": msg.content or "", "tool_calls": getattr(msg, "tool_calls", None)}
        )
        messages.append(msg_dict)

        if not msg.tool_calls:
            content = (msg.content or "").strip()
            # Extract findings/sources from content heuristically
            findings = []
            sources = []
            for line in content.split("\n"):
                if line.strip().startswith("-") or line.strip().startswith("*"):
                    findings.append(line.strip())
                if "http" in line:
                    for part in line.split():
                        if part.startswith("http"):
                            sources.append(part.rstrip(".,)"))
            return {
                "task_id": task_id,
                "summary": content[:2000],
                "findings": findings[:20],
                "sources": list(dict.fromkeys(sources))[:15],
            }

        for tc in msg.tool_calls:
            name = tc.function.name
            args = json.loads(tc.function.arguments)
            if on_tool_call:
                on_tool_call(name, args)
            result = agent._execute_tool(name, args)
            messages.append({
                "role": "tool",
                "tool_call_id": tc.id,
                "content": result,
            })

    return {
        "task_id": task_id,
        "summary": "Max turns reached.",
        "findings": [],
        "sources": [],
    }
