---
name: "power-synth-sdk"
displayName: "SynthAgentSDK Power"
description: "Synth is a layered Python SDK for building production-grade AI agents and multi-agent systems. The architecture follows a composable, bottom-up design: a minimal core (Agent, Tool, RunResult) that works standalone, with orchestration layers (Pipeline, Graph, AgentTeam) composed on top. Provider adapters abstract LLM backends behind a unified interface. Cross-cutting concerns (Memory, Guards, Tracing, Checkpointing) are pluggable middleware that attach to any layer. The SDK targets Python 3.10+ and provides both sync and async APIs. The package uses optional extras (synth-agent-sdk[openai], synth-agent-sdk[anthropic], synth-agent-sdk[agentcore], etc.) to keep the core install minimal."
keywords: ["synth", "agent", "sdk", "tool", "pipeline", "graph", "team", "guard", "memory", "eval", "tracing", "agentcore", "structured-output", "provider", "streaming", "checkpoint", "cli", "tui", "mcp", "bench", "init", "create"]
author: "Synth"
---

# SynthAgentSDK Power

Synth is a layered Python SDK for building production-grade AI agents and multi-agent systems. The architecture follows a composable, bottom-up design: a minimal core (Agent, Tool, RunResult) that works standalone, with orchestration layers (Pipeline, Graph, AgentTeam) composed on top. Provider adapters abstract LLM backends behind a unified interface. Cross-cutting concerns (Memory, Guards, Tracing, Checkpointing) are pluggable middleware that attach to any layer.

The SDK targets Python 3.10+ and provides both sync and async APIs. The package uses optional extras (`synth-agent-sdk[openai]`, `synth-agent-sdk[anthropic]`, `synth-agent-sdk[agentcore]`, etc.) to keep the core install minimal.

**Latest Version:** 0.9.15

Install: `pip install synth-agent-sdk[anthropic]` (recommended) or `pip install synth-agent-sdk[quickstart]` (Claude + GPT)
Import: `from synth import Agent, tool, Graph, Pipeline`
CLI: `synth` or `python -m synth`

First-time users: Run `synth` after installation to see the welcome guide with setup instructions.

## Architecture

```
Public API Layer:    Agent, Pipeline, Graph, AgentTeam, Eval, CLI
Middleware Layer:    Guards, Memory, Tracing, Checkpointing, Structured Output
Provider Layer:      ProviderRouter → Anthropic, OpenAI, Google, Ollama, Bedrock
Tool System:         @tool decorator, ToolKit, JSON Schema Generator, ToolExecutor
Deployment Layer:    AgentCore Adapter, agentcore_handler() → BedrockAgentCoreApp, Deployer
Observability Layer: Dashboard Server, AgentCore Evaluations, Credential Scrubbing
```

## Package Structure

```
synth/
├── __init__.py              # Public API exports
├── __main__.py              # python -m synth entry point
├── agent.py                 # Agent class (sync/async run, stream)
├── types.py                 # RunResult, event types, config types
├── errors.py                # SynthError hierarchy
├── _compat.py               # Sync/async compatibility utilities
├── tools/
│   ├── decorator.py         # @tool decorator and schema generation
│   ├── toolkit.py           # ToolKit class
│   └── executor.py          # ToolExecutor (invocation + error handling)
├── providers/
│   ├── router.py            # ProviderRouter (model string → provider)
│   ├── base.py              # BaseProvider ABC
│   ├── anthropic.py         # AnthropicProvider
│   ├── openai.py            # OpenAIProvider
│   ├── google.py            # GoogleProvider
│   ├── ollama.py            # OllamaProvider
│   ├── bedrock.py           # BedrockProvider (AWS Bedrock Runtime, blank-text sanitization)
│   └── retry.py             # Retry logic with exponential backoff
├── memory/
│   ├── base.py              # BaseMemory ABC
│   ├── thread.py            # ThreadMemory (in-process)
│   ├── persistent.py        # PersistentMemory (Redis)
│   └── semantic.py          # SemanticMemory (vector embeddings)
├── orchestration/
│   ├── pipeline.py          # Pipeline class
│   ├── graph.py             # Graph class, @node decorator, edge routing
│   ├── team.py              # AgentTeam class
│   └── human_in_loop.py     # PausedRun, human-in-the-loop logic
├── guards/
│   ├── base.py              # BaseGuard ABC
│   ├── pii.py               # PII detection guard
│   ├── cost.py              # Cost limit guard
│   ├── tool_filter.py       # Tool call filter guard
│   └── custom.py            # Custom guard wrapper
├── tracing/
│   ├── trace.py             # Trace class, span collection
│   ├── exporter.py          # OTEL JSON export, endpoint forwarding
│   └── integrations.py      # Langfuse, Datadog, Honeycomb adapters
├── checkpointing/
│   ├── base.py              # BaseCheckpointStore ABC
│   ├── local.py             # LocalCheckpointStore (disk)
│   └── redis.py             # RedisCheckpointStore
├── eval/
│   ├── eval.py              # Eval class, case management
│   ├── scorers.py           # ExactMatch, SemanticSimilarity scorers
│   └── report.py            # EvalReport, comparison logic
├── structured/
│   └── output.py            # Pydantic schema enforcement, retry parsing
├── deploy/
│   └── agentcore/
│       ├── adapter.py       # AgentCore payload translation (validates schema, extracts user_id from JWT)
│       ├── handler.py       # agentcore_handler() → BedrockAgentCoreApp
│       ├── manifest.py      # Agent descriptor generation
│       ├── memory.py        # AgentCore memory integration
│       ├── auth.py          # extract_user_id() (JWT), get_gateway_token() (OAuth2)
│       ├── ssm.py           # get_ssm_parameter() helper
│       ├── gateway.py       # GatewayMCPClient + create_gateway_client() factory
│       ├── code_interpreter.py  # CodeInterpreterTools (managed sandbox)
│       ├── credentials.py   # CredentialResolver — detect AWS creds (env/file/toolkit)
│       └── model_catalog.py # ModelCatalog + RegionValidator (CRIS-aware model selection)
└── cli/
    ├── main.py              # CLI entry point (click-based)
    ├── shell.py             # Interactive shell REPL (prompt_toolkit, no-arg entry)
    ├── _tui.py              # Rich terminal UI (Fallout-inspired TUI)
    ├── dev.py               # synth dev (rich TUI or basic REPL fallback)
    ├── run_cmd.py           # synth run
    ├── eval_cmd.py          # synth eval
    ├── trace_cmd.py         # synth trace
    ├── deploy_cmd.py        # synth deploy (Deploy_Wizard: 6-stage guided deployment)
    ├── doctor.py            # synth doctor (checks env, deps, AgentCore config)
    ├── create_cmd.py        # synth create (agent, team, tool, mcp, ui, agentcore)
    ├── init_cmd.py          # synth init (interactive project setup + Tool/MCP wizards + eval config)
    ├── edit_cmd.py          # synth edit agent <file> (Edit_Wizard: modify existing agents)
    ├── bench_cmd.py         # synth bench (performance benchmarking)
    ├── help_cmd.py          # synth help (curated quick-reference)
    ├── welcome.py           # First-run welcome message (tracked via ~/.synth/.welcome_shown)
    ├── package_info.py      # synth info --extra <name> (shows provider/deps/models)
    └── banner.py            # Boot sequence / terminal branding
```

## Quick Start

```python
from synth import Agent, tool

@tool
def get_weather(city: str) -> str:
    """Get the current weather for a city."""
    return f"Sunny, 72°F in {city}"

agent = Agent(
    model="claude-sonnet-4-5",
    instructions="You are a helpful assistant.",
    tools=[get_weather],
)

result = agent.run("What's the weather in Seattle?")
print(result.text)
```

**Installation:**
```bash
# Recommended for most users
pip install synth-agent-sdk[anthropic]

# For tutorials/demos (Claude + GPT)
pip install synth-agent-sdk[quickstart]

# For AgentCore deployment
pip install synth-agent-sdk[agentcore]

# All providers
pip install synth-agent-sdk[all]
```

**First-time setup:**
```bash
synth              # See welcome guide
synth doctor       # Verify setup
synth info         # View package options
```

## Core Agent

```python
class Agent:
    def __init__(
        self,
        model: str | None = None,
        instructions: str = "",
        tools: list[Callable | ToolKit] | None = None,
        memory: BaseMemory | None = None,
        guards: list[BaseGuard] | None = None,
        output_schema: type[BaseModel] | None = None,
        base_url: str | None = None,
        max_retries: int = 3,
        retry_backoff: float = 1.0,
    ): ...

    def run(self, prompt, thread_id=..., run_id=...) -> RunResult
    async def arun(self, prompt, ...) -> RunResult
    def stream(self, prompt, ...) -> Generator[StreamEvent]
    async def astream(self, prompt, ...) -> AsyncGenerator[StreamEvent]
```

Agent execution flow:
1. Memory retrieval (if configured) → prepend context messages
2. Input guard evaluation (in declaration order)
3. Provider call (via ProviderRouter) with tool schemas
4. Tool execution loop (if model requests tool calls)
5. Output guard evaluation
6. Structured output parsing (if output_schema set)
7. Trace finalization and attachment to RunResult

## Tool System

```python
@tool
def search_docs(query: str, limit: int = 5) -> list[str]:
    """Search the documentation for relevant articles."""
    return ["Article 1", "Article 2"]

toolkit = ToolKit([search_docs, another_tool])
agent = Agent(model="gpt-4o", tools=[toolkit])
```

Requirements for `@tool`:
- Every parameter must have a type annotation
- The function must have a docstring (sent to the LLM as the tool description)
- Missing either raises `ToolDefinitionError` at decoration time
- Async tool functions are automatically detected and awaited

## Provider Routing

| Prefix | Provider | Install |
|--------|----------|---------|
| `claude-` | Anthropic | `pip install synth-agent-sdk[anthropic]` |
| `gpt-` | OpenAI | `pip install synth-agent-sdk[openai]` |
| `gemini-` | Google | `pip install synth-agent-sdk[google]` |
| `ollama/` | Ollama | `pip install synth-agent-sdk[ollama]` |
| `bedrock/` | AWS Bedrock | `pip install synth-agent-sdk[bedrock]` |

**Installation Options:**
- `synth-agent-sdk[quickstart]` — Installs both Anthropic and OpenAI (perfect for tutorials/demos)
- `synth-agent-sdk[ui]` — Installs uvicorn and fastapi for the browser testing dashboard
- `synth-agent-sdk[agentcore]` — Includes boto3 and bedrock-agentcore for AgentCore deployment
- `synth-agent-sdk[all]` — Installs all providers at once

Custom endpoints: pass `base_url` to use any OpenAI-compatible API.
Missing provider packages raise `SynthConfigError` with the exact `pip install` command.

**Bedrock provider notes:** The Bedrock Converse API rejects empty text content blocks. The `BedrockProvider` automatically sanitizes all message content (system, user/assistant, and tool results) via `_sanitize_text()`, replacing blank or whitespace-only strings with `"(no content)"`. This prevents `ValidationException` errors when tools return empty results.

**First-time users:** Run `synth` to see the welcome guide, `synth doctor` to verify setup, and `synth info --extra <name>` to view what's included in each installation option.

## Memory

```python
Memory.thread()                              # In-process dict keyed by thread_id
Memory.persistent("redis://localhost:6379")   # Redis-backed storage
Memory.semantic(embedder=my_embedder)         # Vector embeddings with cosine similarity
```

## Guards

```python
Guard.no_pii_output()              # Block PII in responses
Guard.max_cost(dollars=0.50)       # Cost limit per run (raises CostLimitError)
Guard.no_tool_calls(["delete_*"])  # Block dangerous tools via glob patterns
Guard.custom(my_check_fn)          # Custom validation function
```

Guards evaluate in declaration order. First violation raises `GuardViolationError`.

## Structured Output

```python
class Analysis(BaseModel):
    sentiment: str
    confidence: float

agent = Agent(model="claude-sonnet-4-5", output_schema=Analysis)
result = agent.run("Analyze this text")
print(result.output.sentiment)  # Parsed Pydantic model
```

## Orchestration

### Pipeline
```python
pipeline = Pipeline([researcher, writer, editor])
result = pipeline.run("Quantum computing trends")
```

### Graph
```python
graph = Graph(state_schema=MyState)
graph.set_entry("classify")
graph.add_edge("classify", "handle_positive", when=lambda s: s.sentiment == "positive")
graph.add_edge("classify", "handle_negative", when=lambda s: s.sentiment == "negative")
graph.add_edge("handle_positive", Graph.END)
result = graph.run(initial_state, max_iterations=100)
```

### AgentTeam
```python
team = AgentTeam(
    orchestrator="claude-sonnet-4-5",
    agents=[researcher, coder, reviewer],
    strategy="auto",  # or "parallel"
)
result = team.run("Build a REST API")
```

## CLI Commands

Run `synth` or `python -m synth` to see the SynthAgentSDK boot sequence.

| Command | Description |
|---------|-------------|
| `synth` | Launch interactive shell — type commands without the `synth` prefix (e.g. `run agent.py "Hi"`) |
| `synth create agent <name>` | Scaffold a new agent (interactive provider selection) |
| `synth create agentcore <name>` | Scaffold an AWS AgentCore deployment project |
| `synth create team <name>` | Scaffold a multi-agent team + pipeline |
| `synth create tool <name>` | Generate a standalone tools file |
| `synth create mcp <name>` | Scaffold an MCP server with FastMCP |
| `synth create ui <name>` | Scaffold a local browser-based testing UI |
| `synth init` | Interactive project setup (like npm init for agents) |
| `synth dev <file>` | Rich terminal UI with streaming, slash commands, tool visualization |
| `synth run <file> "prompt"` | Execute agent, print result |
| `synth eval <file> --dataset <json>` | Run evaluation suite |
| `synth bench <file> "prompt" -n 20` | Benchmark latency, tokens, and cost |
| `synth trace <run_id>` | Open trace in browser |
| `synth deploy --target agentcore` | Deploy to AWS AgentCore |
| `synth deploy --target agentcore --dry-run` | Validate stages 1–4 without submitting |
| `synth edit agent <file>` | Modify an existing agent's model, instructions, tools, or MCP servers |
| `synth doctor` | Check env, credentials, dependencies, and AgentCore config (suggests missing provider installs) |
| `synth info --extra <name>` | Show what's included in each installation option |
| `synth help` | Show curated getting-started guide |

### synth dev — Rich Terminal UI

`synth dev` launches a Fallout-inspired terminal interface with:
- Streaming token-by-token response rendering
- Tool call visualization with inline args/results
- Slash commands: `/tools`, `/reload`, `/trace`, `/export`, `/clear`, `/model`, `/cost`, `/help`, `/quit`
- Markdown rendering for agent responses
- Persistent status bar (model, turns, tokens, cost, latency)
- Multi-line input (backslash continuation)
- Command history with up/down arrows

### synth create — Scaffolding

`synth create agent <name>` prompts for provider selection (Anthropic, OpenAI, Llama, Gemini, AgentCore) and generates provider-specific scaffolding with the correct model string, pip extra, env var setup, and deployment config for AgentCore.

`synth create agentcore <name>` creates a complete AWS AgentCore deployment project with:
- Agent file with `agentcore_handler`
- `requirements.txt` for dependencies
- `agentcore.yaml` for deployment configuration (IAM permissions, runtime settings)
- Comprehensive README with local development and deployment instructions

This is the recommended way to start an AgentCore project as it includes all necessary configuration files.

### synth info — Package Information

`synth info --extra <name>` displays what's included in each installation option (provider name, dependencies, available models). Useful for understanding what you're installing before running `pip install`.

Examples:
- `synth info --extra anthropic`
- `synth info --extra quickstart`
- `synth info --extra all`

### synth doctor — Diagnostics

`synth doctor` checks your environment and suggests fixes. If providers are missing, it shows:
```
Missing provider packages:
  Install all: pip install synth-agent-sdk[all]
  Or individually: pip install synth[anthropic] synth[openai]
```

### synth init — Interactive Setup

`synth init` walks through project name, description, provider, model selection (region-aware for AgentCore), agent instructions, tool wizard, MCP wizard, feature toggles (memory, guards, structured output, eval, deploy), and credential check (AgentCore only). After generation, AgentCore projects get a "Deploy now?" prompt. Generates a tailored project with `agent.py`, `tools.py`, `synth.toml`, and `README.md`. For AgentCore + eval, also generates `eval_config.json` with built-in evaluators and updates `agentcore.yaml` with evaluations section and IAM permissions.

### synth bench — Benchmarking

`synth bench agent.py "Hello" --runs 20 --warmup 2` runs the agent N times and reports p50/p95/p99 latency, average/total tokens, per-run and total cost, and success rate.

If `synth` is not on your PATH (common on Windows), use `python -m synth` as an alternative, or install via `pipx install synth-agent-sdk[anthropic]` which handles PATH automatically.
Set `SYNTH_NO_BANNER=1` to suppress the boot sequence.

## Error Hierarchy

All errors inherit from `SynthError` with `component` and `suggestion` fields:

| Error | When |
|-------|------|
| `SynthConfigError` | Missing API key, invalid model, missing package |
| `ToolDefinitionError` | `@tool` missing annotations or docstring |
| `ToolExecutionError` | Tool function raises during execution |
| `GuardViolationError` | Guard constraint violated |
| `CostLimitError` | Cost guard limit exceeded |
| `SynthParseError` | Structured output parse failure after retries |
| `GraphRoutingError` | No matching edge condition at a node |
| `GraphLoopError` | Graph exceeds max_iterations |
| `RunNotFoundError` | Checkpoint not found for run_id |
| `PipelineError` | Pipeline step failure (includes partial results) |

## Data Models

```python
@dataclass
class RunResult:
    text: str                          # Model's text response
    output: BaseModel | None           # Parsed structured output
    tokens: TokenUsage                 # input_tokens, output_tokens, total_tokens
    cost: float                        # Estimated cost in USD
    latency_ms: float                  # Wall-clock time
    trace: Trace                       # Full execution trace
    tool_calls: list[ToolCallRecord]   # Record of all tool invocations

# Stream events
StreamEvent = TokenEvent | ToolCallEvent | ToolResultEvent | ThinkingEvent | DoneEvent | ErrorEvent

@dataclass
class TeamResult:
    answer: str
    contributions: list[AgentContribution]
    message_trace: list[Message]
    total_cost: float
    total_latency_ms: float
```

## Environment Variables

| Variable | Purpose |
|----------|---------|
| `SYNTH_TRACE_ENDPOINT` | Auto-forward traces to OTEL collector |
| `SYNTH_NO_BANNER` | Skip terminal boot sequence |
| `ANTHROPIC_API_KEY` | Anthropic API key |
| `OPENAI_API_KEY` | OpenAI API key |
| `GOOGLE_API_KEY` | Google API key |

# When to Load Steering Files

- Building agents, adding tools, memory, guards, or structured output → `building-agents.md`
- Working with Pipeline, Graph, or AgentTeam orchestration → `orchestration-patterns.md`
- Using the CLI (dev, create, init, bench, deploy), tracing, checkpointing, or deploying to AgentCore → `deployment-guide.md`
- Working with AgentCore Evaluations (eval config, dashboard evaluations tab, evaluation endpoints) → `deployment-guide.md`
