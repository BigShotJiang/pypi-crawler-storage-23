# NeuroSim — Architecture Specification

> A Gymnasium Platform for Reinforcement Learning in Brain-Computer Interfaces

**Author:** Hass Dhia — Smart Technology Investments Research Institute
**Date:** February 2026
**Status:** Architecture Design (Pre-Implementation)

---

## 1. Executive Summary

NeuroSim is an open-source simulation platform providing a complete stack for training RL agents to decode, adapt to, and control brain-computer interfaces. It fills a confirmed gap: **no Gymnasium-compatible RL environment for neural signal decoding currently exists** (confirmed across MNE-Python, MOABB, BrainFlow, NeuroGym — none expose Gymnasium `step()`/`reset()` semantics with RL reward shaping).

The platform provides:
- **MOABB data pipeline** for loading 36+ standardized BCI datasets
- **Three Gymnasium environments** targeting distinct BCI paradigms with structurally different RL problems
- **Signal models** for non-stationarity, electrode drift, and co-adaptation dynamics
- **Neural signal surrogate** for fast training without raw data replay
- **PPO baseline agents** with Stable-Baselines3
- **Benchmark suite** across 5 difficulty tiers

### Positioning vs. Existing Tools

| Tool | What It Does | What It Lacks (NeuroSim Fills) |
|------|-------------|-------------------------------|
| **MOABB** | Standardized BCI dataset loading + offline evaluation | No RL environments, no online adaptation, no Gymnasium API |
| **NeuroGym** | Cognitive neuroscience tasks as Gym envs | Abstract tasks, not real BCI decoding — no EEG/ECoG signals |
| **MNE-Python** | EEG/MEG signal processing | Processing library, no RL integration |
| **BrainFlow** | Real-time biosignal acquisition | Hardware interface, no simulation or RL |
| **Liang & Kao 2024** | BCI simulation for RL training | bioRxiv preprint, not packaged as installable library, single paradigm, no benchmark suite |

**NeuroSim's unique value:** Packaged `pip install neurosim` library with MOABB-backed multi-paradigm Gymnasium environments, co-adaptation modeling, and a reproducible benchmark suite. The closest work (Liang & Kao 2024, bioRxiv) demonstrated the concept but is not a distributable library, covers a single paradigm, and lacks standardized benchmarks.

---

## 2. System Architecture

```
┌─────────────────────────────────────────────────────────┐
│                     NeuroSim Platform                    │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ┌──────────┐    ┌──────────────┐    ┌──────────────┐  │
│  │  MOABB   │───▶│ Data Pipeline │───▶│   Signal     │  │
│  │ Datasets │    │  (NWB/EDF+)  │    │   Models     │  │
│  └──────────┘    └──────┬───────┘    └──────┬───────┘  │
│                         │                    │          │
│                         ▼                    ▼          │
│  ┌──────────────────────────────────────────────────┐  │
│  │           Gymnasium Environments                  │  │
│  │  ┌──────────────┐ ┌──────────────┐ ┌───────────┐│  │
│  │  │DecoderAdapt  │ │CursorControl │ │SpellerNav ││  │
│  │  │    -v0       │ │    -v0       │ │   -v0     ││  │
│  │  │ (Motor       │ │ (Continuous  │ │ (P300/    ││  │
│  │  │  Imagery)    │ │  Decode)     │ │  SSVEP)   ││  │
│  │  └──────────────┘ └──────────────┘ └───────────┘│  │
│  └──────────────────────────────────────────────────┘  │
│                         │                               │
│           ┌─────────────┼─────────────┐                │
│           ▼             ▼             ▼                │
│  ┌──────────────┐ ┌──────────┐ ┌──────────────┐      │
│  │   Neural     │ │ Baseline │ │  Benchmark   │      │
│  │  Surrogate   │ │  Agents  │ │    Suite     │      │
│  │   Model      │ │  (PPO)   │ │  (5 Tiers)  │      │
│  └──────────────┘ └──────────┘ └──────────────┘      │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

**Data flow:** Medical datasets (via MOABB) → Data Pipeline (normalization, epoching, NWB format) → Signal Models (non-stationarity injection, drift simulation) → Gymnasium Environments (step/reset with RL rewards) → Agents (PPO/custom) → Benchmark Suite (evaluation).

---

## 3. Data Pipeline

### 3.1 MOABB Integration

MOABB (Mother of All BCI Benchmarks) provides a unified Python API for 36+ BCI datasets. NeuroSim uses MOABB as the **data loading layer**, not as an evaluation framework — MOABB handles download, caching, and basic preprocessing; NeuroSim adds RL-specific transformations.

```python
from neurosim.data import MOABBLoader

loader = MOABBLoader(dataset="BNCI2014_001", subjects=[1, 2, 3])
epochs = loader.load()  # Returns MNE Epochs, cached locally
```

### 3.2 Priority Datasets

| Tier | Dataset | Subjects | Paradigm | Source | Why Priority |
|------|---------|----------|----------|--------|--------------|
| **1** | BCI Competition IV-2a (BNCI2014_001) | 9 | Motor Imagery (4-class) | MOABB | THE benchmark — every MI paper compares here |
| **1** | PhysioNet EEGMMIDB | 109 | Motor Imagery + Execution | MOABB | Largest public MI dataset, 64-channel EEG |
| **1** | Tsinghua SSVEP (BETA) | 70 | SSVEP (40 targets) | Direct download | Gold standard for SSVEP, high SNR |
| **2** | Korea University OpenBMI | 54 | MI (2-class) | MOABB | Large subject count, good for cross-subject |
| **2** | Cho2017 | 52 | MI (2-class) | MOABB | Large, well-documented |
| **2** | Nakanishi2015 | 9 | SSVEP (12 targets) | MOABB | Clean SSVEP paradigm |
| **3** | BCI Competition III-IVa | 5 | MI (2-class) | MOABB | Classic benchmark, small but well-studied |
| **3** | Miller ECoG Library | 34 | Various (ECoG) | Direct download (OpenNeuro) | Best public ECoG resource |
| **Future** | DANDI:000338 (NHP Reaching) | NHP | Intracortical arrays | DANDI API | Closest to clinical BCI (BrainGate-style) |

### 3.3 Internal Format

**Canonical format:** NWB (Neurodata Without Borders) for intracortical/ECoG data, MNE `Epochs` for EEG.

The pipeline normalizes all data to a common internal representation:

```python
@dataclass
class NeuralEpoch:
    signals: np.ndarray      # (n_channels, n_timepoints)
    label: int               # Ground-truth class
    sfreq: float             # Sampling frequency (Hz)
    channels: list[str]      # Channel names
    subject_id: int          # Subject identifier
    session_id: int          # Session identifier (for drift modeling)
    metadata: dict           # Paradigm-specific metadata
```

### 3.4 Preprocessing Stack

1. **Bandpass filter:** 0.5–40 Hz (configurable per paradigm)
2. **Common Average Reference (CAR)**
3. **Epoch extraction:** Paradigm-specific windowing
4. **Z-score normalization** per channel per session
5. **Artifact rejection:** Amplitude threshold (configurable, default ±100 µV)

---

## 4. Gymnasium Environments

### Design Philosophy

Each environment presents a **structurally different RL problem**, not just a different dataset wrapper:

| Environment | RL Problem Type | State Space Nature | Action Space | What Makes It Distinct |
|---|---|---|---|---|
| **DecoderAdapt-v0** | Online adaptation | Discrete epochs + decoder state | Decoder parameter updates | Agent learns WHEN and HOW to recalibrate |
| **CursorControl-v0** | Continuous control | Streaming neural features + cursor position | 2D velocity commands | Agent learns real-time neural-to-motor mapping |
| **SpellerNav-v0** | Sequential decision | Stimulus response probabilities + target queue | Next stimulus selection | Agent learns to maximize information per flash |

### 4.1 DecoderAdapt-v0 (Motor Imagery — Online Adaptation)

**Paradigm:** Motor imagery (left hand, right hand, feet, tongue) from EEG.

**The RL Problem:** BCI decoders degrade over time due to neural non-stationarity (electrode drift, fatigue, attention shifts). The agent must decide when to recalibrate the decoder and how to update its parameters — too frequent recalibration wastes user time, too infrequent lets accuracy degrade.

**Observation Space:**
```python
Dict({
    "neural_features": Box(shape=(n_features,)),     # CSP/bandpower features from current epoch
    "decoder_confidence": Box(shape=(n_classes,)),    # Current decoder's softmax output
    "decoder_age": Box(shape=(1,)),                   # Steps since last recalibration
    "session_progress": Box(shape=(1,)),              # Fraction of session elapsed
    "recent_accuracy": Box(shape=(1,)),               # Rolling accuracy window
    "drift_indicator": Box(shape=(n_features,)),      # Feature distribution shift metric
})
```

**Action Space:**
```python
Dict({
    "classification": Discrete(n_classes),             # Predicted motor imagery class
    "recalibrate": Discrete(2),                        # 0=continue, 1=trigger recalibration
    "adaptation_rate": Box(shape=(1,), low=0, high=1), # How aggressively to update decoder
})
```

**Reward Function:**
```
R(t) = α · correct(t) - β · recal_cost(t) + γ · streak_bonus(t) - δ · confidence_penalty(t)

where:
  correct(t)          = +1.0 if classification matches ground truth, else -0.5
  recal_cost(t)       = 0.3 if recalibrate=1 (simulates user downtime)
  streak_bonus(t)     = 0.1 * consecutive_correct (encourages sustained accuracy)
  confidence_penalty(t) = |decoder_confidence - actual_accuracy| (penalizes miscalibration)

  α=1.0, β=1.0, γ=0.5, δ=0.2 (tunable)
```

**Episode Structure:** 1 session = 200-400 trials. Non-stationarity injected per session via signal model. Episode ends when session completes.

**Data Sources:** BCI Competition IV-2a (primary), PhysioNet EEGMMIDB (extended).

### 4.2 CursorControl-v0 (Continuous Decode — Real-Time Control)

**Paradigm:** Continuous neural decoding for 2D cursor control, simulating intracortical/ECoG BCI.

**The RL Problem:** The agent maps streaming neural population activity to continuous cursor velocity in real time. Unlike DecoderAdapt (discrete decisions), this is a continuous control problem with neural dynamics, noise, and a moving target. The challenge: learning a stable mapping despite trial-to-trial variability in neural tuning curves.

**Observation Space:**
```python
Dict({
    "neural_state": Box(shape=(n_units, n_bins)),     # Binned spike counts / ECoG features
    "cursor_position": Box(shape=(2,)),                # Current (x, y)
    "target_position": Box(shape=(2,)),                # Goal (x, y)
    "cursor_velocity": Box(shape=(2,)),                # Current velocity
    "distance_to_target": Box(shape=(1,)),             # Euclidean distance
    "time_in_trial": Box(shape=(1,)),                  # Normalized trial time
})
```

**Action Space:**
```python
Box(shape=(2,), low=-1.0, high=1.0)  # Decoded velocity (vx, vy)
```

**Reward Function:**
```
R(t) = -λ₁ · d(t) + λ₂ · Δd(t) + λ₃ · acquire(t) - λ₄ · jitter(t)

where:
  d(t)       = distance to target (penalizes being far)
  Δd(t)      = d(t-1) - d(t) (rewards getting closer)
  acquire(t) = +5.0 if cursor enters target zone
  jitter(t)  = ||v(t) - v(t-1)|| (penalizes jerky movements)

  λ₁=0.01, λ₂=1.0, λ₃=5.0, λ₄=0.1 (tunable)
```

**Episode Structure:** 1 trial = reach to target (max 3s at 10 Hz = 30 steps). 1 episode = 50-100 trials with targets at random positions. Neural tuning drifts across trials.

**Data Sources:** Synthetic neural populations (primary), DANDI:000338 NHP reaching (future), Miller ECoG Library (extended).

### 4.3 SpellerNav-v0 (P300/SSVEP — Information Optimization)

**Paradigm:** BCI speller where the agent selects which stimuli to present to maximize information transfer rate (ITR).

**The RL Problem:** Unlike the other environments where the agent decodes neural signals, here the agent decides WHAT TO SHOW the user. It's an **active sensing** problem: given noisy neural responses to visual stimuli, which characters should be flashed next to most quickly identify the target character? This is a sequential decision problem with an explore/exploit tradeoff.

**Observation Space:**
```python
Dict({
    "posterior": Box(shape=(n_symbols,)),              # Belief state over target symbol
    "response_history": Box(shape=(n_history, n_channels)), # Recent ERP/SSVEP features
    "n_flashes": Box(shape=(1,)),                      # Flashes used so far
    "target_queue": Box(shape=(queue_len,)),            # Upcoming characters to spell
    "snr_estimate": Box(shape=(1,)),                   # Estimated signal quality
})
```

**Action Space:**
```python
Dict({
    "stimulus_group": Discrete(n_groups),              # Which character group to flash
    "commit": Discrete(2),                             # 0=gather more evidence, 1=commit selection
})
```

**Reward Function:**
```
R(t) = α · ITR(t) - β · flash_cost(t) + γ · correct_commit(t) - δ · wrong_commit(t)

where:
  ITR(t)           = bits_transferred / time_elapsed (information transfer rate)
  flash_cost(t)    = -0.01 per flash (penalizes slow spelling)
  correct_commit(t)= +2.0 if committed to correct symbol
  wrong_commit(t)  = -3.0 if committed to wrong symbol (asymmetric — errors are costly)

  α=1.0, β=1.0, γ=2.0, δ=3.0 (tunable)
```

**Episode Structure:** 1 episode = spell a word (5-10 characters). Each character requires multiple flashes to identify. Episode ends when word is complete or max time exceeded.

**Data Sources:** Tsinghua SSVEP/BETA (primary), MOABB P300 datasets (extended).

---

## 5. Signal Models

### 5.1 Non-Stationarity Simulation (Core Challenge)

Non-stationarity is the central unsolved problem in BCI — neural signals drift over minutes, hours, and days. NeuroSim simulates four sources of drift:

**a) Electrode Impedance Drift:**
```
Z(t) = Z₀ · (1 + α_z · t + ε_z(t))
signal_attenuated(t) = signal(t) · Z₀/Z(t)

α_z ~ U(0.001, 0.01) per session
ε_z(t) ~ N(0, σ_z) with σ_z = 0.02
```

**b) Neural Fatigue (Attention Waning):**
```
fatigue(t) = 1 - β_f · (1 - exp(-t/τ_f))
signal_fatigued(t) = signal(t) · fatigue(t)

β_f ~ U(0.05, 0.2)  — max fatigue factor
τ_f ~ U(100, 500)    — fatigue time constant (trials)
```

**c) Feature Distribution Shift:**
```
μ_shifted(t) = μ₀ + drift_rate · t + Σ step_shifts
drift_rate ~ N(0, σ_drift) per feature per session
step_shifts occur with P=0.01 per trial, magnitude ~ N(0, σ_step)
```

**d) Co-Adaptation Dynamics:**
When the decoder changes behavior, the user unconsciously adapts their neural strategy. Modeled as:
```
user_adaptation(t) = signal(t) + η · (decoder_expectation(t) - signal(t))
η ~ U(0.1, 0.5) — user adaptation rate
```

### 5.2 Noise Models

| Noise Type | Model | Application |
|---|---|---|
| Background EEG | Pink noise (1/f spectrum) | All EEG environments |
| EMG artifacts | Burst noise, 20-300 Hz | Random injection, P=0.05 per trial |
| Eye blinks | Template-based, frontal channels | Random injection, P=0.03 per trial |
| Line noise | 50/60 Hz sinusoidal | Configurable, default off |
| Neural variability | Poisson (intracortical), Gaussian (EEG) | Per-trial for CursorControl |

### 5.3 Magnetic Field Modeling

Not applicable (unlike VascularSim). NeuroSim's "physics" equivalent is the signal model above.

---

## 6. Neural Signal Surrogate

### 6.1 Purpose

Raw data replay limits training speed and diversity. The neural surrogate generates realistic synthetic neural signals conditioned on:
- Target class/direction
- Subject identity
- Session non-stationarity state
- Current drift parameters

### 6.2 Architecture

**Conditional Variational Autoencoder (cVAE):**

```
Encoder: [neural_epoch (C × T)] → [μ, σ] → z ∈ R^32
Decoder: [z, class_label, subject_id, drift_state] → [synthetic_epoch (C × T)]

Training: Per-subject on real MOABB data
Loss: reconstruction (MSE on time-frequency features) + KL divergence + class-discriminability penalty
```

**Key design:** The surrogate is trained PER SUBJECT to capture individual neural signatures, but conditioned on drift state to generate non-stationary sequences.

### 6.3 Training Pipeline

1. Load subject data via MOABB
2. Extract time-frequency features (CSP + bandpower)
3. Train cVAE per subject (~2-5 min on CPU, ~30s on GPU)
4. Validate: generated epochs must achieve ≥90% of real-data classification accuracy when used as training data for a CSP+LDA baseline

### 6.4 Usage in Environments

```python
env = gym.make("neurosim/DecoderAdapt-v0",
               data_source="surrogate",   # or "replay" for raw data
               subject=3,
               dataset="BNCI2014_001")
```

---

## 7. Benchmark Suite

### 7.1 Difficulty Tiers

| Tier | Name | Subjects | Non-Stationarity | Noise Level | Environment | Success Metric |
|------|------|----------|-------------------|-------------|-------------|----------------|
| **T1** | Stationary | 1 (best) | None | Low | DecoderAdapt | Accuracy ≥ 85% |
| **T2** | Mild Drift | 1 (best) | Electrode drift only | Medium | DecoderAdapt | Accuracy ≥ 75% with ≤5 recalibrations |
| **T3** | Full Drift | 3 (mixed) | All 4 sources | Medium | DecoderAdapt + CursorControl | Accuracy ≥ 65%, Reach time ≤ 2.5s |
| **T4** | Cross-Subject | 9 (all) | All 4 sources | High | All 3 environments | Mean accuracy ≥ 55%, ITR ≥ 20 bits/min |
| **T5** | Adversarial | 9 (all) | All + sudden shifts | High + artifacts | All 3 environments | Graceful degradation, accuracy ≥ 45% |

### 7.2 Metrics

| Metric | Formula | Environments | Unit |
|--------|---------|-------------|------|
| **Classification Accuracy** | correct / total | DecoderAdapt | % |
| **Reach Time** | mean time to target acquisition | CursorControl | seconds |
| **Path Efficiency** | optimal_distance / actual_distance | CursorControl | ratio (0-1) |
| **Information Transfer Rate** | (log₂N + P·log₂P + (1-P)·log₂((1-P)/(N-1))) / T | SpellerNav | bits/min |
| **Adaptation Efficiency** | accuracy_after_drift / accuracy_before_drift | DecoderAdapt | ratio (0-1) |
| **Recalibration Count** | total recalibrations triggered | DecoderAdapt | count |

### 7.3 Benchmark CLI

```bash
neurosim benchmark --env DecoderAdapt-v0 --tier T3 --agent ppo --episodes 50 --seed 42
```

---

## 8. Baseline Agents

### 8.1 PPO Agent (Primary Baseline)

Built on Stable-Baselines3, configured per environment:

| Parameter | DecoderAdapt | CursorControl | SpellerNav |
|---|---|---|---|
| Policy | MlpPolicy | MlpPolicy | MlpPolicy |
| Learning rate | 3e-4 | 1e-3 | 3e-4 |
| Batch size | 64 | 128 | 32 |
| n_steps | 2048 | 1024 | 512 |
| Total timesteps | 500k | 1M | 200k |
| GAE λ | 0.95 | 0.98 | 0.95 |

### 8.2 Comparison Agents

| Agent | Description | Purpose |
|---|---|---|
| **Random** | Uniform random actions | Lower bound |
| **CSP+LDA** | Classical BCI pipeline (no RL) | Traditional baseline |
| **PPO** | Standard RL baseline | Primary comparison |
| **Supervised Retrain** | Periodic full retraining on recent data | Naive adaptation baseline |

---

## 9. Paper Outline

**Target venue:** Journal of Neural Engineering (primary), NeurIPS Datasets & Benchmarks track (secondary)

| Section | Content | Approx. Pages |
|---------|---------|---------------|
| **1. Introduction** | BCI gap, RL opportunity, contribution summary | 1 |
| **2. Related Work** | BCI simulators (Liang & Kao 2024, CathSim analogy), RL for BCI (Kao 2025, Sanchez 2009-2014, CopAC), existing tools (MOABB, NeuroGym, BrainFlow) | 1.5 |
| **3. System Architecture** | Data pipeline, MOABB integration, environment design philosophy | 1 |
| **4. Gymnasium Environments** | DecoderAdapt, CursorControl, SpellerNav — observation/action/reward for each | 2 |
| **5. Signal Models** | Non-stationarity (4 sources), noise models, co-adaptation dynamics | 1 |
| **6. Neural Surrogate** | cVAE architecture, training, validation | 0.5 |
| **7. Benchmark Suite** | 5 tiers, metrics, evaluation protocol | 0.5 |
| **8. Experiments** | PPO training curves, agent comparison, cross-tier results, computational performance | 2 |
| **9. Discussion** | Design tradeoffs, extensibility, sim-to-real gap, limitations | 1 |
| **10. Conclusion** | Summary, availability, future work | 0.5 |

**Key citations to include:**
- Kao et al. 2025 (Nature Machine Intelligence) — AI copilots for BCI, 3.9x improvement
- Liang & Kao 2024 (bioRxiv) — Closest prior work, BCI simulator for RL
- Sanchez et al. 2009-2014 — RLBMI foundational work
- CopAC (ICML 2024) — Co-adaptive RL for BCI
- Schulman et al. 2017 — PPO
- Raffin et al. 2021 — Stable-Baselines3
- Jayaram & Barachant 2018 — MOABB

**Key labs to cite/collaborate with:**
- Kao Lab (UCLA) — AI copilots, closest related work
- Sanchez/Principe Lab (UF) — RLBMI pioneers
- Shanechi Lab (USC) — Neural dynamics and control
- Millan (UT Austin) — Adaptive BCI
- Dragan (Berkeley) — Co-adaptive shared control

---

## 10. Repository Structure

```
neurosim/
├── LICENSE                     # MIT
├── README.md
├── pyproject.toml              # Build config (hatchling)
├── paper/
│   ├── neurosim.tex
│   ├── references.bib
│   └── figures/
├── Plans/
│   └── ARCHITECTURE.md         # This document
├── src/
│   └── neurosim/
│       ├── __init__.py
│       ├── py.typed
│       ├── data/
│       │   ├── __init__.py
│       │   ├── loader.py       # MOABBLoader, NWBLoader
│       │   ├── preprocessing.py # Bandpass, CAR, epoching
│       │   └── formats.py      # NeuralEpoch dataclass
│       ├── envs/
│       │   ├── __init__.py
│       │   ├── decoder_adapt.py    # DecoderAdapt-v0
│       │   ├── cursor_control.py   # CursorControl-v0
│       │   ├── speller_nav.py      # SpellerNav-v0
│       │   └── observation.py      # Shared observation flattening
│       ├── models/
│       │   ├── __init__.py
│       │   ├── drift.py        # Non-stationarity models
│       │   ├── noise.py        # Noise injection models
│       │   ├── coadaptation.py # Co-adaptation dynamics
│       │   └── surrogate.py    # cVAE neural surrogate
│       ├── agents/
│       │   ├── __init__.py
│       │   ├── ppo.py          # PPO baseline configs
│       │   ├── csp_lda.py      # Classical BCI baseline
│       │   └── random_agent.py # Random baseline
│       └── benchmarks/
│           ├── __init__.py
│           ├── tiers.py        # Tier definitions (T1-T5)
│           ├── metrics.py      # Accuracy, ITR, reach time, etc.
│           └── runner.py       # Benchmark CLI runner
└── tests/
    ├── test_data/
    ├── test_envs/
    ├── test_models/
    ├── test_agents/
    └── test_benchmarks/
```

---

## 11. Implementation Roadmap

| Phase | Deliverable | Estimated Effort |
|-------|------------|-----------------|
| **Phase 1** | Data pipeline (MOABB loader + preprocessing) | 1 week |
| **Phase 2** | Signal models (drift, noise, co-adaptation) | 1 week |
| **Phase 3** | DecoderAdapt-v0 environment | 1 week |
| **Phase 4** | CursorControl-v0 environment | 1 week |
| **Phase 5** | SpellerNav-v0 environment | 1 week |
| **Phase 6** | Neural surrogate (cVAE) | 1 week |
| **Phase 7** | Baseline agents + benchmarks | 1 week |
| **Phase 8** | Paper writing + figures | 2 weeks |
| **Phase 9** | Tests (target: 100+ tests) + PyPI release | 1 week |

---

## 12. Dependencies

```toml
[project]
name = "neurosim"
version = "0.1.0"
requires-python = ">=3.10"
dependencies = [
    "gymnasium>=0.29",
    "numpy>=1.24",
    "scipy>=1.11",
    "mne>=1.6",
    "moabb>=1.0",
    "torch>=2.0",
    "stable-baselines3>=2.0",
    "rich>=13.0",        # CLI output
    "typer>=0.9",        # CLI framework
]

[project.optional-dependencies]
dev = ["pytest>=7.0", "pytest-cov", "ruff", "mypy"]
docs = ["sphinx", "sphinx-rtd-theme"]
```

---

## 13. Key Design Decisions

1. **MOABB as data layer, not evaluation layer:** MOABB's evaluation pipelines (WithinSession, CrossSubject) are offline classification benchmarks. NeuroSim wraps the data loading only, adding online RL-specific evaluation on top.

2. **Three paradigms, not one:** Liang & Kao 2024 covered a single BCI paradigm. NeuroSim covers three structurally different RL problems (adaptation, continuous control, sequential decision), making it a platform rather than a single-environment paper.

3. **cVAE surrogate, not GAN:** cVAEs are more stable to train, provide a latent space for interpolation, and allow conditioning on drift state. GANs would offer sharper signals but at training instability cost.

4. **Per-subject surrogates:** BCI is highly individual — a single generative model across subjects would blur individual signatures. Per-subject models are more scientifically accurate even if less convenient.

5. **NWB for intracortical, MNE Epochs for EEG:** Following community standards rather than forcing a single format. The `NeuralEpoch` dataclass provides a common interface.
