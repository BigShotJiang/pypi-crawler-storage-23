# DjangoCMS Render Context

The plugin for the [Django CMS](https://www.django-cms.org/) content management system.
The plugin displays the context in the template. The context can be specified directly in JSON format.
Or the context can be used as a media file. Or the context can be loaded from a URL.
The template can be entered directly or selected from a list defined in the settings in the ``DJANGOCMS_RENDER_CONTEXT_TEMPLATES`` constant.

Supported source data formats (mimetype):

 - csv (text/csv)
 - json (application/json)
 - yaml (application/yaml)
 - xml (application/xml)
 - ods (application/vnd.oasis.opendocument.spreadsheet)

## Install

Install the package from pypi.org.

```
pip install djangocms-render-context
```

Add into `INSTALLED_APPS` in your site `settings.py`:

```python
INSTALLED_APPS = [
    ...
    "easy_thumbnails",
    "filer",
    "djangocms_render_context",
]
```

### Optional urls

The following urls are not required. `JavaScriptCatalog` makes translations available for javascript. `rcdata/` then detail from the list in context.

Add into site `urls.py`:

```python
from django.conf.urls.i18n import i18n_patterns
from django.views.i18n import JavaScriptCatalog
from django.urls import path, register_converter
from django.urls.converters import StringConverter


class PackagesConverter(StringConverter):
    """JavaScriptCatalog packages converter."""
    # Same as SlugConverter, but with extra '+', that is used in JavaScriptCatalog as a sepearator in list of packages.
    regex = "[-a-zA-Z0-9_+]+"


register_converter(PackagesConverter, "pkg")

urlpatterns = [
    ...
] + i18n_patterns(
    path('jsi18n/<pkg:packages>/', JavaScriptCatalog.as_view(), name='jsi18n'),
    path('rcdata/', include(('djangocms_render_context.urls', 'djangocms_render_context'))),
)
```

The path name ``jsi18n`` can be redefined with the ``DJANGOCMS_RENDER_CONTEXT_JSI18N`` constant.


### Extra settings

This value can be defined in settings.

 - `DJANGOCMS_RENDER_CONTEXT_TEMPLATES` - List of templates that the plugin can use.
 - `DJANGOCMS_RENDER_CONTEXT_DETAIL_TEMPLATES` - List of templates that the detail can use.

For example:

```python
DJANGOCMS_RENDER_CONTEXT_TEMPLATES = (
    ("", ""),
    ("plugin.html", "Plugin"),
    ("schedule.html", "Schedule"),
)
DJANGOCMS_RENDER_CONTEXT_DETAIL_TEMPLATES = (
    ("", ""),
    ("detail.html", "Plugin detail"),
)
```

- `DJANGOCMS_RENDER_CONTEXT_PROCESSORS` - List of functions that can work with plugin context.
- `DJANGOCMS_RENDER_CONTEXT_DETAIL_PROCESSORS` - List of functions that can work with detail context.

For example:

```python
DJANGOCMS_RENDER_CONTEXT_PROCESSORS = (
    ("", ""),
    ("mysite.utils.process_plugin", "Process plugin"),
)
DJANGOCMS_RENDER_CONTEXT_DETAIL_PROCESSORS = (
    ("", ""),
    ("mysite.utils.process_plugin_detail", "Process plugin detail"),
)
```

The function in mysite/utils.py:

```python
from django.template.context import RequestContext


def process_plugin(instance: RenderContext, context: dict) -> dict:
    """Process plugin context."""
    context["data"]["extra"] = "content"
    return context


def process_plugin_detail(instance: RenderContext, context: RequestContext) -> RequestContext:
    """Process plugin context."""
    context["detail"]["extra"] = "content"
    return context
```

## License

BSD-3-Clause
