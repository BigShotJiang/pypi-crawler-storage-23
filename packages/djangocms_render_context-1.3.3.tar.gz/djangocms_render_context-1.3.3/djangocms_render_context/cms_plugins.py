import logging

from cms.models.placeholdermodel import Placeholder
from cms.plugin_base import CMSPluginBase
from cms.plugin_pool import plugin_pool
from django.conf import settings
from django.template import Template
from django.template.backends.django import Template as DjangoTemplate
from django.template.context import Context
from django.template.loader import get_template
from django.urls import NoReverseMatch, reverse
from django.utils.module_loading import import_string
from django.utils.safestring import SafeString
from django.utils.translation import gettext_lazy as _

from .forms import RenderContextForm
from .models import RenderContext
from .utils import create_html

logger = logging.getLogger(__name__)


@plugin_pool.register_plugin
class RenderContextPlugin(CMSPluginBase):
    model = RenderContext
    form = RenderContextForm
    name = _("Render Context Plugin")
    fieldsets = [
        (
            _("Sources"),
            {
                "fields": (
                    "mimetype",
                    "context",
                    "file",
                    (
                        "source",
                        "cached",
                    ),
                ),
            },
        ),
        (
            _("Source settings"),
            {
                "classes": ["collapse"],
                "fields": ("config",),
            },
        ),
        (
            _("Templates"),
            {
                "classes": ["collapse"],
                "fields": (
                    "template",
                    "template_list",
                    "path",
                    "processor",
                ),
            },
        ),
        (
            _("Detail"),
            {
                "classes": ["collapse"],
                "fields": (
                    "detail_extends",
                    "detail_template",
                    "detail_template_list",
                    "detail_processor",
                ),
            },
        ),
    ]

    def get_render_template(self, context: dict, instance: RenderContext, placeholder: Placeholder) -> DjangoTemplate:
        context["data"] = instance.get_data()
        if instance.processor:
            try:
                context = import_string(instance.processor)(instance, context)
            except Exception as error:
                if settings.DEBUG:
                    raise error
                logger.error(error)
        if instance.template_list and not instance.template:
            selected_template = get_template(instance.template_list)
            tmpl = PluginTempate(selected_template.template.source)
            return DjangoTemplate(tmpl, tmpl)
        try:
            reverse("djangocms_render_context:item", kwargs={"plugin": 1, "position": 1})
            plugin_id = instance.pk
        except NoReverseMatch:
            plugin_id = None
        tmpl = PluginTempate(instance.template if instance.template else create_html(context["data"], plugin_id))
        return DjangoTemplate(tmpl, tmpl)


class PluginTempate(Template):
    def render(self, context: Context) -> SafeString:
        try:
            return super().render(context)
        except Exception as error:
            if settings.DEBUG:
                raise error
            logger.error(error)
        return SafeString("An error occurred. For more see the log.")
