def get_cache_key(identifier: int) -> str:
    return f"djangocms_render_context_url_{identifier}"
