from collections.abc import Callable
from typing import Union

from django.http import Http404, HttpRequest
from django.shortcuts import get_object_or_404
from django.template import Engine, Origin, RequestContext, Template
from django.template.backends.django import Template as DjangoTemplate
from django.template.base import UNKNOWN_SOURCE, NodeList
from django.template.loader import get_template
from django.template.response import TemplateResponse
from django.utils.module_loading import import_string
from django.utils.safestring import SafeString
from django.views.generic import TemplateView

from .models import RenderContext
from .utils import ArrayWasNotFound, create_html, dataType, get_first_array, pkType

createHtmlType = Union[Callable[[dataType, pkType], str], None]  # noqa: UP007
nodeListType = Union[NodeList, None]  # noqa: UP007


class DataItemTemplate(Template):
    """Data item template."""

    def __init__(self, template_string: str, instance: RenderContext, create_html: createHtmlType = None):
        self.name = None
        self.origin = Origin(UNKNOWN_SOURCE)
        self.engine = Engine.get_default()
        self.source = str(template_string)  # May be lazy.
        self.nodelist: nodeListType = None  # self.compile_nodelist() later in function self._render.
        self.instance = instance
        self.create_html = create_html

    def _render(self, context: RequestContext) -> SafeString:
        if self.instance.detail_processor:
            context = import_string(self.instance.detail_processor)(self.instance, context)
        if self.create_html is not None:
            self.source = self.source.format(self.create_html(context["detail"], None))
        self.nodelist = self.compile_nodelist()
        return self.nodelist.render(context)


class DataItemView(TemplateView):
    """Display data item."""

    def get(self, request: HttpRequest, plugin: int, position: int, *args, **kwargs) -> TemplateResponse:
        self.instance = get_object_or_404(RenderContext, pk=plugin)
        if not position:
            raise Http404("Position cannot be zero.")
        kwargs["data"] = self.instance.get_data()
        try:
            items = get_first_array(kwargs["data"])
        except ArrayWasNotFound as error:
            raise Http404("Data position was not found.") from error
        try:
            kwargs["detail"] = items[position - 1]
        except IndexError as error:
            raise Http404("Invalid data position.") from error
        context = self.get_context_data(**kwargs)
        return self.render_to_response(context)

    def render_to_response(self, context, **response_kwargs):
        """Render context to the response."""
        if self.instance.detail_extends:
            context["CMS_TEMPLATE"] = self.instance.detail_extends
        if self.instance.detail_template_list and not self.instance.detail_template:
            tmpl = get_template(self.instance.detail_template_list)
            template = DataItemTemplate(tmpl.template.source, self.instance)
        elif self.instance.detail_template:
            template = DataItemTemplate(self.instance.detail_template, self.instance)
        else:
            base = (
                "{{% extends CMS_TEMPLATE %}}"
                '{{% block content %}}<div class="container">{}</div>'
                "{{% endblock content %}}"
            )
            template = DataItemTemplate(base, self.instance, create_html)
        response_kwargs.setdefault("content_type", self.content_type)
        return self.response_class(
            request=self.request,
            template=DjangoTemplate(template, template),
            context=context,
            using=self.template_engine,
            **response_kwargs,
        )
