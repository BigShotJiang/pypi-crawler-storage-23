import logging
from collections.abc import Callable
from copy import deepcopy
from typing import Union

from cms.utils.conf import get_cms_setting
from django import forms
from django.conf import settings
from django.contrib.auth.models import AnonymousUser
from django.core.cache import cache
from django.core.exceptions import ValidationError
from django.forms import ALL_FIELDS, ModelForm
from django.template import Template, TemplateDoesNotExist
from django.template.exceptions import TemplateSyntaxError
from django.template.loader import get_template
from django.test import RequestFactory
from django.urls import reverse
from django.urls.exceptions import NoReverseMatch
from django.utils.module_loading import import_string
from django.utils.translation import gettext_lazy as _
from filer.models.filemodels import File
from sekizai.context import SekizaiContext

from .cache import get_cache_key
from .exceptions import SourceParseFailure
from .loaders import (
    CONTEXT_DATA_FORMATS,
    LOADERS,
    SUPPORTED_FILE_TYPES,
    get_data_from_file,
    get_data_from_url,
    value_to_bytes,
)
from .models import RenderContext
from .utils import dataType, get_context_from_path

DEFAULT_CHOICES = (("", ""),)

sourceType = Union[str, File]  # noqa: UP007

logger = logging.getLogger(__name__)


class RenderContextForm(ModelForm):
    """Render Context Form."""

    mimetype = forms.ChoiceField(
        label=_("Type of Data for context"),
        choices=CONTEXT_DATA_FORMATS,
        help_text=_("The format must be consistent with the data in the context."),
    )
    template_list = forms.ChoiceField(
        label=_("Template list"),
        required=False,
        choices=getattr(settings, "DJANGOCMS_RENDER_CONTEXT_TEMPLATES", DEFAULT_CHOICES),
        help_text=_("List of templates. If Template is specified, the template set in the list will not be used."),
    )
    processor = forms.ChoiceField(
        label=_("Processor"),
        required=False,
        choices=getattr(settings, "DJANGOCMS_RENDER_CONTEXT_PROCESSORS", DEFAULT_CHOICES),
        help_text=_("List of functions that process the context."),
    )
    detail_extends = forms.ChoiceField(
        label=_("Detail extends"),
        required=False,
        choices=DEFAULT_CHOICES + settings.CMS_TEMPLATES,
        help_text=_("The detail uses a template. If not specified, the default template is used."),
    )
    detail_template_list = forms.ChoiceField(
        label=_("Detail template list"),
        required=False,
        choices=getattr(settings, "DJANGOCMS_RENDER_CONTEXT_DETAIL_TEMPLATES", DEFAULT_CHOICES),
        help_text=_("List of templates. If Template is specified, the template set in the list will not be used."),
    )
    detail_processor = forms.ChoiceField(
        label=_("Detail processor"),
        required=False,
        choices=getattr(settings, "DJANGOCMS_RENDER_CONTEXT_DETAIL_PROCESSORS", DEFAULT_CHOICES),
        help_text=_("List of functions that process the context."),
    )

    class Media:
        js = [
            # "https://cdn.jsdelivr.net/npm/jspreadsheet-ce@5/dist/index.min.js",
            "djangocms_render_context/js-dist/index.min.js",
            # "https://cdn.jsdelivr.net/npm/jsuites@5/dist/jsuites.min.js",
            "djangocms_render_context/js-dist/jsuites.min.js",
            # https://github.com/nodeca/js-yaml
            "djangocms_render_context/js-dist/js-yaml.min.js",
            # https://github.com/rufuspollock/csv.js
            "djangocms_render_context/js-dist/csv.min.js",
            "djangocms_render_context/js/spreadsheet.js",
        ]
        css = {
            "all": [
                # "https://cdn.jsdelivr.net/npm/jspreadsheet-ce@5/dist/jspreadsheet.min.css",
                "djangocms_render_context/css-dist/jspreadsheet.min.css",
                # "https://cdn.jsdelivr.net/npm/jsuites@5/dist/jsuites.min.css",
                "djangocms_render_context/css-dist/jsuites.min.css",
                # "https://fonts.googleapis.com/icon?family=Material+Icons",
                "djangocms_render_context/css-dist/icon-family-Material-Icons.css",
                "djangocms_render_context/css/spreadsheet.css",
            ],
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["file"].help_text += " " + _("Supported formats are:") + " " + ", ".join(SUPPORTED_FILE_TYPES)
        pathname = getattr(settings, "DJANGOCMS_RENDER_CONTEXT_JSI18N", "jsi18n")
        try:
            path = reverse(pathname, kwargs={"packages": "djangocms_render_context"})
            self.media._js_lists[-1].append(path)
        except NoReverseMatch as error:
            logger.error(error)

    def clean_template_list(self) -> None:
        if self.cleaned_data["template_list"]:
            try:
                get_template(self.cleaned_data["template_list"])
            except TemplateSyntaxError as error:
                raise ValidationError(error) from error
            except TemplateDoesNotExist as error:
                raise ValidationError(f'Template "{error}" does not exist.') from error
        return self.cleaned_data["template_list"]

    def check_value(self, name: str, value: sourceType, loader: Callable) -> dataType:
        try:
            return loader(value)
        except SourceParseFailure as error:
            self.add_error(name, error)
        return None

    def check_context_data(self, value: str, mimetype: str) -> dataType:
        try:
            return LOADERS[mimetype](value_to_bytes(value, mimetype))
        except SourceParseFailure as error:
            self.add_error("context", error)
        return None

    def check_context(self, cleaned_data: dict) -> dataType:
        context: dataType = {}
        if cleaned_data["context"]:
            context = self.check_context_data(cleaned_data["context"], cleaned_data["mimetype"])
        elif cleaned_data["file"]:
            context = self.check_value("file", cleaned_data["file"], get_data_from_file)
        elif cleaned_data["source"]:
            context = self.check_value("source", cleaned_data["source"], get_data_from_url)
        if context is None:
            self.add_error(ALL_FIELDS, "Failed to set context.")
        return context

    def _check_template_or_template_list(
        self, cleaned_data: dict, context: dict, field_name: str, field_name_list: str, processor_name: str
    ) -> None:
        template = None
        form_field_name = ALL_FIELDS
        if cleaned_data[field_name]:
            form_field_name = field_name
            try:
                template = Template(cleaned_data[field_name])
            except TemplateSyntaxError as error:
                self.add_error(field_name, error)
        elif cleaned_data[field_name_list]:
            form_field_name = field_name_list
            template = get_template(cleaned_data[field_name_list]).template
        if template:
            instance = RenderContext(**cleaned_data)
            instance.pk = self.instance.pk if self.instance.pk else 0  # Integer required by reverse.
            if cleaned_data[processor_name]:
                context = import_string(cleaned_data[processor_name])(instance, context)
            context["instance"] = instance  # Instance pk is required by reverse djangocms_render_context:item.
            try:
                template.render(SekizaiContext(context))
            except (TemplateDoesNotExist, TemplateSyntaxError) as error:
                self.add_error(form_field_name, error)

    def check_template(self, cleaned_data: dict, data: dataType) -> None:
        self._check_template_or_template_list(cleaned_data, {"data": data}, "template", "template_list", "processor")

    def check_detail_template(self, cleaned_data: dict, data: dataType) -> None:
        from cms.toolbar.toolbar import CMSToolbar

        detail_extends = (
            cleaned_data["detail_extends"] if cleaned_data["detail_extends"] else get_cms_setting("TEMPLATES")[0][0]
        )
        request = RequestFactory().request()
        request.current_page = None
        request.user = AnonymousUser()
        request.toolbar = CMSToolbar(request)
        context = {
            "CMS_TEMPLATE": detail_extends,
            "request": request,
            "detail": data,
        }
        self._check_template_or_template_list(
            cleaned_data, context, "detail_template", "detail_template_list", "detail_processor"
        )

    def check_path(self, cleaned_data: dict, context: dataType) -> dataType:
        """Check path."""
        if cleaned_data["path"]:
            try:
                context = get_context_from_path(context, cleaned_data["path"])
            except (IndexError, KeyError, ValueError, TypeError) as error:
                self.add_error("path", _("The data path is not valid. Error: %s") % error)
        return context

    def clean(self) -> None:
        """Clean form."""
        cleaned_data = super().clean()
        if self.is_valid():
            context = self.check_context(cleaned_data)
            context = self.check_path(cleaned_data, context)
            for processor_name, key in (("processor", "data"), ("detail_processor", "detail")):
                if cleaned_data[processor_name]:
                    try:
                        import_string(cleaned_data[processor_name])(self.instance, {key: deepcopy(context)})
                    except Exception as error:
                        self.add_error(processor_name, error)
            for name, checker in (("template", self.check_template), ("detail_template", self.check_detail_template)):
                try:
                    checker(cleaned_data, context)
                except Exception as error:
                    self.add_error(name, error)

    def save(self, *args, **kwargs):
        if self.instance.pk:
            cache.delete(get_cache_key(self.instance.pk))
        return super().save(*args, **kwargs)
