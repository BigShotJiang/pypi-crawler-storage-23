// https://bossanova.uk/jspreadsheet/docs/getting-started
// https://bossanova.uk/jspreadsheet/docs/javascript-calendar
// https://github.com/jspreadsheet/editors
// https://jsuites.net/docs/javascript-html-editor
// https://jsuites.net/docs/v4/javascript-html-editor
/*
Available Editors:
    text
    numeric
    hidden
    dropdown
    checkbox
    radio
    calendar
    image
    color
    html
*/

(function() {

const spreadsheetId = "id-spreadsheet"

function parseData(src, mimetype) {
    let data = null
    if (src.value) {
        if (mimetype === "application/json") {
            data = JSON.parse(src.value)
        } else if (mimetype === "text/csv") {
            data = CSV.parse(src.value)
        } else if (mimetype === "application/yaml") {
            data = jsyaml.load(src.value)
        } else if (mimetype === "application/xml") {
            data = parseXml(src.value)
        }
    }
    return data
}

function parseXml(src) {
    const data = {}
    const parser = new DOMParser()
    const doc = parser.parseFromString(src, "text/xml")
    const root = doc.querySelector("*")
    data[root.tagName] = {}
    if (!root.children.length) {
        return data
    }
    const table = []
    for(const row of root.children) {
        const line = {}
        for(const column of row.children) {
            line[column.tagName] = column.innerHTML
        }
        table.push(line)
    }
    data[root.tagName][root.children[0].tagName] = table
    return data
}

function objectToXml(obj, params, level, name) {
    let xml = ""
    if (obj instanceof Object) {
        const rootMissing = name === undefined && level === 0 && params.options.tableNameMissing
        if (rootMissing) {
            xml += `<${params.options.table}>`
        }
        if (Array.isArray(obj)) {
            const subname = name === undefined ? (level ? params.options.table : params.options.row) : name
            const columnMissing = level > 0 && params.options.columnName
            if (columnMissing) {
                xml += `<${params.options.columnName}>`
            }
            for(let key=0; key < obj.length; key++) {
                xml += objectToXml(obj[key], params, level+1, subname)
            }
            if (columnMissing) {
                xml += `</${params.options.columnName}>`
            }
        } else {
            if (name !== undefined) {
                xml += `<${name}>`
            }
            for (const key in obj) {
                xml += objectToXml(obj[key], params, level+1, key)
            }
            if (name !== undefined) {
                xml += `</${name}>`
            }
        }
        if (rootMissing) {
            xml += `</${params.options.table}>`
        }
    } else {
        xml += name !== undefined ? `<${name}>${obj}</${name}>` : obj
    }
    return xml
}

function formatXml(xml) {
    const PADDING = "  "
    const reg = /(>)(<)(\/*)/g
    let pad = 0
    xml = xml.replace(reg, '$1\r\n$2$3')
    return xml.split('\r\n').map((node) => {
        let indent = 0
        if (node.match(/.+<\/\w[^>]*>$/)) {
            indent = 0
        } else if (node.match(/^<\/\w/)) {
            if (pad !== 0) pad -= 1
        } else if (node.match(/^<\w[^>]*[^\/]>.*$/)) {
            indent = 1
        }
        const padding = PADDING.repeat(pad)
        pad += indent
        return padding + node
    }).join('\r\n')
}

function dumpXml(data, params) {
    if (Array.isArray(data)) {
        params.options.tableNameMissing = true
        if (data.length && Array.isArray(data[0])) {
            params.options.columnName = "item"
        }
    }
    if (isObj(data)) {
        for (const key in data) {
            if (Array.isArray(data[key])) {
                params.options.tableNameMissing = true
                break
            }
        }
    }
    return formatXml(objectToXml(data, params, 0))
}


function setDataIntoContext(data, params) {
    const mimetype = document.querySelector("select[name=mimetype]").value
    if (mimetype === "text/csv" && isObj(data)) {
        throw new Error(gettext("This data cannot be serialized in the selected format. Please select a different format."))
    }
    let value
    if (mimetype === "application/json") {
        value = JSON.stringify(data, null, 2)
    } else if (mimetype === "text/csv") {
        value = CSV.serialize(data)
    } else if (mimetype === "application/yaml") {
        value = jsyaml.dump(data)
    } else if (mimetype === "application/xml") {
        value = dumpXml(data, params)
    }
    document.querySelector("textarea[name=context]").value = value
}

function stripCells(row) {
    const cells = []
    let isContent = false
    for (let i = row.length - 1; i >= 0; i--) {
        if (isContent || row[i]) {
            isContent = true
            cells.push(row[i])
        }
    }
    return cells.reverse()
}

function removeEmptyRows(data) {
    const table = []
    let isContent = false
    for (let i = data.length - 1; i >= 0; i--) {
        const cells = stripCells(data[i])
        if (isContent || cells.length) {
            isContent = true
            table.push(cells.length ? cells : data[i])
        }
    }
    return table.reverse()
}

function createSpreadsheetNode() {
    const context = document.querySelector("textarea[name=context]")
    const node = document.createElement("div")
    node.id = spreadsheetId
    context.after(node)
}

function createModalNode() {
    const context = document.querySelector("textarea[name=context]")
    const container = document.createElement("div")
    container.id = MODAL_CONTAINER_ID
    context.after(container)
}


function setSpreadsheetTranslations() {
    window.jspreadsheet.setDictionary({
        'Are you sure?': gettext('Are you sure?'),
        'Rename this cell': gettext('Rename this cell'),
        'Cut': gettext('Cut'),
        'Copy': gettext('Copy'),
        'Paste': gettext('Paste'),
        'Insert a new column before': gettext('Insert a new column before'),
        'Insert a new column after': gettext('Insert a new column after'),
        'Insert a new row before': gettext('Insert a new row before'),
        'Insert a new row after': gettext('Insert a new row after'),
        'Delete selected columns': gettext('Delete selected columns'),
        'Delete selected rows': gettext('Delete selected rows'),
        'Rename this column': gettext('Rename this column'),
        'Add comments': gettext('Add comments'),
        'Edit comments': gettext('Edit comments'),
        'Clear comments': gettext('Clear comments'),
        'Order ascending': gettext('Order ascending'),
        'Order descending': gettext('Order descending'),
        'Save as': gettext('Save as'),
        'About': gettext('About'),
        'Jan': gettext('Jan'),
        'Feb': gettext('Feb'),
        'Mar': gettext('Mar'),
        'Apr': gettext('Apr'),
        'May': gettext('May'),
        'Jun': gettext('Jun'),
        'Jul': gettext('Jul'),
        'Aug': gettext('Aug'),
        'Sep': gettext('Sep'),
        'Oct': gettext('Oct'),
        'Nov': gettext('Nov'),
        'Dec': gettext('Dec'),
        'January': gettext('January'),
        'February': gettext('February'),
        'March': gettext('March'),
        'April': gettext('April'),
        'May': gettext('May'),
        'June': gettext('June'),
        'July': gettext('July'),
        'August': gettext('August'),
        'September': gettext('September'),
        'October': gettext('October'),
        'November': gettext('November'),
        'December': gettext('December'),
        'Sunday': gettext('Sunday'),
        'Monday': gettext('Monday'),
        'Tuesday': gettext('Tuesday'),
        'Wednesday': gettext('Wednesday'),
        'Thursday': gettext('Thursday'),
        'Friday': gettext('Friday'),
        'Saturday': gettext('Saturday'),
        'Done': gettext('Done'),
        'Reset': gettext('Reset'),
        'Update': gettext('Update'),
    })
}

function displayError(message, title) {
    if (!title) {
        title = gettext("Error message")
    }
    jSuites.notification({
        error: 1,
        timeout: 60000,
        // autoHide: false,
        name: title,
        message: message
    })
}

function isObj(value) {
    // Check if value is object.
    return value instanceof Object && !Array.isArray(value)
}

function getPathsToArrays(obj, parent = "") {
    let result = []
    if (isObj(obj)) {
        for (let key in obj) {
            const path = parent ? `${parent}.${key}` : key
            if (Array.isArray(obj[key])) {
                result.push(path)
            } else if (isObj(obj[key])) {
                result = result.concat(getPathsToArrays(obj[key], path))
            }
        }
    }
    return result
}

function getPayload(obj, path) {
    // Get objects data for the path.
    path.split(".").forEach((key) => {
        obj = obj[key]
    })
    return obj
}

function setPayload(obj, path, payload) {
    // Set data into the object path.
    const names = path.split(".")
    const key = names.pop()
    for(let i=0; i < names.length; i++) {
        obj = obj[names[i]]
    }
    obj[key] = payload
}

function resolveColumnType(value) {
    let type = "text"
    if (Number.isInteger(value)) {
        type = "numeric"
    } else if (typeof value == "boolean") {
        type = "checkbox"
    } else if (typeof value === 'string') {
        if (value.match(/#[A-Fa-f0-9]{6}/)) {
            type = "color"
        } else if (value.match(/\d{4}-\d{2}-\d{2}/)) {
            type = "calendar"
        } else if (value.match(/<.+>/)) {
            type = "html"
        }
    } else if (value instanceof Object) {
        type = "json"
    }
    return type
}

function getContextData(mimetype) {
    return parseData(document.querySelector("textarea[name=context]"), mimetype)
}

function getTableName(path) {
    const names = path.split(".").reverse()
    return names.length > 1 ? names[1] : "table"
}

function getTableRowName(path) {
    const names = path.split(".").reverse()
    return names.length > 0 ? names[0] : "row"
}


function numberToColumn(num) {
    let result = ""
    while (num > 0) {
        const remainder = (num - 1) % 26
        result = String.fromCharCode(65 + remainder) + result
        num = Math.floor((num - remainder) / 26)
    }
    return result
}

function convertDataToTableAndOptions(data) {
    let tableData = []
    const tableOptions = {onlyColumns: true}
    if (Array.isArray(data)) {
        for(let r = 0; r < data.length; r++) {
            const row = data[r]
            if (Array.isArray(row)) {
                tableData.push(row)
                if (tableOptions.types === undefined) {
                    tableOptions.types = []
                    for(let c = 0; c < row.length; c++) {
                        tableOptions.types.push(resolveColumnType(row[c]))
                    }
                }
                tableOptions.onlyColumns = false
            } else if (isObj(row)) {
                if (tableOptions.types === undefined) {
                    tableOptions.titles = []
                    tableOptions.types = []
                    for (const [key, value] of Object.entries(row)) {
                        tableOptions.titles.push(key)
                        tableOptions.types.push(resolveColumnType(value))
                    }
                }
                const columns = []
                for (let c=0; c < tableOptions.titles.length; c++) {
                    columns.push(row[tableOptions.titles[c]])
                }
                tableData.push(columns)
                tableOptions.onlyColumns = false
            } else if (typeof row === "string") {
                if (tableOptions.types === undefined) {
                    tableOptions.types = []
                }
                tableOptions.types.push("text")
                tableData.push(row)
            } else if (typeof row === "number") {
                if (tableOptions.types === undefined) {
                    tableOptions.types = []
                }
                tableOptions.types.push("numeric")
                tableData.push(row)
            } else {
                tableOptions.types = [resolveColumnType(row)]
                tableData.push([row])
                tableOptions.onlyColumns = false
            }
        }
        if (tableOptions.onlyColumns) {
            tableData = [tableData]
        }
        if (!tableData.length) {
            tableOptions.types = ["text"]
            tableData.push([""])
        }
    } else {
        tableData.push([data])
        tableOptions.types = [resolveColumnType(data)]
    }
    return [tableData, tableOptions]
}


function addLink() {
    const href = prompt(gettext("Enter a URL:"), "https://")
    if (href) {
        const sel = getSelection()
        const label = sel.toString()
        const link = document.createElement("a")
        link.href = href
        link.appendChild(document.createTextNode(label ? label : href))
        const range = sel.getRangeAt(0)
        range.deleteContents()
        range.insertNode(link)
    }
}

function onCreateEditor(sheet, td, x, y, empty, options) {
    if (options.type === "html") {
        setTimeout(() => {
            const richtext = document.querySelector(".jss_richtext")
            if (richtext) {
                const item = richtext.querySelector(".jeditor-toolbar > div > div:nth-child(6)")
                const button = item.cloneNode(true)
                button.children[0].textContent = "link"
                item.replaceWith(button)
                button.onclick = addLink
                const close = document.createElement("div")
                close.style.cursor = "pointer"
                close.style.textAlign = "center"
                close.appendChild(document.createTextNode(gettext("(Press Alt+Enter to keep changes. / Alt+Q to cancel.)")))
                close.title = gettext("Close this window.")
                richtext.appendChild(close)
                close.addEventListener("click", () => {
                    window.pluginSpreadsheet.closeEditor.call(richtext, td, true);
                })
                richtext.addEventListener("keydown", (event) => {
                    if(event.altKey && event.key == "Enter") {
                        window.pluginSpreadsheet.closeEditor.call(richtext, td, true)
                    } else if (event.altKey && event.key == "q") {
                        window.pluginSpreadsheet.closeEditor.call(richtext, td, false)
                    }
                })
            }
        }, 100)
    }
}

function getSpreadsheetConfig() {
    const jsconfig = window.pluginSpreadsheet.getConfig()
    jsconfig.columns.forEach(column => {
        if (Object.values(CUSTOM_EDITORS).includes(column.type)) {
            column.type = Object.keys(CUSTOM_EDITORS).find(key => CUSTOM_EDITORS[key] === column.type)
        }
    })
    const config = structuredClone(jsconfig)
    delete config.data
    // Remove default values.
    const style = {}
    for (const [key, value] of Object.entries(config.style)) {
        if (value !== "text-align: center;") {
            style[key] = value
        }
    }
    config.style = style
    return config
}

function setSpreadsheetConfig(sheetConfig, path, sheetIsOpen) {
    const configNode = document.querySelector("textarea[name=config]")
    let config = {}
    if (configNode.value) {
        config = JSON.parse(configNode.value)
        if (config === null) {
            config = {}
        }
    }
    config[path] = sheetConfig
    config.openedPath = sheetIsOpen ? path : null
    configNode.value = JSON.stringify(config, null, 2)
}

function submitForm() {
    const src = document.querySelector("textarea[name=context]")
    const form = src.closest("form")
    form.addEventListener('submit', (event) => {
        if (window.pluginSpreadsheet) {
            if (!saveSpreadsheetIntoFrom(true)) {
                event.preventDefault()
                return false
            }
        }
    })
}

function createLinkButton(label, title, path, data) {
    const link = document.createElement("a")
    link.classList.add("btn", "cms-btn")
    link.disabled = true
    link.style.cursor = "pointer"
    if (title) {
        link.title = title
    }
    if (path) {
        link.dataset.path = path
    }
    if (data) {
        link.dataset.options = JSON.stringify(data)
    }
    link.appendChild(document.createTextNode(label))
    return link
}

function populateColumnsOptions(sheetConfig, tableOptions) {
    for(let i = 0; i < tableOptions.types.length; i++) {
        if (sheetConfig.columns[i] === undefined) {
            sheetConfig.columns[i] = {type: tableOptions.types[i]}
        }
        if (sheetConfig.columns[i].title === undefined && tableOptions.titles && tableOptions.titles[i]) {
            sheetConfig.columns[i].title = tableOptions.titles[i]
        }
    }
}

function toggleSelected(element) {
    const parent = element.closest("div")
    for(const link of parent.querySelectorAll("a.selected")) {
        link.classList.remove("selected")
    }
    element.classList.add("selected")
}


function openJsSheet(button) {
    if (button.classList.contains("selected")) {
        return
    }
    if (window.pluginSpreadsheet) {
        if (!saveSpreadsheetIntoFrom(true)) {
            return
        }
    }
    const mimetypeNone = document.querySelector("select[name=mimetype]")
    button.dataset.mimetype = mimetypeNone.value
    // Load table data and spreadsheet options.
    let contextData, configOptions = {}
    try {
        contextData = getContextData(mimetypeNone.value)
    } catch (error) {
        displayError(error, gettext("Parse Data Error"))
        return
    }
    const configValue = document.querySelector("textarea[name=config]").value
    if (configValue) {
        try {
            configOptions = JSON.parse(configValue)
        } catch (error) {
            displayError(error, gettext("Error in Source settings"))
            return
        }
    }

    let payload
    if (button.dataset.path !== ".") {
        payload = getPayload(contextData, button.dataset.path)
    } else {
        payload = contextData
    }
    const [tableData, tableOptions] = convertDataToTableAndOptions(payload)
    const path = button.dataset.path ? button.dataset.path : "."
    let sheetConfig = (configOptions === null) ? null : configOptions[path]
    if (sheetConfig) {
        sheetConfig.data = tableData
    } else {
        sheetConfig = {minDimensions: [7, 10], data: tableData, columns: []}
    }
    populateColumnsOptions(sheetConfig, tableOptions)
    createSpreadsheet(sheetConfig)
    toggleSelected(button)
}


// https://github.com/jspreadsheet/ce
// https://bossanova.uk/jspreadsheet/docs/editors

const createEditor = function (type, cell) {
    const info = cell.getBoundingClientRect()
    const editor = document.createElement(type)
    editor.style.width = info.width + "px"
    editor.style.height = info.height - 2 + "px"
    editor.style.minHeight = info.height - 2 + "px"
    cell.classList.add("editor")
    cell.innerHTML = ""
    cell.appendChild(editor)
    return editor
}


const JsObjectsEditor = {
    createCell: function(cell, value, x, y, instance) {
        cell.innerHTML = value instanceof Object ? JSON.stringify(value) : value
    },
    openEditor: function(cell, value, x, y, instance, options) {
        const editor = createEditor("input", cell)
        editor.value = value instanceof Object ? JSON.stringify(value) : value
        editor.previousValue = value
        editor.focus()
        editor.onblur = function() {
            instance.closeEditor(cell, true)
        }
    },
    closeEditor: function(cell, save, x, y, instance) {
        const editor = cell.children[0]
        const value = editor.value
        const previousValue = editor.previousValue
        cell.lastChild.remove()
        if (save) {
            cell.innerHTML = value
            let data = value
            if (value) {
                try {
                    data = JSON.parse(value)
                } catch (error) {
                    displayError(error, gettext("The entered data does not match the JSON type."))
                    cell.innerHTML = JSON.stringify(previousValue)
                    data = previousValue
                }
            }
            return data
        }
        return previousValue
    },
}

const MODAL_CONTAINER_ID = "recont-modal-container"
const MODAL_INPUT = "recont-modal-input"
const MODAL_SAVE = "recont-modal-save"
const MODAL_CANCEL = "recont-modal-cancel"

const CustomModalEditor = {
    createCell: function(cell, value) {
        cell.innerHTML = value ? JSON.stringify(value) : value
    },
    openEditor: function(cell, value, x, y, instance) {
        const container = document.getElementById(MODAL_CONTAINER_ID)
        const textSave = gettext("Save")
        const textCancel = gettext("Cancel")
        const textHelp = gettext("The data must be in JSON format. See")
        const data = value ? JSON.stringify(value, null, 2) : ""
        container.innerHTML = `
                <div>
                    <textarea id="${MODAL_INPUT}" rows="10">${data}</textarea>
                    <p>${textHelp} <a href="https://en.wikipedia.org/wiki/JSON" target="_blank">JSON Syntax</a>.</p>
                    <button id="${MODAL_SAVE}">${textSave}</button>
                    <button id="${MODAL_CANCEL}">${textCancel}</button>
                </div>
            `
        jSuites.modal(container, {
            closed: function() {
                instance.closeEditor(cell, true)
            },
            title: gettext("Set value"),
        }).open()
        document.getElementById(MODAL_SAVE).addEventListener("click", (e) => {
            e.preventDefault()
            instance.closeEditor(cell, true)
            jSuites.modal(document.getElementById(MODAL_CONTAINER_ID)).close()
        })
        document.getElementById(MODAL_CANCEL).addEventListener("click", (e) => {
            e.preventDefault()
            jSuites.modal(document.getElementById(MODAL_CONTAINER_ID)).close()
        })
    },
    closeEditor: function(cell, save) {
        const value = document.getElementById(MODAL_INPUT).value
        const previousValue = cell.innerHTML ? JSON.parse(cell.innerHTML) : ""
        if (save) {
            cell.innerHTML = value
            let data = value
            if (value) {
                try {
                    data = JSON.parse(value)
                } catch (error) {
                    displayError(error, gettext("The entered data does not match the JSON type."))
                    cell.innerHTML = previousValue ? JSON.stringify(previousValue) : ""
                    data = previousValue
                }
            }
            return data
        }
        return previousValue
    }
}

const createLink = (value, cell) => {
    if (value instanceof Object) {
        const link = document.createElement("a")
        if (value.label) {
            link.appendChild(document.createTextNode(value.label))
        }
        if (value.href) {
            let msg = value.label ? [value.label, "----------------------"] : []
            if (value.href) {
                // msg + `\\nhref: ${value.href}`
                msg.push(`href: ${value.href}`)
            }
            if (value.title) {
                msg.push(`title: ${value.title}`)
            }
            if (value.target) {
                msg.push(`target: ${value.target}`)
            }
            const message = msg.join(`\\n`)
            link.href = `javascript:alert("${message}")`
        }
        if (value.title) {
            link.title = value.title
        }
        if (value.target) {
            link.target = value.target
        }
        cell.innerHTML = ""
        const icon = document.createElement("span")
        icon.className = "material-icons"
        icon.style.cursor = "pointer"
        icon.innerHTML = "link"
        cell.appendChild(icon)
        cell.appendChild(link)
    } else {
        cell.innerHTML = value
    }
}

const ATagEditor = {
    createCell: function(cell, value) {
        createLink(value, cell)
    },
    openEditor: function(cell, value, x, y, instance) {
        const container = document.getElementById(MODAL_CONTAINER_ID)
        const textSave = gettext("Save")
        const textCancel = gettext("Cancel")
        let href = "", label = "", title = "", target = ""
        if (value instanceof Object) {
            if (value.href) {
                href = value.href
            }
            if (value.label) {
                label = value.label
            }
            if (value.title) {
                title = value.title
            }
            if (value.target) {
                target = value.target
            }
        }
        const linkText = gettext("Link text")
        container.innerHTML = `
                <div id="${MODAL_INPUT}">
                    <div>
                        <label for="label">${linkText}:*</label>
                        <input type="text" name="label" value="${label}">
                    </div>
                    <div>
                        <label for="href">href:*</label>
                        <input type="text" name="href" value="${href}">
                    </div>
                    <div>
                        <label for="title">title:</label>
                        <input type="text" name="title" value="${title}">
                    </div>
                    <div>
                        <label for="target">target:</label>
                        <select name="target">
                            <option></option>
                            <option value="_blank">_blank</option>
                            <option value="_parent">_parent</option>
                            <option value="_self">_self</option>
                            <option value="_top">_top</option>
                        </select>
                    </div>
                    <div>
                        <button id="${MODAL_SAVE}">${textSave}</button>
                        <button id="${MODAL_CANCEL}">${textCancel}</button>
                    </div>
                </div>
            `
        if (target) {
            document.querySelector(`#${MODAL_INPUT} select[name=target]`).value = target
        }
        jSuites.modal(container, {
            closed: function() {
                instance.closeEditor(cell, true)
            },
            title: gettext("Set value"),
        }).open()
        document.getElementById(MODAL_SAVE).addEventListener("click", (e) => {
            e.preventDefault()
            instance.closeEditor(cell, true)
            jSuites.modal(document.getElementById(MODAL_CONTAINER_ID)).close()
        })
        document.getElementById(MODAL_CANCEL).addEventListener("click", (e) => {
            e.preventDefault()
            jSuites.modal(document.getElementById(MODAL_CONTAINER_ID)).close()
        })
    },
    closeEditor: function(cell, save) {
        const previousValue = cell.innerHTML
        if (save) {
            const data = {}
            const label = document.querySelector(`#${MODAL_INPUT} input[name=label]`).value
            const href = document.querySelector(`#${MODAL_INPUT} input[name=href]`).value
            const title = document.querySelector(`#${MODAL_INPUT} input[name=title]`).value
            const target = document.querySelector(`#${MODAL_INPUT} select[name=target]`).value
            if (label) {
                data.label = label
            }
            if (href) {
                data.href = href
            }
            if (title) {
                data.title = title
            }
            if (target) {
                data.target = target
            }
            createLink(data, cell)
            return Object.keys(data).length ? data : ""
        }
        return previousValue
    }
}

const CUSTOM_EDITORS = {
    "json": JsObjectsEditor,
    "json.modal": CustomModalEditor,
    "link": ATagEditor,
}


function createSpreadsheet(config) {
    config.columns.forEach(column => {
        if (Object.hasOwn(CUSTOM_EDITORS, column.type)) {
            column.type = CUSTOM_EDITORS[column.type]
        }
    })
    window.pluginSpreadsheet = window.jspreadsheet(document.getElementById(spreadsheetId), {
        worksheets: [config],
        oncreateeditor: onCreateEditor,
    })[0]
    document.querySelector("textarea[name=context]").style.display = "none"
    document.querySelector("select[name=mimetype] option[value='application/vnd.oasis.opendocument.spreadsheet']").disabled = "disabled"
}

function destroySpreadsheet() {
    jspreadsheet.destroy(document.getElementById(spreadsheetId))
    window.pluginSpreadsheet = null
    document.querySelector("textarea[name=context]").style.display = ""
    document.querySelector("select[name=mimetype] option[value='application/vnd.oasis.opendocument.spreadsheet']").disabled = ""
}

function saveSpreadsheetIntoFrom(sheetIsOpen) {
    const link = document.querySelector("#id-toggle-spreadsheet a.selected")
    const mimetype = link.dataset.mimetype
    let path = link.dataset.path
    const options = link.dataset.options === undefined ? {} : JSON.parse(link.dataset.options)
    const sheetData = removeEmptyRows(window.pluginSpreadsheet.getData())
    let data
    if (options.titles) {
        data = convertDataIntoObjects(sheetData, options.titles)
    } else {
        data = sheetData
    }
    convertStringIntoNumber(data, options)
    if (options.onlyColumns) {
        data = data[0]
    }
    let contextData
    if (path === ".") {
        contextData = data
    } else {
        contextData = getContextData(mimetype)
        setPayload(contextData, path, data)
    }
    try {
        setDataIntoContext(contextData, {path: path, options: options})
    } catch (error) {
        displayError(error, gettext("Data serialization error"))
        return false
    }
    const sheetConfig = getSpreadsheetConfig()
    setSpreadsheetConfig(sheetConfig, path, sheetIsOpen)
    destroySpreadsheet()
    return true
}

function toggleSource(event) {
    if (event.target.classList.contains("selected")) {
        return
    }
    if (saveSpreadsheetIntoFrom(false)) {
        toggleSelected(event.target)
        appendSpreadsheetButtons()
    }
}

function getColumnName(name, index) {
    return name === undefined ? numberToColumn(index + 1) : name
}

function getUniqueName(name, names) {
    let uname = name, index = 1
    while (names.includes(uname)) {
        uname = `${name}${++index}`
    }
    return uname
}

function convertDataIntoObjects(sheetData, titles) {
    const data = []
    for(let r=0; r < sheetData.length; r++) {
        const line = {}
        for(let c=0; c < sheetData[r].length; c++) {
            const columnName = getUniqueName(getColumnName(titles[c], c), Object.keys(line))
            line[columnName] = sheetData[r][c]
        }
        data.push(line)
    }
    return data
}
function convertStringIntoNumber(sheetData, options) {
    for(let r=0; r < sheetData.length; r++) {
        for(let c=0; c < sheetData[r].length; c++) {
            if (typeof sheetData[r][c] === "string" && options.types && options.types[r] === "numeric") {
                sheetData[r][c] = Number(sheetData[r][c])
            }
        }
    }
}

function createDefaultButton(linkFrame) {
    const link = createLinkButton(gettext("Edit CSV"), gettext("Show data in spreadsheet."), ".")
    link.addEventListener("click", (event) => {
        document.querySelector("select[name=mimetype]").value = "text/csv"
        openJsSheet(event.target)
    })
    linkFrame.appendChild(link)
}

function appendSeparatorBetweenButtons(linkFrame) {
    const label = document.createElement("span")
    label.appendChild(document.createTextNode(gettext("Spreadsheet") + ":"))
    linkFrame.appendChild(label)
}

function removeAllChildNodes(parent) {
    while (parent.firstChild) {
        parent.removeChild(parent.firstChild);
    }
}

function createButtonsFrame() {
        const context = document.querySelector("textarea[name=context]")
        linkFrame = document.createElement("div")
        linkFrame.id = "id-toggle-spreadsheet"
        const partSrc = document.createElement("span")
        const partTable = document.createElement("span")
        partTable.id = "id-set-spreadsheet"
        linkFrame.appendChild(partSrc)
        linkFrame.appendChild(partTable)
        context.before(linkFrame)

        const link = createLinkButton(gettext("Source"), gettext("View source data."))
        link.classList.add("selected")
        link.addEventListener("click", toggleSource)
        partSrc.appendChild(link)

        appendSeparatorBetweenButtons(partSrc)

        context.addEventListener("focus", () => {
            removeAllChildNodes(document.querySelector("#id-set-spreadsheet"))
        })
        context.addEventListener("blur", appendSpreadsheetButtons)
}

function appendSpreadsheetButtons() {
    const linkTableFrame = document.querySelector("#id-set-spreadsheet")
    removeAllChildNodes(linkTableFrame)
    let data
    try {
        data = getContextData(document.querySelector("select[name=mimetype]").value)
    } catch (error) {
        displayError(error, gettext("Parse Data Error"))
        return
    }
    if (!data) {
        createDefaultButton(linkTableFrame)
        return
    }
    const paths = getPathsToArrays(data)
    if (paths.length) {
        for(let path of paths) {
            const payload = getPayload(data, path)
            const tableOptions = convertDataToTableAndOptions(payload)[1]
            tableOptions.table = getTableName(path)
            tableOptions.row = getTableRowName(path)
            const link = createLinkButton(path, gettext('Show data in spreadsheet.'), path, tableOptions)
            link.addEventListener("click", (event) => openJsSheet(event.target))
            linkTableFrame.appendChild(link)
        }
    } else {
        const tableOptions = convertDataToTableAndOptions(data)[1]
        tableOptions.table = "table"
        tableOptions.row = "row"
        const link = createLinkButton(gettext("Display"), gettext('Show data in spreadsheet.'), ".", tableOptions)
        link.addEventListener("click", (event) => openJsSheet(event.target))
        linkTableFrame.appendChild(link)
    }
}

function openSpreadsheetIfRequired() {
    const configValue = document.querySelector("textarea[name=config]").value
    let config = {}
    if (configValue) {
        try {
            config = JSON.parse(configValue)
        } catch (error) {
            displayError(error, gettext("Error in Source settings"))
            return
        }
    }
    if (config && config.openedPath && !window.pluginSpreadsheet) {
        const button = document.querySelector(`#id-toggle-spreadsheet a[data-path="${config.openedPath}"]`)
        if (button) {
            openJsSheet(button)
        }
    }
}

function handleMimetypeSelect() {
    document.querySelector("select[name=mimetype]").addEventListener("change", (event) => {
        document.getElementById("id-toggle-spreadsheet").disabled = event.target.value === "application/vnd.oasis.opendocument.spreadsheet" ? "disabled" : ""
    })
}

function addHelpTextToConfig() {
    const node = document.querySelector("textarea[name=config]")
    const frame = node.closest("div").parentNode
    const container = document.createElement("div")
    container.classList.add("extra-help")
    const label = document.createElement("div")
    label.classList.add("label")
    const link = document.createElement("a")
    link.textContent = "🔗"
    link.href = "https://bossanova.uk/jspreadsheet/docs/editors"
    link.target = "_blank"
    link.title = gettext("Go to the Overview.")
    label.appendChild(document.createTextNode(gettext("Available Editors")))
    label.appendChild(document.createTextNode(" "))
    label.appendChild(link)
    const code = document.createElement("code")
    code.innerHTML = `{"columns": [{"type": "text", "title": "Title", "width": 80}, ...] ...}`
    const help = document.createElement("div")
    help.classList.add("available-editors")
    help.innerHTML = `
        <div>text <code>{"type": "text", "mask": "$ #.##0,00", "decimal": ",", "disabledMaskOnEdition": true}<code></div>
        <div>numeric</div>
        <div>hidden</div>
        <div>dropdown <code>{"type": "dropdown", "source": ["One", "Two", "Three"], "multiple": true}</code></div>
        <div>checkbox</div>
        <div>radio</div>
        <div>calendar <code>{"type": "calendar", "options": {"format": "d. m. yyyy", "startingDay": 1}}</code></div>
        <div>image</div>
        <div>color <code>{"type": "color", "render": "square"}</code></div>
        <div>html</div>
        <div>json</div>
        <div>json.modal</div>
        <div>link</div>
    `
    container.appendChild(label)
    container.appendChild(code)
    container.appendChild(help)
    frame.appendChild(container)
}

document.addEventListener('DOMContentLoaded', () => {
    handleMimetypeSelect()
    createSpreadsheetNode()
    createModalNode()
    setSpreadsheetTranslations()
    submitForm()
    createButtonsFrame()
    appendSpreadsheetButtons()
    addHelpTextToConfig()
    openSpreadsheetIfRequired()
})

})()
