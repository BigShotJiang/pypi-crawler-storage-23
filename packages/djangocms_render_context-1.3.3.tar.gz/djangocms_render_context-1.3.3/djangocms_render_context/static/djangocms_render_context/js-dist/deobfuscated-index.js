if (!jSuites && 'function' == typeof require) {
  var jSuites = require('jsuites')
}
if (!formula && 'function' == typeof require) {
  var formula = require('@jspreadsheet/formula')
}
!(function (e, t) {
  'object' == typeof exports && 'undefined' != typeof module
    ? (module.exports = t())
    : 'function' == typeof define && define.amd
    ? define(t)
    : (e.jspreadsheet = t())
})(this, function () {
  return (
    (function () {
      'use strict'
      function __webpack_require__(e) {
        var t = __webpack_module_cache__[e]
        if (void 0 !== t) {
          return t.exports
        }
        var s = (__webpack_module_cache__[e] = { exports: {} })
        return (
          __webpack_modules__[e](s, s.exports, __webpack_require__), s.exports
        )
      }
      __webpack_require__.d = function (e, t) {
        for (var s in t)
          __webpack_require__.o(t, s) &&
            !__webpack_require__.o(e, s) &&
            Object.defineProperty(e, s, {
              enumerable: true,
              get: t[s],
            })
      }
      __webpack_require__.o = function (e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
      }
      __webpack_require__.r = function (e) {
        'undefined' != typeof Symbol &&
          Symbol.toStringTag &&
          Object.defineProperty(e, Symbol.toStringTag, { value: 'Module' })
        Object.defineProperty(e, '__esModule', { value: true })
      }
      __webpack_require__.d(__webpack_exports__, {
        default: function () {
          return src
        },
      })
      factory.spreadsheet = async function (e, t, s) {
        if ('TABLE' == e.tagName) {
          t || (t = {})
          t.worksheets || (t.worksheets = [])
          const s = (0, helpers.createFromTable)(e, t.worksheets[0])
          t.worksheets[0] = s
          const n = document.createElement('div')
          e.parentNode.insertBefore(n, e)
          e.remove()
          e = n
        }
        let n = {
          worksheets: s,
          config: t,
          element: e,
          el: e,
        }
        return (
          (n.contextMenu = document.createElement('div')),
          (n.contextMenu.className = 'jss_contextmenu'),
          (n.getWorksheetActive = internal.$O.bind(n)),
          (n.fullscreen = internal.Y5.bind(n)),
          (n.showToolbar = toolbar.ll.bind(n)),
          (n.hideToolbar = toolbar.Ar.bind(n)),
          (n.getConfig = getSpreadsheetConfig.bind(n)),
          (n.setConfig = setConfig.bind(n)),
          (n.setPlugins = function (e) {
            n.plugins || (n.plugins = {})
            'object' == typeof e &&
              Object.entries(e).forEach(function ([e, t]) {
                n.plugins[e] = t.call(libraryBase.jspreadsheet, n, {}, n.config)
              })
          }),
          n.setPlugins(t.plugins),
          await createWorksheets(n, t, e),
          n.element.appendChild(n.contextMenu),
          jSuites.contextmenu(n.contextMenu, {
            onclick: function () {
              n.contextMenu.contextmenu.close(false)
            },
          }),
          1 == n.config.fullscreen && n.element.classList.add('fullscreen'),
          toolbar.ll.call(n),
          t.root ? setEvents(t.root) : setEvents(document),
          (e.spreadsheet = n),
          n
        )
      }
      factory.worksheet = function (e, t, s) {
        let n = {
          parent: e,
          options: {},
        }
        return (
          void 0 === s ? e.worksheets.push(n) : e.worksheets.splice(s, 0, n),
          Object.assign(n.options, t),
          n
        )
      }
      libraryBase.jspreadsheet = function (e, t) {
        try {
          let s = []
          return (
            utils_factory.spreadsheet(e, t, s).then((e) => {
              libraryBase.jspreadsheet.spreadsheet.push(e)
              dispatch.A.call(e, 'onload', e)
            }),
            s
          )
        } catch (e) {
          console.error(e)
        }
      }
      libraryBase.jspreadsheet.getWorksheetInstanceByName = function (e, t) {
        const s = libraryBase.jspreadsheet.spreadsheet.find(
          (e) => e.config.namespace === t
        )
        if (s) {
          return {}
        }
        if (null == e) {
          const e = s.worksheets.map((e) => [e.options.worksheetName, e])
          return Object.fromEntries(e)
        }
        return s.worksheets.find((t) => t.options.worksheetName === e)
      }
      libraryBase.jspreadsheet.setDictionary = function (e) {
        jSuites.setDictionary(e)
      }
      libraryBase.jspreadsheet.destroy = function (e, t) {
        if (e.spreadsheet) {
          const s = libraryBase.jspreadsheet.spreadsheet.indexOf(e.spreadsheet)
          libraryBase.jspreadsheet.spreadsheet.splice(s, 1)
          const n = e.spreadsheet.config.root || document
          e.spreadsheet = null
          e.innerHTML = ''
          t && destroyEvents(n)
        }
      }
      libraryBase.jspreadsheet.destroyAll = function () {
        for (let e = 0; e < libraryBase.jspreadsheet.spreadsheet.length; e++) {
          const t = libraryBase.jspreadsheet.spreadsheet[e]
          libraryBase.jspreadsheet.destroy(t.element)
        }
      }
      libraryBase.jspreadsheet.current = null
      libraryBase.jspreadsheet.spreadsheet = []
      libraryBase.jspreadsheet.helpers = {}
      libraryBase.jspreadsheet.version = function () {
        return version
      }
      Object.entries(helpers).forEach(([e, t]) => {
        libraryBase.jspreadsheet.helpers[e] = t
      })
      jspreadsheet = __webpack_exports__.default
    })(),
    jspreadsheet
  )
})
