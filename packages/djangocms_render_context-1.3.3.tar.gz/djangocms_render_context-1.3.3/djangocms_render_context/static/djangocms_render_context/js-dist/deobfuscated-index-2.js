if (!jSuites && "function" == typeof require) var jSuites = require("jsuites");
if (!formula && "function" == typeof require) var formula = require("@jspreadsheet/formula");
!function (e, t) {
  "object" == typeof exports && "undefined" != typeof module ? module.exports = t() : "function" == typeof define && define.amd ? define(t) : e.jspreadsheet = t();
}(this, function () {
  var jspreadsheet;
  return function () {
    "use strict";
    var __webpack_modules__ = {805: function (e, t) {
      const s = function (e) {
        const t = this, s = [];
        for (let n = 0; n < e.length; n++) {
          const o = e[n].x, r = e[n].y, l = t.options.columns[o].name ? t.options.columns[o].name : o;
          s[r] || (s[r] = {row: r, data: {}}), s[r].data[l] = e[n].value;
        }
        return s.filter(function (e) {
          return null != e;
        });
      }, n = function (e, t) {
        const s = this, n = o.call(s.parent, "onbeforesave", s.parent, s, t);
        if (n) t = n; else if (false === n) return false;
        jSuites.ajax({url: e, method: "POST", dataType: "json", data: {data: JSON.stringify(t)}, success: function (e) {
          o.call(s, "onsave", s.parent, s, t);
        }});
      }, o = function (e) {
        const t = this;
        let o = null, r = t.parent ? t.parent : t;
        if (!r.ignoreEvents && ("function" == typeof r.config.onevent && (o = r.config.onevent.apply(this, arguments)), "function" == typeof r.config[e] && (o = r.config[e].apply(this, Array.prototype.slice.call(arguments, 1))), "object" == typeof r.plugins)) {
          const e = Object.keys(r.plugins);
          for (let t = 0; t < e.length; t++) {
            const s = e[t], n = r.plugins[s];
            "function" == typeof n.onevent && (o = n.onevent.apply(this, arguments));
          }
        }
        if ("onafterchanges" == e) {
          const e = arguments;
          if ("object" == typeof r.plugins && Object.entries(r.plugins).forEach(function ([, s]) {
            "function" == typeof s.persistence && s.persistence(t, "setValue", {data: e[2]});
          }), t.options.persistence) {
            const e = 1 == t.options.persistence ? t.options.url : t.options.persistence, o = s.call(t, arguments[2]);
            n.call(t, e, o);
          }
        }
        return o;
      };
      t.A = o;
    }, 829: function (e, t, s) {
      s.d(t, {F8: function () {
        return l;
      }, N$: function () {
        return r;
      }, dr: function () {
        return i;
      }});
      var n = s(530), o = s(657);
      const r = function (e) {
        const t = this;
        if (t.options.filters) {
          e = parseInt(e), t.resetSelection();
          let s = [];
          if ("checkbox" == t.options.columns[e].type) s.push({id: "true", name: "True"}), s.push({id: "false", name: "False"}); else {
            const n = [];
            let o = false;
            for (let s = 0; s < t.options.data.length; s++) {
              const r = t.options.data[s][e], l = t.records[s][e].element.innerHTML;
              r && l ? n[r] = l : o = true;
            }
            const r = Object.keys(n);
            s = [];
            for (let e = 0; e < r.length; e++) s.push({id: r[e], name: n[r[e]]});
            o && s.push({value: "", id: "", name: "(Blanks)"});
          }
          const n = document.createElement("div");
          t.filter.children[e + 1].innerHTML = "", t.filter.children[e + 1].appendChild(n), t.filter.children[e + 1].style.paddingLeft = "0px", t.filter.children[e + 1].style.paddingRight = "0px", t.filter.children[e + 1].style.overflow = "initial";
          const r = {data: s, multiple: true, autocomplete: true, opened: true, value: undefined !== t.filters[e] ? t.filters[e] : null, width: "100%", position: 1 == t.options.tableOverflow || 1 == t.parent.config.fullscreen, onclose: function (s) {
            i.call(t), t.filters[e] = s.dropdown.getValue(true), t.filter.children[e + 1].innerHTML = s.dropdown.getText(), t.filter.children[e + 1].style.paddingLeft = "", t.filter.children[e + 1].style.paddingRight = "", t.filter.children[e + 1].style.overflow = "", l.call(t, e), o.G9.call(t);
          }};
          jSuites.dropdown(n, r);
        } else console.log("Jspreadsheet: filters not enabled.");
      }, l = function (e) {
        const t = this;
        if (!e) for (let s = 0; s < t.filter.children.length; s++) t.filters[s] && (e = s);
        const s = function (e, s, n) {
          for (let o = 0; o < e.length; o++) {
            const r = "" + t.options.data[n][s], l = "" + t.records[n][s].element.innerHTML;
            if (e[o] == r || e[o] == l) return true;
          }
          return false;
        }, o = t.filters[e];
        t.results = [];
        for (let n = 0; n < t.options.data.length; n++) s(o, e, n) && t.results.push(n);
        t.results.length || (t.results = null), n.hG.call(t);
      }, i = function () {
        const e = this;
        if (e.options.filters) for (let t = 0; t < e.filter.children.length; t++) e.filter.children[t].innerHTML = "&nbsp;", e.filters[t] = null;
        e.results = null, n.hG.call(e);
      };
    }, 160: function (e, t, s) {
      s.d(t, {e: function () {
        return o;
      }});
      var n = s(530);
      const o = function (e) {
        const t = this;
        if (e && (t.options.footers = e), t.options.footers) {
          t.tfoot || (t.tfoot = document.createElement("tfoot"), t.table.appendChild(t.tfoot));
          for (let e = 0; e < t.options.footers.length; e++) {
            let s;
            if (t.tfoot.children[e]) s = t.tfoot.children[e]; else {
              s = document.createElement("tr");
              const e = document.createElement("td");
              s.appendChild(e), t.tfoot.appendChild(s);
            }
            for (let o = 0; o < t.headers.length; o++) {
              let r;
              if (t.options.footers[e][o] || (t.options.footers[e][o] = ""), t.tfoot.children[e].children[o + 1]) r = t.tfoot.children[e].children[o + 1]; else {
                r = document.createElement("td"), s.appendChild(r);
                const e = t.options.columns[o].align || t.options.defaultColAlign || "center";
                r.style.textAlign = e;
              }
              r.textContent = n.$x.call(t, +t.records.length + o, e, t.options.footers[e][o]), r.style.display = t.cols[o].colElement.style.display;
            }
          }
        }
      };
    }, 296: function (e, t, s) {
      s.d(t, {w: function () {
        return n;
      }});
      const n = function () {
        const e = this;
        let t = 0;
        if (e.options.freezeColumns > 0) for (let s = 0; s < e.options.freezeColumns; s++) {
          let n;
          n = e.options.columns && e.options.columns[s] && undefined !== e.options.columns[s].width ? parseInt(e.options.columns[s].width) : undefined !== e.options.defaultColWidth ? parseInt(e.options.defaultColWidth) : 100, t += n;
        }
        return t;
      };
    }, 978: function (e, t, s) {
      s.r(t), s.d(t, {createFromTable: function () {
        return u;
      }, getCaretIndex: function () {
        return o;
      }, getCellNameFromCoords: function () {
        return i;
      }, getColumnName: function () {
        return l;
      }, getCoordsFromCellName: function () {
        return a;
      }, getCoordsFromRange: function () {
        return c;
      }, invert: function () {
        return r;
      }, parseCSV: function () {
        return d;
      }});
      var n = s(689);
      const o = function (e) {
        let t;
        t = this.config.root ? this.config.root : window;
        let s = 0;
        const n = t.getSelection();
        if (n && 0 !== n.rangeCount) {
          const t = n.getRangeAt(0), o = t.cloneRange();
          o.selectNodeContents(e), o.setEnd(t.endContainer, t.endOffset), s = o.toString().length;
        }
        return s;
      }, r = function (e) {
        const t = [], s = Object.keys(e);
        for (let n = 0; n < s.length; n++) t[e[s[n]]] = s[n];
        return t;
      }, l = function (e) {
        let t, s = e + 1, n = "";
        for (; s > 0;) t = (s - 1) % 26, n = String.fromCharCode(65 + t).toString() + n, s = parseInt((s - t) / 26);
        return n;
      }, a = function (e) {
        const t = /^[a-zA-Z]+/.exec(e);
        if (t) {
          let s = 0;
          for (let e = 0; e < t[0].length; e++) s += parseInt(t[0].charCodeAt(e) - 64) * Math.pow(26, t[0].length - 1 - e);
          s--, s < 0 && (s = 0);
          let n = parseInt(/[0-9]+$/.exec(e)) || null;
          return n > 0 && n--, [s, n];
        }
      }, c = function (e) {
        const [t, s] = e.split(":");
        return [...a(t), ...a(s)];
      }, d = function (e, t) {
        t = t || ",", e = e.replace(/\r?\n$|\r$|\n$/g, "");
        const s = [];
        let n = false, o = 0, r = 0, l = 0;
        for (let i = 0; i < e.length; i++) {
          const a = e[i], c = e[i + 1];
          s[r] = s[r] || [], s[r][l] = s[r][l] || "", '"' == a && n && '"' == c ? (s[r][l] += a, ++i) : '"' != a ? a != t || n ? "\r" != a || "\n" != c || n ? "\n" == a && !n || "\r" == a && !n ? (++r, o = Math.max(o, l), l = 0) : s[r][l] += a : (++r, o = Math.max(o, l), l = 0, ++i) : ++l : n = !n;
        }
        return s.forEach((e, t) => {
          for (let t = e.length; t <= o; t++) e.push("");
        }), s;
      }, u = function (e, t) {
        if ("TABLE" == e.tagName) {
          t || (t = {}), t.columns = [], t.data = [];
          const s = e.querySelectorAll("colgroup > col");
          if (s.length) for (let e = 0; e < s.length; e++) {
            let n = s[e].style.width;
            n || (n = s[e].getAttribute("width")), n && (t.columns[e] || (t.columns[e] = {}), t.columns[e].width = n);
          }
          const o = function (e, s) {
            let n = e.getBoundingClientRect();
            const o = n.width > 50 ? n.width : 50;
            t.columns[s] || (t.columns[s] = {}), e.getAttribute("data-celltype") ? t.columns[s].type = e.getAttribute("data-celltype") : t.columns[s].type = "text", t.columns[s].width = o + "px", t.columns[s].title = e.innerHTML, e.style.textAlign && (t.columns[s].align = e.style.textAlign), (n = e.getAttribute("name")) && (t.columns[s].name = n), (n = e.getAttribute("id")) && (t.columns[s].id = n), (n = e.getAttribute("data-mask")) && (t.columns[s].mask = n);
          }, r = [];
          let l = e.querySelectorAll(":scope > thead > tr");
          if (l.length) {
            for (let e = 0; e < l.length - 1; e++) {
              const t = [];
              for (let s = 0; s < l[e].children.length; s++) {
                const n = {title: l[e].children[s].textContent, colspan: l[e].children[s].getAttribute("colspan") || 1};
                t.push(n);
              }
              r.push(t);
            }
            l = l[l.length - 1].children;
            for (let e = 0; e < l.length; e++) o(l[e], e);
          }
          let i = 0;
          const a = {}, c = {}, d = {}, u = {};
          let p = e.querySelectorAll(":scope > tr, :scope > tbody > tr");
          for (let e = 0; e < p.length; e++) if (t.data[i] = [], 1 != t.parseTableFirstRowAsHeader || l.length || 0 != e) {
            for (let s = 0; s < p[e].children.length; s++) {
              let o = p[e].children[s].getAttribute("data-formula");
              o ? "=" != o.substr(0, 1) && (o = "=" + o) : o = p[e].children[s].innerHTML, t.data[i].push(o);
              const r = (0, n.t3)([s, e]), l = p[e].children[s].getAttribute("class");
              l && (u[r] = l);
              const c = parseInt(p[e].children[s].getAttribute("colspan")) || 0, h = parseInt(p[e].children[s].getAttribute("rowspan")) || 0;
              (c || h) && (a[r] = [c || 1, h || 1]), p[e].children[s].style && "none" == p[e].children[s].style.display && (p[e].children[s].style.display = "");
              const m = p[e].children[s].getAttribute("style");
              m && (d[r] = m), p[e].children[s].classList.contains("styleBold") && (d[r] ? d[r] += "; font-weight:bold;" : d[r] = "font-weight:bold;");
            }
            p[e].style && p[e].style.height && (c[e] = {height: p[e].style.height}), i++;
          } else for (let t = 0; t < p[e].children.length; t++) o(p[e].children[t], t);
          if (Object.keys(r).length > 0 && (t.nestedHeaders = r), Object.keys(d).length > 0 && (t.style = d), Object.keys(a).length > 0 && (t.mergeCells = a), Object.keys(c).length > 0 && (t.rows = c), Object.keys(u).length > 0 && (t.classes = u), p = e.querySelectorAll("tfoot tr"), p.length) {
            const e = [];
            for (let t = 0; t < p.length; t++) {
              let s = [];
              for (let e = 0; e < p[t].children.length; e++) s.push(p[t].children[e].textContent);
              e.push(s);
            }
            Object.keys(e).length > 0 && (t.footers = e);
          }
          if (1 == t.parseTableAutoCellType) {
            const e = [];
            for (let s = 0; s < t.columns.length; s++) {
              let n = true, o = true;
              e[s] = [];
              for (let r = 0; r < t.data.length; r++) {
                const l = t.data[r][s];
                e[s][l] || (e[s][l] = 0), e[s][l]++, l.length > 25 && (n = false), 10 == l.length && "-" == l.substr(4, 1) && "-" == l.substr(7, 1) || (o = false);
              }
              const r = Object.keys(e[s]).length;
              o ? t.columns[s].type = "calendar" : 1 == n && r > 1 && r <= parseInt(0.1 * t.data.length) && (t.columns[s].type = "dropdown", t.columns[s].source = Object.keys(e[s]));
            }
          }
          return t;
        }
        console.log("Element is not a table");
      };
    }, 911: function (e, t, s) {
      s.d(t, {Dh: function () {
        return c;
      }, ZS: function () {
        return h;
      }, tN: function () {
        return p;
      }});
      var n = s(805), o = s(689), r = s(530), l = s(910), i = s(94), a = s(657);
      const c = function (e) {
        const t = this;
        if (1 != t.ignoreHistory) {
          const s = ++t.historyIndex;
          t.history = t.history = t.history.slice(0, s + 1), t.history[s] = e;
        }
      }, d = function (e, t) {
        const s = this, n = t.insertBefore ? +t.rowNumber : t.rowNumber + 1;
        if (1 == s.options.search && s.results && s.results.length != s.rows.length && s.resetSearch(), 1 == e) {
          const e = t.numOfRows;
          for (let t = n; t < e + n; t++) s.rows[t].element.parentNode.removeChild(s.rows[t].element);
          s.records.splice(n, e), s.options.data.splice(n, e), s.rows.splice(n, e), a.at.call(s, 1, n, e + n - 1);
        } else {
          const e = t.rowRecords.map(e => [...e]);
          s.records = (0, o.Hh)(s.records, n, e);
          const r = t.rowData.map(e => [...e]);
          s.options.data = (0, o.Hh)(s.options.data, n, r), s.rows = (0, o.Hh)(s.rows, n, t.rowNode);
          let l = 0;
          for (let e = n; e < t.numOfRows + n; e++) s.tbody.insertBefore(t.rowNode[l].element, s.tbody.children[e]), l++;
        }
        for (let e = n; e < s.rows.length; e++) s.rows[e].y = e;
        for (let e = n; e < s.records.length; e++) for (let t = 0; t < s.records[e].length; t++) s.records[e][t].y = e;
        s.options.pagination > 0 && s.page(s.pageNumber), r.o8.call(s);
      }, u = function (e, t) {
        const s = this, n = t.insertBefore ? t.columnNumber : t.columnNumber + 1;
        if (1 == e) {
          const e = t.numOfColumns;
          s.options.columns.splice(n, e);
          for (let t = n; t < e + n; t++) s.headers[t].parentNode.removeChild(s.headers[t]), s.cols[t].colElement.parentNode.removeChild(s.cols[t].colElement);
          s.headers.splice(n, e), s.cols.splice(n, e);
          for (let o = 0; o < t.data.length; o++) {
            for (let t = n; t < e + n; t++) s.records[o][t].element.parentNode.removeChild(s.records[o][t].element);
            s.records[o].splice(n, e), s.options.data[o].splice(n, e);
          }
          if (s.options.footers) for (let t = 0; t < s.options.footers.length; t++) s.options.footers[t].splice(n, e);
        } else {
          s.options.columns = (0, o.Hh)(s.options.columns, n, t.columns), s.headers = (0, o.Hh)(s.headers, n, t.headers), s.cols = (0, o.Hh)(s.cols, n, t.cols);
          let e = 0;
          for (let o = n; o < t.numOfColumns + n; o++) s.headerContainer.insertBefore(t.headers[e], s.headerContainer.children[o + 1]), s.colgroupContainer.insertBefore(t.cols[e].colElement, s.colgroupContainer.children[o + 1]), e++;
          for (let e = 0; e < t.data.length; e++) {
            s.options.data[e] = (0, o.Hh)(s.options.data[e], n, t.data[e]), s.records[e] = (0, o.Hh)(s.records[e], n, t.records[e]);
            let r = 0;
            for (let o = n; o < t.numOfColumns + n; o++) s.rows[e].element.insertBefore(t.records[e][r].element, s.rows[e].element.children[o + 1]), r++;
          }
          if (s.options.footers) for (let e = 0; e < s.options.footers.length; e++) s.options.footers[e] = (0, o.Hh)(s.options.footers[e], n, t.footers[e]);
        }
        for (let e = n; e < s.cols.length; e++) s.cols[e].x = e;
        for (let e = 0; e < s.records.length; e++) for (let t = n; t < s.records[e].length; t++) s.records[e][t].x = t;
        if (s.options.nestedHeaders && s.options.nestedHeaders.length > 0 && s.options.nestedHeaders[0] && s.options.nestedHeaders[0][0]) for (let n = 0; n < s.options.nestedHeaders.length; n++) {
          let o;
          o = 1 == e ? parseInt(s.options.nestedHeaders[n][s.options.nestedHeaders[n].length - 1].colspan) - t.numOfColumns : parseInt(s.options.nestedHeaders[n][s.options.nestedHeaders[n].length - 1].colspan) + t.numOfColumns, s.options.nestedHeaders[n][s.options.nestedHeaders[n].length - 1].colspan = o, s.thead.children[n].children[s.thead.children[n].children.length - 1].setAttribute("colspan", o);
        }
        r.o8.call(s);
      }, p = function () {
        const e = this, t = !!e.parent.ignoreEvents, s = !!e.ignoreHistory;
        e.parent.ignoreEvents = true, e.ignoreHistory = true;
        const o = [];
        let r;
        if (e.historyIndex >= 0) if (r = e.history[e.historyIndex--], "insertRow" == r.action) d.call(e, 1, r); else if ("deleteRow" == r.action) d.call(e, 0, r); else if ("insertColumn" == r.action) u.call(e, 1, r); else if ("deleteColumn" == r.action) u.call(e, 0, r); else if ("moveRow" == r.action) e.moveRow(r.newValue, r.oldValue); else if ("moveColumn" == r.action) e.moveColumn(r.newValue, r.oldValue); else if ("setMerge" == r.action) e.removeMerge(r.column, r.data); else if ("setStyle" == r.action) e.setStyle(r.oldValue, null, null, 1); else if ("setWidth" == r.action) e.setWidth(r.column, r.oldValue); else if ("setHeight" == r.action) e.setHeight(r.row, r.oldValue); else if ("setHeader" == r.action) e.setHeader(r.column, r.oldValue); else if ("setComments" == r.action) e.setComments(r.oldValue); else if ("orderBy" == r.action) {
          let t = [];
          for (let e = 0; e < r.rows.length; e++) t[r.rows[e]] = e;
          i.Th.call(e, r.column, r.order ? 0 : 1), i.iY.call(e, t);
        } else if ("setValue" == r.action) {
          for (let t = 0; t < r.records.length; t++) o.push({x: r.records[t].x, y: r.records[t].y, value: r.records[t].oldValue}), r.oldStyle && e.resetStyle(r.oldStyle);
          e.setValue(o), r.selection && e.updateSelectionFromCoords(r.selection[0], r.selection[1], r.selection[2], r.selection[3]);
        }
        e.parent.ignoreEvents = t, e.ignoreHistory = s, n.A.call(e, "onundo", e, r);
      }, h = function () {
        const e = this, t = !!e.parent.ignoreEvents, s = !!e.ignoreHistory;
        let o;
        if (e.parent.ignoreEvents = true, e.ignoreHistory = true, e.historyIndex < e.history.length - 1) if (o = e.history[++e.historyIndex], "insertRow" == o.action) d.call(e, 0, o); else if ("deleteRow" == o.action) d.call(e, 1, o); else if ("insertColumn" == o.action) u.call(e, 0, o); else if ("deleteColumn" == o.action) u.call(e, 1, o); else if ("moveRow" == o.action) e.moveRow(o.oldValue, o.newValue); else if ("moveColumn" == o.action) e.moveColumn(o.oldValue, o.newValue); else if ("setMerge" == o.action) l.FU.call(e, o.column, o.colspan, o.rowspan, 1); else if ("setStyle" == o.action) e.setStyle(o.newValue, null, null, 1); else if ("setWidth" == o.action) e.setWidth(o.column, o.newValue); else if ("setHeight" == o.action) e.setHeight(o.row, o.newValue); else if ("setHeader" == o.action) e.setHeader(o.column, o.newValue); else if ("setComments" == o.action) e.setComments(o.newValue); else if ("orderBy" == o.action) i.Th.call(e, o.column, o.order), i.iY.call(e, o.rows); else if ("setValue" == o.action) {
          e.setValue(o.records);
          for (let t = 0; t < o.records.length; t++) o.oldStyle && e.resetStyle(o.newStyle);
          o.selection && e.updateSelectionFromCoords(o.selection[0], o.selection[1], o.selection[2], o.selection[3]);
        }
        e.parent.ignoreEvents = t, e.ignoreHistory = s, n.A.call(e, "onredo", e, o);
      };
    }, 530: function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.d(__webpack_exports__, {$O: function () {
        return getWorksheetActive;
      }, $x: function () {
        return parseValue;
      }, C6: function () {
        return showIndex;
      }, Em: function () {
        return executeFormula;
      }, P9: function () {
        return createCell;
      }, Rs: function () {
        return updateScroll;
      }, TI: function () {
        return hideIndex;
      }, Xr: function () {
        return getCellFromCoords;
      }, Y5: function () {
        return fullscreen;
      }, am: function () {
        return updateTable;
      }, dw: function () {
        return isFormula;
      }, eN: function () {
        return getWorksheetInstance;
      }, hG: function () {
        return updateResult;
      }, ju: function () {
        return createNestedHeader;
      }, k9: function () {
        return updateCell;
      }, o8: function () {
        return updateTableReferences;
      }, p9: function () {
        return getLabel;
      }, rS: function () {
        return getMask;
      }, tT: function () {
        return getCell;
      }, xF: function () {
        return updateFormulaChain;
      }, yB: function () {
        return updateFormula;
      }});
      var _dispatch_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(805), _selection_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(657), _helpers_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(978), _meta_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(654), _freeze_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(296), _pagination_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(167), _footer_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(160), _internalHelpers_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(689);
      const updateTable = function () {
        const e = this;
        if (e.options.minSpareRows > 0) {
          let t = 0;
          for (let s = e.rows.length - 1; s >= 0; s--) {
            let n = false;
            for (let t = 0; t < e.headers.length; t++) e.options.data[s][t] && (n = true);
            if (n) break;
            t++;
          }
          e.options.minSpareRows - t > 0 && e.insertRow(e.options.minSpareRows - t);
        }
        if (e.options.minSpareCols > 0) {
          let t = 0;
          for (let s = e.headers.length - 1; s >= 0; s--) {
            let n = false;
            for (let t = 0; t < e.rows.length; t++) e.options.data[t][s] && (n = true);
            if (n) break;
            t++;
          }
          e.options.minSpareCols - t > 0 && e.insertColumn(e.options.minSpareCols - t);
        }
        e.options.footers && _footer_js__WEBPACK_IMPORTED_MODULE_0__.e.call(e), setTimeout(function () {
          _selection_js__WEBPACK_IMPORTED_MODULE_1__.Aq.call(e);
        }, 0);
      }, parseNumber = function (e, t) {
        const s = t && this.options.columns[t].decimal ? this.options.columns[t].decimal : ".";
        let n = "" + e;
        return n = n.split(s), n[0] = n[0].match(/[+-]?[0-9]/g), n[0] && (n[0] = n[0].join("")), n[1] && (n[1] = n[1].match(/[0-9]*/g).join("")), n[0] && Number.isInteger(Number(n[0])) ? n[1] ? Number(n[0] + "." + n[1]) : Number(n[0] + ".00") : null;
      }, executeFormula = function (expression, x, y) {
        const obj = this, formulaResults = [], formulaLoopProtection = [], execute = function (expression, x, y) {
          const parentId = (0, _internalHelpers_js__WEBPACK_IMPORTED_MODULE_2__.t3)([x, y]);
          if (formulaLoopProtection[parentId]) return console.error("Reference loop detected"), "#ERROR";
          formulaLoopProtection[parentId] = true;
          const tokensUpdate = function (e) {
            for (let t = 0; t < e.length; t++) {
              const s = [], n = e[t].split(":"), o = (0, _internalHelpers_js__WEBPACK_IMPORTED_MODULE_2__.vu)(n[0], true), r = (0, _internalHelpers_js__WEBPACK_IMPORTED_MODULE_2__.vu)(n[1], true);
              let l, i, a, c;
              o[0] <= r[0] ? (l = o[0], i = r[0]) : (l = r[0], i = o[0]), o[1] <= r[1] ? (a = o[1], c = r[1]) : (a = r[1], c = o[1]);
              for (let e = a; e <= c; e++) for (let t = l; t <= i; t++) s.push((0, _internalHelpers_js__WEBPACK_IMPORTED_MODULE_2__.t3)([t, e]));
              expression = expression.replace(e[t], s.join(","));
            }
          };
          expression = expression.replace(/\$?([A-Z]+)\$?([0-9]+)/g, "$1$2");
          let tokens = expression.match(/([A-Z]+[0-9]+)\:([A-Z]+[0-9]+)/g);
          if (tokens && tokens.length && tokensUpdate(tokens), tokens = expression.match(/([A-Z]+[0-9]+)/g), tokens && tokens.indexOf(parentId) > -1) return console.error("Self Reference detected"), "#ERROR";
          {
            const formulaExpressions = {};
            if (tokens) for (let i = 0; i < tokens.length; i++) if (obj.formula[tokens[i]] || (obj.formula[tokens[i]] = []), obj.formula[tokens[i]].indexOf(parentId) < 0 && obj.formula[tokens[i]].push(parentId), eval("typeof(" + tokens[i] + ') == "undefined"')) {
              const e = (0, _internalHelpers_js__WEBPACK_IMPORTED_MODULE_2__.vu)(tokens[i], 1);
              let t;
              if (t = undefined !== obj.options.data[e[1]] && undefined !== obj.options.data[e[1]][e[0]] ? obj.options.data[e[1]][e[0]] : "", "=" == ("" + t).substr(0, 1) && (undefined !== formulaResults[tokens[i]] ? t = formulaResults[tokens[i]] : (t = execute(t, e[0], e[1]), formulaResults[tokens[i]] = t)), "" == ("" + t).trim()) formulaExpressions[tokens[i]] = null; else if (t == Number(t) && 0 != obj.parent.config.autoCasting) formulaExpressions[tokens[i]] = Number(t); else {
                const s = parseNumber.call(obj, t, e[0]);
                0 != obj.parent.config.autoCasting && s ? formulaExpressions[tokens[i]] = s : formulaExpressions[tokens[i]] = '"' + t + '"';
              }
            }
            const ret = _dispatch_js__WEBPACK_IMPORTED_MODULE_3__.A.call(obj, "onbeforeformula", obj, expression, x, y);
            if (false === ret) return expression;
            let res;
            ret && (expression = ret);
            try {
              res = formula(expression.substr(1), formulaExpressions, x, y, obj), "function" == typeof res && (res = "#ERROR");
            } catch (e) {
              res = "#ERROR", true === obj.parent.config.debugFormulas && console.log(expression.substr(1), formulaExpressions, e);
            }
            return res;
          }
        };
        return execute(expression, x, y);
      }, parseValue = function (e, t, s, n) {
        const o = this;
        "=" == ("" + s).substr(0, 1) && 0 != o.parent.config.parseFormulas && (s = executeFormula.call(o, s, e, t));
        const r = o.options.columns && o.options.columns[e];
        if (r && !isFormula(s)) {
          let e = null;
          if (e = getMask(r)) {
            s && s == Number(s) && (s = Number(s));
            let t = jSuites.mask.render(s, e, true);
            if (n && e.mask) {
              const o = e.mask.split(";");
              o[1] && (o[1].match(new RegExp("\\[Red\\]", "gi")) && (s < 0 ? n.classList.add("red") : n.classList.remove("red")), o[1].match(new RegExp("\\(", "gi")) && s < 0 && (t = "(" + t + ")"));
            }
            t && (s = t);
          }
        }
        return s;
      }, getDropDownValue = function (e, t) {
        const s = this, n = [];
        if (s.options.columns && s.options.columns[e] && s.options.columns[e].source) {
          const o = [], r = s.options.columns[e].source;
          for (let e = 0; e < r.length; e++) "object" == typeof r[e] ? o[r[e].id] = r[e].name : o[r[e]] = r[e];
          const l = Array.isArray(t) ? t : ("" + t).split(";");
          for (let e = 0; e < l.length; e++) "object" == typeof l[e] ? n.push(o[l[e].id]) : o[l[e]] && n.push(o[l[e]]);
        } else console.error("Invalid column");
        return n.length > 0 ? n.join("; ") : "";
      }, stripScript = function (e) {
        const t = new Option;
        t.innerHTML = e;
        let s = null;
        for (e = t.getElementsByTagName("script"); s = e[0];) s.parentNode.removeChild(s);
        return t.innerHTML;
      }, createCell = function (e, t, s) {
        const n = this;
        let o = document.createElement("td");
        if (o.setAttribute("data-x", e), o.setAttribute("data-y", t), "none" === n.headers[e].style.display && (o.style.display = "none"), "=" == ("" + s).substr(0, 1) && 1 == n.options.secureFormulas) {
          const e = secureFormula(s);
          e != s && (s = e);
        }
        if (n.options.columns && n.options.columns[e] && "object" == typeof n.options.columns[e].type) true === n.parent.config.parseHTML ? o.innerHTML = s : o.textContent = s, "function" == typeof n.options.columns[e].type.createCell && n.options.columns[e].type.createCell(o, s, parseInt(e), parseInt(t), n, n.options.columns[e]); else if (n.options.columns && n.options.columns[e] && "hidden" == n.options.columns[e].type) o.style.display = "none", o.textContent = s; else if (n.options.columns && n.options.columns[e] && ("checkbox" == n.options.columns[e].type || "radio" == n.options.columns[e].type)) {
          const r = document.createElement("input");
          r.type = n.options.columns[e].type, r.name = "c" + e, r.checked = 1 == s || 1 == s || "true" == s, r.onclick = function () {
            n.setValue(o, this.checked);
          }, 1 != n.options.columns[e].readOnly && 0 != n.options.editable || r.setAttribute("disabled", "disabled"), o.appendChild(r), n.options.data[t][e] = r.checked;
        } else if (n.options.columns && n.options.columns[e] && "calendar" == n.options.columns[e].type) {
          let t = null;
          if (!("-" == (s = "" + s).substr(4, 1) && "-" == s.substr(7, 1) || 4 == (s = s.split("-"))[0].length && s[0] == Number(s[0]) && 2 == s[1].length && s[1] == Number(s[1]))) {
            const o = jSuites.calendar.extractDateFromString(s, n.options.columns[e].options && n.options.columns[e].options.format || "YYYY-MM-DD");
            o && (t = o);
          }
          o.textContent = jSuites.calendar.getDateString(t || s, n.options.columns[e].options && n.options.columns[e].options.format);
        } else if (n.options.columns && n.options.columns[e] && "dropdown" == n.options.columns[e].type) o.classList.add("jss_dropdown"), o.textContent = getDropDownValue.call(n, e, s); else if (n.options.columns && n.options.columns[e] && "color" == n.options.columns[e].type) if ("square" == n.options.columns[e].render) {
          const e = document.createElement("div");
          e.className = "color", e.style.backgroundColor = s, o.appendChild(e);
        } else o.style.color = s, o.textContent = s; else if (n.options.columns && n.options.columns[e] && "image" == n.options.columns[e].type) {
          if (s && "data:image" == s.substr(0, 10)) {
            const e = document.createElement("img");
            e.src = s, o.appendChild(e);
          }
        } else n.options.columns && n.options.columns[e] && "html" == n.options.columns[e].type || true === n.parent.config.parseHTML ? o.innerHTML = stripScript(parseValue.call(this, e, t, s, o)) : o.textContent = parseValue.call(this, e, t, s, o);
        n.options.columns && n.options.columns[e] && 1 == n.options.columns[e].readOnly && (o.className = "readonly");
        const r = n.options.columns && n.options.columns[e] && n.options.columns[e].align || n.options.defaultColAlign || "center";
        return o.style.textAlign = r, n.options.columns && n.options.columns[e] && 0 == n.options.columns[e].wordWrap || !(1 == n.options.wordWrap || n.options.columns && n.options.columns[e] && 1 == n.options.columns[e].wordWrap || o.innerHTML.length > 200) || (o.style.whiteSpace = "pre-wrap"), e > 0 && 1 == this.options.textOverflow && (s || o.innerHTML ? n.records[t][e - 1].element.style.overflow = "hidden" : e == n.options.columns.length - 1 && (o.style.overflow = "hidden")), _dispatch_js__WEBPACK_IMPORTED_MODULE_3__.A.call(n, "oncreatecell", n, o, e, t, s), o;
      }, updateCell = function (e, t, s, n) {
        const o = this;
        let r;
        if (1 != o.records[t][e].element.classList.contains("readonly") || n) {
          if ("=" == ("" + s).substr(0, 1) && 1 == o.options.secureFormulas) {
            const e = secureFormula(s);
            e != s && (s = e);
          }
          const n = _dispatch_js__WEBPACK_IMPORTED_MODULE_3__.A.call(o, "onbeforechange", o, o.records[t][e].element, e, t, s);
          if (null != n && (s = n), o.options.columns && o.options.columns[e] && "object" == typeof o.options.columns[e].type && "function" == typeof o.options.columns[e].type.updateCell) {
            const n = o.options.columns[e].type.updateCell(o.records[t][e].element, s, parseInt(e), parseInt(t), o, o.options.columns[e]);
            undefined !== n && (s = n);
          }
          r = {x: e, y: t, col: e, row: t, value: s, oldValue: o.options.data[t][e]};
          let l = o.options.columns && o.options.columns[e] && "object" == typeof o.options.columns[e].type ? o.options.columns[e].type : null;
          if (l) o.options.data[t][e] = s, "function" == typeof l.setValue && l.setValue(o.records[t][e].element, s); else if (o.options.columns && o.options.columns[e] && ("checkbox" == o.options.columns[e].type || "radio" == o.options.columns[e].type)) {
            if ("radio" == o.options.columns[e].type) for (let t = 0; t < o.options.data.length; t++) o.options.data[t][e] = false;
            o.records[t][e].element.children[0].checked = 1 == s || 1 == s || "true" == s || "TRUE" == s, o.options.data[t][e] = o.records[t][e].element.children[0].checked;
          } else if (o.options.columns && o.options.columns[e] && "dropdown" == o.options.columns[e].type) o.options.data[t][e] = s, o.records[t][e].element.textContent = getDropDownValue.call(o, e, s); else if (o.options.columns && o.options.columns[e] && "calendar" == o.options.columns[e].type) {
            let n = null;
            if (!("-" == (s = "" + s).substr(4, 1) && "-" == s.substr(7, 1) || 4 == (s = s.split("-"))[0].length && s[0] == Number(s[0]) && 2 == s[1].length && s[1] == Number(s[1]))) {
              const t = jSuites.calendar.extractDateFromString(s, o.options.columns[e].options && o.options.columns[e].options.format || "YYYY-MM-DD");
              t && (n = t);
            }
            o.options.data[t][e] = s, o.records[t][e].element.textContent = jSuites.calendar.getDateString(n || s, o.options.columns[e].options && o.options.columns[e].options.format);
          } else if (o.options.columns && o.options.columns[e] && "color" == o.options.columns[e].type) if (o.options.data[t][e] = s, "square" == o.options.columns[e].render) {
            const n = document.createElement("div");
            n.className = "color", n.style.backgroundColor = s, o.records[t][e].element.textContent = "", o.records[t][e].element.appendChild(n);
          } else o.records[t][e].element.style.color = s, o.records[t][e].element.textContent = s; else if (o.options.columns && o.options.columns[e] && "image" == o.options.columns[e].type) {
            if (s = "" + s, o.options.data[t][e] = s, o.records[t][e].element.innerHTML = "", s && "data:image" == s.substr(0, 10)) {
              const n = document.createElement("img");
              n.src = s, o.records[t][e].element.appendChild(n);
            }
          } else o.options.data[t][e] = s, o.options.columns && o.options.columns[e] && "html" == o.options.columns[e].type ? o.records[t][e].element.innerHTML = stripScript(parseValue.call(o, e, t, s)) : true === o.parent.config.parseHTML ? o.records[t][e].element.innerHTML = stripScript(parseValue.call(o, e, t, s, o.records[t][e].element)) : o.records[t][e].element.textContent = parseValue.call(o, e, t, s, o.records[t][e].element), o.options.columns && o.options.columns[e] && 0 == o.options.columns[e].wordWrap || !(1 == o.options.wordWrap || o.options.columns && o.options.columns[e] && 1 == o.options.columns[e].wordWrap || o.records[t][e].element.innerHTML.length > 200) ? o.records[t][e].element.style.whiteSpace = "" : o.records[t][e].element.style.whiteSpace = "pre-wrap";
          e > 0 && (o.records[t][e - 1].element.style.overflow = s ? "hidden" : ""), o.options.columns && o.options.columns[e] && "function" == typeof o.options.columns[e].render && o.options.columns[e].render(o.records[t] && o.records[t][e] ? o.records[t][e].element : null, s, parseInt(e), parseInt(t), o, o.options.columns[e]), _dispatch_js__WEBPACK_IMPORTED_MODULE_3__.A.call(o, "onchange", o, o.records[t] && o.records[t][e] ? o.records[t][e].element : null, e, t, s, r.oldValue);
        } else r = {x: e, y: t, col: e, row: t};
        return r;
      }, isFormula = function (e) {
        const t = ("" + e)[0];
        return "=" == t || "#" == t;
      }, getMask = function (e) {
        if (e.format || e.mask || e.locale) {
          const t = {};
          return e.mask ? t.mask = e.mask : e.format ? t.mask = e.format : (t.locale = e.locale, t.options = e.options), e.decimal && (t.options || (t.options = {}), t.options = {decimal: e.decimal}), t;
        }
        return null;
      }, secureFormula = function (e) {
        let t = "", s = 0;
        for (let n = 0; n < e.length; n++) '"' == e[n] && (s = 0 == s ? 1 : 0), t += 1 == s ? e[n] : e[n].toUpperCase();
        return t;
      };
      let chainLoopProtection = [];
      const updateFormulaChain = function (e, t, s) {
        const n = this, o = (0, _internalHelpers_js__WEBPACK_IMPORTED_MODULE_2__.t3)([e, t]);
        if (n.formula[o] && n.formula[o].length > 0) if (chainLoopProtection[o]) n.records[t][e].element.innerHTML = "#ERROR", n.formula[o] = ""; else {
          chainLoopProtection[o] = true;
          for (let e = 0; e < n.formula[o].length; e++) {
            const t = (0, _internalHelpers_js__WEBPACK_IMPORTED_MODULE_2__.vu)(n.formula[o][e], true), r = "" + n.options.data[t[1]][t[0]];
            "=" == r.substr(0, 1) ? s.push(updateCell.call(n, t[0], t[1], r, true)) : Object.keys(n.formula)[e] = null, updateFormulaChain.call(n, t[0], t[1], s);
          }
        }
        chainLoopProtection = [];
      }, updateFormula = function (e, t) {
        const s = /[A-Z]/, n = /[0-9]/;
        let o = "", r = null, l = null, i = "";
        for (let a = 0; a < e.length; a++) s.exec(e[a]) ? (r = 1, l = 0, i += e[a]) : n.exec(e[a]) ? (l = r ? 1 : 0, i += e[a]) : (r && l && (i = t[i] ? t[i] : i), o += i, o += e[a], r = 0, l = 0, i = "");
        return i && (r && l && (i = t[i] ? t[i] : i), o += i), o;
      }, updateFormulas = function (e) {
        const t = this;
        for (let s = 0; s < t.options.data.length; s++) for (let n = 0; n < t.options.data[0].length; n++) {
          const o = "" + t.options.data[s][n];
          if ("=" == o.substr(0, 1)) {
            const r = updateFormula(o, e);
            r != o && (t.options.data[s][n] = r);
          }
        }
        const s = [], n = Object.keys(t.formula);
        for (let o = 0; o < n.length; o++) {
          let r = n[o];
          const l = t.formula[r];
          e[r] && (r = e[r]), s[r] = [];
          for (let t = 0; t < l.length; t++) {
            let n = l[t];
            e[n] && (n = e[n]), s[r].push(n);
          }
        }
        t.formula = s;
      }, updateTableReferences = function () {
        const e = this;
        if (e.skipUpdateTableReferences) return;
        for (let t = 0; t < e.headers.length; t++) e.headers[t].getAttribute("data-x") != t && (e.headers[t].setAttribute("data-x", t), e.headers[t].getAttribute("title") || (e.headers[t].innerHTML = (0, _helpers_js__WEBPACK_IMPORTED_MODULE_4__.getColumnName)(t)));
        for (let t = 0; t < e.rows.length; t++) e.rows[t] && e.rows[t].element.getAttribute("data-y") != t && (e.rows[t].element.setAttribute("data-y", t), e.rows[t].element.children[0].setAttribute("data-y", t), e.rows[t].element.children[0].innerHTML = t + 1);
        const t = [], s = [], n = function (s, n, o, r) {
          if (s != o && e.records[r][o].element.setAttribute("data-x", o), n != r && e.records[r][o].element.setAttribute("data-y", r), s != o || n != r) {
            const e = (0, _internalHelpers_js__WEBPACK_IMPORTED_MODULE_2__.t3)([s, n]), l = (0, _internalHelpers_js__WEBPACK_IMPORTED_MODULE_2__.t3)([o, r]);
            t[e] = l;
          }
        };
        for (let t = 0; t < e.records.length; t++) for (let o = 0; o < e.records[0].length; o++) if (e.records[t][o]) {
          const r = e.records[t][o].element.getAttribute("data-x"), l = e.records[t][o].element.getAttribute("data-y");
          if (e.records[t][o].element.getAttribute("data-merged")) {
            const e = (0, _internalHelpers_js__WEBPACK_IMPORTED_MODULE_2__.t3)([r, l]), n = (0, _internalHelpers_js__WEBPACK_IMPORTED_MODULE_2__.t3)([o, t]);
            if (null == s[e]) if (e == n) s[e] = false; else {
              const i = parseInt(o - r), a = parseInt(t - l);
              s[e] = [n, i, a];
            }
          } else n(r, l, o, t);
        }
        const o = Object.keys(s);
        if (o.length) for (let t = 0; t < o.length; t++) if (s[o[t]]) {
          const r = (0, _internalHelpers_js__WEBPACK_IMPORTED_MODULE_2__.vu)(o[t], true);
          let l = r[0], i = r[1];
          n(l, i, l + s[o[t]][1], i + s[o[t]][2]);
          const a = o[t], c = s[o[t]][0];
          for (let n = 0; n < e.options.mergeCells[a][2].length; n++) l = parseInt(e.options.mergeCells[a][2][n].getAttribute("data-x")), i = parseInt(e.options.mergeCells[a][2][n].getAttribute("data-y")), e.options.mergeCells[a][2][n].setAttribute("data-x", l + s[o[t]][1]), e.options.mergeCells[a][2][n].setAttribute("data-y", i + s[o[t]][2]);
          e.options.mergeCells[c] = e.options.mergeCells[a], delete e.options.mergeCells[a];
        }
        updateFormulas.call(e, t), _meta_js__WEBPACK_IMPORTED_MODULE_5__.hs.call(e, t), _selection_js__WEBPACK_IMPORTED_MODULE_1__.G9.call(e), updateTable.call(e);
      }, updateScroll = function (e) {
        const t = this, s = t.content.getBoundingClientRect(), n = s.left, o = s.top, r = s.width, l = s.height, i = t.records[t.selectedCell[3]][t.selectedCell[2]].element.getBoundingClientRect(), a = i.left, c = i.top, d = i.width, u = i.height;
        let p, h;
        0 == e || 1 == e ? (p = a - n + t.content.scrollLeft, h = c - o + t.content.scrollTop - 2) : (p = a - n + t.content.scrollLeft + d, h = c - o + t.content.scrollTop + u), h > t.content.scrollTop + 30 && h < t.content.scrollTop + l || (h < t.content.scrollTop + 30 ? t.content.scrollTop = h - u : t.content.scrollTop = h - (l - 2));
        const m = _freeze_js__WEBPACK_IMPORTED_MODULE_6__.w.call(t);
        p > t.content.scrollLeft + m && p < t.content.scrollLeft + r || (p < t.content.scrollLeft + 30 ? (t.content.scrollLeft = p, t.content.scrollLeft < 50 && (t.content.scrollLeft = 0)) : p < t.content.scrollLeft + m ? t.content.scrollLeft = p - m - 1 : t.content.scrollLeft = p - (r - 20));
      }, updateResult = function () {
        const e = this;
        let t = 0, s = 0;
        for (t = 1 == e.options.lazyLoading ? 100 : e.options.pagination > 0 ? e.options.pagination : e.results ? e.results.length : e.rows.length; e.tbody.firstChild;) e.tbody.removeChild(e.tbody.firstChild);
        for (let n = 0; n < e.rows.length; n++) !e.results || e.results.indexOf(n) > -1 ? (s < t && (e.tbody.appendChild(e.rows[n].element), s++), e.rows[n].element.style.display = "") : e.rows[n].element.style.display = "none";
        return e.options.pagination > 0 && _pagination_js__WEBPACK_IMPORTED_MODULE_7__.IV.call(e), _selection_js__WEBPACK_IMPORTED_MODULE_1__.Aq.call(e), t;
      }, getCell = function (e, t) {
        if ("string" == typeof e) {
          const s = (0, _internalHelpers_js__WEBPACK_IMPORTED_MODULE_2__.vu)(e, true);
          e = s[0], t = s[1];
        }
        return this.records[t][e].element;
      }, getCellFromCoords = function (e, t) {
        return this.records[t][e].element;
      }, getLabel = function (e, t) {
        if ("string" == typeof e) {
          const s = (0, _internalHelpers_js__WEBPACK_IMPORTED_MODULE_2__.vu)(e, true);
          e = s[0], t = s[1];
        }
        return this.records[t][e].element.innerHTML;
      }, fullscreen = function (e) {
        const t = this;
        null == e && (e = !t.config.fullscreen), t.config.fullscreen != e && (t.config.fullscreen = e, 1 == e ? t.element.classList.add("fullscreen") : t.element.classList.remove("fullscreen"));
      }, showIndex = function () {
        this.table.classList.remove("jss_hidden_index");
      }, hideIndex = function () {
        this.table.classList.add("jss_hidden_index");
      }, createNestedHeader = function (e) {
        const t = this, s = document.createElement("tr");
        s.classList.add("jss_nested");
        const n = document.createElement("td");
        n.classList.add("jss_selectall"), s.appendChild(n), e.element = s;
        let o = 0;
        for (let n = 0; n < e.length; n++) {
          e[n].colspan || (e[n].colspan = 1), e[n].title || (e[n].title = ""), e[n].id || (e[n].id = "");
          let r = e[n].colspan;
          const l = [];
          for (let e = 0; e < r; e++) t.options.columns[o] && "hidden" == t.options.columns[o].type && r++, l.push(o), o++;
          const i = document.createElement("td");
          i.setAttribute("data-column", l.join(",")), i.setAttribute("colspan", e[n].colspan), i.setAttribute("align", e[n].align || "center"), i.setAttribute("id", e[n].id), i.textContent = e[n].title, s.appendChild(i);
        }
        return s;
      }, getWorksheetActive = function () {
        const e = this.parent ? this.parent : this;
        return e.element.tabs ? e.element.tabs.getActive() : 0;
      }, getWorksheetInstance = function (e) {
        const t = undefined !== e ? e : getWorksheetActive.call(this);
        return this.worksheets[t];
      };
    }, 689: function (e, t, s) {
      s.d(t, {Hh: function () {
        return o;
      }, t3: function () {
        return l;
      }, vu: function () {
        return r;
      }});
      var n = s(978);
      const o = function (e, t, s) {
        if (t <= e.length) return e.slice(0, t).concat(s).concat(e.slice(t));
        const n = e.slice(0, e.length);
        for (; t > n.length;) n.push(undefined);
        return n.concat(s);
      }, r = function (e, t) {
        const s = /^[a-zA-Z]+/.exec(e);
        if (s) {
          let n = 0;
          for (let e = 0; e < s[0].length; e++) n += parseInt(s[0].charCodeAt(e) - 64) * Math.pow(26, s[0].length - 1 - e);
          n--, n < 0 && (n = 0);
          let o = parseInt(/[0-9]+$/.exec(e));
          o > 0 && o--, e = 1 == t ? [n, o] : n + "-" + o;
        }
        return e;
      };
    }, 497: function (e, t, s) {
      s.d(t, {AG: function () {
        return o;
      }, G_: function () {
        return r;
      }, p6: function () {
        return l;
      }, wu: function () {
        return n;
      }});
      const n = function (e) {
        const t = this;
        let s;
        s = 1 != t.options.search && 1 != t.options.filters || !t.results ? t.rows : t.results;
        const n = 100;
        null != e && -1 != e || (e = Math.ceil(s.length / n) - 1);
        let o = e * n, r = e * n + n;
        r > s.length && (r = s.length), o = r - 100, o < 0 && (o = 0);
        for (let e = o; e < r; e++) 1 != t.options.search && 1 != t.options.filters || !t.results ? t.tbody.appendChild(t.rows[e].element) : t.tbody.appendChild(t.rows[s[e]].element), t.tbody.children.length > n && t.tbody.removeChild(t.tbody.firstChild);
      }, o = function () {
        const e = this;
        if (e.selectedCell) {
          const t = parseInt(e.tbody.firstChild.getAttribute("data-y")) / 100, s = parseInt(e.selectedCell[3] / 100), n = parseInt(e.rows.length / 100);
          if (t != s && s <= n && !Array.prototype.indexOf.call(e.tbody.children, e.rows[e.selectedCell[3]].element)) return e.loadPage(s), true;
        }
        return false;
      }, r = function () {
        const e = this;
        let t;
        t = 1 != e.options.search && 1 != e.options.filters || !e.results ? e.rows : e.results;
        let s = 0;
        if (t.length > 100) {
          let n = parseInt(e.tbody.firstChild.getAttribute("data-y"));
          if (1 != e.options.search && 1 != e.options.filters || !e.results || (n = t.indexOf(n)), n > 0) for (let o = 0; o < 30; o++) n -= 1, n > -1 && (1 != e.options.search && 1 != e.options.filters || !e.results ? e.tbody.insertBefore(e.rows[n].element, e.tbody.firstChild) : e.tbody.insertBefore(e.rows[t[n]].element, e.tbody.firstChild), e.tbody.children.length > 100 && (e.tbody.removeChild(e.tbody.lastChild), s = 1));
        }
        return s;
      }, l = function () {
        const e = this;
        let t;
        t = 1 != e.options.search && 1 != e.options.filters || !e.results ? e.rows : e.results;
        let s = 0;
        if (t.length > 100) {
          let n = parseInt(e.tbody.lastChild.getAttribute("data-y"));
          if (1 != e.options.search && 1 != e.options.filters || !e.results || (n = t.indexOf(n)), n < e.rows.length - 1) for (let o = 0; o <= 30; o++) n < t.length && (1 != e.options.search && 1 != e.options.filters || !e.results ? e.tbody.appendChild(e.rows[n].element) : e.tbody.appendChild(e.rows[t[n]].element), e.tbody.children.length > 100 && (e.tbody.removeChild(e.tbody.firstChild), s = 1)), n += 1;
        }
        return s;
      };
    }, 910: function (e, t, s) {
      s.d(t, {D0: function () {
        return c;
      }, FU: function () {
        return u;
      }, Lt: function () {
        return a;
      }, VP: function () {
        return h;
      }, Zp: function () {
        return p;
      }, fd: function () {
        return d;
      }});
      var n = s(689), o = s(530), r = s(911), l = s(805), i = s(657);
      const a = function (e, t) {
        const s = this, o = [];
        if (s.options.mergeCells) {
          const r = Object.keys(s.options.mergeCells);
          for (let l = 0; l < r.length; l++) {
            const i = (0, n.vu)(r[l], true), a = s.options.mergeCells[r[l]][0], c = i[0], d = i[0] + (a > 1 ? a - 1 : 0);
            null == t ? c <= e && d >= e && o.push(r[l]) : t ? c < e && d >= e && o.push(r[l]) : c <= e && d > e && o.push(r[l]);
          }
        }
        return o;
      }, c = function (e, t) {
        const s = this, o = [];
        if (s.options.mergeCells) {
          const r = Object.keys(s.options.mergeCells);
          for (let l = 0; l < r.length; l++) {
            const i = (0, n.vu)(r[l], true), a = s.options.mergeCells[r[l]][1], c = i[1], d = i[1] + (a > 1 ? a - 1 : 0);
            null == t ? c <= e && d >= e && o.push(r[l]) : t ? c < e && d >= e && o.push(r[l]) : c <= e && d > e && o.push(r[l]);
          }
        }
        return o;
      }, d = function (e) {
        const t = this;
        let s = {};
        if (e) s = t.options.mergeCells && t.options.mergeCells[e] ? [t.options.mergeCells[e][0], t.options.mergeCells[e][1]] : null; else if (t.options.mergeCells) {
          t.options.mergeCells;
          const e = Object.keys(t.options.mergeCells);
          for (let n = 0; n < e.length; n++) s[e[n]] = [t.options.mergeCells[e[n]][0], t.options.mergeCells[e[n]][1]];
        }
        return s;
      }, u = function (e, t, s, a) {
        const c = this;
        let d = false;
        if (e) {
          if ("string" != typeof e) return null;
        } else {
          if (!c.highlighted.length) return alert(jSuites.translate("No cells selected")), null;
          {
            const o = parseInt(c.highlighted[0].getAttribute("data-x")), r = parseInt(c.highlighted[0].getAttribute("data-y")), l = parseInt(c.highlighted[c.highlighted.length - 1].getAttribute("data-x")), i = parseInt(c.highlighted[c.highlighted.length - 1].getAttribute("data-y"));
            e = (0, n.t3)([o, r]), t = l - o + 1, s = i - r + 1;
          }
        }
        const u = (0, n.vu)(e, true);
        if (c.options.mergeCells && c.options.mergeCells[e]) c.records[u[1]][u[0]].element.getAttribute("data-merged") && (d = "Cell already merged"); else if ((!t || t < 2) && (!s || s < 2)) d = "Invalid merged properties"; else for (let e = u[1]; e < u[1] + s; e++) for (let s = u[0]; s < u[0] + t; s++) (0, n.t3)([s, e]), c.records[e][s].element.getAttribute("data-merged") && (d = "There is a conflict with another merged cell");
        if (d) alert(jSuites.translate(d)); else {
          t > 1 ? c.records[u[1]][u[0]].element.setAttribute("colspan", t) : t = 1, s > 1 ? c.records[u[1]][u[0]].element.setAttribute("rowspan", s) : s = 1, c.options.mergeCells || (c.options.mergeCells = {}), c.options.mergeCells[e] = [t, s, []], c.records[u[1]][u[0]].element.setAttribute("data-merged", "true"), c.records[u[1]][u[0]].element.style.overflow = "hidden";
          const n = [];
          for (let r = u[1]; r < u[1] + s; r++) for (let s = u[0]; s < u[0] + t; s++) u[0] == s && u[1] == r || (n.push(c.options.data[r][s]), o.k9.call(c, s, r, "", true), c.options.mergeCells[e][2].push(c.records[r][s].element), c.records[r][s].element.style.display = "none", c.records[r][s].element = c.records[u[1]][u[0]].element);
          i.c6.call(c, c.records[u[1]][u[0]].element), a || (r.Dh.call(c, {action: "setMerge", column: e, colspan: t, rowspan: s, data: n}), l.A.call(c, "onmerge", c, {[e]: [t, s]}));
        }
      }, p = function (e, t, s) {
        const r = this;
        if (r.options.mergeCells && r.options.mergeCells[e]) {
          const l = (0, n.vu)(e, true);
          r.records[l[1]][l[0]].element.removeAttribute("colspan"), r.records[l[1]][l[0]].element.removeAttribute("rowspan"), r.records[l[1]][l[0]].element.removeAttribute("data-merged");
          const a = r.options.mergeCells[e];
          let c, d, u = 0;
          for (c = 0; c < a[1]; c++) for (d = 0; d < a[0]; d++) (c > 0 || d > 0) && (r.records[l[1] + c][l[0] + d].element = a[2][u], r.records[l[1] + c][l[0] + d].element.style.display = "", t && t[u] && o.k9.call(r, l[0] + d, l[1] + c, t[u]), u++);
          i.c6.call(r, r.records[l[1]][l[0]].element, r.records[l[1] + c - 1][l[0] + d - 1].element), s || delete r.options.mergeCells[e];
        }
      }, h = function (e) {
        const t = this;
        if (t.options.mergeCells) {
          t.options.mergeCells;
          const s = Object.keys(t.options.mergeCells);
          for (let n = 0; n < s.length; n++) p.call(t, s[n], null, e);
        }
      };
    }, 654: function (e, t, s) {
      s.d(t, {IQ: function () {
        return o;
      }, hs: function () {
        return r;
      }, iZ: function () {
        return l;
      }});
      var n = s(805);
      const o = function (e, t) {
        const s = this;
        return e ? t ? s.options.meta && s.options.meta[e] && s.options.meta[e][t] ? s.options.meta[e][t] : null : s.options.meta && s.options.meta[e] ? s.options.meta[e] : null : s.options.meta;
      }, r = function (e) {
        const t = this;
        if (t.options.meta) {
          const s = {}, n = Object.keys(t.options.meta);
          for (let o = 0; o < n.length; o++) e[n[o]] ? s[e[n[o]]] = t.options.meta[n[o]] : s[n[o]] = t.options.meta[n[o]];
          t.options.meta = s;
        }
      }, l = function (e, t, s) {
        const o = this;
        if (o.options.meta || (o.options.meta = {}), t && s) o.options.meta[e] || (o.options.meta[e] = {}), o.options.meta[e][t] = s, n.A.call(o, "onchangemeta", o, {[e]: {[t]: s}}); else {
          const t = Object.keys(e);
          for (let s = 0; s < t.length; s++) {
            o.options.meta[t[s]] || (o.options.meta[t[s]] = {});
            const n = Object.keys(e[t[s]]);
            for (let r = 0; r < n.length; r++) o.options.meta[t[s]][n[r]] = e[t[s]][n[r]];
          }
          n.A.call(o, "onchangemeta", o, e);
        }
      };
    }, 94: function (e, t, s) {
      s.d(t, {My: function () {
        return d;
      }, Th: function () {
        return a;
      }, iY: function () {
        return c;
      }});
      var n = s(911), o = s(805), r = s(530), l = s(497), i = s(829);
      const a = function (e, t) {
        const s = this;
        for (let e = 0; e < s.headers.length; e++) s.headers[e].classList.remove("arrow-up"), s.headers[e].classList.remove("arrow-down");
        t ? s.headers[e].classList.add("arrow-up") : s.headers[e].classList.add("arrow-down");
      }, c = function (e) {
        const t = this;
        let s = [];
        for (let n = 0; n < e.length; n++) s[n] = t.options.data[e[n]];
        t.options.data = s, s = [];
        for (let n = 0; n < e.length; n++) {
          s[n] = t.records[e[n]];
          for (let e = 0; e < s[n].length; e++) s[n][e].y = n;
        }
        t.records = s, s = [];
        for (let n = 0; n < e.length; n++) s[n] = t.rows[e[n]], s[n].y = n;
        if (t.rows = s, r.o8.call(t), t.results && t.results.length) t.searchInput.value ? t.search(t.searchInput.value) : i.F8.call(t); else if (t.results = null, t.pageNumber = 0, t.options.pagination > 0) t.page(0); else if (1 == t.options.lazyLoading) l.wu.call(t, 0); else for (let e = 0; e < t.rows.length; e++) t.tbody.appendChild(t.rows[e].element);
      }, d = function (e, t) {
        const s = this;
        if (e >= 0) {
          if (s.options.mergeCells && Object.keys(s.options.mergeCells).length > 0) {
            if (!confirm(jSuites.translate("This action will destroy any existing merged cells. Are you sure?"))) return false;
            s.destroyMerge();
          }
          t = null == t ? s.headers[e].classList.contains("arrow-down") ? 1 : 0 : t ? 1 : 0;
          let r = [];
          if (s.options.columns && s.options.columns[e] && ("number" == s.options.columns[e].type || "numeric" == s.options.columns[e].type || "percentage" == s.options.columns[e].type || "autonumber" == s.options.columns[e].type || "color" == s.options.columns[e].type)) for (let t = 0; t < s.options.data.length; t++) r[t] = [t, Number(s.options.data[t][e])]; else if (s.options.columns && s.options.columns[e] && ("calendar" == s.options.columns[e].type || "checkbox" == s.options.columns[e].type || "radio" == s.options.columns[e].type)) for (let t = 0; t < s.options.data.length; t++) r[t] = [t, s.options.data[t][e]]; else for (let t = 0; t < s.options.data.length; t++) r[t] = [t, s.records[t][e].element.textContent.toLowerCase()];
          "function" != typeof s.parent.config.sorting && (s.parent.config.sorting = function (e) {
            return function (t, s) {
              const n = t[1], o = s[1];
              return e ? "" === n && "" !== o ? 1 : "" !== n && "" === o || n > o ? -1 : n < o ? 1 : 0 : "" === n && "" !== o ? 1 : "" !== n && "" === o ? -1 : n > o ? 1 : n < o ? -1 : 0;
            };
          }), r = r.sort(s.parent.config.sorting(t));
          const l = [];
          for (let e = 0; e < r.length; e++) l[e] = r[e][0];
          return n.Dh.call(s, {action: "orderBy", rows: l, column: e, order: t}), a.call(s, e, t), c.call(s, l), o.A.call(s, "onsort", s, e, t, l.map(e => e)), true;
        }
      };
    }, 167: function (e, t, s) {
      s.d(t, {$f: function () {
        return a;
      }, IV: function () {
        return l;
      }, MY: function () {
        return i;
      }, ho: function () {
        return r;
      }});
      var n = s(805), o = s(657);
      const r = function (e) {
        const t = this;
        return 1 != t.options.search && 1 != t.options.filters || !t.results || (e = t.results.indexOf(e)), Math.ceil((parseInt(e) + 1) / parseInt(t.options.pagination)) - 1;
      }, l = function () {
        const e = this;
        if (e.pagination.children[0].innerHTML = "", e.pagination.children[1].innerHTML = "", e.options.pagination) {
          let t;
          if (t = 1 != e.options.search && 1 != e.options.filters || !e.results ? e.rows.length : e.results.length, t) {
            const s = Math.ceil(t / e.options.pagination);
            let n, o;
            if (e.pageNumber < 6 ? (n = 1, o = s < 10 ? s : 10) : s - e.pageNumber < 5 ? (n = s - 9, o = s, n < 1 && (n = 1)) : (n = e.pageNumber - 4, o = e.pageNumber + 5), n > 1) {
              const t = document.createElement("div");
              t.className = "jss_page", t.innerHTML = "<", t.title = 1, e.pagination.children[1].appendChild(t);
            }
            for (let t = n; t <= o; t++) {
              const s = document.createElement("div");
              s.className = "jss_page", s.innerHTML = t, e.pagination.children[1].appendChild(s), e.pageNumber == t - 1 && s.classList.add("jss_page_selected");
            }
            if (o < s) {
              const t = document.createElement("div");
              t.className = "jss_page", t.innerHTML = ">", t.title = s, e.pagination.children[1].appendChild(t);
            }
            const r = function (e) {
              const t = Array.prototype.slice.call(arguments, 1);
              return e.replace(/{(\d+)}/g, function (e, s) {
                return undefined !== t[s] ? t[s] : e;
              });
            };
            e.pagination.children[0].innerHTML = r(jSuites.translate("Showing page {0} of {1} entries"), e.pageNumber + 1, s);
          } else e.pagination.children[0].innerHTML = jSuites.translate("No records found");
        }
      }, i = function (e) {
        const t = this, s = t.pageNumber;
        let r;
        r = 1 != t.options.search && 1 != t.options.filters || !t.results ? t.rows : t.results;
        const i = parseInt(t.options.pagination);
        null != e && -1 != e || (e = Math.ceil(r.length / i) - 1), t.pageNumber = e;
        let a = e * i, c = e * i + i;
        for (c > r.length && (c = r.length), a < 0 && (a = 0); t.tbody.firstChild;) t.tbody.removeChild(t.tbody.firstChild);
        for (let e = a; e < c; e++) 1 != t.options.search && 1 != t.options.filters || !t.results ? t.tbody.appendChild(t.rows[e].element) : t.tbody.appendChild(t.rows[r[e]].element);
        t.options.pagination > 0 && l.call(t), o.Aq.call(t), n.A.call(t, "onchangepage", t, e, s, t.options.pagination);
      }, a = function () {
        const e = this;
        let t;
        return t = 1 != e.options.search && 1 != e.options.filters || !e.results ? e.rows.length : e.results.length, Math.ceil(t / e.options.pagination);
      };
    }, 657: function (e, t, s) {
      s.d(t, {AH: function () {
        return m;
      }, Aq: function () {
        return d;
      }, G9: function () {
        return g;
      }, Jg: function () {
        return f;
      }, Lo: function () {
        return v;
      }, R5: function () {
        return _;
      }, Ub: function () {
        return B;
      }, at: function () {
        return w;
      }, c6: function () {
        return p;
      }, eO: function () {
        return x;
      }, ef: function () {
        return A;
      }, gE: function () {
        return u;
      }, gG: function () {
        return y;
      }, kA: function () {
        return h;
      }, kF: function () {
        return C;
      }, kV: function () {
        return k;
      }, sp: function () {
        return E;
      }, tW: function () {
        return j;
      }});
      var n = s(805), o = s(296), r = s(978), l = s(911), i = s(530), a = s(689), c = s(392);
      const d = function () {
        const e = this;
        if (e.highlighted && e.highlighted.length) {
          const t = e.highlighted[e.highlighted.length - 1].element, s = t.getAttribute("data-x"), n = e.content.getBoundingClientRect(), r = n.left, l = n.top, i = t.getBoundingClientRect(), a = i.left, c = i.top, d = i.width, u = i.height, p = a - r + e.content.scrollLeft + d - 4, h = c - l + e.content.scrollTop + u - 4;
          if (e.corner.style.top = h + "px", e.corner.style.left = p + "px", e.options.freezeColumns) {
            const t = o.w.call(e);
            s > e.options.freezeColumns - 1 && a - r + d < t ? e.corner.style.display = "none" : 0 != e.options.selectionCopy && (e.corner.style.display = "");
          } else 0 != e.options.selectionCopy && (e.corner.style.display = "");
        } else e.corner.style.top = "-2000px", e.corner.style.left = "-2000px";
        (0, c.nK)(e);
      }, u = function (e) {
        const t = this;
        let s;
        if (t.highlighted && t.highlighted.length) {
          s = 1;
          for (let e = 0; e < t.highlighted.length; e++) {
            t.highlighted[e].element.classList.remove("highlight"), t.highlighted[e].element.classList.remove("highlight-left"), t.highlighted[e].element.classList.remove("highlight-right"), t.highlighted[e].element.classList.remove("highlight-top"), t.highlighted[e].element.classList.remove("highlight-bottom"), t.highlighted[e].element.classList.remove("highlight-selected");
            const s = parseInt(t.highlighted[e].element.getAttribute("data-x")), n = parseInt(t.highlighted[e].element.getAttribute("data-y"));
            let o, r;
            if (t.highlighted[e].element.getAttribute("data-merged")) {
              const l = parseInt(t.highlighted[e].element.getAttribute("colspan")), i = parseInt(t.highlighted[e].element.getAttribute("rowspan"));
              o = l > 0 ? s + (l - 1) : s, r = i > 0 ? n + (i - 1) : n;
            } else o = s, r = n;
            for (let e = s; e <= o; e++) t.headers[e] && t.headers[e].classList.remove("selected");
            for (let e = n; e <= r; e++) t.rows[e] && t.rows[e].element.classList.remove("selected");
          }
        } else s = 0;
        return t.highlighted = [], t.selectedCell = null, t.corner.style.top = "-2000px", t.corner.style.left = "-2000px", 1 == e && 1 == s && n.A.call(t, "onblur", t), s;
      }, p = function (e, t, s) {
        const n = e.getAttribute("data-x"), o = e.getAttribute("data-y");
        let r, l;
        t ? (r = t.getAttribute("data-x"), l = t.getAttribute("data-y")) : (r = n, l = o), m.call(this, n, o, r, l, s);
      }, h = function () {
        const e = document.querySelectorAll(".jss_worksheet .copying");
        for (let t = 0; t < e.length; t++) e[t].classList.remove("copying"), e[t].classList.remove("copying-left"), e[t].classList.remove("copying-right"), e[t].classList.remove("copying-top"), e[t].classList.remove("copying-bottom");
      }, m = function (e, t, s, o, r) {
        const l = this;
        if (null == t) {
          if (t = 0, o = l.rows.length - 1, null == e) return;
        } else null == e && (e = 0, s = l.options.data[0].length - 1);
        null == s && (s = e), null == o && (o = t), e >= l.headers.length && (e = l.headers.length - 1), t >= l.rows.length && (t = l.rows.length - 1), s >= l.headers.length && (s = l.headers.length - 1), o >= l.rows.length && (o = l.rows.length - 1);
        let i, a, c, u, p = null, m = null, f = null, g = null;
        parseInt(e) < parseInt(s) ? (i = parseInt(e), a = parseInt(s)) : (i = parseInt(s), a = parseInt(e)), parseInt(t) < parseInt(o) ? (c = parseInt(t), u = parseInt(o)) : (c = parseInt(o), u = parseInt(t));
        for (let e = i; e <= a; e++) for (let t = c; t <= u; t++) if (l.records[t][e] && l.records[t][e].element.getAttribute("data-merged")) {
          const s = parseInt(l.records[t][e].element.getAttribute("data-x")), n = parseInt(l.records[t][e].element.getAttribute("data-y")), o = parseInt(l.records[t][e].element.getAttribute("colspan")), r = parseInt(l.records[t][e].element.getAttribute("rowspan"));
          o > 1 && (s < i && (i = s), s + o > a && (a = s + o - 1)), r && (n < c && (c = n), n + r > u && (u = n + r - 1));
        }
        for (let e = c; e <= u; e++) "none" != l.rows[e].element.style.display && (null == f && (f = e), g = e);
        for (let e = i; e <= a; e++) for (let t = c; t <= u; t++) l.options.columns && l.options.columns[e] && "hidden" == l.options.columns[e].type || (null == p && (p = e), m = e);
        if (p || (p = 0), m || (m = 0), false === n.A.call(l, "onbeforeselection", l, p, f, m, g, r)) return false;
        const y = l.resetSelection();
        l.selectedCell = [e, t, s, o], l.records[t][e] && l.records[t][e].element.classList.add("highlight-selected");
        for (let e = i; e <= a; e++) for (let t = c; t <= u; t++) "none" != l.rows[t].element.style.display && "none" != l.records[t][e].element.style.display && (l.records[t][e].element.classList.add("highlight"), l.highlighted.push(l.records[t][e]));
        for (let e = p; e <= m; e++) l.options.columns && l.options.columns[e] && "hidden" == l.options.columns[e].type || !l.cols[e].colElement.style || "none" == l.cols[e].colElement.style.display || (l.records[f] && l.records[f][e] && l.records[f][e].element.classList.add("highlight-top"), l.records[g] && l.records[g][e] && l.records[g][e].element.classList.add("highlight-bottom"), l.headers[e].classList.add("selected"));
        for (let e = f; e <= g; e++) l.rows[e] && "none" != l.rows[e].element.style.display && (l.records[e][p].element.classList.add("highlight-left"), l.records[e][m].element.classList.add("highlight-right"), l.rows[e].element.classList.add("selected"));
        l.selectedContainer = [p, f, m, g], 0 == y && (n.A.call(l, "onfocus", l), h()), n.A.call(l, "onselection", l, p, f, m, g, r), d.call(l);
      }, f = function (e) {
        const t = this;
        if (!t.selectedCell) return [];
        const s = [];
        for (let n = Math.min(t.selectedCell[0], t.selectedCell[2]); n <= Math.max(t.selectedCell[0], t.selectedCell[2]); n++) e && "none" == t.headers[n].style.display || s.push(n);
        return s;
      }, g = function () {
        const e = this;
        e.selectedCell && e.updateSelectionFromCoords(e.selectedCell[0], e.selectedCell[1], e.selectedCell[2], e.selectedCell[3]);
      }, y = function () {
        const e = this;
        for (let t = 0; t < e.selection.length; t++) e.selection[t].classList.remove("selection"), e.selection[t].classList.remove("selection-left"), e.selection[t].classList.remove("selection-right"), e.selection[t].classList.remove("selection-top"), e.selection[t].classList.remove("selection-bottom");
        e.selection = [];
      }, C = function (e, t) {
        const s = this, o = s.getData(true, false), r = s.selectedContainer, c = parseInt(e.getAttribute("data-x")), d = parseInt(e.getAttribute("data-y")), u = parseInt(t.getAttribute("data-x")), p = parseInt(t.getAttribute("data-y")), h = [];
        let m, f, g = false;
        r[0] == c ? (m = d < r[1] ? d - r[1] : 1, f = 0) : (f = c < r[0] ? c - r[0] : 1, m = 0);
        let y = 0, C = 0;
        for (let e = d; e <= p; e++) if (!s.rows[e] || "none" != s.rows[e].element.style.display) {
          null == o[C] && (C = 0), y = 0, r[0] != c && (f = c < r[0] ? c - r[0] : 1);
          for (let t = c; t <= u; t++) {
            if (s.records[e][t] && !s.records[e][t].element.classList.contains("readonly") && "none" != s.records[e][t].element.style.display && 0 == g) {
              if (!s.selection.length && "" != s.options.data[e][t]) {
                g = true;
                continue;
              }
              (null == o[C] || null == o[C][y]) && (y = 0);
              let n = o[C][y];
              if (n && !o[1] && 0 != s.parent.config.autoIncrement) if (!s.options.columns || !s.options.columns[t] || s.options.columns[t].type && "text" != s.options.columns[t].type && "number" != s.options.columns[t].type) {
                if (s.options.columns && s.options.columns[t] && "calendar" == s.options.columns[t].type) {
                  const e = new Date(n);
                  e.setDate(e.getDate() + m), n = e.getFullYear() + "-" + (1 == (parseInt(e.getMonth() + 1) = "" + parseInt(e.getMonth() + 1)).length && (parseInt(e.getMonth() + 1) = "0" + parseInt(e.getMonth() + 1)), parseInt(e.getMonth() + 1)) + "-" + (1 == (e.getDate() = "" + e.getDate()).length && (e.getDate() = "0" + e.getDate()), e.getDate()) + " 00:00:00";
                }
              } else if ("=" == ("" + n).substr(0, 1)) {
                const e = n.match(/([A-Z]+[0-9]+)/g);
                if (e) {
                  const t = [];
                  for (let s = 0; s < e.length; s++) {
                    const n = (0, a.vu)(e[s], 1);
                    n[0] += f, n[1] += m, n[1] < 0 && (n[1] = 0);
                    const o = (0, a.t3)([n[0], n[1]]);
                    o != e[s] && (t[e[s]] = o);
                  }
                  t && (n = (0, i.yB)(n, t));
                }
              } else n == Number(n) && (n = Number(n) + m);
              h.push(i.k9.call(s, t, e, n)), i.xF.call(s, t, e, h);
            }
            y++, r[0] != c && f++;
          }
          C++, m++;
        }
        l.Dh.call(s, {action: "setValue", records: h, selection: s.selectedCell}), i.am.call(s);
        const j = h.map(function (e) {
          return {x: e.x, y: e.y, value: e.value, oldValue: e.oldValue};
        });
        n.A.call(s, "onafterchanges", s, j);
      }, j = function (e) {
        let t, s, n = 0;
        if (!e || 0 === e.length) return n;
        for (t = 0; t < e.length; t++) s = e.charCodeAt(t), n = (n << 5) - n + s, n |= 0;
        return n;
      }, w = function (e, t, s) {
        const n = this;
        if (1 == e) {
          if (n.selectedCell && (t >= n.selectedCell[1] && t <= n.selectedCell[3] || s >= n.selectedCell[1] && s <= n.selectedCell[3])) return void n.resetSelection();
        } else if (n.selectedCell && (t >= n.selectedCell[0] && t <= n.selectedCell[2] || s >= n.selectedCell[0] && s <= n.selectedCell[2])) return void n.resetSelection();
      }, _ = function (e) {
        const t = this;
        if (!t.selectedCell) return [];
        const s = [];
        for (let n = Math.min(t.selectedCell[1], t.selectedCell[3]); n <= Math.max(t.selectedCell[1], t.selectedCell[3]); n++) e && "none" == t.rows[n].element.style.display || s.push(n);
        return s;
      }, B = function () {
        const e = this;
        e.selectedCell || (e.selectedCell = []), e.selectedCell[0] = 0, e.selectedCell[1] = 0, e.selectedCell[2] = e.headers.length - 1, e.selectedCell[3] = e.records.length - 1, e.updateSelectionFromCoords(e.selectedCell[0], e.selectedCell[1], e.selectedCell[2], e.selectedCell[3]);
      }, v = function () {
        const e = this;
        return e.selectedCell ? [Math.min(e.selectedCell[0], e.selectedCell[2]), Math.min(e.selectedCell[1], e.selectedCell[3]), Math.max(e.selectedCell[0], e.selectedCell[2]), Math.max(e.selectedCell[1], e.selectedCell[3])] : null;
      }, A = function (e) {
        const t = this, s = v.call(t);
        if (!s) return [];
        const n = [];
        for (let o = s[1]; o <= s[3]; o++) for (let l = s[0]; l <= s[2]; l++) e ? n.push((0, r.getCellNameFromCoords)(l, o)) : n.push(t.records[o][l]);
        return n;
      }, x = function () {
        const e = this, t = v.call(e);
        if (!t) return "";
        const s = (0, r.getCellNameFromCoords)(t[0], t[1]), n = (0, r.getCellNameFromCoords)(t[2], t[3]);
        return s === n ? e.options.worksheetName + "!" + s : e.options.worksheetName + "!" + s + ":" + n;
      }, E = function (e, t) {
        const s = v.call(this);
        return e >= s[0] && e <= s[2] && t >= s[1] && t <= s[3];
      }, k = function () {
        const e = v.call(this);
        return e ? [e] : [];
      };
    }, 392: function (e, t, s) {
      s.d(t, {Ar: function () {
        return u;
      }, ll: function () {
        return d;
      }, nK: function () {
        return c;
      }});
      var n = s(978), o = s(530);
      const r = function (e, t) {
        0 != t.options.editable ? e.classList.remove("jtoolbar-disabled") : e.classList.add("jtoolbar-disabled");
      }, l = function () {
        const e = [], t = this;
        e.push({content: "undo", onclick: function () {
          o.eN.call(t).undo();
        }}), e.push({content: "redo", onclick: function () {
          o.eN.call(t).redo();
        }}), e.push({content: "save", onclick: function () {
          const e = o.eN.call(t);
          e && e.download();
        }}), e.push({type: "divisor"}), e.push({type: "select", width: "120px", options: ["Default", "Verdana", "Arial", "Courier New"], render: function (e) {
          return '<span style="font-family:' + e + '">' + e + "</span>";
        }, onchange: function (e, t, n, o, r) {
          const l = o.eN.call(t);
          let i = l.getSelected(true);
          if (i) {
            let e = r ? o : "";
            l.setStyle(Object.fromEntries(i.map(function (t) {
              return [t, "font-family: " + e];
            })));
          }
        }, updateState: function (e, t, n) {
          r(n, o.eN.call(t));
        }}), e.push({type: "select", width: "48px", content: "format_size", options: ["x-small", "small", "medium", "large", "x-large"], render: function (e) {
          return '<span style="font-size:' + e + '">' + e + "</span>";
        }, onchange: function (e, t, n, o) {
          const r = o.eN.call(t);
          let l = r.getSelected(true);
          l && r.setStyle(Object.fromEntries(l.map(function (e) {
            return [e, "font-size: " + o];
          })));
        }, updateState: function (e, t, n) {
          r(n, o.eN.call(t));
        }}), e.push({type: "select", options: ["left", "center", "right", "justify"], render: function (e) {
          return '<i class="material-icons">format_align_' + e + "</i>";
        }, onchange: function (e, t, n, o) {
          const r = o.eN.call(t);
          let l = r.getSelected(true);
          l && r.setStyle(Object.fromEntries(l.map(function (e) {
            return [e, "text-align: " + o];
          })));
        }, updateState: function (e, t, n) {
          r(n, o.eN.call(t));
        }}), e.push({content: "format_bold", onclick: function (e, t, n) {
          const o = o.eN.call(t);
          let r = o.getSelected(true);
          r && o.setStyle(Object.fromEntries(r.map(function (e) {
            return [e, "font-weight:bold"];
          })));
        }, updateState: function (e, t, n) {
          r(n, o.eN.call(t));
        }}), e.push({type: "color", content: "format_color_text", k: "color", updateState: function (e, t, n) {
          r(n, o.eN.call(t));
        }}), e.push({type: "color", content: "format_color_fill", k: "background-color", updateState: function (e, t, n, o) {
          r(n, o.eN.call(t));
        }});
        let l = ["top", "middle", "bottom"];
        return e.push({type: "select", options: ["vertical_align_top", "vertical_align_center", "vertical_align_bottom"], render: function (e) {
          return '<i class="material-icons">' + e + "</i>";
        }, value: 1, onchange: function (e, t, n, o, r) {
          const i = o.eN.call(t);
          let a = i.getSelected(true);
          a && i.setStyle(Object.fromEntries(a.map(function (e) {
            return [e, "vertical-align: " + l[r]];
          })));
        }, updateState: function (e, t, n) {
          r(n, o.eN.call(t));
        }}), e.push({content: "web", tooltip: jSuites.translate("Merge the selected cells"), onclick: function () {
          const e = o.eN.call(t);
          if (e.selectedCell && confirm(jSuites.translate("The merged cells will retain the value of the top-left cell only. Are you sure?"))) {
            const t = [Math.min(e.selectedCell[0], e.selectedCell[2]), Math.min(e.selectedCell[1], e.selectedCell[3]), Math.max(e.selectedCell[0], e.selectedCell[2]), Math.max(e.selectedCell[1], e.selectedCell[3])];
            let s = (0, n.getCellNameFromCoords)(t[0], t[1]);
            if (e.records[t[1]][t[0]].element.getAttribute("data-merged")) e.removeMerge(s); else {
              let n = t[2] - t[0] + 1, o = t[3] - t[1] + 1;
              1 === n && 1 === o || e.setMerge(s, n, o);
            }
          }
        }, updateState: function (e, t, n) {
          r(n, o.eN.call(t));
        }}), e.push({type: "select", options: ["border_all", "border_outer", "border_inner", "border_horizontal", "border_vertical", "border_left", "border_top", "border_right", "border_bottom", "border_clear"], columns: 5, render: function (e) {
          return '<i class="material-icons">' + e + "</i>";
        }, right: true, onchange: function (e, t, o, r) {
          const l = o.eN.call(t);
          if (l.selectedCell) {
            const e = [Math.min(l.selectedCell[0], l.selectedCell[2]), Math.min(l.selectedCell[1], l.selectedCell[3]), Math.max(l.selectedCell[0], l.selectedCell[2]), Math.max(l.selectedCell[1], l.selectedCell[3])];
            let s = r;
            if (e) {
              let o = t.thickness || 1, r = t.color || "black";
              const i = t.style || "solid";
              "double" === i && (o += 2);
              let a = {}, c = e[0], d = e[1], u = e[2], p = e[3];
              const h = function (e, t, n) {
                let l = ["", "", "", ""];
                l[0] = ("border_top" === s || "border_outer" === s) && n === d || ("border_inner" === s || "border_horizontal" === s) && n > d || "border_all" === s ? "border-top: " + o + "px " + i + " " + r : "border-top: ", l[1] = "border_all" !== s && "border_right" !== s && "border_outer" !== s || t !== u ? "border-right: " : "border-right: " + o + "px " + i + " " + r, l[2] = "border_all" !== s && "border_bottom" !== s && "border_outer" !== s || n !== p ? "border-bottom: " : "border-bottom: " + o + "px " + i + " " + r, l[3] = ("border_left" === s || "border_outer" === s) && t === c || ("border_inner" === s || "border_vertical" === s) && t > c || "border_all" === s ? "border-left: " + o + "px " + i + " " + r : "border-left: ", a[e] = l.join(";");
              };
              for (let t = e[1]; t <= e[3]; t++) for (let s = e[0]; s <= e[2]; s++) h((0, n.getCellNameFromCoords)(s, t), s, t), l.records[t][s].element.getAttribute("data-merged") && h((0, n.getCellNameFromCoords)(e[0], e[1]), s, t);
              Object.keys(a) && l.setStyle(a);
            }
          }
        }, onload: function (e, t) {
          let s = document.createElement("div"), n = document.createElement("div");
          s.appendChild(n);
          let o = jSuites.color(n, {closeOnChange: false, onchange: function (e, s) {
            e.parentNode.children[1].style.color = s, t.color = s;
          }}), r = document.createElement("i");
          r.classList.add("material-icons"), r.innerHTML = "color_lens", r.onclick = function () {
            o.open();
          }, s.appendChild(r), e.children[1].appendChild(s), n = document.createElement("div"), jSuites.picker(n, {type: "select", data: [1, 2, 3, 4, 5], render: function (e) {
            return '<div style="height: ' + e + 'px; width: 30px; background-color: black;"></div>';
          }, onchange: function (e, s, n, o) {
            t.thickness = o;
          }, width: "50px"}), e.children[1].appendChild(n);
          const l = document.createElement("div");
          jSuites.picker(l, {type: "select", data: ["solid", "dotted", "dashed", "double"], render: function (e) {
            return "double" === e ? '<div style="width: 30px; border-top: 3px ' + e + ' black;"></div>' : '<div style="width: 30px; border-top: 2px ' + e + ' black;"></div>';
          }, onchange: function (e, s, n, o) {
            t.style = o;
          }, width: "50px"}), e.children[1].appendChild(l), n = document.createElement("div"), n.style.flex = "1", e.children[1].appendChild(n);
        }, updateState: function (e, t, n) {
          r(n, o.eN.call(t));
        }}), e.push({type: "divisor"}), e.push({content: "fullscreen", tooltip: "Toggle Fullscreen", onclick: function (e, s, n) {
          "fullscreen" === n.children[0].textContent ? (t.fullscreen(true), n.children[0].textContent = "fullscreen_exit") : (t.fullscreen(false), n.children[0].textContent = "fullscreen");
        }, updateState: function (e, t, s, n) {
          true === n.parent.config.fullscreen ? s.children[0].textContent = "fullscreen_exit" : s.children[0].textContent = "fullscreen";
        }}), e;
      }, i = function (e) {
        const t = this, s = e.items;
        for (let e = 0; e < s.length; e++) s[e].tooltip && (s[e].title = s[e].tooltip, delete s[e].tooltip), "select" == s[e].type ? s[e].options ? (s[e].data = s[e].options, delete s[e].options) : (s[e].data = s[e].v, delete s[e].v, s[e].k && !s[e].onchange && (s[e].onchange = function (n, r, l) {
          const i = o.eN.call(t), a = i.getSelected(true);
          i.setStyle(Object.fromEntries(a.map(function (t) {
            return [t, s[e].k + ": " + l];
          })));
        })) : "color" == s[e].type && (s[e].type = "i", s[e].onclick = function (n, r, l) {
          l.color || (jSuites.color(l, {onchange: function (n, r) {
            const l = o.eN.call(t), i = l.getSelected(true);
            l.setStyle(Object.fromEntries(i.map(function (t) {
              return [t, s[e].k + ": " + r];
            })));
          }, onopen: function (e) {
            e.color.select("");
          }}), l.color.open());
        });
      }, a = function (e) {
        const t = this, s = document.createElement("div");
        return s.classList.add("jss_toolbar"), i.call(t, e), "object" == typeof t.plugins && Object.entries(t.plugins).forEach(function ([, t]) {
          if ("function" == typeof t.toolbar) {
            const s = t.toolbar(e);
            s && (e = s);
          }
        }), jSuites.toolbar(s, e), s;
      }, c = function (e) {
        e.parent.toolbar && e.parent.toolbar.toolbar.update(e);
      }, d = function () {
        const e = this;
        if (e.config.toolbar && !e.toolbar) {
          let t;
          Array.isArray(e.config.toolbar) ? t = {items: e.config.toolbar} : "object" == typeof e.config.toolbar ? t = e.config.toolbar : (t = {items: l.call(e)}, "function" == typeof e.config.toolbar && (t = e.config.toolbar(t))), e.toolbar = e.element.insertBefore(a.call(e, t), e.element.children[1]);
        }
      }, u = function () {
        const e = this;
        e.toolbar && (e.toolbar.parentNode.removeChild(e.toolbar), delete e.toolbar);
      };
    }}, __webpack_module_cache__ = {};
    function __webpack_require__(e) {
      var t = __webpack_module_cache__[e];
      if (undefined !== t) return t.exports;
      var s = __webpack_module_cache__[e] = {exports: {}};
      return __webpack_modules__[e](s, s.exports, __webpack_require__), s.exports;
    }
    __webpack_require__.d = function (e, t) {
      for (var s in t) __webpack_require__.o(t, s) && !__webpack_require__.o(e, s) && Object.defineProperty(e, s, {enumerable: true, get: t[s]});
    }, __webpack_require__.o = function (e, t) {
      return Object.prototype.hasOwnProperty.call(e, t);
    }, __webpack_require__.r = function (e) {
      "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {value: "Module"}), Object.defineProperty(e, "__esModule", {value: true});
    };
    var __webpack_exports__ = {};
    __webpack_require__.d(__webpack_exports__, {default: function () {
      return src;
    }});
    const lib = {jspreadsheet: {}};
    var libraryBase = lib, dispatch = __webpack_require__(805), internal = __webpack_require__(530), utils_history = __webpack_require__(911);

    
    const openEditor = function (e, t, s) {
      const n = this, o = e.getAttribute("data-y"), r = e.getAttribute("data-x");
      dispatch.A.call(n, "oneditionstart", n, e, parseInt(r), parseInt(o)), r > 0 && (n.records[o][r - 1].element.style.overflow = "hidden");
      const l = function (t) {
        const s = e.getBoundingClientRect(), n = document.createElement(t);
        return n.style.width = s.width + "px", n.style.height = s.height - 2 + "px", n.style.minHeight = s.height - 2 + "px", e.classList.add("editor"), e.innerHTML = "", e.appendChild(n), n;
      };
      if (1 == e.classList.contains("readonly")) ; else if (n.edition = [n.records[o][r].element, n.records[o][r].element.innerHTML, r, o], n.options.columns && n.options.columns[r] && "object" == typeof n.options.columns[r].type) n.options.columns[r].type.openEditor(e, n.options.data[o][r], parseInt(r), parseInt(o), n, n.options.columns[r], s), dispatch.A.call(n, "oncreateeditor", n, e, parseInt(r), parseInt(o), null, n.options.columns[r]); else if (n.options.columns && n.options.columns[r] && "hidden" == n.options.columns[r].type) ; else if (n.options.columns && n.options.columns[r] && ("checkbox" == n.options.columns[r].type || "radio" == n.options.columns[r].type)) {
        const t = !e.children[0].checked;
        n.setValue(e, t), n.edition = null;
      } else if (n.options.columns && n.options.columns[r] && "dropdown" == n.options.columns[r].type) {
        let t, s = n.options.data[o][r];
        n.options.columns[r].multiple && !Array.isArray(s) && (s = s.split(";")), t = "function" == typeof n.options.columns[r].filter ? n.options.columns[r].filter(n.element, e, r, o, n.options.columns[r].source) : n.options.columns[r].source;
        const i = [];
        if (t) for (let e = 0; e < t.length; e++) i.push(t[e]);
        const a = l("div");
        dispatch.A.call(n, "oncreateeditor", n, e, parseInt(r), parseInt(o), null, n.options.columns[r]);
        const c = {data: i, multiple: !!n.options.columns[r].multiple, autocomplete: !!n.options.columns[r].autocomplete, opened: true, value: s, width: "100%", height: a.style.minHeight, position: 1 == n.options.tableOverflow || 1 == n.parent.config.fullscreen, onclose: function () {
          closeEditor.call(n, e, true);
        }};
        n.options.columns[r].options && n.options.columns[r].options.type && (c.type = n.options.columns[r].options.type), jSuites.dropdown(a, c);
      } else if (n.options.columns && n.options.columns[r] && ("calendar" == n.options.columns[r].type || "color" == n.options.columns[r].type)) {
        const t = n.options.data[o][r], s = l("input");
        dispatch.A.call(n, "oncreateeditor", n, e, parseInt(r), parseInt(o), null, n.options.columns[r]), s.value = t;
        const i = n.options.columns[r].options ? {...n.options.columns[r].options} : {};
        if (1 != n.options.tableOverflow && 1 != n.parent.config.fullscreen || (i.position = true), i.value = n.options.data[o][r], i.opened = true, i.onclose = function (t, s) {
          closeEditor.call(n, e, true);
        }, "color" == n.options.columns[r].type) {
          jSuites.color(s, i);
          const t = e.getBoundingClientRect();
          i.position && (s.nextSibling.children[1].style.top = t.top + t.height + "px", s.nextSibling.children[1].style.left = t.left + "px");
        } else i.format || (i.format = "YYYY-MM-DD"), jSuites.calendar(s, i);
        s.focus();
      } else if (n.options.columns && n.options.columns[r] && "html" == n.options.columns[r].type) {
        const t = n.options.data[o][r], s = l("div");
        dispatch.A.call(n, "oncreateeditor", n, e, parseInt(r), parseInt(o), null, n.options.columns[r]), s.style.position = "relative";
        const i = document.createElement("div");
        i.classList.add("jss_richtext"), s.appendChild(i), jSuites.editor(i, {focus: true, value: t});
        const a = e.getBoundingClientRect(), c = i.getBoundingClientRect();
        window.innerHeight < a.bottom + c.height ? i.style.top = a.bottom - (c.height + 2) + "px" : i.style.top = a.top + "px", window.innerWidth < a.left + c.width ? i.style.left = a.right - (c.width + 2) + "px" : i.style.left = a.left + "px";
      } else if (n.options.columns && n.options.columns[r] && "image" == n.options.columns[r].type) {
        const t = e.children[0], s = l("div");
        dispatch.A.call(n, "oncreateeditor", n, e, parseInt(r), parseInt(o), null, n.options.columns[r]), s.style.position = "relative";
        const i = document.createElement("div");
        i.classList.add("jclose"), t && t.src && i.appendChild(t), s.appendChild(i), jSuites.image(i, n.options.columns[r]);
        const a = e.getBoundingClientRect(), c = i.getBoundingClientRect();
        window.innerHeight < a.bottom + c.height ? i.style.top = a.top - (c.height + 2) + "px" : i.style.top = a.top + "px", i.style.left = a.left + "px";
      } else {
        const s = 1 == t ? "" : n.options.data[o][r];
        let i;
        i = n.options.columns && n.options.columns[r] && 0 == n.options.columns[r].wordWrap || !(1 == n.options.wordWrap || n.options.columns && n.options.columns[r] && 1 == n.options.columns[r].wordWrap) ? l("input") : l("textarea"), dispatch.A.call(n, "oncreateeditor", n, e, parseInt(r), parseInt(o), null, n.options.columns[r]), i.focus(), i.value = s;
        const a = n.options.columns && n.options.columns[r];
        if (!(0, internal.dw)(s) && a) {
          const e = (0, internal.rS)(a);
          if (e) {
            if (!a.disabledMaskOnEdition) if (a.mask) {
              const e = a.mask.split(";");
              i.setAttribute("data-mask", e[0]);
            } else a.locale && i.setAttribute("data-locale", a.locale);
            e.input = i, i.mask = e, jSuites.mask.render(s, e, false);
          }
        }
        i.onblur = function () {
          closeEditor.call(n, e, true);
        }, i.scrollLeft = i.scrollWidth;
      }
    }, 
    
    
    closeEditor = function (e, t) {
      const s = this, n = parseInt(e.getAttribute("data-x")), o = parseInt(e.getAttribute("data-y"));
      let r;
      if (1 == t) {
        if (s.options.columns && s.options.columns[n] && "object" == typeof s.options.columns[n].type) r = s.options.columns[n].type.closeEditor(e, t, parseInt(n), parseInt(o), s, s.options.columns[n]); else if (s.options.columns && s.options.columns[n] && ("checkbox" == s.options.columns[n].type || "radio" == s.options.columns[n].type || "hidden" == s.options.columns[n].type)) ; else if (s.options.columns && s.options.columns[n] && "dropdown" == s.options.columns[n].type) r = e.children[0].dropdown.close(true); else if (s.options.columns && s.options.columns[n] && "calendar" == s.options.columns[n].type) r = e.children[0].calendar.close(true); else if (s.options.columns && s.options.columns[n] && "color" == s.options.columns[n].type) r = e.children[0].color.close(true); else if (s.options.columns && s.options.columns[n] && "html" == s.options.columns[n].type) r = e.children[0].children[0].editor.getData(); else if (s.options.columns && s.options.columns[n] && "image" == s.options.columns[n].type) {
          const t = e.children[0].children[0].children[0];
          r = t && "IMG" == t.tagName ? t.src : "";
        } else if (s.options.columns && s.options.columns[n] && "numeric" == s.options.columns[n].type) r = e.children[0].value, "=" != ("" + r).substr(0, 1) && "" == r && (r = s.options.columns[n].allowEmpty ? "" : 0), e.children[0].onblur = null; else {
          r = e.children[0].value, e.children[0].onblur = null;
          const t = s.options.columns && s.options.columns[n];
          if (t) {
            const e = (0, internal.rS)(t);
            if (e && "" !== r && !(0, internal.dw)(r) && "number" != typeof r) {
              const t = jSuites.mask.extract(r, e, true);
              t && "" !== t.value && (r = t.value);
            }
          }
        }
        s.options.data[o][n] == r ? e.innerHTML = s.edition[1] : s.setValue(e, r);
      } else s.options.columns && s.options.columns[n] && "object" == typeof s.options.columns[n].type ? s.options.columns[n].type.closeEditor(e, t, parseInt(n), parseInt(o), s, s.options.columns[n]) : s.options.columns && s.options.columns[n] && "dropdown" == s.options.columns[n].type ? e.children[0].dropdown.close(true) : s.options.columns && s.options.columns[n] && "calendar" == s.options.columns[n].type ? e.children[0].calendar.close(true) : s.options.columns && s.options.columns[n] && "color" == s.options.columns[n].type ? e.children[0].color.close(true) : e.children[0].onblur = null, e.innerHTML = s.edition && s.edition[1] ? s.edition[1] : "";
      dispatch.A.call(s, "oneditionend", s, e, n, o, r, t), e.classList.remove("editor"), s.edition = null;
    }, setCheckRadioValue = function () {
      const e = this, t = [], s = Object.keys(e.highlighted);
      for (let n = 0; n < s.length; n++) {
        const s = e.highlighted[n].element.getAttribute("data-x"), o = e.highlighted[n].element.getAttribute("data-y");
        "checkbox" != e.options.columns[s].type && "radio" != e.options.columns[s].type || t.push(internal.k9.call(e, s, o, !e.options.data[o][s]));
      }
      if (t.length) {
        utils_history.Dh.call(e, {action: "setValue", records: t, selection: e.selectedCell});
        const s = t.map(function (e) {
          return {x: e.x, y: e.y, value: e.value, oldValue: e.oldValue};
        });
        dispatch.A.call(e, "onafterchanges", e, s);
      }
    };
    var lazyLoading = __webpack_require__(497);
    const upGet = function (e, t) {
      const s = this;
      e = parseInt(e);
      for (let n = (t = parseInt(t)) - 1; n >= 0; n--) if ("none" != s.records[n][e].element.style.display && "none" != s.rows[n].element.style.display) {
        if (s.records[n][e].element.getAttribute("data-merged") && s.records[n][e].element == s.records[t][e].element) continue;
        t = n;
        break;
      }
      return t;
    }, upVisible = function (e, t) {
      const s = this;
      let n, o;
      if (0 == e ? (n = parseInt(s.selectedCell[0]), o = parseInt(s.selectedCell[1])) : (n = parseInt(s.selectedCell[2]), o = parseInt(s.selectedCell[3])), 0 == t) {
        for (let e = 0; e < o; e++) if ("none" != s.records[e][n].element.style.display && "none" != s.rows[e].element.style.display) {
          o = e;
          break;
        }
      } else o = upGet.call(s, n, o);
      0 == e ? (s.selectedCell[0] = n, s.selectedCell[1] = o) : (s.selectedCell[2] = n, s.selectedCell[3] = o);
    }, up = function (e, t) {
      const s = this;
      if (e ? s.selectedCell[3] > 0 && upVisible.call(s, 1, t ? 0 : 1) : (s.selectedCell[1] > 0 && upVisible.call(s, 0, t ? 0 : 1), s.selectedCell[2] = s.selectedCell[0], s.selectedCell[3] = s.selectedCell[1]), s.updateSelectionFromCoords(s.selectedCell[0], s.selectedCell[1], s.selectedCell[2], s.selectedCell[3]), 1 == s.options.lazyLoading) if (0 == s.selectedCell[1] || 0 == s.selectedCell[3]) lazyLoading.wu.call(s, 0), s.updateSelectionFromCoords(s.selectedCell[0], s.selectedCell[1], s.selectedCell[2], s.selectedCell[3]); else if (lazyLoading.AG.call(s)) s.updateSelectionFromCoords(s.selectedCell[0], s.selectedCell[1], s.selectedCell[2], s.selectedCell[3]); else {
        const e = parseInt(s.tbody.firstChild.getAttribute("data-y"));
        s.selectedCell[1] - e < 30 && (lazyLoading.G_.call(s), s.updateSelectionFromCoords(s.selectedCell[0], s.selectedCell[1], s.selectedCell[2], s.selectedCell[3]));
      } else if (s.options.pagination > 0) {
        const e = s.whichPage(s.selectedCell[3]);
        e != s.pageNumber && s.page(e);
      }
      internal.Rs.call(s, 1);
    }, rightGet = function (e, t) {
      const s = this;
      e = parseInt(e), t = parseInt(t);
      for (let n = e + 1; n < s.headers.length; n++) if ("none" != s.records[t][n].element.style.display) {
        if (s.records[t][n].element.getAttribute("data-merged") && s.records[t][n].element == s.records[t][e].element) continue;
        e = n;
        break;
      }
      return e;
    }, rightVisible = function (e, t) {
      const s = this;
      let n, o;
      if (0 == e ? (n = parseInt(s.selectedCell[0]), o = parseInt(s.selectedCell[1])) : (n = parseInt(s.selectedCell[2]), o = parseInt(s.selectedCell[3])), 0 == t) {
        for (let e = s.headers.length - 1; e > n; e--) if ("none" != s.records[o][e].element.style.display) {
          n = e;
          break;
        }
      } else n = rightGet.call(s, n, o);
      0 == e ? (s.selectedCell[0] = n, s.selectedCell[1] = o) : (s.selectedCell[2] = n, s.selectedCell[3] = o);
    }, right = function (e, t) {
      const s = this;
      e ? s.selectedCell[2] < s.headers.length - 1 && rightVisible.call(s, 1, t ? 0 : 1) : (s.selectedCell[0] < s.headers.length - 1 && rightVisible.call(s, 0, t ? 0 : 1), s.selectedCell[2] = s.selectedCell[0], s.selectedCell[3] = s.selectedCell[1]), s.updateSelectionFromCoords(s.selectedCell[0], s.selectedCell[1], s.selectedCell[2], s.selectedCell[3]), internal.Rs.call(s, 2);
    }, downGet = function (e, t) {
      const s = this;
      e = parseInt(e);
      for (let n = (t = parseInt(t)) + 1; n < s.rows.length; n++) if ("none" != s.records[n][e].element.style.display && "none" != s.rows[n].element.style.display) {
        if (s.records[n][e].element.getAttribute("data-merged") && s.records[n][e].element == s.records[t][e].element) continue;
        t = n;
        break;
      }
      return t;
    }, downVisible = function (e, t) {
      const s = this;
      let n, o;
      if (0 == e ? (n = parseInt(s.selectedCell[0]), o = parseInt(s.selectedCell[1])) : (n = parseInt(s.selectedCell[2]), o = parseInt(s.selectedCell[3])), 0 == t) {
        for (let e = s.rows.length - 1; e > o; e--) if ("none" != s.records[e][n].element.style.display && "none" != s.rows[e].element.style.display) {
          o = e;
          break;
        }
      } else o = downGet.call(s, n, o);
      0 == e ? (s.selectedCell[0] = n, s.selectedCell[1] = o) : (s.selectedCell[2] = n, s.selectedCell[3] = o);
    }, down = function (e, t) {
      const s = this;
      if (e ? s.selectedCell[3] < s.records.length - 1 && downVisible.call(s, 1, t ? 0 : 1) : (s.selectedCell[1] < s.records.length - 1 && downVisible.call(s, 0, t ? 0 : 1), s.selectedCell[2] = s.selectedCell[0], s.selectedCell[3] = s.selectedCell[1]), s.updateSelectionFromCoords(s.selectedCell[0], s.selectedCell[1], s.selectedCell[2], s.selectedCell[3]), 1 == s.options.lazyLoading) s.selectedCell[1] == s.records.length - 1 || s.selectedCell[3] == s.records.length - 1 ? (lazyLoading.wu.call(s, -1), s.updateSelectionFromCoords(s.selectedCell[0], s.selectedCell[1], s.selectedCell[2], s.selectedCell[3])) : lazyLoading.AG.call(s) ? s.updateSelectionFromCoords(s.selectedCell[0], s.selectedCell[1], s.selectedCell[2], s.selectedCell[3]) : parseInt(s.tbody.lastChild.getAttribute("data-y")) - s.selectedCell[3] < 30 && (lazyLoading.p6.call(s), s.updateSelectionFromCoords(s.selectedCell[0], s.selectedCell[1], s.selectedCell[2], s.selectedCell[3])); else if (s.options.pagination > 0) {
        const e = s.whichPage(s.selectedCell[3]);
        e != s.pageNumber && s.page(e);
      }
      internal.Rs.call(s, 3);
    }, leftGet = function (e, t) {
      const s = this;
      e = parseInt(e), t = parseInt(t);
      for (let n = e - 1; n >= 0; n--) if ("none" != s.records[t][n].element.style.display) {
        if (s.records[t][n].element.getAttribute("data-merged") && s.records[t][n].element == s.records[t][e].element) continue;
        e = n;
        break;
      }
      return e;
    }, leftVisible = function (e, t) {
      const s = this;
      let n, o;
      if (0 == e ? (n = parseInt(s.selectedCell[0]), o = parseInt(s.selectedCell[1])) : (n = parseInt(s.selectedCell[2]), o = parseInt(s.selectedCell[3])), 0 == t) {
        for (let e = 0; e < n; e++) if ("none" != s.records[o][e].element.style.display) {
          n = e;
          break;
        }
      } else n = leftGet.call(s, n, o);
      0 == e ? (s.selectedCell[0] = n, s.selectedCell[1] = o) : (s.selectedCell[2] = n, s.selectedCell[3] = o);
    }, left = function (e, t) {
      const s = this;
      e ? s.selectedCell[2] > 0 && leftVisible.call(s, 1, t ? 0 : 1) : (s.selectedCell[0] > 0 && leftVisible.call(s, 0, t ? 0 : 1), s.selectedCell[2] = s.selectedCell[0], s.selectedCell[3] = s.selectedCell[1]), s.updateSelectionFromCoords(s.selectedCell[0], s.selectedCell[1], s.selectedCell[2], s.selectedCell[3]), internal.Rs.call(s, 0);
    }, first = function (e, t) {
      const s = this;
      if (e ? t ? s.selectedCell[3] = 0 : leftVisible.call(s, 1, 0) : (t ? s.selectedCell[1] = 0 : leftVisible.call(s, 0, 0), s.selectedCell[2] = s.selectedCell[0], s.selectedCell[3] = s.selectedCell[1]), 1 != s.options.lazyLoading || 0 != s.selectedCell[1] && 0 != s.selectedCell[3]) {
        if (s.options.pagination > 0) {
          const e = s.whichPage(s.selectedCell[3]);
          e != s.pageNumber && s.page(e);
        }
      } else lazyLoading.wu.call(s, 0);
      s.updateSelectionFromCoords(s.selectedCell[0], s.selectedCell[1], s.selectedCell[2], s.selectedCell[3]), internal.Rs.call(s, 1);
    }, last = function (e, t) {
      const s = this;
      if (e ? t ? s.selectedCell[3] = s.records.length - 1 : rightVisible.call(s, 1, 0) : (t ? s.selectedCell[1] = s.records.length - 1 : rightVisible.call(s, 0, 0), s.selectedCell[2] = s.selectedCell[0], s.selectedCell[3] = s.selectedCell[1]), 1 != s.options.lazyLoading || s.selectedCell[1] != s.records.length - 1 && s.selectedCell[3] != s.records.length - 1) {
        if (s.options.pagination > 0) {
          const e = s.whichPage(s.selectedCell[3]);
          e != s.pageNumber && s.page(e);
        }
      } else lazyLoading.wu.call(s, -1);
      s.updateSelectionFromCoords(s.selectedCell[0], s.selectedCell[1], s.selectedCell[2], s.selectedCell[3]), internal.Rs.call(s, 3);
    };
    var merges = __webpack_require__(910), selection = __webpack_require__(657), helpers = __webpack_require__(978), internalHelpers = __webpack_require__(689);
    const copy = function (e, t, s, n, o, r, l) {
      const i = this;
      t || (t = "	");
      const a = new RegExp(t, "ig"), c = [];
      let d = [], u = [];
      const p = [], h = [], m = i.options.data[0].length, f = i.options.data.length;
      let g = "", y = false, b = "", C = "", j = 0, w = 0, _ = 0, B = 0;
      for (let t = 0; t < f; t++) for (let s = 0; s < m; s++) e && !i.records[t][s].element.classList.contains("highlight") || (_ <= s && (_ = s), B <= t && (B = t));
      if (o && (1 == i.parent.config.includeHeadersOnDownload || n)) {
        if (i.options.nestedHeaders && i.options.nestedHeaders.length > 0) {
          g = i.options.nestedHeaders;
          for (let e = 0; e < g.length; e++) {
            const s = [];
            for (let t = 0; t < g[e].length; t++) {
              const n = parseInt(g[e][t].colspan);
              s.push(g[e][t].title);
              for (let e = 0; e < n - 1; e++) s.push("");
            }
            C += s.join(t) + "\r\n";
          }
        }
        y = true;
      }
      i.style = [];
      for (let s = 0; s < f; s++) {
        d = [], u = [];
        for (let t = 0; t < m; t++) if (!e || i.records[s][t].element.classList.contains("highlight")) {
          1 == y && c.push(i.headers[t].textContent);
          let e, n = i.options.data[s][t];
          n.match && (n.match(a) || n.match(/,/g) || n.match(/\n/) || n.match(/\"/)) && (n = n.replace(new RegExp('"', "g"), '""'), n = '"' + n + '"'), d.push(n), i.options.columns && i.options.columns[t] && ("checkbox" == i.options.columns[t].type || "radio" == i.options.columns[t].type) ? e = n : (e = i.records[s][t].element.innerHTML, e.match && (e.match(a) || e.match(/,/g) || e.match(/\n/) || e.match(/\"/)) && (e = e.replace(new RegExp('"', "g"), '""'), e = '"' + e + '"')), u.push(e), g = i.records[s][t].element.getAttribute("style"), g = g.replace("display: none;", ""), i.style.push(g || "");
        }
        d.length && (y && (j = d.length, p.push(c.join(t))), p.push(d.join(t))), u.length && (w++, y && (h.push(c.join(t)), y = false), h.push(u.join(t)));
      }
      m == j && f == w && (b = C);
      const v = b + p.join("\r\n");
      let A = b + h.join("\r\n");
      if (!s) {
        const e = [Math.min(i.selectedCell[0], i.selectedCell[2]), Math.min(i.selectedCell[1], i.selectedCell[3]), Math.max(i.selectedCell[0], i.selectedCell[2]), Math.max(i.selectedCell[1], i.selectedCell[3])], t = dispatch.A.call(i, "oncopy", i, e, A, r);
        if (t) A = t; else if (false === t) return false;
        i.textarea.value = A, i.textarea.select(), document.execCommand("copy");
      }
      if (i.data = 1 == l ? A : v, i.hashString = selection.tW.call(i, i.data), !s && (selection.kA.call(i), i.highlighted)) for (let e = 0; e < i.highlighted.length; e++) i.highlighted[e].element.classList.add("copying"), i.highlighted[e].element.classList.contains("highlight-left") && i.highlighted[e].element.classList.add("copying-left"), i.highlighted[e].element.classList.contains("highlight-right") && i.highlighted[e].element.classList.add("copying-right"), i.highlighted[e].element.classList.contains("highlight-top") && i.highlighted[e].element.classList.add("copying-top"), i.highlighted[e].element.classList.contains("highlight-bottom") && i.highlighted[e].element.classList.add("copying-bottom");
      return i.data;
    }, paste = function (e, t, s) {
      const n = this, o = (0, selection.tW)(s);
      let r = o == n.hashString ? n.style : null;
      o == n.hashString && (s = n.data), s = (0, helpers.parseCSV)(s, "	");
      const l = n.selectedCell[2] - e + 1, i = n.selectedCell[3] - t + 1, a = s[0].length;
      if (l > 1 & Number.isInteger(l / a)) {
        const e = l / a;
        if (r) {
          const t = [];
          for (let s = 0; s < r.length; s += a) {
            const n = r.slice(s, s + a);
            for (let s = 0; s < e; s++) t.push(...n);
          }
          r = t;
        }
        const t = s.map(function (t, s) {
          const n = Array.apply(null, {length: e * t.length}).map(function (e, s) {
            return t[s % t.length];
          });
          return n;
        });
        s = t;
      }
      const c = s.length;
      if (i > 1 & Number.isInteger(i / c)) {
        const e = i / c;
        if (r) {
          const t = [];
          for (let s = 0; s < e; s++) t.push(...r);
          r = t;
        }
        const t = Array.apply(null, {length: e * c}).map(function (e, t) {
          return s[t % c];
        });
        s = t;
      }
      const d = dispatch.A.call(n, "onbeforepaste", n, s.map(function (e) {
        return e.map(function (e) {
          return {value: e};
        });
      }), e, t);
      if (false === d) return false;
      if (d && (s = d), null != e && null != t && s) {
        let o = 0, l = 0;
        const i = [], a = {}, c = {};
        let d = 0, u = parseInt(e), p = parseInt(t), h = null;
        const m = n.headers.slice(u).filter(e => "none" === e.style.display).length, f = u + m + s[0].length, g = n.headers.length;
        f > g && (n.skipUpdateTableReferences = true, n.insertColumn(f - g));
        const y = n.rows.slice(p).filter(e => "none" === e.element.style.display).length, b = p + y + s.length, C = n.rows.length;
        for (b > C && (n.skipUpdateTableReferences = true, n.insertRow(b - C)), n.skipUpdateTableReferences && (n.skipUpdateTableReferences = false, internal.o8.call(n)); h = s[l];) {
          for (o = 0, u = parseInt(e); null != h[o];) {
            let e = h[o];
            n.options.columns && n.options.columns[o] && "calendar" == n.options.columns[o].type && (e = jSuites.calendar.extractDateFromString(e, n.options.columns[o].options && n.options.columns[o].options.format || "YYYY-MM-DD"));
            const t = internal.k9.call(n, u, p, e);
            if (i.push(t), internal.xF.call(n, u, p, i), r && r[d]) {
              const e = (0, internalHelpers.t3)([u, p]);
              a[e] = r[d], c[e] = n.getStyle(e), n.records[p][u].element.setAttribute("style", r[d]), d++;
            }
            if (o++, null != h[o]) {
              if (u >= n.headers.length - 1) {
                if (0 == n.options.allowInsertColumn) break;
                n.insertColumn();
              }
              u = rightGet.call(n, u, p);
            }
          }
          if (l++, s[l]) {
            if (p >= n.rows.length - 1) {
              if (0 == n.options.allowInsertRow) break;
              n.insertRow();
            }
            p = downGet.call(n, e, p);
          }
        }
        selection.AH.call(n, e, t, u, p), utils_history.Dh.call(n, {action: "setValue", records: i, selection: n.selectedCell, newStyle: a, oldStyle: c}), internal.am.call(n);
        const j = [];
        for (let n = 0; n < s.length; n++) for (let o = 0; o < s[n].length; o++) j.push({x: o + e, y: n + t, value: s[n][o]});
        dispatch.A.call(n, "onpaste", n, j);
        const w = i.map(function (e) {
          return {x: e.x, y: e.y, value: e.value, oldValue: e.oldValue};
        });
        dispatch.A.call(n, "onafterchanges", n, w);
      }
      (0, selection.kA)();
    };
    var filter = __webpack_require__(829), footer = __webpack_require__(160);
    const getNumberOfColumns = function () {
      const e = this;
      let t = e.options.columns && e.options.columns.length || 0;
      if (e.options.data && undefined !== e.options.data[0]) {
        const s = Object.keys(e.options.data[0]);
        s.length > t && (t = s.length);
      }
      return e.options.minDimensions && e.options.minDimensions[0] > t && (t = e.options.minDimensions[0]), t;
    }, createCellHeader = function (e) {
      const t = this, s = t.options.columns && t.options.columns[e] && t.options.columns[e].width || t.options.defaultColWidth || 100, n = t.options.columns && t.options.columns[e] && t.options.columns[e].align || t.options.defaultColAlign || "center";
      t.headers[e] = document.createElement("td"), t.headers[e].textContent = t.options.columns && t.options.columns[e] && t.options.columns[e].title || (0, helpers.getColumnName)(e), t.headers[e].setAttribute("data-x", e), t.headers[e].style.textAlign = n, t.options.columns && t.options.columns[e] && t.options.columns[e].title && t.headers[e].setAttribute("title", t.headers[e].innerText), t.options.columns && t.options.columns[e] && t.options.columns[e].id && t.headers[e].setAttribute("id", t.options.columns[e].id);
      const o = document.createElement("col");
      o.setAttribute("width", s), t.cols[e] = {colElement: o, x: e}, t.options.columns && t.options.columns[e] && "hidden" == t.options.columns[e].type && (t.headers[e].style.display = "none", o.style.display = "none");
    }, insertColumn = function (e, t, s, n) {
      const o = this;
      if (0 != o.options.allowInsertColumn) {
        let r, l = [];
        Array.isArray(e) ? (r = 1, e && (l = e)) : r = "number" == typeof e ? e : 1, s = !!s;
        const i = Math.max(o.options.columns.length, ...o.options.data.map(function (e) {
          return e.length;
        })) - 1;
        (null == t || t >= parseInt(i) || t < 0) && (t = i), n || (n = []);
        for (let e = 0; e < r; e++) n[e] || (n[e] = {});
        const a = [];
        if (Array.isArray(e)) {
          const r = [];
          for (let t = 0; t < o.options.data.length; t++) r.push(t < e.length ? e[t] : "");
          const l = {column: t + (s ? 0 : 1), options: Object.assign({}, n[0]), data: r};
          a.push(l);
        } else for (let o = 0; o < e; o++) {
          const e = {column: t + o + (s ? 0 : 1), options: Object.assign({}, n[o])};
          a.push(e);
        }
        if (false === dispatch.A.call(o, "onbeforeinsertcolumn", o, a)) return false;
        if (o.options.mergeCells && Object.keys(o.options.mergeCells).length > 0 && merges.Lt.call(o, t, s).length) {
          if (!confirm(jSuites.translate("This action will destroy any existing merged cells. Are you sure?"))) return false;
          o.destroyMerge();
        }
        const c = s ? t : t + 1;
        o.options.columns = (0, internalHelpers.Hh)(o.options.columns, c, n);
        const d = o.headers.splice(c), u = o.cols.splice(c), p = [], h = [], m = [], f = [], g = [];
        for (let e = c; e < r + c; e++) createCellHeader.call(o, e), o.headerContainer.insertBefore(o.headers[e], o.headerContainer.children[e + 1]), o.colgroupContainer.insertBefore(o.cols[e].colElement, o.colgroupContainer.children[e + 1]), p.push(o.headers[e]), h.push(o.cols[e]);
        if (o.options.footers) for (let e = 0; e < o.options.footers.length; e++) {
          g[e] = [];
          for (let t = 0; t < r; t++) g[e].push("");
          o.options.footers[e].splice(c, 0, g[e]);
        }
        for (let e = 0; e < o.options.data.length; e++) {
          const t = o.options.data[e].splice(c), s = o.records[e].splice(c);
          f[e] = [], m[e] = [];
          for (let t = c; t < r + c; t++) {
            const s = l[e] ? l[e] : "";
            o.options.data[e][t] = s;
            const n = internal.P9.call(o, t, e, o.options.data[e][t]);
            o.records[e][t] = {element: n, y: e}, o.rows[e] && o.rows[e].element.insertBefore(n, o.rows[e].element.children[t + 1]), o.options.columns && o.options.columns[t] && "function" == typeof o.options.columns[t].render && o.options.columns[t].render(n, s, parseInt(t), parseInt(e), o, o.options.columns[t]), f[e].push(s), m[e].push({element: n, x: t, y: e});
          }
          Array.prototype.push.apply(o.options.data[e], t), Array.prototype.push.apply(o.records[e], s);
        }
        Array.prototype.push.apply(o.headers, d), Array.prototype.push.apply(o.cols, u);
        for (let e = c; e < o.cols.length; e++) o.cols[e].x = e;
        for (let e = 0; e < o.records.length; e++) for (let t = 0; t < o.records[e].length; t++) o.records[e][t].x = t;
        if (o.options.nestedHeaders && o.options.nestedHeaders.length > 0 && o.options.nestedHeaders[0] && o.options.nestedHeaders[0][0]) for (let e = 0; e < o.options.nestedHeaders.length; e++) {
          const t = parseInt(o.options.nestedHeaders[e][o.options.nestedHeaders[e].length - 1].colspan) + r;
          o.options.nestedHeaders[e][o.options.nestedHeaders[e].length - 1].colspan = t, o.thead.children[e].children[o.thead.children[e].children.length - 1].setAttribute("colspan", t);
          let s = o.thead.children[e].children[o.thead.children[e].children.length - 1].getAttribute("data-column");
          s = s.split(",");
          for (let e = c; e < r + c; e++) s.push(e);
          o.thead.children[e].children[o.thead.children[e].children.length - 1].setAttribute("data-column", s);
        }
        utils_history.Dh.call(o, {action: "insertColumn", columnNumber: t, numOfColumns: r, insertBefore: s, columns: n, headers: p, cols: h, records: m, footers: g, data: f}), internal.o8.call(o), dispatch.A.call(o, "oninsertcolumn", o, a);
      }
    }, moveColumn = function (e, t) {
      const s = this;
      if (s.options.mergeCells && Object.keys(s.options.mergeCells).length > 0) {
        let n;
        if (n = e > t ? 1 : 0, merges.Lt.call(s, e).length || merges.Lt.call(s, t, n).length) {
          if (!confirm(jSuites.translate("This action will destroy any existing merged cells. Are you sure?"))) return false;
          s.destroyMerge();
        }
      }
      if ((e = parseInt(e)) > (t = parseInt(t))) {
        s.headerContainer.insertBefore(s.headers[e], s.headers[t]), s.colgroupContainer.insertBefore(s.cols[e].colElement, s.cols[t].colElement);
        for (let n = 0; n < s.rows.length; n++) s.rows[n].element.insertBefore(s.records[n][e].element, s.records[n][t].element);
      } else {
        s.headerContainer.insertBefore(s.headers[e], s.headers[t].nextSibling), s.colgroupContainer.insertBefore(s.cols[e].colElement, s.cols[t].colElement.nextSibling);
        for (let n = 0; n < s.rows.length; n++) s.rows[n].element.insertBefore(s.records[n][e].element, s.records[n][t].element.nextSibling);
      }
      s.options.columns.splice(t, 0, s.options.columns.splice(e, 1)[0]), s.headers.splice(t, 0, s.headers.splice(e, 1)[0]), s.cols.splice(t, 0, s.cols.splice(e, 1)[0]);
      const n = Math.min(e, t), o = Math.max(e, t);
      for (let n = 0; n < s.rows.length; n++) s.options.data[n].splice(t, 0, s.options.data[n].splice(e, 1)[0]), s.records[n].splice(t, 0, s.records[n].splice(e, 1)[0]);
      for (let e = n; e <= o; e++) s.cols[e].x = e;
      for (let e = 0; e < s.records.length; e++) for (let t = n; t <= o; t++) s.records[e][t].x = t;
      if (s.options.footers) for (let n = 0; n < s.options.footers.length; n++) s.options.footers[n].splice(t, 0, s.options.footers[n].splice(e, 1)[0]);
      utils_history.Dh.call(s, {action: "moveColumn", oldValue: e, newValue: t}), internal.o8.call(s), dispatch.A.call(s, "onmovecolumn", s, e, t, 1);
    }, deleteColumn = function (e, t) {
      const s = this;
      if (0 != s.options.allowDeleteColumn) if (s.headers.length > 1) {
        if (null == e) {
          const n = s.getSelectedColumns(true);
          n.length ? (e = parseInt(n[0]), t = parseInt(n.length)) : (e = s.headers.length - 1, t = 1);
        }
        const n = s.options.data[0].length - 1;
        (null == e || e > n || e < 0) && (e = n), t || (t = 1), t > s.options.data[0].length - e && (t = s.options.data[0].length - e);
        const o = [];
        for (let s = 0; s < t; s++) o.push(s + e);
        if (false === dispatch.A.call(s, "onbeforedeletecolumn", s, o)) return false;
        if (parseInt(e) > -1) {
          let n = false;
          if (s.options.mergeCells && Object.keys(s.options.mergeCells).length > 0) for (let o = e; o < e + t; o++) merges.Lt.call(s, o, null).length && (n = true);
          if (n) {
            if (!confirm(jSuites.translate("This action will destroy any existing merged cells. Are you sure?"))) return false;
            s.destroyMerge();
          }
          const r = s.options.columns ? s.options.columns.splice(e, t) : undefined;
          for (let n = e; n < e + t; n++) s.cols[n].colElement.className = "", s.headers[n].className = "", s.cols[n].colElement.parentNode.removeChild(s.cols[n].colElement), s.headers[n].parentNode.removeChild(s.headers[n]);
          const l = s.headers.splice(e, t), i = s.cols.splice(e, t), a = [], c = [], d = [];
          for (let n = 0; n < s.options.data.length; n++) for (let o = e; o < e + t; o++) s.records[n][o].element.className = "", s.records[n][o].element.parentNode.removeChild(s.records[n][o].element);
          for (let n = 0; n < s.options.data.length; n++) c[n] = s.options.data[n].splice(e, t), a[n] = s.records[n].splice(e, t);
          for (let t = e; t < s.cols.length; t++) s.cols[t].x = t;
          for (let t = 0; t < s.records.length; t++) for (let n = e; n < s.records[t].length; n++) s.records[t][n].x = n;
          if (s.options.footers) for (let n = 0; n < s.options.footers.length; n++) d[n] = s.options.footers[n].splice(e, t);
          if (selection.at.call(s, 0, e, e + t - 1), s.options.nestedHeaders && s.options.nestedHeaders.length > 0 && s.options.nestedHeaders[0] && s.options.nestedHeaders[0][0]) for (let e = 0; e < s.options.nestedHeaders.length; e++) {
            const n = parseInt(s.options.nestedHeaders[e][s.options.nestedHeaders[e].length - 1].colspan) - t;
            s.options.nestedHeaders[e][s.options.nestedHeaders[e].length - 1].colspan = n, s.thead.children[e].children[s.thead.children[e].children.length - 1].setAttribute("colspan", n);
          }
          utils_history.Dh.call(s, {action: "deleteColumn", columnNumber: e, numOfColumns: t, insertBefore: 1, columns: r, headers: l, cols: i, records: a, footers: d, data: c}), internal.o8.call(s), dispatch.A.call(s, "ondeletecolumn", s, o);
        }
      } else console.error("Jspreadsheet: It is not possible to delete the last column");
    }, getWidth = function (e) {
      const t = this;
      let s;
      if (undefined === e) {
        s = [];
        for (let e = 0; e < t.headers.length; e++) s.push(t.options.columns && t.options.columns[e] && t.options.columns[e].width || t.options.defaultColWidth || 100);
      } else s = parseInt(t.cols[e].colElement.getAttribute("width"));
      return s;
    }, setWidth = function (e, t, s) {
      const n = this;
      if (t) {
        if (Array.isArray(e)) {
          s || (s = []);
          for (let o = 0; o < e.length; o++) {
            s[o] || (s[o] = parseInt(n.cols[e[o]].colElement.getAttribute("width")));
            const r = Array.isArray(t) && t[o] ? t[o] : t;
            n.cols[e[o]].colElement.setAttribute("width", r), n.options.columns || (n.options.columns = []), n.options.columns[e[o]] || (n.options.columns[e[o]] = {}), n.options.columns[e[o]].width = r;
          }
        } else s || (s = parseInt(n.cols[e].colElement.getAttribute("width"))), n.cols[e].colElement.setAttribute("width", t), n.options.columns || (n.options.columns = []), n.options.columns[e] || (n.options.columns[e] = {}), n.options.columns[e].width = t;
        utils_history.Dh.call(n, {action: "setWidth", column: e, oldValue: s, newValue: t}), dispatch.A.call(n, "onresizecolumn", n, e, t, s), selection.Aq.call(n);
      }
    }, showColumn = function (e) {
      const t = this;
      Array.isArray(e) || (e = [e]);
      for (let s = 0; s < e.length; s++) {
        const n = e[s];
        t.headers[n].style.display = "", t.cols[n].colElement.style.display = "", t.filter && t.filter.children.length > n + 1 && (t.filter.children[n + 1].style.display = "");
        for (let e = 0; e < t.options.data.length; e++) t.records[e][n].element.style.display = "";
      }
      t.options.footers && footer.e.call(t), t.resetSelection();
    }, hideColumn = function (e) {
      const t = this;
      Array.isArray(e) || (e = [e]);
      for (let s = 0; s < e.length; s++) {
        const n = e[s];
        t.headers[n].style.display = "none", t.cols[n].colElement.style.display = "none", t.filter && t.filter.children.length > n + 1 && (t.filter.children[n + 1].style.display = "none");
        for (let e = 0; e < t.options.data.length; e++) t.records[e][n].element.style.display = "none";
      }
      t.options.footers && footer.e.call(t), t.resetSelection();
    }, getColumnData = function (e, t) {
      const s = this, n = [];
      for (let o = 0; o < s.options.data.length; o++) t ? n.push(s.records[o][e].element.innerHTML) : n.push(s.options.data[o][e]);
      return n;
    }, setColumnData = function (e, t, s) {
      const n = this;
      for (let o = 0; o < n.rows.length; o++) {
        const r = (0, internalHelpers.t3)([e, o]);
        null != t[o] && n.setValue(r, t[o], s);
      }
    }, createRow = function (e, t) {
      const s = this;
      s.records[e] || (s.records[e] = []), t || (t = s.options.data[e]);
      const n = {element: document.createElement("tr"), y: e};
      s.rows[e] = n, n.element.setAttribute("data-y", e);
      let o = null;
      s.options.defaultRowHeight && (n.element.style.height = s.options.defaultRowHeight + "px"), s.options.rows && s.options.rows[e] && (s.options.rows[e].height && (n.element.style.height = s.options.rows[e].height), s.options.rows[e].title && (o = s.options.rows[e].title)), o || (o = parseInt(e + 1));
      const r = document.createElement("td");
      r.innerHTML = o, r.setAttribute("data-y", e), r.className = "jss_row", n.element.appendChild(r);
      const l = getNumberOfColumns.call(s);
      for (let o = 0; o < l; o++) s.records[e][o] = {element: internal.P9.call(this, o, e, t[o]), x: o, y: e}, n.element.appendChild(s.records[e][o].element), s.options.columns && s.options.columns[o] && "function" == typeof s.options.columns[o].render && s.options.columns[o].render(s.records[e][o].element, t[o], parseInt(o), parseInt(e), s, s.options.columns[o]);
      return n;
    }, insertRow = function (e, t, s) {
      const n = this;
      if (0 != n.options.allowInsertRow) {
        let o, r = [];
        Array.isArray(e) ? (o = 1, e && (r = e)) : o = undefined !== e ? e : 1, s = !!s;
        const l = n.options.data.length - 1;
        (null == t || t >= parseInt(l) || t < 0) && (t = l);
        const i = [];
        for (let e = 0; e < o; e++) {
          const o = [];
          for (let e = 0; e < n.options.columns.length; e++) o[e] = r[e] ? r[e] : "";
          i.push({row: e + t + (s ? 0 : 1), data: o});
        }
        if (false === dispatch.A.call(n, "onbeforeinsertrow", n, i)) return false;
        if (n.options.mergeCells && Object.keys(n.options.mergeCells).length > 0 && merges.D0.call(n, t, s).length) {
          if (!confirm(jSuites.translate("This action will destroy any existing merged cells. Are you sure?"))) return false;
          n.destroyMerge();
        }
        if (1 == n.options.search) {
          if (n.results && n.results.length != n.rows.length) {
            if (!confirm(jSuites.translate("This action will clear your search results. Are you sure?"))) return false;
            n.resetSearch();
          }
          n.results = null;
        }
        const a = s ? t : t + 1, c = n.records.splice(a), d = n.options.data.splice(a), u = n.rows.splice(a), p = [], h = [], m = [];
        for (let e = a; e < o + a; e++) {
          n.options.data[e] = [];
          for (let t = 0; t < n.options.columns.length; t++) n.options.data[e][t] = r[t] ? r[t] : "";
          const s = createRow.call(n, e, n.options.data[e]);
          u[0] ? Array.prototype.indexOf.call(n.tbody.children, u[0].element) >= 0 && n.tbody.insertBefore(s.element, u[0].element) : Array.prototype.indexOf.call(n.tbody.children, n.rows[t].element) >= 0 && n.tbody.appendChild(s.element), p.push([...n.records[e]]), h.push([...n.options.data[e]]), m.push(s);
        }
        Array.prototype.push.apply(n.records, c), Array.prototype.push.apply(n.options.data, d), Array.prototype.push.apply(n.rows, u);
        for (let e = a; e < n.rows.length; e++) n.rows[e].y = e;
        for (let e = a; e < n.records.length; e++) for (let t = 0; t < n.records[e].length; t++) n.records[e][t].y = e;
        n.options.pagination > 0 && n.page(n.pageNumber), utils_history.Dh.call(n, {action: "insertRow", rowNumber: t, numOfRows: o, insertBefore: s, rowRecords: p, rowData: h, rowNode: m}), internal.o8.call(n), dispatch.A.call(n, "oninsertrow", n, i);
      }
    }, moveRow = function (e, t, s) {
      const n = this;
      if (n.options.mergeCells && Object.keys(n.options.mergeCells).length > 0) {
        let s;
        if (s = e > t ? 1 : 0, merges.D0.call(n, e).length || merges.D0.call(n, t, s).length) {
          if (!confirm(jSuites.translate("This action will destroy any existing merged cells. Are you sure?"))) return false;
          n.destroyMerge();
        }
      }
      if (1 == n.options.search) {
        if (n.results && n.results.length != n.rows.length) {
          if (!confirm(jSuites.translate("This action will clear your search results. Are you sure?"))) return false;
          n.resetSearch();
        }
        n.results = null;
      }
      s || (Array.prototype.indexOf.call(n.tbody.children, n.rows[t].element) >= 0 ? e > t ? n.tbody.insertBefore(n.rows[e].element, n.rows[t].element) : n.tbody.insertBefore(n.rows[e].element, n.rows[t].element.nextSibling) : n.tbody.removeChild(n.rows[e].element)), n.rows.splice(t, 0, n.rows.splice(e, 1)[0]), n.records.splice(t, 0, n.records.splice(e, 1)[0]), n.options.data.splice(t, 0, n.options.data.splice(e, 1)[0]);
      const o = Math.min(e, t), r = Math.max(e, t);
      for (let e = o; e <= r; e++) n.rows[e].y = e;
      for (let e = o; e <= r; e++) for (let t = 0; t < n.records[e].length; t++) n.records[e][t].y = e;
      n.options.pagination > 0 && n.tbody.children.length != n.options.pagination && n.page(n.pageNumber), utils_history.Dh.call(n, {action: "moveRow", oldValue: e, newValue: t}), internal.o8.call(n), dispatch.A.call(n, "onmoverow", n, parseInt(e), parseInt(t), 1);
    }, deleteRow = function (e, t) {
      const s = this;
      if (0 != s.options.allowDeleteRow) if (1 == s.options.allowDeletingAllRows || s.options.data.length > 1) {
        if (null == e) {
          const n = selection.R5.call(s);
          0 === n.length ? (e = s.options.data.length - 1, t = 1) : (e = n[0], t = n.length);
        }
        let n = s.options.data.length - 1;
        (null == e || e > n || e < 0) && (e = n), t || (t = 1), e + t >= s.options.data.length && (t = s.options.data.length - e);
        const o = [];
        for (let s = 0; s < t; s++) o.push(s + e);
        if (false === dispatch.A.call(s, "onbeforedeleterow", s, o)) return false;
        if (parseInt(e) > -1) {
          let r = false;
          if (s.options.mergeCells && Object.keys(s.options.mergeCells).length > 0) for (let n = e; n < e + t; n++) merges.D0.call(s, n, false).length && (r = true);
          if (r) {
            if (!confirm(jSuites.translate("This action will destroy any existing merged cells. Are you sure?"))) return false;
            s.destroyMerge();
          }
          if (1 == s.options.search) {
            if (s.results && s.results.length != s.rows.length) {
              if (!confirm(jSuites.translate("This action will clear your search results. Are you sure?"))) return false;
              s.resetSearch();
            }
            s.results = null;
          }
          1 != s.options.allowDeletingAllRows && n + 1 === t && (t--, console.error("Jspreadsheet: It is not possible to delete the last row"));
          for (let n = e; n < e + t; n++) Array.prototype.indexOf.call(s.tbody.children, s.rows[n].element) >= 0 && (s.rows[n].element.className = "", s.rows[n].element.parentNode.removeChild(s.rows[n].element));
          const l = s.records.splice(e, t), i = s.options.data.splice(e, t), a = s.rows.splice(e, t);
          for (let t = e; t < s.rows.length; t++) s.rows[t].y = t;
          for (let t = e; t < s.records.length; t++) for (let e = 0; e < s.records[t].length; e++) s.records[t][e].y = t;
          s.options.pagination > 0 && s.tbody.children.length != s.options.pagination && s.page(s.pageNumber), selection.at.call(s, 1, e, e + t - 1), utils_history.Dh.call(s, {action: "deleteRow", rowNumber: e, numOfRows: t, insertBefore: 1, rowRecords: l, rowData: i, rowNode: a}), internal.o8.call(s), dispatch.A.call(s, "ondeleterow", s, o);
        }
      } else console.error("Jspreadsheet: It is not possible to delete the last row");
    }, getHeight = function (e) {
      const t = this;
      let s;
      if (undefined === e) {
        s = [];
        for (let e = 0; e < t.rows.length; e++) {
          const n = t.rows[e].element.style.height;
          n && (s[e] = n);
        }
      } else "object" == typeof e && (e = $(e).getAttribute("data-y")), s = t.rows[e].element.style.height;
      return s;
    }, setHeight = function (e, t, s) {
      const n = this;
      t > 0 && (s || (s = n.rows[e].element.getAttribute("height")) || (s = n.rows[e].element.getBoundingClientRect().height), t = parseInt(t), n.rows[e].element.style.height = t + "px", n.options.rows || (n.options.rows = []), n.options.rows[e] || (n.options.rows[e] = {}), n.options.rows[e].height = t, utils_history.Dh.call(n, {action: "setHeight", row: e, oldValue: s, newValue: t}), dispatch.A.call(n, "onresizerow", n, e, t, s), selection.Aq.call(n));
    }, showRow = function (e) {
      const t = this;
      Array.isArray(e) || (e = [e]), e.forEach(function (e) {
        t.rows[e].element.style.display = "";
      });
    }, hideRow = function (e) {
      const t = this;
      Array.isArray(e) || (e = [e]), e.forEach(function (e) {
        t.rows[e].element.style.display = "none";
      });
    }, getRowData = function (e, t) {
      return t ? this.records[e].map(function (e) {
        return e.element.innerHTML;
      }) : this.options.data[e];
    }, setRowData = function (e, t, s) {
      const n = this;
      for (let o = 0; o < n.headers.length; o++) {
        const r = (0, internalHelpers.t3)([o, e]);
        null != t[o] && n.setValue(r, t[o], s);
      }
    };
    var version = {version: "5.0.0", host: "https://bossanova.uk/jspreadsheet", license: "MIT", print: function () {
      return [["Jspreadsheet CE", this.version, this.host, this.license].join("\r\n")];
    }};
    const getElement = function (e) {
      let t = 0, s = 0;
      return function e(n) {
        n.className && (n.classList.contains("jss_container") && (s = n), n.classList.contains("jss_spreadsheet") && (s = n.querySelector(":scope > .jtabs-content > .jtabs-selected"))), "THEAD" == n.tagName ? t = 1 : "TBODY" == n.tagName && (t = 2), n.parentNode && (s || e(n.parentNode));
      }(e), [s, t];
    }, mouseUpControls = function (e) {
      if (libraryBase.jspreadsheet.current) if (libraryBase.jspreadsheet.current.resizing) {
        if (libraryBase.jspreadsheet.current.resizing.column) {
          const e = parseInt(libraryBase.jspreadsheet.current.cols[libraryBase.jspreadsheet.current.resizing.column].colElement.getAttribute("width")), t = libraryBase.jspreadsheet.current.getSelectedColumns();
          if (t.length > 1) {
            const s = [];
            for (let e = 0; e < t.length; e++) s.push(parseInt(libraryBase.jspreadsheet.current.cols[t[e]].colElement.getAttribute("width")));
            s[t.indexOf(parseInt(libraryBase.jspreadsheet.current.resizing.column))] = libraryBase.jspreadsheet.current.resizing.width, setWidth.call(libraryBase.jspreadsheet.current, t, e, s);
          } else setWidth.call(libraryBase.jspreadsheet.current, parseInt(libraryBase.jspreadsheet.current.resizing.column), e, libraryBase.jspreadsheet.current.resizing.width);
          libraryBase.jspreadsheet.current.headers[libraryBase.jspreadsheet.current.resizing.column].classList.remove("resizing");
          for (let e = 0; e < libraryBase.jspreadsheet.current.records.length; e++) libraryBase.jspreadsheet.current.records[e][libraryBase.jspreadsheet.current.resizing.column] && libraryBase.jspreadsheet.current.records[e][libraryBase.jspreadsheet.current.resizing.column].element.classList.remove("resizing");
        } else {
          libraryBase.jspreadsheet.current.rows[libraryBase.jspreadsheet.current.resizing.row].element.children[0].classList.remove("resizing");
          let e = libraryBase.jspreadsheet.current.rows[libraryBase.jspreadsheet.current.resizing.row].element.getAttribute("height");
          setHeight.call(libraryBase.jspreadsheet.current, libraryBase.jspreadsheet.current.resizing.row, e, libraryBase.jspreadsheet.current.resizing.height), libraryBase.jspreadsheet.current.resizing.element.classList.remove("resizing");
        }
        libraryBase.jspreadsheet.current.resizing = null;
      } else if (libraryBase.jspreadsheet.current.dragging) {
        if (libraryBase.jspreadsheet.current.dragging) {
          if (libraryBase.jspreadsheet.current.dragging.column) {
            const t = e.target.getAttribute("data-x");
            libraryBase.jspreadsheet.current.headers[libraryBase.jspreadsheet.current.dragging.column].classList.remove("dragging");
            for (let e = 0; e < libraryBase.jspreadsheet.current.rows.length; e++) libraryBase.jspreadsheet.current.records[e][libraryBase.jspreadsheet.current.dragging.column] && libraryBase.jspreadsheet.current.records[e][libraryBase.jspreadsheet.current.dragging.column].element.classList.remove("dragging");
            for (let e = 0; e < libraryBase.jspreadsheet.current.headers.length; e++) libraryBase.jspreadsheet.current.headers[e].classList.remove("dragging-left"), libraryBase.jspreadsheet.current.headers[e].classList.remove("dragging-right");
            t && libraryBase.jspreadsheet.current.dragging.column != libraryBase.jspreadsheet.current.dragging.destination && libraryBase.jspreadsheet.current.moveColumn(libraryBase.jspreadsheet.current.dragging.column, libraryBase.jspreadsheet.current.dragging.destination);
          } else {
            let e;
            libraryBase.jspreadsheet.current.dragging.element.nextSibling ? (e = parseInt(libraryBase.jspreadsheet.current.dragging.element.nextSibling.getAttribute("data-y")), libraryBase.jspreadsheet.current.dragging.row < e && (e -= 1)) : e = parseInt(libraryBase.jspreadsheet.current.dragging.element.previousSibling.getAttribute("data-y")), libraryBase.jspreadsheet.current.dragging.row != libraryBase.jspreadsheet.current.dragging.destination && moveRow.call(libraryBase.jspreadsheet.current, libraryBase.jspreadsheet.current.dragging.row, e, true), libraryBase.jspreadsheet.current.dragging.element.classList.remove("dragging");
          }
          libraryBase.jspreadsheet.current.dragging = null;
        }
      } else libraryBase.jspreadsheet.current.selectedCorner && (libraryBase.jspreadsheet.current.selectedCorner = false, libraryBase.jspreadsheet.current.selection.length > 0 && (selection.kF.call(libraryBase.jspreadsheet.current, libraryBase.jspreadsheet.current.selection[0], libraryBase.jspreadsheet.current.selection[libraryBase.jspreadsheet.current.selection.length - 1]), selection.gG.call(libraryBase.jspreadsheet.current)));
      libraryBase.jspreadsheet.timeControl && (clearTimeout(libraryBase.jspreadsheet.timeControl), libraryBase.jspreadsheet.timeControl = null), libraryBase.jspreadsheet.isMouseAction = false;
    }, mouseDownControls = function (e) {
      let t;
      t = (e = e || window.event).buttons ? e.buttons : e.button ? e.button : e.which;
      const s = getElement(e.target);
      if (s[0] ? libraryBase.jspreadsheet.current != s[0].jssWorksheet && (libraryBase.jspreadsheet.current && (libraryBase.jspreadsheet.current.edition && closeEditor.call(libraryBase.jspreadsheet.current, libraryBase.jspreadsheet.current.edition[0], true), libraryBase.jspreadsheet.current.resetSelection()), libraryBase.jspreadsheet.current = s[0].jssWorksheet) : libraryBase.jspreadsheet.current && (libraryBase.jspreadsheet.current.edition && closeEditor.call(libraryBase.jspreadsheet.current, libraryBase.jspreadsheet.current.edition[0], true), e.target.classList.contains("jss_object") || (selection.gE.call(libraryBase.jspreadsheet.current, true), libraryBase.jspreadsheet.current = null)), libraryBase.jspreadsheet.current && 1 == t) {
        if (e.target.classList.contains("jss_selectall")) libraryBase.jspreadsheet.current && selection.Ub.call(libraryBase.jspreadsheet.current); else if (e.target.classList.contains("jss_corner")) 0 != libraryBase.jspreadsheet.current.options.editable && (libraryBase.jspreadsheet.current.selectedCorner = true); else {
          if (1 == s[1]) {
            const t = e.target.getAttribute("data-x");
            if (t) {
              const s = e.target.getBoundingClientRect();
              if (0 != libraryBase.jspreadsheet.current.options.columnResize && s.width - e.offsetX < 6) {
                libraryBase.jspreadsheet.current.resizing = {mousePosition: e.pageX, column: t, width: s.width}, libraryBase.jspreadsheet.current.headers[t].classList.add("resizing");
                for (let e = 0; e < libraryBase.jspreadsheet.current.records.length; e++) libraryBase.jspreadsheet.current.records[e][t] && libraryBase.jspreadsheet.current.records[e][t].element.classList.add("resizing");
              } else if (0 != libraryBase.jspreadsheet.current.options.columnDrag && s.height - e.offsetY < 6) if (merges.Lt.call(libraryBase.jspreadsheet.current, t).length) console.error("Jspreadsheet: This column is part of a merged cell."); else {
                libraryBase.jspreadsheet.current.resetSelection(), libraryBase.jspreadsheet.current.dragging = {element: e.target, column: t, destination: t}, libraryBase.jspreadsheet.current.headers[t].classList.add("dragging");
                for (let e = 0; e < libraryBase.jspreadsheet.current.records.length; e++) libraryBase.jspreadsheet.current.records[e][t] && libraryBase.jspreadsheet.current.records[e][t].element.classList.add("dragging");
              } else {
                let s, n;
                libraryBase.jspreadsheet.current.selectedHeader && (e.shiftKey || e.ctrlKey) ? (s = libraryBase.jspreadsheet.current.selectedHeader, n = t) : (libraryBase.jspreadsheet.current.selectedHeader == t && 0 != libraryBase.jspreadsheet.current.options.allowRenameColumn && (libraryBase.jspreadsheet.timeControl = setTimeout(function () {
                  libraryBase.jspreadsheet.current.setHeader(t);
                }, 800)), libraryBase.jspreadsheet.current.selectedHeader = t, s = t, n = t), selection.AH.call(libraryBase.jspreadsheet.current, s, 0, n, libraryBase.jspreadsheet.current.options.data.length - 1, e);
              }
            } else if (e.target.parentNode.classList.contains("jss_nested")) {
              let t, s;
              if (e.target.getAttribute("data-column")) {
                const n = e.target.getAttribute("data-column").split(",");
                t = parseInt(n[0]), s = parseInt(n[n.length - 1]);
              } else t = 0, s = libraryBase.jspreadsheet.current.options.columns.length - 1;
              selection.AH.call(libraryBase.jspreadsheet.current, t, 0, s, libraryBase.jspreadsheet.current.options.data.length - 1, e);
            }
          } else libraryBase.jspreadsheet.current.selectedHeader = false;
          if (2 == s[1]) {
            const t = parseInt(e.target.getAttribute("data-y"));
            if (e.target.classList.contains("jss_row")) {
              const s = e.target.getBoundingClientRect();
              if (0 != libraryBase.jspreadsheet.current.options.rowResize && s.height - e.offsetY < 6) libraryBase.jspreadsheet.current.resizing = {element: e.target.parentNode, mousePosition: e.pageY, row: t, height: s.height}, e.target.parentNode.classList.add("resizing"); else if (0 != libraryBase.jspreadsheet.current.options.rowDrag && s.width - e.offsetX < 6) merges.D0.call(libraryBase.jspreadsheet.current, t).length ? console.error("Jspreadsheet: This row is part of a merged cell") : 1 == libraryBase.jspreadsheet.current.options.search && libraryBase.jspreadsheet.current.results ? console.error("Jspreadsheet: Please clear your search before perform this action") : (libraryBase.jspreadsheet.current.resetSelection(), libraryBase.jspreadsheet.current.dragging = {element: e.target.parentNode, row: t, destination: t}, e.target.parentNode.classList.add("dragging")); else {
                let s, n;
                null != libraryBase.jspreadsheet.current.selectedRow && (e.shiftKey || e.ctrlKey) ? (s = libraryBase.jspreadsheet.current.selectedRow, n = t) : (libraryBase.jspreadsheet.current.selectedRow = t, s = t, n = t), selection.AH.call(libraryBase.jspreadsheet.current, null, s, null, n, e);
              }
            } else if (e.target.classList.contains("jclose") && e.target.clientWidth - e.offsetX < 50 && e.offsetY < 50) closeEditor.call(libraryBase.jspreadsheet.current, libraryBase.jspreadsheet.current.edition[0], true); else {
              const t = function (e) {
                const s = e.getAttribute("data-x"), n = e.getAttribute("data-y");
                return s && n ? [s, n] : e.parentNode ? t(e.parentNode) : undefined;
              }, s = t(e.target);
              if (s) {
                const t = s[0], n = s[1];
                libraryBase.jspreadsheet.current.edition && (libraryBase.jspreadsheet.current.edition[2] == t && libraryBase.jspreadsheet.current.edition[3] == n || closeEditor.call(libraryBase.jspreadsheet.current, libraryBase.jspreadsheet.current.edition[0], true)), libraryBase.jspreadsheet.current.edition || (e.shiftKey ? selection.AH.call(libraryBase.jspreadsheet.current, libraryBase.jspreadsheet.current.selectedCell[0], libraryBase.jspreadsheet.current.selectedCell[1], t, n, e) : selection.AH.call(libraryBase.jspreadsheet.current, t, n, undefined, undefined, e)), libraryBase.jspreadsheet.current.selectedHeader = null, libraryBase.jspreadsheet.current.selectedRow = null;
              }
            }
          } else libraryBase.jspreadsheet.current.selectedRow = false;
          e.target.classList.contains("jss_page") && ("<" == e.target.textContent ? libraryBase.jspreadsheet.current.page(0) : ">" == e.target.textContent ? libraryBase.jspreadsheet.current.page(e.target.getAttribute("title") - 1) : libraryBase.jspreadsheet.current.page(e.target.textContent - 1));
        }
        libraryBase.jspreadsheet.current.edition ? libraryBase.jspreadsheet.isMouseAction = false : libraryBase.jspreadsheet.isMouseAction = true;
      } else libraryBase.jspreadsheet.isMouseAction = false;
    }, mouseMoveControls = function (e) {
      let t;
      if (t = (e = e || window.event).buttons ? e.buttons : e.button ? e.button : e.which, t || (libraryBase.jspreadsheet.isMouseAction = false), libraryBase.jspreadsheet.current) if (1 == libraryBase.jspreadsheet.isMouseAction) {
        if (libraryBase.jspreadsheet.current.resizing) if (libraryBase.jspreadsheet.current.resizing.column) {
          const t = e.pageX - libraryBase.jspreadsheet.current.resizing.mousePosition;
          if (libraryBase.jspreadsheet.current.resizing.width + t > 0) {
            const e = libraryBase.jspreadsheet.current.resizing.width + t;
            libraryBase.jspreadsheet.current.cols[libraryBase.jspreadsheet.current.resizing.column].colElement.setAttribute("width", e), selection.Aq.call(libraryBase.jspreadsheet.current);
          }
        } else {
          const t = e.pageY - libraryBase.jspreadsheet.current.resizing.mousePosition;
          if (libraryBase.jspreadsheet.current.resizing.height + t > 0) {
            const e = libraryBase.jspreadsheet.current.resizing.height + t;
            libraryBase.jspreadsheet.current.rows[libraryBase.jspreadsheet.current.resizing.row].element.setAttribute("height", e), selection.Aq.call(libraryBase.jspreadsheet.current);
          }
        } else if (libraryBase.jspreadsheet.current.dragging) if (libraryBase.jspreadsheet.current.dragging.column) {
          const t = e.target.getAttribute("data-x");
          if (t) if (merges.Lt.call(libraryBase.jspreadsheet.current, t).length) console.error("Jspreadsheet: This column is part of a merged cell."); else {
            for (let e = 0; e < libraryBase.jspreadsheet.current.headers.length; e++) libraryBase.jspreadsheet.current.headers[e].classList.remove("dragging-left"), libraryBase.jspreadsheet.current.headers[e].classList.remove("dragging-right");
            libraryBase.jspreadsheet.current.dragging.column == t ? libraryBase.jspreadsheet.current.dragging.destination = parseInt(t) : e.target.clientWidth / 2 > e.offsetX ? (libraryBase.jspreadsheet.current.dragging.column < t ? libraryBase.jspreadsheet.current.dragging.destination = parseInt(t) - 1 : libraryBase.jspreadsheet.current.dragging.destination = parseInt(t), libraryBase.jspreadsheet.current.headers[t].classList.add("dragging-left")) : (libraryBase.jspreadsheet.current.dragging.column < t ? libraryBase.jspreadsheet.current.dragging.destination = parseInt(t) : libraryBase.jspreadsheet.current.dragging.destination = parseInt(t) + 1, libraryBase.jspreadsheet.current.headers[t].classList.add("dragging-right"));
          }
        } else {
          const t = e.target.getAttribute("data-y");
          if (t) if (merges.D0.call(libraryBase.jspreadsheet.current, t).length) console.error("Jspreadsheet: This row is part of a merged cell."); else {
            const t = e.target.clientHeight / 2 > e.offsetY ? e.target.parentNode.nextSibling : e.target.parentNode;
            libraryBase.jspreadsheet.current.dragging.element != t && (e.target.parentNode.parentNode.insertBefore(libraryBase.jspreadsheet.current.dragging.element, t), libraryBase.jspreadsheet.current.dragging.destination = Array.prototype.indexOf.call(libraryBase.jspreadsheet.current.dragging.element.parentNode.children, libraryBase.jspreadsheet.current.dragging.element));
          }
        }
      } else {
        const t = e.target.getAttribute("data-x"), s = e.target.getAttribute("data-y"), n = e.target.getBoundingClientRect();
        libraryBase.jspreadsheet.current.cursor && (libraryBase.jspreadsheet.current.cursor.style.cursor = "", libraryBase.jspreadsheet.current.cursor = null), e.target.parentNode.parentNode && e.target.parentNode.parentNode.className && (e.target.parentNode.parentNode.classList.contains("resizable") && (e.target && t && !s && n.width - (e.clientX - n.left) < 6 ? (libraryBase.jspreadsheet.current.cursor = e.target, libraryBase.jspreadsheet.current.cursor.style.cursor = "col-resize") : e.target && !t && s && n.height - (e.clientY - n.top) < 6 && (libraryBase.jspreadsheet.current.cursor = e.target, libraryBase.jspreadsheet.current.cursor.style.cursor = "row-resize")), e.target.parentNode.parentNode.classList.contains("draggable") && (e.target && !t && s && n.width - (e.clientX - n.left) < 6 || e.target && t && !s && n.height - (e.clientY - n.top) < 6) && (libraryBase.jspreadsheet.current.cursor = e.target, libraryBase.jspreadsheet.current.cursor.style.cursor = "move"));
      }
    }, updateCopySelection = function (e, t) {
      const s = this;
      selection.gG.call(s);
      const n = s.selectedContainer[0], o = s.selectedContainer[1], r = s.selectedContainer[2], l = s.selectedContainer[3];
      if (null != e && null != t) {
        let i, a, c, d;
        e - r > 0 ? (i = parseInt(r) + 1, a = parseInt(e)) : (i = parseInt(e), a = parseInt(n) - 1), t - l > 0 ? (c = parseInt(l) + 1, d = parseInt(t)) : (c = parseInt(t), d = parseInt(o) - 1), a - i <= d - c ? (i = parseInt(n), a = parseInt(r)) : (c = parseInt(o), d = parseInt(l));
        for (let e = c; e <= d; e++) for (let t = i; t <= a; t++) s.records[e][t] && "none" != s.rows[e].element.style.display && "none" != s.records[e][t].element.style.display && (s.records[e][t].element.classList.add("selection"), s.records[c][t].element.classList.add("selection-top"), s.records[d][t].element.classList.add("selection-bottom"), s.records[e][i].element.classList.add("selection-left"), s.records[e][a].element.classList.add("selection-right"), s.selection.push(s.records[e][t].element));
      }
    }, mouseOverControls = function (e) {
      let t;
      if (t = (e = e || window.event).buttons ? e.buttons : e.button ? e.button : e.which, t || (libraryBase.jspreadsheet.isMouseAction = false), libraryBase.jspreadsheet.current && 1 == libraryBase.jspreadsheet.isMouseAction) {
        const t = getElement(e.target);
        if (t[0]) {
          if (libraryBase.jspreadsheet.current != t[0].jssWorksheet && libraryBase.jspreadsheet.current) return false;
          let s = e.target.getAttribute("data-x");
          const n = e.target.getAttribute("data-y");
          if (libraryBase.jspreadsheet.current.resizing || libraryBase.jspreadsheet.current.dragging) ; else {
            if (1 == t[1] && libraryBase.jspreadsheet.current.selectedHeader) {
              s = e.target.getAttribute("data-x");
              const t = libraryBase.jspreadsheet.current.selectedHeader, n = s;
              selection.AH.call(libraryBase.jspreadsheet.current, t, 0, n, libraryBase.jspreadsheet.current.options.data.length - 1, e);
            }
            if (2 == t[1]) if (e.target.classList.contains("jss_row")) {
              if (null != libraryBase.jspreadsheet.current.selectedRow) {
                const t = libraryBase.jspreadsheet.current.selectedRow, s = n;
                selection.AH.call(libraryBase.jspreadsheet.current, 0, t, libraryBase.jspreadsheet.current.options.data[0].length - 1, s, e);
              }
            } else libraryBase.jspreadsheet.current.edition || s && n && (libraryBase.jspreadsheet.current.selectedCorner ? updateCopySelection.call(libraryBase.jspreadsheet.current, s, n) : libraryBase.jspreadsheet.current.selectedCell && selection.AH.call(libraryBase.jspreadsheet.current, libraryBase.jspreadsheet.current.selectedCell[0], libraryBase.jspreadsheet.current.selectedCell[1], s, n, e));
          }
        }
      }
      libraryBase.jspreadsheet.timeControl && (clearTimeout(libraryBase.jspreadsheet.timeControl), libraryBase.jspreadsheet.timeControl = null);
    }, doubleClickControls = function (e) {
      if (libraryBase.jspreadsheet.current) if (e.target.classList.contains("jss_corner")) {
        if (libraryBase.jspreadsheet.current.highlighted.length > 0) {
          const e = libraryBase.jspreadsheet.current.highlighted[0].element.getAttribute("data-x"), t = parseInt(libraryBase.jspreadsheet.current.highlighted[libraryBase.jspreadsheet.current.highlighted.length - 1].element.getAttribute("data-y")) + 1, s = libraryBase.jspreadsheet.current.highlighted[libraryBase.jspreadsheet.current.highlighted.length - 1].element.getAttribute("data-x"), n = libraryBase.jspreadsheet.current.records.length - 1;
          selection.kF.call(libraryBase.jspreadsheet.current, libraryBase.jspreadsheet.current.records[t][e].element, libraryBase.jspreadsheet.current.records[n][s].element);
        }
      } else if (e.target.classList.contains("jss_column_filter")) {
        const t = e.target.getAttribute("data-x");
        filter.N$.call(libraryBase.jspreadsheet.current, t);
      } else {
        const t = getElement(e.target);
        if (1 == t[1] && 0 != libraryBase.jspreadsheet.current.options.columnSorting) {
          const t = e.target.getAttribute("data-x");
          t && libraryBase.jspreadsheet.current.orderBy(parseInt(t));
        }
        if (2 == t[1] && 0 != libraryBase.jspreadsheet.current.options.editable && !libraryBase.jspreadsheet.current.edition) {
          const t = function (e) {
            if (e.parentNode) {
              const s = e.getAttribute("data-x"), n = e.getAttribute("data-y");
              return s && n ? e : t(e.parentNode);
            }
          }, s = t(e.target);
          s && s.classList.contains("highlight") && openEditor.call(libraryBase.jspreadsheet.current, s, undefined, e);
        }
      }
    }, pasteControls = function (e) {
      libraryBase.jspreadsheet.current && libraryBase.jspreadsheet.current.selectedCell && (libraryBase.jspreadsheet.current.edition || 0 != libraryBase.jspreadsheet.current.options.editable && (e && e.clipboardData ? (paste.call(libraryBase.jspreadsheet.current, libraryBase.jspreadsheet.current.selectedCell[0], libraryBase.jspreadsheet.current.selectedCell[1], e.clipboardData.getData("text")), e.preventDefault()) : window.clipboardData && paste.call(libraryBase.jspreadsheet.current, libraryBase.jspreadsheet.current.selectedCell[0], libraryBase.jspreadsheet.current.selectedCell[1], window.clipboardData.getData("text"))));
    }, getRole = function (e) {
      if (e.classList.contains("jss_selectall")) return "select-all";
      if (e.classList.contains("jss_corner")) return "fill-handle";
      let t = e;
      for (; !t.classList.contains("jss_spreadsheet");) {
        if (t.classList.contains("jss_row")) return "row";
        if (t.classList.contains("jss_nested")) return "nested";
        if (t.classList.contains("jtabs-headers")) return "tabs";
        if (t.classList.contains("jtoolbar")) return "toolbar";
        if (t.classList.contains("jss_pagination")) return "pagination";
        if ("TBODY" === t.tagName) return "cell";
        if ("TFOOT" === t.tagName) return 0 === getElementIndex(e) ? "grid" : "footer";
        if ("THEAD" === t.tagName) return "header";
        t = t.parentElement;
      }
      return "applications";
    }, defaultContextMenu = function (e, t, s, n) {
      const o = [];
      if ("header" === n && (0 != e.options.allowInsertColumn && o.push({title: jSuites.translate("Insert a new column before"), onclick: function () {
        e.insertColumn(1, parseInt(t), 1);
      }}), 0 != e.options.allowInsertColumn && o.push({title: jSuites.translate("Insert a new column after"), onclick: function () {
        e.insertColumn(1, parseInt(t), 0);
      }}), 0 != e.options.allowDeleteColumn && o.push({title: jSuites.translate("Delete selected columns"), onclick: function () {
        e.deleteColumn(e.getSelectedColumns().length ? undefined : parseInt(t));
      }}), 0 != e.options.allowRenameColumn && o.push({title: jSuites.translate("Rename this column"), onclick: function () {
        const s = e.getHeader(t), n = prompt(jSuites.translate("Column name"), s);
        e.setHeader(t, n);
      }}), 0 != e.options.columnSorting && (o.push({type: "line"}), o.push({title: jSuites.translate("Order ascending"), onclick: function () {
        e.orderBy(t, 0);
      }}), o.push({title: jSuites.translate("Order descending"), onclick: function () {
        e.orderBy(t, 1);
      }}))), "row" !== n && "cell" !== n || (0 != e.options.allowInsertRow && (o.push({title: jSuites.translate("Insert a new row before"), onclick: function () {
        e.insertRow(1, parseInt(s), 1);
      }}), o.push({title: jSuites.translate("Insert a new row after"), onclick: function () {
        e.insertRow(1, parseInt(s));
      }})), 0 != e.options.allowDeleteRow && o.push({title: jSuites.translate("Delete selected rows"), onclick: function () {
        e.deleteRow(e.getSelectedRows().length ? undefined : parseInt(s));
      }})), "cell" === n && 0 != e.options.allowComments) {
        o.push({type: "line"});
        const n = e.records[s][t].element.getAttribute("title") || "";
        o.push({title: jSuites.translate(n ? "Edit comments" : "Add comments"), onclick: function () {
          const o = prompt(jSuites.translate("Comments"), n);
          o && e.setComments((0, helpers.getCellNameFromCoords)(t, s), o);
        }}), n && o.push({title: jSuites.translate("Clear comments"), onclick: function () {
          e.setComments((0, helpers.getCellNameFromCoords)(t, s), "");
        }});
      }
      return 0 !== o.length && o.push({type: "line"}), "header" !== n && "row" !== n && "cell" !== n || (o.push({title: jSuites.translate("Copy") + "...", shortcut: "Ctrl + C", onclick: function () {
        copy.call(e, true);
      }}), navigator && navigator.clipboard && o.push({title: jSuites.translate("Paste") + "...", shortcut: "Ctrl + V", onclick: function () {
        e.selectedCell && navigator.clipboard.readText().then(function (t) {
          t && paste.call(e, e.selectedCell[0], e.selectedCell[1], t);
        });
      }})), 0 != e.parent.config.allowExport && o.push({title: jSuites.translate("Save as") + "...", shortcut: "Ctrl + S", onclick: function () {
        e.download();
      }}), 0 != e.parent.config.about && o.push({title: jSuites.translate("About"), onclick: function () {
        undefined === e.parent.config.about || true === e.parent.config.about ? alert(version.print()) : alert(e.parent.config.about);
      }}), o;
    }, getElementIndex = function (e) {
      const t = e.parentElement.children;
      for (let s = 0; s < t.length; s++) if (e === t[s]) return s;
      return -1;
    }, contextMenuControls = function (e) {
      if ("buttons" in (e = e || window.event) ? e.buttons : e.which || e.button, libraryBase.jspreadsheet.current) {
        const t = libraryBase.jspreadsheet.current.parent;
        if (libraryBase.jspreadsheet.current.edition) e.preventDefault(); else if (t.contextMenu.contextmenu.close(), libraryBase.jspreadsheet.current) {
          const s = getRole(e.target);
          let n = null, o = null;
          if ("cell" === s) {
            let t = e.target;
            for (; "TD" !== t.tagName;) t = t.parentNode;
            o = t.getAttribute("data-y"), n = t.getAttribute("data-x"), (!libraryBase.jspreadsheet.current.selectedCell || n < parseInt(libraryBase.jspreadsheet.current.selectedCell[0]) || n > parseInt(libraryBase.jspreadsheet.current.selectedCell[2]) || o < parseInt(libraryBase.jspreadsheet.current.selectedCell[1]) || o > parseInt(libraryBase.jspreadsheet.current.selectedCell[3])) && selection.AH.call(libraryBase.jspreadsheet.current, n, o, n, o, e);
          } else if ("row" === s || "header" === s) "row" === s ? o = e.target.getAttribute("data-y") : n = e.target.getAttribute("data-x"), (!libraryBase.jspreadsheet.current.selectedCell || n < parseInt(libraryBase.jspreadsheet.current.selectedCell[0]) || n > parseInt(libraryBase.jspreadsheet.current.selectedCell[2]) || o < parseInt(libraryBase.jspreadsheet.current.selectedCell[1]) || o > parseInt(libraryBase.jspreadsheet.current.selectedCell[3])) && selection.AH.call(libraryBase.jspreadsheet.current, n, o, n, o, e); else if ("nested" === s) {
            const t = e.target.getAttribute("data-column").split(",");
            n = getElementIndex(e.target) - 1, o = getElementIndex(e.target.parentElement), libraryBase.jspreadsheet.current.selectedCell && t[0] == parseInt(libraryBase.jspreadsheet.current.selectedCell[0]) && t[t.length - 1] == parseInt(libraryBase.jspreadsheet.current.selectedCell[2]) && null == libraryBase.jspreadsheet.current.selectedCell[1] && null == libraryBase.jspreadsheet.current.selectedCell[3] || selection.AH.call(libraryBase.jspreadsheet.current, t[0], null, t[t.length - 1], null, e);
          } else "select-all" === s ? selection.Ub.call(libraryBase.jspreadsheet.current) : "tabs" === s ? n = getElementIndex(e.target) : "footer" === s && (n = getElementIndex(e.target) - 1, o = getElementIndex(e.target.parentElement));
          let r = defaultContextMenu(libraryBase.jspreadsheet.current, parseInt(n), parseInt(o), s);
          if ("function" == typeof t.config.contextMenu) {
            const l = t.config.contextMenu(libraryBase.jspreadsheet.current, n, o, e, r, s, n, o);
            if (l) r = l; else if (false === l) return;
          }
          "object" == typeof t.plugins && Object.entries(t.plugins).forEach(function ([, t]) {
            if ("function" == typeof t.contextMenu) {
              const l = t.contextMenu(libraryBase.jspreadsheet.current, null !== n ? parseInt(n) : null, null !== o ? parseInt(o) : null, e, r, s, null !== n ? parseInt(n) : null, null !== o ? parseInt(o) : null);
              l && (r = l);
            }
          }), t.contextMenu.contextmenu.open(e, r), e.preventDefault();
        }
      }
    }, touchStartControls = function (e) {
      const t = getElement(e.target);
      if (t[0] ? libraryBase.jspreadsheet.current != t[0].jssWorksheet && (libraryBase.jspreadsheet.current && libraryBase.jspreadsheet.current.resetSelection(), libraryBase.jspreadsheet.current = t[0].jssWorksheet) : libraryBase.jspreadsheet.current && (libraryBase.jspreadsheet.current.resetSelection(), libraryBase.jspreadsheet.current = null), libraryBase.jspreadsheet.current && !libraryBase.jspreadsheet.current.edition) {
        const t = e.target.getAttribute("data-x"), s = e.target.getAttribute("data-y");
        t && s && (selection.AH.call(libraryBase.jspreadsheet.current, t, s, undefined, undefined, e), libraryBase.jspreadsheet.timeControl = setTimeout(function () {
          "color" == libraryBase.jspreadsheet.current.options.columns[t].type ? libraryBase.jspreadsheet.tmpElement = null : libraryBase.jspreadsheet.tmpElement = e.target, openEditor.call(libraryBase.jspreadsheet.current, e.target, false, e);
        }, 500));
      }
    }, touchEndControls = function (e) {
      libraryBase.jspreadsheet.timeControl && (clearTimeout(libraryBase.jspreadsheet.timeControl), libraryBase.jspreadsheet.timeControl = null, libraryBase.jspreadsheet.tmpElement && "INPUT" == libraryBase.jspreadsheet.tmpElement.children[0].tagName && libraryBase.jspreadsheet.tmpElement.children[0].focus(), libraryBase.jspreadsheet.tmpElement = null);
    }, cutControls = function (e) {
      libraryBase.jspreadsheet.current && (libraryBase.jspreadsheet.current.edition || (copy.call(libraryBase.jspreadsheet.current, true, undefined, undefined, undefined, undefined, true), 0 != libraryBase.jspreadsheet.current.options.editable && libraryBase.jspreadsheet.current.setValue(libraryBase.jspreadsheet.current.highlighted.map(function (e) {
        return e.element;
      }), "")));
    }, copyControls = function (e) {
      libraryBase.jspreadsheet.current && copyControls.enabled && (libraryBase.jspreadsheet.current.edition || copy.call(libraryBase.jspreadsheet.current, true));
    }, isCtrl = function (e) {
      return navigator.platform.toUpperCase().indexOf("MAC") >= 0 ? e.metaKey : e.ctrlKey;
    }, keyDownControls = function (e) {
      if (libraryBase.jspreadsheet.current) {
        if (libraryBase.jspreadsheet.current.edition) if (27 == e.which) libraryBase.jspreadsheet.current.edition && closeEditor.call(libraryBase.jspreadsheet.current, libraryBase.jspreadsheet.current.edition[0], false), e.preventDefault(); else if (13 == e.which) if (libraryBase.jspreadsheet.current.options.columns && libraryBase.jspreadsheet.current.options.columns[libraryBase.jspreadsheet.current.edition[2]] && "calendar" == libraryBase.jspreadsheet.current.options.columns[libraryBase.jspreadsheet.current.edition[2]].type) closeEditor.call(libraryBase.jspreadsheet.current, libraryBase.jspreadsheet.current.edition[0], true); else if (libraryBase.jspreadsheet.current.options.columns && libraryBase.jspreadsheet.current.options.columns[libraryBase.jspreadsheet.current.edition[2]] && "dropdown" == libraryBase.jspreadsheet.current.options.columns[libraryBase.jspreadsheet.current.edition[2]].type) ; else if ((1 == libraryBase.jspreadsheet.current.options.wordWrap || libraryBase.jspreadsheet.current.options.columns && libraryBase.jspreadsheet.current.options.columns[libraryBase.jspreadsheet.current.edition[2]] && 1 == libraryBase.jspreadsheet.current.options.columns[libraryBase.jspreadsheet.current.edition[2]].wordWrap || libraryBase.jspreadsheet.current.options.data[libraryBase.jspreadsheet.current.edition[3]][libraryBase.jspreadsheet.current.edition[2]] && libraryBase.jspreadsheet.current.options.data[libraryBase.jspreadsheet.current.edition[3]][libraryBase.jspreadsheet.current.edition[2]].length > 200) && e.altKey) {
          const e = libraryBase.jspreadsheet.current.edition[0].children[0];
          let t = libraryBase.jspreadsheet.current.edition[0].children[0].value;
          const s = e.selectionStart;
          t = t.slice(0, s) + "\n" + t.slice(s), e.value = t, e.focus(), e.selectionStart = s + 1, e.selectionEnd = s + 1;
        } else libraryBase.jspreadsheet.current.edition[0].children[0].blur(); else 9 == e.which && (libraryBase.jspreadsheet.current.options.columns && libraryBase.jspreadsheet.current.options.columns[libraryBase.jspreadsheet.current.edition[2]] && ["calendar", "html"].includes(libraryBase.jspreadsheet.current.options.columns[libraryBase.jspreadsheet.current.edition[2]].type) ? closeEditor.call(libraryBase.jspreadsheet.current, libraryBase.jspreadsheet.current.edition[0], true) : libraryBase.jspreadsheet.current.edition[0].children[0].blur());
        if (!libraryBase.jspreadsheet.current.edition && libraryBase.jspreadsheet.current.selectedCell) if (37 == e.which) left.call(libraryBase.jspreadsheet.current, e.shiftKey, e.ctrlKey), e.preventDefault(); else if (39 == e.which) right.call(libraryBase.jspreadsheet.current, e.shiftKey, e.ctrlKey), e.preventDefault(); else if (38 == e.which) up.call(libraryBase.jspreadsheet.current, e.shiftKey, e.ctrlKey), e.preventDefault(); else if (40 == e.which) down.call(libraryBase.jspreadsheet.current, e.shiftKey, e.ctrlKey), e.preventDefault(); else if (36 == e.which) first.call(libraryBase.jspreadsheet.current, e.shiftKey, e.ctrlKey), e.preventDefault(); else if (35 == e.which) last.call(libraryBase.jspreadsheet.current, e.shiftKey, e.ctrlKey), e.preventDefault(); else if (46 == e.which || 8 == e.which) 0 != libraryBase.jspreadsheet.current.options.editable && (null != libraryBase.jspreadsheet.current.selectedRow ? 0 != libraryBase.jspreadsheet.current.options.allowDeleteRow && confirm(jSuites.translate("Are you sure to delete the selected rows?")) && libraryBase.jspreadsheet.current.deleteRow() : libraryBase.jspreadsheet.current.selectedHeader ? 0 != libraryBase.jspreadsheet.current.options.allowDeleteColumn && confirm(jSuites.translate("Are you sure to delete the selected columns?")) && libraryBase.jspreadsheet.current.deleteColumn() : libraryBase.jspreadsheet.current.setValue(libraryBase.jspreadsheet.current.highlighted.map(function (e) {
          return e.element;
        }), "")); else if (13 == e.which) e.shiftKey ? up.call(libraryBase.jspreadsheet.current) : (0 != libraryBase.jspreadsheet.current.options.allowInsertRow && 0 != libraryBase.jspreadsheet.current.options.allowManualInsertRow && libraryBase.jspreadsheet.current.selectedCell[1] == libraryBase.jspreadsheet.current.options.data.length - 1 && libraryBase.jspreadsheet.current.insertRow(), down.call(libraryBase.jspreadsheet.current)), e.preventDefault(); else if (9 == e.which) e.shiftKey ? left.call(libraryBase.jspreadsheet.current) : (0 != libraryBase.jspreadsheet.current.options.allowInsertColumn && 0 != libraryBase.jspreadsheet.current.options.allowManualInsertColumn && libraryBase.jspreadsheet.current.selectedCell[0] == libraryBase.jspreadsheet.current.options.data[0].length - 1 && libraryBase.jspreadsheet.current.insertColumn(), right.call(libraryBase.jspreadsheet.current)), e.preventDefault(); else if (!e.ctrlKey && !e.metaKey || e.shiftKey) {
          if (libraryBase.jspreadsheet.current.selectedCell && 0 != libraryBase.jspreadsheet.current.options.editable) {
            const t = libraryBase.jspreadsheet.current.selectedCell[1], s = libraryBase.jspreadsheet.current.selectedCell[0];
            32 == e.keyCode ? (e.preventDefault(), "checkbox" == libraryBase.jspreadsheet.current.options.columns[s].type || "radio" == libraryBase.jspreadsheet.current.options.columns[s].type ? setCheckRadioValue.call(libraryBase.jspreadsheet.current) : openEditor.call(libraryBase.jspreadsheet.current, libraryBase.jspreadsheet.current.records[t][s].element, true, e)) : 113 == e.keyCode ? openEditor.call(libraryBase.jspreadsheet.current, libraryBase.jspreadsheet.current.records[t][s].element, false, e) : 1 !== e.key.length && "Process" !== e.key || e.altKey || isCtrl(e) || (openEditor.call(libraryBase.jspreadsheet.current, libraryBase.jspreadsheet.current.records[t][s].element, true, e), libraryBase.jspreadsheet.current.options.columns && libraryBase.jspreadsheet.current.options.columns[s] && "calendar" == libraryBase.jspreadsheet.current.options.columns[s].type && e.preventDefault());
          }
        } else 65 == e.which ? (selection.Ub.call(libraryBase.jspreadsheet.current), e.preventDefault()) : 83 == e.which ? (libraryBase.jspreadsheet.current.download(), e.preventDefault()) : 89 == e.which ? (libraryBase.jspreadsheet.current.redo(), e.preventDefault()) : 90 == e.which ? (libraryBase.jspreadsheet.current.undo(), e.preventDefault()) : 67 == e.which ? (copy.call(libraryBase.jspreadsheet.current, true), e.preventDefault()) : 88 == e.which ? (0 != libraryBase.jspreadsheet.current.options.editable ? cutControls() : copyControls(), e.preventDefault()) : 86 == e.which && pasteControls(); else e.target.classList.contains("jss_search") && (libraryBase.jspreadsheet.timeControl && clearTimeout(libraryBase.jspreadsheet.timeControl), libraryBase.jspreadsheet.timeControl = setTimeout(function () {
          libraryBase.jspreadsheet.current.search(e.target.value);
        }, 200));
      }
    }, wheelControls = function (e) {
      const t = this;
      1 == t.options.lazyLoading && null == libraryBase.jspreadsheet.timeControlLoading && (libraryBase.jspreadsheet.timeControlLoading = setTimeout(function () {
        t.content.scrollTop + t.content.clientHeight >= t.content.scrollHeight - 10 ? lazyLoading.p6.call(t) && (t.content.scrollTop + t.content.clientHeight > t.content.scrollHeight - 10 && (t.content.scrollTop = t.content.scrollTop - t.content.clientHeight), selection.Aq.call(t)) : t.content.scrollTop <= t.content.clientHeight && lazyLoading.G_.call(t) && (t.content.scrollTop < 10 && (t.content.scrollTop = t.content.scrollTop + t.content.clientHeight), selection.Aq.call(t)), libraryBase.jspreadsheet.timeControlLoading = null;
      }, 100));
    };
    let scrollLeft = 0;
    const updateFreezePosition = function () {
      const e = this;
      scrollLeft = e.content.scrollLeft;
      let t = 0;
      if (scrollLeft > 50) for (let s = 0; s < e.options.freezeColumns; s++) {
        if (s > 0 && (!e.options.columns || !e.options.columns[s - 1] || "hidden" !== e.options.columns[s - 1].type)) {
          let n;
          n = e.options.columns && e.options.columns[s - 1] && undefined !== e.options.columns[s - 1].width ? parseInt(e.options.columns[s - 1].width) : undefined !== e.options.defaultColWidth ? parseInt(e.options.defaultColWidth) : 100, t += parseInt(n);
        }
        e.headers[s].classList.add("jss_freezed"), e.headers[s].style.left = t + "px";
        for (let t = 0; t < e.rows.length; t++) if (e.rows[t] && e.records[t][s]) {
          const n = scrollLeft + (s > 0 ? e.records[t][s - 1].element.style.width : 0) - 51 + "px";
          e.records[t][s].element.classList.add("jss_freezed"), e.records[t][s].element.style.left = n;
        }
      } else for (let t = 0; t < e.options.freezeColumns; t++) {
        e.headers[t].classList.remove("jss_freezed"), e.headers[t].style.left = "";
        for (let s = 0; s < e.rows.length; s++) e.records[s][t] && (e.records[s][t].element.classList.remove("jss_freezed"), e.records[s][t].element.style.left = "");
      }
      selection.Aq.call(e);
    }, scrollControls = function (e) {
      const t = this;
      wheelControls.call(t), t.options.freezeColumns > 0 && t.content.scrollLeft != scrollLeft && updateFreezePosition.call(t), 1 != t.options.lazyLoading && 1 != t.options.tableOverflow || t.edition && "jdropdown" != e.target.className.substr(0, 9) && closeEditor.call(t, t.edition[0], true);
    }, setEvents = function (e) {
      destroyEvents(e), e.addEventListener("mouseup", mouseUpControls), e.addEventListener("mousedown", mouseDownControls), e.addEventListener("mousemove", mouseMoveControls), e.addEventListener("mouseover", mouseOverControls), e.addEventListener("dblclick", doubleClickControls), e.addEventListener("paste", pasteControls), e.addEventListener("contextmenu", contextMenuControls), e.addEventListener("touchstart", touchStartControls), e.addEventListener("touchend", touchEndControls), e.addEventListener("touchcancel", touchEndControls), e.addEventListener("touchmove", touchEndControls), document.addEventListener("keydown", keyDownControls);
    }, destroyEvents = function (e) {
      e.removeEventListener("mouseup", mouseUpControls), e.removeEventListener("mousedown", mouseDownControls), e.removeEventListener("mousemove", mouseMoveControls), e.removeEventListener("mouseover", mouseOverControls), e.removeEventListener("dblclick", doubleClickControls), e.removeEventListener("paste", pasteControls), e.removeEventListener("contextmenu", contextMenuControls), e.removeEventListener("touchstart", touchStartControls), e.removeEventListener("touchend", touchEndControls), e.removeEventListener("touchcancel", touchEndControls), document.removeEventListener("keydown", keyDownControls);
    };
    var toolbar = __webpack_require__(392), pagination = __webpack_require__(167);
    const setData = function (e) {
      const t = this;
      if (e && (t.options.data = e), t.options.data || (t.options.data = []), t.options.data && t.options.data[0] && !Array.isArray(t.options.data[0])) {
        e = [];
        for (let s = 0; s < t.options.data.length; s++) {
          const n = [];
          for (let e = 0; e < t.options.columns.length; e++) n[e] = t.options.data[s][t.options.columns[e].name];
          e.push(n);
        }
        t.options.data = e;
      }
      let s = 0, n = 0;
      const o = t.options.columns && t.options.columns.length || 0, r = t.options.data.length, l = t.options.minDimensions[0], i = t.options.minDimensions[1], a = l > o ? l : o, c = i > r ? i : r;
      for (s = 0; s < c; s++) for (n = 0; n < a; n++) null == t.options.data[s] && (t.options.data[s] = []), null == t.options.data[s][n] && (t.options.data[s][n] = "");
      let d, u;
      for (t.rows = [], t.results = null, t.records = [], t.history = [], t.historyIndex = -1, t.tbody.innerHTML = "", 1 == t.options.lazyLoading ? (d = 0, u = t.options.data.length < 100 ? t.options.data.length : 100, t.options.pagination && (t.options.pagination = false, console.error("Jspreadsheet: Pagination will be disable due the lazyLoading"))) : t.options.pagination ? (t.pageNumber || (t.pageNumber = 0), t.options.pagination, d = t.options.pagination * t.pageNumber, u = t.options.pagination * t.pageNumber + t.options.pagination, t.options.data.length < u && (u = t.options.data.length)) : (d = 0, u = t.options.data.length), s = 0; s < t.options.data.length; s++) {
        const e = createRow.call(t, s, t.options.data[s]);
        s >= d && s < u && t.tbody.appendChild(e.element);
      }
      if (1 == t.options.lazyLoading || t.options.pagination && pagination.IV.call(t), t.options.mergeCells) {
        const e = Object.keys(t.options.mergeCells);
        for (let s = 0; s < e.length; s++) {
          const n = t.options.mergeCells[e[s]];
          merges.FU.call(t, e[s], n[0], n[1], 1);
        }
      }
      internal.am.call(t);
    }, getValue = function (e, t) {
      const s = this;
      let n, o;
      if ("string" != typeof e) return null;
      n = (e = (0, internalHelpers.vu)(e, true))[0], o = e[1];
      let r = null;
      return null != n && null != o && (s.records[o] && s.records[o][n] && t ? r = s.records[o][n].element.innerHTML : s.options.data[o] && "undefined" != s.options.data[o][n] && (r = s.options.data[o][n])), r;
    }, getValueFromCoords = function (e, t, s) {
      const n = this;
      let o = null;
      return null != e && null != t && (n.records[t] && n.records[t][e] && s ? o = n.records[t][e].element.innerHTML : n.options.data[t] && "undefined" != n.options.data[t][e] && (o = n.options.data[t][e])), o;
    }, setValue = function (e, t, s) {
      const n = this, o = [];
      if ("string" == typeof e) {
        const r = (0, internalHelpers.vu)(e, true), l = r[0], i = r[1];
        o.push(internal.k9.call(n, l, i, t, s)), internal.xF.call(n, l, i, o);
      } else {
        let r = null, l = null;
        if (e && e.getAttribute && (r = e.getAttribute("data-x"), l = e.getAttribute("data-y")), null != r && null != l) o.push(internal.k9.call(n, r, l, t, s)), internal.xF.call(n, r, l, o); else {
          const r = Object.keys(e);
          if (r.length > 0) for (let l = 0; l < r.length; l++) {
            let r, i;
            if ("string" == typeof e[l]) {
              const t = (0, internalHelpers.vu)(e[l], true);
              r = t[0], i = t[1];
            } else null != e[l].x && null != e[l].y ? (r = e[l].x, i = e[l].y, null != e[l].value && (t = e[l].value)) : (r = e[l].getAttribute("data-x"), i = e[l].getAttribute("data-y"));
            null != r && null != i && (o.push(internal.k9.call(n, r, i, t, s)), internal.xF.call(n, r, i, o));
          }
        }
      }
      utils_history.Dh.call(n, {action: "setValue", records: o, selection: n.selectedCell}), internal.am.call(n);
      const r = o.map(function (e) {
        return {x: e.x, y: e.y, value: e.value, oldValue: e.oldValue};
      });
      dispatch.A.call(n, "onafterchanges", n, r);
    }, setValueFromCoords = function (e, t, s, n) {
      const o = this, r = [];
      r.push(internal.k9.call(o, e, t, s, n)), internal.xF.call(o, e, t, r), utils_history.Dh.call(o, {action: "setValue", records: r, selection: o.selectedCell}), internal.am.call(o);
      const l = r.map(function (e) {
        return {x: e.x, y: e.y, value: e.value, oldValue: e.oldValue};
      });
      dispatch.A.call(o, "onafterchanges", o, l);
    }, getData = function (e, t, s, n) {
      const o = this, r = [];
      let l = 0, i = 0;
      const a = Math.max(...o.options.data.map(function (e) {
        return e.length;
      })), c = o.options.data.length;
      for (let s = 0; s < c; s++) {
        l = 0;
        for (let n = 0; n < a; n++) e && !o.records[s][n].element.classList.contains("highlight") || (r[i] || (r[i] = []), r[i][l] = t ? o.records[s][n].element.innerHTML : o.options.data[s][n], l++);
        l > 0 && i++;
      }
      return s ? r.map(function (e) {
        return e.join(s);
      }).join("\r\n") + "\r\n" : n ? r.map(function (e) {
        const t = {};
        return e.forEach(function (e, s) {
          t[s] = e;
        }), t;
      }) : r;
    }, getDataFromRange = function (e, t) {
      const s = this, n = (0, helpers.getCoordsFromRange)(e), o = [];
      for (let e = n[1]; e <= n[3]; e++) {
        o.push([]);
        for (let r = n[0]; r <= n[2]; r++) t ? o[o.length - 1].push(s.records[e][r].element.innerHTML) : o[o.length - 1].push(s.options.data[e][r]);
      }
      return o;
    }, search = function (e) {
      const t = this;
      if (t.options.filters && filter.dr.call(t), t.resetSelection(), t.pageNumber = 0, t.results = [], e) {
        t.searchInput.value !== e && (t.searchInput.value = e);
        const s = function (e, s, n) {
          for (let o = 0; o < e.length; o++) if (("" + e[o]).toLowerCase().search(s) >= 0 || ("" + t.records[n][o].element.innerHTML).toLowerCase().search(s) >= 0) return true;
          return false;
        }, n = function (e) {
          -1 == t.results.indexOf(e) && t.results.push(e);
        };
        let o = e.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
        o = new RegExp(o, "i"), t.options.data.forEach(function (e, r) {
          if (s(e, o, r)) {
            const e = merges.D0.call(t, r);
            if (e.length) for (let s = 0; s < e.length; s++) {
              const o = (0, internalHelpers.vu)(e[s], true);
              for (let r = 0; r < t.options.mergeCells[e[s]][1]; r++) n(o[1] + r);
            } else n(r);
          }
        });
      } else t.results = null;
      internal.hG.call(t);
    }, resetSearch = function () {
      const e = this;
      e.searchInput.value = "", e.search(""), e.results = null;
    }, getHeader = function (e) {
      return this.headers[e].textContent;
    }, getHeaders = function (e) {
      const t = this, s = [];
      for (let e = 0; e < t.headers.length; e++) s.push(t.getHeader(e));
      return e ? s : s.join(t.options.csvDelimiter);
    }, setHeader = function (e, t) {
      const s = this;
      if (s.headers[e]) {
        const n = s.headers[e].textContent, o = s.options.columns && s.options.columns[e] && s.options.columns[e].title || "";
        t || (t = (0, helpers.getColumnName)(e)), s.headers[e].textContent = t, s.headers[e].setAttribute("title", t), s.options.columns || (s.options.columns = []), s.options.columns[e] || (s.options.columns[e] = {}), s.options.columns[e].title = t, utils_history.Dh.call(s, {action: "setHeader", column: e, oldValue: n, newValue: t}), dispatch.A.call(s, "onchangeheader", s, parseInt(e), t, o);
      }
    }, getStyle = function (e, t) {
      const s = this;
      if (e) return e = (0, internalHelpers.vu)(e, true), t ? s.records[e[1]][e[0]].element.style[t] : s.records[e[1]][e[0]].element.getAttribute("style");
      {
        const e = {}, n = s.options.data[0].length, o = s.options.data.length;
        for (let r = 0; r < o; r++) for (let o = 0; o < n; o++) {
          const n = t ? s.records[r][o].element.style[t] : s.records[r][o].element.getAttribute("style");
          n && (e[(0, internalHelpers.t3)([o, r])] = n);
        }
        return e;
      }
    }, setStyle = function (e, t, s, n, o) {
      const r = this, l = {}, i = {}, a = function (e, t, s) {
        const o = (0, internalHelpers.vu)(e, true);
        if (r.records[o[1]] && r.records[o[1]][o[0]] && (0 == r.records[o[1]][o[0]].element.classList.contains("readonly") || n)) {
          const a = r.records[o[1]][o[0]].element.style[t];
          a != s || n ? r.records[o[1]][o[0]].element.style[t] = s : (s = "", r.records[o[1]][o[0]].element.style[t] = ""), i[e] || (i[e] = []), l[e] || (l[e] = []), i[e].push([t + ":" + a]), l[e].push([t + ":" + s]);
        }
      };
      if (t && s) "string" == typeof e && a(e, t, s); else {
        const t = Object.keys(e);
        for (let s = 0; s < t.length; s++) {
          let n = e[t[s]];
          "string" == typeof n && (n = n.split(";"));
          for (let e = 0; e < n.length; e++) "string" == typeof n[e] && (n[e] = n[e].split(":")), n[e][0].trim() && a(t[s], n[e][0].trim(), n[e][1]);
        }
      }
      let c = Object.keys(i);
      for (let e = 0; e < c.length; e++) i[c[e]] = i[c[e]].join(";");
      c = Object.keys(l);
      for (let e = 0; e < c.length; e++) l[c[e]] = l[c[e]].join(";");
      o || utils_history.Dh.call(r, {action: "setStyle", oldValue: i, newValue: l}), dispatch.A.call(r, "onchangestyle", r, l);
    }, resetStyle = function (e, t) {
      const s = this, n = Object.keys(e);
      for (let e = 0; e < n.length; e++) {
        const t = (0, internalHelpers.vu)(n[e], true);
        s.records[t[1]] && s.records[t[1]][t[0]] && s.records[t[1]][t[0]].element.setAttribute("style", "");
      }
      s.setStyle(e, null, null, null, t);
    }, download = function (e, t) {
      const s = this;
      if (0 == s.parent.config.allowExport) console.error("Export not allowed"); else {
        let n = "";
        n += copy.call(s, false, s.options.csvDelimiter, true, e, true, undefined, t);
        const o = new Blob(["﻿" + n], {type: "text/csv;charset=utf-8;"});
        if (window.navigator && window.navigator.msSaveOrOpenBlob) window.navigator.msSaveOrOpenBlob(o, (s.options.csvFileName || s.options.worksheetName) + ".csv"); else {
          const e = document.createElement("a");
          e.setAttribute("target", "_top");
          const t = URL.createObjectURL(o);
          e.href = t, e.setAttribute("download", (s.options.csvFileName || s.options.worksheetName) + ".csv"), document.body.appendChild(e), e.click(), e.parentNode.removeChild(e);
        }
      }
    }, getComments = function (e) {
      const t = this;
      if (e) return "string" != typeof e ? getComments.call(t) : (e = (0, internalHelpers.vu)(e, true), t.records[e[1]][e[0]].element.getAttribute("title") || "");
      {
        const e = {};
        for (let s = 0; s < t.options.data.length; s++) for (let n = 0; n < t.options.columns.length; n++) {
          const o = t.records[s][n].element.getAttribute("title");
          o && (e[(0, internalHelpers.t3)([n, s])] = o);
        }
        return e;
      }
    }, setComments = function (e, t) {
      const s = this;
      let n;
      n = "string" == typeof e ? {[e]: t} : e;
      const o = {};
      Object.entries(n).forEach(function ([e, t]) {
        const n = (0, helpers.getCoordsFromCellName)(e);
        o[e] = s.records[n[1]][n[0]].element.getAttribute("title"), s.records[n[1]][n[0]].element.setAttribute("title", t || ""), t ? (s.records[n[1]][n[0]].element.classList.add("jss_comments"), s.options.comments || (s.options.comments = {}), s.options.comments[e] = t) : (s.records[n[1]][n[0]].element.classList.remove("jss_comments"), s.options.comments && s.options.comments[e] && delete s.options.comments[e]);
      }), utils_history.Dh.call(s, {action: "setComments", newValue: n, oldValue: o}), dispatch.A.call(s, "oncomments", s, n, o);
    };
    var orderBy = __webpack_require__(94);
    const getWorksheetConfig = function () {
      return this.options;
    }, getSpreadsheetConfig = function () {
      return this.config;
    }, setConfig = function (e, t) {
      const s = this, n = Object.keys(e);
      let o;
      s.parent ? o = s.parent : (t = true, o = s), n.forEach(function (n) {
        t ? (o.config[n] = e[n], "toolbar" === n && (true === e[n] ? o.showToolbar() : false === e[n] && o.hideToolbar())) : s.options[n] = e[n];
      });
    };
    var meta = __webpack_require__(654);
    const setReadOnly = function (e, t) {
      const s = this;
      let n;
      if ("string" == typeof e) {
        const t = (0, helpers.getCoordsFromCellName)(e);
        n = s.records[t[1]][t[0]];
      } else {
        const t = parseInt(e.getAttribute("data-x")), o = parseInt(e.getAttribute("data-y"));
        n = s.records[o][t];
      }
      t ? n.element.classList.add("readonly") : n.element.classList.remove("readonly");
    }, isReadOnly = function (e, t) {
      if ("string" == typeof e && undefined === t) {
        const s = (0, helpers.getCoordsFromCellName)(e);
        [e, t] = s;
      }
      return this.records[t][e].element.classList.contains("readonly");
    }, setWorksheetFunctions = function (e) {
      for (let t = 0; t < worksheetPublicMethodsLength; t++) {
        const [s, n] = worksheetPublicMethods[t];
        e[s] = n.bind(e);
      }
    }, createTable = function () {
      let e = this;
      setWorksheetFunctions(e), e.table = document.createElement("table"), e.thead = document.createElement("thead"), e.tbody = document.createElement("tbody"), e.headers = [], e.cols = [], e.content = document.createElement("div"), e.content.classList.add("jss_content"), e.content.onscroll = function (t) {
        scrollControls.call(e, t);
      }, e.content.onwheel = function (t) {
        wheelControls.call(e, t);
      };
      const t = document.createElement("div"), s = document.createElement("label");
      s.innerHTML = jSuites.translate("Search") + ": ", t.appendChild(s), e.searchInput = document.createElement("input"), e.searchInput.classList.add("jss_search"), s.appendChild(e.searchInput), e.searchInput.onfocus = function () {
        e.resetSelection();
      };
      const n = document.createElement("div");
      if (e.options.pagination > 0 && e.options.paginationOptions && e.options.paginationOptions.length > 0) {
        e.paginationDropdown = document.createElement("select"), e.paginationDropdown.classList.add("jss_pagination_dropdown"), e.paginationDropdown.onchange = function () {
          e.options.pagination = parseInt(this.value), e.page(0);
        };
        for (let t = 0; t < e.options.paginationOptions.length; t++) {
          const s = document.createElement("option");
          s.value = e.options.paginationOptions[t], s.innerHTML = e.options.paginationOptions[t], e.paginationDropdown.appendChild(s);
        }
        e.paginationDropdown.value = e.options.pagination, n.appendChild(document.createTextNode(jSuites.translate("Show "))), n.appendChild(e.paginationDropdown), n.appendChild(document.createTextNode(jSuites.translate("entries")));
      }
      const o = document.createElement("div");
      o.classList.add("jss_filter"), o.appendChild(n), o.appendChild(t), e.colgroupContainer = document.createElement("colgroup");
      let r = document.createElement("col");
      if (r.setAttribute("width", "50"), e.colgroupContainer.appendChild(r), e.options.nestedHeaders && e.options.nestedHeaders.length > 0 && e.options.nestedHeaders[0] && e.options.nestedHeaders[0][0]) for (let t = 0; t < e.options.nestedHeaders.length; t++) e.thead.appendChild(internal.ju.call(e, e.options.nestedHeaders[t]));
      e.headerContainer = document.createElement("tr"), r = document.createElement("td"), r.classList.add("jss_selectall"), e.headerContainer.appendChild(r);
      const l = getNumberOfColumns.call(e);
      for (let t = 0; t < l; t++) createCellHeader.call(e, t), e.headerContainer.appendChild(e.headers[t]), e.colgroupContainer.appendChild(e.cols[t].colElement);
      if (e.thead.appendChild(e.headerContainer), 1 == e.options.filters) {
        e.filter = document.createElement("tr");
        const t = document.createElement("td");
        e.filter.appendChild(t);
        for (let t = 0; t < e.options.columns.length; t++) {
          const s = document.createElement("td");
          s.innerHTML = "&nbsp;", s.setAttribute("data-x", t), s.className = "jss_column_filter", "hidden" == e.options.columns[t].type && (s.style.display = "none"), e.filter.appendChild(s);
        }
        e.thead.appendChild(e.filter);
      }
      e.table = document.createElement("table"), e.table.classList.add("jss_worksheet"), e.table.setAttribute("cellpadding", "0"), e.table.setAttribute("cellspacing", "0"), e.table.setAttribute("unselectable", "yes"), e.table.appendChild(e.colgroupContainer), e.table.appendChild(e.thead), e.table.appendChild(e.tbody), e.options.textOverflow || e.table.classList.add("jss_overflow"), e.corner = document.createElement("div"), e.corner.className = "jss_corner", e.corner.setAttribute("unselectable", "on"), e.corner.setAttribute("onselectstart", "return false"), 0 == e.options.selectionCopy && (e.corner.style.display = "none"), e.textarea = document.createElement("textarea"), e.textarea.className = "jss_textarea", e.textarea.id = "jss_textarea", e.textarea.tabIndex = "-1", e.textarea.ariaHidden = "true";
      const i = document.createElement("a");
      i.setAttribute("href", "https://bossanova.uk/jspreadsheet/"), e.ads = document.createElement("div"), e.ads.className = "jss_about";
      const a = document.createElement("span");
      a.innerHTML = "Jspreadsheet CE", i.appendChild(a), e.ads.appendChild(i), document.createElement("div").classList.add("jss_table"), e.pagination = document.createElement("div"), e.pagination.classList.add("jss_pagination");
      const c = document.createElement("div"), d = document.createElement("div");
      if (e.pagination.appendChild(c), e.pagination.appendChild(d), e.options.pagination || (e.pagination.style.display = "none"), 1 == e.options.search && e.element.appendChild(o), e.content.appendChild(e.table), e.content.appendChild(e.corner), e.content.appendChild(e.textarea), e.element.appendChild(e.content), e.element.appendChild(e.pagination), e.element.appendChild(e.ads), e.element.classList.add("jss_container"), e.element.jssWorksheet = e, e.element.jspreadsheet = e, 1 == e.options.tableOverflow && (e.options.tableHeight && (e.content.style["overflow-y"] = "auto", e.content.style["box-shadow"] = "rgb(221 221 221) 2px 2px 5px 0.1px", e.content.style.maxHeight = "string" == typeof e.options.tableHeight ? e.options.tableHeight : e.options.tableHeight + "px"), e.options.tableWidth && (e.content.style["overflow-x"] = "auto", e.content.style.width = "string" == typeof e.options.tableWidth ? e.options.tableWidth : e.options.tableWidth + "px")), 1 != e.options.tableOverflow && e.parent.config.toolbar && e.element.classList.add("with-toolbar"), 0 != e.options.columnDrag && e.thead.classList.add("draggable"), 0 != e.options.columnResize && e.thead.classList.add("resizable"), 0 != e.options.rowDrag && e.tbody.classList.add("draggable"), 0 != e.options.rowResize && e.tbody.classList.add("resizable"), e.setData.call(e), e.options.style && (e.setStyle(e.options.style, null, null, 1, 1), delete e.options.style), Object.defineProperty(e.options, "style", {enumerable: true, configurable: true, get: () => e.getStyle()}), e.options.comments && e.setComments(e.options.comments), e.options.classes) {
        const t = Object.keys(e.options.classes);
        for (let s = 0; s < t.length; s++) {
          const n = (0, internalHelpers.vu)(t[s], true);
          e.records[n[1]][n[0]].element.classList.add(e.options.classes[t[s]]);
        }
      }
    }, prepareTable = function () {
      const e = this;
      1 == e.options.lazyLoading && 1 != e.options.tableOverflow && 1 != e.parent.config.fullscreen && (console.error("Jspreadsheet: The lazyloading only works when tableOverflow = yes or fullscreen = yes"), e.options.lazyLoading = false), e.options.columns || (e.options.columns = []);
      let t, s = e.options.columns.length;
      if (e.options.data && undefined !== e.options.data[0]) if (Array.isArray(e.options.data[0])) {
        const t = e.options.data[0].length;
        t > s && (s = t);
      } else t = Object.keys(e.options.data[0]), t.length > s && (s = t.length);
      e.options.minDimensions || (e.options.minDimensions = [0, 0]), e.options.minDimensions[0] > s && (s = e.options.minDimensions[0]);
      const n = [];
      for (let o = 0; o < s; o++) e.options.columns[o] || (e.options.columns[o] = {}), !e.options.columns[o].name && t && t[o] && (e.options.columns[o].name = t[o]), "dropdown" == e.options.columns[o].type && e.options.columns[o].url && n.push({url: e.options.columns[o].url, index: o, method: "GET", dataType: "json", success: function (t) {
        e.options.columns[this.index].source || (e.options.columns[this.index].source = []);
        for (let s = 0; s < t.length; s++) e.options.columns[this.index].source.push(t[s]);
      }});
      n.length ? jSuites.ajax(n, function () {
        createTable.call(e);
      }) : createTable.call(e);
    }, getNextDefaultWorksheetName = function (e) {
      const t = /^Sheet(\d+)$/;
      let s = 0;
      return e.worksheets.forEach(function (e) {
        const n = t.exec(e.options.worksheetName);
        n && (s = Math.max(s, parseInt(n[1])));
      }), "Sheet" + (s + 1);
    }, buildWorksheet = async function () {
      const e = this, t = (e.element, e.parent);
      "object" == typeof t.plugins && Object.entries(t.plugins).forEach(function ([, t]) {
        "function" == typeof t.beforeinit && t.beforeinit(e);
      }), libraryBase.jspreadsheet.current = e;
      const s = [];
      if (e.options.csv) {
        const t = new Promise(t => {
          jSuites.ajax({url: e.options.csv, method: "GET", dataType: "text", success: function (s) {
            const n = (0, helpers.parseCSV)(s, e.options.csvDelimiter);
            if (1 == e.options.csvHeaders && n.length > 0) {
              const t = n.shift();
              if (t.length > 0) {
                e.options.columns || (e.options.columns = []);
                for (let s = 0; s < t.length; s++) e.options.columns[s] || (e.options.columns[s] = {}), undefined === e.options.columns[s].title && (e.options.columns[s].title = t[s]);
              }
            }
            e.options.data = n, prepareTable.call(e), t();
          }});
        });
        s.push(t);
      } else if (e.options.url) {
        const t = new Promise(t => {
          jSuites.ajax({url: e.options.url, method: "GET", dataType: "json", success: function (s) {
            e.options.data = s.data ? s.data : s, prepareTable.call(e), t();
          }});
        });
        s.push(t);
      } else prepareTable.call(e);
      await Promise.all(s), "object" == typeof t.plugins && Object.entries(t.plugins).forEach(function ([, t]) {
        "function" == typeof t.init && t.init(e);
      });
    }, createWorksheetObj = function (e) {
      const t = this.parent;
      e.worksheetName || (e.worksheetName = getNextDefaultWorksheetName(this.parent));
      const s = {parent: t, options: e, filters: [], formula: [], history: [], selection: [], historyIndex: -1};
      return t.config.worksheets.push(s.options), t.worksheets.push(s), s;
    }, createWorksheet = function (e) {
      const t = this.parent;
      t.creationThroughJss = true, createWorksheetObj.call(this, e), t.element.tabs.create(e.worksheetName);
    }, openWorksheet = function (e) {
      this.parent.element.tabs.open(e);
    }, deleteWorksheet = function (e) {
      const t = this;
      t.parent.element.tabs.remove(e);
      const s = t.parent.worksheets.splice(e, 1)[0];
      dispatch.A.call(t.parent, "ondeleteworksheet", s, e);
    }, worksheetPublicMethods = [["selectAll", selection.Ub], ["updateSelectionFromCoords", function (e, t, s, n) {
      return selection.AH.call(this, e, t, s, n);
    }], ["resetSelection", function () {
      return selection.gE.call(this);
    }], ["getSelection", selection.Lo], ["getSelected", selection.ef], ["getSelectedColumns", selection.Jg], ["getSelectedRows", selection.R5], ["getData", getData], ["setData", setData], ["getValue", getValue], ["getValueFromCoords", getValueFromCoords], ["setValue", setValue], ["setValueFromCoords", setValueFromCoords], ["getWidth", getWidth], ["setWidth", function (e, t) {
      return setWidth.call(this, e, t);
    }], ["insertRow", insertRow], ["moveRow", function (e, t) {
      return moveRow.call(this, e, t);
    }], ["deleteRow", deleteRow], ["hideRow", hideRow], ["showRow", showRow], ["getRowData", getRowData], ["setRowData", setRowData], ["getHeight", getHeight], ["setHeight", function (e, t) {
      return setHeight.call(this, e, t);
    }], ["getMerge", merges.fd], ["setMerge", function (e, t, s) {
      return merges.FU.call(this, e, t, s);
    }], ["destroyMerge", function () {
      return merges.VP.call(this);
    }], ["removeMerge", function (e, t) {
      return merges.Zp.call(this, e, t);
    }], ["search", search], ["resetSearch", resetSearch], ["getHeader", getHeader], ["getHeaders", getHeaders], ["setHeader", setHeader], ["getStyle", getStyle], ["setStyle", function (e, t, s, n) {
      return setStyle.call(this, e, t, s, n);
    }], ["resetStyle", resetStyle], ["insertColumn", insertColumn], ["moveColumn", moveColumn], ["deleteColumn", deleteColumn], ["getColumnData", getColumnData], ["setColumnData", setColumnData], ["whichPage", pagination.ho], ["page", pagination.MY], ["download", download], ["getComments", getComments], ["setComments", setComments], ["orderBy", orderBy.My], ["undo", utils_history.tN], ["redo", utils_history.ZS], ["getCell", internal.tT], ["getCellFromCoords", internal.Xr], ["getLabel", internal.p9], ["getConfig", getWorksheetConfig], ["setConfig", setConfig], ["getMeta", function (e) {
      return meta.IQ.call(this, e);
    }], ["setMeta", meta.iZ], ["showColumn", showColumn], ["hideColumn", hideColumn], ["showIndex", internal.C6], ["hideIndex", internal.TI], ["getWorksheetActive", internal.$O], ["openEditor", openEditor], ["closeEditor", closeEditor], ["createWorksheet", createWorksheet], ["openWorksheet", openWorksheet], ["deleteWorksheet", deleteWorksheet], ["copy", function (e) {
      e ? cutControls() : copy.call(this, true);
    }], ["paste", paste], ["executeFormula", internal.Em], ["getDataFromRange", getDataFromRange], ["quantiyOfPages", pagination.$f], ["getRange", selection.eO], ["isSelected", selection.sp], ["setReadOnly", setReadOnly], ["isReadOnly", isReadOnly], ["getHighlighted", selection.kV], ["dispatch", dispatch.A], ["down", down], ["first", first], ["last", last], ["left", left], ["right", right], ["up", up], ["openFilter", filter.N$], ["resetFilters", filter.dr]], worksheetPublicMethodsLength = worksheetPublicMethods.length, factory = function () {}, createWorksheets = async function (e, t, s) {
      let n = t.worksheets;
      if (!n) throw new Error("JSS: worksheets are not defined");
      {
        let o = {animation: true, onbeforecreate: function (t, s) {
          return s || getNextDefaultWorksheetName(e);
        }, oncreate: function (s, n) {
          if (e.creationThroughJss) e.creationThroughJss = false; else {
            const t = s.tabs.headers.children[s.tabs.headers.children.length - 2].innerHTML;
            createWorksheetObj.call(e.worksheets[0], {minDimensions: [10, 15], worksheetName: t});
          }
          const o = e.worksheets[e.worksheets.length - 1];
          o.element = n, buildWorksheet.call(o).then(function () {
            (0, toolbar.nK)(o), dispatch.A.call(o, "oncreateworksheet", o, t, e.worksheets.length - 1);
          });
        }, onchange: function (t, s, n) {
          0 != e.worksheets.length && e.worksheets[n] && (0, toolbar.nK)(e.worksheets[n]);
        }};
        1 == t.tabs ? o.allowCreate = true : o.hideHeaders = true, o.data = [];
        let r = 1;
        for (let e = 0; e < n.length; e++) n[e].worksheetName || (n[e].worksheetName = "Sheet" + r++), o.data.push({title: n[e].worksheetName, content: ""});
        s.classList.add("jss_spreadsheet"), s.tabIndex = 0;
        const l = jSuites.tabs(s, o), i = t.style;
        delete t.style;
        for (let t = 0; t < n.length; t++) n[t].style && Object.entries(n[t].style).forEach(function ([e, s]) {
          "number" == typeof s && (n[t].style[e] = i[s]);
        }), e.worksheets.push({parent: e, element: l.content.children[t], options: n[t], filters: [], formula: [], history: [], selection: [], historyIndex: -1}), await buildWorksheet.call(e.worksheets[t]);
      }
    };
    factory.spreadsheet = async function (e, t, s) {
      if ("TABLE" == e.tagName) {
        t || (t = {}), t.worksheets || (t.worksheets = []);
        const s = (0, helpers.createFromTable)(e, t.worksheets[0]);
        t.worksheets[0] = s;
        const n = document.createElement("div");
        e.parentNode.insertBefore(n, e), e.remove(), e = n;
      }
      let n = {worksheets: s, config: t, element: e, el: e};
      return n.contextMenu = document.createElement("div"), n.contextMenu.className = "jss_contextmenu", n.getWorksheetActive = internal.$O.bind(n), n.fullscreen = internal.Y5.bind(n), n.showToolbar = toolbar.ll.bind(n), n.hideToolbar = toolbar.Ar.bind(n), n.getConfig = getSpreadsheetConfig.bind(n), n.setConfig = setConfig.bind(n), n.setPlugins = function (e) {
        n.plugins || (n.plugins = {}), "object" == typeof e && Object.entries(e).forEach(function ([e, t]) {
          n.plugins[e] = t.call(libraryBase.jspreadsheet, n, {}, n.config);
        });
      }, n.setPlugins(t.plugins), await createWorksheets(n, t, e), n.element.appendChild(n.contextMenu), jSuites.contextmenu(n.contextMenu, {onclick: function () {
        n.contextMenu.contextmenu.close(false);
      }}), 1 == n.config.fullscreen && n.element.classList.add("fullscreen"), toolbar.ll.call(n), t.root ? setEvents(t.root) : setEvents(document), e.spreadsheet = n, n;
    }, factory.worksheet = function (e, t, s) {
      let n = {parent: e, options: {}};
      return undefined === s ? e.worksheets.push(n) : e.worksheets.splice(s, 0, n), Object.assign(n.options, t), n;
    };
    var utils_factory = factory;
    libraryBase.jspreadsheet = function (e, t) {
      try {
        let s = [];
        return utils_factory.spreadsheet(e, t, s).then(e => {
          libraryBase.jspreadsheet.spreadsheet.push(e), dispatch.A.call(e, "onload", e);
        }), s;
      } catch (e) {
        console.error(e);
      }
    }, libraryBase.jspreadsheet.getWorksheetInstanceByName = function (e, t) {
      const s = libraryBase.jspreadsheet.spreadsheet.find(e => e.config.namespace === t);
      if (s) return {};
      if (null == e) {
        const e = s.worksheets.map(e => [e.options.worksheetName, e]);
        return Object.fromEntries(e);
      }
      return s.worksheets.find(t => t.options.worksheetName === e);
    }, libraryBase.jspreadsheet.setDictionary = function (e) {
      jSuites.setDictionary(e);
    }, libraryBase.jspreadsheet.destroy = function (e, t) {
      if (e.spreadsheet) {
        const s = libraryBase.jspreadsheet.spreadsheet.indexOf(e.spreadsheet);
        libraryBase.jspreadsheet.spreadsheet.splice(s, 1);
        const n = e.spreadsheet.config.root || document;
        e.spreadsheet = null, e.innerHTML = "", t && destroyEvents(n);
      }
    }, libraryBase.jspreadsheet.destroyAll = function () {
      for (let e = 0; e < libraryBase.jspreadsheet.spreadsheet.length; e++) {
        const t = libraryBase.jspreadsheet.spreadsheet[e];
        libraryBase.jspreadsheet.destroy(t.element);
      }
    }, libraryBase.jspreadsheet.current = null, libraryBase.jspreadsheet.spreadsheet = [], libraryBase.jspreadsheet.helpers = {}, libraryBase.jspreadsheet.version = function () {
      return version;
    }, Object.entries(helpers).forEach(([e, t]) => {
      libraryBase.jspreadsheet.helpers[e] = t;
    });
    var src = libraryBase.jspreadsheet;
    jspreadsheet = __webpack_exports__.default;
  }(), jspreadsheet;
});

