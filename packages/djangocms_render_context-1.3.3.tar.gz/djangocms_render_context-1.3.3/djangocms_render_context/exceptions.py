class SourceParseFailure(Exception):
    """Source parse failure."""
