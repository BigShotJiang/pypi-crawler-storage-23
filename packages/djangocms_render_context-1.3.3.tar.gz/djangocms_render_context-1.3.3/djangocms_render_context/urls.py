from django.urls import path

from .views import DataItemView

urlpatterns = [
    path("<int:plugin>/<int:position>/", DataItemView.as_view(), name="item"),
]
