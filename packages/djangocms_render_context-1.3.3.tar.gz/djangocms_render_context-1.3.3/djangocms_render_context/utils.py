from collections.abc import ValuesView
from datetime import date, datetime
from typing import Union

from django.template import Context
from django.urls import reverse
from django.utils.formats import localize
from django.utils.translation import gettext_lazy as _

dataType = Union[str, dict, list, ValuesView, None]  # noqa: UP007
dictContextType = Union[Context, dict]  # noqa: UP007
strOrNoneType = Union[str, None]  # noqa: UP007
pkType = Union[int, None]  # noqa: UP007
arrayType = Union[list, tuple]  # noqa: UP007


class ArrayWasNotFound(Exception):
    """Array was not found."""


def get_data(data: dataType, plugin_id: pkType, level: int = 0, position: int = 0) -> str:
    """Get data."""
    wrapper, separator = "{}", "\n"
    link = ""
    if level == 0:
        separator = "</tr>\n<tr>\n"
    if level == 1:
        if plugin_id is not None:
            path = reverse("djangocms_render_context:item", kwargs={"plugin": plugin_id, "position": position + 1})
            title = _("Go to the detail.")
            link = f'<td class="render-context-data-link"><a href="{path}" title="{title}">🔗</a></td>'
        wrapper = "<td>{}</td>"
    if data is None:
        content = wrapper.format("")
    elif isinstance(data, (date, datetime)):
        content = wrapper.format(localize(data))
    elif not isinstance(data, (tuple, list, dict, ValuesView)):
        if isinstance(data, str) and data[:11] == "data:image/":
            data = f'<img src="{data}">'
        content = wrapper.format(data)
    else:
        content = collect_data(data, plugin_id, wrapper, separator, level)
    return content + link


def collect_data(data: dataType, plugin_id: pkType, wrapper: str, separator: str, level: int) -> str:
    """Collect data."""
    content = []
    if isinstance(data, (tuple, list, ValuesView)):
        for position, item in enumerate(data):
            content.append(wrapper.format(get_data(item, plugin_id, level + 1, position)))
    elif isinstance(data, dict):
        if "href" in data and "text" in data:
            href, text = data.pop("href"), data.pop("text")
            content.append(f"""<a href="{href}">{text}</a>""")
        if "p" in data:
            para = data.pop("p")
            content.append(f"""<p>{para}</p>""")
        content.append(wrapper.format(get_data(data.values(), plugin_id, level + 1)))
    else:
        content.append(wrapper.format(get_data(data, plugin_id, level + 1)))
    return separator.join(content)


def create_html(data: dataType, plugin_id: pkType) -> str:
    return f"""<table class="rc-data"><tbody><tr>{get_data(data, plugin_id)}</tr></tbody></table>"""


def get_context_from_path(context: dictContextType, path: strOrNoneType) -> dictContextType:
    """Get context from the path."""
    if path is not None:
        for key in path.split("."):
            if isinstance(context, (tuple, list)):
                context = context[int(key)]
            else:
                context = context[key]
    return context


def get_first_array(context: dictContextType) -> arrayType:
    """Get first array in context."""
    if isinstance(context, (list, tuple)):
        return context
    if isinstance(context, dict):
        for item in context.values():
            if isinstance(item, (list, tuple)):
                return item
            if isinstance(item, dict):
                return get_first_array(item)
    raise ArrayWasNotFound
