"""Mini-player widget for audio playback.

This module provides a simple audio player widget with basic controls
(play, pause) and a progress bar for track duration.
"""

from PySide6 import QtCore, QtGui, QtWidgets

try:
    from PySide6 import QtMultimedia

    QT_MULTIMEDIA_AVAILABLE = True
except Exception:  # pragma: no cover - depends on system libs
    QtMultimedia = None
    QT_MULTIMEDIA_AVAILABLE = False


class MiniPlayerWidget(QtWidgets.QWidget):
    """A simple audio player widget with play/pause controls and progress slider.

    Signals:
        s_duration_changed: Emitted when the duration of the current media changes.
        s_position_changed: Emitted when the playback position changes.
        s_state_changed: Emitted when the player state changes.
    """

    # Signals
    s_duration_changed = QtCore.Signal(int)
    s_position_changed = QtCore.Signal(int)
    s_state_changed = QtCore.Signal(int)

    def __init__(self, parent: QtWidgets.QWidget | None = None) -> None:
        """Initialize the mini-player widget.

        Args:
            parent (QWidget | None): Parent widget.
        """
        super().__init__(parent)

        self.media_player = None
        self.audio_output = None

        # Track metadata
        self.current_track_title = ""
        self.current_track_artist = ""

        # Setup UI
        self._setup_ui()

        if not QT_MULTIMEDIA_AVAILABLE:
            self._set_backend_unavailable()
            return

        # Create media player
        self.media_player = QtMultimedia.QMediaPlayer(self)
        self.audio_output = QtMultimedia.QAudioOutput(self)
        self.media_player.setAudioOutput(self.audio_output)

        # Connect signals
        self._connect_signals()

    def _set_backend_unavailable(self) -> None:
        """Disable controls when QtMultimedia backend is unavailable."""
        self.lbl_track_info.setText("Audio backend unavailable")
        self.btn_play.setEnabled(False)
        self.btn_pause.setEnabled(False)
        self.btn_stop.setEnabled(False)
        self.slider_progress.setEnabled(False)
        self.slider_volume.setEnabled(False)

    def _setup_ui(self) -> None:
        """Setup the UI components."""
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(10)

        # Track info
        self.lbl_track_info = QtWidgets.QLabel("No track selected")
        self.lbl_track_info.setWordWrap(True)
        self.lbl_track_info.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.lbl_track_info)

        # Progress bar (slider)
        self.slider_progress = QtWidgets.QSlider(QtCore.Qt.Orientation.Horizontal)
        self.slider_progress.setRange(0, 0)
        self.slider_progress.sliderMoved.connect(self._on_slider_moved)
        layout.addWidget(self.slider_progress)

        # Time labels (current / total)
        time_layout = QtWidgets.QHBoxLayout()
        self.lbl_current_time = QtWidgets.QLabel("0:00")
        self.lbl_current_time.setAlignment(QtCore.Qt.AlignmentFlag.AlignLeft)
        self.lbl_total_time = QtWidgets.QLabel("0:00")
        self.lbl_total_time.setAlignment(QtCore.Qt.AlignmentFlag.AlignRight)
        time_layout.addWidget(self.lbl_current_time)
        time_layout.addStretch()
        time_layout.addWidget(self.lbl_total_time)
        layout.addLayout(time_layout)

        # Control buttons
        controls_layout = QtWidgets.QHBoxLayout()
        controls_layout.addStretch()

        self.btn_play = QtWidgets.QPushButton("▶ Play")
        self.btn_play.clicked.connect(self.play)
        controls_layout.addWidget(self.btn_play)

        self.btn_pause = QtWidgets.QPushButton("⏸ Pause")
        self.btn_pause.clicked.connect(self.pause)
        controls_layout.addWidget(self.btn_pause)

        self.btn_stop = QtWidgets.QPushButton("⏹ Stop")
        self.btn_stop.clicked.connect(self.stop)
        controls_layout.addWidget(self.btn_stop)

        controls_layout.addStretch()
        layout.addLayout(controls_layout)

        # Volume control
        volume_layout = QtWidgets.QHBoxLayout()
        volume_layout.addWidget(QtWidgets.QLabel("Volume:"))
        self.slider_volume = QtWidgets.QSlider(QtCore.Qt.Orientation.Horizontal)
        self.slider_volume.setRange(0, 100)
        self.slider_volume.setValue(100)
        self.slider_volume.setMaximumWidth(150)
        self.slider_volume.sliderMoved.connect(self._on_volume_changed)
        self.slider_volume.valueChanged.connect(self._on_volume_changed)
        volume_layout.addWidget(self.slider_volume)
        self.lbl_volume = QtWidgets.QLabel("100%")
        volume_layout.addWidget(self.lbl_volume)
        volume_layout.addStretch()
        layout.addLayout(volume_layout)

        layout.addStretch()

    def _connect_signals(self) -> None:
        """Connect media player signals."""
        if self.media_player is None:
            return
        self.media_player.durationChanged.connect(self._on_duration_changed)
        self.media_player.positionChanged.connect(self._on_position_changed)
        self.media_player.playbackStateChanged.connect(self._on_state_changed)
        self.media_player.mediaStatusChanged.connect(self._on_media_status_changed)

    def _on_duration_changed(self, duration: int) -> None:
        """Handle duration changed signal.

        Args:
            duration (int): Duration in milliseconds.
        """
        self.slider_progress.setMaximum(duration)
        self.lbl_total_time.setText(self._format_time(duration))
        self.s_duration_changed.emit(duration)

    def _on_position_changed(self, position: int) -> None:
        """Handle position changed signal.

        Args:
            position (int): Current position in milliseconds.
        """
        # Update slider without triggering sliderMoved signal
        self.slider_progress.blockSignals(True)
        self.slider_progress.setValue(position)
        self.slider_progress.blockSignals(False)

        self.lbl_current_time.setText(self._format_time(position))
        self.s_position_changed.emit(position)

    def _on_state_changed(self, state) -> None:
        """Handle state changed signal.

        Args:
            state: Current playback state.
        """
        state_value = state.value if hasattr(state, "value") else state
        self.s_state_changed.emit(state_value)

        # Update button states
        if QtMultimedia is None:
            return
        is_playing = state == QtMultimedia.QMediaPlayer.PlaybackState.PlayingState
        self.btn_play.setEnabled(not is_playing)
        self.btn_pause.setEnabled(is_playing)

    def _on_media_status_changed(self, status) -> None:
        """Handle media status changed signal.

        Args:
            status: Current media status.
        """
        if QtMultimedia is None:
            return
        if status == QtMultimedia.QMediaPlayer.MediaStatus.EndOfMedia:
            self.stop()

    def _on_slider_moved(self, position: int) -> None:
        """Handle slider position changed.

        Args:
            position (int): New slider position in milliseconds.
        """
        if self.media_player is None:
            return
        self.media_player.setPosition(position)

    def _on_volume_changed(self, volume: int) -> None:
        """Handle volume changed.

        Args:
            volume (int): Volume level (0-100).
        """
        if self.audio_output is None:
            return
        self.audio_output.setVolume(volume / 100.0)
        self.lbl_volume.setText(f"{volume}%")

    @staticmethod
    def _format_time(milliseconds: int) -> str:
        """Format time in milliseconds to MM:SS format.

        Args:
            milliseconds (int): Time in milliseconds.

        Returns:
            str: Formatted time string.
        """
        total_seconds = milliseconds // 1000
        minutes = total_seconds // 60
        seconds = total_seconds % 60
        return f"{minutes}:{seconds:02d}"

    def load_track(self, track_title: str, track_artist: str, media_url: str) -> None:
        """Load a track for playback.

        Args:
            track_title (str): Title of the track.
            track_artist (str): Artist of the track.
            media_url (str): URL of the media file.
        """
        self.current_track_title = track_title
        self.current_track_artist = track_artist

        # Update track info label
        self.lbl_track_info.setText(f"<b>{track_title}</b><br>{track_artist}")

        if self.media_player is None:
            return

        # Load media
        self.media_player.setSource(QtCore.QUrl(media_url))

        # Reset sliders
        self.slider_progress.setRange(0, 0)
        self.slider_progress.setValue(0)
        self.lbl_current_time.setText("0:00")
        self.lbl_total_time.setText("0:00")

    def play(self) -> None:
        """Start playback."""
        if self.media_player is None or self.media_player.source().isEmpty():
            return

        self.media_player.play()

    def pause(self) -> None:
        """Pause playback."""
        if self.media_player is None:
            return
        self.media_player.pause()

    def stop(self) -> None:
        """Stop playback."""
        if self.media_player is None:
            return
        self.media_player.stop()
        self.slider_progress.setValue(0)
        self.lbl_current_time.setText("0:00")

    def set_volume(self, volume: int) -> None:
        """Set the playback volume.

        Args:
            volume (int): Volume level (0-100).
        """
        self.slider_volume.setValue(volume)

    def closeEvent(self, event: QtGui.QCloseEvent) -> None:
        """Handle widget close event - cleanup resources."""
        if self.media_player is not None:
            self.media_player.stop()
            self.media_player.setSource(QtCore.QUrl())
        super().closeEvent(event)
