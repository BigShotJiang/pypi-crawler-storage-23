"""Backward-compatible GUI entry point.

The legacy :mod:`tidal_dl_ng.gui` module now delegates to the modular
implementation located under :mod:`tidal_dl_ng.gui.*`.
"""

from tidal_dl_ng.gui.activate import gui_activate
from tidal_dl_ng.gui.main_window import MainWindow

__all__ = ["MainWindow", "gui_activate"]


if __name__ == "__main__":
    gui_activate()
