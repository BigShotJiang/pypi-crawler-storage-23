"""GUI module for TIDAL Downloader Next Generation.

This module provides the main window and all GUI-related functionality
organized into manageable components.
"""

from importlib import import_module

try:
    from PySide6 import QtCore, QtGui, QtWidgets
except ImportError:  # pragma: no cover - GUI deps optional in some environments
    QtCore = QtGui = QtWidgets = None


def __getattr__(name: str):
    """Provide lazy access to GUI exports.

    Args:
        name (str): Attribute name.

    Returns:
        object: Imported attribute.
    """
    if name == "MainWindow":
        module = import_module("tidal_dl_ng.gui.main_window")
        return module.MainWindow
    raise AttributeError(name)


__all__ = [
    "MainWindow",
    "QtCore",
    "QtGui",
    "QtWidgets",
]
