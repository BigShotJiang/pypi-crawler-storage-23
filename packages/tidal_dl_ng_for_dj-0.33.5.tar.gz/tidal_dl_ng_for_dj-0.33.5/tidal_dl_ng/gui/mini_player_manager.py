"""Mini-player manager for handling playback control and track selection.

This module provides the MiniPlayerManager class that orchestrates
the mini-player widget and handles playback of tracks.
"""

from PySide6 import QtCore
from tidalapi import Track, Video

from tidal_dl_ng.logger import logger_gui
from tidal_dl_ng.ui.mini_player import MiniPlayerWidget


class MiniPlayerManager(QtCore.QObject):
    """Manager for controlling the mini-player widget.

    Handles track loading, playback control, and communication between
    the GUI and the player widget.

    Signals:
        s_player_error: Emitted when an error occurs during playback.
    """

    s_player_error = QtCore.Signal(str)

    def __init__(self, player_widget: MiniPlayerWidget, tidal_session) -> None:
        """Initialize the mini-player manager.

        Args:
            player_widget (MiniPlayerWidget): The player widget to manage.
            tidal_session: The Tidal session for obtaining stream information.
        """
        super().__init__()
        self.player_widget = player_widget
        self.tidal_session = tidal_session
        self.current_track = None

    def play_track(self, track: Track | Video) -> None:
        """Load and play a track.

        Args:
            track (Track | Video): The track to play.
        """
        if not isinstance(track, Track):
            self.s_player_error.emit("Only audio tracks can be played in the mini-player")
            return

        try:
            # Get track metadata
            track_title = track.name if hasattr(track, "name") else "Unknown"
            track_artist = self._get_artist_names(track) if hasattr(track, "artist") else "Unknown"

            # Try to get a preview URL or stream URL
            media_url = self._get_track_url(track)

            if not media_url:
                self.s_player_error.emit(f"Could not obtain a playable URL for '{track_title}'")
                logger_gui.warning(f"No playable URL found for track: {track_title}")
                return

            # Load track into player
            self.player_widget.load_track(track_title, track_artist, media_url)
            self.current_track = track

            # Auto-play
            self.player_widget.play()

            logger_gui.info(f"Playing: {track_title} - {track_artist}")

        except Exception as e:
            error_msg = f"Error playing track: {e!s}"
            self.s_player_error.emit(error_msg)
            logger_gui.error(error_msg)

    def _get_artist_names(self, track: Track) -> str:
        """Extract artist names from a track.

        Args:
            track (Track): The track object.

        Returns:
            str: Comma-separated artist names.
        """
        if not hasattr(track, "artist") or not track.artist:
            return "Unknown"

        artists = track.artist
        if isinstance(artists, list):
            return ", ".join([artist.name for artist in artists if hasattr(artist, "name")])
        elif hasattr(artists, "name"):
            return artists.name

        return "Unknown"

    def _get_track_url(self, track: Track) -> str | None:
        """Get a playable URL for a track using the stream manifest.

        This method obtains a stream URL from the track's stream manifest,
        which provides HLS/m3u8 segments for playback.

        Args:
            track (Track): The track to get URL for.

        Returns:
            str | None: The playable URL or None if unavailable.
        """
        try:
            if not hasattr(track, "get_stream"):
                logger_gui.debug(f"Track {track.id} has no get_stream method")
                return None

            # Get the stream for this track
            media_stream = track.get_stream()
            if not media_stream:
                logger_gui.debug(f"Could not get stream for track {track.id}")
                return None

            # Get the stream manifest
            stream_manifest = media_stream.get_stream_manifest()
            if not stream_manifest:
                logger_gui.debug(f"Could not get stream manifest for track {track.id}")
                return None

            # Get the URLs from the manifest
            urls = stream_manifest.get_urls()
            if not urls or len(urls) == 0:
                logger_gui.debug(f"No URLs in stream manifest for track {track.id}")
            else:
                # Return the first URL
                first_url = urls[0]
                logger_gui.debug(f"Retrieved streaming URL for track {track.id}")
                return first_url

        except Exception as e:
            logger_gui.debug(f"Error getting track URL: {e!s}")
        return None

    def stop(self) -> None:
        """Stop playback."""
        self.player_widget.stop()
        self.current_track = None
