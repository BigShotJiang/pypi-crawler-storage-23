

class Base():
    def __init__(self,):
        
        pass
    def test_fun(self,):
        pass
    pass