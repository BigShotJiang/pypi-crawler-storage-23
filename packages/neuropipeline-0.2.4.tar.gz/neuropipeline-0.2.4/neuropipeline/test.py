def test():
    print("Hello World!")