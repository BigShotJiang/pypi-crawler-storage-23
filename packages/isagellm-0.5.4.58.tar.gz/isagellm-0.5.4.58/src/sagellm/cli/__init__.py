"""sageLLM CLI module."""

from .main import main


def setup_wizard() -> None:
    """Entry point for `sagellm-setup` script."""
    from .commands.setup import setup

    setup.main(prog_name="sagellm-setup", standalone_mode=True)


__all__ = ["main", "setup_wizard"]
