from .core import core as core_blueprint

blueprints = [core_blueprint]
