// Copyright (c) Soma Contributors
// SPDX-License-Identifier: Apache-2.0

//! Unit tests for submission types.
//!
//! Tests for:
//! - Submission construction and field access
//! - SubmissionManifest creation and size calculation
//! - Transaction type helpers for submissions
//! - Tally-based submission reports on Target objects

use url::Url;

use crate::base::SomaAddress;
use crate::checksum::Checksum;
use crate::crypto::DIGEST_LENGTH;
use crate::metadata::{Manifest, ManifestV1, Metadata, MetadataV1};
use crate::model::ModelId;
use crate::object::ObjectID;
use crate::submission::SubmissionManifest;
use crate::tensor::SomaTensor;
use crate::transaction::{ClaimRewardsArgs, SubmitDataArgs, TransactionKind};

/// Helper to create a test SubmissionManifest
fn test_submission_manifest(size: usize) -> SubmissionManifest {
    let url = Url::parse("https://example.com/data/test.bin").unwrap();
    let metadata =
        Metadata::V1(MetadataV1::new(Checksum::new_from_hash([0u8; DIGEST_LENGTH]), size));
    let manifest = Manifest::V1(ManifestV1::new(url, metadata));
    SubmissionManifest::new(manifest)
}

/// Test SubmissionManifest creation and size accessor
#[test]
fn test_submission_manifest_creation() {
    let manifest = test_submission_manifest(2048);
    assert_eq!(manifest.size(), 2048);
}

/// Test SubmissionManifest with different sizes
#[test]
fn test_submission_manifest_various_sizes() {
    // Small file
    let small = test_submission_manifest(100);
    assert_eq!(small.size(), 100);

    // Large file (1 MB)
    let large = test_submission_manifest(1_000_000);
    assert_eq!(large.size(), 1_000_000);

    // Zero-size (edge case)
    let zero = test_submission_manifest(0);
    assert_eq!(zero.size(), 0);
}

/// Test SubmitData transaction kind helper
#[test]
fn test_submit_data_transaction_kind() {
    let target_id = ObjectID::random();
    let model_id = ModelId::random();
    let data_manifest = test_submission_manifest(1024);
    let embedding = SomaTensor::zeros(vec![2048]);
    let bond_coin =
        (ObjectID::random(), crate::object::Version::new(), crate::digests::ObjectDigest::random());

    let args = SubmitDataArgs {
        target_id,
        data_manifest,
        model_id,
        embedding,
        distance_score: SomaTensor::scalar(1000.0),
        loss_score: SomaTensor::new(vec![0.5], vec![1]),
        bond_coin,
    };

    let kind = TransactionKind::SubmitData(args);

    // Test is_submission_tx helper
    assert!(kind.is_submission_tx());
    assert!(kind.requires_system_state());
}

/// Test ClaimRewards transaction kind helper
#[test]
fn test_claim_rewards_transaction_kind() {
    let target_id = ObjectID::random();

    let args = ClaimRewardsArgs { target_id };
    let kind = TransactionKind::ClaimRewards(args);

    // Test is_submission_tx helper
    assert!(kind.is_submission_tx());
    assert!(kind.requires_system_state());
}

/// Test that non-submission transactions don't match is_submission_tx
#[test]
fn test_non_submission_transactions() {
    // TransferCoin is not a submission tx
    let transfer = TransactionKind::TransferCoin {
        coin: (
            ObjectID::random(),
            crate::object::Version::new(),
            crate::digests::ObjectDigest::random(),
        ),
        recipient: SomaAddress::random(),
        amount: Some(1000),
    };
    assert!(!transfer.is_submission_tx());

    // AddStake is not a submission tx
    let stake = TransactionKind::AddStake {
        address: SomaAddress::random(),
        coin_ref: (
            ObjectID::random(),
            crate::object::Version::new(),
            crate::digests::ObjectDigest::random(),
        ),
        amount: None,
    };
    assert!(!stake.is_submission_tx());
}

/// Test bond calculation from data size
#[test]
fn test_bond_scales_with_data_size() {
    // This tests the logic that bond = bond_per_byte * data_size
    // Using typical values from protocol config
    let bond_per_byte: u64 = 10; // 10 shannons per byte

    // Small data: 1KB
    let small_manifest = test_submission_manifest(1024);
    let small_bond = bond_per_byte * small_manifest.size() as u64;
    assert_eq!(small_bond, 10240); // 10 * 1024

    // Large data: 1MB
    let large_manifest = test_submission_manifest(1_000_000);
    let large_bond = bond_per_byte * large_manifest.size() as u64;
    assert_eq!(large_bond, 10_000_000); // 10 * 1M
}

// =============================================================================
// Tally-Based Submission Report Tests (Target methods)
// =============================================================================

use std::collections::BTreeSet;

use super::test_utils::{create_test_system_state, create_validators_with_stakes};
use crate::target::{TargetStatus, TargetV1};

/// Helper to create a test system state with voting power properly set.
fn create_test_system_state_with_voting_power(
    stakes: Vec<u64>,
) -> crate::system_state::SystemState {
    let validators = create_validators_with_stakes(stakes);
    let mut system_state = create_test_system_state(validators, 1000, 100);
    // Voting power is calculated from stake at epoch boundary, so we need to set it explicitly
    system_state.validators_mut().set_voting_power();
    system_state
}

/// Helper to create a test filled target
fn create_test_target() -> TargetV1 {
    TargetV1 {
        embedding: SomaTensor::zeros(vec![10]),
        model_ids: vec![],
        distance_threshold: SomaTensor::scalar(1000.0),
        reward_pool: 1000,
        generation_epoch: 0,
        status: TargetStatus::Filled { fill_epoch: 1 },
        submitter: Some(SomaAddress::random()),
        winning_model_id: Some(ModelId::random()),
        winning_model_owner: Some(SomaAddress::random()),
        bond_amount: 5000,
        winning_data_manifest: None,
        winning_embedding: None,
        winning_distance_score: Some(SomaTensor::scalar(500.0)),
        winning_loss_score: Some(SomaTensor::new(vec![0.5], vec![1])),
        submission_reports: BTreeSet::new(),
    }
}

/// Test that reports can be added to a Target
#[test]
fn test_target_report_submission() {
    let mut target = create_test_target();
    let validator_addr = SomaAddress::random();

    target.report_submission(validator_addr);
    assert_eq!(target.submission_reports.len(), 1);
    assert!(target.submission_reports.contains(&validator_addr));
}

/// Test that reports are idempotent (inserting same validator twice)
#[test]
fn test_target_report_submission_idempotent() {
    let mut target = create_test_target();
    let validator_addr = SomaAddress::random();

    target.report_submission(validator_addr);
    target.report_submission(validator_addr);
    assert_eq!(target.submission_reports.len(), 1);
    assert!(target.submission_reports.contains(&validator_addr));
}

/// Test that multiple validators can report
#[test]
fn test_target_report_submission_multiple_validators() {
    let mut target = create_test_target();
    let validator1 = SomaAddress::random();
    let validator2 = SomaAddress::random();

    target.report_submission(validator1);
    target.report_submission(validator2);
    assert_eq!(target.submission_reports.len(), 2);
    assert!(target.submission_reports.contains(&validator1));
    assert!(target.submission_reports.contains(&validator2));
}

/// Test undo_report_submission removes the report
#[test]
fn test_target_undo_report_submission() {
    let mut target = create_test_target();
    let validator_addr = SomaAddress::random();

    // Add report then undo
    target.report_submission(validator_addr);
    assert_eq!(target.submission_reports.len(), 1);

    let removed = target.undo_report_submission(validator_addr);
    assert!(removed);
    assert_eq!(target.submission_reports.len(), 0);
}

/// Test undo_report_submission returns false when no report exists
#[test]
fn test_target_undo_report_submission_not_found() {
    let mut target = create_test_target();
    let validator_addr = SomaAddress::random();

    // Try to undo when never reported
    let removed = target.undo_report_submission(validator_addr);
    assert!(!removed);
}

/// Test get_submission_report_quorum returns false with no reports
#[test]
fn test_target_quorum_no_reports() {
    let target = create_test_target();
    let system_state = create_test_system_state_with_voting_power(vec![100, 100]);

    let (has_quorum, reporters) = target.get_submission_report_quorum(system_state.validators());
    assert!(!has_quorum);
    assert!(reporters.is_empty());
}

/// Test get_submission_report_quorum returns false with insufficient stake
#[test]
fn test_target_quorum_insufficient_stake() {
    let mut target = create_test_target();
    // Create 4 validators with equal stake (each gets 25% voting power)
    let system_state = create_test_system_state_with_voting_power(vec![100, 100, 100, 100]);
    let validator_addr = system_state.validators().validators[0].metadata.soma_address;

    // Single validator reports (25% stake, need 67%)
    target.report_submission(validator_addr);

    let (has_quorum, reporters) = target.get_submission_report_quorum(system_state.validators());
    assert!(!has_quorum);
    assert_eq!(reporters.len(), 1); // Still tracked as reporter
}

/// Test get_submission_report_quorum returns true with sufficient stake
#[test]
fn test_target_quorum_sufficient_stake() {
    let mut target = create_test_target();
    // Use 4 validators with equal stake
    // Each gets 2500 voting power, quorum = 6667
    // 3 of 4 = 7500 > 6667 (quorum reached)
    let system_state = create_test_system_state_with_voting_power(vec![100, 100, 100, 100]);
    let validator1_addr = system_state.validators().validators[0].metadata.soma_address;
    let validator2_addr = system_state.validators().validators[1].metadata.soma_address;
    let validator3_addr = system_state.validators().validators[2].metadata.soma_address;

    // All 3 validators report
    target.report_submission(validator1_addr);
    target.report_submission(validator2_addr);
    target.report_submission(validator3_addr);

    let (has_quorum, reporters) = target.get_submission_report_quorum(system_state.validators());
    assert!(has_quorum);
    assert_eq!(reporters.len(), 3);
}

/// Test get_submission_report_quorum with exactly 3 of 4 validators
#[test]
fn test_target_quorum_three_of_four() {
    let mut target = create_test_target();
    let system_state = create_test_system_state_with_voting_power(vec![100, 100, 100, 100]);
    let validator1_addr = system_state.validators().validators[0].metadata.soma_address;
    let validator2_addr = system_state.validators().validators[1].metadata.soma_address;
    let validator3_addr = system_state.validators().validators[2].metadata.soma_address;

    // 3 validators report
    target.report_submission(validator1_addr);
    target.report_submission(validator2_addr);
    target.report_submission(validator3_addr);

    let (has_quorum, reporters) = target.get_submission_report_quorum(system_state.validators());
    assert!(has_quorum);
    assert_eq!(reporters.len(), 3);
}

/// Test clear_submission_reports removes all reports
#[test]
fn test_target_clear_submission_reports() {
    let mut target = create_test_target();
    let validator1 = SomaAddress::random();
    let validator2 = SomaAddress::random();

    target.report_submission(validator1);
    target.report_submission(validator2);
    assert_eq!(target.submission_reports.len(), 2);

    target.clear_submission_reports();
    assert_eq!(target.submission_reports.len(), 0);
}

/// Test quorum calculation with validators of different stakes
#[test]
fn test_target_quorum_with_varied_stakes() {
    let mut target = create_test_target();
    // Create validators with different stakes: [200, 100, 100] = 50%, 25%, 25%
    let system_state = create_test_system_state_with_voting_power(vec![200, 100, 100]);
    let big_validator_addr = system_state.validators().validators[0].metadata.soma_address;
    let small_validator_addr = system_state.validators().validators[1].metadata.soma_address;

    // Small validator alone (25%) - no quorum
    target.report_submission(small_validator_addr);
    let (has_quorum, _) = target.get_submission_report_quorum(system_state.validators());
    assert!(!has_quorum);

    // Add big validator (50% + 25% = 75%) - should have quorum
    target.report_submission(big_validator_addr);
    let (has_quorum, _) = target.get_submission_report_quorum(system_state.validators());
    assert!(has_quorum);
}

// =============================================================================
// Edge Case Tests for Submission and Target
// =============================================================================

/// Test bond calculation with zero size produces zero bond
#[test]
fn test_bond_calculation_zero_size() {
    let bond_per_byte: u64 = 10;
    let data_manifest = test_submission_manifest(0);
    let bond = bond_per_byte * data_manifest.size() as u64;
    assert_eq!(bond, 0);
}

/// Test reports from non-validators are ignored in quorum calculation
#[test]
fn test_quorum_ignores_non_validator_reports() {
    let mut target = create_test_target();
    // Create system state with 4 validators, each with 100 stake
    let system_state = create_test_system_state_with_voting_power(vec![100, 100, 100, 100]);

    // Get one real validator
    let real_validator = system_state.validators().validators[0].metadata.soma_address;

    // Create addresses that are NOT validators
    let fake_validator1 = SomaAddress::random();
    let fake_validator2 = SomaAddress::random();
    let fake_validator3 = SomaAddress::random();

    // Have 3 non-validators report (these should be ignored)
    target.report_submission(fake_validator1);
    target.report_submission(fake_validator2);
    target.report_submission(fake_validator3);

    // Check quorum - should NOT have quorum even with 3 reports
    let (has_quorum, reporters) = target.get_submission_report_quorum(system_state.validators());
    assert!(!has_quorum, "Non-validator reports should not count toward quorum");
    assert!(reporters.is_empty(), "Non-validators should not be in reporters list");

    // Now add the real validator
    target.report_submission(real_validator);

    // Still should not have quorum (only 1 validator = 25%)
    let (has_quorum, reporters) = target.get_submission_report_quorum(system_state.validators());
    assert!(!has_quorum, "Single validator should not reach quorum");
    assert_eq!(reporters.len(), 1, "Should only count the real validator");
}

/// Test that model_owner being None (shouldn't happen but edge case)
/// means model share is not distributed
#[test]
fn test_target_with_no_model_owner() {
    // Create a filled target but with winning_model_owner = None
    // This tests the edge case in ClaimRewards
    let mut target = create_test_target();
    target.submitter = Some(SomaAddress::random());
    target.winning_model_id = Some(ModelId::random());
    target.winning_model_owner = None; // Edge case: no model owner
    target.bond_amount = 5000;
    target.reward_pool = 10000;
    target.status = TargetStatus::Filled { fill_epoch: 0 };

    // Verify the state is as expected
    assert!(target.submitter.is_some());
    assert!(target.winning_model_owner.is_none());
}

/// Test quorum threshold edge case - exactly at threshold
#[test]
fn test_quorum_exactly_at_threshold() {
    let mut target = create_test_target();
    // Use validators with equal stake (each gets 2500 voting power)
    // Quorum threshold is 6667, so need 3 of 4 (7500 > 6667)
    let system_state = create_test_system_state_with_voting_power(vec![100, 100, 100, 100]);

    let validator1 = system_state.validators().validators[0].metadata.soma_address;
    let validator2 = system_state.validators().validators[1].metadata.soma_address;

    // 2 validators = 5000 voting power < 6667 threshold
    target.report_submission(validator1);
    target.report_submission(validator2);

    let (has_quorum, _) = target.get_submission_report_quorum(system_state.validators());
    assert!(!has_quorum, "2 of 4 validators should not reach quorum");
}

/// Test validator reward remainder goes to first validator
#[test]
fn test_validator_reward_remainder_distribution() {
    // This tests the logic in distribute_bond_to_validators
    // where remainder goes to the first validator
    let bond: u64 = 100;
    let num_validators = 3;

    let per_validator = bond / num_validators;
    let remainder = bond % num_validators;

    assert_eq!(per_validator, 33);
    assert_eq!(remainder, 1);

    // First validator gets 33 + 1 = 34
    // Others get 33 each
    // Total: 34 + 33 + 33 = 100 ✓
    let first_amount = per_validator + remainder;
    let other_amount = per_validator;
    let total = first_amount + other_amount * 2;
    assert_eq!(total, bond, "All bond should be distributed");
}

/// Test that reporting same validator twice is idempotent (set behavior)
#[test]
fn test_report_idempotent_behavior() {
    let mut target = create_test_target();
    let validator = SomaAddress::random();

    // First report
    target.report_submission(validator);
    assert!(target.submission_reports.contains(&validator));

    // Second report — still just one entry (BTreeSet)
    target.report_submission(validator);
    assert_eq!(target.submission_reports.len(), 1, "Should still have only one report");
}
