"""Timm model archivers for mindtrace Registry."""

from mindtrace.registry.archivers.timm.timm_model_archiver import TimmModelArchiver

__all__ = ["TimmModelArchiver"]
