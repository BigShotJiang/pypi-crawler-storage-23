"""ONNX model archivers for mindtrace Registry."""

from mindtrace.registry.archivers.onnx.onnx_model_archiver import OnnxModelArchiver

__all__ = ["OnnxModelArchiver"]
