from .s3_registry_backend import S3RegistryBackend


class MinioRegistryBackend(S3RegistryBackend):
    pass
