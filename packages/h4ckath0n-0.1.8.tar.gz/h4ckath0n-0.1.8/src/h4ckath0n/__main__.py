"""Allow ``python -m h4ckath0n`` as an alias for the CLI."""

from h4ckath0n.cli import main

raise SystemExit(main())
