"""Tests for configuration system."""
