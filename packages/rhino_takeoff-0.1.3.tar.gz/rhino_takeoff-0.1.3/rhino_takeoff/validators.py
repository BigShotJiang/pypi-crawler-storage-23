import logging
from typing import Dict

logger = logging.getLogger(__name__)


class UnitValidator:
    """
    Handles validation and conversion of architectural units (mm, cm, m).
    """

    def __init__(self):
        pass

    def to_mm(self, value: float, unit: str) -> float:
        """
        Converts a value to millimeters.

        Args:
            value: The numeric value to convert.
            unit: The current unit of the value ("mm", "cm", "m").

        Returns:
            The value converted to millimeters. Returns the original value
            if the unit is not supported.
        """
        unit = unit.lower()
        if unit == "mm":
            return value
        elif unit == "cm":
            return value * 10.0
        elif unit == "m":
            return value * 1000.0
        else:
            logger.warning(
                f"Unsupported length unit: {unit}. Returning original value."
            )
            return value

    def to_m(self, value: float, unit: str) -> float:
        """
        Converts a value to meters.

        Args:
            value: The numeric value to convert.
            unit: The current unit of the value ("mm", "cm", "m").

        Returns:
            The value converted to meters. Returns the original value
            if the unit is not supported.
        """
        unit = unit.lower()
        if unit == "m":
            return value
        elif unit == "cm":
            return value / 100.0
        elif unit == "mm":
            return value / 1000.0
        else:
            logger.warning(
                f"Unsupported length unit: {unit}. Returning original value."
            )
            return value

    def to_m2(self, value: float, unit: str) -> float:
        """
        Converts a value to square meters.

        Args:
            value: The numeric value to convert.
            unit: The current unit of the value ("m2", "mm2").

        Returns:
            The value converted to square meters. Returns the original value
            if the unit is not supported.
        """
        unit = unit.lower()
        if unit == "m2":
            return value
        elif unit == "mm2":
            return value / 1_000_000.0
        else:
            logger.warning(f"Unsupported area unit: {unit}. Returning original value.")
            return value

    def to_mm2(self, value: float, unit: str) -> float:
        """
        Converts a value to square millimeters.

        Args:
            value: The numeric value to convert.
            unit: The current unit of the value ("m2", "mm2").

        Returns:
            The value converted to square millimeters. Returns the original value
            if the unit is not supported.
        """
        unit = unit.lower()
        if unit == "mm2":
            return value
        elif unit == "m2":
            return value * 1_000_000.0
        else:
            logger.warning(f"Unsupported area unit: {unit}. Returning original value.")
            return value

    def detect_unit(self, value: float) -> str:
        """
        Estimates the unit based on the magnitude of the value using heuristics.

        Args:
            value: The numeric value to analyze.

        Returns:
            Estimated unit string ("mm", "mm2", "m", or "unknown").
        """
        # Heuristic: Identify typical architectural dimensions
        if value > 1000:
            logger.info(f"Value {value}: Estimated as mm or mm2.")
            if value > 1000000:
                return "mm2"
            return "mm"
        elif value < 100:
            return "m"

        logger.warning(f"Could not reliably estimate unit for value {value}.")
        return "unknown"

    def convert_all(
        self, data: Dict[str, float], from_unit: str, to_unit: str
    ) -> Dict[str, float]:
        """
        Converts all numeric values in a dictionary to a target unit.

        Args:
            data: Dictionary of values to convert.
            from_unit: The source unit.
            to_unit: The target unit.

        Returns:
            A new dictionary with converted values.
        """
        result = {}
        for k, v in data.items():
            if from_unit in ["mm", "cm", "m"] and to_unit in ["mm", "cm", "m"]:
                val_in_m = self.to_m(v, from_unit)
                if to_unit == "m":
                    result[k] = val_in_m
                elif to_unit == "mm":
                    result[k] = val_in_m * 1000.0
                elif to_unit == "cm":
                    result[k] = val_in_m * 100.0
            else:
                result[k] = v
        return result


class AreaValidator(UnitValidator):
    """
    Specialized validator for area values.
    """

    def check_range(self, value_m2: float) -> bool:
        """
        Checks if the area value is within a reasonable range.

        Args:
            value_m2: Area value in square meters.

        Returns:
            True if the value is valid (0 <= value <= 100,000), False otherwise.
        """
        if value_m2 < 0:
            logger.warning(f"Area cannot be negative: {value_m2}")
            return False
        if value_m2 > 100000.0:
            logger.warning(
                f"Area is unusually large: {value_m2} m2. Check for unit errors (e.g., mm2)."
            )
            return False
        return True
