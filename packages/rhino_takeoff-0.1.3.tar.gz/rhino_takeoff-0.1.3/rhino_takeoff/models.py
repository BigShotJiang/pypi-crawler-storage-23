from pydantic import BaseModel, model_validator, Field
from typing import List, Optional
from enum import Enum


class ElementType(str, Enum):
    SLAB = "slab"
    WALL = "wall"
    COLUMN = "column"
    BEAM = "beam"
    OPENING = "opening"
    UNKNOWN = "unknown"


class BuildingElement(BaseModel):
    """
    Represents a fundamental building element with its properties.

    Attributes:
        id: Unique identifier for the object (e.g., GUID).
        element_type: The categorized type of the element.
        layer: Rhino layer path or name.
        area_m2: Area of the element in square meters.
        volume_m3: Volume of the element in cubic meters.
        length_m: Length of the element in meters.
        floor_number: Associated floor number.
        notes: Additional remarks or notes.
    """

    id: str = Field(..., description="Unique identifier for the object (e.g., GUID)")
    element_type: ElementType = Field(
        ..., description="The categorized type of the element"
    )
    layer: Optional[str] = Field(None, description="Rhino layer path or name")
    area_m2: Optional[float] = Field(None, description="Area in square meters")
    volume_m3: Optional[float] = Field(None, description="Volume in cubic meters")
    length_m: Optional[float] = Field(None, description="Length in meters")
    floor_number: Optional[int] = Field(None, description="Associated floor number")
    notes: Optional[str] = Field(None, description="Additional remarks")


class TakeoffResult(BaseModel):
    """
    Aggregated result of the quantity takeoff process.

    Attributes:
        project_name: Name of the project.
        elements: List of individual building elements.
        total_area_m2: Sum of areas of all elements.
        total_volume_m3: Sum of volumes of all elements.
    """

    project_name: str
    elements: List[BuildingElement]
    total_area_m2: float = 0.0
    total_volume_m3: float = 0.0

    @model_validator(mode="after")
    def calc_totals(self) -> "TakeoffResult":
        """Calculates total area and volume from the elements list."""
        self.total_area_m2 = sum((e.area_m2 or 0.0) for e in self.elements)
        self.total_volume_m3 = sum((e.volume_m3 or 0.0) for e in self.elements)
        return self


class ZEBEnvelope(BaseModel):
    """
    Represents envelope data for ZEB (Zero Energy Building) certification.

    Attributes:
        element: Name or type of the envelope element.
        area_m2: Area in square meters.
        u_value: Thermal transmittance (W/m²K).
        compliant: Validation result indicating if it meets the criteria.
    """

    element: str
    area_m2: float
    u_value: float = Field(..., description="Thermal transmittance (W/m²K)")
    compliant: Optional[bool] = None
