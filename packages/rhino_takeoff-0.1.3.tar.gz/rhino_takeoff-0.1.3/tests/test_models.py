from rhino_takeoff.models import BuildingElement, TakeoffResult, ElementType


def test_building_element_creation():
    be = BuildingElement(id="123", element_type=ElementType.SLAB, area_m2=100.0)
    assert be.id == "123"
    assert be.element_type == ElementType.SLAB
    assert be.area_m2 == 100.0


def test_takeoff_result_aggregation():
    e1 = BuildingElement(
        id="1", element_type=ElementType.SLAB, area_m2=10.0, volume_m3=2.0
    )
    e2 = BuildingElement(
        id="2", element_type=ElementType.WALL, area_m2=20.0, volume_m3=5.0
    )

    tr = TakeoffResult(project_name="Test", elements=[e1, e2])

    assert tr.total_area_m2 == 30.0
    assert tr.total_volume_m3 == 7.0
