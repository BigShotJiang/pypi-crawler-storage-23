from rhino_takeoff.zeb import ZEBReport
import pytest


def test_export_summary():
    zeb = ZEBReport("Summary Test")
    zeb.set_energy_consumption(100.0, 1000.0)
    zeb.set_renewable_production(50.0) # 50%
    zeb.add_envelope("Wall", 100.0, 0.2)
    
    summary = zeb.export_summary()
    assert summary["project"] == "Summary Test"
    assert summary["energy_independence_rate"] == 50.0
    assert summary["achieved_grade"] == "ZEB_4"
    assert summary["items_count"] == 1


def test_energy_independence_calculation():
    zeb = ZEBReport("Test ZEB")
    zeb.set_energy_consumption(100.0, 1000.0)  # 100 kWh/m2
    zeb.set_renewable_production(20.0)  # 20 kWh/m2

    rate = zeb.calc_energy_independence_rate()
    # (20 / 100) * 100 = 20.0%
    assert rate == 20.0


def test_grade_boundaries():
    zeb = ZEBReport("Boundaries")
    zeb.set_energy_consumption(100.0, 500.0)

    # 1. ZEB 5 Boundary (20%)
    # Case: 19.9%
    zeb.set_renewable_production(19.9)
    assert zeb.calc_energy_independence_rate() == 19.9
    res = zeb.check_compliance("ZEB_5")
    assert not res["compliant"]
    assert zeb.get_achievable_grade() == "None"

    # Case: 20.0%
    zeb.set_renewable_production(20.0)
    res = zeb.check_compliance("ZEB_5")
    assert res["compliant"]
    assert zeb.get_achievable_grade() == "ZEB_5"

    # 2. ZEB 1 Boundary (100%) -> Should now be ZEB_PLUS due to sort order
    # Case: 100.0%
    zeb.set_renewable_production(100.0)
    res = zeb.check_compliance("ZEB_PLUS")
    assert res["compliant"]
    assert zeb.get_achievable_grade() == "ZEB_PLUS"

    # ZEB_1 check (still compliant, but achievable grade is higher)
    res = zeb.check_compliance("ZEB_1")
    assert res["compliant"]



def test_unknown_standard():
    zeb = ZEBReport("Unknown")
    res = zeb.check_compliance("ZEB_UNKNOWN")
    assert not res["compliant"]


def test_zero_consumption():
    zeb = ZEBReport("Zero")
    zeb.set_energy_consumption(0.0, 100.0)
    assert zeb.calc_energy_independence_rate() == 0.0
