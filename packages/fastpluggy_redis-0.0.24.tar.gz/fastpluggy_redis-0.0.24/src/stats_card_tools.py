from .schema import RedisInfo
from fastpluggy_plugin.ui_tools.extra_widget.display.card import CardWidget


def make_memory_usage_card(info: RedisInfo) -> CardWidget:
    """
    Returns a CardWidget showing:
      • used_memory_human / total_system_memory_human
      • a Bootstrap progress bar indicating percent used.
      Tooltip (via title="…") combines descriptions of used_memory_human & total_system_memory_human.
    """
    # 1) Compute percentage
    used_bytes = info.used_memory or 0
    total_bytes = info.total_system_memory or 1
    pct_used = (used_bytes / total_bytes) * 100

    # 2) Pull descriptions directly from RedisInfo.model_fields
    desc_used = RedisInfo.model_fields['used_memory_human'].description or ""
    desc_total = RedisInfo.model_fields['total_system_memory_human'].description or ""
    tooltip_text = f"{desc_used} | {desc_total}"

    return CardWidget(
        subheader="Memory Usage",
        value=f"{info.used_memory_human} / {info.total_system_memory_human}",
        content=tooltip_text,
        progress=round(pct_used, 1),
        progress_color="blue",
    )


def get_stats_cards(info: RedisInfo):
    """
    Build CardWidget objects using value/content for better style.
    """
    f = RedisInfo.model_fields  # shorthand for field metadata

    stats_cards = [
        # CPU Load (user+sys)
        CardWidget(
            subheader="CPU Load (user+sys)",
            value=f'{info.cpu_load:.2f}',
            content=f["used_cpu_user"].description or "",
        ),

        # Memory Usage (combined card)
        make_memory_usage_card(info=info),

        # Connected Clients
        CardWidget(
            subheader="Connected Clients",
            value=str(info.connected_clients),
            content=f["connected_clients"].description or "",
        ),

        # Ops/Sec
        CardWidget(
            subheader="Ops/Sec",
            value=str(info.instantaneous_ops_per_sec),
            content=f["instantaneous_ops_per_sec"].description or "",
        ),

        # Uptime
        CardWidget(
            subheader="Uptime",
            value=str(info.uptime_text),
            content=f["uptime_in_seconds"].description or "",
        ),

    ]

    return stats_cards
