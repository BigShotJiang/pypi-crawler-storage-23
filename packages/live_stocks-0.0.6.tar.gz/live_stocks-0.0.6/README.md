# Live Stocks

This package can get the current price of cryptocurrencies and stocks, graph live price movements, graph historical price data, and retrieve historical price dictionaries. It also includes functions for converting between stock/crypto names and symbols.

---

> ### ⚠️ **Requires an active internet connection**
> All price and history data is retrieved live.

> ### ⚠️ **Symbols must be valid tickers**
> Misspelled or invalid symbols will fail unless autocorrect is enabled.

> ### ⚠️ **Graphing functions require valid price/history functions**
> `draw_graph` and `graph_history` must receive valid data sources.

---

## Table of Contents
- [Quick Start](#quick-start)
- [Features](#features)
- [Usage](#usage)
  - [Getting Prices](#getting-prices)
  - [Drawing Live Graphs](#drawing-live-graphs)
  - [Getting Historical Data](#getting-historical-data)
  - [Graphing Historical Data](#graphing-historical-data)
  - [Symbol and Name Conversion](#symbol-and-name-conversion)
- [Versions](#versions)
- [Coming Soon](#coming-soon)

---

## Quick Start

### Installation
```
pip install live-stocks
```

### Minimal Example
```python
from live_stocks import get_price

print(get_price(symbol="AAPL"))
```

---

## Features

- Get the current price of any stock or cryptocurrency.
- Draw live‑updating price graphs.
- Retrieve historical price data as a dictionary using `get_history()`.
- Graph historical price data using `graph_history()`.
- Convert from company/crypto names to symbols.
- Convert from symbols to company/crypto names.

---

## Usage

### Getting Prices

```python
from live_stocks import get_price

price = get_price(symbol="AAPL")
print(price)
```

---

### Drawing Live Graphs

```python
from live_stocks import get_price, draw_graph

draw_graph(
    price_func=lambda: get_price(symbol="AAPL"),
    stock_name="Apple",
    max_points=200,
    update_time=1.0,
    show_timestamps=True
)
```

---

## Getting Historical Data

The `get_history()` function returns a dictionary mapping timestamps → prices if show_time_stamps is True. If show_time_stamps is False, then the `get_history()` function returns a list of prices.

#### As a dictionary (show_time_stamps = True)

```python
from live_stocks import *

history = get_history(
    symbol="AAPL",
    length=LENGTH_ONE_MONTH,
    interval=INTERVAL_ONE_DAY,
    show_time_stamps = True
)

print(history)
```

Example output structure:

```
{
    "2024-01-01 09:30:00": 187.23,
    "2024-01-02 09:30:00": 189.10,
    ...
}
```

#### As a list (show_time_stamps = False)

```python
from live_stocks import *

history = get_history(
    symbol="AAPL",
    length=LENGTH_ONE_MONTH,
    interval=INTERVAL_ONE_DAY,
    show_time_stamps = False
)

print(history)
```

Example output structure:

```
[
    187.23,
    189.10,
    ...
]
```

**Supported lengths:**  
`1d`, `5d`, `1mo`, `3mo`, `6mo`, `1y`, `2y`, `5y`, `10y`, `ytd`, `max`

**Supported intervals:**  
`1m`, `2m`, `5m`, `15m`, `30m`, `1h`, `90m`, `4h`, `1d`, `5d`, `1wk`, `1mo`, `3mo`

---

## Graphing Historical Data

The `graph_history()` function graphs historical price data using matplotlib.

### Static history graph:

```python
from live_stocks import graph_history

graph_history(
    symbol="AAPL",
    length="5y",
    interval="1mo",
    live=False
)
```

Draws a graph with the history and does not update as the price changes.

### Live‑updating history graph:

```python
graph_history(
    symbol="AAPL",
    length="1y",
    interval="1d",
    live=True
)
```

Draws a graph with the history and keeps on updating every interval.

---

## Symbol and Name Conversion

### Name → Symbol

```python
from live_stocks import name_to_symbol

symbol = name_to_symbol(company_name="Apple", autocorrect=True)
print(symbol)
```

### Symbol → Name

```python
from live_stocks import symbol_to_name

name = symbol_to_name(company_name="AAPL", autocorrect=True)
print(name)
```

---

## Versions

Version 0.0.1: Base code with primary functions added.  
Version 0.0.2: Documentation for crypto functions added and more parameters for `draw_graph`.  
Version 0.0.3: Documentation for stock functions added.  
Version 0.0.4: Symbol → Name and Name → Symbol conversion added.  
Version 0.0.5: Added getting and graphing historical data; merged crypto/stock price functions.  
**(Latest) Version 0.0.6:** Updated README

---

## Coming Soon

Version 0.0.7: Add get_latest_news function for stocks and crypto
