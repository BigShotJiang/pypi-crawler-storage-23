import yfinance as yf
from enum import Enum
from matplotlib import pyplot as plt

def _plot_points_with_lines(points, stock_name, length):
    plt.cla()
    if not points:
        return

    x_vals, y_vals = zip(*points)
    plt.plot(x_vals, y_vals, color='blue', linestyle='-', linewidth=2, label=f'{stock_name} Price ({length})')

    if len(x_vals) >= 3:
        mid_index = len(x_vals) // 2
        tick_positions = [x_vals[0], x_vals[mid_index], x_vals[-1]]
        tick_labels = [str(x_vals[0]), str(x_vals[mid_index]), str(x_vals[-1])]
        plt.xticks(tick_positions, tick_labels)
    else:
        plt.xticks(x_vals, [str(x) for x in x_vals])

    plt.title(f"{stock_name} Price (USD)")
    plt.xlabel("Time")
    plt.ylabel("Price (USD)")
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.legend()
    plt.tight_layout()
    plt.pause(0.1)

LENGTH_ONE_DAY = "1d"
LENGTH_FIVE_DAYS = "5d"
LENGTH_ONE_MONTH = "1mo"
LENGTH_THREE_MONTHS = "3mo"
LENGTH_SIX_MONTHS = "6mo"
LENGTH_ONE_YEAR = "1y"
LENGTH_TWO_YEARS = "2y"
LENGTH_FIVE_YEARS = "5y"
LENGTH_TEN_YEARS = "10y"
LENGTH_YEAR_TO_DATE = "ytd"
LENGTH_ALL = "max"

INTERVAL_ONE_MINUTE = "1m"
INTERVAL_TWO_MINUTES = "2m"
INTERVAL_FIVE_MINUTES = "5m"
INTERVAL_FIFTEEN_MINUTES = "15m"
INTERVAL_THIRTY_MINUTES = "30m"
INTERVAL_HALF_AN_HOUR = "30m"
INTERVAL_ONE_HOUR = "1h"
INTERVAL_NINETY_MINUTES = "90m"
INTERVAL_FOUR_HOURS = "4h"
INTERVAL_ONE_DAY = "1d"
INTERVAL_FIVE_DAYS = "5d"
INTERVAL_ONE_WEEK = "1wk"
INTERVAL_ONE_MONTH = "1mo"
INTERVAL_THREE_MONTHS = "3mo"

def get_history(symbol: str, length = LENGTH_ONE_DAY, interval = INTERVAL_ONE_MINUTE, show_time_stamps = True):
    ticker = yf.Ticker(symbol)
    data = ticker.history(period=length, interval=interval)["Open"]
    if not show_time_stamps:
        return data.to_list()

    dictionary = data.to_dict()
    return_dict = {}
    values = list(dictionary.values())
    keys = list(map(lambda x: str(x).removesuffix("-05:00"), dictionary.keys()))
    for i in range(len(values)):
        return_dict[keys[i]] = values[i]

    return return_dict

def graph_history(symbol: str, length = "10y", interval = "1mo", live = False):
    def get_points():
        history = get_history(symbol, length, interval)
        points = []
        for timestamp, price in history.items():
            points.append((timestamp, price))
        return points

    if not live:
        points = get_points()

    while True:
        if live:
            points = get_points()
        _plot_points_with_lines(points, symbol, length)
