import yfinance as yf
import json
import websocket
import threading
import time
from decimal import Decimal

def get_price(symbol: str) -> float:
    """
    Gets the current stock/crypto price from a symbol

    :param symbol: The symbol of the stock

    :return float: The current price of the symbol
    """
    try:
        if "-" not in symbol:
            ticker = yf.Ticker(symbol)
            data = ticker.history(period="1d", interval="1m")
            if not data.empty:
                return round(data["Close"].iloc[-1], 2)
            else:
                print(f"No data found for {symbol}")
                return None
        else:
            price_data = {"value": None}

            def on_message(ws, message):
                try:
                    data = json.loads(message)
                    if "price" in data:
                        price_data["value"] = float(data["price"])
                        ws.close()
                except Exception:
                    pass

            def on_open(ws):
                subscribe_message = {
                    "type": "subscribe",
                    "channels": [{"name": "ticker", "product_ids": [symbol]}]
                }
                ws.send(json.dumps(subscribe_message))

            ws = websocket.WebSocketApp(
                "wss://ws-feed.exchange.coinbase.com",
                on_message=on_message,
                on_open=on_open
            )

            wst = threading.Thread(target=ws.run_forever, daemon=True)
            wst.start()

            timeout = Decimal(time.time()) + Decimal("10")
            while price_data["value"] is None and Decimal(time.time()) < timeout:
                time.sleep(0.1)

            return price_data["value"]
    except Exception as e:
        print(f"Error fetching stock price for {symbol}: {e}")
        return None
