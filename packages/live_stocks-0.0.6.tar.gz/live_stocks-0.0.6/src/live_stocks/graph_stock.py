import matplotlib.pyplot as plt
from datetime import datetime
import time

def _plot_points_with_lines(points, stock_name, show_timestamps):
    plt.cla()
    if not points:
        return
    x_vals, y_vals = zip(*points)
    plt.plot(x_vals, y_vals, color='blue', linestyle='-', linewidth=2, label=f'{stock_name} Price')
    plt.scatter(x_vals, y_vals, color='red', zorder=3)
    plt.title(f"Live {stock_name} Price (USD)")
    if show_timestamps:
        plt.xlabel("Time")
    plt.ylabel("Price (USD)")
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.legend()
    if show_timestamps:
        plt.xticks(rotation=45)
    plt.tight_layout()
    plt.pause(0.1)

def draw_graph(price_func, stock_name: str, max_points: int | None = None, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of a stock or a crypto
    
    :param price_func: The price function that returns the live price of a stock or a crypto.
    :param stock_name: The name of the stock to be displayed on the graph.
    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of algorand on the x-axis.
    """

    plt.ion()
    prices = []

    while True:
        price = price_func()
        if price is not None:
            if show_timestamps:
                timestamp = datetime.now().strftime("%H:%M:%S")
            else:
                timestamp = ""
            if max_points:
                if len(prices) >= max_points:
                    prices.pop(0)
            prices.append((timestamp, price))
            _plot_points_with_lines(prices, stock_name, show_timestamps)
        if update_time:
            time.sleep(update_time)
