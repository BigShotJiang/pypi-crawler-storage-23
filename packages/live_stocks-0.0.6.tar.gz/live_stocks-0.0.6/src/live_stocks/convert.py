import yfinance as yf
import logging

logging.getLogger("yfinance").setLevel(logging.CRITICAL)
logging.getLogger("urllib3").setLevel(logging.CRITICAL)
logging.getLogger("urllib3.connectionpool").setLevel(logging.CRITICAL)
logging.getLogger("requests").setLevel(logging.CRITICAL)

def symbol_to_name(symbol: str, autocorrect: bool = True) -> str:
    """
    Gets the corresponding name for the symbol. Handles both stocks and cryptocurrency.

    :param symbol: The symbol of the stock/crypto.
    :param autocorrect: If you want to autocorrect the symbol. Example: AAPK -> APPL. Defaults to True.

    :return str: The name of the stock/crypto based on the symbol parameter.

    :raise ValueError: When yfinance raises an error or when the symbol is misspelled and the autocorrect, if it is on, cannot find the correct symbol.
    """
    symbol = symbol.upper()
    error_message = f"No name found for {symbol}."
    try:
        search = yf.search.Search(symbol, enable_fuzzy_query=autocorrect).all['quotes']
        if len(search) == 0:
            raise ValueError
        return search[0]['shortname']
    except Exception:
        raise ValueError(error_message)

def name_to_symbol(name: str, autocorrect: bool = True) -> str:
    """
    Gets the corresponding symbol for the name. Handles both stocks and cryptocurrency.

    :param name: The name of the stock/crypto.
    :param autocorrect: If you want to autocorrect the symbol. Example: Appld -> Apple. Defaults to True.

    :return str: The symbol of the stock/crypto based on the name parameter.

    :raise ValueError: When yfinance raises an error or when the name is misspelled and the autocorrect, if it is on, cannot find the correct name.
    """
    name = name.lower().capitalize()
    error_message = f"No symbol found for {name}."
    try:
        search = yf.search.Search(name, enable_fuzzy_query=autocorrect).all['quotes']
        if len(search) == 0:
            raise ValueError
        return search[0]['symbol']
    except Exception:
        raise ValueError(error_message)
