from .stock_crypto_price import get_price
from .graph_stock import draw_graph

def get_bitcoin() -> float:
    """
    Gets the current price Bitcoin
    """
    return get_price("BTC-USD")

def get_ethereum() -> float:
    """
    Gets the current price Ethereum
    """
    return get_price("ETH-USD")

def get_tether() -> float:
    """
    Gets the current price Tether
    """
    return get_price("USDT-USD")

def get_usd_coin() -> float:
    """
    Gets the current price USD Coin
    """
    return get_price("USDC-USD")

def get_solana() -> float:
    """
    Gets the current price Solana
    """
    return get_price("SOL-USD")

def get_cardano() -> float:
    """
    Gets the current price Cardano
    """
    return get_price("ADA-USD")

def get_dogecoin() -> float:
    """
    Gets the current price Dogecoin
    """
    return get_price("DOGE-USD")

def get_polygon() -> float:
    """
    Gets the current price Polygon
    """
    return get_price("MATIC-USD")

def get_litecoin() -> float:
    """
    Gets the current price Litecoin
    """
    return get_price("LTC-USD")

def get_avalanche() -> float:
    """
    Gets the current price Avalanche
    """
    return get_price("AVAX-USD")

def get_chainlink() -> float:
    """
    Gets the current price Chainlink
    """
    return get_price("LINK-USD")

def get_stellar() -> float:
    """
    Gets the current price Stellar
    """
    return get_price("XLM-USD")

def get_shiba_inu() -> float:
    """
    Gets the current price Shiba Inu
    """
    return get_price("SHIB-USD")

def get_uniswap() -> float:
    """
    Gets the current price Uniswap
    """
    return get_price("UNI-USD")

def get_cosmos() -> float:
    """
    Gets the current price Cosmos
    """
    return get_price("ATOM-USD")

def get_algorand() -> float:
    """
    Gets the current price Algorand
    """
    return get_price("ALGO-USD")

def get_aave() -> float:
    """
    Gets the current price Aave
    """
    return get_price("AAVE-USD")

def get_filecoin() -> float:
    """
    Gets the current price Filecoin
    """
    return get_price("FIL-USD")

def get_internet_computer() -> float:
    """
    Gets the current price Internet Computer
    """
    return get_price("ICP-USD")

def get_aptos() -> float:
    """
    Gets the current price Aptos
    """
    return get_price("APT-USD")

# Graph crypto
def graph_bitcoin(max_points: int | None = None, update_time: float | None = None, show_time_stamps: bool = True) -> None:
    """
    Draws the graph of Bitcoin using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of bitcoin on the x-axis.
    """
    draw_graph(get_bitcoin, "Bitcoin", max_points, update_time, show_time_stamps)

def graph_ethereum(max_points: int | None = None, update_time: float | None = None, show_time_stamps: bool = True) -> None:
    """
    Draws the graph of Ethereum using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of ethereum on the x-axis.
    """
    draw_graph(get_ethereum, "Enthereum", max_points, update_time, show_time_stamps)

def graph_tether(max_points: int | None = None, update_time: float | None = None, show_time_stamps: bool = True) -> None:
    """
    Draws the graph of Tether using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of tether on the x-axis.
    """
    draw_graph(get_tether, "Tether", max_points, update_time, show_time_stamps)

def graph_usd_coin(max_points: int | None = None, update_time: float | None = None, show_time_stamps: bool = True) -> None:
    """
    Draws the graph of USD Coin using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of usd_coin on the x-axis.
    """
    draw_graph(get_usd_coin, "USD Coin", max_points, update_time, show_time_stamps)

def graph_solana(max_points: int | None = None, update_time: float | None = None, show_time_stamps: bool = True) -> None:
    """
    Draws the graph of Solana using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of solana on the x-axis.
    """
    draw_graph(get_solana, "Solana", max_points, update_time, show_time_stamps)

def graph_cardano(max_points: int | None = None, update_time: float | None = None, show_time_stamps: bool = True) -> None:
    """
    Draws the graph of Cardano using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of cardano on the x-axis.
    """
    draw_graph(get_cardano, "Cardano", max_points, update_time, show_time_stamps)

def graph_dogecoin(max_points: int | None = None, update_time: float | None = None, show_time_stamps: bool = True) -> None:
    """
    Draws the graph of Dogecoin using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of dogecoin on the x-axis.
    """
    draw_graph(get_dogecoin, "Dogecoin", max_points, update_time, show_time_stamps)

def graph_polygon(max_points: int | None = None, update_time: float | None = None, show_time_stamps: bool = True) -> None:
    """
    Draws the graph of Polygon using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of polygon on the x-axis.
    """
    draw_graph(get_polygon, "Polygon", max_points, update_time, show_time_stamps)

def graph_litecoin(max_points: int | None = None, update_time: float | None = None, show_time_stamps: bool = True) -> None:
    """
    Draws the graph of Litecoin using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of litecoin on the x-axis.
    """
    draw_graph(get_litecoin, "Litecoin", max_points, update_time, show_time_stamps)

def graph_avalanche(max_points: int | None = None, update_time: float | None = None, show_time_stamps: bool = True) -> None:
    """
    Draws the graph of Avalanche using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of avalanche on the x-axis.
    """
    draw_graph(get_avalanche, "Avalanche", max_points, update_time, show_time_stamps)

def graph_chainlink(max_points: int | None = None, update_time: float | None = None, show_time_stamps: bool = True) -> None:
    """
    Draws the graph of Chainlink using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of chainlink on the x-axis.
    """
    draw_graph(get_chainlink, "Chainlink", max_points, update_time, show_time_stamps)

def graph_stellar(max_points: int | None = None, update_time: float | None = None, show_time_stamps: bool = True) -> None:
    """
    Draws the graph of Stellar using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of stellar on the x-axis.
    """
    draw_graph(get_stellar, "Stellar", max_points, update_time, show_time_stamps)

def graph_shiba_inu(max_points: int | None = None, update_time: float | None = None, show_time_stamps: bool = True) -> None:
    """
    Draws the graph of Shiba Inu using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of shiba_inu on the x-axis.
    """
    draw_graph(get_shiba_inu, "Shiba Inu", max_points, update_time, show_time_stamps)

def graph_uniswap(max_points: int | None = None, update_time: float | None = None, show_time_stamps: bool = True) -> None:
    """
    Draws the graph of Uniswap using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of uniswap on the x-axis.
    """
    draw_graph(get_uniswap, "Uniswap", max_points, update_time, show_time_stamps)

def graph_cosmos(max_points: int | None = None, update_time: float | None = None, show_time_stamps: bool = True) -> None:
    """
    Draws the graph of Cosmos using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of cosmos on the x-axis.
    """
    draw_graph(get_cosmos, "Cosmos", max_points, update_time, show_time_stamps)

def graph_algorand(max_points: int | None = None, update_time: float | None = None, show_time_stamps: bool = True) -> None:
    """
    Draws the graph of Algorand using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of algorand on the x-axis.
    """
    draw_graph(get_algorand, "Algorand", max_points, update_time, show_time_stamps)

def graph_aave(max_points: int | None = None, update_time: float | None = None, show_time_stamps: bool = True) -> None:
    """
    Draws the graph of Aave using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aave on the x-axis.
    """
    draw_graph(get_aave, "Aave", max_points, update_time, show_time_stamps)

def graph_filecoin(max_points: int | None = None, update_time: float | None = None, show_time_stamps: bool = True) -> None:
    """
    Draws the graph of Filecoin using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of filecoin on the x-axis.
    """
    draw_graph(get_filecoin, "Filecoin", max_points, update_time, show_time_stamps)

def graph_internet_computer(max_points: int | None = None, update_time: float | None = None, show_time_stamps: bool = True) -> None:
    """
    Draws the graph of Internet Computer using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of internet_computer on the x-axis.
    """
    draw_graph(get_internet_computer, "Internet Computer", max_points, update_time, show_time_stamps)

def graph_aptos(max_points: int | None = None, update_time: float | None = None, show_time_stamps: bool = True) -> None:
    """
    Draws the graph of Aptos using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_aptos, "Aptos", max_points, update_time, show_time_stamps)