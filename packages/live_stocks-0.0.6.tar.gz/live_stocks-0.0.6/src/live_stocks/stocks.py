from .stock_crypto_price import get_price
from .graph_stock import draw_graph

def get_apple() -> float:
    """
    Gets the current price of Apple.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("AAPL")

def get_microsoft() -> float:
    """
    Gets the current price of Microsoft.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("MSFT")

def get_google() -> float:
    """
    Gets the current price of Google.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("GOOGL")

def get_amazon() -> float:
    """
    Gets the current price of Amazon.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("AMZN")

def get_meta() -> float:
    """
    Gets the current price of Meta.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("META")

def get_nvidia() -> float:
    """
    Gets the current price of Nvidia.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("NVDA")

def get_tesla() -> float:
    """
    Gets the current price of Tesla.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("TSLA")

def get_berkshire_hathaway() -> float:
    """
    Gets the current price of Berkshire Hathaway.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("BRK-B")

def get_johnson_and_johnson() -> float:
    """
    Gets the current price of Johnson & Johnson.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("JNJ")

def get_jpmorgan() -> float:
    """
    Gets the current price of JP Morgan.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("JPM")

def get_vanguard_etf() -> float:
    """
    Gets the current price of Vanguard ETF.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("VOO")

def get_procter_and_gamble() -> float:
    """
    Gets the current price of Procter and Gamble.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("PG")

def get_mastercard() -> float:
    """
    Gets the current price of Mastercard.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("MA")

def get_home_depot() -> float:
    """
    Gets the current price of Home depot.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("HD")

def get_exxon_mobil() -> float:
    """
    Gets the current price of Exxon Mobil.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("XOM")

def get_chevron() -> float:
    """
    Gets the current price of Chevron.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("CVX")

def get_pepsico() -> float:
    """
    Gets the current price of Pepsico.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("PEP")

def get_coca_cola() -> float:
    """
    Gets the current price of Coca Cola.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("KO")

def get_disney() -> float:
    """
    Gets the current price of Disney.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("DIS")

def get_netflix() -> float:
    """
    Gets the current price of Netflix.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("NFLX")

def get_intel() -> float:
    """
    Gets the current price of Intel.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("INTC")

def get_amd() -> float:
    """
    Gets the current price of AMD.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("AMD")

def get_cisco() -> float:
    """
    Gets the current price of Cisco.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("CSCO")

def get_oracle() -> float:
    """
    Gets the current price of Oracle.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("ORCL")

def get_ibm() -> float:
    """
    Gets the current price of IBM.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("IBM")

def get_salesforce() -> float:
    """
    Gets the current price of Salesforce.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("CRM")

def get_adobe() -> float:
    """
    Gets the current price of Adobe.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("ADBE")

def get_paypal() -> float:
    """
    Gets the current price of Paypal.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("PYPL")

def get_square() -> float:
    """
    Gets the current price of Square.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("SQ")

def get_shopify() -> float:
    """
    Gets the current price of shopify.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("SHOP")

def get_airbnb() -> float:
    """
    Gets the current price of Airbnb.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("ABNB")

def get_uber() -> float:
    """
    Gets the current price of Uber.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("UBER")

def get_lyft() -> float:
    """
    Gets the current price of Lyft.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("LYFT")

def get_modern() -> float:
    """
    Gets the current price of Modern.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("MRNA")

def get_pfizer() -> float:
    """
    Gets the current price of Pfizer.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("PFE")

def get_boeing() -> float:
    """
    Gets the current price of Boeing.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("BA")

def get_lockheed_martin() -> float:
    """
    Gets the current price of Lockheed Martin.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("LMT")

def get_caterpillar() -> float:
    """
    Gets the current price of Caterpillar.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("CAT")

def get_ford() -> float:
    """
    Gets the current price of Ford.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("F")

def get_gm() -> float:
    """
    Gets the current price of GM.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("GM")

def get_starbucks() -> float:
    """
    Gets the current price of Starbucks.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("SBUX")

def get_mcdonalds() -> float:
    """
    Gets the current price of McDonalds.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("MCD")

def get_costco() -> float:
    """
    Gets the current price of Costco.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("COST")

def get_walmart() -> float:
    """
    Gets the current price of Walmart.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("WMT")

def get_target() -> float:
    """
    Gets the current price of Target.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("TGT")

def get_verizon() -> float:
    """
    Gets the current price of Verizon.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("VZ")

def get_att() -> float:
    """
    Gets the current price of ATT.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("T")

def get_tmobile() -> float:
    """
    Gets the current price of Tmobile.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("TMUS")

def get_s_and_p_500() -> float:
    """
    Gets the current price of S&P 500.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("^GSPC")

def get_dow_jones() -> float:
    """
    Gets the current price of Dow Jones.

    :return float: The value of the current price at the time the function is called.
    """
    return get_price("^DJI")

# Graph stocks
def graph_apple(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Apple using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_apple, "Apple", max_points, update_time, show_timestamps)

def graph_microsoft(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Microsoft using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_microsoft, "Microsoft", max_points, update_time, show_timestamps)

def graph_google(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Google using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_google, "Google", max_points, update_time, show_timestamps)

def graph_amazon(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Amazon using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_amazon, "Amazon", max_points, update_time, show_timestamps)

def graph_meta(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Meta using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_meta, "Meta", max_points, update_time, show_timestamps)

def graph_nvidia(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Nvidia using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_nvidia, "Nvidia", max_points, update_time, show_timestamps)

def graph_tesla(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Tesla using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_tesla, "Tesla", max_points, update_time, show_timestamps)

def graph_berkshire_hathaway(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Berkshire Hathaway using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_berkshire_hathaway, "Berkshire Hathaway", max_points, update_time, show_timestamps)

def graph_johnson_and_johnson(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Johnson & Johnson using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_johnson_and_johnson, "Johnson & Johnson", max_points, update_time, show_timestamps)

def graph_jpmorgan(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of JP Morgan using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_jpmorgan, "JP Morgan", max_points, update_time, show_timestamps)

def graph_vanguard_etf(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Vanguard ETF using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_vanguard_etf, "Vanguard ETF", max_points, update_time, show_timestamps)

def graph_procter_and_gamble(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Procter & Gamble using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_procter_and_gamble, "Procter & Gamble", max_points, update_time, show_timestamps)

def graph_mastercard(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Mastercard using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_mastercard, "Mastercard", max_points, update_time, show_timestamps)

def graph_home_depot(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Home Depot using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_home_depot, "Home Depot", max_points, update_time, show_timestamps)

def graph_exxon_mobil(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Exxon Mobil using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_exxon_mobil, "Exxon Mobil", max_points, update_time, show_timestamps)

def graph_chevron(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Chevronn using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_chevron, "Chevronn", max_points, update_time, show_timestamps)

def graph_pepsico(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Pepsico using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_pepsico, "Pepsico", max_points, update_time, show_timestamps)

def graph_coca_cola(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Coca Cola using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_coca_cola, "Coca Cola", max_points, update_time, show_timestamps)

def graph_disney(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Disney using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_disney, "Disney", max_points, update_time, show_timestamps)

def graph_netflix(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Netflix using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_netflix, "Netflix", max_points, update_time, show_timestamps)

def graph_intel(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Intel using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_intel, "Intel", max_points, update_time, show_timestamps)

def graph_amd(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of AMD using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_amd, "AMD", max_points, update_time, show_timestamps)

def graph_cisco(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Cisco using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_cisco, "Cisco", max_points, update_time, show_timestamps)

def graph_oracle(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Oracle using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_oracle, "Oracle", max_points, update_time, show_timestamps)

def graph_ibm(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of IBM using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_ibm, "IBM", max_points, update_time, show_timestamps)

def graph_salesforce(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Salesforce using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_salesforce, "Salesforce", max_points, update_time, show_timestamps)

def graph_adobe(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Adobe using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_adobe, "Adobe", max_points, update_time, show_timestamps)

def graph_paypal(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of PayPal using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_paypal, "PayPal", max_points, update_time, show_timestamps)

def graph_square(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Square using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_square, "Square", max_points, update_time, show_timestamps)

def graph_shopify(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Shopify using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_shopify, "Shopify", max_points, update_time, show_timestamps)

def graph_airbnb(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Airbnb using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_airbnb, "Airbnb", max_points, update_time, show_timestamps)

def graph_uber(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Uber using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_uber, "Uber", max_points, update_time, show_timestamps)

def graph_lyft(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Lyft using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_lyft, "Lyft", max_points, update_time, show_timestamps)

def graph_modern(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Modern using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_modern, "Modern", max_points, update_time, show_timestamps)

def graph_pfizer(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Pfizer using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_pfizer, "Pfizer", max_points, update_time, show_timestamps)

def graph_boeing(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Boeing using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_boeing, "Boeing", max_points, update_time, show_timestamps)

def graph_lockheed_martin(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Lockheed Martin using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_lockheed_martin, "Lockheed Martin", max_points, update_time, show_timestamps)

def graph_caterpillar(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Caterpillar using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_caterpillar, "Caterpillar", max_points, update_time, show_timestamps)

def graph_ford(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Ford using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_ford, "Ford", max_points, update_time, show_timestamps)

def graph_gm(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of GM using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_gm, "GM", max_points, update_time, show_timestamps)

def graph_starbucks(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Starbucks using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_starbucks, "Starbucks", max_points, update_time, show_timestamps)

def graph_mcdonalds(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of McDonalds using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_mcdonalds, "McDonalds", max_points, update_time, show_timestamps)

def graph_costco(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Costco using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_costco, "Costco", max_points, update_time, show_timestamps)

def graph_walmart(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Walmart using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_walmart, "Walmart", max_points, update_time, show_timestamps)

def graph_target(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Target using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_target, "Target", max_points, update_time, show_timestamps)

def graph_verizon(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Verizon using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_verizon, "Verizon", max_points, update_time, show_timestamps)

def graph_att(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of ATT using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_att, "ATT", max_points, update_time, show_timestamps)

def graph_tmobile(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of T-Mobile using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_tmobile, "T-Mobile", max_points, update_time, show_timestamps)

def graph_s_and_p_500(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of S&P 500 using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_s_and_p_500, "S&P 500", max_points, update_time, show_timestamps)

def graph_dow_jones(max_points: int = 50, update_time: float | None = None, show_timestamps: bool = True) -> None:
    """
    Draws the graph of Dow Jones using matplotlib.pyplot.

    :param max_points: The max_points to show on the graph. When the amount of points get larger than the max_points, the code will automatically remove the first point. Defaults to None meaning that the code won't remove any points.
    :param update_time: The amount of time the graph should update. Defaults to None, meaning that the graph will update when it gets a different price for the crypto.
    :param show_time_stamps: If you want to show the time that the code the price of aptos on the x-axis.
    """
    draw_graph(get_dow_jones, "Dow Jones", max_points, update_time, show_timestamps)