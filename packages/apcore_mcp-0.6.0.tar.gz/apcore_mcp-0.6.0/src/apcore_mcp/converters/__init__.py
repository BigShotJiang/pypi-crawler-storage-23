"""Converters: OpenAI tools format conversion."""
