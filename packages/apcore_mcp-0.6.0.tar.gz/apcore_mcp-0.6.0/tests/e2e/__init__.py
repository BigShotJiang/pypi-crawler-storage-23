"""End-to-end tests for apcore-mcp."""
