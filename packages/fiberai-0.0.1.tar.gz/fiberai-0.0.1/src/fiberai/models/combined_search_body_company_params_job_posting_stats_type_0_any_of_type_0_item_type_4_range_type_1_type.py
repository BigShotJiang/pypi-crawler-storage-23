from enum import Enum

class CombinedSearchBodyCompanyParamsJobPostingStatsType0AnyOfType0ItemType4RangeType1Type(str, Enum):
    PERCENT_RANGE = "percent-range"

    def __str__(self) -> str:
        return str(self.value)
