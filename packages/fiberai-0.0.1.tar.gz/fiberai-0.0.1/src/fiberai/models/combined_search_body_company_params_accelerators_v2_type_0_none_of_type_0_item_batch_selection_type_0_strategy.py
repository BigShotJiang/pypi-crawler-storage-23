from enum import Enum

class CombinedSearchBodyCompanyParamsAcceleratorsV2Type0NoneOfType0ItemBatchSelectionType0Strategy(str, Enum):
    ALL_BATCHES = "all-batches"

    def __str__(self) -> str:
        return str(self.value)
