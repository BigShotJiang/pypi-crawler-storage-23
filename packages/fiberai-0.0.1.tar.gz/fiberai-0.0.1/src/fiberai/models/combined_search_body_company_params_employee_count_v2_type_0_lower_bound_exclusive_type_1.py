from enum import IntEnum

class CombinedSearchBodyCompanyParamsEmployeeCountV2Type0LowerBoundExclusiveType1(IntEnum):
    VALUE_1 = 1

    def __str__(self) -> str:
        return str(self.value)
