from enum import Enum

class CombinedSearchBodyCompanyParamsHeadquartersLocationType0SubtractAllType0ItemType0RadiusType1Unit(str, Enum):
    KILOMETERS = "kilometers"

    def __str__(self) -> str:
        return str(self.value)
