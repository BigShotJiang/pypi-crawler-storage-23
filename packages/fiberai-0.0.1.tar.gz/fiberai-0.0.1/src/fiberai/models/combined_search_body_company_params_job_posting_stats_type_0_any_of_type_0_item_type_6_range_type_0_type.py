from enum import Enum

class CombinedSearchBodyCompanyParamsJobPostingStatsType0AnyOfType0ItemType6RangeType0Type(str, Enum):
    COUNT_RANGE = "count-range"

    def __str__(self) -> str:
        return str(self.value)
