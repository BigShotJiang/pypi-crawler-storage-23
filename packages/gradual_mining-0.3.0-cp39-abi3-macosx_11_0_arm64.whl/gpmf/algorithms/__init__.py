"""Gradual pattern mining algorithms."""

from .base_algorithm import BaseAlgorithm

__all__ = ['BaseAlgorithm']
