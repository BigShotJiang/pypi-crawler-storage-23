from promptdepot.cli.main import app

__all__ = ["app", "main"]


def main() -> None:
    app()
