"""
SimpleDML - Simple Data Manipulation Language Operations

This module provides simple DML operations with capacity management and recent data focus.
It caps the number of recent DML operations even when the number of clients is unknown
by looking at the effective changes on the tables periodically.

Key Features:
- Monitors effective table changes through polling intervals
- Caps DML operations based on actual table state, not client count
- DELETE operations (remove old rows based on time threshold)
- UPDATE operations (modify existing rows with new timestamps)  
- INSERT operations (add new rows with current timestamps)
- Combined DELETE_UPDATE_INSERT operations (coordinated execution)
- Round-robin table selection for load balancing
- Multi-database support (MySQL, PostgreSQL, SQLite, Oracle, SQL Server)
- Intelligent capacity management regardless of unknown client scenarios
"""

import sqlalchemy as sa
import urllib.parse
import pandas as pd
import queue
import datetime
import random
import threading
from typing import Literal, Optional
from sqlalchemy.dialects.mssql import NVARCHAR
from sqlalchemy import TypeDecorator
from .LfcNotebookConfig import LfcNotebookConfig
from .LfcCredentialModel import LfcCredential
from .SimpleConn import SimpleConn
from .LfcScheduler import LfcScheduler
from pydantic import ValidationError

# Register SQL Server sysname type to suppress SQLAlchemy warnings
class SYSNAME(TypeDecorator):
    """SQL Server sysname type (equivalent to NVARCHAR(128) NOT NULL)"""
    impl = NVARCHAR
    cache_ok = True
    
    def __init__(self):
        super().__init__(length=128)

# Register the sysname type with SQL Server dialect
try:
    from sqlalchemy.dialects import mssql
    mssql.base.ischema_names['sysname'] = SYSNAME
except ImportError:
    # mssql dialect not available, skip registration
    pass

class SimpleDML:
    """SimpleDML - Simple Data Manipulation Language Operations
    
    Provides simple DML operations with capacity management and recent data focus.
    Caps the number of recent DML operations even when the number of clients is unknown
    by monitoring effective changes on tables through polling intervals. Uses actual
    table state to determine capacity limits rather than relying on client count.
    
    Initialization:
    ===============
    Direct instantiation with secrets_json - both secrets_json and config are REQUIRED:
    
        dml = SimpleDML(
            secrets_json=d.secrets_json,      # V2 credentials (REQUIRED - validated with LfcCredential)
            config=config,                    # Notebook config (REQUIRED - validated with LfcNotebookConfig)
            lfc_scheduler=scheduler,          # Optional: LfcScheduler for auto-scheduling DML operations
            metadata_refresh_interval=300     # Optional: refresh metadata every 5 minutes
        )
    
    Both secrets_json and config are validated using Pydantic models:
    - secrets_json → LfcCredential (V2 format only)
    - config → LfcNotebookConfig (accepts dict or LfcNotebookConfig instance)
    
    Instance Attributes:
    ===================
    After initialization, the following attributes are available:
    - self.credential: LfcCredential - Validated credential object from secrets_json
    - self.engine: SQLAlchemy Engine - Database connection engine
    - self.config: LfcNotebookConfig - Validated notebook configuration
    - self.schema: str - Database schema (from credential, config, or defaults)
    - self.metadata: SQLAlchemy MetaData - Database metadata for table operations
    
    Example Usage:
    ==============
    
        # Setup config
        config = {
            "source_connection_name": "lfcddemo-azure-sqlserver",
            "cdc_qbc": "cdc",
            "target_catalog": "main",
            "source_schema": None,
            "database": {"cloud": "azure", "type": "sqlserver"}
        }
        
        # Create scheduler and DbxRest
        scheduler = lfcdemolib.LfcScheduler()
        d = lfcdemolib.DbxRest(dbutils=dbutils, config=config, lfc_scheduler=scheduler)
        
        # Create SimpleDML directly
        dml = SimpleDML(d.secrets_json, config=config, lfc_scheduler=scheduler)
    
    Default Configuration:
    - DEFAULT_MAX_ROWS = 10 (maximum rows to process per operation)
    - DEFAULT_TIME_WINDOW_SECONDS = 60 (1 minute polling/time window for operations)
    
    Core Strategy:
    - Polls tables at regular intervals to assess effective changes
    - Caps DML operations based on actual recent activity in tables
    - Works regardless of unknown number of concurrent clients
    - Maintains data consistency through intelligent capacity management
    - Uses round-robin table selection for balanced load distribution
    """
    
    DRIVERS = {
        "mysql": "mysql+pymysql",
        "postgresql": "postgresql+psycopg2", 
        "sqlserver": "mssql+pymssql",
        "oracle": "oracle+oracledb",
        "sqlite": "sqlite"
    }
    
    DATETIME_COLUMN_NAMES = ['dt', 'created_at', 'updated_at', 'timestamp']
    DATETIME_COLUMN_NAMES_CASEFOLDED = [name.casefold() for name in DATETIME_COLUMN_NAMES]
    DATETIME_TYPE_PATTERNS = [
        'datetime', 'timestamp', 'timestamptz', 'datetime2', 
        'smalldatetime', 'datetimeoffset', 'timestamp with time zone',
        'timestamp without time zone'
    ]
    
    # Default configuration values
    DEFAULT_MAX_ROWS = 10
    DEFAULT_TIME_WINDOW_SECONDS = 60
    
    def __init__(self, secrets_json, config, lfc_scheduler: Optional[LfcScheduler] = None, 
                 metadata_refresh_interval: int = None,
                 time_window_seconds: int = None, run_duration_sec: int = 3600, 
                 workspace_client=None, auto_recreate: bool = False):
        """Initialize SimpleDML with secrets_json and config
        
        Args:
            secrets_json: Dictionary containing V2 connection credentials (REQUIRED)
                         Will be validated using LfcCredential Pydantic model
                         Schema is extracted from secrets_json.schema
            config: Configuration dict or LfcNotebookConfig instance (REQUIRED)
                   If dict, will be converted to LfcNotebookConfig
                   If config.source_schema is provided, it overrides the schema from secrets_json
            lfc_scheduler: Optional LfcScheduler instance for auto-scheduling DML operations
            metadata_refresh_interval: Interval for metadata refresh (default: from config or None)
            time_window_seconds: Time window for DML operations (default: from config or 60s)
            run_duration_sec: Duration for scheduled operations (default: 3600s)
            workspace_client: Optional Databricks WorkspaceClient for auto-recreation
            auto_recreate: Whether to automatically recreate database on connection failure (default: False)
        
        Schema Priority (highest to lowest):
            1. config.source_schema (if explicitly provided)
            2. secrets_json.schema (from LfcCredential)
            3. Database-specific defaults (dbo/public/catalog)
            
        Raises:
            ValueError: If config is not provided, secrets_json validation fails, or schema cannot be determined
            TypeError: If config is not dict or LfcNotebookConfig
            ValidationError: If secrets_json doesn't match V2 format
        """
        # Validate secrets_json using LfcCredential Pydantic model
        try:
            credential = LfcCredential.from_dict(secrets_json)
            print(f"✅ Validated secrets for {credential.connection_name or credential.name or 'connection'}")
        except ValidationError as e:
            # Provide helpful error message with details
            error_details = []
            for error in e.errors():
                field = '.'.join(str(x) for x in error['loc'])
                msg = error['msg']
                error_details.append(f"{field}: {msg}")
            raise ValueError(
                f"Invalid V2 secrets format: {'; '.join(error_details)}. "
                f"Provided fields: {list(secrets_json.keys())}"
            ) from e
        
        if config is None:
            raise ValueError(
                "config is required. Provide either a dict or LfcNotebookConfig instance."
            )
        
        # Convert config to LfcNotebookConfig if it's a dict
        if isinstance(config, dict):
            config = LfcNotebookConfig(config)
        elif not isinstance(config, LfcNotebookConfig):
            raise TypeError(
                f"config must be dict or LfcNotebookConfig, got {type(config).__name__}"
            )
        
        # Create engine using SimpleConn
        conn = SimpleConn(workspace_client=workspace_client)
        engine = conn.create_engine_from_secrets(secrets_json, auto_recreate=auto_recreate)
        
        # Store conn, credential, engine, and config
        self.conn = conn  # Store SimpleConn for later use
        self.credential = credential  # Store validated LfcCredential for later use
        self.engine = engine
        self.db_dialect = engine.dialect.name.lower()  # Cache dialect for performance
        self.config = config
        
        # Extract schema: First from secrets_json (credential), then override with config if provided
        # Priority: config.source_schema > credential.schema_name > database-specific defaults
        self.schema = credential.schema_name  # Get schema from validated credential
        
        # Override with config.source_schema if explicitly provided
        if self.config.source_schema is not None:
            self.schema = self.config.source_schema
        
        # If still None, apply database-specific defaults
        if self.schema is None:
            if self.db_dialect in ['mssql', 'sqlserver']:
                self.schema = 'dbo'
            elif self.db_dialect in ['postgresql', 'postgres']:
                self.schema = 'public'
            elif self.db_dialect == 'mysql':
                # MySQL uses database as schema
                self.schema = engine.url.database
            else:
                # Default fallback
                self.schema = 'public'
        
        # Validate that schema is set and not empty
        if not self.schema or self.schema == '':
            raise ValueError(
                f"Schema could not be determined. "
                f"credential.schema_name={credential.schema_name}, "
                f"config.source_schema={self.config.source_schema}, "
                f"db_type={credential.db_type}. "
                f"Please explicitly set 'schema' in secrets_json or 'source_schema' in config."
            )
        
        # Extract configuration values from config if not provided as parameters
        if metadata_refresh_interval is None:
            metadata_refresh_interval = getattr(self.config, 'metadata_refresh_interval', None)
        
        if time_window_seconds is None:
            time_window_seconds = getattr(self.config, 'time_window_seconds', None)
            
        if run_duration_sec is None:
            config_run_duration = getattr(self.config, 'run_duration_sec', None)
            if config_run_duration is not None:
                run_duration_sec = config_run_duration
        
        # Initialize round-robin state
        self._table_index = 0
        self._table_lock = threading.Lock()
        self._table_list = []  # Initialize empty list
        
        # Initialize metadata and table queue
        self._refresh_metadata()
        
        # Auto-schedule if lfc_scheduler is provided
        if lfc_scheduler is not None:
            self.schedule_delete_update_insert(lfc_scheduler.scheduler, time_window_seconds, run_duration_sec)
            
            # Schedule metadata refresh if interval is specified
            if metadata_refresh_interval is not None:
                self.schedule_metadata_refresh(lfc_scheduler.scheduler, metadata_refresh_interval, run_duration_sec)
                print(f"✅ SimpleDML auto-scheduled: DML operations + metadata refresh every {metadata_refresh_interval}s for {run_duration_sec}s")
            else:
                print(f"✅ SimpleDML auto-scheduled: DML operations for {run_duration_sec}s")
    
    def _get_display_schema(self):
        """Get display schema name (for Oracle, uses catalog username; for others, uses schema)"""
        if self.db_dialect == 'oracle':
            # For Oracle, the actual schema is the connected username (from catalog)
            # Extract username from catalog (e.g., 'g77b202cd67381c_o2ekey2ag0x9ux42_high.adb...' -> 'g77b202cd67381c')
            if hasattr(self, 'credential') and self.credential.catalog:
                return self.credential.catalog.split('_')[0].upper()
            return 'CURRENT_USER'
        return self.schema
    
    def _get_next_table(self):
        """Get next table using thread-safe round-robin index"""
        with self._table_lock:
            if not self._table_list:
                # Get display schema (correct for Oracle)
                schema_path = self._get_display_schema()
                print(f"⚠️ No tables available for round-robin selection in {schema_path}")
                print(f"   Available tables: {self._table_list if hasattr(self, '_table_list') else 'None'}")
                return None
            
            # Try to get next valid table (skip tables that fail to load)
            attempts = 0
            max_attempts = len(self._table_list)
            
            while attempts < max_attempts:
                table_name = self._table_list[self._table_index]
                current_position = self._table_index + 1
                total_tables = len(self._table_list)
                
                # Advance to next table (with wraparound)
                self._table_index = (self._table_index + 1) % len(self._table_list)
                attempts += 1
                
                # Get table info from cached dictionary
                table_info = self._get_table_info(table_name)
                
                if table_info is not None and table_info.get('columns'):
                    # Add metadata for round-robin tracking
                    table_info['name'] = table_name
                    table_info['_round_robin_info'] = f"{current_position}/{total_tables}"
                    return table_info
                else:
                    # Skip this table and try next one
                    print(f"   ⏭️  Skipping table '{table_name}' (no info available)")
                    continue
            
            # All tables failed to load
            print(f"⚠️  All {max_attempts} tables failed to load")
            return None
    
    def get_table_info(self):
        """Get information about available tables and round-robin state"""
        with self._table_lock:
            table_list = sorted(self._table_list) if hasattr(self, '_table_list') else []
            return {
                'table_count': len(table_list),
                'tables': table_list,
                'current_index': self._table_index if hasattr(self, '_table_index') else 0,
                'round_robin_order': self._table_list.copy() if hasattr(self, '_table_list') else [],
                'randomized_order': True
            }
    
    def test_round_robin(self, num_selections=5):
        """Test round-robin selection by getting multiple tables"""
        print(f"🔍 Testing round-robin selection ({num_selections} selections):")
        selections = []
        
        for i in range(num_selections):
            try:
                table = self._get_next_table()
                if table is None:
                    print(f"  {i+1}. SKIPPED: No valid table available")
                    selections.append("SKIPPED")
                else:
                    table_name = self._get_qualified_table_name(table)
                    selections.append(table_name)
                    print(f"  {i+1}. {table_name}")
            except Exception as e:
                print(f"  {i+1}. ERROR: {e}")
                break
        
        print(f"📊 Selection pattern: {' → '.join(selections)}")
        return selections
    
    def _get_table(self, table_name: str):
        """Get specific table info by name
        
        Returns:
            dict: Table info dict, or None if not found
        """
        # Check if table exists in our table list
        if hasattr(self, '_table_list'):
            for name in self._table_list:
                if name.endswith(table_name) or name == table_name:
                    table_info = self._get_table_info(name)
                    if table_info:
                        table_info['name'] = name
                    return table_info
        return None
    
    def _get_datetime_column(self, table):
        """Get first datetime column from table
        
        Args:
            table: Table info dict with 'columns' list
            
        Returns:
            dict: Column info dict {'name': 'dt', 'type': 'TIMESTAMP', ...}
        """
        columns = table.get('columns', [])
        table_name = table.get('name', 'unknown')
        
        for col in columns:
            col_type_str = str(col['type']).casefold()
            col_name_lower = col['name'].casefold()
            
            # Check if column type matches datetime patterns
            if any(dt_type in col_type_str for dt_type in self.DATETIME_TYPE_PATTERNS):
                return col
            # Check if column name matches common datetime names
            elif col_name_lower in self.DATETIME_COLUMN_NAMES_CASEFOLDED:
                return col
        
        raise ValueError(f"No datetime column found in table {table_name}")
    
    def _has_ops_column(self, table):
        """Check if table has an 'ops' column
        
        Args:
            table: Table info dict with 'columns' list
            
        Returns:
            bool: True if table has 'ops' column
        """
        columns = table.get('columns', [])
        return any(col['name'].casefold() == 'ops' for col in columns)
    
    def _get_qualified_table_name(self, table):
        """Get fully qualified table name with schema.table format
        
        For Oracle: Returns just table name (tables are in current user's schema)
        For other databases: Returns schema.table format
        
        Args:
            table: Table info dict with 'name' and 'qualified_name' keys,
                   or table name string
        """
        # Handle dict structure
        if isinstance(table, dict):
            return table.get('qualified_name', table.get('name', 'unknown'))
        
        # Handle string (table name only)
        if self.db_dialect == 'oracle':
            return table
        return f"{self.schema}.{table}" if self.schema else table
    
    def _get_table_and_column_info_from_db(self) -> dict:
        """Get table and column information directly from database using SQL queries
        
        Returns:
            dict: Dictionary mapping table names to their column information
                  Format: {
                      'table1': {
                          'columns': [
                              {'name': 'col1', 'type': 'VARCHAR', 'nullable': True, ...},
                              {'name': 'col2', 'type': 'INTEGER', 'nullable': False, ...}
                          ],
                          'schema': 'schema_name',
                          'qualified_name': 'schema.table1'
                      },
                      ...
                  }
        """
        table_info = {}
        
        try:
            with self.engine.connect() as conn:
                # Get all columns for all tables in schema
                if self.db_dialect == 'oracle':
                    # Oracle: Query USER_TAB_COLS
                    query = sa.text("""
                        SELECT 
                            TABLE_NAME,
                            COLUMN_NAME,
                            DATA_TYPE,
                            NULLABLE,
                            COLUMN_ID as ORDINAL_POSITION,
                            DATA_LENGTH as CHARACTER_MAXIMUM_LENGTH
                        FROM USER_TAB_COLS 
                        WHERE HIDDEN_COLUMN = 'NO'
                        ORDER BY TABLE_NAME, COLUMN_ID
                    """)
                else:
                    # Other databases: Query INFORMATION_SCHEMA.COLUMNS
                    query = sa.text(f"""
                        SELECT 
                            TABLE_NAME,
                            COLUMN_NAME,
                            DATA_TYPE,
                            IS_NULLABLE,
                            ORDINAL_POSITION,
                            CHARACTER_MAXIMUM_LENGTH
                        FROM INFORMATION_SCHEMA.COLUMNS 
                        WHERE TABLE_SCHEMA='{self.schema}'
                        ORDER BY TABLE_NAME, ORDINAL_POSITION
                    """)
                
                result = conn.execute(query)
                
                # Process results into table_info structure
                for row in result.fetchall():
                    table_name = row[0]
                    column_name = row[1]
                    data_type = row[2]
                    nullable = row[3]
                    ordinal_position = row[4]
                    char_max_length = row[5] if len(row) > 5 else None
                    
                    # Initialize table entry if not exists
                    if table_name not in table_info:
                        # Determine qualified name
                        if self.db_dialect == 'oracle':
                            qualified_name = table_name
                        else:
                            qualified_name = f"{self.schema}.{table_name}" if self.schema else table_name
                        
                        table_info[table_name] = {
                            'columns': [],
                            'schema': self._get_display_schema() if self.db_dialect == 'oracle' else self.schema,
                            'qualified_name': qualified_name
                        }
                    
                    # Add column info
                    column_info = {
                        'name': column_name,
                        'type': data_type,
                        'nullable': nullable in ('YES', 'Y', True, 1),
                        'ordinal_position': ordinal_position,
                        'character_maximum_length': char_max_length
                    }
                    table_info[table_name]['columns'].append(column_info)
                
                return table_info
                
        except Exception as e:
            print(f"⚠️  Error querying table and column information: {e}")
            import traceback
            traceback.print_exc()
            return {}
    
    def _get_table_info(self, table_name: str):
        """Get table information from cached table_info dictionary
        
        Args:
            table_name: Name of the table
            
        Returns:
            dict: Table information including columns, or None if not found
                  Format: {
                      'columns': [...],
                      'schema': 'schema_name',
                      'qualified_name': 'schema.table'
                  }
        """
        if not hasattr(self, 'table_info'):
            return None
        
        return self.table_info.get(table_name)
    
    def _refresh_metadata(self):
        """Refresh metadata and rebuild table queue (thread-safe)"""
        
        # Get table and column information from database using SQL queries
        # Store in self.table_info for public access
        self.table_info = self._get_table_and_column_info_from_db()
        new_tables = sorted(list(self.table_info.keys()))
        
        # If no tables exist, create seed tables ONLY ONCE
        if not new_tables and not hasattr(self, '_seed_tables_created'):
            # Get display schema (correct for Oracle)
            display_schema = self._get_display_schema()
            print(f"⚠️  No tables found in schema '{display_schema}'. Creating seed tables...")
            self._seed_tables_created = True  # Set flag to prevent re-creation
            
            try:
                from .SimpleDB import SimpleDB
                
                # Create seed tables with secrets_json for the credential information
                # Reconstruct a minimal secrets_json from the credential
                secrets_json = {
                    'version': 'v2',
                    'name': self.credential.name,
                    'db_type': self.credential.db_type,
                    'host_fqdn': self.credential.host_fqdn,
                    'catalog': self.credential.catalog,
                    'user': self.credential.user,
                    'password': self.credential.password,
                    'port': self.credential.port,
                    'schema': self.schema,
                    'dba': {
                        'user': self.credential.dba.user,
                        'password': self.credential.dba.password
                    },
                    'cloud': {
                        'provider': self.credential.cloud.provider
                    },
                    'replication_mode': self.credential.replication_mode
                }
                
                # Include options if present (for Oracle wallet, etc.)
                if self.credential.options:
                    secrets_json['options'] = self.credential.options
                
                result = SimpleDB.create_seed_tables(
                    engine=self.engine,
                    schema=self.schema,
                    table_count_per_type=2,
                    rows_per_table=5,
                    secrets_json=secrets_json
                )
                
                if result['status'] in ['success', 'partial']:
                    print(f"✅ Created {result['tables_created']} seed tables with {result['rows_inserted']} rows")
                    print(f"   Tables: {result['table_names']}")
                    
                    # Refresh table and column info to pick up newly created tables
                    # Query database directly using SQL
                    self.table_info = self._get_table_and_column_info_from_db()
                    new_tables = sorted(list(self.table_info.keys()))
                    
                    if new_tables:
                        print(f"✅ Detected {len(new_tables)} tables after creation")
                        print(f"   First 5 tables: {new_tables[:5]}")
                    else:
                        print(f"⚠️  Warning: No tables found after creation")
                        print(f"   This should not happen - please check database manually")
                else:
                    print(f"⚠️  Failed to create seed tables: {result.get('errors', 'Unknown error')}")
            except Exception as e:
                print(f"⚠️  Error creating seed tables: {e}")
                import traceback
                traceback.print_exc()
        
        # Atomically replace old table list with new one
        old_table_list = self._table_list.copy() if hasattr(self, '_table_list') else []
        old_table_count = len(old_table_list)
        
        with self._table_lock:
            # Table info is now stored in self.table_info dictionary
            # No SQLAlchemy MetaData needed
            
            # Only reset round-robin index if table list actually changed
            if set(new_tables) != set(old_table_list):
                # Randomize only when table list changes (not on every refresh)
                random.shuffle(new_tables)
                self._table_list = new_tables
                self._table_index = 0  # Reset index only when tables change
                print(f"🔄 Round-robin reset: table list changed from {len(old_table_list)} to {len(new_tables)} tables")
                print(f"🔍 Table order: {self._table_list}")
            else:
                # Keep existing order and position if tables are the same
                # Don't randomize on every refresh - this was causing the position confusion
                if not old_table_list:
                    # First time initialization - randomize once
                    random.shuffle(new_tables)
                    self._table_list = new_tables
                    self._table_index = 0
                    print(f"🔍 Table order: {self._table_list}")
                else:
                    # Keep existing order and position
                    self._table_list = old_table_list
                    # No change to self._table_index
        
        new_table_count = len(new_tables)
        
        # Only report metadata refresh when table changes are detected
        if new_table_count != old_table_count:
            if new_table_count > old_table_count:
                change_info = f"(+{new_table_count - old_table_count} added)"
            else:
                change_info = f"(-{old_table_count - new_table_count} removed)"
            print(f"✅ Metadata refreshed: {old_table_count} → {new_table_count} tables {change_info}")
        
        return new_table_count
    
    def refresh_metadata(self):
        """Manually refresh metadata and table discovery
        
        Returns:
            int: Number of tables discovered after refresh
        """
        return self._refresh_metadata()
    
    def schedule_metadata_refresh(self, scheduler, refresh_interval_seconds: int, run_duration_sec: int = 3600):
        """Schedule automatic metadata refresh
        
        Args:
            scheduler: APScheduler instance
            refresh_interval_seconds: Seconds between metadata refreshes
            run_duration_sec: Total duration to run refreshes (default: 3600)
        """
        # Use unique job ID per database (host_fqdn + catalog)
        job_id = f"{self.credential.host_fqdn}_{self.credential.catalog}_metadata_refresh"
        print(f"🔄 Scheduling metadata refresh job: {job_id}")
        
        scheduler.add_job(
            self._refresh_metadata,
            'interval', 
            seconds=refresh_interval_seconds, 
            replace_existing=False, 
            id=job_id,
            end_date=datetime.datetime.now() + datetime.timedelta(seconds=run_duration_sec),
            next_run_time=datetime.datetime.now() + datetime.timedelta(seconds=refresh_interval_seconds)
        )
    
    
    def get_table_info_detailed(self):
        """Get information about currently discovered tables (with qualified names)
        
        Returns:
            dict: Information about tables including count, names, and schema
        """
        table_names = self._table_list if hasattr(self, '_table_list') else []
        qualified_names = []
        for name in table_names:
            try:
                table_info = self._get_table_info(name)
                if table_info is not None:
                    qualified_names.append(table_info.get('qualified_name', name))
                else:
                    qualified_names.append(f"{name} (no info)")
            except Exception:
                qualified_names.append(f"{name} (error)")  # Fallback to simple name on error
        
        return {
            'schema': self.schema,
            'table_count': len(table_names),
            'table_names': table_names,
            'qualified_names': qualified_names
        }
    
    def _get_time_threshold(self, seconds_back: int):
        """Get database-native time threshold SQL expression
        
        Returns a SQL string expression (not a bound parameter) for the time threshold.
        This allows using database-specific date/time functions.
        """
        if self.db_dialect == 'mysql':
            return f"DATE_SUB(NOW(), INTERVAL {seconds_back} SECOND)"
        elif self.db_dialect == 'postgresql':
            return f"NOW() - INTERVAL '{seconds_back} seconds'"
        elif self.db_dialect == 'mssql':
            return f"DATEADD(second, -{seconds_back}, GETDATE())"
        elif self.db_dialect == 'oracle':
            return f"SYSDATE - INTERVAL '{seconds_back}' SECOND"
        elif self.db_dialect == 'sqlite':
            return f"datetime('now', '-{seconds_back} seconds')"
        else:
            return f"DATE_SUB(NOW(), INTERVAL {seconds_back} SECOND)"
    
    def _get_current_time_sql(self):
        """Get database-specific current time SQL"""
        dialect = self.engine.dialect.name
        if dialect == 'mysql':
            return "NOW()"
        elif dialect == 'postgresql':
            return "NOW()"
        elif dialect == 'mssql':
            return "GETDATE()"
        elif dialect == 'sqlite':
            return "datetime('now')"
        elif dialect == 'oracle':
            return "SYSDATE"
        else:
            return "NOW()"
    
    def _build_limited_where_clause(self, qualified_table_name: str, dt_column_name: str, time_threshold, limit_rows_param: str = ":limit_rows", target_recent: bool = False):
        """Build database-specific WHERE clause with LIMIT/TOP for targeting specific rows
        
        Args:
            qualified_table_name: Full table name with schema
            dt_column_name: Name of the datetime column
            time_threshold: Time threshold SQL expression (embedded directly, not a parameter)
            limit_rows_param: Parameter name for limit (default: ":limit_rows")
            target_recent: If True, target recent rows (>=) instead of old rows (<)
        
        Returns:
            SQL WHERE clause string with embedded time_threshold expression
        """
        dialect = self.engine.dialect.name
        
        # Determine comparison operator and sort order
        if target_recent:
            comparison_op = ">="
            order_by = "DESC"  # Most recent first
        else:
            comparison_op = "<"
            order_by = "ASC"  # Oldest first
        
        # Embed time_threshold SQL expression directly (not a parameter)
        if dialect == 'mysql':
            return f"""
                WHERE {dt_column_name} {comparison_op} {time_threshold}
                ORDER BY {dt_column_name} {order_by}
                LIMIT {limit_rows_param}
            """
        elif dialect == 'postgresql':
            return f"""
                WHERE ctid IN (
                    SELECT ctid FROM {qualified_table_name} 
                    WHERE {dt_column_name} {comparison_op} {time_threshold}
                    ORDER BY {dt_column_name} {order_by}
                    LIMIT {limit_rows_param}
                )
            """
        elif dialect == 'sqlite':
            return f"""
                WHERE rowid IN (
                    SELECT rowid FROM {qualified_table_name} 
                    WHERE {dt_column_name} {comparison_op} {time_threshold}
                    ORDER BY {dt_column_name} {order_by}
                    LIMIT {limit_rows_param}
                )
            """
        elif dialect == 'mssql':
            return f"WHERE {dt_column_name} {comparison_op} {time_threshold}"
        elif dialect == 'oracle':
            return f"""
                WHERE ROWID IN (
                    SELECT ROWID FROM (
                        SELECT ROWID FROM {qualified_table_name} 
                        WHERE {dt_column_name} {comparison_op} {time_threshold}
                        ORDER BY {dt_column_name} {order_by}
                    ) WHERE ROWNUM <= {limit_rows_param}
                )
            """
        else:
            return f"""
                WHERE {dt_column_name} {comparison_op} {time_threshold}
                ORDER BY {dt_column_name} {order_by}
                LIMIT {limit_rows_param}
            """

    def _resolve_parameters(self, max_rows: int = None, time_window_seconds: int = None):
        """Resolve parameters to their default values if None"""
        if max_rows is None:
            max_rows = self.DEFAULT_MAX_ROWS
        if time_window_seconds is None:
            time_window_seconds = self.DEFAULT_TIME_WINDOW_SECONDS
        return max_rows, time_window_seconds
    
    def _calculate_rows_needed(self, table, max_rows: int = None, time_window_seconds: int = None):
        """Calculate rows needed by polling table state within time window
        
        Caps DML operations by examining actual recent changes in the table,
        regardless of unknown client activity. Uses polling interval to assess
        effective table state and determine appropriate capacity limits.
        
        Args:
            table: Table info dict or SQLAlchemy Table object
        """
        max_rows, time_window_seconds = self._resolve_parameters(max_rows, time_window_seconds)
            
        # Get datetime column info (works with dict or Table object)
        dt_column = self._get_datetime_column(table)
        time_threshold = self._get_time_threshold(time_window_seconds)
        
        # Get table and column names for SQL generation
        table_name = table['qualified_name']
        dt_col_name = dt_column['name']
        
        # Generate SQL directly (embed time_threshold SQL expression)
        sql = sa.text(f"SELECT COUNT(*) FROM {table_name} WHERE {dt_col_name} > {time_threshold}")
        
        with self.engine.connect() as conn:
            # Count recent records within the time window
            recent_count = conn.execute(sql).scalar()
            
            rows_needed = max(0, max_rows - recent_count)
            return dt_column, time_threshold, rows_needed

    def _execute_update(self, table, max_rows: int = None, time_window_seconds: int = None, 
                       dt_column=None, time_threshold=None, rows_needed=None, 
                       is_retry: bool = False):
        """Universal update method for all tables (uses synthetic key approach)
        
        Args:
            table: SQLAlchemy table object
            max_rows: Maximum number of rows to update
            time_window_seconds: Time window for row selection
            dt_column: Pre-calculated datetime column (optional)
            time_threshold: Pre-calculated time threshold (optional)
            rows_needed: For normal update: Pre-calculated rows needed (optional)
                        For retry: Number of rows just inserted (REQUIRED - must be passed in)
            is_retry: If True, targets RECENT rows (>=) for retry; if False, targets OLD rows (<)
            
        Returns:
            int: Number of rows updated
        """
        # Determine operation type for logging
        op_type = 'update_retry' if is_retry else 'update'
        
        if is_retry:
            # For retry, rows_needed MUST be provided (number of rows just inserted)
            if rows_needed is None or rows_needed <= 0:
                # No rows to update
                return 0
            
            # Get dt_column and time_threshold for WHERE clause
            if dt_column is None:
                dt_column = self._get_datetime_column(table)
            if time_threshold is None:
                time_threshold = self._get_time_threshold(
                    time_window_seconds if time_window_seconds else self.DEFAULT_TIME_WINDOW_SECONDS
                )
            
            # rows_needed already set to the exact number of inserted rows
            # Don't recalculate - just use what was passed in
        else:
            # For normal update, use provided or calculate for old rows
            if dt_column is None or time_threshold is None or rows_needed is None:
                dt_column, time_threshold, rows_needed = self._calculate_rows_needed(table, max_rows, time_window_seconds)
            
            if rows_needed <= 0:
                return 0
        
        with self.engine.connect() as conn:
            current_time_sql = self._get_current_time_sql()
            dialect = self.engine.dialect.name
            
            # Get column name from dict
            dt_col_name = dt_column['name']
            
            # Check if ops column exists and build SET clause accordingly
            has_ops = self._has_ops_column(table)
            if has_ops:
                set_clause = f"{dt_col_name} = {current_time_sql}, ops='{op_type}'"
            else:
                set_clause = f"{dt_col_name} = {current_time_sql}"
            
            # Build UPDATE SQL using consolidated helper methods
            qualified_table_name = self._get_qualified_table_name(table)
            
            # Determine comparison operator based on retry flag
            comparison_op = ">=" if is_retry else "<"
            
            if dialect == 'mssql':
                # SQL Server uses TOP syntax
                update_sql = sa.text(f"""
                    UPDATE TOP(:limit_rows) {qualified_table_name} 
                    SET {set_clause} 
                    WHERE {dt_col_name} {comparison_op} {time_threshold}
                """)
            else:
                # All other databases use the limited WHERE clause
                where_clause = self._build_limited_where_clause(
                    qualified_table_name, 
                    dt_col_name, 
                    time_threshold,
                    target_recent=is_retry  # Target recent rows if retry, old rows otherwise
                )
                update_sql = sa.text(f"""
                    UPDATE {qualified_table_name} 
                    SET {set_clause} 
                    {where_clause}
                """)
            
            result = conn.execute(update_sql, {'limit_rows': rows_needed})
            conn.commit()
            return result.rowcount
    
    def _execute_update_retry(self, table, inserted_count: int, time_window_seconds: int = None, dt_column=None):
        """Execute UPDATE on recently inserted rows (for retry after INSERT)
        
        This is a convenience wrapper around _execute_update with is_retry=True.
        Targets RECENT rows (>= time_threshold) instead of OLD rows (< time_threshold).
        Updates exactly the number of rows that were just inserted.
        
        Args:
            table: SQLAlchemy table object
            inserted_count: Number of rows just inserted (will update this many rows)
            time_window_seconds: Time window for targeting recent rows (optional)
            dt_column: Pre-calculated datetime column (optional)
            
        Returns:
            int: Number of rows updated
        """
        return self._execute_update(
            table, 
            max_rows=None,  # Not used for retry
            time_window_seconds=time_window_seconds, 
            dt_column=dt_column,
            time_threshold=None,  # Will be calculated
            rows_needed=inserted_count,  # Use exact inserted count
            is_retry=True
        )
    
    def _execute_delete(self, table, max_rows: int = None, time_window_seconds: int = None, dt_column=None, time_threshold=None, rows_needed=None):
        """Delete old rows and report count"""
        
        # Only calculate if not provided
        if dt_column is None or time_threshold is None or rows_needed is None:
            dt_column, time_threshold, rows_needed = self._calculate_rows_needed(table, max_rows, time_window_seconds)
        
        if rows_needed <= 0:
            return 0
        
        with self.engine.connect() as conn:
            dialect = self.engine.dialect.name
            
            # Build DELETE SQL using consolidated helper methods
            qualified_table_name = self._get_qualified_table_name(table)
            
            # Get column name from dict
            dt_col_name = dt_column['name']
            
            if dialect == 'mssql':
                # SQL Server uses TOP syntax
                delete_sql = sa.text(f"""
                    DELETE TOP(:limit_rows) FROM {qualified_table_name} 
                    WHERE {dt_col_name} < {time_threshold}
                """)
            else:
                # All other databases use the limited WHERE clause
                where_clause = self._build_limited_where_clause(qualified_table_name, dt_col_name, time_threshold)
                delete_sql = sa.text(f"""
                    DELETE FROM {qualified_table_name} 
                    {where_clause}
                """)
            
            # Execute delete
            delete_result = conn.execute(delete_sql, {'limit_rows': rows_needed})
            deleted_count = delete_result.rowcount
            
            conn.commit()
            return deleted_count

    def _execute_insert(self, table, num_rows: int, dt_column=None):
        """Insert new rows and report count"""
        
        if num_rows <= 0:
            return 0
        
        # Get datetime column if not provided
        if dt_column is None:
            dt_column = self._get_datetime_column(table)
        
        with self.engine.connect() as conn:
            current_time_sql = self._get_current_time_sql()
            
            # Get column name from dict
            dt_col_name = dt_column['name']
            
            # Check if ops column exists and build INSERT accordingly
            has_ops = self._has_ops_column(table)
            if has_ops:
                columns = f"{dt_col_name}, ops"
                values_list = [f"({current_time_sql}, 'insert')" for _ in range(num_rows)]
            else:
                columns = dt_col_name
                values_list = [f"({current_time_sql})" for _ in range(num_rows)]
            
            values_clause = ", ".join(values_list)
            
            # Build the complete multi-row INSERT statement
            qualified_table_name = self._get_qualified_table_name(table)
            insert_sql = sa.text(f"""
                INSERT INTO {qualified_table_name} ({columns}) 
                VALUES {values_clause}
            """)
            
            # Execute single multi-row INSERT statement
            result = conn.execute(insert_sql)
            inserted_count = result.rowcount
            
            conn.commit()
            return inserted_count

    def execute_delete(self, max_rows: int = None, time_window_seconds: int = None, table_name: str = None):
        """Execute delete - uses round-robin if no table specified"""
        table = self._get_table(table_name) if table_name else self._get_next_table()
        return self._execute_delete(table, max_rows, time_window_seconds)

    def execute_insert(self, num_rows: int = None, table_name: str = None):
        """Execute insert - uses round-robin if no table specified"""
        # Use default max_rows if num_rows not provided
        if num_rows is None:
            num_rows = self.DEFAULT_MAX_ROWS
        table = self._get_table(table_name) if table_name else self._get_next_table()
        return self._execute_insert(table, num_rows)

    def execute_update(self, max_rows: int = None, time_window_seconds: int = None, table_name: str = None):
        """Execute update - uses round-robin if no table specified"""
        table = self._get_table(table_name) if table_name else self._get_next_table()
        return self._execute_update(table, max_rows, time_window_seconds)

    def _execute_delete_update_insert(self, table, max_rows: int = None, time_window_seconds: int = None):
        """Execute DELETE, UPDATE, then INSERT - uses separate functions with detailed reporting
        
        If UPDATE returns 0 rows but INSERT returns non-zero rows, retry UPDATE to update the newly inserted data.
        """
        
        # Resolve parameters using consolidated method
        max_rows, time_window_seconds = self._resolve_parameters(max_rows, time_window_seconds)
        
        # Calculate once for DELETE operations
        dt_column, time_threshold, rows_needed = self._calculate_rows_needed(table, max_rows, time_window_seconds)
        
        # Execute DELETE first
        deleted_count = self._execute_delete(
            table, max_rows, time_window_seconds, 
            dt_column=dt_column, time_threshold=time_threshold, rows_needed=rows_needed
        )
        
        # Execute UPDATE second (on remaining data)
        update_result = self._execute_update(table, max_rows, time_window_seconds)
        
        # Execute INSERT third - insert rows_needed if table is empty, otherwise replace deleted rows
        table_name = self._get_qualified_table_name(table)
        
        # Get round-robin info from dict
        round_robin_info = table.get('_round_robin_info', '')
        round_robin_prefix = f"🎯 {round_robin_info} " if round_robin_info else ""
        
        update_retry_result = 0
        update_retry_triggered = False
        
        if deleted_count > 0:
            # Replace deleted rows
            inserted_count = self._execute_insert(table, deleted_count, dt_column)
            
            # Check if UPDATE returned 0 rows but INSERT returned non-zero rows
            if update_result == 0 and inserted_count > 0:
                update_retry_triggered = True
                update_retry_result = self._execute_update_retry(table, inserted_count, time_window_seconds, dt_column)
            
            print(f"{round_robin_prefix}🔄 {table_name}: DEL={deleted_count}, UPD={update_result}, INS={inserted_count}" + 
                  (f", UPD_RETRY={update_retry_result}" if update_retry_triggered else ""))
        elif rows_needed > 0:
            # Table is empty or insufficient recent data, insert needed rows to reach target
            inserted_count = self._execute_insert(table, rows_needed, dt_column)
            
            # Check if UPDATE returned 0 rows but INSERT returned non-zero rows
            if update_result == 0 and inserted_count > 0:
                update_retry_triggered = True
                update_retry_result = self._execute_update_retry(table, inserted_count, time_window_seconds, dt_column)
            
            print(f"{round_robin_prefix}📈 {table_name}: DEL={deleted_count}, UPD={update_result}, INS={inserted_count} (needed {rows_needed} rows)" +
                  (f", UPD_RETRY={update_retry_result}" if update_retry_triggered else ""))
        else:
            # No rows needed
            inserted_count = 0
            print(f"{round_robin_prefix}✅ {table_name}: DEL={deleted_count}, UPD={update_result}, INS={inserted_count} (sufficient data)")
        
        result = {
            'expected_rows_needed': rows_needed,
            'max_rows_target': max_rows,
            'deleted': deleted_count,
            'inserted': inserted_count,
            'updated': update_result,
            'total_operations': deleted_count + inserted_count + update_result
        }
        
        # Add retry information if it occurred
        if update_retry_triggered:
            result['update_retry_triggered'] = True
            result['update_retry_result'] = update_retry_result
            result['updated_total'] = update_result + update_retry_result
            result['total_operations'] = deleted_count + inserted_count + update_result + update_retry_result
        
        return result

    def execute_delete_update_insert(self, max_rows: int = None, time_window_seconds: int = None, table_name: str = None):
        """Execute DELETE, UPDATE, then INSERT - uses round-robin if no table specified"""
        table = self._get_table(table_name) if table_name else self._get_next_table()
        
        if table is None:
            # Get display schema (correct for Oracle)
            schema_path = self._get_display_schema()
            print(f"⚠️ No table available for DML operations in {schema_path}. Skipping execution.")
            return {
                'status': 'skipped',
                'reason': 'no_tables_available',
                'schema': schema_path,
                'message': f'No tables found in {schema_path} for DML operations'
            }
        
        return self._execute_delete_update_insert(table, max_rows, time_window_seconds)

    def get_recent_data(self, seconds_back: int = None, table_name: str = None):
        """Get recent data - uses round-robin if no table specified"""
        # Use default time window if not provided
        if seconds_back is None:
            seconds_back = self.DEFAULT_TIME_WINDOW_SECONDS
            
        table = self._get_table(table_name) if table_name else self._get_next_table()
        
        if table is None:
            # Get display schema (correct for Oracle)
            schema_path = self._get_display_schema()
            print(f"⚠️ No table available for data retrieval in {schema_path}. Returning empty DataFrame.")
            return pd.DataFrame()  # Return empty DataFrame
        
        dt_column = self._get_datetime_column(table)
        time_threshold = self._get_time_threshold(seconds_back)
        
        # Get table and column names
        qualified_table_name = self._get_qualified_table_name(table)
        dt_col_name = dt_column['name']
        
        # Generate SQL directly (embed time_threshold SQL expression)
        query = sa.text(f"""
            SELECT * FROM {qualified_table_name} 
            WHERE {dt_col_name} >= {time_threshold} 
            ORDER BY {dt_col_name} DESC
        """)
        
        return pd.read_sql(query, self.engine)

    def schedule_delete_update_insert(self, scheduler, time_window_seconds:int = None, run_duration_sec:int = 3600):
        """Schedule automatic DELETE/UPDATE/INSERT operations
        
        Args:
            scheduler: APScheduler instance
            time_window_seconds: Interval between operations (default: DEFAULT_TIME_WINDOW_SECONDS)
            run_duration_sec: Total duration to run operations (default: 3600)
        """
        if time_window_seconds is None:
            time_window_seconds = self.DEFAULT_TIME_WINDOW_SECONDS
        
        # Use unique job ID per database (host_fqdn + catalog)
        job_id = f"{self.credential.host_fqdn}_{self.credential.catalog}_dml_update"
        print(f"🔄 Scheduling DML job: {job_id}")
        
        scheduler.add_job(self.execute_delete_update_insert, 
            'interval', seconds=time_window_seconds, replace_existing=False, id=job_id, 
            end_date=datetime.datetime.now() + datetime.timedelta(seconds=run_duration_sec), 
            next_run_time=datetime.datetime.now() )        