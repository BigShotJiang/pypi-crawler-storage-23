"""clangir has been renamed to headerkit. Install headerkit instead."""

import warnings

warnings.warn(
    "The 'clangir' package has been renamed to 'headerkit'. "
    "Please update your imports: pip install headerkit",
    DeprecationWarning,
    stacklevel=2,
)

from headerkit import *  # noqa: F401, F403, E402
from headerkit import __all__  # noqa: F401, E402
