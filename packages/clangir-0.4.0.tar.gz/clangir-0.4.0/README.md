# clangir has been renamed to headerkit

This package has been renamed to **[headerkit](https://pypi.org/project/headerkit/)**.

## Migration

```bash
pip install headerkit
```

All imports have changed from `clangir` to `headerkit`:

```python
# Before
from clangir.backends import get_backend
from clangir.writers.cffi import header_to_cffi

# After
from headerkit.backends import get_backend
from headerkit.writers.cffi import header_to_cffi
```

## Links

- **PyPI**: https://pypi.org/project/headerkit/
- **GitHub**: https://github.com/axiomantic/headerkit
- **Docs**: https://axiomantic.github.io/headerkit/
