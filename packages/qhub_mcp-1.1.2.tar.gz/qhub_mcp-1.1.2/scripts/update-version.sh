#!/usr/bin/env sh

version=${1:-0.0.0}

uv version --no-sync "$version"
