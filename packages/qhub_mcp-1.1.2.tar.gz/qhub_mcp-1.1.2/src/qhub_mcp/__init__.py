import importlib.metadata

try:
    __version__ = importlib.metadata.version("qhub-mcp")
except importlib.metadata.PackageNotFoundError:
    __version__ = "0.0.0"

from .server import mcp

__all__ = ["mcp", "__version__"]
