from collections import defaultdict
from datetime import datetime
import datetime as dt
import json
import requests

import requests_cache
requests_cache.install_cache('.requests_cache', expire_after=2*60*60)


GITLAB_API_URL = "https://gitlab.com/api/v4"
DEFAULT_PARENT_GROUP_ID = 92940340  # wiredlab/space/bcon-2
ACCESS_TOKEN = ""
GITLAB_USERNAME_EMAIL_MAP = {}

# Policy for system notes (note.get("system") == True).
# Add to allow/deny sets for known activity_type values.
# Add prefix rules to handle unknown/fall-through system messages without
# changing parser branches immediately.
SYSTEM_NOTE_POLICY = {
    "Issue": {
        "default": "deny",
        "allow_activity_types": {
            "Assigned",
            "Unassigned",
            "Blocking",
            "Branch",
            "DateChange",
            "EditTitle",
            "EditDescription",
            "EpicAdd",
            "ItemComplete",
            "ItemIncomplete",
            "Move",
            "RelatedAdd",
            "RelatedRemove",
        },
        "deny_activity_types": {
            "ChildAdd",
            "Comment",
            "CommentEdit",
            "MentionCommit",
            "MentionIssue",
            "MentionMR",
            "MentionTask",
            "ParentAdd",
            "StatusUpdate",
        },
        "allow_message_prefixes": (),
        "deny_message_prefixes": (),
    },
    "MR": {
        "default": "deny",
        "allow_activity_types": {
            "Approved",
            "Unapproved",
            "Assigned",
            "EditTitle",
            "EditDescription",
            "EpicAdd",
            "ItemComplete",
            "ItemIncomplete",
            "Ready",
            "ReviewComment",
            "ReviewRequest",
        },
        "deny_activity_types": {
            "AutoMergeAbort",
            "AutoMergeEnable",
            "Comment (edit)",
            "Comment",
            "LineChange",
            "MentionCommit",
            "MentionIssue",
            "MentionMR",
            "ReviewReset",
            "ThreadsResolved",
            "Update",
        },
        "allow_message_prefixes": (),
        "deny_message_prefixes": (),
    },
}


def load_username_email_map(usermap_path):
    # username_author.json maps git commit authors to GitLab usernames.
    with open(usermap_path, encoding="utf-8") as usermap_file:
        return json.load(usermap_file) or {}


def configure(access_token, username_email_map=None):
    global ACCESS_TOKEN
    ACCESS_TOKEN = access_token or ""

    if username_email_map is not None:
        global GITLAB_USERNAME_EMAIL_MAP
        GITLAB_USERNAME_EMAIL_MAP = username_email_map


def _activity_sort_key(activity):
    return activity.get("updated_at") or activity.get("created_at") or ""


def _policy_allow_system_activity(resource_kind, activity_type, body):
    policy = SYSTEM_NOTE_POLICY.get(resource_kind, {})
    deny_types = policy.get("deny_activity_types", set())
    allow_types = policy.get("allow_activity_types", set())
    deny_prefixes = policy.get("deny_message_prefixes", ())
    allow_prefixes = policy.get("allow_message_prefixes", ())
    default_action = policy.get("default", "deny")

    if activity_type in deny_types:
        return False
    if activity_type in allow_types:
        return True

    body = body or ""
    if any(body.startswith(prefix) for prefix in deny_prefixes):
        return False
    if any(body.startswith(prefix) for prefix in allow_prefixes):
        return True

    print(f"Unhandled {resource_kind} : {activity_type} : {body}")
    return default_action == "allow"


def _activity_heading(activity):
    actor = activity.get("actor") or "???"
    activity_type = activity.get("activity_type") or ""
    detail = activity.get("heading") or activity.get("body") or activity.get("title") or "(no details)"
    detail_text = detail #" ".join(str(detail).split())
    if len(detail_text) > 160:
        detail_text = f"{detail_text[:157]}..."
    return f"@{actor}: {activity_type} - {detail_text}"


def _group_path_from_start(start_group, subgroup):
    start_parts = (start_group.get("full_path") or "").split("/")
    subgroup_parts = (subgroup.get("full_path") or "").split("/")
    if start_parts and subgroup_parts[:len(start_parts)] == start_parts:
        return subgroup_parts[len(start_parts) - 1:]
    return subgroup_parts


def _group_context(start_group, subgroup):
    return {
        "id": subgroup["id"],
        "name": subgroup["name"],
        "full_path": subgroup.get("full_path"),
        "path_from_start": _group_path_from_start(start_group, subgroup),
    }


def _strip_base_prefix(path, base_prefix):
    if not path:
        return path
    if not base_prefix:
        return path

    base_prefix = base_prefix.rstrip("/")
    if path == base_prefix:
        return ""
    if path.startswith(base_prefix + "/"):
        return path[len(base_prefix) + 1:]
    return path


def _project_context(project, group_context, base_group_path):
    full_path = project.get("path_with_namespace")
    relative_path = _strip_base_prefix(full_path, base_group_path) or project.get("name")
    return {
        "id": project.get("id"),
        "name": project.get("name"),
        "path_with_namespace": relative_path,
        "full_path_with_namespace": full_path,
        "url": project.get("web_url"),
    }


def _project_context_for_group_bucket(group_context, bucket_name, base_group_path):
    full_path = f"{group_context.get('full_path', group_context['name'])}/{bucket_name.lower()}"
    return {
        "id": None,
        "name": bucket_name,
        "path_with_namespace": _strip_base_prefix(full_path, base_group_path) or bucket_name.lower(),
        "full_path_with_namespace": full_path,
        "url": None,
        "group": group_context,
    }


def _entry_key(project_context):
    project_path = project_context.get("path_with_namespace") or project_context.get("name")
    project_id = project_context.get("id")
    return f"{project_path}"


def _normalize_user_key(username):
    return username or "unknown"

def get_username_from_commit(name, email):
    git_name = f"{name} <{email}>"
    for username, name_emails in GITLAB_USERNAME_EMAIL_MAP.items():
        for name_email in name_emails:
            if name_email == git_name:
                return username  # Return the username immediately if a match is found
    print(git_name)
    return git_name

def list_groups():
    """List all groups."""
    groups = []
    url = f"{GITLAB_API_URL}/groups?order_by=similarity"
    headers = {"PRIVATE-TOKEN": ACCESS_TOKEN}
    while url:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        groups.extend(response.json())
        url = response.links.get("next", {}).get("url")
    return groups

def get_group(group_id):
    """Retrieve details of a specific group by its group ID."""
    url = f"{GITLAB_API_URL}/groups/{group_id}"
    headers = {"PRIVATE-TOKEN": ACCESS_TOKEN}
    response = requests.get(url, headers=headers)
    response.raise_for_status()
    return response.json()

def get_subgroups(group_id):
    """Fetch direct subgroups within a group."""
    subgroups = []
    url = f"{GITLAB_API_URL}/groups/{group_id}/subgroups"
    headers = {"PRIVATE-TOKEN": ACCESS_TOKEN}
    while url:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        subgroups.extend(response.json())
        url = response.links.get("next", {}).get("url")
    return subgroups


def get_group_tree(group):
    """Recursively fetch a group and all descendants."""
    groups = [group]
    for subgroup in get_subgroups(group["id"]):
        groups.extend(get_group_tree(subgroup))
    return groups

def get_user(user_id):
    """Retrieve details of a specific user by its user ID."""
    url = f"{GITLAB_API_URL}/users/{user_id}"
    headers = {"PRIVATE-TOKEN": ACCESS_TOKEN}
    response = requests.get(url, headers=headers)
    response.raise_for_status()
    return response.json()

def get_group_projects(group_id):
    """Retrieve all projects in a group."""
    projects = []
    url = f"{GITLAB_API_URL}/groups/{group_id}/projects"
    headers = {"PRIVATE-TOKEN": ACCESS_TOKEN}
    while url:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        projects.extend(response.json())
        url = response.links.get("next", {}).get("url")
    return projects

def get_epics(group_id, start_date, end_date, headers):
    """Retrieve epics and their activities for a specific group, considering both creates and edits."""
    activities = defaultdict(list)
    url = f"{GITLAB_API_URL}/groups/{group_id}/epics?updated_after={start_date}&updated_before={end_date}&per_page=100"

    while url:
        response = requests.get(url, headers=headers)
        response.raise_for_status()

        for item in response.json():
            username = item.get("author", {}).get("username", "unknown")
            created_at = item.get("created_at")
            updated_at = item.get("updated_at")

            # Determine the activity type based on created_at and updated_at
            if created_at == updated_at:
                activity_type = "Epic-Created"
            else:
                activity_type = "Epic-Edited"

            # Append the activity details
            activities[username].append({
                "title": item.get("title"),
                "url": item.get("web_url"),
                "created_at": created_at,
                "updated_at": updated_at,
                "activity_type": activity_type,
                "epic": item,
            })

        url = response.links.get("next", {}).get("url")

    return activities

def get_milestones(project_id, start_date, end_date, headers):
    """Retrieve milestones and their activities for a specific project."""
    activities = defaultdict(list)
    url = f"{GITLAB_API_URL}/projects/{project_id}/milestones?updated_after={start_date}&updated_before={end_date}&per_page=100"

    while url:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        for item in response.json():
            username = item.get("author", {}).get("username", "unknown")
            created_at = item.get("created_at")
            updated_at = item.get("updated_at")

            # Only consider edits
            if created_at != updated_at:
                activities[username].append({
                    "title": item.get("title"),
                    "url": item.get("web_url"),
                    "created_at": created_at,
                    "updated_at": updated_at,
                    "activity_type": "Milestone-Edited",
                })

        url = response.links.get("next", {}).get("url")

    return activities

def get_projects(group_id, start_date, end_date, headers):
    """Retrieve projects and their creation."""
    activities = defaultdict(list)
    url = f"{GITLAB_API_URL}/groups/{group_id}/projects?updated_after={start_date}&updated_before={end_date}&order_by=updated_at&per_page=100"

    while url:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        for item in response.json():
            user_id = item.get("creator_id")
            username = get_user(user_id).get("username", "unknown")
            created_at = item.get("created_at")
            updated_at = item.get("updated_at")

            # Only consider creates
            created_at_dt = dt.datetime.fromisoformat(created_at.rstrip("Z"))
            updated_after_dt = dt.datetime.fromisoformat(start_date.rstrip("Z"))
            updated_before_dt = dt.datetime.fromisoformat(end_date.rstrip("Z"))

            if updated_after_dt <= created_at_dt <= updated_before_dt: # The project was created within the provided time window
                activities[username].append({
                    "title": item.get("name"),
                    "url": item.get("web_url"),
                    "created_at": created_at,
                    "updated_at": updated_at,
                    "activity_type": "Project-Created",
                })

        url = response.links.get("next", {}).get("url")

    return activities

def get_issues(project_id, start_date, end_date, headers):
    """Retrieve issues and their activities for a specific project."""
    activities = defaultdict(list)

    # Fetch issues
    issues_url = f"{GITLAB_API_URL}/projects/{project_id}/issues?updated_after={start_date}&updated_before={end_date}&per_page=100"
    while issues_url:
        response = requests.get(issues_url, headers=headers)
        response.raise_for_status()
        for item in response.json():
            created_at = item.get("created_at")
            updated_at = item.get("updated_at")
            closed_at = item.get("closed_at")
            state = item.get("state", "unknown")

            # Determine issue activity type,
            # which also determines who did the action
            if created_at == updated_at:
                activity_type = "Opened"
                username = item.get("author", {}).get("username", "unknown")
            elif closed_at and (updated_at >= closed_at):
                activity_type = "Closed"
                if state != "closed":
                    print(f"Updated==Closed but not closed?? {item.get('id')}")
                username  = item.get("closed_by", {}).get("username", "unknown")
            else:
                activity_type = "Edited"

            issue_url = item.get("web_url")

            # Only log activities that user did. Edits come from lots of
            # sources, the discussion system=true logs these events.
            if activity_type in ("Opened", "Closed"):
                activities[username].append({
                    "title": item.get("title"),
                    "url": issue_url,
                    "created_at": created_at,
                    "updated_at": updated_at,
                    "activity_type": f"Issue-{activity_type}",
                    "issue": item,
                })

            # Fetch comments for this issue
            issue_iid = item.get("iid")
            if issue_iid is None:
                print(f"Skipping issue {item.get('title')} as it lacks an IID.")
                continue

            discussions_url = f"{GITLAB_API_URL}/projects/{project_id}/issues/{issue_iid}/discussions?updated_after={start_date}&updated_before={end_date}&per_page=100"
            while discussions_url:
                discussions_response = requests.get(discussions_url, headers=headers)
                discussions_response.raise_for_status()
                for discussion in discussions_response.json():
                    for note in discussion.get("notes", []):
                        note_user = note.get("author", {}).get("username", "unknown")
                        created_at = note.get("created_at")
                        updated_at = note.get("updated_at")

                        # Consider creates and updates
                        updated_at_dt = datetime.fromisoformat(updated_at.rstrip("Z"))
                        updated_after_dt = datetime.fromisoformat(start_date.rstrip("Z"))
                        updated_before_dt = datetime.fromisoformat(end_date.rstrip("Z"))

                        if updated_after_dt <= updated_at_dt <= updated_before_dt: # The note was created/updated within the provided time window
                            title = item.get("title")
                            body = note.get("body")
                            heading = None
                            activity_type = (
                                "Comment" if created_at == updated_at else "CommentEdit"
                            )

                            # Determine comment activity type in better detail
                            if note.get("system"):
                                activity_type = "SystemUnknown"
                                # checkbox action
                                prefix = "marked the checklist item **"
                                suffix_complete = "** as completed"
                                suffix_incomplete = "** as incomplete"
                                if body.startswith(prefix):
                                    if body.endswith(suffix_complete):
                                        activity_type = "ItemComplete"
                                        check_item = body.replace(prefix, "\u2713 ").replace(suffix_complete, "")
                                    else:
                                        activity_type = "ItemIncomplete"
                                        check_item = body.replace(prefix, "\u237B ").replace(suffix_incomplete, "")

                                    if len(check_item) > 40:
                                        title = f"{check_item[:40]}... ({title})"
                                    else:
                                        title = f"{check_item} ({title})"

                                elif "changed title from" in body:
                                    activity_type = "EditTitle"
                                    heading = title

                                elif body.startswith("changed the description"):
                                    activity_type = "EditDescription"
                                    heading = title

                                elif body.startswith("marked this issue as blocking"):
                                    activity_type = "Blocking"
                                    text = body.replace("marked this issue as blocking ", "")
                                    title +=f" ({text})"

                                elif body.startswith("moved to"):
                                    activity_type = "Move"
                                    text = body.replace("moved to ", "")
                                    title +=f" ({text})"

                                elif body.startswith("assigned to"):
                                    activity_type = "Assigned"
                                    text = body.replace("assigned to ", "")
                                    heading = f"→{text} : {title}"

                                elif body.startswith("unassigned"):
                                    activity_type = "Unassigned"
                                    text = body.replace("unassigned ", "")
                                    title +=f" ({text})"

                                elif body.startswith("created branch"):
                                    activity_type = "Branch"
                                    text = body.split("`")[1]
                                    title = f"{text}"

                                elif body.startswith("mentioned in issue"):
                                    activity_type = "MentionIssue"
                                    text = body.replace("mentioned in issue ", "")
                                    text = f"commit {text[:6]}..."
                                    title += f" ({text})"

                                elif body.startswith("mentioned in task"):
                                    activity_type = "MentionTask"
                                    text = body.replace("mentioned in task ", "")
                                    text = f"commit {text[:6]}..."
                                    title += f" ({text})"

                                elif body.startswith("mentioned in commit"):
                                    activity_type = "MentionCommit"
                                    text = body.replace("mentioned in commit ", "")
                                    text = f"commit {text[:6]}..."
                                    title += f" ({text})"

                                elif body.startswith("mentioned in merge request"):
                                    activity_type = "MentionMR"
                                    text = body.replace("mentioned in merge request ", "")
                                    title += f" ({text})"

                                elif body.startswith("marked this issue as related to"):
                                    activity_type = "RelatedAdd"
                                    text = body.replace("marked this issue as related to ", "")
                                    title += f" ({text})"

                                elif body.startswith("removed the relation with"):
                                    activity_type = "RelatedRemove"
                                    text = body.replace("removed the relation with ", "")
                                    title += f" ({text})"

                                elif body.startswith("added to epic"):
                                    activity_type = "EpicAdd"
                                    text = body.replace("added to epic ", "")
                                    title += f" ({text})"

                                elif body.startswith("set status to"):
                                    activity_type = "StatusUpdate"
                                    text = body.replace("set status to ", "")
                                    title += f" ({text})"

                                elif body.startswith("changed due date"):
                                    activity_type = "DateChange"
                                    text = body.replace("changed due date to ", "")
                                    text = "due: " + text
                                    title += f" ({text})"

                                elif body.startswith("changed start date"):
                                    activity_type = "DateChange"
                                    text = body.replace("changed start date to ", "")
                                    text = "start: " + text
                                    title += f" ({text})"

                                elif body.startswith("added") and body.endswith("as parent issue"):
                                    activity_type = "ParentAdd"

                                elif body.startswith("added") and body.endswith("as child task"):
                                    activity_type = "ChildAdd"

                                else:
                                    print("Issue-system:" + body)

                                if not _policy_allow_system_activity("Issue", activity_type, body):
                                    continue

                            # Construct the note's URL
                            note_id = note.get("id")
                            note_url = f"{issue_url}#note_{note_id}" if note_id else issue_url

                            activities[note_user].append({
                                "body": body,
                                "title": title,
                                "heading": heading,
                                "url": note_url,
                                "created_at": created_at,
                                "updated_at": updated_at,
                                "activity_type": f"Issue-{activity_type}",
                                "discussion": note,
                            })

                discussions_url = discussions_response.links.get("next", {}).get("url")

        issues_url = response.links.get("next", {}).get("url")

    return activities

def get_merge_requests(project_id, start_date, end_date, headers):
    """Retrieve merge requests for a specific project."""
    activities = defaultdict(list)
    url = f"{GITLAB_API_URL}/projects/{project_id}/merge_requests?updated_after={start_date}&updated_before={end_date}&per_page=100"

    while url:
        response = requests.get(url, headers=headers)
        if response.status_code == 403:
            # This project's Merge Request tab is disabled
            break

        for item in response.json():
            username = item.get("author", {}).get("username", "unknown")
            created_at = item.get("created_at")
            updated_at = item.get("updated_at")

            # Determine the activity type based on timestamps
            if created_at == updated_at:
                # not clear if this ever happens, branch create != MR open time
                activity_type = "Created"
            elif item.get("state") == "merged":
                activity_type = "Merged"
            else:
                activity_type = "Updated"

            mr_url = item.get("web_url")

            # Only log activities that user did. Edits come from lots of
            # sources, the discussion system=true logs these events.
            if activity_type in ("Created", "Merged"):
                activities[username].append({
                    "title": item.get("title"),
                    "url": mr_url,
                    "created_at": created_at,
                    "updated_at": updated_at,
                    "activity_type": f"MR-{activity_type}",
                    "mr": item,
                })

            # Fetch comments for this MR
            mr_iid = item.get("iid")
            if mr_iid is None:
                print(f"Skipping MR {item.get('title')} as it lacks an IID.")
                continue

            discussions_url = f"{GITLAB_API_URL}/projects/{project_id}/merge_requests/{mr_iid}/discussions?updated_after={start_date}&updated_before={end_date}&per_page=100"
            while discussions_url:
                discussions_response = requests.get(discussions_url, headers=headers)
                discussions_response.raise_for_status()
                for discussion in discussions_response.json():
                    for note in discussion.get("notes", []):
                        note_user = note.get("author", {}).get("username", "unknown")
                        created_at = note.get("created_at")
                        updated_at = note.get("updated_at")

                        # Consider creates and updates
                        updated_at_dt = datetime.fromisoformat(updated_at.rstrip("Z"))
                        updated_after_dt = datetime.fromisoformat(start_date.rstrip("Z"))
                        updated_before_dt = datetime.fromisoformat(end_date.rstrip("Z"))

                        if updated_after_dt <= updated_at_dt <= updated_before_dt: # The note was created/updated within the provided time window
                            title = item.get("title")
                            body = note.get("body")
                            activity_type = (
                                "Comment" if created_at == updated_at else "Comment (edit)"
                            )

                            # Determine comment activity type in better detail
                            if note.get("system"):
                                activity_type = "SystemUnknown"
                                text = ""

                                prefix = "marked the checklist item **"
                                suffix_complete = "** as completed"
                                suffix_incomplete = "** as incomplete"
                                if body.startswith(prefix):
                                    if body.endswith(suffix_complete):
                                        activity_type = "ItemComplete"
                                        check_item = body.replace(prefix, "\u2713 ").replace(suffix_complete, "")
                                    else:
                                        activity_type = "ItemIncomplete"
                                        check_item = body.replace(prefix, "\u237B ").replace(suffix_incomplete, "")

                                    if len(check_item) > 40:
                                        title = f"{check_item[:40]}... ({title})"
                                    else:
                                        title = f"{check_item} ({title})"

                                elif body.startswith("added "):
                                    # added N commits\n\n
                                    activity_type = "Update"
                                    text = body.split("\n")[0]

                                elif body.startswith("changed the title from"):
                                    activity_type = "EditTitle"
                                    text = body.replace("changed the title from ", "")
                                    title +=f" ({text})"

                                elif body.startswith("changed the description"):
                                    activity_type = "EditDescription"
                                    text = body.replace("changed the description", "")
                                    title +=f" ({text})"

                                elif body.startswith("changed this line in"):
                                    activity_type = "LineChange"
                                    text = body.replace("changed this line in ", "")
                                    title +=f" ({text})"

                                elif body.startswith("approved this merge request"):
                                    activity_type = "Approved"
                                    text = body.replace(" this merge request", "")

                                elif body.startswith("unapproved this merge request"):
                                    activity_type = "Unapproved"
                                    text = body.replace(" this merge request", "")

                                elif body.startswith("enabled an automatic merge"):
                                    activity_type = "AutoMergeEnable"
                                    text = body.replace("enabled an automatic merge", "")

                                elif body.startswith("aborted the automatic merge"):
                                    activity_type = "AutoMergeAbort"
                                    text = body.replace("aborted the automatic merge", "")

                                elif body.startswith("assigned to"):
                                    activity_type = "Assigned"
                                    text = body.replace("assigned to ", "")
                                    heading = f"→{text} : {title}"

                                elif body.startswith("marked this merge request as"):
                                    body = body.replace("marked this merge request as **", "")
                                    body = body.replace("**", "")
                                    activity_type = "Ready"

                                elif body.startswith("mentioned in commit"):
                                    activity_type = "MentionCommit"
                                    text = body.replace("mentioned in commit ", "")
                                    text = f"commit {text[:6]}..."

                                elif body.startswith("mentioned in issue"):
                                    activity_type = "MentionIssue"
                                    text = body.replace("mentioned in issue ", "")
                                    text = f"commit {text[:6]}..."
                                    title += f" ({text})"

                                elif body.startswith("mentioned in merge request"):
                                    activity_type = "MentionMR"
                                    text = body.replace("mentioned in merge request ", "")
                                    text = f"commit {text[:6]}..."

                                elif body.startswith("requested review"):
                                    activity_type = "ReviewRequest"
                                    text = body.replace("requested review from ", "")

                                elif body.startswith("left review comments"):
                                    activity_type = "ReviewComment"

                                elif body.startswith("reset approvals"):
                                    activity_type = "ReviewReset"
                                    text = body.replace("reset approvals from ", "")
                                    text = text.replace(" by pushing to the branch", "")

                                elif body.startswith("resolved all threads"):
                                    activity_type = "ThreadsResolved"

                                elif body.startswith("added to epic"):
                                    activity_type = "EpicAdd"
                                    text = body.replace("added to epic ", "")
                                    title += f" ({text})"

                                else:
                                    print("MR-system: " + body)
                                title += f" ({text})" if text else ""

                                if not _policy_allow_system_activity("MR", activity_type, body):
                                    continue

                            # Construct the note's URL
                            note_id = note.get("id")
                            note_url = f"{mr_url}#note_{note_id}" if note_id else mr_url

                            activities[note_user].append({
                                "body": note.get("body"),
                                "title": title,
                                "url": note_url,
                                "created_at": created_at,
                                "updated_at": updated_at,
                                "activity_type": f"MR-{activity_type}",
                                "mr-discussion": note,
                            })

                discussions_url = discussions_response.links.get("next", {}).get("url")

        url = response.links.get("next", {}).get("url")

    return activities

def get_commits(project_id, start_date, end_date, headers):
    """Retrieve commits for a specific project."""
    activities = defaultdict(list)
    url = f"{GITLAB_API_URL}/projects/{project_id}/repository/commits?since={start_date}&until={end_date}&per_page=100"

    while url:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        for item in response.json():
            user_name = item.get("committer_name", item.get("author_name"))
            user_email = item.get("committer_email", item.get("author_email"))
            username = get_username_from_commit(user_name, user_email)
            sha = item.get("id", "")

            # get branches associated with this commit
            refs_url = f"{GITLAB_API_URL}/projects/{project_id}/repository/commits/{sha}/refs?&per_page=100"

            refs = []
            while refs_url:
                refs_response = requests.get(refs_url, headers=headers)
                refs_response.raise_for_status()
                for ref in refs_response.json():
                    if ref["type"] == "branch":
                        refs.append(ref["name"])
                refs_url = refs_response.links.get("next", {}).get("url")
            refs = ", ".join(refs)

            activities[username].append({
                "title": item.get("message").split("\n")[0],  # First line of the commit message
                "url": item.get("web_url"),
                "created_at": item.get("created_at"),
                "updated_at": item.get("updated_at"),
                "activity_type": "Commit",
                "refs": refs,
            })
        url = response.links.get("next", {}).get("url")

    return activities

def get_user_activities(project_id, start_date, end_date):
    """Retrieve user activities within a specific project."""
    headers = {"PRIVATE-TOKEN": ACCESS_TOKEN}
    aggregated_activities = defaultdict(lambda: defaultdict(list))

    # Fetch and aggregate issues
    issues = get_issues(project_id, start_date, end_date, headers)
    for username, actions in issues.items():
        aggregated_activities[username]["Issues"].extend(actions)

    # Fetch and aggregate merge requests
    merge_requests = get_merge_requests(project_id, start_date, end_date, headers)
    for username, actions in merge_requests.items():
        aggregated_activities[username]["Merge Requests"].extend(actions)

    # Fetch and aggregate commits
    commits = get_commits(project_id, start_date, end_date, headers)
    for username, actions in commits.items():
        aggregated_activities[username]["Commits"].extend(actions)

    # Fetch and aggregate milestones edits
    milestones = get_milestones(project_id, start_date, end_date, headers)
    for username, actions in milestones.items():
        aggregated_activities[username]["Milestones"].extend(actions)

    return aggregated_activities

def _extend_user_activities(by_user, username, project_context, actions):
    username = _normalize_user_key(username)
    project_key = _entry_key(project_context)

    user_projects = by_user[username]
    entry = user_projects.setdefault(
        project_key,
        {
            "project": project_context,
            "activities": [],
        },
    )

    for action in actions:
        activity = dict(action)
        activity["actor"] = username
        activity["activity_heading"] = _activity_heading(activity)
        entry["activities"].append(activity)


def _flatten_actions(actions_by_type):
    flattened = []
    for action_list in actions_by_type.values():
        flattened.extend(action_list)
    return flattened


def _materialize_by_user(by_user):
    materialized = {}
    for username in sorted(by_user):
        projects = {}
        for project_key in sorted(by_user[username]):
            entry = by_user[username][project_key]
            entry["activities"].sort(key=_activity_sort_key)
            projects[project_key] = entry
        materialized[username] = projects
    return materialized


def collect_group_activity(group_id, start_date, end_date):
    """Collect activity data by user with group/project hierarchy context."""
    by_user = defaultdict(dict)

    start_group = get_group(group_id)
    base_group_path = start_group.get("full_path")
    all_groups = get_group_tree(start_group)
    headers = {"PRIVATE-TOKEN": ACCESS_TOKEN}

    epics_activities = get_epics(group_id, start_date, end_date, headers)
    projects_activities = get_projects(group_id, start_date, end_date, headers)

    for subgroup in all_groups:
        subgroup_id = subgroup["id"]
        group_context = _group_context(start_group, subgroup)
        print("subgroup_id", subgroup_id, "subgroup_name", subgroup["name"])

        projects = get_group_projects(subgroup_id)
        for project in projects:
            project_context = _project_context(project, group_context, base_group_path)
            print("project_id", project.get("id"), "project_name", project.get("name"))
            project_activities = get_user_activities(project["id"], start_date, end_date)
            for username, actions_by_type in project_activities.items():
                _extend_user_activities(
                    by_user,
                    username,
                    project_context,
                    _flatten_actions(actions_by_type),
                )

        if subgroup_id == group_id:
            epics_context = _project_context_for_group_bucket(group_context, "Epics", base_group_path)
            for username, actions in epics_activities.items():
                _extend_user_activities(by_user, username, epics_context, actions)

            projects_context = _project_context_for_group_bucket(group_context, "Projects", base_group_path)
            for username, actions in projects_activities.items():
                _extend_user_activities(by_user, username, projects_context, actions)

    return _materialize_by_user(by_user)
