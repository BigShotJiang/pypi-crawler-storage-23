import json


def render_json_report_page(report_data, startdate, enddate):
    payload = json.dumps(report_data, ensure_ascii=False).replace("</", "<\\/")
    start_label = startdate.strftime("%Y-%m-%d")
    end_label = enddate.strftime("%Y-%m-%d")
    meta = report_data.get("meta", {})
    group_name_path = meta.get("group_full_path", "")
    header_title = f"{group_name_path} - GitLab Activity Report" if group_name_path else "GitLab Activity Report"

    return f"""<!DOCTYPE html>
<html lang=\"en\">
<head>
  <meta charset=\"utf-8\">
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
  <title>{header_title}</title>
  <style>
    :root {{
      --bg: #f7f7f2;
      --card: #ffffff;
      --line: #d6d1c4;
      --text: #1f2a2e;
      --muted: #5e6a70;
      --accent: #0f6b72;
      --accent-soft: #d9eeef;
      --shadow: 0 10px 25px rgba(10, 20, 20, 0.07);
    }}

    * {{ box-sizing: border-box; }}

    body {{
      margin: 0;
      font-family: "IBM Plex Sans", "Segoe UI", sans-serif;
      background: radial-gradient(circle at 20% 0%, #fffdf7 0, var(--bg) 45%, #eef2ef 100%);
      color: var(--text);
    }}

    header {{
      position: sticky;
      top: 0;
      z-index: 10;
      background: rgba(247, 247, 242, 0.92);
      backdrop-filter: blur(6px);
      border-bottom: 1px solid var(--line);
      padding: 0.9rem 1rem;
    }}

    .title {{
      margin: 0;
      font-size: 1.15rem;
      font-weight: 700;
      letter-spacing: 0.02em;
    }}

    .subtitle {{
      margin: 0.2rem 0 0;
      color: var(--muted);
      font-size: 0.92rem;
    }}

    .controls {{
      margin-top: 0.8rem;
      display: grid;
      grid-template-columns: 1fr auto auto;
      gap: 0.5rem;
    }}

    input[type=\"search\"] {{
      width: 100%;
      padding: 0.55rem 0.65rem;
      border: 1px solid var(--line);
      border-radius: 8px;
      font-size: 0.92rem;
      background: #fff;
    }}

    button {{
      padding: 0.5rem 0.7rem;
      border: 1px solid var(--line);
      border-radius: 8px;
      background: var(--card);
      cursor: pointer;
      font-size: 0.85rem;
    }}

    button:hover {{
      border-color: var(--accent);
      color: var(--accent);
    }}

    main {{
      padding: 1rem;
      max-width: 1400px;
      margin: 0 auto;
    }}

    .tree {{
      background: var(--card);
      border: 1px solid var(--line);
      border-radius: 14px;
      box-shadow: var(--shadow);
      padding: 0.8rem;
      overflow-x: auto;
    }}

    details {{
      margin-left: 0;
      padding-left: 0;
    }}

    details details {{
      border-left: 2px solid #e6e0d4;
      margin-left: 0.5rem;
      padding-left: 0.7rem;
    }}

    details > summary {{
      cursor: pointer;
      list-style: none;
      margin: 0.2rem 0;
      padding: 0.25rem 0.35rem;
      border-radius: 6px;
      display: inline-flex;
      align-items: center;
      gap: 0.45rem;
      font-weight: 600;
      color: #2f3c42;
    }}

    details > summary::before {{
      content: "▶";
      display: inline-block;
      font-size: 0.72rem;
      transform: translateY(0.04rem);
      color: var(--accent);
    }}

    details[open] > summary::before {{
      content: "▼";
    }}

    details > summary:hover {{
      background: var(--accent-soft);
    }}

    details > summary.activity-summary {{
      font-weight: 500;
      color: #203236;
      border-left: 3px solid var(--accent);
      padding-left: 0.55rem;
      margin-left: 0.1rem;
    }}

    .kv {{
      margin: 0.15rem 0 0.35rem;
      padding-left: 0.35rem;
      color: var(--muted);
      font-family: "IBM Plex Mono", "SFMono-Regular", monospace;
      font-size: 0.83rem;
      white-space: pre-wrap;
      overflow-wrap: anywhere;
    }}

    .kv-body {{
      font-family: "IBM Plex Sans", "Segoe UI", sans-serif;
      color: #2a353a;
    }}

    .kv-body-label {{
      font-family: "IBM Plex Mono", "SFMono-Regular", monospace;
      color: var(--muted);
      margin-right: 0.25rem;
    }}

    .kv-body code.idiff {{
      font-family: "IBM Plex Mono", "SFMono-Regular", monospace;
      background: #f4f1e8;
      border: 1px solid #e2dccb;
      border-radius: 4px;
      padding: 0.06rem 0.25rem;
    }}

    .kv-body .idiff.addition {{
      background: #e6f6ec;
      color: #124d2a;
      border-radius: 3px;
      padding: 0 0.12rem;
    }}

    .kv-body .idiff.deletion {{
      background: #fdebec;
      color: #8b1d1d;
      text-decoration: line-through;
      border-radius: 3px;
      padding: 0 0.12rem;
    }}

    .match > summary,
    .match .kv {{
      background: #fff6bf;
      border-radius: 6px;
    }}

    a {{ color: var(--accent); }}

    @media (max-width: 860px) {{
      .controls {{
        grid-template-columns: 1fr;
      }}
    }}
  </style>
</head>
<body>
  <header>
    <h1 class=\"title\">{header_title}</h1>
    <p class=\"subtitle\" id=\"subtitle\">{start_label} through {end_label}</p>
    <div class=\"controls\">
      <input id=\"filter\" type=\"search\" placeholder=\"Filter keys, values, users, projects, actions...\">
      <button id=\"expand\" type=\"button\">Expand All</button>
      <button id=\"collapse\" type=\"button\">Collapse All</button>
    </div>
  </header>

  <main>
    <section class=\"tree\" id=\"tree\"></section>
  </main>

  <script id=\"report-data\" type=\"application/json\">{payload}</script>
  <script>
    const data = JSON.parse(document.getElementById('report-data').textContent);

    function isObject(value) {{
      return value !== null && typeof value === 'object' && !Array.isArray(value);
    }}

    function normalizeText(value) {{
      const text = String(value ?? '').replace(/\\s+/g, ' ').trim();
      if (!text) {{
        return '(no details)';
      }}
      if (text.length > 160) {{
        return `${{text.slice(0, 157)}}...`;
      }}
      return text;
    }}

    function localTimeZoneCode(dateValue = new Date()) {{
      try {{
        const parts = new Intl.DateTimeFormat(undefined, {{
          timeZoneName: 'short',
        }}).formatToParts(dateValue);
        const tz = parts.find((p) => p.type === 'timeZoneName')?.value || '';
        return tz || 'local';
      }} catch (_err) {{
        return 'local';
      }}
    }}

    function formatLocalDateTime(value) {{
      if (typeof value !== 'string' || !value.includes('T')) {{
        return null;
      }}
      if (!(/[zZ]$|[+-]\\d{{2}}:\\d{{2}}$/.test(value))) {{
        return null;
      }}

      const parsed = new Date(value);
      if (Number.isNaN(parsed.getTime())) {{
        return null;
      }}

      const parts = new Intl.DateTimeFormat(undefined, {{
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
        hour12: true,
      }}).formatToParts(parsed);

      const getPart = (type) => {{
        const match = parts.find((p) => p.type === type);
        return match ? match.value : '';
      }};

      let month = getPart('month');
      if (month && !month.endsWith('.')) {{
        month += '.';
      }}

      const day = getPart('day');
      const year = getPart('year');
      const hour = getPart('hour');
      const minute = getPart('minute');
      const dayPeriod = getPart('dayPeriod');

      if (!(month && day && year && hour && minute && dayPeriod)) {{
        return parsed.toLocaleString();
      }}

      return `${{month}} ${{day}}, ${{year}} at ${{hour}}:${{minute}} ${{dayPeriod}}`;
    }}

    function formatLocalDate(value) {{
      if (typeof value !== 'string' || !value.includes('T')) {{
        return null;
      }}
      if (!(/[zZ]$|[+-]\\d{{2}}:\\d{{2}}$/.test(value))) {{
        return null;
      }}

      const parsed = new Date(value);
      if (Number.isNaN(parsed.getTime())) {{
        return null;
      }}

      const parts = new Intl.DateTimeFormat(undefined, {{
        year: 'numeric',
        month: 'short',
        day: 'numeric',
      }}).formatToParts(parsed);

      const getPart = (type) => {{
        const match = parts.find((p) => p.type === type);
        return match ? match.value : '';
      }};

      let month = getPart('month');
      if (month && !month.endsWith('.')) {{
        month += '.';
      }}

      const day = getPart('day');
      const year = getPart('year');
      if (!(month && day && year)) {{
        return parsed.toLocaleDateString();
      }}

      return `${{month}} ${{day}}, ${{year}}`;
    }}

    function formatLeafValue(key, value) {{
      const localTime = formatLocalDateTime(value);
      if (localTime && /(_at$|^start$|^end$|_time$|^generated_at$|^start_date$|^end_date$)/.test(key)) {{
        return `${{localTime}} (${{localTimeZoneCode(new Date(value))}})`;
      }}
      if (
        typeof value === 'string' &&
        value.includes('/') &&
        !value.includes('://') &&
        /(path|namespace)/i.test(key)
      ) {{
        return value.replace(/\\s*\\/\\s*/g, ' / ');
      }}
      return JSON.stringify(value);
    }}

    function formatPathLabel(label) {{
      if (typeof label !== 'string') {{
        return label;
      }}
      if (!label.includes('/') || label.includes('://')) {{
        return label;
      }}
      return label.replace(/\\s*\\/\\s*/g, ' / ');
    }}

    function activityHeading(item) {{
      if (typeof item.activity_heading === 'string' && item.activity_heading.trim()) {{
        return item.activity_heading;
      }}
      const actor = item.actor || 'unknown';
      const activityType = item.activity_type || 'Activity';
      const detail = normalizeText(item.body ?? item.title);
      return `${{actor}}: ${{activityType}} - ${{detail}}`;
    }}

    function orderedKeys(obj) {{
      const keys = Object.keys(obj);
      if (keys.includes('project') && keys.includes('activities')) {{
        return ['project', 'activities', ...keys.filter((k) => k !== 'project' && k !== 'activities')];
      }}
      return keys;
    }}

    function makeLeaf(key, value) {{
      const row = document.createElement('div');
      row.className = 'kv';

      if (key === 'url' && typeof value === 'string') {{
        const label = document.createElement('span');
        label.textContent = 'url: ';
        const link = document.createElement('a');
        link.href = value;
        link.target = '_blank';
        link.rel = 'noreferrer noopener';
        link.textContent = value;
        row.append(label, link);
      }} else if (key === 'body' && typeof value === 'string') {{
        row.classList.add('kv-body');
        const label = document.createElement('span');
        label.className = 'kv-body-label';
        label.textContent = 'body: ';
        const content = document.createElement('span');
        content.innerHTML = value;
        row.append(label, content);
      }} else {{
        row.textContent = `${{key}}: ${{formatLeafValue(key, value)}}`;
      }}

      return row;
    }}

    function makeNode(label, value, parentLabel = '') {{
      const details = document.createElement('details');
      const summary = document.createElement('summary');
      summary.textContent = parentLabel === 'activity-item' ? label : formatPathLabel(label);
      if (parentLabel === 'activity-item') {{
        summary.classList.add('activity-summary');
      }}
      details.appendChild(summary);

      if (Array.isArray(value)) {{
        const isActivityList = parentLabel === 'activities';
        value.forEach((item, idx) => {{
          const childLabel = isActivityList && isObject(item)
            ? activityHeading(item)
            : `[${{idx}}]`;
          if (isObject(item) || Array.isArray(item)) {{
            details.appendChild(makeNode(childLabel, item, isActivityList ? 'activity-item' : parentLabel));
          }} else {{
            details.appendChild(makeLeaf(childLabel, item));
          }}
        }});
        return details;
      }}

      if (isObject(value)) {{
        orderedKeys(value).forEach((key) => {{
          const child = value[key];
          if (isObject(child) || Array.isArray(child)) {{
            details.appendChild(makeNode(key, child, key));
          }} else {{
            details.appendChild(makeLeaf(key, child));
          }}
        }});
        return details;
      }}

      details.appendChild(makeLeaf(label, value));
      return details;
    }}

    const tree = document.getElementById('tree');
    if (isObject(data)) {{
      orderedKeys(data).forEach((key, idx) => {{
        const child = data[key];
        if (isObject(child) || Array.isArray(child)) {{
          const node = makeNode(key, child, key);
          node.open = idx === 0;
          tree.appendChild(node);
        }} else {{
          tree.appendChild(makeLeaf(key, child));
        }}
      }});
    }} else if (Array.isArray(data)) {{
      const node = makeNode('items', data, 'items');
      node.open = true;
      tree.appendChild(node);
    }} else {{
      tree.appendChild(makeLeaf('value', data));
    }}

    const subtitle = document.getElementById('subtitle');
    const meta = data.meta || {{}};
    const localStart = formatLocalDate(meta.start);
    const localEnd = formatLocalDate(meta.end);
    if (localStart && localEnd) {{
      subtitle.textContent = `${{localStart}} through ${{localEnd}} (${{localTimeZoneCode(new Date(meta.start))}})`;
    }}

    const allDetails = () => Array.from(document.querySelectorAll('details'));

    document.getElementById('expand').addEventListener('click', () => {{
      allDetails().forEach((d) => d.open = true);
    }});

    document.getElementById('collapse').addEventListener('click', () => {{
      allDetails().forEach((d, idx) => d.open = idx === 0);
    }});

    document.getElementById('filter').addEventListener('input', (event) => {{
      const query = event.target.value.trim().toLowerCase();
      const nodes = allDetails();
      nodes.forEach((node) => node.classList.remove('match'));

      if (!query) {{
        return;
      }}

      nodes.forEach((node) => {{
        const text = node.textContent.toLowerCase();
        if (text.includes(query)) {{
          node.classList.add('match');
          node.open = true;
          let parent = node.parentElement;
          while (parent) {{
            if (parent.tagName === 'DETAILS') {{
              parent.open = true;
            }}
            parent = parent.parentElement;
          }}
        }}
      }});
    }});
  </script>
</body>
</html>
"""
