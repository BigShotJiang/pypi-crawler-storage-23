import argparse
import datetime as dt
import os
import sys

from .collector import (
    DEFAULT_PARENT_GROUP_ID,
    configure,
    list_groups,
    load_username_email_map,
)
from .reporting import generate_report

LONG_AGO = dt.date(2005, 4, 6)  # day before the first Git commit ever


def build_parser():
    parser = argparse.ArgumentParser(
        prog="gitlab-activity-report",
        description="Collect user activity under a GitLab group and its subgroups/projects.",
    )

    parser.add_argument("--list-groups", action="store_true", default=False)
    parser.add_argument("--group")
    parser.add_argument("--usermap", default="username_author.json")
    parser.add_argument(
        "--access-token",
        default=os.environ.get("GITLAB_ACCESS_TOKEN", ""),
        help="Access Token with Role:Reporter and Scope:read_api, default from environment GITLAB_ACCESS_TOKEN",
    )

    parser.add_argument(
        "-s",
        "--start",
        dest="startdate",
        help="include dates starting with YYYY-MM-DD or YYYY-Www",
        metavar="DATE",
    )
    parser.add_argument(
        "-e",
        "--end",
        dest="enddate",
        help="include dates thru YYYY-MM-DD or YYYY-Www",
        metavar="DATE",
    )
    parser.add_argument(
        "-d",
        "--days",
        dest="days",
        help="include NUM days after --start, or if negative, NUM before --end",
        metavar="NUM",
        type=int,
        default=0,
    )
    parser.add_argument(
        "-t",
        "--today",
        dest="today",
        action="store_true",
        help="show today only",
        default=False,
    )
    parser.add_argument(
        "-y",
        "--yesterday",
        dest="yesterday",
        action="store_true",
        help="show yesterday only",
        default=False,
    )
    parser.add_argument(
        "-a",
        "--days-ago",
        dest="daysago",
        action="store",
        help="show for N days ago",
        metavar="N",
        type=int,
    )
    parser.add_argument(
        "--output-json",
        dest="outfile_json",
        action="store",
        help="Output file for JSON report",
        default="report.json",
    )
    parser.add_argument(
        "--output-html",
        dest="outfile_html",
        action="store",
        help="Output file for HTML report",
        default="report.html",
    )
    return parser


def _parse_partial_date(date_string):
    parts = list(map(int, date_string.split("-")))
    parts += [1] * (3 - len(parts))  # use start of year/month if missing
    return dt.date(*parts)


def _week_string_to_year_week(week_string):
    week_string = week_string.strip()
    if not week_string:
        raise ValueError("empty week value")

    now_dt = dt.datetime.now()
    upper = week_string.upper()

    if week_string[0] in ("+", "-") or week_string == "0":
        week_offset = int(week_string)
        shifted = now_dt + dt.timedelta(weeks=week_offset)
        year, week, _ = shifted.isocalendar()
    elif "-W" in upper:
        year_str, week_str = upper.split("-W", 1)
        year = int(year_str)
        week = int(week_str)
    elif upper.startswith("W"):
        week = int(upper[1:])
        year, *_ = now_dt.isocalendar()
    else:
        raise ValueError(f"invalid ISO week value: {week_string}")

    if not 1 <= week <= 53:
        raise ValueError(f"week out of range: {week}")
    return year, week


def _parse_start_date_spec(value):
    if "W" in value.upper() or value.startswith(("+", "-")) or value == "0":
        year, week = _week_string_to_year_week(value)
        return dt.date.fromisocalendar(year, week, 1)
    return _parse_partial_date(value)


def _parse_end_date_spec(value):
    if "W" in value.upper() or value.startswith(("+", "-")) or value == "0":
        year, week = _week_string_to_year_week(value)
        return dt.date.fromisocalendar(year, week, 7)
    return dt.date(*list(map(int, value.split("-"))))


def resolve_date_range(args):
    startdate = LONG_AGO
    if args.startdate:
        startdate = _parse_start_date_spec(args.startdate)

    if args.enddate:
        enddate = _parse_end_date_spec(args.enddate)
    else:
        enddate = dt.date.today()

    if args.today and args.yesterday:
        startdate = dt.date.today() - dt.timedelta(1)
        enddate = dt.date.today()
    elif args.today:
        startdate = enddate = dt.date.today()
    elif args.yesterday:
        startdate = enddate = dt.date.today() - dt.timedelta(1)

    if isinstance(args.daysago, int):
        startdate = enddate = dt.date.today() - dt.timedelta(args.daysago)

    if args.days > 0:
        enddate = startdate + dt.timedelta(args.days)
    elif args.days < 0:
        startdate = enddate + dt.timedelta(args.days)

    startdate = dt.datetime.combine(startdate, dt.time.min)
    enddate = dt.datetime.combine(enddate, dt.time.max)
    return startdate, enddate


def to_utc_iso_strings(startdate, enddate):
    startdate_utc = startdate.astimezone().astimezone(dt.timezone.utc).replace(tzinfo=None)
    enddate_utc = enddate.astimezone().astimezone(dt.timezone.utc).replace(tzinfo=None)
    return startdate_utc.isoformat() + "Z", enddate_utc.isoformat() + "Z"


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)

    access_token = (args.access_token or "").strip()
    if not access_token:
        parser.error(
            "missing GitLab access token. Provide --access-token or set GITLAB_ACCESS_TOKEN. "
            "Token requires role Reporter and scope read_api."
        )
    args.access_token = access_token

    configure(access_token=args.access_token)

    if args.list_groups:
        groups = list_groups()
        groups.sort(key=lambda x: x["full_path"])
        for group in groups:
            print(f"{group['id']:9d} {group['full_path']} {group['name']}")
        return 0

    try:
        username_map = load_username_email_map(args.usermap)
    except FileNotFoundError:
        username_map = {}
        print(
            f"Hint: user map file not found: {args.usermap} "
            f"(continuing without author mapping; copy username_author.json.example to start).",
            file=sys.stderr,
        )
    configure(access_token=args.access_token, username_email_map=username_map)

    startdate, enddate = resolve_date_range(args)
    start_date, end_date = to_utc_iso_strings(startdate, enddate)
    parent_group_id = args.group or DEFAULT_PARENT_GROUP_ID

    print(
        f"""
group-id: {parent_group_id}
start: {start_date}
end:   {end_date}
"""
    )

    generate_report(
        parent_group_id=parent_group_id,
        start_date=start_date,
        end_date=end_date,
        outfile_json=args.outfile_json,
        outfile_html=args.outfile_html,
        startdate=startdate,
        enddate=enddate,
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
