from collections import OrderedDict
from copy import deepcopy
from datetime import datetime, timezone
import json

from .collector import collect_group_activity, get_group
from .html_viewer import render_json_report_page


def _activity_sort_key(activity):
    return activity.get("updated_at") or activity.get("created_at") or ""


def _project_sort_key(project_entry):
    project = project_entry[1]["project"]
    group = project.get("group") or {}
    path_from_start = group.get("path_from_start") or []
    project_name = project.get("name") or ""
    project_id = project.get("id")
    return (path_from_start, project_name, str(project_id))


def build_project_activity(by_user):
    """Re-index user-oriented activity into a project-centric structure."""
    projects = {}

    for username, user_projects in by_user.items():
        for project_key, entry in user_projects.items():
            project_bucket = projects.setdefault(
                project_key,
                {
                    "project": deepcopy(entry["project"]),
                    "activities": [],
                },
            )

            for activity in entry["activities"]:
                event = deepcopy(activity)
                if "activity_heading" not in event:
                    actor = event.get("actor") or username
                    activity_type = event.get("activity_type") or "Activity"
                    detail = event.get("body") or event.get("title") or "(no details)"
                    event["activity_heading"] = f"{actor}: {activity_type} - {' '.join(str(detail).split())}"
                project_bucket["activities"].append(event)

    for project_entry in projects.values():
        project_entry["activities"].sort(key=_activity_sort_key)

    sorted_projects = OrderedDict(sorted(projects.items(), key=_project_sort_key))

    return sorted_projects


def generate_report(parent_group_id, start_date, end_date, outfile_json, outfile_html, startdate, enddate):
    group = get_group(parent_group_id)
    group_full_path = group.get("full_path") or str(parent_group_id)

    by_user = collect_group_activity(parent_group_id, start_date, end_date)
    by_project = build_project_activity(by_user)

    data = {
        "meta": {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "group_id": parent_group_id,
            "group_full_path": group_full_path,
            "start": start_date,
            "end": end_date,
        },
        "by_user": by_user,
        "by_project": by_project,
    }

    with open(outfile_json, "w", encoding="utf-8") as report_json_file:
        json.dump(data, report_json_file, ensure_ascii=False, indent=2)

    html_content = render_json_report_page(data, startdate, enddate)
    with open(outfile_html, "w", encoding="utf-8") as report_html_file:
        report_html_file.write(html_content)

    return data
