# CHANGELOG

<!-- version list -->

## v5.0.6 (2026-02-23)

### Bug Fixes

- Bad PP tk
  ([`e9e3afc`](https://github.com/GrCOTE7/Kit2/commit/e9e3afce546395f0dd2311ac9fea3f61eef0cf98))


## v5.0.5 (2026-02-23)


## v5.0.4 (2026-02-23)

### Bug Fixes

- 4 ? ([`83969cd`](https://github.com/GrCOTE7/Kit2/commit/83969cd33e23927b2ebf21648566f6ea9afe2f69))


## v5.0.3 (2026-02-23)

### Bug Fixes

- Previous is not a release
  ([`7f43d29`](https://github.com/GrCOTE7/Kit2/commit/7f43d29d97cd300660b33a0de8d38c1743e57697))


## v1.0.0 (2026-02-23)

- Initial Release

## v1.2.0 (2026-02-23)


## v1.1.0 (2026-02-23)


## v1.0.2 (2026-02-23)


## v1.0.1 (2026-02-23)


## v1.0.0 (2026-02-23)

- Initial Release

## v5.0.2 (2026-02-23)

### Bug Fixes

- Try without dev 4 pypi
  ([`2f31ba9`](https://github.com/GrCOTE7/Kit/commit/2f31ba97e916d0e048d01e30c0c1956edd876942))


## v5.0.1 (2026-02-23)

### Bug Fixes

- Nett ([`eba80e3`](https://github.com/GrCOTE7/Kit/commit/eba80e33f660cff73ff41273b9955f66dfd2d649))

- New tk1
  ([`a41cbf5`](https://github.com/GrCOTE7/Kit/commit/a41cbf5ca865be7804470592aa598ee95135d8aa))

- New tk2
  ([`cfa7567`](https://github.com/GrCOTE7/Kit/commit/cfa756721f694b0be8a333cd8bddd47aa7a0b74a))

- No 777
  ([`45b2fc1`](https://github.com/GrCOTE7/Kit/commit/45b2fc1445a497d432f120e397dba5f4b8343419))

- Permit write
  ([`828e8f5`](https://github.com/GrCOTE7/Kit/commit/828e8f5c06d166901925eb546679981f67033ae9))


## v5.0.0 (2026-02-23)

### Bug Fixes

- New GH_TK
  ([`cffb81a`](https://github.com/GrCOTE7/Kit/commit/cffb81ac43898b7eff7eda843a72384f06f68c24))

- Up ([`95db834`](https://github.com/GrCOTE7/Kit/commit/95db834d08a5eb08887c1a19d290a81a807612a9))

- Up name
  ([`512a710`](https://github.com/GrCOTE7/Kit/commit/512a7100a79d8a2e7326cb80ec39bd5aa9af39ff))

- Up2 ([`5b3ecc5`](https://github.com/GrCOTE7/Kit/commit/5b3ecc569b30aeaf602739aa44b316c07118bc69))

- V4.0.1 ?
  ([`83213fb`](https://github.com/GrCOTE7/Kit/commit/83213fbeaabfb22c48b13478d903e3464d52d978))

### Features

- Up from new GH
  ([`d31373c`](https://github.com/GrCOTE7/Kit/commit/d31373c4ce2531c35e88e5eb48dae2cb86069b84))


## v4.0.0 (2026-02-22)

- Initial Release
