from setuptools import setup, find_packages
setup(
    name="angel-cpu",
    version="1.2",
    author="ERROR-Xmakernotfound",
    author_email="",
    description="A CPU framework",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "pygame",
    ],
    entry_points={
        "console_scripts": [
            "angel=angel_cpu.angel:main",
        ],
    },
)
