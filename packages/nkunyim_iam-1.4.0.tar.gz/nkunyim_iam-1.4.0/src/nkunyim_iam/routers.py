from rest_framework import routers
from nkunyim_iam.viewsets import (
    UserViewSet,
    LoggingViewSet,
)


iam_router = routers.DefaultRouter()

iam_router.register(r'users', UserViewSet, basename='User')
iam_router.register(r'logs', LoggingViewSet, basename='Logging')
