from http import HTTPMethod
import json

from django.conf import settings
from rest_framework import HTTP_HEADER_ENCODING, authentication

from nkunyim_iam.commands import IdentityConfigCommand
from nkunyim_iam.encryption import Signature
from nkunyim_iam.services import IdentityService



class JWTAuthentication(authentication.BaseAuthentication):
    
    def __init__(self, *args, **kwargs):        
        super().__init__(*args, **kwargs)
                            
        self.authentication_headers = ["Bearer", "JWT",]
        self.www_authenticate_realm = 'api' 


    def authenticate_header(self, request): # type: ignore
        return '{0} realm="{1}"'.format(
            self.authentication_headers[0],
            self.www_authenticate_realm,
        )
        
    def authenticate(self, request):
        header = self.get_header(request)
        if header is None:
            return None
                
        if isinstance(header, bytes):
            header = header.decode("utf-8") 
        
        token = self.get_raw_token(header)
        if token is None:
            return None
        
        config = IdentityConfigCommand.model_validate(settings.IDENTITY_CLIENT_CONFIG)
        service = IdentityService(config=config, req=request)
        user = service.authenticate(token=token)
        if not user:
            return None
        
        if self.is_payload_valid(request=request):
            return None
        
        return (user, None)


    def get_header(self, request):
        header = request.META.get('HTTP_AUTHORIZATION', None)
        if header is None:
            return None

        if isinstance(header, str):
            header = header.encode(HTTP_HEADER_ENCODING)

        return header
    
    
    def get_raw_token(self, header):
        parts = header.split()

        if len(parts) == 0:
            return None

        if parts[0] not in self.authentication_headers:
            return None
        
        if len(parts) != 2:
            return None

        return parts[1]
    
    
    def is_payload_valid(self, request) -> bool:
        service_config = Signature.service_config()
        if not service_config.verify or service_config.key == '':
            return True
        
        if not request.method in [HTTPMethod.POST, HTTPMethod.PATCH, HTTPMethod.PUT]:
            return True
        
        signature = request.META.get('HTTP_AUTHENTICATION', None)
        if not signature:
            return False
        
        if not isinstance(signature, str):
            signature = str(signature)
        
        body = json.loads(request.body.decode('utf-8'))
        if not body:
            return False
        
        return Signature.verify(signature=signature, payload=body)

