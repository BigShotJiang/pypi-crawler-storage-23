import rich_click as click
from flyte.cli import _common as common

from flyteplugins.union.remote import Assignment, User


@click.command("user")
@click.option("--first-name", type=str, required=True, help="First name of the user")
@click.option("--last-name", type=str, required=True, help="Last name of the user")
@click.option("--email", type=str, required=True, help="Email address of the user")
@click.option("--policy", type=str, default=None, help="Policy to assign to the user after creation")
@click.pass_obj
def create_user(cfg: common.CLIConfig, first_name: str, last_name: str, email: str, policy: str | None):
    """Create (invite) a new user.

    Examples:

        $ flyte --org my-org create user --first-name Jane --last-name Doe --email jane@example.com
        $ flyte --org my-org create user --first-name Jane --last-name Doe --email jane@example.com --policy admin
    """
    cfg.init(project="", domain="")
    console = common.get_console()

    try:
        user = User.create(first_name=first_name, last_name=last_name, email=email)
    except Exception as e:
        raise click.ClickException(f"Unable to create user: {e}") from e

    console.print(f"[green]✓[/green] Successfully created user: [cyan]{user.email}[/cyan] ({user.subject})")

    if policy:
        try:
            Assignment.create(user_subject=user.subject, policy=policy)
        except Exception as e:
            raise click.ClickException(f"User created, but unable to assign policy '{policy}': {e}") from e
        console.print(f"[green]✓[/green] Assigned policy [cyan]{policy}[/cyan] to user")


@click.command("user")
@click.argument("subject", type=str, required=False)
@click.option("--limit", type=int, default=100, help="Maximum number of users to list")
@click.option("--email", type=str, default=None, help="Filter by email address")
@click.pass_obj
def get_user(cfg: common.CLIConfig, subject: str | None, limit: int, email: str | None):
    """Get or list users.

    If SUBJECT is provided, gets a specific user. Otherwise, lists all users.

    Examples:

        $ flyte --org my-org get user
        $ flyte --org my-org get user --limit 10
        $ flyte --org my-org get user user-subject-id
        $ flyte --org my-org get user --email jane@example.com
    """
    cfg.init(project="", domain="")
    console = common.get_console()

    try:
        if subject:
            user = User.get(subject)
            console.print(common.format(f"User {subject}", [user], "json"))
        else:
            users = list(User.listall(limit=limit, email=email))
            if not users:
                console.print("[yellow]No users found.[/yellow]")
                return
            console.print(common.format("Users", users, cfg.output_format))
    except Exception as e:
        raise click.ClickException(f"Unable to get user(s): {e}") from e


@click.command("user")
@click.argument("subject", type=str)
@click.option("--yes", is_flag=True, help="Skip confirmation prompt")
@click.pass_obj
def delete_user(cfg: common.CLIConfig, subject: str, yes: bool):
    """Delete a user.

    Examples:

        $ flyte --org my-org delete user user-subject-id
        $ flyte --org my-org delete user user-subject-id --yes
    """
    cfg.init(project="", domain="")
    console = common.get_console()

    if not yes:
        click.confirm(f"Are you sure you want to delete user '{subject}' from org '{cfg.org}'?", abort=True)

    try:
        User.delete(subject)
        console.print(f"[green]✓[/green] Successfully deleted user: [cyan]{subject}[/cyan]")
    except Exception as e:
        raise click.ClickException(f"Unable to delete user: {e}") from e
