import rich_click as click
from flyte.cli import _common as common

from flyteplugins.union.remote import Assignment


@click.command("assignment")
@click.option("--user-subject", type=str, default=None, help="User subject identifier")
@click.option("--creds-subject", type=str, default=None, help="Client credentials application subject")
@click.option("--email", type=str, default=None, help="User email for lookup")
@click.option("--policy", type=str, required=True, help="Policy name to assign")
@click.pass_obj
def create_assignment(
    cfg: common.CLIConfig,
    user_subject: str | None,
    creds_subject: str | None,
    email: str | None,
    policy: str,
):
    """Assign a policy to an identity.

    Exactly one of --user-subject, --creds-subject, or --email must be provided.

    Examples:

        $ flyte --org my-org create assignment --user-subject user-123 --policy admin
        $ flyte --org my-org create assignment --creds-subject app-456 --policy admin
        $ flyte --org my-org create assignment --email jane@example.com --policy admin
    """
    cfg.init(project="", domain="")
    console = common.get_console()

    provided = sum(x is not None for x in (user_subject, creds_subject, email))
    if provided != 1:
        raise click.ClickException("Exactly one of --user-subject, --creds-subject, or --email must be provided")

    try:
        assignment = Assignment.create(
            user_subject=user_subject,
            creds_subject=creds_subject,
            email=email,
            policy=policy,
        )
        console.print(
            f"[green]✓[/green] Successfully assigned policy [cyan]{policy}[/cyan] to [cyan]{assignment.subject}[/cyan]"
        )
    except Exception as e:
        raise click.ClickException(f"Unable to create assignment: {e}") from e


@click.command("assignment")
@click.option("--user-subject", type=str, default=None, help="User subject identifier")
@click.option("--creds-subject", type=str, default=None, help="Client credentials application subject")
@click.pass_obj
def get_assignment(cfg: common.CLIConfig, user_subject: str | None, creds_subject: str | None):
    """Get or list assignments.

    Without --user-subject or --creds-subject, lists all assignments.

    Examples:

        $ flyte --org my-org get assignment
        $ flyte --org my-org get assignment --user-subject user-123
        $ flyte --org my-org get assignment --creds-subject app-456
    """
    cfg.init(project="", domain="")
    console = common.get_console()

    try:
        if user_subject or creds_subject:
            assignment = Assignment.get(user_subject=user_subject, creds_subject=creds_subject)
            console.print(common.format("Assignment", [assignment], "json"))
        else:
            assignments = list(Assignment.listall())
            if not assignments:
                console.print("[yellow]No assignments found.[/yellow]")
                return
            console.print(common.format("Assignments", assignments, cfg.output_format))
    except Exception as e:
        raise click.ClickException(f"Unable to get assignment(s): {e}") from e


@click.command("assignment")
@click.option("--user-subject", type=str, default=None, help="User subject identifier")
@click.option("--creds-subject", type=str, default=None, help="Client credentials application subject")
@click.option("--policy", type=str, required=True, help="Policy name to unassign")
@click.option("--yes", is_flag=True, help="Skip confirmation prompt")
@click.pass_obj
def delete_assignment(
    cfg: common.CLIConfig,
    user_subject: str | None,
    creds_subject: str | None,
    policy: str,
    yes: bool,
):
    """Unassign a policy from an identity.

    One of --user-subject or --creds-subject must be provided.

    Examples:

        $ flyte --org my-org delete assignment --user-subject user-123 --policy admin
        $ flyte --org my-org delete assignment --creds-subject app-456 --policy admin
    """
    cfg.init(project="", domain="")
    console = common.get_console()

    if not user_subject and not creds_subject:
        raise click.ClickException("One of --user-subject or --creds-subject must be provided")

    subject = user_subject or creds_subject
    if not yes:
        click.confirm(f"Are you sure you want to unassign policy '{policy}' from '{subject}'?", abort=True)

    try:
        Assignment.unassign(user_subject=user_subject, creds_subject=creds_subject, policy=policy)
        console.print(
            f"[green]✓[/green] Successfully unassigned policy [cyan]{policy}[/cyan] from [cyan]{subject}[/cyan]"
        )
    except Exception as e:
        raise click.ClickException(f"Unable to delete assignment: {e}") from e
