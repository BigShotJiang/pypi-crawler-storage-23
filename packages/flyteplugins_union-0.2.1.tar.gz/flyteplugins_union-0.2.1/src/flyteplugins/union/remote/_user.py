from __future__ import annotations

from dataclasses import dataclass
from typing import AsyncIterator

from flyte._initialize import ensure_client, get_client, get_init_config
from flyte.remote._common import ToJSONMixin
from flyte.syncify import syncify

from flyteplugins.union.internal.common import list_pb2
from flyteplugins.union.internal.common.identifier_pb2 import UserIdentifier
from flyteplugins.union.internal.common.identity_pb2 import User as UserPb2
from flyteplugins.union.internal.common.identity_pb2 import UserSpec
from flyteplugins.union.internal.identity.user_payload_pb2 import (
    CreateUserRequest,
    DeleteUserRequest,
    GetUserRequest,
    ListUsersRequest,
)
from flyteplugins.union.internal.identity.user_service_pb2_grpc import UserServiceStub


@dataclass
class User(ToJSONMixin):
    """Represents a Union user."""

    pb2: UserPb2

    @property
    def subject(self) -> str:
        return self.pb2.id.subject

    @property
    def email(self) -> str:
        return self.pb2.spec.email

    @property
    def first_name(self) -> str:
        return self.pb2.spec.first_name

    @property
    def last_name(self) -> str:
        return self.pb2.spec.last_name

    def __rich_repr__(self):
        yield "subject", self.subject
        yield "email", self.email
        yield "first_name", self.first_name
        yield "last_name", self.last_name

    @syncify
    @classmethod
    async def create(cls, *, first_name: str, last_name: str, email: str) -> User:
        """Create (invite) a new user.

        Args:
            first_name: The user's first name.
            last_name: The user's last name.
            email: The user's email address.

        Returns:
            User instance for the newly created user.
        """
        ensure_client()
        client = get_client()
        org = get_init_config().org
        stub = UserServiceStub(client._channel)

        spec = UserSpec(
            first_name=first_name,
            last_name=last_name,
            email=email,
            organization=org,
        )
        request = CreateUserRequest(spec=spec)
        response = await stub.CreateUser(request)

        # The create response only returns the id; fetch the full user.
        return await cls.get.aio(response.id.subject)

    @syncify
    @classmethod
    async def get(cls, subject: str) -> User:
        """Get a user by subject identifier."""
        ensure_client()
        client = get_client()
        stub = UserServiceStub(client._channel)

        request = GetUserRequest(id=UserIdentifier(subject=subject))
        response = await stub.GetUser(request)
        return cls(pb2=response.user)

    @syncify
    @classmethod
    async def delete(cls, subject: str) -> None:
        """Delete a user."""
        ensure_client()
        client = get_client()
        org = get_init_config().org
        stub = UserServiceStub(client._channel)

        request = DeleteUserRequest(
            id=UserIdentifier(subject=subject),
            organization=org,
        )
        await stub.DeleteUser(request)

    @syncify
    @classmethod
    async def listall(
        cls,
        *,
        limit: int = 100,
        email: str | None = None,
    ) -> AsyncIterator[User]:
        """List all users in the organization.

        Args:
            limit: Maximum number of users to return.
            email: Filter by email (server-side, exact match).
        """
        ensure_client()
        client = get_client()
        org = get_init_config().org
        stub = UserServiceStub(client._channel)

        filters = []
        if email:
            filters.append(
                list_pb2.Filter(
                    function=list_pb2.Filter.Function.EQUAL,
                    field="email",
                    values=[email],
                )
            )

        token = None
        i = 0
        while True:
            request = ListUsersRequest(
                organization=org,
                request=list_pb2.ListRequest(
                    limit=min(100, limit),
                    token=token,
                    filters=filters,
                ),
            )
            response = await stub.ListUsers(request)
            token = response.token

            for user in response.users:
                i += 1
                if i > limit:
                    return
                yield cls(pb2=user)

            if not token:
                break
