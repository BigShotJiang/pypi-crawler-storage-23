from __future__ import annotations

from dataclasses import dataclass
from typing import AsyncIterator

from flyte._initialize import ensure_client, get_client, get_init_config
from flyte.remote._common import ToJSONMixin
from flyte.syncify import syncify

from flyteplugins.union.internal.authorizer.authorizer_pb2_grpc import AuthorizerServiceStub
from flyteplugins.union.internal.authorizer.definition_pb2 import IdentityAssignment
from flyteplugins.union.internal.authorizer.payload_pb2 import (
    AssignIdentityRequest,
    GetIdentityAssignmentRequest,
    ListIdentityAssignmentsRequest,
    UnassignIdentityRequest,
)
from flyteplugins.union.internal.common.identifier_pb2 import (
    ApplicationIdentifier,
    PolicyIdentifier,
    UserIdentifier,
)
from flyteplugins.union.internal.common.identity_pb2 import Identity


def _build_identity(*, user_subject: str | None = None, creds_subject: str | None = None) -> Identity:
    """Build an Identity proto from either a user or application subject."""
    if user_subject:
        return Identity(user_id=UserIdentifier(subject=user_subject))
    if creds_subject:
        return Identity(application_id=ApplicationIdentifier(subject=creds_subject))
    raise ValueError("One of user_subject or creds_subject must be provided")


@dataclass
class Assignment(ToJSONMixin):
    """Represents role/policy assignments for an identity."""

    pb2: IdentityAssignment

    @property
    def subject(self) -> str:
        identity = self.pb2.identity
        if identity.HasField("user_id"):
            return identity.user_id.subject
        if identity.HasField("application_id"):
            return identity.application_id.subject
        return ""

    @property
    def roles(self) -> list[str]:
        return [r.id.name for r in self.pb2.roles]

    @property
    def policies(self) -> list[str]:
        return [p.id.name for p in self.pb2.policies]

    def __rich_repr__(self):
        yield "subject", self.subject
        yield "roles", self.roles
        yield "policies", self.policies

    @syncify
    @classmethod
    async def create(
        cls,
        *,
        user_subject: str | None = None,
        creds_subject: str | None = None,
        email: str | None = None,
        policy: str,
    ) -> Assignment:
        """Assign a policy to an identity.

        Exactly one of user_subject, creds_subject, or email must be provided.

        Args:
            user_subject: User subject identifier.
            creds_subject: Client credentials application subject.
            email: User email for lookup.
            policy: Policy name to assign.

        Returns:
            Assignment for the identity after the policy is assigned.
        """
        provided = sum(x is not None for x in (user_subject, creds_subject, email))
        if provided != 1:
            raise ValueError("Exactly one of user_subject, creds_subject, or email must be provided")

        if email:
            from flyteplugins.union.remote._user import User  # noqa: PLC0415

            users = []
            async for user in User.listall.aio(email=email):
                users.append(user)
            if len(users) == 0:
                raise ValueError(f"No user found with email '{email}'")
            if len(users) > 1:
                raise ValueError(f"Multiple users found with email '{email}': {[u.subject for u in users]}")
            user_subject = users[0].subject

        ensure_client()
        client = get_client()
        org = get_init_config().org
        stub = AuthorizerServiceStub(client._channel)

        identity = _build_identity(user_subject=user_subject, creds_subject=creds_subject)

        request = AssignIdentityRequest(
            organization=org,
            identity=identity,
            policy_id=PolicyIdentifier(organization=org, name=policy),
        )
        await stub.AssignIdentity(request)

        return await cls.get.aio(user_subject=user_subject, creds_subject=creds_subject)

    @syncify
    @classmethod
    async def unassign(
        cls,
        *,
        user_subject: str | None = None,
        creds_subject: str | None = None,
        policy: str,
    ) -> None:
        """Unassign a policy from an identity.

        One of user_subject or creds_subject must be provided.
        """
        ensure_client()
        client = get_client()
        org = get_init_config().org
        stub = AuthorizerServiceStub(client._channel)

        identity = _build_identity(user_subject=user_subject, creds_subject=creds_subject)

        request = UnassignIdentityRequest(
            organization=org,
            identity=identity,
            policy_id=PolicyIdentifier(organization=org, name=policy),
        )
        await stub.UnassignIdentity(request)

    @syncify
    @classmethod
    async def get(
        cls,
        *,
        user_subject: str | None = None,
        creds_subject: str | None = None,
    ) -> Assignment:
        """Get assignments for an identity.

        One of user_subject or creds_subject must be provided.
        """
        ensure_client()
        client = get_client()
        org = get_init_config().org
        stub = AuthorizerServiceStub(client._channel)

        identity = _build_identity(user_subject=user_subject, creds_subject=creds_subject)

        request = GetIdentityAssignmentRequest(identity=identity, organization=org)
        response = await stub.GetIdentityAssignments(request)
        return cls(pb2=response.identity_assignment)

    @syncify
    @classmethod
    async def listall(cls, *, limit: int = 100) -> AsyncIterator[Assignment]:
        """List assignments for all members in the organization."""
        from flyteplugins.union.remote._member import Member  # noqa: PLC0415

        ensure_client()
        client = get_client()
        org = get_init_config().org
        stub = AuthorizerServiceStub(client._channel)

        members = list(Member.listall())
        identities = []
        for m in members[:limit]:
            if m.is_user:
                identities.append(Identity(user_id=UserIdentifier(subject=m.subject)))
            elif m.is_application:
                identities.append(Identity(application_id=ApplicationIdentifier(subject=m.subject)))

        request = ListIdentityAssignmentsRequest(organization=org, identities=identities)
        response = await stub.ListIdentityAssignments(request)

        for assignment in response.identity_assignments:
            yield cls(pb2=assignment)
