from uuid import UUID

from nkunyim_iam.encryption import Base64Util, Hashing
from nkunyim_iam.models import Logging, User
from nkunyim_iam.commands import (
    LoggingCommand,
    LoggingLevel,
    UserCommand,
    HashingAlgo
)


class UserHandler:
    @staticmethod
    def handle(command: UserCommand) -> User:
        command.password = Hashing(input_string=command.id.hex).make(
            algo=HashingAlgo.S512
        )
        command.serial = Base64Util.encode(command.password)

        user = User.objects.filter(id=command.id).first()
        if not user:
            user = User(id=command.id)
        
        user.username = command.username
        user.nickname = command.nickname
        user.first_name = command.first_name
        user.last_name = command.last_name
        user.email_address = command.email_address
        user.phone_number = command.phone_number
        user.gender = command.gender
        user.serial = command.serial
        user.is_pwd = command.is_pwd
        user.is_verified = command.is_verified
        user.is_active = command.is_active
        user.is_admin = command.is_admin
        user.is_superuser = command.is_superuser

        if command.email_verified and command.email_verified != user.email_verified:
            user.email_verified = command.email_verified

        if command.phone_verified and command.phone_verified != user.phone_verified:
            user.phone_verified = command.phone_verified

        if command.middle_name and command.middle_name != user.middle_name:
            user.middle_name = command.middle_name

        if command.birth_date and command.birth_date != user.birth_date:
            user.birth_date = command.birth_date

        if command.photo_url and command.photo_url != user.photo_url:
            user.photo_url = command.photo_url

        if command.profile and command.profile != user.profile:
            user.profile = command.profile

        user.set_password(command.password)
        user.save()
        return user


    @staticmethod
    def create(data: dict) -> User:
        command = UserCommand(
            id=UUID(data['id']),
            username=data['username'],
            nickname=data['nickname'],
            first_name=data['first_name'],
            middle_name=data.get('middle_name'),
            last_name=data['last_name'],
            email_address=data['email_address'],
            email_verified=data['email_verified'],
            email_verified_at=data.get('email_verified_at'),
            phone_number=data['phone_number'],
            phone_verified=data['phone_verified'],
            phone_verified_at=data.get('phone_verified_at'),
            serial=data.get('serial'),
            gender=data['gender'],
            birth_date=data.get('birth_date'),
            photo_url=data.get('photo_url'),
            photo_verified=data.get('photo_verified', False),
            photo_verified_at=data.get('photo_verified_at'),
            profile=data.get('profile'),
            password=data.get('password'),
            is_pwd=data.get('is_pwd', False),
            is_active=data.get('is_active', True),
            is_admin=data.get('is_admin', False),
            is_superuser=data.get('is_superuser', False),
            is_verified=data.get('is_verified', False),
        )
        return UserHandler.handle(command=command)
    
    @staticmethod
    def create_user(data: dict) ->User:
        return User.objects.create_user(
            username=data['username'],
            nickname=data['nickname'],
            first_name=data['first_name'],
            last_name=data['last_name'],
            phone_number=data['phone_number'],
            email_address=data['email_address'],
            password=data['password']
        )

    @staticmethod
    def create_superuser(data: dict) ->User:
        return User.objects.create_superuser(
            username=data['username'],
            nickname=data['nickname'],
            first_name=data['first_name'],
            last_name=data['last_name'],
            phone_number=data['phone_number'],
            email_address=data['email_address'],
            password=data['password']
        )


class LoggingHandler:
    @staticmethod
    def handle(logging: LoggingCommand) -> None:
        create = Logging()
        create.level = logging.level
        create.message = logging.message
        create.context = dict(logging.context)
        create.save()
        
    @staticmethod
    def info(message: str, context: dict = {}) -> None:
        logging = LoggingCommand(level=LoggingLevel.INFO, message=message, context=context)
        LoggingHandler.handle(logging)
    
    @staticmethod
    def success(message: str, context: dict = {}) -> None:
        logging = LoggingCommand(level=LoggingLevel.SUCCESS, message=message, context=context)
        LoggingHandler.handle(logging)
        
    @staticmethod
    def warning(message: str, context: dict = {}) -> None:
        logging = LoggingCommand(level=LoggingLevel.WARNING, message=message, context=context)
        LoggingHandler.handle(logging)
        
    @staticmethod
    def danger(message: str, context: dict = {}) -> None:
        logging = LoggingCommand(level=LoggingLevel.DANGER, message=message, context=context)
        LoggingHandler.handle(logging)
