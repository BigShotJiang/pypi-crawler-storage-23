

While things usually work just fine, sometimes right after stoping a terminal session, the device gets stuck in a state that makes it impossible to start any terminal sessions because every time you send the terminal_start command, it responds with terminal_started abut follows it immidietaly with terminal_exit for whatever reason.