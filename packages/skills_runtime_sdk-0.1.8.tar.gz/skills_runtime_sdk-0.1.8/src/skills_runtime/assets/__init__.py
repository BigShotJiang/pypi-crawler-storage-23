"""
SDK 内置资产（默认配置与默认 prompt 模板）。

说明：
- 这些文件会随 package 分发，用于“开箱即用”的最佳实践默认值；
- 应用层仍可通过 overlay 配置与 PromptTemplates 参数覆盖这些默认值。
"""

