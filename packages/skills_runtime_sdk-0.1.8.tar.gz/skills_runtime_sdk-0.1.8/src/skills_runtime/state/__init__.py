"""状态持久化与恢复（WAL/Checkpoint）。"""

