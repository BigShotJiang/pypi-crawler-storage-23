from enum import Enum


class CompressType(str, Enum):
    rgbimage = "rgbimage"
    token = "token"
    ctxtoken = "ctxtoken"
    pixeltoken = "pixeltoken"
