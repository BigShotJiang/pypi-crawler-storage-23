import os
from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field
from typing_extensions import Annotated

from m3_sdk.DistributedPath import DistributedPath


class GeojsonRegionWindows(BaseModel):
    min_area: float = Field(
        default=0.95,
        description="Area of a window that is required to be inside the annotated region. 0.95 for 95%",
    )
    patch_size: tuple[int, int] | None = 224, 224
    coordinate_augmentation: Literal["random", "none"] = "random"
    windowsize_augmentation: Literal["relative", "none"] = "relative"
    augmentation_strength: float = Field(
        default=0.2,
        description="Controls the windowsize augmentation. Should be smaller than 1.",
    )
    shuffle_coordinates_and_levels: bool = Field(
        default=True,
        description="If true, the coordinates are randomly shuffled and the next level is randomly selected.",
    )
    stepsize: int = Field(
        default=2,
        description="Controls the stepsize. For one moves one window at a time, for 2 it moves half a window every step",
    )
    filter_large_levels: bool = Field(
        default=True, description="Filters levels in which the annotation is smaller than the patch size."
    )


class GigapixelImage(BaseModel):
    """
    >>> GigapixelImage(url="./image.tiff").max_instances is None
    True

    The default for max_instances can be controlled via the environment variable 'gigapixelimage_max_instances'.
    >>> os.environ['gigapixelimage_max_instances'] = '10'; GigapixelImage(url="./image.tiff").max_instances
    10
    """

    model_config = ConfigDict(extra="allow")

    type: Literal["gigapixel"] = "gigapixel"
    url: DistributedPath
    sample_geojson: str | None | dict | DistributedPath = Field(
        default=None,
        description="""The instance meta will reference the 'properties' of the GeoJSON annotation as 'props'.
String and Paths will be loaded into a dictionary representing the GeoJSON.
        """,
    )

    extraction: GeojsonRegionWindows = GeojsonRegionWindows(
        min_area=0.5,  # only include instances that are at least 50% inside the annotated region
        coordinate_augmentation="none",
        windowsize_augmentation="none",
        augmentation_strength=0.0,
        stepsize=1,
        patch_size=(448, 448),
        shuffle_coordinates_and_levels=True,
    )
    levels: list[int] = Field(default=[0, 1, 2], description="The level of the pyramid to extract the image from.")
    max_instances: int | None = Field(
        default_factory=lambda: (
            None
            if (envvar_max_instances := int(os.getenv("gigapixelimage_max_instances", "-1"))) < 0
            else envvar_max_instances
        ),
        description="""The maximum number of instances to extract.
extraction.shuffle_coordinates_and_levels should be set to True to avoid only representing some specific region.""",
    )


class Volume3DImage(BaseModel):
    model_config = ConfigDict(extra="allow")

    type: Literal["volume3d"] = "volume3d"
    url: DistributedPath | list[DistributedPath] = Field(
        description="The URL to the volume data. In case of a list all images are loaded like the first"
    )
    rotate: None | Literal["never", "always", "ifcubical"] = None
    fix_orientation: None | Literal["never", "smallest_axis_into_depth"] | str = None
    resample_to_spacing: None | tuple[float, float, float] = None
    divisable_by: None | tuple[int, int, int] = Field(
        default=None,
        description="Each edge will be padded to be divisable. fix_orientation will be applied before padding.",
    )


class AbstractResult(BaseModel):
    model_config = ConfigDict(extra="allow")
    item_index: int | None = Field(
        default=None,
        description="""The data item that this result belongs to.
If None, the result is relevant for the whole subject.""",
    )
    from_name: str = Field(description="Label name")
    to_name: str = Field(description="Input name")
    score: float | None = Field(default=None)

    def __getitem__(self, key):
        return getattr(self, key)


class BaseResult(AbstractResult):
    type: Literal["brushlabels", "rectanglelabels", "number", "textarea", "choices"]  # All supported labelstudio types

    value: dict[str, Any] = Field(description="""For classification: {"choices": ["Class1", "Class2", ...]}""")

    def get_multiclass_classification(self) -> str | None:
        assert self.type == "choices"
        assert len(self.value["choices"]) == 1, "For multiclass classification, there should be exactly one choice"
        return self.value.get("choices", [None])[0]


class GeoMask(AbstractResult):
    class FeatureCollection(BaseModel):
        type: Literal["FeatureCollection"] = "FeatureCollection"
        features: list[dict] = Field(
            description="List of GeoJSON features. Each feature is a dict with 'type', 'geometry', and 'properties'."
        )

    type: Literal["geomask"] = "geomask"
    value: FeatureCollection | DistributedPath = Field(
        description="The GeoJSON mask {'type': 'FeatureCollection', 'features': [...]} or path to the GeoJSON mask file"
    )


class Volume3DMask(AbstractResult):
    # annotations by labelstudio also have a type such as "brushlabels", "rectanglelabels" etc.
    type: Literal["volume3dmask"] = "volume3dmask"
    value: DistributedPath


class Volume3DBox(AbstractResult):
    type: Literal["volume3dbox"] = "volume3dbox"
    value: dict[str, Any] = Field(description="Contains the coordinates of the box and the class information")


Result = Annotated[Volume3DBox | Volume3DMask | GeoMask | BaseResult, Field(discriminator="type")]


class Annotation(BaseModel):
    model_config = ConfigDict(extra="allow")

    result: list[Result]

    def __getitem__(self, key):
        return getattr(self, key)


class Prediction(Annotation):
    # See label_studio_sdk.Prediction for full model
    model_config = ConfigDict(protected_namespaces=())  # required because one property starts with "model_"

    result: list[Result]
    score: float | None = None
    model_version: str


ImageType = str | Volume3DImage | GigapixelImage


class Subject(BaseModel):
    id: str | int | None = None
    data: dict[str, list[ImageType] | ImageType] = {}
    predictions: list[Prediction] | None = None
    annotations: list[Annotation] | None = None
    meta: dict | None = None

    def get_last_updated_annotation(self, only_for_label: str | None = None) -> Annotation | None:
        """
        If a field 'updated_at' is available, the latest annotation is returned.

        Otherwise, the last annotation is returned.
        """
        if not self.annotations:
            return None

        if only_for_label is not None:
            annos = [a for a in self.annotations if only_for_label in [r["from_name"] for r in a.result]]
            if not annos:
                return None
        else:
            annos = self.annotations

        if all([hasattr(a, "updated_at") for a in annos]):
            from datetime import datetime

            updated_at = [datetime.fromisoformat(a.updated_at[:-1]) for a in annos]  # type: ignore
            latest_index = updated_at.index(max(updated_at))
            return annos[latest_index]
        else:
            return annos[-1]

    def get_last_prediction(self, for_model_version: str | None) -> Prediction | None:
        """ """
        if not self.predictions:
            return None

        # Find the latest prediction for the given model version
        if for_model_version is not None:
            predictions = [p for p in self.predictions if p.model_version == for_model_version]
            if not predictions:
                return None
        else:
            predictions = self.predictions

        return predictions[-1]


class EventType(str, Enum):
    TrainingStep = "TrainingStep"
    TrainingDone = "TrainingDone"


class TrainingStepEvent(BaseModel):
    event_type: Literal[EventType.TrainingStep] = EventType.TrainingStep
    loss: float


class TrainingDoneEvent(BaseModel):
    event_type: Literal[EventType.TrainingDone] = EventType.TrainingDone


WebhookEvent = TrainingStepEvent | TrainingDoneEvent


class WebhookResponse(BaseModel):
    return_id: str
    event: WebhookEvent


class Webhook(BaseModel):
    url: str
    events: list[EventType] = [EventType.TrainingStep, EventType.TrainingDone]
    return_id: str | None = None
