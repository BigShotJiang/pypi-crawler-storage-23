from __future__ import annotations

import ast
import base64
import io
from typing import Any

import numpy as np
import torch
from pydantic import BaseModel, ConfigDict, Field, PlainSerializer, PlainValidator
from typing_extensions import Annotated

from m3_sdk.types import CompressType


def array_to_dict(arr):
    """
    Converts a general array or tensor to a dictionary with base64 encoding
    """
    arraytype = "np" if isinstance(arr, np.ndarray) else "torch"
    if arraytype == "torch":
        arr = arr.numpy()
    return dict(
        data=base64.b64encode(arr).decode("utf-8"),
        dtype=str(arr.dtype),
        shape=arr.shape,
        arraytype=arraytype,
    )


def dict_to_array(d):
    """
    Converts a dictionary with base64 encoding to a general array or tensor
    """
    data = base64.b64decode(d["data"])
    dtype = np.dtype(d["dtype"])
    shape = d["shape"]
    arraytype = d["arraytype"]
    nparray = np.frombuffer(data, dtype=dtype).reshape(shape)
    if arraytype == "np":
        return nparray
    elif arraytype == "torch":
        return torch.from_numpy(nparray.copy())


def _serialize_tensor_if_dict(v) -> torch.Tensor:
    if isinstance(v, torch.Tensor):
        return v
    elif isinstance(v, np.ndarray):
        return torch.from_numpy(v)
    else:
        return dict_to_array(v)


# Only works for BaseModels with arbitrary_types_allowed=True
MTensor = Annotated[
    torch.Tensor,
    PlainSerializer(array_to_dict, return_type=dict),
    PlainValidator(_serialize_tensor_if_dict),
]


class Repr(BaseModel):
    """
    A representation is a PyTorch Tensor or Numpy Array with metadata.
    PyTorch's bfloat16 is not yet supported for serialization and should be converted before serialization.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True, extra="allow")

    tensor: MTensor
    meta: dict[str, Any] = Field(
        description="Contains additional information. Reserved keys are 'group_id', 'msubject', 'context'."
    )

    # Some ground truths are hard to extract without information about the image they describe.
    # For example a video ground truth might need to FPS information that was used to extract the video.
    # A 3D mask might need the orientation of the image to be correctly interpreted.
    _buffer: Any | None = None

    def __getitem__(self, key: str) -> Any:
        return getattr(self, key)

    def to_bytes(self, for_type: CompressType, is_ground_truth: bool = False, lossy: bool = True) -> bytes:
        import msgpack

        return msgpack.packb(self._for_serialization(for_type, is_ground_truth, lossy))

    @staticmethod
    def from_bytes(b: bytes):
        import msgpack
        import torchvision.transforms.functional as F

        raw, meta, (for_type_value, is_ground_truth, lossy, shape, np_saved, orig_dtype) = msgpack.unpackb(b)
        np_dtype = np.dtype(orig_dtype)
        for_type = CompressType(for_type_value)

        if np_saved:
            import io

            raw = np.load(io.BytesIO(raw))["arr"]
        elif not is_ground_truth and for_type is CompressType.rgbimage:
            import cv2

            pic = cv2.imdecode(np.frombuffer(raw, np.uint8), cv2.IMREAD_COLOR)
            # handle numpy array
            if pic.ndim == 2:
                pic = pic[:, :, None]

            raw = torch.from_numpy(pic.astype(np_dtype).transpose((2, 0, 1))).contiguous().div(255)
        else:
            raw_numpy = np.frombuffer(raw, dtype=np.float16 if lossy else np_dtype).reshape(shape)
            if lossy:
                raw_numpy = raw_numpy.astype(np_dtype)
            raw = torch.tensor(raw_numpy)

        return Repr(tensor=raw, meta=meta)

    def _for_serialization(
        self, for_type: CompressType, is_ground_truth: bool, lossy: bool
    ) -> tuple[bytes, dict, tuple[str, bool]]:
        """
        Only enables simple meta data to be stored and resolves tensor views.

        torch.save does not resolve tensor views. For this reason, numpy is used for converting into bytes.
        """
        raw_numpy = np.array(self.tensor)
        orig_dtype = raw_numpy.dtype
        np_saved = False

        if raw_numpy.dtype.kind in "iu":  # int and uint
            b = io.BytesIO()
            np.savez_compressed(b, arr=raw_numpy)
            raw_bytes, shape = b.getvalue(), raw_numpy.shape
            np_saved = True
        elif not is_ground_truth and for_type is CompressType.rgbimage:
            import cv2

            # Convert float32 C,H,W to numpy uint8 for saving as image
            raw = (raw_numpy * 255).transpose(1, 2, 0).astype(np.uint8)
            shape = raw.shape
            raw = cv2.imencode(".jpg" if lossy else ".png", raw)[1]
            raw_bytes = raw.tobytes()
        else:
            if raw_numpy.dtype in (np.float32, np.float64) and lossy:
                # Convert big float types to float16 for saving space
                raw_numpy = raw_numpy.astype(np.float16)

            shape = raw_numpy.shape
            raw_bytes = raw_numpy.tobytes()

        return (
            raw_bytes,
            {k: v for k, v in self.meta.items() if isinstance(v, (str, int, float, tuple, list))},
            (for_type.value, is_ground_truth, lossy, shape, np_saved, str(orig_dtype)),
        )

    @property
    def group_id(self):
        if "group_id" in self.meta:
            return self.meta["group_id"]
        if "msubject" in self.meta:
            return self.meta["msubject"].id
        return None

    def __repr__(self):
        return f"Representation with {self.tensor.shape=}, {self.meta=}"

    def _repr_html_(self):
        return self.__repr__()

    @staticmethod
    def to_mmm_image(repr: Repr):
        res = {"image": repr.tensor, "meta": repr.meta}
        if repr._buffer is not None:
            res["meta"]["buffer"] = repr._buffer  # needs to be in meta to be correctly collated
        return res

    def extract_subject_labels(self, labeling, extract_labels: list[str]):
        labels = {}
        for label in extract_labels:
            subject = self.meta["msubject"]
            if anno := subject.get_last_updated_annotation(only_for_label=label):
                labels[label] = anno.extract_gt(label_name=label, subject=subject, labeling=labeling, for_instance=self)

        if labels:
            self.meta["labels"] = labels
        return self

    @staticmethod
    def resolve_context(ctx: bytes):
        """
        Instance context modeled as InstanceContext = str | int | tuple[int | str, ...]
        """
        return ast.literal_eval(ctx.decode())
