import base64
import logging

import cv2
import numpy as np


def rgbnumpy_to_base64(img: np.ndarray) -> str:
    """
    Expects a numpy array with shape (H, W, C) and converts it to a base64 string like:

    >>> from skimage.data import astronaut
    >>> from m3_sdk.utils import rgbnumpy_to_base64
    >>> astronaut_base64 = rgbnumpy_to_base64(astronaut())

    The base64 string is accepted by browsers like:

    ```python
    from IPython.display import display, HTML
    HTML(f'<img src="{astronaut_base64}" />')
    ```
    """
    if img.shape[-1] == 3:  # RGB
        _, buffer = cv2.imencode(".jpg", cv2.cvtColor(img, cv2.COLOR_RGB2BGR))
        mime_type = "image/jpeg"
    elif img.shape[-1] == 4:  # RGBA
        _, buffer = cv2.imencode(".png", cv2.cvtColor(img, cv2.COLOR_RGBA2BGRA))
        mime_type = "image/png"
    elif len(img.shape) == 2:  # Grayscale
        _, buffer = cv2.imencode(".png", img)
        mime_type = "image/png"
    else:
        raise ValueError(f"No supported image format for shape {img.shape}")

    encoded_img = buffer.tobytes()
    base64_img_string = base64.b64encode(encoded_img).decode("utf-8")
    return f"data:{mime_type};base64,{base64_img_string}"


def brush_annotation_to_npy(result) -> tuple[str, np.ndarray]:
    """
    Expects something like:

    {
      'original_width': 2678,
      'original_height': 2954,
      'image_rotation': 0,
      'value': {'format': 'rle',
        'rle': [],
        'brushlabels': ['lung']},
      'id': 'aaOhNtmESo',
      'from_name': 'tag',
      'to_name': 'image',
      'type': 'brushlabels',
      'origin': 'manual'
    }
    """
    try:
        from label_studio_sdk.converter.brush import decode_rle
    except ImportError:
        logging.error("Please install label_studio_sdk")

    width, height = result["original_width"], result["original_height"]
    classnames = result["value"]["brushlabels"]
    rle = decode_rle(result["value"]["rle"])
    # For unknown reasons, the rle is decoded into four channels
    mask_channels = np.reshape(rle, [height, width, 4])

    mask = mask_channels[:, :, 3]

    assert result["image_rotation"] == 0
    assert len(classnames) == 1
    return classnames[0], mask


def convert_results_to_seglabel(results, prefill_value: int = -1) -> np.ndarray:
    # class_names, masks
    labels = [
        brush_annotation_to_npy(result)
        for result in results
        # if result["type"] == "brushlabels" and result["value"]["brushlabels"][0] in class_names
    ]
    if not labels:
        return None

    class_names = list(set([label[0] for label in labels]))
    # Combine the labels to a single mask
    mask = np.zeros(labels[0][1].shape, dtype=np.int64)
    if prefill_value != 0:
        mask.fill(prefill_value)
    for class_name, annotation_mask in labels:
        mask[annotation_mask > 0] = class_names.index(class_name)

    # Visualize the mask using
    # Image.fromarray(mask * 50).save("mask.png")
    return mask, class_names
