from __future__ import annotations

import colorsys
import json
import math
from enum import Enum
from typing import Type

import cv2
import numpy as np
import shapely
import torch
from rasterio import features
from shapely.affinity import scale
from shapely.geometry import Polygon, shape


def get_colors(num_colors):
    """ """
    colors = []
    for i in np.arange(0.0, 360.0, 360.0 / num_colors):
        hue = i / 360.0
        lightness = (50 + np.random.rand() * 10) / 100.0
        saturation = (90 + np.random.rand() * 10) / 100.0
        colors.append(colorsys.hls_to_rgb(hue, lightness, saturation))
    return colors


class AnnotationType(Enum):
    # Perfect for a detection task
    DetectionBox = "DetectionBox"
    # Perfect for a semantic segmentation task with close boundaries
    Contour = "Contour"
    # Single object with multiple regions
    MultiContour = "MultiContour"


class GeoAnno:
    """
    Wraps one QuPath-style geojson annotation such as

    ```
    {
        "type": "Feature",
        "geometry": {
            "type": "Polygon",
            "coordinates": [
                [
                    [
                        7624,
                        9051
                    ],
                    [
                        7624,
                        9227
                    ],
                    [
                        7845,
                        9227
                    ],
                    [
                        7845,
                        9051
                    ],
                    [
                        7624,
                        9051
                    ]
                ]
            ]
        },
        "properties": {
            "object_type": "annotation",
            "classification": {
                "name": "Dust_8.1.1",
                "colorRGB": -4987213
            }
        }
    }
    ```
    """

    @classmethod
    def from_shapely(
        cls,
        shape: shapely.Geometry,
        class_info: tuple[str, int, int] | None = None,
        **kwargs,
    ) -> GeoAnno:
        """
        class_info is given as (class_name, max_classes, class_index)
        """
        json_dict = {
            "type": "Feature",
            "geometry": shapely.geometry.mapping(shape),
            "properties": {
                "object_type": "annotation",
            },
        }
        if class_info:
            class_color = get_colors(class_info[1])[class_info[2]]  # between 0 and 1
            json_dict["properties"]["classification"] = {
                "name": class_info[0],
                "color": [int(x * 255) for x in class_color],
            }

        json_dict["properties"].update(kwargs)
        return cls(json_dict)

    @classmethod
    def rectangle_builder(
        cls: Type[GeoAnno],
        left_upper: tuple[int, int],
        right_lower: tuple[int, int],
        class_name="defaultclass",
    ) -> GeoAnno:
        return cls(
            {
                "type": "Feature",
                "geometry": {
                    "type": "Polygon",
                    "coordinates": [
                        [
                            [left_upper[0], left_upper[1]],
                            [right_lower[0], left_upper[1]],
                            [right_lower[0], right_lower[1]],
                            [left_upper[0], right_lower[1]],
                            [left_upper[0], left_upper[1]],
                        ]
                    ],
                },
                "properties": {
                    "object_type": "annotation",
                    "classification": {"name": class_name, "color": [200, 0, 0]},
                },
            }
        )

    def __init__(self, json_dict: dict, origin_id: str | None = None) -> None:
        self.wsi_id: str | None = origin_id
        self.shape = shape(json_dict["geometry"])

        self.properties: dict = json_dict["properties"] if "properties" in json_dict else {}

        # QuPath needs a color
        try:
            self.color: list[int] = self.properties["classification"]["color"]
            assert len(self.color) == 3
        except KeyError:
            self.color = [200, 0, 0]

        if self.shape.geom_type == "LineString":
            # Convert to Polygon, because a LineString has no area and we depend on that
            self.shape = self.shape.buffer(np.sqrt(self.shape.length))

    def set_class_name(self, class_name: str):
        if "classification" not in self.properties:
            self.properties["classification"] = {
                "name": class_name.lower(),
                "color": self.color,
            }
        else:
            self.properties["classification"]["name"] = class_name.lower()

    def get_class_name(self) -> str | None:
        try:
            return self.properties["classification"]["name"].lower()
        except KeyError:
            return None

    def get_enclosing_region(self) -> tuple[tuple[int, int], tuple[int, int]]:
        bounds: tuple[int, int, int, int] = self.shape.bounds  # type: ignore
        return (int(bounds[0]), int(bounds[1])), (
            int(bounds[2] - bounds[0]),
            int(bounds[3] - bounds[1]),
        )

    def overlaps_with(self, other_shape: Polygon, overlap_threshold: float = 0.0) -> bool:
        if self.shape.intersects(other_shape):
            intersection_shape = self.shape.intersection(other_shape)
            return intersection_shape.area > (self.shape.area * overlap_threshold)
        return False

    def get_annotation_type(self) -> AnnotationType:
        """
        If the annotation looks like a perfect box, it returns AnnotationType.DetectionBox.
        Otherwise: AnnotationType.Contour or AnnotationType.MultiContour
        """
        if math.isclose(self.shape.area, self.shape.minimum_rotated_rectangle.area):
            return AnnotationType.DetectionBox
        elif self.shape.geom_type == "Polygon":
            return AnnotationType.Contour
        elif self.shape.geom_type == "MultiPolygon":
            return AnnotationType.MultiContour
        else:
            raise NotImplementedError(f"Not implemented for: {self.shape.geom_type}")

    def visualize_as_pyplot(self):
        import matplotlib.pyplot as plt

        fig, ax = plt.subplots()
        if c := self.get_class_name():
            ax.set_title(f"Class {c}")
        ax.plot(*self.shape.exterior.xy)
        return fig

    def to_geojson(self) -> dict:
        res = {
            "type": "Feature",
            "geometry": shapely.geometry.mapping(self.shape),
        }
        if self.properties:
            res["properties"] = self.properties
        return res

    def __repr__(self) -> str:
        return f"GeoAnno:\n{self.shape.geom_type=};{self.shape.area=}\n{json.dumps(self.properties, indent=2)}"


def shapes_from_binary_mask(mask: np.ndarray, downsample_fac: float, coarse: bool, min_area: float = 0.0):
    """
    Returns a list of shapely shapes from a binary mask by using connected components.

    min_area always refers to the area in level 0 (computed by your downsample_fac).
    """
    if coarse:
        fine_areas = cv2.connectedComponentsWithStats(mask, 4, cv2.CV_32S)[2][:, cv2.CC_STAT_AREA]
        mask = features.sieve(mask, size=max(1, fine_areas.mean()))
    dicts = list(features.shapes(mask))
    shapes = [(shape(x[0]), x[1]) for x in dicts]
    shapes = [
        x for x, val in shapes if x.bounds[2] - x.bounds[0] > 1.0 and x.bounds[3] - x.bounds[1] > 1.0 and val > 0.0
    ]
    if min_area:
        shapes = filter(lambda x: (x.area * (downsample_fac**2)) > min_area, shapes)
    return [scale(x, xfact=downsample_fac, yfact=downsample_fac, origin=(0, 0)) for x in shapes]  # type:ignore


def annotations_from_mask(
    mask: np.ndarray,
    for_values: dict[int, str],
    downsample_fac: float,
    coarse: bool = False,
    min_area: float = 0.0,
) -> list[GeoAnno]:
    """
    min_area refers to the area in level 0 (computed by your downsample_fac).
    """
    assert len(mask.shape) == 2, "Mask should be 2D"
    res: list[GeoAnno] = []
    for val, class_name in for_values.items():
        shapes_for_val = shapes_from_binary_mask(
            (mask == val).astype(np.uint8), downsample_fac, coarse, min_area=min_area
        )
        annos_for_val = [
            GeoAnno.from_shapely(shape, class_info=(class_name, max(for_values.keys()) + 1, val))
            for shape in shapes_for_val
        ]
        res.extend(annos_for_val)
    return res


def create_featurecollection(annos: list[GeoAnno]) -> dict:
    res = {
        "type": "FeatureCollection",
        "features": [anno.to_geojson() for anno in annos],
    }
    return res


def create_explainability_geojson(contexts: list, level_downsample: dict[int, float]):
    from seaborn import color_palette

    def get_rgb_value(palette_name, point):
        palette = color_palette(palette_name, 100)
        index = int(point * 99)  # Scale point to the range of the palette
        r, g, b = palette[index]
        return (int(r * 255), int(g * 255), int(b * 255))

    scaled_attention_weights = torch.nn.functional.softmax(torch.tensor([x[1] for x in contexts]), dim=0)

    features = []
    for i, ((level, l0_pos, patchsize), raw_attn_weight) in enumerate(contexts):
        y1, x1 = l0_pos
        ph, pw = patchsize
        scale_factor = level_downsample[level]
        x2 = x1 + (pw * scale_factor)
        y2 = y1 + (ph * scale_factor)
        polygon = Polygon([(x1, y1), (x2, y1), (x2, y2), (x1, y2), (x1, y1)])
        red, green, blue = get_rgb_value("magma", scaled_attention_weights[i])
        features.append(
            GeoAnno.from_shapely(
                polygon,
                color=[red, green, blue],
                fillColor=[red, green, blue],
                color_rgb=[red, green, blue],
                value=scaled_attention_weights[i].item(),
                level=level,
                metadata={"ANNOTATION_DESCRIPTION": f"Value: {raw_attn_weight}"},
            )
        )

    return create_featurecollection(features)
