from __future__ import annotations

import logging
import os
import urllib
from pathlib import Path
from typing import Literal, Type

import fsspec
import torch.multiprocessing as mp
from fsspec.core import OpenFile
from pydantic import BaseModel, Field, model_validator
from torch.utils.data import get_worker_info
from upath import UPath

# Gets the worker info for the parent process
worker_info = get_worker_info()
mp_method = mp.get_start_method()


class DistributedPath(BaseModel):
    """
    Wraps fsspec with a pydantic model that can also be created from a string:
    >>> dp = DistributedPath.model_validate("file.txt"); dp.get_protocol()
    'file'

    >>> dp = DistributedPath(uri="s3://project-histo/gigi/ccc369b1011a0bf8ab0d11b2ac495bc8.tiff")
    >>> dp.exists()  # try e.g. TiffSlide(dp.file()).get_thumbnail(size=(256, 256))
    True

    Paths for S3 are filled with defaults if available in environment
    >>> 'client_kwargs' in dp.options
    True

    Can be used with paths like "s3://bucketname/file", "/path/to/file" and other fsspec URIs.
    If no options are provided, it will default to Minio settings: S3URL, AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY.

    Use `upath` for a pathlib like interface provided by `universal_pathlib` package:

    >>> assert len(list(dp.upath().parent.glob("*"))) > 0

    """

    uri: str = Field(..., description="FSSpec URI to the file")
    # Without options it is modeled as None to enable clean model export with model_dump(exclude_none=True)
    options: dict | None = Field(default=None, description="Options to pass to fsspec")

    @classmethod
    def from_string(cls: Type[DistributedPath], uri: str):
        return cls(uri=uri)

    @model_validator(mode="before")
    @classmethod
    def pre_validator(cls, data):
        if isinstance(data, str):
            data = DistributedPath.from_string(data).model_dump()

        elif isinstance(data, UPath):
            data = DistributedPath(uri=data.as_uri(), options=data.storage_options).model_dump()

        return data

    @model_validator(mode="after")
    def ensure_protocol(self):
        # Convert local paths to file:// URIs
        if self.uri.startswith("/"):
            # Path(self.uri).as_uri() rewrites special characters to be incompatible with upath
            self.uri = "file://" + self.uri
        return self

    @model_validator(mode="after")
    def fill_s3_defaults(self):
        if self.uri.startswith("s3://") and not self.options:
            try:
                from mmm.settings import mtl_settings

                self.options = {
                    "client_kwargs": {"endpoint_url": mtl_settings.s3_url},
                    "key": mtl_settings.s3_access_key,
                    "secret": mtl_settings.s3_secret_key,
                }
            except ImportError:
                self.options = {
                    "client_kwargs": {"endpoint_url": os.getenv("S3URL", "http://localhost:9000")},
                    "key": os.getenv("AWS_ACCESS_KEY_ID", "minioadmin"),
                    "secret": os.getenv("AWS_SECRET_ACCESS_KEY", "minioadmin"),
                }

        return self

    def get_filestem_suggestion(self) -> str:
        return (self.options or {}).get("file_stem", self.upath().stem)

    def fix_multiprocessing_with_fork(self):
        global worker_info
        if mp_method == "fork" and (new_worker_info := get_worker_info()) is not None:
            # If the worker changed, some stuff will deadlock if not erased now:
            if worker_info is None:
                logging.debug(f"MP {mp_method=}, erasing parent fsspec thread")
                fsspec.asyn.iothread[0] = None
                fsspec.asyn.loop[0] = None
                worker_info = new_worker_info

    @property
    def parent(self) -> DistributedPath:
        parent_upath = self.upath().parent
        return DistributedPath(uri=parent_upath.as_uri(), options=parent_upath.storage_options)

    def read_text(self, *args, **kwargs) -> str:
        return self.upath().read_text(*args, **kwargs)

    def file(self, *args, **kwargs) -> OpenFile:
        self.fix_multiprocessing_with_fork()
        return fsspec.open(self.uri, *args, **kwargs, **(self.options or {}))

    def upath(self, *args, **kwargs) -> UPath:
        self.fix_multiprocessing_with_fork()
        # upath has a problem with file:// URIs unless the scheme is removed
        uri = self.uri
        if uri.startswith("file://"):
            uri = uri[len("file://") :]
        return UPath(uri, *args, **kwargs, **(self.options or {}))

    def fs(self):
        self.fix_multiprocessing_with_fork()
        return fsspec.filesystem(self.get_protocol(self.uri), **(self.options or {}))

    def get_protocol(self, path=None):
        # Parse the path using urllib.parse
        parsed_path = urllib.parse.urlparse(self.uri if path is None else path)

        # Extract the scheme (protocol) from the parsed path
        return parsed_path.scheme if parsed_path.scheme else "file"

    def to_local_path(self, download_path: Path | Literal["tmp"] | None = None) -> Path:
        """
        If the protocol is already "file", will return a pathlib.Path object directly.
        Otherwise, will download the file to `download_path`.
        """
        if self.get_protocol() == "file":
            return Path(urllib.parse.urlparse(self.uri).path)
        else:
            assert download_path is not None, "Must provide download_path or set to 'tmp' for remote files"
            if download_path == "tmp":
                import tempfile

                download_path = Path(tempfile.mkstemp()[1])
            download_path.write_bytes(self.upath().read_bytes())
            return download_path

    def exists(self) -> bool:
        return self.fs().exists(self.uri)

    def joinpath(self, *others) -> DistributedPath:
        new_uri = self.uri
        for other in others:
            if isinstance(other, DistributedPath):
                new_uri = os.path.join(new_uri, other.uri)
            else:
                new_uri = os.path.join(new_uri, other)
        return DistributedPath(uri=new_uri, options=self.options)

    def __truediv__(self, other):
        return self.joinpath(other)
