from __future__ import annotations
from collections.abc import Callable
from typing import Any
from ..fable_library.int32 import parse
from ..fable_library.option import some
from ..fable_library.reg_exp import (match, create, get_item, groups)
from ..fable_library.string_ import (trim_start, starts_with_exact, substring)
from .preprocessing import is_document_end
from .regex import (KeyPattern, ValuePattern, LineCommentPattern, FlowStyleArrayPattern, SequenceOpenerPattern, SequenceCloserPattern, FlowStyleObjectPattern, FlowStyleObjectOpenerPattern, FlowStyleObjectCloserPattern, AnchorPattern, AliasPattern, VerbatimTagPattern)
from .yamlicious_types import PreprocessorElement

def trim_for_pattern(s: str) -> str:
    return trim_start(s)


def leading_indent(s: str) -> int:
    return len(s) - len(trim_start(s))


def _007CKey_007C__007C(input: PreprocessorElement) -> dict[str, Any] | None:
    if input.tag == 2:
        line: str = trim_for_pattern(input.fields[0])
        m: Any = match(create(KeyPattern), line)
        if m is not None:
            def _arrow595(__unit: None=None, input: Any=input) -> int | None:
                v: str = get_item(groups(m), "comment") or ""
                return None if (v == "") else parse(v, 511, False, 32)

            return {
                "Comment": _arrow595(),
                "Key": get_item(groups(m), "key") or ""
            }

        else: 
            return None


    else: 
        return None



def _007CKeyValue_007C__007C(input: PreprocessorElement) -> dict[str, Any] | None:
    if input.tag == 2:
        s: str = input.fields[0]
        line: str = trim_for_pattern(s)
        m: Any = match(create("^(?P<key>[^\\{{\\[]+):\\s+(?P<value>.*)$"), line)
        if m is not None:
            v: str = get_item(groups(m), "value") or "".strip()
            def _arrow596(__unit: None=None, input: Any=input) -> dict[str, Any]:
                Key: str = get_item(groups(m), "key") or ""
                return {
                    "Indent": leading_indent(s),
                    "Key": Key,
                    "Value": v
                }

            return _arrow596()

        else: 
            return None


    else: 
        return None



def _007CYamlValue_007C__007C(input: PreprocessorElement) -> dict[str, Any] | None:
    if input.tag == 2:
        s: str = input.fields[0]
        line: str = trim_for_pattern(s)
        m: Any = match(create(ValuePattern), line)
        if m is not None:
            comment: int | None
            v: str = get_item(groups(m), "comment") or ""
            comment = None if (v == "") else parse(v, 511, False, 32)
            v_1: str = get_item(groups(m), "value") or "".strip()
            return {
                "Comment": comment,
                "Indent": leading_indent(s),
                "Value": v_1
            }

        else: 
            return None


    else: 
        return None



def _007CYamlComment_007C__007C(input: PreprocessorElement) -> dict[str, Any] | None:
    if input.tag == 2:
        line: str = trim_for_pattern(input.fields[0])
        m: Any = match(create(LineCommentPattern), line)
        if m is not None:
            return {
                "Comment": parse(get_item(groups(m), "comment") or "", 511, False, 32)
            }

        else: 
            return None


    else: 
        return None



def _007CSequenceMinusOpener_007C__007C(input: PreprocessorElement) -> dict[str, Any] | None:
    if input.tag == 2:
        s: str = input.fields[0]
        line: str = trim_for_pattern(s)
        m: Any = match(create("^-(\\s+(?P<value>.*))?$"), line)
        if m is not None:
            v_1: str | None
            v: str = get_item(groups(m), "value") or "".strip()
            v_1 = None if (v == "") else v
            return {
                "Indent": leading_indent(s),
                "Value": v_1
            }

        else: 
            return None


    else: 
        return None



def _007CFlowStyleArray_007C__007C(input: PreprocessorElement) -> dict[str, Any] | None:
    if input.tag == 2:
        line: str = trim_for_pattern(input.fields[0])
        m: Any = match(create(FlowStyleArrayPattern), line)
        if m is not None:
            def _arrow597(__unit: None=None, input: Any=input) -> int | None:
                v: str = get_item(groups(m), "comment") or ""
                return None if (v == "") else parse(v, 511, False, 32)

            return {
                "Comment": _arrow597(),
                "Value": get_item(groups(m), "inlineSequence") or ""
            }

        else: 
            return None


    else: 
        return None



_007CInlineSequence_007C__007C: Callable[[PreprocessorElement], dict[str, Any] | None] = _007CFlowStyleArray_007C__007C

def _007CSequenceSquareOpener_007C__007C(input: PreprocessorElement) -> dict[str, Any] | None:
    if input.tag == 2:
        line: str = trim_for_pattern(input.fields[0])
        m: Any = match(create(SequenceOpenerPattern), line)
        if m is not None:
            def _arrow598(__unit: None=None, input: Any=input) -> int | None:
                v: str = get_item(groups(m), "comment") or ""
                return None if (v == "") else parse(v, 511, False, 32)

            return {
                "Comment": _arrow598()
            }

        else: 
            return None


    else: 
        return None



def _007CSequenceSquareCloser_007C__007C(input: PreprocessorElement) -> dict[str, Any] | None:
    if input.tag == 2:
        line: str = trim_for_pattern(input.fields[0])
        m: Any = match(create(SequenceCloserPattern), line)
        if m is not None:
            def _arrow599(__unit: None=None, input: Any=input) -> int | None:
                v: str = get_item(groups(m), "comment") or ""
                return None if (v == "") else parse(v, 511, False, 32)

            return {
                "Comment": _arrow599()
            }

        else: 
            return None


    else: 
        return None



def _007CFlowStyleObject_007C__007C(input: PreprocessorElement) -> dict[str, Any] | None:
    if input.tag == 2:
        line: str = trim_for_pattern(input.fields[0])
        m: Any = match(create(FlowStyleObjectPattern), line)
        if m is not None:
            def _arrow600(__unit: None=None, input: Any=input) -> int | None:
                v: str = get_item(groups(m), "comment") or ""
                return None if (v == "") else parse(v, 511, False, 32)

            return {
                "Comment": _arrow600(),
                "Value": get_item(groups(m), "inlineSequence") or ""
            }

        else: 
            return None


    else: 
        return None



_007CInlineJSON_007C__007C: Callable[[PreprocessorElement], dict[str, Any] | None] = _007CFlowStyleObject_007C__007C

def _007CFlowStyleObjectOpener_007C__007C(input: PreprocessorElement) -> dict[str, Any] | None:
    if input.tag == 2:
        line: str = trim_for_pattern(input.fields[0])
        m: Any = match(create(FlowStyleObjectOpenerPattern), line)
        if m is not None:
            def _arrow601(__unit: None=None, input: Any=input) -> int | None:
                v: str = get_item(groups(m), "comment") or ""
                return None if (v == "") else parse(v, 511, False, 32)

            return {
                "Comment": _arrow601(),
                "Key": get_item(groups(m), "key") or ""
            }

        else: 
            return None


    else: 
        return None



_007CJSONKeyOpener_007C__007C: Callable[[PreprocessorElement], dict[str, Any] | None] = _007CFlowStyleObjectOpener_007C__007C

def _007CFlowStyleObjectCloser_007C__007C(input: PreprocessorElement) -> dict[str, Any] | None:
    if input.tag == 2:
        line: str = trim_for_pattern(input.fields[0])
        m: Any = match(create(FlowStyleObjectCloserPattern), line)
        if m is not None:
            def _arrow602(__unit: None=None, input: Any=input) -> int | None:
                v: str = get_item(groups(m), "comment") or ""
                return None if (v == "") else parse(v, 511, False, 32)

            return {
                "Comment": _arrow602()
            }

        else: 
            return None


    else: 
        return None



_007CJSONCloser_007C__007C: Callable[[PreprocessorElement], dict[str, Any] | None] = _007CFlowStyleObjectCloser_007C__007C

def _007CSchemaNamespace_007C__007C(input: PreprocessorElement) -> dict[str, Any] | None:
    if input.tag == 2:
        line: str = trim_for_pattern(input.fields[0])
        m: Any = match(create("^\\$(?P<key>[a-zA-Z0-9\\s:]+):$"), line)
        if m is not None:
            return {
                "Key": get_item(groups(m), "key") or ""
            }

        else: 
            return None


    else: 
        return None



def _007CDocumentEnd_007C__007C(input: PreprocessorElement) -> None | None:
    (pattern_matching_result,) = (None,)
    if input.tag == 2:
        if is_document_end(input.fields[0]):
            pattern_matching_result = 0

        else: 
            pattern_matching_result = 1


    else: 
        pattern_matching_result = 1

    if pattern_matching_result == 0:
        return some(None)

    elif pattern_matching_result == 1:
        return None



def _007CWithAnchor_007C__007C(input: str) -> str | None:
    m: Any = match(create(AnchorPattern), input)
    if m is not None:
        return get_item(groups(m), "anchor") or ""

    else: 
        return None



def _007CAliasNode_007C__007C(input: PreprocessorElement) -> str | None:
    if input.tag == 2:
        m: Any = match(create(AliasPattern), input.fields[0].strip())
        if m is not None:
            return get_item(groups(m), "alias") or ""

        else: 
            return None


    else: 
        return None



def _007CVerbatimTag_007C__007C(input: str) -> str | None:
    m: Any = match(create(VerbatimTagPattern), input)
    if m is not None:
        return get_item(groups(m), "tag") or ""

    else: 
        return None



def _007CExplicitKey_007C__007C(input: PreprocessorElement) -> (str | None) | None:
    if input.tag == 2:
        line: str = trim_for_pattern(input.fields[0])
        if starts_with_exact(line, "?"):
            value: str = substring(line, 1).strip()
            return some(None if (value == "") else value)

        else: 
            return None


    else: 
        return None



def _007CExplicitValue_007C__007C(input: PreprocessorElement) -> str | None:
    if input.tag == 2:
        line: str = trim_for_pattern(input.fields[0])
        if starts_with_exact(line, ":"):
            return substring(line, 1).strip()

        else: 
            return None


    else: 
        return None



__all__ = ["trim_for_pattern", "leading_indent", "_007CKey_007C__007C", "_007CKeyValue_007C__007C", "_007CYamlValue_007C__007C", "_007CYamlComment_007C__007C", "_007CSequenceMinusOpener_007C__007C", "_007CFlowStyleArray_007C__007C", "_007CInlineSequence_007C__007C", "_007CSequenceSquareOpener_007C__007C", "_007CSequenceSquareCloser_007C__007C", "_007CFlowStyleObject_007C__007C", "_007CInlineJSON_007C__007C", "_007CFlowStyleObjectOpener_007C__007C", "_007CJSONKeyOpener_007C__007C", "_007CFlowStyleObjectCloser_007C__007C", "_007CJSONCloser_007C__007C", "_007CSchemaNamespace_007C__007C", "_007CDocumentEnd_007C__007C", "_007CWithAnchor_007C__007C", "_007CAliasNode_007C__007C", "_007CVerbatimTag_007C__007C", "_007CExplicitKey_007C__007C", "_007CExplicitValue_007C__007C"]

