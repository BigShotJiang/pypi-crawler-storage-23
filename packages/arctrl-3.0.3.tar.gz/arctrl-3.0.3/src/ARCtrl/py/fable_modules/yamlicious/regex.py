
AnchorPattern: str = "&(?P<anchor>[^\\s\\[\\]{},:]+)"

AliasPattern: str = "^\\*(?P<alias>[^\\s\\[\\]{},:]+)$"

VerbatimTagPattern: str = "^!<(?P<tag>[^>]+)>"

KeyPattern: str = ("^(?P<key>[^\\{\\[]+):\\s*(" + "\\<c f=(?P<comment>\\d+)\\/\\>") + ")?$"

ExplicitKeyPattern: str = "^\\?\\s*$"

ExplicitKeyWithValuePattern: str = "^\\?\\s+(.+)$"

ExplicitValuePattern: str = "^:\\s*(.*)$"

LineCommentPattern: str = ("^" + "\\<c f=(?P<comment>\\d+)\\/\\>") + "$"

ValuePattern: str = ("^(?P<value>.*?)\\s*?(" + "\\<c f=(?P<comment>\\d+)\\/\\>") + ")?$"

FlowStyleArrayPattern: str = ("^\\[(?P<inlineSequence>.+)\\]\\s*?(" + "\\<c f=(?P<comment>\\d+)\\/\\>") + ")?$"

InlineSequencePattern: str = FlowStyleArrayPattern

FlowStyleObjectPattern: str = ("^\\{(?P<inlineSequence>.*)\\}\\s*?(" + "\\<c f=(?P<comment>\\d+)\\/\\>") + ")?$"

InlineJSONPattern: str = FlowStyleObjectPattern

SequenceOpenerPattern: str = ("^\\[\\s*(" + "\\<c f=(?P<comment>\\d+)\\/\\>") + ")?$"

SequenceCloserPattern: str = ("^\\]\\s*(" + "\\<c f=(?P<comment>\\d+)\\/\\>") + ")?$"

FlowStyleObjectOpenerPattern: str = ("^(?P<key>[^\\{\\[]+):\\s+\\{\\s*(" + "\\<c f=(?P<comment>\\d+)\\/\\>") + ")?$"

JSONOpenerPattern: str = FlowStyleObjectOpenerPattern

FlowStyleObjectCloserPattern: str = ("^\\}\\s*(" + "\\<c f=(?P<comment>\\d+)\\/\\>") + ")?$"

JSONCloserPattern: str = FlowStyleObjectCloserPattern

__all__ = ["AnchorPattern", "AliasPattern", "VerbatimTagPattern", "KeyPattern", "ExplicitKeyPattern", "ExplicitKeyWithValuePattern", "ExplicitValuePattern", "LineCommentPattern", "ValuePattern", "FlowStyleArrayPattern", "InlineSequencePattern", "FlowStyleObjectPattern", "InlineJSONPattern", "SequenceOpenerPattern", "SequenceCloserPattern", "FlowStyleObjectOpenerPattern", "JSONOpenerPattern", "FlowStyleObjectCloserPattern", "JSONCloserPattern"]

