from __future__ import annotations
from ..fable_library.reflection import (TypeInfo, class_type)
from ..fable_library.types import Array
from ..fable_library.util import get_enumerator

def _expr567() -> TypeInfo:
    return class_type("YAMLicious.StringBuffer.StringBuffer", None, StringBuffer)


class StringBuffer:
    def __init__(self, __unit: None=None) -> None:
        self.chars: Array[str] = []

    def __str__(self, __unit: None=None) -> str:
        _: StringBuffer = self
        return ''.join(_.chars[:])


StringBuffer_reflection = _expr567

def StringBuffer__ctor(__unit: None=None) -> StringBuffer:
    return StringBuffer(__unit)


def StringBuffer__get_Length(_: StringBuffer) -> int:
    return len(_.chars)


def StringBuffer__get_Item_Z524259A4(_: StringBuffer, i: int) -> str:
    return _.chars[i]


def StringBuffer__Append_244C7CD6(this: StringBuffer, c: str) -> StringBuffer:
    (this.chars.append(c))
    return this


def StringBuffer__Append_Z721C83C5(this: StringBuffer, s: str) -> StringBuffer:
    with get_enumerator(list(s)) as enumerator:
        while enumerator.System_Collections_IEnumerator_MoveNext():
            c: str = enumerator.System_Collections_Generic_IEnumerator_1_get_Current()
            (this.chars.append(c))
    return this


def StringBuffer__AppendLine_Z721C83C5(this: StringBuffer, s: str) -> StringBuffer:
    with get_enumerator(list(s)) as enumerator:
        while enumerator.System_Collections_IEnumerator_MoveNext():
            c: str = enumerator.System_Collections_Generic_IEnumerator_1_get_Current()
            (this.chars.append(c))
    (this.chars.append("\n"))
    return this


def StringBuffer__TrimEndWhitespace(_: StringBuffer) -> None:
    while (True if (_.chars[len(_.chars) - 1] == "\t") else (_.chars[len(_.chars) - 1] == " ")) if (len(_.chars) > 0) else False:
        _.chars.pop(len(_.chars) - 1)


__all__ = ["StringBuffer_reflection", "StringBuffer__get_Length", "StringBuffer__get_Item_Z524259A4", "StringBuffer__Append_244C7CD6", "StringBuffer__Append_Z721C83C5", "StringBuffer__AppendLine_Z721C83C5", "StringBuffer__TrimEndWhitespace"]

