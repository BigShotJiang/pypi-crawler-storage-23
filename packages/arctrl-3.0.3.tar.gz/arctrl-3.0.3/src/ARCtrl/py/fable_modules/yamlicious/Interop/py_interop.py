
def is_string(s: str) -> bool:
    return isinstance(s, str)


def from_code_point(code_point: int) -> str:
    return chr(code_point)


__all__ = ["is_string", "from_code_point"]

