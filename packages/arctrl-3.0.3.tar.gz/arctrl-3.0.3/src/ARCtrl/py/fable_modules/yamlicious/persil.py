from __future__ import annotations
from collections.abc import Callable
from typing import Any
from ..fable_library.array_ import (try_head, try_find, take_while as take_while_1, take, append)
from ..fable_library.char import is_white_space
from ..fable_library.int32 import parse
from ..fable_library.list import (of_array, FSharpList, is_empty, head, tail, to_array, reverse)
from ..fable_library.map import (add, empty as empty_1)
from ..fable_library.map_util import add_to_dict
from ..fable_library.option import (default_arg, map)
from ..fable_library.reg_exp import (replace as replace_1, get_item, groups, create, match)
from ..fable_library.seq import (max, length as length_1, take_while, to_list)
from ..fable_library.set import (FSharpSet__Contains, of_list, empty)
from ..fable_library.string_ import (trim_start, trim_end, replace, substring, starts_with_exact, to_text, printf, is_null_or_white_space, split)
from ..fable_library.types import (Array, to_string)
from ..fable_library.util import (compare_primitives, ignore, get_enumerator, equals)
from .string_buffer import (StringBuffer__ctor, StringBuffer, StringBuffer__Append_244C7CD6, StringBuffer__get_Length, StringBuffer__get_Item_Z524259A4, StringBuffer__Append_Z721C83C5)
from .yamlicious_types import (StringMapEntry, QuotedStringKind, YAMLDirective)

def next_string_index(dict_1: Any) -> int:
    if len(dict_1) == 0:
        return 0

    else: 
        class ObjectExpr582:
            @property
            def Compare(self) -> Callable[[int, int], int]:
                return compare_primitives

        return max(dict_1.keys(), ObjectExpr582()) + 1



def fold_single_quoted(s: str) -> str:
    lines: Array[str] = s.split("\n")
    sb: StringBuffer = StringBuffer__ctor()
    for i in range(0, (len(lines) - 1) + 1, 1):
        line: str = lines[i]
        if i > 0:
            line = trim_start(line)

        if i < (len(lines) - 1):
            line = trim_end(line)

        if len(line) == 0:
            ignore(StringBuffer__Append_244C7CD6(sb, "\n"))

        else: 
            if (StringBuffer__get_Item_Z524259A4(sb, StringBuffer__get_Length(sb) - 1) != "\n") if (StringBuffer__get_Length(sb) > 0) else False:
                ignore(StringBuffer__Append_Z721C83C5(sb, " "))

            ignore(StringBuffer__Append_Z721C83C5(sb, line))

    return replace(to_string(sb), "\'\'", "\'")


def parse_single_quoted_segment(s: str, start_index: int) -> tuple[bool, str, int]:
    content: StringBuffer = StringBuffer__ctor()
    i: int = (start_index + 1) or 0
    closed: bool = False
    while (not closed) if (i < len(s)) else False:
        ch: str = s[i]
        if ch == "\'":
            if (s[i + 1] == "\'") if ((i + 1) < len(s)) else False:
                ignore(StringBuffer__Append_Z721C83C5(content, "\'\'"))
                i = (i + 2) or 0

            else: 
                closed = True
                i = (i + 1) or 0


        else: 
            ignore(StringBuffer__Append_244C7CD6(content, ch))
            i = (i + 1) or 0

    return (closed, to_string(content), i)


def parse_double_quoted_segment(s: str, start_index: int) -> tuple[bool, str, int]:
    content: StringBuffer = StringBuffer__ctor()
    i: int = (start_index + 1) or 0
    closed: bool = False
    escaped: bool = False
    while (not closed) if (i < len(s)) else False:
        ch: str = s[i]
        if escaped:
            ignore(StringBuffer__Append_244C7CD6(content, ch))
            escaped = False
            i = (i + 1) or 0

        elif ch == "\"":
            closed = True
            i = (i + 1) or 0

        elif ch == "\\":
            ignore(StringBuffer__Append_244C7CD6(content, ch))
            escaped = True
            i = (i + 1) or 0

        else: 
            ignore(StringBuffer__Append_244C7CD6(content, ch))
            i = (i + 1) or 0

    return (closed, to_string(content), i)


def is_token_boundary_start(s: str, quote_index: int) -> bool:
    i: int = (quote_index - 1) or 0
    def _arrow583(__unit: None=None, s: Any=s, quote_index: Any=quote_index) -> bool:
        c: str = s[i]
        return True if (c == " ") else (c == "\t")

    while _arrow583() if (i >= 0) else False:
        i = (i - 1) or 0
    if i < 0:
        return True

    else: 
        match_value: str = s[i]
        (pattern_matching_result,) = (None,)
        if match_value == "\n":
            pattern_matching_result = 0

        elif match_value == "\r":
            pattern_matching_result = 0

        elif match_value == ",":
            pattern_matching_result = 0

        elif match_value == "-":
            pattern_matching_result = 0

        elif match_value == ":":
            pattern_matching_result = 0

        elif match_value == "?":
            pattern_matching_result = 0

        elif match_value == "[":
            pattern_matching_result = 0

        elif match_value == "{":
            pattern_matching_result = 0

        else: 
            pattern_matching_result = 1

        if pattern_matching_result == 0:
            return True

        elif pattern_matching_result == 1:
            start: int = i or 0
            def _arrow584(__unit: None=None, s: Any=s, quote_index: Any=quote_index) -> bool:
                c_1: str = s[start]
                return True if (True if (True if (True if (True if (True if (True if (True if (True if (c_1 == " ") else (c_1 == "\t")) else (c_1 == "\n")) else (c_1 == "\r")) else (c_1 == ":")) else (c_1 == "-")) else (c_1 == ",")) else (c_1 == "[")) else (c_1 == "{")) else (c_1 == "?")

            while (not _arrow584()) if (start >= 0) else False:
                start = (start - 1) or 0
            token: str = substring(s, start + 1, i - start)
            if starts_with_exact(token, "!"):
                return True

            else: 
                return starts_with_exact(token, "&")





def is_token_boundary_end(s: str, next_index: int) -> bool:
    i: int = next_index or 0
    def _arrow585(__unit: None=None, s: Any=s, next_index: Any=next_index) -> bool:
        c: str = s[i]
        return True if (c == " ") else (c == "\t")

    while _arrow585() if (i < len(s)) else False:
        i = (i + 1) or 0
    if i >= len(s):
        return True

    else: 
        match_value: str = s[i]
        (pattern_matching_result,) = (None,)
        if match_value == "\n":
            pattern_matching_result = 0

        elif match_value == "\r":
            pattern_matching_result = 0

        elif match_value == "#":
            pattern_matching_result = 0

        elif match_value == ",":
            pattern_matching_result = 0

        elif match_value == ":":
            pattern_matching_result = 0

        elif match_value == "]":
            pattern_matching_result = 0

        elif match_value == "}":
            pattern_matching_result = 0

        else: 
            pattern_matching_result = 1

        if pattern_matching_result == 0:
            return True

        elif pattern_matching_result == 1:
            return False




def replace_quoted_strings(target: QuotedStringKind, dict_1: Any, protected_block_scalar_lines: Any, s: str) -> str:
    sb: StringBuffer = StringBuffer__ctor()
    i: int = 0
    n: int = next_string_index(dict_1) or 0
    in_comment: bool = False
    length: int = len(s) or 0
    line_index: int = 0
    def append_placeholder(entry: StringMapEntry, target: Any=target, dict_1: Any=dict_1, protected_block_scalar_lines: Any=protected_block_scalar_lines, s: Any=s) -> None:
        nonlocal n
        current_n: int = n or 0
        n = (n + 1) or 0
        add_to_dict(dict_1, current_n, entry)
        ignore(StringBuffer__Append_Z721C83C5(sb, to_text(printf("<s f=%i/>"))(current_n)))

    def append_char(c: str, target: Any=target, dict_1: Any=dict_1, protected_block_scalar_lines: Any=protected_block_scalar_lines, s: Any=s) -> None:
        nonlocal line_index
        ignore(StringBuffer__Append_244C7CD6(sb, c))
        if c == "\n":
            line_index = (line_index + 1) or 0


    def append_text(text: str, target: Any=target, dict_1: Any=dict_1, protected_block_scalar_lines: Any=protected_block_scalar_lines, s: Any=s) -> None:
        with get_enumerator(list(text)) as enumerator:
            while enumerator.System_Collections_IEnumerator_MoveNext():
                append_char(enumerator.System_Collections_Generic_IEnumerator_1_get_Current())

    def advance_line_index(start_index: int, end_index: int, target: Any=target, dict_1: Any=dict_1, protected_block_scalar_lines: Any=protected_block_scalar_lines, s: Any=s) -> None:
        for j in range(start_index, (end_index - 1) + 1, 1):
            nonlocal line_index
            if s[j] == "\n":
                line_index = (line_index + 1) or 0


    while i < length:
        c_2: str = s[i]
        if FSharpSet__Contains(protected_block_scalar_lines, line_index):
            append_char(c_2)
            i = (i + 1) or 0
            if c_2 == "\n":
                in_comment = False


        elif in_comment:
            append_char(c_2)
            i = (i + 1) or 0
            if c_2 == "\n":
                in_comment = False


        elif c_2 == "\"":
            if equals(target, QuotedStringKind(1)):
                if is_token_boundary_start(s, i):
                    pattern_input_2: tuple[bool, str, int] = parse_double_quoted_segment(s, i)
                    next_index_2: int = pattern_input_2[2] or 0
                    if is_token_boundary_end(s, next_index_2) if pattern_input_2[0] else False:
                        append_placeholder(StringMapEntry(pattern_input_2[1], QuotedStringKind(1)))
                        advance_line_index(i, next_index_2)

                    else: 
                        append_text(substring(s, i, next_index_2 - i))

                    i = next_index_2 or 0

                else: 
                    append_char(c_2)
                    i = (i + 1) or 0


            else: 
                next_index_3: int = parse_double_quoted_segment(s, i)[2] or 0
                append_text(substring(s, i, next_index_3 - i))
                i = next_index_3 or 0


        elif c_2 == "#":
            in_comment = True
            append_char(c_2)
            i = (i + 1) or 0

        elif c_2 == "\'":
            if equals(target, QuotedStringKind(0)):
                if is_token_boundary_start(s, i):
                    pattern_input: tuple[bool, str, int] = parse_single_quoted_segment(s, i)
                    next_index: int = pattern_input[2] or 0
                    if is_token_boundary_end(s, next_index) if pattern_input[0] else False:
                        append_placeholder(StringMapEntry(fold_single_quoted(pattern_input[1]), QuotedStringKind(0)))
                        advance_line_index(i, next_index)

                    else: 
                        append_text(substring(s, i, next_index - i))

                    i = next_index or 0

                else: 
                    append_char(c_2)
                    i = (i + 1) or 0


            else: 
                next_index_1: int = parse_single_quoted_segment(s, i)[2] or 0
                append_text(substring(s, i, next_index_1 - i))
                i = next_index_1 or 0


        else: 
            append_char(c_2)
            i = (i + 1) or 0

    return to_string(sb)


def encoding_clean_up(s: str) -> str:
    return replace(s, "\r\n", "\n")


def count_leading_spaces(line: str) -> int:
    def predicate(c: str, line: Any=line) -> bool:
        return c == " "

    return length_1(take_while(predicate, line))


def parse_block_scalar_header_token(token: str) -> bool:
    if is_null_or_white_space(token):
        return False

    else: 
        t: str = token.strip()
        if len(t) == 0:
            return False

        else: 
            first: str = t[0]
            if (first != ">") if (first != "|") else False:
                return False

            else: 
                valid: bool = True
                seen_indent: bool = False
                seen_chomp: bool = False
                idx: int = 1
                while valid if (idx < len(t)) else False:
                    match_value: str = t[idx]
                    (pattern_matching_result,) = (None,)
                    def _arrow586(__unit: None=None, token: Any=token) -> bool:
                        c: str = match_value
                        return (c <= "9") if (c >= "1") else False

                    if _arrow586():
                        pattern_matching_result = 0

                    elif match_value == "+":
                        pattern_matching_result = 1

                    elif match_value == "-":
                        pattern_matching_result = 1

                    else: 
                        pattern_matching_result = 2

                    if pattern_matching_result == 0:
                        if seen_indent:
                            valid = False

                        else: 
                            seen_indent = True


                    elif pattern_matching_result == 1:
                        if seen_chomp:
                            valid = False

                        else: 
                            seen_chomp = True


                    elif pattern_matching_result == 2:
                        valid = False

                    idx = (idx + 1) or 0
                return valid





def try_detect_block_scalar_header_indent(line: str) -> int | None:
    trimmed: str = trim_start(line)
    after_dash: str = trim_start(substring(trimmed, 2)) if starts_with_exact(trimmed, "- ") else trimmed
    def _arrow588(__unit: None=None, line: Any=line) -> str:
        def loop(current_mut: str) -> str:
            while True:
                (current,) = (current_mut,)
                c: str = trim_start(current)
                if starts_with_exact(c, "&"):
                    idx: int = c.find(" ") or 0
                    if idx < 0:
                        return ""

                    else: 
                        current_mut = substring(c, idx + 1)
                        continue


                elif starts_with_exact(c, "!<"):
                    idx_1: int = c.find(">") or 0
                    if idx_1 < 0:
                        return c

                    else: 
                        current_mut = substring(c, idx_1 + 1)
                        continue


                elif (not starts_with_exact(c, ">")) if ((not starts_with_exact(c, "|")) if starts_with_exact(c, "!") else False) else False:
                    idx_2: int = c.find(" ") or 0
                    if idx_2 < 0:
                        return ""

                    else: 
                        current_mut = substring(c, idx_2 + 1)
                        continue


                else: 
                    return c

                break

        def _arrow587(__unit: None=None) -> str:
            idx_3: int = after_dash.find(":") or 0
            return trim_start(substring(after_dash, idx_3 + 1)) if (idx_3 >= 0) else after_dash

        return loop(_arrow587())

    token: str | None = try_head(split(_arrow588(), [" ", "\t"], None, 1))
    (pattern_matching_result,) = (None,)
    if token is not None:
        if parse_block_scalar_header_token(token):
            pattern_matching_result = 0

        else: 
            pattern_matching_result = 1


    else: 
        pattern_matching_result = 1

    if pattern_matching_result == 0:
        return count_leading_spaces(line)

    elif pattern_matching_result == 1:
        return None



def detect_block_scalar_content_lines(yaml_string: str) -> Any:
    lines: Array[str] = split(replace(replace(yaml_string, "\r\n", "\n"), "\r", "\n"), ["\n"], None, 0)
    protected_lines: Array[int] = []
    i: int = 0
    open_block_indent: int | None = None
    while i < len(lines):
        if open_block_indent is None:
            match_value: int | None = try_detect_block_scalar_header_indent(lines[i])
            if match_value is None:
                i = (i + 1) or 0

            else: 
                indent: int = match_value or 0
                open_block_indent = indent
                i = (i + 1) or 0


        else: 
            header_indent: int = open_block_indent or 0
            line: str = lines[i]
            if True if (line.strip() == "") else (count_leading_spaces(line) > header_indent):
                value: None = (protected_lines.append(i))
                ignore(None)
                i = (i + 1) or 0

            else: 
                open_block_indent = None


    class ObjectExpr589:
        @property
        def Compare(self) -> Callable[[int, int], int]:
            return compare_primitives

    return of_list(to_list(protected_lines), ObjectExpr589())


def string_clean_up_with_protected(dict_1: Any, protected_block_scalar_lines: Any, s: str) -> str:
    return replace_quoted_strings(QuotedStringKind(1), dict_1, protected_block_scalar_lines, s)


def single_quoted_string_clean_up_with_protected(dict_1: Any, protected_block_scalar_lines: Any, s: str) -> str:
    return replace_quoted_strings(QuotedStringKind(0), dict_1, protected_block_scalar_lines, s)


def string_clean_up(dict_1: Any, s: str) -> str:
    class ObjectExpr590:
        @property
        def Compare(self) -> Callable[[int, int], int]:
            return compare_primitives

    return string_clean_up_with_protected(dict_1, empty(ObjectExpr590()), s)


def single_quoted_string_clean_up(dict_1: Any, s: str) -> str:
    class ObjectExpr591:
        @property
        def Compare(self) -> Callable[[int, int], int]:
            return compare_primitives

    return single_quoted_string_clean_up_with_protected(dict_1, empty(ObjectExpr591()), s)


def comment_clean_up(dict_1: Any, s: str) -> str:
    n: int = 0
    def matcheval(m: Any, dict_1: Any=dict_1, s: Any=s) -> str:
        nonlocal n
        v: str = get_item(groups(m), "comment") or ""
        current_n: int = n or 0
        n = (n + 1) or 0
        add_to_dict(dict_1, current_n, v)
        return to_text(printf("<c f=%i/>"))(current_n)

    return replace_1(create("#(?P<comment>.*)"), s, matcheval)


def cut(yaml_string: str) -> Array[str]:
    lines: FSharpList[str] = of_array(split(yaml_string, ["\n"], None, 0))
    without_leading: FSharpList[str] = (tail(lines) if (head(lines) == "") else lines) if (not is_empty(lines)) else lines
    def _arrow592(__unit: None=None, yaml_string: Any=yaml_string) -> FSharpList[str]:
        match_value: FSharpList[str] = reverse(without_leading)
        (pattern_matching_result, rest_1) = (None, None)
        if not is_empty(match_value):
            if head(match_value) == "":
                pattern_matching_result = 0
                rest_1 = tail(match_value)

            else: 
                pattern_matching_result = 1


        else: 
            pattern_matching_result = 1

        if pattern_matching_result == 0:
            return reverse(rest_1)

        elif pattern_matching_result == 1:
            return without_leading


    return to_array(_arrow592())


def parse_yamldirective(line: str) -> YAMLDirective | None:
    m: Any = match(create("^%YAML\\s+(\\d+)\\.(\\d+)"), line.strip())
    if m is not None:
        return YAMLDirective(parse(get_item(groups(m), 1) or "", 511, False, 32), parse(get_item(groups(m), 2) or "", 511, False, 32))

    else: 
        return None



def parse_tag_directive(line: str) -> tuple[str, str] | None:
    m: Any = match(create("^%TAG\\s+(\\S+)\\s+(\\S+)"), line.strip())
    if m is not None:
        return (get_item(groups(m), 1) or "", get_item(groups(m), 2) or "")

    else: 
        return None



def is_document_marker(marker: str, line: str) -> bool:
    trimmed: str = trim_start(line)
    if not starts_with_exact(trimmed, marker):
        return False

    elif len(trimmed) == len(marker):
        return True

    else: 
        return is_white_space(trimmed[len(marker)])



def try_inline_content_after_start_marker(line: str) -> str | None:
    trimmed: str = trim_start(line)
    if not starts_with_exact(trimmed, "---"):
        return None

    else: 
        rest: str = trim_start(substring(trimmed, 3))
        if True if is_null_or_white_space(rest) else starts_with_exact(rest, "#"):
            return None

        else: 
            return rest




def pipeline(yaml_string: str) -> dict[str, Any]:
    string_map: Any = dict([])
    comment_map: Any = dict([])
    normalized_content: str = encoding_clean_up(yaml_string)
    protected_block_scalar_lines: Any = detect_block_scalar_content_lines(normalized_content)
    lines: Array[str] = cut(comment_clean_up(comment_map, string_clean_up_with_protected(string_map, protected_block_scalar_lines, single_quoted_string_clean_up_with_protected(string_map, protected_block_scalar_lines, normalized_content))))
    def mapping(line: str, yaml_string: Any=yaml_string) -> bool:
        return starts_with_exact(trim_start(line), "%")

    def predicate(l: str, yaml_string: Any=yaml_string) -> bool:
        t: str = l.strip()
        if t != "":
            return not starts_with_exact(t, "#")

        else: 
            return False


    def predicate_1(l_1: str, yaml_string: Any=yaml_string) -> bool:
        t_1: str = trim_start(l_1)
        if True if starts_with_exact(t_1, "%") else starts_with_exact(t_1, "#"):
            return True

        else: 
            return t_1.strip() == ""


    directive_prelude_length: int = (len(take_while_1(predicate_1, lines, None)) if default_arg(map(mapping, try_find(predicate, lines)), False) else 0) or 0
    directive_lines: Array[str] = take(directive_prelude_length, lines, None)
    content_lines: Array[str] = lines[directive_prelude_length:len(lines)]
    yaml_version: YAMLDirective | None = None
    class ObjectExpr593:
        @property
        def Compare(self) -> Callable[[str, str], int]:
            return compare_primitives

    tag_handles: Any = add("!!", "tag:yaml.org,2002:", add("!", "!", empty_1(ObjectExpr593())))
    for idx in range(0, (len(directive_lines) - 1) + 1, 1):
        line_1: str = directive_lines[idx]
        match_value: YAMLDirective | None = parse_yamldirective(line_1)
        if match_value is None:
            match_value_1: tuple[str, str] | None = parse_tag_directive(line_1)
            if match_value_1 is None:
                pass

            else: 
                t_2: str = match_value_1[1]
                h: str = match_value_1[0]
                tag_handles = add(h, t_2, tag_handles)


        else: 
            v: YAMLDirective = match_value
            if yaml_version is not None:
                raise Exception("Duplicate YAML directive")

            yaml_version = v

    def _arrow594(__unit: None=None, yaml_string: Any=yaml_string) -> Array[str]:
        match_value_2: str | None = try_inline_content_after_start_marker(content_lines[0])
        return content_lines[1:len(content_lines)] if (match_value_2 is None) else append([match_value_2], content_lines[1:len(content_lines)], None)

    return {
        "CommentMap": comment_map,
        "Lines": _arrow594() if (is_document_marker("---", content_lines[0]) if (len(content_lines) > 0) else False) else content_lines,
        "StringMap": string_map,
        "TagHandles": tag_handles,
        "YAMLVersion": yaml_version
    }


__all__ = ["next_string_index", "fold_single_quoted", "parse_single_quoted_segment", "parse_double_quoted_segment", "is_token_boundary_start", "is_token_boundary_end", "replace_quoted_strings", "encoding_clean_up", "count_leading_spaces", "parse_block_scalar_header_token", "try_detect_block_scalar_header_indent", "detect_block_scalar_content_lines", "string_clean_up_with_protected", "single_quoted_string_clean_up_with_protected", "string_clean_up", "single_quoted_string_clean_up", "comment_clean_up", "cut", "parse_yamldirective", "parse_tag_directive", "is_document_marker", "try_inline_content_after_start_marker", "pipeline"]

