from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any
from ..fable_library.list import map
from ..fable_library.option import default_arg
from ..fable_library.reflection import (TypeInfo, int32_type, record_type, union_type, option_type, string_type, bool_type, class_type, list_type)
from ..fable_library.string_ import initialize
from ..fable_library.types import (Record, Array, Union, to_string)
from ..fable_library.util import (ignore, get_enumerator)
from .string_buffer import (StringBuffer__ctor, StringBuffer, StringBuffer__AppendLine_Z721C83C5)

def _expr568() -> TypeInfo:
    return record_type("YAMLicious.YAMLiciousTypes.Config", [], Config, lambda: [("Whitespace", int32_type), ("Level", int32_type)])


@dataclass(eq = False, repr = False, slots = True)
class Config(Record):
    Whitespace: int
    Level: int

Config_reflection = _expr568

def Config_init_71136F3F(whitespace: int | None=None) -> Config:
    return Config(default_arg(whitespace, 4), 0)


def Config__get_WhitespaceString(this: Config) -> str:
    def _arrow569(_arg: int, this: Any=this) -> str:
        return " "

    return initialize(this.Level * this.Whitespace, _arrow569)


def _expr570() -> TypeInfo:
    return record_type("YAMLicious.YAMLiciousTypes.YAMLDirective", [], YAMLDirective, lambda: [("Major", int32_type), ("Minor", int32_type)])


@dataclass(eq = False, repr = False, slots = True)
class YAMLDirective(Record):
    Major: int
    Minor: int

YAMLDirective_reflection = _expr570

def _expr571() -> TypeInfo:
    return union_type("YAMLicious.YAMLiciousTypes.BlockScalarStyle", [], BlockScalarStyle, lambda: [[], []])


class BlockScalarStyle(Union):
    def __init__(self, tag: int, *fields: Any) -> None:
        super().__init__()
        self.tag: int = tag or 0
        self.fields: Array[Any] = list(fields)

    @staticmethod
    def cases() -> list[str]:
        return ["Literal", "Folded"]


BlockScalarStyle_reflection = _expr571

def _expr572() -> TypeInfo:
    return union_type("YAMLicious.YAMLiciousTypes.ChompingMode", [], ChompingMode, lambda: [[], [], []])


class ChompingMode(Union):
    def __init__(self, tag: int, *fields: Any) -> None:
        super().__init__()
        self.tag: int = tag or 0
        self.fields: Array[Any] = list(fields)

    @staticmethod
    def cases() -> list[str]:
        return ["Strip", "Clip", "Keep"]


ChompingMode_reflection = _expr572

def _expr573() -> TypeInfo:
    return union_type("YAMLicious.YAMLiciousTypes.ScalarStyle", [], ScalarStyle, lambda: [[], [], [], [("Item1", BlockScalarStyle_reflection()), ("Item2", ChompingMode_reflection()), ("Item3", option_type(int32_type))]])


class ScalarStyle(Union):
    def __init__(self, tag: int, *fields: Any) -> None:
        super().__init__()
        self.tag: int = tag or 0
        self.fields: Array[Any] = list(fields)

    @staticmethod
    def cases() -> list[str]:
        return ["Plain", "SingleQuoted", "DoubleQuoted", "Block"]


ScalarStyle_reflection = _expr573

def _expr574() -> TypeInfo:
    return union_type("YAMLicious.YAMLiciousTypes.QuotedStringKind", [], QuotedStringKind, lambda: [[], []])


class QuotedStringKind(Union):
    def __init__(self, tag: int, *fields: Any) -> None:
        super().__init__()
        self.tag: int = tag or 0
        self.fields: Array[Any] = list(fields)

    @staticmethod
    def cases() -> list[str]:
        return ["SingleQuotedString", "DoubleQuotedString"]


QuotedStringKind_reflection = _expr574

def _expr575() -> TypeInfo:
    return record_type("YAMLicious.YAMLiciousTypes.StringMapEntry", [], StringMapEntry, lambda: [("Value", string_type), ("Kind", QuotedStringKind_reflection())])


@dataclass(eq = False, repr = False, slots = True)
class StringMapEntry(Record):
    Value: str
    Kind: QuotedStringKind

StringMapEntry_reflection = _expr575

def _expr576() -> TypeInfo:
    return record_type("YAMLicious.YAMLiciousTypes.WriterOptions", [], WriterOptions, lambda: [("PreserveScalarStyle", bool_type), ("MultilineFallbackStyle", BlockScalarStyle_reflection()), ("MultilineFallbackChomping", ChompingMode_reflection())])


@dataclass(eq = False, repr = False, slots = True)
class WriterOptions(Record):
    PreserveScalarStyle: bool
    MultilineFallbackStyle: BlockScalarStyle
    MultilineFallbackChomping: ChompingMode

WriterOptions_reflection = _expr576

def WriterOptions_get_Default(__unit: None=None) -> WriterOptions:
    return WriterOptions(True, BlockScalarStyle(0), ChompingMode(0))


def _expr577() -> TypeInfo:
    return record_type("YAMLicious.YAMLiciousTypes.Preprocessor", [], Preprocessor, lambda: [("AST", PreprocessorElement_reflection()), ("StringMap", class_type("System.Collections.Generic.Dictionary`2", [int32_type, StringMapEntry_reflection()])), ("CommentMap", class_type("System.Collections.Generic.Dictionary`2", [int32_type, string_type])), ("YAMLVersion", option_type(YAMLDirective_reflection())), ("TagHandles", class_type("Microsoft.FSharp.Collections.FSharpMap`2", [string_type, string_type]))])


@dataclass(eq = False, repr = False, slots = True)
class Preprocessor(Record):
    AST: PreprocessorElement
    StringMap: Any
    CommentMap: Any
    YAMLVersion: YAMLDirective | None
    TagHandles: Any

Preprocessor_reflection = _expr577

def _expr579() -> TypeInfo:
    return union_type("YAMLicious.YAMLiciousTypes.PreprocessorElement", [], PreprocessorElement, lambda: [[("Item", list_type(PreprocessorElement_reflection()))], [("Item", list_type(PreprocessorElement_reflection()))], [("Item", string_type)], []])


class PreprocessorElement(Union):
    def __init__(self, tag: int, *fields: Any) -> None:
        super().__init__()
        self.tag: int = tag or 0
        self.fields: Array[Any] = list(fields)

    @staticmethod
    def cases() -> list[str]:
        return ["Level", "Intendation", "Line", "Nil"]

    def __str__(self, __unit: None=None) -> str:
        this: PreprocessorElement = self
        sb: StringBuffer = StringBuffer__ctor()
        def innerprint(next_1: PreprocessorElement, level: int) -> None:
            def _arrow578(_arg: int, next_1: Any=next_1, level: Any=level) -> str:
                return " "

            indent: str = initialize(level * 2, _arrow578)
            if next_1.tag == 1:
                ignore(StringBuffer__AppendLine_Z721C83C5(sb, indent + "Intendation ["))
                with get_enumerator(next_1.fields[0]) as enumerator:
                    while enumerator.System_Collections_IEnumerator_MoveNext():
                        innerprint(enumerator.System_Collections_Generic_IEnumerator_1_get_Current(), level + 1)
                ignore(StringBuffer__AppendLine_Z721C83C5(sb, indent + "]"))

            elif next_1.tag == 0:
                ignore(StringBuffer__AppendLine_Z721C83C5(sb, indent + "Level ["))
                with get_enumerator(next_1.fields[0]) as enumerator_1:
                    while enumerator_1.System_Collections_IEnumerator_MoveNext():
                        innerprint(enumerator_1.System_Collections_Generic_IEnumerator_1_get_Current(), level + 1)
                ignore(StringBuffer__AppendLine_Z721C83C5(sb, indent + "]"))

            elif next_1.tag == 3:
                pass

            else: 
                ignore(StringBuffer__AppendLine_Z721C83C5(sb, indent + (("Line \"" + next_1.fields[0]) + "\"")))


        innerprint(this, 0)
        return to_string(sb)


PreprocessorElement_reflection = _expr579

def _expr580() -> TypeInfo:
    return record_type("YAMLicious.YAMLiciousTypes.YAMLContent", [], YAMLContent, lambda: [("Value", string_type), ("Comment", option_type(string_type)), ("Anchor", option_type(string_type)), ("Tag", option_type(string_type)), ("Style", option_type(ScalarStyle_reflection()))])


@dataclass(eq = False, repr = False, slots = True)
class YAMLContent(Record):
    Value: str
    Comment: str | None
    Anchor: str | None
    Tag: str | None
    Style: ScalarStyle | None

YAMLContent_reflection = _expr580

def YAMLContent_create_Z1C3A29C9(value: str, comment: str | None=None, anchor: str | None=None, tag: str | None=None, style: ScalarStyle | None=None) -> YAMLContent:
    return YAMLContent(value, comment, anchor, tag, style)


def _expr581() -> TypeInfo:
    return union_type("YAMLicious.YAMLiciousTypes.YAMLElement", [], YAMLElement, lambda: [[("Item1", YAMLContent_reflection()), ("Item2", YAMLElement_reflection())], [("Item", YAMLContent_reflection())], [("Item", list_type(YAMLElement_reflection()))], [("Item", list_type(YAMLElement_reflection()))], [("Item", string_type)], [], [], [("Item", string_type)], []])


class YAMLElement(Union):
    def __init__(self, tag: int, *fields: Any) -> None:
        super().__init__()
        self.tag: int = tag or 0
        self.fields: Array[Any] = list(fields)

    @staticmethod
    def cases() -> list[str]:
        return ["Mapping", "Value", "Sequence", "Object", "Comment", "DocumentStart", "DocumentEnd", "Alias", "Nil"]


YAMLElement_reflection = _expr581

def YAMLElementNormalization_withoutScalarStyleInContent(content: YAMLContent) -> YAMLContent:
    return YAMLContent(content.Value, content.Comment, content.Anchor, content.Tag, None)


def YAMLElementNormalization_withoutScalarStyle(element: YAMLElement) -> YAMLElement:
    if element.tag == 1:
        return YAMLElement(1, YAMLElementNormalization_withoutScalarStyleInContent(element.fields[0]))

    elif element.tag == 2:
        def mapping(element_1: YAMLElement, element: Any=element) -> YAMLElement:
            return YAMLElementNormalization_withoutScalarStyle(element_1)

        return YAMLElement(2, map(mapping, element.fields[0]))

    elif element.tag == 3:
        def mapping_1(element_2: YAMLElement, element: Any=element) -> YAMLElement:
            return YAMLElementNormalization_withoutScalarStyle(element_2)

        return YAMLElement(3, map(mapping_1, element.fields[0]))

    elif ((((element.tag == 4) or (element.tag == 5)) or (element.tag == 6)) or (element.tag == 7)) or (element.tag == 8):
        return element

    else: 
        return YAMLElement(0, YAMLElementNormalization_withoutScalarStyleInContent(element.fields[0]), YAMLElementNormalization_withoutScalarStyle(element.fields[1]))



__all__ = ["Config_reflection", "Config_init_71136F3F", "Config__get_WhitespaceString", "YAMLDirective_reflection", "BlockScalarStyle_reflection", "ChompingMode_reflection", "ScalarStyle_reflection", "QuotedStringKind_reflection", "StringMapEntry_reflection", "WriterOptions_reflection", "WriterOptions_get_Default", "Preprocessor_reflection", "PreprocessorElement_reflection", "YAMLContent_reflection", "YAMLContent_create_Z1C3A29C9", "YAMLElement_reflection", "YAMLElementNormalization_withoutScalarStyleInContent", "YAMLElementNormalization_withoutScalarStyle"]

