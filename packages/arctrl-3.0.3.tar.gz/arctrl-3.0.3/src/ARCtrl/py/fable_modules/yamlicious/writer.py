from __future__ import annotations
from collections.abc import Callable
from typing import Any
from ..fable_library.list import (FSharpList, map as map_1, of_array, singleton)
from ..fable_library.option import (default_arg, map)
from ..fable_library.seq import (for_all, to_list, delay, map as map_2, collect, singleton as singleton_1)
from ..fable_library.string_ import (starts_with_exact, replace, join, ends_with_exact, substring, trim_end, split)
from ..fable_library.util import (int32_to_string, IEnumerable_1)
from .preprocessing import write as write_1
from .yamlicious_types import (ScalarStyle, YAMLContent, YAMLElement, WriterOptions, BlockScalarStyle, ChompingMode, PreprocessorElement, WriterOptions_get_Default, Config)

def StyleVerifier_isInlineSimpleScalar(v: YAMLContent) -> bool:
    if (v.Comment is None) if (not (v.Value.find("\n") >= 0)) else False:
        match_value: ScalarStyle | None = v.Style
        (pattern_matching_result,) = (None,)
        if match_value is not None:
            if match_value.tag == 1:
                pattern_matching_result = 0

            elif match_value.tag == 2:
                pattern_matching_result = 0

            elif match_value.tag == 3:
                pattern_matching_result = 1

            else: 
                pattern_matching_result = 0


        else: 
            pattern_matching_result = 0

        if pattern_matching_result == 0:
            return True

        elif pattern_matching_result == 1:
            return False


    else: 
        return False



def StyleVerifier_checkInlineSequence(ele: FSharpList[YAMLElement]) -> bool:
    def predicate(x: YAMLElement, ele: Any=ele) -> bool:
        if x.tag == 1:
            return StyleVerifier_isInlineSimpleScalar(x.fields[0])

        else: 
            return False


    return for_all(predicate, ele)


def Formatting_mkComment(comment: str) -> str:
    return "#" + comment


def Formatting_mkKey(key: str) -> str:
    return key + ":"


def Formatting_mkMinusLine(c: str) -> str:
    return "- " + c


def Formatting_mkTag(tag: str | None=None) -> str:
    if tag is not None:
        if tag == "!":
            return "! "

        else: 
            def _arrow626(__unit: None=None, tag: Any=tag) -> bool:
                s: str = tag
                return (not starts_with_exact(s, "!!")) if starts_with_exact(s, "!") else False

            if _arrow626():
                s_1: str = tag
                return s_1 + " "

            else: 
                s_2: str = tag
                return ("!<" + s_2) + "> "



    else: 
        return ""



def Formatting_mkAnchor(anchor: str | None=None) -> str:
    def mapping(s: str, anchor: Any=anchor) -> str:
        return ("&" + s) + " "

    return default_arg(map(mapping, anchor), "")


def Formatting_mkNodePrefix(content: YAMLContent) -> str:
    return Formatting_mkTag(content.Tag) + Formatting_mkAnchor(content.Anchor)


def Formatting_appendOptionalComment(comment: str | None, s: str) -> str:
    def mapping(c: str, comment: Any=comment, s: Any=s) -> str:
        return " " + Formatting_mkComment(c)

    return s + default_arg(map(mapping, comment), "")


def Formatting_appendComment(content: YAMLContent, s: str) -> str:
    return Formatting_appendOptionalComment(content.Comment, s)


def Formatting_escapeSingleQuoted(s: str) -> str:
    return replace(s, "\'", "\'\'")


def Formatting_escapeDoubleQuoted(s: str) -> str:
    return replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(s, "\\", "\\\\"), "\"", "\\\""), "\u0000", "\\0"), "\u0007", "\\a"), "\b", "\\b"), "\t", "\\t"), "\u000b", "\\v"), "\f", "\\f"), "\r", "\\r"), "\u001b", "\\e"), "\u0085", "\\N"), " ", "\\_"), "\u2028", "\\L"), "\u2029", "\\P"), "\n", "\\n")


def Formatting_normalizeNewlines(s: str) -> str:
    return replace(s, "\r\n", "\n")


def Formatting_resolveBlockStyle(options: WriterOptions, content: YAMLContent) -> tuple[BlockScalarStyle, ChompingMode, int | None]:
    match_value_1: ScalarStyle | None = content.Style
    (pattern_matching_result, chomp, indent, style) = (None, None, None, None)
    if options.PreserveScalarStyle:
        if match_value_1 is not None:
            if match_value_1.tag == 3:
                pattern_matching_result = 0
                chomp = match_value_1.fields[1]
                indent = match_value_1.fields[2]
                style = match_value_1.fields[0]

            else: 
                pattern_matching_result = 1


        else: 
            pattern_matching_result = 1


    else: 
        pattern_matching_result = 1

    if pattern_matching_result == 0:
        return (style, chomp, indent)

    elif pattern_matching_result == 1:
        return (options.MultilineFallbackStyle, options.MultilineFallbackChomping, None)



def Formatting_scalarToInlineText(options: WriterOptions, content: YAMLContent) -> str:
    v: str = content.Value
    if options.PreserveScalarStyle:
        match_value: ScalarStyle | None = content.Style
        (pattern_matching_result,) = (None,)
        if match_value is not None:
            if match_value.tag == 1:
                pattern_matching_result = 0

            elif match_value.tag == 2:
                pattern_matching_result = 1

            else: 
                pattern_matching_result = 2


        else: 
            pattern_matching_result = 2

        if pattern_matching_result == 0:
            return ("\'" + Formatting_escapeSingleQuoted(v)) + "\'"

        elif pattern_matching_result == 1:
            return ("\"" + Formatting_escapeDoubleQuoted(v)) + "\""

        elif pattern_matching_result == 2:
            return v


    else: 
        return v



def Formatting_mkKeyContent(options: WriterOptions, content: YAMLContent) -> str:
    return Formatting_mkNodePrefix(content) + Formatting_scalarToInlineText(options, content)


def Formatting_mkMappingKey(options: WriterOptions, key: YAMLContent) -> str:
    return Formatting_mkKey(Formatting_mkKeyContent(options, key))


def Formatting_shouldEmitBlockScalar(options: WriterOptions, content: YAMLContent) -> bool:
    has_multiline: bool = content.Value.find("\n") >= 0
    match_value_1: ScalarStyle | None = content.Style
    (pattern_matching_result,) = (None,)
    if options.PreserveScalarStyle:
        if match_value_1 is not None:
            if match_value_1.tag == 3:
                pattern_matching_result = 0

            else: 
                pattern_matching_result = 1


        else: 
            pattern_matching_result = 1


    else: 
        pattern_matching_result = 1

    if pattern_matching_result == 0:
        return True

    elif pattern_matching_result == 1:
        return has_multiline



def Formatting_mkInlineContent(options: WriterOptions, content: YAMLContent) -> str:
    inline_scalar: str = Formatting_scalarToInlineText(options, content)
    return Formatting_appendComment(content, Formatting_mkNodePrefix(content) + inline_scalar)


def Formatting_mkInlineSequence(options: WriterOptions, seq: FSharpList[YAMLElement]) -> str:
    def mapping(x: YAMLElement, options: Any=options, seq: Any=seq) -> str:
        if x.tag == 1:
            v: YAMLContent = x.fields[0]
            return Formatting_mkNodePrefix(v) + Formatting_scalarToInlineText(options, v)

        else: 
            raise Exception("Invalid sequence element")


    return ("[" + join(", ", map_1(mapping, seq))) + "]"


def Formatting_mkBlockHeader(style: BlockScalarStyle, chomp: ChompingMode, indent: int | None=None) -> str:
    def mapping(value: int, style: Any=style, chomp: Any=chomp, indent: Any=indent) -> str:
        return int32_to_string(value)

    return ((">" if (style.tag == 1) else "|") + default_arg(map(mapping, indent), "")) + ("" if (chomp.tag == 1) else ("+" if (chomp.tag == 2) else "-"))


def Formatting_bodyTextForChomping(chomp: ChompingMode, value: str) -> str:
    normalized: str = Formatting_normalizeNewlines(value)
    if (chomp.tag == 1) or (chomp.tag == 2):
        if ends_with_exact(normalized, "\n"):
            return substring(normalized, 0, len(normalized) - 1)

        else: 
            return normalized


    else: 
        return trim_end(normalized, "\n")



def Formatting_splitPreservingEmpty(s: str) -> FSharpList[str]:
    return of_array(split(s, ["\n"], None, 0))


def Formatting_mkBlockScalarMapping(options: WriterOptions, key: YAMLContent, content: YAMLContent) -> PreprocessorElement:
    pattern_input: tuple[BlockScalarStyle, ChompingMode, int | None] = Formatting_resolveBlockStyle(options, content)
    chomp: ChompingMode = pattern_input[1]
    header: str = Formatting_mkBlockHeader(pattern_input[0], chomp, pattern_input[2])
    lines: FSharpList[str] = Formatting_splitPreservingEmpty(Formatting_bodyTextForChomping(chomp, content.Value))
    def mapping(Item: str, options: Any=options, key: Any=key, content: Any=content) -> PreprocessorElement:
        return PreprocessorElement(2, Item)

    return PreprocessorElement(0, of_array([PreprocessorElement(2, Formatting_appendComment(content, ((Formatting_mkMappingKey(options, key) + " ") + Formatting_mkNodePrefix(content)) + header)), PreprocessorElement(1, map_1(mapping, lines))]))


def Formatting_mkBlockScalarSequenceItem(options: WriterOptions, content: YAMLContent) -> PreprocessorElement:
    pattern_input: tuple[BlockScalarStyle, ChompingMode, int | None] = Formatting_resolveBlockStyle(options, content)
    chomp: ChompingMode = pattern_input[1]
    header: str = Formatting_mkBlockHeader(pattern_input[0], chomp, pattern_input[2])
    lines: FSharpList[str] = Formatting_splitPreservingEmpty(Formatting_bodyTextForChomping(chomp, content.Value))
    def mapping(Item: str, options: Any=options, content: Any=content) -> PreprocessorElement:
        return PreprocessorElement(2, Item)

    return PreprocessorElement(0, of_array([PreprocessorElement(2, Formatting_appendComment(content, ("- " + Formatting_mkNodePrefix(content)) + header)), PreprocessorElement(1, map_1(mapping, lines))]))


def Formatting_mkBlockScalarRoot(options: WriterOptions, content: YAMLContent) -> PreprocessorElement:
    pattern_input: tuple[BlockScalarStyle, ChompingMode, int | None] = Formatting_resolveBlockStyle(options, content)
    chomp: ChompingMode = pattern_input[1]
    header: str = Formatting_mkBlockHeader(pattern_input[0], chomp, pattern_input[2])
    lines: FSharpList[str] = Formatting_splitPreservingEmpty(Formatting_bodyTextForChomping(chomp, content.Value))
    def mapping(Item: str, options: Any=options, content: Any=content) -> PreprocessorElement:
        return PreprocessorElement(2, Item)

    return PreprocessorElement(0, of_array([PreprocessorElement(2, Formatting_appendComment(content, Formatting_mkNodePrefix(content) + header)), PreprocessorElement(1, map_1(mapping, lines))]))


def detokenize_with_options(options: WriterOptions, ele: YAMLElement) -> PreprocessorElement:
    def loop(ele_1: YAMLElement, options: Any=options, ele: Any=ele) -> PreprocessorElement:
        if ele_1.tag == 0:
            (pattern_matching_result, value_2, value_3, seq_1, any_else) = (None, None, None, None, None)
            if ele_1.fields[0].Comment is not None:
                pattern_matching_result = 0

            elif ele_1.fields[1].tag == 1:
                if Formatting_shouldEmitBlockScalar(options, ele_1.fields[1].fields[0]):
                    pattern_matching_result = 1
                    value_2 = ele_1.fields[1].fields[0]

                else: 
                    pattern_matching_result = 2
                    value_3 = ele_1.fields[1].fields[0]


            elif ele_1.fields[1].tag == 2:
                if StyleVerifier_checkInlineSequence(ele_1.fields[1].fields[0]):
                    pattern_matching_result = 3
                    seq_1 = ele_1.fields[1].fields[0]

                else: 
                    pattern_matching_result = 4
                    any_else = ele_1.fields[1]


            else: 
                pattern_matching_result = 4
                any_else = ele_1.fields[1]

            if pattern_matching_result == 0:
                return PreprocessorElement(0, of_array([PreprocessorElement(2, Formatting_appendOptionalComment(ele_1.fields[0].Comment, Formatting_mkMappingKey(options, ele_1.fields[0]))), PreprocessorElement(1, singleton(loop(ele_1.fields[1])))]))

            elif pattern_matching_result == 1:
                return Formatting_mkBlockScalarMapping(options, ele_1.fields[0], value_2)

            elif pattern_matching_result == 2:
                return PreprocessorElement(2, (Formatting_mkMappingKey(options, ele_1.fields[0]) + " ") + Formatting_mkInlineContent(options, value_3))

            elif pattern_matching_result == 3:
                return PreprocessorElement(2, (Formatting_mkMappingKey(options, ele_1.fields[0]) + " ") + Formatting_mkInlineSequence(options, seq_1))

            elif pattern_matching_result == 4:
                return PreprocessorElement(0, of_array([PreprocessorElement(2, Formatting_mkMappingKey(options, ele_1.fields[0])), PreprocessorElement(1, singleton(loop(any_else)))]))


        elif ele_1.tag == 1:
            if Formatting_shouldEmitBlockScalar(options, ele_1.fields[0]):
                return Formatting_mkBlockScalarRoot(options, ele_1.fields[0])

            else: 
                return PreprocessorElement(2, Formatting_mkInlineContent(options, ele_1.fields[0]))


        elif ele_1.tag == 3:
            def _arrow627(__unit: None=None, ele_1: Any=ele_1) -> IEnumerable_1[PreprocessorElement]:
                return map_2(loop, ele_1.fields[0])

            return PreprocessorElement(0, to_list(delay(_arrow627)))

        elif ele_1.tag == 2:
            def _arrow629(__unit: None=None, ele_1: Any=ele_1) -> IEnumerable_1[PreprocessorElement]:
                def _arrow628(element_1: YAMLElement) -> IEnumerable_1[PreprocessorElement]:
                    match_value: YAMLElement = element_1
                    (pattern_matching_result_1, value_7, value_8, nested_1, any_else_1) = (None, None, None, None, None)
                    if match_value.tag == 1:
                        if Formatting_shouldEmitBlockScalar(options, match_value.fields[0]):
                            pattern_matching_result_1 = 0
                            value_7 = match_value.fields[0]

                        else: 
                            pattern_matching_result_1 = 1
                            value_8 = match_value.fields[0]


                    elif match_value.tag == 2:
                        if StyleVerifier_checkInlineSequence(match_value.fields[0]):
                            pattern_matching_result_1 = 2
                            nested_1 = match_value.fields[0]

                        else: 
                            pattern_matching_result_1 = 3
                            any_else_1 = match_value


                    else: 
                        pattern_matching_result_1 = 3
                        any_else_1 = match_value

                    if pattern_matching_result_1 == 0:
                        return singleton_1(Formatting_mkBlockScalarSequenceItem(options, value_7))

                    elif pattern_matching_result_1 == 1:
                        return singleton_1(PreprocessorElement(2, Formatting_mkMinusLine(Formatting_mkInlineContent(options, value_8))))

                    elif pattern_matching_result_1 == 2:
                        return singleton_1(PreprocessorElement(2, Formatting_mkMinusLine(Formatting_mkInlineSequence(options, nested_1))))

                    elif pattern_matching_result_1 == 3:
                        return singleton_1(PreprocessorElement(0, of_array([PreprocessorElement(2, "-"), PreprocessorElement(1, singleton(loop(any_else_1)))])))


                return collect(_arrow628, ele_1.fields[0])

            return PreprocessorElement(0, to_list(delay(_arrow629)))

        elif ele_1.tag == 4:
            return PreprocessorElement(2, Formatting_mkComment(ele_1.fields[0]))

        elif ele_1.tag == 5:
            return PreprocessorElement(2, "---")

        elif ele_1.tag == 6:
            return PreprocessorElement(2, "...")

        elif ele_1.tag == 7:
            return PreprocessorElement(2, "*" + ele_1.fields[0])

        else: 
            return PreprocessorElement(3)


    return loop(ele)


def detokenize(ele: YAMLElement) -> PreprocessorElement:
    return detokenize_with_options(WriterOptions_get_Default(), ele)


def write_with_options(ele: YAMLElement, writer_options: WriterOptions, fconfig: Callable[[Config], Config] | None=None) -> str:
    return write_1(detokenize_with_options(writer_options, ele), fconfig)


def write(ele: YAMLElement, fconfig: Callable[[Config], Config] | None=None) -> str:
    return write_with_options(ele, WriterOptions_get_Default(), fconfig)


__all__ = ["StyleVerifier_isInlineSimpleScalar", "StyleVerifier_checkInlineSequence", "Formatting_mkComment", "Formatting_mkKey", "Formatting_mkMinusLine", "Formatting_mkTag", "Formatting_mkAnchor", "Formatting_mkNodePrefix", "Formatting_appendOptionalComment", "Formatting_appendComment", "Formatting_escapeSingleQuoted", "Formatting_escapeDoubleQuoted", "Formatting_normalizeNewlines", "Formatting_resolveBlockStyle", "Formatting_scalarToInlineText", "Formatting_mkKeyContent", "Formatting_mkMappingKey", "Formatting_shouldEmitBlockScalar", "Formatting_mkInlineContent", "Formatting_mkInlineSequence", "Formatting_mkBlockHeader", "Formatting_bodyTextForChomping", "Formatting_splitPreservingEmpty", "Formatting_mkBlockScalarMapping", "Formatting_mkBlockScalarSequenceItem", "Formatting_mkBlockScalarRoot", "detokenize_with_options", "detokenize", "write_with_options", "write"]

