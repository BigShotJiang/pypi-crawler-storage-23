from __future__ import annotations
from collections.abc import Callable
from typing import Any
from ..fable_library.int32 import parse
from ..fable_library.string_ import (substring, replicate)
from ..fable_library.types import to_string
from ..fable_library.util import ignore
from .Interop.py_interop import from_code_point
from .string_buffer import (StringBuffer__ctor, StringBuffer, StringBuffer__Append_244C7CD6, StringBuffer__Append_Z721C83C5, StringBuffer__TrimEndWhitespace)

def unescape_double_quoted(s: str) -> str:
    sb: StringBuffer = StringBuffer__ctor()
    def consume_escaped_line_breaks(index_mut: int, extra_breaks_mut: int, s: Any=s) -> tuple[int, int]:
        while True:
            (index, extra_breaks) = (index_mut, extra_breaks_mut)
            j: int = (index + 2) or 0
            while (True if (s[j] == " ") else (s[j] == "\t")) if (j < len(s)) else False:
                j = (j + 1) or 0
            if (s[j + 1] == "\n") if ((s[j] == "\\") if ((j + 1) < len(s)) else False) else False:
                index_mut = j
                extra_breaks_mut = extra_breaks + 1
                continue

            else: 
                return (extra_breaks, j)

            break

    def loop(i_mut: int, s: Any=s) -> None:
        while True:
            (i,) = (i_mut,)
            if i >= len(s):
                pass

            elif ((i + 1) < len(s)) if (s[i] == "\\") else False:
                match_value: str = s[i + 1]
                (pattern_matching_result, c) = (None, None)
                if match_value == "\n":
                    pattern_matching_result = 20

                elif match_value == " ":
                    pattern_matching_result = 9

                elif match_value == "\"":
                    pattern_matching_result = 10

                elif match_value == "/":
                    pattern_matching_result = 11

                elif match_value == "0":
                    pattern_matching_result = 0

                elif match_value == "L":
                    pattern_matching_result = 15

                elif match_value == "N":
                    pattern_matching_result = 13

                elif match_value == "P":
                    pattern_matching_result = 16

                elif match_value == "U":
                    if (i + 9) < len(s):
                        pattern_matching_result = 19

                    else: 
                        pattern_matching_result = 21
                        c = match_value


                elif match_value == "\\":
                    pattern_matching_result = 12

                elif match_value == "_":
                    pattern_matching_result = 14

                elif match_value == "a":
                    pattern_matching_result = 1

                elif match_value == "b":
                    pattern_matching_result = 2

                elif match_value == "e":
                    pattern_matching_result = 8

                elif match_value == "f":
                    pattern_matching_result = 6

                elif match_value == "n":
                    pattern_matching_result = 4

                elif match_value == "r":
                    pattern_matching_result = 7

                elif match_value == "t":
                    pattern_matching_result = 3

                elif match_value == "u":
                    if (i + 5) < len(s):
                        pattern_matching_result = 18

                    else: 
                        pattern_matching_result = 21
                        c = match_value


                elif match_value == "v":
                    pattern_matching_result = 5

                elif match_value == "x":
                    if (i + 3) < len(s):
                        pattern_matching_result = 17

                    else: 
                        pattern_matching_result = 21
                        c = match_value


                else: 
                    pattern_matching_result = 21
                    c = match_value

                if pattern_matching_result == 0:
                    ignore(StringBuffer__Append_244C7CD6(sb, "\u0000"))
                    i_mut = i + 2
                    continue

                elif pattern_matching_result == 1:
                    ignore(StringBuffer__Append_244C7CD6(sb, "\u0007"))
                    i_mut = i + 2
                    continue

                elif pattern_matching_result == 2:
                    ignore(StringBuffer__Append_244C7CD6(sb, "\b"))
                    i_mut = i + 2
                    continue

                elif pattern_matching_result == 3:
                    ignore(StringBuffer__Append_244C7CD6(sb, "\t"))
                    i_mut = i + 2
                    continue

                elif pattern_matching_result == 4:
                    ignore(StringBuffer__Append_244C7CD6(sb, "\n"))
                    i_mut = i + 2
                    continue

                elif pattern_matching_result == 5:
                    ignore(StringBuffer__Append_244C7CD6(sb, "\u000b"))
                    i_mut = i + 2
                    continue

                elif pattern_matching_result == 6:
                    ignore(StringBuffer__Append_244C7CD6(sb, "\f"))
                    i_mut = i + 2
                    continue

                elif pattern_matching_result == 7:
                    ignore(StringBuffer__Append_244C7CD6(sb, "\r"))
                    i_mut = i + 2
                    continue

                elif pattern_matching_result == 8:
                    ignore(StringBuffer__Append_244C7CD6(sb, "\u001b"))
                    i_mut = i + 2
                    continue

                elif pattern_matching_result == 9:
                    ignore(StringBuffer__Append_244C7CD6(sb, " "))
                    i_mut = i + 2
                    continue

                elif pattern_matching_result == 10:
                    ignore(StringBuffer__Append_244C7CD6(sb, "\""))
                    i_mut = i + 2
                    continue

                elif pattern_matching_result == 11:
                    ignore(StringBuffer__Append_244C7CD6(sb, "/"))
                    i_mut = i + 2
                    continue

                elif pattern_matching_result == 12:
                    ignore(StringBuffer__Append_244C7CD6(sb, "\\"))
                    i_mut = i + 2
                    continue

                elif pattern_matching_result == 13:
                    ignore(StringBuffer__Append_244C7CD6(sb, "\u0085"))
                    i_mut = i + 2
                    continue

                elif pattern_matching_result == 14:
                    ignore(StringBuffer__Append_244C7CD6(sb, " "))
                    i_mut = i + 2
                    continue

                elif pattern_matching_result == 15:
                    ignore(StringBuffer__Append_244C7CD6(sb, "\u2028"))
                    i_mut = i + 2
                    continue

                elif pattern_matching_result == 16:
                    ignore(StringBuffer__Append_244C7CD6(sb, "\u2029"))
                    i_mut = i + 2
                    continue

                elif pattern_matching_result == 17:
                    hex: str = substring(s, i + 2, 2)
                    try: 
                        ignore(StringBuffer__Append_244C7CD6(sb, chr(parse(hex, 511, False, 32, 16))))
                        loop(i + 4)

                    except Exception as match_value_1:
                        ignore(StringBuffer__Append_Z721C83C5(StringBuffer__Append_244C7CD6(StringBuffer__Append_244C7CD6(sb, "\\"), "x"), hex))
                        loop(i + 4)


                elif pattern_matching_result == 18:
                    hex_1: str = substring(s, i + 2, 4)
                    try: 
                        ignore(StringBuffer__Append_244C7CD6(sb, chr(parse(hex_1, 511, False, 32, 16))))
                        loop(i + 6)

                    except Exception as match_value_2:
                        ignore(StringBuffer__Append_Z721C83C5(StringBuffer__Append_244C7CD6(StringBuffer__Append_244C7CD6(sb, "\\"), "u"), hex_1))
                        loop(i + 6)


                elif pattern_matching_result == 19:
                    hex_2: str = substring(s, i + 2, 8)
                    try: 
                        ignore(StringBuffer__Append_Z721C83C5(sb, from_code_point(parse(hex_2, 511, False, 32, 16))))
                        loop(i + 10)

                    except Exception as match_value_3:
                        ignore(StringBuffer__Append_Z721C83C5(StringBuffer__Append_244C7CD6(StringBuffer__Append_244C7CD6(sb, "\\"), "U"), hex_2))
                        loop(i + 10)


                elif pattern_matching_result == 20:
                    StringBuffer__TrimEndWhitespace(sb)
                    pattern_input: tuple[int, int] = consume_escaped_line_breaks(i, 0)
                    extra_breaks_1: int = pattern_input[0] or 0
                    if extra_breaks_1 > 0:
                        ignore(StringBuffer__Append_Z721C83C5(sb, replicate(extra_breaks_1, "\n")))

                    i_mut = pattern_input[1]
                    continue

                elif pattern_matching_result == 21:
                    ignore(StringBuffer__Append_244C7CD6(StringBuffer__Append_244C7CD6(sb, "\\"), c))
                    i_mut = i + 2
                    continue


            else: 
                ignore(StringBuffer__Append_244C7CD6(sb, s[i]))
                i_mut = i + 1
                continue

            break

    loop(0)
    return to_string(sb)


__all__ = ["unescape_double_quoted"]

