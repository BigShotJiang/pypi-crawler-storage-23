from __future__ import annotations
from collections.abc import Callable
from typing import Any
from ..fable_library.array_ import try_head
from ..fable_library.int32 import parse
from ..fable_library.list import (to_array, FSharpList, map, filter, is_empty as is_empty_1, min as min_1, cons, empty, head, singleton as singleton_1, tail as tail_4, collect, reverse, of_array_with_tail, append as append_1, exists, for_all, of_array)
from ..fable_library.map import try_find
from ..fable_library.map_util import get_item_from_dict
from ..fable_library.option import (map as map_1, value as value_6)
from ..fable_library.reg_exp import (match, create, get_item, groups, replace)
from ..fable_library.seq import (length, take_while, to_list, delay, append, singleton, skip_while, map as map_2, collect as collect_1)
from ..fable_library.string_ import (is_null_or_white_space, trim_end, substring, starts_with_exact, ends_with_exact, join, to_fail, printf, split as split_1, trim_start, replace as replace_1)
from ..fable_library.types import (Array, to_string)
from ..fable_library.util import (equals, min, compare_primitives, ignore, IEnumerable_1)
from .escapes import unescape_double_quoted
from .flow_to_block import (default_context, TransformContext, transform_elements)
from .preprocessing import (read as read_1, is_document_start, is_document_end)
from .regex import (VerbatimTagPattern, AnchorPattern)
from .regex_active_patterns import (_007CSequenceMinusOpener_007C__007C, _007CYamlComment_007C__007C, _007CExplicitValue_007C__007C, _007CYamlValue_007C__007C, _007CKeyValue_007C__007C, _007CKey_007C__007C, _007CExplicitKey_007C__007C, _007CInlineJSON_007C__007C, _007CJSONKeyOpener_007C__007C, _007CJSONCloser_007C__007C, _007CInlineSequence_007C__007C, _007CSequenceSquareOpener_007C__007C, _007CSequenceSquareCloser_007C__007C, _007CSchemaNamespace_007C__007C, _007CAliasNode_007C__007C, _007CDocumentEnd_007C__007C)
from .string_buffer import (StringBuffer__ctor, StringBuffer, StringBuffer__Append_244C7CD6, StringBuffer__Append_Z721C83C5)
from .yamlicious_types import (StringMapEntry, BlockScalarStyle, ChompingMode, PreprocessorElement, YAMLElement, YAMLContent_create_Z1C3A29C9, ScalarStyle, Preprocessor)

def restore_scalar_placeholder_value(entry: StringMapEntry) -> str:
    if entry.Kind.tag == 1:
        return unescape_double_quoted(entry.Value)

    else: 
        return entry.Value



def restore_block_scalar_placeholder_value(entry: StringMapEntry) -> str:
    if entry.Kind.tag == 1:
        return ("\"" + entry.Value) + "\""

    else: 
        return ("\'" + entry.Value) + "\'"



def try_parse_exact_placeholder_index(v: str) -> int | None:
    m: Any = match(create(("^" + "\\<s f=(?P<index>\\d+)\\/\\>") + "$"), v.strip())
    if m is not None:
        return parse(get_item(groups(m), "index") or "", 511, False, 32)

    else: 
        return None



def restore_string_replace(string_dict: Any, v: str) -> str:
    def _arrow631(m: Any, string_dict: Any=string_dict, v: Any=v) -> str:
        return restore_scalar_placeholder_value(get_item_from_dict(string_dict, parse(get_item(groups(m), "index") or "", 511, False, 32)))

    return replace(v, "\\<s f=(?P<index>\\d+)\\/\\>", _arrow631)


def parse_block_scalar_header(header: str) -> tuple[BlockScalarStyle, int | None, ChompingMode] | None:
    h: str = header.strip()
    if is_null_or_white_space(h):
        return None

    else: 
        style_opt: BlockScalarStyle | None
        match_value: str = h[0]
        style_opt = BlockScalarStyle(1) if (match_value == ">") else (BlockScalarStyle(0) if (match_value == "|") else None)
        if style_opt is not None:
            style: BlockScalarStyle = style_opt
            indent: int | None = None
            chomp: ChompingMode = ChompingMode(1)
            is_valid: bool = True
            for i in range(1, (len(h) - 1) + 1, 1):
                match_value_1: str = h[i]
                def _arrow632(__unit: None=None, header: Any=header) -> bool:
                    c: str = match_value_1
                    return (c <= "9") if (c >= "1") else False

                if _arrow632():
                    if indent is not None:
                        is_valid = False

                    else: 
                        indent = parse(match_value_1, 511, False, 32)


                elif match_value_1 == "+":
                    if not equals(chomp, ChompingMode(1)):
                        is_valid = False

                    else: 
                        chomp = ChompingMode(2)


                elif match_value_1 == "-":
                    if not equals(chomp, ChompingMode(1)):
                        is_valid = False

                    else: 
                        chomp = ChompingMode(0)


                else: 
                    is_valid = False

            if is_valid:
                return (style, indent, chomp)

            else: 
                return None


        else: 
            return None




def apply_chomping(chomp: ChompingMode, content: str) -> str:
    if chomp.tag == 2:
        return content

    elif chomp.tag == 1:
        trimmed: str = trim_end(content, "\r", "\n")
        if len(content) > len(trimmed):
            return trimmed + "\n"

        else: 
            return trimmed


    else: 
        return trim_end(content, "\r", "\n")



def count_leading_spaces(line: str) -> int:
    def predicate(c: str, line: Any=line) -> bool:
        return c == " "

    return length(take_while(predicate, line))


def split_trailing_comment_placeholder(s: str) -> tuple[str, int | None]:
    m: Any = match(create(("^(?<header>.*?)\\s*(?:" + "\\<c f=(?P<comment>\\d+)\\/\\>") + ")\\s*$"), s)
    if m is not None:
        header: str = trim_end(get_item(groups(m), "header") or "")
        comment_group: Any = get_item(groups(m), "comment")
        return (header, parse(comment_group or "", 511, False, 32) if (((comment_group or "") != "") if (comment_group is not None) else False) else None)

    else: 
        return (trim_end(s), None)



def strip_block_indent(indent: int, line: str) -> str:
    if line.strip() == "":
        return ""

    else: 
        def _arrow633(x: int, y: int, indent: Any=indent, line: Any=line) -> int:
            return compare_primitives(x, y)

        return substring(line, min(_arrow633, indent, count_leading_spaces(line)))



def fold_lines(lines: FSharpList[str]) -> str:
    def is_more_indented(line: str, lines: Any=lines) -> bool:
        if starts_with_exact(line, " "):
            return True

        else: 
            return starts_with_exact(line, "\t")


    arr: Array[str] = to_array(lines)
    sb: StringBuffer = StringBuffer__ctor()
    for i in range(0, (len(arr) - 1) + 1, 1):
        line_1: str = arr[i]
        if line_1.strip() == "":
            ignore(StringBuffer__Append_244C7CD6(sb, "\n"))

        else: 
            ignore(StringBuffer__Append_Z721C83C5(sb, line_1))
            if i < (len(arr) - 1):
                next_1: str = arr[i + 1]
                if next_1.strip() == "":
                    ignore(StringBuffer__Append_244C7CD6(sb, "\n"))

                elif True if is_more_indented(line_1) else is_more_indented(next_1):
                    ignore(StringBuffer__Append_244C7CD6(sb, "\n"))

                else: 
                    ignore(StringBuffer__Append_244C7CD6(sb, " "))



    return to_string(sb)


def deindent_block_lines(header_indent: int, explicit_indent: int | None, lines: FSharpList[str]) -> FSharpList[str]:
    content_indent: int
    if explicit_indent is None:
        def _arrow634(line: str, header_indent: Any=header_indent, explicit_indent: Any=explicit_indent, lines: Any=lines) -> int:
            return count_leading_spaces(line)

        def predicate(l: str, header_indent: Any=header_indent, explicit_indent: Any=explicit_indent, lines: Any=lines) -> bool:
            return l.strip() != ""

        _arg: FSharpList[int] = map(_arrow634, filter(predicate, lines))
        class ObjectExpr635:
            @property
            def Compare(self) -> Callable[[int, int], int]:
                return compare_primitives

        content_indent = header_indent if is_empty_1(_arg) else min_1(_arg, ObjectExpr635())

    else: 
        content_indent = header_indent + explicit_indent

    def mapping(line_1: str, header_indent: Any=header_indent, explicit_indent: Any=explicit_indent, lines: Any=lines) -> str:
        return strip_block_indent(content_indent, line_1)

    return map(mapping, lines)


def build_block_scalar_content(style: BlockScalarStyle, chomp: ChompingMode, header_indent: int, explicit_indent: int | None, lines: FSharpList[str]) -> str:
    deindented_lines: FSharpList[str] = deindent_block_lines(header_indent, explicit_indent, lines)
    def _arrow636(__unit: None=None, style: Any=style, chomp: Any=chomp, header_indent: Any=header_indent, explicit_indent: Any=explicit_indent, lines: Any=lines) -> str:
        folded: str = fold_lines(deindented_lines)
        return folded if ends_with_exact(folded, "\n") else (folded + "\n")

    return apply_chomping(chomp, _arrow636() if (style.tag == 1) else ("" if is_empty_1(deindented_lines) else (join("\n", deindented_lines) + "\n")))


def restore_comment_replace(comment_dict: Any, comment_id: int | None=None) -> str | None:
    def mapping(id: int, comment_dict: Any=comment_dict, comment_id: Any=comment_id) -> str:
        return get_item_from_dict(comment_dict, id)

    return map_1(mapping, comment_id)


def collect_sequence_elements(eles: FSharpList[PreprocessorElement]) -> FSharpList[FSharpList[PreprocessorElement]]:
    (pattern_matching_result, rest, v, yaml_ast_list) = (None, None, None, None)
    if not is_empty_1(eles):
        active_pattern_result: dict[str, Any] | None = _007CSequenceMinusOpener_007C__007C(head(eles))
        if active_pattern_result is not None:
            if not is_empty_1(tail_4(eles)):
                if head(tail_4(eles)).tag == 1:
                    pattern_matching_result = 0
                    rest = tail_4(tail_4(eles))
                    v = active_pattern_result
                    yaml_ast_list = head(tail_4(eles)).fields[0]

                else: 
                    pattern_matching_result = 1


            else: 
                pattern_matching_result = 1


        else: 
            pattern_matching_result = 1


    else: 
        pattern_matching_result = 1

    if pattern_matching_result == 0:
        def _arrow638(__unit: None=None, eles: Any=eles) -> IEnumerable_1[FSharpList[PreprocessorElement]]:
            def _arrow637(__unit: None=None) -> IEnumerable_1[FSharpList[PreprocessorElement]]:
                return collect_sequence_elements(rest)

            return append(singleton(cons(PreprocessorElement(2, value_6(v["Value"])), yaml_ast_list)) if (v["Value"] is not None) else singleton(yaml_ast_list), delay(_arrow637))

        return to_list(delay(_arrow638))

    elif pattern_matching_result == 1:
        if is_empty_1(eles):
            return empty()

        else: 
            active_pattern_result_1: dict[str, Any] | None = _007CSequenceMinusOpener_007C__007C(head(eles))
            if active_pattern_result_1 is not None:
                v_1: dict[str, Any] = active_pattern_result_1
                def _arrow640(__unit: None=None, eles: Any=eles) -> IEnumerable_1[FSharpList[PreprocessorElement]]:
                    def _arrow639(__unit: None=None) -> IEnumerable_1[FSharpList[PreprocessorElement]]:
                        return collect_sequence_elements(tail_4(eles))

                    return append(singleton(singleton_1(PreprocessorElement(2, value_6(v_1["Value"])))) if (v_1["Value"] is not None) else singleton(empty()), delay(_arrow639))

                return to_list(delay(_arrow640))

            elif _007CYamlComment_007C__007C(head(eles)) is not None:
                def _arrow642(__unit: None=None, eles: Any=eles) -> IEnumerable_1[FSharpList[PreprocessorElement]]:
                    def _arrow641(__unit: None=None) -> IEnumerable_1[FSharpList[PreprocessorElement]]:
                        return collect_sequence_elements(tail_4(eles))

                    return append(singleton(singleton_1(head(eles))), delay(_arrow641))

                return to_list(delay(_arrow642))

            else: 
                return to_fail(printf("Unknown pattern for sequence elements: %A"))(eles)





def is_sequence_element(e: PreprocessorElement) -> bool:
    (pattern_matching_result,) = (None,)
    if e.tag == 1:
        pattern_matching_result = 0

    elif _007CSequenceMinusOpener_007C__007C(e) is not None:
        pattern_matching_result = 0

    elif _007CYamlComment_007C__007C(e) is not None:
        pattern_matching_result = 0

    else: 
        pattern_matching_result = 1

    if pattern_matching_result == 0:
        return True

    elif pattern_matching_result == 1:
        return False



def tokenize(yaml_list: FSharpList[PreprocessorElement], string_dict: Any, comment_dict: Any, handles: Any) -> YAMLElement:
    ctx: TransformContext = default_context(string_dict)
    def restore_inline_placeholders(line: str, yaml_list: Any=yaml_list, string_dict: Any=string_dict, comment_dict: Any=comment_dict, handles: Any=handles) -> str:
        def _arrow643(m: Any, line: Any=line) -> str:
            return restore_block_scalar_placeholder_value(get_item_from_dict(string_dict, parse(get_item(groups(m), "index") or "", 511, False, 32)))

        def _arrow644(m_1: Any, line: Any=line) -> str:
            return "#" + get_item_from_dict(comment_dict, parse(get_item(groups(m_1), "comment") or "", 511, False, 32))

        return replace(replace(line, "\\<s f=(?P<index>\\d+)\\/\\>", _arrow643), "\\<c f=(?P<comment>\\d+)\\/\\>", _arrow644)

    def flatten_block_scalar_with_depth(depth: int, eles: FSharpList[PreprocessorElement], yaml_list: Any=yaml_list, string_dict: Any=string_dict, comment_dict: Any=comment_dict, handles: Any=handles) -> FSharpList[str]:
        def mapping(_arg: PreprocessorElement, depth: Any=depth, eles: Any=eles) -> FSharpList[str]:
            if _arg.tag == 2:
                s: str = _arg.fields[0]
                return singleton_1(("" if (s == "") else (" " * (depth * 2))) + restore_inline_placeholders(s))

            elif _arg.tag == 1:
                return flatten_block_scalar_with_depth(depth + 1, _arg.fields[0])

            else: 
                return empty()


        return collect(mapping, eles)

    def flatten_block_scalar(eles_1: FSharpList[PreprocessorElement], yaml_list: Any=yaml_list, string_dict: Any=string_dict, comment_dict: Any=comment_dict, handles: Any=handles) -> FSharpList[str]:
        return flatten_block_scalar_with_depth(0, eles_1)

    def flatten_block_scalar_content_with_depth(depth_1: int, eles_2: FSharpList[PreprocessorElement], yaml_list: Any=yaml_list, string_dict: Any=string_dict, comment_dict: Any=comment_dict, handles: Any=handles) -> FSharpList[str]:
        def mapping_1(_arg_1: PreprocessorElement, depth_1: Any=depth_1, eles_2: Any=eles_2) -> FSharpList[str]:
            if _arg_1.tag == 2:
                s_1: str = _arg_1.fields[0]
                return singleton_1(("" if (s_1 == "") else (" " * ((depth_1 + 1) * 2))) + restore_inline_placeholders(s_1))

            elif _arg_1.tag == 1:
                return flatten_block_scalar_content_with_depth(depth_1 + 1, _arg_1.fields[0])

            else: 
                return empty()


        return collect(mapping_1, eles_2)

    def extract_properties(handles_2: Any, v: str, yaml_list: Any=yaml_list, string_dict: Any=string_dict, comment_dict: Any=comment_dict, handles: Any=handles) -> dict[str, Any]:
        current: str = v.strip()
        tag: str | None = None
        anchor: str | None = None
        changed: bool = True
        while changed:
            changed = False
            m_tag: Any = match(create(VerbatimTagPattern), current)
            if m_tag is not None:
                tag = get_item(groups(m_tag), "tag") or ""
                current = substring(current, len(m_tag[0])).strip()
                changed = True

            else: 
                m_short: Any = match(create("^(!\\S*)"), current)
                if m_short is not None:
                    raw_1: str = get_item(groups(m_short), 1) or ""
                    def _arrow649(__unit: None=None, handles_2: Any=handles_2, v: Any=v) -> str:
                        shorthand: str = raw_1
                        if shorthand == "!":
                            return "!"

                        else: 
                            m_2: Any = match(create("^(![\\w-]+!|!!|!)(.*)"), shorthand)
                            if m_2 is not None:
                                handle: str = get_item(groups(m_2), 1) or ""
                                suffix: str = get_item(groups(m_2), 2) or ""
                                match_value_2: str | None = try_find(handle, handles_2)
                                return shorthand if (match_value_2 is None) else (match_value_2 + suffix)

                            else: 
                                return shorthand



                    tag = _arrow649()
                    current = substring(current, len(m_short[0])).strip()
                    changed = True


            m_anchor: Any = match(create(AnchorPattern), current)
            if starts_with_exact(current, "&") if (m_anchor is not None) else False:
                anchor = get_item(groups(m_anchor), "anchor") or ""
                current = substring(current, len(m_anchor[0])).strip()
                changed = True

        return {
            "Anchor": anchor,
            "Tag": tag,
            "Value": current
        }

    def is_block_scalar_header_candidate(raw_header: str, yaml_list: Any=yaml_list, string_dict: Any=string_dict, comment_dict: Any=comment_dict, handles: Any=handles) -> bool:
        props: dict[str, Any] = extract_properties(handles, split_trailing_comment_placeholder(raw_header)[0])
        if starts_with_exact(props["Value"], "|"):
            return True

        else: 
            return starts_with_exact(props["Value"], ">")


    def try_read_block_scalar(raw_header_1: str, header_indent: int, base_comment_id: int | None, block: FSharpList[PreprocessorElement], yaml_list: Any=yaml_list, string_dict: Any=string_dict, comment_dict: Any=comment_dict, handles: Any=handles) -> dict[str, Any] | None:
        pattern_input_1: tuple[str, int | None] = split_trailing_comment_placeholder(raw_header_1)
        props_1: dict[str, Any] = extract_properties(handles, pattern_input_1[0])
        comment_id: int | None = pattern_input_1[1] if (base_comment_id is None) else base_comment_id
        match_value_3: tuple[BlockScalarStyle, int | None, ChompingMode] | None = parse_block_scalar_header(props_1["Value"])
        if match_value_3 is None:
            return None

        else: 
            style_1: BlockScalarStyle = match_value_3[0]
            indent: int | None = match_value_3[1]
            chomp: ChompingMode = match_value_3[2]
            value_4: str = build_block_scalar_content(style_1, chomp, header_indent, indent, flatten_block_scalar_content_with_depth(0, block))
            return {
                "Chomp": chomp,
                "Comment": restore_comment_replace(comment_dict, comment_id),
                "Indent": indent,
                "Props": props_1,
                "Style": style_1,
                "Value": value_4
            }


    def loop_read(handles_3_mut: Any, restlist_mut: FSharpList[PreprocessorElement], acc_mut: FSharpList[YAMLElement], yaml_list: Any=yaml_list, string_dict: Any=string_dict, comment_dict: Any=comment_dict, handles: Any=handles) -> YAMLElement:
        while True:
            (handles_3, restlist, acc) = (handles_3_mut, restlist_mut, acc_mut)
            (pattern_matching_result, alias, rest) = (None, None, None)
            if not is_empty_1(restlist):
                active_pattern_result: str | None = _007CAliasNode_007C__007C(head(restlist))
                if active_pattern_result is not None:
                    pattern_matching_result = 0
                    alias = active_pattern_result
                    rest = tail_4(restlist)

                elif _007CDocumentEnd_007C__007C(head(restlist)) is not None:
                    pattern_matching_result = 1

                else: 
                    pattern_matching_result = 2


            else: 
                pattern_matching_result = 2

            if pattern_matching_result == 0:
                handles_3_mut = handles_3
                restlist_mut = rest
                acc_mut = cons(YAMLElement(7, alias), acc)
                continue

            elif pattern_matching_result == 1:
                return YAMLElement(3, reverse(acc))

            elif pattern_matching_result == 2:
                (pattern_matching_result_1, rest0, v_1, yaml_ast_list) = (None, None, None, None)
                if not is_empty_1(restlist):
                    active_pattern_result_2: dict[str, Any] | None = _007CSchemaNamespace_007C__007C(head(restlist))
                    if active_pattern_result_2 is not None:
                        if not is_empty_1(tail_4(restlist)):
                            if head(tail_4(restlist)).tag == 1:
                                pattern_matching_result_1 = 0
                                rest0 = tail_4(tail_4(restlist))
                                v_1 = active_pattern_result_2
                                yaml_ast_list = head(tail_4(restlist)).fields[0]

                            else: 
                                pattern_matching_result_1 = 1


                        else: 
                            pattern_matching_result_1 = 1


                    else: 
                        pattern_matching_result_1 = 1


                else: 
                    pattern_matching_result_1 = 1

                if pattern_matching_result_1 == 0:
                    def _arrow652(e: PreprocessorElement, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> bool:
                        return is_sequence_element(e)

                    sequence_elements: FSharpList[FSharpList[PreprocessorElement]] = collect_sequence_elements(to_list(take_while(_arrow652, rest0)))
                    handles_3_mut = handles_3
                    def _arrow653(e_1: PreprocessorElement, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> bool:
                        return is_sequence_element(e_1)

                    restlist_mut = to_list(skip_while(_arrow653, rest0))
                    def _arrow659(__unit: None=None, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> IEnumerable_1[YAMLElement]:
                        def _arrow658(__unit: None=None) -> IEnumerable_1[YAMLElement]:
                            def _arrow657(i: FSharpList[PreprocessorElement]) -> YAMLElement:
                                return loop_read(handles_3, i, empty())

                            return map_2(_arrow657, sequence_elements)

                        return append(singleton(loop_read(handles_3, cons(PreprocessorElement(2, v_1["Key"]), yaml_ast_list), empty())), delay(_arrow658))

                    acc_mut = cons(YAMLElement(2, to_list(delay(_arrow659))), acc)
                    continue

                elif pattern_matching_result_1 == 1:
                    (pattern_matching_result_2, rest0_2, v_3, rest0_3, v_4, yaml_ast_list_2) = (None, None, None, None, None, None)
                    if not is_empty_1(restlist):
                        active_pattern_result_3: dict[str, Any] | None = _007CSchemaNamespace_007C__007C(head(restlist))
                        if active_pattern_result_3 is not None:
                            pattern_matching_result_2 = 0
                            rest0_2 = tail_4(restlist)
                            v_3 = active_pattern_result_3

                        else: 
                            active_pattern_result_4: dict[str, Any] | None = _007CSequenceMinusOpener_007C__007C(head(restlist))
                            if active_pattern_result_4 is not None:
                                if not is_empty_1(tail_4(restlist)):
                                    if head(tail_4(restlist)).tag == 1:
                                        def _arrow736(__unit: None=None, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> bool:
                                            v_2: dict[str, Any] = active_pattern_result_4
                                            return is_block_scalar_header_candidate(value_6(v_2["Value"])) if (v_2["Value"] is not None) else False

                                        if _arrow736():
                                            pattern_matching_result_2 = 1
                                            rest0_3 = tail_4(tail_4(restlist))
                                            v_4 = active_pattern_result_4
                                            yaml_ast_list_2 = head(tail_4(restlist)).fields[0]

                                        else: 
                                            pattern_matching_result_2 = 2


                                    else: 
                                        pattern_matching_result_2 = 2


                                else: 
                                    pattern_matching_result_2 = 2


                            else: 
                                pattern_matching_result_2 = 2



                    else: 
                        pattern_matching_result_2 = 2

                    if pattern_matching_result_2 == 0:
                        def _arrow661(e_2: PreprocessorElement, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> bool:
                            return is_sequence_element(e_2)

                        sequence_elements_1: FSharpList[FSharpList[PreprocessorElement]] = collect_sequence_elements(to_list(take_while(_arrow661, rest0_2)))
                        handles_3_mut = handles_3
                        def _arrow662(e_3: PreprocessorElement, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> bool:
                            return is_sequence_element(e_3)

                        restlist_mut = to_list(skip_while(_arrow662, rest0_2))
                        def _arrow669(__unit: None=None, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> IEnumerable_1[YAMLElement]:
                            def _arrow668(__unit: None=None) -> IEnumerable_1[YAMLElement]:
                                def _arrow666(i_1: FSharpList[PreprocessorElement]) -> YAMLElement:
                                    return loop_read(handles_3, i_1, empty())

                                return map_2(_arrow666, sequence_elements_1)

                            return append(singleton(loop_read(handles_3, singleton_1(PreprocessorElement(2, v_3["Key"])), empty())), delay(_arrow668))

                        acc_mut = cons(YAMLElement(2, to_list(delay(_arrow669))), acc)
                        continue

                    elif pattern_matching_result_2 == 1:
                        match_value_4: dict[str, Any] | None = try_read_block_scalar(value_6(v_4["Value"]), v_4["Indent"], None, yaml_ast_list_2)
                        if match_value_4 is None:
                            arg: str = value_6(v_4["Value"])
                            return to_fail(printf("Invalid sequence block scalar header: %s"))(arg)

                        else: 
                            block_scalar: dict[str, Any] = match_value_4
                            def _arrow672(e_4: PreprocessorElement, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> bool:
                                return is_sequence_element(e_4)

                            sequence_elements_2: FSharpList[FSharpList[PreprocessorElement]] = collect_sequence_elements(to_list(take_while(_arrow672, rest0_3)))
                            def _arrow673(e_5: PreprocessorElement, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> bool:
                                return is_sequence_element(e_5)

                            rest_3: FSharpList[PreprocessorElement] = to_list(skip_while(_arrow673, rest0_3))
                            first_item: YAMLElement = YAMLElement(3, singleton_1(YAMLElement(1, YAMLContent_create_Z1C3A29C9(block_scalar["Value"], block_scalar["Comment"], block_scalar["Props"]["Anchor"], block_scalar["Props"]["Tag"], ScalarStyle(3, block_scalar["Style"], block_scalar["Chomp"], block_scalar["Indent"])))))
                            handles_3_mut = handles_3
                            restlist_mut = rest_3
                            def _arrow681(__unit: None=None, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> IEnumerable_1[YAMLElement]:
                                def _arrow680(__unit: None=None) -> IEnumerable_1[YAMLElement]:
                                    def _arrow679(i_2: FSharpList[PreprocessorElement]) -> YAMLElement:
                                        return loop_read(handles_3, i_2, empty())

                                    return map_2(_arrow679, sequence_elements_2)

                                return append(singleton(first_item), delay(_arrow680))

                            acc_mut = cons(YAMLElement(2, to_list(delay(_arrow681))), acc)
                            continue


                    elif pattern_matching_result_2 == 2:
                        (pattern_matching_result_3, rest0_4, v_5, yaml_ast_list_3) = (None, None, None, None)
                        if not is_empty_1(restlist):
                            active_pattern_result_5: dict[str, Any] | None = _007CSequenceMinusOpener_007C__007C(head(restlist))
                            if active_pattern_result_5 is not None:
                                if not is_empty_1(tail_4(restlist)):
                                    if head(tail_4(restlist)).tag == 1:
                                        pattern_matching_result_3 = 0
                                        rest0_4 = tail_4(tail_4(restlist))
                                        v_5 = active_pattern_result_5
                                        yaml_ast_list_3 = head(tail_4(restlist)).fields[0]

                                    else: 
                                        pattern_matching_result_3 = 1


                                else: 
                                    pattern_matching_result_3 = 1


                            else: 
                                pattern_matching_result_3 = 1


                        else: 
                            pattern_matching_result_3 = 1

                        if pattern_matching_result_3 == 0:
                            object_list_1: FSharpList[PreprocessorElement] = cons(PreprocessorElement(2, value_6(v_5["Value"])), yaml_ast_list_3) if (v_5["Value"] is not None) else yaml_ast_list_3
                            def _arrow684(e_6: PreprocessorElement, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> bool:
                                return is_sequence_element(e_6)

                            sequence_elements_3: FSharpList[FSharpList[PreprocessorElement]] = collect_sequence_elements(to_list(take_while(_arrow684, rest0_4)))
                            handles_3_mut = handles_3
                            def _arrow685(e_7: PreprocessorElement, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> bool:
                                return is_sequence_element(e_7)

                            restlist_mut = to_list(skip_while(_arrow685, rest0_4))
                            def _arrow692(__unit: None=None, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> IEnumerable_1[YAMLElement]:
                                def _arrow691(__unit: None=None) -> IEnumerable_1[YAMLElement]:
                                    def _arrow689(i_3: FSharpList[PreprocessorElement]) -> YAMLElement:
                                        return loop_read(handles_3, i_3, empty())

                                    return map_2(_arrow689, sequence_elements_3)

                                return append(singleton(loop_read(handles_3, object_list_1, empty())), delay(_arrow691))

                            acc_mut = cons(YAMLElement(2, to_list(delay(_arrow692))), acc)
                            continue

                        elif pattern_matching_result_3 == 1:
                            (pattern_matching_result_4, rest0_5, v_6, rest_6, v_7, closer, i_list, opener, rest_7) = (None, None, None, None, None, None, None, None, None)
                            if not is_empty_1(restlist):
                                active_pattern_result_6: dict[str, Any] | None = _007CSequenceMinusOpener_007C__007C(head(restlist))
                                if active_pattern_result_6 is not None:
                                    pattern_matching_result_4 = 0
                                    rest0_5 = tail_4(restlist)
                                    v_6 = active_pattern_result_6

                                else: 
                                    active_pattern_result_7: dict[str, Any] | None = _007CInlineSequence_007C__007C(head(restlist))
                                    if active_pattern_result_7 is not None:
                                        pattern_matching_result_4 = 1
                                        rest_6 = tail_4(restlist)
                                        v_7 = active_pattern_result_7

                                    else: 
                                        active_pattern_result_8: dict[str, Any] | None = _007CSequenceSquareOpener_007C__007C(head(restlist))
                                        if active_pattern_result_8 is not None:
                                            if not is_empty_1(tail_4(restlist)):
                                                if head(tail_4(restlist)).tag == 1:
                                                    if not is_empty_1(tail_4(tail_4(restlist))):
                                                        active_pattern_result_9: dict[str, Any] | None = _007CSequenceSquareCloser_007C__007C(head(tail_4(tail_4(restlist))))
                                                        if active_pattern_result_9 is not None:
                                                            pattern_matching_result_4 = 2
                                                            closer = active_pattern_result_9
                                                            i_list = head(tail_4(restlist)).fields[0]
                                                            opener = active_pattern_result_8
                                                            rest_7 = tail_4(tail_4(tail_4(restlist)))

                                                        else: 
                                                            pattern_matching_result_4 = 3


                                                    else: 
                                                        pattern_matching_result_4 = 3


                                                else: 
                                                    pattern_matching_result_4 = 3


                                            else: 
                                                pattern_matching_result_4 = 3


                                        else: 
                                            pattern_matching_result_4 = 3




                            else: 
                                pattern_matching_result_4 = 3

                            if pattern_matching_result_4 == 0:
                                def _arrow693(e_8: PreprocessorElement, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> bool:
                                    return is_sequence_element(e_8)

                                sequence_elements_4: FSharpList[FSharpList[PreprocessorElement]] = collect_sequence_elements(to_list(take_while(_arrow693, rest0_5)))
                                def _arrow694(e_9: PreprocessorElement, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> bool:
                                    return is_sequence_element(e_9)

                                rest_5: FSharpList[PreprocessorElement] = to_list(skip_while(_arrow694, rest0_5))
                                object_list_2: FSharpList[PreprocessorElement] = singleton_1(PreprocessorElement(2, value_6(v_6["Value"]))) if (v_6["Value"] is not None) else empty()
                                handles_3_mut = handles_3
                                restlist_mut = rest_5
                                def _arrow700(__unit: None=None, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> IEnumerable_1[YAMLElement]:
                                    def _arrow699(__unit: None=None) -> IEnumerable_1[YAMLElement]:
                                        def _arrow698(i_4: FSharpList[PreprocessorElement]) -> YAMLElement:
                                            return loop_read(handles_3, i_4, empty())

                                        return map_2(_arrow698, sequence_elements_4)

                                    return append(singleton(loop_read(handles_3, object_list_2, empty())), delay(_arrow699))

                                acc_mut = cons(YAMLElement(2, to_list(delay(_arrow700))), acc)
                                continue

                            elif pattern_matching_result_4 == 1:
                                c: str | None = restore_comment_replace(comment_dict, v_7["Comment"])
                                split: Array[str] = split_1(v_7["Value"], [","], None, 1)
                                def _arrow702(__unit: None=None, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> IEnumerable_1[YAMLElement]:
                                    def _arrow701(value_5: str) -> YAMLElement:
                                        return loop_read(handles_3, singleton_1(PreprocessorElement(2, value_5.strip())), empty())

                                    return map_2(_arrow701, split)

                                current_6: YAMLElement = YAMLElement(2, to_list(delay(_arrow702)))
                                handles_3_mut = handles_3
                                restlist_mut = rest_6
                                acc_mut = of_array_with_tail([current_6, YAMLElement(4, value_6(c))], acc) if (c is not None) else cons(current_6, acc)
                                continue

                            elif pattern_matching_result_4 == 2:
                                c1: str | None = restore_comment_replace(comment_dict, opener["Comment"])
                                c2: str | None = restore_comment_replace(comment_dict, closer["Comment"])
                                def _arrow704(__unit: None=None, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> IEnumerable_1[YAMLElement]:
                                    def _arrow703(i_5: PreprocessorElement) -> IEnumerable_1[YAMLElement]:
                                        return singleton(loop_read(handles_3, singleton_1(PreprocessorElement(2, trim_end(i_5.fields[0], ",")) if (i_5.tag == 2) else to_fail(printf("Unexpected element in MultiLineSquareBrackets: %A"))(i_5)), empty()))

                                    return collect_1(_arrow703, i_list)

                                current_7: YAMLElement = YAMLElement(2, to_list(delay(_arrow704)))
                                handles_3_mut = handles_3
                                restlist_mut = rest_7
                                def _arrow705(__unit: None=None, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> FSharpList[YAMLElement]:
                                    c2_2: str = c2
                                    return of_array_with_tail([YAMLElement(4, c2_2), current_7], acc)

                                def _arrow706(__unit: None=None, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> FSharpList[YAMLElement]:
                                    c1_2: str = c1
                                    return of_array_with_tail([current_7, YAMLElement(4, c1_2)], acc)

                                def _arrow707(__unit: None=None, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> FSharpList[YAMLElement]:
                                    c1_1: str = c1
                                    c2_1: str = c2
                                    return of_array_with_tail([YAMLElement(4, c2_1), current_7, YAMLElement(4, c1_1)], acc)

                                acc_mut = (cons(current_7, acc) if (c2 is None) else _arrow705()) if (c1 is None) else (_arrow706() if (c2 is None) else _arrow707())
                                continue

                            elif pattern_matching_result_4 == 3:
                                (pattern_matching_result_5, rest_9, v_9) = (None, None, None)
                                if not is_empty_1(restlist):
                                    active_pattern_result_10: dict[str, Any] | None = _007CInlineJSON_007C__007C(head(restlist))
                                    if active_pattern_result_10 is not None:
                                        def _arrow735(__unit: None=None, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> bool:
                                            v_8: dict[str, Any] = active_pattern_result_10
                                            return v_8["Value"].strip() == ""

                                        if _arrow735():
                                            pattern_matching_result_5 = 0
                                            rest_9 = tail_4(restlist)
                                            v_9 = active_pattern_result_10

                                        else: 
                                            pattern_matching_result_5 = 1


                                    else: 
                                        pattern_matching_result_5 = 1


                                else: 
                                    pattern_matching_result_5 = 1

                                if pattern_matching_result_5 == 0:
                                    c_1: str | None = restore_comment_replace(comment_dict, v_9["Comment"])
                                    current_8: FSharpList[Any] = empty()
                                    handles_3_mut = handles_3
                                    restlist_mut = rest_9
                                    acc_mut = append_1(current_8, cons(YAMLElement(4, value_6(c_1)), acc)) if (c_1 is not None) else append_1(current_8, acc)
                                    continue

                                elif pattern_matching_result_5 == 1:
                                    (pattern_matching_result_6, opener_1) = (None, None)
                                    if not is_empty_1(restlist):
                                        active_pattern_result_11: dict[str, Any] | None = _007CJSONKeyOpener_007C__007C(head(restlist))
                                        if active_pattern_result_11 is not None:
                                            if not is_empty_1(tail_4(restlist)):
                                                if head(tail_4(restlist)).tag == 1:
                                                    if not is_empty_1(tail_4(tail_4(restlist))):
                                                        if _007CJSONCloser_007C__007C(head(tail_4(tail_4(restlist)))) is not None:
                                                            pattern_matching_result_6 = 0
                                                            opener_1 = active_pattern_result_11

                                                        else: 
                                                            pattern_matching_result_6 = 1


                                                    else: 
                                                        pattern_matching_result_6 = 1


                                                else: 
                                                    pattern_matching_result_6 = 1


                                            else: 
                                                pattern_matching_result_6 = 1


                                        else: 
                                            pattern_matching_result_6 = 1


                                    else: 
                                        pattern_matching_result_6 = 1

                                    if pattern_matching_result_6 == 0:
                                        return to_fail(printf("Untransformed flow-style object detected. This is a bug in FlowToBlock transformation. Pattern: %A"))(opener_1)

                                    elif pattern_matching_result_6 == 1:
                                        (pattern_matching_result_7, v_11) = (None, None)
                                        if not is_empty_1(restlist):
                                            active_pattern_result_13: dict[str, Any] | None = _007CInlineJSON_007C__007C(head(restlist))
                                            if active_pattern_result_13 is not None:
                                                def _arrow734(__unit: None=None, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> bool:
                                                    v_10: dict[str, Any] = active_pattern_result_13
                                                    return v_10["Value"].strip() != ""

                                                if _arrow734():
                                                    pattern_matching_result_7 = 0
                                                    v_11 = active_pattern_result_13

                                                else: 
                                                    pattern_matching_result_7 = 1


                                            else: 
                                                pattern_matching_result_7 = 1


                                        else: 
                                            pattern_matching_result_7 = 1

                                        if pattern_matching_result_7 == 0:
                                            return to_fail(printf("Untransformed non-empty flow-style object detected: {%s}. This is a bug in FlowToBlock transformation."))(v_11["Value"])

                                        elif pattern_matching_result_7 == 1:
                                            (pattern_matching_result_8, k, rest_10, rest_11, v_16, yaml_ast_list_4) = (None, None, None, None, None, None)
                                            if not is_empty_1(restlist):
                                                active_pattern_result_14: (str | None) | None = _007CExplicitKey_007C__007C(head(restlist))
                                                if active_pattern_result_14 is not None:
                                                    pattern_matching_result_8 = 0
                                                    k = value_6(active_pattern_result_14)
                                                    rest_10 = tail_4(restlist)

                                                else: 
                                                    active_pattern_result_15: dict[str, Any] | None = _007CKey_007C__007C(head(restlist))
                                                    if active_pattern_result_15 is not None:
                                                        if not is_empty_1(tail_4(restlist)):
                                                            if head(tail_4(restlist)).tag == 1:
                                                                pattern_matching_result_8 = 1
                                                                rest_11 = tail_4(tail_4(restlist))
                                                                v_16 = active_pattern_result_15
                                                                yaml_ast_list_4 = head(tail_4(restlist)).fields[0]

                                                            else: 
                                                                pattern_matching_result_8 = 2


                                                        else: 
                                                            pattern_matching_result_8 = 2


                                                    else: 
                                                        pattern_matching_result_8 = 2



                                            else: 
                                                pattern_matching_result_8 = 2

                                            if pattern_matching_result_8 == 0:
                                                def parse_value(v_str: str, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> YAMLElement:
                                                    def _arrow708(__unit: None=None, v_str: Any=v_str) -> FSharpList[PreprocessorElement]:
                                                        match_value_6: PreprocessorElement = read_1(v_str).AST
                                                        return match_value_6.fields[0] if (match_value_6.tag == 0) else empty()

                                                    return loop_read(handles_3, transform_elements(TransformContext(0, ctx.IndentStep, ctx.StringDict), _arrow708()), empty())

                                                parse_value: Callable[[str], YAMLElement] = parse_value
                                                (pattern_matching_result_9, i_list_1, key_body, tail, v_12) = (None, None, None, None, None)
                                                if not is_empty_1(rest_10):
                                                    if head(rest_10).tag == 1:
                                                        if not is_empty_1(tail_4(rest_10)):
                                                            active_pattern_result_16: str | None = _007CExplicitValue_007C__007C(head(tail_4(rest_10)))
                                                            if active_pattern_result_16 is not None:
                                                                if not is_empty_1(tail_4(tail_4(rest_10))):
                                                                    if head(tail_4(tail_4(rest_10))).tag == 1:
                                                                        pattern_matching_result_9 = 0
                                                                        i_list_1 = head(tail_4(tail_4(rest_10))).fields[0]
                                                                        key_body = head(rest_10).fields[0]
                                                                        tail = tail_4(tail_4(tail_4(rest_10)))
                                                                        v_12 = active_pattern_result_16

                                                                    else: 
                                                                        pattern_matching_result_9 = 1


                                                                else: 
                                                                    pattern_matching_result_9 = 1


                                                            else: 
                                                                pattern_matching_result_9 = 1


                                                        else: 
                                                            pattern_matching_result_9 = 1


                                                    else: 
                                                        pattern_matching_result_9 = 1


                                                else: 
                                                    pattern_matching_result_9 = 1

                                                if pattern_matching_result_9 == 0:
                                                    simplified_key: str = join("\n", flatten_block_scalar(key_body))
                                                    def _arrow709(__unit: None=None, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> str:
                                                        s_3: str = k
                                                        return (s_3 + ("\n" if (s_3 != "") else "")) + simplified_key

                                                    kp: dict[str, Any] = extract_properties(handles_3, simplified_key if (k is None) else _arrow709())
                                                    separator: str = " " if (True if starts_with_exact(trim_start(v_12), "[") else starts_with_exact(trim_start(v_12), "{")) else "\n"
                                                    value_element: YAMLElement = parse_value((v_12 + separator) + join(separator, flatten_block_scalar(i_list_1)))
                                                    handles_3_mut = handles_3
                                                    restlist_mut = tail
                                                    acc_mut = cons(YAMLElement(0, YAMLContent_create_Z1C3A29C9(kp["Value"], None, kp["Anchor"], kp["Tag"]), value_element), acc)
                                                    continue

                                                elif pattern_matching_result_9 == 1:
                                                    (pattern_matching_result_10, key_body_1, tail_1, v_13, i_list_2, tail_2, v_14) = (None, None, None, None, None, None, None)
                                                    if not is_empty_1(rest_10):
                                                        if head(rest_10).tag == 1:
                                                            if not is_empty_1(tail_4(rest_10)):
                                                                active_pattern_result_17: str | None = _007CExplicitValue_007C__007C(head(tail_4(rest_10)))
                                                                if active_pattern_result_17 is not None:
                                                                    pattern_matching_result_10 = 0
                                                                    key_body_1 = head(rest_10).fields[0]
                                                                    tail_1 = tail_4(tail_4(rest_10))
                                                                    v_13 = active_pattern_result_17

                                                                elif head(tail_4(rest_10)).tag == 1:
                                                                    active_pattern_result_18: str | None = _007CExplicitValue_007C__007C(head(rest_10))
                                                                    if active_pattern_result_18 is not None:
                                                                        pattern_matching_result_10 = 1
                                                                        i_list_2 = head(tail_4(rest_10)).fields[0]
                                                                        tail_2 = tail_4(tail_4(rest_10))
                                                                        v_14 = active_pattern_result_18

                                                                    else: 
                                                                        pattern_matching_result_10 = 2


                                                                else: 
                                                                    pattern_matching_result_10 = 2


                                                            else: 
                                                                pattern_matching_result_10 = 2


                                                        else: 
                                                            active_pattern_result_19: str | None = _007CExplicitValue_007C__007C(head(rest_10))
                                                            if active_pattern_result_19 is not None:
                                                                if not is_empty_1(tail_4(rest_10)):
                                                                    if head(tail_4(rest_10)).tag == 1:
                                                                        pattern_matching_result_10 = 1
                                                                        i_list_2 = head(tail_4(rest_10)).fields[0]
                                                                        tail_2 = tail_4(tail_4(rest_10))
                                                                        v_14 = active_pattern_result_19

                                                                    else: 
                                                                        pattern_matching_result_10 = 2


                                                                else: 
                                                                    pattern_matching_result_10 = 2


                                                            else: 
                                                                pattern_matching_result_10 = 2



                                                    else: 
                                                        pattern_matching_result_10 = 2

                                                    if pattern_matching_result_10 == 0:
                                                        simplified_key_1: str = join("\n", flatten_block_scalar(key_body_1))
                                                        def _arrow710(__unit: None=None, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> str:
                                                            s_4: str = k
                                                            return (s_4 + ("\n" if (s_4 != "") else "")) + simplified_key_1

                                                        kp_1: dict[str, Any] = extract_properties(handles_3, simplified_key_1 if (k is None) else _arrow710())
                                                        value_element_1: YAMLElement = parse_value(v_13)
                                                        handles_3_mut = handles_3
                                                        restlist_mut = tail_1
                                                        acc_mut = cons(YAMLElement(0, YAMLContent_create_Z1C3A29C9(kp_1["Value"], None, kp_1["Anchor"], kp_1["Tag"]), value_element_1), acc)
                                                        continue

                                                    elif pattern_matching_result_10 == 1:
                                                        kp_2: dict[str, Any] = ({
                                                            "Anchor": None,
                                                            "Tag": None,
                                                            "Value": ""
                                                        }) if (k is None) else extract_properties(handles_3, k)
                                                        value_element_2: YAMLElement = parse_value((v_14 + "\n") + join("\n", flatten_block_scalar(i_list_2)))
                                                        handles_3_mut = handles_3
                                                        restlist_mut = tail_2
                                                        acc_mut = cons(YAMLElement(0, YAMLContent_create_Z1C3A29C9(kp_2["Value"], None, kp_2["Anchor"], kp_2["Tag"]), value_element_2), acc)
                                                        continue

                                                    elif pattern_matching_result_10 == 2:
                                                        (pattern_matching_result_11, tail_3, v_15) = (None, None, None)
                                                        if not is_empty_1(rest_10):
                                                            active_pattern_result_20: str | None = _007CExplicitValue_007C__007C(head(rest_10))
                                                            if active_pattern_result_20 is not None:
                                                                pattern_matching_result_11 = 0
                                                                tail_3 = tail_4(rest_10)
                                                                v_15 = active_pattern_result_20

                                                            else: 
                                                                pattern_matching_result_11 = 1


                                                        else: 
                                                            pattern_matching_result_11 = 1

                                                        if pattern_matching_result_11 == 0:
                                                            kp_3: dict[str, Any] = ({
                                                                "Anchor": None,
                                                                "Tag": None,
                                                                "Value": ""
                                                            }) if (k is None) else extract_properties(handles_3, k)
                                                            value_element_3: YAMLElement = parse_value(v_15)
                                                            handles_3_mut = handles_3
                                                            restlist_mut = tail_3
                                                            acc_mut = cons(YAMLElement(0, YAMLContent_create_Z1C3A29C9(kp_3["Value"], None, kp_3["Anchor"], kp_3["Tag"]), value_element_3), acc)
                                                            continue

                                                        elif pattern_matching_result_11 == 1:
                                                            kp_4: dict[str, Any] = ({
                                                                "Anchor": None,
                                                                "Tag": None,
                                                                "Value": ""
                                                            }) if (k is None) else extract_properties(handles_3, k)
                                                            handles_3_mut = handles_3
                                                            restlist_mut = rest_10
                                                            acc_mut = cons(YAMLElement(0, YAMLContent_create_Z1C3A29C9(kp_4["Value"], None, kp_4["Anchor"], kp_4["Tag"]), YAMLElement(8)), acc)
                                                            continue




                                            elif pattern_matching_result_8 == 1:
                                                c_2: str | None = restore_comment_replace(comment_dict, v_16["Comment"])
                                                props_2: dict[str, Any] = extract_properties(handles_3, v_16["Key"])
                                                handles_3_mut = handles_3
                                                restlist_mut = rest_11
                                                acc_mut = cons(YAMLElement(0, YAMLContent_create_Z1C3A29C9(props_2["Value"], c_2, props_2["Anchor"], props_2["Tag"]), loop_read(handles_3, yaml_ast_list_4, empty())), acc)
                                                continue

                                            elif pattern_matching_result_8 == 2:
                                                (pattern_matching_result_12, rest0_6, v_17, w, yaml_ast_list_5) = (None, None, None, None, None)
                                                if not is_empty_1(restlist):
                                                    active_pattern_result_21: dict[str, Any] | None = _007CKey_007C__007C(head(restlist))
                                                    if active_pattern_result_21 is not None:
                                                        if not is_empty_1(tail_4(restlist)):
                                                            active_pattern_result_22: dict[str, Any] | None = _007CSequenceMinusOpener_007C__007C(head(tail_4(restlist)))
                                                            if active_pattern_result_22 is not None:
                                                                if not is_empty_1(tail_4(tail_4(restlist))):
                                                                    if head(tail_4(tail_4(restlist))).tag == 1:
                                                                        pattern_matching_result_12 = 0
                                                                        rest0_6 = tail_4(tail_4(tail_4(restlist)))
                                                                        v_17 = active_pattern_result_21
                                                                        w = active_pattern_result_22
                                                                        yaml_ast_list_5 = head(tail_4(tail_4(restlist))).fields[0]

                                                                    else: 
                                                                        pattern_matching_result_12 = 1


                                                                else: 
                                                                    pattern_matching_result_12 = 1


                                                            else: 
                                                                pattern_matching_result_12 = 1


                                                        else: 
                                                            pattern_matching_result_12 = 1


                                                    else: 
                                                        pattern_matching_result_12 = 1


                                                else: 
                                                    pattern_matching_result_12 = 1

                                                if pattern_matching_result_12 == 0:
                                                    c_3: str | None = restore_comment_replace(comment_dict, v_17["Comment"])
                                                    props_3: dict[str, Any] = extract_properties(handles_3, v_17["Key"])
                                                    object_list_3: FSharpList[PreprocessorElement] = cons(PreprocessorElement(2, value_6(w["Value"])), yaml_ast_list_5) if (w["Value"] is not None) else yaml_ast_list_5
                                                    def _arrow711(e_10: PreprocessorElement, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> bool:
                                                        return is_sequence_element(e_10)

                                                    sequence_elements_5: FSharpList[FSharpList[PreprocessorElement]] = collect_sequence_elements(to_list(take_while(_arrow711, rest0_6)))
                                                    def _arrow712(e_11: PreprocessorElement, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> bool:
                                                        return is_sequence_element(e_11)

                                                    rest_12: FSharpList[PreprocessorElement] = to_list(skip_while(_arrow712, rest0_6))
                                                    def _arrow715(__unit: None=None, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> IEnumerable_1[YAMLElement]:
                                                        def _arrow714(__unit: None=None) -> IEnumerable_1[YAMLElement]:
                                                            def _arrow713(i_6: FSharpList[PreprocessorElement]) -> YAMLElement:
                                                                return loop_read(handles_3, i_6, empty())

                                                            return map_2(_arrow713, sequence_elements_5)

                                                        return append(singleton(loop_read(handles_3, object_list_3, empty())), delay(_arrow714))

                                                    seq: YAMLElement = YAMLElement(2, to_list(delay(_arrow715)))
                                                    handles_3_mut = handles_3
                                                    restlist_mut = rest_12
                                                    acc_mut = cons(YAMLElement(0, YAMLContent_create_Z1C3A29C9(props_3["Value"], c_3, props_3["Anchor"], props_3["Tag"]), YAMLElement(3, singleton_1(seq))), acc)
                                                    continue

                                                elif pattern_matching_result_12 == 1:
                                                    (pattern_matching_result_13, rest0_7, v_18, w_1) = (None, None, None, None)
                                                    if not is_empty_1(restlist):
                                                        active_pattern_result_23: dict[str, Any] | None = _007CKey_007C__007C(head(restlist))
                                                        if active_pattern_result_23 is not None:
                                                            if not is_empty_1(tail_4(restlist)):
                                                                active_pattern_result_24: dict[str, Any] | None = _007CSequenceMinusOpener_007C__007C(head(tail_4(restlist)))
                                                                if active_pattern_result_24 is not None:
                                                                    pattern_matching_result_13 = 0
                                                                    rest0_7 = tail_4(tail_4(restlist))
                                                                    v_18 = active_pattern_result_23
                                                                    w_1 = active_pattern_result_24

                                                                else: 
                                                                    pattern_matching_result_13 = 1


                                                            else: 
                                                                pattern_matching_result_13 = 1


                                                        else: 
                                                            pattern_matching_result_13 = 1


                                                    else: 
                                                        pattern_matching_result_13 = 1

                                                    if pattern_matching_result_13 == 0:
                                                        c_4: str | None = restore_comment_replace(comment_dict, v_18["Comment"])
                                                        props_4: dict[str, Any] = extract_properties(handles_3, v_18["Key"])
                                                        def _arrow716(e_12: PreprocessorElement, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> bool:
                                                            return is_sequence_element(e_12)

                                                        sequence_elements_6: FSharpList[FSharpList[PreprocessorElement]] = collect_sequence_elements(to_list(take_while(_arrow716, rest0_7)))
                                                        def _arrow717(e_13: PreprocessorElement, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> bool:
                                                            return is_sequence_element(e_13)

                                                        rest_13: FSharpList[PreprocessorElement] = to_list(skip_while(_arrow717, rest0_7))
                                                        def _arrow720(__unit: None=None, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> IEnumerable_1[YAMLElement]:
                                                            def _arrow719(__unit: None=None) -> IEnumerable_1[YAMLElement]:
                                                                def _arrow718(i_7: FSharpList[PreprocessorElement]) -> YAMLElement:
                                                                    return loop_read(handles_3, i_7, empty())

                                                                return map_2(_arrow718, sequence_elements_6)

                                                            return append(singleton(loop_read(handles_3, singleton_1(PreprocessorElement(2, value_6(w_1["Value"]))), empty())), delay(_arrow719))

                                                        seq_1: YAMLElement = YAMLElement(2, to_list(delay(_arrow720)))
                                                        handles_3_mut = handles_3
                                                        restlist_mut = rest_13
                                                        acc_mut = cons(YAMLElement(0, YAMLContent_create_Z1C3A29C9(props_4["Value"], c_4, props_4["Anchor"], props_4["Tag"]), YAMLElement(3, singleton_1(seq_1))), acc)
                                                        continue

                                                    elif pattern_matching_result_13 == 1:
                                                        (pattern_matching_result_14, block_2, rest_15, v_20) = (None, None, None, None)
                                                        if not is_empty_1(restlist):
                                                            active_pattern_result_25: dict[str, Any] | None = _007CKeyValue_007C__007C(head(restlist))
                                                            if active_pattern_result_25 is not None:
                                                                if not is_empty_1(tail_4(restlist)):
                                                                    if head(tail_4(restlist)).tag == 1:
                                                                        if is_block_scalar_header_candidate(active_pattern_result_25["Value"]):
                                                                            pattern_matching_result_14 = 0
                                                                            block_2 = head(tail_4(restlist)).fields[0]
                                                                            rest_15 = tail_4(tail_4(restlist))
                                                                            v_20 = active_pattern_result_25

                                                                        else: 
                                                                            pattern_matching_result_14 = 1


                                                                    else: 
                                                                        pattern_matching_result_14 = 1


                                                                else: 
                                                                    pattern_matching_result_14 = 1


                                                            else: 
                                                                pattern_matching_result_14 = 1


                                                        else: 
                                                            pattern_matching_result_14 = 1

                                                        if pattern_matching_result_14 == 0:
                                                            match_value_7: dict[str, Any] | None = try_read_block_scalar(v_20["Value"], v_20["Indent"], None, block_2)
                                                            if match_value_7 is None:
                                                                return to_fail(printf("Invalid block scalar header: %s"))(v_20["Value"])

                                                            else: 
                                                                block_scalar_1: dict[str, Any] = match_value_7
                                                                key_props: dict[str, Any] = extract_properties(handles_3, v_20["Key"])
                                                                handles_3_mut = handles_3
                                                                restlist_mut = rest_15
                                                                acc_mut = cons(YAMLElement(0, YAMLContent_create_Z1C3A29C9(key_props["Value"], None, key_props["Anchor"], key_props["Tag"]), YAMLElement(1, YAMLContent_create_Z1C3A29C9(block_scalar_1["Value"], block_scalar_1["Comment"], block_scalar_1["Props"]["Anchor"], block_scalar_1["Props"]["Tag"], ScalarStyle(3, block_scalar_1["Style"], block_scalar_1["Chomp"], block_scalar_1["Indent"])))), acc)
                                                                continue


                                                        elif pattern_matching_result_14 == 1:
                                                            (pattern_matching_result_15, rest_17, v_22, rest_18, v_23, block_4, rest_19, v_24) = (None, None, None, None, None, None, None, None)
                                                            if not is_empty_1(restlist):
                                                                active_pattern_result_26: dict[str, Any] | None = _007CKeyValue_007C__007C(head(restlist))
                                                                if active_pattern_result_26 is not None:
                                                                    pattern_matching_result_15 = 0
                                                                    rest_17 = tail_4(restlist)
                                                                    v_22 = active_pattern_result_26

                                                                else: 
                                                                    active_pattern_result_27: dict[str, Any] | None = _007CYamlComment_007C__007C(head(restlist))
                                                                    if active_pattern_result_27 is not None:
                                                                        pattern_matching_result_15 = 1
                                                                        rest_18 = tail_4(restlist)
                                                                        v_23 = active_pattern_result_27

                                                                    else: 
                                                                        active_pattern_result_28: dict[str, Any] | None = _007CYamlValue_007C__007C(head(restlist))
                                                                        if active_pattern_result_28 is not None:
                                                                            if not is_empty_1(tail_4(restlist)):
                                                                                if head(tail_4(restlist)).tag == 1:
                                                                                    if is_block_scalar_header_candidate(active_pattern_result_28["Value"]):
                                                                                        pattern_matching_result_15 = 2
                                                                                        block_4 = head(tail_4(restlist)).fields[0]
                                                                                        rest_19 = tail_4(tail_4(restlist))
                                                                                        v_24 = active_pattern_result_28

                                                                                    else: 
                                                                                        pattern_matching_result_15 = 3


                                                                                else: 
                                                                                    pattern_matching_result_15 = 3


                                                                            else: 
                                                                                pattern_matching_result_15 = 3


                                                                        else: 
                                                                            pattern_matching_result_15 = 3




                                                            else: 
                                                                pattern_matching_result_15 = 3

                                                            if pattern_matching_result_15 == 0:
                                                                props_5: dict[str, Any] = extract_properties(handles_3, v_22["Key"])
                                                                handles_3_mut = handles_3
                                                                restlist_mut = rest_17
                                                                acc_mut = cons(YAMLElement(0, YAMLContent_create_Z1C3A29C9(props_5["Value"], None, props_5["Anchor"], props_5["Tag"]), loop_read(handles_3, singleton_1(PreprocessorElement(2, v_22["Value"])), empty())), acc)
                                                                continue

                                                            elif pattern_matching_result_15 == 1:
                                                                handles_3_mut = handles_3
                                                                restlist_mut = rest_18
                                                                acc_mut = cons(YAMLElement(4, get_item_from_dict(comment_dict, v_23["Comment"])), acc)
                                                                continue

                                                            elif pattern_matching_result_15 == 2:
                                                                match_value_8: dict[str, Any] | None = try_read_block_scalar(v_24["Value"], v_24["Indent"], v_24["Comment"], block_4)
                                                                if match_value_8 is None:
                                                                    return to_fail(printf("Invalid block scalar header: %s"))(v_24["Value"])

                                                                else: 
                                                                    block_scalar_2: dict[str, Any] = match_value_8
                                                                    handles_3_mut = handles_3
                                                                    restlist_mut = rest_19
                                                                    acc_mut = cons(YAMLElement(1, YAMLContent_create_Z1C3A29C9(block_scalar_2["Value"], block_scalar_2["Comment"], block_scalar_2["Props"]["Anchor"], block_scalar_2["Props"]["Tag"], ScalarStyle(3, block_scalar_2["Style"], block_scalar_2["Chomp"], block_scalar_2["Indent"]))), acc)
                                                                    continue


                                                            elif pattern_matching_result_15 == 3:
                                                                (pattern_matching_result_16, rest_21, v_26) = (None, None, None)
                                                                if not is_empty_1(restlist):
                                                                    active_pattern_result_29: dict[str, Any] | None = _007CYamlValue_007C__007C(head(restlist))
                                                                    if active_pattern_result_29 is not None:
                                                                        def _arrow733(__unit: None=None, handles_3: Any=handles_3, restlist: Any=restlist, acc: Any=acc) -> bool:
                                                                            v_25: dict[str, Any] = active_pattern_result_29
                                                                            return (v_25["Comment"] is None) if (v_25["Value"] == "") else False

                                                                        if _arrow733():
                                                                            pattern_matching_result_16 = 0
                                                                            rest_21 = tail_4(restlist)
                                                                            v_26 = active_pattern_result_29

                                                                        else: 
                                                                            pattern_matching_result_16 = 1


                                                                    else: 
                                                                        pattern_matching_result_16 = 1


                                                                else: 
                                                                    pattern_matching_result_16 = 1

                                                                if pattern_matching_result_16 == 0:
                                                                    handles_3_mut = handles_3
                                                                    restlist_mut = rest_21
                                                                    acc_mut = acc
                                                                    continue

                                                                elif pattern_matching_result_16 == 1:
                                                                    if is_empty_1(restlist):
                                                                        return YAMLElement(3, reverse(acc))

                                                                    else: 
                                                                        active_pattern_result_30: dict[str, Any] | None = _007CYamlValue_007C__007C(head(restlist))
                                                                        if active_pattern_result_30 is not None:
                                                                            v_27: dict[str, Any] = active_pattern_result_30
                                                                            c_6: str | None = restore_comment_replace(comment_dict, v_27["Comment"])
                                                                            props_6: dict[str, Any] = extract_properties(handles_3, v_27["Value"])
                                                                            pattern_input_2: tuple[str, ScalarStyle | None]
                                                                            raw: str = props_6["Value"]
                                                                            match_value: int | None = try_parse_exact_placeholder_index(raw)
                                                                            if match_value is None:
                                                                                pattern_input_2 = (restore_string_replace(string_dict, raw), None)

                                                                            else: 
                                                                                entry: StringMapEntry = get_item_from_dict(string_dict, match_value)
                                                                                pattern_input_2 = (restore_scalar_placeholder_value(entry), ScalarStyle(2) if (entry.Kind.tag == 1) else ScalarStyle(1))

                                                                            handles_3_mut = handles_3
                                                                            restlist_mut = tail_4(restlist)
                                                                            acc_mut = cons(YAMLElement(1, YAMLContent_create_Z1C3A29C9(pattern_input_2[0], c_6, props_6["Anchor"], props_6["Tag"], pattern_input_2[1])), acc)
                                                                            continue

                                                                        else: 
                                                                            return to_fail(printf("Unknown pattern: %A"))(restlist)
















            break

    return loop_read(handles, transform_elements(ctx, yaml_list), empty())


def read(yaml: str) -> YAMLElement:
    ast: Preprocessor = read_1(yaml)
    match_value: PreprocessorElement = ast.AST
    if match_value.tag == 0:
        return tokenize(match_value.fields[0], ast.StringMap, ast.CommentMap, ast.TagHandles)

    else: 
        raise Exception("Not a root!")



def is_stream_document_marker(marker_check: Callable[[str], bool], line: str) -> bool:
    if count_leading_spaces(line) == 0:
        return marker_check(line)

    else: 
        return False



def try_inline_content_after_start_marker(line: str) -> str | None:
    trimmed: str = trim_start(line)
    if not starts_with_exact(trimmed, "---"):
        return None

    else: 
        rest: str = trim_start(substring(trimmed, 3))
        if True if is_null_or_white_space(rest) else starts_with_exact(rest, "#"):
            return None

        else: 
            return rest




def is_directive_prelude_line(line: str) -> bool:
    t: str = trim_start(line)
    if True if (t == "") else starts_with_exact(t, "%"):
        return True

    else: 
        return starts_with_exact(t, "#")



def is_directive_prelude_only(lines: FSharpList[str]) -> bool:
    def predicate(line: str, lines: Any=lines) -> bool:
        return starts_with_exact(trim_start(line), "%")

    if exists(predicate, lines):
        def _arrow737(line_1: str, lines: Any=lines) -> bool:
            return is_directive_prelude_line(line_1)

        return for_all(_arrow737, lines)

    else: 
        return False



def try_detect_block_scalar_header_indent(line: str) -> int | None:
    trimmed: str = trim_start(line)
    after_dash: str = trim_start(substring(trimmed, 2)) if starts_with_exact(trimmed, "- ") else trimmed
    def _arrow739(__unit: None=None, line: Any=line) -> str:
        def loop(current_mut: str) -> str:
            while True:
                (current,) = (current_mut,)
                c: str = trim_start(current)
                if starts_with_exact(c, "&"):
                    idx: int = c.find(" ") or 0
                    if idx < 0:
                        return ""

                    else: 
                        current_mut = substring(c, idx + 1)
                        continue


                elif starts_with_exact(c, "!<"):
                    idx_1: int = c.find(">") or 0
                    if idx_1 < 0:
                        return c

                    else: 
                        current_mut = substring(c, idx_1 + 1)
                        continue


                elif (not starts_with_exact(c, ">")) if ((not starts_with_exact(c, "|")) if starts_with_exact(c, "!") else False) else False:
                    idx_2: int = c.find(" ") or 0
                    if idx_2 < 0:
                        return ""

                    else: 
                        current_mut = substring(c, idx_2 + 1)
                        continue


                else: 
                    return c

                break

        def _arrow738(__unit: None=None) -> str:
            idx_3: int = after_dash.find(":") or 0
            return trim_start(substring(after_dash, idx_3 + 1)) if (idx_3 >= 0) else after_dash

        return loop(_arrow738())

    header_token: str | None = try_head(split_1(_arrow739(), [" ", "\t"], None, 1))
    (pattern_matching_result,) = (None,)
    if header_token is not None:
        if parse_block_scalar_header(header_token) is not None:
            pattern_matching_result = 0

        else: 
            pattern_matching_result = 1


    else: 
        pattern_matching_result = 1

    if pattern_matching_result == 0:
        return count_leading_spaces(line)

    elif pattern_matching_result == 1:
        return None



def read_documents(yaml: str) -> FSharpList[YAMLElement]:
    def append_current_document(current_doc: FSharpList[str], docs: FSharpList[FSharpList[str]], yaml: Any=yaml) -> FSharpList[FSharpList[str]]:
        if is_empty_1(current_doc):
            return docs

        else: 
            return cons(reverse(current_doc), docs)


    def split_documents(remaining_mut: FSharpList[str], current_doc_1_mut: FSharpList[str], docs_1_mut: FSharpList[FSharpList[str]], block_header_indent_mut: int | None, yaml: Any=yaml) -> FSharpList[FSharpList[str]]:
        while True:
            (remaining, current_doc_1, docs_1, block_header_indent) = (remaining_mut, current_doc_1_mut, docs_1_mut, block_header_indent_mut)
            if not is_empty_1(remaining):
                rest: FSharpList[str] = tail_4(remaining)
                line: str = head(remaining)
                if block_header_indent is None:
                    def _arrow740(line_1: str, remaining: Any=remaining, current_doc_1: Any=current_doc_1, docs_1: Any=docs_1, block_header_indent: Any=block_header_indent) -> bool:
                        return is_document_start(line_1)

                    if is_stream_document_marker(_arrow740, line):
                        inline_content: str | None = try_inline_content_after_start_marker(line)
                        if True if is_empty_1(current_doc_1) else is_directive_prelude_only(current_doc_1):
                            def predicate(l: str, remaining: Any=remaining, current_doc_1: Any=current_doc_1, docs_1: Any=docs_1, block_header_indent: Any=block_header_indent) -> bool:
                                return starts_with_exact(trim_start(l), "%")

                            prelude_directives: FSharpList[str] = filter(predicate, current_doc_1)
                            remaining_mut = rest
                            current_doc_1_mut = prelude_directives if (inline_content is None) else cons(inline_content, prelude_directives)
                            docs_1_mut = docs_1
                            block_header_indent_mut = None
                            continue

                        else: 
                            docs_0027: FSharpList[FSharpList[str]] = append_current_document(current_doc_1, docs_1)
                            remaining_mut = rest
                            current_doc_1_mut = empty() if (inline_content is None) else singleton_1(inline_content)
                            docs_1_mut = docs_0027
                            block_header_indent_mut = None
                            continue


                    else: 
                        def _arrow741(line_2: str, remaining: Any=remaining, current_doc_1: Any=current_doc_1, docs_1: Any=docs_1, block_header_indent: Any=block_header_indent) -> bool:
                            return is_document_end(line_2)

                        if is_stream_document_marker(_arrow741, line):
                            remaining_mut = rest
                            current_doc_1_mut = empty()
                            docs_1_mut = append_current_document(current_doc_1, docs_1)
                            block_header_indent_mut = None
                            continue

                        else: 
                            remaining_mut = rest
                            current_doc_1_mut = cons(line, current_doc_1)
                            docs_1_mut = docs_1
                            def _arrow742(__unit: None=None, remaining: Any=remaining, current_doc_1: Any=current_doc_1, docs_1: Any=docs_1, block_header_indent: Any=block_header_indent) -> int | None:
                                match_value: int | None = try_detect_block_scalar_header_indent(line)
                                return None if (match_value is None) else match_value

                            block_header_indent_mut = _arrow742()
                            continue



                else: 
                    header_indent: int = block_header_indent or 0
                    if True if (line.strip() == "") else (count_leading_spaces(line) > header_indent):
                        remaining_mut = rest
                        current_doc_1_mut = cons(line, current_doc_1)
                        docs_1_mut = docs_1
                        block_header_indent_mut = block_header_indent
                        continue

                    else: 
                        remaining_mut = remaining
                        current_doc_1_mut = current_doc_1
                        docs_1_mut = docs_1
                        block_header_indent_mut = None
                        continue



            else: 
                return reverse(append_current_document(current_doc_1, docs_1))

            break

    def mapping(doc_lines: FSharpList[str], yaml: Any=yaml) -> YAMLElement:
        return read(join("\n", doc_lines))

    def predicate_2(doc: FSharpList[str], yaml: Any=yaml) -> bool:
        def predicate_1(l_1: str, doc: Any=doc) -> bool:
            return l_1.strip() != ""

        return exists(predicate_1, doc)

    return map(mapping, filter(predicate_2, split_documents(of_array(split_1(replace_1(replace_1(yaml, "\r\n", "\n"), "\r", "\n"), ["\n"], None, 0)), empty(), empty(), None)))


__all__ = ["restore_scalar_placeholder_value", "restore_block_scalar_placeholder_value", "try_parse_exact_placeholder_index", "restore_string_replace", "parse_block_scalar_header", "apply_chomping", "count_leading_spaces", "split_trailing_comment_placeholder", "strip_block_indent", "fold_lines", "deindent_block_lines", "build_block_scalar_content", "restore_comment_replace", "collect_sequence_elements", "is_sequence_element", "tokenize", "read", "is_stream_document_marker", "try_inline_content_after_start_marker", "is_directive_prelude_line", "is_directive_prelude_only", "try_detect_block_scalar_header_indent", "read_documents"]

