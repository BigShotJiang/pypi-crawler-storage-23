from __future__ import annotations
from typing import Any
from ..fable_modules.fable_library.array_ import (filter, map_indexed, append, last)
from ..fable_modules.fable_library.char import is_letter
from ..fable_modules.fable_library.list import (of_array, FSharpList)
from ..fable_modules.fable_library.string_ import (split as split_1, starts_with_exact, substring, ends_with_exact, join, trim_end, trim_start, trim)
from ..fable_modules.fable_library.types import Array

seperators: Array[str] = ["/", "\\"]

alternative_licensefile_names: FSharpList[str] = of_array(["LICENSE.txt", "LICENSE.md", "LICENSE.rst"])

def split(path: str) -> Array[str]:
    def predicate(p: str, path: Any=path) -> bool:
        if p != "":
            return p != "."

        else: 
            return False


    return filter(predicate, split_1(path, seperators, None, 3))


def has_leading_separator(path: str) -> bool:
    if len(path) > 0:
        if path[0] == "/":
            return True

        else: 
            return path[0] == "\\"


    else: 
        return False



def is_unc_path(path: str) -> bool:
    if starts_with_exact(path, "//"):
        return True

    else: 
        return starts_with_exact(path, "\\\\")



def try_get_drive_prefix(path: str) -> str | None:
    if (True if (path[2] == "/") else (path[2] == "\\")) if ((path[1] == ":") if (is_letter(path[0]) if (len(path) > 2) else False) else False) else False:
        return substring(path, 0, 2)

    else: 
        return None



def split_with_prefix(path: str) -> tuple[str | None, Array[str]]:
    trimmed: str = path.strip()
    match_value: str | None = try_get_drive_prefix(trimmed)
    if match_value is None:
        if is_unc_path(trimmed):
            return ("//", split(trimmed))

        elif has_leading_separator(trimmed):
            return ("/", split(trimmed))

        else: 
            return (None, split(trimmed))


    else: 
        return (match_value, split(substring(trimmed, 2)))



def normalize_root_prefix(prefix: str) -> str:
    if prefix == "//":
        return "//"

    elif ends_with_exact(prefix, ":"):
        return ("" + prefix) + "/"

    else: 
        return "/"



def build_path_from_prefix_and_segments(prefix_opt: str | None, segments: Array[str]) -> str:
    if len(segments) == 0:
        if prefix_opt is None:
            return ""

        else: 
            return normalize_root_prefix(prefix_opt)


    else: 
        combined: str = join("/", segments)
        (pattern_matching_result, prefix_3, prefix_4) = (None, None, None)
        if prefix_opt is None:
            pattern_matching_result = 4

        elif prefix_opt == "//":
            pattern_matching_result = 0

        elif prefix_opt == "/":
            if ends_with_exact(prefix_opt, ":"):
                pattern_matching_result = 1
                prefix_3 = prefix_opt

            else: 
                pattern_matching_result = 2


        elif ends_with_exact(prefix_opt, ":"):
            pattern_matching_result = 1
            prefix_3 = prefix_opt

        else: 
            pattern_matching_result = 3
            prefix_4 = prefix_opt

        if pattern_matching_result == 0:
            return ("//" + combined) + ""

        elif pattern_matching_result == 1:
            return ((("" + prefix_3) + "/") + combined) + ""

        elif pattern_matching_result == 2:
            return ("/" + combined) + ""

        elif pattern_matching_result == 3:
            return ((("" + prefix_4) + "/") + combined) + ""

        elif pattern_matching_result == 4:
            return combined




def combine(path1: str, path2: str) -> str:
    return (trim_end(path1, *seperators) + "/") + trim_start(path2, *seperators)


def combine_many(paths: Array[str]) -> str:
    def mapping(i: int, p: str, paths: Any=paths) -> str:
        if i == 0:
            return trim_end(p, *seperators)

        elif i == (len(paths) - 1):
            return trim_start(p, *seperators)

        else: 
            return trim(p, *seperators)


    return join("/", map_indexed(mapping, paths, None))


def normalize_segments(segments: Array[str]) -> Array[str]:
    resolved: Array[str] = []
    for idx in range(0, (len(segments) - 1) + 1, 1):
        raw_segment: str = segments[idx]
        segment: str = raw_segment.strip()
        if True if (segment == "") else (segment == "."):
            pass

        elif segment == "..":
            if (resolved[len(resolved) - 1] != "..") if (len(resolved) > 0) else False:
                resolved.pop(len(resolved) - 1)

            else: 
                (resolved.append(segment))


        else: 
            (resolved.append(segment))

    return resolved[:]


def normalize(path: str) -> str:
    trimmed_path: str = path.strip()
    pattern_input: tuple[str | None, Array[str]] = split_with_prefix(trimmed_path)
    prefix_opt: str | None = pattern_input[0]
    normalized_segments: Array[str] = normalize_segments(pattern_input[1])
    if len(normalized_segments) == 0:
        if prefix_opt is None:
            return trimmed_path

        else: 
            return normalize_root_prefix(prefix_opt)


    else: 
        return build_path_from_prefix_and_segments(prefix_opt, normalized_segments)



def normalize_path_key(path: str) -> str:
    normalized: str = normalize(path)
    if normalized == "":
        return path.strip()

    else: 
        trimmed_leading_separators: str = trim_start(normalized, *seperators)
        if trimmed_leading_separators == "":
            return normalized

        else: 
            return trimmed_leading_separators




def resolve_path_from_file(file_path: str, path: str) -> str:
    trimmed_path: str = path.strip()
    pattern_input: tuple[str | None, Array[str]] = split_with_prefix(trimmed_path)
    if pattern_input[0] is not None:
        return normalize(trimmed_path)

    else: 
        pattern_input_1: tuple[str | None, Array[str]] = split_with_prefix(file_path)
        file_prefix_opt: str | None = pattern_input_1[0]
        file_path_segments: Array[str] = pattern_input_1[1]
        resolved_segments: Array[str] = normalize_segments(append([] if (len(file_path_segments) <= 1) else file_path_segments[0:(len(file_path_segments) - 2) + 1], pattern_input[1], None))
        if len(resolved_segments) == 0:
            if file_prefix_opt is None:
                return trimmed_path

            else: 
                return normalize_root_prefix(file_prefix_opt)


        else: 
            return build_path_from_prefix_and_segments(file_prefix_opt, resolved_segments)




def get_file_name(path: str) -> str:
    return last(split(path))


def is_file(file_name: str, path: str) -> bool:
    return get_file_name(path) == file_name


def get_assay_folder_path(assay_identifier: str) -> str:
    return combine("assays", assay_identifier)


def get_study_folder_path(study_identifier: str) -> str:
    return combine("studies", study_identifier)


def get_workflow_folder_path(workflow_identifier: str) -> str:
    return combine("workflows", workflow_identifier)


def get_run_folder_path(run_identifier: str) -> str:
    return combine("runs", run_identifier)


__all__ = ["seperators", "alternative_licensefile_names", "split", "has_leading_separator", "is_unc_path", "try_get_drive_prefix", "split_with_prefix", "normalize_root_prefix", "build_path_from_prefix_and_segments", "combine", "combine_many", "normalize_segments", "normalize", "normalize_path_key", "resolve_path_from_file", "get_file_name", "is_file", "get_assay_folder_path", "get_study_folder_path", "get_workflow_folder_path", "get_run_folder_path"]

