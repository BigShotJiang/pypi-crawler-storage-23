from __future__ import annotations
from ..fable_modules.dynamic_obj.dynamic_obj import (DynamicObj, DynamicObj_reflection)
from ..fable_modules.fable_library.option import default_arg
from ..fable_modules.fable_library.reflection import (TypeInfo, class_type)
from ..fable_modules.fable_library.types import Array
from .inputs import CWLInput
from .outputs import CWLOutput
from .requirements import (Requirement, HintEntry)

def _expr814() -> TypeInfo:
    return class_type("ARCtrl.CWL.CWLToolDescription", None, CWLToolDescription, DynamicObj_reflection())


class CWLToolDescription(DynamicObj):
    def __init__(self, outputs: Array[CWLOutput], cwl_version: str | None=None, base_command: Array[str] | None=None, requirements: Array[Requirement] | None=None, hints: Array[HintEntry] | None=None, intent: Array[str] | None=None, inputs: Array[CWLInput] | None=None, metadata: DynamicObj | None=None, label: str | None=None, doc: str | None=None) -> None:
        super().__init__()
        self._cwlVersion: str = default_arg(cwl_version, "v1.2")
        self._outputs: Array[CWLOutput] = outputs
        self._baseCommand: Array[str] | None = base_command
        self._requirements: Array[Requirement] | None = requirements
        self._hints: Array[HintEntry] | None = hints
        self._intent: Array[str] | None = intent
        self._inputs: Array[CWLInput] | None = inputs
        self._metadata: DynamicObj | None = metadata
        self._label: str | None = label
        self._doc: str | None = doc

    @property
    def CWLVersion(self, __unit: None=None) -> str:
        this: CWLToolDescription = self
        return this._cwlVersion

    @CWLVersion.setter
    def CWLVersion(self, version: str) -> None:
        this: CWLToolDescription = self
        this._cwlVersion = version

    @property
    def Outputs(self, __unit: None=None) -> Array[CWLOutput]:
        this: CWLToolDescription = self
        return this._outputs

    @Outputs.setter
    def Outputs(self, outputs: Array[CWLOutput]) -> None:
        this: CWLToolDescription = self
        this._outputs = outputs

    @property
    def BaseCommand(self, __unit: None=None) -> Array[str] | None:
        this: CWLToolDescription = self
        return this._baseCommand

    @BaseCommand.setter
    def BaseCommand(self, base_command: Array[str] | None=None) -> None:
        this: CWLToolDescription = self
        this._baseCommand = base_command

    @property
    def Requirements(self, __unit: None=None) -> Array[Requirement] | None:
        this: CWLToolDescription = self
        return this._requirements

    @Requirements.setter
    def Requirements(self, requirements: Array[Requirement] | None=None) -> None:
        this: CWLToolDescription = self
        this._requirements = requirements

    @property
    def Hints(self, __unit: None=None) -> Array[HintEntry] | None:
        this: CWLToolDescription = self
        return this._hints

    @Hints.setter
    def Hints(self, hints: Array[HintEntry] | None=None) -> None:
        this: CWLToolDescription = self
        this._hints = hints

    @property
    def Intent(self, __unit: None=None) -> Array[str] | None:
        this: CWLToolDescription = self
        return this._intent

    @Intent.setter
    def Intent(self, intent: Array[str] | None=None) -> None:
        this: CWLToolDescription = self
        this._intent = intent

    @property
    def Inputs(self, __unit: None=None) -> Array[CWLInput] | None:
        this: CWLToolDescription = self
        return this._inputs

    @Inputs.setter
    def Inputs(self, inputs: Array[CWLInput] | None=None) -> None:
        this: CWLToolDescription = self
        this._inputs = inputs

    @property
    def Metadata(self, __unit: None=None) -> DynamicObj | None:
        this: CWLToolDescription = self
        return this._metadata

    @Metadata.setter
    def Metadata(self, metadata: DynamicObj | None=None) -> None:
        this: CWLToolDescription = self
        this._metadata = metadata

    @property
    def Label(self, __unit: None=None) -> str | None:
        this: CWLToolDescription = self
        return this._label

    @Label.setter
    def Label(self, label: str | None=None) -> None:
        this: CWLToolDescription = self
        this._label = label

    @property
    def Doc(self, __unit: None=None) -> str | None:
        this: CWLToolDescription = self
        return this._doc

    @Doc.setter
    def Doc(self, doc: str | None=None) -> None:
        this: CWLToolDescription = self
        this._doc = doc

    @staticmethod
    def get_inputs_or_empty(tool: CWLToolDescription) -> Array[CWLInput]:
        return default_arg(tool.Inputs, [])

    @staticmethod
    def get_outputs(tool: CWLToolDescription) -> Array[CWLOutput]:
        return tool.Outputs

    @staticmethod
    def get_or_create_inputs(tool: CWLToolDescription) -> Array[CWLInput]:
        match_value: Array[CWLInput] | None = tool.Inputs
        if match_value is None:
            inputs_1: Array[CWLInput] = []
            tool.Inputs = inputs_1
            return inputs_1

        else: 
            return match_value


    @staticmethod
    def get_requirements_or_empty(tool: CWLToolDescription) -> Array[Requirement]:
        return default_arg(tool.Requirements, [])

    @staticmethod
    def get_hints_or_empty(tool: CWLToolDescription) -> Array[HintEntry]:
        return default_arg(tool.Hints, [])

    @staticmethod
    def get_intent_or_empty(tool: CWLToolDescription) -> Array[str]:
        return default_arg(tool.Intent, [])

    @staticmethod
    def get_or_create_hints(tool: CWLToolDescription) -> Array[HintEntry]:
        match_value: Array[HintEntry] | None = tool.Hints
        if match_value is None:
            hints_1: Array[HintEntry] = []
            tool.Hints = hints_1
            return hints_1

        else: 
            return match_value


    @staticmethod
    def get_or_create_intent(tool: CWLToolDescription) -> Array[str]:
        match_value: Array[str] | None = tool.Intent
        if match_value is None:
            intent_1: Array[str] = []
            tool.Intent = intent_1
            return intent_1

        else: 
            return match_value



CWLToolDescription_reflection = _expr814

def CWLToolDescription__ctor_Z4F3AD956(outputs: Array[CWLOutput], cwl_version: str | None=None, base_command: Array[str] | None=None, requirements: Array[Requirement] | None=None, hints: Array[HintEntry] | None=None, intent: Array[str] | None=None, inputs: Array[CWLInput] | None=None, metadata: DynamicObj | None=None, label: str | None=None, doc: str | None=None) -> CWLToolDescription:
    return CWLToolDescription(outputs, cwl_version, base_command, requirements, hints, intent, inputs, metadata, label, doc)


__all__ = ["CWLToolDescription_reflection"]

