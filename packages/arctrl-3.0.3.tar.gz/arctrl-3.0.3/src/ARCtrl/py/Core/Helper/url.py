from collections.abc import Callable
from typing import Any
from ...fable_modules.fable_library.util import to_enumerable
from .collections_ import (Dictionary_ofSeq, Dictionary_tryFind)

def OntobeeParser(tsr: str, local_tan: str) -> str:
    return ((((("" + "http://purl.obolibrary.org/obo/") + "") + tsr) + "_") + local_tan) + ""


def BioregistryParser(tsr: str, local_tan: str) -> str:
    return ((((("" + "https://bioregistry.io/") + "") + tsr) + ":") + local_tan) + ""


def OntobeeDPBOParser(tsr: str, local_tan: str) -> str:
    return ((((("" + "http://purl.org/nfdi4plants/ontology/dpbo/") + "") + tsr) + "_") + local_tan) + ""


def MSParser(tsr: str, local_tan: str) -> str:
    return ((((("" + "https://www.ebi.ac.uk/ols4/ontologies/ms/classes/http%253A%252F%252Fpurl.obolibrary.org%252Fobo%252F") + "") + tsr) + "_") + local_tan) + ""


def POParser(tsr: str, local_tan: str) -> str:
    return ((((("" + "https://www.ebi.ac.uk/ols4/ontologies/po/classes/http%253A%252F%252Fpurl.obolibrary.org%252Fobo%252F") + "") + tsr) + "_") + local_tan) + ""


def ROParser(tsr: str, local_tan: str) -> str:
    return ((((("" + "https://www.ebi.ac.uk/ols4/ontologies/ro/classes/http%253A%252F%252Fpurl.obolibrary.org%252Fobo%252F") + "") + tsr) + "_") + local_tan) + ""


def _arrow823(tsr: str) -> Callable[[str], str]:
    def _arrow822(local_tan: str) -> str:
        return OntobeeDPBOParser(tsr, local_tan)

    return _arrow822


def _arrow825(tsr_1: str) -> Callable[[str], str]:
    def _arrow824(local_tan_1: str) -> str:
        return MSParser(tsr_1, local_tan_1)

    return _arrow824


def _arrow827(tsr_2: str) -> Callable[[str], str]:
    def _arrow826(local_tan_2: str) -> str:
        return POParser(tsr_2, local_tan_2)

    return _arrow826


def _arrow829(tsr_3: str) -> Callable[[str], str]:
    def _arrow828(local_tan_3: str) -> str:
        return ROParser(tsr_3, local_tan_3)

    return _arrow828


def _arrow831(tsr_4: str) -> Callable[[str], str]:
    def _arrow830(local_tan_4: str) -> str:
        return BioregistryParser(tsr_4, local_tan_4)

    return _arrow830


def _arrow833(tsr_5: str) -> Callable[[str], str]:
    def _arrow832(local_tan_5: str) -> str:
        return BioregistryParser(tsr_5, local_tan_5)

    return _arrow832


def _arrow835(tsr_6: str) -> Callable[[str], str]:
    def _arrow834(local_tan_6: str) -> str:
        return BioregistryParser(tsr_6, local_tan_6)

    return _arrow834


def _arrow837(tsr_7: str) -> Callable[[str], str]:
    def _arrow836(local_tan_7: str) -> str:
        return BioregistryParser(tsr_7, local_tan_7)

    return _arrow836


def _arrow839(tsr_8: str) -> Callable[[str], str]:
    def _arrow838(local_tan_8: str) -> str:
        return BioregistryParser(tsr_8, local_tan_8)

    return _arrow838


def _arrow841(tsr_9: str) -> Callable[[str], str]:
    def _arrow840(local_tan_9: str) -> str:
        return BioregistryParser(tsr_9, local_tan_9)

    return _arrow840


def _arrow843(tsr_10: str) -> Callable[[str], str]:
    def _arrow842(local_tan_10: str) -> str:
        return BioregistryParser(tsr_10, local_tan_10)

    return _arrow842


def _arrow845(tsr_11: str) -> Callable[[str], str]:
    def _arrow844(local_tan_11: str) -> str:
        return BioregistryParser(tsr_11, local_tan_11)

    return _arrow844


def _arrow847(tsr_12: str) -> Callable[[str], str]:
    def _arrow846(local_tan_12: str) -> str:
        return BioregistryParser(tsr_12, local_tan_12)

    return _arrow846


def _arrow849(tsr_13: str) -> Callable[[str], str]:
    def _arrow848(local_tan_13: str) -> str:
        return BioregistryParser(tsr_13, local_tan_13)

    return _arrow848


def _arrow851(tsr_14: str) -> Callable[[str], str]:
    def _arrow850(local_tan_14: str) -> str:
        return BioregistryParser(tsr_14, local_tan_14)

    return _arrow850


uri_parser_collection: Any = Dictionary_ofSeq(to_enumerable([("DPBO", _arrow823), ("MS", _arrow825), ("PO", _arrow827), ("RO", _arrow829), ("ENVO", _arrow831), ("CHEBI", _arrow833), ("GO", _arrow835), ("OBI", _arrow837), ("PATO", _arrow839), ("PECO", _arrow841), ("TO", _arrow843), ("UO", _arrow845), ("EFO", _arrow847), ("NCIT", _arrow849), ("OMP", _arrow851)]))

def create_oauri(tsr: str, local_tan: str) -> str:
    match_value: Callable[[str, str], str] | None = Dictionary_tryFind(tsr, uri_parser_collection)
    if match_value is None:
        return OntobeeParser(tsr, local_tan)

    else: 
        return match_value(tsr)(local_tan)



__all__ = ["OntobeeParser", "BioregistryParser", "OntobeeDPBOParser", "MSParser", "POParser", "ROParser", "uri_parser_collection", "create_oauri"]

