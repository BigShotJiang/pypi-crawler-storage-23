from __future__ import annotations
from typing import Any
from ..fable_modules.fable_library.reflection import (TypeInfo, class_type)
from ..fable_modules.fable_library.types import Array
from .comment import Comment
from .data import (Data, Data_reflection)
from .data_file import DataFile
from .Helper.hash_codes import (box_hash_array, box_hash_option, box_hash_seq, hash_1)
from .ontology_annotation import OntologyAnnotation
from .value import Value as Value_1

def _expr1104() -> TypeInfo:
    return class_type("ARCtrl.DataContext", None, DataContext, Data_reflection())


class DataContext(Data):
    def __init__(self, id: str | None=None, name: str | None=None, data_type: DataFile | None=None, format: str | None=None, selector_format: str | None=None, explication: OntologyAnnotation | None=None, unit: OntologyAnnotation | None=None, object_type: OntologyAnnotation | None=None, label: str | None=None, description: str | None=None, generated_by: str | None=None, comments: Array[Comment] | None=None) -> None:
        super().__init__(id, name, data_type, format, selector_format, comments)
        self._explication: OntologyAnnotation | None = explication
        self._unit: OntologyAnnotation | None = unit
        self._objectType: OntologyAnnotation | None = object_type
        self._label: str | None = label
        self._description: str | None = description
        self._generatedBy: str | None = generated_by

    @property
    def Explication(self, __unit: None=None) -> OntologyAnnotation | None:
        this: DataContext = self
        return this._explication

    @Explication.setter
    def Explication(self, explication: OntologyAnnotation | None=None) -> None:
        this: DataContext = self
        this._explication = explication

    @property
    def Unit(self, __unit: None=None) -> OntologyAnnotation | None:
        this: DataContext = self
        return this._unit

    @Unit.setter
    def Unit(self, unit: OntologyAnnotation | None=None) -> None:
        this: DataContext = self
        this._unit = unit

    @property
    def ObjectType(self, __unit: None=None) -> OntologyAnnotation | None:
        this: DataContext = self
        return this._objectType

    @ObjectType.setter
    def ObjectType(self, object_type: OntologyAnnotation | None=None) -> None:
        this: DataContext = self
        this._objectType = object_type

    @property
    def Label(self, __unit: None=None) -> str | None:
        this: DataContext = self
        return this._label

    @Label.setter
    def Label(self, label: str | None=None) -> None:
        this: DataContext = self
        this._label = label

    @property
    def Description(self, __unit: None=None) -> str | None:
        this: DataContext = self
        return this._description

    @Description.setter
    def Description(self, description: str | None=None) -> None:
        this: DataContext = self
        this._description = description

    @property
    def GeneratedBy(self, __unit: None=None) -> str | None:
        this: DataContext = self
        return this._generatedBy

    @GeneratedBy.setter
    def GeneratedBy(self, generated_by: str | None=None) -> None:
        this: DataContext = self
        this._generatedBy = generated_by

    def AsData(self, __unit: None=None) -> Data:
        this: DataContext = self
        return Data(this.ID, this.Name, this.DataType, this.Format, this.SelectorFormat, this.Comments)

    @staticmethod
    def from_data(data: Data, explication: OntologyAnnotation | None=None, unit: OntologyAnnotation | None=None, object_type: OntologyAnnotation | None=None, label: str | None=None, description: str | None=None, generated_by: str | None=None) -> DataContext:
        return DataContext(data.ID, data.Name, data.DataType, data.Format, data.SelectorFormat, explication, unit, object_type, label, description, generated_by, data.Comments)

    @staticmethod
    def create_as_pv(alternate_name: str | None=None, measurement_method: str | None=None, description: str | None=None, category: OntologyAnnotation | None=None, value: Value_1 | None=None, unit: OntologyAnnotation | None=None) -> DataContext:
        def _arrow1102(__unit: None=None) -> OntologyAnnotation | None:
            oa: OntologyAnnotation = value.fields[0]
            return oa

        def _arrow1103(__unit: None=None) -> OntologyAnnotation | None:
            v: Value_1 = value
            return OntologyAnnotation(v.Text)

        return DataContext(None, None, None, None, None, category, unit, None if (value is None) else (_arrow1102() if (value.tag == 0) else _arrow1103()), alternate_name, description, measurement_method)

    def Copy(self, __unit: None=None) -> DataContext:
        this: DataContext = self
        copy: DataContext = DataContext()
        copy.ID = this.ID
        copy.Name = this.Name
        copy.DataType = this.DataType
        copy.Format = this.Format
        copy.SelectorFormat = this.SelectorFormat
        copy.Explication = this.Explication
        copy.Unit = this.Unit
        copy.ObjectType = this.ObjectType
        copy.Description = this.Description
        copy.GeneratedBy = this.GeneratedBy
        copy.Comments = this.Comments
        return copy

    def __hash__(self, __unit: None=None) -> Any:
        this: DataContext = self
        return box_hash_array([box_hash_option(this.ID), box_hash_option(this.Name), box_hash_option(this.DataType), box_hash_option(this.Format), box_hash_option(this.SelectorFormat), box_hash_seq(this.Comments), box_hash_option(this.Explication), box_hash_option(this.Unit), box_hash_option(this.ObjectType), box_hash_option(this.Label), box_hash_option(this.Description), box_hash_option(this.GeneratedBy)])

    def __eq__(self, obj: Any=None) -> bool:
        this: DataContext = self
        return hash_1(this) == hash_1(obj)


DataContext_reflection = _expr1104

def DataContext__ctor_Z780A8A2A(id: str | None=None, name: str | None=None, data_type: DataFile | None=None, format: str | None=None, selector_format: str | None=None, explication: OntologyAnnotation | None=None, unit: OntologyAnnotation | None=None, object_type: OntologyAnnotation | None=None, label: str | None=None, description: str | None=None, generated_by: str | None=None, comments: Array[Comment] | None=None) -> DataContext:
    return DataContext(id, name, data_type, format, selector_format, explication, unit, object_type, label, description, generated_by, comments)


__all__ = ["DataContext_reflection"]

