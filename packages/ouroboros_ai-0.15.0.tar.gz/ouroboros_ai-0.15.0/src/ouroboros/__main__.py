"""Ouroboros CLI entry point.

This module serves as the main entry point for the Ouroboros CLI.
"""

from ouroboros import main

if __name__ == "__main__":
    main()
