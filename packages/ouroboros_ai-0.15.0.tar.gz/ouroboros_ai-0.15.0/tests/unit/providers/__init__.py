"""Unit tests for ouroboros.providers module."""
