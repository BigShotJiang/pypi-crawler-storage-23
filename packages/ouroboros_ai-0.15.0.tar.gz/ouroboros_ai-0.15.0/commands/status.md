---
description: "Check session status and measure goal drift"
aliases: [drift]
---

Read the file at `${CLAUDE_PLUGIN_ROOT}/skills/status/SKILL.md` using the Read tool and follow its instructions exactly.
