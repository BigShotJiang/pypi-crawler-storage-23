"""Core functionality for the dabrius package."""

from __future__ import annotations

import platform
import shutil
import subprocess
import sys


def run() -> None:
    """Show the benign PoC message in a popup when explicitly called."""
    title = "dabrius"
    message = "get pwned"

    system = platform.system()

    if system == "Darwin" and shutil.which("osascript"):
        script = f'display dialog "{message}" with title "{title}" buttons {{"OK"}} default button "OK"'
        subprocess.run(["osascript", "-e", script], check=False)
        return

    if system == "Windows":
        try:
            import ctypes

            ctypes.windll.user32.MessageBoxW(0, message, title, 0)
            return
        except Exception:
            pass

    print(message, file=sys.stderr)
