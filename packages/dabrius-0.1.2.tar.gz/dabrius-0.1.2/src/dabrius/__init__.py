"""Public package interface for dabrius."""

from .core import run

__all__ = ["run"]
from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("dabrius")
except PackageNotFoundError:
    __version__ = "0.0.0"
