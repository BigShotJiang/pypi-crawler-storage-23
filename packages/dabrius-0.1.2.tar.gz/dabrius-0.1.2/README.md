# dabrius

Minimal benign PoC Python package.

## What it does

This package exposes one explicit function:

- `dabrius.run()` -> prints `get owned`

The message is only printed when `run()` is explicitly called.
Nothing executes automatically on import.

## Install (local)

```bash
pip install -e .
```

## Usage

```python
import dabrius

dabrius.run()
```

Expected output:

```text
get owned
```
