[EE][26-01-14 11:43:37][MAIN] Starting device main loop...
[EE][26-01-14 11:43:37][MAIN] Performing auto-warmup of AI Engines: {'lowres_general_detector': OrderedDict()}
[EE][26-01-14 11:43:37][SMGR] `maybe_start_server`: 'TH_YF8S' server NOT available. Attempting to start server...
[EE][26-01-14 11:43:37][SMGR] Creating PARALLEL serving process 'TH_YF8S'(TH_YF8S)...
[EE][26-01-14 11:43:37][SMGR] Attempting to load ServingManager plugin 'TH_YF8S'
[EE][26-01-14 11:43:37][SMGR]     Trying [SAFE]: 'naeural_core.serving.default_inference.th_yf8s' -> FOUND!
[EE][26-01-14 11:43:37][SMGR]   Found safe plugin 'naeural_core.serving.default_inference.th_yf8s'
[EE][26-01-14 11:43:37][SMGR]   Plugin 'TH_YF8S' loaded and code checked from naeural_core.serving.default_inference
[EE][26-01-14 11:43:37][SMGR] Loaded model serving class 'ThYf8s' <class 'naeural_core.serving.default_inference.th_yf8s.ThYf8s'>
[EE][26-01-14 11:43:37][NumpySharedMemory] Initializing shmem 'TH_YF8S' using multiprocessing.SharedMemory
[EE][26-01-14 11:43:37][NumpySharedMemory] Shared memory 'TH_YF8S'[Creator] successfully initialized
[EE][26-01-14 11:43:37][SMGR] Running process <ThYf8s name='ThYf8s-1' parent=1 initial>...
[EE][26-01-14 11:43:38] ###IMPORTANT###
ian 14 09:43:38 teste sh[3722914]:                     ##############################################################################
ian 14 09:43:38 teste sh[3722914]:                     #                                                                            #
ian 14 09:43:38 teste sh[3722914]:                     #          [AMON] INFO: Heartbeat with pipelines status. Current: 0          #
ian 14 09:43:38 teste sh[3722914]:                     #                                                                            #
ian 14 09:43:38 teste sh[3722914]:                     ##############################################################################
ian 14 09:43:38 teste sh[3722914]:
[EE][26-01-14 11:43:38] ###IMPORTANT###
ian 14 09:43:38 teste sh[3722914]:                     ###################################################################################
ian 14 09:43:38 teste sh[3722914]:                     #                                                                                 #
ian 14 09:43:38 teste sh[3722914]:                     #          [AMON] INFO: Heartbeat with active plugins status. Current: 0          #
ian 14 09:43:38 teste sh[3722914]:                     #                                                                                 #
ian 14 09:43:38 teste sh[3722914]:                     ###################################################################################
ian 14 09:43:38 teste sh[3722914]:
[EE][26-01-14 11:43:38] ###IMPORTANT###
ian 14 09:43:38 teste sh[3722914]:                     ###########################################################################################
ian 14 09:43:38 teste sh[3722914]:                     #                                                                                         #
ian 14 09:43:38 teste sh[3722914]:                     #          [AMON] First hb for 0xai_Au2ThBNmSylWXmBmtrY-lNXBcWcmcLEFvdV75HAg26-3          #
ian 14 09:43:38 teste sh[3722914]:                     #                                                                                         #
ian 14 09:43:38 teste sh[3722914]:                     ###########################################################################################
ian 14 09:43:38 teste sh[3722914]:
[EE][26-01-14 11:43:38][MAIN] Heartbeat preparation took 0.323s
[EE][26-01-14 11:43:38] Saving data json: ./_local_cache/_data/local_history.json
[EE][26-01-14 11:43:38][AMON] Elapsed time for saving history: 0.00s
[EE][26-01-14 11:43:38][MAIN] 'teste' v4.2.389/7.7.225/3.4.121 hb:1 itr 0 (0 void), Hz: 0/5, 0.0 hrs, New.pl.: 0, cpu 0.0%, ram(EE) 6.0(0.5)/31.1 GB, cuda:0 0.0%, mem 0.7/7.5GB, 33°C, gpu fan 0%, coretemp.Package id 0 at 51.0°C, wl:0
[EE][26-01-14 11:43:38][MAIN] ===== Notifications =====
[EE][26-01-14 11:43:38][MAIN]   NOTIF: [MQTTCommThread (EE core v7.7.225)] TYPE:NORMAL | CODE:None | TAG: None | EE: teste | STREAM: None | EMAIL: No | MSG: "EE core v7.7.225: MQTT conn ok by 'teste_COMMAND_b9iggbuz' in 0.0s - 172.31.3.70:1883 with subtopic alias" | INFO: EE app v4.2.389, core v7.7.225, SDK v3.4.121, info text: None
[EE][26-01-14 11:43:38][MAIN]   NOTIF: [MQTTCommThread (EE core v7.7.225)] TYPE:NORMAL | CODE:None | TAG: None | EE: teste | STREAM: None | EMAIL: No | MSG: "EE core v7.7.225: MQTT (Paho) subscribed to topic 'lummetry/ctrl' (QoS=0)" | INFO: EE app v4.2.389, core v7.7.225, SDK v3.4.121, info text: None
[EE][26-01-14 11:43:38][MAIN]   NOTIF: [MQTTCommThread (EE core v7.7.225)] TYPE:NORMAL | CODE:None | TAG: None | EE: teste | STREAM: None | EMAIL: No | MSG: "EE core v7.7.225: MQTT conn ok by 'teste_DEFAULT_zjcae9cg' in 0.0s - 172.31.3.70:1883 with subtopic alias" | INFO: EE app v4.2.389, core v7.7.225, SDK v3.4.121, info text: None
[EE][26-01-14 11:43:38][MAIN]   NOTIF: [MQTTCommThread (EE core v7.7.225)] TYPE:NORMAL | CODE:None | TAG: None | EE: teste | STREAM: None | EMAIL: No | MSG: "EE core v7.7.225: MQTT conn ok by 'teste_HEARTBE_2dfv40yv' in 0.0s - 172.31.3.70:1883 with subtopic alias" | INFO: EE app v4.2.389, core v7.7.225, SDK v3.4.121, info text: None
[EE][26-01-14 11:43:38][MAIN]   NOTIF: [MQTTCommThread (EE core v7.7.225)] TYPE:NORMAL | CODE:None | TAG: None | EE: teste | STREAM: None | EMAIL: No | MSG: "EE core v7.7.225: MQTT (Paho) subscribed to topic 'lummetry/0xai_Au2ThBNmSylWXmBmtrY-lNXBcWcmcLEFvdV75HAg26-3/config' (QoS=0)" | INFO: EE app v4.2.389, core v7.7.225, SDK v3.4.121, info text: None
[EE][26-01-14 11:43:38][MAIN]   NOTIF: [MQTTCommThread (EE core v7.7.225)] TYPE:NORMAL | CODE:None | TAG: None | EE: teste | STREAM: None | EMAIL: No | MSG: "EE core v7.7.225: MQTT conn ok by 'teste_NOTIFIC_ytj31pfw' in 0.0s - 172.31.3.70:1883 with subtopic alias" | INFO: EE app v4.2.389, core v7.7.225, SDK v3.4.121, info text: None
[EE][26-01-14 11:43:38][MQ][NO] 1674: ['teste', None, None, None]
[EE][26-01-14 11:43:38][MQ][HE] 3399: ['teste', None, None, None]
[EE][26-01-14 11:43:38][MQ][HE] Delivered 3KB after 0.0s from last hb. Time between hb: 0.0s, min: 0.0s, max: 0.0s, loop freq: 46.8Hz
[EE][26-01-14 11:43:38][NMON] Box alive: 0xai_Au2ThBNmSylWXmBmtrY-lNXBcWcmcLEFvdV75HAg26-3:teste.
[EE][26-01-14 11:43:38][MQ][NO] 1642: ['teste', None, None, None]
[EE][26-01-14 11:43:38][MQ][NO] 1674: ['teste', None, None, None]
[EE][26-01-14 11:43:38][MQ][NO] 1674: ['teste', None, None, None]
[EE][26-01-14 11:43:38][MQ][NO] 1694: ['teste', None, None, None]
[EE][26-01-14 11:43:38][MQ][NO] 1674: ['teste', None, None, None]
ian 14 09:43:39 teste sh[3722914]:   Running in a normal Python process
No config file provided. Using default config.
  No secrets/template found in config
BASE: ./_local_cachee sh[3722914]:
<Logging with default color: m>4]:
[TH_YF8S][26-01-14 11:43:39] ./_local_cache/_logs/TH_YF8S.txt log changed to ./_local_cache/_logs/20260114_114339_TH_YF8S_001_log.txt...
[TH_YF8S][26-01-14 11:43:39] ./_local_cache/_logs/TH_YF8S.txt error log changed to ./_local_cache/_logs/20260114_114339_TH_YF8S_001_error_log.txt...
[TH_YF8S][26-01-14 11:43:39] ###IMPORTANT###
ian 14 09:43:39 teste sh[3722914]:                     #########################################################################################
ian 14 09:43:39 teste sh[3722914]:                     #                                                                                       #
ian 14 09:43:39 teste sh[3722914]:                     #          R1SDK v3.4.121 initialized on [teste][ Intel(R) Core(TM) i7-14700].          #
ian 14 09:43:39 teste sh[3722914]:                     #                                                                                       #
ian 14 09:43:39 teste sh[3722914]:                     #########################################################################################
ian 14 09:43:39 teste sh[3722914]:
[TH_YF8S][26-01-14 11:43:39]   Timezone: Europe/Bucharest.
[TH_YF8S][26-01-14 11:43:39]   DEBUG is enabled in Logger
[TH_YF8S][26-01-14 11:43:39] Cleaning logs older than 2 days...
[TH_YF8S][26-01-14 11:43:39]   Nothing to clean.
[TH_YF8S][26-01-14 11:43:39]   Python 3.10.12, Git branch: 'develop', Conda: 'None'
[TH_YF8S][26-01-14 11:43:39]   Os: Linux-6.8.0-88-generic-x86_64-with-glibc2.35
[TH_YF8S][26-01-14 11:43:39]   IP: 172.31.110.69
[TH_YF8S][26-01-14 11:43:39]   Avail/Total RAM: 24.8 GB / 31.1 GB
[TH_YF8S][26-01-14 11:43:39][NumpySharedMemory] Initializing shmem 'TH_YF8S' using multiprocessing.SharedMemory
[TH_YF8S][26-01-14 11:43:39][NumpySharedMemory] Shared memory 'TH_YF8S'[User] successfully initialized
[TH_YF8S][26-01-14 11:43:39][52] Updating model config with 'SERVING_ENVIRONMENT' config...
[TH_YF8S][26-01-14 11:43:39][52] Updating model config with upstream config...
[TH_YF8S][26-01-14 11:43:39][52] Automatic validation for instance of `ThYf8s` is successful
[TH_YF8S][26-01-14 11:43:39][52] Model setup initiated for ThYf8s
[TH_YF8S][26-01-14 11:43:39][52] Prepping classes if available...
[TH_YF8S][26-01-14 11:43:39] Maybe dl '['coco.txt']' to 'models' from '[None]'
[TH_YF8S][26-01-14 11:43:39] Cannot download 'coco.txt' from 'None'
[TH_YF8S][26-01-14 11:43:39] Loading json 'coco.txt' from 'models'
[TH_YF8S][26-01-14 11:43:39]   File not found!
[TH_YF8S][26-01-14 11:43:39][52] WARNING: based class names loading failed. This is not necessarily an error as classes can be loaded within models.
[TH_YF8S][26-01-14 11:43:39][52] Loading for backend trt
[TH_YF8S][26-01-14 11:43:39][52] Preparing TH_YF8S TensorRT model 0.0.0...
[TH_YF8S][26-01-14 11:43:39] Maybe dl '['trt/20240430_y8s_640x1152_nms_f32_trt/20240430_y8s_640x1152_nms_f32_trt.onnx']' to 'models' from '['minio:Y8/20240430_y8s_640x1152_nms_f32_trt.onnx']'
[TH_YF8S][26-01-14 11:43:39] File 20240430_y8s_640x1152_nms_f32_trt.onnx found. Skipping.
[TH_YF8S][26-01-14 11:43:39][52] Using ONNX model 20240430_y8s_640x1152_nms_f32_trt.onnx (42.959 MB) at `./_local_cache/_models/trt/20240430_y8s_640x1152_nms_f32_trt/20240430_y8s_640x1152_nms_f32_trt.onnx` using map_location: cuda:0 on python v3.10.12...
[TH_YF8S][26-01-14 11:43:39][52] Trying to load TensorRT model from ./_local_cache/_models/trt/20240430_y8s_640x1152_nms_f32_trt/20240430_y8s_640x1152_nms_f32_trt.onnx
[TH_YF8S][26-01-14 11:43:39][TRT] No metadata file
[TH_YF8S][26-01-14 11:43:39][TRT] Failed to load model, trying to rebuild
[TH_YF8S][26-01-14 11:43:39] Building TensorRT engine file, this can take up to an hour
[EE][26-01-14 11:43:39][NMON] Box alive: 0xai_AjsKV3Dy55oLIXg2UqOQrzstiDTt7nsuKgHgDdNdFo0J:pre-k8s-super-0.
[EE][26-01-14 11:43:39][SMGR] Serving process 'TH_YF8S' is running with PID 52
[EE][26-01-14 11:43:39][SMGR]   Waiting until 'TH_YF8S' responds
[TH_YF8S][26-01-14 11:43:40] TensorRT build diagnostics (setup)
ian 14 09:43:40 teste sh[3722914]:   ONNX source: ./_local_cache/_models/trt/20240430_y8s_640x1152_nms_f32_trt/20240430_y8s_640x1152_nms_f32_trt.onnx
ian 14 09:43:40 teste sh[3722914]:   ONNX build path: _local_cache/_models/trt/20240430_y8s_640x1152_nms_f32_trt/20240430_y8s_640x1152_nms_f32_trt.tofp16.onnx
ian 14 09:43:40 teste sh[3722914]:   ONNX size: 42.959 MB
ian 14 09:43:40 teste sh[3722914]:   ONNX md5: 4e6e0c6d8b49e381f601f7ce140651ad
ian 14 09:43:40 teste sh[3722914]:   Requested precision: fp16
ian 14 09:43:40 teste sh[3722914]:   ONNX metadata precision: fp32
ian 14 09:43:40 teste sh[3722914]:   Torch: 2.3.1+cu121, CUDA: 12.1, TensorRT: 8.6.1
ian 14 09:43:40 teste sh[3722914]:   CUDA available: True, device_count: 1
ian 14 09:43:40 teste sh[3722914]:   CUDA driver version: None
ian 14 09:43:40 teste sh[3722914]:   Device index: 0
ian 14 09:43:40 teste sh[3722914]:   Device name: NVIDIA GeForce RTX 5060
ian 14 09:43:40 teste sh[3722914]:   Device capability: 12.0
ian 14 09:43:40 teste sh[3722914]:   Device total memory: 7706.0 MB
ian 14 09:43:40 teste sh[3722914]:   Device multiprocessors: 30
[TH_YF8S][26-01-14 11:43:40][TRT] [MemUsageChange] Init CUDA: CPU +29, GPU +0, now: CPU 231, GPU 336 (MiB)
[TH_YF8S][26-01-14 11:43:40][TRT] Trying to load shared library libnvinfer_builder_resource.so.8.6.1
[TH_YF8S][26-01-14 11:43:40][TRT] Loaded shared library libnvinfer_builder_resource.so.8.6.1
[EE][26-01-14 11:43:40][NMON] Box alive: 0xai_Al98PNfE5RmbfMOOREf7fHU2UW0k2wuHJVWfTQ6rGzEe:zed-optizone.
[TH_YF8S][26-01-14 11:43:42][TRT] [MemUsageChange] Init builder kernel library: CPU +1, GPU +0, now: CPU 310, GPU 336 (MiB)
[TH_YF8S][26-01-14 11:43:42][TRT] CUDA lazy loading is enabled.
[TH_YF8S][26-01-14 11:43:42] TensorRT builder platform
ian 14 09:43:42 teste sh[3722914]:   fast_fp16: True
ian 14 09:43:42 teste sh[3722914]:   fast_int8: True
ian 14 09:43:42 teste sh[3722914]:   tf32: False
[TH_YF8S][26-01-14 11:43:42][TRT] ----------------------------------------------------------------
[TH_YF8S][26-01-14 11:43:42][TRT] Input filename:   _local_cache/_models/trt/20240430_y8s_640x1152_nms_f32_trt/20240430_y8s_640x1152_nms_f32_trt.tofp16.onnx
[TH_YF8S][26-01-14 11:43:42][TRT] ONNX IR version:  0.0.7
[TH_YF8S][26-01-14 11:43:42][TRT] Opset version:    14
[TH_YF8S][26-01-14 11:43:42][TRT] Producer name:    pytorch
[TH_YF8S][26-01-14 11:43:42][TRT] Producer version: 2.0.1
[TH_YF8S][26-01-14 11:43:42][TRT] Domain:
[TH_YF8S][26-01-14 11:43:42][TRT] Model version:    0
[TH_YF8S][26-01-14 11:43:42][TRT] Doc string:
[TH_YF8S][26-01-14 11:43:42][TRT] ----------------------------------------------------------------
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::BatchedNMSDynamic_TRT version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::BatchedNMS_TRT version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::BatchTilePlugin_TRT version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::Clip_TRT version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::CoordConvAC version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::CropAndResizeDynamic version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::CropAndResize version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::DecodeBbox3DPlugin version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::DetectionLayer_TRT version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::EfficientNMS_Explicit_TF_TRT version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::EfficientNMS_Implicit_TF_TRT version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::EfficientNMS_ONNX_TRT version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::EfficientNMS_TRT version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::FlattenConcat_TRT version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::GenerateDetection_TRT version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::GridAnchor_TRT version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::GridAnchorRect_TRT version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::InstanceNormalization_TRT version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::InstanceNormalization_TRT version 2
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::LReLU_TRT version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::ModulatedDeformConv2d version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::MultilevelCropAndResize_TRT version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::MultilevelProposeROI_TRT version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::MultiscaleDeformableAttnPlugin_TRT version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::NMSDynamic_TRT version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::NMS_TRT version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::Normalize_TRT version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::PillarScatterPlugin version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::PriorBox_TRT version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::ProposalDynamic version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::ProposalLayer_TRT version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::Proposal version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::PyramidROIAlign_TRT version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::Region_TRT version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::Reorg_TRT version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::ResizeNearest_TRT version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::ROIAlign_TRT version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::RPROI_TRT version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::ScatterND version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::SpecialSlice_TRT version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::Split version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Plugin creator already registered - ::VoxelGeneratorPlugin version 1
[TH_YF8S][26-01-14 11:43:42][TRT] Adding network input: inputs with dtype: float16, dimensions: (-1, 3, 640, 1152)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: inputs for ONNX tensor: inputs
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: backbone_model.model.22.cv2.0.2.weight
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: backbone_model.model.22.cv2.0.2.bias
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: backbone_model.model.22.cv2.1.2.weight
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: backbone_model.model.22.cv2.1.2.bias
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: backbone_model.model.22.cv2.2.2.weight
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: backbone_model.model.22.cv2.2.2.bias
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: backbone_model.model.22.cv3.0.2.weight
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: backbone_model.model.22.cv3.0.2.bias
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: backbone_model.model.22.cv3.1.2.weight
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: backbone_model.model.22.cv3.1.2.bias
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: backbone_model.model.22.cv3.2.2.weight
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: backbone_model.model.22.cv3.2.2.bias
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: backbone_model.model.22.dfl.conv.weight
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1488
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1489
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1491
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1492
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1494
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1495
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1497
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1498
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1500
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1501
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1503
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1504
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1506
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1507
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1509
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1510
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1512
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1513
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1515
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1516
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1518
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1519
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1521
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1522
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1524
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1525
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1527
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1528
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1530
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1531
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1533
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1534
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1536
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1537
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1539
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1540
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1542
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1543
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1545
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1546
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1548
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1549
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1551
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1552
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1554
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1555
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1557
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1558
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1560
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1561
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1563
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1564
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1566
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1567
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1569
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1570
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1572
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1573
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1575
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1576
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1578
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1579
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1581
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1582
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1584
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1585
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1587
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1588
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1590
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1591
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1593
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1594
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1596
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1597
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1599
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1600
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1602
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1603
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1605
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1606
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1608
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1609
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1611
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1612
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1614
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1615
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1617
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1618
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1620
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1621
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1623
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1624
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1626
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1627
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1629
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1630
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1632
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1633
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1635
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1636
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1638
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1639
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1641
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1642
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1644
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1645
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1647
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1648
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1650
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1651
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1653
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1654
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1656
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Conv_1657
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /backbone_model/model.0/conv/Constant_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] onnx2trt_utils.cpp:374: Your ONNX model has been generated with INT64 weights, while TensorRT does not natively support INT64. Attempting to cast down to INT32.
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /backbone_model/model.2/Constant_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /backbone_model/model.2/Constant_4_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /backbone_model/model.10/Constant_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /backbone_model/model.22/Constant_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /backbone_model/model.22/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /backbone_model/model.22/Constant_3_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: onnx::Split_770
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /backbone_model/model.22/dfl/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /backbone_model/model.22/dfl/Constant_3_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /backbone_model/model.22/Constant_14_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /backbone_model/model.22/Constant_16_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /backbone_model/model.22/Constant_17_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /Constant_2_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /Constant_3_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /Constant_4_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /Constant_19_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /Constant_20_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /Constant_22_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /Constant_31_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /Constant_79_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /Constant_95_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /Constant_147_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /Constant_176_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Weight at index 0: 9223372036854775807 is out of range. Clamping to: 2147483647
[TH_YF8S][26-01-14 11:43:42][TRT] onnx2trt_utils.cpp:400: One or more weights outside the range of INT32 was clamped
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: _v_1801
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /backbone_model/model.2/Div_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /backbone_model/model.2/Mul_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /backbone_model/model.4/Mul_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /backbone_model/model.6/Mul_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /backbone_model/model.8/Mul_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /Reshape_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /ConstantOfShape_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: /Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Importing initializer: _v_681
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.0/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: inputs
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1488
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1489
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.0/conv/Conv [Conv] inputs: [inputs -> (-1, 3, 640, 1152)[HALF]], [onnx::Conv_1488 -> (32, 3, 3, 3)[HALF]], [onnx::Conv_1489 -> (32)[HALF]],
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution input dimensions: (-1, 3, 640, 1152)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.0/conv/Conv for ONNX node: /backbone_model/model.0/conv/Conv
[TH_YF8S][26-01-14 11:43:42][TRT] Using kernel: (3, 3), strides: (2, 2), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 32
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution output dimensions: (-1, 32, 320, 576)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.0/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.0/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.0/conv/Conv [Conv] outputs: [/backbone_model/model.0/conv/Conv_output_0 -> (-1, 32, 320, 576)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.0/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.0/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.0/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.0/conv/Conv_output_0 -> (-1, 32, 320, 576)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.0/act/Sigmoid for ONNX node: /backbone_model/model.0/act/Sigmoid
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.0/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.0/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.0/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.0/act/Sigmoid_output_0 -> (-1, 32, 320, 576)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.0/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.0/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.0/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.0/act/Mul [Mul] inputs: [/backbone_model/model.0/conv/Conv_output_0 -> (-1, 32, 320, 576)[FLOAT]], [/backbone_model/model.0/act/Sigmoid_output_0 -> (-1, 32, 320, 576)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.0/act/Mul for ONNX node: /backbone_model/model.0/act/Mul
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.0/act/Mul_output_0 for ONNX tensor: /backbone_model/model.0/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.0/act/Mul [Mul] outputs: [/backbone_model/model.0/act/Mul_output_0 -> (-1, 32, 320, 576)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.1/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.0/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1491
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1492
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.1/conv/Conv [Conv] inputs: [/backbone_model/model.0/act/Mul_output_0 -> (-1, 32, 320, 576)[FLOAT]], [onnx::Conv_1491 -> (64, 32, 3, 3)[HALF]], [onnx::Conv_1492 -> (64)[HALF]],
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution input dimensions: (-1, 32, 320, 576)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.1/conv/Conv for ONNX node: /backbone_model/model.1/conv/Conv
[TH_YF8S][26-01-14 11:43:42][TRT] Using kernel: (3, 3), strides: (2, 2), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 64
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution output dimensions: (-1, 64, 160, 288)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.1/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.1/conv/Conv [Conv] outputs: [/backbone_model/model.1/conv/Conv_output_0 -> (-1, 64, 160, 288)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.1/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.1/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.1/conv/Conv_output_0 -> (-1, 64, 160, 288)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.1/act/Sigmoid for ONNX node: /backbone_model/model.1/act/Sigmoid
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.1/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.1/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.1/act/Sigmoid_output_0 -> (-1, 64, 160, 288)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.1/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.1/act/Mul [Mul] inputs: [/backbone_model/model.1/conv/Conv_output_0 -> (-1, 64, 160, 288)[FLOAT]], [/backbone_model/model.1/act/Sigmoid_output_0 -> (-1, 64, 160, 288)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.1/act/Mul for ONNX node: /backbone_model/model.1/act/Mul
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.1/act/Mul_output_0 for ONNX tensor: /backbone_model/model.1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.1/act/Mul [Mul] outputs: [/backbone_model/model.1/act/Mul_output_0 -> (-1, 64, 160, 288)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.2/cv1/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1494
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1495
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/cv1/conv/Conv [Conv] inputs: [/backbone_model/model.1/act/Mul_output_0 -> (-1, 64, 160, 288)[FLOAT]], [onnx::Conv_1494 -> (64, 64, 1, 1)[HALF]], [onnx::Conv_1495 -> (64)[HALF]],
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution input dimensions: (-1, 64, 160, 288)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.2/cv1/conv/Conv for ONNX node: /backbone_model/model.2/cv1/conv/Conv
[TH_YF8S][26-01-14 11:43:42][TRT] Using kernel: (1, 1), strides: (1, 1), prepadding: (0, 0), postpadding: (0, 0), dilations: (1, 1), numOutputs: 64
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution output dimensions: (-1, 64, 160, 288)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.2/cv1/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.2/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/cv1/conv/Conv [Conv] outputs: [/backbone_model/model.2/cv1/conv/Conv_output_0 -> (-1, 64, 160, 288)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.2/cv1/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/cv1/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.2/cv1/conv/Conv_output_0 -> (-1, 64, 160, 288)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.2/cv1/act/Sigmoid for ONNX node: /backbone_model/model.2/cv1/act/Sigmoid
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.2/cv1/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.2/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/cv1/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.2/cv1/act/Sigmoid_output_0 -> (-1, 64, 160, 288)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.2/cv1/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/cv1/act/Mul [Mul] inputs: [/backbone_model/model.2/cv1/conv/Conv_output_0 -> (-1, 64, 160, 288)[FLOAT]], [/backbone_model/model.2/cv1/act/Sigmoid_output_0 -> (-1, 64, 160, 288)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.2/cv1/act/Mul for ONNX node: /backbone_model/model.2/cv1/act/Mul
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.2/cv1/act/Mul_output_0 for ONNX tensor: /backbone_model/model.2/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/cv1/act/Mul [Mul] outputs: [/backbone_model/model.2/cv1/act/Mul_output_0 -> (-1, 64, 160, 288)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.2/Slice [Slice]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/Div_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/Slice [Slice] inputs: [/backbone_model/model.2/cv1/act/Mul_output_0 -> (-1, 64, 160, 288)[FLOAT]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]], [/backbone_model/model.2/Div_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.2/Slice for ONNX node: /backbone_model/model.2/Slice
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.2/Slice_output_0 for ONNX tensor: /backbone_model/model.2/Slice_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/Slice [Slice] outputs: [/backbone_model/model.2/Slice_output_0 -> (-1, 32, 160, 288)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.2/Slice_1 [Slice]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/Div_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/Mul_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/Slice_1 [Slice] inputs: [/backbone_model/model.2/cv1/act/Mul_output_0 -> (-1, 64, 160, 288)[FLOAT]], [/backbone_model/model.2/Div_output_0 -> (1)[INT32]], [/backbone_model/model.2/Mul_1_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.2/Slice_1 for ONNX node: /backbone_model/model.2/Slice_1
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.2/Slice_1_output_0 for ONNX tensor: /backbone_model/model.2/Slice_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/Slice_1 [Slice] outputs: [/backbone_model/model.2/Slice_1_output_0 -> (-1, 32, 160, 288)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.2/m.0/cv1/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/Slice_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1497
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1498
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/m.0/cv1/conv/Conv [Conv] inputs: [/backbone_model/model.2/Slice_1_output_0 -> (-1, 32, 160, 288)[FLOAT]], [onnx::Conv_1497 -> (32, 32, 3, 3)[HALF]], [onnx::Conv_1498 -> (32)[HALF]],
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution input dimensions: (-1, 32, 160, 288)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.2/m.0/cv1/conv/Conv for ONNX node: /backbone_model/model.2/m.0/cv1/conv/Conv
[TH_YF8S][26-01-14 11:43:42][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 32
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution output dimensions: (-1, 32, 160, 288)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.2/m.0/cv1/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.2/m.0/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/m.0/cv1/conv/Conv [Conv] outputs: [/backbone_model/model.2/m.0/cv1/conv/Conv_output_0 -> (-1, 32, 160, 288)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.2/m.0/cv1/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/m.0/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/m.0/cv1/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.2/m.0/cv1/conv/Conv_output_0 -> (-1, 32, 160, 288)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.2/m.0/cv1/act/Sigmoid for ONNX node: /backbone_model/model.2/m.0/cv1/act/Sigmoid
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.2/m.0/cv1/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.2/m.0/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/m.0/cv1/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.2/m.0/cv1/act/Sigmoid_output_0 -> (-1, 32, 160, 288)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.2/m.0/cv1/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/m.0/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/m.0/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/m.0/cv1/act/Mul [Mul] inputs: [/backbone_model/model.2/m.0/cv1/conv/Conv_output_0 -> (-1, 32, 160, 288)[FLOAT]], [/backbone_model/model.2/m.0/cv1/act/Sigmoid_output_0 -> (-1, 32, 160, 288)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.2/m.0/cv1/act/Mul for ONNX node: /backbone_model/model.2/m.0/cv1/act/Mul
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.2/m.0/cv1/act/Mul_output_0 for ONNX tensor: /backbone_model/model.2/m.0/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/m.0/cv1/act/Mul [Mul] outputs: [/backbone_model/model.2/m.0/cv1/act/Mul_output_0 -> (-1, 32, 160, 288)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.2/m.0/cv2/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/m.0/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1500
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1501
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/m.0/cv2/conv/Conv [Conv] inputs: [/backbone_model/model.2/m.0/cv1/act/Mul_output_0 -> (-1, 32, 160, 288)[FLOAT]], [onnx::Conv_1500 -> (32, 32, 3, 3)[HALF]], [onnx::Conv_1501 -> (32)[HALF]],
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution input dimensions: (-1, 32, 160, 288)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.2/m.0/cv2/conv/Conv for ONNX node: /backbone_model/model.2/m.0/cv2/conv/Conv
[TH_YF8S][26-01-14 11:43:42][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 32
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution output dimensions: (-1, 32, 160, 288)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.2/m.0/cv2/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.2/m.0/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/m.0/cv2/conv/Conv [Conv] outputs: [/backbone_model/model.2/m.0/cv2/conv/Conv_output_0 -> (-1, 32, 160, 288)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.2/m.0/cv2/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/m.0/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/m.0/cv2/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.2/m.0/cv2/conv/Conv_output_0 -> (-1, 32, 160, 288)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.2/m.0/cv2/act/Sigmoid for ONNX node: /backbone_model/model.2/m.0/cv2/act/Sigmoid
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.2/m.0/cv2/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.2/m.0/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/m.0/cv2/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.2/m.0/cv2/act/Sigmoid_output_0 -> (-1, 32, 160, 288)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.2/m.0/cv2/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/m.0/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/m.0/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/m.0/cv2/act/Mul [Mul] inputs: [/backbone_model/model.2/m.0/cv2/conv/Conv_output_0 -> (-1, 32, 160, 288)[FLOAT]], [/backbone_model/model.2/m.0/cv2/act/Sigmoid_output_0 -> (-1, 32, 160, 288)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.2/m.0/cv2/act/Mul for ONNX node: /backbone_model/model.2/m.0/cv2/act/Mul
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.2/m.0/cv2/act/Mul_output_0 for ONNX tensor: /backbone_model/model.2/m.0/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/m.0/cv2/act/Mul [Mul] outputs: [/backbone_model/model.2/m.0/cv2/act/Mul_output_0 -> (-1, 32, 160, 288)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.2/m.0/Add [Add]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/Slice_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/m.0/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/m.0/Add [Add] inputs: [/backbone_model/model.2/Slice_1_output_0 -> (-1, 32, 160, 288)[FLOAT]], [/backbone_model/model.2/m.0/cv2/act/Mul_output_0 -> (-1, 32, 160, 288)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.2/m.0/Add for ONNX node: /backbone_model/model.2/m.0/Add
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.2/m.0/Add_output_0 for ONNX tensor: /backbone_model/model.2/m.0/Add_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/m.0/Add [Add] outputs: [/backbone_model/model.2/m.0/Add_output_0 -> (-1, 32, 160, 288)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.2/Concat [Concat]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/Slice_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/Slice_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/m.0/Add_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/Concat [Concat] inputs: [/backbone_model/model.2/Slice_output_0 -> (-1, 32, 160, 288)[FLOAT]], [/backbone_model/model.2/Slice_1_output_0 -> (-1, 32, 160, 288)[FLOAT]], [/backbone_model/model.2/m.0/Add_output_0 -> (-1, 32, 160, 288)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.2/Concat for ONNX node: /backbone_model/model.2/Concat
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.2/Concat_output_0 for ONNX tensor: /backbone_model/model.2/Concat_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/Concat [Concat] outputs: [/backbone_model/model.2/Concat_output_0 -> (-1, 96, 160, 288)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.2/cv2/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/Concat_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1503
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1504
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/cv2/conv/Conv [Conv] inputs: [/backbone_model/model.2/Concat_output_0 -> (-1, 96, 160, 288)[FLOAT]], [onnx::Conv_1503 -> (64, 96, 1, 1)[HALF]], [onnx::Conv_1504 -> (64)[HALF]],
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution input dimensions: (-1, 96, 160, 288)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.2/cv2/conv/Conv for ONNX node: /backbone_model/model.2/cv2/conv/Conv
[TH_YF8S][26-01-14 11:43:42][TRT] Using kernel: (1, 1), strides: (1, 1), prepadding: (0, 0), postpadding: (0, 0), dilations: (1, 1), numOutputs: 64
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution output dimensions: (-1, 64, 160, 288)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.2/cv2/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.2/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/cv2/conv/Conv [Conv] outputs: [/backbone_model/model.2/cv2/conv/Conv_output_0 -> (-1, 64, 160, 288)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.2/cv2/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/cv2/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.2/cv2/conv/Conv_output_0 -> (-1, 64, 160, 288)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.2/cv2/act/Sigmoid for ONNX node: /backbone_model/model.2/cv2/act/Sigmoid
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.2/cv2/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.2/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/cv2/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.2/cv2/act/Sigmoid_output_0 -> (-1, 64, 160, 288)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.2/cv2/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/cv2/act/Mul [Mul] inputs: [/backbone_model/model.2/cv2/conv/Conv_output_0 -> (-1, 64, 160, 288)[FLOAT]], [/backbone_model/model.2/cv2/act/Sigmoid_output_0 -> (-1, 64, 160, 288)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.2/cv2/act/Mul for ONNX node: /backbone_model/model.2/cv2/act/Mul
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.2/cv2/act/Mul_output_0 for ONNX tensor: /backbone_model/model.2/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.2/cv2/act/Mul [Mul] outputs: [/backbone_model/model.2/cv2/act/Mul_output_0 -> (-1, 64, 160, 288)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.3/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1506
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1507
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.3/conv/Conv [Conv] inputs: [/backbone_model/model.2/cv2/act/Mul_output_0 -> (-1, 64, 160, 288)[FLOAT]], [onnx::Conv_1506 -> (128, 64, 3, 3)[HALF]], [onnx::Conv_1507 -> (128)[HALF]],
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution input dimensions: (-1, 64, 160, 288)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.3/conv/Conv for ONNX node: /backbone_model/model.3/conv/Conv
[TH_YF8S][26-01-14 11:43:42][TRT] Using kernel: (3, 3), strides: (2, 2), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 128
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution output dimensions: (-1, 128, 80, 144)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.3/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.3/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.3/conv/Conv [Conv] outputs: [/backbone_model/model.3/conv/Conv_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.3/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.3/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.3/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.3/conv/Conv_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.3/act/Sigmoid for ONNX node: /backbone_model/model.3/act/Sigmoid
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.3/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.3/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.3/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.3/act/Sigmoid_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.3/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.3/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.3/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.3/act/Mul [Mul] inputs: [/backbone_model/model.3/conv/Conv_output_0 -> (-1, 128, 80, 144)[FLOAT]], [/backbone_model/model.3/act/Sigmoid_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.3/act/Mul for ONNX node: /backbone_model/model.3/act/Mul
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.3/act/Mul_output_0 for ONNX tensor: /backbone_model/model.3/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.3/act/Mul [Mul] outputs: [/backbone_model/model.3/act/Mul_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.4/cv1/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.3/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1509
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1510
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/cv1/conv/Conv [Conv] inputs: [/backbone_model/model.3/act/Mul_output_0 -> (-1, 128, 80, 144)[FLOAT]], [onnx::Conv_1509 -> (128, 128, 1, 1)[HALF]], [onnx::Conv_1510 -> (128)[HALF]],
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution input dimensions: (-1, 128, 80, 144)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.4/cv1/conv/Conv for ONNX node: /backbone_model/model.4/cv1/conv/Conv
[TH_YF8S][26-01-14 11:43:42][TRT] Using kernel: (1, 1), strides: (1, 1), prepadding: (0, 0), postpadding: (0, 0), dilations: (1, 1), numOutputs: 128
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution output dimensions: (-1, 128, 80, 144)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.4/cv1/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.4/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/cv1/conv/Conv [Conv] outputs: [/backbone_model/model.4/cv1/conv/Conv_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.4/cv1/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/cv1/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.4/cv1/conv/Conv_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.4/cv1/act/Sigmoid for ONNX node: /backbone_model/model.4/cv1/act/Sigmoid
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.4/cv1/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.4/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/cv1/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.4/cv1/act/Sigmoid_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.4/cv1/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/cv1/act/Mul [Mul] inputs: [/backbone_model/model.4/cv1/conv/Conv_output_0 -> (-1, 128, 80, 144)[FLOAT]], [/backbone_model/model.4/cv1/act/Sigmoid_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.4/cv1/act/Mul for ONNX node: /backbone_model/model.4/cv1/act/Mul
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.4/cv1/act/Mul_output_0 for ONNX tensor: /backbone_model/model.4/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/cv1/act/Mul [Mul] outputs: [/backbone_model/model.4/cv1/act/Mul_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.4/Slice [Slice]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/Mul_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/Slice [Slice] inputs: [/backbone_model/model.4/cv1/act/Mul_output_0 -> (-1, 128, 80, 144)[FLOAT]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]], [/backbone_model/model.2/Mul_1_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.4/Slice for ONNX node: /backbone_model/model.4/Slice
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.4/Slice_output_0 for ONNX tensor: /backbone_model/model.4/Slice_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/Slice [Slice] outputs: [/backbone_model/model.4/Slice_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.4/Slice_1 [Slice]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/Mul_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/Mul_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/Slice_1 [Slice] inputs: [/backbone_model/model.4/cv1/act/Mul_output_0 -> (-1, 128, 80, 144)[FLOAT]], [/backbone_model/model.2/Mul_1_output_0 -> (1)[INT32]], [/backbone_model/model.4/Mul_1_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.4/Slice_1 for ONNX node: /backbone_model/model.4/Slice_1
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.4/Slice_1_output_0 for ONNX tensor: /backbone_model/model.4/Slice_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/Slice_1 [Slice] outputs: [/backbone_model/model.4/Slice_1_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.4/m.0/cv1/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/Slice_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1512
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1513
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/m.0/cv1/conv/Conv [Conv] inputs: [/backbone_model/model.4/Slice_1_output_0 -> (-1, 64, 80, 144)[FLOAT]], [onnx::Conv_1512 -> (64, 64, 3, 3)[HALF]], [onnx::Conv_1513 -> (64)[HALF]],
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution input dimensions: (-1, 64, 80, 144)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.4/m.0/cv1/conv/Conv for ONNX node: /backbone_model/model.4/m.0/cv1/conv/Conv
[TH_YF8S][26-01-14 11:43:42][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 64
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution output dimensions: (-1, 64, 80, 144)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.4/m.0/cv1/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.4/m.0/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/m.0/cv1/conv/Conv [Conv] outputs: [/backbone_model/model.4/m.0/cv1/conv/Conv_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.4/m.0/cv1/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/m.0/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/m.0/cv1/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.4/m.0/cv1/conv/Conv_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.4/m.0/cv1/act/Sigmoid for ONNX node: /backbone_model/model.4/m.0/cv1/act/Sigmoid
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.4/m.0/cv1/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.4/m.0/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/m.0/cv1/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.4/m.0/cv1/act/Sigmoid_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.4/m.0/cv1/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/m.0/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/m.0/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/m.0/cv1/act/Mul [Mul] inputs: [/backbone_model/model.4/m.0/cv1/conv/Conv_output_0 -> (-1, 64, 80, 144)[FLOAT]], [/backbone_model/model.4/m.0/cv1/act/Sigmoid_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.4/m.0/cv1/act/Mul for ONNX node: /backbone_model/model.4/m.0/cv1/act/Mul
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.4/m.0/cv1/act/Mul_output_0 for ONNX tensor: /backbone_model/model.4/m.0/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/m.0/cv1/act/Mul [Mul] outputs: [/backbone_model/model.4/m.0/cv1/act/Mul_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.4/m.0/cv2/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/m.0/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1515
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1516
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/m.0/cv2/conv/Conv [Conv] inputs: [/backbone_model/model.4/m.0/cv1/act/Mul_output_0 -> (-1, 64, 80, 144)[FLOAT]], [onnx::Conv_1515 -> (64, 64, 3, 3)[HALF]], [onnx::Conv_1516 -> (64)[HALF]],
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution input dimensions: (-1, 64, 80, 144)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.4/m.0/cv2/conv/Conv for ONNX node: /backbone_model/model.4/m.0/cv2/conv/Conv
[TH_YF8S][26-01-14 11:43:42][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 64
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution output dimensions: (-1, 64, 80, 144)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.4/m.0/cv2/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.4/m.0/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/m.0/cv2/conv/Conv [Conv] outputs: [/backbone_model/model.4/m.0/cv2/conv/Conv_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.4/m.0/cv2/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/m.0/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/m.0/cv2/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.4/m.0/cv2/conv/Conv_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.4/m.0/cv2/act/Sigmoid for ONNX node: /backbone_model/model.4/m.0/cv2/act/Sigmoid
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.4/m.0/cv2/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.4/m.0/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/m.0/cv2/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.4/m.0/cv2/act/Sigmoid_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.4/m.0/cv2/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/m.0/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/m.0/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/m.0/cv2/act/Mul [Mul] inputs: [/backbone_model/model.4/m.0/cv2/conv/Conv_output_0 -> (-1, 64, 80, 144)[FLOAT]], [/backbone_model/model.4/m.0/cv2/act/Sigmoid_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.4/m.0/cv2/act/Mul for ONNX node: /backbone_model/model.4/m.0/cv2/act/Mul
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.4/m.0/cv2/act/Mul_output_0 for ONNX tensor: /backbone_model/model.4/m.0/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/m.0/cv2/act/Mul [Mul] outputs: [/backbone_model/model.4/m.0/cv2/act/Mul_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.4/m.0/Add [Add]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/Slice_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/m.0/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/m.0/Add [Add] inputs: [/backbone_model/model.4/Slice_1_output_0 -> (-1, 64, 80, 144)[FLOAT]], [/backbone_model/model.4/m.0/cv2/act/Mul_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.4/m.0/Add for ONNX node: /backbone_model/model.4/m.0/Add
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.4/m.0/Add_output_0 for ONNX tensor: /backbone_model/model.4/m.0/Add_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/m.0/Add [Add] outputs: [/backbone_model/model.4/m.0/Add_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.4/m.1/cv1/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/m.0/Add_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1518
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1519
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/m.1/cv1/conv/Conv [Conv] inputs: [/backbone_model/model.4/m.0/Add_output_0 -> (-1, 64, 80, 144)[FLOAT]], [onnx::Conv_1518 -> (64, 64, 3, 3)[HALF]], [onnx::Conv_1519 -> (64)[HALF]],
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution input dimensions: (-1, 64, 80, 144)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.4/m.1/cv1/conv/Conv for ONNX node: /backbone_model/model.4/m.1/cv1/conv/Conv
[TH_YF8S][26-01-14 11:43:42][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 64
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution output dimensions: (-1, 64, 80, 144)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.4/m.1/cv1/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.4/m.1/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/m.1/cv1/conv/Conv [Conv] outputs: [/backbone_model/model.4/m.1/cv1/conv/Conv_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.4/m.1/cv1/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/m.1/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/m.1/cv1/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.4/m.1/cv1/conv/Conv_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.4/m.1/cv1/act/Sigmoid for ONNX node: /backbone_model/model.4/m.1/cv1/act/Sigmoid
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.4/m.1/cv1/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.4/m.1/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/m.1/cv1/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.4/m.1/cv1/act/Sigmoid_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.4/m.1/cv1/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/m.1/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/m.1/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/m.1/cv1/act/Mul [Mul] inputs: [/backbone_model/model.4/m.1/cv1/conv/Conv_output_0 -> (-1, 64, 80, 144)[FLOAT]], [/backbone_model/model.4/m.1/cv1/act/Sigmoid_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.4/m.1/cv1/act/Mul for ONNX node: /backbone_model/model.4/m.1/cv1/act/Mul
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.4/m.1/cv1/act/Mul_output_0 for ONNX tensor: /backbone_model/model.4/m.1/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/m.1/cv1/act/Mul [Mul] outputs: [/backbone_model/model.4/m.1/cv1/act/Mul_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.4/m.1/cv2/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/m.1/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1521
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1522
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/m.1/cv2/conv/Conv [Conv] inputs: [/backbone_model/model.4/m.1/cv1/act/Mul_output_0 -> (-1, 64, 80, 144)[FLOAT]], [onnx::Conv_1521 -> (64, 64, 3, 3)[HALF]], [onnx::Conv_1522 -> (64)[HALF]],
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution input dimensions: (-1, 64, 80, 144)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.4/m.1/cv2/conv/Conv for ONNX node: /backbone_model/model.4/m.1/cv2/conv/Conv
[TH_YF8S][26-01-14 11:43:42][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 64
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution output dimensions: (-1, 64, 80, 144)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.4/m.1/cv2/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.4/m.1/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/m.1/cv2/conv/Conv [Conv] outputs: [/backbone_model/model.4/m.1/cv2/conv/Conv_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.4/m.1/cv2/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/m.1/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/m.1/cv2/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.4/m.1/cv2/conv/Conv_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.4/m.1/cv2/act/Sigmoid for ONNX node: /backbone_model/model.4/m.1/cv2/act/Sigmoid
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.4/m.1/cv2/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.4/m.1/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/m.1/cv2/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.4/m.1/cv2/act/Sigmoid_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.4/m.1/cv2/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/m.1/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/m.1/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/m.1/cv2/act/Mul [Mul] inputs: [/backbone_model/model.4/m.1/cv2/conv/Conv_output_0 -> (-1, 64, 80, 144)[FLOAT]], [/backbone_model/model.4/m.1/cv2/act/Sigmoid_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.4/m.1/cv2/act/Mul for ONNX node: /backbone_model/model.4/m.1/cv2/act/Mul
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.4/m.1/cv2/act/Mul_output_0 for ONNX tensor: /backbone_model/model.4/m.1/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/m.1/cv2/act/Mul [Mul] outputs: [/backbone_model/model.4/m.1/cv2/act/Mul_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.4/m.1/Add [Add]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/m.0/Add_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/m.1/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/m.1/Add [Add] inputs: [/backbone_model/model.4/m.0/Add_output_0 -> (-1, 64, 80, 144)[FLOAT]], [/backbone_model/model.4/m.1/cv2/act/Mul_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.4/m.1/Add for ONNX node: /backbone_model/model.4/m.1/Add
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.4/m.1/Add_output_0 for ONNX tensor: /backbone_model/model.4/m.1/Add_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/m.1/Add [Add] outputs: [/backbone_model/model.4/m.1/Add_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.4/Concat [Concat]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/Slice_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/Slice_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/m.0/Add_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/m.1/Add_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/Concat [Concat] inputs: [/backbone_model/model.4/Slice_output_0 -> (-1, 64, 80, 144)[FLOAT]], [/backbone_model/model.4/Slice_1_output_0 -> (-1, 64, 80, 144)[FLOAT]], [/backbone_model/model.4/m.0/Add_output_0 -> (-1, 64, 80, 144)[FLOAT]], [/backbone_model/model.4/m.1/Add_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.4/Concat for ONNX node: /backbone_model/model.4/Concat
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.4/Concat_output_0 for ONNX tensor: /backbone_model/model.4/Concat_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/Concat [Concat] outputs: [/backbone_model/model.4/Concat_output_0 -> (-1, 256, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.4/cv2/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/Concat_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1524
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1525
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/cv2/conv/Conv [Conv] inputs: [/backbone_model/model.4/Concat_output_0 -> (-1, 256, 80, 144)[FLOAT]], [onnx::Conv_1524 -> (128, 256, 1, 1)[HALF]], [onnx::Conv_1525 -> (128)[HALF]],
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution input dimensions: (-1, 256, 80, 144)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.4/cv2/conv/Conv for ONNX node: /backbone_model/model.4/cv2/conv/Conv
[TH_YF8S][26-01-14 11:43:42][TRT] Using kernel: (1, 1), strides: (1, 1), prepadding: (0, 0), postpadding: (0, 0), dilations: (1, 1), numOutputs: 128
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution output dimensions: (-1, 128, 80, 144)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.4/cv2/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.4/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/cv2/conv/Conv [Conv] outputs: [/backbone_model/model.4/cv2/conv/Conv_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.4/cv2/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/cv2/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.4/cv2/conv/Conv_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.4/cv2/act/Sigmoid for ONNX node: /backbone_model/model.4/cv2/act/Sigmoid
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.4/cv2/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.4/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/cv2/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.4/cv2/act/Sigmoid_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.4/cv2/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/cv2/act/Mul [Mul] inputs: [/backbone_model/model.4/cv2/conv/Conv_output_0 -> (-1, 128, 80, 144)[FLOAT]], [/backbone_model/model.4/cv2/act/Sigmoid_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.4/cv2/act/Mul for ONNX node: /backbone_model/model.4/cv2/act/Mul
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.4/cv2/act/Mul_output_0 for ONNX tensor: /backbone_model/model.4/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.4/cv2/act/Mul [Mul] outputs: [/backbone_model/model.4/cv2/act/Mul_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.5/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1527
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1528
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.5/conv/Conv [Conv] inputs: [/backbone_model/model.4/cv2/act/Mul_output_0 -> (-1, 128, 80, 144)[FLOAT]], [onnx::Conv_1527 -> (256, 128, 3, 3)[HALF]], [onnx::Conv_1528 -> (256)[HALF]],
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution input dimensions: (-1, 128, 80, 144)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.5/conv/Conv for ONNX node: /backbone_model/model.5/conv/Conv
[TH_YF8S][26-01-14 11:43:42][TRT] Using kernel: (3, 3), strides: (2, 2), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 256
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution output dimensions: (-1, 256, 40, 72)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.5/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.5/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.5/conv/Conv [Conv] outputs: [/backbone_model/model.5/conv/Conv_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.5/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.5/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.5/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.5/conv/Conv_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.5/act/Sigmoid for ONNX node: /backbone_model/model.5/act/Sigmoid
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.5/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.5/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.5/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.5/act/Sigmoid_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.5/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.5/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.5/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.5/act/Mul [Mul] inputs: [/backbone_model/model.5/conv/Conv_output_0 -> (-1, 256, 40, 72)[FLOAT]], [/backbone_model/model.5/act/Sigmoid_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.5/act/Mul for ONNX node: /backbone_model/model.5/act/Mul
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.5/act/Mul_output_0 for ONNX tensor: /backbone_model/model.5/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.5/act/Mul [Mul] outputs: [/backbone_model/model.5/act/Mul_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.6/cv1/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.5/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1530
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1531
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/cv1/conv/Conv [Conv] inputs: [/backbone_model/model.5/act/Mul_output_0 -> (-1, 256, 40, 72)[FLOAT]], [onnx::Conv_1530 -> (256, 256, 1, 1)[HALF]], [onnx::Conv_1531 -> (256)[HALF]],
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution input dimensions: (-1, 256, 40, 72)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.6/cv1/conv/Conv for ONNX node: /backbone_model/model.6/cv1/conv/Conv
[TH_YF8S][26-01-14 11:43:42][TRT] Using kernel: (1, 1), strides: (1, 1), prepadding: (0, 0), postpadding: (0, 0), dilations: (1, 1), numOutputs: 256
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution output dimensions: (-1, 256, 40, 72)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.6/cv1/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.6/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/cv1/conv/Conv [Conv] outputs: [/backbone_model/model.6/cv1/conv/Conv_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.6/cv1/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/cv1/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.6/cv1/conv/Conv_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.6/cv1/act/Sigmoid for ONNX node: /backbone_model/model.6/cv1/act/Sigmoid
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.6/cv1/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.6/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/cv1/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.6/cv1/act/Sigmoid_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.6/cv1/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/cv1/act/Mul [Mul] inputs: [/backbone_model/model.6/cv1/conv/Conv_output_0 -> (-1, 256, 40, 72)[FLOAT]], [/backbone_model/model.6/cv1/act/Sigmoid_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.6/cv1/act/Mul for ONNX node: /backbone_model/model.6/cv1/act/Mul
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.6/cv1/act/Mul_output_0 for ONNX tensor: /backbone_model/model.6/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/cv1/act/Mul [Mul] outputs: [/backbone_model/model.6/cv1/act/Mul_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.6/Slice [Slice]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/Mul_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/Slice [Slice] inputs: [/backbone_model/model.6/cv1/act/Mul_output_0 -> (-1, 256, 40, 72)[FLOAT]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]], [/backbone_model/model.4/Mul_1_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.6/Slice for ONNX node: /backbone_model/model.6/Slice
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.6/Slice_output_0 for ONNX tensor: /backbone_model/model.6/Slice_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/Slice [Slice] outputs: [/backbone_model/model.6/Slice_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.6/Slice_1 [Slice]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/Mul_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/Mul_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/Slice_1 [Slice] inputs: [/backbone_model/model.6/cv1/act/Mul_output_0 -> (-1, 256, 40, 72)[FLOAT]], [/backbone_model/model.4/Mul_1_output_0 -> (1)[INT32]], [/backbone_model/model.6/Mul_1_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.6/Slice_1 for ONNX node: /backbone_model/model.6/Slice_1
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.6/Slice_1_output_0 for ONNX tensor: /backbone_model/model.6/Slice_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/Slice_1 [Slice] outputs: [/backbone_model/model.6/Slice_1_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.6/m.0/cv1/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/Slice_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1533
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1534
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/m.0/cv1/conv/Conv [Conv] inputs: [/backbone_model/model.6/Slice_1_output_0 -> (-1, 128, 40, 72)[FLOAT]], [onnx::Conv_1533 -> (128, 128, 3, 3)[HALF]], [onnx::Conv_1534 -> (128)[HALF]],
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution input dimensions: (-1, 128, 40, 72)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.6/m.0/cv1/conv/Conv for ONNX node: /backbone_model/model.6/m.0/cv1/conv/Conv
[TH_YF8S][26-01-14 11:43:42][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 128
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution output dimensions: (-1, 128, 40, 72)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.6/m.0/cv1/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.6/m.0/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/m.0/cv1/conv/Conv [Conv] outputs: [/backbone_model/model.6/m.0/cv1/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.6/m.0/cv1/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/m.0/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/m.0/cv1/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.6/m.0/cv1/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.6/m.0/cv1/act/Sigmoid for ONNX node: /backbone_model/model.6/m.0/cv1/act/Sigmoid
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.6/m.0/cv1/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.6/m.0/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/m.0/cv1/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.6/m.0/cv1/act/Sigmoid_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.6/m.0/cv1/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/m.0/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/m.0/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/m.0/cv1/act/Mul [Mul] inputs: [/backbone_model/model.6/m.0/cv1/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]], [/backbone_model/model.6/m.0/cv1/act/Sigmoid_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.6/m.0/cv1/act/Mul for ONNX node: /backbone_model/model.6/m.0/cv1/act/Mul
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.6/m.0/cv1/act/Mul_output_0 for ONNX tensor: /backbone_model/model.6/m.0/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/m.0/cv1/act/Mul [Mul] outputs: [/backbone_model/model.6/m.0/cv1/act/Mul_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.6/m.0/cv2/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/m.0/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1536
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1537
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/m.0/cv2/conv/Conv [Conv] inputs: [/backbone_model/model.6/m.0/cv1/act/Mul_output_0 -> (-1, 128, 40, 72)[FLOAT]], [onnx::Conv_1536 -> (128, 128, 3, 3)[HALF]], [onnx::Conv_1537 -> (128)[HALF]],
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution input dimensions: (-1, 128, 40, 72)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.6/m.0/cv2/conv/Conv for ONNX node: /backbone_model/model.6/m.0/cv2/conv/Conv
[TH_YF8S][26-01-14 11:43:42][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 128
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution output dimensions: (-1, 128, 40, 72)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.6/m.0/cv2/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.6/m.0/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/m.0/cv2/conv/Conv [Conv] outputs: [/backbone_model/model.6/m.0/cv2/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.6/m.0/cv2/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/m.0/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/m.0/cv2/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.6/m.0/cv2/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.6/m.0/cv2/act/Sigmoid for ONNX node: /backbone_model/model.6/m.0/cv2/act/Sigmoid
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.6/m.0/cv2/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.6/m.0/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/m.0/cv2/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.6/m.0/cv2/act/Sigmoid_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.6/m.0/cv2/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/m.0/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/m.0/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/m.0/cv2/act/Mul [Mul] inputs: [/backbone_model/model.6/m.0/cv2/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]], [/backbone_model/model.6/m.0/cv2/act/Sigmoid_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.6/m.0/cv2/act/Mul for ONNX node: /backbone_model/model.6/m.0/cv2/act/Mul
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.6/m.0/cv2/act/Mul_output_0 for ONNX tensor: /backbone_model/model.6/m.0/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/m.0/cv2/act/Mul [Mul] outputs: [/backbone_model/model.6/m.0/cv2/act/Mul_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.6/m.0/Add [Add]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/Slice_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/m.0/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/m.0/Add [Add] inputs: [/backbone_model/model.6/Slice_1_output_0 -> (-1, 128, 40, 72)[FLOAT]], [/backbone_model/model.6/m.0/cv2/act/Mul_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.6/m.0/Add for ONNX node: /backbone_model/model.6/m.0/Add
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.6/m.0/Add_output_0 for ONNX tensor: /backbone_model/model.6/m.0/Add_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/m.0/Add [Add] outputs: [/backbone_model/model.6/m.0/Add_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.6/m.1/cv1/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/m.0/Add_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1539
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1540
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/m.1/cv1/conv/Conv [Conv] inputs: [/backbone_model/model.6/m.0/Add_output_0 -> (-1, 128, 40, 72)[FLOAT]], [onnx::Conv_1539 -> (128, 128, 3, 3)[HALF]], [onnx::Conv_1540 -> (128)[HALF]],
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution input dimensions: (-1, 128, 40, 72)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.6/m.1/cv1/conv/Conv for ONNX node: /backbone_model/model.6/m.1/cv1/conv/Conv
[TH_YF8S][26-01-14 11:43:42][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 128
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution output dimensions: (-1, 128, 40, 72)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.6/m.1/cv1/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.6/m.1/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/m.1/cv1/conv/Conv [Conv] outputs: [/backbone_model/model.6/m.1/cv1/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.6/m.1/cv1/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/m.1/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/m.1/cv1/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.6/m.1/cv1/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.6/m.1/cv1/act/Sigmoid for ONNX node: /backbone_model/model.6/m.1/cv1/act/Sigmoid
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.6/m.1/cv1/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.6/m.1/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/m.1/cv1/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.6/m.1/cv1/act/Sigmoid_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.6/m.1/cv1/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/m.1/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/m.1/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/m.1/cv1/act/Mul [Mul] inputs: [/backbone_model/model.6/m.1/cv1/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]], [/backbone_model/model.6/m.1/cv1/act/Sigmoid_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.6/m.1/cv1/act/Mul for ONNX node: /backbone_model/model.6/m.1/cv1/act/Mul
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.6/m.1/cv1/act/Mul_output_0 for ONNX tensor: /backbone_model/model.6/m.1/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/m.1/cv1/act/Mul [Mul] outputs: [/backbone_model/model.6/m.1/cv1/act/Mul_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.6/m.1/cv2/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/m.1/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1542
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1543
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/m.1/cv2/conv/Conv [Conv] inputs: [/backbone_model/model.6/m.1/cv1/act/Mul_output_0 -> (-1, 128, 40, 72)[FLOAT]], [onnx::Conv_1542 -> (128, 128, 3, 3)[HALF]], [onnx::Conv_1543 -> (128)[HALF]],
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution input dimensions: (-1, 128, 40, 72)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.6/m.1/cv2/conv/Conv for ONNX node: /backbone_model/model.6/m.1/cv2/conv/Conv
[TH_YF8S][26-01-14 11:43:42][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 128
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution output dimensions: (-1, 128, 40, 72)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.6/m.1/cv2/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.6/m.1/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/m.1/cv2/conv/Conv [Conv] outputs: [/backbone_model/model.6/m.1/cv2/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.6/m.1/cv2/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/m.1/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/m.1/cv2/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.6/m.1/cv2/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.6/m.1/cv2/act/Sigmoid for ONNX node: /backbone_model/model.6/m.1/cv2/act/Sigmoid
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.6/m.1/cv2/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.6/m.1/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/m.1/cv2/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.6/m.1/cv2/act/Sigmoid_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.6/m.1/cv2/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/m.1/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/m.1/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/m.1/cv2/act/Mul [Mul] inputs: [/backbone_model/model.6/m.1/cv2/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]], [/backbone_model/model.6/m.1/cv2/act/Sigmoid_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.6/m.1/cv2/act/Mul for ONNX node: /backbone_model/model.6/m.1/cv2/act/Mul
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.6/m.1/cv2/act/Mul_output_0 for ONNX tensor: /backbone_model/model.6/m.1/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/m.1/cv2/act/Mul [Mul] outputs: [/backbone_model/model.6/m.1/cv2/act/Mul_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.6/m.1/Add [Add]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/m.0/Add_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/m.1/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/m.1/Add [Add] inputs: [/backbone_model/model.6/m.0/Add_output_0 -> (-1, 128, 40, 72)[FLOAT]], [/backbone_model/model.6/m.1/cv2/act/Mul_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.6/m.1/Add for ONNX node: /backbone_model/model.6/m.1/Add
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.6/m.1/Add_output_0 for ONNX tensor: /backbone_model/model.6/m.1/Add_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/m.1/Add [Add] outputs: [/backbone_model/model.6/m.1/Add_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.6/Concat [Concat]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/Slice_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/Slice_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/m.0/Add_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/m.1/Add_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/Concat [Concat] inputs: [/backbone_model/model.6/Slice_output_0 -> (-1, 128, 40, 72)[FLOAT]], [/backbone_model/model.6/Slice_1_output_0 -> (-1, 128, 40, 72)[FLOAT]], [/backbone_model/model.6/m.0/Add_output_0 -> (-1, 128, 40, 72)[FLOAT]], [/backbone_model/model.6/m.1/Add_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.6/Concat for ONNX node: /backbone_model/model.6/Concat
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.6/Concat_output_0 for ONNX tensor: /backbone_model/model.6/Concat_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/Concat [Concat] outputs: [/backbone_model/model.6/Concat_output_0 -> (-1, 512, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.6/cv2/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/Concat_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1545
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1546
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/cv2/conv/Conv [Conv] inputs: [/backbone_model/model.6/Concat_output_0 -> (-1, 512, 40, 72)[FLOAT]], [onnx::Conv_1545 -> (256, 512, 1, 1)[HALF]], [onnx::Conv_1546 -> (256)[HALF]],
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution input dimensions: (-1, 512, 40, 72)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.6/cv2/conv/Conv for ONNX node: /backbone_model/model.6/cv2/conv/Conv
[TH_YF8S][26-01-14 11:43:42][TRT] Using kernel: (1, 1), strides: (1, 1), prepadding: (0, 0), postpadding: (0, 0), dilations: (1, 1), numOutputs: 256
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution output dimensions: (-1, 256, 40, 72)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.6/cv2/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.6/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/cv2/conv/Conv [Conv] outputs: [/backbone_model/model.6/cv2/conv/Conv_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.6/cv2/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/cv2/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.6/cv2/conv/Conv_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.6/cv2/act/Sigmoid for ONNX node: /backbone_model/model.6/cv2/act/Sigmoid
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.6/cv2/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.6/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/cv2/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.6/cv2/act/Sigmoid_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.6/cv2/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/cv2/act/Mul [Mul] inputs: [/backbone_model/model.6/cv2/conv/Conv_output_0 -> (-1, 256, 40, 72)[FLOAT]], [/backbone_model/model.6/cv2/act/Sigmoid_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.6/cv2/act/Mul for ONNX node: /backbone_model/model.6/cv2/act/Mul
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.6/cv2/act/Mul_output_0 for ONNX tensor: /backbone_model/model.6/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.6/cv2/act/Mul [Mul] outputs: [/backbone_model/model.6/cv2/act/Mul_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.7/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1548
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1549
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.7/conv/Conv [Conv] inputs: [/backbone_model/model.6/cv2/act/Mul_output_0 -> (-1, 256, 40, 72)[FLOAT]], [onnx::Conv_1548 -> (512, 256, 3, 3)[HALF]], [onnx::Conv_1549 -> (512)[HALF]],
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution input dimensions: (-1, 256, 40, 72)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.7/conv/Conv for ONNX node: /backbone_model/model.7/conv/Conv
[TH_YF8S][26-01-14 11:43:42][TRT] Using kernel: (3, 3), strides: (2, 2), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 512
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution output dimensions: (-1, 512, 20, 36)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.7/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.7/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.7/conv/Conv [Conv] outputs: [/backbone_model/model.7/conv/Conv_output_0 -> (-1, 512, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.7/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.7/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.7/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.7/conv/Conv_output_0 -> (-1, 512, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.7/act/Sigmoid for ONNX node: /backbone_model/model.7/act/Sigmoid
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.7/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.7/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.7/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.7/act/Sigmoid_output_0 -> (-1, 512, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.7/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.7/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.7/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.7/act/Mul [Mul] inputs: [/backbone_model/model.7/conv/Conv_output_0 -> (-1, 512, 20, 36)[FLOAT]], [/backbone_model/model.7/act/Sigmoid_output_0 -> (-1, 512, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.7/act/Mul for ONNX node: /backbone_model/model.7/act/Mul
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.7/act/Mul_output_0 for ONNX tensor: /backbone_model/model.7/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.7/act/Mul [Mul] outputs: [/backbone_model/model.7/act/Mul_output_0 -> (-1, 512, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.8/cv1/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.7/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1551
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1552
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/cv1/conv/Conv [Conv] inputs: [/backbone_model/model.7/act/Mul_output_0 -> (-1, 512, 20, 36)[FLOAT]], [onnx::Conv_1551 -> (512, 512, 1, 1)[HALF]], [onnx::Conv_1552 -> (512)[HALF]],
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution input dimensions: (-1, 512, 20, 36)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.8/cv1/conv/Conv for ONNX node: /backbone_model/model.8/cv1/conv/Conv
[TH_YF8S][26-01-14 11:43:42][TRT] Using kernel: (1, 1), strides: (1, 1), prepadding: (0, 0), postpadding: (0, 0), dilations: (1, 1), numOutputs: 512
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution output dimensions: (-1, 512, 20, 36)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.8/cv1/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.8/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/cv1/conv/Conv [Conv] outputs: [/backbone_model/model.8/cv1/conv/Conv_output_0 -> (-1, 512, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.8/cv1/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.8/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/cv1/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.8/cv1/conv/Conv_output_0 -> (-1, 512, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.8/cv1/act/Sigmoid for ONNX node: /backbone_model/model.8/cv1/act/Sigmoid
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.8/cv1/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.8/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/cv1/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.8/cv1/act/Sigmoid_output_0 -> (-1, 512, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.8/cv1/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.8/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.8/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/cv1/act/Mul [Mul] inputs: [/backbone_model/model.8/cv1/conv/Conv_output_0 -> (-1, 512, 20, 36)[FLOAT]], [/backbone_model/model.8/cv1/act/Sigmoid_output_0 -> (-1, 512, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.8/cv1/act/Mul for ONNX node: /backbone_model/model.8/cv1/act/Mul
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.8/cv1/act/Mul_output_0 for ONNX tensor: /backbone_model/model.8/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/cv1/act/Mul [Mul] outputs: [/backbone_model/model.8/cv1/act/Mul_output_0 -> (-1, 512, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.8/Slice [Slice]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.8/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/Mul_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/Slice [Slice] inputs: [/backbone_model/model.8/cv1/act/Mul_output_0 -> (-1, 512, 20, 36)[FLOAT]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]], [/backbone_model/model.6/Mul_1_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.8/Slice for ONNX node: /backbone_model/model.8/Slice
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.8/Slice_output_0 for ONNX tensor: /backbone_model/model.8/Slice_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/Slice [Slice] outputs: [/backbone_model/model.8/Slice_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.8/Slice_1 [Slice]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.8/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/Mul_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.8/Mul_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/Slice_1 [Slice] inputs: [/backbone_model/model.8/cv1/act/Mul_output_0 -> (-1, 512, 20, 36)[FLOAT]], [/backbone_model/model.6/Mul_1_output_0 -> (1)[INT32]], [/backbone_model/model.8/Mul_1_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.8/Slice_1 for ONNX node: /backbone_model/model.8/Slice_1
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.8/Slice_1_output_0 for ONNX tensor: /backbone_model/model.8/Slice_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/Slice_1 [Slice] outputs: [/backbone_model/model.8/Slice_1_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.8/m.0/cv1/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.8/Slice_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1554
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1555
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/m.0/cv1/conv/Conv [Conv] inputs: [/backbone_model/model.8/Slice_1_output_0 -> (-1, 256, 20, 36)[FLOAT]], [onnx::Conv_1554 -> (256, 256, 3, 3)[HALF]], [onnx::Conv_1555 -> (256)[HALF]],
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution input dimensions: (-1, 256, 20, 36)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.8/m.0/cv1/conv/Conv for ONNX node: /backbone_model/model.8/m.0/cv1/conv/Conv
[TH_YF8S][26-01-14 11:43:42][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 256
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution output dimensions: (-1, 256, 20, 36)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.8/m.0/cv1/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.8/m.0/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/m.0/cv1/conv/Conv [Conv] outputs: [/backbone_model/model.8/m.0/cv1/conv/Conv_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.8/m.0/cv1/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.8/m.0/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/m.0/cv1/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.8/m.0/cv1/conv/Conv_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.8/m.0/cv1/act/Sigmoid for ONNX node: /backbone_model/model.8/m.0/cv1/act/Sigmoid
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.8/m.0/cv1/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.8/m.0/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/m.0/cv1/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.8/m.0/cv1/act/Sigmoid_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.8/m.0/cv1/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.8/m.0/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.8/m.0/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/m.0/cv1/act/Mul [Mul] inputs: [/backbone_model/model.8/m.0/cv1/conv/Conv_output_0 -> (-1, 256, 20, 36)[FLOAT]], [/backbone_model/model.8/m.0/cv1/act/Sigmoid_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.8/m.0/cv1/act/Mul for ONNX node: /backbone_model/model.8/m.0/cv1/act/Mul
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.8/m.0/cv1/act/Mul_output_0 for ONNX tensor: /backbone_model/model.8/m.0/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/m.0/cv1/act/Mul [Mul] outputs: [/backbone_model/model.8/m.0/cv1/act/Mul_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.8/m.0/cv2/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.8/m.0/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1557
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1558
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/m.0/cv2/conv/Conv [Conv] inputs: [/backbone_model/model.8/m.0/cv1/act/Mul_output_0 -> (-1, 256, 20, 36)[FLOAT]], [onnx::Conv_1557 -> (256, 256, 3, 3)[HALF]], [onnx::Conv_1558 -> (256)[HALF]],
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution input dimensions: (-1, 256, 20, 36)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.8/m.0/cv2/conv/Conv for ONNX node: /backbone_model/model.8/m.0/cv2/conv/Conv
[TH_YF8S][26-01-14 11:43:42][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 256
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution output dimensions: (-1, 256, 20, 36)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.8/m.0/cv2/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.8/m.0/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/m.0/cv2/conv/Conv [Conv] outputs: [/backbone_model/model.8/m.0/cv2/conv/Conv_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.8/m.0/cv2/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.8/m.0/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/m.0/cv2/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.8/m.0/cv2/conv/Conv_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.8/m.0/cv2/act/Sigmoid for ONNX node: /backbone_model/model.8/m.0/cv2/act/Sigmoid
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.8/m.0/cv2/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.8/m.0/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/m.0/cv2/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.8/m.0/cv2/act/Sigmoid_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.8/m.0/cv2/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.8/m.0/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.8/m.0/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/m.0/cv2/act/Mul [Mul] inputs: [/backbone_model/model.8/m.0/cv2/conv/Conv_output_0 -> (-1, 256, 20, 36)[FLOAT]], [/backbone_model/model.8/m.0/cv2/act/Sigmoid_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.8/m.0/cv2/act/Mul for ONNX node: /backbone_model/model.8/m.0/cv2/act/Mul
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.8/m.0/cv2/act/Mul_output_0 for ONNX tensor: /backbone_model/model.8/m.0/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/m.0/cv2/act/Mul [Mul] outputs: [/backbone_model/model.8/m.0/cv2/act/Mul_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.8/m.0/Add [Add]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.8/Slice_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.8/m.0/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/m.0/Add [Add] inputs: [/backbone_model/model.8/Slice_1_output_0 -> (-1, 256, 20, 36)[FLOAT]], [/backbone_model/model.8/m.0/cv2/act/Mul_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.8/m.0/Add for ONNX node: /backbone_model/model.8/m.0/Add
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.8/m.0/Add_output_0 for ONNX tensor: /backbone_model/model.8/m.0/Add_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/m.0/Add [Add] outputs: [/backbone_model/model.8/m.0/Add_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.8/Concat [Concat]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.8/Slice_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.8/Slice_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.8/m.0/Add_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/Concat [Concat] inputs: [/backbone_model/model.8/Slice_output_0 -> (-1, 256, 20, 36)[FLOAT]], [/backbone_model/model.8/Slice_1_output_0 -> (-1, 256, 20, 36)[FLOAT]], [/backbone_model/model.8/m.0/Add_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.8/Concat for ONNX node: /backbone_model/model.8/Concat
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.8/Concat_output_0 for ONNX tensor: /backbone_model/model.8/Concat_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/Concat [Concat] outputs: [/backbone_model/model.8/Concat_output_0 -> (-1, 768, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.8/cv2/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.8/Concat_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1560
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1561
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/cv2/conv/Conv [Conv] inputs: [/backbone_model/model.8/Concat_output_0 -> (-1, 768, 20, 36)[FLOAT]], [onnx::Conv_1560 -> (512, 768, 1, 1)[HALF]], [onnx::Conv_1561 -> (512)[HALF]],
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution input dimensions: (-1, 768, 20, 36)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.8/cv2/conv/Conv for ONNX node: /backbone_model/model.8/cv2/conv/Conv
[TH_YF8S][26-01-14 11:43:42][TRT] Using kernel: (1, 1), strides: (1, 1), prepadding: (0, 0), postpadding: (0, 0), dilations: (1, 1), numOutputs: 512
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution output dimensions: (-1, 512, 20, 36)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.8/cv2/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.8/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/cv2/conv/Conv [Conv] outputs: [/backbone_model/model.8/cv2/conv/Conv_output_0 -> (-1, 512, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.8/cv2/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.8/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/cv2/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.8/cv2/conv/Conv_output_0 -> (-1, 512, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.8/cv2/act/Sigmoid for ONNX node: /backbone_model/model.8/cv2/act/Sigmoid
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.8/cv2/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.8/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/cv2/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.8/cv2/act/Sigmoid_output_0 -> (-1, 512, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.8/cv2/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.8/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.8/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/cv2/act/Mul [Mul] inputs: [/backbone_model/model.8/cv2/conv/Conv_output_0 -> (-1, 512, 20, 36)[FLOAT]], [/backbone_model/model.8/cv2/act/Sigmoid_output_0 -> (-1, 512, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.8/cv2/act/Mul for ONNX node: /backbone_model/model.8/cv2/act/Mul
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.8/cv2/act/Mul_output_0 for ONNX tensor: /backbone_model/model.8/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.8/cv2/act/Mul [Mul] outputs: [/backbone_model/model.8/cv2/act/Mul_output_0 -> (-1, 512, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.9/cv1/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.8/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1563
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1564
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.9/cv1/conv/Conv [Conv] inputs: [/backbone_model/model.8/cv2/act/Mul_output_0 -> (-1, 512, 20, 36)[FLOAT]], [onnx::Conv_1563 -> (256, 512, 1, 1)[HALF]], [onnx::Conv_1564 -> (256)[HALF]],
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution input dimensions: (-1, 512, 20, 36)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.9/cv1/conv/Conv for ONNX node: /backbone_model/model.9/cv1/conv/Conv
[TH_YF8S][26-01-14 11:43:42][TRT] Using kernel: (1, 1), strides: (1, 1), prepadding: (0, 0), postpadding: (0, 0), dilations: (1, 1), numOutputs: 256
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution output dimensions: (-1, 256, 20, 36)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.9/cv1/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.9/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.9/cv1/conv/Conv [Conv] outputs: [/backbone_model/model.9/cv1/conv/Conv_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.9/cv1/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.9/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.9/cv1/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.9/cv1/conv/Conv_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.9/cv1/act/Sigmoid for ONNX node: /backbone_model/model.9/cv1/act/Sigmoid
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.9/cv1/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.9/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.9/cv1/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.9/cv1/act/Sigmoid_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.9/cv1/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.9/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.9/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.9/cv1/act/Mul [Mul] inputs: [/backbone_model/model.9/cv1/conv/Conv_output_0 -> (-1, 256, 20, 36)[FLOAT]], [/backbone_model/model.9/cv1/act/Sigmoid_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.9/cv1/act/Mul for ONNX node: /backbone_model/model.9/cv1/act/Mul
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.9/cv1/act/Mul_output_0 for ONNX tensor: /backbone_model/model.9/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.9/cv1/act/Mul [Mul] outputs: [/backbone_model/model.9/cv1/act/Mul_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.9/m/MaxPool [MaxPool]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.9/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.9/m/MaxPool [MaxPool] inputs: [/backbone_model/model.9/cv1/act/Mul_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.9/m/MaxPool for ONNX node: /backbone_model/model.9/m/MaxPool
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.9/m/MaxPool_output_0 for ONNX tensor: /backbone_model/model.9/m/MaxPool_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.9/m/MaxPool [MaxPool] outputs: [/backbone_model/model.9/m/MaxPool_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.9/m_1/MaxPool [MaxPool]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.9/m/MaxPool_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.9/m_1/MaxPool [MaxPool] inputs: [/backbone_model/model.9/m/MaxPool_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.9/m_1/MaxPool for ONNX node: /backbone_model/model.9/m_1/MaxPool
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.9/m_1/MaxPool_output_0 for ONNX tensor: /backbone_model/model.9/m_1/MaxPool_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.9/m_1/MaxPool [MaxPool] outputs: [/backbone_model/model.9/m_1/MaxPool_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.9/m_2/MaxPool [MaxPool]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.9/m_1/MaxPool_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.9/m_2/MaxPool [MaxPool] inputs: [/backbone_model/model.9/m_1/MaxPool_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.9/m_2/MaxPool for ONNX node: /backbone_model/model.9/m_2/MaxPool
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.9/m_2/MaxPool_output_0 for ONNX tensor: /backbone_model/model.9/m_2/MaxPool_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.9/m_2/MaxPool [MaxPool] outputs: [/backbone_model/model.9/m_2/MaxPool_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.9/Concat [Concat]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.9/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.9/m/MaxPool_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.9/m_1/MaxPool_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.9/m_2/MaxPool_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.9/Concat [Concat] inputs: [/backbone_model/model.9/cv1/act/Mul_output_0 -> (-1, 256, 20, 36)[FLOAT]], [/backbone_model/model.9/m/MaxPool_output_0 -> (-1, 256, 20, 36)[FLOAT]], [/backbone_model/model.9/m_1/MaxPool_output_0 -> (-1, 256, 20, 36)[FLOAT]], [/backbone_model/model.9/m_2/MaxPool_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.9/Concat for ONNX node: /backbone_model/model.9/Concat
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.9/Concat_output_0 for ONNX tensor: /backbone_model/model.9/Concat_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.9/Concat [Concat] outputs: [/backbone_model/model.9/Concat_output_0 -> (-1, 1024, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.9/cv2/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.9/Concat_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1566
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1567
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.9/cv2/conv/Conv [Conv] inputs: [/backbone_model/model.9/Concat_output_0 -> (-1, 1024, 20, 36)[FLOAT]], [onnx::Conv_1566 -> (512, 1024, 1, 1)[HALF]], [onnx::Conv_1567 -> (512)[HALF]],
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution input dimensions: (-1, 1024, 20, 36)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.9/cv2/conv/Conv for ONNX node: /backbone_model/model.9/cv2/conv/Conv
[TH_YF8S][26-01-14 11:43:42][TRT] Using kernel: (1, 1), strides: (1, 1), prepadding: (0, 0), postpadding: (0, 0), dilations: (1, 1), numOutputs: 512
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution output dimensions: (-1, 512, 20, 36)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.9/cv2/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.9/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.9/cv2/conv/Conv [Conv] outputs: [/backbone_model/model.9/cv2/conv/Conv_output_0 -> (-1, 512, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.9/cv2/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.9/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.9/cv2/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.9/cv2/conv/Conv_output_0 -> (-1, 512, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.9/cv2/act/Sigmoid for ONNX node: /backbone_model/model.9/cv2/act/Sigmoid
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.9/cv2/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.9/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.9/cv2/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.9/cv2/act/Sigmoid_output_0 -> (-1, 512, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.9/cv2/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.9/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.9/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.9/cv2/act/Mul [Mul] inputs: [/backbone_model/model.9/cv2/conv/Conv_output_0 -> (-1, 512, 20, 36)[FLOAT]], [/backbone_model/model.9/cv2/act/Sigmoid_output_0 -> (-1, 512, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.9/cv2/act/Mul for ONNX node: /backbone_model/model.9/cv2/act/Mul
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.9/cv2/act/Mul_output_0 for ONNX tensor: /backbone_model/model.9/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.9/cv2/act/Mul [Mul] outputs: [/backbone_model/model.9/cv2/act/Mul_output_0 -> (-1, 512, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.10/Resize [Resize]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.9/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.10/Constant_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.10/Resize [Resize] inputs: [/backbone_model/model.9/cv2/act/Mul_output_0 -> (-1, 512, 20, 36)[FLOAT]], [optional input, not set], [/backbone_model/model.10/Constant_output_0 -> (4)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.10/Resize for ONNX node: /backbone_model/model.10/Resize
[TH_YF8S][26-01-14 11:43:42][TRT] Running resize layer with:
ian 14 09:43:42 teste sh[3722914]: Transformation mode: asymmetric
ian 14 09:43:42 teste sh[3722914]: Resize mode: nearest
ian 14 09:43:42 teste sh[3722914]:
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.10/Resize_output_0 for ONNX tensor: /backbone_model/model.10/Resize_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.10/Resize [Resize] outputs: [/backbone_model/model.10/Resize_output_0 -> (-1, 512, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.11/Concat [Concat]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.10/Resize_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.11/Concat [Concat] inputs: [/backbone_model/model.10/Resize_output_0 -> (-1, 512, 40, 72)[FLOAT]], [/backbone_model/model.6/cv2/act/Mul_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.11/Concat for ONNX node: /backbone_model/model.11/Concat
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.11/Concat_output_0 for ONNX tensor: /backbone_model/model.11/Concat_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.11/Concat [Concat] outputs: [/backbone_model/model.11/Concat_output_0 -> (-1, 768, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.12/cv1/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.11/Concat_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1569
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1570
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.12/cv1/conv/Conv [Conv] inputs: [/backbone_model/model.11/Concat_output_0 -> (-1, 768, 40, 72)[FLOAT]], [onnx::Conv_1569 -> (256, 768, 1, 1)[HALF]], [onnx::Conv_1570 -> (256)[HALF]],
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution input dimensions: (-1, 768, 40, 72)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.12/cv1/conv/Conv for ONNX node: /backbone_model/model.12/cv1/conv/Conv
[TH_YF8S][26-01-14 11:43:42][TRT] Using kernel: (1, 1), strides: (1, 1), prepadding: (0, 0), postpadding: (0, 0), dilations: (1, 1), numOutputs: 256
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution output dimensions: (-1, 256, 40, 72)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.12/cv1/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.12/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.12/cv1/conv/Conv [Conv] outputs: [/backbone_model/model.12/cv1/conv/Conv_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.12/cv1/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.12/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.12/cv1/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.12/cv1/conv/Conv_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.12/cv1/act/Sigmoid for ONNX node: /backbone_model/model.12/cv1/act/Sigmoid
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.12/cv1/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.12/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.12/cv1/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.12/cv1/act/Sigmoid_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.12/cv1/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.12/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.12/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.12/cv1/act/Mul [Mul] inputs: [/backbone_model/model.12/cv1/conv/Conv_output_0 -> (-1, 256, 40, 72)[FLOAT]], [/backbone_model/model.12/cv1/act/Sigmoid_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.12/cv1/act/Mul for ONNX node: /backbone_model/model.12/cv1/act/Mul
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.12/cv1/act/Mul_output_0 for ONNX tensor: /backbone_model/model.12/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.12/cv1/act/Mul [Mul] outputs: [/backbone_model/model.12/cv1/act/Mul_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.12/Slice [Slice]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.12/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/Mul_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.12/Slice [Slice] inputs: [/backbone_model/model.12/cv1/act/Mul_output_0 -> (-1, 256, 40, 72)[FLOAT]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]], [/backbone_model/model.4/Mul_1_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.12/Slice for ONNX node: /backbone_model/model.12/Slice
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.12/Slice_output_0 for ONNX tensor: /backbone_model/model.12/Slice_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.12/Slice [Slice] outputs: [/backbone_model/model.12/Slice_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.12/Slice_1 [Slice]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.12/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.4/Mul_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.6/Mul_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.12/Slice_1 [Slice] inputs: [/backbone_model/model.12/cv1/act/Mul_output_0 -> (-1, 256, 40, 72)[FLOAT]], [/backbone_model/model.4/Mul_1_output_0 -> (1)[INT32]], [/backbone_model/model.6/Mul_1_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.12/Slice_1 for ONNX node: /backbone_model/model.12/Slice_1
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.12/Slice_1_output_0 for ONNX tensor: /backbone_model/model.12/Slice_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.12/Slice_1 [Slice] outputs: [/backbone_model/model.12/Slice_1_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.12/m.0/cv1/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.12/Slice_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1572
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1573
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.12/m.0/cv1/conv/Conv [Conv] inputs: [/backbone_model/model.12/Slice_1_output_0 -> (-1, 128, 40, 72)[FLOAT]], [onnx::Conv_1572 -> (128, 128, 3, 3)[HALF]], [onnx::Conv_1573 -> (128)[HALF]],
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution input dimensions: (-1, 128, 40, 72)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.12/m.0/cv1/conv/Conv for ONNX node: /backbone_model/model.12/m.0/cv1/conv/Conv
[TH_YF8S][26-01-14 11:43:42][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 128
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution output dimensions: (-1, 128, 40, 72)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.12/m.0/cv1/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.12/m.0/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.12/m.0/cv1/conv/Conv [Conv] outputs: [/backbone_model/model.12/m.0/cv1/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.12/m.0/cv1/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.12/m.0/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.12/m.0/cv1/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.12/m.0/cv1/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.12/m.0/cv1/act/Sigmoid for ONNX node: /backbone_model/model.12/m.0/cv1/act/Sigmoid
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.12/m.0/cv1/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.12/m.0/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.12/m.0/cv1/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.12/m.0/cv1/act/Sigmoid_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.12/m.0/cv1/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.12/m.0/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.12/m.0/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.12/m.0/cv1/act/Mul [Mul] inputs: [/backbone_model/model.12/m.0/cv1/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]], [/backbone_model/model.12/m.0/cv1/act/Sigmoid_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.12/m.0/cv1/act/Mul for ONNX node: /backbone_model/model.12/m.0/cv1/act/Mul
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.12/m.0/cv1/act/Mul_output_0 for ONNX tensor: /backbone_model/model.12/m.0/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.12/m.0/cv1/act/Mul [Mul] outputs: [/backbone_model/model.12/m.0/cv1/act/Mul_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.12/m.0/cv2/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.12/m.0/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1575
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1576
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.12/m.0/cv2/conv/Conv [Conv] inputs: [/backbone_model/model.12/m.0/cv1/act/Mul_output_0 -> (-1, 128, 40, 72)[FLOAT]], [onnx::Conv_1575 -> (128, 128, 3, 3)[HALF]], [onnx::Conv_1576 -> (128)[HALF]],
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution input dimensions: (-1, 128, 40, 72)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.12/m.0/cv2/conv/Conv for ONNX node: /backbone_model/model.12/m.0/cv2/conv/Conv
[TH_YF8S][26-01-14 11:43:42][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 128
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution output dimensions: (-1, 128, 40, 72)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.12/m.0/cv2/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.12/m.0/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.12/m.0/cv2/conv/Conv [Conv] outputs: [/backbone_model/model.12/m.0/cv2/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.12/m.0/cv2/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.12/m.0/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.12/m.0/cv2/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.12/m.0/cv2/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.12/m.0/cv2/act/Sigmoid for ONNX node: /backbone_model/model.12/m.0/cv2/act/Sigmoid
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.12/m.0/cv2/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.12/m.0/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.12/m.0/cv2/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.12/m.0/cv2/act/Sigmoid_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.12/m.0/cv2/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.12/m.0/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.12/m.0/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.12/m.0/cv2/act/Mul [Mul] inputs: [/backbone_model/model.12/m.0/cv2/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]], [/backbone_model/model.12/m.0/cv2/act/Sigmoid_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.12/m.0/cv2/act/Mul for ONNX node: /backbone_model/model.12/m.0/cv2/act/Mul
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.12/m.0/cv2/act/Mul_output_0 for ONNX tensor: /backbone_model/model.12/m.0/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.12/m.0/cv2/act/Mul [Mul] outputs: [/backbone_model/model.12/m.0/cv2/act/Mul_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.12/Concat [Concat]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.12/Slice_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.12/Slice_1_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.12/m.0/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.12/Concat [Concat] inputs: [/backbone_model/model.12/Slice_output_0 -> (-1, 128, 40, 72)[FLOAT]], [/backbone_model/model.12/Slice_1_output_0 -> (-1, 128, 40, 72)[FLOAT]], [/backbone_model/model.12/m.0/cv2/act/Mul_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.12/Concat for ONNX node: /backbone_model/model.12/Concat
[TH_YF8S][26-01-14 11:43:42][TRT] Registering tensor: /backbone_model/model.12/Concat_output_0 for ONNX tensor: /backbone_model/model.12/Concat_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.12/Concat [Concat] outputs: [/backbone_model/model.12/Concat_output_0 -> (-1, 384, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:42][TRT] Parsing node: /backbone_model/model.12/cv2/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: /backbone_model/model.12/Concat_output_0
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1578
[TH_YF8S][26-01-14 11:43:42][TRT] Searching for input: onnx::Conv_1579
[TH_YF8S][26-01-14 11:43:42][TRT] /backbone_model/model.12/cv2/conv/Conv [Conv] inputs: [/backbone_model/model.12/Concat_output_0 -> (-1, 384, 40, 72)[FLOAT]], [onnx::Conv_1578 -> (256, 384, 1, 1)[HALF]], [onnx::Conv_1579 -> (256)[HALF]],
[TH_YF8S][26-01-14 11:43:42][TRT] Convolution input dimensions: (-1, 384, 40, 72)
[TH_YF8S][26-01-14 11:43:42][TRT] Registering layer: /backbone_model/model.12/cv2/conv/Conv for ONNX node: /backbone_model/model.12/cv2/conv/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (1, 1), strides: (1, 1), prepadding: (0, 0), postpadding: (0, 0), dilations: (1, 1), numOutputs: 256
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 256, 40, 72)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.12/cv2/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.12/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.12/cv2/conv/Conv [Conv] outputs: [/backbone_model/model.12/cv2/conv/Conv_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.12/cv2/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.12/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.12/cv2/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.12/cv2/conv/Conv_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.12/cv2/act/Sigmoid for ONNX node: /backbone_model/model.12/cv2/act/Sigmoid
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.12/cv2/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.12/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.12/cv2/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.12/cv2/act/Sigmoid_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.12/cv2/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.12/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.12/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.12/cv2/act/Mul [Mul] inputs: [/backbone_model/model.12/cv2/conv/Conv_output_0 -> (-1, 256, 40, 72)[FLOAT]], [/backbone_model/model.12/cv2/act/Sigmoid_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.12/cv2/act/Mul for ONNX node: /backbone_model/model.12/cv2/act/Mul
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.12/cv2/act/Mul_output_0 for ONNX tensor: /backbone_model/model.12/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.12/cv2/act/Mul [Mul] outputs: [/backbone_model/model.12/cv2/act/Mul_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.13/Resize [Resize]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.12/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.10/Constant_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.13/Resize [Resize] inputs: [/backbone_model/model.12/cv2/act/Mul_output_0 -> (-1, 256, 40, 72)[FLOAT]], [optional input, not set], [/backbone_model/model.10/Constant_output_0 -> (4)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.13/Resize for ONNX node: /backbone_model/model.13/Resize
[TH_YF8S][26-01-14 11:43:43][TRT] Running resize layer with:
ian 14 09:43:43 teste sh[3722914]: Transformation mode: asymmetric
ian 14 09:43:43 teste sh[3722914]: Resize mode: nearest
ian 14 09:43:43 teste sh[3722914]:
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.13/Resize_output_0 for ONNX tensor: /backbone_model/model.13/Resize_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.13/Resize [Resize] outputs: [/backbone_model/model.13/Resize_output_0 -> (-1, 256, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.14/Concat [Concat]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.13/Resize_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.4/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.14/Concat [Concat] inputs: [/backbone_model/model.13/Resize_output_0 -> (-1, 256, 80, 144)[FLOAT]], [/backbone_model/model.4/cv2/act/Mul_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.14/Concat for ONNX node: /backbone_model/model.14/Concat
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.14/Concat_output_0 for ONNX tensor: /backbone_model/model.14/Concat_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.14/Concat [Concat] outputs: [/backbone_model/model.14/Concat_output_0 -> (-1, 384, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.15/cv1/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.14/Concat_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1581
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1582
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.15/cv1/conv/Conv [Conv] inputs: [/backbone_model/model.14/Concat_output_0 -> (-1, 384, 80, 144)[FLOAT]], [onnx::Conv_1581 -> (128, 384, 1, 1)[HALF]], [onnx::Conv_1582 -> (128)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 384, 80, 144)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.15/cv1/conv/Conv for ONNX node: /backbone_model/model.15/cv1/conv/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (1, 1), strides: (1, 1), prepadding: (0, 0), postpadding: (0, 0), dilations: (1, 1), numOutputs: 128
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 128, 80, 144)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.15/cv1/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.15/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.15/cv1/conv/Conv [Conv] outputs: [/backbone_model/model.15/cv1/conv/Conv_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.15/cv1/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.15/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.15/cv1/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.15/cv1/conv/Conv_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.15/cv1/act/Sigmoid for ONNX node: /backbone_model/model.15/cv1/act/Sigmoid
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.15/cv1/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.15/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.15/cv1/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.15/cv1/act/Sigmoid_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.15/cv1/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.15/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.15/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.15/cv1/act/Mul [Mul] inputs: [/backbone_model/model.15/cv1/conv/Conv_output_0 -> (-1, 128, 80, 144)[FLOAT]], [/backbone_model/model.15/cv1/act/Sigmoid_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.15/cv1/act/Mul for ONNX node: /backbone_model/model.15/cv1/act/Mul
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.15/cv1/act/Mul_output_0 for ONNX tensor: /backbone_model/model.15/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.15/cv1/act/Mul [Mul] outputs: [/backbone_model/model.15/cv1/act/Mul_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.15/Slice [Slice]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.15/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.2/Mul_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.15/Slice [Slice] inputs: [/backbone_model/model.15/cv1/act/Mul_output_0 -> (-1, 128, 80, 144)[FLOAT]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]], [/backbone_model/model.2/Mul_1_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.15/Slice for ONNX node: /backbone_model/model.15/Slice
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.15/Slice_output_0 for ONNX tensor: /backbone_model/model.15/Slice_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.15/Slice [Slice] outputs: [/backbone_model/model.15/Slice_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.15/Slice_1 [Slice]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.15/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.2/Mul_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.4/Mul_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.15/Slice_1 [Slice] inputs: [/backbone_model/model.15/cv1/act/Mul_output_0 -> (-1, 128, 80, 144)[FLOAT]], [/backbone_model/model.2/Mul_1_output_0 -> (1)[INT32]], [/backbone_model/model.4/Mul_1_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.15/Slice_1 for ONNX node: /backbone_model/model.15/Slice_1
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.15/Slice_1_output_0 for ONNX tensor: /backbone_model/model.15/Slice_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.15/Slice_1 [Slice] outputs: [/backbone_model/model.15/Slice_1_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.15/m.0/cv1/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.15/Slice_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1584
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1585
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.15/m.0/cv1/conv/Conv [Conv] inputs: [/backbone_model/model.15/Slice_1_output_0 -> (-1, 64, 80, 144)[FLOAT]], [onnx::Conv_1584 -> (64, 64, 3, 3)[HALF]], [onnx::Conv_1585 -> (64)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 64, 80, 144)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.15/m.0/cv1/conv/Conv for ONNX node: /backbone_model/model.15/m.0/cv1/conv/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 64
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 64, 80, 144)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.15/m.0/cv1/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.15/m.0/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.15/m.0/cv1/conv/Conv [Conv] outputs: [/backbone_model/model.15/m.0/cv1/conv/Conv_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.15/m.0/cv1/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.15/m.0/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.15/m.0/cv1/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.15/m.0/cv1/conv/Conv_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.15/m.0/cv1/act/Sigmoid for ONNX node: /backbone_model/model.15/m.0/cv1/act/Sigmoid
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.15/m.0/cv1/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.15/m.0/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.15/m.0/cv1/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.15/m.0/cv1/act/Sigmoid_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.15/m.0/cv1/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.15/m.0/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.15/m.0/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.15/m.0/cv1/act/Mul [Mul] inputs: [/backbone_model/model.15/m.0/cv1/conv/Conv_output_0 -> (-1, 64, 80, 144)[FLOAT]], [/backbone_model/model.15/m.0/cv1/act/Sigmoid_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.15/m.0/cv1/act/Mul for ONNX node: /backbone_model/model.15/m.0/cv1/act/Mul
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.15/m.0/cv1/act/Mul_output_0 for ONNX tensor: /backbone_model/model.15/m.0/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.15/m.0/cv1/act/Mul [Mul] outputs: [/backbone_model/model.15/m.0/cv1/act/Mul_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.15/m.0/cv2/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.15/m.0/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1587
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1588
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.15/m.0/cv2/conv/Conv [Conv] inputs: [/backbone_model/model.15/m.0/cv1/act/Mul_output_0 -> (-1, 64, 80, 144)[FLOAT]], [onnx::Conv_1587 -> (64, 64, 3, 3)[HALF]], [onnx::Conv_1588 -> (64)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 64, 80, 144)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.15/m.0/cv2/conv/Conv for ONNX node: /backbone_model/model.15/m.0/cv2/conv/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 64
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 64, 80, 144)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.15/m.0/cv2/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.15/m.0/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.15/m.0/cv2/conv/Conv [Conv] outputs: [/backbone_model/model.15/m.0/cv2/conv/Conv_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.15/m.0/cv2/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.15/m.0/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.15/m.0/cv2/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.15/m.0/cv2/conv/Conv_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.15/m.0/cv2/act/Sigmoid for ONNX node: /backbone_model/model.15/m.0/cv2/act/Sigmoid
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.15/m.0/cv2/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.15/m.0/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.15/m.0/cv2/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.15/m.0/cv2/act/Sigmoid_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.15/m.0/cv2/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.15/m.0/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.15/m.0/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.15/m.0/cv2/act/Mul [Mul] inputs: [/backbone_model/model.15/m.0/cv2/conv/Conv_output_0 -> (-1, 64, 80, 144)[FLOAT]], [/backbone_model/model.15/m.0/cv2/act/Sigmoid_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.15/m.0/cv2/act/Mul for ONNX node: /backbone_model/model.15/m.0/cv2/act/Mul
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.15/m.0/cv2/act/Mul_output_0 for ONNX tensor: /backbone_model/model.15/m.0/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.15/m.0/cv2/act/Mul [Mul] outputs: [/backbone_model/model.15/m.0/cv2/act/Mul_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.15/Concat [Concat]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.15/Slice_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.15/Slice_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.15/m.0/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.15/Concat [Concat] inputs: [/backbone_model/model.15/Slice_output_0 -> (-1, 64, 80, 144)[FLOAT]], [/backbone_model/model.15/Slice_1_output_0 -> (-1, 64, 80, 144)[FLOAT]], [/backbone_model/model.15/m.0/cv2/act/Mul_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.15/Concat for ONNX node: /backbone_model/model.15/Concat
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.15/Concat_output_0 for ONNX tensor: /backbone_model/model.15/Concat_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.15/Concat [Concat] outputs: [/backbone_model/model.15/Concat_output_0 -> (-1, 192, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.15/cv2/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.15/Concat_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1590
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1591
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.15/cv2/conv/Conv [Conv] inputs: [/backbone_model/model.15/Concat_output_0 -> (-1, 192, 80, 144)[FLOAT]], [onnx::Conv_1590 -> (128, 192, 1, 1)[HALF]], [onnx::Conv_1591 -> (128)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 192, 80, 144)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.15/cv2/conv/Conv for ONNX node: /backbone_model/model.15/cv2/conv/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (1, 1), strides: (1, 1), prepadding: (0, 0), postpadding: (0, 0), dilations: (1, 1), numOutputs: 128
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 128, 80, 144)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.15/cv2/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.15/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.15/cv2/conv/Conv [Conv] outputs: [/backbone_model/model.15/cv2/conv/Conv_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.15/cv2/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.15/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.15/cv2/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.15/cv2/conv/Conv_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.15/cv2/act/Sigmoid for ONNX node: /backbone_model/model.15/cv2/act/Sigmoid
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.15/cv2/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.15/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.15/cv2/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.15/cv2/act/Sigmoid_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.15/cv2/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.15/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.15/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.15/cv2/act/Mul [Mul] inputs: [/backbone_model/model.15/cv2/conv/Conv_output_0 -> (-1, 128, 80, 144)[FLOAT]], [/backbone_model/model.15/cv2/act/Sigmoid_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.15/cv2/act/Mul for ONNX node: /backbone_model/model.15/cv2/act/Mul
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.15/cv2/act/Mul_output_0 for ONNX tensor: /backbone_model/model.15/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.15/cv2/act/Mul [Mul] outputs: [/backbone_model/model.15/cv2/act/Mul_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.16/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.15/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1593
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1594
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.16/conv/Conv [Conv] inputs: [/backbone_model/model.15/cv2/act/Mul_output_0 -> (-1, 128, 80, 144)[FLOAT]], [onnx::Conv_1593 -> (128, 128, 3, 3)[HALF]], [onnx::Conv_1594 -> (128)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 128, 80, 144)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.16/conv/Conv for ONNX node: /backbone_model/model.16/conv/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (3, 3), strides: (2, 2), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 128
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 128, 40, 72)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.16/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.16/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.16/conv/Conv [Conv] outputs: [/backbone_model/model.16/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.16/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.16/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.16/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.16/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.16/act/Sigmoid for ONNX node: /backbone_model/model.16/act/Sigmoid
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.16/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.16/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.16/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.16/act/Sigmoid_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.16/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.16/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.16/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.16/act/Mul [Mul] inputs: [/backbone_model/model.16/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]], [/backbone_model/model.16/act/Sigmoid_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.16/act/Mul for ONNX node: /backbone_model/model.16/act/Mul
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.16/act/Mul_output_0 for ONNX tensor: /backbone_model/model.16/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.16/act/Mul [Mul] outputs: [/backbone_model/model.16/act/Mul_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.17/Concat [Concat]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.16/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.12/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.17/Concat [Concat] inputs: [/backbone_model/model.16/act/Mul_output_0 -> (-1, 128, 40, 72)[FLOAT]], [/backbone_model/model.12/cv2/act/Mul_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.17/Concat for ONNX node: /backbone_model/model.17/Concat
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.17/Concat_output_0 for ONNX tensor: /backbone_model/model.17/Concat_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.17/Concat [Concat] outputs: [/backbone_model/model.17/Concat_output_0 -> (-1, 384, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.18/cv1/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.17/Concat_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1596
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1597
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.18/cv1/conv/Conv [Conv] inputs: [/backbone_model/model.17/Concat_output_0 -> (-1, 384, 40, 72)[FLOAT]], [onnx::Conv_1596 -> (256, 384, 1, 1)[HALF]], [onnx::Conv_1597 -> (256)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 384, 40, 72)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.18/cv1/conv/Conv for ONNX node: /backbone_model/model.18/cv1/conv/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (1, 1), strides: (1, 1), prepadding: (0, 0), postpadding: (0, 0), dilations: (1, 1), numOutputs: 256
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 256, 40, 72)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.18/cv1/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.18/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.18/cv1/conv/Conv [Conv] outputs: [/backbone_model/model.18/cv1/conv/Conv_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.18/cv1/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.18/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.18/cv1/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.18/cv1/conv/Conv_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.18/cv1/act/Sigmoid for ONNX node: /backbone_model/model.18/cv1/act/Sigmoid
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.18/cv1/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.18/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.18/cv1/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.18/cv1/act/Sigmoid_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.18/cv1/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.18/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.18/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.18/cv1/act/Mul [Mul] inputs: [/backbone_model/model.18/cv1/conv/Conv_output_0 -> (-1, 256, 40, 72)[FLOAT]], [/backbone_model/model.18/cv1/act/Sigmoid_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.18/cv1/act/Mul for ONNX node: /backbone_model/model.18/cv1/act/Mul
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.18/cv1/act/Mul_output_0 for ONNX tensor: /backbone_model/model.18/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.18/cv1/act/Mul [Mul] outputs: [/backbone_model/model.18/cv1/act/Mul_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.18/Slice [Slice]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.18/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.4/Mul_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.18/Slice [Slice] inputs: [/backbone_model/model.18/cv1/act/Mul_output_0 -> (-1, 256, 40, 72)[FLOAT]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]], [/backbone_model/model.4/Mul_1_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.18/Slice for ONNX node: /backbone_model/model.18/Slice
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.18/Slice_output_0 for ONNX tensor: /backbone_model/model.18/Slice_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.18/Slice [Slice] outputs: [/backbone_model/model.18/Slice_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.18/Slice_1 [Slice]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.18/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.4/Mul_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.6/Mul_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.18/Slice_1 [Slice] inputs: [/backbone_model/model.18/cv1/act/Mul_output_0 -> (-1, 256, 40, 72)[FLOAT]], [/backbone_model/model.4/Mul_1_output_0 -> (1)[INT32]], [/backbone_model/model.6/Mul_1_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.18/Slice_1 for ONNX node: /backbone_model/model.18/Slice_1
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.18/Slice_1_output_0 for ONNX tensor: /backbone_model/model.18/Slice_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.18/Slice_1 [Slice] outputs: [/backbone_model/model.18/Slice_1_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.18/m.0/cv1/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.18/Slice_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1599
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1600
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.18/m.0/cv1/conv/Conv [Conv] inputs: [/backbone_model/model.18/Slice_1_output_0 -> (-1, 128, 40, 72)[FLOAT]], [onnx::Conv_1599 -> (128, 128, 3, 3)[HALF]], [onnx::Conv_1600 -> (128)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 128, 40, 72)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.18/m.0/cv1/conv/Conv for ONNX node: /backbone_model/model.18/m.0/cv1/conv/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 128
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 128, 40, 72)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.18/m.0/cv1/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.18/m.0/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.18/m.0/cv1/conv/Conv [Conv] outputs: [/backbone_model/model.18/m.0/cv1/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.18/m.0/cv1/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.18/m.0/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.18/m.0/cv1/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.18/m.0/cv1/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.18/m.0/cv1/act/Sigmoid for ONNX node: /backbone_model/model.18/m.0/cv1/act/Sigmoid
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.18/m.0/cv1/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.18/m.0/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.18/m.0/cv1/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.18/m.0/cv1/act/Sigmoid_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.18/m.0/cv1/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.18/m.0/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.18/m.0/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.18/m.0/cv1/act/Mul [Mul] inputs: [/backbone_model/model.18/m.0/cv1/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]], [/backbone_model/model.18/m.0/cv1/act/Sigmoid_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.18/m.0/cv1/act/Mul for ONNX node: /backbone_model/model.18/m.0/cv1/act/Mul
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.18/m.0/cv1/act/Mul_output_0 for ONNX tensor: /backbone_model/model.18/m.0/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.18/m.0/cv1/act/Mul [Mul] outputs: [/backbone_model/model.18/m.0/cv1/act/Mul_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.18/m.0/cv2/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.18/m.0/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1602
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1603
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.18/m.0/cv2/conv/Conv [Conv] inputs: [/backbone_model/model.18/m.0/cv1/act/Mul_output_0 -> (-1, 128, 40, 72)[FLOAT]], [onnx::Conv_1602 -> (128, 128, 3, 3)[HALF]], [onnx::Conv_1603 -> (128)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 128, 40, 72)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.18/m.0/cv2/conv/Conv for ONNX node: /backbone_model/model.18/m.0/cv2/conv/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 128
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 128, 40, 72)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.18/m.0/cv2/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.18/m.0/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.18/m.0/cv2/conv/Conv [Conv] outputs: [/backbone_model/model.18/m.0/cv2/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.18/m.0/cv2/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.18/m.0/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.18/m.0/cv2/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.18/m.0/cv2/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.18/m.0/cv2/act/Sigmoid for ONNX node: /backbone_model/model.18/m.0/cv2/act/Sigmoid
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.18/m.0/cv2/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.18/m.0/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.18/m.0/cv2/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.18/m.0/cv2/act/Sigmoid_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.18/m.0/cv2/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.18/m.0/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.18/m.0/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.18/m.0/cv2/act/Mul [Mul] inputs: [/backbone_model/model.18/m.0/cv2/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]], [/backbone_model/model.18/m.0/cv2/act/Sigmoid_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.18/m.0/cv2/act/Mul for ONNX node: /backbone_model/model.18/m.0/cv2/act/Mul
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.18/m.0/cv2/act/Mul_output_0 for ONNX tensor: /backbone_model/model.18/m.0/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.18/m.0/cv2/act/Mul [Mul] outputs: [/backbone_model/model.18/m.0/cv2/act/Mul_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.18/Concat [Concat]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.18/Slice_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.18/Slice_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.18/m.0/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.18/Concat [Concat] inputs: [/backbone_model/model.18/Slice_output_0 -> (-1, 128, 40, 72)[FLOAT]], [/backbone_model/model.18/Slice_1_output_0 -> (-1, 128, 40, 72)[FLOAT]], [/backbone_model/model.18/m.0/cv2/act/Mul_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.18/Concat for ONNX node: /backbone_model/model.18/Concat
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.18/Concat_output_0 for ONNX tensor: /backbone_model/model.18/Concat_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.18/Concat [Concat] outputs: [/backbone_model/model.18/Concat_output_0 -> (-1, 384, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.18/cv2/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.18/Concat_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1605
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1606
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.18/cv2/conv/Conv [Conv] inputs: [/backbone_model/model.18/Concat_output_0 -> (-1, 384, 40, 72)[FLOAT]], [onnx::Conv_1605 -> (256, 384, 1, 1)[HALF]], [onnx::Conv_1606 -> (256)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 384, 40, 72)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.18/cv2/conv/Conv for ONNX node: /backbone_model/model.18/cv2/conv/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (1, 1), strides: (1, 1), prepadding: (0, 0), postpadding: (0, 0), dilations: (1, 1), numOutputs: 256
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 256, 40, 72)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.18/cv2/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.18/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.18/cv2/conv/Conv [Conv] outputs: [/backbone_model/model.18/cv2/conv/Conv_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.18/cv2/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.18/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.18/cv2/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.18/cv2/conv/Conv_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.18/cv2/act/Sigmoid for ONNX node: /backbone_model/model.18/cv2/act/Sigmoid
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.18/cv2/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.18/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.18/cv2/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.18/cv2/act/Sigmoid_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.18/cv2/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.18/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.18/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.18/cv2/act/Mul [Mul] inputs: [/backbone_model/model.18/cv2/conv/Conv_output_0 -> (-1, 256, 40, 72)[FLOAT]], [/backbone_model/model.18/cv2/act/Sigmoid_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.18/cv2/act/Mul for ONNX node: /backbone_model/model.18/cv2/act/Mul
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.18/cv2/act/Mul_output_0 for ONNX tensor: /backbone_model/model.18/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.18/cv2/act/Mul [Mul] outputs: [/backbone_model/model.18/cv2/act/Mul_output_0 -> (-1, 256, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.19/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.18/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1608
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1609
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.19/conv/Conv [Conv] inputs: [/backbone_model/model.18/cv2/act/Mul_output_0 -> (-1, 256, 40, 72)[FLOAT]], [onnx::Conv_1608 -> (256, 256, 3, 3)[HALF]], [onnx::Conv_1609 -> (256)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 256, 40, 72)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.19/conv/Conv for ONNX node: /backbone_model/model.19/conv/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (3, 3), strides: (2, 2), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 256
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 256, 20, 36)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.19/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.19/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.19/conv/Conv [Conv] outputs: [/backbone_model/model.19/conv/Conv_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.19/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.19/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.19/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.19/conv/Conv_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.19/act/Sigmoid for ONNX node: /backbone_model/model.19/act/Sigmoid
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.19/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.19/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.19/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.19/act/Sigmoid_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.19/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.19/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.19/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.19/act/Mul [Mul] inputs: [/backbone_model/model.19/conv/Conv_output_0 -> (-1, 256, 20, 36)[FLOAT]], [/backbone_model/model.19/act/Sigmoid_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.19/act/Mul for ONNX node: /backbone_model/model.19/act/Mul
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.19/act/Mul_output_0 for ONNX tensor: /backbone_model/model.19/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.19/act/Mul [Mul] outputs: [/backbone_model/model.19/act/Mul_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.20/Concat [Concat]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.19/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.9/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.20/Concat [Concat] inputs: [/backbone_model/model.19/act/Mul_output_0 -> (-1, 256, 20, 36)[FLOAT]], [/backbone_model/model.9/cv2/act/Mul_output_0 -> (-1, 512, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.20/Concat for ONNX node: /backbone_model/model.20/Concat
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.20/Concat_output_0 for ONNX tensor: /backbone_model/model.20/Concat_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.20/Concat [Concat] outputs: [/backbone_model/model.20/Concat_output_0 -> (-1, 768, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.21/cv1/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.20/Concat_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1611
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1612
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.21/cv1/conv/Conv [Conv] inputs: [/backbone_model/model.20/Concat_output_0 -> (-1, 768, 20, 36)[FLOAT]], [onnx::Conv_1611 -> (512, 768, 1, 1)[HALF]], [onnx::Conv_1612 -> (512)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 768, 20, 36)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.21/cv1/conv/Conv for ONNX node: /backbone_model/model.21/cv1/conv/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (1, 1), strides: (1, 1), prepadding: (0, 0), postpadding: (0, 0), dilations: (1, 1), numOutputs: 512
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 512, 20, 36)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.21/cv1/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.21/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.21/cv1/conv/Conv [Conv] outputs: [/backbone_model/model.21/cv1/conv/Conv_output_0 -> (-1, 512, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.21/cv1/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.21/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.21/cv1/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.21/cv1/conv/Conv_output_0 -> (-1, 512, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.21/cv1/act/Sigmoid for ONNX node: /backbone_model/model.21/cv1/act/Sigmoid
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.21/cv1/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.21/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.21/cv1/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.21/cv1/act/Sigmoid_output_0 -> (-1, 512, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.21/cv1/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.21/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.21/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.21/cv1/act/Mul [Mul] inputs: [/backbone_model/model.21/cv1/conv/Conv_output_0 -> (-1, 512, 20, 36)[FLOAT]], [/backbone_model/model.21/cv1/act/Sigmoid_output_0 -> (-1, 512, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.21/cv1/act/Mul for ONNX node: /backbone_model/model.21/cv1/act/Mul
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.21/cv1/act/Mul_output_0 for ONNX tensor: /backbone_model/model.21/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.21/cv1/act/Mul [Mul] outputs: [/backbone_model/model.21/cv1/act/Mul_output_0 -> (-1, 512, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.21/Slice [Slice]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.21/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.6/Mul_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.21/Slice [Slice] inputs: [/backbone_model/model.21/cv1/act/Mul_output_0 -> (-1, 512, 20, 36)[FLOAT]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]], [/backbone_model/model.6/Mul_1_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.21/Slice for ONNX node: /backbone_model/model.21/Slice
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.21/Slice_output_0 for ONNX tensor: /backbone_model/model.21/Slice_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.21/Slice [Slice] outputs: [/backbone_model/model.21/Slice_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.21/Slice_1 [Slice]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.21/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.6/Mul_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.8/Mul_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.21/Slice_1 [Slice] inputs: [/backbone_model/model.21/cv1/act/Mul_output_0 -> (-1, 512, 20, 36)[FLOAT]], [/backbone_model/model.6/Mul_1_output_0 -> (1)[INT32]], [/backbone_model/model.8/Mul_1_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.21/Slice_1 for ONNX node: /backbone_model/model.21/Slice_1
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.21/Slice_1_output_0 for ONNX tensor: /backbone_model/model.21/Slice_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.21/Slice_1 [Slice] outputs: [/backbone_model/model.21/Slice_1_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.21/m.0/cv1/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.21/Slice_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1614
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1615
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.21/m.0/cv1/conv/Conv [Conv] inputs: [/backbone_model/model.21/Slice_1_output_0 -> (-1, 256, 20, 36)[FLOAT]], [onnx::Conv_1614 -> (256, 256, 3, 3)[HALF]], [onnx::Conv_1615 -> (256)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 256, 20, 36)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.21/m.0/cv1/conv/Conv for ONNX node: /backbone_model/model.21/m.0/cv1/conv/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 256
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 256, 20, 36)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.21/m.0/cv1/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.21/m.0/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.21/m.0/cv1/conv/Conv [Conv] outputs: [/backbone_model/model.21/m.0/cv1/conv/Conv_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.21/m.0/cv1/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.21/m.0/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.21/m.0/cv1/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.21/m.0/cv1/conv/Conv_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.21/m.0/cv1/act/Sigmoid for ONNX node: /backbone_model/model.21/m.0/cv1/act/Sigmoid
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.21/m.0/cv1/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.21/m.0/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.21/m.0/cv1/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.21/m.0/cv1/act/Sigmoid_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.21/m.0/cv1/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.21/m.0/cv1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.21/m.0/cv1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.21/m.0/cv1/act/Mul [Mul] inputs: [/backbone_model/model.21/m.0/cv1/conv/Conv_output_0 -> (-1, 256, 20, 36)[FLOAT]], [/backbone_model/model.21/m.0/cv1/act/Sigmoid_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.21/m.0/cv1/act/Mul for ONNX node: /backbone_model/model.21/m.0/cv1/act/Mul
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.21/m.0/cv1/act/Mul_output_0 for ONNX tensor: /backbone_model/model.21/m.0/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.21/m.0/cv1/act/Mul [Mul] outputs: [/backbone_model/model.21/m.0/cv1/act/Mul_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.21/m.0/cv2/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.21/m.0/cv1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1617
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1618
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.21/m.0/cv2/conv/Conv [Conv] inputs: [/backbone_model/model.21/m.0/cv1/act/Mul_output_0 -> (-1, 256, 20, 36)[FLOAT]], [onnx::Conv_1617 -> (256, 256, 3, 3)[HALF]], [onnx::Conv_1618 -> (256)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 256, 20, 36)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.21/m.0/cv2/conv/Conv for ONNX node: /backbone_model/model.21/m.0/cv2/conv/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 256
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 256, 20, 36)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.21/m.0/cv2/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.21/m.0/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.21/m.0/cv2/conv/Conv [Conv] outputs: [/backbone_model/model.21/m.0/cv2/conv/Conv_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.21/m.0/cv2/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.21/m.0/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.21/m.0/cv2/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.21/m.0/cv2/conv/Conv_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.21/m.0/cv2/act/Sigmoid for ONNX node: /backbone_model/model.21/m.0/cv2/act/Sigmoid
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.21/m.0/cv2/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.21/m.0/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.21/m.0/cv2/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.21/m.0/cv2/act/Sigmoid_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.21/m.0/cv2/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.21/m.0/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.21/m.0/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.21/m.0/cv2/act/Mul [Mul] inputs: [/backbone_model/model.21/m.0/cv2/conv/Conv_output_0 -> (-1, 256, 20, 36)[FLOAT]], [/backbone_model/model.21/m.0/cv2/act/Sigmoid_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.21/m.0/cv2/act/Mul for ONNX node: /backbone_model/model.21/m.0/cv2/act/Mul
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.21/m.0/cv2/act/Mul_output_0 for ONNX tensor: /backbone_model/model.21/m.0/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.21/m.0/cv2/act/Mul [Mul] outputs: [/backbone_model/model.21/m.0/cv2/act/Mul_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.21/Concat [Concat]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.21/Slice_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.21/Slice_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.21/m.0/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.21/Concat [Concat] inputs: [/backbone_model/model.21/Slice_output_0 -> (-1, 256, 20, 36)[FLOAT]], [/backbone_model/model.21/Slice_1_output_0 -> (-1, 256, 20, 36)[FLOAT]], [/backbone_model/model.21/m.0/cv2/act/Mul_output_0 -> (-1, 256, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.21/Concat for ONNX node: /backbone_model/model.21/Concat
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.21/Concat_output_0 for ONNX tensor: /backbone_model/model.21/Concat_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.21/Concat [Concat] outputs: [/backbone_model/model.21/Concat_output_0 -> (-1, 768, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.21/cv2/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.21/Concat_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1620
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1621
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.21/cv2/conv/Conv [Conv] inputs: [/backbone_model/model.21/Concat_output_0 -> (-1, 768, 20, 36)[FLOAT]], [onnx::Conv_1620 -> (512, 768, 1, 1)[HALF]], [onnx::Conv_1621 -> (512)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 768, 20, 36)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.21/cv2/conv/Conv for ONNX node: /backbone_model/model.21/cv2/conv/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (1, 1), strides: (1, 1), prepadding: (0, 0), postpadding: (0, 0), dilations: (1, 1), numOutputs: 512
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 512, 20, 36)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.21/cv2/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.21/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.21/cv2/conv/Conv [Conv] outputs: [/backbone_model/model.21/cv2/conv/Conv_output_0 -> (-1, 512, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.21/cv2/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.21/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.21/cv2/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.21/cv2/conv/Conv_output_0 -> (-1, 512, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.21/cv2/act/Sigmoid for ONNX node: /backbone_model/model.21/cv2/act/Sigmoid
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.21/cv2/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.21/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.21/cv2/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.21/cv2/act/Sigmoid_output_0 -> (-1, 512, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.21/cv2/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.21/cv2/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.21/cv2/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.21/cv2/act/Mul [Mul] inputs: [/backbone_model/model.21/cv2/conv/Conv_output_0 -> (-1, 512, 20, 36)[FLOAT]], [/backbone_model/model.21/cv2/act/Sigmoid_output_0 -> (-1, 512, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.21/cv2/act/Mul for ONNX node: /backbone_model/model.21/cv2/act/Mul
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.21/cv2/act/Mul_output_0 for ONNX tensor: /backbone_model/model.21/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.21/cv2/act/Mul [Mul] outputs: [/backbone_model/model.21/cv2/act/Mul_output_0 -> (-1, 512, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv2.0/cv2.0.0/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.15/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1623
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1624
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.0/cv2.0.0/conv/Conv [Conv] inputs: [/backbone_model/model.15/cv2/act/Mul_output_0 -> (-1, 128, 80, 144)[FLOAT]], [onnx::Conv_1623 -> (64, 128, 3, 3)[HALF]], [onnx::Conv_1624 -> (64)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 128, 80, 144)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv2.0/cv2.0.0/conv/Conv for ONNX node: /backbone_model/model.22/cv2.0/cv2.0.0/conv/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 64
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 64, 80, 144)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv2.0/cv2.0.0/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.22/cv2.0/cv2.0.0/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.0/cv2.0.0/conv/Conv [Conv] outputs: [/backbone_model/model.22/cv2.0/cv2.0.0/conv/Conv_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv2.0/cv2.0.0/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv2.0/cv2.0.0/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.0/cv2.0.0/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.22/cv2.0/cv2.0.0/conv/Conv_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv2.0/cv2.0.0/act/Sigmoid for ONNX node: /backbone_model/model.22/cv2.0/cv2.0.0/act/Sigmoid
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv2.0/cv2.0.0/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.22/cv2.0/cv2.0.0/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.0/cv2.0.0/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.22/cv2.0/cv2.0.0/act/Sigmoid_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv2.0/cv2.0.0/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv2.0/cv2.0.0/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv2.0/cv2.0.0/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.0/cv2.0.0/act/Mul [Mul] inputs: [/backbone_model/model.22/cv2.0/cv2.0.0/conv/Conv_output_0 -> (-1, 64, 80, 144)[FLOAT]], [/backbone_model/model.22/cv2.0/cv2.0.0/act/Sigmoid_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv2.0/cv2.0.0/act/Mul for ONNX node: /backbone_model/model.22/cv2.0/cv2.0.0/act/Mul
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv2.0/cv2.0.0/act/Mul_output_0 for ONNX tensor: /backbone_model/model.22/cv2.0/cv2.0.0/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.0/cv2.0.0/act/Mul [Mul] outputs: [/backbone_model/model.22/cv2.0/cv2.0.0/act/Mul_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv2.0/cv2.0.1/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv2.0/cv2.0.0/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1626
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1627
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.0/cv2.0.1/conv/Conv [Conv] inputs: [/backbone_model/model.22/cv2.0/cv2.0.0/act/Mul_output_0 -> (-1, 64, 80, 144)[FLOAT]], [onnx::Conv_1626 -> (64, 64, 3, 3)[HALF]], [onnx::Conv_1627 -> (64)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 64, 80, 144)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv2.0/cv2.0.1/conv/Conv for ONNX node: /backbone_model/model.22/cv2.0/cv2.0.1/conv/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 64
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 64, 80, 144)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv2.0/cv2.0.1/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.22/cv2.0/cv2.0.1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.0/cv2.0.1/conv/Conv [Conv] outputs: [/backbone_model/model.22/cv2.0/cv2.0.1/conv/Conv_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv2.0/cv2.0.1/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv2.0/cv2.0.1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.0/cv2.0.1/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.22/cv2.0/cv2.0.1/conv/Conv_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv2.0/cv2.0.1/act/Sigmoid for ONNX node: /backbone_model/model.22/cv2.0/cv2.0.1/act/Sigmoid
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv2.0/cv2.0.1/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.22/cv2.0/cv2.0.1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.0/cv2.0.1/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.22/cv2.0/cv2.0.1/act/Sigmoid_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv2.0/cv2.0.1/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv2.0/cv2.0.1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv2.0/cv2.0.1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.0/cv2.0.1/act/Mul [Mul] inputs: [/backbone_model/model.22/cv2.0/cv2.0.1/conv/Conv_output_0 -> (-1, 64, 80, 144)[FLOAT]], [/backbone_model/model.22/cv2.0/cv2.0.1/act/Sigmoid_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv2.0/cv2.0.1/act/Mul for ONNX node: /backbone_model/model.22/cv2.0/cv2.0.1/act/Mul
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv2.0/cv2.0.1/act/Mul_output_0 for ONNX tensor: /backbone_model/model.22/cv2.0/cv2.0.1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.0/cv2.0.1/act/Mul [Mul] outputs: [/backbone_model/model.22/cv2.0/cv2.0.1/act/Mul_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv2.0/cv2.0.2/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv2.0/cv2.0.1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: backbone_model.model.22.cv2.0.2.weight
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: backbone_model.model.22.cv2.0.2.bias
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.0/cv2.0.2/Conv [Conv] inputs: [/backbone_model/model.22/cv2.0/cv2.0.1/act/Mul_output_0 -> (-1, 64, 80, 144)[FLOAT]], [backbone_model.model.22.cv2.0.2.weight -> (64, 64, 1, 1)[HALF]], [backbone_model.model.22.cv2.0.2.bias -> (64)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 64, 80, 144)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv2.0/cv2.0.2/Conv for ONNX node: /backbone_model/model.22/cv2.0/cv2.0.2/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (1, 1), strides: (1, 1), prepadding: (0, 0), postpadding: (0, 0), dilations: (1, 1), numOutputs: 64
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 64, 80, 144)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv2.0/cv2.0.2/Conv_output_0 for ONNX tensor: /backbone_model/model.22/cv2.0/cv2.0.2/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.0/cv2.0.2/Conv [Conv] outputs: [/backbone_model/model.22/cv2.0/cv2.0.2/Conv_output_0 -> (-1, 64, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv3.0/cv3.0.0/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.15/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1629
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1630
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.0/cv3.0.0/conv/Conv [Conv] inputs: [/backbone_model/model.15/cv2/act/Mul_output_0 -> (-1, 128, 80, 144)[FLOAT]], [onnx::Conv_1629 -> (128, 128, 3, 3)[HALF]], [onnx::Conv_1630 -> (128)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 128, 80, 144)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv3.0/cv3.0.0/conv/Conv for ONNX node: /backbone_model/model.22/cv3.0/cv3.0.0/conv/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 128
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 128, 80, 144)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv3.0/cv3.0.0/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.22/cv3.0/cv3.0.0/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.0/cv3.0.0/conv/Conv [Conv] outputs: [/backbone_model/model.22/cv3.0/cv3.0.0/conv/Conv_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv3.0/cv3.0.0/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv3.0/cv3.0.0/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.0/cv3.0.0/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.22/cv3.0/cv3.0.0/conv/Conv_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv3.0/cv3.0.0/act/Sigmoid for ONNX node: /backbone_model/model.22/cv3.0/cv3.0.0/act/Sigmoid
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv3.0/cv3.0.0/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.22/cv3.0/cv3.0.0/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.0/cv3.0.0/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.22/cv3.0/cv3.0.0/act/Sigmoid_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv3.0/cv3.0.0/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv3.0/cv3.0.0/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv3.0/cv3.0.0/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.0/cv3.0.0/act/Mul [Mul] inputs: [/backbone_model/model.22/cv3.0/cv3.0.0/conv/Conv_output_0 -> (-1, 128, 80, 144)[FLOAT]], [/backbone_model/model.22/cv3.0/cv3.0.0/act/Sigmoid_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv3.0/cv3.0.0/act/Mul for ONNX node: /backbone_model/model.22/cv3.0/cv3.0.0/act/Mul
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv3.0/cv3.0.0/act/Mul_output_0 for ONNX tensor: /backbone_model/model.22/cv3.0/cv3.0.0/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.0/cv3.0.0/act/Mul [Mul] outputs: [/backbone_model/model.22/cv3.0/cv3.0.0/act/Mul_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv3.0/cv3.0.1/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv3.0/cv3.0.0/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1632
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1633
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.0/cv3.0.1/conv/Conv [Conv] inputs: [/backbone_model/model.22/cv3.0/cv3.0.0/act/Mul_output_0 -> (-1, 128, 80, 144)[FLOAT]], [onnx::Conv_1632 -> (128, 128, 3, 3)[HALF]], [onnx::Conv_1633 -> (128)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 128, 80, 144)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv3.0/cv3.0.1/conv/Conv for ONNX node: /backbone_model/model.22/cv3.0/cv3.0.1/conv/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 128
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 128, 80, 144)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv3.0/cv3.0.1/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.22/cv3.0/cv3.0.1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.0/cv3.0.1/conv/Conv [Conv] outputs: [/backbone_model/model.22/cv3.0/cv3.0.1/conv/Conv_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv3.0/cv3.0.1/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv3.0/cv3.0.1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.0/cv3.0.1/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.22/cv3.0/cv3.0.1/conv/Conv_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv3.0/cv3.0.1/act/Sigmoid for ONNX node: /backbone_model/model.22/cv3.0/cv3.0.1/act/Sigmoid
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv3.0/cv3.0.1/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.22/cv3.0/cv3.0.1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.0/cv3.0.1/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.22/cv3.0/cv3.0.1/act/Sigmoid_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv3.0/cv3.0.1/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv3.0/cv3.0.1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv3.0/cv3.0.1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.0/cv3.0.1/act/Mul [Mul] inputs: [/backbone_model/model.22/cv3.0/cv3.0.1/conv/Conv_output_0 -> (-1, 128, 80, 144)[FLOAT]], [/backbone_model/model.22/cv3.0/cv3.0.1/act/Sigmoid_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv3.0/cv3.0.1/act/Mul for ONNX node: /backbone_model/model.22/cv3.0/cv3.0.1/act/Mul
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv3.0/cv3.0.1/act/Mul_output_0 for ONNX tensor: /backbone_model/model.22/cv3.0/cv3.0.1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.0/cv3.0.1/act/Mul [Mul] outputs: [/backbone_model/model.22/cv3.0/cv3.0.1/act/Mul_output_0 -> (-1, 128, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv3.0/cv3.0.2/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv3.0/cv3.0.1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: backbone_model.model.22.cv3.0.2.weight
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: backbone_model.model.22.cv3.0.2.bias
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.0/cv3.0.2/Conv [Conv] inputs: [/backbone_model/model.22/cv3.0/cv3.0.1/act/Mul_output_0 -> (-1, 128, 80, 144)[FLOAT]], [backbone_model.model.22.cv3.0.2.weight -> (80, 128, 1, 1)[HALF]], [backbone_model.model.22.cv3.0.2.bias -> (80)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 128, 80, 144)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv3.0/cv3.0.2/Conv for ONNX node: /backbone_model/model.22/cv3.0/cv3.0.2/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (1, 1), strides: (1, 1), prepadding: (0, 0), postpadding: (0, 0), dilations: (1, 1), numOutputs: 80
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 80, 80, 144)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv3.0/cv3.0.2/Conv_output_0 for ONNX tensor: /backbone_model/model.22/cv3.0/cv3.0.2/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.0/cv3.0.2/Conv [Conv] outputs: [/backbone_model/model.22/cv3.0/cv3.0.2/Conv_output_0 -> (-1, 80, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/Concat [Concat]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv2.0/cv2.0.2/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv3.0/cv3.0.2/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/Concat [Concat] inputs: [/backbone_model/model.22/cv2.0/cv2.0.2/Conv_output_0 -> (-1, 64, 80, 144)[FLOAT]], [/backbone_model/model.22/cv3.0/cv3.0.2/Conv_output_0 -> (-1, 80, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/Concat for ONNX node: /backbone_model/model.22/Concat
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/Concat_output_0 for ONNX tensor: /backbone_model/model.22/Concat_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/Concat [Concat] outputs: [/backbone_model/model.22/Concat_output_0 -> (-1, 144, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv2.1/cv2.1.0/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.18/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1635
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1636
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.1/cv2.1.0/conv/Conv [Conv] inputs: [/backbone_model/model.18/cv2/act/Mul_output_0 -> (-1, 256, 40, 72)[FLOAT]], [onnx::Conv_1635 -> (64, 256, 3, 3)[HALF]], [onnx::Conv_1636 -> (64)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 256, 40, 72)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv2.1/cv2.1.0/conv/Conv for ONNX node: /backbone_model/model.22/cv2.1/cv2.1.0/conv/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 64
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 64, 40, 72)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv2.1/cv2.1.0/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.22/cv2.1/cv2.1.0/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.1/cv2.1.0/conv/Conv [Conv] outputs: [/backbone_model/model.22/cv2.1/cv2.1.0/conv/Conv_output_0 -> (-1, 64, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv2.1/cv2.1.0/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv2.1/cv2.1.0/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.1/cv2.1.0/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.22/cv2.1/cv2.1.0/conv/Conv_output_0 -> (-1, 64, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv2.1/cv2.1.0/act/Sigmoid for ONNX node: /backbone_model/model.22/cv2.1/cv2.1.0/act/Sigmoid
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv2.1/cv2.1.0/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.22/cv2.1/cv2.1.0/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.1/cv2.1.0/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.22/cv2.1/cv2.1.0/act/Sigmoid_output_0 -> (-1, 64, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv2.1/cv2.1.0/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv2.1/cv2.1.0/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv2.1/cv2.1.0/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.1/cv2.1.0/act/Mul [Mul] inputs: [/backbone_model/model.22/cv2.1/cv2.1.0/conv/Conv_output_0 -> (-1, 64, 40, 72)[FLOAT]], [/backbone_model/model.22/cv2.1/cv2.1.0/act/Sigmoid_output_0 -> (-1, 64, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv2.1/cv2.1.0/act/Mul for ONNX node: /backbone_model/model.22/cv2.1/cv2.1.0/act/Mul
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv2.1/cv2.1.0/act/Mul_output_0 for ONNX tensor: /backbone_model/model.22/cv2.1/cv2.1.0/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.1/cv2.1.0/act/Mul [Mul] outputs: [/backbone_model/model.22/cv2.1/cv2.1.0/act/Mul_output_0 -> (-1, 64, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv2.1/cv2.1.1/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv2.1/cv2.1.0/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1638
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1639
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.1/cv2.1.1/conv/Conv [Conv] inputs: [/backbone_model/model.22/cv2.1/cv2.1.0/act/Mul_output_0 -> (-1, 64, 40, 72)[FLOAT]], [onnx::Conv_1638 -> (64, 64, 3, 3)[HALF]], [onnx::Conv_1639 -> (64)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 64, 40, 72)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv2.1/cv2.1.1/conv/Conv for ONNX node: /backbone_model/model.22/cv2.1/cv2.1.1/conv/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 64
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 64, 40, 72)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv2.1/cv2.1.1/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.22/cv2.1/cv2.1.1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.1/cv2.1.1/conv/Conv [Conv] outputs: [/backbone_model/model.22/cv2.1/cv2.1.1/conv/Conv_output_0 -> (-1, 64, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv2.1/cv2.1.1/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv2.1/cv2.1.1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.1/cv2.1.1/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.22/cv2.1/cv2.1.1/conv/Conv_output_0 -> (-1, 64, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv2.1/cv2.1.1/act/Sigmoid for ONNX node: /backbone_model/model.22/cv2.1/cv2.1.1/act/Sigmoid
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv2.1/cv2.1.1/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.22/cv2.1/cv2.1.1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.1/cv2.1.1/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.22/cv2.1/cv2.1.1/act/Sigmoid_output_0 -> (-1, 64, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv2.1/cv2.1.1/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv2.1/cv2.1.1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv2.1/cv2.1.1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.1/cv2.1.1/act/Mul [Mul] inputs: [/backbone_model/model.22/cv2.1/cv2.1.1/conv/Conv_output_0 -> (-1, 64, 40, 72)[FLOAT]], [/backbone_model/model.22/cv2.1/cv2.1.1/act/Sigmoid_output_0 -> (-1, 64, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv2.1/cv2.1.1/act/Mul for ONNX node: /backbone_model/model.22/cv2.1/cv2.1.1/act/Mul
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv2.1/cv2.1.1/act/Mul_output_0 for ONNX tensor: /backbone_model/model.22/cv2.1/cv2.1.1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.1/cv2.1.1/act/Mul [Mul] outputs: [/backbone_model/model.22/cv2.1/cv2.1.1/act/Mul_output_0 -> (-1, 64, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv2.1/cv2.1.2/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv2.1/cv2.1.1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: backbone_model.model.22.cv2.1.2.weight
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: backbone_model.model.22.cv2.1.2.bias
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.1/cv2.1.2/Conv [Conv] inputs: [/backbone_model/model.22/cv2.1/cv2.1.1/act/Mul_output_0 -> (-1, 64, 40, 72)[FLOAT]], [backbone_model.model.22.cv2.1.2.weight -> (64, 64, 1, 1)[HALF]], [backbone_model.model.22.cv2.1.2.bias -> (64)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 64, 40, 72)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv2.1/cv2.1.2/Conv for ONNX node: /backbone_model/model.22/cv2.1/cv2.1.2/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (1, 1), strides: (1, 1), prepadding: (0, 0), postpadding: (0, 0), dilations: (1, 1), numOutputs: 64
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 64, 40, 72)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv2.1/cv2.1.2/Conv_output_0 for ONNX tensor: /backbone_model/model.22/cv2.1/cv2.1.2/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.1/cv2.1.2/Conv [Conv] outputs: [/backbone_model/model.22/cv2.1/cv2.1.2/Conv_output_0 -> (-1, 64, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv3.1/cv3.1.0/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.18/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1641
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1642
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.1/cv3.1.0/conv/Conv [Conv] inputs: [/backbone_model/model.18/cv2/act/Mul_output_0 -> (-1, 256, 40, 72)[FLOAT]], [onnx::Conv_1641 -> (128, 256, 3, 3)[HALF]], [onnx::Conv_1642 -> (128)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 256, 40, 72)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv3.1/cv3.1.0/conv/Conv for ONNX node: /backbone_model/model.22/cv3.1/cv3.1.0/conv/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 128
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 128, 40, 72)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv3.1/cv3.1.0/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.22/cv3.1/cv3.1.0/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.1/cv3.1.0/conv/Conv [Conv] outputs: [/backbone_model/model.22/cv3.1/cv3.1.0/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv3.1/cv3.1.0/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv3.1/cv3.1.0/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.1/cv3.1.0/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.22/cv3.1/cv3.1.0/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv3.1/cv3.1.0/act/Sigmoid for ONNX node: /backbone_model/model.22/cv3.1/cv3.1.0/act/Sigmoid
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv3.1/cv3.1.0/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.22/cv3.1/cv3.1.0/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.1/cv3.1.0/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.22/cv3.1/cv3.1.0/act/Sigmoid_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv3.1/cv3.1.0/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv3.1/cv3.1.0/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv3.1/cv3.1.0/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.1/cv3.1.0/act/Mul [Mul] inputs: [/backbone_model/model.22/cv3.1/cv3.1.0/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]], [/backbone_model/model.22/cv3.1/cv3.1.0/act/Sigmoid_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv3.1/cv3.1.0/act/Mul for ONNX node: /backbone_model/model.22/cv3.1/cv3.1.0/act/Mul
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv3.1/cv3.1.0/act/Mul_output_0 for ONNX tensor: /backbone_model/model.22/cv3.1/cv3.1.0/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.1/cv3.1.0/act/Mul [Mul] outputs: [/backbone_model/model.22/cv3.1/cv3.1.0/act/Mul_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv3.1/cv3.1.1/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv3.1/cv3.1.0/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1644
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1645
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.1/cv3.1.1/conv/Conv [Conv] inputs: [/backbone_model/model.22/cv3.1/cv3.1.0/act/Mul_output_0 -> (-1, 128, 40, 72)[FLOAT]], [onnx::Conv_1644 -> (128, 128, 3, 3)[HALF]], [onnx::Conv_1645 -> (128)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 128, 40, 72)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv3.1/cv3.1.1/conv/Conv for ONNX node: /backbone_model/model.22/cv3.1/cv3.1.1/conv/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 128
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 128, 40, 72)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv3.1/cv3.1.1/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.22/cv3.1/cv3.1.1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.1/cv3.1.1/conv/Conv [Conv] outputs: [/backbone_model/model.22/cv3.1/cv3.1.1/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv3.1/cv3.1.1/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv3.1/cv3.1.1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.1/cv3.1.1/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.22/cv3.1/cv3.1.1/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv3.1/cv3.1.1/act/Sigmoid for ONNX node: /backbone_model/model.22/cv3.1/cv3.1.1/act/Sigmoid
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv3.1/cv3.1.1/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.22/cv3.1/cv3.1.1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.1/cv3.1.1/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.22/cv3.1/cv3.1.1/act/Sigmoid_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv3.1/cv3.1.1/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv3.1/cv3.1.1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv3.1/cv3.1.1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.1/cv3.1.1/act/Mul [Mul] inputs: [/backbone_model/model.22/cv3.1/cv3.1.1/conv/Conv_output_0 -> (-1, 128, 40, 72)[FLOAT]], [/backbone_model/model.22/cv3.1/cv3.1.1/act/Sigmoid_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv3.1/cv3.1.1/act/Mul for ONNX node: /backbone_model/model.22/cv3.1/cv3.1.1/act/Mul
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv3.1/cv3.1.1/act/Mul_output_0 for ONNX tensor: /backbone_model/model.22/cv3.1/cv3.1.1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.1/cv3.1.1/act/Mul [Mul] outputs: [/backbone_model/model.22/cv3.1/cv3.1.1/act/Mul_output_0 -> (-1, 128, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv3.1/cv3.1.2/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv3.1/cv3.1.1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: backbone_model.model.22.cv3.1.2.weight
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: backbone_model.model.22.cv3.1.2.bias
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.1/cv3.1.2/Conv [Conv] inputs: [/backbone_model/model.22/cv3.1/cv3.1.1/act/Mul_output_0 -> (-1, 128, 40, 72)[FLOAT]], [backbone_model.model.22.cv3.1.2.weight -> (80, 128, 1, 1)[HALF]], [backbone_model.model.22.cv3.1.2.bias -> (80)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 128, 40, 72)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv3.1/cv3.1.2/Conv for ONNX node: /backbone_model/model.22/cv3.1/cv3.1.2/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (1, 1), strides: (1, 1), prepadding: (0, 0), postpadding: (0, 0), dilations: (1, 1), numOutputs: 80
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 80, 40, 72)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv3.1/cv3.1.2/Conv_output_0 for ONNX tensor: /backbone_model/model.22/cv3.1/cv3.1.2/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.1/cv3.1.2/Conv [Conv] outputs: [/backbone_model/model.22/cv3.1/cv3.1.2/Conv_output_0 -> (-1, 80, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/Concat_1 [Concat]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv2.1/cv2.1.2/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv3.1/cv3.1.2/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/Concat_1 [Concat] inputs: [/backbone_model/model.22/cv2.1/cv2.1.2/Conv_output_0 -> (-1, 64, 40, 72)[FLOAT]], [/backbone_model/model.22/cv3.1/cv3.1.2/Conv_output_0 -> (-1, 80, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/Concat_1 for ONNX node: /backbone_model/model.22/Concat_1
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/Concat_1_output_0 for ONNX tensor: /backbone_model/model.22/Concat_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/Concat_1 [Concat] outputs: [/backbone_model/model.22/Concat_1_output_0 -> (-1, 144, 40, 72)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv2.2/cv2.2.0/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.21/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1647
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1648
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.2/cv2.2.0/conv/Conv [Conv] inputs: [/backbone_model/model.21/cv2/act/Mul_output_0 -> (-1, 512, 20, 36)[FLOAT]], [onnx::Conv_1647 -> (64, 512, 3, 3)[HALF]], [onnx::Conv_1648 -> (64)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 512, 20, 36)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv2.2/cv2.2.0/conv/Conv for ONNX node: /backbone_model/model.22/cv2.2/cv2.2.0/conv/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 64
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 64, 20, 36)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv2.2/cv2.2.0/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.22/cv2.2/cv2.2.0/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.2/cv2.2.0/conv/Conv [Conv] outputs: [/backbone_model/model.22/cv2.2/cv2.2.0/conv/Conv_output_0 -> (-1, 64, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv2.2/cv2.2.0/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv2.2/cv2.2.0/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.2/cv2.2.0/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.22/cv2.2/cv2.2.0/conv/Conv_output_0 -> (-1, 64, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv2.2/cv2.2.0/act/Sigmoid for ONNX node: /backbone_model/model.22/cv2.2/cv2.2.0/act/Sigmoid
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv2.2/cv2.2.0/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.22/cv2.2/cv2.2.0/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.2/cv2.2.0/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.22/cv2.2/cv2.2.0/act/Sigmoid_output_0 -> (-1, 64, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv2.2/cv2.2.0/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv2.2/cv2.2.0/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv2.2/cv2.2.0/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.2/cv2.2.0/act/Mul [Mul] inputs: [/backbone_model/model.22/cv2.2/cv2.2.0/conv/Conv_output_0 -> (-1, 64, 20, 36)[FLOAT]], [/backbone_model/model.22/cv2.2/cv2.2.0/act/Sigmoid_output_0 -> (-1, 64, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv2.2/cv2.2.0/act/Mul for ONNX node: /backbone_model/model.22/cv2.2/cv2.2.0/act/Mul
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv2.2/cv2.2.0/act/Mul_output_0 for ONNX tensor: /backbone_model/model.22/cv2.2/cv2.2.0/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.2/cv2.2.0/act/Mul [Mul] outputs: [/backbone_model/model.22/cv2.2/cv2.2.0/act/Mul_output_0 -> (-1, 64, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv2.2/cv2.2.1/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv2.2/cv2.2.0/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1650
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1651
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.2/cv2.2.1/conv/Conv [Conv] inputs: [/backbone_model/model.22/cv2.2/cv2.2.0/act/Mul_output_0 -> (-1, 64, 20, 36)[FLOAT]], [onnx::Conv_1650 -> (64, 64, 3, 3)[HALF]], [onnx::Conv_1651 -> (64)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 64, 20, 36)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv2.2/cv2.2.1/conv/Conv for ONNX node: /backbone_model/model.22/cv2.2/cv2.2.1/conv/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 64
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 64, 20, 36)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv2.2/cv2.2.1/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.22/cv2.2/cv2.2.1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.2/cv2.2.1/conv/Conv [Conv] outputs: [/backbone_model/model.22/cv2.2/cv2.2.1/conv/Conv_output_0 -> (-1, 64, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv2.2/cv2.2.1/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv2.2/cv2.2.1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.2/cv2.2.1/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.22/cv2.2/cv2.2.1/conv/Conv_output_0 -> (-1, 64, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv2.2/cv2.2.1/act/Sigmoid for ONNX node: /backbone_model/model.22/cv2.2/cv2.2.1/act/Sigmoid
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv2.2/cv2.2.1/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.22/cv2.2/cv2.2.1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.2/cv2.2.1/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.22/cv2.2/cv2.2.1/act/Sigmoid_output_0 -> (-1, 64, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv2.2/cv2.2.1/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv2.2/cv2.2.1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv2.2/cv2.2.1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.2/cv2.2.1/act/Mul [Mul] inputs: [/backbone_model/model.22/cv2.2/cv2.2.1/conv/Conv_output_0 -> (-1, 64, 20, 36)[FLOAT]], [/backbone_model/model.22/cv2.2/cv2.2.1/act/Sigmoid_output_0 -> (-1, 64, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv2.2/cv2.2.1/act/Mul for ONNX node: /backbone_model/model.22/cv2.2/cv2.2.1/act/Mul
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv2.2/cv2.2.1/act/Mul_output_0 for ONNX tensor: /backbone_model/model.22/cv2.2/cv2.2.1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.2/cv2.2.1/act/Mul [Mul] outputs: [/backbone_model/model.22/cv2.2/cv2.2.1/act/Mul_output_0 -> (-1, 64, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv2.2/cv2.2.2/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv2.2/cv2.2.1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: backbone_model.model.22.cv2.2.2.weight
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: backbone_model.model.22.cv2.2.2.bias
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.2/cv2.2.2/Conv [Conv] inputs: [/backbone_model/model.22/cv2.2/cv2.2.1/act/Mul_output_0 -> (-1, 64, 20, 36)[FLOAT]], [backbone_model.model.22.cv2.2.2.weight -> (64, 64, 1, 1)[HALF]], [backbone_model.model.22.cv2.2.2.bias -> (64)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 64, 20, 36)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv2.2/cv2.2.2/Conv for ONNX node: /backbone_model/model.22/cv2.2/cv2.2.2/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (1, 1), strides: (1, 1), prepadding: (0, 0), postpadding: (0, 0), dilations: (1, 1), numOutputs: 64
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 64, 20, 36)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv2.2/cv2.2.2/Conv_output_0 for ONNX tensor: /backbone_model/model.22/cv2.2/cv2.2.2/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv2.2/cv2.2.2/Conv [Conv] outputs: [/backbone_model/model.22/cv2.2/cv2.2.2/Conv_output_0 -> (-1, 64, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv3.2/cv3.2.0/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.21/cv2/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1653
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1654
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.2/cv3.2.0/conv/Conv [Conv] inputs: [/backbone_model/model.21/cv2/act/Mul_output_0 -> (-1, 512, 20, 36)[FLOAT]], [onnx::Conv_1653 -> (128, 512, 3, 3)[HALF]], [onnx::Conv_1654 -> (128)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 512, 20, 36)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv3.2/cv3.2.0/conv/Conv for ONNX node: /backbone_model/model.22/cv3.2/cv3.2.0/conv/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 128
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 128, 20, 36)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv3.2/cv3.2.0/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.22/cv3.2/cv3.2.0/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.2/cv3.2.0/conv/Conv [Conv] outputs: [/backbone_model/model.22/cv3.2/cv3.2.0/conv/Conv_output_0 -> (-1, 128, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv3.2/cv3.2.0/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv3.2/cv3.2.0/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.2/cv3.2.0/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.22/cv3.2/cv3.2.0/conv/Conv_output_0 -> (-1, 128, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv3.2/cv3.2.0/act/Sigmoid for ONNX node: /backbone_model/model.22/cv3.2/cv3.2.0/act/Sigmoid
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv3.2/cv3.2.0/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.22/cv3.2/cv3.2.0/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.2/cv3.2.0/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.22/cv3.2/cv3.2.0/act/Sigmoid_output_0 -> (-1, 128, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv3.2/cv3.2.0/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv3.2/cv3.2.0/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv3.2/cv3.2.0/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.2/cv3.2.0/act/Mul [Mul] inputs: [/backbone_model/model.22/cv3.2/cv3.2.0/conv/Conv_output_0 -> (-1, 128, 20, 36)[FLOAT]], [/backbone_model/model.22/cv3.2/cv3.2.0/act/Sigmoid_output_0 -> (-1, 128, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv3.2/cv3.2.0/act/Mul for ONNX node: /backbone_model/model.22/cv3.2/cv3.2.0/act/Mul
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv3.2/cv3.2.0/act/Mul_output_0 for ONNX tensor: /backbone_model/model.22/cv3.2/cv3.2.0/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.2/cv3.2.0/act/Mul [Mul] outputs: [/backbone_model/model.22/cv3.2/cv3.2.0/act/Mul_output_0 -> (-1, 128, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv3.2/cv3.2.1/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv3.2/cv3.2.0/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1656
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Conv_1657
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.2/cv3.2.1/conv/Conv [Conv] inputs: [/backbone_model/model.22/cv3.2/cv3.2.0/act/Mul_output_0 -> (-1, 128, 20, 36)[FLOAT]], [onnx::Conv_1656 -> (128, 128, 3, 3)[HALF]], [onnx::Conv_1657 -> (128)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 128, 20, 36)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv3.2/cv3.2.1/conv/Conv for ONNX node: /backbone_model/model.22/cv3.2/cv3.2.1/conv/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (3, 3), strides: (1, 1), prepadding: (1, 1), postpadding: (1, 1), dilations: (1, 1), numOutputs: 128
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 128, 20, 36)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv3.2/cv3.2.1/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.22/cv3.2/cv3.2.1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.2/cv3.2.1/conv/Conv [Conv] outputs: [/backbone_model/model.22/cv3.2/cv3.2.1/conv/Conv_output_0 -> (-1, 128, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv3.2/cv3.2.1/act/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv3.2/cv3.2.1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.2/cv3.2.1/act/Sigmoid [Sigmoid] inputs: [/backbone_model/model.22/cv3.2/cv3.2.1/conv/Conv_output_0 -> (-1, 128, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv3.2/cv3.2.1/act/Sigmoid for ONNX node: /backbone_model/model.22/cv3.2/cv3.2.1/act/Sigmoid
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv3.2/cv3.2.1/act/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.22/cv3.2/cv3.2.1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.2/cv3.2.1/act/Sigmoid [Sigmoid] outputs: [/backbone_model/model.22/cv3.2/cv3.2.1/act/Sigmoid_output_0 -> (-1, 128, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv3.2/cv3.2.1/act/Mul [Mul]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv3.2/cv3.2.1/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv3.2/cv3.2.1/act/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.2/cv3.2.1/act/Mul [Mul] inputs: [/backbone_model/model.22/cv3.2/cv3.2.1/conv/Conv_output_0 -> (-1, 128, 20, 36)[FLOAT]], [/backbone_model/model.22/cv3.2/cv3.2.1/act/Sigmoid_output_0 -> (-1, 128, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv3.2/cv3.2.1/act/Mul for ONNX node: /backbone_model/model.22/cv3.2/cv3.2.1/act/Mul
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv3.2/cv3.2.1/act/Mul_output_0 for ONNX tensor: /backbone_model/model.22/cv3.2/cv3.2.1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.2/cv3.2.1/act/Mul [Mul] outputs: [/backbone_model/model.22/cv3.2/cv3.2.1/act/Mul_output_0 -> (-1, 128, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/cv3.2/cv3.2.2/Conv [Conv]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv3.2/cv3.2.1/act/Mul_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: backbone_model.model.22.cv3.2.2.weight
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: backbone_model.model.22.cv3.2.2.bias
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.2/cv3.2.2/Conv [Conv] inputs: [/backbone_model/model.22/cv3.2/cv3.2.1/act/Mul_output_0 -> (-1, 128, 20, 36)[FLOAT]], [backbone_model.model.22.cv3.2.2.weight -> (80, 128, 1, 1)[HALF]], [backbone_model.model.22.cv3.2.2.bias -> (80)[HALF]],
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution input dimensions: (-1, 128, 20, 36)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/cv3.2/cv3.2.2/Conv for ONNX node: /backbone_model/model.22/cv3.2/cv3.2.2/Conv
[TH_YF8S][26-01-14 11:43:43][TRT] Using kernel: (1, 1), strides: (1, 1), prepadding: (0, 0), postpadding: (0, 0), dilations: (1, 1), numOutputs: 80
[TH_YF8S][26-01-14 11:43:43][TRT] Convolution output dimensions: (-1, 80, 20, 36)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/cv3.2/cv3.2.2/Conv_output_0 for ONNX tensor: /backbone_model/model.22/cv3.2/cv3.2.2/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/cv3.2/cv3.2.2/Conv [Conv] outputs: [/backbone_model/model.22/cv3.2/cv3.2.2/Conv_output_0 -> (-1, 80, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/Concat_2 [Concat]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv2.2/cv2.2.2/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/cv3.2/cv3.2.2/Conv_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/Concat_2 [Concat] inputs: [/backbone_model/model.22/cv2.2/cv2.2.2/Conv_output_0 -> (-1, 64, 20, 36)[FLOAT]], [/backbone_model/model.22/cv3.2/cv3.2.2/Conv_output_0 -> (-1, 80, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/Concat_2 for ONNX node: /backbone_model/model.22/Concat_2
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/Concat_2_output_0 for ONNX tensor: /backbone_model/model.22/Concat_2_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/Concat_2 [Concat] outputs: [/backbone_model/model.22/Concat_2_output_0 -> (-1, 144, 20, 36)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/Shape [Shape]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/Concat_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/Shape [Shape] inputs: [/backbone_model/model.22/Concat_output_0 -> (-1, 144, 80, 144)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/Shape for ONNX node: /backbone_model/model.22/Shape
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/Shape_output_0 for ONNX tensor: /backbone_model/model.22/Shape_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/Shape [Shape] outputs: [/backbone_model/model.22/Shape_output_0 -> (4)[INT32]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/Gather [Gather]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/Shape_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/Constant_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/Gather [Gather] inputs: [/backbone_model/model.22/Shape_output_0 -> (4)[INT32]], [/backbone_model/model.22/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/Constant_output_0 for ONNX node: /backbone_model/model.22/Constant_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Using Gather axis: 0
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/Gather for ONNX node: /backbone_model/model.22/Gather
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/Gather_output_0 for ONNX tensor: /backbone_model/model.22/Gather_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/Gather [Gather] outputs: [/backbone_model/model.22/Gather_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/Unsqueeze [Unsqueeze]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/Gather_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/Unsqueeze [Unsqueeze] inputs: [/backbone_model/model.22/Gather_output_0 -> ()[INT32]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:43][TRT] Original shape: (), unsqueezing to: (1,)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/Unsqueeze for ONNX node: /backbone_model/model.22/Unsqueeze
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/Unsqueeze_output_0 for ONNX tensor: /backbone_model/model.22/Unsqueeze_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/Unsqueeze [Unsqueeze] outputs: [/backbone_model/model.22/Unsqueeze_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/Concat_3 [Concat]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/Unsqueeze_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/Constant_3_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/Concat_3 [Concat] inputs: [/backbone_model/model.22/Unsqueeze_output_0 -> (1)[INT32]], [/backbone_model/model.22/Constant_2_output_0 -> (1)[INT32]], [/backbone_model/model.22/Constant_3_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/Constant_2_output_0 for ONNX node: /backbone_model/model.22/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/Constant_3_output_0 for ONNX node: /backbone_model/model.22/Constant_3_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/Concat_3 for ONNX node: /backbone_model/model.22/Concat_3
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/Concat_3_output_0 for ONNX tensor: /backbone_model/model.22/Concat_3_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/Concat_3 [Concat] outputs: [/backbone_model/model.22/Concat_3_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/Reshape [Reshape]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/Concat_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/Concat_3_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/Reshape [Reshape] inputs: [/backbone_model/model.22/Concat_output_0 -> (-1, 144, 80, 144)[FLOAT]], [/backbone_model/model.22/Concat_3_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/Reshape for ONNX node: /backbone_model/model.22/Reshape
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/Reshape_output_0 for ONNX tensor: /backbone_model/model.22/Reshape_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/Reshape [Reshape] outputs: [/backbone_model/model.22/Reshape_output_0 -> (-1, 144, 11520)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/Reshape_1 [Reshape]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/Concat_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/Concat_3_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/Reshape_1 [Reshape] inputs: [/backbone_model/model.22/Concat_1_output_0 -> (-1, 144, 40, 72)[FLOAT]], [/backbone_model/model.22/Concat_3_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/Reshape_1 for ONNX node: /backbone_model/model.22/Reshape_1
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/Reshape_1_output_0 for ONNX tensor: /backbone_model/model.22/Reshape_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/Reshape_1 [Reshape] outputs: [/backbone_model/model.22/Reshape_1_output_0 -> (-1, 144, 2880)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/Reshape_2 [Reshape]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/Concat_2_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/Concat_3_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/Reshape_2 [Reshape] inputs: [/backbone_model/model.22/Concat_2_output_0 -> (-1, 144, 20, 36)[FLOAT]], [/backbone_model/model.22/Concat_3_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/Reshape_2 for ONNX node: /backbone_model/model.22/Reshape_2
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/Reshape_2_output_0 for ONNX tensor: /backbone_model/model.22/Reshape_2_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/Reshape_2 [Reshape] outputs: [/backbone_model/model.22/Reshape_2_output_0 -> (-1, 144, 720)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/Concat_6 [Concat]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/Reshape_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/Reshape_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/Reshape_2_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/Concat_6 [Concat] inputs: [/backbone_model/model.22/Reshape_output_0 -> (-1, 144, 11520)[FLOAT]], [/backbone_model/model.22/Reshape_1_output_0 -> (-1, 144, 2880)[FLOAT]], [/backbone_model/model.22/Reshape_2_output_0 -> (-1, 144, 720)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/Concat_6 for ONNX node: /backbone_model/model.22/Concat_6
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/Concat_6_output_0 for ONNX tensor: /backbone_model/model.22/Concat_6_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/Concat_6 [Concat] outputs: [/backbone_model/model.22/Concat_6_output_0 -> (-1, 144, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/Split [Split]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/Concat_6_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: onnx::Split_770
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/Split [Split] inputs: [/backbone_model/model.22/Concat_6_output_0 -> (-1, 144, 15120)[FLOAT]], [onnx::Split_770 -> (2)[INT32]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/Split for ONNX node: /backbone_model/model.22/Split
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/Split_177 for ONNX node: /backbone_model/model.22/Split
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/Split_output_0 for ONNX tensor: /backbone_model/model.22/Split_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/Split_output_1 for ONNX tensor: /backbone_model/model.22/Split_output_1
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/Split [Split] outputs: [/backbone_model/model.22/Split_output_0 -> (-1, 64, 15120)[FLOAT]], [/backbone_model/model.22/Split_output_1 -> (-1, 80, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/dfl/Shape [Shape]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/Split_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/dfl/Shape [Shape] inputs: [/backbone_model/model.22/Split_output_0 -> (-1, 64, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/dfl/Shape for ONNX node: /backbone_model/model.22/dfl/Shape
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/dfl/Shape_output_0 for ONNX tensor: /backbone_model/model.22/dfl/Shape_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/dfl/Shape [Shape] outputs: [/backbone_model/model.22/dfl/Shape_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/dfl/Gather [Gather]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/dfl/Shape_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/Constant_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/dfl/Gather [Gather] inputs: [/backbone_model/model.22/dfl/Shape_output_0 -> (3)[INT32]], [/backbone_model/model.22/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:43][TRT] Using Gather axis: 0
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/dfl/Gather for ONNX node: /backbone_model/model.22/dfl/Gather
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/dfl/Gather_output_0 for ONNX tensor: /backbone_model/model.22/dfl/Gather_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/dfl/Gather [Gather] outputs: [/backbone_model/model.22/dfl/Gather_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/dfl/Gather_1 [Gather]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/dfl/Shape_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.2/Constant_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/dfl/Gather_1 [Gather] inputs: [/backbone_model/model.22/dfl/Shape_output_0 -> (3)[INT32]], [/backbone_model/model.2/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.2/Constant_output_0 for ONNX node: /backbone_model/model.2/Constant_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Using Gather axis: 0
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/dfl/Gather_1 for ONNX node: /backbone_model/model.22/dfl/Gather_1
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/dfl/Gather_1_output_0 for ONNX tensor: /backbone_model/model.22/dfl/Gather_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/dfl/Gather_1 [Gather] outputs: [/backbone_model/model.22/dfl/Gather_1_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/dfl/Unsqueeze [Unsqueeze]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/dfl/Gather_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/dfl/Unsqueeze [Unsqueeze] inputs: [/backbone_model/model.22/dfl/Gather_output_0 -> ()[INT32]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:43][TRT] Original shape: (), unsqueezing to: (1,)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/dfl/Unsqueeze for ONNX node: /backbone_model/model.22/dfl/Unsqueeze
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/dfl/Unsqueeze_output_0 for ONNX tensor: /backbone_model/model.22/dfl/Unsqueeze_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/dfl/Unsqueeze [Unsqueeze] outputs: [/backbone_model/model.22/dfl/Unsqueeze_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/dfl/Unsqueeze_1 [Unsqueeze]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/dfl/Gather_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/dfl/Unsqueeze_1 [Unsqueeze] inputs: [/backbone_model/model.22/dfl/Gather_1_output_0 -> ()[INT32]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:43][TRT] Original shape: (), unsqueezing to: (1,)
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/dfl/Unsqueeze_1 for ONNX node: /backbone_model/model.22/dfl/Unsqueeze_1
[TH_YF8S][26-01-14 11:43:43][TRT] Registering tensor: /backbone_model/model.22/dfl/Unsqueeze_1_output_0 for ONNX tensor: /backbone_model/model.22/dfl/Unsqueeze_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/dfl/Unsqueeze_1 [Unsqueeze] outputs: [/backbone_model/model.22/dfl/Unsqueeze_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:43][TRT] Parsing node: /backbone_model/model.22/dfl/Concat [Concat]
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/dfl/Unsqueeze_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/dfl/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/dfl/Constant_3_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] Searching for input: /backbone_model/model.22/dfl/Unsqueeze_1_output_0
[TH_YF8S][26-01-14 11:43:43][TRT] /backbone_model/model.22/dfl/Concat [Concat] inputs: [/backbone_model/model.22/dfl/Unsqueeze_output_0 -> (1)[INT32]], [/backbone_model/model.22/dfl/Constant_2_output_0 -> (1)[INT32]], [/backbone_model/model.22/dfl/Constant_3_output_0 -> (1)[INT32]], [/backbone_model/model.22/dfl/Unsqueeze_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:43][TRT] Registering layer: /backbone_model/model.22/dfl/Constant_2_output_0 for ONNX node: /backbone_model/model.22/dfl/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /backbone_model/model.22/dfl/Constant_3_output_0 for ONNX node: /backbone_model/model.22/dfl/Constant_3_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /backbone_model/model.22/dfl/Concat for ONNX node: /backbone_model/model.22/dfl/Concat
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /backbone_model/model.22/dfl/Concat_output_0 for ONNX tensor: /backbone_model/model.22/dfl/Concat_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/dfl/Concat [Concat] outputs: [/backbone_model/model.22/dfl/Concat_output_0 -> (4)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /backbone_model/model.22/dfl/Reshape [Reshape]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Split_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/dfl/Concat_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/dfl/Reshape [Reshape] inputs: [/backbone_model/model.22/Split_output_0 -> (-1, 64, 15120)[FLOAT]], [/backbone_model/model.22/dfl/Concat_output_0 -> (4)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /backbone_model/model.22/dfl/Reshape for ONNX node: /backbone_model/model.22/dfl/Reshape
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /backbone_model/model.22/dfl/Reshape_output_0 for ONNX tensor: /backbone_model/model.22/dfl/Reshape_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/dfl/Reshape [Reshape] outputs: [/backbone_model/model.22/dfl/Reshape_output_0 -> (-1, 4, 16, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /backbone_model/model.22/dfl/Transpose [Transpose]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/dfl/Reshape_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/dfl/Transpose [Transpose] inputs: [/backbone_model/model.22/dfl/Reshape_output_0 -> (-1, 4, 16, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /backbone_model/model.22/dfl/Transpose for ONNX node: /backbone_model/model.22/dfl/Transpose
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /backbone_model/model.22/dfl/Transpose_output_0 for ONNX tensor: /backbone_model/model.22/dfl/Transpose_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/dfl/Transpose [Transpose] outputs: [/backbone_model/model.22/dfl/Transpose_output_0 -> (-1, 16, 4, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /backbone_model/model.22/dfl/Softmax [Softmax]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/dfl/Transpose_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/dfl/Softmax [Softmax] inputs: [/backbone_model/model.22/dfl/Transpose_output_0 -> (-1, 16, 4, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /backbone_model/model.22/dfl/Softmax for ONNX node: /backbone_model/model.22/dfl/Softmax
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /backbone_model/model.22/dfl/Softmax_output_0 for ONNX tensor: /backbone_model/model.22/dfl/Softmax_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/dfl/Softmax [Softmax] outputs: [/backbone_model/model.22/dfl/Softmax_output_0 -> (-1, 16, 4, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /backbone_model/model.22/dfl/conv/Conv [Conv]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/dfl/Softmax_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: backbone_model.model.22.dfl.conv.weight
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/dfl/conv/Conv [Conv] inputs: [/backbone_model/model.22/dfl/Softmax_output_0 -> (-1, 16, 4, 15120)[FLOAT]], [backbone_model.model.22.dfl.conv.weight -> (1, 16, 1, 1)[HALF]],
[TH_YF8S][26-01-14 11:43:44][TRT] Convolution input dimensions: (-1, 16, 4, 15120)
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /backbone_model/model.22/dfl/conv/Conv for ONNX node: /backbone_model/model.22/dfl/conv/Conv
[TH_YF8S][26-01-14 11:43:44][TRT] Using kernel: (1, 1), strides: (1, 1), prepadding: (0, 0), postpadding: (0, 0), dilations: (1, 1), numOutputs: 1
[TH_YF8S][26-01-14 11:43:44][TRT] Convolution output dimensions: (-1, 1, 4, 15120)
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /backbone_model/model.22/dfl/conv/Conv_output_0 for ONNX tensor: /backbone_model/model.22/dfl/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/dfl/conv/Conv [Conv] outputs: [/backbone_model/model.22/dfl/conv/Conv_output_0 -> (-1, 1, 4, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /backbone_model/model.22/dfl/Concat_1 [Concat]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/dfl/Unsqueeze_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/dfl/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/dfl/Unsqueeze_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/dfl/Concat_1 [Concat] inputs: [/backbone_model/model.22/dfl/Unsqueeze_output_0 -> (1)[INT32]], [/backbone_model/model.22/dfl/Constant_2_output_0 -> (1)[INT32]], [/backbone_model/model.22/dfl/Unsqueeze_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /backbone_model/model.22/dfl/Concat_1 for ONNX node: /backbone_model/model.22/dfl/Concat_1
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /backbone_model/model.22/dfl/Concat_1_output_0 for ONNX tensor: /backbone_model/model.22/dfl/Concat_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/dfl/Concat_1 [Concat] outputs: [/backbone_model/model.22/dfl/Concat_1_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /backbone_model/model.22/dfl/Reshape_1 [Reshape]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/dfl/conv/Conv_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/dfl/Concat_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/dfl/Reshape_1 [Reshape] inputs: [/backbone_model/model.22/dfl/conv/Conv_output_0 -> (-1, 1, 4, 15120)[FLOAT]], [/backbone_model/model.22/dfl/Concat_1_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /backbone_model/model.22/dfl/Reshape_1 for ONNX node: /backbone_model/model.22/dfl/Reshape_1
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /backbone_model/model.22/dfl/Reshape_1_output_0 for ONNX tensor: /backbone_model/model.22/dfl/Reshape_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/dfl/Reshape_1 [Reshape] outputs: [/backbone_model/model.22/dfl/Reshape_1_output_0 -> (-1, 4, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /backbone_model/model.22/Shape_1 [Shape]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/dfl/Reshape_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Shape_1 [Shape] inputs: [/backbone_model/model.22/dfl/Reshape_1_output_0 -> (-1, 4, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /backbone_model/model.22/Shape_1 for ONNX node: /backbone_model/model.22/Shape_1
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /backbone_model/model.22/Shape_1_output_0 for ONNX tensor: /backbone_model/model.22/Shape_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Shape_1 [Shape] outputs: [/backbone_model/model.22/Shape_1_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /backbone_model/model.22/Gather_1 [Gather]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Shape_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Gather_1 [Gather] inputs: [/backbone_model/model.22/Shape_1_output_0 -> (3)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /backbone_model/model.2/Constant_1_output_0 for ONNX node: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Using Gather axis: 0
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /backbone_model/model.22/Gather_1 for ONNX node: /backbone_model/model.22/Gather_1
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /backbone_model/model.22/Gather_1_output_0 for ONNX tensor: /backbone_model/model.22/Gather_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Gather_1 [Gather] outputs: [/backbone_model/model.22/Gather_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /backbone_model/model.22/Add [Add]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Gather_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Add [Add] inputs: [/backbone_model/model.22/Gather_1_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /backbone_model/model.22/Add for ONNX node: /backbone_model/model.22/Add
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /backbone_model/model.22/Add_output_0 for ONNX tensor: /backbone_model/model.22/Add_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Add [Add] outputs: [/backbone_model/model.22/Add_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /backbone_model/model.22/Div [Div]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Add_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.2/Constant_4_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Div [Div] inputs: [/backbone_model/model.22/Add_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_4_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /backbone_model/model.2/Constant_4_output_0 for ONNX node: /backbone_model/model.2/Constant_4_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /backbone_model/model.22/Div for ONNX node: /backbone_model/model.22/Div
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /backbone_model/model.22/Div_output_0 for ONNX tensor: /backbone_model/model.22/Div_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Div [Div] outputs: [/backbone_model/model.22/Div_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /backbone_model/model.22/Slice [Slice]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/dfl/Reshape_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Div_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Slice [Slice] inputs: [/backbone_model/model.22/dfl/Reshape_1_output_0 -> (-1, 4, 15120)[FLOAT]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]], [/backbone_model/model.22/Div_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /backbone_model/model.22/Slice for ONNX node: /backbone_model/model.22/Slice
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /backbone_model/model.22/Slice_output_0 for ONNX tensor: /backbone_model/model.22/Slice_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Slice [Slice] outputs: [/backbone_model/model.22/Slice_output_0 -> (-1, 2, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /backbone_model/model.22/Mul_1 [Mul]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Div_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.2/Constant_4_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Mul_1 [Mul] inputs: [/backbone_model/model.22/Div_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_4_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /backbone_model/model.22/Mul_1 for ONNX node: /backbone_model/model.22/Mul_1
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /backbone_model/model.22/Mul_1_output_0 for ONNX tensor: /backbone_model/model.22/Mul_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Mul_1 [Mul] outputs: [/backbone_model/model.22/Mul_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /backbone_model/model.22/Slice_1 [Slice]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/dfl/Reshape_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Div_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Mul_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Slice_1 [Slice] inputs: [/backbone_model/model.22/dfl/Reshape_1_output_0 -> (-1, 4, 15120)[FLOAT]], [/backbone_model/model.22/Div_output_0 -> (1)[INT32]], [/backbone_model/model.22/Mul_1_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /backbone_model/model.22/Slice_1 for ONNX node: /backbone_model/model.22/Slice_1
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /backbone_model/model.22/Slice_1_output_0 for ONNX tensor: /backbone_model/model.22/Slice_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Slice_1 [Slice] outputs: [/backbone_model/model.22/Slice_1_output_0 -> (-1, 2, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /backbone_model/model.22/Sub [Sub]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Constant_14_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Slice_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Sub [Sub] inputs: [/backbone_model/model.22/Constant_14_output_0 -> (1, 2, 15120)[HALF]], [/backbone_model/model.22/Slice_output_0 -> (-1, 2, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /backbone_model/model.22/Constant_14_output_0 for ONNX node: /backbone_model/model.22/Constant_14_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /backbone_model/model.22/Sub for ONNX node: /backbone_model/model.22/Sub
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /backbone_model/model.22/Sub_output_0 for ONNX tensor: /backbone_model/model.22/Sub_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Sub [Sub] outputs: [/backbone_model/model.22/Sub_output_0 -> (-1, 2, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /backbone_model/model.22/Add_1 [Add]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Constant_14_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Slice_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Add_1 [Add] inputs: [/backbone_model/model.22/Constant_14_output_0 -> (1, 2, 15120)[HALF]], [/backbone_model/model.22/Slice_1_output_0 -> (-1, 2, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /backbone_model/model.22/Add_1 for ONNX node: /backbone_model/model.22/Add_1
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /backbone_model/model.22/Add_1_output_0 for ONNX tensor: /backbone_model/model.22/Add_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Add_1 [Add] outputs: [/backbone_model/model.22/Add_1_output_0 -> (-1, 2, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /backbone_model/model.22/Add_2 [Add]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Sub_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Add_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Add_2 [Add] inputs: [/backbone_model/model.22/Sub_output_0 -> (-1, 2, 15120)[FLOAT]], [/backbone_model/model.22/Add_1_output_0 -> (-1, 2, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /backbone_model/model.22/Add_2 for ONNX node: /backbone_model/model.22/Add_2
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /backbone_model/model.22/Add_2_output_0 for ONNX tensor: /backbone_model/model.22/Add_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Add_2 [Add] outputs: [/backbone_model/model.22/Add_2_output_0 -> (-1, 2, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /backbone_model/model.22/Div_1 [Div]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Add_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Constant_16_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Div_1 [Div] inputs: [/backbone_model/model.22/Add_2_output_0 -> (-1, 2, 15120)[FLOAT]], [/backbone_model/model.22/Constant_16_output_0 -> ()[HALF]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /backbone_model/model.22/Constant_16_output_0 for ONNX node: /backbone_model/model.22/Constant_16_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /backbone_model/model.22/Div_1 for ONNX node: /backbone_model/model.22/Div_1
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /backbone_model/model.22/Div_1_output_0 for ONNX tensor: /backbone_model/model.22/Div_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Div_1 [Div] outputs: [/backbone_model/model.22/Div_1_output_0 -> (-1, 2, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /backbone_model/model.22/Sub_1 [Sub]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Add_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Sub_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Sub_1 [Sub] inputs: [/backbone_model/model.22/Add_1_output_0 -> (-1, 2, 15120)[FLOAT]], [/backbone_model/model.22/Sub_output_0 -> (-1, 2, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /backbone_model/model.22/Sub_1 for ONNX node: /backbone_model/model.22/Sub_1
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /backbone_model/model.22/Sub_1_output_0 for ONNX tensor: /backbone_model/model.22/Sub_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Sub_1 [Sub] outputs: [/backbone_model/model.22/Sub_1_output_0 -> (-1, 2, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /backbone_model/model.22/Concat_7 [Concat]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Div_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Sub_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Concat_7 [Concat] inputs: [/backbone_model/model.22/Div_1_output_0 -> (-1, 2, 15120)[FLOAT]], [/backbone_model/model.22/Sub_1_output_0 -> (-1, 2, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /backbone_model/model.22/Concat_7 for ONNX node: /backbone_model/model.22/Concat_7
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /backbone_model/model.22/Concat_7_output_0 for ONNX tensor: /backbone_model/model.22/Concat_7_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Concat_7 [Concat] outputs: [/backbone_model/model.22/Concat_7_output_0 -> (-1, 4, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /backbone_model/model.22/Mul_2 [Mul]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Concat_7_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Constant_17_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Mul_2 [Mul] inputs: [/backbone_model/model.22/Concat_7_output_0 -> (-1, 4, 15120)[FLOAT]], [/backbone_model/model.22/Constant_17_output_0 -> (1, 15120)[HALF]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /backbone_model/model.22/Constant_17_output_0 for ONNX node: /backbone_model/model.22/Constant_17_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /backbone_model/model.22/Mul_2 for ONNX node: /backbone_model/model.22/Mul_2
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /backbone_model/model.22/Mul_2_output_0 for ONNX tensor: /backbone_model/model.22/Mul_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Mul_2 [Mul] outputs: [/backbone_model/model.22/Mul_2_output_0 -> (-1, 4, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /backbone_model/model.22/Sigmoid [Sigmoid]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Split_output_1
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Sigmoid [Sigmoid] inputs: [/backbone_model/model.22/Split_output_1 -> (-1, 80, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /backbone_model/model.22/Sigmoid for ONNX node: /backbone_model/model.22/Sigmoid
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /backbone_model/model.22/Sigmoid_output_0 for ONNX tensor: /backbone_model/model.22/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Sigmoid [Sigmoid] outputs: [/backbone_model/model.22/Sigmoid_output_0 -> (-1, 80, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /backbone_model/model.22/Concat_8 [Concat]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Mul_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Sigmoid_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Concat_8 [Concat] inputs: [/backbone_model/model.22/Mul_2_output_0 -> (-1, 4, 15120)[FLOAT]], [/backbone_model/model.22/Sigmoid_output_0 -> (-1, 80, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /backbone_model/model.22/Concat_8 for ONNX node: /backbone_model/model.22/Concat_8
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /backbone_model/model.22/Concat_8_output_0 for ONNX tensor: /backbone_model/model.22/Concat_8_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /backbone_model/model.22/Concat_8 [Concat] outputs: [/backbone_model/model.22/Concat_8_output_0 -> (-1, 84, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Shape [Shape]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Concat_8_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Shape [Shape] inputs: [/backbone_model/model.22/Concat_8_output_0 -> (-1, 84, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Shape for ONNX node: /Shape
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Shape_output_0 for ONNX tensor: /Shape_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Shape [Shape] outputs: [/Shape_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Gather [Gather]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Shape_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Constant_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Gather [Gather] inputs: [/Shape_output_0 -> (3)[INT32]], [/backbone_model/model.22/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Using Gather axis: 0
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Gather for ONNX node: /Gather
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Gather_output_0 for ONNX tensor: /Gather_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Gather [Gather] outputs: [/Gather_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Gather_1 [Gather]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Shape_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.0/conv/Constant_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Gather_1 [Gather] inputs: [/Shape_output_0 -> (3)[INT32]], [/backbone_model/model.0/conv/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /backbone_model/model.0/conv/Constant_output_0 for ONNX node: /backbone_model/model.0/conv/Constant_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Using Gather axis: 0
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Gather_1 for ONNX node: /Gather_1
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Gather_1_output_0 for ONNX tensor: /Gather_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Gather_1 [Gather] outputs: [/Gather_1_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Sub [Sub]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Gather_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Constant_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Sub [Sub] inputs: [/Gather_1_output_0 -> ()[INT32]], [/Constant_2_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Constant_2_output_0 for ONNX node: /Constant_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Sub for ONNX node: /Sub
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Sub_output_0 for ONNX tensor: /Sub_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Sub [Sub] outputs: [/Sub_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Unsqueeze [Unsqueeze]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Gather_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Unsqueeze [Unsqueeze] inputs: [/Gather_output_0 -> ()[INT32]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Original shape: (), unsqueezing to: (1,)
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Unsqueeze for ONNX node: /Unsqueeze
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Unsqueeze_output_0 for ONNX tensor: /Unsqueeze_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Unsqueeze [Unsqueeze] outputs: [/Unsqueeze_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Concat [Concat]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Unsqueeze_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Constant_3_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Constant_4_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Concat [Concat] inputs: [/Unsqueeze_output_0 -> (1)[INT32]], [/Constant_3_output_0 -> (1)[INT32]], [/Constant_4_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Constant_3_output_0 for ONNX node: /Constant_3_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Constant_4_output_0 for ONNX node: /Constant_4_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Concat for ONNX node: /Concat
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Concat_output_0 for ONNX tensor: /Concat_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Concat [Concat] outputs: [/Concat_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /ConstantOfShape [ConstantOfShape]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Concat_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /ConstantOfShape [ConstantOfShape] inputs: [/Concat_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /ConstantOfShape_output_0 for ONNX tensor: /ConstantOfShape_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /ConstantOfShape [ConstantOfShape] outputs: [/ConstantOfShape_output_0 -> (-1, 300, 6)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Transpose [Transpose]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Concat_8_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Transpose [Transpose] inputs: [/backbone_model/model.22/Concat_8_output_0 -> (-1, 84, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Transpose for ONNX node: /Transpose
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Transpose_output_0 for ONNX tensor: /Transpose_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Transpose [Transpose] outputs: [/Transpose_output_0 -> (-1, 15120, 84)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Unsqueeze_2 [Unsqueeze]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Sub_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Unsqueeze_2 [Unsqueeze] inputs: [/Sub_output_0 -> ()[INT32]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Original shape: (), unsqueezing to: (1,)
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Unsqueeze_2 for ONNX node: /Unsqueeze_2
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Unsqueeze_2_output_0 for ONNX tensor: /Unsqueeze_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Unsqueeze_2 [Unsqueeze] outputs: [/Unsqueeze_2_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Slice [Slice]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Transpose_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/dfl/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.2/Constant_4_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Slice [Slice] inputs: [/Transpose_output_0 -> (-1, 15120, 84)[FLOAT]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]], [/backbone_model/model.22/dfl/Constant_2_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_4_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Slice for ONNX node: /Slice
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Slice_output_0 for ONNX tensor: /Slice_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Slice [Slice] outputs: [/Slice_output_0 -> (-1, 15120, 4)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Add [Add]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/dfl/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Unsqueeze_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Add [Add] inputs: [/backbone_model/model.22/dfl/Constant_2_output_0 -> (1)[INT32]], [/Unsqueeze_2_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Add for ONNX node: /Add
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Add_output_0 for ONNX tensor: /Add_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Add [Add] outputs: [/Add_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Slice_1 [Slice]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Transpose_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/dfl/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Add_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.2/Constant_4_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Slice_1 [Slice] inputs: [/Transpose_output_0 -> (-1, 15120, 84)[FLOAT]], [/backbone_model/model.22/dfl/Constant_2_output_0 -> (1)[INT32]], [/Add_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_4_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Slice_1 for ONNX node: /Slice_1
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Slice_1_output_0 for ONNX tensor: /Slice_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Slice_1 [Slice] outputs: [/Slice_1_output_0 -> (-1, 15120, 80)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Gather_2 [Gather]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Slice_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Constant_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Gather_2 [Gather] inputs: [/Slice_output_0 -> (-1, 15120, 4)[FLOAT]], [/backbone_model/model.22/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Using Gather axis: 2
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Gather_2 for ONNX node: /Gather_2
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Gather_2_output_0 for ONNX tensor: /Gather_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Gather_2 [Gather] outputs: [/Gather_2_output_0 -> (-1, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Gather_3 [Gather]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Slice_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.2/Constant_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Gather_3 [Gather] inputs: [/Slice_output_0 -> (-1, 15120, 4)[FLOAT]], [/backbone_model/model.2/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Using Gather axis: 2
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Gather_3 for ONNX node: /Gather_3
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Gather_3_output_0 for ONNX tensor: /Gather_3_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Gather_3 [Gather] outputs: [/Gather_3_output_0 -> (-1, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Div [Div]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Gather_3_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Constant_16_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Div [Div] inputs: [/Gather_3_output_0 -> (-1, 15120)[FLOAT]], [/backbone_model/model.22/Constant_16_output_0 -> ()[HALF]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Div for ONNX node: /Div
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Div_output_0 for ONNX tensor: /Div_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Div [Div] outputs: [/Div_output_0 -> (-1, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Sub_1 [Sub]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Gather_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Div_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Sub_1 [Sub] inputs: [/Gather_2_output_0 -> (-1, 15120)[FLOAT]], [/Div_output_0 -> (-1, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Sub_1 for ONNX node: /Sub_1
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Sub_1_output_0 for ONNX tensor: /Sub_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Sub_1 [Sub] outputs: [/Sub_1_output_0 -> (-1, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Shape_2 [Shape]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Gather_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Shape_2 [Shape] inputs: [/Gather_2_output_0 -> (-1, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Shape_2 for ONNX node: /Shape_2
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Shape_2_output_0 for ONNX tensor: /Shape_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Shape_2 [Shape] outputs: [/Shape_2_output_0 -> (2)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Expand [Expand]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Sub_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Shape_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Expand [Expand] inputs: [/Sub_1_output_0 -> (-1, 15120)[FLOAT]], [/Shape_2_output_0 -> (2)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Expand for ONNX node: /Expand
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Expand_output_0 for ONNX tensor: /Expand_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Expand [Expand] outputs: [/Expand_output_0 -> (-1, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Shape_3 [Shape]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Slice_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Shape_3 [Shape] inputs: [/Slice_output_0 -> (-1, 15120, 4)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Shape_3 for ONNX node: /Shape_3
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Shape_3_output_0 for ONNX tensor: /Shape_3_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Shape_3 [Shape] outputs: [/Shape_3_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Gather_5 [Gather]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Shape_3_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Constant_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Gather_5 [Gather] inputs: [/Shape_3_output_0 -> (3)[INT32]], [/backbone_model/model.22/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Using Gather axis: 0
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Gather_5 for ONNX node: /Gather_5
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Gather_5_output_0 for ONNX tensor: /Gather_5_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Gather_5 [Gather] outputs: [/Gather_5_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Range [Range]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Constant_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Gather_5_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.0/conv/Constant_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Range [Range] inputs: [/backbone_model/model.22/Constant_output_0 -> ()[INT32]], [/Gather_5_output_0 -> ()[INT32]], [/backbone_model/model.0/conv/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Range for ONNX node: /Range
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Range_output_0 for ONNX tensor: /Range_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Range [Range] outputs: [/Range_output_0 -> (-1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Reshape [Reshape]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Range_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Constant_19_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Reshape [Reshape] inputs: [/Range_output_0 -> (-1)[INT32]], [/Constant_19_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Reshape for ONNX node: /Reshape
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Reshape_output_0 for ONNX tensor: /Reshape_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Reshape [Reshape] outputs: [/Reshape_output_0 -> (-1, 1, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Add_1 [Add]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Reshape_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Reshape_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Add_1 [Add] inputs: [/Reshape_output_0 -> (-1, 1, 1)[INT32]], [/Reshape_1_output_0 -> (15120, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Reshape_1_output_0 for ONNX node: /Reshape_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Add_1 for ONNX node: /Add_1
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Add_1_output_0 for ONNX tensor: /Add_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Add_1 [Add] outputs: [/Add_1_output_0 -> (-1, 15120, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Shape_5 [Shape]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Add_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Shape_5 [Shape] inputs: [/Add_1_output_0 -> (-1, 15120, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Shape_5 for ONNX node: /Shape_5
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Shape_5_output_0 for ONNX tensor: /Shape_5_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Shape_5 [Shape] outputs: [/Shape_5_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Equal [Equal]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Shape_5_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Mul_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Equal [Equal] inputs: [/Shape_5_output_0 -> (3)[INT32]], [/Mul_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Mul_output_0 for ONNX node: /Mul_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Equal for ONNX node: /Equal
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Equal_output_0 for ONNX tensor: /Equal_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Equal [Equal] outputs: [/Equal_output_0 -> (3)[BOOL]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Where [Where]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Equal_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /ConstantOfShape_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Shape_5_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Where [Where] inputs: [/Equal_output_0 -> (3)[BOOL]], [/ConstantOfShape_1_output_0 -> (3)[INT32]], [/Shape_5_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /ConstantOfShape_1_output_0 for ONNX node: /ConstantOfShape_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Where for ONNX node: /Where
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Where_output_0 for ONNX tensor: /Where_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Where [Where] outputs: [/Where_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Expand_1 [Expand]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Reshape_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Where_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Expand_1 [Expand] inputs: [/Reshape_output_0 -> (-1, 1, 1)[INT32]], [/Where_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Expand_1 for ONNX node: /Expand_1
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Expand_1_output_0 for ONNX tensor: /Expand_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Expand_1 [Expand] outputs: [/Expand_1_output_0 -> (-1, 15120, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Unsqueeze_3 [Unsqueeze]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Expand_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Constant_3_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Unsqueeze_3 [Unsqueeze] inputs: [/Expand_1_output_0 -> (-1, 15120, 1)[INT32]], [/backbone_model/model.22/Constant_3_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Original shape: (_, 15120, 1), unsqueezing to: (_, _, _, _)
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Unsqueeze_3 for ONNX node: /Unsqueeze_3
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Unsqueeze_3_output_0 for ONNX tensor: /Unsqueeze_3_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Unsqueeze_3 [Unsqueeze] outputs: [/Unsqueeze_3_output_0 -> (-1, 15120, 1, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Expand_2 [Expand]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Reshape_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Where_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Expand_2 [Expand] inputs: [/Reshape_1_output_0 -> (15120, 1)[INT32]], [/Where_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Expand_2 for ONNX node: /Expand_2
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Expand_2_output_0 for ONNX tensor: /Expand_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Expand_2 [Expand] outputs: [/Expand_2_output_0 -> (-1, 15120, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Unsqueeze_4 [Unsqueeze]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Expand_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Constant_3_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Unsqueeze_4 [Unsqueeze] inputs: [/Expand_2_output_0 -> (-1, 15120, 1)[INT32]], [/backbone_model/model.22/Constant_3_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Original shape: (_, 15120, 1), unsqueezing to: (_, _, _, _)
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Unsqueeze_4 for ONNX node: /Unsqueeze_4
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Unsqueeze_4_output_0 for ONNX tensor: /Unsqueeze_4_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Unsqueeze_4 [Unsqueeze] outputs: [/Unsqueeze_4_output_0 -> (-1, 15120, 1, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Expand_3 [Expand]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Where_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Expand_3 [Expand] inputs: [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]], [/Where_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /backbone_model/model.2/Constant_2_output_0 for ONNX node: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Expand_3 for ONNX node: /Expand_3
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Expand_3_output_0 for ONNX tensor: /Expand_3_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Expand_3 [Expand] outputs: [/Expand_3_output_0 -> (-1, 15120, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Unsqueeze_5 [Unsqueeze]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Expand_3_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Constant_3_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Unsqueeze_5 [Unsqueeze] inputs: [/Expand_3_output_0 -> (-1, 15120, 1)[INT32]], [/backbone_model/model.22/Constant_3_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Original shape: (_, 15120, 1), unsqueezing to: (_, _, _, _)
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Unsqueeze_5 for ONNX node: /Unsqueeze_5
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Unsqueeze_5_output_0 for ONNX tensor: /Unsqueeze_5_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Unsqueeze_5 [Unsqueeze] outputs: [/Unsqueeze_5_output_0 -> (-1, 15120, 1, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Concat_2 [Concat]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Unsqueeze_3_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Unsqueeze_4_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Unsqueeze_5_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Concat_2 [Concat] inputs: [/Unsqueeze_3_output_0 -> (-1, 15120, 1, 1)[INT32]], [/Unsqueeze_4_output_0 -> (-1, 15120, 1, 1)[INT32]], [/Unsqueeze_5_output_0 -> (-1, 15120, 1, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Concat_2 for ONNX node: /Concat_2
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Concat_2_output_0 for ONNX tensor: /Concat_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Concat_2 [Concat] outputs: [/Concat_2_output_0 -> (-1, 15120, 1, 3)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Reshape_2 [Reshape]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Expand_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Shape_5_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Reshape_2 [Reshape] inputs: [/Expand_output_0 -> (-1, 15120)[FLOAT]], [/Shape_5_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Reshape_2 for ONNX node: /Reshape_2
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Reshape_2_output_0 for ONNX tensor: /Reshape_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Reshape_2 [Reshape] outputs: [/Reshape_2_output_0 -> (-1, 15120, 1)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /ScatterND [ScatterND]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Slice_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Concat_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Reshape_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /ScatterND [ScatterND] inputs: [/Slice_output_0 -> (-1, 15120, 4)[FLOAT]], [/Concat_2_output_0 -> (-1, 15120, 1, 3)[INT32]], [/Reshape_2_output_0 -> (-1, 15120, 1)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /ScatterND for ONNX node: /ScatterND
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /ScatterND_output_0 for ONNX tensor: /ScatterND_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /ScatterND [ScatterND] outputs: [/ScatterND_output_0 -> (-1, 15120, 4)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Gather_7 [Gather]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Slice_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.0/conv/Constant_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Gather_7 [Gather] inputs: [/Slice_output_0 -> (-1, 15120, 4)[FLOAT]], [/backbone_model/model.0/conv/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Using Gather axis: 2
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Gather_7 for ONNX node: /Gather_7
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Gather_7_output_0 for ONNX tensor: /Gather_7_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Gather_7 [Gather] outputs: [/Gather_7_output_0 -> (-1, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Gather_8 [Gather]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Slice_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Constant_31_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Gather_8 [Gather] inputs: [/Slice_output_0 -> (-1, 15120, 4)[FLOAT]], [/Constant_31_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Constant_31_output_0 for ONNX node: /Constant_31_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Using Gather axis: 2
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Gather_8 for ONNX node: /Gather_8
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Gather_8_output_0 for ONNX tensor: /Gather_8_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Gather_8 [Gather] outputs: [/Gather_8_output_0 -> (-1, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Div_1 [Div]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Gather_8_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Constant_16_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Div_1 [Div] inputs: [/Gather_8_output_0 -> (-1, 15120)[FLOAT]], [/backbone_model/model.22/Constant_16_output_0 -> ()[HALF]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Div_1 for ONNX node: /Div_1
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Div_1_output_0 for ONNX tensor: /Div_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Div_1 [Div] outputs: [/Div_1_output_0 -> (-1, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Sub_2 [Sub]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Gather_7_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Div_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Sub_2 [Sub] inputs: [/Gather_7_output_0 -> (-1, 15120)[FLOAT]], [/Div_1_output_0 -> (-1, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Sub_2 for ONNX node: /Sub_2
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Sub_2_output_0 for ONNX tensor: /Sub_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Sub_2 [Sub] outputs: [/Sub_2_output_0 -> (-1, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Gather_9 [Gather]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /ScatterND_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.0/conv/Constant_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Gather_9 [Gather] inputs: [/ScatterND_output_0 -> (-1, 15120, 4)[FLOAT]], [/backbone_model/model.0/conv/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Using Gather axis: 2
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Gather_9 for ONNX node: /Gather_9
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Gather_9_output_0 for ONNX tensor: /Gather_9_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Gather_9 [Gather] outputs: [/Gather_9_output_0 -> (-1, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Shape_10 [Shape]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Gather_9_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Shape_10 [Shape] inputs: [/Gather_9_output_0 -> (-1, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Shape_10 for ONNX node: /Shape_10
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Shape_10_output_0 for ONNX tensor: /Shape_10_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Shape_10 [Shape] outputs: [/Shape_10_output_0 -> (2)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Expand_4 [Expand]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Sub_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Shape_10_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Expand_4 [Expand] inputs: [/Sub_2_output_0 -> (-1, 15120)[FLOAT]], [/Shape_10_output_0 -> (2)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Expand_4 for ONNX node: /Expand_4
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Expand_4_output_0 for ONNX tensor: /Expand_4_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Expand_4 [Expand] outputs: [/Expand_4_output_0 -> (-1, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Shape_11 [Shape]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /ScatterND_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Shape_11 [Shape] inputs: [/ScatterND_output_0 -> (-1, 15120, 4)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Shape_11 for ONNX node: /Shape_11
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Shape_11_output_0 for ONNX tensor: /Shape_11_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Shape_11 [Shape] outputs: [/Shape_11_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Gather_10 [Gather]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Shape_11_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Constant_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Gather_10 [Gather] inputs: [/Shape_11_output_0 -> (3)[INT32]], [/backbone_model/model.22/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Using Gather axis: 0
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Gather_10 for ONNX node: /Gather_10
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Gather_10_output_0 for ONNX tensor: /Gather_10_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Gather_10 [Gather] outputs: [/Gather_10_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Range_2 [Range]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Constant_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Gather_10_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.0/conv/Constant_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Range_2 [Range] inputs: [/backbone_model/model.22/Constant_output_0 -> ()[INT32]], [/Gather_10_output_0 -> ()[INT32]], [/backbone_model/model.0/conv/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Range_2 for ONNX node: /Range_2
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Range_2_output_0 for ONNX tensor: /Range_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Range_2 [Range] outputs: [/Range_2_output_0 -> (-1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Reshape_3 [Reshape]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Range_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Constant_19_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Reshape_3 [Reshape] inputs: [/Range_2_output_0 -> (-1)[INT32]], [/Constant_19_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Reshape_3 for ONNX node: /Reshape_3
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Reshape_3_output_0 for ONNX tensor: /Reshape_3_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Reshape_3 [Reshape] outputs: [/Reshape_3_output_0 -> (-1, 1, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Add_3 [Add]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Reshape_3_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Reshape_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Add_3 [Add] inputs: [/Reshape_3_output_0 -> (-1, 1, 1)[INT32]], [/Reshape_1_output_0 -> (15120, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Add_3 for ONNX node: /Add_3
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Add_3_output_0 for ONNX tensor: /Add_3_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Add_3 [Add] outputs: [/Add_3_output_0 -> (-1, 15120, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Add_4 [Add]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Add_3_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Add_4 [Add] inputs: [/Add_3_output_0 -> (-1, 15120, 1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Add_4 for ONNX node: /Add_4
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Add_4_output_0 for ONNX tensor: /Add_4_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Add_4 [Add] outputs: [/Add_4_output_0 -> (-1, 15120, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Shape_13 [Shape]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Add_4_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Shape_13 [Shape] inputs: [/Add_4_output_0 -> (-1, 15120, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Shape_13 for ONNX node: /Shape_13
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Shape_13_output_0 for ONNX tensor: /Shape_13_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Shape_13 [Shape] outputs: [/Shape_13_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Equal_3 [Equal]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Shape_13_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Mul_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Equal_3 [Equal] inputs: [/Shape_13_output_0 -> (3)[INT32]], [/Mul_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Equal_3 for ONNX node: /Equal_3
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Equal_3_output_0 for ONNX tensor: /Equal_3_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Equal_3 [Equal] outputs: [/Equal_3_output_0 -> (3)[BOOL]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Where_3 [Where]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Equal_3_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /ConstantOfShape_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Shape_13_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Where_3 [Where] inputs: [/Equal_3_output_0 -> (3)[BOOL]], [/ConstantOfShape_1_output_0 -> (3)[INT32]], [/Shape_13_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Where_3 for ONNX node: /Where_3
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Where_3_output_0 for ONNX tensor: /Where_3_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Where_3 [Where] outputs: [/Where_3_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Expand_5 [Expand]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Reshape_3_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Where_3_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Expand_5 [Expand] inputs: [/Reshape_3_output_0 -> (-1, 1, 1)[INT32]], [/Where_3_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Expand_5 for ONNX node: /Expand_5
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Expand_5_output_0 for ONNX tensor: /Expand_5_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Expand_5 [Expand] outputs: [/Expand_5_output_0 -> (-1, 15120, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Unsqueeze_6 [Unsqueeze]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Expand_5_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Constant_3_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Unsqueeze_6 [Unsqueeze] inputs: [/Expand_5_output_0 -> (-1, 15120, 1)[INT32]], [/backbone_model/model.22/Constant_3_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Original shape: (_, 15120, 1), unsqueezing to: (_, _, _, _)
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Unsqueeze_6 for ONNX node: /Unsqueeze_6
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Unsqueeze_6_output_0 for ONNX tensor: /Unsqueeze_6_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Unsqueeze_6 [Unsqueeze] outputs: [/Unsqueeze_6_output_0 -> (-1, 15120, 1, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Expand_6 [Expand]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Reshape_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Where_3_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Expand_6 [Expand] inputs: [/Reshape_1_output_0 -> (15120, 1)[INT32]], [/Where_3_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Expand_6 for ONNX node: /Expand_6
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Expand_6_output_0 for ONNX tensor: /Expand_6_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Expand_6 [Expand] outputs: [/Expand_6_output_0 -> (-1, 15120, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Unsqueeze_7 [Unsqueeze]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Expand_6_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Constant_3_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Unsqueeze_7 [Unsqueeze] inputs: [/Expand_6_output_0 -> (-1, 15120, 1)[INT32]], [/backbone_model/model.22/Constant_3_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Original shape: (_, 15120, 1), unsqueezing to: (_, _, _, _)
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Unsqueeze_7 for ONNX node: /Unsqueeze_7
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Unsqueeze_7_output_0 for ONNX tensor: /Unsqueeze_7_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Unsqueeze_7 [Unsqueeze] outputs: [/Unsqueeze_7_output_0 -> (-1, 15120, 1, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Expand_7 [Expand]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Where_3_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Expand_7 [Expand] inputs: [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]], [/Where_3_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Expand_7 for ONNX node: /Expand_7
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Expand_7_output_0 for ONNX tensor: /Expand_7_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Expand_7 [Expand] outputs: [/Expand_7_output_0 -> (-1, 15120, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Unsqueeze_8 [Unsqueeze]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Expand_7_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Constant_3_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Unsqueeze_8 [Unsqueeze] inputs: [/Expand_7_output_0 -> (-1, 15120, 1)[INT32]], [/backbone_model/model.22/Constant_3_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Original shape: (_, 15120, 1), unsqueezing to: (_, _, _, _)
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Unsqueeze_8 for ONNX node: /Unsqueeze_8
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Unsqueeze_8_output_0 for ONNX tensor: /Unsqueeze_8_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Unsqueeze_8 [Unsqueeze] outputs: [/Unsqueeze_8_output_0 -> (-1, 15120, 1, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Concat_4 [Concat]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Unsqueeze_6_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Unsqueeze_7_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Unsqueeze_8_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Concat_4 [Concat] inputs: [/Unsqueeze_6_output_0 -> (-1, 15120, 1, 1)[INT32]], [/Unsqueeze_7_output_0 -> (-1, 15120, 1, 1)[INT32]], [/Unsqueeze_8_output_0 -> (-1, 15120, 1, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Concat_4 for ONNX node: /Concat_4
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Concat_4_output_0 for ONNX tensor: /Concat_4_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Concat_4 [Concat] outputs: [/Concat_4_output_0 -> (-1, 15120, 1, 3)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Reshape_5 [Reshape]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Expand_4_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Shape_13_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Reshape_5 [Reshape] inputs: [/Expand_4_output_0 -> (-1, 15120)[FLOAT]], [/Shape_13_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Reshape_5 for ONNX node: /Reshape_5
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Reshape_5_output_0 for ONNX tensor: /Reshape_5_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Reshape_5 [Reshape] outputs: [/Reshape_5_output_0 -> (-1, 15120, 1)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /ScatterND_1 [ScatterND]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /ScatterND_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Concat_4_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Reshape_5_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /ScatterND_1 [ScatterND] inputs: [/ScatterND_output_0 -> (-1, 15120, 4)[FLOAT]], [/Concat_4_output_0 -> (-1, 15120, 1, 3)[INT32]], [/Reshape_5_output_0 -> (-1, 15120, 1)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /ScatterND_1 for ONNX node: /ScatterND_1
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /ScatterND_1_output_0 for ONNX tensor: /ScatterND_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /ScatterND_1 [ScatterND] outputs: [/ScatterND_1_output_0 -> (-1, 15120, 4)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Add_5 [Add]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Gather_2_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Div_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Add_5 [Add] inputs: [/Gather_2_output_0 -> (-1, 15120)[FLOAT]], [/Div_output_0 -> (-1, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Add_5 for ONNX node: /Add_5
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Add_5_output_0 for ONNX tensor: /Add_5_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Add_5 [Add] outputs: [/Add_5_output_0 -> (-1, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Gather_14 [Gather]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /ScatterND_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.2/Constant_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Gather_14 [Gather] inputs: [/ScatterND_1_output_0 -> (-1, 15120, 4)[FLOAT]], [/backbone_model/model.2/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Using Gather axis: 2
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Gather_14 for ONNX node: /Gather_14
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Gather_14_output_0 for ONNX tensor: /Gather_14_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Gather_14 [Gather] outputs: [/Gather_14_output_0 -> (-1, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Shape_18 [Shape]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Gather_14_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Shape_18 [Shape] inputs: [/Gather_14_output_0 -> (-1, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Shape_18 for ONNX node: /Shape_18
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Shape_18_output_0 for ONNX tensor: /Shape_18_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Shape_18 [Shape] outputs: [/Shape_18_output_0 -> (2)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Expand_8 [Expand]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Add_5_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Shape_18_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Expand_8 [Expand] inputs: [/Add_5_output_0 -> (-1, 15120)[FLOAT]], [/Shape_18_output_0 -> (2)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Expand_8 for ONNX node: /Expand_8
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Expand_8_output_0 for ONNX tensor: /Expand_8_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Expand_8 [Expand] outputs: [/Expand_8_output_0 -> (-1, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Shape_19 [Shape]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /ScatterND_1_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Shape_19 [Shape] inputs: [/ScatterND_1_output_0 -> (-1, 15120, 4)[FLOAT]],
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Shape_19 for ONNX node: /Shape_19
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Shape_19_output_0 for ONNX tensor: /Shape_19_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Shape_19 [Shape] outputs: [/Shape_19_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Parsing node: /Gather_15 [Gather]
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /Shape_19_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] Searching for input: /backbone_model/model.22/Constant_output_0
[TH_YF8S][26-01-14 11:43:44][TRT] /Gather_15 [Gather] inputs: [/Shape_19_output_0 -> (3)[INT32]], [/backbone_model/model.22/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:44][TRT] Using Gather axis: 0
[TH_YF8S][26-01-14 11:43:44][TRT] Registering layer: /Gather_15 for ONNX node: /Gather_15
[TH_YF8S][26-01-14 11:43:44][TRT] Registering tensor: /Gather_15_output_0 for ONNX tensor: /Gather_15_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Gather_15 [Gather] outputs: [/Gather_15_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Range_4 [Range]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.22/Constant_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Gather_15_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.0/conv/Constant_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Range_4 [Range] inputs: [/backbone_model/model.22/Constant_output_0 -> ()[INT32]], [/Gather_15_output_0 -> ()[INT32]], [/backbone_model/model.0/conv/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Range_4 for ONNX node: /Range_4
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Range_4_output_0 for ONNX tensor: /Range_4_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Range_4 [Range] outputs: [/Range_4_output_0 -> (-1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Reshape_6 [Reshape]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Range_4_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Constant_19_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Reshape_6 [Reshape] inputs: [/Range_4_output_0 -> (-1)[INT32]], [/Constant_19_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Reshape_6 for ONNX node: /Reshape_6
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Reshape_6_output_0 for ONNX tensor: /Reshape_6_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Reshape_6 [Reshape] outputs: [/Reshape_6_output_0 -> (-1, 1, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Add_6 [Add]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Reshape_6_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Reshape_1_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Add_6 [Add] inputs: [/Reshape_6_output_0 -> (-1, 1, 1)[INT32]], [/Reshape_1_output_0 -> (15120, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Add_6 for ONNX node: /Add_6
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Add_6_output_0 for ONNX tensor: /Add_6_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Add_6 [Add] outputs: [/Add_6_output_0 -> (-1, 15120, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Add_7 [Add]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Add_6_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.2/Constant_4_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Add_7 [Add] inputs: [/Add_6_output_0 -> (-1, 15120, 1)[INT32]], [/backbone_model/model.2/Constant_4_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Add_7 for ONNX node: /Add_7
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Add_7_output_0 for ONNX tensor: /Add_7_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Add_7 [Add] outputs: [/Add_7_output_0 -> (-1, 15120, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Shape_21 [Shape]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Add_7_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Shape_21 [Shape] inputs: [/Add_7_output_0 -> (-1, 15120, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Shape_21 for ONNX node: /Shape_21
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Shape_21_output_0 for ONNX tensor: /Shape_21_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Shape_21 [Shape] outputs: [/Shape_21_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Equal_6 [Equal]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Shape_21_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Mul_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Equal_6 [Equal] inputs: [/Shape_21_output_0 -> (3)[INT32]], [/Mul_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Equal_6 for ONNX node: /Equal_6
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Equal_6_output_0 for ONNX tensor: /Equal_6_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Equal_6 [Equal] outputs: [/Equal_6_output_0 -> (3)[BOOL]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Where_6 [Where]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Equal_6_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /ConstantOfShape_1_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Shape_21_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Where_6 [Where] inputs: [/Equal_6_output_0 -> (3)[BOOL]], [/ConstantOfShape_1_output_0 -> (3)[INT32]], [/Shape_21_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Where_6 for ONNX node: /Where_6
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Where_6_output_0 for ONNX tensor: /Where_6_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Where_6 [Where] outputs: [/Where_6_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Expand_9 [Expand]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Reshape_6_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Where_6_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Expand_9 [Expand] inputs: [/Reshape_6_output_0 -> (-1, 1, 1)[INT32]], [/Where_6_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Expand_9 for ONNX node: /Expand_9
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Expand_9_output_0 for ONNX tensor: /Expand_9_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Expand_9 [Expand] outputs: [/Expand_9_output_0 -> (-1, 15120, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Unsqueeze_9 [Unsqueeze]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Expand_9_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.22/Constant_3_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Unsqueeze_9 [Unsqueeze] inputs: [/Expand_9_output_0 -> (-1, 15120, 1)[INT32]], [/backbone_model/model.22/Constant_3_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Original shape: (_, 15120, 1), unsqueezing to: (_, _, _, _)
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Unsqueeze_9 for ONNX node: /Unsqueeze_9
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Unsqueeze_9_output_0 for ONNX tensor: /Unsqueeze_9_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Unsqueeze_9 [Unsqueeze] outputs: [/Unsqueeze_9_output_0 -> (-1, 15120, 1, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Expand_10 [Expand]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Reshape_1_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Where_6_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Expand_10 [Expand] inputs: [/Reshape_1_output_0 -> (15120, 1)[INT32]], [/Where_6_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Expand_10 for ONNX node: /Expand_10
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Expand_10_output_0 for ONNX tensor: /Expand_10_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Expand_10 [Expand] outputs: [/Expand_10_output_0 -> (-1, 15120, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Unsqueeze_10 [Unsqueeze]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Expand_10_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.22/Constant_3_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Unsqueeze_10 [Unsqueeze] inputs: [/Expand_10_output_0 -> (-1, 15120, 1)[INT32]], [/backbone_model/model.22/Constant_3_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Original shape: (_, 15120, 1), unsqueezing to: (_, _, _, _)
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Unsqueeze_10 for ONNX node: /Unsqueeze_10
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Unsqueeze_10_output_0 for ONNX tensor: /Unsqueeze_10_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Unsqueeze_10 [Unsqueeze] outputs: [/Unsqueeze_10_output_0 -> (-1, 15120, 1, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Expand_11 [Expand]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.2/Constant_4_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Where_6_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Expand_11 [Expand] inputs: [/backbone_model/model.2/Constant_4_output_0 -> (1)[INT32]], [/Where_6_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Expand_11 for ONNX node: /Expand_11
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Expand_11_output_0 for ONNX tensor: /Expand_11_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Expand_11 [Expand] outputs: [/Expand_11_output_0 -> (-1, 15120, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Unsqueeze_11 [Unsqueeze]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Expand_11_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.22/Constant_3_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Unsqueeze_11 [Unsqueeze] inputs: [/Expand_11_output_0 -> (-1, 15120, 1)[INT32]], [/backbone_model/model.22/Constant_3_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Original shape: (_, 15120, 1), unsqueezing to: (_, _, _, _)
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Unsqueeze_11 for ONNX node: /Unsqueeze_11
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Unsqueeze_11_output_0 for ONNX tensor: /Unsqueeze_11_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Unsqueeze_11 [Unsqueeze] outputs: [/Unsqueeze_11_output_0 -> (-1, 15120, 1, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Concat_6 [Concat]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Unsqueeze_9_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Unsqueeze_10_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Unsqueeze_11_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Concat_6 [Concat] inputs: [/Unsqueeze_9_output_0 -> (-1, 15120, 1, 1)[INT32]], [/Unsqueeze_10_output_0 -> (-1, 15120, 1, 1)[INT32]], [/Unsqueeze_11_output_0 -> (-1, 15120, 1, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Concat_6 for ONNX node: /Concat_6
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Concat_6_output_0 for ONNX tensor: /Concat_6_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Concat_6 [Concat] outputs: [/Concat_6_output_0 -> (-1, 15120, 1, 3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Reshape_8 [Reshape]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Expand_8_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Shape_21_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Reshape_8 [Reshape] inputs: [/Expand_8_output_0 -> (-1, 15120)[FLOAT]], [/Shape_21_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Reshape_8 for ONNX node: /Reshape_8
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Reshape_8_output_0 for ONNX tensor: /Reshape_8_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Reshape_8 [Reshape] outputs: [/Reshape_8_output_0 -> (-1, 15120, 1)[FLOAT]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /ScatterND_2 [ScatterND]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /ScatterND_1_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Concat_6_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Reshape_8_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /ScatterND_2 [ScatterND] inputs: [/ScatterND_1_output_0 -> (-1, 15120, 4)[FLOAT]], [/Concat_6_output_0 -> (-1, 15120, 1, 3)[INT32]], [/Reshape_8_output_0 -> (-1, 15120, 1)[FLOAT]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /ScatterND_2 for ONNX node: /ScatterND_2
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /ScatterND_2_output_0 for ONNX tensor: /ScatterND_2_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /ScatterND_2 [ScatterND] outputs: [/ScatterND_2_output_0 -> (-1, 15120, 4)[FLOAT]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Add_8 [Add]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Gather_7_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Div_1_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Add_8 [Add] inputs: [/Gather_7_output_0 -> (-1, 15120)[FLOAT]], [/Div_1_output_0 -> (-1, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Add_8 for ONNX node: /Add_8
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Add_8_output_0 for ONNX tensor: /Add_8_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Add_8 [Add] outputs: [/Add_8_output_0 -> (-1, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Gather_19 [Gather]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /ScatterND_2_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Constant_31_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Gather_19 [Gather] inputs: [/ScatterND_2_output_0 -> (-1, 15120, 4)[FLOAT]], [/Constant_31_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Using Gather axis: 2
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Gather_19 for ONNX node: /Gather_19
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Gather_19_output_0 for ONNX tensor: /Gather_19_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Gather_19 [Gather] outputs: [/Gather_19_output_0 -> (-1, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Shape_26 [Shape]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Gather_19_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Shape_26 [Shape] inputs: [/Gather_19_output_0 -> (-1, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Shape_26 for ONNX node: /Shape_26
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Shape_26_output_0 for ONNX tensor: /Shape_26_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Shape_26 [Shape] outputs: [/Shape_26_output_0 -> (2)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Expand_12 [Expand]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Add_8_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Shape_26_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Expand_12 [Expand] inputs: [/Add_8_output_0 -> (-1, 15120)[FLOAT]], [/Shape_26_output_0 -> (2)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Expand_12 for ONNX node: /Expand_12
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Expand_12_output_0 for ONNX tensor: /Expand_12_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Expand_12 [Expand] outputs: [/Expand_12_output_0 -> (-1, 15120)[FLOAT]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Shape_27 [Shape]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /ScatterND_2_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Shape_27 [Shape] inputs: [/ScatterND_2_output_0 -> (-1, 15120, 4)[FLOAT]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Shape_27 for ONNX node: /Shape_27
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Shape_27_output_0 for ONNX tensor: /Shape_27_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Shape_27 [Shape] outputs: [/Shape_27_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Gather_20 [Gather]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Shape_27_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.22/Constant_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Gather_20 [Gather] inputs: [/Shape_27_output_0 -> (3)[INT32]], [/backbone_model/model.22/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Using Gather axis: 0
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Gather_20 for ONNX node: /Gather_20
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Gather_20_output_0 for ONNX tensor: /Gather_20_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Gather_20 [Gather] outputs: [/Gather_20_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Range_6 [Range]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.22/Constant_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Gather_20_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.0/conv/Constant_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Range_6 [Range] inputs: [/backbone_model/model.22/Constant_output_0 -> ()[INT32]], [/Gather_20_output_0 -> ()[INT32]], [/backbone_model/model.0/conv/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Range_6 for ONNX node: /Range_6
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Range_6_output_0 for ONNX tensor: /Range_6_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Range_6 [Range] outputs: [/Range_6_output_0 -> (-1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Reshape_9 [Reshape]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Range_6_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Constant_19_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Reshape_9 [Reshape] inputs: [/Range_6_output_0 -> (-1)[INT32]], [/Constant_19_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Reshape_9 for ONNX node: /Reshape_9
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Reshape_9_output_0 for ONNX tensor: /Reshape_9_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Reshape_9 [Reshape] outputs: [/Reshape_9_output_0 -> (-1, 1, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Add_9 [Add]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Reshape_9_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Reshape_1_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Add_9 [Add] inputs: [/Reshape_9_output_0 -> (-1, 1, 1)[INT32]], [/Reshape_1_output_0 -> (15120, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Add_9 for ONNX node: /Add_9
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Add_9_output_0 for ONNX tensor: /Add_9_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Add_9 [Add] outputs: [/Add_9_output_0 -> (-1, 15120, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Add_10 [Add]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Add_9_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Constant_79_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Add_10 [Add] inputs: [/Add_9_output_0 -> (-1, 15120, 1)[INT32]], [/Constant_79_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Constant_79_output_0 for ONNX node: /Constant_79_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Add_10 for ONNX node: /Add_10
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Add_10_output_0 for ONNX tensor: /Add_10_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Add_10 [Add] outputs: [/Add_10_output_0 -> (-1, 15120, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Shape_29 [Shape]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Add_10_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Shape_29 [Shape] inputs: [/Add_10_output_0 -> (-1, 15120, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Shape_29 for ONNX node: /Shape_29
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Shape_29_output_0 for ONNX tensor: /Shape_29_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Shape_29 [Shape] outputs: [/Shape_29_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Equal_9 [Equal]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Shape_29_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Mul_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Equal_9 [Equal] inputs: [/Shape_29_output_0 -> (3)[INT32]], [/Mul_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Equal_9 for ONNX node: /Equal_9
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Equal_9_output_0 for ONNX tensor: /Equal_9_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Equal_9 [Equal] outputs: [/Equal_9_output_0 -> (3)[BOOL]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Where_9 [Where]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Equal_9_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /ConstantOfShape_1_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Shape_29_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Where_9 [Where] inputs: [/Equal_9_output_0 -> (3)[BOOL]], [/ConstantOfShape_1_output_0 -> (3)[INT32]], [/Shape_29_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Where_9 for ONNX node: /Where_9
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Where_9_output_0 for ONNX tensor: /Where_9_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Where_9 [Where] outputs: [/Where_9_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Expand_13 [Expand]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Reshape_9_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Where_9_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Expand_13 [Expand] inputs: [/Reshape_9_output_0 -> (-1, 1, 1)[INT32]], [/Where_9_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Expand_13 for ONNX node: /Expand_13
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Expand_13_output_0 for ONNX tensor: /Expand_13_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Expand_13 [Expand] outputs: [/Expand_13_output_0 -> (-1, 15120, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Unsqueeze_12 [Unsqueeze]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Expand_13_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.22/Constant_3_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Unsqueeze_12 [Unsqueeze] inputs: [/Expand_13_output_0 -> (-1, 15120, 1)[INT32]], [/backbone_model/model.22/Constant_3_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Original shape: (_, 15120, 1), unsqueezing to: (_, _, _, _)
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Unsqueeze_12 for ONNX node: /Unsqueeze_12
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Unsqueeze_12_output_0 for ONNX tensor: /Unsqueeze_12_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Unsqueeze_12 [Unsqueeze] outputs: [/Unsqueeze_12_output_0 -> (-1, 15120, 1, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Expand_14 [Expand]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Reshape_1_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Where_9_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Expand_14 [Expand] inputs: [/Reshape_1_output_0 -> (15120, 1)[INT32]], [/Where_9_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Expand_14 for ONNX node: /Expand_14
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Expand_14_output_0 for ONNX tensor: /Expand_14_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Expand_14 [Expand] outputs: [/Expand_14_output_0 -> (-1, 15120, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Unsqueeze_13 [Unsqueeze]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Expand_14_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.22/Constant_3_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Unsqueeze_13 [Unsqueeze] inputs: [/Expand_14_output_0 -> (-1, 15120, 1)[INT32]], [/backbone_model/model.22/Constant_3_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Original shape: (_, 15120, 1), unsqueezing to: (_, _, _, _)
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Unsqueeze_13 for ONNX node: /Unsqueeze_13
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Unsqueeze_13_output_0 for ONNX tensor: /Unsqueeze_13_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Unsqueeze_13 [Unsqueeze] outputs: [/Unsqueeze_13_output_0 -> (-1, 15120, 1, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Expand_15 [Expand]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Constant_79_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Where_9_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Expand_15 [Expand] inputs: [/Constant_79_output_0 -> (1)[INT32]], [/Where_9_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Expand_15 for ONNX node: /Expand_15
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Expand_15_output_0 for ONNX tensor: /Expand_15_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Expand_15 [Expand] outputs: [/Expand_15_output_0 -> (-1, 15120, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Unsqueeze_14 [Unsqueeze]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Expand_15_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.22/Constant_3_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Unsqueeze_14 [Unsqueeze] inputs: [/Expand_15_output_0 -> (-1, 15120, 1)[INT32]], [/backbone_model/model.22/Constant_3_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Original shape: (_, 15120, 1), unsqueezing to: (_, _, _, _)
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Unsqueeze_14 for ONNX node: /Unsqueeze_14
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Unsqueeze_14_output_0 for ONNX tensor: /Unsqueeze_14_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Unsqueeze_14 [Unsqueeze] outputs: [/Unsqueeze_14_output_0 -> (-1, 15120, 1, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Concat_8 [Concat]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Unsqueeze_12_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Unsqueeze_13_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Unsqueeze_14_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Concat_8 [Concat] inputs: [/Unsqueeze_12_output_0 -> (-1, 15120, 1, 1)[INT32]], [/Unsqueeze_13_output_0 -> (-1, 15120, 1, 1)[INT32]], [/Unsqueeze_14_output_0 -> (-1, 15120, 1, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Concat_8 for ONNX node: /Concat_8
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Concat_8_output_0 for ONNX tensor: /Concat_8_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Concat_8 [Concat] outputs: [/Concat_8_output_0 -> (-1, 15120, 1, 3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Reshape_11 [Reshape]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Expand_12_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Shape_29_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Reshape_11 [Reshape] inputs: [/Expand_12_output_0 -> (-1, 15120)[FLOAT]], [/Shape_29_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Reshape_11 for ONNX node: /Reshape_11
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Reshape_11_output_0 for ONNX tensor: /Reshape_11_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Reshape_11 [Reshape] outputs: [/Reshape_11_output_0 -> (-1, 15120, 1)[FLOAT]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /ScatterND_3 [ScatterND]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /ScatterND_2_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Concat_8_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Reshape_11_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /ScatterND_3 [ScatterND] inputs: [/ScatterND_2_output_0 -> (-1, 15120, 4)[FLOAT]], [/Concat_8_output_0 -> (-1, 15120, 1, 3)[INT32]], [/Reshape_11_output_0 -> (-1, 15120, 1)[FLOAT]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /ScatterND_3 for ONNX node: /ScatterND_3
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /ScatterND_3_output_0 for ONNX tensor: /ScatterND_3_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /ScatterND_3 [ScatterND] outputs: [/ScatterND_3_output_0 -> (-1, 15120, 4)[FLOAT]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /ArgMax [ArgMax]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Slice_1_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /ArgMax [ArgMax] inputs: [/Slice_1_output_0 -> (-1, 15120, 80)[FLOAT]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /ArgMax for ONNX node: /ArgMax
[TH_YF8S][26-01-14 11:43:45][TRT] Tensor DataType is determined at build time for tensors not marked as input or output.
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /ArgMax_output_0 for ONNX tensor: /ArgMax_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /ArgMax [ArgMax] outputs: [/ArgMax_output_0 -> (-1, 15120, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Shape_34 [Shape]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Slice_1_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Shape_34 [Shape] inputs: [/Slice_1_output_0 -> (-1, 15120, 80)[FLOAT]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Shape_34 for ONNX node: /Shape_34
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Shape_34_output_0 for ONNX tensor: /Shape_34_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Shape_34 [Shape] outputs: [/Shape_34_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Gather_22 [Gather]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Shape_34_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.22/Constant_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Gather_22 [Gather] inputs: [/Shape_34_output_0 -> (3)[INT32]], [/backbone_model/model.22/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Using Gather axis: 0
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Gather_22 for ONNX node: /Gather_22
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Gather_22_output_0 for ONNX tensor: /Gather_22_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Gather_22 [Gather] outputs: [/Gather_22_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Gather_23 [Gather]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Shape_34_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.0/conv/Constant_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Gather_23 [Gather] inputs: [/Shape_34_output_0 -> (3)[INT32]], [/backbone_model/model.0/conv/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Using Gather axis: 0
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Gather_23 for ONNX node: /Gather_23
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Gather_23_output_0 for ONNX tensor: /Gather_23_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Gather_23 [Gather] outputs: [/Gather_23_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Gather_24 [Gather]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Shape_34_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.2/Constant_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Gather_24 [Gather] inputs: [/Shape_34_output_0 -> (3)[INT32]], [/backbone_model/model.2/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Using Gather axis: 0
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Gather_24 for ONNX node: /Gather_24
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Gather_24_output_0 for ONNX tensor: /Gather_24_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Gather_24 [Gather] outputs: [/Gather_24_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Unsqueeze_15 [Unsqueeze]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Gather_22_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Unsqueeze_15 [Unsqueeze] inputs: [/Gather_22_output_0 -> ()[INT32]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Original shape: (), unsqueezing to: (1,)
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Unsqueeze_15 for ONNX node: /Unsqueeze_15
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Unsqueeze_15_output_0 for ONNX tensor: /Unsqueeze_15_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Unsqueeze_15 [Unsqueeze] outputs: [/Unsqueeze_15_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Unsqueeze_16 [Unsqueeze]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Gather_23_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Unsqueeze_16 [Unsqueeze] inputs: [/Gather_23_output_0 -> ()[INT32]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Original shape: (), unsqueezing to: (1,)
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Unsqueeze_16 for ONNX node: /Unsqueeze_16
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Unsqueeze_16_output_0 for ONNX tensor: /Unsqueeze_16_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Unsqueeze_16 [Unsqueeze] outputs: [/Unsqueeze_16_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Unsqueeze_17 [Unsqueeze]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Gather_24_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Unsqueeze_17 [Unsqueeze] inputs: [/Gather_24_output_0 -> ()[INT32]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Original shape: (), unsqueezing to: (1,)
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Unsqueeze_17 for ONNX node: /Unsqueeze_17
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Unsqueeze_17_output_0 for ONNX tensor: /Unsqueeze_17_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Unsqueeze_17 [Unsqueeze] outputs: [/Unsqueeze_17_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Concat_10 [Concat]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Unsqueeze_15_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Unsqueeze_16_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Unsqueeze_17_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Concat_10 [Concat] inputs: [/Unsqueeze_15_output_0 -> (1)[INT32]], [/Unsqueeze_16_output_0 -> (1)[INT32]], [/Unsqueeze_17_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Concat_10 for ONNX node: /Concat_10
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Concat_10_output_0 for ONNX tensor: /Concat_10_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Concat_10 [Concat] outputs: [/Concat_10_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /ConstantOfShape_13 [ConstantOfShape]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Concat_10_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /ConstantOfShape_13 [ConstantOfShape] inputs: [/Concat_10_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /ConstantOfShape_13_output_0 for ONNX tensor: /ConstantOfShape_13_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /ConstantOfShape_13 [ConstantOfShape] outputs: [/ConstantOfShape_13_output_0 -> (-1, 15120, 80)[FLOAT]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Shape_37 [Shape]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /ArgMax_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Shape_37 [Shape] inputs: [/ArgMax_output_0 -> (-1, 15120, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Shape_37 for ONNX node: /Shape_37
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Shape_37_output_0 for ONNX tensor: /Shape_37_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Shape_37 [Shape] outputs: [/Shape_37_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Expand_16 [Expand]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Constant_95_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Shape_37_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Expand_16 [Expand] inputs: [/Constant_95_output_0 -> ()[HALF]], [/Shape_37_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Constant_95_output_0 for ONNX node: /Constant_95_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Expand_16 for ONNX node: /Expand_16
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Expand_16_output_0 for ONNX tensor: /Expand_16_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Expand_16 [Expand] outputs: [/Expand_16_output_0 -> (-1, 15120, 1)[FLOAT]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /ScatterElements [ScatterElements]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /ConstantOfShape_13_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /ArgMax_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Expand_16_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /ScatterElements [ScatterElements] inputs: [/ConstantOfShape_13_output_0 -> (-1, 15120, 80)[FLOAT]], [/ArgMax_output_0 -> (-1, 15120, 1)[INT32]], [/Expand_16_output_0 -> (-1, 15120, 1)[FLOAT]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /ScatterElements for ONNX node: /ScatterElements
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /ScatterElements_output_0 for ONNX tensor: /ScatterElements_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /ScatterElements [ScatterElements] outputs: [/ScatterElements_output_0 -> (-1, 15120, 80)[FLOAT]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Mul_12 [Mul]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Slice_1_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /ScatterElements_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Mul_12 [Mul] inputs: [/Slice_1_output_0 -> (-1, 15120, 80)[FLOAT]], [/ScatterElements_output_0 -> (-1, 15120, 80)[FLOAT]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Mul_12 for ONNX node: /Mul_12
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Mul_12_output_0 for ONNX tensor: /Mul_12_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Mul_12 [Mul] outputs: [/Mul_12_output_0 -> (-1, 15120, 80)[FLOAT]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /EfficientNMS_TRT [EfficientNMS_TRT]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /ScatterND_3_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Mul_12_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /EfficientNMS_TRT [EfficientNMS_TRT] inputs: [/ScatterND_3_output_0 -> (-1, 15120, 4)[FLOAT]], [/Mul_12_output_0 -> (-1, 15120, 80)[FLOAT]],
[TH_YF8S][26-01-14 11:43:45][TRT] No importer registered for op: EfficientNMS_TRT. Attempting to import as plugin.
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for plugin: EfficientNMS_TRT, plugin_version: 1, plugin_namespace:
[TH_YF8S][26-01-14 11:43:45][TRT] Local registry did not find EfficientNMS_TRT creator. Will try parent registry if enabled.
[TH_YF8S][26-01-14 11:43:45][TRT] Global registry found EfficientNMS_TRT creator.
[TH_YF8S][26-01-14 11:43:45][TRT] Successfully created plugin: EfficientNMS_TRT
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /EfficientNMS_TRT for ONNX node: /EfficientNMS_TRT
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /EfficientNMS_TRT_output_0 for ONNX tensor: /EfficientNMS_TRT_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /EfficientNMS_TRT_output_1 for ONNX tensor: /EfficientNMS_TRT_output_1
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /EfficientNMS_TRT_output_2 for ONNX tensor: /EfficientNMS_TRT_output_2
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /EfficientNMS_TRT_output_3 for ONNX tensor: /EfficientNMS_TRT_output_3
[TH_YF8S][26-01-14 11:43:45][TRT] /EfficientNMS_TRT [EfficientNMS_TRT] outputs: [/EfficientNMS_TRT_output_0 -> (-1, 1)[INT32]], [/EfficientNMS_TRT_output_1 -> (-1, 300, 4)[FLOAT]], [/EfficientNMS_TRT_output_2 -> (-1, 300)[FLOAT]], [/EfficientNMS_TRT_output_3 -> (-1, 300)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Reshape_13 [Reshape]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /EfficientNMS_TRT_output_2
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: _v_681
[TH_YF8S][26-01-14 11:43:45][TRT] /Reshape_13 [Reshape] inputs: [/EfficientNMS_TRT_output_2 -> (-1, 300)[FLOAT]], [_v_681 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Reshape_13 for ONNX node: /Reshape_13
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Reshape_13_output_0 for ONNX tensor: /Reshape_13_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Reshape_13 [Reshape] outputs: [/Reshape_13_output_0 -> (-1, 300, 1)[FLOAT]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Reshape_14 [Reshape]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /EfficientNMS_TRT_output_3
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: _v_681
[TH_YF8S][26-01-14 11:43:45][TRT] /Reshape_14 [Reshape] inputs: [/EfficientNMS_TRT_output_3 -> (-1, 300)[INT32]], [_v_681 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Reshape_14 for ONNX node: /Reshape_14
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Reshape_14_output_0 for ONNX tensor: /Reshape_14_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Reshape_14 [Reshape] outputs: [/Reshape_14_output_0 -> (-1, 300, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Shape_38 [Shape]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /EfficientNMS_TRT_output_1
[TH_YF8S][26-01-14 11:43:45][TRT] /Shape_38 [Shape] inputs: [/EfficientNMS_TRT_output_1 -> (-1, 300, 4)[FLOAT]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Shape_38 for ONNX node: /Shape_38
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Shape_38_output_0 for ONNX tensor: /Shape_38_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Shape_38 [Shape] outputs: [/Shape_38_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Gather_25 [Gather]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Shape_38_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.0/conv/Constant_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Gather_25 [Gather] inputs: [/Shape_38_output_0 -> (3)[INT32]], [/backbone_model/model.0/conv/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Using Gather axis: 0
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Gather_25 for ONNX node: /Gather_25
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Gather_25_output_0 for ONNX tensor: /Gather_25_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Gather_25 [Gather] outputs: [/Gather_25_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Unsqueeze_22 [Unsqueeze]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Gather_25_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Unsqueeze_22 [Unsqueeze] inputs: [/Gather_25_output_0 -> ()[INT32]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Original shape: (), unsqueezing to: (1,)
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Unsqueeze_22 for ONNX node: /Unsqueeze_22
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Unsqueeze_22_output_0 for ONNX tensor: /Unsqueeze_22_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Unsqueeze_22 [Unsqueeze] outputs: [/Unsqueeze_22_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Slice_6 [Slice]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /ConstantOfShape_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Unsqueeze_22_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Slice_6 [Slice] inputs: [/ConstantOfShape_output_0 -> (-1, 300, 6)[FLOAT]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]], [/Unsqueeze_22_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Slice_6 for ONNX node: /Slice_6
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Slice_6_output_0 for ONNX tensor: /Slice_6_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Slice_6 [Slice] outputs: [/Slice_6_output_0 -> (-1, 300, 6)[FLOAT]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Slice_7 [Slice]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Slice_6_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.22/dfl/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.2/Constant_4_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Slice_7 [Slice] inputs: [/Slice_6_output_0 -> (-1, 300, 6)[FLOAT]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]], [/backbone_model/model.22/dfl/Constant_2_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_4_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Slice_7 for ONNX node: /Slice_7
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Slice_7_output_0 for ONNX tensor: /Slice_7_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Slice_7 [Slice] outputs: [/Slice_7_output_0 -> (-1, 300, 4)[FLOAT]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Shape_39 [Shape]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Slice_7_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Shape_39 [Shape] inputs: [/Slice_7_output_0 -> (-1, 300, 4)[FLOAT]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Shape_39 for ONNX node: /Shape_39
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Shape_39_output_0 for ONNX tensor: /Shape_39_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Shape_39 [Shape] outputs: [/Shape_39_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Expand_17 [Expand]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /EfficientNMS_TRT_output_1
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Shape_39_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Expand_17 [Expand] inputs: [/EfficientNMS_TRT_output_1 -> (-1, 300, 4)[FLOAT]], [/Shape_39_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Expand_17 for ONNX node: /Expand_17
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Expand_17_output_0 for ONNX tensor: /Expand_17_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Expand_17 [Expand] outputs: [/Expand_17_output_0 -> (-1, 300, 4)[FLOAT]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Shape_40 [Shape]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /ConstantOfShape_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Shape_40 [Shape] inputs: [/ConstantOfShape_output_0 -> (-1, 300, 6)[FLOAT]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Shape_40 for ONNX node: /Shape_40
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Shape_40_output_0 for ONNX tensor: /Shape_40_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Shape_40 [Shape] outputs: [/Shape_40_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Gather_26 [Gather]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Shape_40_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.22/Constant_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Gather_26 [Gather] inputs: [/Shape_40_output_0 -> (3)[INT32]], [/backbone_model/model.22/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Using Gather axis: 0
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Gather_26 for ONNX node: /Gather_26
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Gather_26_output_0 for ONNX tensor: /Gather_26_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Gather_26 [Gather] outputs: [/Gather_26_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Cast_8 [Cast]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Gather_26_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Cast_8 [Cast] inputs: [/Gather_26_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Casting to type: int32
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Cast_8 for ONNX node: /Cast_8
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Cast_8_output_0 for ONNX tensor: /Cast_8_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Cast_8 [Cast] outputs: [/Cast_8_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Range_8 [Range]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.22/Constant_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Cast_8_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.0/conv/Constant_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Range_8 [Range] inputs: [/backbone_model/model.22/Constant_output_0 -> ()[INT32]], [/Cast_8_output_0 -> ()[INT32]], [/backbone_model/model.0/conv/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Range_8 for ONNX node: /Range_8
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Range_8_output_0 for ONNX tensor: /Range_8_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Range_8 [Range] outputs: [/Range_8_output_0 -> (-1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Gather_27 [Gather]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Shape_40_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.0/conv/Constant_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Gather_27 [Gather] inputs: [/Shape_40_output_0 -> (3)[INT32]], [/backbone_model/model.0/conv/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Using Gather axis: 0
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Gather_27 for ONNX node: /Gather_27
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Gather_27_output_0 for ONNX tensor: /Gather_27_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Gather_27 [Gather] outputs: [/Gather_27_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Cast_9 [Cast]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Gather_27_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Cast_9 [Cast] inputs: [/Gather_27_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Casting to type: int32
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Cast_9 for ONNX node: /Cast_9
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Cast_9_output_0 for ONNX tensor: /Cast_9_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Cast_9 [Cast] outputs: [/Cast_9_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Range_9 [Range]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.22/Constant_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Cast_9_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.0/conv/Constant_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Range_9 [Range] inputs: [/backbone_model/model.22/Constant_output_0 -> ()[INT32]], [/Cast_9_output_0 -> ()[INT32]], [/backbone_model/model.0/conv/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Range_9 for ONNX node: /Range_9
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Range_9_output_0 for ONNX tensor: /Range_9_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Range_9 [Range] outputs: [/Range_9_output_0 -> (300)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Slice_8 [Slice]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Range_9_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Unsqueeze_22_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Slice_8 [Slice] inputs: [/Range_9_output_0 -> (300)[INT32]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]], [/Unsqueeze_22_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Slice_8 for ONNX node: /Slice_8
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Slice_8_output_0 for ONNX tensor: /Slice_8_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Slice_8 [Slice] outputs: [/Slice_8_output_0 -> (300)[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Gather_28 [Gather]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Shape_40_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.2/Constant_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Gather_28 [Gather] inputs: [/Shape_40_output_0 -> (3)[INT32]], [/backbone_model/model.2/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Using Gather axis: 0
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Gather_28 for ONNX node: /Gather_28
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Gather_28_output_0 for ONNX tensor: /Gather_28_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Gather_28 [Gather] outputs: [/Gather_28_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Cast_10 [Cast]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Gather_28_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Cast_10 [Cast] inputs: [/Gather_28_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Casting to type: int32
[TH_YF8S][26-01-14 11:43:45][TRT] Registering layer: /Cast_10 for ONNX node: /Cast_10
[TH_YF8S][26-01-14 11:43:45][TRT] Registering tensor: /Cast_10_output_0 for ONNX tensor: /Cast_10_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Cast_10 [Cast] outputs: [/Cast_10_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:45][TRT] Parsing node: /Range_10 [Range]
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.22/Constant_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /Cast_10_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] Searching for input: /backbone_model/model.0/conv/Constant_output_0
[TH_YF8S][26-01-14 11:43:45][TRT] /Range_10 [Range] inputs: [/backbone_model/model.22/Constant_output_0 -> ()[INT32]], [/Cast_10_output_0 -> ()[INT32]], [/backbone_model/model.0/conv/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Range_10 for ONNX node: /Range_10
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Range_10_output_0 for ONNX tensor: /Range_10_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Range_10 [Range] outputs: [/Range_10_output_0 -> (6)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Slice_9 [Slice]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Range_10_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.22/dfl/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Slice_9 [Slice] inputs: [/Range_10_output_0 -> (6)[INT32]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]], [/backbone_model/model.22/dfl/Constant_2_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Slice_9 for ONNX node: /Slice_9
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Slice_9_output_0 for ONNX tensor: /Slice_9_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Slice_9 [Slice] outputs: [/Slice_9_output_0 -> (4)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Reshape_16 [Reshape]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Range_8_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Constant_19_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Reshape_16 [Reshape] inputs: [/Range_8_output_0 -> (-1)[INT32]], [/Constant_19_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Reshape_16 for ONNX node: /Reshape_16
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Reshape_16_output_0 for ONNX tensor: /Reshape_16_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Reshape_16 [Reshape] outputs: [/Reshape_16_output_0 -> (-1, 1, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Reshape_17 [Reshape]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Slice_8_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Constant_20_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Reshape_17 [Reshape] inputs: [/Slice_8_output_0 -> (300)[INT32]], [/Constant_20_output_0 -> (2)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Reshape_17 for ONNX node: /Reshape_17
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Reshape_17_output_0 for ONNX tensor: /Reshape_17_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Reshape_17 [Reshape] outputs: [/Reshape_17_output_0 -> (300, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Add_11 [Add]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Reshape_16_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Reshape_17_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Add_11 [Add] inputs: [/Reshape_16_output_0 -> (-1, 1, 1)[INT32]], [/Reshape_17_output_0 -> (300, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Add_11 for ONNX node: /Add_11
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Add_11_output_0 for ONNX tensor: /Add_11_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Add_11 [Add] outputs: [/Add_11_output_0 -> (-1, 300, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Add_12 [Add]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Add_11_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Slice_9_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Add_12 [Add] inputs: [/Add_11_output_0 -> (-1, 300, 1)[INT32]], [/Slice_9_output_0 -> (4)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Add_12 for ONNX node: /Add_12
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Add_12_output_0 for ONNX tensor: /Add_12_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Add_12 [Add] outputs: [/Add_12_output_0 -> (-1, 300, 4)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Shape_43 [Shape]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Add_12_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Shape_43 [Shape] inputs: [/Add_12_output_0 -> (-1, 300, 4)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Shape_43 for ONNX node: /Shape_43
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Shape_43_output_0 for ONNX tensor: /Shape_43_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Shape_43 [Shape] outputs: [/Shape_43_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Shape_44 [Shape]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Shape_43_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Shape_44 [Shape] inputs: [/Shape_43_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Shape_44 for ONNX node: /Shape_44
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Shape_44_output_0 for ONNX tensor: /Shape_44_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Shape_44 [Shape] outputs: [/Shape_44_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /ConstantOfShape_14 [ConstantOfShape]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Shape_44_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /ConstantOfShape_14 [ConstantOfShape] inputs: [/Shape_44_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /ConstantOfShape_14_output_0 for ONNX tensor: /ConstantOfShape_14_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /ConstantOfShape_14 [ConstantOfShape] outputs: [/ConstantOfShape_14_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Mul_13 [Mul]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /ConstantOfShape_14_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Constant_22_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Mul_13 [Mul] inputs: [/ConstantOfShape_14_output_0 -> (3)[INT32]], [/Constant_22_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Constant_22_output_0 for ONNX node: /Constant_22_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Mul_13 for ONNX node: /Mul_13
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Mul_13_output_0 for ONNX tensor: /Mul_13_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Mul_13 [Mul] outputs: [/Mul_13_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Equal_12 [Equal]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Shape_43_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Mul_13_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Equal_12 [Equal] inputs: [/Shape_43_output_0 -> (3)[INT32]], [/Mul_13_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Equal_12 for ONNX node: /Equal_12
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Equal_12_output_0 for ONNX tensor: /Equal_12_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Equal_12 [Equal] outputs: [/Equal_12_output_0 -> (3)[BOOL]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Where_12 [Where]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Equal_12_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /ConstantOfShape_14_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Shape_43_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Where_12 [Where] inputs: [/Equal_12_output_0 -> (3)[BOOL]], [/ConstantOfShape_14_output_0 -> (3)[INT32]], [/Shape_43_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Where_12 for ONNX node: /Where_12
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Where_12_output_0 for ONNX tensor: /Where_12_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Where_12 [Where] outputs: [/Where_12_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Expand_18 [Expand]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Reshape_16_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Where_12_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Expand_18 [Expand] inputs: [/Reshape_16_output_0 -> (-1, 1, 1)[INT32]], [/Where_12_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Expand_18 for ONNX node: /Expand_18
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Expand_18_output_0 for ONNX tensor: /Expand_18_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Expand_18 [Expand] outputs: [/Expand_18_output_0 -> (-1, 300, 4)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Unsqueeze_24 [Unsqueeze]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Expand_18_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.22/Constant_3_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Unsqueeze_24 [Unsqueeze] inputs: [/Expand_18_output_0 -> (-1, 300, 4)[INT32]], [/backbone_model/model.22/Constant_3_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Original shape: (_, 300, 4), unsqueezing to: (_, _, _, _)
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Unsqueeze_24 for ONNX node: /Unsqueeze_24
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Unsqueeze_24_output_0 for ONNX tensor: /Unsqueeze_24_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Unsqueeze_24 [Unsqueeze] outputs: [/Unsqueeze_24_output_0 -> (-1, 300, 4, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Expand_19 [Expand]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Reshape_17_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Where_12_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Expand_19 [Expand] inputs: [/Reshape_17_output_0 -> (300, 1)[INT32]], [/Where_12_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Expand_19 for ONNX node: /Expand_19
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Expand_19_output_0 for ONNX tensor: /Expand_19_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Expand_19 [Expand] outputs: [/Expand_19_output_0 -> (-1, 300, 4)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Unsqueeze_25 [Unsqueeze]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Expand_19_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.22/Constant_3_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Unsqueeze_25 [Unsqueeze] inputs: [/Expand_19_output_0 -> (-1, 300, 4)[INT32]], [/backbone_model/model.22/Constant_3_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Original shape: (_, 300, 4), unsqueezing to: (_, _, _, _)
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Unsqueeze_25 for ONNX node: /Unsqueeze_25
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Unsqueeze_25_output_0 for ONNX tensor: /Unsqueeze_25_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Unsqueeze_25 [Unsqueeze] outputs: [/Unsqueeze_25_output_0 -> (-1, 300, 4, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Expand_20 [Expand]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Slice_9_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Where_12_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Expand_20 [Expand] inputs: [/Slice_9_output_0 -> (4)[INT32]], [/Where_12_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Expand_20 for ONNX node: /Expand_20
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Expand_20_output_0 for ONNX tensor: /Expand_20_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Expand_20 [Expand] outputs: [/Expand_20_output_0 -> (-1, 300, 4)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Unsqueeze_26 [Unsqueeze]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Expand_20_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.22/Constant_3_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Unsqueeze_26 [Unsqueeze] inputs: [/Expand_20_output_0 -> (-1, 300, 4)[INT32]], [/backbone_model/model.22/Constant_3_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Original shape: (_, 300, 4), unsqueezing to: (_, _, _, _)
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Unsqueeze_26 for ONNX node: /Unsqueeze_26
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Unsqueeze_26_output_0 for ONNX tensor: /Unsqueeze_26_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Unsqueeze_26 [Unsqueeze] outputs: [/Unsqueeze_26_output_0 -> (-1, 300, 4, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Concat_15 [Concat]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Unsqueeze_24_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Unsqueeze_25_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Unsqueeze_26_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Concat_15 [Concat] inputs: [/Unsqueeze_24_output_0 -> (-1, 300, 4, 1)[INT32]], [/Unsqueeze_25_output_0 -> (-1, 300, 4, 1)[INT32]], [/Unsqueeze_26_output_0 -> (-1, 300, 4, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Concat_15 for ONNX node: /Concat_15
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Concat_15_output_0 for ONNX tensor: /Concat_15_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Concat_15 [Concat] outputs: [/Concat_15_output_0 -> (-1, 300, 4, 3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Reshape_18 [Reshape]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Expand_17_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Shape_43_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Reshape_18 [Reshape] inputs: [/Expand_17_output_0 -> (-1, 300, 4)[FLOAT]], [/Shape_43_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Reshape_18 for ONNX node: /Reshape_18
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Reshape_18_output_0 for ONNX tensor: /Reshape_18_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Reshape_18 [Reshape] outputs: [/Reshape_18_output_0 -> (-1, 300, 4)[FLOAT]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /ScatterND_4 [ScatterND]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /ConstantOfShape_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Concat_15_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Reshape_18_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /ScatterND_4 [ScatterND] inputs: [/ConstantOfShape_output_0 -> (-1, 300, 6)[FLOAT]], [/Concat_15_output_0 -> (-1, 300, 4, 3)[INT32]], [/Reshape_18_output_0 -> (-1, 300, 4)[FLOAT]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /ScatterND_4 for ONNX node: /ScatterND_4
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /ScatterND_4_output_0 for ONNX tensor: /ScatterND_4_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /ScatterND_4 [ScatterND] outputs: [/ScatterND_4_output_0 -> (-1, 300, 6)[FLOAT]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Shape_48 [Shape]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Reshape_13_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Shape_48 [Shape] inputs: [/Reshape_13_output_0 -> (-1, 300, 1)[FLOAT]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Shape_48 for ONNX node: /Shape_48
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Shape_48_output_0 for ONNX tensor: /Shape_48_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Shape_48 [Shape] outputs: [/Shape_48_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Gather_29 [Gather]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Shape_48_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.0/conv/Constant_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Gather_29 [Gather] inputs: [/Shape_48_output_0 -> (3)[INT32]], [/backbone_model/model.0/conv/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Using Gather axis: 0
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Gather_29 for ONNX node: /Gather_29
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Gather_29_output_0 for ONNX tensor: /Gather_29_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Gather_29 [Gather] outputs: [/Gather_29_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Unsqueeze_27 [Unsqueeze]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Gather_29_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Unsqueeze_27 [Unsqueeze] inputs: [/Gather_29_output_0 -> ()[INT32]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Original shape: (), unsqueezing to: (1,)
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Unsqueeze_27 for ONNX node: /Unsqueeze_27
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Unsqueeze_27_output_0 for ONNX tensor: /Unsqueeze_27_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Unsqueeze_27 [Unsqueeze] outputs: [/Unsqueeze_27_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Slice_11 [Slice]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /ScatterND_4_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Unsqueeze_27_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Slice_11 [Slice] inputs: [/ScatterND_4_output_0 -> (-1, 300, 6)[FLOAT]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]], [/Unsqueeze_27_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Slice_11 for ONNX node: /Slice_11
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Slice_11_output_0 for ONNX tensor: /Slice_11_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Slice_11 [Slice] outputs: [/Slice_11_output_0 -> (-1, 300, 6)[FLOAT]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Slice_12 [Slice]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Slice_11_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.22/dfl/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Constant_147_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.2/Constant_4_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Slice_12 [Slice] inputs: [/Slice_11_output_0 -> (-1, 300, 6)[FLOAT]], [/backbone_model/model.22/dfl/Constant_2_output_0 -> (1)[INT32]], [/Constant_147_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_4_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Slice_12 for ONNX node: /Slice_12
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Slice_12_output_0 for ONNX tensor: /Slice_12_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Slice_12 [Slice] outputs: [/Slice_12_output_0 -> (-1, 300, 1)[FLOAT]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Shape_49 [Shape]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Slice_12_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Shape_49 [Shape] inputs: [/Slice_12_output_0 -> (-1, 300, 1)[FLOAT]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Shape_49 for ONNX node: /Shape_49
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Shape_49_output_0 for ONNX tensor: /Shape_49_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Shape_49 [Shape] outputs: [/Shape_49_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Expand_21 [Expand]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Reshape_13_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Shape_49_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Expand_21 [Expand] inputs: [/Reshape_13_output_0 -> (-1, 300, 1)[FLOAT]], [/Shape_49_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Expand_21 for ONNX node: /Expand_21
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Expand_21_output_0 for ONNX tensor: /Expand_21_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Expand_21 [Expand] outputs: [/Expand_21_output_0 -> (-1, 300, 1)[FLOAT]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Shape_50 [Shape]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /ScatterND_4_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Shape_50 [Shape] inputs: [/ScatterND_4_output_0 -> (-1, 300, 6)[FLOAT]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Shape_50 for ONNX node: /Shape_50
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Shape_50_output_0 for ONNX tensor: /Shape_50_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Shape_50 [Shape] outputs: [/Shape_50_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Gather_30 [Gather]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Shape_50_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.22/Constant_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Gather_30 [Gather] inputs: [/Shape_50_output_0 -> (3)[INT32]], [/backbone_model/model.22/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Using Gather axis: 0
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Gather_30 for ONNX node: /Gather_30
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Gather_30_output_0 for ONNX tensor: /Gather_30_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Gather_30 [Gather] outputs: [/Gather_30_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Cast_11 [Cast]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Gather_30_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Cast_11 [Cast] inputs: [/Gather_30_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Casting to type: int32
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Cast_11 for ONNX node: /Cast_11
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Cast_11_output_0 for ONNX tensor: /Cast_11_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Cast_11 [Cast] outputs: [/Cast_11_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Range_11 [Range]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.22/Constant_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Cast_11_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.0/conv/Constant_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Range_11 [Range] inputs: [/backbone_model/model.22/Constant_output_0 -> ()[INT32]], [/Cast_11_output_0 -> ()[INT32]], [/backbone_model/model.0/conv/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Range_11 for ONNX node: /Range_11
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Range_11_output_0 for ONNX tensor: /Range_11_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Range_11 [Range] outputs: [/Range_11_output_0 -> (-1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Gather_31 [Gather]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Shape_50_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.0/conv/Constant_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Gather_31 [Gather] inputs: [/Shape_50_output_0 -> (3)[INT32]], [/backbone_model/model.0/conv/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Using Gather axis: 0
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Gather_31 for ONNX node: /Gather_31
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Gather_31_output_0 for ONNX tensor: /Gather_31_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Gather_31 [Gather] outputs: [/Gather_31_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Cast_12 [Cast]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Gather_31_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Cast_12 [Cast] inputs: [/Gather_31_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Casting to type: int32
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Cast_12 for ONNX node: /Cast_12
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Cast_12_output_0 for ONNX tensor: /Cast_12_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Cast_12 [Cast] outputs: [/Cast_12_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Range_12 [Range]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.22/Constant_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Cast_12_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.0/conv/Constant_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Range_12 [Range] inputs: [/backbone_model/model.22/Constant_output_0 -> ()[INT32]], [/Cast_12_output_0 -> ()[INT32]], [/backbone_model/model.0/conv/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Range_12 for ONNX node: /Range_12
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Range_12_output_0 for ONNX tensor: /Range_12_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Range_12 [Range] outputs: [/Range_12_output_0 -> (300)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Slice_13 [Slice]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Range_12_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Unsqueeze_27_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Slice_13 [Slice] inputs: [/Range_12_output_0 -> (300)[INT32]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]], [/Unsqueeze_27_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Slice_13 for ONNX node: /Slice_13
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Slice_13_output_0 for ONNX tensor: /Slice_13_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Slice_13 [Slice] outputs: [/Slice_13_output_0 -> (300)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Gather_32 [Gather]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Shape_50_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.2/Constant_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Gather_32 [Gather] inputs: [/Shape_50_output_0 -> (3)[INT32]], [/backbone_model/model.2/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Using Gather axis: 0
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Gather_32 for ONNX node: /Gather_32
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Gather_32_output_0 for ONNX tensor: /Gather_32_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Gather_32 [Gather] outputs: [/Gather_32_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Cast_13 [Cast]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Gather_32_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Cast_13 [Cast] inputs: [/Gather_32_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Casting to type: int32
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Cast_13 for ONNX node: /Cast_13
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Cast_13_output_0 for ONNX tensor: /Cast_13_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Cast_13 [Cast] outputs: [/Cast_13_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Range_13 [Range]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.22/Constant_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Cast_13_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.0/conv/Constant_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Range_13 [Range] inputs: [/backbone_model/model.22/Constant_output_0 -> ()[INT32]], [/Cast_13_output_0 -> ()[INT32]], [/backbone_model/model.0/conv/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Range_13 for ONNX node: /Range_13
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Range_13_output_0 for ONNX tensor: /Range_13_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Range_13 [Range] outputs: [/Range_13_output_0 -> (6)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Slice_14 [Slice]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Range_13_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.22/dfl/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Constant_147_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Slice_14 [Slice] inputs: [/Range_13_output_0 -> (6)[INT32]], [/backbone_model/model.22/dfl/Constant_2_output_0 -> (1)[INT32]], [/Constant_147_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Slice_14 for ONNX node: /Slice_14
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Slice_14_output_0 for ONNX tensor: /Slice_14_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Slice_14 [Slice] outputs: [/Slice_14_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Reshape_19 [Reshape]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Range_11_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Constant_19_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Reshape_19 [Reshape] inputs: [/Range_11_output_0 -> (-1)[INT32]], [/Constant_19_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Reshape_19 for ONNX node: /Reshape_19
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Reshape_19_output_0 for ONNX tensor: /Reshape_19_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Reshape_19 [Reshape] outputs: [/Reshape_19_output_0 -> (-1, 1, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Reshape_20 [Reshape]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Slice_13_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Constant_20_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Reshape_20 [Reshape] inputs: [/Slice_13_output_0 -> (300)[INT32]], [/Constant_20_output_0 -> (2)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Reshape_20 for ONNX node: /Reshape_20
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Reshape_20_output_0 for ONNX tensor: /Reshape_20_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Reshape_20 [Reshape] outputs: [/Reshape_20_output_0 -> (300, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Add_13 [Add]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Reshape_19_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Reshape_20_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Add_13 [Add] inputs: [/Reshape_19_output_0 -> (-1, 1, 1)[INT32]], [/Reshape_20_output_0 -> (300, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Add_13 for ONNX node: /Add_13
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Add_13_output_0 for ONNX tensor: /Add_13_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Add_13 [Add] outputs: [/Add_13_output_0 -> (-1, 300, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Add_14 [Add]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Add_13_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Slice_14_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Add_14 [Add] inputs: [/Add_13_output_0 -> (-1, 300, 1)[INT32]], [/Slice_14_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Add_14 for ONNX node: /Add_14
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Add_14_output_0 for ONNX tensor: /Add_14_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Add_14 [Add] outputs: [/Add_14_output_0 -> (-1, 300, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Shape_53 [Shape]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Add_14_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Shape_53 [Shape] inputs: [/Add_14_output_0 -> (-1, 300, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Shape_53 for ONNX node: /Shape_53
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Shape_53_output_0 for ONNX tensor: /Shape_53_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Shape_53 [Shape] outputs: [/Shape_53_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Shape_54 [Shape]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Shape_53_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Shape_54 [Shape] inputs: [/Shape_53_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Shape_54 for ONNX node: /Shape_54
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Shape_54_output_0 for ONNX tensor: /Shape_54_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Shape_54 [Shape] outputs: [/Shape_54_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /ConstantOfShape_17 [ConstantOfShape]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Shape_54_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /ConstantOfShape_17 [ConstantOfShape] inputs: [/Shape_54_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /ConstantOfShape_17_output_0 for ONNX tensor: /ConstantOfShape_17_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /ConstantOfShape_17 [ConstantOfShape] outputs: [/ConstantOfShape_17_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Mul_16 [Mul]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /ConstantOfShape_17_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Constant_22_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Mul_16 [Mul] inputs: [/ConstantOfShape_17_output_0 -> (3)[INT32]], [/Constant_22_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Mul_16 for ONNX node: /Mul_16
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Mul_16_output_0 for ONNX tensor: /Mul_16_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Mul_16 [Mul] outputs: [/Mul_16_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Equal_15 [Equal]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Shape_53_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Mul_16_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Equal_15 [Equal] inputs: [/Shape_53_output_0 -> (3)[INT32]], [/Mul_16_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Equal_15 for ONNX node: /Equal_15
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Equal_15_output_0 for ONNX tensor: /Equal_15_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Equal_15 [Equal] outputs: [/Equal_15_output_0 -> (3)[BOOL]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Where_15 [Where]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Equal_15_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /ConstantOfShape_17_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Shape_53_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Where_15 [Where] inputs: [/Equal_15_output_0 -> (3)[BOOL]], [/ConstantOfShape_17_output_0 -> (3)[INT32]], [/Shape_53_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Where_15 for ONNX node: /Where_15
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Where_15_output_0 for ONNX tensor: /Where_15_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Where_15 [Where] outputs: [/Where_15_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Expand_22 [Expand]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Reshape_19_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Where_15_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Expand_22 [Expand] inputs: [/Reshape_19_output_0 -> (-1, 1, 1)[INT32]], [/Where_15_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Expand_22 for ONNX node: /Expand_22
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Expand_22_output_0 for ONNX tensor: /Expand_22_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Expand_22 [Expand] outputs: [/Expand_22_output_0 -> (-1, 300, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Unsqueeze_29 [Unsqueeze]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Expand_22_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.22/Constant_3_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Unsqueeze_29 [Unsqueeze] inputs: [/Expand_22_output_0 -> (-1, 300, 1)[INT32]], [/backbone_model/model.22/Constant_3_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Original shape: (_, 300, 1), unsqueezing to: (_, _, _, _)
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Unsqueeze_29 for ONNX node: /Unsqueeze_29
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Unsqueeze_29_output_0 for ONNX tensor: /Unsqueeze_29_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Unsqueeze_29 [Unsqueeze] outputs: [/Unsqueeze_29_output_0 -> (-1, 300, 1, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Expand_23 [Expand]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Reshape_20_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Where_15_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Expand_23 [Expand] inputs: [/Reshape_20_output_0 -> (300, 1)[INT32]], [/Where_15_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Expand_23 for ONNX node: /Expand_23
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Expand_23_output_0 for ONNX tensor: /Expand_23_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Expand_23 [Expand] outputs: [/Expand_23_output_0 -> (-1, 300, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Unsqueeze_30 [Unsqueeze]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Expand_23_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.22/Constant_3_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Unsqueeze_30 [Unsqueeze] inputs: [/Expand_23_output_0 -> (-1, 300, 1)[INT32]], [/backbone_model/model.22/Constant_3_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Original shape: (_, 300, 1), unsqueezing to: (_, _, _, _)
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Unsqueeze_30 for ONNX node: /Unsqueeze_30
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Unsqueeze_30_output_0 for ONNX tensor: /Unsqueeze_30_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Unsqueeze_30 [Unsqueeze] outputs: [/Unsqueeze_30_output_0 -> (-1, 300, 1, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Expand_24 [Expand]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Slice_14_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Where_15_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Expand_24 [Expand] inputs: [/Slice_14_output_0 -> (1)[INT32]], [/Where_15_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Expand_24 for ONNX node: /Expand_24
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Expand_24_output_0 for ONNX tensor: /Expand_24_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Expand_24 [Expand] outputs: [/Expand_24_output_0 -> (-1, 300, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Unsqueeze_31 [Unsqueeze]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Expand_24_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.22/Constant_3_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Unsqueeze_31 [Unsqueeze] inputs: [/Expand_24_output_0 -> (-1, 300, 1)[INT32]], [/backbone_model/model.22/Constant_3_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Original shape: (_, 300, 1), unsqueezing to: (_, _, _, _)
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Unsqueeze_31 for ONNX node: /Unsqueeze_31
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Unsqueeze_31_output_0 for ONNX tensor: /Unsqueeze_31_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Unsqueeze_31 [Unsqueeze] outputs: [/Unsqueeze_31_output_0 -> (-1, 300, 1, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Concat_17 [Concat]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Unsqueeze_29_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Unsqueeze_30_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Unsqueeze_31_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Concat_17 [Concat] inputs: [/Unsqueeze_29_output_0 -> (-1, 300, 1, 1)[INT32]], [/Unsqueeze_30_output_0 -> (-1, 300, 1, 1)[INT32]], [/Unsqueeze_31_output_0 -> (-1, 300, 1, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Concat_17 for ONNX node: /Concat_17
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Concat_17_output_0 for ONNX tensor: /Concat_17_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Concat_17 [Concat] outputs: [/Concat_17_output_0 -> (-1, 300, 1, 3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Slice_15 [Slice]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Shape_50_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Constant_79_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Constant_176_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Slice_15 [Slice] inputs: [/Shape_50_output_0 -> (3)[INT32]], [/Constant_79_output_0 -> (1)[INT32]], [/Constant_176_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Slice_15 for ONNX node: /Slice_15
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Slice_15_output_0 for ONNX tensor: /Slice_15_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Slice_15 [Slice] outputs: [/Slice_15_output_0 -> (0)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Concat_18 [Concat]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Shape_53_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Slice_15_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Concat_18 [Concat] inputs: [/Shape_53_output_0 -> (3)[INT32]], [/Slice_15_output_0 -> (0)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Concat_18 for ONNX node: /Concat_18
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Concat_18_output_0 for ONNX tensor: /Concat_18_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Concat_18 [Concat] outputs: [/Concat_18_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Reshape_21 [Reshape]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Expand_21_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Concat_18_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Reshape_21 [Reshape] inputs: [/Expand_21_output_0 -> (-1, 300, 1)[FLOAT]], [/Concat_18_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Reshape_21 for ONNX node: /Reshape_21
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Reshape_21_output_0 for ONNX tensor: /Reshape_21_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Reshape_21 [Reshape] outputs: [/Reshape_21_output_0 -> (-1, 300, 1)[FLOAT]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /ScatterND_5 [ScatterND]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /ScatterND_4_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Concat_17_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Reshape_21_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /ScatterND_5 [ScatterND] inputs: [/ScatterND_4_output_0 -> (-1, 300, 6)[FLOAT]], [/Concat_17_output_0 -> (-1, 300, 1, 3)[INT32]], [/Reshape_21_output_0 -> (-1, 300, 1)[FLOAT]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /ScatterND_5 for ONNX node: /ScatterND_5
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /ScatterND_5_output_0 for ONNX tensor: /ScatterND_5_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /ScatterND_5 [ScatterND] outputs: [/ScatterND_5_output_0 -> (-1, 300, 6)[FLOAT]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Slice_16 [Slice]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /ScatterND_5_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Unsqueeze_27_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Slice_16 [Slice] inputs: [/ScatterND_5_output_0 -> (-1, 300, 6)[FLOAT]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]], [/Unsqueeze_27_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Slice_16 for ONNX node: /Slice_16
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Slice_16_output_0 for ONNX tensor: /Slice_16_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Slice_16 [Slice] outputs: [/Slice_16_output_0 -> (-1, 300, 6)[FLOAT]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Slice_17 [Slice]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Slice_16_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Constant_147_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Constant_4_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.2/Constant_4_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Slice_17 [Slice] inputs: [/Slice_16_output_0 -> (-1, 300, 6)[FLOAT]], [/Constant_147_output_0 -> (1)[INT32]], [/Constant_4_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_4_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Slice_17 for ONNX node: /Slice_17
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Slice_17_output_0 for ONNX tensor: /Slice_17_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Slice_17 [Slice] outputs: [/Slice_17_output_0 -> (-1, 300, 1)[FLOAT]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Shape_59 [Shape]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Slice_17_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Shape_59 [Shape] inputs: [/Slice_17_output_0 -> (-1, 300, 1)[FLOAT]],
[TH_YF8S][26-01-14 11:43:46][TRT] Registering layer: /Shape_59 for ONNX node: /Shape_59
[TH_YF8S][26-01-14 11:43:46][TRT] Registering tensor: /Shape_59_output_0 for ONNX tensor: /Shape_59_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] /Shape_59 [Shape] outputs: [/Shape_59_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:46][TRT] Parsing node: /Expand_25 [Expand]
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Reshape_14_output_0
[TH_YF8S][26-01-14 11:43:46][TRT] Searching for input: /Shape_59_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Expand_25 [Expand] inputs: [/Reshape_14_output_0 -> (-1, 300, 1)[INT32]], [/Shape_59_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Expand_25 for ONNX node: /Expand_25
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Expand_25_output_0 for ONNX tensor: /Expand_25_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Expand_25 [Expand] outputs: [/Expand_25_output_0 -> (-1, 300, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Shape_60 [Shape]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /ScatterND_5_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Shape_60 [Shape] inputs: [/ScatterND_5_output_0 -> (-1, 300, 6)[FLOAT]],
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Shape_60 for ONNX node: /Shape_60
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Shape_60_output_0 for ONNX tensor: /Shape_60_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Shape_60 [Shape] outputs: [/Shape_60_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Gather_34 [Gather]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Shape_60_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /backbone_model/model.22/Constant_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Gather_34 [Gather] inputs: [/Shape_60_output_0 -> (3)[INT32]], [/backbone_model/model.22/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Using Gather axis: 0
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Gather_34 for ONNX node: /Gather_34
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Gather_34_output_0 for ONNX tensor: /Gather_34_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Gather_34 [Gather] outputs: [/Gather_34_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Cast_14 [Cast]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Gather_34_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Cast_14 [Cast] inputs: [/Gather_34_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Casting to type: int32
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Cast_14 for ONNX node: /Cast_14
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Cast_14_output_0 for ONNX tensor: /Cast_14_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Cast_14 [Cast] outputs: [/Cast_14_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Range_14 [Range]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /backbone_model/model.22/Constant_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Cast_14_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /backbone_model/model.0/conv/Constant_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Range_14 [Range] inputs: [/backbone_model/model.22/Constant_output_0 -> ()[INT32]], [/Cast_14_output_0 -> ()[INT32]], [/backbone_model/model.0/conv/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Range_14 for ONNX node: /Range_14
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Range_14_output_0 for ONNX tensor: /Range_14_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Range_14 [Range] outputs: [/Range_14_output_0 -> (-1)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Gather_35 [Gather]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Shape_60_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /backbone_model/model.0/conv/Constant_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Gather_35 [Gather] inputs: [/Shape_60_output_0 -> (3)[INT32]], [/backbone_model/model.0/conv/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Using Gather axis: 0
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Gather_35 for ONNX node: /Gather_35
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Gather_35_output_0 for ONNX tensor: /Gather_35_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Gather_35 [Gather] outputs: [/Gather_35_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Cast_15 [Cast]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Gather_35_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Cast_15 [Cast] inputs: [/Gather_35_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Casting to type: int32
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Cast_15 for ONNX node: /Cast_15
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Cast_15_output_0 for ONNX tensor: /Cast_15_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Cast_15 [Cast] outputs: [/Cast_15_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Range_15 [Range]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /backbone_model/model.22/Constant_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Cast_15_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /backbone_model/model.0/conv/Constant_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Range_15 [Range] inputs: [/backbone_model/model.22/Constant_output_0 -> ()[INT32]], [/Cast_15_output_0 -> ()[INT32]], [/backbone_model/model.0/conv/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Range_15 for ONNX node: /Range_15
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Range_15_output_0 for ONNX tensor: /Range_15_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Range_15 [Range] outputs: [/Range_15_output_0 -> (300)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Slice_18 [Slice]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Range_15_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Unsqueeze_27_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Slice_18 [Slice] inputs: [/Range_15_output_0 -> (300)[INT32]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]], [/Unsqueeze_27_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Slice_18 for ONNX node: /Slice_18
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Slice_18_output_0 for ONNX tensor: /Slice_18_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Slice_18 [Slice] outputs: [/Slice_18_output_0 -> (300)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Gather_36 [Gather]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Shape_60_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /backbone_model/model.2/Constant_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Gather_36 [Gather] inputs: [/Shape_60_output_0 -> (3)[INT32]], [/backbone_model/model.2/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Using Gather axis: 0
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Gather_36 for ONNX node: /Gather_36
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Gather_36_output_0 for ONNX tensor: /Gather_36_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Gather_36 [Gather] outputs: [/Gather_36_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Cast_16 [Cast]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Gather_36_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Cast_16 [Cast] inputs: [/Gather_36_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Casting to type: int32
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Cast_16 for ONNX node: /Cast_16
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Cast_16_output_0 for ONNX tensor: /Cast_16_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Cast_16 [Cast] outputs: [/Cast_16_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Range_16 [Range]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /backbone_model/model.22/Constant_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Cast_16_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /backbone_model/model.0/conv/Constant_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Range_16 [Range] inputs: [/backbone_model/model.22/Constant_output_0 -> ()[INT32]], [/Cast_16_output_0 -> ()[INT32]], [/backbone_model/model.0/conv/Constant_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Range_16 for ONNX node: /Range_16
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Range_16_output_0 for ONNX tensor: /Range_16_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Range_16 [Range] outputs: [/Range_16_output_0 -> (6)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Slice_19 [Slice]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Range_16_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Constant_147_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Constant_4_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Slice_19 [Slice] inputs: [/Range_16_output_0 -> (6)[INT32]], [/Constant_147_output_0 -> (1)[INT32]], [/Constant_4_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_1_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Slice_19 for ONNX node: /Slice_19
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Slice_19_output_0 for ONNX tensor: /Slice_19_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Slice_19 [Slice] outputs: [/Slice_19_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Reshape_22 [Reshape]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Range_14_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Constant_19_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Reshape_22 [Reshape] inputs: [/Range_14_output_0 -> (-1)[INT32]], [/Constant_19_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Reshape_22 for ONNX node: /Reshape_22
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Reshape_22_output_0 for ONNX tensor: /Reshape_22_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Reshape_22 [Reshape] outputs: [/Reshape_22_output_0 -> (-1, 1, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Reshape_23 [Reshape]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Slice_18_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Constant_20_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Reshape_23 [Reshape] inputs: [/Slice_18_output_0 -> (300)[INT32]], [/Constant_20_output_0 -> (2)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Reshape_23 for ONNX node: /Reshape_23
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Reshape_23_output_0 for ONNX tensor: /Reshape_23_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Reshape_23 [Reshape] outputs: [/Reshape_23_output_0 -> (300, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Add_15 [Add]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Reshape_22_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Reshape_23_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Add_15 [Add] inputs: [/Reshape_22_output_0 -> (-1, 1, 1)[INT32]], [/Reshape_23_output_0 -> (300, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Add_15 for ONNX node: /Add_15
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Add_15_output_0 for ONNX tensor: /Add_15_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Add_15 [Add] outputs: [/Add_15_output_0 -> (-1, 300, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Add_16 [Add]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Add_15_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Slice_19_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Add_16 [Add] inputs: [/Add_15_output_0 -> (-1, 300, 1)[INT32]], [/Slice_19_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Add_16 for ONNX node: /Add_16
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Add_16_output_0 for ONNX tensor: /Add_16_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Add_16 [Add] outputs: [/Add_16_output_0 -> (-1, 300, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Shape_63 [Shape]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Add_16_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Shape_63 [Shape] inputs: [/Add_16_output_0 -> (-1, 300, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Shape_63 for ONNX node: /Shape_63
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Shape_63_output_0 for ONNX tensor: /Shape_63_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Shape_63 [Shape] outputs: [/Shape_63_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Shape_64 [Shape]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Shape_63_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Shape_64 [Shape] inputs: [/Shape_63_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Shape_64 for ONNX node: /Shape_64
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Shape_64_output_0 for ONNX tensor: /Shape_64_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Shape_64 [Shape] outputs: [/Shape_64_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /ConstantOfShape_20 [ConstantOfShape]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Shape_64_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /ConstantOfShape_20 [ConstantOfShape] inputs: [/Shape_64_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /ConstantOfShape_20_output_0 for ONNX tensor: /ConstantOfShape_20_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /ConstantOfShape_20 [ConstantOfShape] outputs: [/ConstantOfShape_20_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Mul_19 [Mul]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /ConstantOfShape_20_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Constant_22_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Mul_19 [Mul] inputs: [/ConstantOfShape_20_output_0 -> (3)[INT32]], [/Constant_22_output_0 -> ()[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Mul_19 for ONNX node: /Mul_19
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Mul_19_output_0 for ONNX tensor: /Mul_19_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Mul_19 [Mul] outputs: [/Mul_19_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Equal_18 [Equal]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Shape_63_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Mul_19_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Equal_18 [Equal] inputs: [/Shape_63_output_0 -> (3)[INT32]], [/Mul_19_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Equal_18 for ONNX node: /Equal_18
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Equal_18_output_0 for ONNX tensor: /Equal_18_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Equal_18 [Equal] outputs: [/Equal_18_output_0 -> (3)[BOOL]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Where_18 [Where]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Equal_18_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /ConstantOfShape_20_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Shape_63_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Where_18 [Where] inputs: [/Equal_18_output_0 -> (3)[BOOL]], [/ConstantOfShape_20_output_0 -> (3)[INT32]], [/Shape_63_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Where_18 for ONNX node: /Where_18
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Where_18_output_0 for ONNX tensor: /Where_18_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Where_18 [Where] outputs: [/Where_18_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Expand_26 [Expand]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Reshape_22_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Where_18_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Expand_26 [Expand] inputs: [/Reshape_22_output_0 -> (-1, 1, 1)[INT32]], [/Where_18_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Expand_26 for ONNX node: /Expand_26
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Expand_26_output_0 for ONNX tensor: /Expand_26_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Expand_26 [Expand] outputs: [/Expand_26_output_0 -> (-1, 300, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Unsqueeze_34 [Unsqueeze]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Expand_26_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /backbone_model/model.22/Constant_3_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Unsqueeze_34 [Unsqueeze] inputs: [/Expand_26_output_0 -> (-1, 300, 1)[INT32]], [/backbone_model/model.22/Constant_3_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Original shape: (_, 300, 1), unsqueezing to: (_, _, _, _)
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Unsqueeze_34 for ONNX node: /Unsqueeze_34
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Unsqueeze_34_output_0 for ONNX tensor: /Unsqueeze_34_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Unsqueeze_34 [Unsqueeze] outputs: [/Unsqueeze_34_output_0 -> (-1, 300, 1, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Expand_27 [Expand]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Reshape_23_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Where_18_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Expand_27 [Expand] inputs: [/Reshape_23_output_0 -> (300, 1)[INT32]], [/Where_18_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Expand_27 for ONNX node: /Expand_27
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Expand_27_output_0 for ONNX tensor: /Expand_27_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Expand_27 [Expand] outputs: [/Expand_27_output_0 -> (-1, 300, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Unsqueeze_35 [Unsqueeze]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Expand_27_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /backbone_model/model.22/Constant_3_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Unsqueeze_35 [Unsqueeze] inputs: [/Expand_27_output_0 -> (-1, 300, 1)[INT32]], [/backbone_model/model.22/Constant_3_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Original shape: (_, 300, 1), unsqueezing to: (_, _, _, _)
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Unsqueeze_35 for ONNX node: /Unsqueeze_35
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Unsqueeze_35_output_0 for ONNX tensor: /Unsqueeze_35_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Unsqueeze_35 [Unsqueeze] outputs: [/Unsqueeze_35_output_0 -> (-1, 300, 1, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Expand_28 [Expand]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Slice_19_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Where_18_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Expand_28 [Expand] inputs: [/Slice_19_output_0 -> (1)[INT32]], [/Where_18_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Expand_28 for ONNX node: /Expand_28
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Expand_28_output_0 for ONNX tensor: /Expand_28_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Expand_28 [Expand] outputs: [/Expand_28_output_0 -> (-1, 300, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Unsqueeze_36 [Unsqueeze]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Expand_28_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /backbone_model/model.22/Constant_3_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Unsqueeze_36 [Unsqueeze] inputs: [/Expand_28_output_0 -> (-1, 300, 1)[INT32]], [/backbone_model/model.22/Constant_3_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Original shape: (_, 300, 1), unsqueezing to: (_, _, _, _)
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Unsqueeze_36 for ONNX node: /Unsqueeze_36
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Unsqueeze_36_output_0 for ONNX tensor: /Unsqueeze_36_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Unsqueeze_36 [Unsqueeze] outputs: [/Unsqueeze_36_output_0 -> (-1, 300, 1, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Concat_19 [Concat]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Unsqueeze_34_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Unsqueeze_35_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Unsqueeze_36_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Concat_19 [Concat] inputs: [/Unsqueeze_34_output_0 -> (-1, 300, 1, 1)[INT32]], [/Unsqueeze_35_output_0 -> (-1, 300, 1, 1)[INT32]], [/Unsqueeze_36_output_0 -> (-1, 300, 1, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Concat_19 for ONNX node: /Concat_19
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Concat_19_output_0 for ONNX tensor: /Concat_19_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Concat_19 [Concat] outputs: [/Concat_19_output_0 -> (-1, 300, 1, 3)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Slice_20 [Slice]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Shape_60_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Constant_79_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Constant_176_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Slice_20 [Slice] inputs: [/Shape_60_output_0 -> (3)[INT32]], [/Constant_79_output_0 -> (1)[INT32]], [/Constant_176_output_0 -> (1)[INT32]], [/backbone_model/model.2/Constant_2_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Slice_20 for ONNX node: /Slice_20
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Slice_20_output_0 for ONNX tensor: /Slice_20_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Slice_20 [Slice] outputs: [/Slice_20_output_0 -> (0)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Concat_20 [Concat]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Shape_63_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Slice_20_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Concat_20 [Concat] inputs: [/Shape_63_output_0 -> (3)[INT32]], [/Slice_20_output_0 -> (0)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Concat_20 for ONNX node: /Concat_20
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Concat_20_output_0 for ONNX tensor: /Concat_20_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Concat_20 [Concat] outputs: [/Concat_20_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Reshape_24 [Reshape]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Expand_25_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Concat_20_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Reshape_24 [Reshape] inputs: [/Expand_25_output_0 -> (-1, 300, 1)[INT32]], [/Concat_20_output_0 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Reshape_24 for ONNX node: /Reshape_24
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Reshape_24_output_0 for ONNX tensor: /Reshape_24_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Reshape_24 [Reshape] outputs: [/Reshape_24_output_0 -> (-1, 300, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Cast_17 [Cast]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Reshape_24_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Cast_17 [Cast] inputs: [/Reshape_24_output_0 -> (-1, 300, 1)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Casting to type: float16
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Cast_17 for ONNX node: /Cast_17
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /Cast_17_output_0 for ONNX tensor: /Cast_17_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Cast_17 [Cast] outputs: [/Cast_17_output_0 -> (-1, 300, 1)[FLOAT]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /ScatterND_6 [ScatterND]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /ScatterND_5_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Concat_19_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Cast_17_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /ScatterND_6 [ScatterND] inputs: [/ScatterND_5_output_0 -> (-1, 300, 6)[FLOAT]], [/Concat_19_output_0 -> (-1, 300, 1, 3)[INT32]], [/Cast_17_output_0 -> (-1, 300, 1)[FLOAT]],
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /ScatterND_6 for ONNX node: /ScatterND_6
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: /ScatterND_6_output_0 for ONNX tensor: /ScatterND_6_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /ScatterND_6 [ScatterND] outputs: [/ScatterND_6_output_0 -> (-1, 300, 6)[FLOAT]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Reshape_25 [Reshape]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /EfficientNMS_TRT_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /Unsqueeze_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] /Reshape_25 [Reshape] inputs: [/EfficientNMS_TRT_output_0 -> (-1, 1)[INT32]], [/Unsqueeze_output_0 -> (1)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Reshape_25 for ONNX node: /Reshape_25
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: num_preds_412 for ONNX tensor: num_preds
[TH_YF8S][26-01-14 11:43:47][TRT] /Reshape_25 [Reshape] outputs: [num_preds -> (-1)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Parsing node: /Reshape_26 [Reshape]
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: /ScatterND_6_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] Searching for input: _v_1801
[TH_YF8S][26-01-14 11:43:47][TRT] /Reshape_26 [Reshape] inputs: [/ScatterND_6_output_0 -> (-1, 300, 6)[FLOAT]], [_v_1801 -> (3)[INT32]],
[TH_YF8S][26-01-14 11:43:47][TRT] Registering layer: /Reshape_26 for ONNX node: /Reshape_26
[TH_YF8S][26-01-14 11:43:47][TRT] Registering tensor: preds_413 for ONNX tensor: preds
[TH_YF8S][26-01-14 11:43:47][TRT] /Reshape_26 [Reshape] outputs: [preds -> (-1, 300, 6)[FLOAT]],
[TH_YF8S][26-01-14 11:43:47][TRT] Marking preds_413 as output: preds
[TH_YF8S][26-01-14 11:43:47][TRT] Marking num_preds_412 as output: num_preds
[TH_YF8S][26-01-14 11:43:47] TensorRT build config
ian 14 09:43:47 teste sh[3722914]:   Workspace size: 4 GB
ian 14 09:43:47 teste sh[3722914]:   Network flags: ['NetworkDefinitionCreationFlag.EXPLICIT_BATCH']
ian 14 09:43:47 teste sh[3722914]:   Builder flags: ['FP16', 'TF32']
[TH_YF8S][26-01-14 11:43:47] TensorRT network IO
ian 14 09:43:47 teste sh[3722914]:   Inputs: 1
ian 14 09:43:47 teste sh[3722914]:     input: name=inputs, dtype=DataType.HALF, shape=(-1, 3, 640, 1152)
ian 14 09:43:47 teste sh[3722914]:   Outputs: 2
ian 14 09:43:47 teste sh[3722914]:     output: name=preds, dtype=DataType.HALF, shape=(-1, 300, 6)
ian 14 09:43:47 teste sh[3722914]:     output: name=num_preds, dtype=DataType.INT32, shape=(-1,)
[TH_YF8S][26-01-14 11:43:47] TensorRT optimization profiles
ian 14 09:43:47 teste sh[3722914]:   inputs: min=[1, 3, 640, 1152], opt=[8, 3, 640, 1152], max=[8, 3, 640, 1152]
[TH_YF8S][26-01-14 11:43:47][TRT] BuilderFlag::kTF32 is set but hardware does not support TF32. Disabling TF32.
[TH_YF8S][26-01-14 11:43:47][TRT] Original: 403 layers
[TH_YF8S][26-01-14 11:43:47][TRT] After dead-layer removal: 403 layers
[TH_YF8S][26-01-14 11:43:47][TRT] Graph construction completed in 0.0112665 seconds.
[TH_YF8S][26-01-14 11:43:47][TRT] Running: ConstShuffleFusion on /backbone_model/model.2/Constant_1_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] ConstShuffleFusion: Fusing /backbone_model/model.2/Constant_1_output_0 with (Unnamed Layer* 928) [Shuffle]
[TH_YF8S][26-01-14 11:43:47][TRT] Running: ConstShuffleFusion on /backbone_model/model.2/Constant_4_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] ConstShuffleFusion: Fusing /backbone_model/model.2/Constant_4_output_0 with (Unnamed Layer* 1005) [Shuffle]
[TH_YF8S][26-01-14 11:43:47][TRT] Running: ConstShuffleFusion on /backbone_model/model.22/Constant_17_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] ConstShuffleFusion: Fusing /backbone_model/model.22/Constant_17_output_0 with (Unnamed Layer* 712) [Shuffle]
[TH_YF8S][26-01-14 11:43:47][TRT] Running: ConstShuffleFusion on (Unnamed Layer* 726) [Constant]
[TH_YF8S][26-01-14 11:43:47][TRT] ConstShuffleFusion: Fusing (Unnamed Layer* 726) [Constant] with (Unnamed Layer* 727) [Shuffle]
[TH_YF8S][26-01-14 11:43:47][TRT] Running: ConstShuffleFusion on /backbone_model/model.2/Constant_2_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] ConstShuffleFusion: Fusing /backbone_model/model.2/Constant_2_output_0 with (Unnamed Layer* 846) [Shuffle]
[TH_YF8S][26-01-14 11:43:47][TRT] Running: ConstShuffleFusion on /Constant_79_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] ConstShuffleFusion: Fusing /Constant_79_output_0 with (Unnamed Layer* 1083) [Shuffle]
[TH_YF8S][26-01-14 11:43:47][TRT] Running: ConstShuffleFusion on (Unnamed Layer* 1109) [Constant]
[TH_YF8S][26-01-14 11:43:47][TRT] ConstShuffleFusion: Fusing (Unnamed Layer* 1109) [Constant] with (Unnamed Layer* 1110) [Shuffle]
[TH_YF8S][26-01-14 11:43:47][TRT] Running: ConstShuffleFusion on /Constant_95_output_0
[TH_YF8S][26-01-14 11:43:47][TRT] ConstShuffleFusion: Fusing /Constant_95_output_0 with (Unnamed Layer* 1114) [Shuffle]
[TH_YF8S][26-01-14 11:43:47][TRT] Running: ShuffleShuffleFusion on /backbone_model/model.22/dfl/Reshape
[TH_YF8S][26-01-14 11:43:47][TRT] ShuffleShuffleFusion: Fusing /backbone_model/model.22/dfl/Reshape with /backbone_model/model.22/dfl/Transpose
[TH_YF8S][26-01-14 11:43:47][TRT] Running: ShuffleErasure on (Unnamed Layer* 637) [Shuffle]
[TH_YF8S][26-01-14 11:43:47][TRT] Removing (Unnamed Layer* 637) [Shuffle]
[TH_YF8S][26-01-14 11:43:47][TRT] Running: ShuffleShuffleFusion on /Reshape_17
[TH_YF8S][26-01-14 11:43:47][TRT] ShuffleShuffleFusion: Fusing /Reshape_17 with (Unnamed Layer* 1263) [Shuffle]
[TH_YF8S][26-01-14 11:43:47][TRT] Running: ShuffleErasure on /Reshape_18
[TH_YF8S][26-01-14 11:43:47][TRT] Removing /Reshape_18
[TH_YF8S][26-01-14 11:43:47][TRT] Running: ShuffleShuffleFusion on /Reshape_20
[TH_YF8S][26-01-14 11:43:47][TRT] ShuffleShuffleFusion: Fusing /Reshape_20 with (Unnamed Layer* 1429) [Shuffle]
[TH_YF8S][26-01-14 11:43:47][TRT] Running: ShuffleErasure on /Reshape_21
[TH_YF8S][26-01-14 11:43:47][TRT] Removing /Reshape_21
[TH_YF8S][26-01-14 11:43:47][TRT] Running: ShuffleShuffleFusion on /Reshape_23
[TH_YF8S][26-01-14 11:43:47][TRT] ShuffleShuffleFusion: Fusing /Reshape_23 with (Unnamed Layer* 1594) [Shuffle]
[TH_YF8S][26-01-14 11:43:47][TRT] Running: ShuffleErasure on /Reshape_24
[TH_YF8S][26-01-14 11:43:47][TRT] Removing /Reshape_24
[TH_YF8S][26-01-14 11:43:47][TRT] Running: ShuffleErasure on /Reshape_26
[TH_YF8S][26-01-14 11:43:47][TRT] Removing /Reshape_26
[TH_YF8S][26-01-14 11:43:47][TRT] 2: [helpers.h::smVerHex2Dig::694] Error Code 2: Internal Error (Assertion major >= 0 && major < 10 failed. )
[TH_YF8S][26-01-14 11:43:47] TensorRT build failed. If you see smVerHex2Dig assertions, verify GPU compute capability and driver compatibility with this TensorRT build.
[TH_YF8S][26-01-14 11:43:47][52] Exception in ThYf8s:
ian 14 09:43:47 teste sh[3722914]: Traceback (most recent call last):
ian 14 09:43:47 teste sh[3722914]:   File "/usr/local/lib/python3.10/dist-packages/naeural_core/serving/base/backends/trt.py", line 879, in create_from_onnx
ian 14 09:43:47 teste sh[3722914]:     raise RuntimeError("TensorRT build_engine returned None")
ian 14 09:43:47 teste sh[3722914]: RuntimeError: TensorRT build_engine returned None
ian 14 09:43:47 teste sh[3722914]: During handling of the above exception, another exception occurred:
ian 14 09:43:47 teste sh[3722914]: Traceback (most recent call last):
ian 14 09:43:47 teste sh[3722914]:   File "/usr/local/lib/python3.10/dist-packages/naeural_core/serving/base/base_serving_process.py", line 601, in run
ian 14 09:43:47 teste sh[3722914]:     _msg = self.__startup()
ian 14 09:43:47 teste sh[3722914]:   File "/usr/local/lib/python3.10/dist-packages/naeural_core/serving/base/base_serving_process.py", line 713, in __startup
ian 14 09:43:47 teste sh[3722914]:     return self._startup()
ian 14 09:43:47 teste sh[3722914]:   File "/usr/local/lib/python3.10/dist-packages/naeural_core/serving/base/basic_th.py", line 871, in _startup
ian 14 09:43:47 teste sh[3722914]:     msg = self._setup_model()
ian 14 09:43:47 teste sh[3722914]:   File "/usr/local/lib/python3.10/dist-packages/naeural_core/serving/base/basic_th.py", line 299, in _setup_model
ian 14 09:43:47 teste sh[3722914]:     self.th_model = self._get_model(config=backend_model_map)
ian 14 09:43:47 teste sh[3722914]:   File "/usr/local/lib/python3.10/dist-packages/naeural_core/serving/default_inference/th_yf_base.py", line 74, in _get_model
ian 14 09:43:47 teste sh[3722914]:     model, model_loaded_config, fn = self.prepare_model(
ian 14 09:43:47 teste sh[3722914]:   File "/usr/local/lib/python3.10/dist-packages/naeural_core/serving/base/basic_th.py", line 584, in prepare_model
ian 14 09:43:47 teste sh[3722914]:     model, config = load_method(
ian 14 09:43:47 teste sh[3722914]:   File "/usr/local/lib/python3.10/dist-packages/naeural_core/serving/mixins_base/trt_mixin.py", line 61, in _prepare_trt_model
ian 14 09:43:47 teste sh[3722914]:     model.load_or_rebuild_model(fn_path, half, max_batch_size, self.dev)
ian 14 09:43:47 teste sh[3722914]:   File "/usr/local/lib/python3.10/dist-packages/naeural_core/serving/base/backends/trt.py", line 440, in load_or_rebuild_model
ian 14 09:43:47 teste sh[3722914]:     TensorRTModel.create_from_onnx(
ian 14 09:43:47 teste sh[3722914]:   File "/usr/local/lib/python3.10/dist-packages/naeural_core/serving/base/backends/trt.py", line 898, in create_from_onnx
ian 14 09:43:47 teste sh[3722914]:     raise RuntimeError("Failed to build TensorRT engine: {}".format(e))
ian 14 09:43:47 teste sh[3722914]: RuntimeError: Failed to build TensorRT engine: TensorRT build_engine returned None
ian 14 09:43:47 teste sh[3722914]:
[TH_YF8S][26-01-14 11:43:47][52] Closing Serving Process execution loop...
[EE][26-01-14 11:43:47][SMGR] Received 'STARTUP_FAILURE': from 'TH_YF8S' with data: 'Traceback (most recent call last):
ian 14 09:43:47 teste sh[3722914]:   File "/usr/local/lib/python3.10/dist-packages/naeural_core/serving/base/backends/trt.py", line 879, in create_from_onnx
ian 14 09:43:47 teste sh[3722914]:     raise RuntimeError("TensorRT build_engine returned None")
ian 14 09:43:47 teste sh[3722914]: RuntimeError: TensorRT build_engine returned None
ian 14 09:43:47 teste sh[3722914]: During handling of the above exception, another exception occurred:
ian 14 09:43:47 teste sh[3722914]: Traceback (most recent call last):
ian 14 09:43:47 teste sh[3722914]:   File "/usr/local/lib/python3.10/dist-packages/naeural_core/serving/base/base_serving_process.py", line 601, in run
ian 14 09:43:47 teste sh[3722914]:     _msg = self.__startup()
ian 14 09:43:47 teste sh[3722914]:   File "/usr/local/lib/python3.10/dist-packages/naeural_core/serving/base/base_serving_process.py", line 713, in __startup
ian 14 09:43:47 teste sh[3722914]:     return self._startup()
ian 14 09:43:47 teste sh[3722914]:   File "/usr/local/lib/python3.10/dist-packages/naeural_core/serving/base/basic_th.py", line 871, in _startup
ian 14 09:43:47 teste sh[3722914]:     msg = self._setup_model()
ian 14 09:43:47 teste sh[3722914]:   File "/usr/local/lib/python3.10/dist-packages/naeural_core/serving/base/basic_th.py", line 299, in _setup_model
ian 14 09:43:47 teste sh[3722914]:     self.th_model = self._get_model(config=backend_model_map)
ian 14 09:43:47 teste sh[3722914]:   File "/usr/local/lib/python3.10/dist-packages/naeural_core/serving/default_inference/th_yf_base.py", line 74, in _get_model
ian 14 09:43:47 teste sh[3722914]:     model, model_loaded_config, fn = self.prepare_model(
ian 14 09:43:47 teste sh[3722914]:   File "/usr/local/lib/python3.10/dist-packages/naeural_core/serving/base/basic_th.py", line 584, in prepare_model
ian 14 09:43:47 teste sh[3722914]:     model, config = load_method(
ian 14 09:43:47 teste sh[3722914]:   File "/usr/local/lib/python3.10/dist-packages/naeural_core/serving/mixins_base/trt_mixin.py", line 61, in _prepare_trt_model
ian 14 09:43:47 teste sh[3722914]:     model.load_or_rebuild_model(fn_path, half, max_batch_size, self.dev)
ian 14 09:43:47 teste sh[3722914]:   File "/usr/local/lib/python3.10/dist-packages/naeural_core/serving/base/backends/trt.py", line 440, in load_or_rebuild_model
ian 14 09:43:47 teste sh[3722914]:     TensorRTModel.create_from_onnx(
ian 14 09:43:47 teste sh[3722914]:   File "/usr/local/lib/python3.10/dist-packages/naeural_core/serving/base/backends/trt.py", line 898, in create_from_onnx
ian 14 09:43:47 teste sh[3722914]:     raise RuntimeError("Failed to build TensorRT engine: {}".format(e))
ian 14 09:43:47 teste sh[3722914]: RuntimeError: Failed to build TensorRT engine: TensorRT build_engine returned None
ian 14 09:43:47 teste sh[3722914]: '
[EE][26-01-14 11:43:47][SMGR] Serving process 'TH_YF8S' FAILED. Closing pipes and process...
[EE][26-01-14 11:43:47][NumpySharedMemory] Shutdown NumpySharedMemory TH_YF8S[Creator]...
[EE][26-01-14 11:43:47][SMGR]   Serving process 'TH_YF8S' terminated: <ThYf8s name='ThYf8s-1' pid=52 parent=1 started daemon>
[EE][26-01-14 11:43:47][SMGR] Serving process creation failed for TH_YF8S!