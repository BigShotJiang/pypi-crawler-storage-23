from abc import ABC, abstractmethod
from logging import Logger

from fastapi import FastAPI

from phederation.utils.logging import configure_logger
from phederation.utils.settings import PhedSettings
from phederation.web.middleware import ActivityPubMiddleware
from phederation.web.server import ActivityPubServer


class BaseAPI(ABC):
    """Base class for all API implementations."""

    async def initialize(self, app: FastAPI, settings: PhedSettings, middleware: ActivityPubMiddleware, server: ActivityPubServer) -> None:
        self.app: FastAPI = app
        self.settings: PhedSettings = settings
        self.server: ActivityPubServer = server
        self.middleware: ActivityPubMiddleware = middleware
        self.logger: Logger = configure_logger(
            f"{".".join(__name__.split('.')[:-1])}.{type(self).__name__.lower()}", prefix=self.settings.federation.logging_prefix
        )

    @abstractmethod
    def version(self, major: bool = True, minor: bool = True, patch: bool = True) -> str:
        pass
