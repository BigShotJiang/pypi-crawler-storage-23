"""API package for ActivityPub phederation.

This module implements version v1 of the Phederation API with FastAPI routes.
"""

from .base import BaseAPI
from .v1 import APIv1


async def create_api(version: str) -> BaseAPI:
    if version.startswith('1'):
        return APIv1()
    raise ValueError(f"API version '{version}' cannot be served. Must start with '1'")

API_LATEST = "1.0.0"

__all__ = [
    "BaseAPI", "create_api", "API_LATEST"
]
