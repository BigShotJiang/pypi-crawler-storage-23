from typing import override

from phederation.api.routes.base import BaseRoute


class SecurityRoute(BaseRoute):

    @override
    def setup(self) -> None:
        pass
