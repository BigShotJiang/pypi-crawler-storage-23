from .base import BaseRoute

__all__ = [
    'BaseRoute'
]