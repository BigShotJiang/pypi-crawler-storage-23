"""Integration into a web framework.

Defines the interface to a proper web endpoint and API, here FastAPI.
"""


from .base import BaseIntegration
from .integration import FastAPIIntegration

__all__ = [
    "BaseIntegration", "FastAPIIntegration"
]