"""
Base integration interfaces.
"""

from abc import ABC, abstractmethod

from fastapi import FastAPI

from phederation.api.base import BaseAPI
from phederation.web.middleware import ActivityPubMiddleware
from phederation.web.server import ActivityPubServer
from phederation.utils.exceptions import IntegrationError, catch_exceptions
from phederation.utils.settings import PhedSettings


class BaseIntegration(ABC):
    """Base integration interface."""

    app: FastAPI
    middleware: ActivityPubMiddleware
    server: ActivityPubServer

    def __init__(self, settings: PhedSettings):
        self.settings: PhedSettings = settings

    @catch_exceptions(IntegrationError, "Failed to initialize integration")
    @abstractmethod
    async def initialize(self) -> None:
        """Initialize integration."""
        pass

    @abstractmethod
    async def api(self, api_version: str | None = None) -> BaseAPI:
        """Create an API object depending on the API version specified in the request.
        If nothing is specified, use the latest API version.

        Args:
            api_version (str | None, optional): Version string with format "x.y.z", e.g. "1.0.0". Defaults to None.

        Returns:
            BaseAPI | None: The API version to return.
        """
        pass
