from dataclasses import dataclass
from datetime import datetime
import enum

from cryptography.hazmat.primitives.asymmetric.rsa import RSAPrivateKey, RSAPublicKey

from phederation.utils.base import ObjectId


class KeyType(str, enum.Enum):
    RSA = "rsa-sha256-key"
    Fernet = "fernet-key"


@dataclass
class KeyPair:
    key_id: ObjectId
    private_key: RSAPrivateKey | None = None
    public_key: RSAPublicKey | None = None
    created_at: datetime | None = None
    expires_at: datetime | None = None
