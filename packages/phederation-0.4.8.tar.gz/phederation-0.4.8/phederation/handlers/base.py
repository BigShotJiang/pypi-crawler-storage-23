"""
Base activity handler implementation.
"""

from abc import ABC, abstractmethod
from logging import Logger

from phederation.collections.collections import CollectionManager
from phederation.federation.delivery import ActivityDelivery
from phederation.federation.resolver import ActivityPubResolver
from phederation.models import APActivity
from phederation.federation.keys import KeyManager
from phederation.federation.actors import ActorManager
from phederation.storage.base import StorageBackend
from phederation.utils.logging import configure_logger


class ActivityHandler(ABC):
    """Base activity handler."""

    def __init__(
        self,
        actor_manager: ActorManager,
        key_manager: KeyManager,
        storage: StorageBackend,
        collections: CollectionManager,
        resolver: ActivityPubResolver,
        delivery: ActivityDelivery,
    ):
        self.actor_manager: ActorManager = actor_manager
        self.key_manager: KeyManager = key_manager
        self.storage: StorageBackend = storage
        self.collections: CollectionManager = collections
        self.resolver: ActivityPubResolver = resolver
        self.delivery: ActivityDelivery = delivery
        self.logger: Logger = configure_logger(
            f"{".".join(__name__.split('.')[:-1])}.{type(self).__name__.lower()}", prefix=self.storage.settings.federation.logging_prefix
        )

    @abstractmethod
    async def validate(self, activity: APActivity) -> APActivity:
        """
        Validate activity.

        Args:
            activity: Activity to validate

        Raises:
            ValidationError if validation fails

        Returns:
            The activity dictionary, potentially changed due to validation.
        """
        pass

    @abstractmethod
    async def process_outbox(self, activity: APActivity) -> APActivity:
        """
        Process activity that was posted into an outbox (so, client to server).

        Args:
            activity: Activity to process

        Returns:
            Activity ID if successful

        Raises:
            HandlerError if processing fails
        """
        pass

    @abstractmethod
    async def process_inbox(self, activity: APActivity) -> None | str:
        """
        Process activity that was posted into an inbox (so, server to server).

        Args:
            activity: Activity to process

        Returns:
            Activity ID if successful

        Raises:
            HandlerError if processing fails
        """
        pass
