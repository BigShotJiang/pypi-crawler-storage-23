"""
Storage module for ActivityPub data persistence.

Features
- Abstract storage interface, one async nosql implementation for now
- Efficient implementation of specific ActivityPub features, such as followers and file storage in gridfs
"""

from .base import StorageBackend
from .nosql import NoSQLStorageBackend
from .nosqlcrud import NoSqlCRUD

__all__ = ["StorageBackend", "NoSQLStorageBackend", "NoSqlCRUD"]
