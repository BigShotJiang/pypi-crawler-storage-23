
from abc import ABCMeta

from pydantic import BaseModel


class BaseError(BaseModel, metaclass=ABCMeta):
    """Base model for all Error Message classes."""

