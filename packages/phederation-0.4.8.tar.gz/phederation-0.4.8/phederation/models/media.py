"""
media.py
This module defines metadata for media sent/received through activity pub.

For more information, see:
https://www.w3.org/TR/activitystreams-vocabulary/
"""

from pydantic import BaseModel, Field
from phederation.utils.base import ObjectId

class MediaMetadata(BaseModel):
    """
    Represents media for a file object sent over the media endpoint of APActors.
    """
    filename: str = Field(default=..., description='Name of the file. Can be as it is stored on the server, or as it was defined by the uploading actor.')
    content_type: str = Field(..., description="Mime type of the file.")
    hash_sha256: str | None = Field(default=None, description="Sha256 hash of the file content. Optional, used by DataIntegrityProof process.")
    document_id: ObjectId = Field(default=..., description="Id of the APDocument that describes this file, including the accessibility.")