"""
activities.py
This module defines the Activity types for ActivityPub.
These activities are based on the ActivityStreams vocabulary.

For more information, see:
https://www.w3.org/TR/activitystreams-vocabulary/#activity-types
"""

from typing import ClassVar, override

from pydantic import ConfigDict, Field, SerializeAsAny, ValidationError, field_validator

from phederation.models.objects import APObject
from phederation.utils import ActivityPubBaseWithId, ActivityType, ObjectId
from phederation.utils.base import APDateTime

from .errors import BaseError
from .objects import APDocument


class ErrorMessageActivityNotFound(BaseError):
    message: str = "Activity does not exist locally."
    description: str = "The activity with the given id cannot be found on this instance."


class ErrorMessageActivityRestricted(BaseError):
    message: str = "Activity has restricted visibility."
    description: str = "The activity with the given id has restricted visibility."


class ErrorMessageActivityValidation(BaseError):
    message: str = "Activity request body is not valid."
    description: str = "The activity posted has an invalid request body."


class ErrorMessageActivityHandler(BaseError):
    message: str = "Activity could not be processed properly."
    description: str = "The inbox could not process the given activity request body."


class APActivity(APObject):
    """
    Base class for all ActivityPub activities.
    An Activity is a subtype of Object that describes some form of action.

    Specification: https://www.w3.org/TR/activitystreams-vocabulary/#activity
    Usage: https://www.w3.org/TR/activitypub/#activities
    """

    actor: None | str | SerializeAsAny[APObject] = Field(None, description="The actor performing the activity. May be None")
    object: None | str | SerializeAsAny[APObject] = Field(default=None, description="The object of the activity")
    target: None | str | SerializeAsAny[APObject] | list[SerializeAsAny[APObject]] = Field(default=None, description="The target of the activity")
    result: None | str | SerializeAsAny[APObject] = Field(default=None, description="The result of the activity")
    origin: None | str | SerializeAsAny[APObject] = Field(default=None, description="The origin of the activity")
    instrument: None | str | SerializeAsAny[APObject] = Field(default=None, description="The instrument used")

    @override
    def clear_recipients(self):
        super().clear_recipients()
        if self.object and not isinstance(self.object, str):
            self.object.clear_recipients()

    @override
    async def get_recipients(self) -> list[ObjectId]:
        """Get the (deduplicated) list of actors in the activity recipient fields (to,cc,bto,bcc,audience).
        This includes the activity.object recipients. Does *not* resolve the inboxes of these recipients yet.

        Returns:
            list[ObjectId]: List of actor_id's for all recipients found.
        """
        recipients = await super().get_recipients()
        object = self.object
        if isinstance(object, dict):
            object = APObject.deserialize(object)
        if isinstance(object, APObject):
            recipients += await object.get_recipients()

        recipients = list(set(recipients))
        return recipients

    def get_object_or_None(self) -> APObject | None:
        """Returns the activity.object as APObject or APDocument if it is set (also if it is a dict).

        If the activity.object is None or just an ObjectId string, this returns None.

        Returns:
            APObject | None: The object if it is set, None otherwise.
        """
        if isinstance(self.object, APObject):
            return self.object

    model_config: ClassVar[ConfigDict] = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "id": "https://example.org/id-of-the-activity-unused",
                    "type": "Create",
                    "attributedTo": "https://example.org/id-of-an-actor",
                    "content": "The content of the activity described in text.",
                    "summary": "A summary of the activity.",
                    "actor": "https://example.org/id-of-actor-performing-the-activity",
                    "object": {"id": "https://example.org/id-of-the-note-temporary", "type": "Note", "summary": "This is a note to create."},
                    "target": "https://example.org/id-of-target-actor-or-object",
                }
            ]
        }
    )


class APIntransitiveActivity(APActivity):
    """
    Instances of IntransitiveActivity are a subtype of Activity representing intransitive actions.
    The object property is therefore inappropriate for these activities.

    Specification: https://www.w3.org/ns/activitystreams#IntransitiveActivity
    """

    type: str = Field(
        default=ActivityType.INTRANSITIVE.value,
        description="Indicates that this object represents a create activity",
    )
    object: None | str | APDocument | APObject = Field(default=None, description="The object being created")

    @field_validator("object")
    @classmethod
    def check_object_is_none(cls, value: None | str | APDocument | APObject):
        if value is not None:
            raise ValidationError("IntransitiveActivity must not have an object set")


class APCreate(APActivity):
    """
    Represents a Create activity in ActivityPub.
    Indicates that the actor has created the object.

    Specification: https://www.w3.org/TR/activitystreams-vocabulary/#create
    """

    type: str = Field(
        default=ActivityType.CREATE.value,
        description="Indicates that this object represents a create activity",
    )
    object: None | str | APDocument | APObject = Field(default=None, description="The object being created")


class APUpdate(APActivity):
    """
    Represents an Update activity in ActivityPub.
    Indicates that the actor has updated the object.

    Specification: https://www.w3.org/TR/activitystreams-vocabulary/#update
    """

    type: str = Field(
        default=ActivityType.UPDATE.value,
        description="Indicates that this object represents an update activity",
    )
    object: None | str | APObject = Field(default=None, description="The object being updated")


class APDelete(APActivity):
    """
    Represents a Delete activity in ActivityPub.
    Indicates that the actor has deleted the object.

    Specification: https://www.w3.org/TR/activitystreams-vocabulary/#delete
    """

    type: str = Field(
        default=ActivityType.DELETE.value,
        description="Indicates that this object represents a delete activity",
    )
    object: None | str | APObject = Field(default=None, description="The object being deleted")


class APFollow(APActivity):
    """
    Represents a Follow activity in ActivityPub.
    Indicates that the actor is "following" the object.

    Specification: https://www.w3.org/TR/activitystreams-vocabulary/#follow
    """

    type: str = Field(
        default=ActivityType.FOLLOW.value,
        description="Indicates that this object represents a follow activity",
    )
    object: None | str | APObject = Field(default=..., description="The object being followed")
    accepted: bool = Field(default=False, description="If the object has accepted the follow of actor")
    accepted_at: APDateTime | None = Field(default=None, description="Time of accept of follow.")


class APUndo(APActivity):
    """
    Represents an Undo activity in ActivityPub.
    Indicates that the actor is undoing the object activity.

    Specification: https://www.w3.org/TR/activitystreams-vocabulary/#undo
    """

    type: str = Field(
        default=ActivityType.UNDO.value,
        description="Indicates that this object represents an undo activity",
    )
    object: None | str | APObject = Field(default=None, description="The activity being undone")


class APLike(APActivity):
    """
    Represents a Like activity in ActivityPub.
    Indicates that the actor likes the object.

    Specification: https://www.w3.org/TR/activitystreams-vocabulary/#like
    """

    type: str = Field(
        default=ActivityType.LIKE.value,
        description="Indicates that this object represents a like activity",
    )
    object: None | str | APObject = Field(default=None, description="The object being liked")


class APDislike(APActivity):
    """
    Indicates that the actor dislikes the object.

    Specification: https://www.w3.org/ns/activitystreams#Dislike
    """

    type: str = Field(
        default=ActivityType.DISLIKE.value,
        description="Indicates that the actor dislikes the object.",
    )
    object: None | str | APObject = Field(default=None, description="The object being disliked")


class APQuestion(APIntransitiveActivity):
    """
    Represents a question being asked. Question objects are an extension of IntransitiveActivity.
    That is, the Question object is an Activity, but the direct object is the question
    itself and therefore it would not contain an object property.

    Either of the anyOf and oneOf properties MAY be used to express possible answers, but a Question object MUST NOT have both properties.
    """

    type: str = Field(
        default=ActivityType.QUESTION.value,
        description="Represents a question being asked.",
    )

    anyOf: None | str | SerializeAsAny[APObject] = Field(default=None, description="Any of these is a possible answer")
    oneOf: None | str | SerializeAsAny[APObject] = Field(default=None, description="One of these is a possible answer")
    closed: None | str | SerializeAsAny[APObject] | APDateTime = Field(default=None, description="Indicates that this question is closed")


class APAnnounce(APActivity):
    """
    Represents an Announce activity in ActivityPub.
    Indicates that the actor is calling the target's attention to the object.

    Specification: https://www.w3.org/TR/activitystreams-vocabulary/#announce
    """

    type: str = Field(
        default=ActivityType.ANNOUNCE.value,
        description="Indicates that this object represents an announce activity",
    )
    object: None | str | APObject = Field(default=None, description="The object being announced")


class APAccept(APActivity):
    """
    Represents an Accept activity in ActivityPub.
    Indicates that the actor accepts the object.

    Specification: https://www.w3.org/TR/activitystreams-vocabulary/#accept
    """

    type: str = Field(
        default=ActivityType.ACCEPT.value,
        description="Indicates that this object represents an accept activity",
    )
    object: None | str | APObject = Field(default=None, description="The object being accepted")


class APTentativeAccept(APAccept):
    """
    Represents an TentativeAccept activity in ActivityPub.
    A specialization of Accept indicating that the acceptance is tentative.

    Specification: https://www.w3.org/ns/activitystreams#TentativeAccept
    """

    type: str = Field(
        default=ActivityType.TENTATIVE_ACCEPT.value,
        description="Indicates that this object represents a tentative accept activity",
    )
    object: None | str | APObject = Field(default=None, description="The object being accepted tentatively")


class APAdd(APActivity):
    """
    Represents a Add activity in ActivityPub.
    Indicates that the actor is adding the object.

    Specification: https://www.w3.org/TR/activitystreams-vocabulary/#add
    """

    type: str = Field(
        default=ActivityType.ADD.value,
        description="Activity to add an object to an origin",
    )
    object: None | str | APObject = Field(default=None, description="The object being added")
    origin: None | str | APObject = Field(default=None, description="The origin where the object should be added to")


class APRemove(APActivity):
    """
    Represents a Remove activity in ActivityPub.
    Indicates that the actor is removing the object.

    Specification: https://www.w3.org/TR/activitystreams-vocabulary/#remove
    """

    type: str = Field(
        default=ActivityType.REMOVE.value,
        description="Activity to remove an object from an origin",
    )
    object: None | str | APObject = Field(default=None, description="The object being removed")
    origin: None | str | APObject = Field(default=None, description="The origin where the object resides now, and where it should be removed from")


class APBlock(APActivity):
    """
    Represents a Block activity in ActivityPub.
    Indicates that the actor is blocking the object.

    Specification: https://www.w3.org/TR/activitystreams-vocabulary/#block
    """

    type: str = Field(
        default=ActivityType.BLOCK.value,
        description="Indicates that this object represents a block activity",
    )
    object: None | str | APObject = Field(default=None, description="The object being blocked")


class APReject(APActivity):
    """
    Represents a Reject activity in ActivityPub.
    Indicates that the actor rejects the object.
    This is typically used to reject incoming activities such as Follow requests.

    Specification: https://www.w3.org/TR/activitystreams-vocabulary/#reject
    """

    type: str = Field(
        default=ActivityType.REJECT.value,
        description="A reject activity",
    )
    object: None | str | APObject = Field(default=None, description="The object being rejected")


class APTentativeReject(APReject):
    """
    Represents an TentativeReject activity in ActivityPub.
    A specialization of Reject indicating that the rejection is tentative.

    Specification: https://www.w3.org/ns/activitystreams#TentativeReject
    """

    type: str = Field(
        default=ActivityType.TENTATIVE_REJECT.value,
        description="Indicates that this object represents a tentative reject activity",
    )
    object: None | str | APObject = Field(default=None, description="The object being rejected tentatively")


class APArrive(APActivity):
    """
    Represents a Arrive activity in ActivityPub.
    An IntransitiveActivity that indicates that the actor has arrived at the location.
    The origin can be used to identify the context from which the actor originated.
    The target typically has no defined meaning.

    Specification: https://www.w3.org/ns/activitystreams#Arrive
    """

    type: str = Field(
        default=ActivityType.ARRIVE.value,
        description="Arrive activity",
    )
    origin: None | str | SerializeAsAny[APObject] = Field(default=None, description="The origin being arrived at")


class APMove(APActivity):
    """
    Represents a Move activity in ActivityPub.
    Indicates that the actor has moved object from origin to target.
    If the origin or target are not specified, either can be determined by context.

    Specification: https://www.w3.org/ns/activitystreams#Move
    """

    type: str = Field(
        default=ActivityType.MOVE.value,
        description="Move activity",
    )
    target: None | str | SerializeAsAny[APObject] | list[SerializeAsAny[APObject]] = Field(default=None, description="The target of the move")
    origin: None | str | SerializeAsAny[APObject] = Field(default=None, description="The origin of the move")


class APTravel(APIntransitiveActivity):
    """
    Indicates that the actor is traveling to target from origin.
    Travel is an IntransitiveObject whose actor specifies the direct object.
    If the target or origin are not specified, either can be determined by context.

    Specification: https://www.w3.org/ns/activitystreams#Travel
    """

    type: str = Field(
        default=ActivityType.TRAVEL.value,
        description="Travel activity",
    )
    target: None | str | SerializeAsAny[APObject] | list[SerializeAsAny[APObject]] = Field(default=None, description="The target of the travel")
    origin: None | str | SerializeAsAny[APObject] = Field(default=None, description="The origin of the travel")


class APIgnore(APActivity):
    """
    Represents a Ignore activity in ActivityPub.
    Indicates that the actor is ignoring the object.

    Specification: https://www.w3.org/ns/activitystreams#Ignore
    """

    type: str = Field(
        default=ActivityType.IGNORE.value,
        description="Ignore activity",
    )
    object: None | str | APObject = Field(default=None, description="The object being ignored")


class APFlag(APActivity):
    """
    Indicates that the actor is "flagging" the object.
    Flagging is defined in the sense common to many social platforms
    as reporting content as being inappropriate for any number of reasons.

    Specification: https://www.w3.org/ns/activitystreams#Flag
    """

    type: str = Field(
        default=ActivityType.FLAG.value,
        description="Flag activity",
    )
    object: None | str | APObject = Field(default=None, description="The object being flagged")


class APOffer(APActivity):
    """
    Represents a Offer activity in ActivityPub.
    Indicates that the actor is offering the object.
    If specified, the target indicates the entity to which the object is being offered.

    Specification: https://www.w3.org/ns/activitystreams#Offer
    """

    object: None | str | APObject = Field(default=None, description="The object being offered")
    target: None | str | SerializeAsAny[APObject] | list[SerializeAsAny[APObject]] = Field(
        default=None, description="The target the object is offered to"
    )


class APInvite(APOffer):
    """
    Represents a Invite activity in ActivityPub.
    A specialization of Offer in which the actor is extending an invitation for the object to the target.

    Specification: https://www.w3.org/ns/activitystreams#Invite
    """

    object: None | str | APObject = Field(default=None, description="The object being invited")
    target: None | str | SerializeAsAny[APObject] | list[SerializeAsAny[APObject]] = Field(
        default=None, description="The target the object is invited to"
    )


class APView(APActivity):
    """
    Represents a View activity in ActivityPub.
    Indicates that the actor has viewed the object.

    Specification: 	https://www.w3.org/ns/activitystreams#View
    """

    type: str = Field(
        default=ActivityType.VIEW.value,
        description="Indicates that the actor has viewed the object",
    )
    object: None | str | APObject = Field(default=None, description="The object being viewed")


class APListen(APActivity):
    """
    Represents a Listen activity in ActivityPub.
    Indicates that the actor has listened to the object.

    Specification: 	https://www.w3.org/ns/activitystreams#Listen
    """

    type: str = Field(
        default=ActivityType.LISTEN.value,
        description="Indicates that the actor has listened to the object",
    )
    object: None | str | APObject = Field(default=None, description="The object being listened to")


class APRead(APActivity):
    """
    Represents a Read activity in ActivityPub.
    Indicates that the actor has read the object.

    Specification: 	https://www.w3.org/ns/activitystreams#Read
    """

    type: str = Field(
        default=ActivityType.READ.value,
        description="Indicates that the actor has read the object",
    )
    object: None | str | APObject = Field(default=None, description="The object being read")


class APLeave(APActivity):
    """
    Represents a Leave activity in ActivityPub.
    Indicates that the actor has left the object.

    Specification: 	https://www.w3.org/ns/activitystreams#Leave
    """

    type: str = Field(
        default=ActivityType.LEAVE.value,
        description="Indicates that the actor leaves a place.",
    )
    object: None | str | APObject = Field(default=None, description="The object being left")


class APJoin(APActivity):
    """
    Represents a Join activity in ActivityPub.
    Indicates that the actor has joined the object.

    Specification: 	https://www.w3.org/ns/activitystreams#Join
    """

    type: str = Field(
        default=ActivityType.LEAVE.value,
        description="Indicates that the actor leaves a place.",
    )
    object: None | str | APObject = Field(default=None, description="The object being joined")


class APMigrate(APActivity):
    """Represents a Migrate activity.

    This is not part of the official ActivityPub specification.
    It allows to migrate user accounts to new instances, or between accounts on the same instance.
    """

    type: str = Field(default=ActivityType.MIGRATE.value, description="A migrate activity")
    actor_to: ObjectId | None = Field(
        default=None,
        description="Actor to migrate to. Can be on a new instance, or on the same instance. If set to None, this can be used to download the migration data locally and use it for migration somewhere else",
    )
    accepted_at: APDateTime | None = Field(
        default=None,
        description="If the actor on the new instance has accepted the APMigrate activity. This is the last step before migration is completed",
    )


class ActivityInQueue(ActivityPubBaseWithId):
    type: str = ActivityType.ACTIVITY_IN_QUEUE.value
    activity: APActivity = Field(..., description="The activity to send")
    recipients: list[ObjectId] = Field(
        ...,
        description="The list of ids of the recipient actors. This can include the bcc/bto fields that should be removed already from the given activity",
    )
    send_at: APDateTime = Field(..., description="When to attempt to send the given activity")
