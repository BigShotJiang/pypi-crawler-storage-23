from typing import Any


def str_to_list(value: str | list[str] | None) -> list[str] | None:
    if value is None:
        return None
    if isinstance(value, str):
        return [value]
    return value


def dict_to_list(value: dict[str, Any] | list[dict[str, Any]] | None) -> list[dict[str, Any]] | None:
    if value is None:
        return None
    if isinstance(value, dict):
        return [value]
    return value
