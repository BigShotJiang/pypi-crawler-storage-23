"""
version.py
Contains the version string of the current instance.
Useful for UserAgent, and database migration.
"""

import os
from typing import cast

import toml

pyproject_toml_path = "pyproject.toml"
if os.path.exists(pyproject_toml_path):
    with open(pyproject_toml_path, "r") as f:
        pyproject_toml = toml.load(f)
        version_string = cast(str, pyproject_toml["project"]["version"])
else:
    version_string = "0.4"

PHEDERATION_SOFTWARE_HOMEPAGE = "https://codeberg.org/feldie/phederation"
PHEDERATION_SOFTWARE_NAME = "phederation"
PHEDERATION_VERSION = version_string
PHEDERATION_USERAGENT = f"{PHEDERATION_SOFTWARE_NAME}/{PHEDERATION_VERSION}"

PHEDERATION_HEADERS = {
    "Content-Type": 'application/ld+json; profile="https://www.w3.org/ns/activitystreams"',
    "User-Agent": PHEDERATION_USERAGENT,
    "Accept": "application/activity+json"
}