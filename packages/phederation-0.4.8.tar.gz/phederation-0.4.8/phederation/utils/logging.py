# logging.py

"""
Uses the [python `logging` facility](https://docs.python.org/3/library/logging.html) to set up loggers for all classes.
The configuration file is stored separately in `settings/logging.yaml` and defines where the log output is being written to.
"""

import logging
from typing import override


class InstanceFilter(logging.Filter):
    def __init__(self, error_only: list[str], logging_prefix: str | None = None, name: str = "") -> None:
        super().__init__(name)
        self.logging_prefix: str | None = logging_prefix
        self.error_only: list[str] = error_only

    @override
    def filter(self, record: logging.LogRecord):
        for check in self.error_only:
            if record.name.endswith(check) and record.levelno < logging.ERROR:
                return False
        return (record.name.split("|")[0].startswith(self.logging_prefix)) if self.logging_prefix else True


def configure_logger(name: str, prefix: str = "phederation") -> logging.Logger:
    """
    Get a logger with the specified name.

    Args:
        name (str): The name of the logger, typically __name__ of the module.
        prefix (str): the prefix to use for the logger name. Default "phederation"

    Returns:
        logging.Logger: A logger instance.
    """
    return logging.getLogger(f"{prefix}|{name}")
