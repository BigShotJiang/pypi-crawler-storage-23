"""Collection handler.

Implements managers for ActivityPub collections, like followers, blocks, likes, etc.
"""

from .collections import CollectionManager

__all__ = ["CollectionManager"]
