"""Allow running code-maat-python as a module with python -m code_maat_python"""
from code_maat_python.cli import main

if __name__ == "__main__":
    main()
