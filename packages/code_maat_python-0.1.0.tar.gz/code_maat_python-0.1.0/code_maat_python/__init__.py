"""
code-maat-python: Modern Python tool for mining VCS data with pandas.

A rewrite of Code Maat (by Adam Tornhill) using pandas for data analysis.
"""

__version__ = "0.1.0"
__author__ = "Cameron Yick"
__license__ = "GPL-3.0"

# Version info
VERSION = __version__
