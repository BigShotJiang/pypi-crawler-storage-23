"""Git log parser for code-maat-python.

Parses git log output into pandas DataFrames for analysis.
"""

from dataclasses import dataclass
from pathlib import Path
from typing import Iterator, TextIO

import pandas as pd
import re


@dataclass
class CommitRecord:
    """Represents a single commit with file changes."""

    rev: str
    date: str
    author: str
    entity: str
    loc_added: int
    loc_deleted: int


class GitLogSchema:
    """Defines the DataFrame schema for parsed git logs."""

    # Column names
    REV = "rev"
    DATE = "date"
    AUTHOR = "author"
    ENTITY = "entity"
    LOC_ADDED = "loc_added"
    LOC_DELETED = "loc_deleted"

    # Column types for optimization
    DTYPES = {
        REV: "category",
        AUTHOR: "category",
        ENTITY: "category",
        LOC_ADDED: "int32",
        LOC_DELETED: "int32",
    }

    @classmethod
    def columns(cls) -> list[str]:
        """Return ordered list of column names."""
        return [cls.REV, cls.DATE, cls.AUTHOR, cls.ENTITY, cls.LOC_ADDED, cls.LOC_DELETED]

    @classmethod
    def create_empty_dataframe(cls) -> pd.DataFrame:
        """Create an empty DataFrame with the correct schema."""
        df = pd.DataFrame(columns=cls.columns())
        df[cls.DATE] = pd.to_datetime(df[cls.DATE])
        return df


class GitLogParser:
    """Parser for git log output.

    Parses output from:
        git log --all -M -C --numstat --date=short --pretty=format:'--%h--%cd--%cn'
    """

    # Regex patterns
    COMMIT_PATTERN = re.compile(r"^--([a-f0-9]+)--(\d{4}-\d{2}-\d{2})--(.*)$")
    CHANGE_PATTERN = re.compile(r"^(\d+|-)\t(\d+|-)\t(.+)$")

    def __init__(self) -> None:
        """Initialize the parser."""
        self._current_commit: dict[str, str] | None = None
        self._records: list[CommitRecord] = []

    def parse_file(self, filepath: Path | str) -> pd.DataFrame:
        """Parse a git log file.

        Args:
            filepath: Path to the git log file

        Returns:
            DataFrame with columns: rev, date, author, entity, loc_added, loc_deleted

        Raises:
            FileNotFoundError: If the file doesn't exist
            ValueError: If the file format is invalid
        """
        filepath = Path(filepath)
        if not filepath.exists():
            raise FileNotFoundError(f"Git log file not found: {filepath}")

        with open(filepath, "r", encoding="utf-8") as f:
            return self.parse_stream(f)

    def parse_stream(self, stream: TextIO) -> pd.DataFrame:
        """Parse a git log from a stream.

        Args:
            stream: Text stream (file object) containing git log

        Returns:
            DataFrame with parsed commit data
        """
        self._current_commit = None
        self._records = []

        for line_num, line in enumerate(stream, start=1):
            line = line.strip()

            # Skip empty lines
            if not line:
                continue

            # Try to parse as commit header
            if self._try_parse_commit(line):
                continue

            # Try to parse as file change
            if self._try_parse_change(line, line_num):
                continue

            # If we get here, the line didn't match any pattern
            # This might be okay (e.g., continuation of author name with newline)
            # But we should warn if it looks like data
            if line.strip() and not line.startswith(" "):
                print(f"Warning: Unparsed line {line_num}: {line[:50]}")

        return self._to_dataframe()

    def _try_parse_commit(self, line: str) -> bool:
        """Try to parse line as commit header.

        Args:
            line: Line from git log

        Returns:
            True if line was a commit header, False otherwise
        """
        match = self.COMMIT_PATTERN.match(line)
        if match:
            self._current_commit = {
                "rev": match.group(1),
                "date": match.group(2),
                "author": match.group(3).strip(),
            }
            return True
        return False

    def _try_parse_change(self, line: str, line_num: int) -> bool:
        """Try to parse line as file change.

        Args:
            line: Line from git log
            line_num: Line number (for error reporting)

        Returns:
            True if line was a file change, False otherwise
        """
        match = self.CHANGE_PATTERN.match(line)
        if match and self._current_commit:
            # Parse added/deleted, handling binary files (-)
            loc_added = 0 if match.group(1) == "-" else int(match.group(1))
            loc_deleted = 0 if match.group(2) == "-" else int(match.group(2))
            entity = match.group(3)

            record = CommitRecord(
                rev=self._current_commit["rev"],
                date=self._current_commit["date"],
                author=self._current_commit["author"],
                entity=entity,
                loc_added=loc_added,
                loc_deleted=loc_deleted,
            )
            self._records.append(record)
            return True

        if match and not self._current_commit:
            print(f"Warning: File change without commit header at line {line_num}")
            return False

        return False

    def _to_dataframe(self) -> pd.DataFrame:
        """Convert parsed records to DataFrame.

        Returns:
            DataFrame with proper schema and types
        """
        if not self._records:
            return GitLogSchema.create_empty_dataframe()

        # Convert records to dict
        data = {
            GitLogSchema.REV: [r.rev for r in self._records],
            GitLogSchema.DATE: [r.date for r in self._records],
            GitLogSchema.AUTHOR: [r.author for r in self._records],
            GitLogSchema.ENTITY: [r.entity for r in self._records],
            GitLogSchema.LOC_ADDED: [r.loc_added for r in self._records],
            GitLogSchema.LOC_DELETED: [r.loc_deleted for r in self._records],
        }

        df = pd.DataFrame(data)

        # Convert date to datetime
        df[GitLogSchema.DATE] = pd.to_datetime(df[GitLogSchema.DATE])

        # Apply categorical types for memory efficiency
        df[GitLogSchema.REV] = df[GitLogSchema.REV].astype("category")
        df[GitLogSchema.AUTHOR] = df[GitLogSchema.AUTHOR].astype("category")
        df[GitLogSchema.ENTITY] = df[GitLogSchema.ENTITY].astype("category")

        return df


# Convenience function
def parse_git_log(filepath: Path | str) -> pd.DataFrame:
    """Parse a git log file.

    Convenience function for quick parsing.

    Args:
        filepath: Path to git log file

    Returns:
        DataFrame with parsed commit data

    Example:
        >>> df = parse_git_log("git.log")
        >>> print(df.head())
    """
    parser = GitLogParser()
    return parser.parse_file(filepath)
