"""Data pipeline utilities for code-maat-python.

Provides utilities for transforming and filtering DataFrames between
parsing and analysis stages.
"""

import pandas as pd
from pathlib import Path
from typing import Callable

from code_maat_python.parser import parse_git_log, GitLogSchema


def load_git_log(filepath: Path | str) -> pd.DataFrame:
    """Load and parse a git log file.

    Convenience function that wraps the parser.

    Args:
        filepath: Path to git log file

    Returns:
        Parsed DataFrame

    Raises:
        FileNotFoundError: If file doesn't exist
    """
    return parse_git_log(filepath)


def filter_by_date(
    df: pd.DataFrame, start_date: str | None = None, end_date: str | None = None
) -> pd.DataFrame:
    """Filter DataFrame by date range.

    Args:
        df: Input DataFrame
        start_date: Start date (YYYY-MM-DD) or None for no start limit
        end_date: End date (YYYY-MM-DD) or None for no end limit

    Returns:
        Filtered DataFrame

    Example:
        >>> df_filtered = filter_by_date(df, start_date="2023-01-01")
    """
    result = df.copy()

    if start_date:
        start = pd.to_datetime(start_date)
        result = result[result[GitLogSchema.DATE] >= start]

    if end_date:
        end = pd.to_datetime(end_date)
        result = result[result[GitLogSchema.DATE] <= end]

    return result


def filter_by_entity_pattern(df: pd.DataFrame, pattern: str) -> pd.DataFrame:
    """Filter DataFrame by entity path pattern.

    Args:
        df: Input DataFrame
        pattern: Regex pattern to match against entity paths

    Returns:
        Filtered DataFrame

    Example:
        >>> df_py = filter_by_entity_pattern(df, r".*\\.py$")
    """
    mask = df[GitLogSchema.ENTITY].str.contains(pattern, na=False, regex=True)
    return df[mask].copy()


def apply_transformation(
    df: pd.DataFrame, transform_fn: Callable[[pd.DataFrame], pd.DataFrame]
) -> pd.DataFrame:
    """Apply a transformation function to DataFrame.

    Generic utility for applying transformations in pipeline.

    Args:
        df: Input DataFrame
        transform_fn: Function that takes and returns a DataFrame

    Returns:
        Transformed DataFrame
    """
    return transform_fn(df)


def validate_dataframe(df: pd.DataFrame) -> None:
    """Validate that DataFrame has required columns and types.

    Args:
        df: DataFrame to validate

    Raises:
        ValueError: If DataFrame is invalid
    """
    required_cols = set(GitLogSchema.columns())
    actual_cols = set(df.columns)

    if not required_cols.issubset(actual_cols):
        missing = required_cols - actual_cols
        raise ValueError(f"DataFrame missing required columns: {missing}")

    # Check date column is datetime
    if not pd.api.types.is_datetime64_any_dtype(df[GitLogSchema.DATE]):
        raise ValueError(f"Column '{GitLogSchema.DATE}' must be datetime type")
