"""Mathematical utilities for analyses."""

from typing import Union

Number = Union[int, float]


def percentage(value: Number, total: Number) -> float:
    """Calculate percentage.

    Args:
        value: Numerator value
        total: Denominator value

    Returns:
        Percentage as float (0-100 range)

    Raises:
        ValueError: If total is zero

    Example:
        >>> percentage(25, 100)
        25.0
    """
    if total == 0:
        raise ValueError("Cannot calculate percentage with zero total")
    return (value / total) * 100.0


def average(*values: Number) -> float:
    """Calculate average of values.

    Args:
        *values: Variable number of numeric values

    Returns:
        Average as float

    Raises:
        ValueError: If no values provided

    Example:
        >>> average(10, 20, 30)
        20.0
    """
    if not values:
        raise ValueError("Cannot calculate average of zero values")
    return sum(values) / len(values)


def fractal_value(contributions: list[Number]) -> float:
    """Calculate fractal fragmentation value.

    The fractal value measures how fragmented contributions are across
    contributors. Formula: FV = 1 - Σ(ai/nc)²

    Args:
        contributions: List of contribution counts per contributor

    Returns:
        Fractal value in range [0, 1)
        - 0: Single contributor (no fragmentation)
        - →1: Highly fragmented across many contributors

    Raises:
        ValueError: If contributions list is empty

    Example:
        >>> fractal_value([100])  # Single contributor
        0.0
        >>> fractal_value([50, 50])  # Two equal contributors
        0.5
        >>> fractal_value([33, 33, 34])  # Three ~equal contributors
        0.6667
    """
    if not contributions:
        raise ValueError("Cannot calculate fractal value with no contributions")

    total = sum(contributions)
    if total == 0:
        return 0.0

    return 1.0 - sum((count / total) ** 2 for count in contributions)


def clamp(value: Number, min_value: Number, max_value: Number) -> Number:
    """Clamp value to range [min_value, max_value].

    Args:
        value: Value to clamp
        min_value: Minimum allowed value
        max_value: Maximum allowed value

    Returns:
        Clamped value

    Example:
        >>> clamp(150, 0, 100)
        100
        >>> clamp(-10, 0, 100)
        0
        >>> clamp(50, 0, 100)
        50
    """
    return max(min_value, min(value, max_value))
