r"""Architectural grouper for mapping entities to logical boundaries.

This module provides functionality to map physical file paths to logical
architectural groups (layers, components, subsystems) before analysis.

Grouping is specified via text files with two pattern types:
1. Plain text paths: "src/Features/Core => Core"
   - Automatically converted to regex: ^src/Features/Core/
2. Explicit regex: r"^src\/.*Test.*$ => Tests"
   - Used as-is for flexible matching

First matching pattern wins (order matters). Unmapped entities are filtered out.
"""

import re
from dataclasses import dataclass
from pathlib import Path
from re import Pattern

import pandas as pd

from code_maat_python.parser import GitLogSchema


@dataclass
class GroupPattern:
    """A compiled grouping pattern.

    Attributes:
        pattern: Compiled regex pattern to match entity paths
        logical_name: Logical group name to map to
    """

    pattern: Pattern[str]
    logical_name: str


def parse_group_specification(spec: str) -> list[GroupPattern]:
    """Parse a grouping specification into compiled patterns.

    The specification format is:
        path_pattern => logical_name

    Where path_pattern can be:
    - Plain text path (e.g., "src/Core") - auto-converted to ^src/Core/
    - Explicit regex (e.g., r"^src\\/.*Test.*$") - used as-is

    Args:
        spec: Multi-line string with grouping specifications

    Returns:
        List of compiled GroupPattern objects in specification order

    Raises:
        ValueError: If specification format is invalid or regex won't compile

    Examples:
        >>> spec = "src/Core => Core\\n^src\\\\/.*Test.*$ => Tests"
        >>> patterns = parse_group_specification(spec)
        >>> len(patterns)
        2
    """
    patterns: list[GroupPattern] = []

    for line_num, line in enumerate(spec.split("\n"), start=1):
        # Skip empty lines and whitespace
        line = line.strip()
        if not line:
            continue

        # Check for separator
        if "=>" not in line:
            raise ValueError(
                f"Invalid group specification at line {line_num}: "
                f"Missing '=>' separator. Line: '{line}'"
            )

        # Split on separator
        parts = line.split("=>", maxsplit=1)
        if len(parts) != 2:
            raise ValueError(
                f"Invalid group specification at line {line_num}: "
                f"Expected 'pattern => name' format. Line: '{line}'"
            )

        path_pattern = parts[0].strip()
        logical_name = parts[1].strip()

        if not path_pattern or not logical_name:
            raise ValueError(
                f"Invalid group specification at line {line_num}: "
                f"Pattern and name cannot be empty. Line: '{line}'"
            )

        # Determine pattern type and compile
        try:
            if path_pattern.startswith("^"):
                # Explicit regex pattern - use as-is
                compiled_pattern = re.compile(path_pattern)
            else:
                # Plain text path - convert to regex with trailing /
                # Escape special regex characters, then add ^ and /
                escaped = re.escape(path_pattern)
                regex_str = f"^{escaped}/"
                compiled_pattern = re.compile(regex_str)
        except re.error as e:
            raise ValueError(
                f"Invalid regex pattern at line {line_num}: {path_pattern}. " f"Error: {str(e)}"
            ) from e

        patterns.append(GroupPattern(pattern=compiled_pattern, logical_name=logical_name))

    return patterns


def map_entities_to_groups(df: pd.DataFrame, patterns: list[GroupPattern]) -> pd.DataFrame:
    """Map entity names to logical groups based on patterns.

    Applies patterns in order, using first match. Entities that don't match
    any pattern are filtered out (not passed through).

    Args:
        df: DataFrame with GitLogSchema columns
        patterns: List of compiled GroupPattern objects

    Returns:
        DataFrame with entity names replaced by logical group names.
        Only includes rows where entity matched a pattern.

    Examples:
        >>> data = [{"entity": "src/Core/file.py", "author": "Alice", ...}]
        >>> df = pd.DataFrame(data)
        >>> spec = "src/Core => Core"
        >>> patterns = parse_group_specification(spec)
        >>> result = map_entities_to_groups(df, patterns)
        >>> result.iloc[0]["entity"]
        'Core'
    """
    # Handle empty inputs
    if df.empty:
        # Return empty DataFrame with correct schema
        return GitLogSchema.create_empty_dataframe()

    if not patterns:
        # No patterns = filter out everything
        empty_df = df.iloc[:0].copy()
        return empty_df

    # Map each entity to its logical group (or None if no match)
    def find_logical_group(entity: str) -> str | None:
        """Find the first matching logical group for an entity."""
        for group_pattern in patterns:
            if group_pattern.pattern.match(entity):
                return group_pattern.logical_name
        return None

    # Apply mapping
    entity_col = GitLogSchema.ENTITY
    df_copy = df.copy()
    df_copy["_logical_group"] = df_copy[entity_col].apply(find_logical_group)

    # Filter out unmapped entities
    df_filtered = df_copy[df_copy["_logical_group"].notna()].copy()

    # Replace entity column with logical group
    if not df_filtered.empty:
        df_filtered[entity_col] = df_filtered["_logical_group"]

    # Drop the temporary column
    df_filtered = df_filtered.drop(columns=["_logical_group"])

    return df_filtered


def load_group_specification_file(filepath: Path | str) -> list[GroupPattern]:
    """Load and parse a grouping specification file.

    Convenience function that reads a file and parses its contents.

    Args:
        filepath: Path to grouping specification file

    Returns:
        List of compiled GroupPattern objects

    Raises:
        FileNotFoundError: If file doesn't exist
        ValueError: If file contents are invalid

    Example:
        >>> patterns = load_group_specification_file("layers.txt")
        >>> len(patterns) > 0
        True
    """
    filepath = Path(filepath)

    if not filepath.exists():
        raise FileNotFoundError(f"Group specification file not found: {filepath}")

    if not filepath.is_file():
        raise ValueError(f"Not a file: {filepath}")

    spec = filepath.read_text(encoding="utf-8")
    return parse_group_specification(spec)
