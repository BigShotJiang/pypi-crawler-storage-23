"""Team mapper for aggregating author contributions to team level.

This module provides functionality to map individual authors to teams, allowing
analysis at the organizational team level rather than individual contributor level.

Team mappings are specified via CSV files with format:
    author,team
    John Doe,Backend Team
    Jane Smith,Backend Team

Authors not in the mapping are preserved as-is (treated as individual "teams"),
which allows detection of missing mappings rather than silent data loss.
"""

from io import StringIO
from pathlib import Path

import pandas as pd

from code_maat_python.parser import GitLogSchema


def parse_team_mapping_csv(csv_content: str) -> dict[str, str]:
    """Parse a team mapping CSV into author->team dictionary.

    The CSV format expected:
        author,team
        John Doe,Backend Team
        Jane Smith,Frontend Team

    Args:
        csv_content: CSV string with author,team columns

    Returns:
        Dictionary mapping author names to team names

    Raises:
        ValueError: If CSV is missing required columns

    Examples:
        >>> csv = "author,team\\nAlice,Backend\\nBob,Frontend"
        >>> mapping = parse_team_mapping_csv(csv)
        >>> mapping["Alice"]
        'Backend'
    """
    # Parse CSV (keep_default_na=False to preserve empty strings)
    df = pd.read_csv(StringIO(csv_content), keep_default_na=False)

    # Validate required columns
    required_cols = {"author", "team"}
    if not required_cols.issubset(set(df.columns)):
        missing = required_cols - set(df.columns)
        raise ValueError(
            f"Missing required columns in team mapping CSV: {missing}. "
            f"Expected columns: {required_cols}, got: {set(df.columns)}"
        )

    # Build author->team lookup dictionary
    # If there are duplicates, last one wins (pandas default behavior)
    # strict=False allows different lengths (though they should match in valid CSV)
    mapping = dict(zip(df["author"], df["team"], strict=False))

    return mapping


def map_authors_to_teams(df: pd.DataFrame, team_mapping: dict[str, str]) -> pd.DataFrame:
    """Map author names to team names based on mapping.

    Authors not in the mapping are preserved as-is (not filtered out).
    This allows detection of missing mappings.

    Args:
        df: DataFrame with GitLogSchema columns
        team_mapping: Dictionary mapping author names to team names

    Returns:
        DataFrame with author column replaced by team names.
        Authors not in mapping are kept unchanged.

    Examples:
        >>> data = [{"entity": "file.py", "author": "Alice", ...}]
        >>> df = pd.DataFrame(data)
        >>> mapping = {"Alice": "Backend Team"}
        >>> result = map_authors_to_teams(df, mapping)
        >>> result.iloc[0]["author"]
        'Backend Team'
    """
    # Handle empty inputs
    if df.empty:
        return GitLogSchema.create_empty_dataframe()

    # Make a copy to avoid modifying original
    result = df.copy()

    # Map authors to teams, preserving unmapped authors
    # Using .get(author, author) keeps original if not in mapping
    author_col = GitLogSchema.AUTHOR
    result[author_col] = result[author_col].map(lambda author: team_mapping.get(author, author))

    return result


def load_team_mapping_file(filepath: Path | str) -> dict[str, str]:
    """Load and parse a team mapping CSV file.

    Convenience function that reads a file and parses its contents.

    Args:
        filepath: Path to team mapping CSV file

    Returns:
        Dictionary mapping author names to team names

    Raises:
        FileNotFoundError: If file doesn't exist
        ValueError: If file is invalid or missing required columns

    Example:
        >>> mapping = load_team_mapping_file("teams.csv")
        >>> "Alice" in mapping
        True
    """
    filepath = Path(filepath)

    if not filepath.exists():
        raise FileNotFoundError(f"Team mapping file not found: {filepath}")

    if not filepath.is_file():
        raise ValueError(f"Not a file: {filepath}")

    csv_content = filepath.read_text(encoding="utf-8")
    return parse_team_mapping_csv(csv_content)
