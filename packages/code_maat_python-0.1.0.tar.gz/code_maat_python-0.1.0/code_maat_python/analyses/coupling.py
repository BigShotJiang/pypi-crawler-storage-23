"""Logical coupling analysis for code-maat-python.

Calculate logical coupling between files based on co-change frequency.
"""

from collections import Counter
from itertools import combinations

import pandas as pd

from code_maat_python.parser import GitLogSchema


def analyze_coupling(
    df: pd.DataFrame,
    min_revs: int = 5,
    min_shared_revs: int = 5,
    min_coupling: int = 30,
    max_coupling: int = 100,
    max_changeset_size: int = 30,
) -> pd.DataFrame:
    """Calculate logical coupling between files.

    Logical coupling identifies files that frequently change together,
    which may indicate hidden dependencies, architectural issues, or
    related functionality that should be refactored together.

    Algorithm (from PYTHON_MIGRATION_PLAN.md lines 99-296):
    1. Group commits by revision
    2. Filter out large commits (> max_changeset_size files) BEFORE processing
    3. Generate all 2-combinations of files per commit using itertools.combinations
    4. Count co-occurrence frequencies
    5. Calculate coupling degree: (shared_revs / avg_revs) * 100
    6. Apply thresholds: min_revs, min_shared_revs, min_coupling, max_coupling

    Critical notes:
    - Large commits must be filtered BEFORE generating pairs (performance)
    - Use itertools.combinations(files, 2) for efficiency
    - Duplicate pairs are automatically handled by combinations (A,B) not (B,A)
    - Average revisions = (entity1_revs + entity2_revs) / 2

    Args:
        df: DataFrame with columns: entity, rev, author, date, loc_added, loc_deleted
        min_revs: Minimum average number of revisions for both modules (default: 5)
        min_shared_revs: Minimum shared revisions between modules (default: 5)
        min_coupling: Minimum coupling percentage threshold (default: 30)
        max_coupling: Maximum coupling percentage threshold (default: 100)
        max_changeset_size: Maximum number of files in a commit to consider (default: 30)

    Returns:
        DataFrame with columns:
            - entity: First file in the coupled pair
            - coupled: Second file in the coupled pair
            - degree: Coupling degree as integer percentage (0-100)
            - average-revs: Average number of revisions as integer
        Sorted by degree descending, then by entity and coupled names.

    Example:
        >>> data = [
        ...     {'entity': 'src/main.py', 'rev': '1', 'author': 'Alice', 'date': '2023-01-01'},
        ...     {'entity': 'src/utils.py', 'rev': '1', 'author': 'Alice', 'date': '2023-01-01'},
        ...     {'entity': 'src/main.py', 'rev': '2', 'author': 'Bob', 'date': '2023-01-02'},
        ...     {'entity': 'src/utils.py', 'rev': '2', 'author': 'Bob', 'date': '2023-01-02'},
        ... ]
        >>> df = pd.DataFrame(data)
        >>> result = analyze_coupling(df, min_revs=1, min_shared_revs=1, min_coupling=50)
        >>> print(result)
                 entity        coupled  degree  average-revs
        0   src/main.py  src/utils.py     100             2
    """
    # Handle empty DataFrame
    if df.empty:
        return pd.DataFrame(columns=["entity", "coupled", "degree", "average-revs"])

    # 1. Filter large commits BEFORE processing (critical for performance)
    commit_sizes = df.groupby(GitLogSchema.REV, observed=True)[GitLogSchema.ENTITY].count()
    valid_revs = commit_sizes[commit_sizes <= max_changeset_size].index
    df_filtered = df[df[GitLogSchema.REV].isin(valid_revs)]

    if df_filtered.empty:
        return pd.DataFrame(columns=["entity", "coupled", "degree", "average-revs"])

    # 2. Generate file pairs per commit using itertools.combinations
    pairs: list[tuple[str, str]] = []
    for rev, group in df_filtered.groupby(GitLogSchema.REV, observed=True):
        files = sorted(group[GitLogSchema.ENTITY].unique())
        if len(files) >= 2:
            # Generate all 2-combinations (automatically handles duplicates)
            pairs.extend(combinations(files, 2))

    if not pairs:
        return pd.DataFrame(columns=["entity", "coupled", "degree", "average-revs"])

    # 3. Count co-occurrences
    pair_counts = Counter(pairs)

    # 4. Count revisions per module
    module_revs = (
        df_filtered.groupby(GitLogSchema.ENTITY, observed=True)[GitLogSchema.REV]
        .nunique()
        .to_dict()
    )

    # 5. Calculate coupling degree and apply thresholds
    results = []
    for (entity1, entity2), shared_revs in pair_counts.items():
        entity1_revs = module_revs[entity1]
        entity2_revs = module_revs[entity2]
        avg_revs = (entity1_revs + entity2_revs) / 2.0
        coupling = (shared_revs / avg_revs) * 100.0

        # 6. Apply all thresholds
        if (
            avg_revs >= min_revs
            and shared_revs >= min_shared_revs
            and min_coupling <= coupling <= max_coupling
        ):
            results.append(
                {
                    "entity": entity1,
                    "coupled": entity2,
                    "degree": int(coupling),
                    "average-revs": int(avg_revs),
                }
            )

    if not results:
        return pd.DataFrame(columns=["entity", "coupled", "degree", "average-revs"])

    # Sort by degree descending, then by entity and coupled names
    result_df = pd.DataFrame(results)
    result_df = result_df.sort_values(
        ["degree", "entity", "coupled"], ascending=[False, True, True]
    )

    return result_df.reset_index(drop=True)
