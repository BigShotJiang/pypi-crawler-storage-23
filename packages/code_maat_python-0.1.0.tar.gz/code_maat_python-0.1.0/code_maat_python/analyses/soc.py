"""Sum of Coupling (SOC) analysis for code-maat-python.

Calculate sum of coupling for each entity based on commit size.
"""

import pandas as pd

from code_maat_python.parser import GitLogSchema


def analyze_soc(df: pd.DataFrame, max_changeset_size: int = 30) -> pd.DataFrame:
    """Calculate sum of coupling (SOC) for each entity.

    Sum of Coupling provides a simpler metric than full logical coupling
    analysis. For each commit with m files, each file gets a SOC score
    of (m-1). This measures how often a file changes with other files,
    without tracking which specific files it changes with.

    Algorithm:
    1. Filter out large commits (> max_changeset_size files)
    2. For each commit, calculate commit size (number of files)
    3. For each entity in a commit, add (commit_size - 1) to its SOC score
    4. Sum all contributions per entity

    This is simpler and faster than full coupling analysis, making it
    useful for validating the data pipeline.

    Args:
        df: DataFrame with columns: entity, rev, author, date, loc_added, loc_deleted
        max_changeset_size: Maximum number of files in a commit to consider (default: 30)

    Returns:
        DataFrame with columns:
            - entity: File or module path
            - soc: Sum of coupling score (integer)
        Sorted by soc descending, then by entity name.

    Example:
        >>> data = [
        ...     {'entity': 'src/main.py', 'rev': '1', 'author': 'Alice', 'date': '2023-01-01'},
        ...     {'entity': 'src/utils.py', 'rev': '1', 'author': 'Alice', 'date': '2023-01-01'},
        ...     {'entity': 'src/test.py', 'rev': '2', 'author': 'Bob', 'date': '2023-01-02'},
        ... ]
        >>> df = pd.DataFrame(data)
        >>> result = analyze_soc(df)
        >>> print(result)
                  entity  soc
        0    src/main.py    1
        1   src/utils.py    1
        2    src/test.py    0
        # main.py and utils.py were in a commit together (m=2), so each gets soc=1
        # test.py was alone (m=1), so gets soc=0
    """
    # Handle empty DataFrame
    if df.empty:
        return pd.DataFrame(columns=["entity", "soc"])

    # Filter large commits BEFORE processing
    commit_sizes = df.groupby(GitLogSchema.REV, observed=True)[GitLogSchema.ENTITY].count()
    valid_revs = commit_sizes[commit_sizes <= max_changeset_size].index
    df_filtered = df[df[GitLogSchema.REV].isin(valid_revs)].copy()

    if df_filtered.empty:
        return pd.DataFrame(columns=["entity", "soc"])

    # Calculate commit sizes and map to each row
    commit_size_map = (
        df_filtered.groupby(GitLogSchema.REV, observed=True)[GitLogSchema.ENTITY]
        .count()
        .to_dict()
    )

    # Calculate SOC contribution for each entity occurrence
    # For each occurrence of entity in a commit, add (commit_size - 1)
    df_filtered["commit_size"] = df_filtered[GitLogSchema.REV].map(commit_size_map).astype(int)
    df_filtered["soc_contribution"] = df_filtered["commit_size"] - 1

    # Sum contributions per entity
    result = (
        df_filtered.groupby(GitLogSchema.ENTITY, observed=True)["soc_contribution"]
        .sum()
        .reset_index()
        .rename(columns={"soc_contribution": "soc"})
    )

    # Convert to integer and sort
    result["soc"] = result["soc"].astype(int)
    result = result.sort_values(["soc", "entity"], ascending=[False, True])

    return result.reset_index(drop=True)
