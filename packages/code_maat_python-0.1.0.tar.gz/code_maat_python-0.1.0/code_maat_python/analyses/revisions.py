"""Revision frequency analysis for code-maat-python.

Analyzes and sorts entities by their revision frequency.
"""

import pandas as pd

from code_maat_python.parser import GitLogSchema


def analyze_revisions(df: pd.DataFrame) -> pd.DataFrame:
    """Sort entities by revision frequency.

    Counts the number of times each entity has been revised and sorts
    by frequency in descending order. This helps identify the most
    frequently changed files in a codebase.

    Args:
        df: DataFrame with columns: entity, rev, author, date, loc_added, loc_deleted

    Returns:
        DataFrame with columns:
            - entity: File or module path
            - n-revs: Number of revisions
        Sorted by n-revs descending, then by entity name.

    Example:
        >>> data = [
        ...     {'entity': 'src/main.py', 'rev': '1', 'author': 'Alice', 'date': '2023-01-01'},
        ...     {'entity': 'src/main.py', 'rev': '2', 'author': 'Bob', 'date': '2023-01-02'},
        ...     {'entity': 'src/main.py', 'rev': '3', 'author': 'Alice', 'date': '2023-01-03'},
        ...     {'entity': 'src/utils.py', 'rev': '1', 'author': 'Alice', 'date': '2023-01-01'},
        ... ]
        >>> df = pd.DataFrame(data)
        >>> result = analyze_revisions(df)
        >>> print(result)
                  entity  n-revs
        0    src/main.py       3
        1   src/utils.py       1
    """
    # Handle empty DataFrame
    if df.empty:
        return pd.DataFrame(columns=["entity", "n-revs"])

    # Count unique revisions per entity
    result = (
        df.groupby(GitLogSchema.ENTITY, observed=True)[GitLogSchema.REV]
        .nunique()
        .reset_index()
    )
    result.columns = ["entity", "n-revs"]

    # Sort by revision count descending, then by entity name
    result = result.sort_values(by=["n-revs", "entity"], ascending=[False, True])

    return result.reset_index(drop=True)
