"""Author analysis for code-maat-python.

Analyzes distinct authors per entity with revision counts.
"""

import pandas as pd

from code_maat_python.parser import GitLogSchema


def analyze_authors(df: pd.DataFrame) -> pd.DataFrame:
    """Count distinct authors per entity with revision counts.

    Identifies how many authors have worked on each entity and how
    many revisions each entity has undergone.

    Args:
        df: DataFrame with columns: entity, rev, author, date, loc_added, loc_deleted

    Returns:
        DataFrame with columns:
            - entity: File or module path
            - n-authors: Number of distinct authors
            - n-revs: Number of revisions

    Example:
        >>> data = [
        ...     {'entity': 'src/main.py', 'rev': '1', 'author': 'Alice', 'date': '2023-01-01'},
        ...     {'entity': 'src/main.py', 'rev': '2', 'author': 'Bob', 'date': '2023-01-02'},
        ...     {'entity': 'src/utils.py', 'rev': '1', 'author': 'Alice', 'date': '2023-01-01'},
        ... ]
        >>> df = pd.DataFrame(data)
        >>> result = analyze_authors(df)
        >>> print(result)
                  entity  n-authors  n-revs
        0    src/main.py          2       2
        1   src/utils.py          1       1
    """
    # Handle empty DataFrame
    if df.empty:
        return pd.DataFrame(columns=["entity", "n-authors", "n-revs"])

    # Group by entity and calculate metrics
    result = (
        df.groupby(GitLogSchema.ENTITY, observed=True)
        .agg(
            **{
                "n-authors": (GitLogSchema.AUTHOR, "nunique"),
                "n-revs": (GitLogSchema.REV, "nunique"),
            }
        )
        .reset_index()
    )

    # Sort by number of authors descending, then by entity name
    result = result.sort_values(
        by=["n-authors", GitLogSchema.ENTITY], ascending=[False, True]
    )

    return result.reset_index(drop=True)
