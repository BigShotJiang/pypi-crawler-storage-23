"""Code age analysis for code-maat-python."""

import pandas as pd

from code_maat_python.parser import GitLogSchema


def code_age(df: pd.DataFrame, reference_date: pd.Timestamp | None = None) -> pd.DataFrame:
    """Calculate age of entities in months since last modification.

    This analysis helps identify stale code that hasn't been modified recently,
    which may indicate technical debt, abandoned features, or stable components.

    Args:
        df: DataFrame with GitLogSchema columns (entity, rev, author, date, loc_added, loc_deleted).
            Multiple commits to the same entity are allowed; the latest date is used.
        reference_date: Reference date for age calculation. If None, uses current date.
            Should be timezone-naive or match the timezone of dates in df.

    Returns:
        DataFrame with columns:
            - entity: File path (str)
            - age-months: Number of months since last modification (int)
        Sorted by age-months descending (oldest entities first).

        For empty input, returns empty DataFrame with correct schema.

    Raises:
        ValueError: If df doesn't have required columns (entity, date).

    Example:
        >>> import pandas as pd
        >>> from code_maat_python.analyses.age import code_age
        >>> from code_maat_python.parser import parse_git_log
        >>>
        >>> # Parse git log
        >>> df = parse_git_log("git.log")
        >>>
        >>> # Calculate age using current date
        >>> result = code_age(df)
        >>> print(result.head())
           entity           age-months
        0  legacy_file.py   24
        1  old_module.py    18
        2  stable.py        12
        >>>
        >>> # Calculate age with custom reference date
        >>> ref_date = pd.Timestamp('2023-12-31')
        >>> result = code_age(df, reference_date=ref_date)
        >>> print(result.head())
           entity           age-months
        0  legacy_file.py   18
        1  old_module.py    12

    Note:
        Age calculation uses 30.44 days per month (365.25/12) for accuracy.
        Ages are rounded to the nearest whole month.
    """
    # 1. Handle empty DataFrame
    if df.empty:
        return pd.DataFrame(columns=["entity", "age-months"])

    # 2. Validate required columns
    required_cols = {GitLogSchema.ENTITY, GitLogSchema.DATE}
    if not required_cols.issubset(df.columns):
        missing = required_cols - set(df.columns)
        raise ValueError(f"DataFrame missing required columns: {missing}")

    # 3. Set reference_date to now if None
    if reference_date is None:
        reference_date = pd.Timestamp.now()

    # 4. Ensure date column is datetime
    if not pd.api.types.is_datetime64_any_dtype(df[GitLogSchema.DATE]):
        df = df.copy()
        df[GitLogSchema.DATE] = pd.to_datetime(df[GitLogSchema.DATE])

    # 5. Find last modification date per entity (groupby + max)
    last_dates = df.groupby(GitLogSchema.ENTITY, observed=True)[GitLogSchema.DATE].max()

    # 6. Calculate age in months: (reference_date - last_date).days / 30.44
    age_days = (reference_date - last_dates).dt.days
    age_months = age_days / 30.44

    # 7. Round to nearest month and convert to int
    age_months = age_months.round().astype(int)

    # 8. Create result DataFrame
    result = pd.DataFrame(
        {
            "entity": last_dates.index,
            "age-months": age_months.values,
        }
    )

    # 9. Sort by age descending (oldest first)
    result = result.sort_values(by=["age-months"], ascending=False)

    # 10. Reset index and return with explicit column ordering
    result = result.reset_index(drop=True)
    return result[["entity", "age-months"]]
