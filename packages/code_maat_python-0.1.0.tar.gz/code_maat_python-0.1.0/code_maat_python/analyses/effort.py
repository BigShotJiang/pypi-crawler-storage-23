"""Effort analysis for code-maat-python.

Analyzes author contributions by revision count and calculates
code fragmentation metrics.
"""

import pandas as pd

from code_maat_python.parser import GitLogSchema
from code_maat_python.utils.math import fractal_value


def entity_effort(df: pd.DataFrame) -> pd.DataFrame:
    """Calculate author contribution to each entity by revision count.

    Identifies how many revisions each author contributed to each entity,
    providing a measure of effort that works for all VCS systems.

    Args:
        df: DataFrame with columns: entity, rev, author, date, loc_added, loc_deleted

    Returns:
        DataFrame with columns:
            - entity: File or module path
            - author: Author name
            - author-revs: Number of revisions by author for this entity
            - total-revs: Total revisions for this entity

    Example:
        >>> data = [
        ...     {'entity': 'main.py', 'rev': '1', 'author': 'Alice', 'date': '2023-01-01'},
        ...     {'entity': 'main.py', 'rev': '2', 'author': 'Alice', 'date': '2023-01-02'},
        ...     {'entity': 'main.py', 'rev': '3', 'author': 'Bob', 'date': '2023-01-03'},
        ... ]
        >>> df = pd.DataFrame(data)
        >>> result = entity_effort(df)
    """
    # Handle empty DataFrame
    if df.empty:
        return pd.DataFrame(columns=["entity", "author", "author-revs", "total-revs"])

    # Count revisions per entity-author combination
    entity_author_revs = (
        df.groupby([GitLogSchema.ENTITY, GitLogSchema.AUTHOR], observed=True)[GitLogSchema.REV]
        .nunique()
        .reset_index()
        .rename(columns={GitLogSchema.REV: "author-revs"})
    )

    # Count total revisions per entity
    entity_total_revs = (
        df.groupby(GitLogSchema.ENTITY, observed=True)[GitLogSchema.REV]
        .nunique()
        .reset_index()
        .rename(columns={GitLogSchema.REV: "total-revs"})
    )

    # Merge to get complete picture
    result = entity_author_revs.merge(entity_total_revs, on=GitLogSchema.ENTITY)

    # Sort by entity ascending, then by author-revs descending (stable sort)
    # This matches the Clojure implementation which uses stable sort
    result = result.sort_values(by=["author-revs"], ascending=False)  # First sort by revs
    result = result.sort_values(
        by=[GitLogSchema.ENTITY], ascending=True, kind="stable"
    )  # Then stable sort by entity

    return result.reset_index(drop=True)


def main_dev_by_revs(df: pd.DataFrame) -> pd.DataFrame:
    """Identify the main developer of each entity by revision count.

    The main developer is the author who has contributed the most revisions
    to each entity. Returns ownership percentage based on revision count.

    Args:
        df: DataFrame with columns: entity, rev, author, date, loc_added, loc_deleted

    Returns:
        DataFrame with columns:
            - entity: File or module path
            - main-dev: Primary developer name
            - added: Number of revisions by main developer
            - total-added: Total revisions for entity
            - ownership: Ownership percentage (0-100)

    Example:
        >>> data = [
        ...     {'entity': 'main.py', 'rev': '1', 'author': 'Alice', 'date': '2023-01-01'},
        ...     {'entity': 'main.py', 'rev': '2', 'author': 'Alice', 'date': '2023-01-02'},
        ...     {'entity': 'main.py', 'rev': '3', 'author': 'Bob', 'date': '2023-01-03'},
        ... ]
        >>> df = pd.DataFrame(data)
        >>> result = main_dev_by_revs(df)
    """
    # Handle empty DataFrame
    if df.empty:
        return pd.DataFrame(columns=["entity", "main-dev", "added", "total-added", "ownership"])

    # Count revisions per entity-author combination
    entity_author_revs = (
        df.groupby([GitLogSchema.ENTITY, GitLogSchema.AUTHOR], observed=True)[GitLogSchema.REV]
        .nunique()
        .reset_index()
        .rename(columns={GitLogSchema.REV: "author-revs"})
    )

    # Count total revisions per entity
    entity_total_revs = (
        df.groupby(GitLogSchema.ENTITY, observed=True)[GitLogSchema.REV]
        .nunique()
        .reset_index()
        .rename(columns={GitLogSchema.REV: "total-revs"})
    )

    # Find the author with max revisions per entity
    main_devs = (
        entity_author_revs.loc[
            entity_author_revs.groupby(GitLogSchema.ENTITY, observed=True)["author-revs"].idxmax()
        ]
        .rename(
            columns={
                GitLogSchema.AUTHOR: "main-dev",
                "author-revs": "added",
            }
        )
        .reset_index(drop=True)
    )

    # Merge with total revisions
    result = main_devs.merge(entity_total_revs, on=GitLogSchema.ENTITY)
    result = result.rename(columns={"total-revs": "total-added"})

    # Calculate ownership percentage
    result["ownership"] = (result["added"] / result["total-added"] * 100).round(2)

    # Sort by entity ascending
    result = result.sort_values(by=[GitLogSchema.ENTITY], ascending=True)

    return result.reset_index(drop=True)


def fragmentation(df: pd.DataFrame) -> pd.DataFrame:
    """Calculate fragmentation for each entity using fractal value.

    The fractal value measures how fragmented contributions are across
    authors. Formula: FV = 1 - Σ(ai/nc)²

    Args:
        df: DataFrame with columns: entity, rev, author, date, loc_added, loc_deleted

    Returns:
        DataFrame with columns:
            - entity: File or module path
            - fractal-value: Fragmentation metric (0 to <1)
              - 0: Single author (no fragmentation)
              - →1: Highly fragmented across many authors
            - total-revs: Total revisions for entity

    Example:
        >>> data = [
        ...     {'entity': 'main.py', 'rev': '1', 'author': 'Alice', 'date': '2023-01-01'},
        ...     {'entity': 'main.py', 'rev': '2', 'author': 'Alice', 'date': '2023-01-02'},
        ...     {'entity': 'utils.py', 'rev': '3', 'author': 'Alice', 'date': '2023-01-03'},
        ...     {'entity': 'utils.py', 'rev': '4', 'author': 'Bob', 'date': '2023-01-04'},
        ... ]
        >>> df = pd.DataFrame(data)
        >>> result = fragmentation(df)
    """
    # Handle empty DataFrame
    if df.empty:
        return pd.DataFrame(columns=["entity", "fractal-value", "total-revs"])

    # Count revisions per entity-author combination
    entity_author_revs = (
        df.groupby([GitLogSchema.ENTITY, GitLogSchema.AUTHOR], observed=True)[GitLogSchema.REV]
        .nunique()
        .reset_index()
        .rename(columns={GitLogSchema.REV: "author-revs"})
    )

    # Count total revisions per entity
    entity_total_revs = (
        df.groupby(GitLogSchema.ENTITY, observed=True)[GitLogSchema.REV].nunique().to_dict()
    )

    # Calculate fractal value for each entity
    results = []
    for entity, group in entity_author_revs.groupby(GitLogSchema.ENTITY, observed=True):
        contributions = group["author-revs"].tolist()
        total_revs = entity_total_revs[entity]

        # Use the fractal_value utility function
        fv = fractal_value(contributions)

        results.append(
            {
                "entity": entity,
                "fractal-value": round(fv, 2),
                "total-revs": total_revs,
            }
        )

    result = pd.DataFrame(results)

    # Sort by fractal-value descending, then by total-revs descending
    result = result.sort_values(by=["fractal-value", "total-revs"], ascending=[False, False])

    return result.reset_index(drop=True)
