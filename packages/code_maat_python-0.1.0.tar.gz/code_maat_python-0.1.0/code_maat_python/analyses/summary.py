"""Summary statistics analysis for code-maat-python.

Provides overview statistics for a repository.
"""

import pandas as pd

from code_maat_python.parser import GitLogSchema


def analyze_summary(df: pd.DataFrame) -> pd.DataFrame:
    """Generate overview statistics.

    Provides high-level statistics about the repository including
    commit count, entity count, author count, and date range.

    Args:
        df: DataFrame with columns: entity, rev, author, date, loc_added, loc_deleted

    Returns:
        DataFrame with columns:
            - statistic: Name of the statistic
            - value: String representation of the value
        Including: n-commits, n-entities, n-authors, first-commit, last-commit

    Example:
        >>> data = [
        ...     {'entity': 'src/main.py', 'rev': 'abc', 'author': 'Dev1',
        ...      'date': pd.to_datetime('2023-01-01')},
        ...     {'entity': 'src/utils.py', 'rev': 'def', 'author': 'Dev2',
        ...      'date': pd.to_datetime('2023-01-15')},
        ... ]
        >>> df = pd.DataFrame(data)
        >>> result = analyze_summary(df)
        >>> print(result)
              statistic  value
        0     n-commits      2
        1    n-entities      2
        2     n-authors      2
        3  first-commit 2023-01-01
        4   last-commit 2023-01-15
    """
    # Handle empty DataFrame
    if df.empty:
        return pd.DataFrame(columns=["statistic", "value"])

    # Calculate statistics
    stats = {
        "n-commits": df[GitLogSchema.REV].nunique(),
        "n-entities": df[GitLogSchema.ENTITY].nunique(),
        "n-authors": df[GitLogSchema.AUTHOR].nunique(),
        "first-commit": df[GitLogSchema.DATE].min().strftime("%Y-%m-%d"),
        "last-commit": df[GitLogSchema.DATE].max().strftime("%Y-%m-%d"),
    }

    # Convert to DataFrame with specific order
    result = pd.DataFrame(
        [{"statistic": k, "value": str(v)} for k, v in stats.items()]
    )

    return result
