"""Communication analysis for code-maat-python."""

from itertools import combinations

import pandas as pd

from code_maat_python.parser import GitLogSchema


def communication(df: pd.DataFrame, min_shared: int = 5, min_coupling: int = 30) -> pd.DataFrame:
    """Calculate communication needs between developers based on shared entities.

    This analysis identifies developers who work on the same code files, indicating
    a need for communication and coordination. The strength metric normalizes by
    each developer's total workload to avoid bias toward highly active developers.

    CRITICAL IMPLEMENTATION NOTE: Self-pairs (author, author) are used internally
    to track each author's total entity count for normalization, but are excluded
    from the final output.

    Args:
        df: DataFrame with GitLogSchema columns (entity, rev, author, date, loc_added, loc_deleted).
            Multiple commits to the same entity by the same author are deduplicated.
        min_shared: Minimum number of shared entities required for a pair to be included.
            Default is 5.
        min_coupling: Minimum coupling strength percentage required (0-100).
            Default is 30. Strength is calculated as:
            (shared_entities / average_total_entities) * 100

    Returns:
        DataFrame with columns:
            - author: First developer name (str), alphabetically sorted
            - peer: Second developer name (str), alphabetically sorted
            - shared: Number of entities both authors worked on (int)
            - strength: Communication coupling strength percentage (int)
        Sorted by strength descending, then shared descending.

        Self-pairs (author, author) are NOT included in output.
        For empty input or no pairs meeting thresholds, returns empty DataFrame with correct schema.

    Raises:
        ValueError: If df doesn't have required columns (entity, author).

    Example:
        >>> import pandas as pd
        >>> from code_maat_python.analyses.communication import communication
        >>> from code_maat_python.parser import parse_git_log
        >>>
        >>> # Parse git log
        >>> df = parse_git_log("git.log")
        >>>
        >>> # Find developer pairs with high communication needs
        >>> result = communication(df, min_shared=5, min_coupling=30)
        >>> print(result.head())
           author    peer  shared  strength
        0  Alice     Bob   12      85
        1  Alice     Charlie 8    60
        2  Bob       Charlie 6    45
        >>>
        >>> # Use stricter thresholds
        >>> result = communication(df, min_shared=10, min_coupling=50)

    Note:
        Strength calculation uses self-pairs internally to normalize:
        - Self-pair (A, A) tracks total entities touched by author A
        - Regular pair (A, B) tracks shared entities between A and B
        - Strength = (shared / ((A_total + B_total) / 2)) * 100
        - Self-pairs are excluded from final results
    """
    # 1. Handle empty DataFrame
    if df.empty:
        return pd.DataFrame(columns=["author", "peer", "shared", "strength"])

    # 2. Validate required columns
    required_cols = {GitLogSchema.ENTITY, GitLogSchema.AUTHOR}
    if not required_cols.issubset(df.columns):
        missing = required_cols - set(df.columns)
        raise ValueError(f"DataFrame missing required columns: {missing}")

    # 3. Get unique author-entity pairs (deduplicate multiple commits)
    unique_pairs = (
        df[[GitLogSchema.ENTITY, GitLogSchema.AUTHOR]].drop_duplicates().reset_index(drop=True)
    )

    # 4. Track pairs: (author1, author2) -> shared entity count
    # Also track self-pairs: (author, author) -> total entity count for that author
    pair_counts: dict[tuple[str, str], int] = {}

    # 5. Calculate total entities per author (self-pairs for normalization)
    author_totals = (
        unique_pairs.groupby(GitLogSchema.AUTHOR, observed=True)[GitLogSchema.ENTITY]
        .nunique()
        .to_dict()
    )
    for author, total in author_totals.items():
        pair_counts[(author, author)] = total

    # 6. Find shared entities between author pairs
    for _entity, group in unique_pairs.groupby(GitLogSchema.ENTITY, observed=True):
        authors = sorted(group[GitLogSchema.AUTHOR].unique())

        # Generate all pairs (excluding self-pairs for shared counts)
        for author1, author2 in combinations(authors, 2):
            # Keep alphabetical order
            pair_key = (author1, author2)
            pair_counts[pair_key] = pair_counts.get(pair_key, 0) + 1

    # 7. Calculate communication strength for each pair
    results = []
    for (author1, author2), shared_count in pair_counts.items():
        # Skip self-pairs in output (they were only for normalization)
        if author1 == author2:
            continue

        # Get total entities for each author from self-pairs
        author1_total = pair_counts.get((author1, author1), 0)
        author2_total = pair_counts.get((author2, author2), 0)

        # Calculate average work
        avg_work = (author1_total + author2_total) / 2

        # Protect against division by zero
        if avg_work == 0:
            continue

        # Calculate strength percentage and round
        strength = int(round((shared_count / avg_work) * 100))

        # Apply filters (using rounded strength)
        if shared_count >= min_shared and strength >= min_coupling:
            results.append(
                {
                    "author": author1,
                    "peer": author2,
                    "shared": shared_count,
                    "strength": strength,
                }
            )

    # 8. Create result DataFrame
    if not results:
        return pd.DataFrame(columns=["author", "peer", "shared", "strength"])

    result_df = pd.DataFrame(results)

    # 9. Sort by strength descending, then shared descending
    result_df = result_df.sort_values(by=["strength", "shared"], ascending=[False, False])

    # 10. Reset index and return with explicit column ordering
    result_df = result_df.reset_index(drop=True)
    return result_df[["author", "peer", "shared", "strength"]]
