"""Entity listing analysis for code-maat-python.

Lists all entities with basic statistics.
"""

import pandas as pd

from code_maat_python.parser import GitLogSchema


def analyze_entities(df: pd.DataFrame) -> pd.DataFrame:
    """List all entities with statistics.

    Provides a simple listing of all entities (files) in the repository
    with the number of times they appear in commits.

    Args:
        df: DataFrame with columns: entity, rev, author, date, loc_added, loc_deleted

    Returns:
        DataFrame with columns:
            - entity: File or module path
            - n-commits: Number of commit records (entity appearances)
        Sorted by entity name.

    Example:
        >>> data = [
        ...     {'entity': 'src/main.py', 'rev': '1', 'author': 'Alice', 'date': '2023-01-01'},
        ...     {'entity': 'src/main.py', 'rev': '2', 'author': 'Bob', 'date': '2023-01-02'},
        ...     {'entity': 'src/utils.py', 'rev': '1', 'author': 'Alice', 'date': '2023-01-01'},
        ... ]
        >>> df = pd.DataFrame(data)
        >>> result = analyze_entities(df)
        >>> print(result)
                  entity  n-commits
        0    src/main.py          2
        1   src/utils.py          1
    """
    # Handle empty DataFrame
    if df.empty:
        return pd.DataFrame(columns=["entity", "n-commits"])

    # Count occurrences of each entity
    result = (
        df.groupby(GitLogSchema.ENTITY, observed=True)
        .size()
        .reset_index(name="n-commits")
        .sort_values("entity")
    )

    return result.reset_index(drop=True)
