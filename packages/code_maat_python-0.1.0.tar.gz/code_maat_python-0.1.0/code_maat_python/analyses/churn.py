"""Churn analysis for code-maat-python.

Analyzes code churn metrics including lines added/deleted by date, author,
and entity, as well as main developer identification.
"""

import pandas as pd

from code_maat_python.parser import GitLogSchema


def abs_churn(df: pd.DataFrame) -> pd.DataFrame:
    """Calculate absolute code churn per date.

    Calculates the total lines added and deleted for each date in the
    commit history. Only dates with commits are included.

    Args:
        df: DataFrame with columns: entity, rev, author, date, loc_added, loc_deleted

    Returns:
        DataFrame with columns:
            - date: Commit date
            - added: Total lines added on that date
            - deleted: Total lines deleted on that date
            - commits: Number of commits on that date

    Example:
        >>> data = [
        ...     {'entity': 'A', 'rev': '1', 'author': 'Dev1', 'date': '2023-01-01',
        ...      'loc_added': 10, 'loc_deleted': 5},
        ...     {'entity': 'B', 'rev': '2', 'author': 'Dev2', 'date': '2023-01-01',
        ...      'loc_added': 15, 'loc_deleted': 3},
        ... ]
        >>> df = pd.DataFrame(data)
        >>> result = abs_churn(df)
    """
    # Handle empty DataFrame
    if df.empty:
        return pd.DataFrame(columns=["date", "added", "deleted", "commits"])

    # Group by date and aggregate churn metrics
    result = (
        df.groupby(GitLogSchema.DATE, observed=True)
        .agg(
            added=(GitLogSchema.LOC_ADDED, "sum"),
            deleted=(GitLogSchema.LOC_DELETED, "sum"),
            commits=(GitLogSchema.REV, "nunique"),
        )
        .reset_index()
    )

    # Sort by date ascending
    result = result.sort_values(by=[GitLogSchema.DATE], ascending=True)

    return result.reset_index(drop=True)


def author_churn(df: pd.DataFrame) -> pd.DataFrame:
    """Calculate total churn per author.

    Sums the total lines added and deleted for each contributing author
    across all entities and commits.

    Args:
        df: DataFrame with columns: entity, rev, author, date, loc_added, loc_deleted

    Returns:
        DataFrame with columns:
            - author: Author name
            - added: Total lines added by author
            - deleted: Total lines deleted by author
            - commits: Number of commits by author

    Example:
        >>> data = [
        ...     {'entity': 'A', 'rev': '1', 'author': 'Alice', 'date': '2023-01-01',
        ...      'loc_added': 10, 'loc_deleted': 5},
        ...     {'entity': 'B', 'rev': '2', 'author': 'Alice', 'date': '2023-01-02',
        ...      'loc_added': 15, 'loc_deleted': 3},
        ... ]
        >>> df = pd.DataFrame(data)
        >>> result = author_churn(df)
    """
    # Handle empty DataFrame
    if df.empty:
        return pd.DataFrame(columns=["author", "added", "deleted", "commits"])

    # Group by author and aggregate churn metrics
    result = (
        df.groupby(GitLogSchema.AUTHOR, observed=True)
        .agg(
            added=(GitLogSchema.LOC_ADDED, "sum"),
            deleted=(GitLogSchema.LOC_DELETED, "sum"),
            commits=(GitLogSchema.REV, "nunique"),
        )
        .reset_index()
    )

    # Sort by author name ascending
    result = result.sort_values(by=[GitLogSchema.AUTHOR], ascending=True)

    return result.reset_index(drop=True)


def entity_churn(df: pd.DataFrame) -> pd.DataFrame:
    """Calculate absolute churn per entity.

    Returns the total lines added and deleted for each entity (file).
    Entities are sorted by lines added in descending order, as this is
    a better predictor of post-release defects.

    Args:
        df: DataFrame with columns: entity, rev, author, date, loc_added, loc_deleted

    Returns:
        DataFrame with columns:
            - entity: File or module path
            - added: Total lines added to entity
            - deleted: Total lines deleted from entity
            - commits: Number of commits affecting entity

    Example:
        >>> data = [
        ...     {'entity': 'main.py', 'rev': '1', 'author': 'Dev1', 'date': '2023-01-01',
        ...      'loc_added': 100, 'loc_deleted': 10},
        ...     {'entity': 'main.py', 'rev': '2', 'author': 'Dev2', 'date': '2023-01-02',
        ...      'loc_added': 50, 'loc_deleted': 5},
        ... ]
        >>> df = pd.DataFrame(data)
        >>> result = entity_churn(df)
    """
    # Handle empty DataFrame
    if df.empty:
        return pd.DataFrame(columns=["entity", "added", "deleted", "commits"])

    # Group by entity and aggregate churn metrics
    result = (
        df.groupby(GitLogSchema.ENTITY, observed=True)
        .agg(
            added=(GitLogSchema.LOC_ADDED, "sum"),
            deleted=(GitLogSchema.LOC_DELETED, "sum"),
            commits=(GitLogSchema.REV, "nunique"),
        )
        .reset_index()
    )

    # Sort by lines added descending (better predictor of defects)
    result = result.sort_values(by=["added"], ascending=False)

    return result.reset_index(drop=True)


def entity_ownership(df: pd.DataFrame) -> pd.DataFrame:
    """Calculate ownership of each entity by author based on churn.

    Returns a table showing how much each author has contributed to each
    entity in terms of lines added and deleted. This helps identify code
    ownership patterns.

    Args:
        df: DataFrame with columns: entity, rev, author, date, loc_added, loc_deleted

    Returns:
        DataFrame with columns:
            - entity: File or module path
            - author: Author name
            - added: Lines added by author to entity
            - deleted: Lines deleted by author from entity

    Example:
        >>> data = [
        ...     {'entity': 'main.py', 'rev': '1', 'author': 'Alice', 'date': '2023-01-01',
        ...      'loc_added': 100, 'loc_deleted': 10},
        ...     {'entity': 'main.py', 'rev': '2', 'author': 'Bob', 'date': '2023-01-02',
        ...      'loc_added': 50, 'loc_deleted': 5},
        ... ]
        >>> df = pd.DataFrame(data)
        >>> result = entity_ownership(df)
    """
    # Handle empty DataFrame
    if df.empty:
        return pd.DataFrame(columns=["entity", "author", "added", "deleted"])

    # Group by entity and author, aggregate churn metrics
    result = (
        df.groupby([GitLogSchema.ENTITY, GitLogSchema.AUTHOR], observed=True)
        .agg(
            added=(GitLogSchema.LOC_ADDED, "sum"),
            deleted=(GitLogSchema.LOC_DELETED, "sum"),
        )
        .reset_index()
    )

    # Sort by entity ascending
    result = result.sort_values(by=[GitLogSchema.ENTITY], ascending=True)

    return result.reset_index(drop=True)


def main_dev(df: pd.DataFrame) -> pd.DataFrame:
    """Identify the main developer of each entity by lines added.

    The main developer is the author who has contributed the most lines
    of code (added) to each entity. Returns ownership percentage.

    Args:
        df: DataFrame with columns: entity, rev, author, date, loc_added, loc_deleted

    Returns:
        DataFrame with columns:
            - entity: File or module path
            - main-dev: Primary developer name
            - added: Lines added by main developer
            - total-added: Total lines added to entity
            - ownership: Ownership percentage (0-100)

    Example:
        >>> data = [
        ...     {'entity': 'main.py', 'rev': '1', 'author': 'Alice', 'date': '2023-01-01',
        ...      'loc_added': 100, 'loc_deleted': 10},
        ...     {'entity': 'main.py', 'rev': '2', 'author': 'Bob', 'date': '2023-01-02',
        ...      'loc_added': 50, 'loc_deleted': 5},
        ... ]
        >>> df = pd.DataFrame(data)
        >>> result = main_dev(df)
    """
    # Handle empty DataFrame
    if df.empty:
        return pd.DataFrame(columns=["entity", "main-dev", "added", "total-added", "ownership"])

    # Calculate lines added by each author per entity
    entity_author_added = (
        df.groupby([GitLogSchema.ENTITY, GitLogSchema.AUTHOR], observed=True)[
            GitLogSchema.LOC_ADDED
        ]
        .sum()
        .reset_index()
    )

    # Calculate total lines added per entity
    entity_total_added = (
        df.groupby(GitLogSchema.ENTITY, observed=True)[GitLogSchema.LOC_ADDED]
        .sum()
        .reset_index()
        .rename(columns={GitLogSchema.LOC_ADDED: "total-added"})
    )

    # Find the author with max lines added per entity
    main_devs = (
        entity_author_added.loc[
            entity_author_added.groupby(GitLogSchema.ENTITY, observed=True)[
                GitLogSchema.LOC_ADDED
            ].idxmax()
        ]
        .rename(
            columns={
                GitLogSchema.AUTHOR: "main-dev",
                GitLogSchema.LOC_ADDED: "added",
            }
        )
        .reset_index(drop=True)
    )

    # Merge with total added
    result = main_devs.merge(entity_total_added, on=GitLogSchema.ENTITY)

    # Calculate ownership percentage
    # Use max(total, 1) to handle entities with only deletions
    result["ownership"] = (result["added"] / result["total-added"].clip(lower=1) * 100).round(2)

    # Sort by entity ascending
    result = result.sort_values(by=[GitLogSchema.ENTITY], ascending=True)

    return result.reset_index(drop=True)


def refactoring_main_dev(df: pd.DataFrame) -> pd.DataFrame:
    """Identify the main developer of each entity by lines removed.

    This alternative calculation identifies the main developer as the
    author who has removed the most lines of code. The idea is that
    removing code represents more active design choices and refactoring.

    Args:
        df: DataFrame with columns: entity, rev, author, date, loc_added, loc_deleted

    Returns:
        DataFrame with columns:
            - entity: File or module path
            - main-dev: Primary developer name
            - removed: Lines removed by main developer
            - total-removed: Total lines removed from entity
            - ownership: Ownership percentage (0-100)

    Example:
        >>> data = [
        ...     {'entity': 'main.py', 'rev': '1', 'author': 'Alice', 'date': '2023-01-01',
        ...      'loc_added': 10, 'loc_deleted': 100},
        ...     {'entity': 'main.py', 'rev': '2', 'author': 'Bob', 'date': '2023-01-02',
        ...      'loc_added': 5, 'loc_deleted': 50},
        ... ]
        >>> df = pd.DataFrame(data)
        >>> result = refactoring_main_dev(df)
    """
    # Handle empty DataFrame
    if df.empty:
        return pd.DataFrame(columns=["entity", "main-dev", "removed", "total-removed", "ownership"])

    # Calculate lines deleted by each author per entity
    entity_author_deleted = (
        df.groupby([GitLogSchema.ENTITY, GitLogSchema.AUTHOR], observed=True)[
            GitLogSchema.LOC_DELETED
        ]
        .sum()
        .reset_index()
    )

    # Calculate total lines deleted per entity
    entity_total_deleted = (
        df.groupby(GitLogSchema.ENTITY, observed=True)[GitLogSchema.LOC_DELETED]
        .sum()
        .reset_index()
        .rename(columns={GitLogSchema.LOC_DELETED: "total-removed"})
    )

    # Find the author with max lines deleted per entity
    main_devs = (
        entity_author_deleted.loc[
            entity_author_deleted.groupby(GitLogSchema.ENTITY, observed=True)[
                GitLogSchema.LOC_DELETED
            ].idxmax()
        ]
        .rename(
            columns={
                GitLogSchema.AUTHOR: "main-dev",
                GitLogSchema.LOC_DELETED: "removed",
            }
        )
        .reset_index(drop=True)
    )

    # Merge with total deleted
    result = main_devs.merge(entity_total_deleted, on=GitLogSchema.ENTITY)

    # Calculate ownership percentage
    # Use max(total, 1) to handle entities with only additions
    result["ownership"] = (result["removed"] / result["total-removed"].clip(lower=1) * 100).round(2)

    # Sort by entity ascending
    result = result.sort_values(by=[GitLogSchema.ENTITY], ascending=True)

    return result.reset_index(drop=True)
