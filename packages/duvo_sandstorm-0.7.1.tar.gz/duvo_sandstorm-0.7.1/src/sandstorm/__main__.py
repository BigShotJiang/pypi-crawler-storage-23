"""Allow running sandstorm as `python -m sandstorm`."""

from sandstorm.cli import cli

cli()
