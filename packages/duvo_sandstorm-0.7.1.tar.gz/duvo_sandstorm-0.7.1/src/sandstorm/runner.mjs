/**
 * Agent runner script — executed inside the E2B sandbox.
 *
 * Uses the Claude Agent SDK's query() function directly (not the CLI).
 * Reads config from agent_config.json, streams each SDK message
 * as a JSON line to stdout.
 */
import { query } from "@anthropic-ai/claude-agent-sdk";
import { readFileSync } from "fs";
import { dirname, join } from "path";
import { fileURLToPath } from "url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const config = JSON.parse(readFileSync(join(__dirname, "agent_config.json"), "utf-8"));

const options = {
  cwd: config.cwd || "/home/user",
  permissionMode: "bypassPermissions",
  allowDangerouslySkipPermissions: true,
  // When skills are present, include "project" so the SDK discovers SKILL.md files
  settingSources: config.has_skills ? ["user", "project"] : ["user"],
};

// Map snake_case config fields to camelCase SDK options
const fieldMap = {
  model: "model",
  system_prompt: "systemPrompt",
  max_turns: "maxTurns",
  mcp_servers: "mcpServers",
  output_format: "outputFormat",
  agents: "agents",
  allowed_tools: "allowedTools",
};
for (const [src, dst] of Object.entries(fieldMap)) {
  if (config[src] !== undefined && config[src] !== null) options[dst] = config[src];
}

try {
  for await (const message of query({ prompt: config.prompt, options })) {
    process.stdout.write(JSON.stringify(message) + "\n");

    // Break on terminal result to avoid hanging
    if (
      message.type === "result" &&
      typeof message.subtype === "string" &&
      ["success", "error_max_turns", "error_during_execution", "error_max_budget_usd", "error_max_structured_output_retries"].includes(message.subtype)
    ) {
      break;
    }
  }
} catch (err) {
  process.stdout.write(JSON.stringify({ type: "error", error: err.message }) + "\n");
  process.exit(1);
}
