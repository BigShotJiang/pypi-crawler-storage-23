# Quantum Circuit Reasoning

This is an experimental library to create Quantum Circuits based on the mod2-basis+ CP decomposition of a targeted tensor.

Documentation can be found in the [notes from the tnreason project](https://github.com/tnreason/tnreason-notes).