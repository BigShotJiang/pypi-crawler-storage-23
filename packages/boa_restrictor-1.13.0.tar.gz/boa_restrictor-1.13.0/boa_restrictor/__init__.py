"""A custom Python and Django linter from Ambient"""

__version__ = "1.13.0"
