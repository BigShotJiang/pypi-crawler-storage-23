"""PactKit - Spec-driven agentic DevOps toolkit."""

__version__ = "1.6.0"
