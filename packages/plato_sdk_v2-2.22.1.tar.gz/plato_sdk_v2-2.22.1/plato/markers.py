"""Annotation markers for Plato configurations (agents and worlds).

Provides typed annotation markers for special fields like secrets, agents,
and environments in configuration classes.

Usage (agents):
    from plato.markers import Secret
    api_key: Annotated[str, Secret(description="API key")]

Usage (worlds):
    from plato.markers import Agent, WorldSecret, Env, EnvList, FieldMarker
    coder: Annotated[AgentConfig, Agent(description="Coding agent")]
"""

from __future__ import annotations

from typing import Literal


class FieldMarker:
    """Base marker for special fields in configs.

    This is the underlying implementation. Use Agent(), Secret(), Env(), or EnvList()
    for cleaner syntax.
    """

    def __init__(
        self,
        kind: Literal["agent", "secret", "env", "env_list"],
        description: str = "",
        required: bool = True,
    ):
        self.kind = kind
        self.description = description
        self.required = required


class Secret:
    """Annotation marker for secret fields in agent configs.

    Fields annotated with Secret are automatically loaded from environment variables.
    The env var name is the uppercase version of the field name (e.g., api_key -> API_KEY).

    Usage:
        api_key: Annotated[str, Secret(description="API key")]
    """

    def __init__(self, description: str = "", required: bool = False):
        self.description = description
        self.required = required


def Agent(description: str = "", required: bool = True) -> FieldMarker:
    """Marker for agent fields in world configs.

    Usage:
        coder: Annotated[AgentConfig, Agent(description="Coding agent")]
    """
    return FieldMarker("agent", description, required)


def WorldSecret(description: str = "", required: bool = False) -> FieldMarker:
    """Marker for secret fields in world configs.

    Returns a FieldMarker (unlike agent Secret which is a class), for use with
    the world schema system.

    Usage:
        git_token: Annotated[str | None, WorldSecret(description="GitHub token")] = None
    """
    return FieldMarker("secret", description, required)


def Env(description: str = "", required: bool = True) -> FieldMarker:
    """Marker for single environment fields in world configs.

    Usage:
        database: Annotated[EnvConfig, Env(description="Database server")]
    """
    return FieldMarker("env", description, required)


def EnvList(description: str = "") -> FieldMarker:
    """Marker for a list of arbitrary environments in world configs.

    Usage:
        envs: Annotated[list[EnvConfig], EnvList(description="Environments")]
    """
    return FieldMarker("env_list", description, required=False)
