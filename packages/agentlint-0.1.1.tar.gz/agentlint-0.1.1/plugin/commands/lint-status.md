---
name: lint-status
description: Show AgentLint status — active rules, violations this session
---

Run `agentlint status --project-dir "$CLAUDE_PROJECT_DIR"` and display:
1. Which rule packs are active
2. How many rules are running
3. Current severity mode
4. Any violations found this session
