---
name: lint-config
description: Show or edit AgentLint configuration
---

Read the `agentlint.yml` file in the project root and display:
1. Current severity mode (standard/strict/relaxed)
2. Active packs
3. Rule overrides
4. Custom rules directory

If the user wants to change settings, edit the agentlint.yml file.
