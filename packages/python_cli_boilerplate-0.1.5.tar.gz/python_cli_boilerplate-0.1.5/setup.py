from setuptools import setup, find_packages

setup(
    name="python-cli-boilerplate",
    version="0.1.5",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    install_requires=[
    ],
    long_description=open('readme.md').read(),
    long_description_content_type='text/markdown',
    author="dev.plotzZzky",
    author_email="",
    description="python-cli-cli_boilerplate",
    url="https://github.com/plotzZzky/python-cli-boilerplate",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.9',
)
