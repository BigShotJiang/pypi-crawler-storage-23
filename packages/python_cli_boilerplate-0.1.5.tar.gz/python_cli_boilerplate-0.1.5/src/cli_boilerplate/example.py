from cli_boilerplate import CliBoilerplate


class SimpleCli(CliBoilerplate):
    """ Exemplo de cli simples usando o python-cli-cli_boilerplate """

    def __init__(self):
        super().__init__()
        self.CLI_DESC = "Test de app usando o CliBoilerplate"

        self.menu_options = [
            self.exemple_function,
            self.another_exemple_function,
        ]

    @staticmethod
    def exemple_function():
        print("New exemple function!")

    @staticmethod
    def another_exemple_function():
        print("Another exemple function!")


cli = SimpleCli()

if __name__ == "__main__":
    cli.main_loop()

