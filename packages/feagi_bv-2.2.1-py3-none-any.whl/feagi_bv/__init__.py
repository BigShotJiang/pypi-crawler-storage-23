"""
FEAGI Brain Visualizer runtime package.

This package ships platform-specific Brain Visualizer binaries as data files.
"""

from feagi_bv.runtime import BrainVisualizer

__all__ = ["BrainVisualizer"]
