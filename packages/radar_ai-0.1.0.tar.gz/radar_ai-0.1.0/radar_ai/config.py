import os


class RadarConfig:
    def __init__(
        self,
        project_id: str,
        secret: str,
        service: str = "backend",
        root: str | None = None,
        log_file: str | None = None,
        base_url: str = "http://127.0.0.1:8000",
    ):
        self.project_id = project_id
        self.secret = secret
        self.service = service

        # Project root (default = current working directory)
        self.root = root or os.getcwd()

        # Default log file path
        self.log_file = log_file or os.path.join(self.root, "app.log")

        # Backend base URL
        self.base_url = base_url

        # Internal flags (future scaling ke liye useful)
        self.connected = False

    def validate(self):
        if not self.project_id:
            raise ValueError("RADAR project_id is required")

        if not self.secret:
            raise ValueError("RADAR secret is required")

        if not self.service:
            raise ValueError("RADAR service name is required")