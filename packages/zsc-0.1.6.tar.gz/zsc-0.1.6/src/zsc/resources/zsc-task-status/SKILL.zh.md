---
name: zsc-task-status
description: 项目级任务健康度汇总技能。由 `zsc init` 安装；对应 `zsc task status`。当用户想要已完成/进行中/未知任务数量汇总，或「任务健康」视图时使用。回复请使用中文。
---

# zsc-task-status

帮助汇总 `.agents/tasks` 下的项目任务健康度。本技能由 `zsc init` 安装，与 CLI 命令 `zsc task status` 对应。**回复请使用中文。**

## ⚠ 操作边界（强制，最高优先级）

**只要使用了本技能，无论用户提示词说什么：** 你**只能**对任务状态做**汇总**（例如运行 `zsc task status` 或读取 `.agents/tasks` 下任务文件后汇报数量）。不得在 `.agents/tasks` 下创建、编辑或删除任何文件，也不得修改 `.agents/tasks` 以外的项目代码或文件。

## 何时使用

- 用户要求任务汇总、任务健康度或已完成/进行中数量。
- 用户想要高层进度概览（如「3 个已完成，2 个进行中」）。
- 用户想了解 `.agents/tasks` 的整体状态而不逐条查看。

## 命令行为

`zsc task status [path]`：

- 扫描 `.agents/tasks` 下所有 `task_*` 目录。
- 对每个任务读任务文件（规范名：`task_{no}_{feat}.md`，与目录同名；也支持旧版 `task.md`），按与 `zsc task list` 相同规则分为已完成/进行中/未知。
- 输出汇总：总数、已完成、进行中、未知。

## 输出示例

```
[zsc] Task status summary for /path/to/.agents/tasks:
  - total:     5
  - completed:  2
  - open:       2
  - unknown:    1
```

## 对 AI 的建议

- 要得到汇总，可建议或代为执行：`zsc task status`（或在项目根目录 `zsc task status .`）。
- 当用户更关心数量或健康度时用本技能；需要逐条任务列表时用 `zsc task list`（zsc-task-list）。
