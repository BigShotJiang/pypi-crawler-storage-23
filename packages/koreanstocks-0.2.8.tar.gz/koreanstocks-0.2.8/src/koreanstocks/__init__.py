VERSION = "0.2.8"

import warnings
warnings.filterwarnings("ignore", message="pkg_resources is deprecated")
