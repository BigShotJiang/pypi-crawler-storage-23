"""
Media Security Middleware
=========================

Provides security headers and access control for media files in production.
"""

import logging

from django.conf import settings
from django.http import HttpResponseForbidden
from django.utils.deprecation import MiddlewareMixin

from nimoh_base.core.utils import get_client_ip as _core_get_client_ip

logger = logging.getLogger(__name__)


class MediaSecurityMiddleware(MiddlewareMixin):
    """
    Middleware to add security headers for media files.

    Features:
    - Adds CORS headers for media files
    - Adds caching headers for media files
    - Optional: Access control for private media
    """

    def process_response(self, request, response):
        """Add security and caching headers for media files."""

        # Only process media file requests
        if not request.path.startswith(settings.MEDIA_URL):
            return response

        # Add CORS headers for media files
        if hasattr(settings, "CORS_ALLOWED_ORIGINS") and settings.CORS_ALLOWED_ORIGINS:
            # Allow media files to be accessed cross-origin
            origin = request.headers.get("Origin", "")

            if origin in settings.CORS_ALLOWED_ORIGINS or "*" in settings.CORS_ALLOWED_ORIGINS:
                response["Access-Control-Allow-Origin"] = origin
                response["Access-Control-Allow-Credentials"] = "true"
                response["Access-Control-Expose-Headers"] = "Content-Length, Content-Range, Accept-Ranges"

        # Add caching headers for media files (1 year)
        if response.status_code == 200:
            response["Cache-Control"] = "public, max-age=31536000, immutable"
            response["Vary"] = "Origin"

        # Add security headers
        response["X-Content-Type-Options"] = "nosniff"

        return response


class PrivateMediaAccessMiddleware(MiddlewareMixin):
    """
    Middleware to protect private media files.

    Use this if you have private/protected media that requires authentication.
    Configure PRIVATE_MEDIA_URL in settings.
    """

    def process_request(self, request):
        """Check access permissions for private media files."""

        # Check if this is a private media request
        private_media_url = getattr(settings, "PRIVATE_MEDIA_URL", "/private/")

        if not request.path.startswith(private_media_url):
            return None  # Not a private media request

        # Check if user is authenticated
        if not request.user.is_authenticated:
            logger.warning(
                f"Unauthenticated access attempt to private media: {request.path}",
                extra={"path": request.path, "ip": self._get_client_ip(request)},
            )
            return HttpResponseForbidden("Authentication required to access this resource.")

        # Optional: Add custom permission checks here
        # Example: Check if user has permission to access specific file
        # if not self._check_file_permission(request.user, request.path):
        #     return HttpResponseForbidden('You do not have permission to access this resource.')

        return None  # Allow access

    @staticmethod
    def _get_client_ip(request):
        """Delegate to canonical get_client_ip."""
        return _core_get_client_ip(request)
