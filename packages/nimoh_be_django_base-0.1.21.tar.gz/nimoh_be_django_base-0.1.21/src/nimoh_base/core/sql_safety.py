"""
SQL Injection Protection Utilities.

This module provides safe database query helpers and validation
to prevent SQL injection vulnerabilities.
"""

import logging
from typing import Any

from django.core.exceptions import ValidationError
from django.db import DatabaseError, connection

logger = logging.getLogger(__name__)


class SafeQueryHelper:
    """
    Helper class for executing raw SQL queries safely with parameterization.

    Always use parameterized queries to prevent SQL injection.
    Never use string formatting or concatenation for SQL queries.
    """

    @staticmethod
    def execute_safe_query(query: str, params: tuple[Any, ...] | None = None, fetch_one: bool = False) -> Any:
        """
        Execute a parameterized SQL query safely.

        Args:
            query: SQL query with %s placeholders for parameters
            params: Tuple of parameters to safely inject into query
            fetch_one: If True, return single row; otherwise return all rows

        Returns:
            Query results (single row or all rows)

        Raises:
            ValidationError: If query appears to contain SQL injection attempts

        Example:
            >>> SafeQueryHelper.execute_safe_query(
            ...     "SELECT * FROM users WHERE email = %s",
            ...     params=("user@example.com",)
            ... )
        """
        # Validate query doesn't contain dangerous patterns
        SafeQueryHelper._validate_query_safety(query)

        try:
            with connection.cursor() as cursor:
                cursor.execute(query, params or ())

                if fetch_one:
                    return cursor.fetchone()
                return cursor.fetchall()

        except DatabaseError as e:
            logger.error(f"Safe query execution failed: {e}", extra={"query": query, "params": params, "error": str(e)})
            raise

    @staticmethod
    def _validate_query_safety(query: str) -> None:
        """
        Validate that query follows safe patterns.

        Args:
            query: SQL query to validate

        Raises:
            ValidationError: If query contains dangerous patterns
        """
        # Check for string formatting indicators (potential SQL injection)
        dangerous_patterns = [
            ("format(", "Use parameterized queries instead of .format()"),
            ("{", "Use parameterized queries instead of f-strings"),
            ("DROP TABLE", "DROP TABLE not allowed in application queries"),
            ("DROP DATABASE", "DROP DATABASE not allowed in application queries"),
            (";--", "SQL comment injection attempt detected"),
            ("UNION SELECT", "UNION-based SQL injection attempt detected"),
        ]

        query_upper = query.upper()
        for pattern, message in dangerous_patterns:
            if pattern.upper() in query_upper:
                logger.warning(
                    f"Potentially unsafe SQL query detected: {message}", extra={"query": query, "pattern": pattern}
                )
                raise ValidationError(f"Unsafe SQL query pattern detected: {message}")

    @staticmethod
    def safe_table_name(table_name: str) -> str:
        """
        Validate and sanitize table name to prevent SQL injection.

        Args:
            table_name: Table name to validate

        Returns:
            Validated table name

        Raises:
            ValidationError: If table name is invalid
        """
        # Only allow alphanumeric, underscore, and period (for schema.table)
        import re

        if not re.match(r"^[a-zA-Z0-9_\.]+$", table_name):
            raise ValidationError(
                f"Invalid table name: {table_name}. Only alphanumeric characters, underscores, and periods allowed."
            )

        # Prevent common SQL injection patterns
        if any(keyword in table_name.upper() for keyword in ["DROP", "DELETE", "UNION", "--"]):
            raise ValidationError(f"Suspicious table name: {table_name}")

        return table_name

    @staticmethod
    def safe_column_name(column_name: str) -> str:
        """
        Validate and sanitize column name to prevent SQL injection.

        Args:
            column_name: Column name to validate

        Returns:
            Validated column name

        Raises:
            ValidationError: If column name is invalid
        """
        import re

        if not re.match(r"^[a-zA-Z0-9_]+$", column_name):
            raise ValidationError(
                f"Invalid column name: {column_name}. Only alphanumeric characters and underscores allowed."
            )

        return column_name


class QueryParameterValidator:
    """
    Validator for query parameters to prevent injection attacks.
    """

    @staticmethod
    def validate_order_by(field: str, allowed_fields: list[str]) -> str:
        """
        Validate ORDER BY field to prevent SQL injection.

        Args:
            field: Field name (may include - for descending)
            allowed_fields: List of allowed field names

        Returns:
            Validated field name

        Raises:
            ValidationError: If field is not in allowed list
        """
        # Remove descending indicator
        clean_field = field.lstrip("-")

        if clean_field not in allowed_fields:
            raise ValidationError(f"Invalid ordering field: {field}. Allowed fields: {', '.join(allowed_fields)}")

        return field

    @staticmethod
    def validate_filter_field(field: str, allowed_fields: list[str]) -> str:
        """
        Validate filter field to prevent SQL injection.

        Args:
            field: Field name (may include lookup like __icontains)
            allowed_fields: List of allowed base field names

        Returns:
            Validated field name

        Raises:
            ValidationError: If field base is not in allowed list
        """
        # Extract base field name (before lookup)
        base_field = field.split("__")[0]

        if base_field not in allowed_fields:
            raise ValidationError(f"Invalid filter field: {field}. Allowed fields: {', '.join(allowed_fields)}")

        return field

    @staticmethod
    def validate_limit_offset(limit: int | None, offset: int | None) -> tuple[int, int]:
        """
        Validate LIMIT and OFFSET values.

        Args:
            limit: Maximum number of results (None = default)
            offset: Number of results to skip (None = 0)

        Returns:
            Tuple of (validated_limit, validated_offset)

        Raises:
            ValidationError: If values are invalid
        """
        # Default values
        validated_limit = limit if limit is not None else 100
        validated_offset = offset if offset is not None else 0

        # Validate types
        if not isinstance(validated_limit, int) or not isinstance(validated_offset, int):
            raise ValidationError("LIMIT and OFFSET must be integers")

        # Validate ranges
        if validated_limit < 1 or validated_limit > 1000:
            raise ValidationError("LIMIT must be between 1 and 1000")

        if validated_offset < 0:
            raise ValidationError("OFFSET must be non-negative")

        return validated_limit, validated_offset


# Example usage documentation
"""
SAFE USAGE EXAMPLES:

1. Parameterized Query (SAFE):
    SafeQueryHelper.execute_safe_query(
        "SELECT * FROM users WHERE email = %s AND active = %s",
        params=("user@example.com", True)
    )

2. Table Name Validation (SAFE):
    table = SafeQueryHelper.safe_table_name("auth_user")
    query = f"SELECT * FROM {table} WHERE id = %s"
    SafeQueryHelper.execute_safe_query(query, params=(user_id,))

3. ORDER BY Validation (SAFE):
    ordering = QueryParameterValidator.validate_order_by(
        request.GET.get('order_by', 'created_at'),
        allowed_fields=['created_at', 'email', 'username']
    )
    users = User.objects.all().order_by(ordering)

UNSAFE EXAMPLES (NEVER DO THIS):

1. String Formatting (UNSAFE):
    # ❌ VULNERABLE TO SQL INJECTION
    query = f"SELECT * FROM users WHERE email = '{email}'"
    cursor.execute(query)

2. String Concatenation (UNSAFE):
    # ❌ VULNERABLE TO SQL INJECTION
    query = "SELECT * FROM users WHERE id = " + str(user_id)
    cursor.execute(query)

3. Unvalidated User Input (UNSAFE):
    # ❌ VULNERABLE TO SQL INJECTION
    table = request.GET.get('table')
    query = f"SELECT * FROM {table}"
    cursor.execute(query)
"""
