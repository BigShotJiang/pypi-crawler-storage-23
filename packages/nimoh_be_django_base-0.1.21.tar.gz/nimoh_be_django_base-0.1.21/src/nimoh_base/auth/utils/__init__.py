"""
Authentication utilities package.
"""

from .auth import (
    PasswordValidator,
    estimate_password_strength,
    generate_reset_token,
    generate_secure_token,
    generate_verification_token,
    get_client_ip,
    is_disposable_email,
    normalize_email,
    validate_password_strength,
)
from .cookies import (
    clear_all_auth_cookies,
    clear_refresh_token_cookie,
    create_secure_response,
    get_refresh_token_from_cookie,
    set_csrf_cookie,
    set_refresh_token_cookie,
    set_security_headers,
)
from .email import EmailService, EmailThrottler, test_email_connection, validate_email_settings
from .sessions import (
    calculate_session_risk_score,
    detect_session_anomalies,
    get_device_fingerprint,
    get_session_summary,
    is_suspicious_user_agent,
    parse_user_agent,
)

__all__ = [
    # Email utilities
    "EmailService",
    "EmailThrottler",
    "PasswordValidator",
    "calculate_session_risk_score",
    "clear_all_auth_cookies",
    "clear_refresh_token_cookie",
    "create_secure_response",
    "detect_session_anomalies",
    "estimate_password_strength",
    "generate_reset_token",
    # Auth utilities
    "generate_secure_token",
    "generate_verification_token",
    "get_client_ip",
    "get_device_fingerprint",
    "get_refresh_token_from_cookie",
    "get_session_summary",
    "is_disposable_email",
    "is_suspicious_user_agent",
    "normalize_email",
    # Session utilities
    "parse_user_agent",
    "set_csrf_cookie",
    # Cookie utilities
    "set_refresh_token_cookie",
    "set_security_headers",
    "test_email_connection",
    "validate_email_settings",
    "validate_password_strength",
]
