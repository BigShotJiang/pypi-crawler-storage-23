"""
nimoh_base.cli.checks
======================
Logic for the ``nimoh-base check`` command.

Inspects a consumer project's settings module and reports:
- Missing required NIMOH_BASE keys
- Deprecated keys present in NIMOH_BASE (future compatibility)
- AUTH_USER_MODEL not set to a subclass of AbstractNimohUser

Usage (CLI)::

    nimoh-base check --settings myproject.config.settings.base
"""

from __future__ import annotations

import importlib
import sys
from dataclasses import dataclass
from pathlib import Path


@dataclass
class CheckResult:
    """Result of running the NIMOH_BASE health check."""

    missing_keys: list[str]
    unknown_keys: list[str]
    auth_user_model: str | None
    auth_user_model_ok: bool
    errors: list[str]
    warnings: list[str]

    @property
    def passed(self) -> bool:
        return len(self.errors) == 0


def run_checks(settings_module: str, project_root: str | Path | None = None) -> CheckResult:
    """
    Import *settings_module* and validate NIMOH_BASE configuration.

    Parameters
    ----------
    settings_module:
        Dotted Python import path (e.g. ``"myproject.config.settings.base"``).
    project_root:
        Optional filesystem path to prepend to ``sys.path`` before importing.
    """
    # Optionally add project root to path so the settings module is importable
    if project_root is not None:
        root = str(Path(project_root).resolve())
        if root not in sys.path:
            sys.path.insert(0, root)

    # Import settings without setting up Django (avoids app-registry issues)
    try:
        mod = importlib.import_module(settings_module)
    except ImportError as exc:
        return CheckResult(
            missing_keys=[],
            unknown_keys=[],
            auth_user_model=None,
            auth_user_model_ok=False,
            errors=[f"Cannot import settings module '{settings_module}': {exc}"],
            warnings=[],
        )

    from nimoh_base.conf.defaults import NIMOH_BASE_DEFAULTS, NIMOH_BASE_REQUIRED_KEYS

    nimoh = getattr(mod, "NIMOH_BASE", None)
    errors: list[str] = []
    warnings: list[str] = []

    if nimoh is None:
        errors.append(
            "NIMOH_BASE dict is not defined in the settings module. "
            "Add it with at least SITE_NAME, SUPPORT_EMAIL, NOREPLY_EMAIL."
        )
        nimoh = {}

    if not isinstance(nimoh, dict):
        errors.append(f"NIMOH_BASE must be a dict, got {type(nimoh).__name__}.")
        nimoh = {}

    # Required keys check
    missing = [k for k in NIMOH_BASE_REQUIRED_KEYS if k not in nimoh or not nimoh[k]]
    for key in missing:
        errors.append(f"NIMOH_BASE['{key}'] is missing or empty (required).")

    # Unknown keys — warn but don't error
    known = set(NIMOH_BASE_REQUIRED_KEYS) | set(NIMOH_BASE_DEFAULTS.keys())
    unknown = [k for k in nimoh if k not in known]
    for key in unknown:
        warnings.append(
            f"NIMOH_BASE['{key}'] is not a known package key — "
            "it may be a typo or a future key added by a newer package version."
        )

    # AUTH_USER_MODEL check
    auth_user_model = getattr(mod, "AUTH_USER_MODEL", None)
    auth_user_model_ok = False

    if auth_user_model is None:
        errors.append("AUTH_USER_MODEL is not set. Set it to a concrete subclass of nimoh_base.auth.AbstractNimohUser.")
    elif auth_user_model == "auth.User":
        errors.append(
            "AUTH_USER_MODEL is set to 'auth.User' (Django's built-in User). "
            "It must point to a project model that subclasses AbstractNimohUser."
        )
    elif auth_user_model == "nimoh_auth.User":
        warnings.append(
            "AUTH_USER_MODEL is 'nimoh_auth.User' (the package's reference model). "
            "For production projects, create your own subclass of AbstractNimohUser "
            "so you can add custom fields without a future major-version bump."
        )
        auth_user_model_ok = True
    else:
        auth_user_model_ok = True  # assume consumer knows what they're doing

    return CheckResult(
        missing_keys=missing,
        unknown_keys=unknown,
        auth_user_model=auth_user_model,
        auth_user_model_ok=auth_user_model_ok,
        errors=errors,
        warnings=warnings,
    )


def print_check_results(result: CheckResult) -> None:
    """Pretty-print check results using Rich (falls back to plain print)."""
    try:
        from rich.console import Console
        from rich.table import Table  # noqa: F401

        console = Console()
        _rich_results(console, result)
    except ImportError:
        _plain_results(result)


def _rich_results(console, result: CheckResult) -> None:

    if result.passed:
        console.print("\n[bold green]✓  All checks passed.[/bold green]\n")
    else:
        console.print(f"\n[bold red]✗  {len(result.errors)} error(s) found.[/bold red]\n")

    if result.errors:
        console.print("[bold red]Errors[/bold red]")
        for e in result.errors:
            console.print(f"  [red]•[/red] {e}")
        console.print()

    if result.warnings:
        console.print("[bold yellow]Warnings[/bold yellow]")
        for w in result.warnings:
            console.print(f"  [yellow]•[/yellow] {w}")
        console.print()

    if result.auth_user_model:
        status = "[green]OK[/green]" if result.auth_user_model_ok else "[red]FAIL[/red]"
        console.print(f"AUTH_USER_MODEL: [cyan]{result.auth_user_model}[/cyan]  {status}\n")


def _plain_results(result: CheckResult) -> None:
    status = "PASSED" if result.passed else "FAILED"
    print(f"\n--- nimoh-base check: {status} ---")
    for e in result.errors:
        print(f"  ERROR:   {e}")
    for w in result.warnings:
        print(f"  WARNING: {w}")
    if result.auth_user_model:
        ok = "OK" if result.auth_user_model_ok else "FAIL"
        print(f"  AUTH_USER_MODEL: {result.auth_user_model} [{ok}]")
    print()
