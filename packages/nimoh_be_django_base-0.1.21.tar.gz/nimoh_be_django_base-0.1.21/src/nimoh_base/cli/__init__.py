"""
nimoh_base.cli — Interactive project scaffolding CLI.

Install CLI extras first:  pip install 'nimoh-be-django-base[cli]'
Then run:                  nimoh-base --help
"""
# Lazy re-export: only import cli group when explicitly requested,
# so that importing nimoh_base without the [cli] extra doesn't fail.


def __getattr__(name: str):
    if name == "cli":
        from nimoh_base.cli.main import cli

        return cli
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
