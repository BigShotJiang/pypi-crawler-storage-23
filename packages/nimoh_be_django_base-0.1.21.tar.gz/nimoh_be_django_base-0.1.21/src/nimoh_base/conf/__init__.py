"""
nimoh_base.conf
===============
Central configuration helpers for ``nimoh-be-django-base``.

Usage in a consumer project's ``settings/base.py``::

    from nimoh_base.conf import NimohBaseSettings

    INSTALLED_APPS = NimohBaseSettings.get_base_apps() + [
        'myproject.profiles',
        'myproject.myapp',
    ]

    MIDDLEWARE = NimohBaseSettings.get_base_middleware()

    REST_FRAMEWORK = NimohBaseSettings.get_base_rest_framework()

    NIMOH_BASE = {
        'SITE_NAME': 'My Application',
        'SUPPORT_EMAIL': 'support@myapp.com',
        'NOREPLY_EMAIL': 'noreply@myapp.com',
        'SERVER_HEADER': 'MyApp',
        'PASSWORD_CHECKER_USER_AGENT': 'MyApp-PasswordChecker/1.0',
        'CELERY_APP_NAME': 'my_application',
        'CACHE_KEY_PREFIX': 'myapp',
        'MOBILE_APP_IDENTIFIERS': ['my-app-ios', 'my-app-android'],
        'ENABLE_MONITORING_PERSISTENCE': True,
    }
"""

from django.core.exceptions import ImproperlyConfigured

_UNSET = object()  # sentinel — distinguishes "not given" from None


def nimoh_setting(key: str, default=_UNSET):
    """
    Read a value from the consumer project's ``NIMOH_BASE`` dict at runtime.

    This is the **canonical accessor** that all package code should use when
    it needs a ``NIMOH_BASE`` value during a request/task (i.e. after Django
    is fully loaded).  Never read ``settings.NIMOH_BASE`` directly in package
    code — always go through this helper so the key name is validated and the
    call site is easy to grep.

    Args:
        key:     The ``NIMOH_BASE`` dict key (e.g. ``'SITE_NAME'``).
        default: Value returned when the key is absent.  Omit to raise
                 ``ImproperlyConfigured`` on a missing key (same behaviour
                 as ``NIMOH_BASE[key]``).

    Returns:
        The configured value, or *default* if provided and key is absent.

    Raises:
        ``ImproperlyConfigured`` if the key is absent and no default is given.

    Examples::

        from nimoh_base.conf import nimoh_setting

        site_name = nimoh_setting('SITE_NAME')
        ua = nimoh_setting('PASSWORD_CHECKER_USER_AGENT', 'Django-Password-Validator')
    """
    from django.conf import settings as _s

    nimoh = getattr(_s, "NIMOH_BASE", {})
    if key in nimoh:
        return nimoh[key]
    if default is not _UNSET:
        return default
    raise ImproperlyConfigured(
        f"NIMOH_BASE['{key}'] is not configured. Add it to the NIMOH_BASE dict in your Django settings."
    )


# ──────────────────────────────────────────────────
# Required keys — ImproperlyConfigured raised if any
# are absent from NIMOH_BASE dict at startup.
# ──────────────────────────────────────────────────
REQUIRED_NIMOH_BASE_KEYS = [
    "SITE_NAME",
    "SUPPORT_EMAIL",
    "NOREPLY_EMAIL",
]

# Keys that have safe defaults and are therefore optional
OPTIONAL_NIMOH_BASE_DEFAULTS = {
    "SERVER_HEADER": "",
    "PASSWORD_CHECKER_USER_AGENT": "Django-Password-Validator",
    "CELERY_APP_NAME": "django-app",
    "CACHE_KEY_PREFIX": "app",
    "MOBILE_APP_IDENTIFIERS": [],
    "ENABLE_MONITORING_PERSISTENCE": False,
    # Set to False to skip the Celery worker check in /api/v1/health/.
    # Useful when running without a Celery worker (e.g. local dev, CI).
    "HEALTH_CHECK_CELERY": True,
    # Account lockout — override in NIMOH_BASE to tune per-project.
    "MAX_LOGIN_ATTEMPTS": 5,
    "ACCOUNT_LOCK_DURATION_MINUTES": 30,
}


def validate_nimoh_base_settings() -> None:
    """
    Called from ``CoreConfig.ready()`` to assert all required keys exist.

    Raises ``ImproperlyConfigured`` with a descriptive message listing every
    missing key so the developer can fix them all at once.
    """
    from django.conf import settings

    nimoh = getattr(settings, "NIMOH_BASE", None)
    if nimoh is None:
        raise ImproperlyConfigured(
            "nimoh-be-django-base requires a NIMOH_BASE = {} dict in your "
            "Django settings. At minimum the following keys must be set: " + ", ".join(REQUIRED_NIMOH_BASE_KEYS)
        )

    missing = [k for k in REQUIRED_NIMOH_BASE_KEYS if k not in nimoh]
    if missing:
        raise ImproperlyConfigured(
            f"NIMOH_BASE is missing the following required keys: {', '.join(missing)}. "
            "Add them to your NIMOH_BASE dict in Django settings."
        )


class NimohBaseSettings:
    """
    Static helper that returns composable default settings blocks.

    Each method returns a standalone value — it is never mutated in place.
    Consumer projects can override at any granularity::

        # Use the full set of base apps
        INSTALLED_APPS = NimohBaseSettings.get_base_apps() + ['myapp']

        # Override just one DRF key
        REST_FRAMEWORK = {
            **NimohBaseSettings.get_base_rest_framework(),
            'PAGE_SIZE': 50,
        }
    """

    # ── Core Django app list ───────────────────────────────────────────────
    DJANGO_APPS = [
        "django.contrib.admin",
        "django.contrib.auth",
        "django.contrib.contenttypes",
        "django.contrib.sessions",
        "django.contrib.messages",
        "django.contrib.staticfiles",
    ]

    THIRD_PARTY_APPS = [
        "rest_framework",
        "rest_framework_simplejwt",
        "rest_framework_simplejwt.token_blacklist",
        "corsheaders",
        "drf_spectacular",
        "django_filters",
        "django_otp",
        "django_otp.plugins.otp_totp",
        "django_otp.plugins.otp_static",
        "django_celery_beat",
        "django_celery_results",
        "channels",
    ]

    NIMOH_APPS = [
        "nimoh_base.core",
        "nimoh_base.auth",
        "nimoh_base.monitoring",
        "nimoh_base.privacy",
    ]

    @classmethod
    def get_base_apps(cls, *, include_monitoring: bool = True, include_privacy: bool = True) -> list:
        """
        Return the full recommended ``INSTALLED_APPS`` list.

        Args:
            include_monitoring: Include ``nimoh_base.monitoring`` app.
            include_privacy: Include ``nimoh_base.privacy`` app.
        """
        nimoh_apps = ["nimoh_base.core", "nimoh_base.auth"]
        if include_monitoring:
            nimoh_apps.append("nimoh_base.monitoring")
        if include_privacy:
            nimoh_apps.append("nimoh_base.privacy")
        return cls.DJANGO_APPS + cls.THIRD_PARTY_APPS + nimoh_apps

    @classmethod
    def get_base_middleware(cls) -> list:
        """Return the default ordered MIDDLEWARE list."""
        return [
            "django.middleware.security.SecurityMiddleware",
            "whitenoise.middleware.WhiteNoiseMiddleware",
            "corsheaders.middleware.CorsMiddleware",
            "django.contrib.sessions.middleware.SessionMiddleware",
            "django.middleware.common.CommonMiddleware",
            "django.middleware.csrf.CsrfViewMiddleware",
            "django.contrib.auth.middleware.AuthenticationMiddleware",
            "django.contrib.messages.middleware.MessageMiddleware",
            "django.middleware.clickjacking.XFrameOptionsMiddleware",
            "nimoh_base.core.security.headers.SecurityHeadersMiddleware",
            "nimoh_base.core.middleware.performance.PerformanceMonitoringMiddleware",
            "nimoh_base.core.middleware.error_handling.ErrorHandlingMiddleware",
        ]

    @classmethod
    def get_base_rest_framework(cls) -> dict:
        """Return the default REST_FRAMEWORK configuration dict."""
        return {
            "DEFAULT_AUTHENTICATION_CLASSES": [
                "rest_framework_simplejwt.authentication.JWTAuthentication",
            ],
            "DEFAULT_PERMISSION_CLASSES": [
                "rest_framework.permissions.IsAuthenticated",
            ],
            "DEFAULT_RENDERER_CLASSES": [
                "rest_framework.renderers.JSONRenderer",
            ],
            "DEFAULT_PARSER_CLASSES": [
                "rest_framework.parsers.JSONParser",
                "rest_framework.parsers.FormParser",
                "rest_framework.parsers.MultiPartParser",
            ],
            "DEFAULT_PAGINATION_CLASS": "rest_framework.pagination.PageNumberPagination",
            "PAGE_SIZE": 20,
            "DEFAULT_FILTER_BACKENDS": [
                "django_filters.rest_framework.DjangoFilterBackend",
                "rest_framework.filters.SearchFilter",
                "rest_framework.filters.OrderingFilter",
            ],
            "DEFAULT_SCHEMA_CLASS": "drf_spectacular.openapi.AutoSchema",
            "DEFAULT_THROTTLE_CLASSES": [
                "rest_framework.throttling.AnonRateThrottle",
                "rest_framework.throttling.UserRateThrottle",
            ],
            "DEFAULT_THROTTLE_RATES": {
                "anon": "100/day",
                "user": "1000/day",
            },
            "EXCEPTION_HANDLER": "nimoh_base.core.exceptions.custom_exception_handler",
        }

    @classmethod
    def get_base_simple_jwt(cls) -> dict:
        """Return the default SIMPLE_JWT configuration dict."""
        from datetime import timedelta

        return {
            "ACCESS_TOKEN_LIFETIME": timedelta(minutes=15),
            "REFRESH_TOKEN_LIFETIME": timedelta(days=7),
            "ROTATE_REFRESH_TOKENS": True,
            "BLACKLIST_AFTER_ROTATION": True,
            "UPDATE_LAST_LOGIN": True,
            "ALGORITHM": "HS256",
            "AUTH_HEADER_TYPES": ("Bearer",),
            "USER_ID_FIELD": "id",
            "USER_ID_CLAIM": "user_id",
        }

    @classmethod
    def get_base_spectacular_settings(
        cls,
        title: str = "API",
        description: str = "",
        version: str = "1.0.0",
    ) -> dict:
        """Return the default DRF Spectacular (OpenAPI) settings.

        Args:
            title: API title shown in the OpenAPI schema.
            description: API description shown in the OpenAPI schema.
            version: API version string.
        """
        return {
            "TITLE": title,
            "DESCRIPTION": description,
            "VERSION": version,
            "SERVE_INCLUDE_SCHEMA": False,
            "COMPONENT_SPLIT_REQUEST": True,
        }

    @classmethod
    def get_base_caches(cls, key_prefix: str = "app", redis_url: str = "redis://localhost:6379/1") -> dict:
        """
        Return the default CACHES configuration using django-redis.

        Args:
            key_prefix: The cache key prefix (from ``NIMOH_BASE['CACHE_KEY_PREFIX']``).
            redis_url: Redis connection URL.
        """
        return {
            "default": {
                "BACKEND": "django_redis.cache.RedisCache",
                "LOCATION": redis_url,
                "OPTIONS": {
                    "CLIENT_CLASS": "django_redis.client.DefaultClient",
                    "IGNORE_EXCEPTIONS": True,
                },
                "KEY_PREFIX": key_prefix,
                "TIMEOUT": 300,
            }
        }

    @classmethod
    def get_base_logging(cls, log_level: str = "INFO") -> dict:
        """Return the default LOGGING configuration.

        Uses :class:`nimoh_base.core.logging.DevConsoleFormatter` for
        human-friendly, coloured console output in development / Docker dev
        environments, and keeps a plain ``verbose`` formatter as a fallback.

        ``SensitiveDataFilter`` is attached to the console handler to redact
        passwords, tokens and API keys before they reach the terminal.

        Args:
            log_level: Root logger level (default: 'INFO').
        """
        return {
            "version": 1,
            "disable_existing_loggers": False,
            # ── Filters ───────────────────────────────────────────────────
            "filters": {
                "sensitive_data": {
                    "()": "nimoh_base.core.logging.SensitiveDataFilter",
                },
            },
            # ── Formatters ────────────────────────────────────────────────
            "formatters": {
                # Human-friendly coloured output (dev / Docker dev)
                "dev_console": {
                    "()": "nimoh_base.core.logging.DevConsoleFormatter",
                },
                # Single-line JSON — for production / log-aggregation
                "json": {
                    "()": "nimoh_base.core.logging.JsonFormatter",
                },
                # Plain verbose fallback (non-colour environments / files)
                "verbose": {
                    "format": "{levelname} {asctime} {name} {module} {message}",
                    "style": "{",
                },
                # Coloured startup banner (nimoh_base.core.startup)
                "colored": {
                    "()": "nimoh_base.core.startup.ColoredFormatter",
                    "format": "%(levelname)s %(message)s",
                },
            },
            # ── Handlers ──────────────────────────────────────────────────
            "handlers": {
                "console": {
                    "class": "logging.StreamHandler",
                    "formatter": "dev_console",
                    "filters": ["sensitive_data"],
                },
                "startup": {
                    "class": "logging.StreamHandler",
                    "formatter": "colored",
                },
            },
            # ── Root ──────────────────────────────────────────────────────
            "root": {
                "handlers": ["console"],
                "level": log_level,
            },
            # ── Named loggers ─────────────────────────────────────────────
            "loggers": {
                "nimoh_base": {
                    "handlers": ["console"],
                    "level": log_level,
                    "propagate": False,
                },
                "django": {
                    "handlers": ["console"],
                    "level": "INFO",
                    "propagate": False,
                },
                "django.db.backends": {
                    "handlers": ["console"],
                    "level": "WARNING",  # suppress SQL noise by default
                    "propagate": False,
                },
                "django.utils.autoreload": {
                    "handlers": ["console"],
                    "level": "WARNING",  # suppress autoreload chatter
                    "propagate": False,
                },
                "celery": {
                    "handlers": ["console"],
                    "level": "INFO",
                    "propagate": False,
                },
                "celery.task": {
                    "handlers": ["console"],
                    "level": "INFO",
                    "propagate": False,
                },
                # App-level loggers
                "apps": {
                    "handlers": ["console"],
                    "level": log_level,
                    "propagate": False,
                },
                "security": {
                    "handlers": ["console"],
                    "level": "INFO",
                    "propagate": False,
                },
                "performance": {
                    "handlers": ["console"],
                    "level": "INFO",
                    "propagate": False,
                },
                # startup banner
                "startup": {
                    "handlers": ["startup"],
                    "level": "INFO",
                    "propagate": False,
                },
                # Third-party noise reduction
                "urllib3": {
                    "handlers": ["console"],
                    "level": "WARNING",
                    "propagate": False,
                },
                "boto3": {
                    "handlers": ["console"],
                    "level": "WARNING",
                    "propagate": False,
                },
                "botocore": {
                    "handlers": ["console"],
                    "level": "WARNING",
                    "propagate": False,
                },
            },
        }

    @classmethod
    def get_base_celery(cls, broker_url: str = "redis://localhost:6379/0", result_backend: str = "django-db") -> dict:
        """
        Return the default Celery / Django-Celery configuration dict.

        Keys are in Django settings format (``CELERY_``-prefixed).

        Args:
            broker_url:      Celery broker URL (default: Redis db 0).
            result_backend:  Celery result backend. ``'django-db'`` uses
                             ``django-celery-results``; pass a Redis URL for
                             pure-Redis results.
        """
        return {
            "CELERY_BROKER_URL": broker_url,
            "CELERY_RESULT_BACKEND": result_backend,
            "CELERY_ACCEPT_CONTENT": ["json"],
            "CELERY_TASK_SERIALIZER": "json",
            "CELERY_RESULT_SERIALIZER": "json",
            "CELERY_TIMEZONE": "UTC",
            "CELERY_TASK_TRACK_STARTED": True,
            "CELERY_TASK_TIME_LIMIT": 30 * 60,  # 30 minutes hard limit
            "CELERY_TASK_SOFT_TIME_LIMIT": 25 * 60,  # 25 minutes soft limit
            "CELERY_WORKER_PREFETCH_MULTIPLIER": 1,
            "CELERY_TASK_ACKS_LATE": True,
            "CELERY_WORKER_MAX_TASKS_PER_CHILD": 1000,
        }

    @classmethod
    def get_base_celery_beat(cls) -> dict:
        """
        Return the default ``CELERY_BEAT_SCHEDULE`` dict.

        Consumer projects extend this by merging their own tasks::

            CELERY_BEAT_SCHEDULE = {
                **NimohBaseSettings.get_base_celery_beat(),
                'my-task': {
                    'task': 'myapp.tasks.my_task',
                    'schedule': crontab(hour=8, minute=30),
                },
            }
        """
        from celery.schedules import crontab

        return {
            "cleanup-expired-sessions": {
                "task": "nimoh_base.auth.tasks.cleanup_expired_sessions",
                "schedule": crontab(hour=2, minute=0),
            },
            "cleanup-expired-tokens": {
                "task": "nimoh_base.auth.tasks.cleanup_old_tokens",
                "schedule": crontab(hour=3, minute=0),
            },
        }

    @classmethod
    def get_base_channels(cls, redis_url: str = "redis://localhost:6379/2") -> dict:
        """
        Return the default ``CHANNEL_LAYERS`` configuration (django-channels + redis).

        Args:
            redis_url: Redis URL for the channel layer (default: db 2).
        """
        return {
            "default": {
                "BACKEND": "channels_redis.core.RedisChannelLayer",
                "CONFIG": {
                    "hosts": [redis_url],
                    "capacity": 1500,
                    "expiry": 10,
                },
            }
        }

    @classmethod
    def get_base_security_settings(cls, *, https: bool = False) -> dict:
        """
        Return Django security-hardening settings.

        Args:
            https: When ``True``, enable HSTS and force HTTPS redirects
                   (suitable for production; leave ``False`` in development).

        Returns:
            A flat dict of ``SECURE_*``, ``SESSION_*``, and ``CSRF_*`` settings
            that can be spread into the consumer project's ``settings`` module::

                locals().update(NimohBaseSettings.get_base_security_settings(https=True))
        """
        config = {
            # CSRF
            "CSRF_COOKIE_HTTPONLY": True,
            "CSRF_COOKIE_SAMESITE": "Strict",
            # Sessions
            "SESSION_COOKIE_HTTPONLY": True,
            "SESSION_COOKIE_SAMESITE": "Lax",
            "SESSION_COOKIE_AGE": 86400,  # 24 hours
            # Clickjacking / content-type sniffing
            "X_FRAME_OPTIONS": "DENY",
            "SECURE_CONTENT_TYPE_NOSNIFF": True,
            "SECURE_BROWSER_XSS_FILTER": True,
            # Referrer
            "SECURE_REFERRER_POLICY": "strict-origin-when-cross-origin",
            # Password hashing — prefer Argon2 (memory-hard), fall back to
            # PBKDF2 so existing hashes remain usable after upgrade.
            "PASSWORD_HASHERS": [
                "django.contrib.auth.hashers.Argon2PasswordHasher",
                "django.contrib.auth.hashers.PBKDF2PasswordHasher",
            ],
        }
        if https:
            config.update(
                {
                    "SECURE_SSL_REDIRECT": True,
                    "SECURE_HSTS_SECONDS": 31_536_000,  # 1 year
                    "SECURE_HSTS_INCLUDE_SUBDOMAINS": True,
                    "SECURE_HSTS_PRELOAD": True,
                    "CSRF_COOKIE_SECURE": True,
                    "SESSION_COOKIE_SECURE": True,
                    # Tell Django it's behind an HTTPS-terminating reverse proxy.
                    # Without this, request.is_secure() is always False behind
                    # nginx/Caddy and HSTS headers are never emitted.
                    "SECURE_PROXY_SSL_HEADER": ("HTTP_X_FORWARDED_PROTO", "https"),
                }
            )
        return config

    @classmethod
    def get_base_cors(cls, allowed_origins: list[str] | None = None) -> dict:
        """
        Return the default ``django-cors-headers`` configuration.

        Args:
            allowed_origins: Explicit list of allowed origins.  When ``None``
                             the dict is returned without ``CORS_ALLOWED_ORIGINS``
                             so consumers can set it or use ``CORS_ALLOW_ALL_ORIGINS``
                             themselves.
        """
        config: dict = {
            "CORS_ALLOW_CREDENTIALS": True,
            "CORS_ALLOW_HEADERS": [
                "accept",
                "accept-encoding",
                "authorization",
                "content-type",
                "dnt",
                "origin",
                "user-agent",
                "x-csrftoken",
                "x-requested-with",
            ],
            "CORS_EXPOSE_HEADERS": ["Content-Type", "X-CSRFToken"],
        }
        if allowed_origins is not None:
            config["CORS_ALLOWED_ORIGINS"] = allowed_origins
        return config
