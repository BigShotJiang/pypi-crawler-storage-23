"""Klisk Assistant — AI-powered helper for building agents."""

from klisk.assistant.run import run_assistant

__all__ = ["run_assistant"]
