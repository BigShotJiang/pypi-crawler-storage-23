# Traceflow AI (SDK)

AI/LLM observability: capture prompts, completions, tokens, cost, and latency; send traces to your dashboard.

## Install

```bash
pip install traceflow-ai[openai]
```

## Use

```python
import traceflow_ai
traceflow_ai.init(endpoint="http://localhost:8000")
# Use openai.chat.completions.create(...) as usual — traces appear in the dashboard
```

Optional: run the dashboard (or your own ingest API) so traces have somewhere to go.

## PyPI

- **Package:** [traceflow-ai](https://pypi.org/project/traceflow-ai/)
- **Import:** `import traceflow_ai`
