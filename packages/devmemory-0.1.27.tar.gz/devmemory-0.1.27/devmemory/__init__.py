__version__ = "0.1.27"
__app_name__ = "devmemory"
