# Copyright 2026 Flyto2. Licensed under Apache-2.0. See LICENSE.

"""
Shell Operation Modules
Execute shell commands and scripts
"""

from .exec import shell_exec

__all__ = ['shell_exec']
