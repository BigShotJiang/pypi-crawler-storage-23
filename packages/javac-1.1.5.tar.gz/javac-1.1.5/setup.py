from setuptools import setup, find_packages
import io
import os

def read(fname):
    return io.open(os.path.join(os.path.dirname(__file__), fname), encoding="utf-8").read()

setup(
    name="javac",  # must be unique on PyPI
    version="1.1.5",
    author="kya dekh rha hai luvday",
    author_email="xyz@gmail.com",
    description="Teri Maa ne bhoot ke sath suhagrat rachai thi woh bhoot huh mein ",
    long_description=read("README.md"),
    long_description_content_type="text/markdown",
    url="",  # optional
    packages=find_packages(),
    include_package_data=True,
    install_requires=[],
    license="MIT",  # ✅ SPDX-compliant license declaration
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)
