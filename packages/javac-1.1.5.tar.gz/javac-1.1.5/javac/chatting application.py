#chatting application


import java.net.*;
import java.io.*;

class ChatServer {

    public static void main(String args[]) {

        try {
            // Create server socket on port 8000
            ServerSocket ss = new ServerSocket(8000);
            System.out.println("Waiting for client to connect...");

            // Accept client connection
            Socket s = ss.accept();
            System.out.println("Client connected!");

            // Read from client
            BufferedReader br = new BufferedReader(
                    new InputStreamReader(s.getInputStream()));

            // Read from server keyboard
            BufferedReader keyboard = new BufferedReader(
                    new InputStreamReader(System.in));

            // Send to client
            DataOutputStream out =
                    new DataOutputStream(s.getOutputStream());

            String receive, send;

            // Continuous chat
            while ((receive = br.readLine()) != null) {

                // Display client message
                System.out.println("Client says: " + receive);

                // Type reply from server
                send = keyboard.readLine();

                // Send reply
                out.writeBytes(send + "\n");
            }

            // Close all connections
            br.close();
            keyboard.close();
            out.close();
            s.close();
            ss.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}


#
import java.net.*;
import java.io.*;

class ChatClient {

    public static void main(String args[]) {

        try {
            // Connect to server
            Socket s = new Socket("localhost", 8000);
            System.out.println("Connected to server!");

            // Keyboard input
            BufferedReader keyboard = new BufferedReader(
                    new InputStreamReader(System.in));

            // Read from server
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(s.getInputStream()));

            // Send to server
            DataOutputStream out =
                    new DataOutputStream(s.getOutputStream());

            String msg, reply;

            System.out.println("Type STOP to end chat");

            // Continuous chat
            while (true) {

                // Send message
                msg = keyboard.readLine();
                out.writeBytes(msg + "\n");

                if (msg.equalsIgnoreCase("STOP"))
                    break;

                // Receive reply
                reply = in.readLine();
                System.out.println("Server says: " + reply);
            }

            // Close all resources
            keyboard.close();
            in.close();
            out.close();
            s.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}


