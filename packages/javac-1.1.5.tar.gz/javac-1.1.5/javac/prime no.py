#prime no
#client 
import java.net.*;
import java.io.*;

class ClientLine {
    public static void main(String args[]) {
        try {
            // Create socket connection to localhost on port 8001
            Socket s = new Socket("localhost", 8001);

            // Read input from keyboard
            BufferedReader br = new BufferedReader(
                    new InputStreamReader(System.in));

            System.out.print("Enter number: ");
            int a = Integer.parseInt(br.readLine());

            // Send data to server
            DataOutputStream out =
                    new DataOutputStream(s.getOutputStream());
            out.writeInt(a);

            // Receive data from server
            DataInputStream in =
                    new DataInputStream(s.getInputStream());
            System.out.println(in.readUTF());

            // Close socket
            s.close();
        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
    }
}

#server


Folder highlights
Java programs implement a TCP client and server to check if an integer input is prime over port 8001.

import java.net.*;
import java.io.*;

class ServerLine {

    public static void main(String args[]) {

        try {
            // Create server socket at port 8001
            ServerSocket ss = new ServerSocket(8001);

            System.out.println("Server started... Waiting for client");

            // Accept client connection
            Socket s = ss.accept();

            // Read number from client
            DataInputStream in =
                    new DataInputStream(s.getInputStream());

            int x = in.readInt();

            // Send result back to client
            DataOutputStream out =
                    new DataOutputStream(s.getOutputStream());

            boolean isPrime = true;

            if (x <= 1) {
                isPrime = false;
            } else {
                for (int i = 2; i <= x / 2; i++) {
                    if (x % i == 0) {
                        isPrime = false;
                        break;
                    }
                }
            }

            if (isPrime) {
                out.writeUTF(x + " is prime");
            } else {
                out.writeUTF(x + " is not prime");
            }

            // Close connection
            s.close();
            ss.close();

        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }
}



