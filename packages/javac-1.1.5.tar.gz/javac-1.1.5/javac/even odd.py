## even odd

import java.io.*;
import java.net.*;
public class prac4server{
    public static void main(String args[]) {
        try {            
            DatagramSocket ds = new DatagramSocket(2000);
            byte b[] = new byte[1024];           
            DatagramPacket dp = new DatagramPacket(b, b.length);
            ds.receive(dp);
            // Convert received bytes into string
            String str = new String(dp.getData(), 0, dp.getLength());
            System.out.println("Received number: " + str);
            // Convert string to integer
            int a = Integer.parseInt(str);
            String s;
            // Check even or odd
            if (a % 2 == 0)
                s = "Number is Even";
            else
                s = "Number is Odd";
            // Convert result into byte array
            byte b1[] = s.getBytes();
            // Send result back to client
            DatagramPacket dp1 = new DatagramPacket(
                    b1,
                    b1.length,
                    dp.getAddress(),
                    dp.getPort()
            );
            ds.send(dp1);
            ds.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}


##


Folder highlights
Java programs implement a UDP client-server check to determine if an entered number is even or odd.

import java.io.*;
import java.net.*;
public class prac4client {
    public static void main(String args[]) {
        try {
            // Create socket on port 1000
            DatagramSocket ds = new DatagramSocket(1000);
            // Take input from user
            BufferedReader br = new BufferedReader(
                    new InputStreamReader(System.in)
            );
            System.out.println("Enter a number:");
            String num = br.readLine();
            // Convert input to bytes
            byte b[] = num.getBytes();
            // Create packet to send to server (port 2000)
            DatagramPacket dp = new DatagramPacket(
                    b,
                    b.length,
                    InetAddress.getLocalHost(),
                    2000
            );
            ds.send(dp);
            // Receive response from server
            byte b1[] = new byte[1024];
            DatagramPacket dp1 = new DatagramPacket(b1, b1.length);
            ds.receive(dp1);
            // Convert response to string
            String str = new String(dp1.getData(), 0, dp1.getLength());
            System.out.println("Server Response: " + str);
            ds.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
