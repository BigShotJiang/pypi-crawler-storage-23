
#calculator

import java.net.*;
class RPCServer {
    DatagramSocket ds;
    DatagramPacket dp;
    String st1, methodName, result;
    int val1, val2;
    RPCServer() {
        try {
            ds = new DatagramSocket(1200);
            byte b[] = new byte[1024];
            System.out.println("RPC Server is running on port 1200...\n");
            while (true) {
                dp = new DatagramPacket(b, b.length);
                ds.receive(dp);   // receive client request
                st1 = new String(dp.getData(), 0, dp.getLength());
                if (st1.equalsIgnoreCase("q")) {
                    System.out.println("Server Stopped.");
                    break;
                }                
                String arr[] = st1.split(" ");
                methodName = arr[0];
                val1 = Integer.parseInt(arr[1]);
                val2 = Integer.parseInt(arr[2]);                
                if (methodName.equalsIgnoreCase("sub"))
                    result = String.valueOf(sub(val1, val2));
                else if (methodName.equalsIgnoreCase("mul"))
                    result = String.valueOf(mul(val1, val2));
                else if (methodName.equalsIgnoreCase("div"))
                    result = String.valueOf(div(val1, val2));
                else if (methodName.equalsIgnoreCase("add"))
                    result = String.valueOf(add(val1, val2));
                else
                    result = "Invalid Method";
                byte b1[] = result.getBytes();
                DatagramPacket dp1 = new DatagramPacket(
                        b1,
                        b1.length,
                        dp.getAddress(),
                        dp.getPort()
                );
                ds.send(dp1);
                System.out.println("Client Request: " + st1);
                System.out.println("Result Sent: " + result + "\n");
            }
            ds.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public int sub(int a, int b) {
        return a - b;
    }
    public int add(int a, int b) {
        return a + b;
    }
    public int mul(int a, int b) {
        return a * b;
    }
    public int div(int a, int b) {
        return a / b;
    }
    public static void main(String args[]) {
        new RPCServer();
    }
}


##
import java.net.*;
class RPCClient {
    RPCClient() {
        try {
            DatagramSocket ds = new DatagramSocket();  // create socket
            InetAddress ia = InetAddress.getLocalHost();
            BufferedReader br = new BufferedReader(
                    new InputStreamReader(System.in)
            );
            System.out.println("Enter method name and parameters like add 3 4:");
            String s = br.readLine();   // take input
            byte b[] = s.getBytes();
            DatagramPacket dp = new DatagramPacket(
                    b,
                    b.length,
                    ia,
                    1200
            );
            ds.send(dp);   // send request
            byte b1[] = new byte[1024];
            dp = new DatagramPacket(b1, b1.length);
            ds.receive(dp);   // receive response
            String s2 = new String(dp.getData(), 0, dp.getLength());
            System.out.println("\nResult = " + s2);
            ds.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void main(String args[]) {
        new RPCClient();
    }
}
