import java.net.*;

public class BroadcastClient {

    public static final int PORT = 1234;

    public static void main(String[] args) throws Exception {

        InetAddress group = InetAddress.getByName("239.1.2.3");

        // Create socket properly (modern way)
        MulticastSocket socket = new MulticastSocket(null);
        socket.setReuseAddress(true);
        socket.bind(new InetSocketAddress(PORT));

        // Get network interface
        NetworkInterface networkInterface =
                NetworkInterface.getByInetAddress(InetAddress.getLocalHost());

        // Join multicast group
        socket.joinGroup(new InetSocketAddress(group, PORT), networkInterface);

        System.out.println("Client started. Waiting for messages...");

        byte[] buffer = new byte[1024];

        while (true) {
            DatagramPacket packet =
                    new DatagramPacket(buffer, buffer.length);

            socket.receive(packet);

            String message = new String(
                    packet.getData(), 0, packet.getLength());

            System.out.println("Message received from "
                    + packet.getAddress()
                    + " : " + message);
        }
    }
}


###
import java.net.*;

public class BroadcastServer {

    public static final int PORT = 1234;

    public static void main(String[] args) throws Exception {

        // Multicast group address
        InetAddress group = InetAddress.getByName("239.1.2.3");

        // Create multicast socket
        MulticastSocket socket = new MulticastSocket();

        // Optional: keep multicast within local network
        socket.setTimeToLive(1);

        // Wait for 10 seconds before sending
        Thread.sleep(10000);

        System.out.println("Sending message...");

        String message = "This is Mohit calling...";
        byte[] buffer = message.getBytes();

        // Create datagram packet
        DatagramPacket packet =
                new DatagramPacket(buffer, buffer.length, group, PORT);

        // Send packet
        socket.send(packet);

        System.out.println("Message sent successfully.");

        socket.close();
    }
}
run javac *.java
java BroadcastClient
java BroadcastServer
