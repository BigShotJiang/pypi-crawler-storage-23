# `Thread Options`

::: agents.extensions.experimental.codex.thread_options
