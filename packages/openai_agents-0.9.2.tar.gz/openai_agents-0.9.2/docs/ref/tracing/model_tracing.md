# `Model Tracing`

::: agents.tracing.model_tracing
