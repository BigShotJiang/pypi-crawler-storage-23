# `Session Settings`

::: agents.memory.session_settings
