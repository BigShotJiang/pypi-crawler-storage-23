# yostlabs-math

Math utilities for Yost Labs products, including quaternion, vector, and axes operations.

## Installation

```bash
pip install yostlabs-math
```
