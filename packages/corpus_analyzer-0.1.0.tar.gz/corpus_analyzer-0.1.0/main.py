def main():
    print("Hello from corpus-analyzer!")


if __name__ == "__main__":
    main()
