# [DRY RUN PLACEHOLDER] Observability Engineer

*   **Category**: runbook
*   **Source Path**: ../.agent/application-performance/agents/observability-engineer.md
*   **Template Used**: runbook.v1.md

## Mock Content
(This content is a placeholder. In a real run, the LLM would generate text here based on the template.)
