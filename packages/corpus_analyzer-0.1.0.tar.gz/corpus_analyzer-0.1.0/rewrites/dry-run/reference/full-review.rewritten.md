# [DRY RUN PLACEHOLDER] Full Review

*   **Category**: reference
*   **Source Path**: ../.agent/workflows/full-review.md
*   **Template Used**: reference.v1.md

## Mock Content
(This content is a placeholder. In a real run, the LLM would generate text here based on the template.)
