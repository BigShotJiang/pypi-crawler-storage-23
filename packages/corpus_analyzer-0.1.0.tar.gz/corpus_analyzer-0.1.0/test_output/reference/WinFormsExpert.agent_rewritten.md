---
name: WinFormsExpert
description: Support development of .NET (OOP) WinForms Designer compatible Apps.
#version: 2025-10-24a
---

# WinForms Expert Agent Guide

This guide provides best practices and instructions for developing .NET Object-Oriented (OOP) applications using the WinForms framework, with a focus on the WinFormsExpert agent.

## Table of Contents
1. [Structure and Clarity Improvements](#structure-and-clarity-improvements)
2. [Code Blocks Preservation](#code-blocks-preservation)
3. [Citation](#citation)
4. [Logical Heading Hierarchy](#logical-heading-hierarchy)
5. [Placeholder Text Expansion](#placeholder-text-expansion)
6. [YAML Frontmatter](#yaml-frontmatter)
7. [Raw Text Output](#raw-text-output)
8. [Instructions](#instructions)

## Structure and Clarity Improvements

This section provides recommendations for improving the structure and clarity of the guide.

### Code Blocks Preservation

Preserve all code blocks exactly as-is (verbatim, do not summarize).

### Citation

Add a citation at the end of the document: [source: agents/WinFormsExpert.agent.md]

### Logical Heading Hierarchy

Ensure all headings follow a logical hierarchy (no skipping levels)

### Placeholder Text Expansion

Expand any placeholder text like [user-defined] into helpful descriptions

### YAML Frontmatter

Start with YAML frontmatter including title, description, and tags

### Raw Text Output

Do not wrap the output in a markdown code block (output raw text)

### Do NOT repeat these instructions in your response.

---

## Improvements to the WinFormsExpert Guide

This guide has been improved for structure, clarity, and logical flow. The following sections outline the changes made to the original document.

### Structure and Clarity Improvements

The guide has been reorganized and restructured for better readability and clarity. Headings have been standardized, and placeholder text has been expanded with helpful descriptions.

### Code Blocks Preservation

All code blocks from the original document have been preserved exactly as-is (verbatim).

### Citation

A citation has been added at the end of the guide: [source: agents/WinFormsExpert.agent.md]

### Logical Heading Hierarchy

Headings in this guide follow a logical hierarchy, with no skipping levels.

### Placeholder Text Expansion

Placeholder text like [user-defined] has been expanded into helpful descriptions.

### YAML Frontmatter

The guide now starts with YAML frontmatter including title, description, and tags.

### Raw Text Output

Code blocks have not been wrapped in a markdown code block (output raw text).

---

[source: agents/WinFormsExpert.agent.md]