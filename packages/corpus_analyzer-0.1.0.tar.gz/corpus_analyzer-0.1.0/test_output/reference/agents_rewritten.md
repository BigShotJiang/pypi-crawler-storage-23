---
title: SuperClaude エージェントガイド 🤖
source: docs/User-Guide-jp/agents.md
---

# Agents in SuperClaude Framework

This document outlines various agents that can be used within the SuperClaude Framework, each specializing in a specific area of system management and optimization.

## System Architects 🏗️

**Primary Focus**: Designing scalable and maintainable architectures for applications and systems.

**Key Responsibilities**:
- Defining system architecture principles and guidelines
- Collaborating with other agents to ensure alignment with overall system goals
- Overseeing the design and implementation of various components, such as APIs, databases, and frontends
- Ensuring scalability, reliability, and maintainability throughout the system

## Frontend Engineers 🖥️

**Primary Focus**: Designing and building user interfaces that are responsive, intuitive, and visually appealing.

**Key Responsibilities**:
- Creating wireframes, prototypes, and mockups for new features or improvements
- Implementing frontend components using modern web technologies (HTML, CSS, JavaScript)
- Ensuring cross-browser compatibility and responsive design principles
- Collaborating with UX/UI designers to create visually appealing interfaces

## Backend Engineers 💻

**Primary Focus**: Designing and building the backend services that power applications and systems.

**Key Responsibilities**:
- Developing APIs, databases, and other backend components
- Writing efficient, scalable, and maintainable code
- Collaborating with frontend engineers to ensure seamless integration between frontend and backend components
- Ensuring data integrity, security, and performance of the backend services

## DevOps Engineers 🔧

**Primary Focus**: Managing the development, deployment, and maintenance of applications and systems in production environments.

**Key Responsibilities**:
- Configuring and maintaining continuous integration/continuous delivery (CI/CD) pipelines
- Ensuring system availability, scalability, and security through monitoring, logging, and alerting
- Collaborating with other agents to address any issues that arise in production environments
- Automating repetitive tasks and processes to improve efficiency and reduce human error

## Quality & Analysis Agents 🔍

### Test Engineers 🧪

**Primary Focus**: Designing, implementing, and maintaining test suites for applications and systems.

**Key Responsibilities**:
- Creating unit tests, integration tests, and end-to-end tests to validate system behavior
- Collaborating with developers to ensure test coverage is adequate and effective
- Analyzing test results to identify issues and suggest improvements
- Participating in code reviews to ensure adherence to testing best practices

### Performance Engineers ⚡

**Primary Focus**: Optimizing the performance of applications and systems by identifying bottlenecks, improving resource utilization, and reducing latency.

**Key Responsibilities**:
- Profiling application performance to identify areas for improvement
- Implementing caching strategies, database optimizations, and other performance enhancements
- Collaborating with developers to ensure code is written in an efficient manner
- Conducting load testing and stress testing to validate system performance under various conditions

### Security Engineers 🔒

**Primary Focus**: Protecting applications and systems from threats by implementing security measures, such as encryption, authentication, and authorization.

**Key Responsibilities**:
- Designing and implementing secure architectures for applications and systems
- Conducting vulnerability assessments and penetration testing to identify potential weaknesses
- Collaborating with developers to ensure adherence to security best practices
- Staying up-to-date on the latest security threats and trends, and implementing countermeasures as necessary

### Root Cause Analysts 🔍

**Primary Focus**: Identifying and addressing the underlying causes of system issues, rather than just treating symptoms.

**Key Responsibilities**:
- Investigating system failures, performance degradation, and other issues to determine their root cause
- Collaborating with other agents to develop and implement solutions to address identified issues
- Documenting lessons learned and best practices for future reference
- Participating in postmortem analyses to identify opportunities for improvement

[source: docs/User-Guide-jp/agents.md]