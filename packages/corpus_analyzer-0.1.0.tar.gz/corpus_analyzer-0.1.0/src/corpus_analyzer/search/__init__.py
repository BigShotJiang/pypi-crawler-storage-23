"""Search module for corpus-analyzer.

Provides hybrid BM25+vector search, construct type classification,
AI summary generation, and result formatting.
"""
