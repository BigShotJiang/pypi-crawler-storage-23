"""Python public API package for corpus semantic search."""
