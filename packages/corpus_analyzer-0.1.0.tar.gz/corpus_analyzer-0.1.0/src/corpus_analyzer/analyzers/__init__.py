"""Analyzers package."""

from corpus_analyzer.analyzers.shape import ShapeReport, generate_shape_reports

__all__ = ["ShapeReport", "generate_shape_reports"]
