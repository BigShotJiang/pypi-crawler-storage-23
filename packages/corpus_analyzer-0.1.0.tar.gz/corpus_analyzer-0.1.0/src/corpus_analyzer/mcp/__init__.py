"""MCP server package for corpus semantic search."""
