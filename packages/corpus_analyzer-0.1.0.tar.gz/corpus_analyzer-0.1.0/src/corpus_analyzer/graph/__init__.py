"""Relationship graph extraction and storage for corpus-analyzer."""
