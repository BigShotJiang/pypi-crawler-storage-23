"""Document Corpus Analyzer - Extract, categorize, analyze, and template documentation."""

__version__ = "0.1.0"
