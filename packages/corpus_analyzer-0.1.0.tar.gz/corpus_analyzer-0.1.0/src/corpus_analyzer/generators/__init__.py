"""Generators package."""

from corpus_analyzer.generators.templates import generate_from_analysis

__all__ = ["generate_from_analysis"]
