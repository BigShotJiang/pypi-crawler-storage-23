from typing import Optional, Callable
from .errors import (
    AutomationDecoratorCannotBeUsedTwiceError,
    AutomationNameCannotBeEmptyError,
    InvalidAutomationError,
)

_automation_name: Optional[str] = None
_automation_callable: Optional[Callable] = None

def reset_storage() -> None:
    """
    Reset the data from the decorators
    """
    global _automation_name, _automation_callable
    _automation_name = None
    _automation_callable = None

def get_automation_callable() -> Optional[Callable]:
    """
    Get the callable of the automation
    """
    return _automation_callable

def set_automation_callable(automation: str, automation_callable: Callable) -> None:
    """
    Set the callable of the automation
    """
    global _automation_name, _automation_callable
    if _automation_name is not None:
        raise AutomationDecoratorCannotBeUsedTwiceError()
    if automation == "" or automation is None:
        raise AutomationNameCannotBeEmptyError()
    if type(automation) != str:
        raise InvalidAutomationError("Automation name must be a string")
    if automation_callable is None or not callable(automation_callable):
        raise InvalidAutomationError("Automation callable must be a callable")
    
    _automation_name = automation
    _automation_callable = automation_callable