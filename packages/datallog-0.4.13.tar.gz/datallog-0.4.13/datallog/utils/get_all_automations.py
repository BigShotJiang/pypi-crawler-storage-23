
import pathlib
from typing import List

from .errors import InvalidAutomationError

def get_all_automations(path: pathlib.Path) -> List[str]:
    automations = []
    automation_dir = path / "automations"
    if not automation_dir.exists():
        raise InvalidAutomationError(f"Automation directory not found at {automation_dir}")
    for automation in automation_dir.iterdir():
        if automation.is_dir():
            automation_name = automation.name
            if automation_name.startswith(".") or automation_name == "__pycache__":
                continue
            automation = automation / f"{automation_name}.py"
            if automation.exists():
                automations.append(automation_name)
    return automations