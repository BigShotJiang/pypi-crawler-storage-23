import json
from pathlib import Path
import sys
import threading
from typing import Any, Dict
from .get_all_automations import get_all_automations
import json
from .import_module import  import_module
from .storage import reset_storage, get_automation_callable

def generate_build_file(project_dir: Path, output_file_path: Path) -> Dict[str, Any]:
    automations = get_all_automations(project_dir)

    build: Dict[str, Any] = {}
    automations_dir = project_dir / "automations"
    valid_automations = []
    print(f"Generating build file for automations in {automations_dir}")
    for automation_name in automations:
        try:
            automation_file = automations_dir / automation_name / f'{automation_name}.py'
            num_of_threads = threading.active_count()
            if not automation_file.exists():
                print(f"Warning: {automation_file} does not exist, skipping.")
                continue
            reset_storage()
            import_module(str(automation_file))
            if threading.active_count() > num_of_threads:
                print(f"Warning: {automation_name} has threads running, this may cause issues with the push.")
    
            if get_automation_callable() is None:
                print(f"Warning: {automation_name} does not define a datallog callable, skipping.")
                continue
            valid_automations.append(automation_name)
        except Exception as e:
            import traceback
            traceback.print_exc()
            print(f"Error generating build file for {automation_name}: {e}", file=sys.stderr)
            exit(1)
    build["automations"] = valid_automations
    with open(output_file_path, 'w') as f:
        json.dump(build, f, indent=4)

    return build


if __name__ == "__main__":

    project_dir = Path('/project')
    output_file_path = Path('/build.json')

    build_file = generate_build_file(project_dir, output_file_path)
    