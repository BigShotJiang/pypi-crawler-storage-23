"""Video Research MCP — unified research partner server."""

__version__ = "0.1.0"
