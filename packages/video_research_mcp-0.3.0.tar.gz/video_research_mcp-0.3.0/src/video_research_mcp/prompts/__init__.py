"""Prompt templates for Gemini calls."""
