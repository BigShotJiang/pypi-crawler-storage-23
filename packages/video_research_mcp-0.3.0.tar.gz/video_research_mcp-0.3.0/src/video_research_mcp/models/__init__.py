"""Pydantic models for tool inputs and outputs."""
