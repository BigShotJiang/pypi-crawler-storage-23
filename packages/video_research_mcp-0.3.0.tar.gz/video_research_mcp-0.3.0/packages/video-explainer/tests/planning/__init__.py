"""Tests for the planning module."""
