"""Tests for the refine module."""
