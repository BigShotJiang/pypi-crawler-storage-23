"""Video Explainer - Generate high-quality explainer videos from technical content."""

__version__ = "0.1.0"
