"""Command-line interface for video explainer pipeline."""

from .main import main

__all__ = ["main"]
