"""Video composition module - assemble final videos from assets."""

from .composer import VideoComposer

__all__ = ["VideoComposer"]
