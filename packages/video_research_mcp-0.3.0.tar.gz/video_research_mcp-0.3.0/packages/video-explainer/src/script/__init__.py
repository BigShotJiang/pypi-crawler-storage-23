"""Script generation module - create video scripts from content analysis."""

from .generator import ScriptGenerator

__all__ = ["ScriptGenerator"]
