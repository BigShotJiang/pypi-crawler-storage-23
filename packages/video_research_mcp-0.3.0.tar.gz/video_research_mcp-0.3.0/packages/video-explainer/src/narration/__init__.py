"""Narration generation module."""

from .generator import NarrationGenerator

__all__ = ["NarrationGenerator"]
