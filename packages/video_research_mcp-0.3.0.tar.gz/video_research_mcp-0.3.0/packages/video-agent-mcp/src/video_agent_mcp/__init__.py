"""video-agent-mcp — Parallel scene generation via Claude Agent SDK."""

__version__ = "0.1.0"
