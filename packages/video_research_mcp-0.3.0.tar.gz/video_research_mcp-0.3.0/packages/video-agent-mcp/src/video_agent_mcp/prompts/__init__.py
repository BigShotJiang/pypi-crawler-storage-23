"""Prompt templates extracted from video_explainer scene generator."""
