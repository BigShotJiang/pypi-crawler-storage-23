"""Video Explainer MCP — synthesize explainer videos from research output."""

__version__ = "0.1.0"
