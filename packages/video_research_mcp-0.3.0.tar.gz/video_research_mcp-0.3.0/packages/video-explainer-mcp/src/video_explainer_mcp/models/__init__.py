"""Data models for video explainer pipeline."""
