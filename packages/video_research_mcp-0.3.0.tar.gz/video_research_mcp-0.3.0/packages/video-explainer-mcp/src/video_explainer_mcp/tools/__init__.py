"""Tool sub-servers for video explainer MCP."""
