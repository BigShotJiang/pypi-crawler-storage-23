"""
SCDQ 模式 SCBench 评测
======================

Same Context Different Query - 模拟 KV Cache 复用场景。
要求：本地 vLLM Python API（支持 Automatic Prefix Caching）。
"""
