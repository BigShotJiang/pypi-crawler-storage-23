# SPDX-FileCopyrightText: 2025 OmniNode.ai Inc.
# SPDX-License-Identifier: MIT

"""
Severity level enumeration following ONEX standards.

This module re-exports EnumSeverity from omnibase_core for ONEX compliance.
Use this module for all severity level needs within OmniMemory.
"""

from omnibase_core.enums import EnumSeverity

__all__ = ["EnumSeverity"]
