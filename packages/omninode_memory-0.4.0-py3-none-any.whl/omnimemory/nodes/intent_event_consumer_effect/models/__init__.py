# SPDX-FileCopyrightText: 2025 OmniNode.ai Inc.
# SPDX-License-Identifier: MIT

"""Models for intent event consumer effect node."""

from omnimemory.nodes.intent_event_consumer_effect.models.model_consumer_config import (
    ModelIntentEventConsumerConfig,
)
from omnimemory.nodes.intent_event_consumer_effect.models.model_consumer_health import (
    ModelIntentEventConsumerHealth,
)

__all__ = [
    "ModelIntentEventConsumerConfig",
    "ModelIntentEventConsumerHealth",
]
