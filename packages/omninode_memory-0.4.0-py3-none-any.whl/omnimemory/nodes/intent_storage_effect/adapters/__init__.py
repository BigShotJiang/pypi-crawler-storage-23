# SPDX-FileCopyrightText: 2025 OmniNode.ai Inc.
# SPDX-License-Identifier: MIT

# Copyright (c) 2025 OmniNode Team
"""Intent storage effect adapters."""

from .adapter_intent_storage import HandlerIntentStorageAdapter

__all__ = [
    "HandlerIntentStorageAdapter",
]
