# -*- coding: utf-8 -*-

"""枚举开放代理订单级别
"""

class OpsOrderLevel(object):
    """开放代理订单级别"""
    NORMAL = "dev"  # 普通
    VIP = "dev"     # vip
    SVIP = "svip"   # svip
    PRO = "ent"     # 专业版
