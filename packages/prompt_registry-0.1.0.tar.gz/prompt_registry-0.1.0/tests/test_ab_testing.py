"""Tests for A/B testing -- deterministic selection, result recording, summaries."""

from __future__ import annotations

import pytest

from prompt_registry.ab_testing import PromptExperiment, _hash_bucket
from prompt_registry.models import ExperimentConfig


# ---------------------------------------------------------------------------
# Hash bucket
# ---------------------------------------------------------------------------


class TestHashBucket:
    def test_deterministic(self):
        b1 = _hash_bucket("user-1", "exp-a")
        b2 = _hash_bucket("user-1", "exp-a")
        assert b1 == b2

    def test_range(self):
        for i in range(200):
            bucket = _hash_bucket(f"user-{i}", "exp")
            assert 0.0 <= bucket < 1.0

    def test_different_users(self):
        buckets = {_hash_bucket(f"user-{i}", "exp") for i in range(100)}
        assert len(buckets) > 10  # reasonable spread

    def test_different_experiments(self):
        b1 = _hash_bucket("user-1", "exp-a")
        b2 = _hash_bucket("user-1", "exp-b")
        # Not guaranteed to differ, but both should be valid
        assert isinstance(b1, float) and isinstance(b2, float)


# ---------------------------------------------------------------------------
# Variant selection
# ---------------------------------------------------------------------------


class TestVariantSelection:
    def _make_experiment(self, split: list[float] | None = None) -> PromptExperiment:
        return PromptExperiment(
            ExperimentConfig(
                name="test-exp",
                variants=["1.0", "2.0"],
                traffic_split=split or [0.5, 0.5],
            )
        )

    def test_deterministic_selection(self):
        exp = self._make_experiment()
        v1 = exp.select_variant("user-1")
        v2 = exp.select_variant("user-1")
        assert v1 == v2

    def test_returns_valid_variant(self):
        exp = self._make_experiment()
        for i in range(100):
            variant = exp.select_variant(f"user-{i}")
            assert variant in ["1.0", "2.0"]

    def test_distribution_roughly_even(self):
        exp = self._make_experiment([0.5, 0.5])
        counts = {"1.0": 0, "2.0": 0}
        for i in range(1000):
            v = exp.select_variant(f"user-{i}")
            counts[v] += 1
        ratio = counts["1.0"] / 1000
        assert 0.35 < ratio < 0.65

    def test_heavily_skewed_split(self):
        exp = self._make_experiment([0.9, 0.1])
        counts = {"1.0": 0, "2.0": 0}
        for i in range(1000):
            v = exp.select_variant(f"user-{i}")
            counts[v] += 1
        # Variant 1.0 should dominate
        assert counts["1.0"] > counts["2.0"]

    def test_three_variants(self):
        exp = PromptExperiment(
            ExperimentConfig(
                name="triple",
                variants=["a", "b", "c"],
                traffic_split=[0.33, 0.34, 0.33],
            )
        )
        variants_seen = {exp.select_variant(f"u-{i}") for i in range(300)}
        assert len(variants_seen) >= 2  # should see at least 2 out of 3


# ---------------------------------------------------------------------------
# Result recording
# ---------------------------------------------------------------------------


class TestResultRecording:
    def test_record_result(self):
        exp = PromptExperiment(
            ExperimentConfig(name="e", variants=["1.0", "2.0"], traffic_split=[0.5, 0.5])
        )
        result = exp.record_result("1.0", "quality", 0.85)
        assert result.metric_value == 0.85
        assert result.variant == "1.0"

    def test_record_invalid_variant(self):
        exp = PromptExperiment(
            ExperimentConfig(name="e", variants=["1.0", "2.0"], traffic_split=[0.5, 0.5])
        )
        with pytest.raises(ValueError, match="Unknown variant"):
            exp.record_result("3.0", "quality", 0.5)

    def test_get_results_all(self):
        exp = PromptExperiment(
            ExperimentConfig(name="e", variants=["1.0", "2.0"], traffic_split=[0.5, 0.5])
        )
        exp.record_result("1.0", "q", 0.8)
        exp.record_result("2.0", "q", 0.9)
        assert len(exp.get_results()) == 2

    def test_get_results_filtered(self):
        exp = PromptExperiment(
            ExperimentConfig(name="e", variants=["1.0", "2.0"], traffic_split=[0.5, 0.5])
        )
        exp.record_result("1.0", "q", 0.8)
        exp.record_result("2.0", "q", 0.9)
        exp.record_result("1.0", "q", 0.7)
        results = exp.get_results("1.0")
        assert len(results) == 2

    def test_get_summary(self):
        exp = PromptExperiment(
            ExperimentConfig(name="e", variants=["1.0", "2.0"], traffic_split=[0.5, 0.5])
        )
        exp.record_result("1.0", "quality", 0.8)
        exp.record_result("1.0", "quality", 0.6)
        exp.record_result("2.0", "quality", 0.9)
        summary = exp.get_summary()
        assert abs(summary["1.0"]["quality"] - 0.7) < 1e-6
        assert abs(summary["2.0"]["quality"] - 0.9) < 1e-6

    def test_get_summary_empty(self):
        exp = PromptExperiment(
            ExperimentConfig(name="e", variants=["1.0", "2.0"], traffic_split=[0.5, 0.5])
        )
        assert exp.get_summary() == {}
