"""Tests for PromptTemplate -- rendering, validation, Jinja2 features."""

from __future__ import annotations

import pytest

from prompt_registry.models import Prompt, PromptMetadata
from prompt_registry.template import PromptTemplate


class TestSimpleRendering:
    def test_basic_variables(self):
        t = PromptTemplate("greet", "1.0", "Hello {name}, welcome to {place}!")
        result = t.render(name="Alice", place="Wonderland")
        assert result == "Hello Alice, welcome to Wonderland!"

    def test_single_variable(self):
        t = PromptTemplate("simple", "1.0", "Say {word}")
        assert t.render(word="hello") == "Say hello"

    def test_no_variables(self):
        t = PromptTemplate("static", "1.0", "No variables here")
        assert t.render() == "No variables here"

    def test_missing_variable_raises(self):
        t = PromptTemplate("greet", "1.0", "Hello {name}")
        with pytest.raises(ValueError, match="Missing required variables.*name"):
            t.render()

    def test_missing_one_of_many(self):
        t = PromptTemplate("multi", "1.0", "A={a} B={b} C={c}")
        with pytest.raises(ValueError, match="Missing required variables"):
            t.render(a="1", b="2")

    def test_extra_variables_ok(self):
        t = PromptTemplate("greet", "1.0", "Hello {name}")
        result = t.render(name="Bob", extra="ignored")
        assert result == "Hello Bob"


class TestJinja2Features:
    def test_conditional(self):
        template = "{% if formal %}Dear {{ name }}{% else %}Hey {{ name }}{% endif %}"
        t = PromptTemplate("greet", "1.0", template)
        assert t.render(formal=True, name="Alice") == "Dear Alice"
        assert t.render(formal=False, name="Bob") == "Hey Bob"

    def test_loop(self):
        template = "Items:{% for item in items %} {{ item }}{% endfor %}"
        t = PromptTemplate("list", "1.0", template)
        result = t.render(items=["a", "b", "c"])
        assert result == "Items: a b c"

    def test_filters(self):
        template = "{{ name | upper }}"
        t = PromptTemplate("upper", "1.0", template)
        assert t.render(name="alice") == "ALICE"

    def test_multiline_template(self):
        template = (
            "{% for item in items %}\n"
            "- {{ item }}\n"
            "{% endfor %}"
        )
        t = PromptTemplate("list", "1.0", template)
        result = t.render(items=["apple", "banana"])
        assert "- apple" in result
        assert "- banana" in result


class TestValidation:
    def test_validate_all_present(self):
        t = PromptTemplate("t", "1.0", "Hello {name}")
        assert t.validate({"name": "Bob"}) == []

    def test_validate_missing(self):
        t = PromptTemplate("t", "1.0", "{a} and {b}")
        missing = t.validate({"a": "1"})
        assert missing == ["b"]

    def test_validate_empty(self):
        t = PromptTemplate("t", "1.0", "no vars")
        assert t.validate({}) == []

    def test_variables_property(self):
        t = PromptTemplate("t", "1.0", "Hello {name}, your {item} is ready")
        assert t.variables == {"name", "item"}

    def test_variables_jinja2_syntax(self):
        t = PromptTemplate("t", "1.0", "Hello {{ name }}, your {{ item }}")
        assert "name" in t.variables
        assert "item" in t.variables


class TestMetadata:
    def test_metadata_stored(self):
        t = PromptTemplate(
            "test", "1.0", "Hello {name}",
            model="claude-sonnet-4-20250514", temperature=0.5, max_tokens=100,
        )
        assert t.metadata.model == "claude-sonnet-4-20250514"
        assert t.metadata.temperature == 0.5
        assert t.metadata.max_tokens == 100

    def test_default_metadata(self):
        t = PromptTemplate("test", "1.0", "Hello")
        assert t.metadata.model is None
        assert t.metadata.temperature is None


class TestConversion:
    def test_to_prompt(self):
        t = PromptTemplate("greet", "1.0", "Hello {name}", model="gpt-4")
        prompt = t.to_prompt()
        assert isinstance(prompt, Prompt)
        assert prompt.name == "greet"
        assert prompt.metadata.model == "gpt-4"

    def test_from_prompt(self):
        prompt = Prompt(
            name="sum",
            version="2.0",
            template="Summarize: {text}",
            metadata=PromptMetadata(temperature=0.3),
        )
        t = PromptTemplate.from_prompt(prompt)
        assert t.name == "sum"
        assert t.version == "2.0"
        assert t.metadata.temperature == 0.3
        assert t.render(text="hello") == "Summarize: hello"


class TestInvalidTemplate:
    def test_bad_jinja_syntax(self):
        with pytest.raises(ValueError, match="Invalid template syntax"):
            PromptTemplate("bad", "1.0", "{% if unclosed %}")


class TestRepr:
    def test_repr(self):
        t = PromptTemplate("test", "1.0", "hello")
        assert "test" in repr(t)
        assert "1.0" in repr(t)
