"""Tests for config module -- init, global registry, file-based loading."""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml

from prompt_registry.config import (
    PromptConfig,
    StoreType,
    get_registry,
    init_prompts,
    reset_registry,
)


@pytest.fixture(autouse=True)
def _clean_registry():
    """Reset global registry before and after each test."""
    reset_registry()
    yield
    reset_registry()


class TestInitPrompts:
    def test_default_memory_store(self):
        registry = init_prompts()
        assert registry is not None
        assert len(registry) == 0

    def test_with_config(self):
        config = PromptConfig(store_type=StoreType.memory)
        registry = init_prompts(config)
        assert registry is not None

    def test_file_store_loads_prompts(self, tmp_path: Path):
        (tmp_path / "greet.yaml").write_text(
            yaml.dump({"name": "greet", "version": "1.0", "template": "Hello {name}"})
        )
        config = PromptConfig(store_type=StoreType.file, prompts_dir=str(tmp_path))
        registry = init_prompts(config)
        assert len(registry) == 1
        t = registry.get("greet")
        assert t is not None
        assert t.render(name="World") == "Hello World"


class TestGetRegistry:
    def test_raises_if_not_initialized(self):
        with pytest.raises(RuntimeError, match="not initialized"):
            get_registry()

    def test_returns_registry_after_init(self):
        init_prompts()
        registry = get_registry()
        assert registry is not None


class TestResetRegistry:
    def test_reset(self):
        init_prompts()
        get_registry()  # should not raise
        reset_registry()
        with pytest.raises(RuntimeError):
            get_registry()


class TestPromptConfig:
    def test_defaults(self):
        config = PromptConfig()
        assert config.store_type == StoreType.memory
        assert config.database_url is None
        assert config.prompts_dir is None

    def test_file_config(self):
        config = PromptConfig(store_type=StoreType.file, prompts_dir="/prompts")
        assert config.store_type == StoreType.file
        assert config.prompts_dir == "/prompts"

    def test_database_config(self):
        config = PromptConfig(
            store_type=StoreType.database,
            database_url="postgresql://localhost/prompts",
        )
        assert config.store_type == StoreType.database
