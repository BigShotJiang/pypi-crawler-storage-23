"""Tests for prompt stores -- FilePromptStore and DatabasePromptStore."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest
import yaml

from prompt_registry.models import Prompt, PromptMetadata
from prompt_registry.store import DatabasePromptStore, FilePromptStore, _row_to_prompt


# ---------------------------------------------------------------------------
# FilePromptStore
# ---------------------------------------------------------------------------


class TestFilePromptStore:
    def test_load_yaml_files(self, tmp_path: Path):
        """Load prompts from YAML files in a directory."""
        (tmp_path / "greet.yaml").write_text(
            yaml.dump({
                "name": "greet",
                "version": "1.0",
                "template": "Hello {name}",
                "model": "gpt-4",
                "temperature": 0.5,
            })
        )
        store = FilePromptStore(tmp_path)
        prompts = store.load_all()
        assert len(prompts) == 1
        assert prompts[0].name == "greet"
        assert prompts[0].metadata.model == "gpt-4"

    def test_load_yml_extension(self, tmp_path: Path):
        (tmp_path / "test.yml").write_text(
            yaml.dump({"name": "test", "version": "1.0", "template": "Hello"})
        )
        store = FilePromptStore(tmp_path)
        prompts = store.load_all()
        assert len(prompts) == 1

    def test_load_prompt_by_name(self, tmp_path: Path):
        (tmp_path / "sum.yaml").write_text(
            yaml.dump({"name": "summarize", "version": "1.0", "template": "Sum: {text}"})
        )
        store = FilePromptStore(tmp_path)
        prompt = store.load_prompt("summarize")
        assert prompt is not None
        assert prompt.name == "summarize"

    def test_load_prompt_by_name_and_version(self, tmp_path: Path):
        (tmp_path / "v1.yaml").write_text(
            yaml.dump({"name": "p", "version": "1.0", "template": "v1"})
        )
        (tmp_path / "v2.yaml").write_text(
            yaml.dump({"name": "p", "version": "2.0", "template": "v2"})
        )
        store = FilePromptStore(tmp_path)
        p = store.load_prompt("p", "1.0")
        assert p is not None
        assert p.template == "v1"

    def test_load_prompt_latest(self, tmp_path: Path):
        (tmp_path / "v1.yaml").write_text(
            yaml.dump({"name": "p", "version": "1.0", "template": "v1"})
        )
        (tmp_path / "v2.yaml").write_text(
            yaml.dump({"name": "p", "version": "2.0", "template": "v2"})
        )
        store = FilePromptStore(tmp_path)
        p = store.load_prompt("p")
        assert p is not None
        assert p.version == "2.0"

    def test_load_nonexistent(self, tmp_path: Path):
        store = FilePromptStore(tmp_path)
        assert store.load_prompt("nope") is None

    def test_nonexistent_directory(self):
        store = FilePromptStore("/nonexistent/path/that/should/not/exist")
        assert store.load_all() == []

    def test_save_prompt(self, tmp_path: Path):
        store = FilePromptStore(tmp_path)
        prompt = Prompt(
            name="new",
            version="1.0",
            template="Hello {name}",
            metadata=PromptMetadata(model="claude-sonnet-4-20250514"),
        )
        store.save_prompt(prompt)
        # Verify file was created
        saved = tmp_path / "new-v1.0.yaml"
        assert saved.exists()
        data = yaml.safe_load(saved.read_text())
        assert data["name"] == "new"
        assert data["model"] == "claude-sonnet-4-20250514"

    def test_save_then_load(self, tmp_path: Path):
        store = FilePromptStore(tmp_path)
        prompt = Prompt(name="round", version="1.0", template="Trip: {dest}")
        store.save_prompt(prompt)
        loaded = store.load_prompt("round", "1.0")
        assert loaded is not None
        assert loaded.template == "Trip: {dest}"

    def test_reload(self, tmp_path: Path):
        (tmp_path / "a.yaml").write_text(
            yaml.dump({"name": "a", "version": "1.0", "template": "original"})
        )
        store = FilePromptStore(tmp_path)
        assert store.load_prompt("a") is not None
        # Modify on disk
        (tmp_path / "a.yaml").write_text(
            yaml.dump({"name": "a", "version": "1.0", "template": "updated"})
        )
        store.reload()
        p = store.load_prompt("a")
        assert p is not None
        assert p.template == "updated"

    def test_invalid_yaml_skipped(self, tmp_path: Path):
        (tmp_path / "bad.yaml").write_text("not: valid: yaml: {{{{")
        (tmp_path / "good.yaml").write_text(
            yaml.dump({"name": "good", "version": "1.0", "template": "ok"})
        )
        store = FilePromptStore(tmp_path)
        prompts = store.load_all()
        assert len(prompts) == 1
        assert prompts[0].name == "good"

    def test_yaml_missing_required_fields_skipped(self, tmp_path: Path):
        (tmp_path / "noname.yaml").write_text(yaml.dump({"version": "1.0"}))
        store = FilePromptStore(tmp_path)
        assert store.load_all() == []

    def test_default_version(self, tmp_path: Path):
        """YAML without explicit version defaults to '1.0'."""
        (tmp_path / "noversion.yaml").write_text(
            yaml.dump({"name": "x", "template": "t"})
        )
        store = FilePromptStore(tmp_path)
        p = store.load_prompt("x")
        assert p is not None
        assert p.version == "1.0"


# ---------------------------------------------------------------------------
# DatabasePromptStore (mocked asyncpg)
# ---------------------------------------------------------------------------


class TestDatabasePromptStore:
    def _make_pool(self) -> MagicMock:
        pool = MagicMock()
        pool.execute = AsyncMock()
        pool.fetchrow = AsyncMock()
        pool.fetch = AsyncMock()
        return pool

    @pytest.mark.asyncio
    async def test_create_table(self):
        pool = self._make_pool()
        store = DatabasePromptStore(pool)
        await store.create_table()
        pool.execute.assert_called_once()
        sql = pool.execute.call_args[0][0]
        assert "CREATE TABLE IF NOT EXISTS prompts" in sql

    @pytest.mark.asyncio
    async def test_save_prompt(self):
        pool = self._make_pool()
        store = DatabasePromptStore(pool)
        prompt = Prompt(name="test", version="1.0", template="Hello {name}")
        await store.save_prompt(prompt)
        pool.execute.assert_called_once()
        args = pool.execute.call_args[0]
        assert "INSERT INTO prompts" in args[0]
        assert args[1] == "test"
        assert args[2] == "1.0"

    @pytest.mark.asyncio
    async def test_load_prompt_with_version(self):
        pool = self._make_pool()
        pool.fetchrow.return_value = {
            "name": "test",
            "version": "1.0",
            "template": "Hello {name}",
            "model": None,
            "temperature": None,
            "max_tokens": None,
        }
        store = DatabasePromptStore(pool)
        prompt = await store.load_prompt("test", "1.0")
        assert prompt is not None
        assert prompt.name == "test"

    @pytest.mark.asyncio
    async def test_load_prompt_latest(self):
        pool = self._make_pool()
        pool.fetchrow.return_value = {
            "name": "test",
            "version": "2.0",
            "template": "v2",
            "model": None,
            "temperature": None,
            "max_tokens": None,
        }
        store = DatabasePromptStore(pool)
        prompt = await store.load_prompt("test")
        assert prompt is not None
        assert prompt.version == "2.0"

    @pytest.mark.asyncio
    async def test_load_prompt_not_found(self):
        pool = self._make_pool()
        pool.fetchrow.return_value = None
        store = DatabasePromptStore(pool)
        assert await store.load_prompt("nope") is None

    @pytest.mark.asyncio
    async def test_load_all(self):
        pool = self._make_pool()
        pool.fetch.return_value = [
            {"name": "a", "version": "1.0", "template": "t", "model": None, "temperature": None, "max_tokens": None},
            {"name": "b", "version": "1.0", "template": "t", "model": "gpt-4", "temperature": 0.5, "max_tokens": 100},
        ]
        store = DatabasePromptStore(pool)
        prompts = await store.load_all()
        assert len(prompts) == 2
        assert prompts[1].metadata.model == "gpt-4"

    @pytest.mark.asyncio
    async def test_delete_prompt(self):
        pool = self._make_pool()
        pool.execute.return_value = "DELETE 1"
        store = DatabasePromptStore(pool)
        assert await store.delete_prompt("test", "1.0") is True

    @pytest.mark.asyncio
    async def test_delete_prompt_not_found(self):
        pool = self._make_pool()
        pool.execute.return_value = "DELETE 0"
        store = DatabasePromptStore(pool)
        assert await store.delete_prompt("nope") is False


class TestRowToPrompt:
    def test_converts_row(self):
        row = {
            "name": "test",
            "version": "1.0",
            "template": "Hello",
            "model": "claude-sonnet-4-20250514",
            "temperature": 0.7,
            "max_tokens": 1024,
        }
        prompt = _row_to_prompt(row)
        assert prompt.name == "test"
        assert prompt.metadata.model == "claude-sonnet-4-20250514"
        assert prompt.metadata.max_tokens == 1024
