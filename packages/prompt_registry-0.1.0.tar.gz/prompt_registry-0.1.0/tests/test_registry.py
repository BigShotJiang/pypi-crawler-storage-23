"""Tests for PromptRegistry -- registration, versioning, lookups."""

from __future__ import annotations

from prompt_registry.registry import PromptRegistry


class TestRegistration:
    def test_register_and_get(self):
        reg = PromptRegistry()
        reg.register("greet", "1.0", "Hello {name}")
        t = reg.get("greet", "1.0")
        assert t is not None
        assert t.name == "greet"
        assert t.version == "1.0"

    def test_register_multiple_versions(self):
        reg = PromptRegistry()
        reg.register("greet", "1.0", "Hello {name}")
        reg.register("greet", "2.0", "Hi {name}!")
        t1 = reg.get("greet", "1.0")
        t2 = reg.get("greet", "2.0")
        assert t1 is not None
        assert t2 is not None
        assert t1.render(name="A") == "Hello A"
        assert t2.render(name="A") == "Hi A!"

    def test_overwrite_same_version(self):
        reg = PromptRegistry()
        reg.register("greet", "1.0", "v1")
        reg.register("greet", "1.0", "v1-updated")
        t = reg.get("greet", "1.0")
        assert t is not None
        assert t.render() == "v1-updated"

    def test_register_with_metadata(self):
        reg = PromptRegistry()
        reg.register("sum", "1.0", "Summarize: {text}", model="gpt-4", temperature=0.3)
        t = reg.get("sum")
        assert t is not None
        assert t.metadata.model == "gpt-4"
        assert t.metadata.temperature == 0.3


class TestLatestVersion:
    def test_get_latest(self):
        reg = PromptRegistry()
        reg.register("p", "1.0", "v1")
        reg.register("p", "1.1", "v1.1")
        reg.register("p", "2.0", "v2")
        t = reg.get("p")
        assert t is not None
        assert t.version == "2.0"

    def test_get_latest_skips_inactive(self):
        reg = PromptRegistry()
        reg.register("p", "1.0", "v1")
        reg.register("p", "2.0", "v2")
        reg.deactivate("p", "2.0")
        t = reg.get("p")
        assert t is not None
        assert t.version == "1.0"

    def test_get_latest_all_inactive_returns_none(self):
        reg = PromptRegistry()
        reg.register("p", "1.0", "v1")
        reg.deactivate("p", "1.0")
        assert reg.get("p") is None

    def test_semver_ordering(self):
        reg = PromptRegistry()
        reg.register("p", "1.9", "old")
        reg.register("p", "1.10", "new")  # 1.10 > 1.9 in semver
        t = reg.get("p")
        assert t is not None
        assert t.version == "1.10"


class TestGetVersions:
    def test_get_versions(self):
        reg = PromptRegistry()
        reg.register("p", "2.0", "v2")
        reg.register("p", "1.0", "v1")
        reg.register("p", "1.5", "v1.5")
        versions = reg.get_versions("p")
        assert [pv.prompt.version for pv in versions] == ["1.0", "1.5", "2.0"]

    def test_get_versions_nonexistent(self):
        reg = PromptRegistry()
        assert reg.get_versions("nope") == []


class TestListPrompts:
    def test_list_prompts(self):
        reg = PromptRegistry()
        reg.register("a", "1.0", "t")
        reg.register("a", "2.0", "t")
        reg.register("b", "1.0", "t")
        listing = reg.list_prompts()
        assert set(listing.keys()) == {"a", "b"}
        assert listing["a"] == ["1.0", "2.0"]

    def test_list_empty(self):
        reg = PromptRegistry()
        assert reg.list_prompts() == {}


class TestRemove:
    def test_remove_specific_version(self):
        reg = PromptRegistry()
        reg.register("p", "1.0", "v1")
        reg.register("p", "2.0", "v2")
        assert reg.remove("p", "1.0") is True
        assert reg.get("p", "1.0") is None
        assert reg.get("p", "2.0") is not None

    def test_remove_all_versions(self):
        reg = PromptRegistry()
        reg.register("p", "1.0", "v1")
        reg.register("p", "2.0", "v2")
        assert reg.remove("p") is True
        assert "p" not in reg

    def test_remove_nonexistent(self):
        reg = PromptRegistry()
        assert reg.remove("nope") is False
        assert reg.remove("nope", "1.0") is False

    def test_remove_last_version_cleans_up(self):
        reg = PromptRegistry()
        reg.register("p", "1.0", "v1")
        reg.remove("p", "1.0")
        assert "p" not in reg


class TestGetNotFound:
    def test_get_nonexistent_name(self):
        reg = PromptRegistry()
        assert reg.get("nope") is None

    def test_get_nonexistent_version(self):
        reg = PromptRegistry()
        reg.register("p", "1.0", "t")
        assert reg.get("p", "99.0") is None


class TestContainsAndLen:
    def test_contains(self):
        reg = PromptRegistry()
        reg.register("p", "1.0", "t")
        assert "p" in reg
        assert "q" not in reg

    def test_len(self):
        reg = PromptRegistry()
        assert len(reg) == 0
        reg.register("a", "1.0", "t")
        reg.register("a", "2.0", "t")
        reg.register("b", "1.0", "t")
        assert len(reg) == 3
