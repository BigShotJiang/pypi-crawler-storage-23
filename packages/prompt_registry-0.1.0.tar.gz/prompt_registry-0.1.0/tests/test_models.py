"""Tests for Pydantic models -- validation, defaults, serialization."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from prompt_registry.models import (
    ChainStep,
    ExperimentConfig,
    ExperimentResult,
    Prompt,
    PromptMetadata,
    PromptVersion,
)


class TestPromptMetadata:
    def test_defaults(self):
        meta = PromptMetadata()
        assert meta.model is None
        assert meta.temperature is None
        assert meta.max_tokens is None

    def test_full(self):
        meta = PromptMetadata(model="claude-sonnet-4-20250514", temperature=0.7, max_tokens=1024)
        assert meta.model == "claude-sonnet-4-20250514"
        assert meta.temperature == 0.7
        assert meta.max_tokens == 1024

    def test_temperature_bounds(self):
        with pytest.raises(ValidationError):
            PromptMetadata(temperature=-0.1)
        with pytest.raises(ValidationError):
            PromptMetadata(temperature=2.1)

    def test_max_tokens_positive(self):
        with pytest.raises(ValidationError):
            PromptMetadata(max_tokens=0)
        with pytest.raises(ValidationError):
            PromptMetadata(max_tokens=-1)


class TestPrompt:
    def test_minimal(self):
        p = Prompt(name="greet", version="1.0", template="Hello {name}")
        assert p.name == "greet"
        assert p.version == "1.0"
        assert p.metadata.model is None

    def test_with_metadata(self):
        p = Prompt(
            name="summarize",
            version="2.1.0",
            template="Summarize: {text}",
            metadata=PromptMetadata(model="gpt-4", temperature=0.3),
        )
        assert p.metadata.model == "gpt-4"
        assert p.metadata.temperature == 0.3

    def test_serialization_roundtrip(self):
        p = Prompt(name="x", version="1.0", template="t")
        data = p.model_dump()
        p2 = Prompt.model_validate(data)
        assert p == p2


class TestPromptVersion:
    def test_defaults(self):
        prompt = Prompt(name="p", version="1.0", template="t")
        pv = PromptVersion(prompt=prompt)
        assert pv.is_active is True
        assert pv.created_at is not None

    def test_inactive(self):
        prompt = Prompt(name="p", version="1.0", template="t")
        pv = PromptVersion(prompt=prompt, is_active=False)
        assert pv.is_active is False


class TestExperimentConfig:
    def test_valid(self):
        cfg = ExperimentConfig(
            name="test-exp", variants=["1.0", "2.0"], traffic_split=[0.5, 0.5]
        )
        assert cfg.name == "test-exp"
        assert len(cfg.variants) == 2

    def test_mismatched_lengths(self):
        with pytest.raises((ValueError, ValidationError)):
            ExperimentConfig(
                name="bad", variants=["1.0", "2.0", "3.0"], traffic_split=[0.5, 0.5]
            )

    def test_split_not_one(self):
        with pytest.raises(ValueError, match="sum to 1.0"):
            ExperimentConfig(
                name="bad", variants=["1.0", "2.0"], traffic_split=[0.3, 0.3]
            )

    def test_three_variants(self):
        cfg = ExperimentConfig(
            name="multi",
            variants=["1.0", "2.0", "3.0"],
            traffic_split=[0.5, 0.3, 0.2],
        )
        assert len(cfg.variants) == 3

    def test_min_variants(self):
        with pytest.raises(ValidationError):
            ExperimentConfig(name="solo", variants=["1.0"], traffic_split=[1.0])


class TestChainStep:
    def test_defaults(self):
        step = ChainStep(prompt_name="summarize")
        assert step.prompt_version is None
        assert step.input_mapping == {}

    def test_with_mapping(self):
        step = ChainStep(
            prompt_name="translate",
            input_mapping={"text": "step_0_output", "language": "target_lang"},
        )
        assert step.input_mapping["text"] == "step_0_output"


class TestExperimentResult:
    def test_creation(self):
        r = ExperimentResult(
            experiment_name="exp1",
            variant="1.0",
            metric_name="quality",
            metric_value=0.85,
        )
        assert r.metric_value == 0.85
        assert r.recorded_at is not None
