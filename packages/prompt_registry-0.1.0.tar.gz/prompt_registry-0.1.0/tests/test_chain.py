"""Tests for PromptChain -- sequential execution with mocked LLM."""

from __future__ import annotations

import pytest

from prompt_registry.chain import PromptChain
from prompt_registry.registry import PromptRegistry


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def registry() -> PromptRegistry:
    reg = PromptRegistry()
    reg.register("summarize", "1.0", "Summarize this text: {text}")
    reg.register("translate", "1.0", "Translate to {language}: {text}")
    reg.register("format", "1.0", "Format as {style}: {content}")
    reg.register("greet", "1.0", "Hello {name}")
    return reg


async def _mock_llm(prompt: str) -> str:
    """Simple mock LLM that echoes a transformed version of the prompt."""
    if "Summarize" in prompt:
        return "This is a summary."
    if "Translate" in prompt:
        return "Esta es una traduccion."
    if "Format" in prompt:
        return "- formatted content"
    return f"LLM response to: {prompt}"


# ---------------------------------------------------------------------------
# Basic chain execution
# ---------------------------------------------------------------------------


class TestChainExecution:
    @pytest.mark.asyncio
    async def test_single_step(self, registry: PromptRegistry):
        chain = PromptChain(registry)
        chain.add_step("summarize", {"text": "text"})
        results = await chain.execute({"text": "Long article..."}, _mock_llm)
        assert len(results) == 1
        assert results[0].prompt_name == "summarize"
        assert results[0].llm_output == "This is a summary."
        assert results[0].step_index == 0
        assert results[0].duration_ms >= 0

    @pytest.mark.asyncio
    async def test_two_step_chain(self, registry: PromptRegistry):
        chain = PromptChain(registry)
        chain.add_step("summarize", {"text": "text"})
        chain.add_step("translate", {"text": "step_0_output", "language": "language"})
        results = await chain.execute(
            {"text": "Long article...", "language": "Spanish"}, _mock_llm
        )
        assert len(results) == 2
        assert results[0].prompt_name == "summarize"
        assert results[1].prompt_name == "translate"
        # Second step should have received the summary as input
        assert "This is a summary" in results[1].rendered_prompt

    @pytest.mark.asyncio
    async def test_three_step_chain(self, registry: PromptRegistry):
        chain = PromptChain(registry)
        chain.add_step("summarize", {"text": "text"})
        chain.add_step("translate", {"text": "step_0_output", "language": "language"})
        chain.add_step("format", {"content": "step_1_output", "style": "style"})
        results = await chain.execute(
            {"text": "Article", "language": "Spanish", "style": "bullets"},
            _mock_llm,
        )
        assert len(results) == 3
        assert "traduccion" in results[2].rendered_prompt

    @pytest.mark.asyncio
    async def test_empty_chain(self, registry: PromptRegistry):
        chain = PromptChain(registry)
        results = await chain.execute({"text": "test"}, _mock_llm)
        assert results == []


# ---------------------------------------------------------------------------
# Fluent API
# ---------------------------------------------------------------------------


class TestFluentAPI:
    def test_add_step_returns_self(self, registry: PromptRegistry):
        chain = PromptChain(registry)
        result = chain.add_step("summarize")
        assert result is chain

    def test_chained_add(self, registry: PromptRegistry):
        chain = (
            PromptChain(registry)
            .add_step("summarize", {"text": "text"})
            .add_step("translate", {"text": "step_0_output", "language": "language"})
        )
        assert len(chain.steps) == 2


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


class TestChainErrors:
    @pytest.mark.asyncio
    async def test_missing_prompt(self, registry: PromptRegistry):
        chain = PromptChain(registry)
        chain.add_step("nonexistent")
        with pytest.raises(ValueError, match="Prompt not found"):
            await chain.execute({}, _mock_llm)

    @pytest.mark.asyncio
    async def test_missing_context_key(self, registry: PromptRegistry):
        chain = PromptChain(registry)
        chain.add_step("translate", {"text": "missing_key", "language": "language"})
        with pytest.raises(ValueError, match="missing key"):
            await chain.execute({"language": "Spanish"}, _mock_llm)


# ---------------------------------------------------------------------------
# No mapping passes full context
# ---------------------------------------------------------------------------


class TestNoMapping:
    @pytest.mark.asyncio
    async def test_no_mapping_passes_context(self, registry: PromptRegistry):
        chain = PromptChain(registry)
        chain.add_step("greet")  # No mapping, should pass all context
        results = await chain.execute({"name": "Alice"}, _mock_llm)
        assert len(results) == 1
        assert "Hello Alice" in results[0].rendered_prompt
