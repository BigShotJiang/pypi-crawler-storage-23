"""Willian Prompts -- Prompt management, versioning, A/B testing, and chaining for AI apps."""

from prompt_registry.ab_testing import PromptExperiment
from prompt_registry.chain import PromptChain
from prompt_registry.config import PromptConfig, StoreType, get_registry, init_prompts, reset_registry
from prompt_registry.models import (
    ChainResult,
    ChainStep,
    ExperimentConfig,
    ExperimentResult,
    Prompt,
    PromptMetadata,
    PromptVersion,
)
from prompt_registry.registry import PromptRegistry
from prompt_registry.store import DatabasePromptStore, FilePromptStore, PromptStore
from prompt_registry.template import PromptTemplate

__all__ = [
    "ChainResult",
    "ChainStep",
    "DatabasePromptStore",
    "ExperimentConfig",
    "ExperimentResult",
    "FilePromptStore",
    "PromptChain",
    "PromptConfig",
    "PromptExperiment",
    "PromptMetadata",
    "PromptRegistry",
    "PromptStore",
    "PromptTemplate",
    "PromptVersion",
    "Prompt",
    "StoreType",
    "get_registry",
    "init_prompts",
    "reset_registry",
]


def render_prompt(name: str, version: str | None = None, **kwargs: object) -> str:
    """Convenience: render a prompt from the global registry.

    Usage::

        from prompt_registry import init_prompts, render_prompt

        init_prompts(config)
        result = render_prompt("summarize", style="bullet", text="...")
    """
    registry = get_registry()
    template = registry.get(name, version)
    if template is None:
        raise ValueError(f"Prompt not found: {name!r} (version={version!r})")
    return template.render(**kwargs)
