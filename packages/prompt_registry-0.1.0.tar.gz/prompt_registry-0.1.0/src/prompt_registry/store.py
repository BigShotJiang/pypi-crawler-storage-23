"""Prompt storage backends -- filesystem (YAML) and database (asyncpg)."""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from pathlib import Path
from typing import TYPE_CHECKING

import yaml

from prompt_registry.models import Prompt, PromptMetadata

if TYPE_CHECKING:
    import asyncpg


class PromptStore(ABC):
    """Abstract base for prompt persistence."""

    @abstractmethod
    def load_prompt(self, name: str, version: str | None = None) -> Prompt | None:
        """Load a prompt by name and optional version."""

    @abstractmethod
    def load_all(self) -> list[Prompt]:
        """Load all stored prompts."""

    @abstractmethod
    def save_prompt(self, prompt: Prompt) -> None:
        """Persist a prompt."""


# ---------------------------------------------------------------------------
# File-based YAML store
# ---------------------------------------------------------------------------


class FilePromptStore(PromptStore):
    """Loads prompts from a directory of YAML files.

    Expected YAML format::

        name: summarize
        version: "1.2"
        model: claude-sonnet-4-20250514
        temperature: 0.3
        template: |
          Summarize the following text in {style} style:
          {text}
    """

    def __init__(self, prompts_dir: str | Path) -> None:
        self.prompts_dir = Path(prompts_dir)
        self._cache: dict[tuple[str, str], Prompt] = {}
        self._loaded = False

    def _ensure_loaded(self) -> None:
        if self._loaded:
            return
        self._load_all_from_disk()
        self._loaded = True

    def _load_all_from_disk(self) -> None:
        if not self.prompts_dir.exists():
            return
        for path in sorted(self.prompts_dir.glob("*.yaml")):
            prompt = self._parse_yaml(path)
            if prompt:
                self._cache[(prompt.name, prompt.version)] = prompt
        for path in sorted(self.prompts_dir.glob("*.yml")):
            prompt = self._parse_yaml(path)
            if prompt:
                self._cache[(prompt.name, prompt.version)] = prompt

    @staticmethod
    def _parse_yaml(path: Path) -> Prompt | None:
        try:
            data = yaml.safe_load(path.read_text(encoding="utf-8"))
        except (yaml.YAMLError, OSError):
            return None
        if not isinstance(data, dict) or "name" not in data or "template" not in data:
            return None
        return Prompt(
            name=data["name"],
            version=str(data.get("version", "1.0")),
            template=data["template"],
            metadata=PromptMetadata(
                model=data.get("model"),
                temperature=data.get("temperature"),
                max_tokens=data.get("max_tokens"),
            ),
        )

    def load_prompt(self, name: str, version: str | None = None) -> Prompt | None:
        self._ensure_loaded()
        if version:
            return self._cache.get((name, version))
        # Return latest version for this name
        matching = [p for (n, _), p in self._cache.items() if n == name]
        if not matching:
            return None
        return max(matching, key=lambda p: _parse_version_tuple(p.version))

    def load_all(self) -> list[Prompt]:
        self._ensure_loaded()
        return list(self._cache.values())

    def save_prompt(self, prompt: Prompt) -> None:
        self.prompts_dir.mkdir(parents=True, exist_ok=True)
        filename = f"{prompt.name}-v{prompt.version}.yaml"
        data: dict[str, object] = {
            "name": prompt.name,
            "version": prompt.version,
            "template": prompt.template,
        }
        if prompt.metadata.model:
            data["model"] = prompt.metadata.model
        if prompt.metadata.temperature is not None:
            data["temperature"] = prompt.metadata.temperature
        if prompt.metadata.max_tokens is not None:
            data["max_tokens"] = prompt.metadata.max_tokens

        path = self.prompts_dir / filename
        path.write_text(yaml.dump(data, default_flow_style=False, allow_unicode=True), encoding="utf-8")
        self._cache[(prompt.name, prompt.version)] = prompt

    def reload(self) -> None:
        """Force reload all prompts from disk."""
        self._cache.clear()
        self._loaded = False
        self._ensure_loaded()


# ---------------------------------------------------------------------------
# Database-backed store (asyncpg)
# ---------------------------------------------------------------------------


CREATE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS prompts (
    id          SERIAL PRIMARY KEY,
    name        TEXT NOT NULL,
    version     TEXT NOT NULL,
    template    TEXT NOT NULL,
    model       TEXT,
    temperature DOUBLE PRECISION,
    max_tokens  INTEGER,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (name, version)
);
CREATE INDEX IF NOT EXISTS idx_prompts_name ON prompts (name);
"""


class DatabasePromptStore:
    """Async PostgreSQL-backed prompt store using asyncpg."""

    def __init__(self, pool: asyncpg.Pool) -> None:
        self.pool = pool

    async def create_table(self) -> None:
        """Create the prompts table if it does not exist."""
        await self.pool.execute(CREATE_TABLE_SQL)

    async def save_prompt(self, prompt: Prompt) -> None:
        """Insert or update a prompt in the database."""
        await self.pool.execute(
            """
            INSERT INTO prompts (name, version, template, model, temperature, max_tokens)
            VALUES ($1, $2, $3, $4, $5, $6)
            ON CONFLICT (name, version)
            DO UPDATE SET template = $3, model = $4, temperature = $5, max_tokens = $6
            """,
            prompt.name,
            prompt.version,
            prompt.template,
            prompt.metadata.model,
            prompt.metadata.temperature,
            prompt.metadata.max_tokens,
        )

    async def load_prompt(self, name: str, version: str | None = None) -> Prompt | None:
        """Load a prompt by name and optional version."""
        if version:
            row = await self.pool.fetchrow(
                "SELECT * FROM prompts WHERE name = $1 AND version = $2", name, version
            )
        else:
            row = await self.pool.fetchrow(
                "SELECT * FROM prompts WHERE name = $1 ORDER BY created_at DESC LIMIT 1",
                name,
            )
        return _row_to_prompt(row) if row else None

    async def load_all(self) -> list[Prompt]:
        """Load all prompts ordered by name and version."""
        rows = await self.pool.fetch("SELECT * FROM prompts ORDER BY name, version")
        return [_row_to_prompt(r) for r in rows]

    async def delete_prompt(self, name: str, version: str | None = None) -> bool:
        """Delete a prompt. Returns True if any row was deleted."""
        if version:
            result = await self.pool.execute(
                "DELETE FROM prompts WHERE name = $1 AND version = $2", name, version
            )
        else:
            result = await self.pool.execute(
                "DELETE FROM prompts WHERE name = $1", name
            )
        return "DELETE 0" not in result


def _row_to_prompt(row: object) -> Prompt:
    """Convert a database row to a Prompt model."""
    return Prompt(
        name=row["name"],  # type: ignore[index]
        version=row["version"],  # type: ignore[index]
        template=row["template"],  # type: ignore[index]
        metadata=PromptMetadata(
            model=row["model"],  # type: ignore[index]
            temperature=row["temperature"],  # type: ignore[index]
            max_tokens=row["max_tokens"],  # type: ignore[index]
        ),
    )


def _parse_version_tuple(version: str) -> tuple[int, ...]:
    """Parse a version string into a tuple for comparison."""
    try:
        return tuple(int(p) for p in version.split("."))
    except ValueError:
        return (0,)
