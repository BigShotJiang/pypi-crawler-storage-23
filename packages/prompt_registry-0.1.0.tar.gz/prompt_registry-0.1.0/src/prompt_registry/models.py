"""Pydantic models for prompts, versions, experiments, and chain steps."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from pydantic import BaseModel, Field


class PromptMetadata(BaseModel):
    """Hints for LLM invocation. All fields are optional suggestions."""

    model: str | None = Field(default=None, description="Suggested model (e.g. 'claude-sonnet-4-20250514')")
    temperature: float | None = Field(default=None, ge=0.0, le=2.0, description="Suggested temperature")
    max_tokens: int | None = Field(default=None, gt=0, description="Suggested max output tokens")


class Prompt(BaseModel):
    """Core prompt definition with template and metadata."""

    name: str = Field(description="Unique prompt identifier (e.g. 'summarize')")
    version: str = Field(description="Semantic version string (e.g. '1.0.0' or '1.2')")
    template: str = Field(description="Jinja2 template string with {variable} placeholders")
    metadata: PromptMetadata = Field(default_factory=PromptMetadata)


class PromptVersion(BaseModel):
    """A prompt with lifecycle tracking."""

    prompt: Prompt
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    is_active: bool = Field(default=True, description="Whether this version is currently active")


class ExperimentConfig(BaseModel):
    """Configuration for an A/B test between prompt variants."""

    name: str = Field(description="Experiment identifier")
    variants: list[str] = Field(
        min_length=2,
        description="List of prompt version strings to test (e.g. ['1.0', '2.0'])",
    )
    traffic_split: list[float] = Field(
        min_length=2,
        description="Weight for each variant (e.g. [0.5, 0.5]). Must sum to 1.0.",
    )

    def model_post_init(self, __context: Any) -> None:
        if len(self.variants) != len(self.traffic_split):
            raise ValueError("variants and traffic_split must have the same length")
        if abs(sum(self.traffic_split) - 1.0) > 1e-6:
            raise ValueError(f"traffic_split must sum to 1.0, got {sum(self.traffic_split)}")


class ChainStep(BaseModel):
    """A single step in a prompt chain."""

    prompt_name: str = Field(description="Name of the prompt to use for this step")
    prompt_version: str | None = Field(
        default=None, description="Specific version, or None for latest"
    )
    input_mapping: dict[str, str] = Field(
        default_factory=dict,
        description="Maps prompt variables to keys from previous step output or initial vars",
    )


class ChainResult(BaseModel):
    """Result of executing one step in a prompt chain."""

    step_index: int
    prompt_name: str
    rendered_prompt: str
    llm_output: str
    duration_ms: float


class ExperimentResult(BaseModel):
    """Recorded outcome for an A/B experiment variant."""

    experiment_name: str
    variant: str
    metric_name: str
    metric_value: float
    recorded_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
