"""Prompt chaining -- sequential execution with output flowing between steps."""

from __future__ import annotations

import time
from collections.abc import Awaitable, Callable
from typing import Any

from prompt_registry.models import ChainResult, ChainStep
from prompt_registry.registry import PromptRegistry


# Type for the async LLM callable: takes rendered prompt string, returns response string
LLMCallable = Callable[[str], Awaitable[str]]


class PromptChain:
    """A sequence of prompts where each step's output feeds into the next.

    Steps are executed in order via an async LLM callable. The output of each
    step is stored under the key ``"step_{i}_output"`` and can be referenced
    by subsequent steps via ``input_mapping``.
    """

    def __init__(self, registry: PromptRegistry) -> None:
        self.registry = registry
        self._steps: list[ChainStep] = []

    def add_step(
        self,
        prompt_name: str,
        input_mapping: dict[str, str] | None = None,
        prompt_version: str | None = None,
    ) -> PromptChain:
        """Add a step to the chain. Returns self for fluent chaining."""
        self._steps.append(
            ChainStep(
                prompt_name=prompt_name,
                prompt_version=prompt_version,
                input_mapping=input_mapping or {},
            )
        )
        return self

    @property
    def steps(self) -> list[ChainStep]:
        return list(self._steps)

    async def execute(
        self,
        initial_vars: dict[str, Any],
        llm_fn: LLMCallable,
    ) -> list[ChainResult]:
        """Execute the chain sequentially, passing outputs between steps.

        Args:
            initial_vars: Starting variables available to all steps.
            llm_fn: Async function that takes a rendered prompt and returns LLM output.

        Returns:
            List of ChainResult with intermediate results and timings.

        Raises:
            ValueError: If a referenced prompt is not found in the registry.
        """
        if not self._steps:
            return []

        # Accumulated context: initial vars + step outputs
        context: dict[str, Any] = dict(initial_vars)
        results: list[ChainResult] = []

        for i, step in enumerate(self._steps):
            template = self.registry.get(step.prompt_name, step.prompt_version)
            if template is None:
                raise ValueError(
                    f"Prompt not found: name={step.prompt_name!r}, "
                    f"version={step.prompt_version!r}"
                )

            # Build step input by mapping context keys to template variables
            step_vars = self._resolve_mapping(step.input_mapping, context)

            rendered = template.render(**step_vars)

            start = time.monotonic()
            llm_output = await llm_fn(rendered)
            duration_ms = (time.monotonic() - start) * 1000

            # Store output in context for subsequent steps
            context[f"step_{i}_output"] = llm_output

            results.append(
                ChainResult(
                    step_index=i,
                    prompt_name=step.prompt_name,
                    rendered_prompt=rendered,
                    llm_output=llm_output,
                    duration_ms=duration_ms,
                )
            )

        return results

    @staticmethod
    def _resolve_mapping(
        mapping: dict[str, str], context: dict[str, Any]
    ) -> dict[str, Any]:
        """Resolve input_mapping: maps template variable names to context values.

        If mapping is empty, passes the full context through.
        """
        if not mapping:
            return dict(context)
        resolved: dict[str, Any] = {}
        for template_var, context_key in mapping.items():
            if context_key not in context:
                raise ValueError(
                    f"Input mapping references missing key: {context_key!r} "
                    f"(mapping {template_var!r} -> {context_key!r})"
                )
            resolved[template_var] = context[context_key]
        return resolved
