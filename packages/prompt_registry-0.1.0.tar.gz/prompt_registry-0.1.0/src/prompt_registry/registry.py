"""In-memory prompt registry with semantic version management."""

from __future__ import annotations

from prompt_registry.models import Prompt, PromptVersion
from prompt_registry.template import PromptTemplate


def _parse_version(version: str) -> tuple[int, ...]:
    """Parse a version string into a tuple for comparison.

    Supports '1', '1.0', '1.0.0', etc.
    """
    try:
        return tuple(int(p) for p in version.split("."))
    except ValueError:
        return (0,)


class PromptRegistry:
    """In-memory registry for prompt templates with version management.

    Stores prompt versions keyed by (name, version) and provides lookups
    for the latest version, all versions, and listing all prompts.
    """

    def __init__(self) -> None:
        # {name: {version_str: PromptVersion}}
        self._store: dict[str, dict[str, PromptVersion]] = {}

    def register(
        self,
        name: str,
        version: str,
        template: str,
        *,
        model: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        is_active: bool = True,
    ) -> PromptVersion:
        """Register a prompt template version.

        If the same (name, version) already exists, it is overwritten.
        """
        from prompt_registry.models import PromptMetadata

        prompt = Prompt(
            name=name,
            version=version,
            template=template,
            metadata=PromptMetadata(
                model=model, temperature=temperature, max_tokens=max_tokens
            ),
        )
        pv = PromptVersion(prompt=prompt, is_active=is_active)

        if name not in self._store:
            self._store[name] = {}
        self._store[name][version] = pv
        return pv

    def get(self, name: str, version: str | None = None) -> PromptTemplate | None:
        """Get a prompt template by name and optional version.

        If version is None, returns the latest active version (by semver).
        Returns None if no matching prompt is found.
        """
        versions = self._store.get(name)
        if not versions:
            return None

        if version is not None:
            pv = versions.get(version)
            if pv is None:
                return None
            return PromptTemplate.from_prompt(pv.prompt)

        # Find latest active version
        active = [(v, pv) for v, pv in versions.items() if pv.is_active]
        if not active:
            return None

        latest_version, latest_pv = max(active, key=lambda x: _parse_version(x[0]))
        return PromptTemplate.from_prompt(latest_pv.prompt)

    def get_version(self, name: str, version: str) -> PromptVersion | None:
        """Get the raw PromptVersion record."""
        versions = self._store.get(name)
        if not versions:
            return None
        return versions.get(version)

    def get_versions(self, name: str) -> list[PromptVersion]:
        """Get all versions of a prompt, sorted by semver ascending."""
        versions = self._store.get(name)
        if not versions:
            return []
        return sorted(versions.values(), key=lambda pv: _parse_version(pv.prompt.version))

    def list_prompts(self) -> dict[str, list[str]]:
        """Return a mapping of prompt name to list of version strings."""
        return {
            name: sorted(versions.keys(), key=_parse_version)
            for name, versions in self._store.items()
        }

    def deactivate(self, name: str, version: str) -> bool:
        """Mark a version as inactive. Returns True if found and deactivated."""
        pv = self.get_version(name, version)
        if pv is None:
            return False
        pv.is_active = False
        return True

    def remove(self, name: str, version: str | None = None) -> bool:
        """Remove a specific version or all versions of a prompt.

        Returns True if anything was removed.
        """
        if name not in self._store:
            return False
        if version is None:
            del self._store[name]
            return True
        if version in self._store[name]:
            del self._store[name][version]
            if not self._store[name]:
                del self._store[name]
            return True
        return False

    def __len__(self) -> int:
        """Total number of prompt versions registered."""
        return sum(len(v) for v in self._store.values())

    def __contains__(self, name: str) -> bool:
        return name in self._store
