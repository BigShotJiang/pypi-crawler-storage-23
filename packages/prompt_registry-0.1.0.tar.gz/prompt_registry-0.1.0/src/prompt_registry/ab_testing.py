"""A/B testing for prompt variants with deterministic hash-based selection."""

from __future__ import annotations

import hashlib

from prompt_registry.models import ExperimentConfig, ExperimentResult


class PromptExperiment:
    """Manages an A/B experiment between prompt variants.

    Selection is deterministic: the same user_id always gets the same variant
    for a given experiment, similar to feature flag bucketing.
    """

    def __init__(self, config: ExperimentConfig) -> None:
        self.config = config
        self._results: list[ExperimentResult] = []

    @property
    def name(self) -> str:
        return self.config.name

    @property
    def variants(self) -> list[str]:
        return self.config.variants

    def select_variant(self, user_id: str) -> str:
        """Deterministically select a variant for the given user.

        Uses MD5 hashing to bucket users into variant groups based
        on the configured traffic split weights.
        """
        bucket = _hash_bucket(user_id, self.config.name)
        cumulative = 0.0
        for variant, weight in zip(self.config.variants, self.config.traffic_split):
            cumulative += weight
            if bucket < cumulative:
                return variant
        # Fallback to last variant (handles floating point edge cases)
        return self.config.variants[-1]

    def record_result(
        self, variant: str, metric_name: str, metric_value: float
    ) -> ExperimentResult:
        """Record an outcome metric for a variant."""
        if variant not in self.config.variants:
            raise ValueError(f"Unknown variant: {variant!r}. Expected one of {self.config.variants}")
        result = ExperimentResult(
            experiment_name=self.config.name,
            variant=variant,
            metric_name=metric_name,
            metric_value=metric_value,
        )
        self._results.append(result)
        return result

    def get_results(self, variant: str | None = None) -> list[ExperimentResult]:
        """Get recorded results, optionally filtered by variant."""
        if variant is None:
            return list(self._results)
        return [r for r in self._results if r.variant == variant]

    def get_summary(self) -> dict[str, dict[str, float]]:
        """Get average metric values per variant.

        Returns: {variant: {metric_name: average_value}}
        """
        summary: dict[str, dict[str, list[float]]] = {}
        for result in self._results:
            if result.variant not in summary:
                summary[result.variant] = {}
            if result.metric_name not in summary[result.variant]:
                summary[result.variant][result.metric_name] = []
            summary[result.variant][result.metric_name].append(result.metric_value)

        return {
            variant: {
                metric: sum(values) / len(values)
                for metric, values in metrics.items()
            }
            for variant, metrics in summary.items()
        }


def _hash_bucket(user_id: str, experiment_name: str) -> float:
    """Return a deterministic float in [0, 1) from user_id + experiment_name."""
    digest = hashlib.md5(
        f"{user_id}:{experiment_name}".encode(), usedforsecurity=False
    ).digest()
    # Use first 4 bytes as unsigned int, normalize to [0, 1)
    int_val = int.from_bytes(digest[:4], "little")
    return int_val / (2**32)
