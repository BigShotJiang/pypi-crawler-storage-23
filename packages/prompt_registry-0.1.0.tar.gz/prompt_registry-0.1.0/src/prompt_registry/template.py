"""Prompt template rendering with Jinja2 support and variable validation."""

from __future__ import annotations

import re

from jinja2 import Environment, StrictUndefined, TemplateSyntaxError, UndefinedError, meta

from prompt_registry.models import Prompt, PromptMetadata


# Shared Jinja2 environment with strict undefined (raises on missing vars)
_jinja_env = Environment(undefined=StrictUndefined, keep_trailing_newline=True)

# Regex to extract simple {variable} placeholders (non-Jinja2 syntax)
_SIMPLE_VAR_RE = re.compile(r"\{(\w+)\}")


class PromptTemplate:
    """A renderable prompt template with variable validation.

    Supports both simple ``{variable}`` placeholders (auto-converted to Jinja2)
    and native Jinja2 syntax (``{{ variable }}``, ``{% if ... %}``, ``{% for ... %}``).
    """

    def __init__(
        self,
        name: str,
        version: str,
        template: str,
        *,
        model: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
    ) -> None:
        self.name = name
        self.version = version
        self.raw_template = template
        self.metadata = PromptMetadata(
            model=model, temperature=temperature, max_tokens=max_tokens
        )

        # Convert simple {var} to {{ var }} only outside existing Jinja2 blocks
        self._jinja_source = self._normalize_template(template)

        try:
            self._compiled = _jinja_env.from_string(self._jinja_source)
        except TemplateSyntaxError as exc:
            raise ValueError(f"Invalid template syntax: {exc}") from exc

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @property
    def variables(self) -> set[str]:
        """Return all top-level (undeclared) variable names referenced in the template.

        Uses Jinja2 AST analysis so loop variables (e.g. ``item`` in
        ``{% for item in items %}``) are excluded.
        """
        ast = _jinja_env.parse(self._jinja_source)
        return meta.find_undeclared_variables(ast)

    def validate(self, kwargs: dict[str, object]) -> list[str]:
        """Return list of missing required variables. Empty list means valid."""
        provided = set(kwargs.keys())
        missing = self.variables - provided
        return sorted(missing)

    def render(self, **kwargs: object) -> str:
        """Render the template with the given variables.

        Raises ``ValueError`` if any required variable is missing.
        """
        missing = self.validate(kwargs)
        if missing:
            raise ValueError(f"Missing required variables: {', '.join(missing)}")
        try:
            return self._compiled.render(**kwargs)
        except UndefinedError as exc:
            raise ValueError(f"Template rendering error: {exc}") from exc

    def to_prompt(self) -> Prompt:
        """Convert this template to a ``Prompt`` model instance."""
        return Prompt(
            name=self.name,
            version=self.version,
            template=self.raw_template,
            metadata=self.metadata,
        )

    # ------------------------------------------------------------------
    # Class methods
    # ------------------------------------------------------------------

    @classmethod
    def from_prompt(cls, prompt: Prompt) -> PromptTemplate:
        """Create a PromptTemplate from a Prompt model."""
        return cls(
            name=prompt.name,
            version=prompt.version,
            template=prompt.template,
            model=prompt.metadata.model,
            temperature=prompt.metadata.temperature,
            max_tokens=prompt.metadata.max_tokens,
        )

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    @staticmethod
    def _normalize_template(template: str) -> str:
        """Convert simple ``{var}`` placeholders to ``{{ var }}``.

        Skips anything already inside ``{{ }}``, ``{% %}``, or ``{# #}`` blocks.
        """
        # If template already uses Jinja2 syntax, return as-is
        if "{{" in template or "{%" in template or "{#" in template:
            return template
        # Convert simple {var} to {{ var }}
        return _SIMPLE_VAR_RE.sub(r"{{ \1 }}", template)

    def __repr__(self) -> str:
        return f"PromptTemplate(name={self.name!r}, version={self.version!r})"
