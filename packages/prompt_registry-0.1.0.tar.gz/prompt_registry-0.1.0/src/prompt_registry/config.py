"""Configuration and initialization helpers for the prompt system."""

from __future__ import annotations

from enum import StrEnum
from typing import TYPE_CHECKING

from pydantic import BaseModel, Field

from prompt_registry.registry import PromptRegistry
from prompt_registry.store import FilePromptStore

if TYPE_CHECKING:
    pass

_registry: PromptRegistry | None = None


class StoreType(StrEnum):
    """Supported prompt store backends."""

    memory = "memory"
    file = "file"
    database = "database"


class PromptConfig(BaseModel):
    """Configuration for the prompt management system."""

    store_type: StoreType = Field(
        default=StoreType.memory,
        description="Storage backend: 'memory', 'file', or 'database'",
    )
    database_url: str | None = Field(
        default=None,
        description="PostgreSQL connection string (required for 'database' store)",
    )
    prompts_dir: str | None = Field(
        default=None,
        description="Path to YAML prompt files (required for 'file' store)",
    )


def init_prompts(config: PromptConfig | None = None) -> PromptRegistry:
    """Initialize the global prompt registry.

    For file-based stores, prompts are loaded from disk into the registry.
    For memory stores, an empty registry is returned.
    For database stores, use ``init_prompts_async`` instead.
    """
    global _registry
    _registry = PromptRegistry()

    if config and config.store_type == StoreType.file and config.prompts_dir:
        file_store = FilePromptStore(config.prompts_dir)
        for prompt in file_store.load_all():
            _registry.register(
                name=prompt.name,
                version=prompt.version,
                template=prompt.template,
                model=prompt.metadata.model,
                temperature=prompt.metadata.temperature,
                max_tokens=prompt.metadata.max_tokens,
            )

    return _registry


def get_registry() -> PromptRegistry:
    """Return the current global registry. Raises if not initialized."""
    if _registry is None:
        raise RuntimeError("Prompt system not initialized. Call init_prompts() first.")
    return _registry


def reset_registry() -> None:
    """Reset the global registry. Useful for testing."""
    global _registry
    _registry = None
