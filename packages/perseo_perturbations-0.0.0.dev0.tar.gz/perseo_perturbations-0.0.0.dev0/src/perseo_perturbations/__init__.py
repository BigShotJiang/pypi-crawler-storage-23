# SPDX-FileCopyrightText: Aresys S.r.l. <info@aresys.it>
# SPDX-License-Identifier: MIT

"""
Python Ecosystem for Remote Sensing & Earth Observation - PERSEO: Geodynamics and Atmospheric Perturbations
-----------------------------------------------------------------------------------------------------------
"""

__version__ = "0.0.0.dev0"
