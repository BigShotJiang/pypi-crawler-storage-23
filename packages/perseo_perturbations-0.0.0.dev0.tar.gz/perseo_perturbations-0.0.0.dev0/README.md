# PERSEO Perturbations

This package is part of the PERSEO (**P**ython **E**cosystem for **R**emote **S**ensing & **E**arth **O**bservation)
open source python framework developed by Aresys s.r.l..

It provides functionalities for computing geolocation corrections from:

- **geodetic perturbations** (Plate Tectonics, Solid Earth Tides)
- **atmospheric delays** (Ionospheric, Tropospheric)

## Project Status

⚠️ **Coming Soon** ⚠️

This package is currently a placeholder release.

It has been published to PyPI to reserve the project name as part of our release and distribution planning process.
The full implementation, documentation, and production-ready features will be made available in an upcoming official release.

At this stage, the package does not provide functional capabilities and **should not be used in production environments**.

Further updates, including technical documentation and usage guidelines, will follow shortly.

Stay tuned for updates. 🚀
