import re

from slugify import slugify

from ...canonical import Product, Variant
from ..shared import utils
from ..shared.weight_units import resolve_weight_unit

_WIX_HEADER = (
    "handle,fieldType,name,visible,plainDescription,media,mediaAltText,ribbon,brand,price,strikethroughPrice,"
    "baseUnit,baseUnitMeasurement,totalUnits,totalUnitsMeasurement,cost,inventory,preOrderEnabled,preOrderMessage,"
    "preOrderLimit,sku,barcode,weight,productOptionName1,productOptionType1,productOptionChoices1,productOptionName2,"
    "productOptionType2,productOptionChoices2,productOptionName3,productOptionType3,productOptionChoices3,"
    "productOptionName4,productOptionType4,productOptionChoices4,productOptionName5,productOptionType5,"
    "productOptionChoices5,productOptionName6,productOptionType6,productOptionChoices6,modifierName1,modifierType1,"
    "modifierCharLimit1,modifierMandatory1,modifierDescription1,modifierName2,modifierType2,modifierCharLimit2,"
    "modifierMandatory2,modifierDescription2,modifierName3,modifierType3,modifierCharLimit3,modifierMandatory3,"
    "modifierDescription3,modifierName4,modifierType4,modifierCharLimit4,modifierMandatory4,modifierDescription4,"
    "modifierName5,modifierType5,modifierCharLimit5,modifierMandatory5,modifierDescription5,modifierName6,"
    "modifierType6,modifierCharLimit6,modifierMandatory6,modifierDescription6,modifierName7,modifierType7,"
    "modifierCharLimit7,modifierMandatory7,modifierDescription7,modifierName8,modifierType8,modifierCharLimit8,"
    "modifierMandatory8,modifierDescription8,modifierName9,modifierType9,modifierCharLimit9,modifierMandatory9,"
    "modifierDescription9,modifierName10,modifierType10,modifierCharLimit10,modifierMandatory10,modifierDescription10"
)

WIX_COLUMNS: list[str] = _WIX_HEADER.split(",")

_HANDLE_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
_MAX_OPTIONS = 6
_DEFAULT_OPTION_TYPE = "TEXT_CHOICES"
_MAX_WIX_NAME_LEN = 80
_MAX_WIX_PLAIN_DESCRIPTION_LEN = 16000


def _empty_row() -> dict[str, str]:
    return {column: "" for column in WIX_COLUMNS}


def _format_bool(value: bool) -> str:
    return "TRUE" if value else "FALSE"


def _format_inventory_qty(value: int | None) -> str:
    if value is None:
        return ""
    try:
        return str(max(0, int(value)))
    except (TypeError, ValueError):
        return ""


def _truncate(value: str | None, max_len: int) -> str:
    text = str(value or "")
    if not text:
        return ""

    units = 0
    out: list[str] = []
    for ch in text:
        # Wix validation appears to use UTF-16 code units (JS-style length).
        ch_units = 2 if ord(ch) > 0xFFFF else 1
        if units + ch_units > max_len:
            break
        out.append(ch)
        units += ch_units
    return "".join(out)


def _normalize_handle(value: str) -> str:
    normalized = value.strip().lower()
    if _HANDLE_RE.fullmatch(normalized):
        return normalized
    return ""


def _resolve_handle(product: Product) -> str:
    if product.source.slug:
        handle = _normalize_handle(product.source.slug)
        if handle:
            return handle

    if product.title:
        title_handle = _normalize_handle(slugify(product.title))
        if title_handle:
            return title_handle

    fallback = slugify(f"{product.source.platform or 'product'}-{product.source.id or 'item'}")
    handle = _normalize_handle(fallback)
    return handle or "product-item"


def _resolve_price(product: Product, variant: Variant | None = None) -> str:
    amount = utils.resolve_price_amount(product, variant)
    return utils.format_number(amount, decimals=2) if amount is not None else ""


def _resolve_weight(product: Product, variant: Variant | None = None, *, weight_unit: str) -> str:
    grams = utils.resolve_weight_grams(product, variant)
    converted = utils.convert_weight_from_grams(grams, unit=weight_unit)
    if converted is None:
        return ""
    return utils.format_number(converted, decimals=6)


def _resolve_option_names(product: Product, variants: list[Variant]) -> list[str]:
    option_names = [option.name for option in utils.resolve_option_defs(product) if option.name]
    if not option_names and len(variants) > 1:
        return ["Option"]
    return option_names[:_MAX_OPTIONS]


def _fallback_option_value(variant: Variant, index: int) -> str:
    return str(variant.title or variant.sku or variant.id or f"Variant {index}")


def _resolve_product_option_choices(
    *,
    variants: list[Variant],
    variant_option_maps: list[dict[str, str]],
    option_values_by_name: dict[str, list[str]],
    option_name: str,
) -> str:
    values: list[str] = []
    if option_name != "Option":
        values.extend(option_values_by_name.get(option_name, []))

    for index, variant in enumerate(variants, start=1):
        if option_name == "Option":
            values.append(_fallback_option_value(variant, index))
            continue
        value = str(variant_option_maps[index - 1].get(option_name) or "")
        if value:
            values.append(value)

    return ";".join(utils.ordered_unique(values))


def _resolve_variant_option_choice(
    option_name: str,
    variant: Variant,
    *,
    index: int,
    values_by_name: dict[str, str],
) -> str:
    if option_name == "Option":
        return _fallback_option_value(variant, index)
    return str(values_by_name.get(option_name) or "")


def _set_option_fields(
    row: dict[str, str],
    option_names: list[str],
    variants: list[Variant],
    variant_option_maps: list[dict[str, str]],
    option_values_by_name: dict[str, list[str]],
    *,
    variant: Variant | None,
    variant_option_values: dict[str, str] | None,
    index: int,
) -> None:
    for option_index, option_name in enumerate(option_names, start=1):
        row[f"productOptionName{option_index}"] = option_name
        row[f"productOptionType{option_index}"] = _DEFAULT_OPTION_TYPE
        if variant is None:
            row[f"productOptionChoices{option_index}"] = _resolve_product_option_choices(
                variants=variants,
                variant_option_maps=variant_option_maps,
                option_values_by_name=option_values_by_name,
                option_name=option_name,
            )
        else:
            row[f"productOptionChoices{option_index}"] = _resolve_variant_option_choice(
                option_name,
                variant,
                index=index,
                values_by_name=variant_option_values or {},
            )


def _variant_in_stock(product: Product, variant: Variant) -> bool:
    quantity = utils.resolve_variant_inventory_quantity(variant)
    if quantity is not None:
        return quantity > 0
    available = utils.resolve_variant_available(variant)
    if available is not None:
        return bool(available)
    return not utils.resolve_variant_track_quantity(product, variant)


def _resolve_variant_inventory(product: Product, variant: Variant) -> str:
    qty = _format_inventory_qty(utils.resolve_variant_inventory_quantity(variant))
    if qty:
        return qty
    available = utils.resolve_variant_available(variant)
    if available is not None:
        return "IN_STOCK" if available else "OUT_OF_STOCK"
    if not utils.resolve_variant_track_quantity(product, variant):
        return "IN_STOCK"
    return ""


def _resolve_product_inventory(product: Product, variants: list[Variant]) -> str:
    quantities: list[int] = []
    for variant in variants:
        quantity = utils.resolve_variant_inventory_quantity(variant)
        if quantity is None:
            continue
        quantities.append(quantity)

    if quantities:
        return str(sum(quantities))

    in_stock = any(_variant_in_stock(product, variant) for variant in variants)
    if in_stock:
        return "IN_STOCK"
    if not product.track_quantity:
        return "IN_STOCK"
    return "OUT_OF_STOCK"


def product_to_wix_rows(
    product: Product,
    *,
    publish: bool,
    weight_unit: str = "kg",
) -> list[dict[str, str]]:
    resolved_weight_unit = resolve_weight_unit("wix", weight_unit)
    handle = _resolve_handle(product)
    variants = utils.resolve_variants(product)
    images = utils.resolve_product_image_urls(product)
    option_names = _resolve_option_names(product, variants)
    option_values_by_name = {
        option.name: option.values
        for option in utils.resolve_option_defs(product)
        if option.name and option.name in option_names
    }
    variant_option_maps = [utils.resolve_variant_option_map(product, variant) for variant in variants]

    rows: list[dict[str, str]] = []

    first_variant = variants[0] if variants else None
    product_row = _empty_row()
    product_row["handle"] = handle
    product_row["fieldType"] = "PRODUCT"
    product_row["name"] = _truncate(product.title, _MAX_WIX_NAME_LEN)
    product_row["visible"] = _format_bool(publish)
    product_row["plainDescription"] = _truncate(product.description, _MAX_WIX_PLAIN_DESCRIPTION_LEN)
    product_row["brand"] = product.vendor or product.brand or ""
    product_row["price"] = _resolve_price(product, first_variant)
    product_row["inventory"] = _resolve_product_inventory(product, variants)
    product_row["sku"] = str((first_variant.sku if first_variant else None) or product.source.id or "")
    product_row["weight"] = _resolve_weight(product, first_variant, weight_unit=resolved_weight_unit)
    if images:
        product_row["media"] = images[0]
        product_row["mediaAltText"] = (product.title or "").strip()

    _set_option_fields(
        product_row,
        option_names,
        variants,
        variant_option_maps,
        option_values_by_name,
        variant=None,
        variant_option_values=None,
        index=0,
    )
    rows.append(product_row)

    for index, variant in enumerate(variants, start=1):
        variant_option_values = variant_option_maps[index - 1]
        variant_row = _empty_row()
        variant_row["handle"] = handle
        variant_row["fieldType"] = "VARIANT"
        variant_row["visible"] = _format_bool(publish)
        variant_row["price"] = _resolve_price(product, variant)
        variant_row["inventory"] = _resolve_variant_inventory(product, variant)
        variant_row["sku"] = str(variant.sku or variant.id or "")
        variant_row["weight"] = _resolve_weight(product, variant, weight_unit=resolved_weight_unit)

        _set_option_fields(
            variant_row,
            option_names,
            variants,
            variant_option_maps,
            option_values_by_name,
            variant=variant,
            variant_option_values=variant_option_values,
            index=index,
        )
        rows.append(variant_row)

    for image_url in images[1:]:
        media_row = _empty_row()
        media_row["handle"] = handle
        media_row["fieldType"] = "MEDIA"
        media_row["media"] = image_url
        media_row["mediaAltText"] = (product.title or "").strip()
        rows.append(media_row)

    return rows


def product_to_wix_csv(
    product: Product,
    *,
    publish: bool,
    weight_unit: str = "kg",
) -> tuple[str, str]:
    rows = product_to_wix_rows(product, publish=publish, weight_unit=weight_unit)
    return utils.dict_rows_to_csv(rows, WIX_COLUMNS), utils.make_export_filename("wix")
