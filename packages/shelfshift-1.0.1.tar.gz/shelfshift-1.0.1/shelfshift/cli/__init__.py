"""CLI frontend for the Shelfshift core engine."""
