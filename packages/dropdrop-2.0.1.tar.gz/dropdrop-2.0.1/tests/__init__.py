"""DropDrop test suite."""
