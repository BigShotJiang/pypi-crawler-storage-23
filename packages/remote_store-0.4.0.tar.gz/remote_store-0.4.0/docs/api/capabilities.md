# Capabilities

Backends declare what they support through the capability system. This allows operations to fail with clear errors rather than silent surprises.

::: remote_store.Capability

---

::: remote_store.CapabilitySet
