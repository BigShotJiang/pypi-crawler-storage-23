{%
   include-markdown "../../../sdd/specs/005-error-model.md"
   rewrite-relative-urls=false
%}
