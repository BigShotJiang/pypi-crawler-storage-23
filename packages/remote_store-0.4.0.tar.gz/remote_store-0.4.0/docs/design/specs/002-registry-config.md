{%
   include-markdown "../../../sdd/specs/002-registry-config.md"
   rewrite-relative-urls=false
%}
