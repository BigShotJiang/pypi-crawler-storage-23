{%
   include-markdown "../../../sdd/adrs/0001-architecture-store-registry-backends.md"
   rewrite-relative-urls=false
%}
