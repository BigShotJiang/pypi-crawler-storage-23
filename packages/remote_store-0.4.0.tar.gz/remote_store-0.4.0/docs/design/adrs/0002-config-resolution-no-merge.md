{%
   include-markdown "../../../sdd/adrs/0002-config-resolution-no-merge.md"
   rewrite-relative-urls=false
%}
