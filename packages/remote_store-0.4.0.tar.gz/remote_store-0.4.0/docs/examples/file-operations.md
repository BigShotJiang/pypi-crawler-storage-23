# File Operations

Read, write, delete, move, copy, list, and metadata.

```python
--8<-- "examples/file_operations.py"
```
