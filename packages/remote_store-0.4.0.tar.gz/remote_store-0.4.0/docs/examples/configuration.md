# Configuration

Config-as-code, `from_dict()`, and multiple stores.

```python
--8<-- "examples/configuration.py"
```
