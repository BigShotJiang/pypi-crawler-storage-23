"""CLI tests for lintro."""
