"""Integration tests for lintro."""
