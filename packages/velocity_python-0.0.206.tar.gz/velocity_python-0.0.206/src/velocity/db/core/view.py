from __future__ import annotations

from dataclasses import dataclass

from velocity.db import exceptions


def _quote_ident(identifier: str) -> str:
    return '"' + str(identifier).replace('"', '""') + '"'


def _grantee_sql(grantee: str) -> str:
    normalized = str(grantee).strip()
    if not normalized:
        raise ValueError("grantee cannot be empty")

    keyword = normalized.upper()
    if keyword in {"PUBLIC", "CURRENT_USER", "SESSION_USER"}:
        return keyword

    return _quote_ident(normalized)


@dataclass
class Grant:
    privilege: str
    grantee: str


class View:
    """PostgreSQL view helper.

    This is intentionally lightweight and uses catalog queries directly rather than
    embedding view DDL in the dialect.

    Primary goals:
    - Create views in an idempotent way (CREATE OR REPLACE).
    - If the view already exists, "enhance" it by applying missing grants.

    Notes:
    - For updating the view definition, pass replace_existing=True.
    - Privilege checks use has_table_privilege().
    """

    def __init__(self, tx, name: str, schema: str | None = None):
        self.tx = tx
        self.name = str(name).lower()
        self.schema = (schema or getattr(tx.engine.sql, "default_schema", None) or "public").lower()

    @property
    def qualified_name(self) -> str:
        return f"{_quote_ident(self.schema)}.{_quote_ident(self.name)}"

    def exists(self) -> bool:
        result = self.tx.execute(
            """
            SELECT 1
            FROM information_schema.views
            WHERE table_schema = %s AND table_name = %s
            LIMIT 1
            """,
            [self.schema, self.name],
        )
        try:
            rows = result.as_dict().all()
        except Exception:
            rows = []
        return bool(rows)

    def create_or_replace(self, select_sql: str) -> None:
        if self.tx.engine.schema_locked:
            raise exceptions.DbSchemaLockedError(
                f"Cannot create/replace view {self.schema}.{self.name}: schema is locked"
            )

        sql = (select_sql or "").strip().rstrip(";")
        if not sql:
            raise ValueError("select_sql cannot be empty")

        # If caller already provided CREATE VIEW, execute as-is.
        lowered = sql.lower().lstrip()
        if lowered.startswith("create"):
            self.tx.execute(sql)
            return

        ddl = f"CREATE OR REPLACE VIEW {self.qualified_name} AS\n{sql}"
        self.tx.execute(ddl)

    def _has_privilege(self, grantee: str, privilege: str) -> bool:
        # PUBLIC is a PostgreSQL pseudo-role for GRANT, but it's not necessarily a
        # real role that can be passed to has_table_privilege() in all setups.
        # GRANT itself is idempotent, so for PUBLIC we just apply it unconditionally.
        if str(grantee).strip().upper() == "PUBLIC":
            return False

        # has_table_privilege(role, table, privilege)
        # Note: privilege must be like 'SELECT'.
        result = self.tx.execute(
            "SELECT has_table_privilege(%s, %s, %s) as ok",
            [grantee, f"{self.schema}.{self.name}", privilege],
        )
        try:
            rows = result.as_dict().all()
        except Exception:
            rows = []
        row = rows[0] if rows else None
        return bool(row.get("ok")) if isinstance(row, dict) and row else False

    def grant(self, privilege: str = "SELECT", grantee: str = "PUBLIC") -> None:
        if self.tx.engine.schema_locked:
            raise exceptions.DbSchemaLockedError(
                f"Cannot grant privileges on {self.schema}.{self.name}: schema is locked"
            )
        privilege = str(privilege).upper().strip()
        if not privilege:
            raise ValueError("privilege cannot be empty")
        self.tx.execute(
            f"GRANT {privilege} ON {self.qualified_name} TO {_grantee_sql(grantee)}"
        )

    def ensure(
        self,
        select_sql: str | None = None,
        *,
        replace_existing: bool = False,
        grants: list[Grant] | None = None,
        grant_public_select: bool = True,
    ) -> None:
        """Ensure the view exists and has required grants.

        - If the view does not exist, it is created using select_sql (required).
        - If it exists, it is not modified unless replace_existing=True.
        - Missing privileges are granted.
        """

        exists = self.exists()

        if not exists:
            if select_sql is None:
                raise ValueError("select_sql is required when creating a missing view")
            self.create_or_replace(select_sql)
        elif replace_existing and select_sql is not None:
            self.create_or_replace(select_sql)

        desired_grants: list[Grant] = []
        if grant_public_select:
            desired_grants.append(Grant("SELECT", "PUBLIC"))
        if grants:
            desired_grants.extend(grants)

        for g in desired_grants:
            privilege = str(g.privilege).upper().strip()
            grantee = str(g.grantee).strip()
            if not privilege or not grantee:
                continue

            if not self._has_privilege(grantee, privilege):
                self.grant(privilege=privilege, grantee=grantee)
