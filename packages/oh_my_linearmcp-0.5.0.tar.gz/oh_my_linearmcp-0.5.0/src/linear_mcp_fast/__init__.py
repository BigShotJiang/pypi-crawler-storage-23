"""
oh-my-linearmcp (OhMyLinearMCP) - unified Linear MCP via local cache + official fallback.
"""

from .server import main

__version__ = "0.5.0"
__all__ = ["main"]
