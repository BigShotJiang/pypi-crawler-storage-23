"""Compatibility package for running OhMyLinearMCP by distribution-aligned module name."""

from linear_mcp_fast import main

__all__ = ["main"]
