"""Entry point for running oh_my_linearmcp as a module."""

from linear_mcp_fast import main

if __name__ == "__main__":
    main()
