const ErrorMessages = {
  GitClone: {
    Dialog: 'GitCloneDialogError',
    ValidRepoPathError: 'ValidRepoPathError',
  },
};

export { ErrorMessages };
