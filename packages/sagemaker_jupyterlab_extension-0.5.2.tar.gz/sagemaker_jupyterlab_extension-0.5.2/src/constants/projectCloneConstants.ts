type ProjectsListResponse = {
  projectsList: string[];
};

export { ProjectsListResponse };
