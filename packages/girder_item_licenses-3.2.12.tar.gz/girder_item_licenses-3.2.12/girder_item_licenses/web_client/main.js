import './routes';

// Extends and overrides API
import './views/EditItemWidget';
import './views/HierarchyWidget';
import './views/ItemView';
import './views/UploadWidget';
