"""test_phase1.py – Phase 1: Schema primitives, FunctorNode, Pipeline DLL linking.

Async-aware: pipeline.append() and pipeline.execute_all() are now coroutines.
"""

from __future__ import annotations

import pytest

from morphism.core.schemas import Int_0_to_100, Float_Normalized
from morphism.core.node import FunctorNode
from morphism.core.pipeline import MorphismPipeline
from morphism.exceptions import SchemaMismatchError


# ======================================================================
# Test A – Compatible append succeeds and DLL is correctly linked
# ======================================================================

@pytest.mark.asyncio
async def test_append_compatible_nodes() -> None:
    pipeline = MorphismPipeline()

    node_a = FunctorNode(
        input_schema=Int_0_to_100,
        output_schema=Int_0_to_100,
        executable=lambda x: x + 1,
        name="increment",
    )
    node_b = FunctorNode(
        input_schema=Int_0_to_100,
        output_schema=Int_0_to_100,
        executable=lambda x: x * 2,
        name="double",
    )

    assert await pipeline.append(node_a) is True
    assert await pipeline.append(node_b) is True

    assert pipeline.head is node_a
    assert pipeline.tail is node_b
    assert node_a.children[0] is node_b
    assert node_b.parents[0] is node_a
    assert pipeline.length == 2


# ======================================================================
# Test B – Incompatible append raises SchemaMismatchError
# ======================================================================

@pytest.mark.asyncio
async def test_append_incompatible_node_raises() -> None:
    pipeline = MorphismPipeline()

    node_a = FunctorNode(
        input_schema=Int_0_to_100,
        output_schema=Int_0_to_100,
        executable=lambda x: x + 1,
        name="increment",
    )
    node_b = FunctorNode(
        input_schema=Int_0_to_100,
        output_schema=Int_0_to_100,
        executable=lambda x: x * 2,
        name="double",
    )
    node_bad = FunctorNode(
        input_schema=Float_Normalized,
        output_schema=Float_Normalized,
        executable=lambda x: x * 0.5,
        name="halve_float",
    )

    await pipeline.append(node_a)
    await pipeline.append(node_b)

    with pytest.raises(SchemaMismatchError):
        await pipeline.append(node_bad)

    assert pipeline.length == 2
    assert pipeline.tail is node_b
    assert len(node_b.children) == 0


# ======================================================================
# Test C – Execution and time-travel
# ======================================================================

@pytest.mark.asyncio
async def test_execute_and_time_travel() -> None:
    pipeline = MorphismPipeline()

    node_a = FunctorNode(
        input_schema=Int_0_to_100,
        output_schema=Int_0_to_100,
        executable=lambda x: x + 10,
        name="add_10",
    )
    node_b = FunctorNode(
        input_schema=Int_0_to_100,
        output_schema=Int_0_to_100,
        executable=lambda x: x * 2,
        name="double",
    )

    await pipeline.append(node_a)
    await pipeline.append(node_b)

    result = await pipeline.execute_all(5)
    assert result == 30

    assert pipeline.maps_back() == 15
    assert pipeline.maps_forward() == 30
