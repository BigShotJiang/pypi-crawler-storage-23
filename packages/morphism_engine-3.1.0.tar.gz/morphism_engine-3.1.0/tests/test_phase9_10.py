"""test_phase9_10.py – Phases 9 & 10: SQLite Functor Cache + DAG Branching.

Test A: Cache hit/miss lifecycle
Test B: DAG topological execution with parallel branches
Test C: Regression – linear pipeline still works after DAG refactor
"""

from __future__ import annotations

import asyncio
import os
import tempfile
from pathlib import Path
from unittest.mock import AsyncMock, patch

import pytest

from morphism.ai.synthesizer import MockLLMSynthesizer, LLMSynthesizer
from morphism.core.cache import FunctorCache, _schema_hash
from morphism.core.node import FunctorNode
from morphism.core.pipeline import MorphismPipeline
from morphism.core.schemas import (
    Float_Normalized,
    Int_0_to_100,
    Int_0_to_10,
    String_NonEmpty,
)
from morphism.exceptions import SchemaMismatchError, VerificationFailedError


# ======================================================================
# Helpers
# ======================================================================


class SpyMockLLM(MockLLMSynthesizer):
    """A MockLLM that counts how many times generate_functor is called."""

    def __init__(self) -> None:
        super().__init__()
        self.call_count: int = 0

    async def generate_functor(self, source, target) -> str:
        self.call_count += 1
        return await super().generate_functor(source, target)


@pytest.fixture()
def tmp_cache(tmp_path: Path) -> FunctorCache:
    """Return a FunctorCache backed by a temp file."""
    db = tmp_path / "test_cache.db"
    return FunctorCache(db_path=db)


# ======================================================================
# Test A – Cache Hit / Miss lifecycle
# ======================================================================


class TestCacheHitMiss:
    """Build the same mismatch pipeline twice. Second time must hit cache."""

    @pytest.mark.asyncio
    async def test_cache_miss_then_hit(self, tmp_cache: FunctorCache) -> None:
        spy = SpyMockLLM()

        # ── First run: cache miss → LLM synthesis ────────────────────
        p1 = MorphismPipeline(llm_client=spy, cache=tmp_cache)

        n1 = FunctorNode(
            input_schema=Int_0_to_100,
            output_schema=Int_0_to_100,
            executable=lambda x: x,
            name="source_int",
        )
        n2 = FunctorNode(
            input_schema=Float_Normalized,
            output_schema=Float_Normalized,
            executable=lambda x: x,
            name="sink_float",
        )

        await p1.append(n1)
        await p1.append(n2)

        result1 = await p1.execute_all(50)
        assert result1 == 0.5
        assert spy.call_count == 1  # LLM was invoked

        # ── Second run: cache hit → LLM NOT invoked ──────────────────
        spy2 = SpyMockLLM()
        p2 = MorphismPipeline(llm_client=spy2, cache=tmp_cache)

        n3 = FunctorNode(
            input_schema=Int_0_to_100,
            output_schema=Int_0_to_100,
            executable=lambda x: x,
            name="source_int_2",
        )
        n4 = FunctorNode(
            input_schema=Float_Normalized,
            output_schema=Float_Normalized,
            executable=lambda x: x,
            name="sink_float_2",
        )

        await p2.append(n3)
        await p2.append(n4)

        result2 = await p2.execute_all(80)
        assert result2 == pytest.approx(0.8, abs=1e-6)
        assert spy2.call_count == 0  # LLM was NOT invoked (cache hit)

    def test_cache_roundtrip(self, tmp_cache: FunctorCache) -> None:
        """Test store + lookup at the DB level."""
        assert tmp_cache.lookup("A", "B") is None
        tmp_cache.store("A", "B", "lambda x: x / 100.0")
        result = tmp_cache.lookup("A", "B")
        assert result == "lambda x: x / 100.0"

    def test_schema_hash_deterministic(self) -> None:
        h1 = _schema_hash("Int_0_to_100", "Float_Normalized")
        h2 = _schema_hash("Int_0_to_100", "Float_Normalized")
        assert h1 == h2
        assert len(h1) == 64  # SHA-256

    def test_schema_hash_different_pairs(self) -> None:
        h1 = _schema_hash("A", "B")
        h2 = _schema_hash("B", "A")
        assert h1 != h2


# ======================================================================
# Test B – DAG Topological Execution (parallel branches)
# ======================================================================


class TestDAGBranching:
    @pytest.mark.asyncio
    async def test_fan_out_two_children(self, tmp_cache: FunctorCache) -> None:
        """emit_raw → bridge → (render_float, render_float)

        Both leaf nodes must execute concurrently and receive the
        correct Z3-verified data.
        """
        spy = SpyMockLLM()
        pipeline = MorphismPipeline(llm_client=spy, cache=tmp_cache)

        root = FunctorNode(
            input_schema=Int_0_to_100,
            output_schema=Int_0_to_100,
            executable=lambda x: 50,
            name="emit_raw",
        )
        pipeline.root_nodes.append(root)
        pipeline.all_nodes.append(root)

        child_a = FunctorNode(
            input_schema=Float_Normalized,
            output_schema=String_NonEmpty,
            executable=lambda x: f"[RENDERED UI]: {x}",
            name="render_float_A",
        )
        child_b = FunctorNode(
            input_schema=Float_Normalized,
            output_schema=String_NonEmpty,
            executable=lambda x: f"[RENDERED UI]: {x}",
            name="render_float_B",
        )

        await pipeline.add_branch(root, [child_a, child_b])

        result = await pipeline.execute_all(None)

        # Both children should have executed
        assert child_a.output_state is not None
        assert child_b.output_state is not None
        assert "[RENDERED UI]: 0.5" in child_a.output_state
        assert "[RENDERED UI]: 0.5" in child_b.output_state

    @pytest.mark.asyncio
    async def test_parent_child_relationship(self) -> None:
        """Verify bidirectional parent/child edges."""
        parent = FunctorNode(
            input_schema=Int_0_to_100,
            output_schema=Int_0_to_100,
            executable=lambda x: x,
            name="parent",
        )
        child = FunctorNode(
            input_schema=Int_0_to_100,
            output_schema=Int_0_to_100,
            executable=lambda x: x + 1,
            name="child",
        )
        parent.append_child(child)

        assert child in parent.children
        assert parent in child.parents

        # idempotent
        parent.append_child(child)
        assert parent.children.count(child) == 1

    @pytest.mark.asyncio
    async def test_fan_out_compatible_no_bridge(self) -> None:
        """Fan-out where all edges are schema-compatible → no bridge."""
        pipeline = MorphismPipeline()  # no LLM needed

        root = FunctorNode(
            input_schema=Int_0_to_100,
            output_schema=Int_0_to_100,
            executable=lambda x: 42,
            name="root",
        )
        pipeline.root_nodes.append(root)
        pipeline.all_nodes.append(root)

        c1 = FunctorNode(
            input_schema=Int_0_to_100,
            output_schema=Int_0_to_100,
            executable=lambda x: x + 1,
            name="child_1",
        )
        c2 = FunctorNode(
            input_schema=Int_0_to_100,
            output_schema=Int_0_to_100,
            executable=lambda x: x + 2,
            name="child_2",
        )

        await pipeline.add_branch(root, [c1, c2])

        result = await pipeline.execute_all(None)

        assert c1.output_state == 43
        assert c2.output_state == 44

    @pytest.mark.asyncio
    async def test_branch_mismatch_without_llm_raises(self) -> None:
        """Branch with mismatch and no LLM → SchemaMismatchError."""
        pipeline = MorphismPipeline()  # no LLM

        root = FunctorNode(
            input_schema=Int_0_to_100,
            output_schema=Int_0_to_100,
            executable=lambda x: 50,
            name="root",
        )
        pipeline.root_nodes.append(root)
        pipeline.all_nodes.append(root)

        child = FunctorNode(
            input_schema=Float_Normalized,
            output_schema=Float_Normalized,
            executable=lambda x: x,
            name="child_float",
        )

        with pytest.raises(SchemaMismatchError):
            await pipeline.add_branch(root, [child])


# ======================================================================
# Test C – Regression: Linear pipeline still works after DAG refactor
# ======================================================================


class TestLinearRegression:
    @pytest.mark.asyncio
    async def test_linear_three_node_pipeline(self) -> None:
        """Standard linear chain: A → B → C."""
        pipeline = MorphismPipeline()

        nodes = [
            FunctorNode(
                input_schema=Int_0_to_100,
                output_schema=Int_0_to_100,
                executable=lambda x: x + 10,
                name="add_10",
            ),
            FunctorNode(
                input_schema=Int_0_to_100,
                output_schema=Int_0_to_100,
                executable=lambda x: x * 2,
                name="double",
            ),
            FunctorNode(
                input_schema=Int_0_to_100,
                output_schema=Int_0_to_100,
                executable=lambda x: x - 1,
                name="sub_1",
            ),
        ]

        for n in nodes:
            await pipeline.append(n)

        result = await pipeline.execute_all(5)
        assert result == 29  # (5+10)*2 - 1

    @pytest.mark.asyncio
    async def test_time_travel_linear(self) -> None:
        """maps_back / maps_forward still work on linear chains."""
        pipeline = MorphismPipeline()

        na = FunctorNode(
            input_schema=Int_0_to_100,
            output_schema=Int_0_to_100,
            executable=lambda x: x + 10,
            name="add_10",
        )
        nb = FunctorNode(
            input_schema=Int_0_to_100,
            output_schema=Int_0_to_100,
            executable=lambda x: x * 2,
            name="double",
        )

        await pipeline.append(na)
        await pipeline.append(nb)

        result = await pipeline.execute_all(5)
        assert result == 30

        assert pipeline.maps_back() == 15
        assert pipeline.maps_forward() == 30

    @pytest.mark.asyncio
    async def test_self_healing_with_cache(self, tmp_cache: FunctorCache) -> None:
        """Mock-LLM self-healing + cache store works end-to-end."""
        spy = SpyMockLLM()
        pipeline = MorphismPipeline(llm_client=spy, cache=tmp_cache)

        n1 = FunctorNode(
            input_schema=Int_0_to_100,
            output_schema=Int_0_to_100,
            executable=lambda x: x,
            name="src",
        )
        n2 = FunctorNode(
            input_schema=Float_Normalized,
            output_schema=Float_Normalized,
            executable=lambda x: x,
            name="sink",
        )

        await pipeline.append(n1)
        await pipeline.append(n2)
        result = await pipeline.execute_all(100)
        assert result == 1.0

        # Cache should now contain the lambda
        cached = tmp_cache.lookup("Int_0_to_100", "Float_Normalized")
        assert cached == "lambda x: x / 100.0"
