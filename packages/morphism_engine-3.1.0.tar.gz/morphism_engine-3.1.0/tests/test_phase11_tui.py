"""test_phase11_tui.py – Phase 11 (Overhaul): Textual TUI Topographer.

Tests use Textual's ``pilot`` testing framework to headlessly drive
the TUI, submit commands, select tree nodes, and assert widget state.

Covers the v3.1 overhaul:
  - Widget composition (DataTable, Suggester, LoadingIndicator)
  - Tool Catalog population & filtering
  - Pipeline execution via worker
  - DAG tree population
  - Inspector panel
  - RichLog logging handler
  - Error handling / edge cases
"""

from __future__ import annotations

import asyncio

import pytest

from morphism.cli.tui import (
    TOOL_REGISTRY,
    MorphismApp,
    _PipeSuggester,
    _RichLogHandler,
    _TOOL_NAMES,
    _make_node,
)
from morphism.core.node import FunctorNode
from morphism.core.schemas import Int_0_to_100, Float_Normalized, String_NonEmpty


# ======================================================================
# Helpers
# ======================================================================

async def _wait_for_processing(pilot, cycles: int = 40) -> None:
    """Pause enough animation frames for the async worker to resolve."""
    for _ in range(cycles):
        await pilot.pause()


# ======================================================================
# Test A – Widget Composition (overhauled layout)
# ======================================================================

class TestWidgetComposition:

    @pytest.mark.asyncio
    async def test_app_has_all_core_widgets(self) -> None:
        """App must compose Header, Footer, Tree, Static, RichLog, and Inputs."""
        app = MorphismApp()
        async with app.run_test() as pilot:
            from textual.widgets import (
                Header, Footer, Tree, RichLog, Static, Input, DataTable,
            )
            assert app.query_one("#topographer", Tree)
            assert app.query_one("#inspector", Static)
            assert app.query_one("#telemetry", RichLog)
            assert app.query_one("#cmd-input", Input)
            assert app.query(Header)
            assert app.query(Footer)

    @pytest.mark.asyncio
    async def test_app_has_catalog_datatable(self) -> None:
        """The Tool Catalog DataTable must be present."""
        app = MorphismApp()
        async with app.run_test() as pilot:
            from textual.widgets import DataTable
            table = app.query_one("#catalog-table", DataTable)
            assert table is not None

    @pytest.mark.asyncio
    async def test_app_has_catalog_filter_input(self) -> None:
        """The catalog filter Input must be present."""
        app = MorphismApp()
        async with app.run_test() as pilot:
            from textual.widgets import Input
            filt = app.query_one("#catalog-filter", Input)
            assert filt is not None

    @pytest.mark.asyncio
    async def test_cmd_input_has_suggester(self) -> None:
        """The command input should have a _PipeSuggester attached."""
        app = MorphismApp()
        async with app.run_test() as pilot:
            inp = app.query_one("#cmd-input")
            assert inp.suggester is not None
            assert isinstance(inp.suggester, _PipeSuggester)

    @pytest.mark.asyncio
    async def test_telemetry_has_startup_message(self) -> None:
        """The telemetry panel should have the logging handler attached."""
        app = MorphismApp()
        async with app.run_test() as pilot:
            await pilot.pause()
            assert app._log_handler is not None


# ======================================================================
# Test B – Tool Catalog Population & Filtering
# ======================================================================

class TestToolCatalog:

    @pytest.mark.asyncio
    async def test_catalog_populated_on_mount(self) -> None:
        """Catalog DataTable should have rows for each registry entry."""
        app = MorphismApp()
        async with app.run_test() as pilot:
            from textual.widgets import DataTable
            table = app.query_one("#catalog-table", DataTable)
            assert table.row_count == len(TOOL_REGISTRY)

    @pytest.mark.asyncio
    async def test_catalog_has_correct_columns(self) -> None:
        """Catalog should have Tool, Input, Output columns."""
        app = MorphismApp()
        async with app.run_test() as pilot:
            from textual.widgets import DataTable
            table = app.query_one("#catalog-table", DataTable)
            col_labels = [str(c.label) for c in table.columns.values()]
            assert "Tool" in col_labels
            assert "Input" in col_labels
            assert "Output" in col_labels

    @pytest.mark.asyncio
    async def test_catalog_filter_narrows_rows(self) -> None:
        """Typing in the filter should reduce the catalog rows."""
        app = MorphismApp()
        async with app.run_test() as pilot:
            from textual.widgets import DataTable, Input
            filt = app.query_one("#catalog-filter", Input)
            table = app.query_one("#catalog-table", DataTable)

            # Start with all rows
            assert table.row_count == len(TOOL_REGISTRY)

            # Type a filter that matches only one tool
            filt.value = "emit"
            await pilot.pause()
            await pilot.pause()
            assert table.row_count == 1

    @pytest.mark.asyncio
    async def test_catalog_filter_no_match(self) -> None:
        """A filter with no matches should produce 0 rows."""
        app = MorphismApp()
        async with app.run_test() as pilot:
            from textual.widgets import DataTable, Input
            filt = app.query_one("#catalog-filter", Input)
            table = app.query_one("#catalog-table", DataTable)

            filt.value = "nonexistent_tool_xyz"
            await pilot.pause()
            await pilot.pause()
            assert table.row_count == 0

    @pytest.mark.asyncio
    async def test_catalog_filter_clear_restores_all(self) -> None:
        """Clearing the filter should restore all rows."""
        app = MorphismApp()
        async with app.run_test() as pilot:
            from textual.widgets import DataTable, Input
            filt = app.query_one("#catalog-filter", Input)
            table = app.query_one("#catalog-table", DataTable)

            filt.value = "emit"
            await pilot.pause()
            assert table.row_count == 1

            filt.value = ""
            await pilot.pause()
            assert table.row_count == len(TOOL_REGISTRY)


# ======================================================================
# Test C – Pipeline Execution via Input (worker-backed)
# ======================================================================

class TestPipelineExecution:

    @pytest.mark.asyncio
    async def test_single_node_pipeline(self) -> None:
        """Typing 'emit_raw' should build a 1-node pipeline."""
        app = MorphismApp()
        async with app.run_test() as pilot:
            inp = app.query_one("#cmd-input")
            inp.value = "emit_raw"
            await inp.action_submit()
            await _wait_for_processing(pilot)

            assert app._pipeline is not None
            assert app._pipeline.length == 1
            assert app._pipeline.head.name == "emit_raw"

    @pytest.mark.asyncio
    async def test_linear_two_node_pipeline(self) -> None:
        """'emit_raw | render_float' should build a 2-node chain."""
        app = MorphismApp()
        async with app.run_test() as pilot:
            inp = app.query_one("#cmd-input")
            inp.value = "emit_raw | render_float"
            await inp.action_submit()
            await _wait_for_processing(pilot)

            assert app._pipeline is not None
            assert app._pipeline.length >= 2
            assert app._pipeline.head.name == "emit_raw"

    @pytest.mark.asyncio
    async def test_input_clears_after_submit(self) -> None:
        """After pressing Enter the input should be empty."""
        app = MorphismApp()
        async with app.run_test() as pilot:
            inp = app.query_one("#cmd-input")
            inp.value = "emit_raw"
            await inp.action_submit()
            await _wait_for_processing(pilot)
            assert inp.value == ""

    @pytest.mark.asyncio
    async def test_catalog_filter_submit_does_not_run_pipeline(self) -> None:
        """Pressing Enter in the catalog filter must NOT trigger a pipeline."""
        app = MorphismApp()
        async with app.run_test() as pilot:
            filt = app.query_one("#catalog-filter")
            filt.value = "emit"
            await filt.action_submit()
            await _wait_for_processing(pilot, cycles=10)
            # No pipeline should have been created
            assert app._pipeline is None


# ======================================================================
# Test D – DAG Tree Population
# ======================================================================

class TestDAGTree:

    @pytest.mark.asyncio
    async def test_tree_populated_after_pipeline(self) -> None:
        """After executing a pipeline the tree should have child nodes."""
        app = MorphismApp()
        async with app.run_test() as pilot:
            inp = app.query_one("#cmd-input")
            inp.value = "emit_raw"
            await inp.action_submit()
            await _wait_for_processing(pilot)

            from textual.widgets import Tree
            tree = app.query_one("#topographer", Tree)
            assert len(tree.root.children) >= 1

    @pytest.mark.asyncio
    async def test_tree_has_schema_labels(self) -> None:
        """Tree node labels should contain schema names."""
        app = MorphismApp()
        async with app.run_test() as pilot:
            inp = app.query_one("#cmd-input")
            inp.value = "emit_raw"
            await inp.action_submit()
            await _wait_for_processing(pilot)

            from textual.widgets import Tree
            tree = app.query_one("#topographer", Tree)
            first_child = tree.root.children[0]
            label_text = str(first_child.label)
            assert "Int_0_to_100" in label_text

    @pytest.mark.asyncio
    async def test_node_map_populated(self) -> None:
        """The app's _node_map should have entries for every pipeline node."""
        app = MorphismApp()
        async with app.run_test() as pilot:
            inp = app.query_one("#cmd-input")
            inp.value = "emit_raw"
            await inp.action_submit()
            await _wait_for_processing(pilot)

            assert len(app._node_map) >= 1


# ======================================================================
# Test E – Inspector Panel
# ======================================================================

class TestInspector:

    @pytest.mark.asyncio
    async def test_inspector_default_message(self) -> None:
        """Before selecting a node, inspector shows default text."""
        app = MorphismApp()
        async with app.run_test() as pilot:
            from textual.widgets import Static
            inspector = app.query_one("#inspector", Static)
            # Textual 8 name-mangles the content attribute
            text = str(inspector._Static__content)
            assert "Select a node" in text or "inspect" in text.lower()


# ======================================================================
# Test F – _make_node Helper
# ======================================================================

class TestMakeNode:

    def test_known_tool_returns_functor_node(self) -> None:
        node = _make_node("emit_raw")
        assert isinstance(node, FunctorNode)
        assert node.name == "emit_raw"
        assert node.output_schema == Int_0_to_100

    def test_known_tool_render_float(self) -> None:
        node = _make_node("render_float")
        assert node.input_schema == Float_Normalized
        assert node.output_schema == String_NonEmpty

    def test_unknown_tool_returns_native_node(self) -> None:
        from morphism.core.native_node import NativeCommandNode
        node = _make_node("echo hello")
        assert isinstance(node, NativeCommandNode)


# ======================================================================
# Test G – RichLog Handler
# ======================================================================

class TestRichLogHandler:

    @pytest.mark.asyncio
    async def test_handler_attached_on_mount(self) -> None:
        """The custom logging handler should be attached after mount."""
        app = MorphismApp()
        async with app.run_test() as pilot:
            assert app._log_handler is not None
            assert isinstance(app._log_handler, _RichLogHandler)

    @pytest.mark.asyncio
    async def test_handler_removed_on_exit(self) -> None:
        """After exiting, the handler should be removed from the logger."""
        import logging
        app = MorphismApp()
        async with app.run_test() as pilot:
            handler = app._log_handler
            assert handler is not None
        # After context exit, on_unmount fires
        root_logger = logging.getLogger("morphism")
        assert handler not in root_logger.handlers


# ======================================================================
# Test H – Pipe-aware Suggester
# ======================================================================

class TestPipeSuggester:

    @pytest.mark.asyncio
    async def test_simple_suggestion(self) -> None:
        """Typing a prefix should suggest a matching tool name."""
        suggester = _PipeSuggester(_TOOL_NAMES)
        result = await suggester.get_suggestion("emi")
        assert result == "emit_raw"

    @pytest.mark.asyncio
    async def test_pipe_resets_suggestion(self) -> None:
        """After a pipe, suggestions should autocomplete the new segment."""
        suggester = _PipeSuggester(_TOOL_NAMES)
        result = await suggester.get_suggestion("emit_raw | ren")
        assert result is not None
        assert "render_float" in result

    @pytest.mark.asyncio
    async def test_pipe_no_fragment_returns_none(self) -> None:
        """After a pipe with no text, suggestion should be None."""
        suggester = _PipeSuggester(_TOOL_NAMES)
        result = await suggester.get_suggestion("emit_raw | ")
        assert result is None

    @pytest.mark.asyncio
    async def test_no_match_returns_none(self) -> None:
        """If no tools match, suggestion should be None."""
        suggester = _PipeSuggester(_TOOL_NAMES)
        result = await suggester.get_suggestion("zzz_no_match")
        assert result is None


# ======================================================================
# Test I – Loading State
# ======================================================================

class TestLoadingState:

    @pytest.mark.asyncio
    async def test_loading_flag_false_initially(self) -> None:
        """Loading flag should be False before any pipeline runs."""
        app = MorphismApp()
        async with app.run_test() as pilot:
            assert app._loading is False

    @pytest.mark.asyncio
    async def test_loading_cleared_after_pipeline(self) -> None:
        """After pipeline completes, loading should be cleared."""
        app = MorphismApp()
        async with app.run_test() as pilot:
            inp = app.query_one("#cmd-input")
            inp.value = "emit_raw"
            await inp.action_submit()
            await _wait_for_processing(pilot)
            # After completion, loading should be False
            assert app._loading is False


# ======================================================================
# Test J – Error Handling / Edge Cases
# ======================================================================

class TestErrorHandling:

    @pytest.mark.asyncio
    async def test_empty_input_ignored(self) -> None:
        """An empty input should not create a pipeline."""
        app = MorphismApp()
        async with app.run_test() as pilot:
            inp = app.query_one("#cmd-input")
            inp.value = ""
            await inp.action_submit()
            await _wait_for_processing(pilot, cycles=5)
            assert app._pipeline is None

    @pytest.mark.asyncio
    async def test_css_path_set(self) -> None:
        """The app must reference the external tcss stylesheet."""
        assert MorphismApp.CSS_PATH == "morphism.tcss"

    @pytest.mark.asyncio
    async def test_tool_names_precomputed(self) -> None:
        """_TOOL_NAMES should contain all registered tool keys."""
        assert set(_TOOL_NAMES) == set(TOOL_REGISTRY.keys())
