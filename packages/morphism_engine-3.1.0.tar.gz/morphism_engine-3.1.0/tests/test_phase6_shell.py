"""test_phase6_shell.py – Phase 6: Interactive REPL Shell integration tests.

Uses ``MorphismShell.onecmd()`` with captured stdout.
Requires a running Ollama instance; skipped otherwise.
"""

from __future__ import annotations

import io
import sys

import pytest
import requests

from morphism.cli.shell import MorphismShell
from morphism.utils.logger import setup_logging

setup_logging("DEBUG")


def _ollama_is_alive(base_url: str = "http://localhost:11434") -> bool:
    try:
        return requests.get(base_url, timeout=5).status_code == 200
    except Exception:
        return False


pytestmark = pytest.mark.skipif(
    not _ollama_is_alive(),
    reason="Ollama server not reachable at localhost:11434",
)


def _capture(shell: MorphismShell, command: str) -> str:
    """Run *command* through the shell, capturing stdout."""
    buf = io.StringIO()
    old = sys.stdout
    sys.stdout = buf
    try:
        shell.onecmd(command)
    finally:
        sys.stdout = old
    return buf.getvalue()


def test_repl_pipe_emit_render() -> None:
    shell = MorphismShell()
    captured = _capture(shell, "emit_raw | render_float")

    # The logger writes to its own handler (not stdout) so we check
    # the final rendered output which goes through sys.stdout.write().
    assert "[RENDERED UI]: 0.5" in captured, (
        f"Expected rendered output. Got:\n{captured}"
    )


def test_repl_unknown_command() -> None:
    shell = MorphismShell()
    captured = _capture(shell, "nonexistent_tool | render_float")
    assert "ERROR" in captured
    assert "nonexistent_tool" in captured


def test_repl_history_and_inspect() -> None:
    shell = MorphismShell()
    _capture(shell, "emit_raw | render_float")

    history_out = _capture(shell, "history")
    assert "emit_raw" in history_out
    assert "AI_Bridge_Functor" in history_out
    assert "render_float" in history_out

    inspect_out = _capture(shell, "inspect 2")
    assert "AI_Bridge_Functor" in inspect_out
    assert "0.5" in inspect_out
