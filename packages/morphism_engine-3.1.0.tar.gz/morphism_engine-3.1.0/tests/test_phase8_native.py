"""test_phase8_native.py – Phase 8: Native subprocess integration & schema inference.

Tests are split into three tiers:

1. **Pure-Python** – schema inference logic (no subprocess, no Ollama).
2. **Subprocess** – ``NativeCommandNode`` executing real OS commands.
3. **Pipeline** – end-to-end pipelines mixing native + registered nodes.
"""

from __future__ import annotations

import json
import sys
import textwrap

import pytest

from morphism.core.inference import infer_schema
from morphism.core.native_node import NativeCommandNode
from morphism.core.node import FunctorNode
from morphism.core.pipeline import MorphismPipeline
from morphism.core.schemas import (
    CSV_Data,
    Float_Normalized,
    Int_0_to_100,
    JSON_Object,
    Pending,
    Plaintext,
    String_NonEmpty,
)
from morphism.exceptions import EngineExecutionError, SchemaMismatchError


# ======================================================================
# Tier 1 – Schema Inference (pure Python)
# ======================================================================


class TestInferSchema:
    def test_json_object(self) -> None:
        data = json.dumps({"name": "morphism", "version": 2})
        assert infer_schema(data) == JSON_Object

    def test_json_array(self) -> None:
        data = json.dumps([1, 2, 3])
        assert infer_schema(data) == JSON_Object

    def test_json_with_whitespace(self) -> None:
        data = '  \n  {"key": "value"}  \n  '
        assert infer_schema(data) == JSON_Object

    def test_csv_data(self) -> None:
        data = "name,age,city\nAlice,30,NYC\nBob,25,LA\n"
        assert infer_schema(data) == CSV_Data

    def test_plaintext(self) -> None:
        data = "hello world"
        assert infer_schema(data) == Plaintext

    def test_multiline_plaintext(self) -> None:
        data = "line one\nline two\nline three\n"
        # Three lines without a clear CSV dialect → Plaintext
        assert infer_schema(data) == Plaintext

    def test_empty_string(self) -> None:
        assert infer_schema("") == Plaintext

    def test_whitespace_only(self) -> None:
        assert infer_schema("   \n\n  ") == Plaintext


# ======================================================================
# Tier 2 – NativeCommandNode (subprocess)
# ======================================================================


class TestNativeCommandNode:
    @pytest.mark.asyncio
    async def test_from_command_factory(self) -> None:
        node = NativeCommandNode.from_command("echo hello")
        assert node.input_schema == Pending
        assert node.output_schema == Pending
        assert node.cmd_string == "echo hello"
        assert node.name == "echo hello"

    @pytest.mark.asyncio
    async def test_echo_plaintext(self) -> None:
        node = NativeCommandNode.from_command("echo hello world")
        result = await node.execute(None)
        assert "hello world" in result
        assert node.output_schema == Plaintext

    @pytest.mark.asyncio
    async def test_python_json_output(self) -> None:
        """Use python -c to emit JSON and verify inference."""
        cmd = (
            f'{sys.executable} -c "'
            "import json; print(json.dumps({'name': 'morphism'}))"
            '"'
        )
        # Build a portable command
        cmd = (
            f"{sys.executable} -c "
            "\"import json; print(json.dumps({'name': 'morphism'}))\""
        )
        node = NativeCommandNode.from_command(cmd)
        result = await node.execute(None)
        assert node.output_schema == JSON_Object
        parsed = json.loads(result.strip())
        assert parsed["name"] == "morphism"

    @pytest.mark.asyncio
    async def test_type_json_file(self, tmp_path) -> None:
        """Read a JSON file with 'type' (Windows) and verify schema."""
        json_file = tmp_path / "test.json"
        json_file.write_text(
            json.dumps({"key": "value", "n": 42}), encoding="utf-8",
        )
        # Windows uses 'type'; Unix uses 'cat'
        if sys.platform == "win32":
            cmd = f'type "{json_file}"'
        else:
            cmd = f'cat "{json_file}"'
        node = NativeCommandNode.from_command(cmd)
        result = await node.execute(None)
        assert node.output_schema == JSON_Object
        assert "value" in result

    @pytest.mark.asyncio
    async def test_stdin_passthrough(self) -> None:
        """Data piped via stdin is available to the subprocess."""
        if sys.platform == "win32":
            cmd = "findstr /R ."  # pass-through all non-empty lines
        else:
            cmd = "cat"
        node = NativeCommandNode.from_command(cmd)
        result = await node.execute("hello from morphism")
        assert "hello from morphism" in result

    @pytest.mark.asyncio
    async def test_bad_command_raises(self) -> None:
        node = NativeCommandNode.from_command("__nonexistent_binary_xyz__")
        with pytest.raises(EngineExecutionError):
            await node.execute(None)


# ======================================================================
# Tier 3 – Pipeline integration
# ======================================================================


class TestPipelineNative:
    @pytest.mark.asyncio
    async def test_single_native_node(self) -> None:
        """A pipeline with one native node should execute and infer schema."""
        pipeline = MorphismPipeline()
        node = NativeCommandNode.from_command("echo integration-test")
        await pipeline.append(node)
        result = await pipeline.execute_all(None)
        assert "integration-test" in result
        assert node.output_schema == Plaintext

    @pytest.mark.asyncio
    async def test_two_native_nodes_plaintext(self) -> None:
        """Two native nodes producing Plaintext should chain without a bridge."""
        pipeline = MorphismPipeline()

        node1 = NativeCommandNode.from_command("echo chaining")
        if sys.platform == "win32":
            node2 = NativeCommandNode.from_command("findstr /R .")
        else:
            node2 = NativeCommandNode.from_command("cat")

        await pipeline.append(node1)
        await pipeline.append(node2)

        result = await pipeline.execute_all(None)
        assert "chaining" in result
        # Both should have resolved to Plaintext — no bridge needed
        assert node1.output_schema == Plaintext
        assert node2.input_schema == Plaintext

    @pytest.mark.asyncio
    async def test_pending_defers_at_append(self) -> None:
        """Appending a Pending-schema node after a concrete node should not
        raise SchemaMismatchError."""
        pipeline = MorphismPipeline()

        concrete = FunctorNode(
            input_schema=Int_0_to_100,
            output_schema=Int_0_to_100,
            executable=lambda x: 42,
            name="source",
        )
        native = NativeCommandNode.from_command("echo ok")

        await pipeline.append(concrete)
        # Should NOT raise even though Int_0_to_100 != Pending
        await pipeline.append(native)
        assert pipeline.length == 2

    @pytest.mark.asyncio
    async def test_runtime_mismatch_without_llm_raises(self) -> None:
        """Runtime schema mismatch without an LLM client should raise."""
        pipeline = MorphismPipeline()  # no llm_client

        native = NativeCommandNode.from_command("echo hello")
        registered = FunctorNode(
            input_schema=Float_Normalized,
            output_schema=String_NonEmpty,
            executable=lambda x: f"rendered: {x}",
            name="render",
        )

        await pipeline.append(native)
        await pipeline.append(registered)

        with pytest.raises(SchemaMismatchError, match="Runtime schema mismatch"):
            await pipeline.execute_all(None)

    @pytest.mark.asyncio
    async def test_native_json_inferred(self, tmp_path) -> None:
        """A native command producing JSON should have its schema inferred."""
        json_file = tmp_path / "sample.json"
        json_file.write_text(
            json.dumps({"status": "ok"}), encoding="utf-8",
        )
        if sys.platform == "win32":
            cmd = f'type "{json_file}"'
        else:
            cmd = f'cat "{json_file}"'

        pipeline = MorphismPipeline()
        node = NativeCommandNode.from_command(cmd)
        await pipeline.append(node)
        result = await pipeline.execute_all(None)

        assert node.output_schema == JSON_Object
        assert "ok" in result
