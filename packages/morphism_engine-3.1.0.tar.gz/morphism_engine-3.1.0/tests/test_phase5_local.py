"""test_phase5_local.py – Phase 5: Live Local LLM integration tests.

Requires a running Ollama instance with ``qwen2.5-coder:1.5b``.
Skipped automatically if Ollama is not reachable.
"""

from __future__ import annotations

import pytest
import requests

from morphism.core.schemas import Int_0_to_100, Float_Normalized
from morphism.core.node import FunctorNode
from morphism.core.pipeline import MorphismPipeline
from morphism.ai.synthesizer import OllamaSynthesizer


def _ollama_is_alive(base_url: str = "http://localhost:11434") -> bool:
    try:
        return requests.get(base_url, timeout=5).status_code == 200
    except Exception:
        return False


pytestmark = pytest.mark.skipif(
    not _ollama_is_alive(),
    reason="Ollama server not reachable at localhost:11434",
)


@pytest.mark.asyncio
async def test_live_local_healing() -> None:
    synthesizer = OllamaSynthesizer()
    pipeline = MorphismPipeline(llm_client=synthesizer)

    node_1 = FunctorNode(
        input_schema=Int_0_to_100,
        output_schema=Int_0_to_100,
        executable=lambda x: x,
        name="source_int",
    )
    node_2 = FunctorNode(
        input_schema=Float_Normalized,
        output_schema=Float_Normalized,
        executable=lambda x: x,
        name="sink_float",
    )

    assert await pipeline.append(node_1) is True
    assert await pipeline.append(node_2) is True
    assert pipeline.length == 3

    bridge = node_1.children[0]
    assert bridge is not None
    assert bridge.name == "AI_Bridge_Functor"

    result = await pipeline.execute_all(50)
    assert result == pytest.approx(0.5, abs=1e-6)
