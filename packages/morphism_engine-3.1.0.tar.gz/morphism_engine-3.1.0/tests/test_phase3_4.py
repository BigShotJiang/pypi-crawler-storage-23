"""test_phase3_4.py – Phases 3 & 4: Mock LLM self-healing pipeline + Z3 rejection."""

from __future__ import annotations

import pytest

from morphism.core.schemas import Int_0_to_100, Float_Normalized, Int_0_to_10
from morphism.core.node import FunctorNode
from morphism.core.pipeline import MorphismPipeline
from morphism.ai.synthesizer import MockLLMSynthesizer
from morphism.exceptions import VerificationFailedError


@pytest.mark.asyncio
async def test_self_healing_pipe() -> None:
    pipeline = MorphismPipeline(llm_client=MockLLMSynthesizer())

    node_1 = FunctorNode(
        input_schema=Int_0_to_100,
        output_schema=Int_0_to_100,
        executable=lambda x: x,
        name="source_int",
    )
    node_2 = FunctorNode(
        input_schema=Float_Normalized,
        output_schema=Float_Normalized,
        executable=lambda x: x,
        name="sink_float",
    )

    assert await pipeline.append(node_1) is True
    assert await pipeline.append(node_2) is True

    assert pipeline.length == 3
    bridge = node_1.children[0]
    assert bridge is not None
    assert bridge.name == "AI_Bridge_Functor"
    assert bridge.input_schema == Int_0_to_100
    assert bridge.output_schema == Float_Normalized
    assert bridge.children[0] is node_2
    assert node_2.parents[0] is bridge

    result = await pipeline.execute_all(50)
    assert result == 0.5


@pytest.mark.asyncio
async def test_unsafe_hallucination_blocked() -> None:
    pipeline = MorphismPipeline(llm_client=MockLLMSynthesizer())

    node_1 = FunctorNode(
        input_schema=Int_0_to_100,
        output_schema=Int_0_to_100,
        executable=lambda x: x,
        name="source_int",
    )
    node_bad = FunctorNode(
        input_schema=Int_0_to_10,
        output_schema=Int_0_to_10,
        executable=lambda x: x,
        name="sink_int_0_10",
    )

    await pipeline.append(node_1)

    with pytest.raises(VerificationFailedError):
        await pipeline.append(node_bad)

    assert pipeline.length == 1
    assert pipeline.tail is node_1
    assert len(node_1.children) == 0
