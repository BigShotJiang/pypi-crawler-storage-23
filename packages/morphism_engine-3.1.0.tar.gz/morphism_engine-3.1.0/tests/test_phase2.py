"""test_phase2.py – Phase 2: Z3 formal verification of functor mappings."""

from __future__ import annotations

from morphism.core.schemas import Int_0_to_100, Float_Normalized
from morphism.math.z3_verifier import verify_functor_mapping


def test_valid_functor_mapping() -> None:
    result = verify_functor_mapping(
        source_schema=Int_0_to_100,
        target_schema=Float_Normalized,
        transformation_logic=lambda x: x / 100.0,
    )
    assert result is True


def test_invalid_functor_mapping() -> None:
    result = verify_functor_mapping(
        source_schema=Int_0_to_100,
        target_schema=Float_Normalized,
        transformation_logic=lambda x: x / 50.0,
    )
    assert result is False
