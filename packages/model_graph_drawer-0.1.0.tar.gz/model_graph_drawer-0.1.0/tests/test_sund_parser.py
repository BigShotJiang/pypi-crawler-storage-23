"""Tests for the sund model file parser."""
from pathlib import Path

import pytest

from model_graph_drawer.sund_parser import parse_sund_text, parse_sund_file

# ---------------------------------------------------------------------------
# Minimal inline model for fast unit tests
# ---------------------------------------------------------------------------

MINIMAL_TEXT = """\
########## STATES
d/dt(R)  = r2-r1
d/dt(Rp) = r1-r2
d/dt(A)  = 0

R(0)  = 1.0
Rp(0) = 0.0
A(0)  = 0.0
########## VARIABLES
r1 = R*A*k1
r2 = Rp*k2
########## INPUTS
A = stimulus @ 0
########## OUTPUTS
Rp_out = Rp
########## FEATURES
Rp = Rp
"""


# ---------------------------------------------------------------------------
# Species / states
# ---------------------------------------------------------------------------

def test_states_are_species():
    result = parse_sund_text(MINIMAL_TEXT)
    assert {"R", "Rp", "A"} == result.species


def test_constant_state_included():
    """d/dt(A) = 0 — A must still be in the species set."""
    result = parse_sund_text(MINIMAL_TEXT)
    assert "A" in result.species


# ---------------------------------------------------------------------------
# Stoichiometry
# ---------------------------------------------------------------------------

def test_r1_stoichiometry():
    result = parse_sund_text(MINIMAL_TEXT)
    r1 = next(r for r in result.reactions if r.id == "r1")
    assert r1.reactants == ["R"]
    assert r1.products == ["Rp"]


def test_r2_stoichiometry():
    result = parse_sund_text(MINIMAL_TEXT)
    r2 = next(r for r in result.reactions if r.id == "r2")
    assert r2.reactants == ["Rp"]
    assert r2.products == ["R"]


def test_reaction_count():
    result = parse_sund_text(MINIMAL_TEXT)
    assert len(result.reactions) == 2


# ---------------------------------------------------------------------------
# Inputs / Outputs / Features
# ---------------------------------------------------------------------------

def test_inputs_parsed():
    result = parse_sund_text(MINIMAL_TEXT)
    assert result.inputs == {"A"}


def test_outputs_parsed():
    result = parse_sund_text(MINIMAL_TEXT)
    assert result.outputs == {"Rp"}


def test_features_parsed():
    result = parse_sund_text(MINIMAL_TEXT)
    assert result.features == {"Rp"}


def test_empty_sections_return_empty_sets():
    text = """\
########## STATES
d/dt(X) = r1
########## VARIABLES
r1 = k*X
"""
    result = parse_sund_text(text)
    assert result.inputs == set()
    assert result.outputs == set()
    assert result.features == set()


# ---------------------------------------------------------------------------
# File-based smoke tests (require sund_model_example/ to exist)
# ---------------------------------------------------------------------------

M1_PATH = Path("examples/sund_model_example/M1.txt")
M2_PATH = Path("examples/sund_model_example/M2.txt")


@pytest.mark.skipif(not M1_PATH.exists(), reason="M1.txt not found")
def test_m1_species():
    result = parse_sund_file(M1_PATH)
    assert {"R", "Rp", "S", "Sp", "A"} == result.species


@pytest.mark.skipif(not M1_PATH.exists(), reason="M1.txt not found")
def test_m1_inputs():
    result = parse_sund_file(M1_PATH)
    assert "A" in result.inputs


@pytest.mark.skipif(not M1_PATH.exists(), reason="M1.txt not found")
def test_m1_outputs():
    result = parse_sund_file(M1_PATH)
    assert "Sp" in result.outputs


@pytest.mark.skipif(not M1_PATH.exists(), reason="M1.txt not found")
def test_m1_features():
    result = parse_sund_file(M1_PATH)
    assert "Rp" in result.features


@pytest.mark.skipif(not M2_PATH.exists(), reason="M2.txt not found")
def test_m2_a_consumed():
    """In M2, d/dt(A) = -r3, so A is a reactant of r3."""
    result = parse_sund_file(M2_PATH)
    r3 = next(r for r in result.reactions if r.id == "r3")
    assert "A" in r3.reactants
