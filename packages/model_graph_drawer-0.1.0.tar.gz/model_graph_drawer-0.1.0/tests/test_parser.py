"""Tests for the reaction string parser."""
import pytest
from model_graph_drawer.parser import parse_reaction, parse_text


# ---------------------------------------------------------------------------
# parse_reaction
# ---------------------------------------------------------------------------

def test_source_reaction():
    r = parse_reaction("-> A : k1", "r1")
    assert r.id == "r1"
    assert r.reactants == []
    assert r.products == ["A"]
    assert r.rate == "k1"


def test_sink_reaction():
    r = parse_reaction("C -> : k4*C", "r4")
    assert r.id == "r4"
    assert r.reactants == ["C"]
    assert r.products == []
    assert r.rate == "k4*C"


def test_basic_reaction():
    r = parse_reaction("A -> B : k2*A*C", "r2")
    assert r.id == "r2"
    assert r.reactants == ["A"]
    assert r.products == ["B"]
    assert r.rate == "k2*A*C"


def test_named_rate_overrides_id():
    r = parse_reaction("A -> B : v2=k2*A*C", "r1")
    assert r.id == "v2"
    assert r.reactants == ["A"]
    assert r.products == ["B"]
    assert r.rate == "k2*A*C"


def test_named_rate_with_spaces():
    r = parse_reaction("A -> B : v1 = k1*A", "r1")
    assert r.id == "v1"
    assert r.rate == "k1*A"


def test_multi_reactant_product():
    r = parse_reaction("A + B -> C + D : k*A*B", "r1")
    assert r.reactants == ["A", "B"]
    assert r.products == ["C", "D"]
    assert r.rate == "k*A*B"


def test_no_rate():
    r = parse_reaction("A -> B", "r1")
    assert r.reactants == ["A"]
    assert r.products == ["B"]
    assert r.rate == ""


def test_missing_arrow_raises():
    with pytest.raises(ValueError, match="->"):
        parse_reaction("A : k1", "r1")


# ---------------------------------------------------------------------------
# parse_text
# ---------------------------------------------------------------------------

def test_parse_text_basic():
    reactions = parse_text("-> A : k1\nA -> B : k2*A\nB -> : k3*B")
    assert len(reactions) == 3
    assert reactions[0].products == ["A"]
    assert reactions[1].reactants == ["A"]
    assert reactions[2].reactants == ["B"]


def test_parse_text_skips_blank_and_comments():
    text = """
    # synthesis
    -> A : k1

    # degradation
    A -> : k2*A
    """
    reactions = parse_text(text)
    assert len(reactions) == 2


def test_parse_text_auto_ids():
    reactions = parse_text("A -> B : k1\nB -> C : k2")
    assert reactions[0].id == "r1"
    assert reactions[1].id == "r2"


def test_parse_text_named_ids():
    reactions = parse_text("A -> B : v1=k1*A\nB -> C : v2=k2*B")
    assert reactions[0].id == "v1"
    assert reactions[1].id == "v2"
