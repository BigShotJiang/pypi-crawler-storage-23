"""Tests for Model construction and modifier detection."""
from pathlib import Path

import pytest

from model_graph_drawer import Model
from model_graph_drawer.model import Reaction


# ---------------------------------------------------------------------------
# from_reactions / from_text
# ---------------------------------------------------------------------------

def test_from_reactions_species():
    model = Model.from_reactions(["A -> B : k1", "B -> C : k2"])
    assert model.species == {"A", "B", "C"}


def test_from_reactions_named_rate_ids():
    model = Model.from_reactions([
        "-> A   : s1=k1",
        "A -> B : v2=k2*A*C",
        "B -> C : v3=k3*B",
        "C ->   : d4=k4*C",
    ])
    ids = {r.id for r in model.reactions}
    assert ids == {"s1", "v2", "v3", "d4"}


def test_modifier_detection():
    """C appears in k2*A*C but is not a reactant → C is a modifier of r2."""
    model = Model.from_reactions([
        "-> A   : k1",
        "A -> B : v2=k2*A*C",
        "B -> C : v3=k3*B",
        "C ->   : k4*C",
    ])
    v2 = next(r for r in model.reactions if r.id == "v2")
    assert "C" in v2.modifiers
    assert "A" not in v2.modifiers   # reactant, not modifier


def test_no_spurious_modifiers():
    """k2 is a parameter, not a species — must not appear as modifier."""
    model = Model.from_reactions(["A -> B : k2*A"])
    r = model.reactions[0]
    assert r.modifiers == []


def test_from_text_skips_comments():
    model = Model.from_text("""
        # ignored
        A -> B : k1
        B -> C : k2
    """)
    assert len(model.reactions) == 2


# ---------------------------------------------------------------------------
# inputs / outputs / features defaults
# ---------------------------------------------------------------------------

def test_no_inputs_by_default():
    model = Model.from_reactions(["A -> B : k1"])
    assert model.inputs == set()
    assert model.outputs == set()
    assert model.features == set()


def test_inputs_added_to_species():
    """Inputs not in species set must be merged in so they appear in the graph."""
    model = Model(
        reactions=[Reaction(id="r1", reactants=["R"], products=["Rp"], rate="R*U*k1")],
        species={"R", "Rp"},
        inputs={"U"},
    )
    assert "U" in model.species


def test_input_detected_as_modifier():
    """Once added to species, an input that appears in a rate is a modifier."""
    model = Model(
        reactions=[Reaction(id="r1", reactants=["R"], products=["Rp"], rate="R*U*k1")],
        species={"R", "Rp"},
        inputs={"U"},
    )
    r1 = model.reactions[0]
    assert "U" in r1.modifiers


# ---------------------------------------------------------------------------
# from_sund (file-based)
# ---------------------------------------------------------------------------

M1_PATH = Path("examples/sund_model_example/M1.txt")
M2_PATH = Path("examples/sund_model_example/M2.txt")


@pytest.mark.skipif(not M1_PATH.exists(), reason="M1.txt not found")
def test_from_sund_species():
    model = Model.from_sund(M1_PATH)
    assert {"R", "Rp", "S", "Sp", "A"} == model.species


@pytest.mark.skipif(not M1_PATH.exists(), reason="M1.txt not found")
def test_from_sund_inputs():
    model = Model.from_sund(M1_PATH)
    assert "A" in model.inputs


@pytest.mark.skipif(not M1_PATH.exists(), reason="M1.txt not found")
def test_from_sund_outputs():
    model = Model.from_sund(M1_PATH)
    assert "Sp" in model.outputs


@pytest.mark.skipif(not M1_PATH.exists(), reason="M1.txt not found")
def test_from_sund_features():
    model = Model.from_sund(M1_PATH)
    assert "Rp" in model.features


@pytest.mark.skipif(not M1_PATH.exists(), reason="M1.txt not found")
def test_from_sund_a_is_modifier():
    """A is an input that appears in r1 = R*A*k1 — must be detected as modifier."""
    model = Model.from_sund(M1_PATH)
    r1 = next(r for r in model.reactions if r.id == "r1")
    assert "A" in r1.modifiers


@pytest.mark.skipif(not M2_PATH.exists(), reason="M2.txt not found")
def test_m2_reaction_count():
    model = Model.from_sund(M2_PATH)
    assert len(model.reactions) == 5
