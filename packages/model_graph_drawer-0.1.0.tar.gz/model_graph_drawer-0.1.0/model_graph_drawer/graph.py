from __future__ import annotations

import re
from collections import defaultdict

import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.lines import Line2D

from .model import Model

# Render SVG text as editable strings rather than paths.
plt.rcParams["svg.fonttype"] = "none"


# ---------------------------------------------------------------------------
# Colors / style constants
# ---------------------------------------------------------------------------
_FLOW_COLOR    = "#1A252F"
_MOD_COLOR     = "#C0392B"
_INPUT_COLOR   = "#1E8449"   # green  — external input signals
_OUTPUT_COLOR  = "#D35400"   # orange — species exposed to other models
_FEATURE_BG    = "#FEF9E7"   # pale yellow background — observable features

# Arrow shrink in points — keeps arrow endpoints clear of the species text
_SPECIES_SHRINK = 15

# Kept for build_graph backward compatibility
_SPECIES_COLOR  = "#AED6F1"
_SPECIES_EDGE   = "#2471A3"
_REACTION_COLOR = "#F9E4B7"
_REACTION_EDGE  = "#784212"
_SPECIES_SIZE   = 2500
_REACTION_SIZE  = 400


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def build_graph(model: Model) -> nx.DiGraph:
    """Return a directed NetworkX graph with explicit reaction nodes.

    Useful for programmatic graph analysis.  The :func:`draw` function
    visualises the same information without explicit reaction nodes.

    Node attributes
    ---------------
    node_type : ``'species'`` or ``'reaction'``

    Edge attributes
    ---------------
    edge_type : ``'consumption'``, ``'production'``, or ``'modifier'``
    """
    G = nx.DiGraph()
    for species in sorted(model.species):
        G.add_node(species, node_type="species", size=_SPECIES_SIZE)
    for rxn in model.reactions:
        G.add_node(rxn.id, node_type="reaction", size=_REACTION_SIZE)
        for reactant in rxn.reactants:
            G.add_edge(reactant, rxn.id, edge_type="consumption")
        for product in rxn.products:
            G.add_edge(rxn.id, product, edge_type="production")
        for modifier in rxn.modifiers:
            G.add_edge(modifier, rxn.id, edge_type="modifier")
    return G


def draw(
    model: Model,
    *,
    ax: plt.Axes | None = None,
    figsize: tuple[float, float] = (10, 7),
    layout: str = "kamada_kawai",
    title: str | None = None,
) -> plt.Axes:
    """Draw the interaction graph for *model*.

    Species are shown as bold text labels.  Each reaction is a direct solid
    arrow between species, labelled with its rate constant(s).  Modifier
    arrows (dashed red) curve from the modifier species to the midpoint of
    the reaction they regulate and end with a ``+`` marker.

    Parameters
    ----------
    model : Model
    ax : optional Axes — created automatically when ``None``
    figsize : (width, height) in inches; used only when *ax* is ``None``
    layout : ``'kamada_kawai'`` *(default)*, ``'spring'``, ``'spectral'``, ``'circular'``
    title : optional plot title

    Returns
    -------
    plt.Axes

    Examples
    --------
    >>> model = Model.from_reactions([
    ...     "-> A : k1", "A -> B: k2*A*C", "B -> C: k3*B", "C ->: k4*C"])
    >>> draw(model, title="A→B→C with C as modifier")
    """
    created_fig = ax is None
    if created_fig:
        _, ax = plt.subplots(figsize=figsize)

    pos = _species_layout(model, layout)
    arc_radii = _assign_arc_radii(model)

    # Draw flow arrows; collect arc geometry for each reaction
    # Each entry: (target_point, src_pos_or_None, dst_pos_or_None, arc_rad)
    rxn_geoms: dict[str, tuple] = {}
    for rxn in model.reactions:
        geom = _draw_reaction(ax, rxn, pos, arc_radii, model.species)
        if geom is not None:
            rxn_geoms[rxn.id] = geom

    # Draw modifier arrows, curving away from the reaction arc they target
    for rxn in model.reactions:
        if not rxn.modifiers:
            continue
        geom = rxn_geoms.get(rxn.id)
        if geom is None:
            continue
        target, rxn_src_p, rxn_dst_p, rxn_rad = geom
        for mod in rxn.modifiers:
            if mod in pos:
                mod_rad = _modifier_arc_rad(pos[mod], target, rxn_src_p, rxn_dst_p, rxn_rad)
                _draw_modifier_arrow(ax, pos[mod], target, rad=mod_rad)

    # Species labels drawn last (on top of arrows)
    for sp, p in pos.items():
        bbox = _species_bbox(sp, model.inputs, model.outputs, model.features)
        kw = dict(ha="center", va="center",
                  fontsize=16, fontweight="bold", color="black", zorder=10)
        if bbox is not None:
            kw["bbox"] = bbox
        ax.text(p[0], p[1], sp, **kw)

    # Axis limits
    xs = [p[0] for p in pos.values()]
    ys = [p[1] for p in pos.values()]
    margin = 1.8
    ax.set_xlim(min(xs) - margin, max(xs) + margin)
    ax.set_ylim(min(ys) - margin, max(ys) + margin)
    ax.set_aspect("equal", adjustable="box")
    ax.axis("off")

    # Legend
    has_mods = any(rxn.modifiers for rxn in model.reactions)
    handles = [
        Line2D([0], [0], color=_FLOW_COLOR, lw=2, label="Reaction"),
    ]
    if has_mods:
        handles.append(
            Line2D([0], [0], color=_MOD_COLOR, lw=1.5, linestyle="dashed",
                   label="Modifier  (+)")
        )
    if model.inputs:
        handles.append(mpatches.Patch(
            facecolor="white", edgecolor=_INPUT_COLOR,
            linestyle="dashed", linewidth=1.5, label="Input"))
    if model.outputs:
        handles.append(mpatches.Patch(
            facecolor="white", edgecolor=_OUTPUT_COLOR,
            linestyle="solid", linewidth=2.0, label="Output"))
    if model.features:
        handles.append(mpatches.Patch(
            facecolor=_FEATURE_BG, edgecolor="#888", linewidth=0.8,
            label="Feature"))
    ax.legend(handles=handles, loc="best", framealpha=0.9, fontsize=10)

    if title:
        ax.set_title(title, fontsize=14, fontweight="bold", pad=15)

    if created_fig:
        plt.tight_layout()

    return ax


# ---------------------------------------------------------------------------
# Species label styling
# ---------------------------------------------------------------------------

def _species_bbox(
    sp: str,
    inputs: set[str],
    outputs: set[str],
    features: set[str],
) -> dict | None:
    """Return a matplotlib ``bbox`` dict for a species label, or ``None``."""
    is_input   = sp in inputs
    is_output  = sp in outputs
    is_feature = sp in features

    if not (is_input or is_output or is_feature):
        return None

    bbox: dict = {"pad": 4, "boxstyle": "round,pad=0.3"}
    bbox["facecolor"] = _FEATURE_BG if is_feature else "white"

    if is_input:
        bbox["edgecolor"] = _INPUT_COLOR
        bbox["linestyle"] = "dashed"
        bbox["linewidth"] = 1.5
    elif is_output:
        bbox["edgecolor"] = _OUTPUT_COLOR
        bbox["linestyle"] = "solid"
        bbox["linewidth"] = 2.0
    else:
        bbox["edgecolor"] = "#AAAAAA"
        bbox["linewidth"] = 0.8

    return bbox


# ---------------------------------------------------------------------------
# Reaction drawing
# ---------------------------------------------------------------------------

def _draw_reaction(
    ax: plt.Axes,
    rxn,
    pos: dict[str, np.ndarray],
    arc_radii: dict[str, float],
    species_set: set[str],
) -> tuple | None:
    """Draw flow arrow(s) for *rxn*.

    Returns ``(target, src, dst, rad)`` where *src* and *dst* are the species
    positions used for the arc (``None`` for source / sink / complex reactions)
    and *rad* is the arc curvature.  The tuple is used by the caller to choose
    the correct curvature for modifier arrows.
    """
    n_r, n_p = len(rxn.reactants), len(rxn.products)
    rad   = arc_radii.get(rxn.id, 0.0)
    label = _rate_label(rxn, species_set)

    if n_r == 1 and n_p == 1:
        src = pos[rxn.reactants[0]]
        dst = pos[rxn.products[0]]
        _flow_arrow(ax, src, dst, rad)
        _arc_label(ax, src, dst, rad, label)
        return _arc_midpoint(src, dst, rad), src, dst, rad

    elif n_r == 0 and n_p == 1:          # source  →  A
        dst = pos[rxn.products[0]]
        src = _virtual_point(dst, pos)
        _flow_arrow(ax, src, dst, 0.0,
                    shrink_src=0, shrink_dst=_SPECIES_SHRINK)
        _arc_label(ax, src, dst, 0.0, label)
        return _arc_midpoint(src, dst, 0.0), None, None, 0.0

    elif n_r == 1 and n_p == 0:          # A  →  sink
        src = pos[rxn.reactants[0]]
        dst = _virtual_point(src, pos)
        _flow_arrow(ax, src, dst, 0.0,
                    shrink_src=_SPECIES_SHRINK, shrink_dst=0)
        _arc_label(ax, src, dst, 0.0, label)
        return _arc_midpoint(src, dst, 0.0), None, None, 0.0

    else:                                # complex: small dot at centroid
        involved = [s for s in rxn.reactants + rxn.products if s in pos]
        if not involved:
            return None
        centroid = np.mean([pos[s] for s in involved], axis=0)
        for r in rxn.reactants:
            if r in pos:
                _flow_arrow(ax, pos[r], centroid, 0.0,
                            shrink_src=_SPECIES_SHRINK, shrink_dst=0)
        for p in rxn.products:
            if p in pos:
                _flow_arrow(ax, centroid, pos[p], 0.0,
                            shrink_src=0, shrink_dst=_SPECIES_SHRINK)
        ax.plot(*centroid, "o", color="#555555", markersize=7, zorder=3)
        if label:
            ax.text(centroid[0], centroid[1] + 0.3, label,
                    ha="center", va="bottom", fontsize=9, color="#444",
                    bbox=dict(facecolor="white", edgecolor="none", alpha=0.6, pad=1.5),
                    zorder=6)
        return centroid, None, None, 0.0


def _flow_arrow(
    ax: plt.Axes,
    src: np.ndarray,
    dst: np.ndarray,
    rad: float,
    shrink_src: float = _SPECIES_SHRINK,
    shrink_dst: float = _SPECIES_SHRINK,
) -> None:
    ax.annotate(
        "", xy=tuple(dst), xytext=tuple(src),
        arrowprops=dict(
            arrowstyle="-|>",
            color=_FLOW_COLOR,
            lw=2.0,
            connectionstyle=f"arc3,rad={rad}",
            mutation_scale=15,
            shrinkA=shrink_src,
            shrinkB=shrink_dst,
        ),
        zorder=2,
    )


def _modifier_arc_rad(
    mod_pos: np.ndarray,
    target: np.ndarray,
    rxn_src: np.ndarray | None,
    rxn_dst: np.ndarray | None,
    rxn_rad: float,
    base: float = 0.35,
) -> float:
    """Choose modifier arc curvature to approach the reaction from the outside.

    Determines which side of the straight ``src→dst`` line the modifier species
    sits on, then chooses the curvature sign that bows the modifier arc TOWARD
    that side (away from the reaction).  Works for both straight (rad=0) and
    curved reactions.
    """
    if rxn_src is None or rxn_dst is None:
        return base

    rxn_d = np.array(rxn_dst) - np.array(rxn_src)
    rxn_perp = np.array([-rxn_d[1], rxn_d[0]])
    rxn_norm = np.linalg.norm(rxn_perp)
    if rxn_norm < 1e-10:
        return base
    rxn_perp_unit = rxn_perp / rxn_norm

    # Which side of the reaction line is the modifier on?
    rxn_mid = (np.array(rxn_src) + np.array(rxn_dst)) / 2.0
    side = np.dot(rxn_perp_unit, np.array(mod_pos) - rxn_mid)
    if abs(side) < 1e-10:
        return base  # modifier on the line — no geometric preference

    desired_dir = rxn_perp_unit * np.sign(side)   # direction toward the modifier

    # Left-perpendicular of the modifier arrow direction
    mod_d = np.array(target) - np.array(mod_pos)
    mod_perp = np.array([-mod_d[1], mod_d[0]])
    mod_norm = np.linalg.norm(mod_perp)
    if mod_norm < 1e-10:
        return base
    mod_left = mod_perp / mod_norm

    # Bow the arc toward the modifier's side
    return base if np.dot(desired_dir, mod_left) >= 0 else -base


def _draw_modifier_arrow(ax: plt.Axes, src: np.ndarray, target: np.ndarray, rad: float = 0.35) -> None:
    """Dashed curved arrow from modifier species to reaction midpoint, with + at tip."""
    ax.annotate(
        "", xy=tuple(target), xytext=tuple(src),
        arrowprops=dict(
            arrowstyle="-|>",
            color=_MOD_COLOR,
            lw=1.5,
            connectionstyle=f"arc3,rad={rad}",
            mutation_scale=12,
            linestyle="dashed",
            shrinkA=_SPECIES_SHRINK,
            shrinkB=0,
        ),
        zorder=4,
    )
    # "+" marker at the arrowhead
    ax.text(target[0], target[1], "+",
            ha="center", va="center",
            fontsize=13, fontweight="bold", color=_MOD_COLOR,
            bbox=dict(facecolor="white", edgecolor="none", alpha=0.9, pad=1.5),
            zorder=5)


def _arc_label(
    ax: plt.Axes, src, dst, rad: float, label: str
) -> None:
    """Place the rate label outside the arc (perpendicular offset beyond the arc peak)."""
    if not label:
        return
    src = np.array(src)
    dst = np.array(dst)
    mid  = (src + dst) / 2.0
    d    = dst - src
    perp = np.array([-d[1], d[0]])
    norm = np.linalg.norm(perp)
    if norm > 1e-10:
        perp /= norm
    # Arc peak height + a fixed extra offset so label clears the arrow body
    label_pos = mid + perp * (rad * np.linalg.norm(d) * 0.5 + 0.35)
    ax.text(label_pos[0], label_pos[1], label,
            ha="center", va="center",
            fontsize=9, color="#333",
            bbox=dict(facecolor="white", edgecolor="none", alpha=0.7, pad=2),
            zorder=6)


# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------

def _arc_midpoint(src: np.ndarray, dst: np.ndarray, rad: float) -> np.ndarray:
    """Approximate midpoint of a matplotlib arc3 arc."""
    mid  = (src + dst) / 2.0
    d    = dst - src
    perp = np.array([-d[1], d[0]])
    norm = np.linalg.norm(perp)
    if norm > 1e-10:
        perp /= norm
    return mid + perp * (rad * np.linalg.norm(d) * 0.5)


def _virtual_point(
    species_pos: np.ndarray, pos: dict, distance: float = 1.0
) -> np.ndarray:
    """A point outside the graph in the direction away from the centroid."""
    centroid  = np.mean(list(pos.values()), axis=0)
    d         = np.array(species_pos) - centroid
    norm      = np.linalg.norm(d)
    direction = d / norm if norm > 1e-10 else np.array([0.0, 1.0])
    return np.array(species_pos) + direction * distance


# ---------------------------------------------------------------------------
# Arc radius assignment (parallel / anti-parallel reactions)
# ---------------------------------------------------------------------------

def _assign_arc_radii(model: Model) -> dict[str, float]:
    """Assign arc curvatures so parallel and anti-parallel reactions are distinct.

    Anti-parallel reactions (A→B and B→A) automatically curve to opposite
    sides when both have the same positive ``rad`` value, because the
    perpendicular direction flips with the direction of travel.

    Multiple same-direction reactions get increasing radii so they fan out.
    """
    directed: dict[tuple, list[str]] = defaultdict(list)
    for rxn in model.reactions:
        if len(rxn.reactants) == 1 and len(rxn.products) == 1:
            directed[(rxn.reactants[0], rxn.products[0])].append(rxn.id)

    radii: dict[str, float] = {}
    processed: set = set()

    for (a, b), ids_ab in directed.items():
        if (a, b) in processed:
            continue
        ids_ba = directed.get((b, a), [])
        processed.add((a, b))
        processed.add((b, a))

        has_anti = bool(ids_ba)
        # Start curving if there are parallel or anti-parallel reactions
        base = 0.15 if (has_anti or len(ids_ab) > 1) else 0.0
        step = 0.25

        for i, rxn_id in enumerate(ids_ab):
            radii[rxn_id] = base + i * step
        for i, rxn_id in enumerate(ids_ba):
            radii[rxn_id] = base + i * step   # opposite side automatically

    return radii


# ---------------------------------------------------------------------------
# Species-only layout
# ---------------------------------------------------------------------------

def _species_layout(model: Model, layout: str) -> dict[str, np.ndarray]:
    """Compute 2-D positions for species, normalised to a [1, 9]² box."""
    G = nx.Graph()
    for s in sorted(model.species):
        G.add_node(s)
    # Connect species that share a reaction (including modifiers) for layout purposes
    for rxn in model.reactions:
        connected = rxn.reactants + rxn.products + rxn.modifiers
        for i, a in enumerate(connected):
            for b in connected[i + 1:]:
                if a in G and b in G:
                    G.add_edge(a, b)

    try:
        if layout == "kamada_kawai":
            raw = nx.kamada_kawai_layout(G)
        elif layout == "spring":
            raw = nx.spring_layout(G, seed=42, k=2.0)
        elif layout == "spectral":
            raw = nx.spectral_layout(G)
        elif layout == "circular":
            raw = nx.circular_layout(G)
        else:
            raise ValueError(f"Unknown layout {layout!r}")
    except Exception:
        raw = nx.spring_layout(G, seed=42)

    vals = np.array(list(raw.values()))
    mn   = vals.min(axis=0)
    mx   = vals.max(axis=0)
    rng  = np.maximum(mx - mn, 1e-3)
    scale = 8.0 / rng.max()

    return {
        k: np.array([(v[0] - mn[0]) * scale + 1,
                     (v[1] - mn[1]) * scale + 1])
        for k, v in raw.items()
    }


# ---------------------------------------------------------------------------
# Rate label extraction
# ---------------------------------------------------------------------------

def _rate_label(rxn, species_set: set[str]) -> str:
    """Return the rate parameter name(s): identifiers in the rate that are not species."""
    if not rxn.rate:
        return ""
    ids = re.findall(r'\b([a-zA-Z_]\w*)\b', rxn.rate)
    seen: set[str] = set()
    params: list[str] = []
    for x in ids:
        if x not in species_set and x not in seen:
            seen.add(x)
            params.append(x)
    return " · ".join(params) if params else ""
