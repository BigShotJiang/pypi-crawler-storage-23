from __future__ import annotations

import re

from .model import Reaction

# Matches an optional reaction name prefix in the rate part: "v1 = ..."
_NAMED_RATE_RE = re.compile(r'^([a-zA-Z_]\w*)\s*=\s*(.+)$')


def parse_reaction(line: str, reaction_id: str) -> Reaction:
    """Parse a single reaction string into a :class:`Reaction`.

    Format::

        [reactants] -> [products] [: [name =] rate]

    Reactants and products are ``+``-separated species names.  Either side
    may be empty (source / sink reactions).  The rate part (after ``:``) may
    optionally start with a reaction name followed by ``=``; when present the
    name overrides the auto-generated *reaction_id*.

    Examples
    --------
    >>> parse_reaction("-> A : k1", "r1")
    Reaction(id='r1', reactants=[], products=['A'], rate='k1', ...)

    >>> parse_reaction("A -> B : k2*A*C", "r2")
    Reaction(id='r2', reactants=['A'], products=['B'], rate='k2*A*C', ...)

    >>> parse_reaction("A -> B : v2=k2*A*C", "r2")
    Reaction(id='v2', reactants=['A'], products=['B'], rate='k2*A*C', ...)

    >>> parse_reaction("A + B -> C + D: k*A*B", "r3")
    Reaction(id='r3', reactants=['A', 'B'], products=['C', 'D'], rate='k*A*B', ...)
    """
    line = line.strip()

    # Separate stoichiometry from rate expression
    if ":" in line:
        stoich_part, rate = line.split(":", 1)
        rate = rate.strip()
    else:
        stoich_part = line
        rate = ""

    if "->" not in stoich_part:
        raise ValueError(
            f"Invalid reaction (missing '->'): {line!r}"
        )

    left, right = stoich_part.split("->", 1)

    # Optional named rate: "v1 = k1*A"  →  id='v1', rate='k1*A'
    m = _NAMED_RATE_RE.match(rate)
    if m:
        reaction_id = m.group(1)
        rate = m.group(2).strip()

    return Reaction(
        id=reaction_id,
        reactants=_parse_species_list(left),
        products=_parse_species_list(right),
        rate=rate,
    )


def parse_text(text: str) -> list[Reaction]:
    """Parse a multi-line text block into a list of :class:`Reaction` objects.

    Empty lines and lines starting with ``#`` are ignored.

    Parameters
    ----------
    text:
        One reaction per line, e.g.::

            -> A : k1
            A -> B: k2*A*C
            B -> C: k3*B
            C ->: k4*C
    """
    reactions: list[Reaction] = []
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        reaction_id = f"r{len(reactions) + 1}"
        reactions.append(parse_reaction(stripped, reaction_id))
    return reactions


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _parse_species_list(text: str) -> list[str]:
    """Split a ``+``-separated species list, stripping whitespace."""
    return [part.strip() for part in text.split("+") if part.strip()]
