"""Parser for the sund model file format.

A sund file is divided into named sections separated by lines of the form::

    ########## SECTION_NAME

The sections used here are STATES, PARAMETERS, VARIABLES, INPUTS, OUTPUTS,
and FEATURES.

STATES
------
Each line is either a differential equation::

    d/dt(species) = [signed sum of reaction variables]

or an initial condition (ignored here)::

    species(0) = value

The signed sum encodes stoichiometry: a reaction variable with a ``+`` sign
produces the species, ``-`` means it consumes it.

VARIABLES
---------
Named intermediate values – used here as reaction definitions::

    r1 = R*A*k1

Only variables that appear in at least one d/dt expression are treated as
reactions.

PARAMETERS
----------
Scalar constants (``k1 = 1.0``).  Collected so they are excluded from
modifier detection.

INPUTS
------
External signals fed into the model from other models or activity objects::

    internal_name = source_property @ default_value

OUTPUTS
-------
Internal properties exposed to other models::

    external_name = internal_name

FEATURES
--------
Observable model properties that appear in simulation results::

    feature_name = internal_name [unit]
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import NamedTuple

from .model import Reaction


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

class SundParseResult(NamedTuple):
    """Result of parsing a sund model file.

    Attributes
    ----------
    reactions:
        List of :class:`~model_graph_drawer.model.Reaction` objects.
    species:
        Full set of state variable names.
    inputs:
        Internal names of input variables (external signals driving the model).
    outputs:
        Internal names of species/variables exposed to other models.
    features:
        Internal names of species/variables that are observable features.
    """

    reactions: list[Reaction]
    species: set[str]
    inputs: set[str]
    outputs: set[str]
    features: set[str]


def parse_sund_file(path: str | Path) -> SundParseResult:
    """Parse a sund ``.txt`` model file.

    Returns
    -------
    SundParseResult
        Named tuple with ``reactions``, ``species``, ``inputs``, ``outputs``,
        and ``features``.
    """
    return parse_sund_text(Path(path).read_text())


def parse_sund_text(text: str) -> SundParseResult:
    """Parse sund model text.

    Returns
    -------
    SundParseResult
        See :func:`parse_sund_file`.
    """
    sections = _split_sections(text)

    # ---- 1. States ----------------------------------------------------------
    # Collect species names and per-species d/dt expressions.
    state_exprs: dict[str, str] = {}   # species -> rhs of d/dt equation
    for line in sections.get("STATES", "").splitlines():
        line = line.strip()
        m = re.match(r"d/dt\s*\(\s*(\w+)\s*\)\s*=\s*(.+)", line)
        if m:
            state_exprs[m.group(1)] = m.group(2).strip()

    species_set: set[str] = set(state_exprs)

    # ---- 2. Variables (reaction rate definitions) ---------------------------
    rate_defs: dict[str, str] = {}     # variable name -> rate expression
    for line in sections.get("VARIABLES", "").splitlines():
        line = line.strip()
        m = re.match(r"(\w+)\s*=\s*(.+)", line)
        if m:
            rate_defs[m.group(1)] = m.group(2).strip()

    # ---- 3. Build stoichiometry from d/dt expressions ----------------------
    # Only variables that actually appear in a d/dt rhs are reactions.
    stoich: dict[str, dict[str, list[str]]] = {}   # rxn_id -> {reactants, products}

    for species, expr in state_exprs.items():
        if expr == "0":
            continue
        for rxn_id, sign in _parse_signed_terms(expr).items():
            if rxn_id not in rate_defs:
                continue                        # not a known variable
            if rxn_id not in stoich:
                stoich[rxn_id] = {"reactants": [], "products": []}
            if sign > 0:
                stoich[rxn_id]["products"].append(species)
            else:
                stoich[rxn_id]["reactants"].append(species)

    # ---- 4. Assemble Reaction objects ---------------------------------------
    reactions: list[Reaction] = []
    for rxn_id, s in stoich.items():
        reactions.append(Reaction(
            id=rxn_id,
            reactants=s["reactants"],
            products=s["products"],
            rate=rate_defs[rxn_id],
        ))

    # ---- 5. Inputs / Outputs / Features ------------------------------------
    inputs   = _parse_inputs(sections.get("INPUTS", ""))
    outputs  = _parse_outputs(sections.get("OUTPUTS", ""))
    features = _parse_features(sections.get("FEATURES", ""))

    return SundParseResult(reactions, species_set, inputs, outputs, features)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _parse_inputs(section: str) -> set[str]:
    """Parse INPUTS section → set of internal variable names.

    Format: ``internal_name = source @ default``
    """
    result: set[str] = set()
    for line in section.splitlines():
        m = re.match(r"\s*(\w+)\s*=", line)
        if m:
            result.add(m.group(1))
    return result


def _parse_outputs(section: str) -> set[str]:
    """Parse OUTPUTS section → set of internal species names.

    Format: ``external_name = internal_name``
    """
    result: set[str] = set()
    for line in section.splitlines():
        m = re.match(r"\s*\w+\s*=\s*(\w+)", line)
        if m:
            result.add(m.group(1))
    return result


def _parse_features(section: str) -> set[str]:
    """Parse FEATURES section → set of internal species names.

    Format: ``feature_name = internal_name [optional unit]``
    """
    result: set[str] = set()
    for line in section.splitlines():
        m = re.match(r"\s*\w+\s*=\s*(\w+)", line)
        if m:
            result.add(m.group(1))
    return result


def _split_sections(text: str) -> dict[str, str]:
    """Split sund text into a dict of {SECTION_NAME: content}."""
    sections: dict[str, str] = {}
    current: str | None = None
    buf: list[str] = []

    for line in text.splitlines():
        m = re.match(r"#{5,}\s+(\w+)", line)
        if m:
            if current is not None:
                sections[current] = "\n".join(buf)
            current = m.group(1)
            buf = []
        elif current is not None:
            buf.append(line)

    if current is not None:
        sections[current] = "\n".join(buf)

    return sections


def _parse_signed_terms(expr: str) -> dict[str, int]:
    """Parse a signed sum like ``r3+r2-r1`` into ``{'r3': 1, 'r2': 1, 'r1': -1}``.

    Handles leading terms with no explicit sign (treated as positive).
    """
    expr = expr.strip()
    if expr and expr[0] not in "+-":
        expr = "+" + expr
    result: dict[str, int] = {}
    for m in re.finditer(r"([+-])\s*([a-zA-Z_]\w*)", expr):
        result[m.group(2)] = 1 if m.group(1) == "+" else -1
    return result
