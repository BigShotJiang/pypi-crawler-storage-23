"""model_graph_drawer – interaction-graph visualisation for systems biology models.

Quick start
-----------
>>> from model_graph_drawer import Model, draw
>>> import matplotlib.pyplot as plt
>>>
>>> model = Model.from_text(\"\"\"
...     -> A : k1
...     A -> B: k2*A*C
...     B -> C: k3*B
...     C ->: k4*C
... \"\"\")
>>> draw(model, title="A→B→C cycle")
>>> plt.show()

Or use the shortcut on the model object itself::

    model.draw(title="A→B→C cycle")
"""

from .model import Model, Reaction
from .graph import build_graph, draw

__version__ = "0.1.0"
__all__ = ["Model", "Reaction", "build_graph", "draw"]
