from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Reaction:
    """A single reaction in a systems biology model.

    Attributes
    ----------
    id:
        Unique identifier (e.g. 'r1').
    reactants:
        Species consumed by the reaction.
    products:
        Species produced by the reaction.
    rate:
        Rate expression as a string (e.g. 'k2*A*C').
    modifiers:
        Species that appear in the rate expression but are not reactants.
        Populated automatically by :class:`Model`.
    label:
        Optional human-readable label; falls back to *id* when None.
    """

    id: str
    reactants: list[str]
    products: list[str]
    rate: str
    modifiers: list[str] = field(default_factory=list)
    label: Optional[str] = None

    def display_label(self) -> str:
        """Return the label used in graph visualisations."""
        return self.label if self.label is not None else self.id


class Model:
    """A collection of reactions forming a systems biology model.

    Parameters
    ----------
    reactions:
        List of :class:`Reaction` objects.  Modifier lists are computed
        automatically from the rate expressions.

    Examples
    --------
    Build from a multi-line text block::

        model = Model.from_text(\"\"\"
            -> A : k1
            A -> B: k2*A*C
            B -> C: k3*B
            C ->: k4*C
        \"\"\")

    Build from a list of strings::

        model = Model.from_reactions([
            "-> A : k1",
            "A -> B: k2*A*C",
            "B -> C: k3*B",
            "C ->: k4*C",
        ])
    """

    def __init__(
        self,
        reactions: list[Reaction],
        species: set[str] | None = None,
        inputs: set[str] | None = None,
        outputs: set[str] | None = None,
        features: set[str] | None = None,
    ) -> None:
        self.reactions: list[Reaction] = reactions
        # Use the explicitly provided species set when given (e.g. from a sund
        # model where some states never appear as reactants or products).
        self.species: set[str] = species if species is not None else self._collect_species()
        self.inputs:   set[str] = inputs   or set()
        self.outputs:  set[str] = outputs  or set()
        self.features: set[str] = features or set()
        # Inputs that are not already states are added to the species set so
        # they appear in the layout and participate in modifier detection.
        self.species = self.species | self.inputs
        self._compute_modifiers()

    # ------------------------------------------------------------------
    # Construction helpers
    # ------------------------------------------------------------------

    @classmethod
    def from_text(cls, text: str) -> Model:
        """Create a model from a multi-line text block of reactions."""
        from .parser import parse_text
        return cls(parse_text(text))

    @classmethod
    def from_reactions(cls, reactions: list[str]) -> Model:
        """Create a model from a list of reaction strings."""
        return cls.from_text("\n".join(reactions))

    @classmethod
    def from_sund(cls, path: str) -> Model:
        """Create a model from a sund ``.txt`` model file.

        Parameters
        ----------
        path:
            Path to the sund model file.
        """
        from .sund_parser import parse_sund_file
        result = parse_sund_file(path)
        return cls(
            result.reactions,
            species=result.species,
            inputs=result.inputs,
            outputs=result.outputs,
            features=result.features,
        )

    # ------------------------------------------------------------------
    # Drawing shortcut
    # ------------------------------------------------------------------

    def draw(self, **kwargs):
        """Draw the interaction graph.  All kwargs are forwarded to :func:`draw`."""
        from .graph import draw
        return draw(self, **kwargs)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _collect_species(self) -> set[str]:
        species: set[str] = set()
        for rxn in self.reactions:
            species.update(rxn.reactants)
            species.update(rxn.products)
        return species

    def _compute_modifiers(self) -> None:
        """Identify modifiers: species in the rate expression that are not reactants."""
        for rxn in self.reactions:
            if not rxn.rate:
                rxn.modifiers = []
                continue
            identifiers = set(re.findall(r'\b([a-zA-Z_][a-zA-Z0-9_]*)\b', rxn.rate))
            rxn.modifiers = sorted(identifiers & self.species - set(rxn.reactants))

    # ------------------------------------------------------------------
    # Dunder helpers
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return (
            f"Model(species={sorted(self.species)}, "
            f"reactions={len(self.reactions)})"
        )
