from datetime import date


def convert_value(
    value: str, data_type: str, parse_dates: bool = False
) -> str | int | float | date:
    """
    Converts a string value to the specified data type.

    Args:
        value: The string value to convert.
        data_type: The target data type (e.g., "string", "int", "float", "bool").
        parse_dates: Whether to parse date fields into python datetime objects.

    Returns:
        The converted value in the appropriate type.
    """
    if data_type == "text" or data_type == "string":
        return value
    elif data_type == "integer":
        try:
            return int(value)
        except ValueError:
            return value
    elif data_type == "float":
        try:
            return float(value)
        except ValueError:
            return 0.0
    elif data_type == "date" and parse_dates:
        try:
            return date.strptime(value, "%Y-%m-%d")
        except ValueError:
            return value
    else:
        return value
