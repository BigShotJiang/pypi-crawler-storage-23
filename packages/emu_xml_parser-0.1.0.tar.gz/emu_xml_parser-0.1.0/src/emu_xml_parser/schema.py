from typing import Any, Dict, List
from .converter import convert_value
import cerberus


class Schema:
    def __init__(self, schema_text: str, parse_dates: bool = False):
        self.parse_dates = parse_dates
        self.schema_text = schema_text
        self.single_field_tables = []
        self.schema = self.parse_schema()
        self.validator = cerberus.Validator(self.schema)

    def parse_schema(self) -> Dict[str, Any]:
        """
        Parses the schema text and returns a Cerberus-compatible schema dictionary.
        """
        lines = [line.strip() for line in self.schema_text.splitlines() if line.strip()]

        if not lines:
            return {}

        # Skip root table declaration, parse its contents
        schema, _ = self._parse_block(lines, start_index=1)
        return schema

    def _parse_block(
        self, lines: List[str], start_index: int = 0
    ) -> tuple[Dict[str, Any], int]:
        """
        Recursively parse a block (table or tuple) and return (schema, next_line_index).

        Returns:
            (cerberus_schema_dict, index_of_next_line_after_block)
        """
        schema = {}
        index = start_index

        while index < len(lines):
            line = lines[index]

            if line == "end":
                # End of this block
                return schema, index + 1
            parts = line.split()
            if not parts:
                index += 1
                continue

            # Check if this is a nested table/tuple
            if parts[0] in ("table", "tuple"):
                block_type = parts[0]
                block_name = parts[1]

                # Recursively parse nested block
                nested_schema, index = self._parse_block(lines, index + 1)

                # Define schema key
                children_count = len(nested_schema.keys())

                if children_count == 1 and block_type == "table":
                    # Single-field table -> list of that field's type
                    only_field = next(iter(nested_schema.keys()))
                    nested_schema = {
                        "type": "list",
                        "schema": {"type": nested_schema[only_field]["type"]},
                        "default": [],
                    }
                    self.single_field_tables.append(block_name)
                else:
                    nested_schema = {
                        "type": "dict",
                        "schema": nested_schema,
                        "default": {},
                    }

                schema[block_name] = nested_schema

            else:
                # It's a field definition
                field_type = parts[0]
                field_name = parts[-1]  # Last part is always the name

                if field_type == "integer":
                    schema[field_name] = {
                        "type": "integer",
                        "coerce": lambda s, ft=field_type: convert_value(s, ft),
                        "nullable": True,
                        "default": None,
                    }
                elif field_type == "float":
                    schema[field_name] = {
                        "type": "float",
                        "coerce": lambda s, ft=field_type: convert_value(s, ft),
                        "nullable": True,
                        "default": None,
                    }
                elif field_type == "date" and self.parse_dates:
                    schema[field_name] = {
                        "type": "datetime",
                        "coerce": lambda s, ft=field_type: convert_value(
                            s, ft, parse_dates=True
                        ),
                        "nullable": True,
                        "default": None,
                    }
                else:
                    schema[field_name] = {
                        "type": "string",
                        "coerce": lambda s, ft=field_type: convert_value(s, ft),
                        "nullable": True,
                        "default": None,
                    }
                index += 1

        return schema

    def normalize(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Normalize and validate `data` using the parsed schema.

        - Prune unexpected keys (fields or declared children).
        - Ensure declared atom fields exist with default "".
        - Ensure declared child tables exist and normalize their entries.

        Args:
            data: The dictionary to normalize.
            table_name: The name of the current table (used to look up schema).
        Returns:
            The normalized dictionary with all expected fields and nested tables.
        """

        self.validator.validate(data)
        return self.validator.document
