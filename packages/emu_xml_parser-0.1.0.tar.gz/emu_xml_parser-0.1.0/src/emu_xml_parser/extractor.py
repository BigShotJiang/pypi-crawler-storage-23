import re
from pathlib import Path


def extract_schema_from_pi(xml_file: str) -> str:
    """
    Extracts the schema block from an XML file's processing instruction.

    Args:
        xml_file: Path to the XML file.

    Returns:
        The schema text as a string.

    Raises:
        ValueError: If no schema block is found in the XML.
    """
    text = Path(xml_file).read_text(encoding="utf-8")
    match = re.search(r"<\?schema(.*?)\?>", text, re.DOTALL)
    if not match:
        raise ValueError("No schema block found in XML processing instructions.")
    return match.group(1)
