from typing import Any, Dict
from .schema import Schema
import xml.etree.ElementTree as ET


def parse_tuple(
    elem: ET.Element,
    schema: Schema,
) -> Dict[str, Any]:
    """
    Recursively parses a <tuple> XML element according to the schema.

    Args:
        elem: The XML element to parse.
        schema: The schema dictionary for the current level.
        parse_dates: Whether to parse date fields into python datetime objects.

    Returns:
        A dictionary representing the parsed record, with all expected fields/tables present.
    """
    data: Dict[str, Any] = {}

    for child in elem:
        name = child.attrib.get("name")
        # Atoms are simple fields
        if child.tag == "atom":
            value = (child.text or "").strip()
            data[name] = value

        # Allow for recursion of nested tables and tuples
        elif child.tag == "table":
            nested_rows = [
                parse_tuple(
                    subtuple,
                    schema,
                )
                for subtuple in child.findall("tuple")
            ]

            if name in schema.single_field_tables:
                # single-column table -> return list[str]
                nested_rows = [list(row.values())[0] for row in nested_rows]

            data[name] = nested_rows

        elif child.tag == "tuple":
            tuple_name = child.attrib.get("name")
            if tuple_name:
                nested = parse_tuple(child, schema)

                data[tuple_name] = [nested]
            else:
                nested = parse_tuple(child, schema)
                data.update(nested)

    return data
