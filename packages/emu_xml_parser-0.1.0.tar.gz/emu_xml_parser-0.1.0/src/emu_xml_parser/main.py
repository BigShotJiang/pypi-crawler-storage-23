from typing import Any, Dict, List
import xml.etree.ElementTree as ET
from .extractor import extract_schema_from_pi
from .tuple_parser import parse_tuple
from .sanitizer import sanitize_xml
from .schema import Schema


def parse(
    xml_file: str,
    parse_dates: bool = False,
) -> List[Dict[str, Any]]:
    """
    Converts an EMu XML file to a list of dictionaries, one per record.

    Args:
        xml_file: Path to the EMu XML file.
        parse_dates: Whether to parse date fields into python datetime objects.
    Returns:
        A list of dictionaries, each representing a record with all expected fields and nested tables.
        - Atom fields are strings.
        - Multi-field tables are lists of dicts.
        - Single-field tables are lists of strings.
        - Missing fields/tables are filled with "" or [] as appropriate.
    """
    schema_text = extract_schema_from_pi(xml_file)
    schema = Schema(schema_text, parse_dates=parse_dates)

    try:
        tree = ET.parse(xml_file)
    except ET.ParseError:
        # try sanitizing illegal XML characters and parse from string
        with open(xml_file, "r", encoding="utf-8") as f:
            text = f.read()
        clean = sanitize_xml(text)
        root = ET.fromstring(clean)
        tree = ET.ElementTree(root)

    # The root table name is determined from the schema's first line, or defaults to "root"
    root = tree.getroot()
    rows: List[Dict[str, Any]] = []

    for tuple_elem in root.findall("tuple"):
        row = parse_tuple(tuple_elem, schema)
        normalized = schema.normalize(row)
        rows.append(normalized)

    return rows
