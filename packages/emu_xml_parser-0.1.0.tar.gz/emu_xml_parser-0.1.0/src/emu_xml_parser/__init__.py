"""Public package API for emu_xml_parser."""

from .main import parse

__all__ = ["parse"]
