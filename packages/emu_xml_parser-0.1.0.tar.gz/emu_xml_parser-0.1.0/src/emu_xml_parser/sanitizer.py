import re

# Allowed by XML 1.0: #x9 | #xA | #xD | #x20–#xD7FF | #xE000–#xFFFD | #x10000–#x10FFFF
_INVALID_XML_RE = re.compile(
    r"""
    [^                                      # negate: match any char NOT in the allowed set
        \x09                                # #x9  : Horizontal Tab
        \x0A                                # #xA  : Line Feed (LF)
        \x0D                                # #xD  : Carriage Return (CR)
        \u0020-\uD7FF                       # #x20 - #xD7FF : most common BMP chars (excludes C0 controls)
        \uE000-\uFFFD                       # #xE000 - #xFFFD : BMP private-use & other permitted BMP chars
        \U00010000-\U0010FFFF               # #x10000 - #x10FFFF : Supplementary Planes
    ]
""",
    re.VERBOSE,
)


def sanitize_xml(text: str) -> str:
    """Remove characters illegal in XML 1.0 (e.g. vertical tab U+000B)."""
    return _INVALID_XML_RE.sub("", text)
