# Copyright (C) 2025-2026 J. F. Escobar
# SPDX-License-Identifier: LGPL-3.0-or-later

FLUML_TEMPLATE = ".. msg.welcome: Welcome, from { Fluvel | https://github.com/Robotid/Fluvel }"
