from .utils import create_internal_link_handler

__all__ = ['create_internal_link_handler']
