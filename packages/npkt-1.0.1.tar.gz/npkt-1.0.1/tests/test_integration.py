"""Integration tests for end-to-end workflows."""

from datetime import datetime

from npkt.analyzer import ImpactAnalyzer
from npkt.ingest import FileIngester
from npkt.parsers import load_policy


def test_end_to_end_analysis(sample_scp_file, sample_cloudtrail_file):
    """Test complete end-to-end analysis workflow."""
    # Parse SCP
    scp_policy = load_policy(sample_scp_file)
    assert scp_policy is not None
    assert len(scp_policy.statements) == 3

    # Create ingester
    ingester = FileIngester(sample_cloudtrail_file)

    # Create analyzer
    analyzer = ImpactAnalyzer(
        scp_policies=[scp_policy],
        cloudtrail_ingester=ingester,
    )

    # Perform analysis
    start_time = datetime(2025, 12, 1, 0, 0, 0)
    end_time = datetime(2025, 12, 1, 23, 59, 59)

    impact_report = analyzer.analyze(start_time, end_time)

    # Verify results
    assert impact_report.total_events == 6

    # Should deny:
    # - s3:DeleteBucket (1 event)
    # - iam:CreateUser (1 event)
    # - ec2:TerminateInstances (1 event)
    # - s3:DeleteBucketPolicy (1 event)
    # Total: 4 denials
    assert impact_report.denied_count == 4

    # Should allow:
    # - s3:GetObject (1 event)
    # - ec2:DescribeInstances (1 event)
    # Total: 2 allowed
    assert impact_report.allowed_count == 2

    # Check statistics
    assert "s3" in impact_report.statistics.denied_by_service
    assert "iam" in impact_report.statistics.denied_by_service
    assert "ec2" in impact_report.statistics.denied_by_service

    # Verify specific denied actions
    denied_actions = [event.iam_action for event, _ in impact_report.denied_events]
    assert "s3:DeleteBucket" in denied_actions
    assert "iam:CreateUser" in denied_actions
    assert "ec2:TerminateInstances" in denied_actions
    assert "s3:DeleteBucketPolicy" in denied_actions

    # Should not deny these
    assert "s3:GetObject" not in denied_actions
    assert "ec2:DescribeInstances" not in denied_actions
