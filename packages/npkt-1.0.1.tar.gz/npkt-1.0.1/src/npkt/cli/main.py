"""Unified CLI entry point for npkt."""

import click

from .analyze import analyze
from .generate import generate_logs
from .lint import lint
from .simulate import simulate
from .validate import validate


@click.group()
@click.version_option(version="1.0.1", prog_name="npkt")
def cli() -> None:
    """NPKT - AWS Service Control Policy toolkit.

    Lint, analyze, and simulate SCP impact.

    \b
    Commands:
      lint      Lint SCP policies for errors and warnings
      analyze   Analyze policies for conflicts and redundancies
      simulate  Simulate SCP impact against CloudTrail events
      validate       Quick syntax validation of SCP files
      generate-logs  Generate mock CloudTrail events for testing
    """
    pass


# Register subcommands
cli.add_command(lint)
cli.add_command(analyze)
cli.add_command(simulate)
cli.add_command(validate)
cli.add_command(generate_logs)


if __name__ == "__main__":
    cli()
