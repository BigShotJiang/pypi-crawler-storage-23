"""Reference data and utilities."""

from .global_actions import GLOBAL_ACTIONS, is_global_action
from .iam_reference import AWSIAMReference, get_iam_reference

__all__ = [
    "AWSIAMReference",
    "GLOBAL_ACTIONS",
    "get_iam_reference",
    "is_global_action",
]
