"""Lint result data models."""

from dataclasses import dataclass, field
from enum import Enum


class LintSeverity(Enum):
    """Severity levels for lint issues."""

    ERROR = "error"  # Invalid, will not work
    WARNING = "warning"  # Valid but potentially problematic
    INFO = "info"  # Informational, best practices


@dataclass
class LintResult:
    """A single lint issue found in an SCP."""

    severity: LintSeverity
    code: str  # e.g., "E001", "W001", "I001"
    message: str
    location: str | None = None  # e.g., "Statement[0].Action"
    suggestion: str | None = None

    def __str__(self) -> str:
        loc = f" at {self.location}" if self.location else ""
        sug = f" Suggestion: {self.suggestion}" if self.suggestion else ""
        return f"[{self.severity.value.upper()}] {self.code}: {self.message}{loc}{sug}"

    def to_dict(self) -> dict:
        """Convert result to dictionary for JSON serialization."""
        return {
            "severity": self.severity.value,
            "code": self.code,
            "message": self.message,
            "location": self.location,
            "suggestion": self.suggestion,
        }


@dataclass
class LintReport:
    """Complete lint report for an SCP."""

    results: list[LintResult] = field(default_factory=list)
    policy_size: int = 0
    statement_count: int = 0
    is_valid: bool = True

    @property
    def errors(self) -> list[LintResult]:
        return [r for r in self.results if r.severity == LintSeverity.ERROR]

    @property
    def warnings(self) -> list[LintResult]:
        return [r for r in self.results if r.severity == LintSeverity.WARNING]

    @property
    def infos(self) -> list[LintResult]:
        return [r for r in self.results if r.severity == LintSeverity.INFO]

    @property
    def has_errors(self) -> bool:
        return len(self.errors) > 0

    @property
    def has_warnings(self) -> bool:
        return len(self.warnings) > 0

    @property
    def error_count(self) -> int:
        return len(self.errors)

    @property
    def warning_count(self) -> int:
        return len(self.warnings)

    @property
    def info_count(self) -> int:
        return len(self.infos)

    def add(self, result: LintResult) -> None:
        self.results.append(result)
        if result.severity == LintSeverity.ERROR:
            self.is_valid = False

    def to_dict(self) -> dict:
        """Convert report to dictionary for JSON serialization."""
        return {
            "is_valid": self.is_valid,
            "policy_size": self.policy_size,
            "statement_count": self.statement_count,
            "results": [r.to_dict() for r in self.results],
            "summary": {
                "errors": len(self.errors),
                "warnings": len(self.warnings),
                "infos": len(self.infos),
            },
        }
