"""CloudTrail log generation utilities."""

from .cloudtrail_generator import CloudTrailGenerator, GeneratorConfig

__all__ = ["CloudTrailGenerator", "GeneratorConfig"]
