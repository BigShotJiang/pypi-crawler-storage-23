"""NPKT - AWS Service Control Policy toolkit.

A comprehensive toolkit for linting, analyzing, and simulating
AWS Service Control Policies (SCPs).

Example usage:
    >>> from npkt import load_policy, SCPLinter, PolicyAnalyzer
    >>>
    >>> # Load and lint a policy
    >>> policy = load_policy("policy.json")
    >>> linter = SCPLinter()
    >>> report = linter.lint(policy.to_dict())
    >>>
    >>> # Analyze policies for conflicts
    >>> from npkt import analyze_policies
    >>> report = analyze_policies([policy])
"""

__version__ = "1.0.1"

# Models
from .analyzer.impact_analyzer import ImpactAnalyzer

# Analyzers
from .analyzer.policy_analyzer import PolicyAnalyzer, analyze_policies

# Engine
from .engine.scp_engine import SCPEngine

# Ingesters
from .ingest.base import CloudTrailIngester
from .ingest.file_ingester import FileIngester

# Linter
from .linter.scp_linter import SCPLinter
from .models.analysis import AnalysisReport, Issue, IssueType
from .models.cloudtrail import CloudTrailEvent
from .models.external_context import ExternalContext, ExternalContextError
from .models.lint import LintReport, LintResult, LintSeverity
from .models.report import EvaluationContext, EvaluationResult, ImpactReport
from .models.scp import SCPPolicy, SCPStatement

# Parsers
from .parsers.scp_parser import load_policies_from_dir, load_policy

# Reporters
from .reporters.console_reporter import ConsoleReporter
from .reporters.json_reporter import JSONReporter

__all__ = [
    # Version
    "__version__",
    # Models - SCP
    "SCPStatement",
    "SCPPolicy",
    # Models - Lint
    "LintReport",
    "LintResult",
    "LintSeverity",
    # Models - Analysis
    "AnalysisReport",
    "Issue",
    "IssueType",
    # Models - CloudTrail
    "CloudTrailEvent",
    # Models - Report
    "ImpactReport",
    "EvaluationResult",
    "EvaluationContext",
    # Models - External Context
    "ExternalContext",
    "ExternalContextError",
    # Parsers
    "load_policy",
    "load_policies_from_dir",
    # Linter
    "SCPLinter",
    # Analyzers
    "PolicyAnalyzer",
    "analyze_policies",
    "ImpactAnalyzer",
    # Engine
    "SCPEngine",
    # Ingesters
    "CloudTrailIngester",
    "FileIngester",
    # Reporters
    "ConsoleReporter",
    "JSONReporter",
]
