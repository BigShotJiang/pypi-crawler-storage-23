"""Template tags package for next-dj."""
