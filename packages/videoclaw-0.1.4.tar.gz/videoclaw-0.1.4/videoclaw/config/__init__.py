"""配置模块"""
from videoclaw.config.loader import Config

config = Config()

__all__ = ["Config", "config"]
