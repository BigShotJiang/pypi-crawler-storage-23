"""Videoclaw - AI 视频创作 CLI 工具"""

__version__ = "0.1.0"
