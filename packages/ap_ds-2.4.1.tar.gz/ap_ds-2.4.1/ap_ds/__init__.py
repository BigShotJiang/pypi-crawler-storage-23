import os
import sys

try:
    from ._version import __version__
except ImportError:
    try:
        from _version import __version__
    except ImportError:
        __version__ = "unknown"

if os.environ.get('AP_DS_HIDE_SUPPORT_PROMPT') != '1':
    print(f"AP_DS © - Audio Library By DVS  v{__version__} | https://dvsx.top")


try:
    from .player import *
except ImportError:
    from player import *
