# Agent Company AI

**Spin up an AI agent company - a business run by AI agents, managed by you.**

Agent Company AI lets a solo entrepreneur create a virtual company staffed entirely by AI agents. Each agent has a specific business role (CEO, CTO, Developer, Marketer, etc.), they collaborate on tasks, and you manage everything through a CLI or web dashboard. Agents can earn real money with built-in Stripe, Gumroad, invoicing, and booking integrations.

## Quick Start

```bash
pip install agent-company-ai
```

### 1. Initialize your company

```bash
agent-company-ai init --name "My AI Startup"
```

You'll be prompted to:
1. **Choose an LLM provider** — Anthropic, OpenAI, DeepSeek, Ollama, and more
2. **Configure integrations** — Stripe, Email, Gumroad, Cal.com, Invoices, Landing Pages

The integration menu lets you pick any combination (comma-separated) or select "All":

```
Configure integrations (optional)
  [1] Stripe (payment links & subscriptions)
  [2] Email (send invoices & notifications)
  [3] Gumroad (sell digital products)
  [4] Cal.com (paid bookings)
  [5] Invoices (generate & send invoices)
  [6] Landing Pages (auto-enabled, no key needed)
  [7] All of the above
  [8] Skip for now
```

For each selected integration you'll be prompted for its API key (or press Enter to use an environment variable placeholder like `${STRIPE_SECRET_KEY}`).

**Non-interactive mode** (for CI/scripts):

```bash
agent-company-ai init --name "Acme AI" --provider anthropic --api-key $ANTHROPIC_API_KEY
```

This skips all interactive prompts (LLM and integrations). To skip only integration prompts:

```bash
agent-company-ai init --name "Acme AI" --skip-integrations
```

### 2. One-command setup

Spin up a full team from a preset template:

```bash
agent-company-ai setup tech_startup --name "Acme AI"
agent-company-ai setup saas --name "CloudCo" --provider anthropic --api-key $ANTHROPIC_API_KEY
agent-company-ai setup --list  # see all presets
```

**Available presets:** `tech_startup` (6 agents), `agency` (6), `ecommerce` (7), `saas` (9), `consulting` (6), `content` (5), `full` (10 — all departments)

### 3. Or hire agents individually

```bash
agent-company-ai hire ceo --name Alice
agent-company-ai hire cto --name Bob
agent-company-ai hire developer --name Carol
agent-company-ai hire marketer --name Dave
```

### 4. Define your business model

Tell your agents how the company makes money:

```bash
agent-company-ai profit-engine setup --template saas
```

This injects your business DNA into every agent's decision-making. See [ProfitEngine](#profitengine--business-dna) below.

### 5. Run autonomously

Give the CEO a goal and watch the company run:

```bash
agent-company-ai run "Build a landing page for our new product"
```

The CEO will break down the goal, delegate tasks to the team, and agents will collaborate to deliver results.

```bash
# With limits
agent-company-ai run "Launch MVP" --cycles 3 --timeout 600 --max-tasks 20
```

### 6. Check revenue

```bash
agent-company-ai revenue --days 30
```

## Commands

| Command | Description |
|---------|-------------|
| `init` | Initialize a new company (with LLM + integration setup prompts) |
| `setup <preset>` | Set up a full company from a template |
| `hire <role>` | Hire an agent |
| `fire <name>` | Remove an agent |
| `team` | List all agents |
| `assign "<task>"` | Assign a task |
| `tasks` | Show the task board |
| `chat <name>` | Chat with an agent |
| `run "<goal>"` | Autonomous mode |
| `broadcast "<msg>"` | Message all agents |
| `dashboard` | Launch web dashboard |
| `status` | Company overview |
| `output` | List deliverables produced by agents |
| `roles` | List available roles |
| `revenue` | Revenue summary across all sources |
| `companies` | List all companies in this directory |
| `destroy` | Permanently delete a company |
| `profit-engine <cmd>` | Configure business model DNA ([details](#profitengine--business-dna)) |
| `wallet <cmd>` | Manage blockchain wallet ([details](#blockchain-wallet)) |
| `upgrade` | Run the automated self-upgrade pipeline ([details](#auto-upgrade)) |

### Global Options

| Flag | Description |
|------|-------------|
| `--company` / `-C` | Company slug to operate on (default: `default`) |

You can also set the company via environment variable:

```bash
export AGENT_COMPANY_NAME=my-startup
agent-company-ai team  # operates on my-startup
```

## Money-Earning Tools

Agents can generate real revenue using built-in integrations. All tools are rate-limited and logged to the database.

### Stripe Payment Links & Subscriptions

Create one-time payment links and recurring subscription links directly from agent workflows.

```yaml
# config.yaml
integrations:
  stripe:
    enabled: true
    api_key: ${STRIPE_SECRET_KEY}
    max_link_amount_cents: 50000  # $500 safety cap per link
```

**Tools:** `create_payment_link`, `create_subscription_link`, `list_subscribers`, `check_subscription_revenue`

### Gumroad Products

Create and sell digital products on Gumroad.

```yaml
integrations:
  gumroad:
    enabled: true
    api_key: ${GUMROAD_ACCESS_TOKEN}
```

**Tools:** `create_gumroad_product`, `list_gumroad_products`, `check_gumroad_sales`

### Invoices

Generate professional HTML invoices, email them to clients, and track payment status. No external API required.

```yaml
integrations:
  invoice:
    enabled: true
    company_name: "Acme AI Inc."
    company_address: "123 AI Street"
    payment_instructions: "Pay via bank transfer to..."
    currency: USD
```

**Tools:** `create_invoice`, `send_invoice`, `list_invoices`, `mark_invoice_paid`

Invoices are saved as HTML files in `.agent-company-ai/default/invoices/`.

### Cal.com Bookings

Create booking event types for paid consultations.

```yaml
integrations:
  calcom:
    enabled: true
    api_key: ${CALCOM_API_KEY}
    default_duration: 30
```

**Tools:** `create_booking_link`, `list_bookings`, `check_booking_revenue`

> **Note:** Payment collection requires Cal.com payment app setup in your dashboard. The price is recorded locally for revenue tracking.

### Revenue Ledger

Unified revenue tracking across all sources — Stripe, Gumroad, invoices, crypto, and manual entries.

**Tools:** `check_revenue`, `record_revenue`, `sync_stripe_revenue`

```bash
# CLI command
agent-company-ai revenue --days 30
```

### Email & Landing Pages

Send transactional emails (via Resend or SendGrid) and generate landing pages.

```yaml
integrations:
  email:
    enabled: true
    provider: resend       # or sendgrid
    api_key: ${RESEND_API_KEY}
    from_address: hello@yourdomain.com
  landing_page:
    enabled: true
```

**Tools:** `send_email`, `generate_landing_page`

### Social Media

Draft social media posts for review.

```yaml
integrations:
  social:
    enabled: true
    twitter:
      api_key: ${TWITTER_API_KEY}
      api_secret: ${TWITTER_API_SECRET}
      access_token: ${TWITTER_ACCESS_TOKEN}
      access_secret: ${TWITTER_ACCESS_SECRET}
```

**Tools:** `draft_social_post`, `publish_twitter`

### Lead Prospecting

Find leads, enrich contact info, and auto-add to CRM — no API keys needed. Uses DuckDuckGo search + website scraping.

```bash
agent-company-ai assign "Find 5 SaaS companies in the US and add them to our CRM"
```

**Tools:** `prospect_search`, `enrich_contact`, `prospect_campaign`

- `prospect_search` — Search for companies by industry, keywords, and location
- `enrich_contact` — Scrape a company's website for emails, phones, and social links
- `prospect_campaign` — Full pipeline: search → enrich → CRM insert in one call

### Content Generation

Create publish-ready blog posts, email sequences, and digital products from markdown. No API keys needed — all content is generated locally as styled HTML files.

**Tools:** `create_blog_post`, `create_email_sequence`, `create_digital_product`

- `create_blog_post` — Markdown → styled HTML blog post with SEO meta tags. Saved to `content/blog/`
- `create_email_sequence` — Drip campaign builder (onboarding, sales, nurture, launch). Stored in DB for use with email tool
- `create_digital_product` — Multi-chapter HTML ebook with TOC. Saved to `content/products/`

### Browser Automation

Scrape websites, extract structured data, and submit forms — no API keys needed.

**Tools:** `browse_page`, `extract_contacts_from_url`, `submit_form`

- `browse_page` — Fetch any URL and extract text, links, emails, meta tags, or forms
- `extract_contacts_from_url` — Multi-page contact extraction (checks main page + /contact + /about)
- `submit_form` — POST/GET form data to any URL

### Rate Limits

All integrations have configurable rate limits to prevent runaway spending:

| Resource | Default Limit |
|----------|---------------|
| Emails | 20/hour, 100/day |
| Payment links | 10/day, $500 max per link |
| Gumroad products | 50/day |
| Invoices | 50/day |
| Bookings | 20/day |
| Prospect searches | 30/hour, 200/day |
| Page browses | 60/hour, 500/day |

## ProfitEngine — Business DNA

ProfitEngine lets you define your company's business model — how it earns money, who it serves, and what matters most. This "business DNA" is injected into **every agent's system prompt** and into the **CEO's goal loop**, so all decisions align with your business model.

### Setup

Start from a preset template or from scratch:

```bash
# Interactive wizard with a preset
agent-company-ai profit-engine setup --template saas

# Fully interactive — choose a template then customize each field
agent-company-ai profit-engine setup
```

The wizard walks you through 8 fields:

| Field | What it defines |
|-------|----------------|
| **Mission** | The company's core purpose |
| **Revenue Streams** | How the company makes money |
| **Target Customers** | Who the ideal customers are |
| **Pricing Model** | How products/services are priced |
| **Competitive Edge** | What sets the company apart |
| **Key Metrics** | What metrics define success |
| **Cost Priorities** | Where money should be spent first |
| **Additional Context** | Any other business context |

### Templates

6 preset templates to start from:

| Template | Business Model |
|----------|---------------|
| `saas` | SaaS (Software as a Service) — recurring subscriptions |
| `ecommerce` | E-Commerce — online retail |
| `marketplace` | Marketplace / Platform — transaction fees |
| `agency` | Agency / Services — project and retainer fees |
| `consulting` | Consulting — advisory and engagement fees |
| `content` | Content / Media — ads, subscriptions, licensing |

```bash
agent-company-ai profit-engine templates  # list all templates
```

### Commands

| Command | Description |
|---------|-------------|
| `profit-engine setup` | Interactive wizard to configure business DNA |
| `profit-engine show` | Display current DNA |
| `profit-engine edit <field>` | Edit a single field |
| `profit-engine templates` | List available preset templates |
| `profit-engine disable` | Disable DNA injection (config preserved) |

### How it works

Once configured, the business DNA is automatically:

- **Appended to every agent's system prompt** — so developers, marketers, sales, and support all understand the business model
- **Injected into the CEO's planning and review tasks** — so autonomous mode goals are planned and evaluated through the lens of your business model

The DNA is stored in `config.yaml` under the `profit_engine` key. No new database tables — just config.

```yaml
# .agent-company-ai/default/config.yaml
profit_engine:
  enabled: true
  mission: "Build and scale a SaaS product..."
  revenue_streams: "Monthly/annual subscriptions..."
  target_customers: "SMB to enterprise..."
  pricing_model: "Tiered subscription pricing..."
  competitive_edge: "Product-led growth..."
  key_metrics: "MRR/ARR, churn rate, LTV:CAC..."
  cost_priorities: "Engineering first..."
  additional_context: ""
```

### Dashboard API

| Endpoint | Description |
|----------|-------------|
| `GET /api/profit-engine` | Return current ProfitEngine config |
| `POST /api/profit-engine` | Update fields and save to config |
| `GET /api/profit-engine/templates` | List all templates with content |

## Blockchain Wallet

Built-in Ethereum wallet with multi-chain support. Agents can request payments (with human approval), and you can send tokens directly from the CLI.

### Setup

```bash
agent-company-ai wallet create
```

Creates an encrypted keystore (password-protected). One address works across all supported chains.

### Supported Chains

| Chain | Native Token |
|-------|-------------|
| Ethereum | ETH |
| Base | ETH |
| Arbitrum | ETH |
| Polygon | MATIC |

### Commands

| Command | Description |
|---------|-------------|
| `wallet create` | Generate a new wallet with encrypted keystore |
| `wallet address` | Show the company wallet address |
| `wallet balance` | Show balances across all chains |
| `wallet balance --chain base` | Show balance on a specific chain |
| `wallet send <amount> --to <addr> --chain <chain>` | Send native tokens (requires password) |
| `wallet payments` | Show the payment approval queue |
| `wallet approve <id>` | Approve and send a pending payment |
| `wallet reject <id>` | Reject a pending payment |

### Agent Payments

Agents with wallet tools (`check_balance`, `get_wallet_address`, `list_payments`, `request_payment`) can request payments during task execution. All payment requests go into an approval queue — nothing is sent without your explicit approval.

```bash
# Check pending payments
agent-company-ai wallet payments --status pending

# Approve a payment
agent-company-ai wallet approve abc123

# Reject a payment
agent-company-ai wallet reject abc123
```

### Dashboard API

| Endpoint | Description |
|----------|-------------|
| `GET /api/wallet/balance` | Balances (optional `?chain=` filter) |
| `GET /api/wallet/address` | Wallet address |
| `GET /api/wallet/payments` | Payment queue (optional `?status=` filter) |

## Multi-Company Support

Run multiple independent companies in the same directory. Each company gets its own config, database, and agents:

```bash
# Default company
agent-company-ai init --name "Acme AI"
agent-company-ai hire ceo --name Alice

# Create a second company
agent-company-ai -C my-startup init --name "My Startup" --provider anthropic
agent-company-ai -C my-startup hire ceo --name Bob

# List all companies
agent-company-ai companies

# Destroy a company
agent-company-ai destroy --company my-startup
agent-company-ai destroy --yes  # destroy default, skip confirmation
```

**Directory layout:**
```
.agent-company-ai/
    default/
        config.yaml
        company.db
        invoices/
        output/
    my-startup/
        config.yaml
        company.db
```

Existing single-company setups are automatically migrated into `default/` on first access.

## Available Roles

| Role | Title | Reports To |
|------|-------|------------|
| `ceo` | Chief Executive Officer | Owner |
| `cto` | Chief Technology Officer | CEO |
| `developer` | Software Developer | CTO |
| `marketer` | Head of Marketing | CEO |
| `sales` | Head of Sales | CEO |
| `support` | Customer Support Lead | CEO |
| `finance` | CFO / Finance | CEO |
| `hr` | Head of HR | CEO |
| `project_manager` | Project Manager | CEO |

## LLM Providers

Supports 11 providers out of the box. All providers include automatic retry with exponential backoff on transient errors (429, 500-503).

| Provider | Models | API Key Env Var |
|----------|--------|-----------------|
| **Anthropic** (default) | Claude Sonnet 4.5, etc. | `ANTHROPIC_API_KEY` |
| **OpenAI** | GPT-4o, etc. | `OPENAI_API_KEY` |
| **DeepSeek** | DeepSeek-R1 | `DEEPSEEK_API_KEY` |
| **MiMo** | MiMo-7B-RL | `DEEPSEEK_API_KEY` |
| **Kimi** | Kimi-K2 | `MOONSHOT_API_KEY` |
| **Qwen** | Qwen-Max | `DASHSCOPE_API_KEY` |
| **MiniMax** | MiniMax-M1 | `MINIMAX_API_KEY` |
| **Ollama** | Llama 3.1, etc. | None (local) |
| **Together** | Llama, Mixtral, etc. | `TOGETHER_API_KEY` |
| **Groq** | Fast open-source inference | `GROQ_API_KEY` |
| **OpenAI-compatible** | Any endpoint | Custom |

Configure different providers per agent:

```yaml
llm:
  default_provider: anthropic
  anthropic:
    api_key: ${ANTHROPIC_API_KEY}
    model: claude-sonnet-4-5-20250929
  openai:
    api_key: ${OPENAI_API_KEY}
    model: gpt-4o
    base_url: https://api.openai.com/v1  # or any compatible endpoint

agents:
  - name: Alice
    role: ceo
    provider: anthropic
  - name: Bob
    role: developer
    provider: openai
```

## Web Dashboard

```bash
agent-company-ai dashboard --port 8420
```

Features:
- **Org Chart** - Visual company hierarchy
- **Agent Roster** - See all agents and their roles
- **Task Board** - Kanban-style task management
- **Chat** - Talk directly to any agent
- **Activity Feed** - Real-time event stream via WebSocket
- **Autonomous Mode** - Set goals and monitor progress from the UI
- **Cost Tracker** - Real-time API cost breakdown by agent and model
- **ProfitEngine** - View and edit business DNA from the dashboard
- **Wallet** - Check balances and view payment queue

## Built-in Agent Tools

Agents have access to these tools based on their role:

### Core Tools

| Tool | Description |
|------|-------------|
| `web_search` | Search the web via DuckDuckGo (no API key needed) |
| `read_file` / `write_file` | File operations in the workspace (sandboxed) |
| `code_exec` | Execute Python code (restricted builtins) |
| `shell` | Run shell commands (30s timeout, dangerous patterns blocked) |
| `delegate_task` | Delegate work to other agents |
| `report_result` | Submit task results |

### Revenue Tools

| Tool | Description |
|------|-------------|
| `create_payment_link` | Create Stripe one-time payment link |
| `create_subscription_link` | Create Stripe recurring subscription link |
| `list_subscribers` | List active Stripe subscribers with MRR |
| `check_subscription_revenue` | Calculate MRR/ARR from Stripe subscriptions |
| `create_gumroad_product` | Create a digital product on Gumroad |
| `list_gumroad_products` | List Gumroad products |
| `check_gumroad_sales` | Check Gumroad sales revenue |
| `create_invoice` | Generate a professional HTML invoice |
| `send_invoice` | Email an invoice to a client |
| `list_invoices` | List invoices with status filter |
| `mark_invoice_paid` | Mark an invoice as paid |
| `create_booking_link` | Create a Cal.com booking event type |
| `list_bookings` | List Cal.com bookings |
| `check_booking_revenue` | Check booking pricing summary |
| `check_revenue` | Unified revenue summary across all sources |
| `record_revenue` | Manually record revenue (cash, crypto, etc.) |
| `sync_stripe_revenue` | Sync Stripe charges into revenue ledger |

### Lead Prospecting Tools

| Tool | Description |
|------|-------------|
| `prospect_search` | Search for companies by industry/keywords/location |
| `enrich_contact` | Scrape a company's website for emails, phones, social links |
| `prospect_campaign` | Full pipeline: search → enrich → CRM insert |

### Content Generation Tools

| Tool | Description |
|------|-------------|
| `create_blog_post` | Markdown → styled HTML blog post with SEO meta |
| `create_email_sequence` | Build email drip campaigns (onboarding, sales, nurture) |
| `create_digital_product` | Multi-chapter HTML ebook/guide with TOC |

### Browser Automation Tools

| Tool | Description |
|------|-------------|
| `browse_page` | Fetch URL and extract text/links/emails/meta/forms |
| `extract_contacts_from_url` | Multi-page contact extraction from a website |
| `submit_form` | Submit POST/GET form data to any URL |

### Communication & Outreach Tools

| Tool | Description |
|------|-------------|
| `send_email` | Send transactional email (Resend/SendGrid) |
| `create_landing_page` | Generate a styled HTML landing page |
| `deploy_landing_page` | Deploy a landing page to Vercel |
| `draft_social_post` | Draft social media content |
| `publish_social_post` | Publish a tweet via Twitter API |
| `add_contact` | Add a contact to the CRM |
| `list_contacts` | Search and list CRM contacts |
| `update_contact` | Update an existing CRM contact |

### Wallet Tools

| Tool | Description |
|------|-------------|
| `check_balance` | Check wallet balance |
| `get_wallet_address` | Get company wallet address |
| `list_payments` | View payment queue |
| `request_payment` | Request a payment (goes to approval queue) |

## Autonomous Mode

The company runs in CEO-driven cycles:

1. **Plan** - CEO breaks the goal into tasks and delegates to the team
2. **Execute** - Agents work on tasks in parallel waves
3. **Review** - CEO evaluates progress and decides: DONE, CONTINUE, or FAILED
4. **Loop** - Repeat until goal achieved or limits reached

When ProfitEngine is enabled, the CEO factors business DNA into every planning and review decision. Incomplete tasks are automatically cancelled (not failed) when the goal loop ends.

**Configurable limits** (in `config.yaml` or via CLI flags):
- `max_cycles: 5` — CEO review loops
- `max_waves_per_cycle: 10` — parallel execution waves per cycle
- `max_total_tasks: 50` — hard cap on tasks
- `max_time_seconds: 3600` — wall-clock timeout
- `max_cost_usd: 0.0` — spending cap (0 = unlimited)

## Custom Roles

Create custom roles by adding YAML files:

```yaml
# .agent-company-ai/roles/custom_analyst.yaml
name: analyst
title: "Data Analyst"
description: "Analyzes data and creates reports"
system_prompt: |
  You are a data analyst at {company_name}.
  Your expertise: data analysis, visualization, reporting.
  Team: {team_members}
  Delegates: {delegates}
default_tools:
  - code_exec
  - file_io
can_delegate_to: []
reports_to: cto
```

## Auto-Upgrade

Agent Company AI can upgrade itself automatically — researching AI agent trends, planning improvements, generating code, validating, and publishing to PyPI — all within a configurable budget.

### How It Works

The auto-upgrade pipeline runs in 6 stages:

1. **Research** — Searches the web for AI agent trends via DuckDuckGo
2. **Plan** — Claude Sonnet picks the best improvement and writes an implementation plan
3. **Code** — Generates new tool files or config changes following existing patterns
4. **Validate** — `ast.parse()` syntax check, import smoke test, secret scan, size limits, path restrictions
5. **Publish** — Bumps version, builds, uploads to PyPI, commits and pushes to GitHub
6. **Changelog** — Auto-generates a `CHANGELOG.md` entry

### Safety Guardrails

| Guardrail | Description |
|-----------|-------------|
| **Budget cap** | Hard $10/run limit (configurable). Every LLM call is tracked |
| **Path restrictions** | Can only touch `tools/`, `roles/`, `config.py`, `README.md`, `pyproject.toml` |
| **Denied paths** | Never touches `core/`, `cli/`, `storage/`, `auto_upgrade/`, `.github/` |
| **Syntax validation** | `ast.parse()` on every generated Python file |
| **Import smoke test** | Verifies tools register correctly before publishing |
| **Auto-revert** | `git checkout -- .` on any failure |
| **Size limits** | Max 500 lines/file, 2000 lines total per upgrade |
| **No new deps** | Generated code can only use existing dependencies |
| **Retry with feedback** | Up to 3 attempts, passing validation errors back to Sonnet |

### CLI Usage

```bash
# Full upgrade (research → publish)
agent-company-ai upgrade

# Dry run — runs the full pipeline but skips publish
agent-company-ai upgrade --dry-run

# Custom budget
agent-company-ai upgrade --budget 5.0
```

### Standalone Script

```bash
python scripts/auto_upgrade.py
python scripts/auto_upgrade.py --dry-run
python scripts/auto_upgrade.py --budget 5
```

### Scheduled Runs (GitHub Actions)

The included workflow (`.github/workflows/auto-upgrade.yml`) runs the pipeline automatically:

- **Wednesday 3 AM UTC**
- **Saturday 3 AM UTC**
- **Manual trigger** via `workflow_dispatch`

Required GitHub secrets: `ANTHROPIC_API_KEY`, `PYPI_TOKEN`.

### Cost

Each run uses Claude Sonnet (~$3/$15 per 1M input/output tokens). Typical cost: **$0.50–$1.50 per run**, well within the $10 default budget.

## Donate

If this project is useful to you, consider supporting development:

**ETH:** `0x0448F896Fc878DF56046Aa0090D05Dd01F28b338`

## Enterprise Customization & Consulting

**"We build AI agent workforce for your company"**

- **Implementation fee:** $10k-100k+
- **Ongoing support:** $2k-10k/month

Please contact gobeyondfj@gmail.com

## License

MIT
