"""Configuration for the auto-upgrade system."""

from __future__ import annotations

import subprocess
from dataclasses import dataclass, field
from pathlib import Path


def _find_project_root() -> Path:
    """Detect project root from git."""
    try:
        out = subprocess.check_output(
            ["git", "rev-parse", "--show-toplevel"],
            stderr=subprocess.DEVNULL,
            text=True,
        )
        return Path(out.strip())
    except (subprocess.CalledProcessError, FileNotFoundError):
        return Path.cwd()


@dataclass
class UpgradeConfig:
    """Settings for a single auto-upgrade run."""

    max_budget_usd: float = 10.0
    model: str = "claude-sonnet-4-5-20250929"
    max_retries: int = 3
    project_root: Path = field(default_factory=_find_project_root)

    # Paths the upgrade is allowed to touch
    allowed_paths: list[str] = field(
        default_factory=lambda: [
            "src/agent_company_ai/tools/",
            "src/agent_company_ai/roles/",
            "src/agent_company_ai/config.py",
            "README.md",
            "pyproject.toml",
        ]
    )

    # Paths the upgrade must never touch
    denied_paths: list[str] = field(
        default_factory=lambda: [
            "src/agent_company_ai/core/",
            "src/agent_company_ai/cli/",
            "src/agent_company_ai/storage/",
            "src/agent_company_ai/auto_upgrade/",
            ".github/",
        ]
    )

    pypi_token_env: str = "PYPI_TOKEN"
    anthropic_key_env: str = "ANTHROPIC_API_KEY"

    # Search queries for trend research
    search_queries: list[str] = field(
        default_factory=lambda: [
            "AI agent tools trending 2026",
            "AI automation business tools new",
            "Python AI agent framework features",
        ]
    )
