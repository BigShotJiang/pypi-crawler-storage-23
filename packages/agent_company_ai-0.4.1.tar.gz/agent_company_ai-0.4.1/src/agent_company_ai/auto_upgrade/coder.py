"""Generate code changes from an approved plan."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from anthropic import AsyncAnthropic

    from .config import UpgradeConfig
    from .cost_guard import CostGuard

_CODE_PROMPT = """\
You are a Python developer implementing a feature for "agent-company-ai".

## Plan
{plan}

## Existing file contents (for context)
{existing_files}

## Pattern reference
New tool files must follow this exact pattern:

```python
\"\"\"<description>.\"\"\"

from agent_company_ai.tools.registry import tool

@tool(
    "<tool_name>",
    "<Tool description for the LLM>",
    {{
        "type": "object",
        "properties": {{
            "param": {{"type": "string", "description": "..."}},
        }},
        "required": ["param"],
    }},
)
async def <tool_name>(param: str) -> str:
    ...
```

## Rules
- Only use imports from the standard library or these installed packages:
  anthropic, openai, typer, fastapi, uvicorn, websockets, pydantic, pyyaml,
  aiosqlite, rich, httpx, jinja2, web3, eth_account
- Every new tool MUST use the @tool() decorator
- Return ONLY valid JSON (no markdown fences)

Return JSON:
{{
  "new_files": {{
    "relative/path.py": "full file content as a string"
  }},
  "edits": [
    {{
      "path": "relative/path.py",
      "old": "exact string to find",
      "new": "replacement string"
    }}
  ],
  "version_bump": "patch"
}}
"""


async def generate_code(
    client: AsyncAnthropic,
    cost_guard: CostGuard,
    config: UpgradeConfig,
    plan: dict,
    existing_files: dict[str, str],
    validation_errors: list[str] | None = None,
) -> dict:
    """Generate code changes to implement the planned improvement.

    *existing_files* maps relative paths to their current content.
    *validation_errors* (if any) are from a previous attempt.

    Returns a dict with ``new_files``, ``edits``, and ``version_bump``.
    """
    existing_text = ""
    for path, content in existing_files.items():
        existing_text += f"\n### {path}\n```python\n{content}\n```\n"

    plan_text = json.dumps(plan, indent=2)

    extra = ""
    if validation_errors:
        extra = (
            "\n\n## Previous attempt failed validation. Fix these errors:\n"
            + "\n".join(f"- {e}" for e in validation_errors)
        )

    prompt = _CODE_PROMPT.format(
        plan=plan_text,
        existing_files=existing_text or "(no existing files to modify)",
    ) + extra

    estimated = cost_guard._cost_for(len(prompt) // 4, 4000)
    if not cost_guard.check(estimated):
        return {"new_files": {}, "edits": [], "version_bump": "patch", "error": "budget_exceeded"}

    response = await client.messages.create(
        model=config.model,
        max_tokens=4096,
        messages=[{"role": "user", "content": prompt}],
    )

    cost_guard.record(
        response.usage.input_tokens,
        response.usage.output_tokens,
        label="generate_code",
    )

    block = response.content[0]
    text = (block.text if hasattr(block, "text") else "").strip()  # type: ignore[union-attr]
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)

    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return {"new_files": {}, "edits": [], "version_bump": "patch", "raw": text}


def read_existing_files(plan: dict, project_root: Path) -> dict[str, str]:
    """Read files referenced in the plan so Sonnet has context."""
    files: dict[str, str] = {}
    paths = [f["path"] for f in plan.get("files_to_modify", [])]
    for rel in paths:
        full = project_root / rel
        if full.is_file():
            try:
                files[rel] = full.read_text(encoding="utf-8")
            except Exception:
                pass
    return files
