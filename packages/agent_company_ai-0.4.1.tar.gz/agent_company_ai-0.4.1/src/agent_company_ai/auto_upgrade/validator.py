"""Validate generated code changes before applying them."""

from __future__ import annotations

import ast
import re
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .config import UpgradeConfig

# Patterns that suggest leaked secrets
_SECRET_PATTERNS = [
    re.compile(r"""(?:api[_-]?key|secret|token|password)\s*=\s*["'][^"']{8,}["']""", re.IGNORECASE),
    re.compile(r"sk-[a-zA-Z0-9]{20,}"),
    re.compile(r"ghp_[a-zA-Z0-9]{36}"),
    re.compile(r"AKIA[0-9A-Z]{16}"),
]

MAX_LINES_PER_FILE = 500
MAX_TOTAL_LINES = 2000


def validate_changes(
    changes: dict,
    config: UpgradeConfig,
) -> tuple[bool, list[str]]:
    """Validate generated code changes.

    Returns ``(passed, errors)`` where *errors* is empty on success.
    """
    errors: list[str] = []

    new_files: dict[str, str] = changes.get("new_files", {})
    edits: list[dict] = changes.get("edits", [])

    # --- 1. Path safety ---
    all_paths = list(new_files.keys()) + [e["path"] for e in edits]
    for p in all_paths:
        if any(p.startswith(d) for d in config.denied_paths):
            errors.append(f"Denied path: {p}")
        if not any(p.startswith(a) for a in config.allowed_paths):
            errors.append(f"Path not in allowed list: {p}")

    # --- 2. Syntax check (Python files only) ---
    total_lines = 0
    for path, content in new_files.items():
        if path.endswith(".py"):
            try:
                ast.parse(content, filename=path)
            except SyntaxError as exc:
                errors.append(f"Syntax error in {path}: {exc}")
            lines = content.count("\n") + 1
            if lines > MAX_LINES_PER_FILE:
                errors.append(
                    f"File too large: {path} has {lines} lines (max {MAX_LINES_PER_FILE})"
                )
            total_lines += lines

    # Count edit additions towards total
    for edit in edits:
        total_lines += edit.get("new", "").count("\n") + 1

    if total_lines > MAX_TOTAL_LINES:
        errors.append(
            f"Total changes too large: {total_lines} lines (max {MAX_TOTAL_LINES})"
        )

    # --- 3. No secrets ---
    for path, content in new_files.items():
        for pat in _SECRET_PATTERNS:
            if pat.search(content):
                errors.append(f"Possible secret/key in {path}")
                break

    for edit in edits:
        new_text = edit.get("new", "")
        for pat in _SECRET_PATTERNS:
            if pat.search(new_text):
                errors.append(f"Possible secret/key in edit for {edit['path']}")
                break

    # --- 4. Tool decorator check ---
    for path, content in new_files.items():
        if path.startswith("src/agent_company_ai/tools/") and path.endswith(".py"):
            if "@tool(" not in content:
                errors.append(
                    f"Tool file {path} missing @tool() decorator"
                )

    # --- 5. No new dependency imports ---
    _allowed_packages = {
        "anthropic", "openai", "typer", "fastapi", "uvicorn", "websockets",
        "pydantic", "pyyaml", "yaml", "aiosqlite", "rich", "httpx", "jinja2",
        "web3", "eth_account",
        # stdlib
        "os", "sys", "re", "json", "ast", "math", "time", "datetime",
        "pathlib", "subprocess", "importlib", "asyncio", "hashlib", "uuid",
        "base64", "urllib", "html", "io", "typing", "dataclasses",
        "collections", "functools", "itertools", "contextlib", "logging",
        "textwrap", "shutil", "tempfile", "csv", "string", "secrets",
        "agent_company_ai",
    }
    for path, content in new_files.items():
        if not path.endswith(".py"):
            continue
        for line in content.splitlines():
            line = line.strip()
            if line.startswith("import ") or line.startswith("from "):
                pkg = _top_level_package(line)
                if pkg and pkg not in _allowed_packages:
                    errors.append(
                        f"Disallowed import '{pkg}' in {path}"
                    )

    return (len(errors) == 0, errors)


def _top_level_package(import_line: str) -> str | None:
    """Extract top-level package name from an import statement."""
    import_line = import_line.strip()
    if import_line.startswith("from "):
        parts = import_line.split()
        if len(parts) >= 2:
            return parts[1].split(".")[0]
    elif import_line.startswith("import "):
        parts = import_line.split()
        if len(parts) >= 2:
            return parts[1].split(".")[0].rstrip(",")
    return None


def verify_tool_imports(project_root: Path, new_files: dict[str, str]) -> list[str]:
    """Smoke-test that new tool modules can be imported.

    This writes files temporarily, attempts import, then cleans up on failure.
    Returns a list of import errors (empty means success).
    """
    import importlib
    import sys

    errors: list[str] = []
    written: list[Path] = []

    try:
        for rel, content in new_files.items():
            if not rel.startswith("src/agent_company_ai/tools/"):
                continue
            full = project_root / rel
            full.parent.mkdir(parents=True, exist_ok=True)
            full.write_text(content, encoding="utf-8")
            written.append(full)

            # Build module name from path
            module = rel.replace("src/", "").replace("/", ".").removesuffix(".py")
            # Clear from cache so we get a fresh import
            sys.modules.pop(module, None)
            try:
                importlib.import_module(module)
            except Exception as exc:
                errors.append(f"Import failed for {module}: {exc}")
    finally:
        # Clean up files that were written for the smoke test
        if errors:
            for f in written:
                try:
                    f.unlink(missing_ok=True)
                except Exception:
                    pass

    return errors
