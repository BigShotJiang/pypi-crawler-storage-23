"""Auto-generate CHANGELOG.md entries."""

from __future__ import annotations

import datetime
from pathlib import Path


def generate_changelog_entry(
    improvement: str,
    version: str,
    project_root: Path | None = None,
) -> str:
    """Create a changelog entry and prepend it to CHANGELOG.md.

    Returns the entry text.
    """
    today = datetime.date.today().isoformat()
    entry = f"## v{version} — {today}\n\n- {improvement}\n"

    if project_root is None:
        return entry

    changelog = project_root / "CHANGELOG.md"
    if changelog.is_file():
        existing = changelog.read_text(encoding="utf-8")
        # Insert after the first heading line (e.g. "# Changelog\n")
        lines = existing.split("\n", 1)
        if len(lines) == 2:
            changelog.write_text(
                f"{lines[0]}\n\n{entry}\n{lines[1]}",
                encoding="utf-8",
            )
        else:
            changelog.write_text(f"{existing}\n\n{entry}", encoding="utf-8")
    else:
        changelog.write_text(f"# Changelog\n\n{entry}", encoding="utf-8")

    return entry
