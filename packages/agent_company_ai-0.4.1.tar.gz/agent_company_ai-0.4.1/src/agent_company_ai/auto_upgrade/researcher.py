"""Trend research via web search + LLM analysis."""

from __future__ import annotations

import json
import re
from typing import TYPE_CHECKING

import httpx

if TYPE_CHECKING:
    from anthropic import AsyncAnthropic

    from .config import UpgradeConfig
    from .cost_guard import CostGuard

# ---------------------------------------------------------------------------
# DuckDuckGo HTML scraping (mirrors web_search.py pattern)
# ---------------------------------------------------------------------------
_SNIPPET_RE = re.compile(
    r'class="result__snippet"[^>]*>(.*?)</(?:a|td|div|span)',
    re.DOTALL,
)
_TITLE_RE = re.compile(
    r'class="result__a"[^>]*>(.*?)</a>',
    re.DOTALL,
)
_TAG_RE = re.compile(r"<[^>]+>")


def _strip_tags(html: str) -> str:
    text = _TAG_RE.sub("", html)
    for old, new in (
        ("&amp;", "&"), ("&lt;", "<"), ("&gt;", ">"),
        ("&quot;", '"'), ("&#x27;", "'"), ("&nbsp;", " "),
    ):
        text = text.replace(old, new)
    return text.strip()


async def _search(query: str) -> list[dict]:
    """Run a DuckDuckGo HTML search and return top-5 results."""
    results: list[dict] = []
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.get(
                "https://html.duckduckgo.com/html/",
                params={"q": query},
                headers={
                    "User-Agent": "Mozilla/5.0 (compatible; AgentCompanyAI/0.4)"
                },
            )
            resp.raise_for_status()
            html = resp.text
            snippets = _SNIPPET_RE.findall(html)
            titles = _TITLE_RE.findall(html)
            for i, snippet in enumerate(snippets[:5]):
                clean = _strip_tags(snippet)
                if not clean:
                    continue
                title = _strip_tags(titles[i]) if i < len(titles) else ""
                results.append({"title": title, "snippet": clean})
    except Exception:
        pass  # Non-fatal: we'll analyse whatever we got
    return results


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

_RESEARCH_PROMPT = """\
You are a trend researcher for an AI agent framework called "agent-company-ai".
The framework lets users spin up AI-powered businesses with tools for email,
payments (Stripe, Gumroad), web search, social media, invoicing, landing pages,
browser automation, lead prospecting, and content generation.

Below are recent web search results about AI agent trends:

{search_results}

Analyse these trends and identify 3-5 concrete, small improvements that could
be added to the framework. Each improvement must be:
- Implementable as a single new tool OR a small config/role change
- Useful for AI-powered business automation
- Not duplicating existing tools (listed below)

Existing tools: {existing_tools}

Return ONLY valid JSON (no markdown fences):
{{
  "trends": ["trend 1 summary", "trend 2 summary", ...],
  "suggested_improvements": [
    {{
      "title": "Short title",
      "description": "1-2 sentence description of what to build",
      "difficulty": "low|medium",
      "impact": "high|medium|low"
    }}
  ]
}}
"""


async def research_trends(
    client: AsyncAnthropic,
    cost_guard: CostGuard,
    config: UpgradeConfig,
    existing_tools: list[str] | None = None,
) -> dict:
    """Search the web for AI-agent trends and ask Sonnet to pick improvements.

    Returns a dict with ``trends`` and ``suggested_improvements`` keys.
    """
    # Gather search results for all configured queries
    all_results: list[dict] = []
    for query in config.search_queries:
        all_results.extend(await _search(query))

    if not all_results:
        all_results = [
            {"title": "Fallback", "snippet": "No search results available."}
        ]

    search_text = "\n".join(
        f"- {r['title']}: {r['snippet']}" for r in all_results
    )

    prompt = _RESEARCH_PROMPT.format(
        search_results=search_text,
        existing_tools=", ".join(existing_tools or []),
    )

    # Check budget before calling
    estimated = cost_guard._cost_for(len(prompt) // 4, 2000)
    if not cost_guard.check(estimated):
        return {"trends": [], "suggested_improvements": []}

    response = await client.messages.create(
        model=config.model,
        max_tokens=2048,
        messages=[{"role": "user", "content": prompt}],
    )

    # Record actual usage
    cost_guard.record(
        response.usage.input_tokens,
        response.usage.output_tokens,
        label="research_trends",
    )

    # Parse JSON from response
    block = response.content[0]
    text = (block.text if hasattr(block, "text") else "").strip()  # type: ignore[union-attr]
    # Strip markdown fences if present
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)

    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return {"trends": [], "suggested_improvements": [], "raw": text}
