"""Plan the single best improvement from research results."""

from __future__ import annotations

import json
import re
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from anthropic import AsyncAnthropic

    from .config import UpgradeConfig
    from .cost_guard import CostGuard

_PLAN_PROMPT = """\
You are a software architect for the "agent-company-ai" Python framework.
Tools live in src/agent_company_ai/tools/ and use a @tool decorator pattern.
Roles (YAML) live in src/agent_company_ai/roles/.

Research suggested these improvements:
{suggestions}

Current tool names (do NOT duplicate): {current_tools}

Pick the SINGLE best improvement (prefer high-impact + low-difficulty).
Write a detailed implementation plan.

Rules:
- New tools go in src/agent_company_ai/tools/<name>.py
- New roles go in src/agent_company_ai/roles/<name>.yaml
- Config changes go in src/agent_company_ai/config.py
- You may update README.md or pyproject.toml
- NEVER touch: core/, cli/, storage/, auto_upgrade/, .github/
- Do NOT add new pip dependencies — only use existing ones
- Follow the existing @tool() decorator pattern exactly

Return ONLY valid JSON (no markdown fences):
{{
  "chosen_improvement": "Title of chosen improvement",
  "rationale": "Why this was chosen",
  "plan": "Detailed step-by-step implementation plan",
  "files_to_create": [
    {{"path": "relative/path.py", "description": "What this file does"}}
  ],
  "files_to_modify": [
    {{"path": "relative/path.py", "description": "What changes to make"}}
  ],
  "estimated_lines": 150
}}
"""


async def plan_upgrade(
    client: AsyncAnthropic,
    cost_guard: CostGuard,
    config: UpgradeConfig,
    research: dict,
    current_tools: list[str],
) -> dict:
    """Choose the best improvement and produce an implementation plan.

    Returns a dict with ``chosen_improvement``, ``plan``, ``files_to_create``,
    ``files_to_modify``, and ``estimated_lines``.
    """
    suggestions = json.dumps(
        research.get("suggested_improvements", []), indent=2
    )

    prompt = _PLAN_PROMPT.format(
        suggestions=suggestions,
        current_tools=", ".join(current_tools),
    )

    estimated = cost_guard._cost_for(len(prompt) // 4, 3000)
    if not cost_guard.check(estimated):
        return {
            "chosen_improvement": "",
            "plan": "",
            "files_to_create": [],
            "files_to_modify": [],
            "estimated_lines": 0,
            "error": "budget_exceeded",
        }

    response = await client.messages.create(
        model=config.model,
        max_tokens=3000,
        messages=[{"role": "user", "content": prompt}],
    )

    cost_guard.record(
        response.usage.input_tokens,
        response.usage.output_tokens,
        label="plan_upgrade",
    )

    block = response.content[0]
    text = (block.text if hasattr(block, "text") else "").strip()  # type: ignore[union-attr]
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)

    try:
        plan = json.loads(text)
    except json.JSONDecodeError:
        return {
            "chosen_improvement": "",
            "plan": "",
            "files_to_create": [],
            "files_to_modify": [],
            "estimated_lines": 0,
            "raw": text,
        }

    # Validate paths against denied list
    all_paths = [f["path"] for f in plan.get("files_to_create", [])] + [
        f["path"] for f in plan.get("files_to_modify", [])
    ]
    for path in all_paths:
        if any(path.startswith(d) for d in config.denied_paths):
            return {
                **plan,
                "error": f"Plan touches denied path: {path}",
            }

    return plan
