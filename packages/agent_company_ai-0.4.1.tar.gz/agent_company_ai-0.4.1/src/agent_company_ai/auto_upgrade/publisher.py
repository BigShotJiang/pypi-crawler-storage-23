"""Apply changes, build, and publish to PyPI."""

from __future__ import annotations

import os
import re
import subprocess
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .config import UpgradeConfig


def _run(cmd: list[str], cwd: Path, check: bool = True) -> subprocess.CompletedProcess:
    return subprocess.run(
        cmd,
        cwd=cwd,
        capture_output=True,
        text=True,
        check=check,
        timeout=120,
    )


def _bump_version(pyproject: Path, bump: str = "patch") -> str:
    """Bump the version in pyproject.toml and return the new version string."""
    text = pyproject.read_text(encoding="utf-8")
    match = re.search(r'version\s*=\s*"(\d+\.\d+\.\d+)"', text)
    if not match:
        raise RuntimeError("Could not find version in pyproject.toml")

    old = match.group(1)
    major, minor, patch = (int(x) for x in old.split("."))
    if bump == "minor":
        minor += 1
        patch = 0
    else:
        patch += 1

    new_version = f"{major}.{minor}.{patch}"
    text = text.replace(f'version = "{old}"', f'version = "{new_version}"')
    pyproject.write_text(text, encoding="utf-8")
    return new_version


def _apply_changes(project_root: Path, changes: dict) -> list[Path]:
    """Write new files and apply edits.  Returns list of touched paths."""
    touched: list[Path] = []

    for rel, content in changes.get("new_files", {}).items():
        full = project_root / rel
        full.parent.mkdir(parents=True, exist_ok=True)
        full.write_text(content, encoding="utf-8")
        touched.append(full)

    for edit in changes.get("edits", []):
        full = project_root / edit["path"]
        if not full.is_file():
            continue
        text = full.read_text(encoding="utf-8")
        if edit["old"] in text:
            text = text.replace(edit["old"], edit["new"], 1)
            full.write_text(text, encoding="utf-8")
            touched.append(full)

    return touched


def _revert(project_root: Path) -> None:
    """Revert all uncommitted changes."""
    _run(["git", "checkout", "--", "."], cwd=project_root, check=False)
    # Also remove untracked files that we may have created
    _run(["git", "clean", "-fd", "src/agent_company_ai/tools/"], cwd=project_root, check=False)


def publish(
    config: UpgradeConfig,
    changes: dict,
    dry_run: bool = False,
) -> dict:
    """Apply changes, bump version, build, and publish.

    If *dry_run* is True the build step runs but upload and git push are skipped.

    Returns a result dict with version, published flag, and optional commit hash.
    """
    root = config.project_root
    pyproject = root / "pyproject.toml"
    result: dict = {"version": "", "published": False, "commit": "", "dry_run": dry_run}

    try:
        # 1. Apply code changes
        _apply_changes(root, changes)

        # 2. Bump version
        bump_type = changes.get("version_bump", "patch")
        new_version = _bump_version(pyproject, bump_type)
        result["version"] = new_version

        # 3. Smoke test — make sure tools still register
        _run(
            [
                "python", "-c",
                (
                    "from agent_company_ai.tools.registry import ToolRegistry; "
                    "import agent_company_ai.tools; "
                    "print('tools:', len(ToolRegistry.get().list_names()))"
                ),
            ],
            cwd=root,
        )

        if dry_run:
            result["published"] = False
            return result

        # 4. Build
        dist = root / "dist"
        if dist.exists():
            for f in dist.iterdir():
                f.unlink()
        _run(["python", "-m", "build"], cwd=root)

        # 5. Upload to PyPI
        token = os.environ.get(config.pypi_token_env, "")
        if token:
            _run(
                [
                    "python", "-m", "twine", "upload", "dist/*",
                    "-u", "__token__", "-p", token,
                    "--non-interactive",
                ],
                cwd=root,
            )
            result["published"] = True
        else:
            result["published"] = False
            result["skip_reason"] = "PYPI_TOKEN not set"

        # 6. Git commit & push
        _run(["git", "add", "-A"], cwd=root)
        _run(
            ["git", "commit", "-m", f"Auto-upgrade to v{new_version}"],
            cwd=root,
        )
        commit = _run(["git", "rev-parse", "--short", "HEAD"], cwd=root)
        result["commit"] = commit.stdout.strip()

        _run(["git", "push"], cwd=root, check=False)

    except Exception as exc:
        result["error"] = str(exc)
        _revert(root)

    return result
