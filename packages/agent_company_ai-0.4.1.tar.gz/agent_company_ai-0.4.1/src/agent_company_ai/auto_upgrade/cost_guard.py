"""Budget enforcement for auto-upgrade LLM calls."""

from __future__ import annotations


class BudgetExceededError(Exception):
    """Raised when the cumulative cost exceeds the allowed budget."""


class CostGuard:
    """Track and enforce a per-run dollar budget for Anthropic API calls.

    Pricing (Claude Sonnet):
        Input:  $3.00 per 1M tokens
        Output: $15.00 per 1M tokens
    """

    INPUT_PRICE_PER_TOKEN: float = 3.0 / 1_000_000
    OUTPUT_PRICE_PER_TOKEN: float = 15.0 / 1_000_000

    def __init__(self, max_budget_usd: float = 10.0) -> None:
        self.max_budget_usd = max_budget_usd
        self.total_cost: float = 0.0
        self.total_input_tokens: int = 0
        self.total_output_tokens: int = 0
        self.calls: list[dict] = []

    def _cost_for(self, input_tokens: int, output_tokens: int) -> float:
        return (
            input_tokens * self.INPUT_PRICE_PER_TOKEN
            + output_tokens * self.OUTPUT_PRICE_PER_TOKEN
        )

    def record(self, input_tokens: int, output_tokens: int, label: str = "") -> float:
        """Record token usage from an API call.  Returns the call cost."""
        cost = self._cost_for(input_tokens, output_tokens)
        self.total_cost += cost
        self.total_input_tokens += input_tokens
        self.total_output_tokens += output_tokens
        self.calls.append(
            {
                "label": label,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "cost": round(cost, 6),
                "cumulative": round(self.total_cost, 6),
            }
        )
        if self.total_cost > self.max_budget_usd:
            raise BudgetExceededError(
                f"Budget exceeded: ${self.total_cost:.4f} > ${self.max_budget_usd:.2f}"
            )
        return cost

    def remaining(self) -> float:
        """Return remaining budget in USD."""
        return max(0.0, self.max_budget_usd - self.total_cost)

    def check(self, estimated_cost: float) -> bool:
        """Return True if *estimated_cost* fits within the remaining budget."""
        return estimated_cost <= self.remaining()

    def summary(self) -> dict:
        """Return a JSON-serialisable summary of spending."""
        return {
            "total_cost_usd": round(self.total_cost, 6),
            "remaining_usd": round(self.remaining(), 6),
            "total_input_tokens": self.total_input_tokens,
            "total_output_tokens": self.total_output_tokens,
            "calls": self.calls,
        }
