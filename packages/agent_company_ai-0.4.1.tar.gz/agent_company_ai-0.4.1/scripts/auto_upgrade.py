#!/usr/bin/env python3
"""Auto-upgrade orchestrator. Run directly or via GitHub Actions.

Usage:
    python scripts/auto_upgrade.py              # full run (research → publish)
    python scripts/auto_upgrade.py --dry-run    # skip publish step
    python scripts/auto_upgrade.py --budget 5   # override budget cap
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from pathlib import Path

# Ensure the project source is importable when running the script directly
_root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_root / "src"))

from anthropic import AsyncAnthropic  # noqa: E402

from agent_company_ai.auto_upgrade.changelog import generate_changelog_entry  # noqa: E402
from agent_company_ai.auto_upgrade.coder import generate_code, read_existing_files  # noqa: E402
from agent_company_ai.auto_upgrade.config import UpgradeConfig  # noqa: E402
from agent_company_ai.auto_upgrade.cost_guard import CostGuard  # noqa: E402
from agent_company_ai.auto_upgrade.planner import plan_upgrade  # noqa: E402
from agent_company_ai.auto_upgrade.publisher import publish  # noqa: E402
from agent_company_ai.auto_upgrade.researcher import research_trends  # noqa: E402
from agent_company_ai.auto_upgrade.validator import validate_changes, verify_tool_imports  # noqa: E402


def _get_current_tools() -> list[str]:
    """Return names of all currently registered tools."""
    try:
        from agent_company_ai.tools.registry import ToolRegistry
        import agent_company_ai.tools  # noqa: F401 — triggers tool registration
        return ToolRegistry.get().list_names()
    except Exception:
        return []


def _save_log(log: dict, root: Path) -> None:
    """Write run log to upgrade_log.json."""
    path = root / "upgrade_log.json"
    path.write_text(json.dumps(log, indent=2, default=str), encoding="utf-8")


async def main(dry_run: bool = False, budget: float = 10.0) -> None:
    config = UpgradeConfig(max_budget_usd=budget)
    guard = CostGuard(config.max_budget_usd)
    client = AsyncAnthropic()

    log: dict = {"stages": {}, "success": False}

    try:
        # ── Stage 1: Research ────────────────────────────────────────
        print("[1/6] Researching AI agent trends …")
        current_tools = _get_current_tools()
        research = await research_trends(client, guard, config, existing_tools=current_tools)
        log["stages"]["research"] = research
        suggestions = research.get("suggested_improvements", [])
        if not suggestions:
            print("  No improvements suggested. Exiting.")
            log["stages"]["research"]["skip"] = "no suggestions"
            _save_log(log, config.project_root)
            return
        print(f"  Found {len(suggestions)} candidate improvements.")

        # ── Stage 2: Plan ────────────────────────────────────────────
        print("[2/6] Planning upgrade …")
        plan = await plan_upgrade(client, guard, config, research, current_tools)
        log["stages"]["plan"] = plan
        if plan.get("error"):
            print(f"  Planning failed: {plan['error']}")
            _save_log(log, config.project_root)
            return
        print(f"  Chosen: {plan.get('chosen_improvement', '?')}")

        # ── Stage 3: Generate code ───────────────────────────────────
        print("[3/6] Generating code …")
        existing = read_existing_files(plan, config.project_root)
        changes = await generate_code(client, guard, config, plan, existing)
        log["stages"]["code"] = {
            "new_files": list(changes.get("new_files", {}).keys()),
            "edits": len(changes.get("edits", [])),
        }

        # ── Stage 4: Validate (with retries) ────────────────────────
        print("[4/6] Validating changes …")
        ok, errors = validate_changes(changes, config)
        attempts = 1
        while not ok and attempts < config.max_retries:
            print(f"  Validation failed ({len(errors)} errors), retrying …")
            changes = await generate_code(
                client, guard, config, plan, existing, validation_errors=errors
            )
            ok, errors = validate_changes(changes, config)
            attempts += 1

        if not ok:
            print(f"  Validation failed after {attempts} attempts:")
            for e in errors:
                print(f"    - {e}")
            log["stages"]["validation"] = {"passed": False, "errors": errors}
            _save_log(log, config.project_root)
            return

        # Import smoke test
        import_errors = verify_tool_imports(config.project_root, changes.get("new_files", {}))
        if import_errors:
            print("  Import smoke test failed:")
            for e in import_errors:
                print(f"    - {e}")
            log["stages"]["validation"] = {"passed": False, "import_errors": import_errors}
            _save_log(log, config.project_root)
            return

        log["stages"]["validation"] = {"passed": True, "attempts": attempts}
        print("  Validation passed.")

        # ── Stage 5: Publish ─────────────────────────────────────────
        print("[5/6] Publishing …" if not dry_run else "[5/6] Dry run — skipping publish.")
        result = publish(config, changes, dry_run=dry_run)
        log["stages"]["publish"] = result
        if result.get("error"):
            print(f"  Publish failed: {result['error']}")
            _save_log(log, config.project_root)
            return

        # ── Stage 6: Changelog ───────────────────────────────────────
        print("[6/6] Updating changelog …")
        entry = generate_changelog_entry(
            plan.get("chosen_improvement", "Automated improvement"),
            result.get("version", "0.0.0"),
            project_root=config.project_root,
        )
        log["stages"]["changelog"] = entry

        log["success"] = True
        log["cost"] = guard.summary()
        _save_log(log, config.project_root)

        version = result.get("version", "?")
        cost = guard.total_cost
        published = "published" if result.get("published") else "built (dry run)"
        print(f"\nUpgrade complete: v{version} — {published} | Cost: ${cost:.2f}")

    except Exception as exc:
        log["error"] = str(exc)
        log["cost"] = guard.summary()
        _save_log(log, config.project_root)
        print(f"\nUpgrade failed: {exc}")
        raise


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Auto-upgrade agent-company-ai")
    parser.add_argument("--dry-run", action="store_true", help="Skip publish step")
    parser.add_argument("--budget", type=float, default=10.0, help="Max budget in USD")
    args = parser.parse_args()
    asyncio.run(main(dry_run=args.dry_run, budget=args.budget))
