function(element) { element.focus(); }
// sourceURL=__InjectedScript_WebDriver_FocusElement.js
