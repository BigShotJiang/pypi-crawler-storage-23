"""Entry point for running uijit as a module."""

from uijit.cli import main

if __name__ == "__main__":
    main()
