"""Re-export Hook Protocol from the canonical location in src.protocols."""
from everstaff.protocols import Hook

__all__ = ["Hook"]
