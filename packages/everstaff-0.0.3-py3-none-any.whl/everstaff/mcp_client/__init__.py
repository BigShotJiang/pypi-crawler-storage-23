"""MCP subsystem — connection management, tool wrapping, and provider."""
