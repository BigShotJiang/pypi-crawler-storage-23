COOP_SHARE_PRODUCT_CATEG_REF = "cooperator.product_category_company_share"
COOP_VOLUNTARY_SHARE_PRODUCT_CATEG_REF = (
    "energy_communities_cooperator.product_category_company_voluntary_share"
)
