# Energy Communities Cooperator

## Changelog

## Changelog

### 2026-01-19 (v16.0.0.6.2)

- fix formula voluntary share interest return

### 2026-01-18 (v16.0.0.6.1)

- fix the count of the days between the start and end period of a share
- fix the calculation of the share day one year before
- more verbose and descriptions in interest calculations

### 2026-01-10 (v16.0.0.6.0)

- Add wizard to send emails to a cooperator
- fix correct taxes in product
- Improvement translations

### 2026-01-30 (v16.0.0.5.4)

- Fix translations for:

  - msgid "Sell Back"
  - msgid "Transfer"
  - sentence in basc language for msg:
    model:mail.template,body_html:cooperator.email_template_confirmation
  - variable to choose the correct iban account
  - msgid for model:mail.template,body_html:cooperator.email_template_release_capital

### 2026-01-30 (v16.0.0.5.3)

- Fix email.template cooperator.email_template_confirmation for field email_cc

### 2026-01-29 (v16.0.0.5.2)

- Update email.template cooperator.email_template_confirmation for field email_cc

### 2026-01-15 (v16.0.0.5.1)

- numberof_effective_inviteds,numberof_effective_members and
  numberof_effective_cooperators are fixed

### 2025-11-12 (v16.0.0.5.0)

- Moves all new fields of res company model to res_config_setting

### 2025-11-03 (v16.0.0.4.1)

- Adjustments for new public form for new community creation

### 2025-10-22 (v16.0.0.4.0)

- Improved MulltiCompanyEasyCreationWizard

### 2025-09-23 (v16.0.0.3.7)

- fix added new translations

### 2025-09-23 (v16.0.0.3.6)

- Fix translations

### 2025-05-21

- Added Readme
