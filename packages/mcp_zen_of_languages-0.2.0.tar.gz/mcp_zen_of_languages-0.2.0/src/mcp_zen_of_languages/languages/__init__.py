"""Language-specific analyzers, detectors, and rule definitions."""

__all__: list[str] = []
