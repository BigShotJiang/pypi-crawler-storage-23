"""Javascript module."""

from mcp_zen_of_languages.languages.javascript.analyzer import JavaScriptAnalyzer

__all__ = ["JavaScriptAnalyzer"]
