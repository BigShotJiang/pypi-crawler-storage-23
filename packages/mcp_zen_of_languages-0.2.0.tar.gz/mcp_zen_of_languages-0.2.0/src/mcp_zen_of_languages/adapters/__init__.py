"""Adapters module."""

# adapters package for mapping rules to analyzer models
