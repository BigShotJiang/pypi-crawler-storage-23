"""Bundled default guides and prompts for keephive."""
