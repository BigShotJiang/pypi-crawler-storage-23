# Playwright E2E Architect Memory — mcp-tap

## Project: mcp-tap (CLI/MCP server — no web UI)
- No frontend. This agent is unlikely to be needed for this project.
