"""CLI entrypoint for benchmark utilities."""

from __future__ import annotations

from mcp_tap.benchmark.recommendation import run_cli

raise SystemExit(run_cli())
