"""Benchmark package for recommendation quality gates."""

from __future__ import annotations
