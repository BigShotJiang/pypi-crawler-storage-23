"""
基金模块

提供基金数据的截面和时序查询功能。

Examples:
    >>> from kepler.wind import Wind
    >>> w = Wind()
    >>> w.fund.history("000001.OF")                # 时序：基金净值
    >>> w.fund.filter(type="股票型")               # 筛选基金
"""

from functools import lru_cache
from typing import Optional, Union, List, Set

import pandas as pd
from sqlalchemy import func

from kepler.wind.db import get_db
from kepler.wind.pulse import CALENDAR


class FundAPI:
    """基金 API

    提供基金数据的截面和时序查询功能。
    """

    @property
    def db(self):
        return get_db()

    def history(
        self,
        codes: Optional[Union[str, List[str], Set[str]]] = None,
        start: str = "20010101",
        end: str = "20990101"
    ) -> pd.DataFrame:
        """时序：基金净值历史

        Args:
            codes: 基金代码，None 表示全部
            start: 开始日期
            end: 结束日期

        Returns:
            DataFrame with columns: sid, trade_dt, close

        Examples:
            >>> w.fund.history("000001.OF")
            >>> w.fund.history(["000001.OF", "000002.OF"])
        """
        start = str(start).replace("-", "")
        end = str(end).replace("-", "")

        table = self.db.chinamutualfundnav
        query = self.db.query(
            table.f_info_windcode.label("sid"),
            table.price_date.label("trade_dt"),
            table.f_nav_adjfactor,
            table.f_nav_unit,
        ).filter(
            table.price_date >= start,
            table.price_date <= end
        ).order_by(table.price_date, table.f_info_windcode)

        # 基金代码过滤（前6位匹配）
        if codes is not None:
            if isinstance(codes, str):
                code = codes[:6]
                query = query.filter(
                    func.substring(table.f_info_windcode, 1, 6) == code
                )
            else:
                code_list = [c[:6] for c in codes]
                query = query.filter(
                    func.substring(table.f_info_windcode, 1, 6).in_(code_list)
                )

        df = query.to_df()
        df.columns = ["sid", "trade_dt", "adjfactor", "unit"]
        df["close"] = df["adjfactor"] * df["unit"]
        df = df[["sid", "trade_dt", "close"]]

        # 交易日过滤
        trade_dates = CALENDAR.dates.to_list()
        df = df[df.trade_dt.isin(trade_dates)]

        return df.reset_index(drop=True)

    def filter(self, **kwargs) -> pd.DataFrame:
        """筛选基金

        Args:
            type: 基金类型
            company: 基金公司
            ...

        Returns:
            DataFrame

        Examples:
            >>> w.fund.filter(type="股票型")
        """
        table = self.db.chinamutualfunddescription
        query = self.db.query(
            table.f_info_windcode.label("sid"),
            table.f_info_fullname,
            table.f_info_fundmanager,
            table.f_info_fundcorp,
        )

        # 基金类型过滤
        if "type" in kwargs:
            type_map = {
                "股票型": "101",
                "混合型": "102",
                "债券型": "103",
                "货币型": "104",
                "指数型": "105",
                "QDII": "106",
            }
            type_code = type_map.get(kwargs["type"], kwargs["type"])
            query = query.filter(table.f_info_windcode.startswith(type_code))

        df = query.to_df()
        return df


__all__ = ['FundAPI']
