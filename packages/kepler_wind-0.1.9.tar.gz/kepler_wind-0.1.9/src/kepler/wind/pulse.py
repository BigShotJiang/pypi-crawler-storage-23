"""
交易日历模块

提供 A 股和港股的交易日历实例。
"""

from kepler.wind.db import WIND_DB
from kepler.pulse import Calendar


def _load_a_trade_dates():
    """加载 A 股交易日"""
    table = WIND_DB.asharecalendar
    df = WIND_DB.query(
        table.trade_days.label('t')
    ).filter(
        table.s_info_exchmarket == 'SSE'
    ).order_by(
        table.trade_days
    ).to_df()
    return df['t']


def _load_hk_trade_dates():
    """加载港股交易日"""
    table = WIND_DB.hkexcalendar
    df = WIND_DB.query(
        table.trade_days.label('t')
    ).filter(
        table.s_info_exchmarket == 'HKEX'
    ).order_by(
        table.trade_days
    ).to_df()
    return df['t']


# A 股日历实例
CALENDAR = Calendar(_load_a_trade_dates())

# 港股日历实例
CALENDAR_HK = Calendar(_load_hk_trade_dates())


__all__ = ['CALENDAR', 'CALENDAR_HK']
