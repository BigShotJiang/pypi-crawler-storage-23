"""
Wind 门面类 - 统一入口

提供优雅的链式 API 接口。

Examples:
    >>> from kepler.wind import Wind
    >>> w = Wind()                                    # 从配置文件加载
    >>> w = Wind(url="mysql+pymysql://user:pass@host:3306/db")  # 手动指定

    # 股票池
    >>> w.universe.members("HS300")
    >>> w.universe.at("HS300", "20240101")

    # 指数
    >>> w.index.history("000001.SH")
    >>> w.index.weight("000300.SH")

    # 收益率
    >>> w.returns.on("20240101")
    >>> w.returns.daily("000001.SZ")

    # 行业
    >>> w.industry.on("20240101")
    >>> w.industry.of("000001.SZ")

    # 基金
    >>> w.fund.history("000001.OF")
"""

from typing import Optional

from kepler.wind.db import init_db
from kepler.wind.universe import UniverseAPI
from kepler.wind.index import IndexAPI
from kepler.wind.returns import ReturnsAPI
from kepler.wind.industry import IndustryAPI
from kepler.wind.fund import FundAPI


class Wind:
    """量化数据统一入口

    按资产分类，每个资产提供截面和时序查询方法。

    Args:
        url: 数据库连接URL，如 "mysql+pymysql://user:pass@host:3306/db"
             如果为 None，则从配置文件 ~/.kepler/wind/wind.yaml 读取
        schema: 数据库schema，默认 "public"

    Examples:
        >>> w = Wind()  # 从配置文件读取
        >>> w = Wind(url="mysql+pymysql://user:pass@host:3306/wind")

        # 股票池
        >>> w.universe.members("HS300")       # 当前成分股
        >>> w.universe.at("HS300", "20240101")  # 历史成分股

        # 指数
        >>> w.index.history("000001.SH")      # 历史数据
        >>> w.index.weight("000300.SH")       # 成分权重

        # 收益率
        >>> w.returns.on("20240101")          # 截面
        >>> w.returns.daily("000001.SZ")      # 时序

        # 行业
        >>> w.industry.on("20240101")         # 截面
        >>> w.industry.of("000001.SZ")        # 单股

        # 基金
        >>> w.fund.history("000001.OF")       # 历史
    """

    def __init__(self, url: Optional[str] = None, schema: str = "public"):
        if url is not None:
            init_db(url, schema)

        self._universe = UniverseAPI()
        self._index = IndexAPI()
        self._returns = ReturnsAPI()
        self._industry = IndustryAPI()
        self._fund = FundAPI()

    @property
    def universe(self) -> UniverseAPI:
        """股票池 API"""
        return self._universe

    @property
    def index(self) -> IndexAPI:
        """指数 API"""
        return self._index

    @property
    def returns(self) -> ReturnsAPI:
        """收益率 API"""
        return self._returns

    @property
    def industry(self) -> IndustryAPI:
        """行业 API"""
        return self._industry

    @property
    def fund(self) -> FundAPI:
        """基金 API"""
        return self._fund


# 全局单例
_wind = Wind()


__all__ = ['Wind', '_wind']
