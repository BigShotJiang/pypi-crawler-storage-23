"""
收益率模块

提供股票收益率的截面和时序查询功能。

Examples:
    >>> from kepler.wind import Wind
    >>> w = Wind()
    >>> w.returns.on("20240101")                    # 截面：某日所有股票
    >>> w.returns.daily("000001.SZ")                # 时序：单股日收益率
    >>> w.returns.monthly("000001.SZ")              # 时序：单股月收益率
"""

from typing import Optional, Union, List, Set

import pandas as pd

from kepler.wind.pulse import CALENDAR
from kepler.wind.db import get_db


class ReturnsAPI:
    """收益率 API

    提供股票收益率的截面和时序查询功能。
    """

    @property
    def db(self):
        return get_db()

    def on(self, date: str, universe: str = "A") -> pd.DataFrame:
        """截面：某日所有股票的收益率

        Args:
            date: 交易日期
            universe: 股票池 ("A" 或 "HK")

        Returns:
            DataFrame: sid → return

        Examples:
            >>> w.returns.on("20240101")
        """
        date = str(date).replace("-", "")

        if universe == "A":
            table = self.db.ashareeodprices
        elif universe == "HK":
            table = self.db.hkshareeodprices
        else:
            raise ValueError(f"Unknown universe: {universe}")

        df = self.db.query(
            table.s_info_windcode.label("sid"),
            table.s_dq_adjclose.label("pct")
        ).filter(
            table.trade_dt == date
        ).to_df()

        df = df.set_index("sid")["pct"]
        df = df.pct_change(fill_method=None)
        return df.dropna()

    def daily(
        self,
        sid: Optional[Union[str, List[str], Set[str]]] = None,
        start: str = "20030101",
        end: str = "20990101",
        universe: str = "A"
    ) -> pd.DataFrame:
        """时序：日收益率

        Args:
            sid: 股票代码（单个或列表），None 表示全市场
            start: 开始日期
            end: 结束日期
            universe: 股票池 ("A" 或 "HK")

        Returns:
            DataFrame: dates × stocks（宽表格式）

        Examples:
            >>> w.returns.daily("000001.SZ")
            >>> w.returns.daily(["000001.SZ", "000002.SZ"])
        """
        start = str(start).replace("-", "")
        end = str(end).replace("-", "")

        if universe == "A":
            table = self.db.ashareeodprices
        elif universe == "HK":
            table = self.db.hkshareeodprices
        else:
            raise ValueError(f"Unknown universe: {universe}")

        query = self.db.query(
            table.s_info_windcode.label("sid"),
            table.trade_dt,
            table.s_dq_adjclose.label("pct")
        ).filter(
            table.trade_dt >= start,
            table.trade_dt <= end
        )

        if sid is not None:
            if isinstance(sid, str):
                query = query.filter(table.s_info_windcode == sid)
            else:
                query = query.filter(table.s_info_windcode.in_(list(sid)))

        df = query.order_by(table.trade_dt).to_df()

        if df.empty:
            return pd.DataFrame()

        df = df.pivot(index="trade_dt", columns="sid", values="pct")
        df = df.pct_change(fill_method=None)
        return df.dropna(how="all").T

    def monthly(
        self,
        sid: Optional[Union[str, List[str], Set[str]]] = None,
        start: str = "20030101",
        end: str = "20990101",
        trade_dt: Optional[str] = None
    ) -> pd.DataFrame:
        """时序：月收益率

        Args:
            sid: 股票代码
            start: 开始日期
            end: 结束日期
            trade_dt: 单个交易日期（截面查询）

        Returns:
            DataFrame

        Examples:
            >>> w.returns.monthly("000001.SZ")
            >>> w.returns.monthly(trade_dt="20240101")  # 截面
        """
        start = str(start).replace("-", "")
        end = str(end).replace("-", "")

        table = self.db.asharemonthlyyield
        query = self.db.query(
            table.s_info_windcode.label("sid"),
            table.trade_dt,
            table.s_mq_pctchange.label("pct")
        )

        if trade_dt is not None:
            trade_dt = str(trade_dt).replace("-", "")
            trade_dt = CALENDAR.monthly.last.prev(trade_dt)
            query = query.filter(table.trade_dt == trade_dt)
        else:
            query = query.filter(
                table.trade_dt >= start,
                table.trade_dt <= end
            )

        if sid is not None:
            if isinstance(sid, str):
                query = query.filter(table.s_info_windcode == sid)
            else:
                query = query.filter(table.s_info_windcode.in_(list(sid)))

        df = query.order_by(table.trade_dt).to_df()

        if df.empty:
            return pd.DataFrame()

        df["pct"] = df["pct"] / 100.0

        if trade_dt is not None:
            return df
        else:
            df = df.pivot(index="trade_dt", columns="sid", values="pct")
            return df.dropna(how="all").T


__all__ = ['ReturnsAPI']
