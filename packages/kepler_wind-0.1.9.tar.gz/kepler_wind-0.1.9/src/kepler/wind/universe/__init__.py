"""
股票池模块

提供股票池的截面和历史查询功能。

Examples:
    >>> from kepler.wind import Wind
    >>> w = Wind()
    >>> w.universe.members("HS300")              # 当前成分股
    >>> w.universe.at("HS300", "20240101")       # 历史成分股
    >>> w.universe.history("HS300")              # 完整变更历史
"""

from functools import lru_cache
from typing import Optional, Set, Union, List

import pandas as pd

from kepler.wind.pulse import CALENDAR
from kepler.wind.db import get_db


# 指数代码映射
INDEX_DICT = {
    "HS300": "000300.SH",
    "ZZ500": "000905.SH",
    "ZZ800": "000906.SH",
    "ZZ1000": "000852.SH",
    "SSE50": "000016.SH",
    "CSI100": "000903.SH",
    "GEM": "399006.SZ",
    "SME": "399005.SZ",
    "A": "881001.WI",
}


class UniverseAPI:
    """股票池 API

    提供股票池的截面和历史查询功能。
    """

    @property
    def db(self):
        return get_db()

    def members(self, index: str, cur_sign: bool = True) -> Set[str]:
        """获取当前成分股

        Args:
            index: 指数代码或简称 ("HS300", "ZZ500", "A", "MSCI", ...)
            cur_sign: 是否只取当前有效

        Returns:
            股票代码集合

        Examples:
            >>> w.universe.members("HS300")
            >>> w.universe.members("000300.SH")
            >>> w.universe.members("A")  # 全A股
        """
        index_code = INDEX_DICT.get(index, index)

        if index == "MSCI":
            return self._get_msci_members(cur_sign)
        elif index == "A" or index_code == "881001.WI":
            return self._get_a_members(cur_sign)
        elif index_code.endswith("HI"):
            return self._get_hk_members(index_code, cur_sign)
        else:
            return self._get_normal_members(index_code, cur_sign)

    def at(self, index: str, date: str) -> Set[str]:
        """获取历史成分股

        Args:
            index: 指数代码或简称
            date: 交易日期

        Returns:
            股票代码集合

        Examples:
            >>> w.universe.at("HS300", "20240101")
        """
        df = self.history(index)
        date = str(date).replace("-", "")

        df = df.loc[
            (df["entry_dt"] <= date) &
            ((df["out_dt"] >= date) | (df["out_dt"].isnull()))
        ]
        return set(df["sid"])

    def history(self, index: str) -> pd.DataFrame:
        """获取完整变更历史

        Args:
            index: 指数代码或简称

        Returns:
            DataFrame with columns: sid, entry_dt, out_dt

        Examples:
            >>> w.universe.history("HS300")
        """
        index_code = INDEX_DICT.get(index, index)

        if index == "MSCI":
            return self._get_msci_history()
        elif index == "A" or index_code == "881001.WI":
            return self._get_a_history()
        elif index_code.endswith("HI"):
            return self._get_hk_history(index_code)
        else:
            return self._get_normal_history(index_code)

    # ===== 内部实现 =====

    def _get_normal_members(self, index_code: str, cur_sign: bool) -> Set[str]:
        """普通指数成分股"""
        table = self.db.aindexmembers
        query = self.db.query(table.s_con_windcode).filter(
            table.s_info_windcode == index_code
        )
        if cur_sign:
            query = query.filter(table.cur_sign == "1")
        df = query.to_df()
        return set(df.iloc[:, 0])

    @lru_cache(maxsize=32)
    def _get_normal_history(self, index_code: str) -> pd.DataFrame:
        """普通指数历史"""
        table = self.db.aindexmembers
        df = self.db.query(
            table.s_con_windcode.label("sid"),
            table.s_con_indate.label("entry_dt"),
            table.s_con_outdate.label("out_dt")
        ).filter(
            table.s_info_windcode == index_code
        ).to_df()
        return df

    def _get_a_members(self, cur_sign: bool) -> Set[str]:
        """全A股成分股"""
        table = self.db.aindexmemberswind
        query = self.db.query(table.s_con_windcode).filter(
            table.f_info_windcode == "881001.WI"
        )
        if cur_sign:
            query = query.filter(table.cur_sign == "1")
        df = query.to_df()
        return set(df.iloc[:, 0])

    @lru_cache(maxsize=1)
    def _get_a_history(self) -> pd.DataFrame:
        """全A股历史"""
        table = self.db.aindexmemberswind
        df = self.db.query(
            table.s_con_windcode.label("sid"),
            table.s_con_indate.label("entry_dt"),
            table.s_con_outdate.label("out_dt")
        ).filter(
            table.f_info_windcode == "881001.WI"
        ).to_df()
        return df

    def _get_msci_members(self, cur_sign: bool) -> Set[str]:
        """MSCI成分股"""
        table = self.db.asharemscimembers
        query = self.db.query(table.s_info_windcode)
        if cur_sign:
            query = query.filter(table.cur_sign == "1")
        df = query.to_df()
        return set(df.iloc[:, 0])

    @lru_cache(maxsize=1)
    def _get_msci_history(self) -> pd.DataFrame:
        """MSCI历史"""
        table = self.db.asharemscimembers
        df = self.db.query(
            table.s_info_windcode.label("sid"),
            table.entry_dt.label("entry_dt"),
            table.remove_dt.label("out_dt")
        ).to_df()
        return df

    def _get_hk_members(self, index_code: str, cur_sign: bool) -> Set[str]:
        """港股成分股"""
        table = self.db.hkstockindexmembers
        query = self.db.query(table.s_con_windcode).filter(
            table.s_info_windcode == index_code
        )
        if cur_sign:
            query = query.filter(table.cur_sign == "1")
        df = query.to_df()
        return set(df.iloc[:, 0])

    @lru_cache(maxsize=32)
    def _get_hk_history(self, index_code: str) -> pd.DataFrame:
        """港股历史"""
        table = self.db.hkstockindexmembers
        df = self.db.query(
            table.s_con_windcode.label("sid"),
            table.s_con_indate.label("entry_dt"),
            table.s_con_outdate.label("out_dt")
        ).filter(
            table.s_info_windcode == index_code
        ).to_df()
        return df


__all__ = ['UniverseAPI', 'INDEX_DICT']
