"""
Kepler Wind - 量化数据API

优雅的量化数据访问接口，按资产分类，每个资产提供截面和时序查询方法。

Examples:
    >>> from kepler.wind import Wind
    >>> w = Wind()
    >>> w = Wind(url="mysql+pymysql://user:pass@host:3306/db")

    # 股票池
    >>> w.universe.members("HS300")           # 当前成分股
    >>> w.universe.at("HS300", "20240101")    # 历史成分股

    # 指数
    >>> w.index.history("000001.SH")          # 历史数据
    >>> w.index.weight("000300.SH")           # 成分权重

    # 收益率
    >>> w.returns.on("20240101")              # 截面收益率
    >>> w.returns.daily("000001.SZ")          # 日收益率
    >>> w.returns.monthly("000001.SZ")        # 月收益率

    # 行业
    >>> w.industry.on("20240101")             # 截面行业分类
    >>> w.industry.of("000001.SZ")            # 单股行业

    # 基金
    >>> w.fund.history("000001.OF")           # 基金净值
    >>> w.fund.filter(type="股票型")          # 筛选基金
"""

from kepler.wind.wind import Wind, _wind
from kepler.wind.pulse import CALENDAR, CALENDAR_HK

__all__ = [
    'Wind',
    '_wind',
    'CALENDAR',
    'CALENDAR_HK',
]
