import json
import subprocess
from datetime import date

from engel_semantic_layer.cli import _resolve_period


def test_validate_command_json_output():
    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "validate",
            "--model-path",
            "examples/model",
            "--json",
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    data = json.loads(result.stdout)
    assert data["ok"] is True
    assert data["modules"] >= 2
    assert data["metrics"] >= 2


def test_resolve_period_current_year_is_ytd():
    from_date, to_date = _resolve_period("current year", today=date(2026, 2, 15))
    assert from_date == "2026-01-01T00:00:00Z"
    assert to_date == "2026-02-15T23:59:59Z"


def test_resolve_period_current_month_is_mtd():
    from_date, to_date = _resolve_period("current month", today=date(2026, 2, 15))
    assert from_date == "2026-02-01T00:00:00Z"
    assert to_date == "2026-02-15T23:59:59Z"


def test_validate_command_summary_only_json():
    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "validate",
            "--model-path",
            "examples/model",
            "--json",
            "--summary-only",
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    data = json.loads(result.stdout)
    assert data["ok"] is True
    assert "warningCount" in data
    assert "compileFailureCount" in data
    assert "compileFailures" not in data
    assert "metricValidation" not in data


def test_compile_command_sql_output(tmp_path):
    request = {
        "fromDate": "2026-01-01T00:00:00Z",
        "toDate": "2026-01-31T23:59:59Z",
        "breakdownDimensionIds": ["user_email"],
    }
    request_file = tmp_path / "request.json"
    request_file.write_text(json.dumps(request), encoding="utf-8")

    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "compile",
            "--model-path",
            "examples/model",
            "--metric-id",
            "metric_event_count",
            "--request",
            str(request_file),
            "--format",
            "sql",
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    assert "SELECT" in result.stdout
    assert "COUNT(*) AS metric" in result.stdout


def test_compile_command_json_output(tmp_path):
    request = {
        "fromDate": "2026-01-01T00:00:00Z",
        "toDate": "2026-01-31T23:59:59Z",
    }
    request_file = tmp_path / "request.json"
    request_file.write_text(json.dumps(request), encoding="utf-8")

    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "compile",
            "--model-path",
            "examples/model",
            "--metric-id",
            "metric_event_distinct_count",
            "--request",
            str(request_file),
            "--format",
            "json",
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    payload = json.loads(result.stdout)
    assert payload["metricId"] == "metric_event_distinct_count"
    assert "COUNT(DISTINCT" in payload["sql"]
    assert "metadata" in payload


def test_compile_cross_module_metric_single_file(tmp_path):
    request = {
        "fromDate": "2025-02-26T00:00:00Z",
        "toDate": "2025-12-31T23:59:59Z",
        "timeGrain": "monthly",
    }
    request_file = tmp_path / "request.json"
    request_file.write_text(json.dumps(request), encoding="utf-8")

    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "compile",
            "--model-path",
            "examples/semantic_layer.yml",
            "--metric-id",
            "ratio_primary_per_entity",
            "--request",
            str(request_file),
            "--format",
            "json",
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    payload = json.loads(result.stdout)
    assert payload["metricId"] == "ratio_primary_per_entity"
    assert "WITH numerator AS" in payload["sql"]


def test_compile_command_explain_output(tmp_path):
    request = {
        "fromDate": "2026-01-01T00:00:00Z",
        "toDate": "2026-01-31T23:59:59Z",
        "breakdownDimensionIds": ["user_email"],
    }
    request_file = tmp_path / "request.json"
    request_file.write_text(json.dumps(request), encoding="utf-8")

    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "compile",
            "--model-path",
            "examples/model",
            "--metric-id",
            "metric_event_count",
            "--request",
            str(request_file),
            "--format",
            "explain",
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    payload = json.loads(result.stdout)
    assert payload["metricId"] == "metric_event_count"
    assert "explain" in payload
    assert "metadata" in payload["explain"]
    assert "required_tables" in payload["explain"]["metadata"]


def test_compile_command_dry_run_validate_json(tmp_path):
    request = {
        "fromDate": "2026-01-01T00:00:00Z",
        "toDate": "2026-01-31T23:59:59Z",
        "breakdownDimensionIds": ["user_email"],
    }
    request_file = tmp_path / "request.json"
    request_file.write_text(json.dumps(request), encoding="utf-8")

    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "compile",
            "--model-path",
            "examples/model",
            "--metric-id",
            "metric_event_count",
            "--request",
            str(request_file),
            "--format",
            "json",
            "--dry-run-validate",
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    payload = json.loads(result.stdout)
    assert payload["ok"] is True
    assert payload["metricId"] == "metric_event_count"
    assert "metadata" in payload
    assert "sql" not in payload


def test_registry_from_information_schema_json_array(tmp_path):
    rows = [
        {"table_schema": "analytics_wide", "table_name": "wide_metric_count_a", "column_name": "recorded_at"},
        {"table_schema": "analytics_wide", "table_name": "wide_metric_count_a", "column_name": "value_secondary_amount"},
        {"table_schema": "analytics_wide", "table_name": "wide_users", "column_name": "id"},
    ]

    in_file = tmp_path / "rows.json"
    out_file = tmp_path / "registry.json"
    in_file.write_text(json.dumps(rows), encoding="utf-8")

    subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "registry",
            "from-information-schema",
            "--input",
            str(in_file),
            "--output",
            str(out_file),
        ],
        check=True,
    )

    data = json.loads(out_file.read_text(encoding="utf-8"))
    assert sorted(data["analytics_wide"]["wide_metric_count_a"]) == sorted(
        ["recorded_at", "value_secondary_amount"]
    )
    assert data["analytics_wide"]["wide_users"] == ["id"]


def test_registry_from_information_schema_jsonl_custom_keys(tmp_path):
    rows = [
        {"schema": "s1", "table": "t1", "column": "c1"},
        {"schema": "s1", "table": "t1", "column": "c2"},
    ]

    in_file = tmp_path / "rows.jsonl"
    in_file.write_text("\n".join(json.dumps(r) for r in rows), encoding="utf-8")

    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "registry",
            "from-information-schema",
            "--input",
            str(in_file),
            "--schema-key",
            "schema",
            "--table-key",
            "table",
            "--column-key",
            "column",
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    data = json.loads(result.stdout)
    assert data == {"s1": {"t1": ["c1", "c2"]}}


def test_compile_command_returns_nonzero_on_invalid_request(tmp_path):
    request_file = tmp_path / "request.json"
    request_file.write_text("[]", encoding="utf-8")

    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "compile",
            "--model-path",
            "examples/model",
            "--metric-id",
            "metric_event_count",
            "--request",
            str(request_file),
        ],
        check=False,
        capture_output=True,
        text=True,
    )

    assert result.returncode == 2
    assert "ERROR:" in result.stderr


def test_compile_command_supports_stdin_request():
    request = {
        "fromDate": "2026-01-01T00:00:00Z",
        "toDate": "2026-01-31T23:59:59Z",
    }

    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "compile",
            "--model-path",
            "examples/model",
            "--metric-id",
            "metric_event_distinct_count",
            "--request",
            "-",
        ],
        check=True,
        capture_output=True,
        text=True,
        input=json.dumps(request),
    )

    assert "COUNT(DISTINCT" in result.stdout


def test_compile_command_supports_period_without_dates(tmp_path):
    request_file = tmp_path / "request.json"
    request_file.write_text("{}", encoding="utf-8")

    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "compile",
            "--model-path",
            "examples/model",
            "--metric-id",
            "metric_event_distinct_count",
            "--request",
            str(request_file),
            "--period",
            "2025",
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    assert "DATE(`analytics_prod.event_log`.`creation_time`) >= DATE('2025-01-01')" in result.stdout
    assert "DATE(`analytics_prod.event_log`.`creation_time`) <= DATE('2025-12-31')" in result.stdout


def test_compile_command_dry_run_validate_text(tmp_path):
    request = {
        "fromDate": "2026-01-01T00:00:00Z",
        "toDate": "2026-01-31T23:59:59Z",
    }
    request_file = tmp_path / "request.json"
    request_file.write_text(json.dumps(request), encoding="utf-8")

    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "compile",
            "--model-path",
            "examples/model",
            "--metric-id",
            "metric_event_distinct_count",
            "--request",
            str(request_file),
            "--dry-run-validate",
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    assert "request is valid" in result.stdout


def test_compile_command_requires_dates_or_period(tmp_path):
    request_file = tmp_path / "request.json"
    request_file.write_text("{}", encoding="utf-8")

    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "compile",
            "--model-path",
            "examples/model",
            "--metric-id",
            "metric_event_count",
            "--request",
            str(request_file),
        ],
        check=False,
        capture_output=True,
        text=True,
    )

    assert result.returncode == 2
    assert "fromDate/toDate" in result.stderr


def test_compile_command_json_error_mode(tmp_path):
    request_file = tmp_path / "request.json"
    request_file.write_text("[]", encoding="utf-8")

    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "--json-errors",
            "compile",
            "--model-path",
            "examples/model",
            "--metric-id",
            "metric_event_count",
            "--request",
            str(request_file),
        ],
        check=False,
        capture_output=True,
        text=True,
    )

    assert result.returncode == 2
    payload = json.loads(result.stderr)
    assert payload["ok"] is False
    assert payload["exitCode"] == 2
    assert payload["errorType"] == "ValueError"


def test_metrics_command_json_output():
    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "metrics",
            "--model-path",
            "examples/model",
            "--format",
            "json",
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    metrics = json.loads(result.stdout)
    assert any(m["id"] == "metric_event_count" for m in metrics)
    assert any(m["id"] == "metric_actual_secondary" for m in metrics)


def test_metrics_command_table_output_contains_headers():
    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "metrics",
            "--model-path",
            "examples/model",
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    assert "metric_id" in result.stdout
    assert "calculation" in result.stdout
    assert "module_id" in result.stdout


def test_metrics_command_includes_cross_module_metrics_for_single_file():
    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "metrics",
            "--model-path",
            "examples/semantic_layer.yml",
            "--format",
            "json",
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    metrics = json.loads(result.stdout)
    assert any(m["id"] == "ratio_primary_per_entity" for m in metrics)
    metric_future_primary = next(m for m in metrics if m["id"] == "metric_future_primary")
    assert metric_future_primary["aiContext"]["synonyms"]


def test_metrics_command_filters():
    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "metrics",
            "--model-path",
            "examples/model",
            "--format",
            "json",
            "--module",
            "fact_records",
            "--calculation",
            "sum",
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    metrics = json.loads(result.stdout)
    assert len(metrics) > 0
    assert all(m["moduleId"] == "fact_records" for m in metrics)
    assert all(m["calculation"] == "sum" for m in metrics)


def test_joins_command_json_output():
    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "joins",
            "--model-path",
            "examples/model",
            "--format",
            "json",
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    payload = json.loads(result.stdout)
    assert "modules" in payload
    assert "crossModuleMetrics" in payload
    assert "joins" in payload
    assert "orphans" in payload
    assert "edges" in payload


def test_joins_command_table_output():
    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "joins",
            "--model-path",
            "examples/model",
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    assert "modules:" in result.stdout
    assert "joins:" in result.stdout
    assert "orphans:" in result.stdout


def test_validate_command_strict_column_lint(tmp_path):
    registry = {
        "analytics_prod": {
            "event_log": [
                "creation_time",
                "query",
                "user_email",
            ]
        },
        "analytics_wide": {
            "wide_metric_count_a": [
                "recorded_at",
                "fulfilled_at",
                "value_primary_amount",
                "dim_order_id",
                "dim_user_id",
                "value_delta_amount",
                "duration_units",
                "value_secondary_amount",
                "status",
                "outcome",
                "settled_at",
                "stage_one_at",
                "segment_group",
                "segment_name",
                "segment_medium",
                "segment_source",
                "init_type",
                "party_type",
                "first_segment",
                "last_segment",
                "origin_region",
                "destination_region",
                "is_repeat_actor",
            ]
        },
        "analytics_marts": {
            "entity_snapshots": [
                "date",
                "dim_entity_id",
                "is_live",
                "has_last_minute_promotion",
            ]
        },
    }
    registry_file = tmp_path / "registry.json"
    registry_file.write_text(json.dumps(registry), encoding="utf-8")

    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "validate",
            "--model-path",
            "examples/model",
            "--json",
            "--strict-column-lint",
            "--column-registry",
            str(registry_file),
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    payload = json.loads(result.stdout)
    assert payload["strictColumnLint"] is True
    assert payload["compileCheckedMetrics"] > 0


def test_validate_command_check_compilable():
    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "validate",
            "--model-path",
            "examples/model",
            "--json",
            "--check-compilable",
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    payload = json.loads(result.stdout)
    assert payload["checkCompilable"] is True
    assert payload["compileCheckedMetrics"] > 0
    assert payload["compileValidationTimeGrain"] == "monthly"


def test_validate_command_supports_period_override():
    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "validate",
            "--model-path",
            "examples/model",
            "--json",
            "--check-compilable",
            "--period",
            "Q1 2025",
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    payload = json.loads(result.stdout)
    assert payload["checkCompilable"] is True
    assert payload["compileCheckedMetrics"] > 0
    assert payload["compileValidationTimeGrain"] == "monthly"


def test_validate_command_check_compilable_single_file_includes_cross_metrics():
    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "validate",
            "--model-path",
            "examples/semantic_layer.yml",
            "--json",
            "--check-compilable",
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    payload = json.loads(result.stdout)
    assert payload["checkCompilable"] is True
    assert payload["compileFailureCount"] == 0
    assert any(
        item["metricId"] == "ratio_primary_per_entity" and item["status"] == "ok"
        for item in payload["metricValidation"]
    )


def test_validate_command_allows_time_grain_override_for_compile_checks():
    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "validate",
            "--model-path",
            "examples/semantic_layer.yml",
            "--json",
            "--check-compilable",
            "--time-grain",
            "weekly",
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    payload = json.loads(result.stdout)
    assert payload["compileValidationTimeGrain"] == "weekly"
    assert payload["compileFailureCount"] == 0


def test_validate_check_compilable_returns_error_on_compile_failure(tmp_path):
    model_dir = tmp_path / "model"
    model_dir.mkdir()
    (model_dir / "records.yml").write_text(
        """
module:
  identifier: "records"
  schema: "analytics"
  table: "records"
  dimensions:
    - column: "id"
      type: "categorical"
  metrics:
    - identifier: "records_sum"
      name: "Records sum"
      calculation: "sum"
      time: "records.recorded_at"
      value: "customers.amount"
""".strip(),
        encoding="utf-8",
    )
    (model_dir / "customers.yml").write_text(
        """
module:
  identifier: "customers"
  schema: "analytics"
  table: "customers"
  dimensions:
    - column: "country"
      type: "categorical"
""".strip(),
        encoding="utf-8",
    )

    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "--json-errors",
            "validate",
            "--model-path",
            str(model_dir),
            "--check-compilable",
        ],
        check=False,
        capture_output=True,
        text=True,
    )

    assert result.returncode == 2
    payload = json.loads(result.stderr)
    assert payload["ok"] is False
    assert "failed compile validation" in payload["message"]


def test_validate_writes_report_file(tmp_path):
    report_file = tmp_path / "report.json"

    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "validate",
            "--model-path",
            "examples/model",
            "--check-compilable",
            "--report",
            str(report_file),
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    assert result.returncode == 0
    assert report_file.exists()
    report = json.loads(report_file.read_text(encoding="utf-8"))
    assert report["ok"] is True
    assert report["compileCheckedMetrics"] > 0
    assert len(report["metricValidation"]) > 0
    assert any(item["status"] == "ok" for item in report["metricValidation"])


def test_validate_error_still_writes_report_file(tmp_path):
    model_dir = tmp_path / "model"
    model_dir.mkdir()
    (model_dir / "records.yml").write_text(
        """
module:
  identifier: "records"
  schema: "analytics"
  table: "records"
  dimensions:
    - column: "id"
      type: "categorical"
  metrics:
    - identifier: "records_sum"
      name: "Records sum"
      calculation: "sum"
      time: "records.recorded_at"
      value: "customers.amount"
""".strip(),
        encoding="utf-8",
    )
    (model_dir / "customers.yml").write_text(
        """
module:
  identifier: "customers"
  schema: "analytics"
  table: "customers"
  dimensions:
    - column: "country"
      type: "categorical"
""".strip(),
        encoding="utf-8",
    )
    report_file = tmp_path / "report.json"

    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "validate",
            "--model-path",
            str(model_dir),
            "--check-compilable",
            "--report",
            str(report_file),
        ],
        check=False,
        capture_output=True,
        text=True,
    )

    assert result.returncode == 2
    assert report_file.exists()
    report = json.loads(report_file.read_text(encoding="utf-8"))
    assert report["ok"] is False
    assert report["compileFailureCount"] > 0
    assert any(item["status"] == "failed" for item in report["metricValidation"])


def test_validate_rejects_invalid_ai_context(tmp_path):
    model_dir = tmp_path / "model"
    model_dir.mkdir()
    (model_dir / "records.yml").write_text(
        """
module:
  identifier: "records"
  schema: "analytics"
  table: "records"
  dimensions:
    - column: "country"
      type: "categorical"
  metrics:
    - identifier: "records_count"
      name: "Records"
      calculation: "count"
      time: "records.recorded_at"
      ai_context:
        synonyms:
          - "metric_count_a"
          - 42
""".strip(),
        encoding="utf-8",
    )

    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "validate",
            "--model-path",
            str(model_dir),
        ],
        check=False,
        capture_output=True,
        text=True,
    )

    assert result.returncode == 2
    assert "ai_context.synonyms" in result.stderr


def test_validate_reports_semantic_warnings(tmp_path):
    model_dir = tmp_path / "model"
    model_dir.mkdir()
    (model_dir / "records.yml").write_text(
        """
module:
  identifier: "records"
  schema: "analytics"
  table: "records"
  dimensions:
    - column: "country"
      type: "categorical"
  metrics:
    - identifier: "records_count"
      name: "Records"
      calculation: "count"
      time: "records.recorded_at"
      dimensions:
        - "ghost_table.*"
""".strip(),
        encoding="utf-8",
    )

    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "validate",
            "--model-path",
            str(model_dir),
            "--json",
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    payload = json.loads(result.stdout)
    assert payload["warningCount"] > 0
    assert any(w["type"] == "unresolved-wildcard" for w in payload["warnings"])


def test_validate_rejects_invalid_cross_join_type(tmp_path):
    model_file = tmp_path / "semantic_layer.yml"
    model_file.write_text(
        """
semantic_layer:
  modules:
    - identifier: "a"
      schema: "s"
      table: "a"
      metrics:
        - identifier: "a_count"
          name: "A"
          calculation: "count"
          time: "a.recorded_at"
    - identifier: "b"
      schema: "s"
      table: "b"
      metrics:
        - identifier: "b_count"
          name: "B"
          calculation: "count"
          time: "b.recorded_at"
  cross_module_metrics:
    - identifier: "ratio"
      name: "Ratio"
      calculation: "derived-ratio"
      numerator_metric: "a_count"
      denominator_metric: "b_count"
      join_on: "time"
      join_type: "right"
""".strip(),
        encoding="utf-8",
    )

    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "validate",
            "--model-path",
            str(model_file),
        ],
        check=False,
        capture_output=True,
        text=True,
    )

    assert result.returncode == 2
    assert "unsupported join_type" in result.stderr


def test_validate_warnings_as_errors(tmp_path):
    model_dir = tmp_path / "model"
    model_dir.mkdir()
    (model_dir / "records.yml").write_text(
        """
module:
  identifier: "records"
  schema: "analytics"
  table: "records"
  dimensions:
    - column: "country"
      type: "categorical"
  metrics:
    - identifier: "records_count"
      name: "Records"
      calculation: "count"
      time: "records.recorded_at"
      dimensions:
        - "ghost_table.*"
""".strip(),
        encoding="utf-8",
    )

    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "--json-errors",
            "validate",
            "--model-path",
            str(model_dir),
            "--warnings-as-errors",
        ],
        check=False,
        capture_output=True,
        text=True,
    )

    assert result.returncode == 2
    payload = json.loads(result.stderr)
    assert payload["ok"] is False
    assert "warning(s) treated as errors" in payload["message"]


def test_compile_command_supports_yoy_time_comparison(tmp_path):
    request_file = tmp_path / "request.json"
    request_file.write_text(
        json.dumps(
            {
                "fromDate": "2026-01-01T00:00:00Z",
                "toDate": "2026-02-15T23:59:59Z",
                "timeGrain": "monthly",
                "timeComparison": "YoY",
            }
        ),
        encoding="utf-8",
    )

    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "compile",
            "--model-path",
            "examples/model",
            "--metric-id",
            "metric_event_count",
            "--request",
            str(request_file),
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    assert "comparison_percentage" in result.stdout
    assert "DATE_SUB(curr.time, INTERVAL 1 YEAR)" in result.stdout


def test_compile_command_supports_weekly_yoy_with_52_week_shift(tmp_path):
    request_file = tmp_path / "request.json"
    request_file.write_text(
        json.dumps(
            {
                "fromDate": "2026-01-01T00:00:00Z",
                "toDate": "2026-02-15T23:59:59Z",
                "timeGrain": "weekly",
                "timeComparison": "YoY",
            }
        ),
        encoding="utf-8",
    )

    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "compile",
            "--model-path",
            "examples/model",
            "--metric-id",
            "metric_event_count",
            "--request",
            str(request_file),
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    assert "DATE_SUB(curr.time, INTERVAL 52 WEEK)" in result.stdout
    assert "DATE_SUB(curr.time, INTERVAL 1 YEAR)" not in result.stdout


def test_compile_command_rejects_match_weekday_without_daily_grain(tmp_path):
    request_file = tmp_path / "request.json"
    request_file.write_text(
        json.dumps(
            {
                "fromDate": "2026-01-01T00:00:00Z",
                "toDate": "2026-02-15T23:59:59Z",
                "timeGrain": "monthly",
                "timeComparison": "YoY (Match Weekday)",
            }
        ),
        encoding="utf-8",
    )

    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "compile",
            "--model-path",
            "examples/model",
            "--metric-id",
            "metric_event_count",
            "--request",
            str(request_file),
        ],
        check=False,
        capture_output=True,
        text=True,
    )

    assert result.returncode == 2
    assert "requires daily timeGrain" in result.stderr


def test_compile_command_supports_time_grain_none_with_yoy(tmp_path):
    request_file = tmp_path / "request.json"
    request_file.write_text(
        json.dumps(
            {
                "fromDate": "2026-01-01T00:00:00Z",
                "toDate": "2026-02-15T23:59:59Z",
                "timeGrain": "none",
                "timeComparison": "YoY",
            }
        ),
        encoding="utf-8",
    )

    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "compile",
            "--model-path",
            "examples/semantic_layer.yml",
            "--metric-id",
            "metric_future_primary",
            "--request",
            str(request_file),
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    assert "WITH curr AS (" in result.stdout
    assert "prev AS (" in result.stdout
    assert "comparison_value" in result.stdout


def test_compile_command_supports_exclude_open_period(tmp_path):
    request_file = tmp_path / "request.json"
    request_file.write_text(
        json.dumps(
            {
                "fromDate": "2026-01-01T00:00:00Z",
                "toDate": "2026-02-15T23:59:59Z",
                "timeGrain": "monthly",
                "excludeOpenPeriod": True,
            }
        ),
        encoding="utf-8",
    )

    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "compile",
            "--model-path",
            "examples/semantic_layer.yml",
            "--metric-id",
            "metric_future_primary",
            "--request",
            str(request_file),
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    assert "<= DATE('2026-01-31')" in result.stdout


def test_compile_command_supports_exclude_today(tmp_path):
    request_file = tmp_path / "request.json"
    request_file.write_text(
        json.dumps(
            {
                "fromDate": "2026-02-01T00:00:00Z",
                "toDate": "2026-02-15T23:59:59Z",
                "timeGrain": "daily",
                "excludeToday": True,
            }
        ),
        encoding="utf-8",
    )

    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "compile",
            "--model-path",
            "examples/semantic_layer.yml",
            "--metric-id",
            "metric_future_primary",
            "--request",
            str(request_file),
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    assert "<= DATE('2026-02-14')" in result.stdout


def test_compile_command_supports_target_series_comparison(tmp_path):
    request_file = tmp_path / "request.json"
    request_file.write_text(
        json.dumps(
            {
                "fromDate": "2026-01-01T00:00:00Z",
                "toDate": "2026-02-15T23:59:59Z",
                "timeGrain": "monthly",
                "targetSeries": "budget_current",
                "filters": [{"dimensionId": "segment_group", "filterValues": ["SegmentA"]}],
            }
        ),
        encoding="utf-8",
    )

    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "compile",
            "--model-path",
            "examples/semantic_layer.yml",
            "--metric-id",
            "metric_future_primary",
            "--request",
            str(request_file),
            "--target-project",
            "p",
            "--target-schema",
            "s",
            "--target-table",
            "custom_targets",
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    assert "targets AS (" in result.stdout
    assert "target_value" in result.stdout
    assert "target_comparison_percentage" in result.stdout
    assert "`p.s.custom_targets`" in result.stdout
    assert "custom_targets`.`segment_group` IN ('SegmentA')" in result.stdout


def test_compile_command_supports_cumulative_mode(tmp_path):
    request_file = tmp_path / "request.json"
    request_file.write_text(
        json.dumps(
            {
                "fromDate": "2026-01-01T00:00:00Z",
                "toDate": "2026-01-31T23:59:59Z",
                "timeGrain": "daily",
                "cumulativeMode": "mtd",
            }
        ),
        encoding="utf-8",
    )

    result = subprocess.run(
        [
            "python",
            "-m",
            "engel_semantic_layer.cli",
            "compile",
            "--model-path",
            "examples/semantic_layer.yml",
            "--metric-id",
            "metric_future_primary",
            "--request",
            str(request_file),
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    assert "metric_base" in result.stdout
    assert "SUM(base.metric) OVER" in result.stdout
    assert "DATE_TRUNC(base.time, MONTH)" in result.stdout
