from __future__ import annotations

from pathlib import Path

import yaml

from .models import (
    CrossModuleMetric,
    Dimension,
    Filter,
    JoinEndpoint,
    JoinPath,
    Metric,
    Module,
    QueryFilter,
    QueryRequest,
    Slice,
)


class SemanticConfigError(ValueError):
    pass


_ALLOWED_CALCULATIONS = {
    "sum",
    "count",
    "ratio",
    "count-distinct",
    "custom-value",
    "custom-ratio",
}
_ALLOWED_OPERATORS = {
    "equals",
    "not-equals",
    "less-than",
    "less-than-or-equal",
    "greater-than",
    "greater-than-or-equal",
    "in",
    "not-in",
    "is",
    "is-not",
    "like",
    "not-like",
}
_ALLOWED_TIME_GRAINS = {"none", "daily", "weekly", "monthly", "quarterly", "yearly"}
_TIME_GRAIN_ALIASES = {
    "all": "none",  # backwards compatibility
}
_TIME_COMPARISON_ALIASES = {
    "yoy": "yoy",
    "year-over-year": "yoy",
    "mom": "mom",
    "month-over-month": "mom",
    "last-year": "last-year",
    "last year": "last-year",
    "last-month": "last-month",
    "last month": "last-month",
    "yoy-match-weekday": "yoy-match-weekday",
    "yoy (match weekday)": "yoy-match-weekday",
}
_CUMULATIVE_MODE_ALIASES = {
    "mtd": "mtd",
    "month_to_date": "mtd",
    "month-to-date": "mtd",
    "ytd": "ytd",
    "year_to_date": "ytd",
    "year-to-date": "ytd",
    "rolling_days": "rolling_days",
    "rolling-days": "rolling_days",
}


def _require(obj: dict, key: str):
    if key not in obj:
        raise SemanticConfigError(f"Missing required key: {key}")
    return obj[key]


def parse_filter(raw: dict) -> Filter:
    return Filter(
        column=_require(raw, "column"),
        operator=_require(raw, "operator"),
        expression=str(_require(raw, "expression")),
        table=raw.get("table"),
        schema=raw.get("schema"),
    )


def parse_metric(raw: dict) -> Metric:
    return Metric(
        identifier=_require(raw, "identifier"),
        name=_require(raw, "name"),
        calculation=_require(raw, "calculation"),
        time=_require(raw, "time"),
        description=raw.get("description"),
        target_name=raw.get("target_name") or raw.get("targetName"),
        ai_context=raw.get("ai_context"),
        category=raw.get("category"),
        dimensions=list(raw.get("dimensions", []) or []),
        owner_emails=list(raw.get("owner_emails", []) or []),
        is_private=bool(raw.get("is_private", False)),
        is_unlisted=bool(raw.get("is_unlisted", False)),
        time_grains=list(raw.get("time_grains", []) or []),
        time_resampling=raw.get("time_resampling"),
        filters=[parse_filter(f) for f in (raw.get("filters", []) or [])],
        slices=[
            Slice(name=s["name"], filter=parse_filter(s["filter"]))
            for s in (raw.get("slices", []) or [])
        ],
        value=raw.get("value"),
        numerator=raw.get("numerator"),
        denominator=raw.get("denominator"),
        format=raw.get("format"),
        distinct_on=raw.get("distinct_on"),
        sql_expression=raw.get("sql_expression"),
        numerator_sql=raw.get("numerator_sql"),
        denominator_sql=raw.get("denominator_sql"),
    )


def parse_cross_module_metric(raw: dict) -> CrossModuleMetric:
    calculation = raw.get("calculation", "derived-ratio")
    return CrossModuleMetric(
        identifier=_require(raw, "identifier"),
        name=_require(raw, "name"),
        calculation=calculation,
        numerator_metric=_require(raw, "numerator_metric"),
        denominator_metric=_require(raw, "denominator_metric"),
        join_on=raw.get("join_on", "time"),
        join_type=raw.get("join_type", "inner"),
        description=raw.get("description"),
        format=raw.get("format"),
        target_name=raw.get("target_name") or raw.get("targetName"),
    )


def parse_module(raw: dict) -> Module:
    module_raw = _require(raw, "module")

    joins = []
    for join in module_raw.get("joinPaths", []) or []:
        joins.append(
            JoinPath(
                from_=JoinEndpoint(column=join["from"]["column"], table=join["from"].get("table")),
                to=JoinEndpoint(column=join["to"]["column"], table=join["to"].get("table")),
                type=join["type"],
            )
        )

    return Module(
        identifier=_require(module_raw, "identifier"),
        schema=_require(module_raw, "schema"),
        table=_require(module_raw, "table"),
        project=module_raw.get("project"),
        label=module_raw.get("label"),
        description=module_raw.get("description"),
        dimensions=[
            Dimension(
                column=d["column"],
                type=d["type"],
                label=d.get("label"),
                description=d.get("description"),
                target_column=d.get("target_column") or d.get("targetColumn"),
            )
            for d in (module_raw.get("dimensions", []) or [])
        ],
        metrics=[parse_metric(m) for m in (module_raw.get("metrics", []) or [])],
        join_paths=joins,
    )


def _validate_metric(module: Module, metric: Metric) -> None:
    if metric.calculation not in _ALLOWED_CALCULATIONS:
        raise SemanticConfigError(
            f"Metric '{metric.identifier}' has unsupported calculation '{metric.calculation}'"
        )

    required_by_calc = {
        "sum": ["value"],
        "count": [],
        "ratio": ["numerator", "denominator", "format"],
        "count-distinct": ["distinct_on"],
        "custom-value": ["sql_expression"],
        "custom-ratio": ["numerator_sql", "denominator_sql", "format"],
    }

    for field_name in required_by_calc[metric.calculation]:
        if not getattr(metric, field_name):
            raise SemanticConfigError(
                f"Metric '{metric.identifier}' missing required field '{field_name}' for calculation '{metric.calculation}'"
            )

    if metric.format and metric.format not in {"number", "percentage"}:
        raise SemanticConfigError(
            f"Metric '{metric.identifier}' has invalid format '{metric.format}'"
        )

    if metric.format and metric.calculation not in {"ratio", "custom-ratio"}:
        raise SemanticConfigError(
            f"Metric '{metric.identifier}' uses format with unsupported calculation '{metric.calculation}'"
        )

    if metric.ai_context is not None:
        if not isinstance(metric.ai_context, dict):
            raise SemanticConfigError(
                f"Metric '{metric.identifier}' has invalid ai_context (must be an object)"
            )
        synonyms = metric.ai_context.get("synonyms")
        if synonyms is not None:
            if not isinstance(synonyms, list) or not all(isinstance(s, str) for s in synonyms):
                raise SemanticConfigError(
                    f"Metric '{metric.identifier}' has invalid ai_context.synonyms (must be an array of strings)"
                )

    for grain in metric.time_grains:
        if grain not in _ALLOWED_TIME_GRAINS:
            raise SemanticConfigError(
                f"Metric '{metric.identifier}' has unsupported time_grain '{grain}'"
            )

    dim_columns = {d.column for d in module.dimensions}
    for dim in metric.dimensions:
        if dim.endswith(".*") or "." in dim:
            continue
        if dim not in dim_columns:
            raise SemanticConfigError(
                f"Metric '{metric.identifier}' references unknown dimension '{dim}' in module '{module.identifier}'"
            )

    slice_names = set()
    for sl in metric.slices:
        if sl.name in slice_names:
            raise SemanticConfigError(
                f"Metric '{metric.identifier}' has duplicate slice name '{sl.name}'"
            )
        slice_names.add(sl.name)

    for f in [*metric.filters, *(s.filter for s in metric.slices)]:
        if f.operator not in _ALLOWED_OPERATORS:
            raise SemanticConfigError(
                f"Metric '{metric.identifier}' has unsupported operator '{f.operator}'"
            )


def validate_modules(modules: list[Module], cross_module_metrics: list[CrossModuleMetric]) -> None:
    module_ids = set()
    module_tables = set()
    metric_ids = set()

    for module in modules:
        if module.identifier in module_ids:
            raise SemanticConfigError(f"Duplicate module identifier '{module.identifier}'")
        module_ids.add(module.identifier)

        if module.table in module_tables:
            raise SemanticConfigError(
                f"Duplicate module table '{module.table}' (table names must be unique in this compiler)"
            )
        module_tables.add(module.table)

        dim_cols = set()
        for dim in module.dimensions:
            if dim.column in dim_cols:
                raise SemanticConfigError(
                    f"Module '{module.identifier}' has duplicate dimension column '{dim.column}'"
                )
            dim_cols.add(dim.column)

        for metric in module.metrics:
            if metric.identifier in metric_ids:
                raise SemanticConfigError(f"Duplicate metric identifier '{metric.identifier}'")
            metric_ids.add(metric.identifier)
            _validate_metric(module, metric)

    for cm in cross_module_metrics:
        if cm.identifier in metric_ids:
            raise SemanticConfigError(f"Duplicate metric identifier '{cm.identifier}'")
        metric_ids.add(cm.identifier)

        if cm.calculation != "derived-ratio":
            raise SemanticConfigError(
                f"Cross module metric '{cm.identifier}' has unsupported calculation '{cm.calculation}'"
            )
        if cm.join_on != "time":
            raise SemanticConfigError(
                f"Cross module metric '{cm.identifier}' currently only supports join_on='time'"
            )
        if cm.join_type not in {"inner", "left", "full"}:
            raise SemanticConfigError(
                f"Cross module metric '{cm.identifier}' has unsupported join_type '{cm.join_type}'"
            )
        if cm.numerator_metric not in metric_ids:
            raise SemanticConfigError(
                f"Cross module metric '{cm.identifier}' references unknown numerator_metric '{cm.numerator_metric}'"
            )
        if cm.denominator_metric not in metric_ids:
            raise SemanticConfigError(
                f"Cross module metric '{cm.identifier}' references unknown denominator_metric '{cm.denominator_metric}'"
            )


def _extract_from_document(data: dict) -> tuple[list[Module], list[CrossModuleMetric]]:
    if "semantic_layer" in data and isinstance(data["semantic_layer"], dict):
        data = data["semantic_layer"]

    modules: list[Module] = []
    cross: list[CrossModuleMetric] = []

    if "module" in data:
        modules.append(parse_module(data))

    for module_raw in data.get("modules", []) or []:
        modules.append(parse_module({"module": module_raw}))

    for cm_raw in data.get("cross_module_metrics", []) or []:
        cross.append(parse_cross_module_metric(cm_raw))

    return modules, cross


def load_modules(path: str | Path) -> tuple[list[Module], list[CrossModuleMetric], list[Path]]:
    root = Path(path)
    if root.is_file():
        files = [root]
    else:
        files = sorted(
            [*root.rglob("*.yml"), *root.rglob("*.yaml")],
            key=lambda p: str(p),
        )
    if not files:
        raise SemanticConfigError(f"No YAML files found in: {root}")

    modules: list[Module] = []
    cross_module_metrics: list[CrossModuleMetric] = []
    for file in files:
        with file.open("r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        file_modules, file_cross = _extract_from_document(data)
        modules.extend(file_modules)
        cross_module_metrics.extend(file_cross)

    if not modules:
        raise SemanticConfigError("No modules found in provided YAML input")

    validate_modules(modules, cross_module_metrics)
    return modules, cross_module_metrics, files


def _normalize_time_grain(value: str | None) -> str | None:
    if value is None:
        return None
    grain = str(value).strip().lower()
    grain = _TIME_GRAIN_ALIASES.get(grain, grain)
    if grain not in _ALLOWED_TIME_GRAINS:
        raise SemanticConfigError(
            f"Unsupported timeGrain '{value}'. Allowed: none, daily, weekly, monthly, quarterly, yearly"
        )
    return grain


def _normalize_time_comparison(value: str | None) -> str | None:
    if value is None:
        return None
    key = str(value).strip().lower()
    normalized = _TIME_COMPARISON_ALIASES.get(key)
    if not normalized:
        raise SemanticConfigError(
            "Unsupported timeComparison. Allowed: YoY, MoM, Last Year, Last Month, YoY (Match Weekday)"
        )
    return normalized


def _normalize_cumulative_mode(value: str | None) -> str | None:
    if value is None:
        return None
    key = str(value).strip().lower()
    normalized = _CUMULATIVE_MODE_ALIASES.get(key)
    if not normalized:
        raise SemanticConfigError(
            "Unsupported cumulativeMode. Allowed: mtd, ytd, rolling_days"
        )
    return normalized


def parse_query_request(raw: dict) -> QueryRequest:
    cumulative_mode = _normalize_cumulative_mode(raw.get("cumulativeMode"))
    rolling_days_raw = raw.get("rollingDays")
    rolling_days = int(rolling_days_raw) if rolling_days_raw is not None else None

    if cumulative_mode == "rolling_days" and (rolling_days is None or rolling_days <= 0):
        raise SemanticConfigError("rollingDays must be a positive integer when cumulativeMode=rolling_days")
    if cumulative_mode != "rolling_days" and rolling_days is not None:
        raise SemanticConfigError("rollingDays is only supported when cumulativeMode=rolling_days")

    return QueryRequest(
        from_date=raw["fromDate"],
        to_date=raw["toDate"],
        time_grain=_normalize_time_grain(raw.get("timeGrain")),
        time_comparison=_normalize_time_comparison(raw.get("timeComparison")),
        target_series=raw.get("targetSeries"),
        cumulative_mode=cumulative_mode,
        rolling_days=rolling_days,
        exclude_open_period=bool(raw.get("excludeOpenPeriod", False)),
        exclude_today=bool(raw.get("excludeToday", False)),
        breakdown_dimension_ids=raw.get("breakdownDimensionIds", []) or [],
        slice_name=raw.get("sliceName"),
        filters=[
            QueryFilter(dimension_id=f["dimensionId"], filter_values=f["filterValues"])
            for f in (raw.get("filters", []) or [])
        ],
    )
