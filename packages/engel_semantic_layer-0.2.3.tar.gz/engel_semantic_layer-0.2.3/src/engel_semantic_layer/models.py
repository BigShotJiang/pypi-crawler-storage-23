from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass(slots=True)
class Dimension:
    column: str
    type: str
    label: str | None = None
    description: str | None = None
    target_column: str | None = None


@dataclass(slots=True)
class JoinEndpoint:
    column: str
    table: str | None = None


@dataclass(slots=True)
class JoinPath:
    from_: JoinEndpoint
    to: JoinEndpoint
    type: str


@dataclass(slots=True)
class Filter:
    column: str
    operator: str
    expression: str
    table: str | None = None
    schema: str | None = None


@dataclass(slots=True)
class Slice:
    name: str
    filter: Filter


@dataclass(slots=True)
class Metric:
    identifier: str
    name: str
    calculation: str
    time: str
    description: str | None = None
    target_name: str | None = None
    ai_context: dict[str, Any] | None = None
    category: str | None = None
    dimensions: list[str] = field(default_factory=list)
    owner_emails: list[str] = field(default_factory=list)
    is_private: bool = False
    is_unlisted: bool = False
    time_grains: list[str] = field(default_factory=list)
    time_resampling: str | None = None
    filters: list[Filter] = field(default_factory=list)
    slices: list[Slice] = field(default_factory=list)
    value: str | None = None
    numerator: str | None = None
    denominator: str | None = None
    format: str | None = None
    distinct_on: str | None = None
    sql_expression: str | None = None
    numerator_sql: str | None = None
    denominator_sql: str | None = None


@dataclass(slots=True)
class Module:
    identifier: str
    schema: str
    table: str
    project: str | None = None
    label: str | None = None
    description: str | None = None
    dimensions: list[Dimension] = field(default_factory=list)
    metrics: list[Metric] = field(default_factory=list)
    join_paths: list[JoinPath] = field(default_factory=list)

    @property
    def table_key(self) -> str:
        return self.table


@dataclass(slots=True)
class QueryFilter:
    dimension_id: str
    filter_values: list[str]


@dataclass(slots=True)
class CrossModuleMetric:
    identifier: str
    name: str
    calculation: str
    numerator_metric: str
    denominator_metric: str
    join_on: str = "time"
    join_type: str = "inner"
    description: str | None = None
    format: str | None = None
    target_name: str | None = None


@dataclass(slots=True)
class QueryRequest:
    from_date: str
    to_date: str
    time_grain: str | None = None
    time_comparison: str | None = None
    target_series: str | None = None
    cumulative_mode: str | None = None
    rolling_days: int | None = None
    exclude_open_period: bool = False
    exclude_today: bool = False
    breakdown_dimension_ids: list[str] = field(default_factory=list)
    slice_name: str | None = None
    filters: list[QueryFilter] = field(default_factory=list)


@dataclass(slots=True)
class CompiledQuery:
    sql: str
    metric_id: str
    module_id: str
    source_files: list[Path]
    metadata: dict[str, Any] = field(default_factory=dict)
