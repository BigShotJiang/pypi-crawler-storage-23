from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable


@dataclass(slots=True)
class ColumnRegistry:
    """Column metadata for optional strict column linting.

    Keys are (schema, table) and values are sets of column names.
    """

    columns_by_table: dict[tuple[str, str], set[str]]

    @classmethod
    def from_dict(cls, data: dict[str, dict[str, Iterable[str]]]) -> "ColumnRegistry":
        """Build from nested mapping {schema: {table: [columns...]}}."""
        out: dict[tuple[str, str], set[str]] = {}
        for schema, tables in data.items():
            for table, columns in tables.items():
                out[(schema, table)] = {str(c) for c in columns}
        return cls(columns_by_table=out)

    @classmethod
    def from_information_schema_rows(
        cls,
        rows: Iterable[dict],
        *,
        schema_key: str = "table_schema",
        table_key: str = "table_name",
        column_key: str = "column_name",
    ) -> "ColumnRegistry":
        """Build registry from INFORMATION_SCHEMA.COLUMNS-like rows."""
        out: dict[tuple[str, str], set[str]] = {}
        for row in rows:
            schema = str(row[schema_key])
            table = str(row[table_key])
            column = str(row[column_key])
            out.setdefault((schema, table), set()).add(column)
        return cls(columns_by_table=out)

    def has_column(self, schema: str, table: str, column: str) -> bool:
        return column in self.columns_by_table.get((schema, table), set())

    def has_table(self, schema: str, table: str) -> bool:
        return (schema, table) in self.columns_by_table

    def to_dict(self) -> dict[str, dict[str, list[str]]]:
        out: dict[str, dict[str, list[str]]] = {}
        for (schema, table), columns in sorted(self.columns_by_table.items()):
            out.setdefault(schema, {})[table] = sorted(columns)
        return out
