import os
import sys
import json
import hashlib
import logging
import warnings
import boto3
import httpx
import tomlkit
from botocore.exceptions import ClientError
from pathlib import Path
from poly_hammer_utils.constants import ENVIRONMENT
from poly_hammer_utils.utilities import shell, get_blender_executable

logger = logging.getLogger(__name__)

ACCESS_KEY = os.environ.get('AWS_ACCESS_KEY_ID')
SECRET_KEY = os.environ.get('AWS_SECRET_ACCESS_KEY')
REGION = os.environ.get('AWS_REGION')

BASE_URL = 'https://api.portal.staging.polyhammer.com'
if ENVIRONMENT == 'production':
    BASE_URL = 'https://api.portal.polyhammer.com'

PORTAL_API_KEY = os.environ.get('PORTAL_API_KEY')

def sync_extensions_from_s3(
        repo_folder: Path,
        bucket: str,
        s3_prefix: str = ''
    ) -> list[Path]:
    """
    Downloads all .zip extension files from an S3 folder to a local directory.

    Args:
        repo_folder (Path): Local directory to download files to.
        bucket (str): The S3 bucket name.
        s3_prefix (str, optional): Prefix (folder path) in S3. Defaults to ''.

    Returns:
        list[Path]: List of local file paths that were downloaded.
    """
    s3_client = boto3.client(
        's3',
        aws_access_key_id=ACCESS_KEY,
        aws_secret_access_key=SECRET_KEY,
        region_name=REGION,
    )

    repo_folder.mkdir(parents=True, exist_ok=True)

    # List all objects in the S3 prefix
    prefix = f'{s3_prefix}/' if s3_prefix and not s3_prefix.endswith('/') else s3_prefix
    logger.info(f'Listing objects in s3://{bucket}/{prefix}')

    downloaded_files = []
    paginator = s3_client.get_paginator('list_objects_v2')

    for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
        for obj in page.get('Contents', []):
            key = obj['Key']
            filename = key.split('/')[-1]

            # Only download .zip files
            if not filename.endswith('.zip'):
                continue

            local_path = repo_folder / filename
            logger.info(f'Downloading s3://{bucket}/{key} to "{local_path}"')
            s3_client.download_file(bucket, key, str(local_path))
            downloaded_files.append(local_path)

    logger.info(f'Successfully downloaded {len(downloaded_files)} file(s) from S3')
    return downloaded_files


def upload_extensions_to_s3(
        repo_folder: Path,
        bucket: str,
        s3_prefix: str = ''
    ) -> list[str]:
    """
    Uploads extension .zip files and the index.json to S3.
    Only uploads .zip files if they are newer than the S3 version.
    Always uploads the index.json file.

    Args:
        repo_folder (Path): Local directory containing files to upload.
        bucket (str): The S3 bucket name.
        s3_prefix (str, optional): Prefix (folder path) in S3. Defaults to ''.

    Returns:
        list[str]: List of S3 keys that were uploaded.
    """
    s3_client = boto3.client(
        's3',
        aws_access_key_id=ACCESS_KEY,
        aws_secret_access_key=SECRET_KEY,
        region_name=REGION,
    )

    # Build a map of S3 object keys to their last modified times
    prefix = f'{s3_prefix}/' if s3_prefix and not s3_prefix.endswith('/') else s3_prefix
    s3_objects = {}
    paginator = s3_client.get_paginator('list_objects_v2')
    for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
        for obj in page.get('Contents', []):
            s3_objects[obj['Key']] = obj['LastModified']

    uploaded_keys = []
    # Collect .json and .zip files
    file_paths = list(repo_folder.glob('*.json')) + list(repo_folder.glob('*.zip'))

    for file_path in file_paths:
        if not file_path.exists():
            logger.warning(f'File "{file_path}" does not exist, skipping')
            continue

        # Build the S3 key
        s3_key = f'{s3_prefix}/{file_path.name}' if s3_prefix else file_path.name
        s3_key = s3_key.lstrip('/')

        # For .zip files, check if local file is newer than S3 version
        if file_path.suffix == '.zip' and s3_key in s3_objects:
            import datetime
            local_mtime = datetime.datetime.fromtimestamp(
                file_path.stat().st_mtime, 
                tz=datetime.timezone.utc
            )
            s3_mtime = s3_objects[s3_key]
            if local_mtime <= s3_mtime:
                logger.info(f'Skipping "{file_path.name}" (not newer than S3 version)')
                continue

        # Determine content type
        if file_path.suffix == '.zip':
            content_type = 'application/zip'
        elif file_path.suffix == '.json':
            content_type = 'application/json'
        else:
            content_type = 'application/octet-stream'

        logger.info(f'Uploading "{file_path}" to s3://{bucket}/{s3_key}')
        s3_client.upload_file(
            Filename=str(file_path),
            Bucket=bucket,
            Key=s3_key,
            ExtraArgs={'ContentType': content_type}
        )
        uploaded_keys.append(s3_key)

    logger.info(f'Successfully uploaded {len(uploaded_keys)} file(s) to S3')
    return uploaded_keys


def _get_s3_client():
    """Create and return a configured boto3 S3 client."""
    return boto3.client(
        's3',
        aws_access_key_id=ACCESS_KEY,
        aws_secret_access_key=SECRET_KEY,
        region_name=REGION,
    )


def _normalize_s3_prefix(s3_prefix: str) -> str:
    """Ensure the S3 prefix ends with a trailing slash."""
    if s3_prefix and not s3_prefix.endswith('/'):
        return f'{s3_prefix}/'
    return s3_prefix


def fetch_index_from_s3(
        bucket: str,
        s3_prefix: str = '',
        s3_client=None,
    ) -> dict:
    """
    Fetch and parse the existing index.json from S3.

    Args:
        bucket: The S3 bucket name.
        s3_prefix: Prefix (folder path) in S3.
        s3_client: Optional pre-configured boto3 S3 client.

    Returns:
        Parsed index dict, or an empty template if the index doesn't exist.
    """
    if s3_client is None:
        s3_client = _get_s3_client()

    prefix = _normalize_s3_prefix(s3_prefix)
    s3_key = f'{prefix}index.json'

    try:
        response = s3_client.get_object(Bucket=bucket, Key=s3_key)
        body = response['Body'].read().decode('utf-8')
        index = json.loads(body)
        logger.info(f'Fetched existing index from s3://{bucket}/{s3_key} ({len(index.get("data", []))} entries)')
        return index
    except ClientError as e:
        error_code = e.response['Error']['Code']
        if error_code in ('NoSuchKey', '404'):
            logger.info(f'No existing index.json found at s3://{bucket}/{s3_key}, starting fresh')
            return {'version': 'v1', 'blocklist': [], 'data': []}
        raise


def list_s3_zip_objects(
        bucket: str,
        s3_prefix: str = '',
        s3_client=None,
    ) -> set[str]:
    """
    List all .zip filenames (base names only) under an S3 prefix.

    Args:
        bucket: The S3 bucket name.
        s3_prefix: Prefix (folder path) in S3.
        s3_client: Optional pre-configured boto3 S3 client.

    Returns:
        Set of .zip filenames found in S3.
    """
    if s3_client is None:
        s3_client = _get_s3_client()

    prefix = _normalize_s3_prefix(s3_prefix)
    zip_filenames = set()
    paginator = s3_client.get_paginator('list_objects_v2')

    for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
        for obj in page.get('Contents', []):
            filename = obj['Key'].split('/')[-1]
            if filename.endswith('.zip'):
                zip_filenames.add(filename)

    logger.info(f'Found {len(zip_filenames)} .zip object(s) in s3://{bucket}/{prefix}')
    return zip_filenames


def _compute_file_hash(file_path: Path) -> str:
    """Compute SHA-256 hash of a file, returned as 'sha256:<hex>'."""
    sha256 = hashlib.sha256()
    with open(file_path, 'rb') as f:
        for chunk in iter(lambda: f.read(8192), b''):
            sha256.update(chunk)
    return f'sha256:{sha256.hexdigest()}'


def _parse_platform_from_zip_name(filename: str) -> list[str]:
    """
    Parse the platform string from a Blender extension zip filename.

    Expected format: {addon_id}-{version}-{platform}_{arch}.zip
    e.g. meta_human_dna_pro-0.5.21-linux_x64.zip -> ['linux-x64']
    """
    stem = Path(filename).stem  # strip .zip
    # The platform_arch is the last segment after the final '-'
    last_dash = stem.rfind('-')
    if last_dash == -1:
        return []
    platform_arch = stem[last_dash + 1:]  # e.g. 'linux_x64'
    # Convert underscore to dash for Blender's format: 'linux-x64'
    return [platform_arch.replace('_', '-')]


def build_entry_from_manifest(
        manifest: dict,
        zip_file: Path,
    ) -> dict:
    """
    Build a single index.json entry from a parsed blender_manifest.toml and
    a locally available .zip file.

    Args:
        manifest: Parsed blender_manifest.toml dict.
        zip_file: Path to the local .zip file.

    Returns:
        A dict representing one entry in the index 'data' array.
    """
    entry = {
        'schema_version': manifest.get('schema_version', '1.0.0'),
        'id': manifest.get('id', ''),
        'name': manifest.get('name', ''),
        'tagline': manifest.get('tagline', ''),
        'version': manifest.get('version', ''),
        'type': manifest.get('type', 'add-on'),
        'maintainer': manifest.get('maintainer', ''),
        'license': list(manifest.get('license', [])),
        'blender_version_min': manifest.get('blender_version_min', ''),
    }

    # Optional fields
    if manifest.get('blender_version_max'):
        entry['blender_version_max'] = manifest['blender_version_max']
    if manifest.get('website'):
        entry['website'] = manifest['website']
    if manifest.get('copyright'):
        entry['copyright'] = list(manifest['copyright'])
    if manifest.get('permissions'):
        entry['permissions'] = dict(manifest['permissions'])
    if manifest.get('tags'):
        entry['tags'] = list(manifest['tags'])

    # Platform is derived from the zip filename, not the manifest
    # (each zip is platform-specific after --split-platforms)
    entry['platforms'] = _parse_platform_from_zip_name(zip_file.name)

    # Python versions from manifest
    if manifest.get('python_versions'):
        entry['python_versions'] = list(manifest['python_versions'])

    # Archive fields computed from the local file
    entry['archive_url'] = f'./{zip_file.name}'
    entry['archive_size'] = zip_file.stat().st_size
    entry['archive_hash'] = _compute_file_hash(zip_file)

    return entry


def build_extension_index(
        repo_folder: Path,
        bucket: str,
        s3_prefix: str,
        local_zip_files: list[Path],
        source_folder: Path,
        s3_client=None,
    ) -> Path:
    """
    Build an index.json without needing Blender CLI or downloading old zips.

    Merges entries from the existing S3 index.json (for older versions) with
    new entries built from the local blender_manifest.toml and newly-built
    .zip files. Reconciles against actual S3 objects to drop orphaned entries.

    Args:
        repo_folder: Local directory where index.json will be written.
        bucket: The S3 bucket name.
        s3_prefix: Prefix (folder path) in S3 for this extension.
        local_zip_files: List of locally-built .zip file paths.
        source_folder: Path to the addon source containing blender_manifest.toml.
        s3_client: Optional pre-configured boto3 S3 client.

    Returns:
        Path to the generated index.json.
    """
    if s3_client is None:
        s3_client = _get_s3_client()

    # Read the manifest from the source folder
    manifest_path = source_folder / 'blender_manifest.toml'
    if not manifest_path.exists():
        raise FileNotFoundError(f'blender_manifest.toml not found in {source_folder}')
    manifest = tomlkit.parse(manifest_path.read_text())

    # Fetch the existing index from S3
    existing_index = fetch_index_from_s3(
        bucket=bucket,
        s3_prefix=s3_prefix,
        s3_client=s3_client,
    )

    # List actual zip objects currently in S3
    s3_zips = list_s3_zip_objects(
        bucket=bucket,
        s3_prefix=s3_prefix,
        s3_client=s3_client,
    )

    # Also include the local zip filenames (they will be uploaded after this)
    local_zip_names = {zf.name for zf in local_zip_files}
    all_known_zips = s3_zips | local_zip_names

    # Build new entries for the locally-built zips
    new_entries = []
    for zip_file in local_zip_files:
        entry = build_entry_from_manifest(manifest=manifest, zip_file=zip_file)
        new_entries.append(entry)
        logger.info(f'Built index entry for {zip_file.name} (platform={entry["platforms"]})')

    # Build a dedup key set from the new entries so we can replace old entries
    # for the same id + version + platform combo
    new_entry_keys = set()
    for entry in new_entries:
        key = (entry['id'], entry['version'], tuple(entry.get('platforms', [])))
        new_entry_keys.add(key)

    # Filter the existing index: keep entries whose zip still exists in S3
    # and that are not superseded by a new entry
    filtered_data = []
    for entry in existing_index.get('data', []):
        archive_url = entry.get('archive_url', '')
        filename = archive_url.lstrip('./')

        # Check if this entry's zip exists in S3 or is being newly uploaded
        if filename not in all_known_zips:
            logger.warning(
                f'Dropping orphaned index entry: {entry.get("id")} '
                f'v{entry.get("version")} {entry.get("platforms")} '
                f'(zip "{filename}" not found in S3)'
            )
            continue

        # Check if this entry is superseded by a new build
        key = (entry.get('id'), entry.get('version'), tuple(entry.get('platforms', [])))
        if key in new_entry_keys:
            logger.info(
                f'Replacing existing entry: {entry.get("id")} '
                f'v{entry.get("version")} {entry.get("platforms")}'
            )
            continue

        filtered_data.append(entry)

    # Combine: old (filtered) entries + new entries
    index = {
        'version': existing_index.get('version', 'v1'),
        'blocklist': existing_index.get('blocklist', []),
        'data': filtered_data + new_entries,
    }

    # Write the index
    repo_folder.mkdir(parents=True, exist_ok=True)
    index_path = repo_folder / 'index.json'
    index_path.write_text(json.dumps(index, indent=2))
    logger.info(f'Wrote index.json with {len(index["data"])} entries to {index_path}')

    return index_path


def generate_extension_index(
        repo_folder: Path, 
        blender_version: str = '4.5',
        docker: bool = False,
    ):
    """
    .. deprecated::
        Use :func:`build_extension_index` instead, which generates the index
        without requiring Blender CLI or downloading old .zip files from S3.
    """
    warnings.warn(
        'generate_extension_index is deprecated. Use build_extension_index instead.',
        DeprecationWarning,
        stacklevel=2,
    )
    blender_executable = get_blender_executable(version=blender_version)

    if docker:
        command = (
            f'docker run '
            f'-v {repo_folder.as_posix()}:/repo '
            f'ghcr.io/poly-hammer/blender-linux:{blender_version} '
            f'blender --command extension server-generate --repo-dir /repo'
        )
    else:
        # wrap in quotes for Windows paths with spaces
        if sys.platform == 'win32':
            blender_executable = f'"{blender_executable}"'

        command = f'{blender_executable} --command extension server-generate --repo-dir {repo_folder.as_posix()}'

    shell(command)

def trigger_poly_hammer_portal_extension_index_refresh() -> httpx.Response:
    """Trigger sync of all extensions from S3."""
    logger.info("Triggering extension sync...")
    
    url = f"{BASE_URL}/v1/admin/extensions/sync"
    headers = {"X-Admin-API-Key": PORTAL_API_KEY}

    response = httpx.post(url, headers=headers, timeout=60.0)

    if response.status_code == 200:
        data = response.json()
        logger.info("Sync complete!")
        logger.info(f"Extensions processed: {data['extensions_processed']}")
        logger.info(f"Platforms synced: {data['total_platforms_synced']}")
        
        if data.get("errors"):
            logger.error(f"Errors: {data['errors']}")
        
        if data.get("details"):
            logger.info("Extension details:")
            for ext in data["details"]:
                logger.info(f"- {ext['extension_id']}: {ext['versions_synced']} versions, {ext['platforms_synced']} platforms")
    else:
        logger.error(f"Failed with status {response.status_code}")
        logger.error(f"Response: {response.text}")

    return response

def update_extension_index(
        repo_folder: Path, 
        bucket: str,
        s3_folder: str,
        local_zip_files: list[Path],
        source_folder: Path,
    ):
    """
    Build the extension index from the local manifest + S3 state, upload
    new .zip files and the updated index.json, then trigger a portal refresh.

    This replaces the old workflow that required downloading all zips from S3
    and invoking Blender CLI to regenerate the index.

    Args:
        repo_folder: Local directory containing newly-built .zip files.
        bucket: The S3 bucket name.
        s3_folder: The folder path in S3.
        local_zip_files: List of newly-built .zip file paths to include.
        source_folder: Path to the addon source containing blender_manifest.toml.
    """
    # Step 1: Build index.json from manifest + existing S3 index + S3 object list
    build_extension_index(
        repo_folder=repo_folder,
        bucket=bucket,
        s3_prefix=s3_folder,
        local_zip_files=local_zip_files,
        source_folder=source_folder,
    )

    # Step 2: Upload new/modified .zip files and the updated index.json back to S3
    upload_extensions_to_s3(
        repo_folder=repo_folder,
        bucket=bucket,
        s3_prefix=s3_folder,
    )

    # Step 3: Trigger the Poly Hammer Portal to refresh its extension index
    trigger_poly_hammer_portal_extension_index_refresh()