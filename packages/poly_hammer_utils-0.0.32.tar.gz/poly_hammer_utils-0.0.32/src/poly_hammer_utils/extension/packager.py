import os
import sys
import tomlkit
import logging
from pathlib import Path
from poly_hammer_utils.utilities import shell, get_blender_executable

logger = logging.getLogger(__name__)

def get_addon_id(
        source_folder: Path,
    ) -> str:
    file_path = source_folder / 'blender_manifest.toml'
    # Read the id from the manifest file
    if file_path.exists():
        manifest_data = tomlkit.parse(file_path.read_text())
        return manifest_data.get('id', '')
    return ''


def get_addon_version(
        source_folder: Path,
    ) -> str:
    file_path = source_folder / 'blender_manifest.toml'
    # Read the version from the manifest file
    if file_path.exists():
        manifest_data = tomlkit.parse(file_path.read_text())
        return manifest_data.get('version', '')
    return ''

def package_extension(
        source_folder: Path, 
        output_folder: Path,
        blender_version: str = '4.5',
        split_platforms: bool = False,
        docker: bool = False,
    ) -> list[Path]:
    blender_executable = get_blender_executable(version=blender_version)

    addon_version = get_addon_version(source_folder=source_folder)
    addon_id = get_addon_id(source_folder=source_folder)
    logger.info(f'Packaging extension {addon_id} version: {addon_version}')

    # Ensure output folder exists before Docker mounts it, otherwise Docker
    # creates it as root and the --user flag causes permission errors.
    output_folder.mkdir(parents=True, exist_ok=True)

    if docker:
        # On Linux, set user to avoid permission issues with Docker-created files
        user_flag = ''
        if sys.platform != 'win32':
            user_flag = f'--user {os.getuid()}:{os.getgid()} '
        
        command = (
            f'docker run '
            f'{user_flag}'
            f'-v {source_folder.as_posix()}:/src '
            f'-v {output_folder.as_posix()}:/output '
            f'ghcr.io/poly-hammer/blender-linux:{blender_version} '
            f'blender --command extension build --source-dir /src --output-dir /output'
        )
    else:
        # wrap in quotes for Windows paths with spaces
        if sys.platform == 'win32':
            blender_executable = f'"{blender_executable}"'

        command = f'{blender_executable} --command extension build --source-dir {source_folder.as_posix()} --output-dir {output_folder.as_posix()}'
    
    if split_platforms:
        command += ' --split-platforms'
        
    shell(command, cwd=source_folder)

    return list(output_folder.glob(f'{addon_id}-{addon_version}-*.zip'))


def rename_addon(
        toml_file_path: Path,
        constants_file_path: Path,
        addon_id: str,
        new_addon_id: str,
        new_addon_name: str,
):
    # Update the id and name in the blender_manifest.toml
    if not toml_file_path.exists():
        raise FileNotFoundError(f'Manifest file not found: {toml_file_path}')

    manifest_data = tomlkit.parse(toml_file_path.read_text())
    manifest_data['id'] = new_addon_id
    manifest_data['name'] = new_addon_name
    toml_file_path.write_text(tomlkit.dumps(manifest_data))
    logger.info(f'Updated manifest: id="{new_addon_id}", name="{new_addon_name}"')

    # Update ToolInfo.NAME in constants.py
    if not constants_file_path.exists():
        raise FileNotFoundError(f'Constants file not found: {constants_file_path}')

    constants_text = constants_file_path.read_text()
    updated_text = constants_text.replace(
        f'NAME: str = "{addon_id}"',
        f'NAME: str = "{new_addon_id}"',
    )
    if updated_text == constants_text:
        logger.warning(f'Could not find ToolInfo.NAME with value "{addon_id}" in {constants_file_path}')
    else:
        constants_file_path.write_text(updated_text)
        logger.info(f'Updated ToolInfo.NAME to "{new_addon_id}" in {constants_file_path}')

    