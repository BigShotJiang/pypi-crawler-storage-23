"""The root package of Eventum SDK."""

__version__ = '2.0.2'
