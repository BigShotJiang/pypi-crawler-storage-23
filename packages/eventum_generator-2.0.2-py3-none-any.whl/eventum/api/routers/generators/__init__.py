"""Generator router package."""

from eventum.api.routers.generators.routes import router, ws_router

__all__ = ['router', 'ws_router']
