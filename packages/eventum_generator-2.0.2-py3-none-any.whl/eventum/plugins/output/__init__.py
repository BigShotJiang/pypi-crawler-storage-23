"""Output plugins package."""
