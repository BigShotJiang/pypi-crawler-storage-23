"""Package with http output plugin implementation."""
