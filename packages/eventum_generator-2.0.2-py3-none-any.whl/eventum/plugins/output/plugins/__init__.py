"""Output plugins definition package."""
