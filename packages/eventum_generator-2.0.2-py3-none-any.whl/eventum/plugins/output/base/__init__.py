"""Package with definition of base output plugin."""
