"""Package with http input plugin implementation."""
