"""Package with web UI service definition."""
