"""
Doit Agent - Core Configuration
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

# Version
VERSION = "1.0.0"
DB_SCHEMA_VERSION = 1

# Paths
if sys.platform == "win32":
    BASE_DIR = Path(os.environ.get("APPDATA", Path.home())) / "doit"
elif sys.platform == "darwin":
    BASE_DIR = Path.home() / "Library" / "Application Support" / "doit"
else:
    BASE_DIR = Path.home() / ".config" / "doit"

DATA_DIR = BASE_DIR / "data"
LOG_DIR = BASE_DIR / "logs"
PLUGIN_DIR = BASE_DIR / "plugins"
BACKUP_DIR = BASE_DIR / "backups"
LOCK_FILE = BASE_DIR / "doit.lock"
DB_PATH = DATA_DIR / "doit.db"
CONFIG_PATH = DATA_DIR / "config.enc"
AUDIT_LOG = LOG_DIR / "audit.log"
APP_LOG = LOG_DIR / "app.log"

# Task engine
MAX_WORKERS = 4
TASK_TIMEOUT_DEFAULT = 300  # seconds
TASK_MAX_RETRIES = 3
TASK_RETRY_DELAY = 5

# Resource limits
MAX_CPU_PERCENT = 80
MAX_MEMORY_MB = 512
MAX_DISK_WRITE_MB = 500
MAX_EXEC_TIME = 300
AI_RATE_LIMIT_PER_MIN = 20

# Network
TELEGRAM_POLL_TIMEOUT = 30
TELEGRAM_RETRY_MAX = 60  # max backoff seconds
HTTP_TIMEOUT = 30

# Security
BLOCKED_PATHS = [
    "/etc",  # All of /etc (covers passwd, shadow, hosts, sudoers, etc.)
    "/boot",
    "/sys",
    "/proc",
    "C:\\Windows\\System32",
    "C:\\Windows\\SysWOW64",
]
BLOCKED_COMMANDS = [
    "rm -rf /", "mkfs", "dd if=", ":(){:|:&};:",
    "chmod -R 777 /", "chown -R",
]

# AI providers
AI_PROVIDERS = {
    "nvidia": {
        "name": "NVIDIA NIM",
        "base_url": "https://integrate.api.nvidia.com/v1",
        "models": [
            {"id": "meta/llama-3.3-70b-instruct", "label": "Llama 3.3 70B Instruct", "free": True},
            {"id": "nvidia/llama-3.1-nemotron-ultra-253b-v1", "label": "Nemotron Ultra 253B", "free": False},
            {"id": "meta/llama-3.1-8b-instruct", "label": "Llama 3.1 8B Instruct", "free": True},
            {"id": "mistralai/mistral-7b-instruct-v0.3", "label": "Mistral 7B Instruct", "free": True},
            {"id": "nvidia/mistral-nemo-minitron-8b-8k-instruct", "label": "Mistral NeMo Minitron 8B", "free": False},
        ],
    },
    "zhipu": {
        "name": "Zhipu AI (z.ai)",
        "base_url": "https://open.bigmodel.cn/api/paas/v4",
        "models": [
            {"id": "glm-4-flash", "label": "GLM-4 Flash", "free": True},
            {"id": "glm-4-air", "label": "GLM-4 Air", "free": False},
            {"id": "glm-4", "label": "GLM-4", "free": False},
            {"id": "glm-4-long", "label": "GLM-4 Long (128K)", "free": False},
            {"id": "glm-3-turbo", "label": "GLM-3 Turbo", "free": True},
        ],
    },
    "openai": {
        "name": "OpenAI",
        "base_url": "https://api.openai.com/v1",
        "models": [
            {"id": "gpt-4o-mini", "label": "GPT-4o Mini", "free": False},
            {"id": "gpt-4o", "label": "GPT-4o", "free": False},
            {"id": "gpt-4-turbo", "label": "GPT-4 Turbo", "free": False},
            {"id": "gpt-3.5-turbo", "label": "GPT-3.5 Turbo", "free": False},
            {"id": "o1-mini", "label": "o1 Mini", "free": False},
        ],
    },
    "anthropic": {
        "name": "Anthropic",
        "base_url": "https://api.anthropic.com/v1",
        "models": [
            {"id": "claude-3-haiku-20240307", "label": "Claude 3 Haiku", "free": False},
            {"id": "claude-3-5-sonnet-20241022", "label": "Claude 3.5 Sonnet", "free": False},
            {"id": "claude-3-opus-20240229", "label": "Claude 3 Opus", "free": False},
            {"id": "claude-3-5-haiku-20241022", "label": "Claude 3.5 Haiku", "free": False},
            {"id": "claude-3-sonnet-20240229", "label": "Claude 3 Sonnet", "free": False},
        ],
    },
    "ollama": {
        "name": "Ollama (Local)",
        "base_url": "http://localhost:11434/v1",
        "models": [
            {"id": "llama3.2", "label": "Llama 3.2", "free": True},
            {"id": "mistral", "label": "Mistral 7B", "free": True},
            {"id": "gemma2", "label": "Gemma 2", "free": True},
            {"id": "qwen2.5", "label": "Qwen 2.5", "free": True},
            {"id": "phi3", "label": "Phi-3", "free": True},
        ],
    },
    "custom": {
        "name": "Custom Endpoint",
        "base_url": None,
        "models": [],
    },
}
