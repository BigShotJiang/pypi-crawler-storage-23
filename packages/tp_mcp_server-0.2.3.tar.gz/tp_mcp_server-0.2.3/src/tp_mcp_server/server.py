"""TrainingPeaks MCP Server entry point."""

import logging

from mcp.server.fastmcp import FastMCP

import tp_mcp_server.mcp_instance as mcp_module
from tp_mcp_server.api.client import setup_api_client
from tp_mcp_server.config import get_config

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("tp_mcp_server")

# Load config
config = get_config()

# Create FastMCP instance
mcp = FastMCP("trainingpeaks", lifespan=setup_api_client)

# Set shared instance to break circular imports
mcp_module.mcp = mcp

# Import tools — they self-register via @mcp.tool() decorators
from tp_mcp_server.tools.auth import tp_auth_status, tp_refresh_auth  # noqa: E402, F401
from tp_mcp_server.tools.profile import tp_get_profile  # noqa: E402, F401
from tp_mcp_server.tools.workouts import tp_get_workouts, tp_get_workout  # noqa: E402, F401
from tp_mcp_server.tools.fitness import tp_get_fitness  # noqa: E402, F401
from tp_mcp_server.tools.peaks import tp_get_peaks, tp_get_workout_prs  # noqa: E402, F401
from tp_mcp_server.tools.analytics import (  # noqa: E402, F401
    tp_training_load_summary,
    tp_fitness_trend,
    tp_workout_analysis,
    tp_performance_summary,
    tp_training_zones_distribution,
)


def main():
    """Run the MCP server with stdio transport."""
    logger.info("Starting TrainingPeaks MCP server...")
    mcp.run()


if __name__ == "__main__":
    main()
