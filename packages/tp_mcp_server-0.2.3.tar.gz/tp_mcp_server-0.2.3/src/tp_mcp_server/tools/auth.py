"""Authentication status and refresh tools."""

from tp_mcp_server.api.client import (
    clear_token,
    is_authenticated,
    make_tp_request,
)
from tp_mcp_server.api.endpoints import TOKEN_URL
from tp_mcp_server.auth.storage import get_cookie
from tp_mcp_server.mcp_instance import mcp


@mcp.tool()
async def tp_auth_status() -> str:
    """Check TrainingPeaks authentication status.

    Returns whether you have a valid auth cookie and bearer token.
    If not authenticated, provides instructions for setting up credentials.
    """
    cookie = get_cookie()
    if not cookie:
        return (
            "Not authenticated.\n\n"
            "To authenticate, set the TP_AUTH_COOKIE environment variable:\n"
            "1. Log in to trainingpeaks.com in your browser\n"
            "2. Open DevTools > Application > Cookies\n"
            "3. Copy the value of 'Production_tpAuth'\n"
            "4. Set TP_AUTH_COOKIE=<value> in your .env file"
        )

    if is_authenticated():
        return "Authenticated. Bearer token is valid and cached."

    # Try to get a fresh token
    result = await make_tp_request(TOKEN_URL)
    if isinstance(result, dict) and result.get("error"):
        return f"Cookie found but authentication failed: {result.get('message')}"

    return "Authenticated successfully. Bearer token obtained."


@mcp.tool()
async def tp_refresh_auth() -> str:
    """Force refresh the TrainingPeaks bearer token.

    Use this if you're getting authentication errors.
    Clears the cached token and obtains a fresh one from the auth cookie.
    """
    clear_token()

    cookie = get_cookie()
    if not cookie:
        return (
            "No auth cookie available. "
            "Please set TP_AUTH_COOKIE in your .env file first."
        )

    result = await make_tp_request(TOKEN_URL)
    if isinstance(result, dict) and result.get("error"):
        return f"Token refresh failed: {result.get('message')}"

    return "Bearer token refreshed successfully."
