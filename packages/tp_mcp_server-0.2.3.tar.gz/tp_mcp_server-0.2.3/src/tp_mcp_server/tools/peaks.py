"""Personal records / peaks tools."""

from collections import defaultdict
from typing import Any

from tp_mcp_server.api.client import make_tp_request
from tp_mcp_server.api.endpoints import WORKOUTS_URL, WORKOUT_PRS_URL
from tp_mcp_server.config import get_config
from tp_mcp_server.mcp_instance import mcp
from tp_mcp_server.models.peaks import PeakRecord, PR_TYPE_LABELS
from tp_mcp_server.models.workout import WORKOUT_TYPES
from tp_mcp_server.utils.dates import parse_date_range, get_date_ago


def _resolve_athlete_id() -> tuple[str, str | None]:
    config = get_config()
    if not config.athlete_id:
        return "", (
            "No athlete ID available. Run tp_get_profile first to auto-detect it, "
            "or set ATHLETE_ID in your .env file."
        )
    return config.athlete_id, None


# Map sport names to workout type IDs
SPORT_TYPE_IDS = {
    "bike": 2,
    "run": 3,
    "swim": 1,
    "hike": 13,
}


@mcp.tool()
async def tp_get_workout_prs(workout_id: int) -> str:
    """Get personal records from a specific workout.

    Args:
        workout_id: The TrainingPeaks workout ID.

    Returns all PRs achieved in this workout, grouped by class (Power, HR, etc.)
    and time frame (All-Time, Last 90 Days, etc.).
    """
    aid, err = _resolve_athlete_id()
    if err:
        return err

    url = WORKOUT_PRS_URL.format(athlete_id=aid, workout_id=workout_id)
    result: Any = await make_tp_request(url)

    if isinstance(result, dict) and result.get("error"):
        return f"Error fetching workout PRs: {result.get('message')}"

    if not isinstance(result, dict):
        return "Unexpected response format."

    prs_data = result.get("personalRecords", [])
    if not prs_data:
        count = result.get("personalRecordCount", 0)
        if result.get("calcsPending"):
            return "PR calculations are still pending for this workout. Try again later."
        return f"No personal records found for workout {workout_id}."

    records = [PeakRecord.from_api(p) for p in prs_data if not p.get("invalid")]

    # Group by class, then by type
    by_class: dict[str, dict[str, list[PeakRecord]]] = defaultdict(lambda: defaultdict(list))
    for r in records:
        by_class[r.pr_class][r.pr_type].append(r)

    lines = [f"Personal Records for Workout {workout_id}"]
    lines.append(f"Total: {len(records)} PRs\n")

    for pr_class, types in sorted(by_class.items()):
        lines.append(f"## {pr_class}")
        for pr_type, recs in sorted(types.items()):
            for r in sorted(recs, key=lambda x: x.rank):
                lines.append(f"  {r.format()}")
        lines.append("")

    return "\n".join(lines)


@mcp.tool()
async def tp_get_peaks(
    sport: str = "Bike",
    days: int = 90,
    pr_class: str | None = None,
) -> str:
    """Get personal records by scanning recent workouts for a given sport.

    Args:
        sport: Sport type — "Bike", "Run", "Swim", or "Hike" (default "Bike").
        days: Number of days to scan (default 90, max 365).
        pr_class: Filter by PR class — "Power", "HeartRate", or None for all.

    Scans workouts that have PRs and aggregates the best values per type.
    Shows the top record for each duration/distance across the time range.
    """
    aid, err = _resolve_athlete_id()
    if err:
        return err

    days = min(days, 365)
    sport_lower = sport.lower()
    type_id = SPORT_TYPE_IDS.get(sport_lower)
    if type_id is None:
        return f"Unknown sport '{sport}'. Use: Bike, Run, Swim, or Hike."

    # Fetch workouts in 90-day chunks
    all_workouts = []
    end = parse_date_range(None, None)[1]  # today
    remaining_days = days

    while remaining_days > 0:
        chunk = min(remaining_days, 90)
        start = get_date_ago(days - (days - remaining_days) + chunk - 1)
        chunk_end = get_date_ago(days - remaining_days) if remaining_days < days else end

        # Recalculate properly
        from datetime import datetime, timedelta
        end_dt = datetime.strptime(end, "%Y-%m-%d")
        chunk_end_dt = end_dt - timedelta(days=(days - remaining_days))
        chunk_start_dt = chunk_end_dt - timedelta(days=chunk)
        chunk_start = chunk_start_dt.strftime("%Y-%m-%d")
        chunk_end = chunk_end_dt.strftime("%Y-%m-%d")

        url = WORKOUTS_URL.format(
            athlete_id=aid, start_date=chunk_start, end_date=chunk_end
        )
        result = await make_tp_request(url)
        if isinstance(result, list):
            all_workouts.extend(result)
        remaining_days -= chunk

    # Filter to sport + has PRs
    pr_workouts = [
        w for w in all_workouts
        if w.get("workoutTypeValueId") == type_id
        and w.get("personalRecordCount", 0) > 0
    ]

    if not pr_workouts:
        return f"No {sport} workouts with personal records found in the last {days} days."

    # Fetch PRs for each workout
    all_records: list[PeakRecord] = []
    for w in pr_workouts:
        wid = w["workoutId"]
        url = WORKOUT_PRS_URL.format(athlete_id=aid, workout_id=wid)
        result = await make_tp_request(url)
        if isinstance(result, dict):
            for p in result.get("personalRecords", []):
                if not p.get("invalid"):
                    rec = PeakRecord.from_api(p)
                    # Only include All-Time #1 records to find true peaks
                    if rec.time_frame_name == "All-Time" and rec.rank == 1:
                        all_records.append(rec)

    if pr_class:
        all_records = [r for r in all_records if r.pr_class.lower() == pr_class.lower()]

    if not all_records:
        return f"No {'All-Time #1 ' if True else ''}{pr_class or ''} PRs found for {sport} in the last {days} days."

    # Deduplicate: keep only the best value per (class, type)
    best: dict[tuple[str, str], PeakRecord] = {}
    for r in all_records:
        key = (r.pr_class, r.pr_type)
        if key not in best or r.value > best[key].value:
            best[key] = r

    # Group by class
    by_class: dict[str, list[PeakRecord]] = defaultdict(list)
    for r in best.values():
        by_class[r.pr_class].append(r)

    lines = [
        f"All-Time {sport} Personal Records (from last {days} days)",
        f"Scanned {len(pr_workouts)} workouts with PRs\n",
    ]

    for cls_name, records in sorted(by_class.items()):
        lines.append(f"## {cls_name}")
        # Sort by type label for readability
        for r in sorted(records, key=lambda x: x.type_label):
            date = r.workout_date[:10] if r.workout_date else "?"
            lines.append(f"  {r.type_label}: {r.format_value()} — {r.workout_title} ({date})")
        lines.append("")

    return "\n".join(lines)
