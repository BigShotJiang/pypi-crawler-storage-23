"""Workout listing and detail tools."""

from typing import Any

from tp_mcp_server.api.client import make_tp_request
from tp_mcp_server.api.endpoints import WORKOUTS_URL, WORKOUT_DETAIL_URL
from tp_mcp_server.config import get_config
from tp_mcp_server.mcp_instance import mcp
from tp_mcp_server.models.workout import WorkoutSummary, WORKOUT_TYPES
from tp_mcp_server.utils.dates import parse_date_range, days_between, get_today, get_date_ahead


def _resolve_athlete_id(athlete_id: str | None = None) -> tuple[str, str | None]:
    """Resolve athlete ID from param or config. Returns (id, error_msg)."""
    config = get_config()
    aid = athlete_id or config.athlete_id
    if not aid:
        return "", (
            "No athlete ID available. Run tp_get_profile first to auto-detect it, "
            "or set ATHLETE_ID in your .env file."
        )
    return aid, None


@mcp.tool()
async def tp_get_workouts(
    start_date: str | None = None,
    end_date: str | None = None,
    workout_type: str | None = None,
    limit: int = 20,
) -> str:
    """Get a list of workouts from TrainingPeaks.

    Args:
        start_date: Start date (YYYY-MM-DD). Defaults to 30 days ago.
        end_date: End date (YYYY-MM-DD). Defaults to today.
        workout_type: Filter by type (e.g. "Bike", "Run", "Swim", "Strength").
        limit: Maximum number of workouts to return (default 20).

    Returns workouts with date, type, duration, distance, TSS, HR, and power data.
    The TP API limits requests to 90 days at a time.
    """
    aid, err = _resolve_athlete_id()
    if err:
        return err

    start, end = parse_date_range(start_date, end_date, default_days_back=30)

    # Enforce 90-day limit
    if days_between(start, end) > 90:
        return "Date range exceeds 90 days. Please use a shorter range."

    url = WORKOUTS_URL.format(athlete_id=aid, start_date=start, end_date=end)
    result: Any = await make_tp_request(url)

    if isinstance(result, dict) and result.get("error"):
        return f"Error fetching workouts: {result.get('message')}"

    if not isinstance(result, list):
        return "Unexpected response format."

    workouts = [WorkoutSummary.from_api(w) for w in result]

    # Filter by type if requested
    if workout_type:
        type_lower = workout_type.lower()
        workouts = [w for w in workouts if w.workout_type.lower() == type_lower]

    # Sort by date descending (most recent first)
    workouts.sort(key=lambda w: w.workout_day, reverse=True)

    # Apply limit
    workouts = workouts[:limit]

    if not workouts:
        return f"No workouts found between {start} and {end}."

    lines = [f"Workouts ({start} to {end}): {len(workouts)} results\n"]
    for w in workouts:
        lines.append(w.format_summary())
        lines.append("")

    return "\n".join(lines)


@mcp.tool()
async def tp_get_planned_workouts(
    start_date: str | None = None,
    end_date: str | None = None,
    workout_type: str | None = None,
    limit: int = 20,
) -> str:
    """Get upcoming planned workouts from TrainingPeaks.

    Args:
        start_date: Start date (YYYY-MM-DD). Defaults to today.
        end_date: End date (YYYY-MM-DD). Defaults to 14 days from now.
        workout_type: Filter by type (e.g. "Bike", "Run", "Swim", "Strength").
        limit: Maximum number of workouts to return (default 20).

    Returns planned workouts with date, type, planned duration/distance/TSS,
    workout instructions, and coach comments. Sorted chronologically (nearest first).
    The TP API limits requests to 90 days at a time.
    """
    aid, err = _resolve_athlete_id()
    if err:
        return err

    start = start_date or get_today()
    end = end_date or get_date_ahead(14)

    if days_between(start, end) > 90:
        return "Date range exceeds 90 days. Please use a shorter range."

    url = WORKOUTS_URL.format(athlete_id=aid, start_date=start, end_date=end)
    result: Any = await make_tp_request(url)

    if isinstance(result, dict) and result.get("error"):
        return f"Error fetching workouts: {result.get('message')}"

    if not isinstance(result, list):
        return "Unexpected response format."

    workouts = [WorkoutSummary.from_api(w) for w in result]

    if workout_type:
        type_lower = workout_type.lower()
        workouts = [w for w in workouts if w.workout_type.lower() == type_lower]

    # Sort chronologically ascending (nearest first)
    workouts.sort(key=lambda w: w.workout_day)

    workouts = workouts[:limit]

    if not workouts:
        return f"No planned workouts found between {start} and {end}."

    lines = [f"Planned Workouts ({start} to {end}): {len(workouts)} results\n"]
    for w in workouts:
        lines.append(w.format_planned_summary())
        lines.append("")

    return "\n".join(lines)


@mcp.tool()
async def tp_get_workout(workout_id: int) -> str:
    """Get detailed information about a specific workout.

    Args:
        workout_id: The TrainingPeaks workout ID.

    Returns full workout details including power, HR, speed, elevation,
    description, and coach comments.
    """
    aid, err = _resolve_athlete_id()
    if err:
        return err

    url = WORKOUT_DETAIL_URL.format(athlete_id=aid, workout_id=workout_id)
    result: Any = await make_tp_request(url)

    if isinstance(result, dict) and result.get("error"):
        return f"Error fetching workout: {result.get('message')}"

    if not isinstance(result, dict):
        return "Unexpected response format."

    workout = WorkoutSummary.from_api(result)
    return workout.format_detail()
