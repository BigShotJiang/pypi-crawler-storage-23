"""Derived analytics tools — training load, fitness trends, workout analysis, performance summary."""

from collections import defaultdict
from datetime import datetime, timedelta
from typing import Any

from tp_mcp_server.api.client import make_tp_request
from tp_mcp_server.api.endpoints import WORKOUTS_URL, FITNESS_URL, WORKOUT_PRS_URL
from tp_mcp_server.config import get_config
from tp_mcp_server.mcp_instance import mcp
from tp_mcp_server.models.fitness import FitnessEntry, compute_ctl_atl_tsb, fitness_status_label
from tp_mcp_server.models.workout import WorkoutSummary, WORKOUT_TYPES
from tp_mcp_server.models.peaks import PeakRecord
from tp_mcp_server.utils.dates import parse_date_range, get_date_ago, get_today
from tp_mcp_server.utils.formatting import format_duration, format_distance


def _resolve_athlete_id() -> tuple[str, str | None]:
    config = get_config()
    if not config.athlete_id:
        return "", (
            "No athlete ID available. Run tp_get_profile first to auto-detect it, "
            "or set ATHLETE_ID in your .env file."
        )
    return config.athlete_id, None


async def _fetch_workouts(aid: str, start: str, end: str) -> list[WorkoutSummary]:
    """Fetch workouts in 90-day chunks."""
    all_workouts: list[WorkoutSummary] = []
    start_dt = datetime.strptime(start, "%Y-%m-%d")
    end_dt = datetime.strptime(end, "%Y-%m-%d")

    while start_dt < end_dt:
        chunk_end = min(start_dt + timedelta(days=89), end_dt)
        url = WORKOUTS_URL.format(
            athlete_id=aid,
            start_date=start_dt.strftime("%Y-%m-%d"),
            end_date=chunk_end.strftime("%Y-%m-%d"),
        )
        result = await make_tp_request(url)
        if isinstance(result, list):
            all_workouts.extend(WorkoutSummary.from_api(w) for w in result)
        start_dt = chunk_end + timedelta(days=1)

    return all_workouts


async def _fetch_fitness(aid: str, start: str, end: str) -> list[FitnessEntry]:
    """Fetch fitness data with warmup period for CTL/ATL accuracy."""
    warmup_dt = datetime.strptime(start, "%Y-%m-%d") - timedelta(days=90)
    url = FITNESS_URL.format(
        athlete_id=aid,
        start_date=warmup_dt.strftime("%Y-%m-%d"),
        end_date=end,
    )
    result = await make_tp_request(url, method="POST", data={})
    if not isinstance(result, list):
        return []
    entries = [FitnessEntry.from_api(e) for e in result]
    return compute_ctl_atl_tsb(entries)


@mcp.tool()
async def tp_training_load_summary(days: int = 90) -> str:
    """Analyze training load trends over time.

    Args:
        days: Number of days to analyze (default 90).

    Returns weekly and monthly TSS totals, averages, load ramp rate,
    and comparison between recent and previous periods.
    """
    aid, err = _resolve_athlete_id()
    if err:
        return err

    start = get_date_ago(days)
    end = get_today()
    entries = await _fetch_fitness(aid, start, end)
    display = [e for e in entries if e.workout_day[:10] >= start]

    if not display:
        return f"No training data found in the last {days} days."

    # Group by ISO week
    weeks: dict[str, list[FitnessEntry]] = defaultdict(list)
    for e in display:
        dt = datetime.strptime(e.workout_day[:10], "%Y-%m-%d")
        week_key = f"{dt.isocalendar()[0]}-W{dt.isocalendar()[1]:02d}"
        weeks[week_key].append(e)

    # Group by month
    months: dict[str, list[FitnessEntry]] = defaultdict(list)
    for e in display:
        months[e.workout_day[:7]].append(e)

    lines = [
        f"Training Load Summary (last {days} days)",
        "",
        "## Weekly TSS",
        f"{'Week':<10} {'Total TSS':>10} {'Avg/Day':>10} {'Days w/TSS':>12}",
        "-" * 45,
    ]

    sorted_weeks = sorted(weeks.items())
    weekly_totals = []
    for week, wentries in sorted_weeks:
        total = sum(e.tss_actual for e in wentries)
        active_days = sum(1 for e in wentries if e.tss_actual > 0)
        avg = total / len(wentries) if wentries else 0
        weekly_totals.append(total)
        lines.append(f"{week:<10} {total:>10.0f} {avg:>10.1f} {active_days:>12}")

    lines.append("")
    lines.append("## Monthly TSS")
    f"{'Month':<10} {'Total TSS':>10} {'Avg/Day':>10}"
    lines.append(f"{'Month':<10} {'Total TSS':>10} {'Avg/Day':>10}")
    lines.append("-" * 32)

    for month, mentries in sorted(months.items()):
        total = sum(e.tss_actual for e in mentries)
        avg = total / len(mentries) if mentries else 0
        lines.append(f"{month:<10} {total:>10.0f} {avg:>10.1f}")

    # Load ramp rate (week-over-week change)
    lines.append("")
    lines.append("## Load Trends")
    if len(weekly_totals) >= 2:
        recent_4 = weekly_totals[-4:] if len(weekly_totals) >= 4 else weekly_totals
        prev_4 = weekly_totals[-8:-4] if len(weekly_totals) >= 8 else weekly_totals[:len(weekly_totals)//2]

        avg_recent = sum(recent_4) / len(recent_4)
        avg_prev = sum(prev_4) / len(prev_4) if prev_4 else avg_recent

        lines.append(f"Recent 4-week avg: {avg_recent:.0f} TSS/week")
        if prev_4:
            lines.append(f"Previous 4-week avg: {avg_prev:.0f} TSS/week")
            if avg_prev > 0:
                ramp = ((avg_recent - avg_prev) / avg_prev) * 100
                direction = "increase" if ramp > 0 else "decrease"
                lines.append(f"Load ramp: {ramp:+.1f}% ({direction})")
                if abs(ramp) > 15:
                    lines.append("  Warning: Ramp rate exceeds 15% — injury risk increases.")
    else:
        lines.append("Not enough data for trend analysis.")

    # Overall stats
    total_tss = sum(e.tss_actual for e in display)
    active_days = sum(1 for e in display if e.tss_actual > 0)
    lines.append("")
    lines.append("## Overall")
    lines.append(f"Total TSS: {total_tss:.0f}")
    lines.append(f"Training days: {active_days} / {len(display)} ({active_days/len(display)*100:.0f}%)")
    lines.append(f"Average daily TSS: {total_tss/len(display):.1f}")

    return "\n".join(lines)


@mcp.tool()
async def tp_fitness_trend(days: int = 90) -> str:
    """Analyze CTL/ATL/TSB trajectory and project future values.

    Args:
        days: Number of days to analyze (default 90).

    Returns trend direction, rate of change, and 7-day projected CTL/ATL/TSB.
    """
    aid, err = _resolve_athlete_id()
    if err:
        return err

    start = get_date_ago(days)
    end = get_today()
    entries = await _fetch_fitness(aid, start, end)
    display = [e for e in entries if e.workout_day[:10] >= start]

    if len(display) < 14:
        return "Not enough data for trend analysis (need at least 14 days)."

    current = display[-1]
    week_ago = display[-8] if len(display) >= 8 else display[0]
    month_ago = display[-31] if len(display) >= 31 else display[0]

    lines = [
        f"Fitness Trend Analysis (last {days} days)",
        "",
        "## Current Status",
        f"  CTL (Fitness): {current.ctl:.1f}" if current.ctl is not None else "  CTL: N/A",
        f"  ATL (Fatigue): {current.atl:.1f}" if current.atl is not None else "  ATL: N/A",
        f"  TSB (Form):    {current.tsb:.1f}" if current.tsb is not None else "  TSB: N/A",
        f"  Status: {fitness_status_label(current.tsb)}",
    ]

    # Rate of change
    if current.ctl is not None and week_ago.ctl is not None:
        lines.append("")
        lines.append("## Rate of Change")
        ctl_7d = current.ctl - week_ago.ctl
        atl_7d = current.atl - week_ago.atl if current.atl and week_ago.atl else 0
        lines.append(f"  CTL 7-day change: {ctl_7d:+.1f}")
        lines.append(f"  ATL 7-day change: {atl_7d:+.1f}")

        if month_ago.ctl is not None:
            ctl_30d = current.ctl - month_ago.ctl
            lines.append(f"  CTL 30-day change: {ctl_30d:+.1f}")

        # Trend direction
        if ctl_7d > 1:
            trend = "Building (fitness increasing)"
        elif ctl_7d < -1:
            trend = "Detraining (fitness declining)"
        else:
            trend = "Maintaining (stable fitness)"
        lines.append(f"  Trend: {trend}")

    # 7-day projection (assume same average daily TSS continues)
    if current.ctl is not None:
        recent_7 = display[-7:]
        avg_tss = sum(e.tss_actual for e in recent_7) / 7

        proj_ctl = current.ctl
        proj_atl = current.atl or 0
        for _ in range(7):
            proj_ctl = proj_ctl + (avg_tss - proj_ctl) / 42
            proj_atl = proj_atl + (avg_tss - proj_atl) / 7
        proj_tsb = proj_ctl - proj_atl

        lines.append("")
        lines.append("## 7-Day Projection")
        lines.append(f"  (assuming {avg_tss:.0f} TSS/day average continues)")
        lines.append(f"  Projected CTL: {proj_ctl:.1f} ({proj_ctl - current.ctl:+.1f})")
        lines.append(f"  Projected ATL: {proj_atl:.1f}")
        lines.append(f"  Projected TSB: {proj_tsb:.1f} — {fitness_status_label(proj_tsb)}")

    # Key dates (peak fitness, lowest form)
    if any(e.ctl for e in display):
        peak_ctl = max((e for e in display if e.ctl is not None), key=lambda e: e.ctl)
        lowest_tsb = min((e for e in display if e.tsb is not None), key=lambda e: e.tsb)
        lines.append("")
        lines.append("## Key Dates")
        lines.append(f"  Peak fitness: CTL {peak_ctl.ctl:.1f} on {peak_ctl.workout_day[:10]}")
        lines.append(f"  Deepest fatigue: TSB {lowest_tsb.tsb:.1f} on {lowest_tsb.workout_day[:10]}")

    return "\n".join(lines)


@mcp.tool()
async def tp_workout_analysis(workout_id: int) -> str:
    """Deep analysis of a specific workout with derived metrics.

    Args:
        workout_id: The TrainingPeaks workout ID.

    Returns efficiency factor (NP/avg HR), variability index (NP/avg power),
    intensity distribution, and comparison context.
    """
    aid, err = _resolve_athlete_id()
    if err:
        return err

    from tp_mcp_server.api.endpoints import WORKOUT_DETAIL_URL
    url = WORKOUT_DETAIL_URL.format(athlete_id=aid, workout_id=workout_id)
    result: Any = await make_tp_request(url)

    if isinstance(result, dict) and result.get("error"):
        return f"Error: {result.get('message')}"

    w = WorkoutSummary.from_api(result)
    lines = [
        f"# Workout Analysis: {w.title or '(untitled)'}",
        f"Date: {w.workout_day[:10]}  |  Type: {w.workout_type}  |  ID: {w.workout_id}",
        "",
    ]

    # Basic metrics
    lines.append("## Key Metrics")
    if w.total_time:
        lines.append(f"  Duration: {format_duration(w.total_time)}")
    if w.distance:
        lines.append(f"  Distance: {format_distance(w.distance)}")
    if w.tss_actual is not None:
        lines.append(f"  TSS: {w.tss_actual:.1f}")
        if w.tss_planned:
            compliance = (w.tss_actual / w.tss_planned * 100) if w.tss_planned > 0 else 0
            lines.append(f"  TSS Compliance: {compliance:.0f}% (planned: {w.tss_planned:.0f})")
    if w.intensity_factor:
        lines.append(f"  IF: {w.intensity_factor:.2f}")

    # Duration compliance
    if w.total_time and w.total_time_planned and w.total_time_planned > 0:
        dur_compliance = (w.total_time / w.total_time_planned) * 100
        lines.append(f"  Duration Compliance: {dur_compliance:.0f}% ({format_duration(w.total_time)} / {format_duration(w.total_time_planned)})")

    # Derived metrics
    lines.append("")
    lines.append("## Derived Metrics")

    vi = None
    if w.normalized_power and w.power_average and w.power_average > 0:
        vi = w.normalized_power / w.power_average
        lines.append(f"  Variability Index (VI): {vi:.2f}")
        if vi < 1.05:
            lines.append("    -> Very steady effort (time trial / threshold)")
        elif vi < 1.15:
            lines.append("    -> Moderate variability (typical endurance)")
        else:
            lines.append("    -> High variability (intervals / race)")

    ef = None
    if w.normalized_power and w.hr_average and w.hr_average > 0:
        ef = w.normalized_power / w.hr_average
        lines.append(f"  Efficiency Factor (EF): {ef:.2f} W/bpm")
        lines.append("    (Higher EF = better aerobic efficiency)")

    if w.total_time and w.tss_actual and w.total_time > 0:
        tss_per_hour = w.tss_actual / w.total_time
        lines.append(f"  TSS/hour: {tss_per_hour:.1f}")

    if w.distance and w.total_time and w.total_time > 0:
        speed_kmh = (w.distance / 1000) / w.total_time
        lines.append(f"  Avg Speed: {speed_kmh:.1f} km/h")

    # Power analysis
    if w.power_average or w.normalized_power:
        lines.append("")
        lines.append("## Power Profile")
        if w.power_average:
            lines.append(f"  Average Power: {w.power_average:.0f} W")
        if w.normalized_power:
            lines.append(f"  Normalized Power: {w.normalized_power:.0f} W")
        if w.power_max:
            lines.append(f"  Peak Power: {w.power_max:.0f} W")
            if w.power_average and w.power_average > 0:
                ratio = w.power_max / w.power_average
                lines.append(f"  Peak/Avg Ratio: {ratio:.1f}x")

    # HR analysis
    if w.hr_average:
        lines.append("")
        lines.append("## Heart Rate Profile")
        lines.append(f"  Average: {w.hr_average} bpm")
        if w.hr_min:
            lines.append(f"  Minimum: {w.hr_min} bpm")
        if w.hr_max:
            lines.append(f"  Maximum: {w.hr_max} bpm")
            if w.hr_average > 0:
                hr_range = w.hr_max - (w.hr_min or w.hr_average)
                lines.append(f"  Range: {hr_range} bpm")

    # PRs
    if w.personal_record_count > 0:
        lines.append(f"\nPersonal Records: {w.personal_record_count}")
        lines.append("(Use tp_get_workout_prs for details)")

    return "\n".join(lines)


@mcp.tool()
async def tp_performance_summary(
    sport: str = "Bike",
    days: int = 90,
) -> str:
    """Aggregated performance summary for a sport over time.

    Args:
        sport: Sport type — "Bike", "Run", "Swim" (default "Bike").
        days: Number of days to analyze (default 90).

    Returns volume, intensity distribution, consistency metrics,
    and PR timeline for the specified sport.
    """
    aid, err = _resolve_athlete_id()
    if err:
        return err

    sport_type_ids = {"bike": 2, "run": 3, "swim": 1, "hike": 13}
    type_id = sport_type_ids.get(sport.lower())
    if type_id is None:
        return f"Unknown sport '{sport}'. Use: Bike, Run, or Swim."

    start = get_date_ago(days)
    end = get_today()
    all_workouts = await _fetch_workouts(aid, start, end)
    workouts = [w for w in all_workouts if w.workout_type_id == type_id]

    if not workouts:
        return f"No {sport} workouts found in the last {days} days."

    lines = [
        f"{sport} Performance Summary (last {days} days)",
        f"Total workouts: {len(workouts)}",
        "",
    ]

    # Volume
    total_time = sum(w.total_time or 0 for w in workouts)
    total_dist = sum(w.distance or 0 for w in workouts)
    total_tss = sum(w.tss_actual or 0 for w in workouts)
    total_cals = sum(w.calories or 0 for w in workouts)

    lines.append("## Volume")
    lines.append(f"  Total Time: {format_duration(total_time)}")
    if total_dist > 0:
        lines.append(f"  Total Distance: {format_distance(total_dist)}")
    lines.append(f"  Total TSS: {total_tss:.0f}")
    if total_cals > 0:
        lines.append(f"  Total Calories: {total_cals:.0f}")

    # Averages per workout
    lines.append("")
    lines.append("## Per-Workout Averages")
    n = len(workouts)
    if total_time > 0:
        lines.append(f"  Duration: {format_duration(total_time / n)}")
    if total_dist > 0:
        lines.append(f"  Distance: {format_distance(total_dist / n)}")
    if total_tss > 0:
        lines.append(f"  TSS: {total_tss / n:.0f}")

    # Intensity distribution
    with_if = [w for w in workouts if w.intensity_factor]
    if with_if:
        lines.append("")
        lines.append("## Intensity Distribution")
        z1 = sum(1 for w in with_if if w.intensity_factor < 0.55)
        z2 = sum(1 for w in with_if if 0.55 <= w.intensity_factor < 0.75)
        z3 = sum(1 for w in with_if if 0.75 <= w.intensity_factor < 0.90)
        z4 = sum(1 for w in with_if if 0.90 <= w.intensity_factor < 1.05)
        z5 = sum(1 for w in with_if if w.intensity_factor >= 1.05)
        total_if = len(with_if)

        for label, count in [
            ("Recovery (IF <0.55)", z1),
            ("Endurance (IF 0.55-0.75)", z2),
            ("Tempo (IF 0.75-0.90)", z3),
            ("Threshold (IF 0.90-1.05)", z4),
            ("VO2max+ (IF >1.05)", z5),
        ]:
            pct = count / total_if * 100 if total_if else 0
            bar = "#" * int(pct / 5)
            lines.append(f"  {label:<28} {count:>3} ({pct:>4.0f}%) {bar}")

    # Power stats (bike)
    with_power = [w for w in workouts if w.power_average]
    if with_power:
        lines.append("")
        lines.append("## Power Stats")
        avg_pwr = sum(w.power_average for w in with_power) / len(with_power)
        lines.append(f"  Avg Power (all): {avg_pwr:.0f} W")
        with_np = [w for w in workouts if w.normalized_power]
        if with_np:
            avg_np = sum(w.normalized_power for w in with_np) / len(with_np)
            lines.append(f"  Avg NP (all): {avg_np:.0f} W")
        max_pwr = max(w.power_max for w in with_power if w.power_max)
        lines.append(f"  Peak Power: {max_pwr:.0f} W")

    # HR stats
    with_hr = [w for w in workouts if w.hr_average]
    if with_hr:
        lines.append("")
        lines.append("## Heart Rate Stats")
        avg_hr = sum(w.hr_average for w in with_hr) / len(with_hr)
        max_hr = max(w.hr_max for w in with_hr if w.hr_max)
        lines.append(f"  Avg HR (all): {avg_hr:.0f} bpm")
        lines.append(f"  Max HR: {max_hr} bpm")

    # Consistency
    lines.append("")
    lines.append("## Consistency")
    workout_days = set(w.workout_day[:10] for w in workouts)
    total_days = (datetime.strptime(end, "%Y-%m-%d") - datetime.strptime(start, "%Y-%m-%d")).days + 1

    # Weekly breakdown
    by_week: dict[str, int] = defaultdict(int)
    for w in workouts:
        dt = datetime.strptime(w.workout_day[:10], "%Y-%m-%d")
        week = f"{dt.isocalendar()[0]}-W{dt.isocalendar()[1]:02d}"
        by_week[week] += 1

    weeks_with = len(by_week)
    total_weeks = max(total_days // 7, 1)
    avg_per_week = len(workouts) / total_weeks

    lines.append(f"  {sport} days: {len(workout_days)} / {total_days} days ({len(workout_days)/total_days*100:.0f}%)")
    lines.append(f"  Avg per week: {avg_per_week:.1f} sessions")
    lines.append(f"  Weeks with {sport.lower()}: {weeks_with} / {total_weeks}")

    # PR count
    total_prs = sum(w.personal_record_count for w in workouts)
    if total_prs:
        lines.append(f"\nTotal PRs achieved: {total_prs}")

    return "\n".join(lines)


@mcp.tool()
async def tp_training_zones_distribution(
    start_date: str | None = None,
    end_date: str | None = None,
    days: int = 30,
) -> str:
    """Analyze training time and TSS distribution across intensity zones.

    Args:
        start_date: Start date (YYYY-MM-DD). Defaults to {days} days ago.
        end_date: End date (YYYY-MM-DD). Defaults to today.
        days: Days to look back if start_date not set (default 30).

    Breaks down workouts by IF-based training zones showing how training
    time and stress are distributed. Helps identify polarized vs pyramidal
    vs threshold-heavy training patterns.
    """
    aid, err = _resolve_athlete_id()
    if err:
        return err

    start, end = parse_date_range(start_date, end_date, default_days_back=days)
    workouts = await _fetch_workouts(aid, start, end)

    if not workouts:
        return f"No workouts found between {start} and {end}."

    with_data = [w for w in workouts if w.intensity_factor and w.total_time]

    if not with_data:
        return "No workouts with both IF and duration data found."

    # Define zones by IF
    zones = [
        ("Z1 Recovery", 0, 0.55),
        ("Z2 Endurance", 0.55, 0.75),
        ("Z3 Tempo", 0.75, 0.90),
        ("Z4 Threshold", 0.90, 1.05),
        ("Z5 VO2max+", 1.05, 9.99),
    ]

    zone_time: dict[str, float] = defaultdict(float)  # hours
    zone_tss: dict[str, float] = defaultdict(float)
    zone_count: dict[str, int] = defaultdict(int)

    for w in with_data:
        for zname, zlow, zhigh in zones:
            if zlow <= w.intensity_factor < zhigh:
                zone_time[zname] += w.total_time
                zone_tss[zname] += w.tss_actual or 0
                zone_count[zname] += 1
                break

    total_time = sum(zone_time.values())
    total_tss = sum(zone_tss.values())

    lines = [
        f"Training Zones Distribution ({start} to {end})",
        f"Workouts analyzed: {len(with_data)} (of {len(workouts)} total)",
        "",
        f"{'Zone':<18} {'Time':>8} {'%Time':>7} {'TSS':>7} {'%TSS':>6} {'Count':>6}",
        "-" * 55,
    ]

    for zname, _, _ in zones:
        t = zone_time.get(zname, 0)
        tss = zone_tss.get(zname, 0)
        cnt = zone_count.get(zname, 0)
        t_pct = (t / total_time * 100) if total_time > 0 else 0
        tss_pct = (tss / total_tss * 100) if total_tss > 0 else 0
        bar = "#" * int(t_pct / 3)
        lines.append(
            f"{zname:<18} {format_duration(t):>8} {t_pct:>6.1f}% {tss:>7.0f} {tss_pct:>5.1f}% {cnt:>6}  {bar}"
        )

    lines.append(f"{'Total':<18} {format_duration(total_time):>8} {'100%':>7} {total_tss:>7.0f} {'100%':>6} {len(with_data):>6}")

    # Training pattern analysis
    lines.append("")
    lines.append("## Training Pattern")
    z1_z2_pct = ((zone_time.get("Z1 Recovery", 0) + zone_time.get("Z2 Endurance", 0)) / total_time * 100) if total_time > 0 else 0
    z4_z5_pct = ((zone_time.get("Z4 Threshold", 0) + zone_time.get("Z5 VO2max+", 0)) / total_time * 100) if total_time > 0 else 0
    z3_pct = (zone_time.get("Z3 Tempo", 0) / total_time * 100) if total_time > 0 else 0

    if z1_z2_pct >= 75 and z4_z5_pct >= 10:
        pattern = "Polarized (80/20) — optimal for endurance development"
    elif z3_pct >= 30:
        pattern = "Threshold-heavy — risk of stagnation, consider more easy/hard polarization"
    elif z1_z2_pct >= 60:
        pattern = "Pyramidal — good balance with base focus"
    else:
        pattern = "Mixed — consider more structured intensity distribution"

    lines.append(f"  Low intensity (Z1+Z2): {z1_z2_pct:.0f}%")
    lines.append(f"  Moderate (Z3): {z3_pct:.0f}%")
    lines.append(f"  High intensity (Z4+Z5): {z4_z5_pct:.0f}%")
    lines.append(f"  Pattern: {pattern}")

    return "\n".join(lines)
