"""Allow running as: python -m tp_mcp_server"""

from tp_mcp_server.server import main

main()
