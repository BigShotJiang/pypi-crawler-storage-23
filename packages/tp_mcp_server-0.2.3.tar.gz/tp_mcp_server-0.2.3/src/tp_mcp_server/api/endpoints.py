"""TrainingPeaks API endpoint constants."""

# Authentication
TOKEN_URL = "/users/v3/token"
USER_URL = "/users/v3/user"

# Workouts
WORKOUTS_URL = "/fitness/v6/athletes/{athlete_id}/workouts/{start_date}/{end_date}"
WORKOUT_DETAIL_URL = "/fitness/v6/athletes/{athlete_id}/workouts/{workout_id}"

# Fitness / Performance
FITNESS_URL = (
    "/fitness/v1/athletes/{athlete_id}"
    "/reporting/performancedata/{start_date}/{end_date}"
)

# Personal Records
PEAKS_URL = "/personalrecord/v2/athletes/{athlete_id}/{sport}"
WORKOUT_PRS_URL = "/personalrecord/v2/athletes/{athlete_id}/workouts/{workout_id}"
