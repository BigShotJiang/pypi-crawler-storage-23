"""Fitness/performance models — CTL, ATL, TSB."""

import math
from dataclasses import dataclass
from typing import Any


@dataclass
class FitnessEntry:
    workout_day: str
    tss_actual: float
    tss_planned: float
    ctl: float | None  # Chronic Training Load (fitness)
    atl: float | None  # Acute Training Load (fatigue)
    tsb: float | None  # Training Stress Balance (form)
    if_actual: float | None  # Intensity Factor

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "FitnessEntry":
        def parse_float(val: Any) -> float | None:
            if val is None:
                return None
            if isinstance(val, str):
                if val == "NaN" or val == "":
                    return None
                try:
                    f = float(val)
                    return None if math.isnan(f) else f
                except ValueError:
                    return None
            if isinstance(val, (int, float)):
                return None if math.isnan(val) else val
            return None

        return cls(
            workout_day=data.get("workoutDay", ""),
            tss_actual=data.get("tssActual", 0.0) or 0.0,
            tss_planned=data.get("tssPlanned", 0.0) or 0.0,
            ctl=parse_float(data.get("ctl")),
            atl=parse_float(data.get("atl")),
            tsb=parse_float(data.get("tsb")),
            if_actual=parse_float(data.get("ifActual")),
        )


def compute_ctl_atl_tsb(entries: list[FitnessEntry]) -> list[FitnessEntry]:
    """Compute CTL/ATL/TSB from TSS when API returns NaN.

    CTL = exponentially weighted moving average of TSS (42-day time constant)
    ATL = exponentially weighted moving average of TSS (7-day time constant)
    TSB = CTL(yesterday) - ATL(yesterday)
    """
    if not entries:
        return entries

    # Check if API already provides valid values
    has_valid = any(e.ctl is not None for e in entries)
    if has_valid:
        return entries

    ctl = 0.0
    atl = 0.0
    ctl_decay = 1 / 42
    atl_decay = 1 / 7

    for entry in entries:
        tss = entry.tss_actual or 0.0
        entry.tsb = ctl - atl
        ctl = ctl + (tss - ctl) * ctl_decay
        atl = atl + (tss - atl) * atl_decay
        entry.ctl = round(ctl, 1)
        entry.atl = round(atl, 1)
        entry.tsb = round(entry.tsb, 1)

    return entries


def fitness_status_label(tsb: float | None) -> str:
    """Return a fitness status label based on TSB value."""
    if tsb is None:
        return "Unknown"
    if tsb > 25:
        return "Transition (very fresh)"
    if tsb > 5:
        return "Fresh"
    if tsb > -10:
        return "Neutral"
    if tsb > -30:
        return "Tired (optimal loading)"
    return "Exhausted (overreaching)"
