"""User profile model."""

from dataclasses import dataclass
from typing import Any


@dataclass
class UserProfile:
    athlete_id: int
    first_name: str
    last_name: str
    email: str
    username: str
    date_of_birth: str | None = None
    gender: str | None = None
    timezone: str | None = None
    is_premium: bool = False
    age: int | None = None

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "UserProfile":
        """Create from TP API response.

        Response shape: {"user": {"userId": ..., "athletes": [{"athleteId": ...}]}}
        """
        user = data.get("user", data)
        # Athlete ID comes from the athletes array or falls back to userId
        athletes = user.get("athletes", [])
        athlete_id = athletes[0]["athleteId"] if athletes else user.get("userId", 0)

        # Premium status from nested settings
        settings = user.get("settings", {})
        account = settings.get("account", {}) if isinstance(settings, dict) else {}

        return cls(
            athlete_id=athlete_id,
            first_name=user.get("firstName", ""),
            last_name=user.get("lastName", ""),
            email=user.get("email", ""),
            username=user.get("userName", ""),
            date_of_birth=user.get("birthday"),
            gender=user.get("gender"),
            timezone=user.get("timeZone"),
            is_premium=account.get("isPremium", False),
            age=user.get("age"),
        )

    def format(self) -> str:
        """Format profile for display."""
        lines = [
            f"Name: {self.first_name} {self.last_name}",
            f"Username: {self.username}",
            f"Athlete ID: {self.athlete_id}",
            f"Email: {self.email}",
        ]
        if self.age:
            lines.append(f"Age: {self.age}")
        if self.gender:
            lines.append(f"Gender: {self.gender}")
        if self.timezone:
            lines.append(f"Timezone: {self.timezone}")
        lines.append(f"Premium: {'Yes' if self.is_premium else 'No'}")
        return "\n".join(lines)
