from mcp.server.fastmcp import FastMCP

# Module-level variable, initialized by server.py
mcp: FastMCP | None = None
