import os
from dataclasses import dataclass

from dotenv import load_dotenv

_ = load_dotenv()


@dataclass
class Config:
    auth_cookie: str
    athlete_id: str
    tp_api_base_url: str
    user_agent: str


_config_instance: Config | None = None


def load_config() -> Config:
    """Load configuration from environment variables."""
    auth_cookie = os.getenv("TP_AUTH_COOKIE", "")
    athlete_id = os.getenv("ATHLETE_ID", "")
    tp_api_base_url = os.getenv(
        "TP_API_BASE_URL", "https://tpapi.trainingpeaks.com"
    )
    user_agent = (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/131.0.0.0 Safari/537.36"
    )

    return Config(
        auth_cookie=auth_cookie,
        athlete_id=athlete_id,
        tp_api_base_url=tp_api_base_url,
        user_agent=user_agent,
    )


def get_config() -> Config:
    """Get singleton config instance."""
    global _config_instance
    if _config_instance is None:
        _config_instance = load_config()
    return _config_instance
