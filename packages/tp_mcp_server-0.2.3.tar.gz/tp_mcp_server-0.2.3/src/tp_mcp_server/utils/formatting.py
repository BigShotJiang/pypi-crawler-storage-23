"""Output formatting helpers."""


def format_duration(hours: float) -> str:
    """Format hours as human-readable duration (e.g. 1h 30m)."""
    if not hours:
        return "0m"
    total_minutes = round(hours * 60)
    h = total_minutes // 60
    m = total_minutes % 60
    if h > 0 and m > 0:
        return f"{h}h {m:02d}m"
    if h > 0:
        return f"{h}h 00m"
    return f"{m}m"


def format_distance(meters: float) -> str:
    """Format meters as km (e.g. 42.2 km)."""
    if not meters:
        return "0 m"
    if meters < 1000:
        return f"{meters:.0f} m"
    return f"{meters / 1000:.2f} km"
