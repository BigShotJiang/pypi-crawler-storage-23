"""End-to-end test of the TrainingPeaks MCP Server.

Uses the MCP Python SDK client to connect to the server via stdio,
lists tools, and calls each tool verifying real API responses.

Requires: TP_AUTH_COOKIE set in .env or environment.
"""

import asyncio
import sys
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


PROJECT_DIR = Path(__file__).parent.parent
SERVER_PYTHON = str(PROJECT_DIR / ".venv" / "bin" / "python")


async def run_e2e():
    results = []
    passed = 0
    failed = 0

    def check(name: str, ok: bool, detail: str = ""):
        nonlocal passed, failed
        if ok:
            passed += 1
        else:
            failed += 1
        results.append((name, "PASS" if ok else "FAIL", detail))
        icon = "+" if ok else "!"
        print(f"  [{icon}] {name}" + (f" — {detail}" if detail else ""))

    print("=" * 60)
    print("TrainingPeaks MCP Server — E2E Test")
    print("=" * 60)

    server_params = StdioServerParameters(
        command=SERVER_PYTHON,
        args=["-m", "tp_mcp_server"],
        cwd=str(PROJECT_DIR),
        env={
            **dict(__import__("os").environ),
            "PYTHONPATH": str(PROJECT_DIR / "src"),
        },
    )

    async with stdio_client(server_params) as (read_stream, write_stream):
        async with ClientSession(read_stream, write_stream) as session:
            # 1. Initialize
            print("\n## MCP Protocol")
            result = await session.initialize()
            check(
                "Initialize",
                result.serverInfo.name == "trainingpeaks",
                f"server={result.serverInfo.name}",
            )

            # 2. List tools
            tools_result = await session.list_tools()
            tools = tools_result.tools
            tool_names = [t.name for t in tools]
            check("List tools", len(tools) == 14, f"got {len(tools)} tools")

            expected_tools = [
                "tp_auth_status", "tp_refresh_auth", "tp_get_profile",
                "tp_get_workouts", "tp_get_planned_workouts", "tp_get_workout",
                "tp_get_fitness",
                "tp_get_workout_prs", "tp_get_peaks",
                "tp_training_load_summary", "tp_fitness_trend",
                "tp_workout_analysis", "tp_performance_summary",
                "tp_training_zones_distribution",
            ]
            missing = [t for t in expected_tools if t not in tool_names]
            check("All tools registered", not missing, f"missing: {missing}" if missing else "all 14 present")

            tools_with_desc = [t for t in tools if t.description]
            check("Tool descriptions", len(tools_with_desc) == 14, f"{len(tools_with_desc)}/14")

            # Helper to call a tool and get text
            async def call(name: str, args: dict | None = None) -> str:
                r = await session.call_tool(name, arguments=args or {})
                texts = [c.text for c in r.content if hasattr(c, "text")]
                return "\n".join(texts)

            # 3. Auth
            print("\n## Auth & Profile")
            text = await call("tp_auth_status")
            check("tp_auth_status", "Authenticated" in text, text.split("\n")[0][:60])

            text = await call("tp_refresh_auth")
            check("tp_refresh_auth", "refreshed" in text.lower(), text.split("\n")[0][:60])

            # 4. Profile
            text = await call("tp_get_profile")
            has_name = "Viet" in text or "Anh" in text
            has_id = "5567117" in text
            check("tp_get_profile", has_name and has_id, f"name={'ok' if has_name else 'missing'}, id={'ok' if has_id else 'missing'}")

            # 5. Workouts
            print("\n## Workouts")
            text = await call("tp_get_workouts", {"limit": 3})
            has_workouts = "Workouts" in text and ("Bike" in text or "Run" in text or "Swim" in text or "Strength" in text)
            check("tp_get_workouts (default)", has_workouts, f"{len(text)} chars")

            text = await call("tp_get_workouts", {"workout_type": "Bike", "limit": 2})
            check("tp_get_workouts (Bike filter)", "Bike" in text, text.split("\n")[0][:60])

            test_workout_id = 3582938169
            text = await call("tp_get_workout", {"workout_id": test_workout_id})
            has_detail = "Metrics" in text or "Duration" in text or "TSS" in text
            check("tp_get_workout (detail)", has_detail, "has metrics" if has_detail else "no metrics")

            # 6. Planned Workouts
            print("\n## Planned Workouts")
            text = await call("tp_get_planned_workouts")
            has_header = "Planned Workouts" in text
            has_status = "[Planned]" in text or "[Completed]" in text or "No planned workouts" in text
            check("tp_get_planned_workouts (default)", has_header and has_status, text.split("\n")[0][:60])

            text = await call("tp_get_planned_workouts", {"limit": 2})
            check("tp_get_planned_workouts (limit)", "Planned Workouts" in text, text.split("\n")[0][:60])

            text = await call("tp_get_planned_workouts", {"workout_type": "Run"})
            # Either finds Run workouts or none — both valid
            no_non_run = "Run" in text or "No planned workouts" in text
            check("tp_get_planned_workouts (Run filter)", no_non_run, text.split("\n")[0][:60])

            text = await call("tp_get_planned_workouts", {"start_date": "2020-01-01", "end_date": "2020-06-01"})
            check("tp_get_planned_workouts (>90 days)", "90 days" in text.lower() or "exceeds" in text.lower(), text.split("\n")[0][:60])

            # 7. Fitness
            print("\n## Fitness")
            text = await call("tp_get_fitness", {"days": 30})
            has_ctl = "CTL" in text
            has_status = "Status" in text
            check("tp_get_fitness", has_ctl and has_status, f"CTL={'ok' if has_ctl else 'missing'}")

            # 8. Peaks
            print("\n## Peaks & PRs")
            text = await call("tp_get_workout_prs", {"workout_id": 3559617637})
            has_prs = "Personal Records" in text or "HeartRate" in text or "Speed" in text
            check("tp_get_workout_prs", has_prs, f"{len(text)} chars")

            text = await call("tp_get_peaks", {"sport": "Bike", "days": 90, "pr_class": "Power"})
            has_power = "Power" in text and "W" in text
            check("tp_get_peaks (Bike Power)", has_power, "found" if has_power else "missing")

            text = await call("tp_get_peaks", {"sport": "Run", "days": 90})
            has_run = "Speed" in text or "/km" in text
            check("tp_get_peaks (Run)", has_run, "found" if has_run else "missing")

            # 9. Analytics
            print("\n## Analytics")
            text = await call("tp_training_load_summary", {"days": 60})
            has_weekly = "Weekly TSS" in text
            has_trend = "Load Trends" in text or "Overall" in text
            check("tp_training_load_summary", has_weekly and has_trend, f"weekly={'ok' if has_weekly else 'missing'}")

            text = await call("tp_fitness_trend", {"days": 90})
            has_proj = "Projection" in text or "Projected" in text
            has_rate = "Rate of Change" in text
            check("tp_fitness_trend", has_proj and has_rate, f"projection={'ok' if has_proj else 'missing'}")

            text = await call("tp_workout_analysis", {"workout_id": test_workout_id})
            has_vi = "Variability" in text
            has_ef = "Efficiency" in text
            check("tp_workout_analysis", has_vi or has_ef, f"VI={'ok' if has_vi else 'missing'}, EF={'ok' if has_ef else 'missing'}")

            text = await call("tp_performance_summary", {"sport": "Bike", "days": 90})
            has_vol = "Volume" in text
            has_con = "Consistency" in text
            check("tp_performance_summary", has_vol and has_con, f"volume={'ok' if has_vol else 'missing'}")

            text = await call("tp_training_zones_distribution", {"days": 30})
            has_zones = "Z1" in text or "Z2" in text
            has_pattern = "Pattern" in text
            check("tp_training_zones_distribution", has_zones and has_pattern, f"zones={'ok' if has_zones else 'missing'}")

            # 10. Error handling
            print("\n## Error Handling")
            text = await call("tp_get_workout", {"workout_id": 9999999999})
            check("Invalid workout ID", "error" in text.lower() or "not found" in text.lower(), text.split("\n")[0][:60])

            text = await call("tp_get_peaks", {"sport": "Curling"})
            check("Invalid sport", "unknown" in text.lower(), text.split("\n")[0][:60])

            text = await call("tp_get_workouts", {"start_date": "2020-01-01", "end_date": "2020-06-01"})
            check("Date range >90 days", "90 days" in text.lower() or "exceeds" in text.lower(), text.split("\n")[0][:60])

    # Summary
    print("\n" + "=" * 60)
    print(f"E2E Results: {passed} passed, {failed} failed, {passed + failed} total")
    print("=" * 60)

    if failed > 0:
        print("\nFailed tests:")
        for name, status, detail in results:
            if status == "FAIL":
                print(f"  {name}: {detail}")

    return failed == 0


if __name__ == "__main__":
    ok = asyncio.run(run_e2e())
    sys.exit(0 if ok else 1)
