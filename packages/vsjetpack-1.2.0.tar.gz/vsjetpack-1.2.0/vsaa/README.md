# vs-aa

### VapourSynth anti aliasing and scaling functions

<br>

Wrappers for aa/scaling plugins and functions, aimed to have compatibility with vs-kernels scalers.
