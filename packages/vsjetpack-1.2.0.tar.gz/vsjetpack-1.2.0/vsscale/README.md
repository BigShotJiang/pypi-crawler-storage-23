# vs-scale

### VapourSynth (de)scale functions

<br>

Wrappers for scaling and descaling functions.
