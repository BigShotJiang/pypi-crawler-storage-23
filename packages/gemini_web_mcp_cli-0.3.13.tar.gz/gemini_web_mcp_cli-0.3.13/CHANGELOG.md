# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [0.3.13] - 2026-02-21

### Fixed
- **Sparse protobuf response parsing** — Google A/B tests a compressed JSON format where arrays with many null elements become `[{"field_num": value}]` dicts with 1-based protobuf field numbers. This caused `has_music: false` and `has_video: false` on affected accounts. Fixed `get_nested()` in `parser.py` to handle both formats transparently.

---

## [0.3.12] - 2026-02-21

### Fixed
- Token Factory `at=` access token handling — video and music generation failed because Chrome's live `SNlM0e` token wasn't being included in replayed requests
- Video/music polling 400 errors from token mismatch between Python cache and Chrome session
- Prompt truncation in Token Factory — uses dummy string for BotGuard capture, injects real prompt in Python
- Various CDP and login stability fixes

---

## [0.3.9] - 2026-02-20

### Added
- `gemcli hack claude -m pro` — model selection flag for hack claude sessions
- Model identity injection so Gemini can correctly identify which model it's running as

### Fixed
- Pro model context loss, system prompt refusal, and prompt format issues in hack claude

---

## [0.3.0] - 2026-02-20

### Added
- **File upload support** — upload images, PDFs, documents, audio to Gemini for conversation context (`gemcli chat -f <file>`, MCP `chat` tool `files` parameter)
- **`gemcli hack claude`** — launch Claude Code connected to Gemini models via local Anthropic-compatible API server

### Fixed
- CDP Chrome startup reliability (polling loop, IPv6 resolution)
- Login profile selection terminal input handling
- FastAPI/uvicorn dependency packaging

---

## [0.2.2] - 2026-02-19

### Added
- **Video generation (Veo 3.1)** — `gemcli video`, MCP `video` tool, polling-based async generation
- **CDP page fetch download** — browser-context `fetch()` for media downloads, bypassing partitioned cookie restrictions

### Fixed
- Media download 403 errors from missing partitioned cookies
- Frame merge now preserves music/video/image data across streaming frames

---

## [0.2.0] - 2026-02-18

### Added
- **Music generation (Lyria 3)** — `gemcli music`, MCP `music` tool, 16 style presets, audio/video formats
- **Persistent Chrome daemon** — `gemcli chrome start/stop/status` for background processes
- **BotGuard for tool-based generation** — music requires BotGuard even on Flash model

---

## [0.1.x] - 2026-02-16

### 0.1.0 — Initial Alpha
Full CLI (`gemcli`) and MCP server (`gemini-web-mcp`) for the Gemini web interface: chat, image generation, deep research, gems management, multi-profile support, skill system, diagnostics (`gemcli doctor`), and MCP client setup for 8+ AI tools.

### 0.1.1 — CI/CD + PyPI
GitHub Actions release workflow (test, build, publish). First PyPI release. Lint fixes.

### 0.1.2 — Dependency Fix
Moved `mcp[cli]` to core dependencies for `uv tool install` compatibility.

### 0.1.3 — Skill Path Fix
Fixed OpenClaw skill installation directory path.

---

[0.3.13]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.12...v0.3.13
[0.3.12]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.9...v0.3.12
[0.3.9]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.0...v0.3.9
[0.3.0]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.2.2...v0.3.0
[0.2.2]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.2.0...v0.2.2
[0.2.0]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.1.3...v0.2.0
[0.1.x]: https://github.com/jacob-bd/gemini-web-mcp-cli/releases/tag/v0.1.0
