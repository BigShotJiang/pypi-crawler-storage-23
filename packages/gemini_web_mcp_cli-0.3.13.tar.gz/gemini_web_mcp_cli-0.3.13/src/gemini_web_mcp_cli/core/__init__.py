"""Core layer: RPC transport, response parsing, authentication, and profile management."""
