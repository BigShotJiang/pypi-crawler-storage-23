# weightify/constants.py

"""
Weightify Threat Database
-------------------------
This file contains the known dangerous Python globals that can be 
used to achieve Remote Code Execution (RCE) via serialized model weights.
"""

# CRITICAL: These modules/functions trigger an immediate 'Dangerous' finding.
# We use "*" to block an entire module if any function within it is a risk.
UNSAFE_GLOBALS = {
    # Core Python builtins that allow code execution or file manipulation
    "__builtin__": {
        "eval", "compile", "getattr", "apply", 
        "exec", "open", "breakpoint", "input"
    },
    "builtins": {
        "eval", "compile", "getattr", "apply", 
        "exec", "open", "breakpoint", "input"
    },

    # System & Process Control (The most common RCE vectors)
    "os": "*",            
    "subprocess": "*",    
    "posix": "*",         # os alias for Linux/Mac
    "nt": "*",            # os alias for Windows
    "pty": "*",           # Pseudo-terminal utilities
    
    # Network & Data Exfiltration
    "socket": "*",
    "requests.api": "*",
    "urllib.request": "*",
    "http.client": "*",
    
    # Advanced code reconstruction (used by hackers to hide logic)
    "types": {"CodeType", "FunctionType", "ModuleType"},
    "runpy": "*",
    "code": "*",
    
    # File System manipulation
    "shutil": "*",
    "pathlib": "*",
    "tempfile": "*",
    
    # Tools often used for obfuscation/persistence
    "sys": "*",
    "importlib": "*",
    "pickle": "*",
    "shelve": "*"
}

# INNOCUOUS: These are allowed math/data structures. 
# Anything NOT in this list and NOT in the UNSAFE list is marked as 'Suspicious'.
SAFE_GLOBALS = {
    "numpy": {
        "dtype", "ndarray", "core.multiarray._reconstruct", 
        "_core.multiarray._reconstruct"
    },
    "torch": {
        "FloatStorage", "LongStorage", "HalfStorage", "ByteStorage",
        "DoubleStorage", "CharStorage", "ShortStorage", "IntStorage",
        "BoolStorage", "BFloat16Storage", "ComplexFloatStorage",
        "_utils._rebuild_tensor_v2"
    },
    "collections": {"OrderedDict"},
    "builtins": {"set", "list", "dict", "tuple"}
}