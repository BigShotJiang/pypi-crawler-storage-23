# weightify/engine.py
import pickletools
import io
from .constants import UNSAFE_GLOBALS

class WeightScanner:
    def __init__(self):
        self.blocklist = UNSAFE_GLOBALS

    def scan_stream(self, data_stream):
        """Analyzes a single byte stream for vulnerabilities."""
        findings = []
        try:
            for opcode, arg, pos in pickletools.genops(data_stream):
                # Standard Global calls
                if opcode.name in ("GLOBAL", "INST"):
                    module, name = arg.split(" ", 1)
                    if self._is_unsafe(module, name):
                        findings.append({"module": module, "op": name, "at": pos})
        except Exception:
            pass
        return findings

    def _is_unsafe(self, module, name):
        if module in self.blocklist:
            return self.blocklist[module] == "*" or name in self.blocklist[module]
        return False