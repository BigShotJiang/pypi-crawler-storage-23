# weightify/__init__.py
import io
import zipfile
from .engine import WeightScanner

def scan(byte_data: bytes):
    """The main API for Weightify."""
    scanner = WeightScanner()
    results = []
    
    # 1. Check if it's a Zip (Standard for PyTorch .pt files)
    stream = io.BytesIO(byte_data)
    if zipfile.is_zipfile(stream):
        with zipfile.ZipFile(stream, 'r') as z:
            for file_info in z.infolist():
                if file_info.filename.endswith(('.pkl', '.bin')) or "data.pkl" in file_info.filename:
                    with z.open(file_info) as f:
                        results.extend(scanner.scan_stream(f.read()))
    else:
        # 2. Otherwise scan as raw bytes
        results.extend(scanner.scan_stream(byte_data))
        
    return results