# weightify/archive_handler.py
import zipfile
import io

def get_pickle_streams(byte_data):
    """Detects if data is a zip (PyTorch) or raw pickle and yields streams."""
    stream = io.BytesIO(byte_data)
    
    if zipfile.is_zipfile(stream):
        with zipfile.ZipFile(stream, 'r') as z:
            for file_name in z.namelist():
                # PyTorch stores weights in 'data.pkl' or files ending in .pkl
                if file_name.endswith('.pkl') or 'data.pkl' in file_name:
                    yield z.read(file_name)
    else:
        yield byte_data