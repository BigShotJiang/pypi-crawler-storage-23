// Used for generating deno/bun auto-imports
export const lib = {
  meriyah: await import("meriyah"),
  astring: await import("astring"),
};
