"""
File GitHub issues.

    from com.issue import create
    create("Bug: upload fails", body="Traceback...", labels=["bug", "crash"])

Uses ISSUES_TOKEN_GITHUB and GITHUB_REPO from settings.
Falls back to console output when the token is not set.
"""

import os
import re

import requests
from django.conf import settings


# ── Scrubbing ─────────────────────────────────────────────────────────────────

_HOME = os.path.expanduser("~")

_SECRET_ENV_RE = re.compile(
    r"(TOKEN|SECRET|KEY|PASSWORD|CREDENTIAL|AUTH)[=:]\s*\S+",
    re.IGNORECASE,
)
_EMAIL_RE = re.compile(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+")
_BEARER_RE = re.compile(r"(Bearer\s+)\S+", re.IGNORECASE)
_HEX_TOKEN_RE = re.compile(r"\b[0-9a-fA-F]{32,}\b")


def scrub(text: str) -> str:
    """Remove user-identifying information from *text*."""
    out = text.replace(_HOME, "~")
    out = _SECRET_ENV_RE.sub(r"\1=***", out)
    out = _BEARER_RE.sub(r"\1<token>", out)
    out = _HEX_TOKEN_RE.sub("<token>", out)
    out = _EMAIL_RE.sub("<email>", out)
    return out


# ── Issue creation ────────────────────────────────────────────────────────────


def create(title: str, body: str = "", labels: list[str] | None = None) -> dict | None:
    # Scrub server-side before posting to GitHub, in case the caller
    # (e.g. the crash API endpoint) passes unscrubbed user data.
    title = scrub(title)
    body = scrub(body)

    token = settings.ISSUES_TOKEN_GITHUB
    repo = settings.GITHUB_REPO

    if not token:
        print(f"[issue] (no token) {title}\n  Labels: {labels or []}\n  {body[:200]}")
        return None

    resp = requests.post(
        f"https://api.github.com/repos/{repo}/issues",
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
        },
        json={
            "title": title,
            "body": body,
            "labels": labels or [],
        },
        timeout=10,
    )
    resp.raise_for_status()
    return resp.json()
