"""ROS 2 enabled 2D mobile robot simulator for behavior prototyping."""
