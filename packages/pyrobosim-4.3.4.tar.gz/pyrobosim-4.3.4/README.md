ROS 2 enabled 2D mobile robot simulator for behavior prototyping.

Refer to the [GitHub repo](https://github.com/sea-bass/pyrobosim) or [full documentation](https://pyrobosim.readthedocs.io/) for more information.
