interface ParsedSpecName {
  kernel: string | null;
  arnEnvironment: string | null;
  version: string | null;
}

export { ParsedSpecName };
