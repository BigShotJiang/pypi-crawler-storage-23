enum AppNetworkAccessType {
  PublicInternetOnly = 'PublicInternetOnly',
  VpcOnly = 'VpcOnly',
}

export { AppNetworkAccessType };
