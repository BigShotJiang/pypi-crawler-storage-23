#!/usr/bin/env python3
"""키움증권 범용 MCP 서버 (로컬 — 사용자 컨테이너)

PDR v7 정의: 사용자별 API키로 키움 REST API 185개 전체 호출
포트: 8201
모의/실전: KIWOOM_ENV=mock → mockapi.kiwoom.com, KIWOOM_ENV=live → api.kiwoom.com

도구 8개:
  REST (4개):
  - kiwoom_call_api        : 185개 전체 REST API 범용 호출 + DB 자동저장
  - kiwoom_list_apis       : 사용 가능한 API 코드 카탈로그
  - kiwoom_get_env_info    : 현재 환경 정보 (env, base_url, 계좌번호)
  - kiwoom_api_spec        : API 스펙 조회 (파라미터/응답 구조 확인)

  WebSocket 조건검색 (4개, ka10171~10174):
  - kiwoom_condition_list  : 조건검색식 목록 조회 (ka10171/CNSRLST)
  - kiwoom_condition_search: 조건검색식 종목조회 (ka10172/CNSRREQ)
  - kiwoom_condition_realtime: 실시간 조건검색 등록 (ka10173/CNSRREQ search_type=1)
  - kiwoom_condition_stop  : 실시간 조건검색 해제 (ka10174/CNSRCLR)

응답 표준 (STANDARD.md):
  성공: {"ok": true, "source": "kiwoom", "asof": "...", "data": {...}, "meta": {...}, "error": null}
  실패: {"ok": false, "source": "kiwoom", "asof": "...", "data": null, "meta": {...}, "error": {"code": "...", "message": "..."}}

DB 저장 흐름:
  1) hub_api_responses — 모든 API 응답 무조건 JSONB 저장
  2) 정규화 테이블 — api_code 라우팅 (7개 API → 5개 테이블)
     ka10001 → kiwoom_prices      (현재가)
     ka10079 → kiwoom_charts      (일/주/월봉)
     ka10080 → kiwoom_charts      (분봉)
     ka10004 → kiwoom_orderbooks  (호가)
     kt00018 → kiwoom_balances    (잔고)
     kt10000 → kiwoom_orders      (매수)
     kt10001 → kiwoom_orders      (매도)

사용 예시:
    KIWOOM_ENV=mock python kiwoom_mcp_server.py
"""

import os
import sys
import json
import gzip
import base64
import hashlib
import re
from pathlib import Path
from typing import Any, Dict

# kiwoom_rest_client.py 임포트 (같은 디렉토리)
sys.path.insert(0, str(Path(__file__).parent))
import kiwoom_rest_client as krc
import kiwoom_ws_client as kwc
from response import ok_response, error_response, ErrorCode

try:
    import psycopg2
    import psycopg2.extras
    _HAS_PG = True
except ImportError:
    _HAS_PG = False

# ─── api_code → 정규화 테이블 라우팅 ────────────────────────────
_NORMALIZED_ROUTES = {
    "ka10001": "prices",       # 현재가 → kiwoom_prices
    "ka10079": "charts",       # 일/주/월봉 → kiwoom_charts
    "ka10080": "charts",       # 분봉 → kiwoom_charts
    "ka10004": "orderbooks",   # 호가 → kiwoom_orderbooks
    "kt00018": "balances",     # 잔고 → kiwoom_balances
    "kt10000": "orders",       # 매수주문 → kiwoom_orders
    "kt10001": "orders",       # 매도주문 → kiwoom_orders
}

# ─── PostgreSQL 자동저장 ─────────────────────────────────────
_pg_conn = None
_pg_getter = None  # Gateway에서 주입, 없으면 로컬 _get_pg 사용


def _get_pg():
    """PostgreSQL 연결 (재사용, 실패 시 None)"""
    global _pg_conn
    if not _HAS_PG:
        return None
    try:
        if _pg_conn is None or _pg_conn.closed:
            _pg_conn = psycopg2.connect(
                host=os.getenv("PG_HOST", "localhost"),
                port=int(os.getenv("PG_PORT", "5432")),
                dbname=os.getenv("PG_DB", "shared_data_lake"),
                user=os.getenv("PG_USER", "hub"),
                password=os.getenv("PG_PASSWORD", ""),
                connect_timeout=5,
            )
            _pg_conn.autocommit = True
            print("[DB] PostgreSQL 연결 성공 (kiwoom)")
        return _pg_conn
    except Exception as e:
        print(f"[DB] PostgreSQL 연결 실패: {e}")
        return None


def _db_save(api_code: str, params: dict, result: dict):
    """API 응답을 hub_api_responses(통합 로그) + 정규화 테이블에 동시 저장

    autocommit=True이므로 각 INSERT는 즉시 커밋.
    hub_api_responses 저장 후 정규화 저장이 실패해도 통합 로그는 보존됨.
    """
    conn = (_pg_getter or _get_pg)()
    if not conn:
        return
    try:
        p_json = json.dumps(params, ensure_ascii=False, default=str)
        p_hash = hashlib.md5(p_json.encode()).hexdigest()
        r_json = json.dumps(result, ensure_ascii=False, default=str)

        with conn.cursor() as cur:
            # 1) hub_api_responses — 모든 API 무조건 저장 (autocommit 즉시 커밋)
            cur.execute(
                """INSERT INTO hub_api_responses (tool_name, params_hash, params, response)
                   VALUES (%s, %s, %s::jsonb, %s::jsonb)""",
                (f"kiwoom:{api_code}", p_hash, p_json, r_json),
            )
            # 2) 정규화 테이블 — 매핑된 api_code만 추가 저장
            _db_save_normalized(cur, api_code, params, result)
    except Exception as e:
        print(f"[DB] 저장 실패 (kiwoom:{api_code}): {e}")


def _db_save_normalized(cur, api_code: str, params: dict, result: dict):
    """api_code 기반 정규화 테이블 라우팅 저장

    7개 api_code만 정규화 테이블에 추가 저장.
    나머지 178개 API는 hub_api_responses만으로 충분.
    실패 응답(ok=False)은 정규화하지 않음.
    """
    if not result.get("ok"):
        return

    route = _NORMALIZED_ROUTES.get(api_code)
    if not route:
        return  # 매핑 없는 API → hub_api_responses만 (이미 저장 완료)

    data = result.get("data", {})
    env = (result.get("meta") or {}).get("env", "mock")
    data_json = json.dumps(data, ensure_ascii=False, default=str)
    ticker = params.get("stk_cd", "")

    if route == "prices":
        cur.execute(
            "INSERT INTO kiwoom_prices (ticker, env, price_data) VALUES (%s, %s, %s::jsonb)",
            (ticker, env, data_json),
        )

    elif route == "charts":
        # ka10079: period_tp(1=일,2=주,3=월), ka10080: 분봉
        if api_code == "ka10080":
            period = "minute"
        else:
            _period_map = {"1": "day", "2": "week", "3": "month"}
            period = _period_map.get(str(params.get("period_tp", "1")), "day")
        bar_count = int(params.get("req_cnt", 0))
        cur.execute(
            "INSERT INTO kiwoom_charts (ticker, period, bar_count, env, chart_data) VALUES (%s, %s, %s, %s, %s::jsonb)",
            (ticker, period, bar_count, env, data_json),
        )

    elif route == "orderbooks":
        cur.execute(
            "INSERT INTO kiwoom_orderbooks (ticker, env, orderbook) VALUES (%s, %s, %s::jsonb)",
            (ticker, env, data_json),
        )

    elif route == "balances":
        cur.execute(
            "INSERT INTO kiwoom_balances (env, balance_data) VALUES (%s, %s::jsonb)",
            (env, data_json),
        )

    elif route == "orders":
        cur.execute(
            "INSERT INTO kiwoom_orders (ticker, side, qty, price, env, order_data) VALUES (%s, %s, %s, %s, %s, %s::jsonb)",
            (
                ticker,
                "buy" if api_code == "kt10000" else "sell",
                int(params.get("ord_qty", 0)),
                int(params.get("ord_prc", 0)),
                env,
                data_json,
            ),
        )


# ─── API 스펙 데이터 (lazy 로딩 + 캐시) ─────────────────────
_DATA_DIR = Path(__file__).parent / "data"
_min_cache: dict | None = None
_lossless_raw: str | None = None


def _load_min() -> dict:
    """kiwoom_api_min.json 로드 (최초 1회, 이후 캐시)"""
    global _min_cache
    if _min_cache is not None:
        return _min_cache
    min_path = _DATA_DIR / "kiwoom_api_min.json"
    if not min_path.exists():
        return {}
    with open(min_path, "r", encoding="utf-8") as f:
        _min_cache = json.load(f)
    return _min_cache


def _load_lossless_raw() -> str:
    """kiwoom_api_lossless.json → gzip+base64 디코딩 → 마크다운 텍스트"""
    global _lossless_raw
    if _lossless_raw is not None:
        return _lossless_raw
    lossless_path = _DATA_DIR / "kiwoom_api_lossless.json"
    if not lossless_path.exists():
        return ""
    with open(lossless_path, "r", encoding="utf-8") as f:
        obj = json.load(f)
    _lossless_raw = gzip.decompress(base64.b64decode(obj["payload"])).decode("utf-8")
    return _lossless_raw


def _extract_full(api_code: str) -> str:
    """lossless 마크다운에서 특정 API 섹션만 추출"""
    raw = _load_lossless_raw()
    if not raw:
        return ""
    pattern = re.compile(
        r'^(## ' + re.escape(api_code) + r' .+?)(?=^## [a-z]|\Z)',
        re.MULTILINE | re.DOTALL,
    )
    m = pattern.search(raw)
    return m.group(1).strip() if m else ""


# ─── MCP 도구 8개 ──────────────────────────────────────────

def register_tools(mcp, get_pg=None):
    """FastMCP 인스턴스에 Kiwoom 도구 8개 등록"""
    global _pg_getter
    if get_pg is not None:
        _pg_getter = get_pg

    @mcp.tool()
    def kiwoom_call_api(api_code: str, payload_json: str = "{}") -> dict:
        """키움증권 실시간 시세 + 매매 — 185개 API (키움 계좌/인증 필요)

        USE THIS WHEN: 실시간 현재가, 호가, 체결, 순위, 주문 실행
        DO NOT USE: 과거 주가/차트 분석 → datakit_call (무료), 뉴스 → news_search_stock

        Args:
            api_code: 키움 API 코드 (예: "ka10001" 현재가, "ka10079" 일봉, "kt00018" 잔고)
            payload_json: JSON 문자열 파라미터 (예: '{"stk_cd":"005930"}')

        Returns:
            {
                "ok": true,
                "source": "kiwoom",
                "asof": "2026-02-18T09:30:00+09:00",
                "data": { ... API 응답 ... },
                "meta": {"env": "mock", "api_code": "ka10001"},
                "error": null
            }

        DB 자동저장:
            - hub_api_responses: 모든 API 무조건 저장 (JSONB 통합 로그)
            - kiwoom_prices: ka10001 (현재가)
            - kiwoom_charts: ka10079/ka10080 (차트)
            - kiwoom_orderbooks: ka10004 (호가)
            - kiwoom_balances: kt00018 (잔고)
            - kiwoom_orders: kt10000/kt10001 (주문)

        Note:
            kiwoom_list_apis()로 사용 가능한 185개 API 코드 목록 확인 가능.
        """
        try:
            payload = json.loads(payload_json) if payload_json else {}
        except json.JSONDecodeError:
            return error_response(
                ErrorCode.INVALID_PARAMS, "payload_json 파싱 실패",
                source="kiwoom", meta={"api_code": api_code},
            )

        try:
            data = krc.call_api(api_code, payload)
            result = ok_response(data, source="kiwoom", meta={"env": krc.pick_env(), "api_code": api_code})
        except krc.KiwoomError as e:
            result = error_response(
                ErrorCode.API_ERROR, str(e),
                source="kiwoom", meta={"api_code": api_code},
            )
        except Exception as e:
            result = error_response(
                ErrorCode.UNKNOWN, str(e),
                source="kiwoom", meta={"api_code": api_code},
            )

        try:
            _db_save(api_code, payload, result)
        except Exception as e:
            print(f"[Kiwoom DB] {api_code} 저장 실패: {e}")
        return result


    @mcp.tool()
    def kiwoom_list_apis() -> dict:
        """키움증권 185개 전체 API 코드 카탈로그

        Returns:
            카테고리별 API 코드 목록 + 정규화 테이블 매핑 + 사용법 예시
        """
        categories = {}
        for tr_code, cat in krc._TR_CATEGORY.items():
            categories.setdefault(cat, []).append(tr_code)

        cat_names = {
            "stkinfo": "종목정보", "mrkcond": "시세/호가", "frgnistt": "외국인/기관",
            "sect": "업종", "rkinfo": "순위", "chart": "차트", "acnt": "계좌",
            "elw": "ELW", "etf": "ETF", "thme": "테마", "slb": "대차거래",
            "ordr": "주문", "crdordr": "신용주문",
        }

        result = []
        total = 0
        for cat, codes in sorted(categories.items()):
            codes_sorted = sorted(codes)
            total += len(codes_sorted)
            result.append({
                "category": cat,
                "name": cat_names.get(cat, cat),
                "count": len(codes_sorted),
                "api_codes": codes_sorted,
            })

        return ok_response(
            {
                "total_api_count": total,
                "categories": result,
                "normalized_tables": {
                    "ka10001": "kiwoom_prices (현재가)",
                    "ka10079": "kiwoom_charts (일/주/월봉)",
                    "ka10080": "kiwoom_charts (분봉)",
                    "ka10004": "kiwoom_orderbooks (호가)",
                    "kt00018": "kiwoom_balances (잔고)",
                    "kt10000": "kiwoom_orders (매수)",
                    "kt10001": "kiwoom_orders (매도)",
                },
                "usage_examples": [
                    'kiwoom_call_api(api_code="ka10001", payload_json=\'{"stk_cd":"005930"}\')',
                    'kiwoom_call_api(api_code="ka10079", payload_json=\'{"stk_cd":"005930","period_tp":"1","req_cnt":"30"}\')',
                    'kiwoom_call_api(api_code="ka10004", payload_json=\'{"stk_cd":"005930"}\')',
                ],
            },
            source="kiwoom",
        )


    @mcp.tool()
    def kiwoom_get_env_info() -> dict:
        """현재 키움 MCP 서버 환경 정보 조회

        Returns:
            {
                "ok": true,
                "source": "kiwoom",
                "data": {
                    "env": "mock" or "live",
                    "base_url": "...",
                    "account_no": "12345678" or null,
                    "total_api_count": 185,
                    "normalized_routes": 7
                }
            }
        """
        try:
            data = {
                "env": krc.pick_env(),
                "base_url": krc.get_base_url(),
                "creds_path": str(krc.creds_path()),
                "token_cache_path": str(krc.token_cache_path()),
                "account_no": os.environ.get("KIWOOM_ACCOUNT_NO"),
                "total_api_count": len(krc._TR_CATEGORY),
                "normalized_routes": len(_NORMALIZED_ROUTES),
            }
            return ok_response(data, source="kiwoom")
        except Exception as e:
            return error_response(ErrorCode.UNKNOWN, str(e), source="kiwoom")


    @mcp.tool()
    def kiwoom_api_spec(api_code: str = "", detail: str = "min") -> dict:
        """키움 REST API 스펙 조회. 파라미터/응답 구조 확인용.

        USE THIS FIRST: API 호출 전 파라미터 확인이 필요할 때
        THEN USE: kiwoom_call_api로 실제 호출

        Args:
            api_code: API 코드 (예: "ka10001"). 빈 값이면 전체 목록.
            detail: "min" = 파라미터명만 (기본), "full" = 원문 전체 스펙

        Returns:
            min: {name, cat, method, url, req[], res[]}
            full: 원문 마크다운 섹션 (Request/Response 필드 전체)

        Examples:
            kiwoom_api_spec("ka10001")          → 현재가 API 파라미터 확인
            kiwoom_api_spec("ka10001", "full")  → 현재가 API 전체 스펙
            kiwoom_api_spec("")                 → 185개 전체 목록 (카테고리별)
        """
        try:
            min_data = _load_min()
            if not min_data:
                return error_response(
                    ErrorCode.DATA_UNAVAILABLE, "API 스펙 데이터 없음 (kiwoom_api_min.json)",
                    source="kiwoom",
                )

            # 전체 목록 (api_code 비어있을 때)
            if not api_code:
                grouped = {}
                for code, info in sorted(min_data.items()):
                    cat = info.get("cat", "etc")
                    grouped.setdefault(cat, []).append({
                        "code": code,
                        "name": info["name"],
                        "method": info["method"],
                        "url": info["url"],
                    })
                return ok_response(
                    {"total": len(min_data), "categories": grouped},
                    source="kiwoom",
                )

            # 개별 API 조회
            if api_code not in min_data:
                return error_response(
                    ErrorCode.NOT_FOUND,
                    f"'{api_code}' 없음. kiwoom_api_spec('')으로 전체 목록 확인",
                    source="kiwoom",
                )

            if detail == "full":
                full_text = _extract_full(api_code)
                if not full_text:
                    return error_response(
                        ErrorCode.DATA_UNAVAILABLE,
                        f"'{api_code}' 원문 데이터 없음 (kiwoom_api_lossless.json)",
                        source="kiwoom",
                    )
                return ok_response(
                    {"api_code": api_code, "detail": "full", "spec": full_text},
                    source="kiwoom",
                )

            # min (기본)
            return ok_response(
                {"api_code": api_code, "detail": "min", "spec": min_data[api_code]},
                source="kiwoom",
            )

        except Exception as e:
            return error_response(ErrorCode.UNKNOWN, str(e), source="kiwoom")


    # ── WebSocket 조건검색 도구 4개 (ka10171~10174) ─────────────────

    @mcp.tool()
    async def kiwoom_condition_list() -> dict:
        """키움 조건검색식 목록 조회 (ka10171/CNSRLST — WebSocket)

        USE THIS WHEN: HTS에 저장된 조건검색식 목록이 필요할 때.
        REQUIRES: 키움 HTS에서 조건검색식을 사전 등록해야 함.

        Returns:
            {
                "ok": true,
                "source": "kiwoom",
                "data": {
                    "conditions": [{"seq": "0", "name": "조건명"}, ...],
                    "count": N
                }
            }
        """
        try:
            data = await kwc.get_condition_list()
            return ok_response(data, source="kiwoom", meta={"env": krc.pick_env()})
        except kwc.KiwoomWsError as e:
            return error_response(ErrorCode.API_ERROR, str(e), source="kiwoom")
        except Exception as e:
            return error_response(ErrorCode.UNKNOWN, str(e), source="kiwoom")

    @mcp.tool()
    async def kiwoom_condition_search(
        seq: str,
        search_type: str = "0",
        stex_tp: str = "K",
    ) -> dict:
        """키움 조건검색식 종목조회 (ka10172/CNSRREQ — WebSocket)

        USE kiwoom_condition_list() FIRST to get available seq values.

        Args:
            seq: 조건검색식 순번 (kiwoom_condition_list로 조회)
            search_type: "0" = 일반조회(기본), "1" = 실시간등록(→ kiwoom_condition_realtime 권장)
            stex_tp: 거래소 구분. "K" = KRX (기본값, 현재 유일한 유효값)

        Returns:
            {
                "ok": true,
                "source": "kiwoom",
                "data": {
                    "seq": "1",
                    "stk_list": [
                        {"stk_cd": "A005930", "stk_nm": "삼성전자",
                         "price": "75000", "volume": "10386116", ...}
                    ],
                    "stk_cnt": 15
                }
            }
        """
        try:
            data = await kwc.search_condition(seq, search_type, stex_tp)
            return ok_response(data, source="kiwoom", meta={"env": krc.pick_env()})
        except kwc.KiwoomWsError as e:
            return error_response(ErrorCode.API_ERROR, str(e), source="kiwoom")
        except Exception as e:
            return error_response(ErrorCode.UNKNOWN, str(e), source="kiwoom")

    @mcp.tool()
    async def kiwoom_condition_realtime(seq: str, stex_tp: str = "K") -> dict:
        """키움 실시간 조건검색 등록 (ka10173/CNSRREQ search_type=1 — WebSocket)

        USE THIS WHEN: 조건검색식 실시간 모니터링 등록이 필요할 때.
        NOTE: MCP 특성상 실시간 스트림이 아닌 등록 응답(초기 종목코드 목록)만 반환.
              등록 해제는 kiwoom_condition_stop(seq) 사용.

        Args:
            seq: 조건검색식 순번 (kiwoom_condition_list로 조회)
            stex_tp: 거래소 구분. "K" = KRX (기본값, 현재 유일한 유효값)

        Returns:
            {
                "ok": true,
                "source": "kiwoom",
                "data": {"seq": "1", "stk_list": [{"stk_cd": "A005930"}, ...],
                         "stk_cnt": N, "registered": true}
            }
        """
        try:
            data = await kwc.search_condition(seq, search_type="1", stex_tp=stex_tp)
            data["registered"] = True
            return ok_response(data, source="kiwoom", meta={"env": krc.pick_env()})
        except kwc.KiwoomWsError as e:
            return error_response(ErrorCode.API_ERROR, str(e), source="kiwoom")
        except Exception as e:
            return error_response(ErrorCode.UNKNOWN, str(e), source="kiwoom")

    @mcp.tool()
    async def kiwoom_condition_stop(seq: str) -> dict:
        """키움 실시간 조건검색 해제 (ka10174/CNSRCLR — WebSocket)

        USE THIS WHEN: kiwoom_condition_realtime()으로 등록한 조건검색을 해제할 때.

        Args:
            seq: 해제할 조건검색식 순번

        Returns:
            {
                "ok": true,
                "source": "kiwoom",
                "data": {"seq": "1", "return_msg": "해제 완료"}
            }
        """
        try:
            data = await kwc.stop_condition(seq)
            return ok_response(data, source="kiwoom", meta={"env": krc.pick_env()})
        except kwc.KiwoomWsError as e:
            return error_response(ErrorCode.API_ERROR, str(e), source="kiwoom")
        except Exception as e:
            return error_response(ErrorCode.UNKNOWN, str(e), source="kiwoom")


if __name__ == "__main__":
    from openclaw_stock_kit.tool_registry import ToolRegistry
    mcp = ToolRegistry("Kiwoom Data")
    register_tools(mcp)

    print(f"Kiwoom Data — standalone test")
    print(f"   Environment: {krc.pick_env()}")
    print(f"   API Count: {len(krc._TR_CATEGORY)}")
    print(f"   Tools: {[t['name'] for t in mcp.list_tools()]}")
