#!/usr/bin/env python3
"""Kiwoom REST API minimal client (MVP).

- Reads credentials from ~/.openclaw/keys/kiwoom_rest.json (appkey/secretkey)
- Fetches & caches OAuth token in ~/.openclaw/keys/kiwoom_token.json
- Calls Kiwoom REST TR endpoints using common headers from the official spec bundle

This is intentionally small and dependency-free (stdlib only).
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import sys
import urllib.error
import urllib.request
from urllib.parse import urlencode
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

_OPENCLAW_HOME = Path(os.getenv("OPENCLAW_HOME", Path.home() / ".openclaw"))
WORKSPACE = Path(os.getenv("OPENCLAW_WORKSPACE", _OPENCLAW_HOME / "workspace"))
SPEC_DIR = WORKSPACE / "inbox" / "kiwoom_rest" / "kiwoom-api"
COMMON_JSON = SPEC_DIR / "common.json"
INDEX_JSON = SPEC_DIR / "index.json"
AUTH_SPEC_JSON = SPEC_DIR / "specs" / "auth.json"

_KEYS_DIR = _OPENCLAW_HOME / "keys"
CREDS_PATH_LIVE = _KEYS_DIR / "kiwoom_rest.json"
CREDS_PATH_MOCK = _KEYS_DIR / "kiwoom_rest_mock.json"
TOKEN_CACHE_PATH_LIVE = _KEYS_DIR / "kiwoom_token.json"
TOKEN_CACHE_PATH_MOCK = _KEYS_DIR / "kiwoom_token_mock.json"


def pick_env() -> str:
    env = (os.environ.get("KIWOOM_ENV") or "live").strip().lower()
    return "mock" if env in ("mock", "paper", "sim", "simulation") else "live"


def creds_path() -> Path:
    return CREDS_PATH_MOCK if pick_env() == "mock" else CREDS_PATH_LIVE


def token_cache_path() -> Path:
    return TOKEN_CACHE_PATH_MOCK if pick_env() == "mock" else TOKEN_CACHE_PATH_LIVE


DEFAULT_TIMEOUT_S = 30
TOKEN_SAFETY_SKEW_S = 60  # refresh 60s before expiry


# NOTE: The optimized JSON specs bundle in this repo does not include per-TR URL paths.
# For MVP we include a small mapping from the official Kiwoom guide.
# Extend this mapping as needed.
API_PATH_MAP: Dict[str, str] = {
    # OAuth
    "au10001": "/oauth2/token",
    "au10002": "/oauth2/revoke",
}

# 카테고리별 URL 매핑 (키움 REST API 공식)
_URL_MAP = {
    "stkinfo":  "/api/dostk/stkinfo",   # 01: 종목정보
    "mrkcond":  "/api/dostk/mrkcond",   # 02: 시세/호가
    "frgnistt": "/api/dostk/frgnistt",  # 03: 외국인/기관
    "sect":     "/api/dostk/sect",      # 04: 업종
    "rkinfo":   "/api/dostk/rkinfo",    # 05: 순위
    "elw":      "/api/dostk/elw",       # 06: ELW
    "chart":    "/api/dostk/chart",     # 07: 차트
    "acnt":     "/api/dostk/acnt",      # 08: 계좌
    "etf":      "/api/dostk/etf",       # 10: ETF
    "thme":     "/api/dostk/thme",      # 11: 테마
    "slb":      "/api/dostk/slb",       # 12: 대차거래
    "ordr":     "/api/dostk/ordr",      # 13: 주문
    "crdordr":  "/api/dostk/crdordr",   # 16: 신용주문
    "shsa":     "/api/dostk/shsa",      # 17: 금현물
}

# TR → 카테고리 매핑  (공식 문서 기준 — URL 경로로 판정)
_TR_CATEGORY = {
    # 종목정보 (stkinfo) — /api/dostk/stkinfo
    "ka10001": "stkinfo",   # 주식기본정보조회
    "ka10003": "stkinfo",   # 체결조회
    "ka10095": "stkinfo",   # 업종화면추가종목조회
    "ka10099": "stkinfo",   # 종목정보 리스트
    "ka10100": "stkinfo",   # 종목정보 조회
    "ka10101": "stkinfo",   # 업종코드 리스트
    "ka10102": "stkinfo",   # 회원사 리스트
    "kt20016": "stkinfo",   # 신용가능종목조회
    "kt20017": "stkinfo",   # 신용가능잔고

    # 시세/호가 (mrkcond) — /api/dostk/mrkcond
    **{f"ka{c}": "mrkcond" for c in [
        10002,10004,10005,10006,10007,10055,10084,10086,10087,  # 주식
        50010,50012,50087,50100,50101,                           # 금현물
    ]},

    # 외국인/기관 (frgnistt) — /api/dostk/frgnistt
    **{f"ka{c}": "frgnistt" for c in [
        10008,10009,10013,10014,10015,10035,10036,10037,10038,10039,
        10040,10042,10043,10044,10045,10051,10052,10053,10058,10059,
        10060,10061,10062,10063,10064,10065,10066,10078,10131,
    ]},
    "ka52301": "frgnistt",  # 금현물외국인현황

    # 업종 (sect) — /api/dostk/sect
    **{f"ka{c}": "sect" for c in [
        10010,                                                    # 프로그램매매
        20001,20002,20003,20004,20005,20006,20007,20008,20009,20019,20068,
    ]},

    # 순위 (rkinfo) — /api/dostk/rkinfo
    **{f"ka{c}": "rkinfo" for c in [
        10016,10017,10018,10020,10021,10022,10023,10024,10025,10026,
        10027,10028,10029,10030,10031,10032,10033,10034,10046,10047,
        10054,10098,
    ]},
    "ka10019": "stkinfo",   # 가격급등락 → stkinfo (공식 URL 기준)
    "ka00198": "rkinfo",    # 실시간검색조회시작

    # 차트 (chart) — /api/dostk/chart
    **{f"ka{c}": "chart" for c in [
        10079,10080,10081,10082,10083,10094,                    # 주식
        50079,50080,50081,50082,50083,50091,50092,              # 금현물
    ]},

    # 계좌 (acnt) — /api/dostk/acnt
    "ka00001": "acnt",      # 계좌번호 조회
    "ka01690": "acnt",      # 일봉다운로드
    **{f"ka{c}": "acnt" for c in [10072,10073,10074,10075,10076,10077,10085,10088,10170]},
    # ka10171/10172/10173/10174 = WebSocket-only (CNSRLST/CNSRREQ/CNSRCLR) → kiwoom_ws_client.py
    **{f"kt{c:05d}": "acnt" for c in range(1, 20)},
    **{f"kt{c}": "acnt" for c in [50020,50021,50030,50031,50032,50075]},  # 금현물 계좌

    # ELW — /api/dostk/elw
    **{f"ka{c}": "elw" for c in [10011,10048,10050,30001,30002,30003,30004,30005,30009,30010,30011,30012]},

    # ETF — /api/dostk/etf
    **{f"ka{c}": "etf" for c in [40001,40002,40003,40004,40006,40007,40008,40009,40010]},

    # 테마 (thme) — /api/dostk/thme
    **{f"ka{c}": "thme" for c in [90001,90002,90003,90004,90005,90006,90007,90008,90009,90010,90012,90013]},

    # 대차거래 (slb) — /api/dostk/slb
    **{f"ka{c}": "slb" for c in [10068,10069]},

    # 주문 (ordr) — /api/dostk/ordr
    **{f"kt{c}": "ordr" for c in [10000,10001,10002,10003]},
    **{f"kt{c}": "ordr" for c in [50000,50001,50002,50003]},  # 금현물 주문

    # 신용주문 (crdordr) — /api/dostk/crdordr
    **{f"kt{c}": "crdordr" for c in [10006,10007,10008,10009]},
}

# API_PATH_MAP 자동 생성
for _tr, _cat in _TR_CATEGORY.items():
    if _cat in _URL_MAP:
        API_PATH_MAP[_tr] = _URL_MAP[_cat]


@dataclass
class KiwoomCredentials:
    appkey: str
    secretkey: str


class KiwoomError(RuntimeError):
    pass


def _read_json_file(path: Path) -> Any:
    try:
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError as e:
        raise KiwoomError(f"Missing file: {path}") from e
    except json.JSONDecodeError as e:
        raise KiwoomError(f"Invalid JSON in {path}: {e}") from e


def _write_json_file(path: Path, obj: Any, *, chmod600: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
        f.write("\n")
    os.replace(tmp, path)
    if chmod600:
        os.chmod(path, 0o600)


def load_credentials(path: Path | None = None) -> KiwoomCredentials:
    path = path or creds_path()
    data = _read_json_file(path)
    if not isinstance(data, dict):
        raise KiwoomError(f"Credentials JSON must be an object: {path}")
    appkey = data.get("appkey")
    secretkey = data.get("secretkey")
    if not appkey or not secretkey:
        raise KiwoomError("Credentials must contain non-empty fields: appkey, secretkey")
    return KiwoomCredentials(appkey=str(appkey), secretkey=str(secretkey))


def _parse_expires_dt(expires_dt: str) -> dt.datetime:
    """Parse Kiwoom expires_dt.

    The docs return expires_dt as String; formats observed vary.
    We support:
      - ISO8601: 2026-01-31T12:34:56
      - Compact: 20260131123456
      - Date-only: 2026-01-31
    Returned datetime is timezone-aware (UTC) when possible; otherwise treated as local time.
    """
    s = expires_dt.strip()

    # ISO8601
    if "T" in s:
        try:
            d = dt.datetime.fromisoformat(s.replace("Z", "+00:00"))
            if d.tzinfo is None:
                d = d.replace(tzinfo=dt.timezone.utc)
            return d.astimezone(dt.timezone.utc)
        except ValueError:
            pass

    # Compact yyyymmddHHMMSS
    if s.isdigit() and len(s) == 14:
        d = dt.datetime.strptime(s, "%Y%m%d%H%M%S")
        return d.replace(tzinfo=dt.timezone.utc)

    # Date-only
    try:
        d = dt.date.fromisoformat(s)
        return dt.datetime(d.year, d.month, d.day, tzinfo=dt.timezone.utc)
    except ValueError:
        pass

    raise KiwoomError(f"Unrecognized expires_dt format: {expires_dt!r}")


def get_base_url() -> str:
    """Base URL from common.json, overridable via env KIWOOM_BASE_URL.

    Note: Kiwoom mock trading uses a separate domain.
    - live: https://api.kiwoom.com
    - mock: https://mockapi.kiwoom.com (KRX only)
    """
    env = os.environ.get("KIWOOM_BASE_URL")
    if env:
        return env.rstrip("/")

    # Auto-switch for mock env
    if pick_env() == "mock":
        return "https://mockapi.kiwoom.com"

    # Fallback default (repo may not carry the official common.json bundle)
    return "https://api.kiwoom.com"


def _urljoin(base_url: str, path: str) -> str:
    if not path:
        return base_url
    if path.startswith("http://") or path.startswith("https://"):
        return path
    if not path.startswith("/"):
        path = "/" + path
    return base_url.rstrip("/") + path


def _http_json(
    method: str,
    url: str,
    headers: Dict[str, str],
    body_obj: Optional[Dict[str, Any]] = None,
    *,
    timeout_s: int = DEFAULT_TIMEOUT_S,
    form_encoded: bool = False,
) -> Tuple[int, Dict[str, Any], Dict[str, str]]:
    data: Optional[bytes] = None
    if body_obj is not None:
        headers = dict(headers)
        if form_encoded:
            data = urlencode({k: str(v) for k, v in body_obj.items()}).encode('utf-8')
            headers.setdefault('content-type', 'application/x-www-form-urlencoded')
        else:
            data = json.dumps(body_obj, ensure_ascii=False).encode("utf-8")
            headers.setdefault("content-type", "application/json;charset=UTF-8")

    req = urllib.request.Request(url=url, data=data, method=method.upper())
    # Default headers to avoid WAF "Request Blocked" HTML responses
    req.add_header("User-Agent", headers.get("user-agent", "Mozilla/5.0"))
    req.add_header("Accept", headers.get("accept", "application/json"))
    # Some endpoints are protected; adding Origin/Referer helps.
    if "origin" in headers or True:
        req.add_header("Origin", headers.get("origin", "https://api.kiwoom.com"))
    if "referer" in headers or True:
        req.add_header("Referer", headers.get("referer", "https://api.kiwoom.com/"))

    for k, v in headers.items():
        # skip duplicates of the defaults
        if k.lower() in ("user-agent", "accept", "origin", "referer"):
            continue
        req.add_header(k, v)

    try:
        with urllib.request.urlopen(req, timeout=timeout_s) as resp:
            raw = resp.read()
            charset = resp.headers.get_content_charset() or "utf-8"
            text = raw.decode(charset, errors="replace")
            try:
                obj = json.loads(text) if text.strip() else {}
            except json.JSONDecodeError:
                obj = {"_non_json": text}
            resp_headers = {k.lower(): v for (k, v) in resp.headers.items()}
            return resp.status, obj, resp_headers
    except urllib.error.HTTPError as e:
        raw = e.read() if hasattr(e, "read") else b""
        text = raw.decode("utf-8", errors="replace") if raw else ""
        try:
            obj = json.loads(text) if text.strip() else {}
        except json.JSONDecodeError:
            obj = {"_non_json": text}
        raise KiwoomError(
            f"HTTP {e.code} for {method} {url}: {obj if obj else text or e.reason}"
        ) from None
    except urllib.error.URLError as e:
        raise KiwoomError(f"Request failed for {method} {url}: {e}") from None


def _load_token_cache() -> Optional[Dict[str, Any]]:
    cache = token_cache_path()
    if not cache.exists():
        return None
    try:
        data = _read_json_file(cache)
    except KiwoomError:
        return None
    if not isinstance(data, dict):
        return None
    if not data.get("token") or not data.get("expires_dt"):
        return None
    return data


def _is_token_valid(cache: Dict[str, Any]) -> bool:
    try:
        exp = _parse_expires_dt(str(cache["expires_dt"]))
    except KiwoomError:
        return False
    now = dt.datetime.now(dt.timezone.utc)
    return now + dt.timedelta(seconds=TOKEN_SAFETY_SKEW_S) < exp


def fetch_token(force: bool = False) -> Dict[str, Any]:
    cache = _load_token_cache()
    if not force and cache and _is_token_valid(cache):
        return cache

    creds = load_credentials()
    base_url = get_base_url()

    url = _urljoin(base_url, API_PATH_MAP["au10001"])
    payload = {
        "grant_type": "client_credentials",
        "appkey": creds.appkey,
        "secretkey": creds.secretkey,
    }

    # Token endpoint expects JSON (per observed 415 when form-encoded).
    status, obj, _headers = _http_json(
        "POST",
        url,
        headers={"content-type": "application/json;charset=UTF-8"},
        body_obj=payload,
        form_encoded=False,
    )
    if status != 200:
        raise KiwoomError(f"Unexpected status for token request: {status}")

    # Do NOT print the token; just cache it.
    if not isinstance(obj, dict) or not obj.get("token") or not obj.get("expires_dt"):
        raise KiwoomError(f"Token response missing required fields: {obj}")

    cache = token_cache_path()
    _write_json_file(
        cache,
        {"token": obj.get("token"), "expires_dt": obj.get("expires_dt"), "env": pick_env()},
        chmod600=True,
    )
    return {"token": obj.get("token"), "expires_dt": obj.get("expires_dt"), "env": pick_env()}


def _build_common_headers(api_code: str, token: Optional[str]) -> Dict[str, str]:
    headers: Dict[str, str] = {}

    # Always include api-id
    headers["api-id"] = api_code

    # Include authorization when token is provided
    if token:
        # common.json says authorization: "Bearer {token}"
        headers["authorization"] = f"Bearer {token}"

    # We keep cont-yn/next-key optional for future.
    # If common.json changes header names, this function is the single place to update.
    return headers


def call_api(api_code: str, payload: Dict[str, Any], *, base_url: Optional[str] = None) -> Dict[str, Any]:
    base_url = (base_url or get_base_url()).rstrip("/")

    path = API_PATH_MAP.get(api_code)
    if not path:
        raise KiwoomError(
            f"Unknown api_code {api_code!r} (no URL mapping). "
            f"Add it to API_PATH_MAP in tools/kiwoom_rest_client.py"
        )

    token_obj = fetch_token(force=False)
    token = str(token_obj["token"])

    headers = _build_common_headers(api_code, token)
    url = _urljoin(base_url, path)

    _status, obj, resp_headers = _http_json(
        "POST",
        url,
        headers=headers,
        body_obj=payload,
    )

    if isinstance(obj, dict):
        # Attach response headers relevant for pagination/continuation.
        cont = {k: v for k, v in resp_headers.items() if k in {"cont-yn", "next-key", "api-id"}}
        if cont:
            obj = {"_headers": cont, **obj}

    return obj


def _cmd_token(args: argparse.Namespace) -> int:
    tok = fetch_token(force=bool(args.force))

    # Print only metadata (do not print token).
    out = {"expires_dt": tok.get("expires_dt"), "cached": True}
    sys.stdout.write(json.dumps(out, ensure_ascii=False, indent=2) + "\n")
    return 0


def _cmd_call(args: argparse.Namespace) -> int:
    try:
        payload = json.loads(args.json)
    except json.JSONDecodeError as e:
        raise KiwoomError(f"--json must be valid JSON: {e}")
    if not isinstance(payload, dict):
        raise KiwoomError("--json payload must be a JSON object")

    resp = call_api(args.api_code, payload)
    sys.stdout.write(json.dumps(resp, ensure_ascii=False, indent=2) + "\n")
    return 0


def _cmd_smoke_ka10001(args: argparse.Namespace) -> int:
    payload = {"stk_cd": args.ticker}
    resp = call_api("ka10001", payload)

    out_path = WORKSPACE / "public" / "kiwoom_sample" / f"ka10001_{args.ticker}.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    _write_json_file(out_path, resp)

    sys.stdout.write(json.dumps({"wrote": str(out_path)}, ensure_ascii=False, indent=2) + "\n")
    return 0


def main(argv: Optional[list[str]] = None) -> int:
    p = argparse.ArgumentParser(prog="kiwoom_rest_client", description="Kiwoom REST API MVP client")
    sub = p.add_subparsers(dest="cmd", required=True)

    p_tok = sub.add_parser("token", help="Fetch/refresh token and cache it")
    p_tok.add_argument("--force", action="store_true", help="Force refresh even if cached token is valid")
    p_tok.set_defaults(func=_cmd_token)

    p_call = sub.add_parser("call", help="Call an API by code")
    p_call.add_argument("api_code", help="API code (e.g., ka10001)")
    p_call.add_argument("--json", required=True, help="Request JSON payload (object)")
    p_call.set_defaults(func=_cmd_call)

    p_smoke = sub.add_parser("smoke_ka10001", help="Smoke test: call ka10001 and write sample output")
    p_smoke.add_argument("--ticker", default="005930", help="Ticker code (default: 005930)")
    p_smoke.set_defaults(func=_cmd_smoke_ka10001)

    args = p.parse_args(argv)
    try:
        return int(args.func(args))
    except KiwoomError as e:
        sys.stderr.write(f"ERROR: {e}\n")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
