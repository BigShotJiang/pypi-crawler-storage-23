---
name: stock-kit
description: "Korean stock market data & trading toolkit. CLI direct call. Triggers: 주식, 현재가, 시세, 매매, 주문, 잔고, 뉴스, 공시, 차트, 종목, 코스피, 코스닥, 환율, 금리, 시가총액, 급등주, 호가, 배당, stock, price, trade, order, balance, news, disclosure, chart, KOSPI. Do NOT use for: general knowledge, coding, non-stock questions, cryptocurrency"
argument-hint: "[종목명|질문]"
user-invokable: true
---

# StockClaw Kit — CLI 직접 호출 가이드

> **중요**: 모든 도구는 반드시 `openclaw-stock-kit call` 명령으로 호출한다.
> `openclaw` CLI가 아니라 `openclaw-stock-kit` CLI를 사용한다.

---

## 1단계: 설치 확인 (첫 사용 시 반드시 실행)

```bash
openclaw-stock-kit call list 2>/dev/null
```

"command not found" 에러 시 자동 설치:

```bash
pip install openclaw-stock-kit 2>&1 || pip install --break-system-packages openclaw-stock-kit 2>&1
```

설치 후 스킬 등록:

```bash
openclaw-stock-kit setup openclaw 2>&1
```

---

## 2단계: 설정 서버 시작 (API 키 입력용)

사용자가 브라우저에서 API 키를 입력할 수 있는 웹 페이지를 띄운다.

```bash
# 포트 8200이 이미 사용 중일 수 있으므로, 빈 포트를 찾아서 시작
# 8200 시도 → 실패하면 8201, 8202... 순서로 시도
pm2 start openclaw-stock-kit --name stockclaw-settings -- -p 8200 2>/dev/null || nohup openclaw-stock-kit -p 8201 &>/dev/null &
```

설정 페이지 URL을 사용자에게 알려줄 때:
- **서버 환경**: `http://<서버의_외부_IP>:8200` (0.0.0.0이나 localhost가 아닌 실제 IP)
- **로컬 환경**: `http://localhost:8200`

서버 IP 확인 방법:
```bash
hostname -I 2>/dev/null | awk '{print $1}' || curl -s ifconfig.me
```

> **반드시** 사용자에게 "브라우저에서 이 URL을 열어서 API 키를 입력해주세요"라고 안내한다.
> 사용자가 API 키를 입력하기 **전에는** API 키가 필요한 도구를 호출하면 안 된다.

---

## 3단계: API 우선순위 (매우 중요!)

### 무료 (API 키 불필요) — 즉시 사용 가능
| 모듈 | 도구명 | 용도 |
|------|--------|------|
| PyKRX | `datakit_call` | 종목검색, 과거 주가, 시총, 거래량, 수급, 지수 |

### 유료 (API 키 필요) — 사용자가 키 입력 후에만 사용
| 모듈 | 도구명 | 필요 키 | 용도 |
|------|--------|---------|------|
| DART | `datakit_call` | DART_API_KEY | 공시, 기업개황, 최대주주 |
| ECOS/환율 | `datakit_call` | ECOS_API_KEY, EXIM_API_KEY | 기준금리, CPI, GDP, 환율 |
| 네이버 뉴스 | `news_search` / `news_search_stock` | NAVER_CLIENT_ID/SECRET | 뉴스 검색 |
| 텔레그램 | `telegram_*` | TELEGRAM_API_ID/HASH | 실시간 채널 |
| 키움증권 | `kiwoom_call_api` | KIWOOM_APP_KEY/SECRET | 실시간 시세, 매매 |
| 한투(KIS) | `kis_domestic_stock` 등 | KIS_APP_KEY/SECRET | 국내+해외 주식 |
| 프리미엄 | `premium_call` | 라이선스 키 | 브리핑, 백테스트 |

### 사용 규칙
1. **PyKRX는 항상 먼저 시도한다** — 과거 주가, 종목검색, 시총은 PyKRX로 무료 조회 가능
2. **API 키가 필요한 도구는** 사용자가 설정 페이지에서 키를 입력했는지 `gateway_status`로 먼저 확인한다
3. **키가 없으면 해당 도구를 호출하지 않는다** — "API 키가 필요합니다. 설정 페이지에서 입력해주세요"라고 안내
4. 키움/KIS 실시간 현재가가 필요한데 키가 없으면 → PyKRX `get_price`로 최근 종가 대체 가능

---

## 4단계: 도구 호출 (핵심)

**모든 호출은 이 형식을 따른다:**

```bash
openclaw-stock-kit call <도구명> '<JSON 파라미터>' 2>/dev/null
```

> `2>/dev/null`을 항상 붙여서 로딩 로그를 숨긴다.

### 빠른 시작 — 무료 (PyKRX)

```bash
# 종목 검색 (무료)
openclaw-stock-kit call datakit_call '{"function":"search_stock","params_json":"{\"keyword\":\"삼성전자\"}"}' 2>/dev/null

# 과거 주가 (무료)
openclaw-stock-kit call datakit_call '{"function":"get_price","params_json":"{\"ticker\":\"005930\",\"start\":\"20260101\",\"end\":\"20260220\"}"}' 2>/dev/null

# 시가총액 (무료)
openclaw-stock-kit call datakit_call '{"function":"get_market_cap","params_json":"{\"ticker\":\"005930\",\"start\":\"20260101\",\"end\":\"20260220\"}"}' 2>/dev/null

# 전체 상태 확인 (어떤 모듈이 활성인지)
openclaw-stock-kit call gateway_status 2>/dev/null

# 도구 목록
openclaw-stock-kit call list 2>/dev/null
```

### API 키 필요 (키 입력 후에만)

```bash
# 뉴스 검색 (NAVER_CLIENT_ID/SECRET 필요)
openclaw-stock-kit call news_search_stock '{"stock_name":"삼성전자","days":7}' 2>/dev/null

# 키움 실시간 현재가 (KIWOOM_APP_KEY/SECRET 필요)
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"ka10001","inputs":{"종목코드":"005930"}}' 2>/dev/null
```

---

## 의사결정 트리 — 서브 스킬 라우팅

사용자 의도를 파악하여 해당 서브 스킬 파일을 **Read 도구**로 읽고, 그 안의 상세 가이드를 따른다.

| 사용자 의도 | 서브 스킬 파일 | CLI 도구 | API 키 |
|------------|--------------|---------|--------|
| 종목검색, 과거 주가, 시총, 수급, 지수 | `{baseDir}/skills/datakit-pykrx.md` | `datakit_call` | 불필요 (무료) |
| DART 공시, 기업개황, 최대주주, 임원 | `{baseDir}/skills/datakit-dart.md` | `datakit_call` | DART_API_KEY |
| 기준금리, CPI, GDP, 실업률, 환율 | `{baseDir}/skills/datakit-macro.md` | `datakit_call` | ECOS/EXIM |
| 뉴스 검색, 종목별 뉴스 | `{baseDir}/skills/news-naver.md` | `news_search` / `news_search_stock` | NAVER |
| 텔레그램 채널, 메시지, 인증 | `{baseDir}/skills/news-telegram.md` | `telegram_*` | TELEGRAM |
| 키움 실시간 시세, 호가, 차트 | `{baseDir}/skills/kiwoom-market.md` | `kiwoom_call_api` | KIWOOM |
| 키움 매수, 매도, 잔고, 예수금 | `{baseDir}/skills/kiwoom-trading.md` | `kiwoom_call_api` | KIWOOM |
| 키움 외국인, 기관, 순위, 업종, 테마 | `{baseDir}/skills/kiwoom-analysis.md` | `kiwoom_call_api` | KIWOOM |
| 키움 ELW, ETF, 대차 | `{baseDir}/skills/kiwoom-specialty.md` | `kiwoom_call_api` | KIWOOM |
| 키움 조건검색 | `{baseDir}/skills/kiwoom-condition.md` | `kiwoom_condition_*` | KIWOOM |
| 한투 국내주식 (시세, 주문, 잔고) | `{baseDir}/skills/kis-domestic.md` | `kis_domestic_stock` | KIS |
| 한투 해외주식 (미국, 중국, 일본 등) | `{baseDir}/skills/kis-overseas.md` | `kis_overseas_stock` | KIS |
| 한투 선물옵션, 채권, ETF/ETN, ELW | `{baseDir}/skills/kis-derivatives.md` | `kis_*` | KIS |
| 브리핑, 백테스트, 강좌, 프리미엄 | `{baseDir}/skills/premium.md` | `premium_call` | 라이선스 |

---

## 전형적인 사용 흐름

### 처음 설치한 사용자

1. 설치 → `pip install openclaw-stock-kit`
2. 스킬 등록 → `openclaw-stock-kit setup openclaw`
3. 설정 서버 시작 → `openclaw-stock-kit -p 8200`
4. **사용자에게 설정 URL 안내** → `http://<IP>:8200` 에서 API 키 입력
5. 사용자가 키 입력 완료했다고 알려주면 → `gateway_status`로 확인
6. 이후 도구 호출 가능

### "삼성전자 주가 알려줘" 요청 시

1. 종목코드 확인: `datakit_call` + `search_stock` → 005930 (무료, 즉시 가능)
2. 과거 주가: `datakit_call` + `get_price` (무료, 즉시 가능)
3. 실시간 현재가: `kiwoom_call_api` (키움 키 필요 → 키 없으면 PyKRX 최근 종가로 대체)

### "뉴스 보여줘" 요청 시

1. `gateway_status`로 네이버 뉴스 모듈 활성 확인
2. 키가 있으면 → `news_search_stock` 호출
3. 키가 없으면 → "네이버 API 키가 필요합니다. 설정 페이지에서 입력해주세요"

---

## 에러 대처

- "Tool not found" → `call list`로 정확한 도구명 확인
- "Unexpected keyword argument" → 해당 서브 스킬에서 파라미터 확인
- "KIWOOM_APP_KEY not set" → 키움 API 키 미설정 (설정 페이지에서 입력)
- "KIS 인증 필요" → 한투 API 키/계좌 미설정
- 종목코드 모를 때 → `datakit_call` + `search_stock` 먼저 호출 (무료)
- "Connection refused" → call 모드는 SSE 서버 불필요 (독립 실행)
- 포트 충돌 → `-p 8201` 등 다른 포트로 설정 서버 시작
