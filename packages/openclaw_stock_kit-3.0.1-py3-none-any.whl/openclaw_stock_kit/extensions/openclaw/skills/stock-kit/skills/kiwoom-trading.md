# kiwoom-trading — 주문/계좌 (48개 API)

키움증권 REST API 중 매수/매도 주문과 계좌 조회를 다루는 도구 모음이다.
모든 API는 KIWOOM_APP_KEY + KIWOOM_SECRET_KEY 환경변수가 필요하다.

## ⚠️ 주의사항

**주문 API(kt10000~kt10003, kt50000~kt50003, kt10006~kt10009)는 실제 매매가 즉시 실행된다.**
반드시 사용자에게 종목코드, 수량, 가격을 재확인받은 후 호출할 것.

---

## 기본 호출 패턴

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"CODE","inputs":{...}}' 2>/dev/null
```

파라미터 스펙 확인:
```bash
openclaw-stock-kit call kiwoom_api_spec '{"tr_id":"kt10000"}' 2>/dev/null
```

---

## 계좌 (acnt) — 36개

| API 코드 | 설명 |
|----------|------|
| ka00001 | 계좌번호 조회 |
| ka01690 | 일봉 다운로드 |
| ka10072 | 계좌 관련 조회 |
| ka10073 | 계좌 관련 조회 |
| ka10074 | 계좌 관련 조회 |
| ka10075 | 계좌 관련 조회 |
| ka10076 | 계좌 관련 조회 |
| ka10077 | 계좌 관련 조회 |
| ka10085 | 계좌 수익률 |
| ka10088 | 체결잔고 |
| ka10170 | 다계좌 잔고 |
| kt00001~kt00019 | 계좌 조회 시리즈 |
| kt50020 | 금현물 잔고 |
| kt50021 | 금현물 예수금 |
| kt50030~kt50032 | 금현물 계좌 조회 |
| kt50075 | 금현물 주문 내역 |

### ka00001 — 계좌번호 조회

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"ka00001","inputs":{}}' 2>/dev/null
```

보유 계좌 목록을 반환한다. 계좌번호 확인 시 먼저 이 API를 호출한다.

### kt00018 — 잔고 조회 (가장 많이 사용)

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"kt00018","inputs":{"계좌번호":"XXXXXXXX"}}' 2>/dev/null
```

보유 종목, 수량, 평균단가, 평가손익을 반환한다.

### ka10085 — 계좌 수익률

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"ka10085","inputs":{"계좌번호":"XXXXXXXX"}}' 2>/dev/null
```

### ka10088 — 체결잔고

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"ka10088","inputs":{"계좌번호":"XXXXXXXX"}}' 2>/dev/null
```

당일 체결 내역과 잔고를 함께 반환한다.

---

## 주문 (ordr) — 8개

| API 코드 | 설명 |
|----------|------|
| kt10000 | 매수 주문 |
| kt10001 | 매도 주문 |
| kt10002 | 주문 정정 |
| kt10003 | 주문 취소 |
| kt50000 | 금현물 매수 |
| kt50001 | 금현물 매도 |
| kt50002 | 금현물 정정 |
| kt50003 | 금현물 취소 |

주문유형 코드:
- `00` = 지정가
- `03` = 시장가
- `05` = 조건부지정가
- `06` = 최유리지정가
- `07` = 최우선지정가

### kt10000 — 매수 주문

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"kt10000","inputs":{"계좌번호":"XXXXXXXX","종목코드":"005930","주문수량":"10","주문단가":"0","주문유형":"03"}}' 2>/dev/null
```

시장가 매수 시 주문단가는 "0"으로 설정한다.

### kt10001 — 매도 주문

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"kt10001","inputs":{"계좌번호":"XXXXXXXX","종목코드":"005930","주문수량":"10","주문단가":"0","주문유형":"03"}}' 2>/dev/null
```

### kt10002 — 주문 정정

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"kt10002","inputs":{"계좌번호":"XXXXXXXX","원주문번호":"XXXXXXXXXX","종목코드":"005930","주문수량":"10","주문단가":"75000","주문유형":"00"}}' 2>/dev/null
```

### kt10003 — 주문 취소

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"kt10003","inputs":{"계좌번호":"XXXXXXXX","원주문번호":"XXXXXXXXXX","종목코드":"005930","주문수량":"10"}}' 2>/dev/null
```

---

## 신용주문 (crdordr) — 4개

| API 코드 | 설명 |
|----------|------|
| kt10006 | 신용 매수 |
| kt10007 | 신용 매도 |
| kt10008 | 신용 정정 |
| kt10009 | 신용 취소 |

신용 주문은 일반 주문과 동일한 패턴이나 신용구분 파라미터가 추가된다.
정확한 파라미터는 스펙 확인 필수:

```bash
openclaw-stock-kit call kiwoom_api_spec '{"tr_id":"kt10006"}' 2>/dev/null
```

---

## 워크플로우 예시

### 현재 잔고 확인 후 매수

```bash
# 1. 계좌번호 확인
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"ka00001","inputs":{}}' 2>/dev/null

# 2. 잔고 및 예수금 확인
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"kt00018","inputs":{"계좌번호":"XXXXXXXX"}}' 2>/dev/null

# 3. 종목 현재가 확인 (kiwoom-market.md 참조)
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"ka10001","inputs":{"종목코드":"005930"}}' 2>/dev/null

# 4. 사용자 최종 확인 후 매수
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"kt10000","inputs":{"계좌번호":"XXXXXXXX","종목코드":"005930","주문수량":"1","주문단가":"0","주문유형":"03"}}' 2>/dev/null
```
