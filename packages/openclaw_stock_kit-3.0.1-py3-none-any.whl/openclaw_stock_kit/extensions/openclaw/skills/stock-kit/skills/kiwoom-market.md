# kiwoom-market — 시세/호가/차트 (37개 API)

키움증권 REST API 중 시세 조회, 호가, 차트 데이터를 다루는 도구 모음이다.
모든 API는 KIWOOM_APP_KEY + KIWOOM_SECRET_KEY 환경변수가 필요하다.

## 기본 호출 패턴

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"CODE","inputs":{...}}' 2>/dev/null
```

파라미터를 모르면 먼저 스펙을 확인한다:
```bash
openclaw-stock-kit call kiwoom_api_spec '{"tr_id":"ka10001"}' 2>/dev/null
```

---

## 종목정보 (stkinfo) — 10개

| API 코드 | 설명 |
|----------|------|
| ka10001 | 주식기본정보 (현재가) |
| ka10003 | 체결 조회 |
| ka10019 | 가격 급등락 |
| ka10095 | 업종화면 추가종목 |
| ka10099 | 종목정보 리스트 |
| ka10100 | 종목정보 조회 |
| ka10101 | 업종코드 리스트 |
| ka10102 | 회원사 리스트 |
| kt20016 | 신용가능 종목 |
| kt20017 | 신용가능 잔고 |

### ka10001 — 주식 현재가 (가장 많이 사용)

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"ka10001","inputs":{"종목코드":"005930"}}' 2>/dev/null
```

주요 응답 필드: 현재가, 전일대비, 등락률, 거래량, 시가, 고가, 저가, 시가총액

### ka10003 — 체결 조회

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"ka10003","inputs":{"종목코드":"005930"}}' 2>/dev/null
```

---

## 시세/호가 (mrkcond) — 14개

| API 코드 | 설명 |
|----------|------|
| ka10002 | 주식 체결 |
| ka10004 | 호가잔량 |
| ka10005 | 상하한가 종목 |
| ka10006 | 시간별 체결 |
| ka10007 | 일별 체결 |
| ka10055 | 당일 시간대별 체결 |
| ka10084 | 당일/전일 체결 비교 |
| ka10086 | 시세표 |
| ka10087 | 투자자별 매매동향 |
| ka50010 | 금현물 시세 |
| ka50012 | 금현물 호가 |
| ka50087 | 금현물 투자자 |
| ka50100 | 금현물 종목 리스트 |
| ka50101 | 금현물 종목정보 |

### ka10004 — 호가잔량

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"ka10004","inputs":{"종목코드":"005930"}}' 2>/dev/null
```

매도/매수 각 10호가 잔량을 반환한다.

### ka10005 — 상하한가 종목

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"ka10005","inputs":{"시장구분":"0"}}' 2>/dev/null
```

시장구분: 0=전체, 1=코스피, 2=코스닥

### ka10087 — 투자자별 매매동향

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"ka10087","inputs":{"종목코드":"005930"}}' 2>/dev/null
```

---

## 차트 (chart) — 13개

| API 코드 | 설명 |
|----------|------|
| ka10079 | 일봉 차트 |
| ka10080 | 주봉 차트 |
| ka10081 | 월봉 차트 |
| ka10082 | 분봉 차트 |
| ka10083 | 분봉 체결 |
| ka10094 | 종가 추이 |
| ka50079 | 금현물 일봉 |
| ka50080 | 금현물 주봉 |
| ka50081 | 금현물 월봉 |
| ka50082 | 금현물 분봉 |
| ka50083 | 금현물 분봉 체결 |
| ka50091 | 금현물 일봉2 |
| ka50092 | 금현물 다운로드 |

### ka10079 — 일봉 차트

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"ka10079","inputs":{"종목코드":"005930","기준일자":"20260220","수정주가구분":"1"}}' 2>/dev/null
```

수정주가구분: 1=수정주가 적용, 0=미적용

### ka10080 — 주봉 차트

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"ka10080","inputs":{"종목코드":"005930","기준일자":"20260220","수정주가구분":"1"}}' 2>/dev/null
```

### ka10082 — 분봉 차트

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"ka10082","inputs":{"종목코드":"005930","틱범위":"5"}}' 2>/dev/null
```

틱범위(분): 1, 3, 5, 10, 15, 30, 45, 60

---

## 환경 정보 확인

```bash
openclaw-stock-kit call kiwoom_get_env_info 2>/dev/null
```

## API 목록 전체 조회

```bash
openclaw-stock-kit call kiwoom_list_apis 2>/dev/null
```
