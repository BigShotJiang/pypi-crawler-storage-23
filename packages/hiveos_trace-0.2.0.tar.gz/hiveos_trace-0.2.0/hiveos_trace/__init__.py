"""HiveOS Trace package scaffold.

Phase 1 migration: compatibility namespace that delegates to `hiveos.observe`.
"""

