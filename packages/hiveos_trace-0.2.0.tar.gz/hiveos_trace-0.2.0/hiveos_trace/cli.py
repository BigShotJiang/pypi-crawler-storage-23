"""HiveOS Trace canonical CLI entrypoint."""

from hiveos_trace.runtime import main as _runtime_main


def main(argv=None):
    return _runtime_main(argv=argv)
