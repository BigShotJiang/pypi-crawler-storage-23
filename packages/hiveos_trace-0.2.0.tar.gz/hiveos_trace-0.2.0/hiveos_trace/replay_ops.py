"""Replay and anchor orchestration helpers extracted from `hiveos.observe`."""

from __future__ import annotations

import json


def run_has_step_id(run_id, step_id, *, event_limit=50000, read_run_record, read_trace_events_for_run, read_trace_events):
    rid = str(run_id or "").strip()
    sid = str(step_id or "").strip()
    if not rid or not sid:
        return False
    record = read_run_record(rid) or {}
    preferred_log = str(record.get("trace_log_path") or "").strip()
    events = read_trace_events_for_run(rid, limit=max(1, min(50000, int(event_limit))), trace_log_path=preferred_log)
    if not events:
        events = read_trace_events(limit=max(1, min(50000, int(event_limit))), filters={"run_id": rid})
    for event in events:
        if str(event.get("step_id") or "").strip() == sid:
            return True
    return False


def run_has_checkpoint_id(
    run_id,
    checkpoint_id,
    *,
    event_limit=50000,
    read_run_record,
    read_trace_events_for_run,
    read_trace_events,
):
    rid = str(run_id or "").strip()
    cid = str(checkpoint_id or "").strip()
    if not rid or not cid:
        return False
    record = read_run_record(rid) or {}
    preferred_log = str(record.get("trace_log_path") or "").strip()
    events = read_trace_events_for_run(rid, limit=max(1, min(50000, int(event_limit))), trace_log_path=preferred_log)
    if not events:
        events = read_trace_events(limit=max(1, min(50000, int(event_limit))), filters={"run_id": rid})
    for event in events:
        if str(event.get("event_type") or "") != "observe_checkpoint":
            continue
        payload = event.get("payload") if isinstance(event.get("payload"), dict) else {}
        if str(payload.get("checkpoint_id") or "").strip() == cid:
            return True
    return False


def resolve_replay_plan(
    args,
    *,
    read_run_record,
    run_has_step_id,
    run_has_checkpoint_id,
    resolve_ui_url_for_command,
):
    base_run_id = str(args.run_id or "").strip()
    if not base_run_id:
        raise SystemExit("run_id is required")
    base = read_run_record(base_run_id)
    if not base:
        raise SystemExit(f"run_id not found: {base_run_id}")
    base_argv = base.get("argv")
    if isinstance(base_argv, list) and base_argv:
        replay_command = [str(part) for part in base_argv if str(part)]
    else:
        replay_command = str(base.get("command") or "").strip()
    if not replay_command:
        raise SystemExit(f"run command missing for run_id: {base_run_id}")
    run_name = str(args.run_name or "").strip()
    if not run_name:
        run_name = f"replay:{base_run_id}"
    from_step_id = str(getattr(args, "from_step_id", "") or "").strip()
    from_checkpoint_id = str(getattr(args, "from_checkpoint_id", "") or "").strip()
    if from_step_id and from_checkpoint_id:
        raise SystemExit("Choose only one of --from-step-id or --from-checkpoint-id")
    if from_step_id and not run_has_step_id(base_run_id, from_step_id):
        raise SystemExit(f"step_id not found on source run: {from_step_id}")
    if from_checkpoint_id and not run_has_checkpoint_id(base_run_id, from_checkpoint_id):
        raise SystemExit(f"checkpoint_id not found on source run: {from_checkpoint_id}")
    replay_cwd = str(args.cwd or "").strip() or str(base.get("cwd") or "").strip() or None
    record_fields = {"replay_of_run_id": base_run_id, "source": "replay"}
    if from_step_id:
        record_fields["replay_from_step_id"] = from_step_id
        record_fields["replay_anchor_type"] = "step_id"
    if from_checkpoint_id:
        record_fields["replay_from_checkpoint_id"] = from_checkpoint_id
        record_fields["replay_anchor_type"] = "checkpoint_id"
    return {
        "base_run_id": base_run_id,
        "replay_command": replay_command,
        "run_name": run_name,
        "replay_cwd": replay_cwd,
        "from_step_id": from_step_id,
        "from_checkpoint_id": from_checkpoint_id,
        "record_fields": record_fields,
        "ui_url": resolve_ui_url_for_command(args),
    }


def execute_replay_from_plan(plan, *, timeout_sec=None, run_command_observed, build_ui_url):
    result = run_command_observed(
        plan["replay_command"],
        run_name=plan["run_name"],
        cwd=plan["replay_cwd"],
        timeout_sec=timeout_sec,
        agent_id="observer.replay",
        open_ui_url=plan["ui_url"],
        record_fields=plan["record_fields"],
    )
    line = (
        f"run_id={result['run_id']} status={result['status']} duration_ms={result['duration_ms']} "
        f"replay_of={plan['base_run_id']}"
    )
    if plan["from_step_id"]:
        line += f" from_step_id={plan['from_step_id']}"
    if plan["from_checkpoint_id"]:
        line += f" from_checkpoint_id={plan['from_checkpoint_id']}"
    print(line)
    if plan["ui_url"]:
        print(f"ui={build_ui_url(plan['ui_url'], result['run_id'])}")
    return int(result["exit_code"])


def handle_trace_replay(args, *, resolve_replay_plan_fn, execute_replay_from_plan_fn):
    plan = resolve_replay_plan_fn(args)
    return execute_replay_from_plan_fn(plan, timeout_sec=args.timeout_sec or None)


def handle_trace_replay_plan(args, *, resolve_replay_plan_fn, execute_replay_from_plan_fn):
    plan = resolve_replay_plan_fn(args)
    if bool(args.apply):
        if bool(args.json):
            raise SystemExit("Choose only one of --apply or --json")
        return execute_replay_from_plan_fn(plan, timeout_sec=args.timeout_sec or None)
    payload = {
        "replay_of_run_id": plan["base_run_id"],
        "run_name": plan["run_name"],
        "replay_command": plan["replay_command"],
        "replay_cwd": plan["replay_cwd"],
        "from_step_id": plan["from_step_id"] or None,
        "from_checkpoint_id": plan["from_checkpoint_id"] or None,
        "record_fields": plan["record_fields"],
        "does_execute": False,
    }
    if args.json:
        print(json.dumps(payload, separators=(",", ":")))
        return 0
    print(
        f"replay_of={payload['replay_of_run_id']} run_name={payload['run_name']} "
        f"anchor_step={payload['from_step_id']} anchor_checkpoint={payload['from_checkpoint_id']}"
    )
    print(f"command={payload['replay_command']}")
    print(f"cwd={payload['replay_cwd']}")
    print("next=hive trace replay <run_id> [--from-step-id <id> | --from-checkpoint-id <id>] --no-open")
    return 0


def collect_run_anchors(run_id, *, event_limit=5000, read_run_record, read_trace_events_for_run, read_trace_events):
    rid = str(run_id or "").strip()
    if not rid:
        raise ValueError("run_id is required")
    limit = max(1, min(50000, int(event_limit or 5000)))
    record = read_run_record(rid) or {}
    preferred_log = str(record.get("trace_log_path") or "").strip()
    events = read_trace_events_for_run(rid, limit=limit, trace_log_path=preferred_log)
    if not events:
        events = read_trace_events(limit=limit, filters={"run_id": rid})
    step_ids = []
    step_seen = set()
    checkpoint_ids = []
    ckpt_seen = set()
    for event in events:
        step_id = str(event.get("step_id") or "").strip()
        if step_id and step_id not in step_seen:
            step_seen.add(step_id)
            step_ids.append(step_id)
        if str(event.get("event_type") or "") == "observe_checkpoint":
            payload = event.get("payload") if isinstance(event.get("payload"), dict) else {}
            checkpoint_id = str(payload.get("checkpoint_id") or "").strip()
            if checkpoint_id and checkpoint_id not in ckpt_seen:
                ckpt_seen.add(checkpoint_id)
                checkpoint_ids.append(checkpoint_id)
    return {
        "run_id": rid,
        "step_ids": step_ids,
        "checkpoint_ids": checkpoint_ids,
        "step_count": len(step_ids),
        "checkpoint_count": len(checkpoint_ids),
    }


def handle_trace_anchors(args, *, maybe_auto_reconcile, read_run_record, collect_run_anchors_fn):
    maybe_auto_reconcile()
    run_id = str(args.run_id or "").strip()
    if not run_id:
        raise SystemExit("run_id is required")
    record = read_run_record(run_id)
    if not record:
        raise SystemExit(f"run_id not found: {run_id}")
    payload = collect_run_anchors_fn(run_id, event_limit=args.event_limit)
    if args.json:
        print(json.dumps(payload, separators=(",", ":")))
        return 0
    print(
        f"run_id={payload['run_id']} step_count={payload['step_count']} checkpoint_count={payload['checkpoint_count']}"
    )
    if payload["step_ids"]:
        print("step_ids:")
        for item in payload["step_ids"]:
            print(f"  {item}")
    if payload["checkpoint_ids"]:
        print("checkpoint_ids:")
        for item in payload["checkpoint_ids"]:
            print(f"  {item}")
    if (not payload["step_ids"]) and (not payload["checkpoint_ids"]):
        print("No anchors found on run.")
    return 0
