"""TEI ingest helpers extracted from `hiveos.observe` monolith."""

from datetime import datetime, timezone

from hiveos import config as hive_config
from hiveos.intelligence.tracing import build_trace_event, emit_trace
from hiveos.tei import TEI_VERSION, validate_tei_batch, validate_tei_event


def _iso_from_epoch_ms(epoch_ms):
    return datetime.fromtimestamp(float(epoch_ms) / 1000.0, tz=timezone.utc).isoformat()


def _ensure_tei_run_record(
    run_id,
    *,
    occurred_at_ms,
    source,
    read_run_record,
    persist_run_record,
    active_trace_log_path,
    now_ms,
):
    rid = str(run_id or "").strip()
    if not rid:
        return None
    existing = read_run_record(rid)
    if existing:
        return existing
    started = int(occurred_at_ms or now_ms())
    framework = str((source or {}).get("framework") or "").strip() or "unknown"
    emitter = str((source or {}).get("emitter") or "").strip()
    run_name = f"tei:{framework}" if not emitter else f"tei:{framework}:{emitter}"
    record = {
        "run_id": rid,
        "run_name": run_name,
        "command": "",
        "argv": [],
        "cwd": "",
        "trace_log_path": active_trace_log_path(),
        "archived": False,
        "archived_at_ms": None,
        "archive_reason": None,
        "archive_actor": None,
        "started_at_ms": started,
        "last_update_ms": started,
        "last_output_ms": None,
        "status": "running",
        "exit_code": None,
        "duration_ms": None,
        "source": "tei",
    }
    persist_run_record(record)
    return record


def ingest_tei_event(
    event,
    *,
    agent_id="observer.tei",
    persist_db=True,
    persist_file=True,
    strict_version=None,
    now_ms,
    read_run_record,
    persist_run_record,
    touch_run_record,
    active_trace_log_path,
):
    """Validate and ingest one TEI event into the trace stream."""

    if not bool(getattr(hive_config, "TRACE_TEI_INGEST_ENABLED", False)):
        return {
            "ok": False,
            "reason": "tei_ingest_disabled",
            "hint": "Set HIVE_TRACE_TEI_INGEST_ENABLED=true to enable TEI ingestion.",
        }

    strict = bool(getattr(hive_config, "TRACE_TEI_STRICT_VERSION", True))
    if strict_version is not None:
        strict = bool(strict_version)
    validated = validate_tei_event(event, strict_version=strict)
    if not bool(validated.get("ok")):
        return {
            "ok": False,
            "reason": "tei_validation_failed",
            "errors": list(validated.get("errors") or []),
            "strict_version": strict,
        }

    normalized = dict(validated.get("normalized") or {})
    run_id = str(normalized.get("run_id") or "").strip()
    occurred_at_ms = int(normalized.get("occurred_at_ms") or now_ms())
    source = dict(normalized.get("source") or {})
    _ensure_tei_run_record(
        run_id,
        occurred_at_ms=occurred_at_ms,
        source=source,
        read_run_record=read_run_record,
        persist_run_record=persist_run_record,
        active_trace_log_path=active_trace_log_path,
        now_ms=now_ms,
    )
    touch_run_record(run_id, last_update_ms=now_ms())

    payload = dict(normalized.get("payload") or {})
    payload.setdefault("source", "tei")
    payload["tei"] = {
        "tei_version": str(normalized.get("tei_version") or TEI_VERSION),
        "event_id": str(normalized.get("event_id") or ""),
        "occurred_at_ms": occurred_at_ms,
        "source": source,
        "metadata": dict(normalized.get("metadata") or {}),
        "tags": list(normalized.get("tags") or []),
    }

    ingested = build_trace_event(
        event_type=str(normalized.get("event_type") or "tei.event"),
        run_id=run_id,
        outcome=str(normalized.get("outcome") or "success"),
        payload=payload,
        agent_id=str(agent_id or "observer.tei"),
        flow_id=str(normalized.get("flow_id") or "") or None,
        step_id=str(normalized.get("step_id") or "") or None,
        parent_step_id=str(normalized.get("parent_step_id") or "") or None,
        tool_call_id=str(normalized.get("tool_call_id") or "") or None,
        attempt=normalized.get("attempt"),
        step_type=str(normalized.get("step_type") or "") or None,
        timestamp=_iso_from_epoch_ms(occurred_at_ms),
    )
    emit_trace(ingested, persist_db=bool(persist_db), persist_file=bool(persist_file))
    touch_run_record(run_id, last_update_ms=now_ms())
    return {
        "ok": True,
        "run_id": run_id,
        "event_id": str(normalized.get("event_id") or ""),
        "event_type": str(normalized.get("event_type") or ""),
        "strict_version": strict,
    }


def ingest_tei_events(
    events,
    *,
    agent_id="observer.tei",
    persist_db=True,
    persist_file=True,
    strict_version=None,
    now_ms,
    read_run_record,
    persist_run_record,
    touch_run_record,
    active_trace_log_path,
):
    """Validate and ingest a TEI batch. Returns aggregate diagnostics."""

    strict = bool(getattr(hive_config, "TRACE_TEI_STRICT_VERSION", True))
    if strict_version is not None:
        strict = bool(strict_version)
    batch = validate_tei_batch(events, strict_version=strict)
    if not bool(getattr(hive_config, "TRACE_TEI_INGEST_ENABLED", False)):
        return {
            "ok": False,
            "reason": "tei_ingest_disabled",
            "total": int(batch.get("total") or 0),
            "valid": int(batch.get("valid") or 0),
            "invalid": int(batch.get("invalid") or 0),
            "items": list(batch.get("items") or []),
        }

    results = []
    for item in list(batch.get("items") or []):
        index = int(item.get("index") or 0)
        raw_event = events[index] if isinstance(events, list) and 0 <= index < len(events) else None
        if not bool(item.get("ok")):
            results.append({"index": index, "ok": False, "errors": list(item.get("errors") or [])})
            continue
        ingested = ingest_tei_event(
            raw_event,
            agent_id=agent_id,
            persist_db=persist_db,
            persist_file=persist_file,
            strict_version=strict,
            now_ms=now_ms,
            read_run_record=read_run_record,
            persist_run_record=persist_run_record,
            touch_run_record=touch_run_record,
            active_trace_log_path=active_trace_log_path,
        )
        results.append({"index": index, **ingested})
    success_count = sum(1 for item in results if bool(item.get("ok")))
    return {
        "ok": success_count == len(results),
        "total": len(results),
        "ingested": success_count,
        "failed": max(0, len(results) - success_count),
        "items": results,
        "strict_version": strict,
    }

