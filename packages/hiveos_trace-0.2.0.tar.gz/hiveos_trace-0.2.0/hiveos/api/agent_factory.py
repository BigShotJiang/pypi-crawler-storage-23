from hiveos.utilities.wrapper_serialization import hydrate_wrapper, serialize_wrapper


def build_sim_agent_for_capability(capability, capabilities):
    cap = str(capability or "").strip()
    if cap == "display":
        from hiveos.agents_sim.sim_display_agent import SimDisplayAgent

        wrapper_spec = serialize_wrapper(SimDisplayAgent)
        wrapper_spec["metadata"]["origin"] = "inline-test"
        wrapper_spec["capabilities"] = ["display"]
        return hydrate_wrapper(wrapper_spec), wrapper_spec
    if cap == "terminal":
        from hiveos.agents_sim.sim_terminal_agent import SimTerminalAgent

        return SimTerminalAgent(), None
    if cap == "sensor":
        from hiveos.agents_sim.sim_sensor_agent import SimSensorAgent

        return SimSensorAgent(capability=cap), None
    if cap == "random-output":
        from hiveos.agents_sim.sim_random_output import RandomValueAgent

        return RandomValueAgent(), None
    if cap == "task_injector":
        from hiveos.agents_utility.task_injection_agent import TaskInjectionAgent

        return TaskInjectionAgent(), None
    if cap == "agent_injector":
        from hiveos.agents_utility.agent_injector import AgentInjector

        return AgentInjector(), None
    if cap == "ai":
        from hiveos.intelligence.ai_agent import AIAgent

        return AIAgent(capabilities=capabilities), None

    from hiveos.sim_agent import SimAgent

    return SimAgent(capabilities=capabilities or [cap or "generic"]), None
