from hiveos.observe import main as observe_main


def main(argv=None):
    return observe_main(argv=argv)


if __name__ == "__main__":
    raise SystemExit(main())
