import uuid
from hiveos.agent_interface import AgentInterface

class SimSensorAgent(AgentInterface):
    def __init__(self, capability="sensor", sensor_key="sensor_temp", simulated_value=85):
        super().__init__()
        self.agent_id = f"sim-sensor-{str(uuid.uuid4())[:8]}"
        self.name = f"SimSensor-{str(uuid.uuid4())[:4]}"
        self.zone = None
        self.status = "idle"
        self.capabilities = [capability]
        self._available = True
        self.current_chunk = None
        self.chunk_progress = 0
        self.required_ticks = 0

        # Simulated sensor configuration
        self.sensor_key = sensor_key
        self.simulated_value = simulated_value

    def get_status(self):
        return self.status

    def report_capabilities(self):
        return self.capabilities

    def execute_chunk(self, chunk_id, payload=None):
        super().execute_chunk(chunk_id, payload)

        intent = payload.get("intent") if isinstance(payload, dict) else None

        if intent == "read_sensor":
            if self.zone and self.message_bus:
                self.message_bus.publish(self.sensor_key, self.simulated_value)
                print(f"[{self.agent_id}] Published {self.sensor_key}: {self.simulated_value}")
            else:
                print(f"[{self.agent_id}] No message bus or zone assigned.")
        else:
            print(f"[{self.agent_id}] Unknown intent: {intent}")

    def report_completion(self, chunk_id):
        super().report_completion(chunk_id)

    def health_check(self):
        return True

    def enter_cooldown(self, reason=""):
        self.status = 'cooldown'

    def is_available(self):
        return self._available and self.status == 'idle'

    def get_summary(self):
        return super().get_summary() | {
            "type": "SimSensor",
        }
