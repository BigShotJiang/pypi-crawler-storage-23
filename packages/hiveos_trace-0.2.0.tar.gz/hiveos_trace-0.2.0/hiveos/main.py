from hiveos.db import init_db, get_db
from hiveos.cli import main as launch_cli

def main():
    print("🧠 Initializing HiveOS...")
    init_db()
    launch_cli()

if __name__ == "__main__":
    main()