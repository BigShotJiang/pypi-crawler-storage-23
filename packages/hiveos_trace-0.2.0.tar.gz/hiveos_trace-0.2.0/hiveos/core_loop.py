import time
from hiveos.metrics import log_event
from hiveos.core import Core

core = Core()

def ingest_intent(intent):
    core.ingest_intent(intent)

def tick(verbose=True):
    # start = time.perf_counter()
    # print("⏱ Tick started...")
    # print()

    core.tick(verbose=verbose)

    # log_event("system", None, "tick_completed", "global")

    # end = time.perf_counter()
    # elapsed_ms = (end - start) * 1000
    # print(f"✅ Tick complete in {elapsed_ms:.2f} ms.")
