from hiveos.db import get_db
from datetime import datetime

def log_event(agent_id, chunk_id, event_type, zone=None, task_id=None, result=None, reason=None, tick=None):
    with get_db() as conn:
        conn.execute("""
            INSERT INTO task_logs (
                chunk_id,
                task_id,
                agent_id,
                zone_id,
                result,
                reason,
                tick,
                timestamp
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            chunk_id,
            task_id,
            agent_id,
            zone,
            result or event_type,
            reason,
            tick,
            datetime.utcnow().isoformat()
        ))
