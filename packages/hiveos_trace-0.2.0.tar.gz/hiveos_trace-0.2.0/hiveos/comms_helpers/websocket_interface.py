import asyncio
import websockets

class WebSocketInterface:
    def __init__(self, uri="ws://localhost:8765"):
        self.uri = uri
        self.connected = False

    def send_payload(self, payload: str):
        asyncio.run(self._send_payload_async(payload))

    async def _send_payload_async(self, payload: str):
        try:
            async with websockets.connect(self.uri) as websocket:
                self.connected = True
                await websocket.send(payload)
        except Exception as e:
            print(f"[WebSocketInterface] Error: {e}")
            self.connected = False

    def is_connected(self):
        return self.connected

    def close(self):
        # For now, nothing to do. Future: persistent connection
        pass
