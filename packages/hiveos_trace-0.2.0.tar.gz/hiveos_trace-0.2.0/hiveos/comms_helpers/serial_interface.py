import serial

class SerialInterface:
    def __init__(self, port="/dev/ttyUSB0", baud=115200):
        self.port = port
        self.baud = baud
        self.ser = serial.Serial(port, baudrate=baud, timeout=0.1)

    def send_payload(self, payload: str):
        if self.ser and self.ser.is_open:
            self.ser.write((payload.strip() + "\n").encode("utf-8"))

    def is_connected(self):
        return self.ser.is_open

    def close(self):
        if self.ser and self.ser.is_open:
            self.ser.close()
