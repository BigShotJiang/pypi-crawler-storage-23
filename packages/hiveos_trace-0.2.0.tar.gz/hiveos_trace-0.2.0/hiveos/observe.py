"""Compatibility shim for HiveOS Trace runtime.

This module keeps the historic `hiveos.observe` import surface stable while
runtime ownership lives in `hiveos_trace.runtime`.
"""

from hiveos_trace import runtime as _runtime


# Re-export all runtime attributes, including underscored helpers used by tests
# and internal compatibility call sites.
for _name in dir(_runtime):
    if _name.startswith("__"):
        continue
    globals()[_name] = getattr(_runtime, _name)

__all__ = [name for name in globals().keys() if not name.startswith("__")]
