
def reset_runtime():
    from hiveos.sim_agent import SimAgent
    from hiveos.core_loop import core
    core.zones.clear()
    core._runtime_agents.clear()
    core.task_objects.clear()
    core.chunk_objects.clear()
    core.task_name_map.clear()
    core.tick_counter["count"] = 0
    SimAgent._name_counter = 1
    print("✅ Runtime state has been reset (agents, zones, counters).")
