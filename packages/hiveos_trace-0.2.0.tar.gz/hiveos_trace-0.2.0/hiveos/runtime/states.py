class TaskStatus:
    PENDING = "pending"
    RUNNING = "running"
    BLOCKED = "blocked"
    COMPLETED = "completed"
    FAILED = "failed"
    TERMINATED = "terminated"


class ChunkStatus:
    PENDING = "pending"
    ASSIGNED = "assigned"
    COMPLETED = "completed"
    STALE = "stale"


class AgentStatus:
    IDLE = "idle"
    WORKING = "working"
    RECHARGING = "recharging"
    COOLDOWN = "cooldown"


class ZoneStallState:
    HEALTHY = "healthy"
    BLOCKED = "blocked"
    FAILED = "failed"
