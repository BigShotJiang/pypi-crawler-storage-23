def render_zone_summary(zone_id, task_name, total_chunks, completed_chunks, agent_counts):
    """
    Returns a clean, aligned multi-line string summary for a single zone.
    """
    bar_length = 20
    progress = completed_chunks / total_chunks if total_chunks else 0
    bar = "█" * int(bar_length * progress) + "-" * (bar_length - int(bar_length * progress))

    agent_total = agent_counts.get("total", 0)
    working = agent_counts.get("working", 0)
    idle = agent_counts.get("idle", 0)
    recharge = agent_counts.get("recharging", 0)
    cooldown = agent_counts.get("cooldown", 0)

    return f"""Zone {zone_id:<8} | Task: {task_name}
  Progress : [{bar}] {completed_chunks}/{total_chunks}
  Agents   : Total: {agent_total} (Working: {working}, Idle: {idle}, Recharge: {recharge}, Cooldown: {cooldown})
"""
