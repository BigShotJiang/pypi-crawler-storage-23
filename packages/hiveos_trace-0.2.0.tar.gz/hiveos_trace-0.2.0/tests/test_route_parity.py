import unittest

from web_interface import app


EXPECTED_ROUTES = {
    "/",
    "/inject_yaml",
    "/status",
    "/inject_agent",
    "/inject_agents_for_pending",
    "/remove_agent",
    "/agent_input",
    "/reinject_task",
    "/delete_task",
    "/get_task_yaml",
    "/proposals",
    "/proposal_artifacts",
    "/validate_proposal",
    "/inject_proposal",
    "/archive_proposal",
    "/rank_proposals",
    "/trace_events",
    "/trace_events_export",
    "/model_routing_recommendation",
    "/model_routing_profile",
    "/model_routing_profile_apply",
    "/model_routing_artifacts",
    "/freeze_zone",
    "/unfreeze_zone",
    "/kill_zone",
    "/pause_core",
    "/resume_core",
    "/shutdown_core",
    "/set_tickrate",
    "/step_tick",
    "/create_session",
    "/switch_session",
    "/get_sessions",
    "/delete_session",
    "/echo_headers",
    "/terminal_targets",
    "/terminal_open",
    "/terminal_close",
    "/terminal_clear",
    "/terminal_transform",
    "/terminal_exec",
    "/intent_preview",
    "/intent_apply",
    "/intent_specs",
}


class RouteParityTests(unittest.TestCase):
    def test_expected_routes_are_registered(self):
        actual = {rule.rule for rule in app.url_map.iter_rules()}
        missing = sorted(EXPECTED_ROUTES - actual)
        self.assertEqual([], missing, f"Missing routes: {missing}")


if __name__ == "__main__":
    unittest.main()
