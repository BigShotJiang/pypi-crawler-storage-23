"""
ProactiveGuard custom exceptions.
"""


class ProactiveGuardError(Exception):
    """Base exception for all ProactiveGuard errors."""


class ModelNotTrainedError(ProactiveGuardError):
    """Raised when predict() is called before fit() or load()."""

    def __init__(self) -> None:
        super().__init__(
            "Model has not been trained. Call fit() or load() first, "
            "or use ProactiveGuard.from_pretrained() to load bundled weights."
        )


class InsufficientDataError(ProactiveGuardError):
    """Raised when fewer observations than window_size have been collected."""

    def __init__(self, node_id: str, have: int, need: int) -> None:
        super().__init__(
            f"Node '{node_id}' has {have} observation(s); need at least {need} "
            f"to fill one window."
        )


class CollectorError(ProactiveGuardError):
    """Raised when a metrics collector fails to connect or fetch data."""


class WeightsNotFoundError(ProactiveGuardError):
    """Raised when the requested pre-trained weights cannot be located."""

    def __init__(self, name: str) -> None:
        super().__init__(
            f"Pre-trained weights '{name}' not found. "
            f"Available: 'etcd-raft-v1'. "
            f"You can also train your own with ProactiveGuard().fit(X, y)."
        )
