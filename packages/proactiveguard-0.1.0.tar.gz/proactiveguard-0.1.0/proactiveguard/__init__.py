"""
ProactiveGuard — Predictive failure detection for distributed consensus systems.

Quick start
-----------
    from proactiveguard import ProactiveGuard

    # Pre-trained model (etcd / Raft clusters)
    pg = ProactiveGuard.from_pretrained("etcd-raft-v1")

    # Streaming monitoring
    pg.observe("node-0", metrics)
    result = pg.status("node-0")
    if result and result.is_pre_failure:
        print(f"Warning: {result.status} — {result.time_to_failure:.0f}s to failure")

    # Batch sklearn-style API
    pg = ProactiveGuard()
    pg.fit(X_train, y_train)
    labels = pg.predict(X_test)
    probs  = pg.predict_proba(X_test)
"""

from __future__ import annotations

from collections import defaultdict, deque
from pathlib import Path
from typing import Dict, Optional, Union

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset

from .engine import (
    FAILURE_TYPE_MAP,
    HORIZON_NAMES,
    NUM_FEATURES,
    NUM_PREDICTION_CLASSES,
    PREDICTION_HORIZONS,
    WINDOW_SIZE,
    Observation,
    PredictiveModel,
    extract_features,
)
from .exceptions import (
    InsufficientDataError,
    ModelNotTrainedError,
    WeightsNotFoundError,
)
from .types import PredictionResult

__version__ = "0.1.0"
__all__ = ["ProactiveGuard", "PredictionResult", "Observation", "InsufficientDataError"]

# ── Bundled weight registry ────────────────────────────────────────────────────

_WEIGHTS_DIR = Path(__file__).parent / "weights"

_PRETRAINED_REGISTRY: Dict[str, str] = {
    "etcd-raft-v1": "etcd_raft_v1.pt",
}


# ── Main class ─────────────────────────────────────────────────────────────────


class ProactiveGuard:
    """
    Predictive failure detector for distributed consensus systems.

    Wraps the ProactiveGuard engine with a clean, sklearn-compatible API plus
    a streaming monitoring interface for real-time cluster observation.

    Parameters
    ----------
    window_size:
        Number of timestep observations to accumulate before predicting.
        Default matches the pre-trained model (50).
    device:
        PyTorch device string — 'cpu', 'cuda', 'mps', etc.
    """

    def __init__(
        self,
        window_size: int = WINDOW_SIZE,
        device: str = "cpu",
    ) -> None:
        self.window_size = window_size
        self.device = torch.device(device)

        self._model: Optional[PredictiveModel] = None
        self._trained = False

        # Streaming state: per-node rolling observation window
        self._windows: Dict[str, deque] = defaultdict(lambda: deque(maxlen=window_size))
        # Latest prediction per node
        self._latest: Dict[str, PredictionResult] = {}

    # ── Constructors ───────────────────────────────────────────────────────────

    @classmethod
    def from_pretrained(cls, name: str = "etcd-raft-v1") -> "ProactiveGuard":
        """
        Load a ProactiveGuard instance with bundled pre-trained weights.

        Parameters
        ----------
        name:
            Weight bundle name.  Currently available: ``"etcd-raft-v1"``.

        Returns
        -------
        ProactiveGuard
            Ready-to-use detector; no fit() call required.

        Raises
        ------
        WeightsNotFoundError
            If `name` is not in the registry or the weight file is missing.
        """
        if name not in _PRETRAINED_REGISTRY:
            raise WeightsNotFoundError(name)

        weight_path = _WEIGHTS_DIR / _PRETRAINED_REGISTRY[name]
        if not weight_path.exists():
            raise WeightsNotFoundError(name)

        return cls.load(str(weight_path))

    @classmethod
    def load(cls, path: Union[str, Path]) -> "ProactiveGuard":
        """
        Load a saved ProactiveGuard model from disk.

        Parameters
        ----------
        path:
            Path to a ``.pt`` checkpoint saved via :meth:`save`.

        Returns
        -------
        ProactiveGuard
        """
        path = Path(path)
        checkpoint = torch.load(path, map_location="cpu", weights_only=False)

        pg = cls(
            window_size=checkpoint.get("window_size", WINDOW_SIZE),
            device="cpu",
        )
        pg._model = PredictiveModel(
            input_size=checkpoint.get("input_size", NUM_FEATURES),
            num_classes=checkpoint.get("num_classes", NUM_PREDICTION_CLASSES),
            seq_len=checkpoint.get("window_size", WINDOW_SIZE),
        )
        pg._model.load_state_dict(checkpoint["model_state_dict"])
        pg._model.to(pg.device)
        pg._model.eval()
        pg._trained = True
        return pg

    # ── Training ───────────────────────────────────────────────────────────────

    def fit(
        self,
        X: np.ndarray,
        y: np.ndarray,
        *,
        epochs: int = 50,
        lr: float = 1e-3,
        batch_size: int = 64,
        val_split: float = 0.1,
        verbose: bool = True,
    ) -> "ProactiveGuard":
        """
        Train the model on labelled observation windows.

        Parameters
        ----------
        X:
            Feature tensor of shape ``(n_samples, window_size, n_features)``.
            Each sample is one observation window for one node.
        y:
            Integer class labels of shape ``(n_samples,)``.
            Use :data:`proactiveguard.engine.PREDICTION_HORIZONS` to convert
            string labels to integers (e.g. ``PREDICTION_HORIZONS["healthy"]``).
        epochs:
            Training epochs.
        lr:
            Initial learning rate (Adam).
        batch_size:
            Mini-batch size.
        val_split:
            Fraction of samples held out for validation loss reporting.
        verbose:
            Print epoch loss and val-loss when True.

        Returns
        -------
        self
        """
        X_t = torch.tensor(X, dtype=torch.float32)
        y_t = torch.tensor(y, dtype=torch.long)

        n_val = max(1, int(len(X_t) * val_split))
        n_train = len(X_t) - n_val

        train_ds = TensorDataset(X_t[:n_train], y_t[:n_train])
        val_ds = TensorDataset(X_t[n_train:], y_t[n_train:])
        train_dl = DataLoader(train_ds, batch_size=batch_size, shuffle=True)
        val_dl = DataLoader(val_ds, batch_size=batch_size)

        _, ws, nf = X_t.shape
        nc = int(y_t.max().item()) + 1

        if self._model is None:
            self._model = PredictiveModel(input_size=nf, seq_len=ws, num_classes=nc)
        self._model.to(self.device)

        optimizer = optim.Adam(self._model.parameters(), lr=lr, weight_decay=1e-4)
        scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)
        criterion = nn.CrossEntropyLoss()

        for epoch in range(1, epochs + 1):
            self._model.train()
            train_loss = 0.0
            for xb, yb in train_dl:
                xb, yb = xb.to(self.device), yb.to(self.device)
                optimizer.zero_grad()
                out = self._model(xb)
                loss = criterion(out["class_logits"], yb)
                loss.backward()
                nn.utils.clip_grad_norm_(self._model.parameters(), 1.0)
                optimizer.step()
                train_loss += loss.item() * len(xb)

            scheduler.step()

            if verbose and (epoch % 10 == 0 or epoch == 1):
                self._model.eval()
                val_loss = 0.0
                with torch.no_grad():
                    for xb, yb in val_dl:
                        xb, yb = xb.to(self.device), yb.to(self.device)
                        out = self._model(xb)
                        val_loss += criterion(out["class_logits"], yb).item() * len(xb)
                print(
                    f"Epoch {epoch:3d}/{epochs} | "
                    f"train_loss={train_loss/n_train:.4f} | "
                    f"val_loss={val_loss/n_val:.4f}"
                )

        self._model.eval()
        self._trained = True
        return self

    # ── Batch prediction ───────────────────────────────────────────────────────

    def predict(self, X: np.ndarray) -> np.ndarray:
        """
        Predict failure class labels for a batch of observation windows.

        Parameters
        ----------
        X:
            ``(n_samples, window_size, n_features)`` or a single window
            ``(window_size, n_features)`` — will be auto-expanded.

        Returns
        -------
        np.ndarray
            String labels of shape ``(n_samples,)`` drawn from
            :data:`proactiveguard.engine.HORIZON_NAMES`.
        """
        probs = self.predict_proba(X)
        class_ids = np.argmax(probs, axis=1)
        return np.array([HORIZON_NAMES[i] for i in class_ids])

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """
        Return class probability array.

        Parameters
        ----------
        X:
            ``(n_samples, window_size, n_features)`` or ``(window_size, n_features)``.

        Returns
        -------
        np.ndarray
            Shape ``(n_samples, n_classes)`` — each row sums to 1.
        """
        self._require_trained()
        X = np.asarray(X, dtype=np.float32)
        if X.ndim == 2:
            X = X[np.newaxis]  # (1, T, F)

        with torch.no_grad():
            X_t = torch.tensor(X).to(self.device)
            out = self._model(X_t)
            probs = torch.softmax(out["class_logits"], dim=1).cpu().numpy()
        return probs

    def predict_with_ttf(self, X: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Return (class_labels, time_to_failure_seconds, confidence).

        Parameters
        ----------
        X:
            ``(n_samples, window_size, n_features)`` or ``(window_size, n_features)``.

        Returns
        -------
        labels : np.ndarray of str
        ttf    : np.ndarray of float (seconds, 0 if healthy)
        conf   : np.ndarray of float (0–1)
        """
        self._require_trained()
        X = np.asarray(X, dtype=np.float32)
        if X.ndim == 2:
            X = X[np.newaxis]

        with torch.no_grad():
            X_t = torch.tensor(X).to(self.device)
            out = self._model(X_t)
            probs = torch.softmax(out["class_logits"], dim=1).cpu().numpy()
            ttf = (out["ttf"].squeeze(-1) * 30.0).cpu().numpy()
            conf = out["confidence"].squeeze(-1).cpu().numpy()

        class_ids = np.argmax(probs, axis=1)
        labels = np.array([HORIZON_NAMES[i] for i in class_ids])
        return labels, ttf, conf

    # ── Streaming / monitoring API ─────────────────────────────────────────────

    def observe(
        self,
        node_id: str,
        metrics: Union[dict, "Observation"],
    ) -> Optional[PredictionResult]:
        """
        Feed one timestep of metrics for a node.

        The window fills up incrementally.  Once ``window_size`` observations
        have been collected a :class:`PredictionResult` is returned; before
        that ``None`` is returned.

        Parameters
        ----------
        node_id:
            Cluster node identifier (e.g. ``"etcd-0"``).
        metrics:
            Either an :class:`~proactiveguard.engine.Observation` instance or
            a plain ``dict`` with matching field names.  Unknown keys are
            silently ignored; missing keys fall back to Observation defaults.

        Returns
        -------
        PredictionResult or None
        """
        self._require_trained()

        if isinstance(metrics, dict):
            obs = Observation(
                node_id=node_id,
                **{k: v for k, v in metrics.items() if k in Observation.__dataclass_fields__},
            )
        else:
            obs = metrics
            obs.node_id = node_id

        self._windows[node_id].append(obs)

        if len(self._windows[node_id]) < self.window_size:
            return None

        window_list = list(self._windows[node_id])
        features = extract_features(window_list, self.window_size)
        result = self._run_inference(node_id, features)
        self._latest[node_id] = result
        return result

    def status(self, node_id: str) -> Optional[PredictionResult]:
        """
        Return the latest prediction for `node_id`, or None if not yet ready.
        """
        return self._latest.get(node_id)

    def reset(self, node_id: Optional[str] = None) -> None:
        """
        Clear observation windows (and cached predictions).

        Parameters
        ----------
        node_id:
            If given, reset only that node.  If None, reset all nodes.
        """
        if node_id:
            self._windows.pop(node_id, None)
            self._latest.pop(node_id, None)
        else:
            self._windows.clear()
            self._latest.clear()

    # ── Persistence ────────────────────────────────────────────────────────────

    def save(self, path: Union[str, Path]) -> None:
        """
        Save model weights and metadata to disk.

        Parameters
        ----------
        path:
            Destination ``.pt`` file path.
        """
        self._require_trained()
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        torch.save(
            {
                "model_state_dict": self._model.state_dict(),
                "window_size": self.window_size,
                "input_size": self._model.input_size,
                "num_classes": self._model.num_classes,
                "proactiveguard_version": __version__,
            },
            path,
        )

    # ── Internal helpers ───────────────────────────────────────────────────────

    def _require_trained(self) -> None:
        if not self._trained or self._model is None:
            raise ModelNotTrainedError()

    def _run_inference(self, node_id: str, features: np.ndarray) -> PredictionResult:
        """Run the model on a single (window_size, n_features) feature array."""
        x = torch.tensor(features[np.newaxis], dtype=torch.float32).to(self.device)

        with torch.no_grad():
            out = self._model(x)
            probs = torch.softmax(out["class_logits"], dim=1).cpu().numpy()[0]
            conf = float(out["confidence"].squeeze().item())

        class_id = int(np.argmax(probs))
        status = HORIZON_NAMES[class_id]
        failure_type = FAILURE_TYPE_MAP.get(status)

        # Risk score = 1 − P(healthy)
        risk = float(1.0 - probs[PREDICTION_HORIZONS["healthy"]])

        # TTF: only meaningful when degraded/failed; else None
        time_to_failure: Optional[float]
        if status == "healthy":
            time_to_failure = None
        elif status.startswith("degraded_"):
            seconds = int(status.split("_")[1].replace("s", ""))
            time_to_failure = float(seconds)
        else:
            time_to_failure = 0.0

        return PredictionResult(
            node_id=node_id,
            status=status,
            risk_score=risk,
            confidence=conf,
            probabilities={HORIZON_NAMES[i]: float(probs[i]) for i in range(len(probs))},
            time_to_failure=time_to_failure,
            failure_type=failure_type,
        )

    def __repr__(self) -> str:
        state = "trained" if self._trained else "untrained"
        return f"ProactiveGuard(window_size={self.window_size}, device={self.device}, {state})"
