"""
PrometheusCollector — scrape etcd metrics from a Prometheus endpoint.

Usage
-----
    from proactiveguard.collectors import PrometheusCollector

    collector = PrometheusCollector(
        prometheus_url="http://prometheus:9090",
        # Optional: restrict to specific node labels
        node_selector={"job": "etcd"},
        interval_s=5.0,
    )

    for obs in collector.stream():
        pg.observe(obs.node_id, obs)

The collector recognises the standard etcd Prometheus metrics published by
etcd v3.  It expects metrics to be grouped by the ``instance`` label which
is used as the node ID.

Dependencies
------------
Requires the ``requests`` package (always installed as a core dependency).
"""

from __future__ import annotations

import time
from typing import Dict, Generator, List, Optional

import requests

from ..engine import Observation
from ..exceptions import CollectorError


class PrometheusCollector:
    """
    Collect per-node observations by querying a Prometheus server.

    Uses Prometheus's HTTP API (``/api/v1/query``) to fetch the latest
    values of etcd-specific metrics and converts them into
    :class:`~proactiveguard.engine.Observation` objects.

    Parameters
    ----------
    prometheus_url:
        Base URL of the Prometheus server, e.g. ``"http://localhost:9090"``.
    node_selector:
        Optional label matchers applied to every query, e.g.
        ``{"job": "etcd", "namespace": "default"}``.
    interval_s:
        Polling interval in seconds used by :meth:`stream`.
    timeout:
        HTTP request timeout in seconds.
    """

    # Prometheus metric names used by etcd 3.x
    _METRIC_MAP = {
        # raft
        "raft_term": "etcd_server_leader_changes_seen_total",  # proxy
        "commit_index": "etcd_disk_wal_fsync_duration_seconds_count",
        "leader": "etcd_server_is_leader",
        # messages
        "msgs_sent": "etcd_network_peer_sent_bytes_total",
        "msgs_received": "etcd_network_peer_received_bytes_total",
        "msgs_failed": "etcd_network_peer_sent_failures_total",
        # response / latency
        "rpc_duration_sum": "grpc_server_handling_seconds_sum",
        "rpc_duration_count": "grpc_server_handling_seconds_count",
        # heartbeat proxy
        "heartbeat_send": "etcd_server_heartbeat_send_failures_total",
    }

    def __init__(
        self,
        prometheus_url: str,
        *,
        node_selector: Optional[Dict[str, str]] = None,
        interval_s: float = 5.0,
        timeout: int = 10,
    ) -> None:
        self.base_url = prometheus_url.rstrip("/")
        self.node_selector = node_selector or {}
        self.interval_s = interval_s
        self.timeout = timeout

        self._prev_counters: Dict[str, Dict[str, float]] = {}
        self._prev_time: Dict[str, float] = {}

    # ── Public API ─────────────────────────────────────────────────────────────

    def collect_once(self) -> List[Observation]:
        """Query Prometheus for all known nodes and return Observation list."""
        try:
            raw = self._fetch_all_metrics()
        except requests.RequestException as exc:
            raise CollectorError(f"Prometheus unreachable: {exc}") from exc

        return self._build_observations(raw)

    def stream(self) -> Generator[Observation, None, None]:
        """
        Yield observations continuously at :attr:`interval_s` cadence.

            for obs in collector.stream():
                pg.observe(obs.node_id, obs)
        """
        while True:
            try:
                for obs in self.collect_once():
                    yield obs
            except CollectorError as exc:
                import warnings

                warnings.warn(f"PrometheusCollector: {exc}")
            time.sleep(self.interval_s)

    # ── Internal helpers ───────────────────────────────────────────────────────

    def _fetch_metric(self, metric_name: str) -> Dict[str, float]:
        """
        Fetch current value of `metric_name` from Prometheus.
        Returns {instance_label: value}.
        """
        selector = ",".join(f'{k}="{v}"' for k, v in self.node_selector.items())
        query = f"{metric_name}{{{selector}}}" if selector else metric_name
        url = f"{self.base_url}/api/v1/query"

        resp = requests.get(url, params={"query": query}, timeout=self.timeout)
        resp.raise_for_status()
        data = resp.json()

        results: Dict[str, float] = {}
        for result in data.get("data", {}).get("result", []):
            instance = result["metric"].get("instance", result["metric"].get("pod", "unknown"))
            value = float(result["value"][1])
            results[instance] = value

        return results

    def _fetch_all_metrics(self) -> Dict[str, Dict[str, float]]:
        """Fetch all configured metrics; return {metric_key: {instance: value}}."""
        raw: Dict[str, Dict[str, float]] = {}
        for key, prom_name in self._METRIC_MAP.items():
            try:
                raw[key] = self._fetch_metric(prom_name)
            except Exception:
                raw[key] = {}
        return raw

    def _build_observations(self, raw: Dict[str, Dict[str, float]]) -> List[Observation]:
        # Collect all known instances across all metrics
        instances: set = set()
        for metric_values in raw.values():
            instances.update(metric_values.keys())

        now = time.time()
        observations = []

        for instance in instances:
            prev = self._prev_counters.get(instance, {})
            dt = now - self._prev_time.get(instance, now - self.interval_s)
            dt = max(dt, 0.001)

            # Counters → deltas → rates
            sent_total = raw["msgs_sent"].get(instance, 0.0)
            recv_total = raw["msgs_received"].get(instance, 0.0)
            fail_total = raw["msgs_failed"].get(instance, 0.0)
            hb_fail = raw["heartbeat_send"].get(instance, 0.0)

            sent_delta = max(0.0, sent_total - prev.get("sent", sent_total))
            recv_delta = max(0.0, recv_total - prev.get("recv", recv_total))
            fail_delta = max(0.0, fail_total - prev.get("fail", fail_total))
            hb_fail_delta = max(0.0, hb_fail - prev.get("hb_fail", hb_fail))

            self._prev_counters[instance] = {
                "sent": sent_total,
                "recv": recv_total,
                "fail": fail_total,
                "hb_fail": hb_fail,
            }
            self._prev_time[instance] = now

            # Latency from gRPC histogram
            rpc_sum = raw["rpc_duration_sum"].get(instance, 0.0)
            rpc_count = raw["rpc_duration_count"].get(instance, 1.0)
            avg_latency_ms = (rpc_sum / max(rpc_count, 1)) * 1000.0

            is_leader = raw["leader"].get(instance, 0.0) > 0.5
            commit_index = int(raw["commit_index"].get(instance, 0))

            # Message counts (bytes → approx. message count at ~64 B/msg)
            msgs_sent = int(sent_delta / 64)
            msgs_recv = int(recv_delta / 64)
            msgs_drop = int(fail_delta)

            # Response rate: 1 - (dropped / (sent + 1))
            response_rate = max(0.0, 1.0 - msgs_drop / (msgs_sent + 1))

            # Missed heartbeats proxy from hb_fail counter
            missed_hb = int(hb_fail_delta)

            obs = Observation(
                timestamp_ms=now * 1000,
                node_id=f"prom-{instance}",
                observer_id="prometheus-collector",
                heartbeat_latency_ms=avg_latency_ms,
                latency_jitter_ms=0.0,
                latency_trend=0.0,
                messages_sent=msgs_sent,
                messages_received=msgs_recv,
                messages_dropped=msgs_drop,
                out_of_order_count=0,
                heartbeat_interval_actual_ms=150.0,
                heartbeat_interval_expected_ms=150.0,
                missed_heartbeats=missed_hb,
                response_rate=response_rate,
                response_time_avg_ms=avg_latency_ms,
                response_time_max_ms=avg_latency_ms * 2.0,
                term=int(raw.get("raft_term", {}).get(instance, 1)),
                log_length=commit_index,
                commit_index=commit_index,
                is_leader=is_leader,
                vote_participation=1.0,
                label="healthy",
            )
            observations.append(obs)

        return observations
