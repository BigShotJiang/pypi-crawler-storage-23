"""
EtcdCollector — scrape metrics directly from etcd v3 endpoints.

Usage
-----
    from proactiveguard.collectors import EtcdCollector

    collector = EtcdCollector(
        endpoints=["http://etcd-0:2379", "http://etcd-1:2379", "http://etcd-2:2379"],
        interval_s=1.0,
    )

    for obs in collector.stream():
        pg.observe(obs.node_id, obs)

Dependencies
------------
Requires the ``etcd3`` package (``pip install proactiveguard[etcd]``).
Falls back gracefully with a clear error if it is not installed.
"""

from __future__ import annotations

import time
from typing import Dict, Generator, List, Optional, Tuple

from ..engine import Observation
from ..exceptions import CollectorError

# ── Optional dependency guard ──────────────────────────────────────────────────

try:
    import etcd3  # type: ignore

    _ETCD3_AVAILABLE = True
except ImportError:
    _ETCD3_AVAILABLE = False


def _require_etcd3() -> None:
    if not _ETCD3_AVAILABLE:
        raise CollectorError(
            "The 'etcd3' package is required for EtcdCollector. "
            "Install it with: pip install proactiveguard[etcd]"
        )


# ── Collector ──────────────────────────────────────────────────────────────────


class EtcdCollector:
    """
    Collect per-node observations from a live etcd cluster.

    Fetches metrics via etcd's gRPC API (``etcd3`` library) and translates
    them into :class:`~proactiveguard.engine.Observation` objects suitable
    for :meth:`ProactiveGuard.observe`.

    Parameters
    ----------
    endpoints:
        List of etcd endpoint strings, e.g. ``["http://localhost:2379"]``.
        Each endpoint is treated as one cluster node.
    interval_s:
        Polling interval in seconds.  Used by :meth:`stream`.
    timeout:
        gRPC call timeout in seconds.
    ca_cert, cert_key, cert_cert:
        Optional TLS credentials (paths to PEM files).
    """

    def __init__(
        self,
        endpoints: List[str],
        *,
        interval_s: float = 1.0,
        timeout: int = 5,
        ca_cert: Optional[str] = None,
        cert_key: Optional[str] = None,
        cert_cert: Optional[str] = None,
    ) -> None:
        _require_etcd3()
        self.endpoints = endpoints
        self.interval_s = interval_s
        self.timeout = timeout
        self._tls = dict(ca_cert=ca_cert, cert_key=cert_key, cert_cert=cert_cert)

        # Snapshot state for delta calculations
        self._prev_stats: Dict[str, dict] = {}
        self._prev_time: Dict[str, float] = {}

    # ── Public API ─────────────────────────────────────────────────────────────

    def collect_once(self) -> List[Observation]:
        """
        Poll every endpoint once and return a list of Observations.

        Nodes that fail to respond are skipped (no exception raised).
        """
        observations: List[Observation] = []
        for endpoint in self.endpoints:
            obs = self._collect_endpoint(endpoint)
            if obs is not None:
                observations.append(obs)
        return observations

    def stream(self) -> Generator[Observation, None, None]:
        """
        Yield observations continuously at :attr:`interval_s` cadence.

        This is a blocking generator; run it in a thread or async task.

            for obs in collector.stream():
                pg.observe(obs.node_id, obs)
        """
        while True:
            for obs in self.collect_once():
                yield obs
            time.sleep(self.interval_s)

    # ── Internal helpers ───────────────────────────────────────────────────────

    def _make_client(self, host: str, port: int) -> "etcd3.Etcd3Client":
        tls = {k: v for k, v in self._tls.items() if v is not None}
        return etcd3.client(host=host, port=port, timeout=self.timeout, **tls)

    def _collect_endpoint(self, endpoint: str) -> Optional[Observation]:
        try:
            host, port = self._parse_endpoint(endpoint)
            client = self._make_client(host, port)

            # Fetch cluster member list to resolve this endpoint's member ID
            members = client.members
            node_id = self._resolve_node_id(endpoint, members)

            # etcd status for this member
            status = client.status()
            now = time.time()

            # Leader detection
            is_leader = status.leader == status.header.member_id

            # Compute message rate deltas
            prev = self._prev_stats.get(node_id, {})
            dt = now - self._prev_time.get(node_id, now - self.interval_s)
            dt = max(dt, 0.001)

            msgs_sent_total = getattr(status, "sent_bytes_rate", 0) / 64
            msgs_recv_total = getattr(status, "received_bytes_rate", 0) / 64
            msgs_sent_delta = max(0, msgs_sent_total - prev.get("sent", 0))
            msgs_recv_delta = max(0, msgs_recv_total - prev.get("recv", 0))

            # Store for next delta
            self._prev_stats[node_id] = {"sent": msgs_sent_total, "recv": msgs_recv_total}
            self._prev_time[node_id] = now

            obs = Observation(
                timestamp_ms=now * 1000,
                node_id=node_id,
                observer_id="etcd-collector",
                # Latency — etcd does not expose heartbeat RTT directly;
                # we use db_size as a proxy for response time.
                heartbeat_latency_ms=float(status.db_size) / 1e6,
                latency_jitter_ms=0.0,
                latency_trend=0.0,
                # Messages (rates converted to counts per interval)
                messages_sent=int(msgs_sent_delta * dt),
                messages_received=int(msgs_recv_delta * dt),
                messages_dropped=0,
                out_of_order_count=0,
                # Heartbeat
                heartbeat_interval_actual_ms=150.0,
                heartbeat_interval_expected_ms=150.0,
                missed_heartbeats=0,
                # Response
                response_rate=1.0,
                response_time_avg_ms=0.0,
                response_time_max_ms=0.0,
                # Raft
                term=int(status.raft_term),
                log_length=int(status.raft_applied_index),
                commit_index=int(status.raft_applied_index),
                is_leader=is_leader,
                vote_participation=1.0,
                label="healthy",
            )
            return obs

        except Exception as exc:
            # Non-fatal: log and continue
            import warnings

            warnings.warn(f"EtcdCollector: failed to collect from {endpoint!r}: {exc}")
            return None

    @staticmethod
    def _parse_endpoint(endpoint: str) -> Tuple[str, int]:
        """Parse 'http://host:port' or 'host:port' into (host, port)."""
        ep = endpoint.replace("https://", "").replace("http://", "")
        if ":" in ep:
            host, port_str = ep.rsplit(":", 1)
            return host, int(port_str)
        return ep, 2379

    @staticmethod
    def _resolve_node_id(endpoint: str, members) -> str:
        """Use endpoint URL as node ID (stable, human-readable)."""
        ep = endpoint.replace("https://", "").replace("http://", "")
        return f"etcd-{ep}"
