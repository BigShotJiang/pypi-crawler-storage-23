"""
ProactiveGuard metric collectors.

Collectors scrape real cluster metrics and convert them into the
:class:`~proactiveguard.engine.Observation` format expected by
:meth:`ProactiveGuard.observe`.

Available collectors
--------------------
EtcdCollector
    Connects directly to etcd v3 endpoints via gRPC.
PrometheusCollector
    Scrapes etcd metrics exposed through a Prometheus endpoint.
"""

from .etcd import EtcdCollector
from .prometheus import PrometheusCollector

__all__ = ["EtcdCollector", "PrometheusCollector"]
