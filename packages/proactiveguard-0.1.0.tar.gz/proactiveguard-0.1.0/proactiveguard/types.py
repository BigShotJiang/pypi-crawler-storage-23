"""
ProactiveGuard public types.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Dict, Optional


@dataclass
class PredictionResult:
    """
    The result of a single ProactiveGuard prediction for one node.

    Attributes
    ----------
    node_id:
        Identifier of the cluster node.
    status:
        One of 'healthy', 'degraded_30s', 'degraded_20s', 'degraded_10s',
        'degraded_5s', 'failed_crash', 'failed_slow', 'failed_byzantine',
        'failed_partition'.
    risk_score:
        Probability that the node is NOT healthy (0.0 = certainly healthy,
        1.0 = certainly failed/degraded).
    time_to_failure:
        Estimated seconds until failure (None if the node is healthy).
    failure_type:
        One of 'crash', 'slow', 'byzantine', 'partition', or None.
    confidence:
        Model confidence in this prediction (0.0–1.0).
    probabilities:
        Full probability distribution over all nine classes.
    is_healthy:
        True when status == 'healthy'.
    is_pre_failure:
        True when the node shows degradation but has not yet failed.
    is_failed:
        True when the node is predicted to have already failed.
    timestamp:
        UNIX timestamp (seconds) when the prediction was produced.
    """

    node_id: str
    status: str
    risk_score: float
    confidence: float
    probabilities: Dict[str, float] = field(default_factory=dict)
    time_to_failure: Optional[float] = None
    failure_type: Optional[str] = None
    timestamp: float = field(default_factory=time.time)

    # Convenience flags computed in __post_init__
    is_healthy: bool = field(init=False)
    is_pre_failure: bool = field(init=False)
    is_failed: bool = field(init=False)

    _DEGRADED = {"degraded_30s", "degraded_20s", "degraded_10s", "degraded_5s"}
    _FAILED = {"failed_crash", "failed_slow", "failed_byzantine", "failed_partition"}

    def __post_init__(self) -> None:
        self.is_healthy = self.status == "healthy"
        self.is_pre_failure = self.status in self._DEGRADED
        self.is_failed = self.status in self._FAILED

    def to_dict(self) -> dict:
        return {
            "node_id": self.node_id,
            "status": self.status,
            "risk_score": round(self.risk_score, 4),
            "confidence": round(self.confidence, 4),
            "time_to_failure": self.time_to_failure,
            "failure_type": self.failure_type,
            "is_healthy": self.is_healthy,
            "is_pre_failure": self.is_pre_failure,
            "is_failed": self.is_failed,
            "probabilities": {k: round(v, 4) for k, v in self.probabilities.items()},
            "timestamp": self.timestamp,
        }

    def __repr__(self) -> str:
        ttf = f", ttf={self.time_to_failure:.1f}s" if self.time_to_failure else ""
        return (
            f"PredictionResult(node={self.node_id!r}, status={self.status!r}, "
            f"risk={self.risk_score:.3f}, confidence={self.confidence:.3f}{ttf})"
        )
