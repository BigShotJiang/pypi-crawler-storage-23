"""
ProactiveGuard Engine
Core model architecture, feature extraction, and data types.
Shared between the PyPI package and the SaaS backend.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

import numpy as np
import torch
import torch.nn as nn

# ── Configuration ──────────────────────────────────────────────────────────────

NUM_FEATURES = 32
WINDOW_SIZE = 50

PREDICTION_HORIZONS: Dict[str, int] = {
    "healthy": 0,
    "degraded_30s": 1,
    "degraded_20s": 2,
    "degraded_10s": 3,
    "degraded_5s": 4,
    "failed_crash": 5,
    "failed_slow": 6,
    "failed_byzantine": 7,
    "failed_partition": 8,
}

HORIZON_NAMES: Dict[int, str] = {v: k for k, v in PREDICTION_HORIZONS.items()}
NUM_PREDICTION_CLASSES = len(PREDICTION_HORIZONS)

# Human-readable failure type from horizon label
FAILURE_TYPE_MAP: Dict[str, Optional[str]] = {
    "healthy": None,
    "degraded_30s": None,
    "degraded_20s": None,
    "degraded_10s": None,
    "degraded_5s": None,
    "failed_crash": "crash",
    "failed_slow": "slow",
    "failed_byzantine": "byzantine",
    "failed_partition": "partition",
}


# ── Observation dataclass ──────────────────────────────────────────────────────


@dataclass
class Observation:
    """
    A single timestep observation from a cluster node.
    All fields have defaults so you can partially specify metrics.
    """

    timestamp_ms: float = 0.0
    node_id: str = "node_0"
    observer_id: str = "observer"

    # Latency
    heartbeat_latency_ms: float = 20.0
    latency_jitter_ms: float = 5.0
    latency_trend: float = 0.0

    # Messages
    messages_sent: int = 10
    messages_received: int = 10
    messages_dropped: int = 0
    out_of_order_count: int = 0

    # Heartbeat
    heartbeat_interval_actual_ms: float = 150.0
    heartbeat_interval_expected_ms: float = 150.0
    missed_heartbeats: int = 0

    # Response
    response_rate: float = 1.0
    response_time_avg_ms: float = 15.0
    response_time_max_ms: float = 30.0

    # Raft state
    term: int = 1
    log_length: int = 100
    commit_index: int = 99
    is_leader: bool = False
    vote_participation: float = 1.0

    label: str = "healthy"


# ── Feature extraction ─────────────────────────────────────────────────────────


def extract_features(observations: List[Any], window_size: int = WINDOW_SIZE) -> np.ndarray:
    """
    Convert a list of Observation (or compatible) objects into a
    (window_size, NUM_FEATURES) float32 numpy array.

    Compatible objects just need matching attribute names.
    """
    features = np.zeros((window_size, NUM_FEATURES), dtype=np.float32)

    n_obs = min(len(observations), window_size)
    start_idx = window_size - n_obs

    latencies: List[float] = []
    response_rates: List[float] = []

    for i, obs in enumerate(observations[-window_size:]):
        idx = start_idx + i

        latencies.append(obs.heartbeat_latency_ms)
        response_rates.append(obs.response_rate)

        # Latency features (cols 0-7)
        features[idx, 0] = min(1.0, obs.heartbeat_latency_ms / 200.0)
        features[idx, 1] = min(1.0, obs.latency_jitter_ms / 100.0)
        features[idx, 2] = float(np.tanh(obs.latency_trend / 20.0))

        # Message features (cols 8-13)
        total = obs.messages_sent + obs.messages_received + 1
        features[idx, 8] = min(1.0, obs.messages_received / 50.0)
        features[idx, 9] = min(1.0, obs.messages_sent / 50.0)
        features[idx, 10] = obs.messages_dropped / (total + 1)
        features[idx, 11] = obs.out_of_order_count / (total + 1)

        # Heartbeat features (cols 14-18)
        features[idx, 14] = obs.response_rate
        features[idx, 15] = min(1.0, obs.missed_heartbeats / 5.0)
        features[idx, 16] = 1.0 if obs.missed_heartbeats > 2 else 0.0

        # Response features (cols 19-22)
        features[idx, 19] = min(1.0, obs.response_time_avg_ms / 200.0)
        features[idx, 20] = min(1.0, obs.response_time_max_ms / 500.0)

        # Raft features (cols 23-27)
        features[idx, 23] = 1.0 if obs.is_leader else 0.0
        features[idx, 24] = min(1.0, obs.term / 10.0)
        features[idx, 25] = min(1.0, obs.log_length / 100.0)
        features[idx, 26] = min(1.0, obs.commit_index / 100.0)

        # Slow-detection indicators (cols 28-31)
        is_responding = obs.response_rate > 0.3
        is_high_latency = obs.heartbeat_latency_ms > 50
        features[idx, 28] = 1.0 if (is_responding and is_high_latency) else 0.0

        if obs.response_time_avg_ms > 0:
            features[idx, 29] = min(1.0, obs.heartbeat_latency_ms / (obs.response_time_avg_ms + 1))
        features[idx, 30] = 1.0 if obs.latency_trend > 5 else 0.0

    # Window-level aggregate statistics (broadcast across all rows)
    if n_obs > 1:
        features[:, 3] = float(np.mean(latencies)) / 200.0
        features[:, 4] = (float(np.std(latencies)) / 100.0) if len(latencies) > 1 else 0.0
        features[:, 5] = float(np.min(latencies)) / 200.0
        features[:, 6] = float(np.max(latencies)) / 200.0
        features[:, 7] = float(np.max(latencies) - np.min(latencies)) / 200.0

        avg_latency = float(np.mean(latencies))
        avg_response = float(np.mean(response_rates))
        features[:, 31] = 1.0 if (avg_latency > 80 and avg_response > 0.3) else 0.0
        features[:, 12] = 1.0 if avg_response < 0.1 else 0.0

    return features


# ── Model building blocks ──────────────────────────────────────────────────────


class ResBlock(nn.Module):
    """Residual block for 1-D convolution."""

    def __init__(self, channels: int):
        super().__init__()
        self.conv1 = nn.Conv1d(channels, channels, 3, padding=1)
        self.bn1 = nn.BatchNorm1d(channels)
        self.conv2 = nn.Conv1d(channels, channels, 3, padding=1)
        self.bn2 = nn.BatchNorm1d(channels)
        self.relu = nn.ReLU()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        x = self.relu(self.bn1(self.conv1(x)))
        x = self.bn2(self.conv2(x))
        return self.relu(x + residual)


class SEBlock(nn.Module):
    """Squeeze-and-Excitation channel attention block."""

    def __init__(self, channels: int, reduction: int = 4):
        super().__init__()
        self.pool = nn.AdaptiveAvgPool1d(1)
        self.fc = nn.Sequential(
            nn.Linear(channels, channels // reduction),
            nn.ReLU(),
            nn.Linear(channels // reduction, channels),
            nn.Sigmoid(),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, c, _ = x.size()
        w = self.pool(x).view(b, c)
        w = self.fc(w).view(b, c, 1)
        return x * w


# ── Main model ─────────────────────────────────────────────────────────────────


class PredictiveModel(nn.Module):
    """
    ProactiveGuard predictive failure detection model.

    Architecture:
      - Linear input projection + Layer Norm
      - ResNet-style 1-D CNN with Squeeze-and-Excitation blocks
      - Bidirectional LSTM
      - Multi-head self-attention
      - Feature fusion → latent representation
      - Output heads: classification, time-to-failure regression,
        binary healthy/failure, confidence estimation
    """

    def __init__(
        self,
        input_size: int = NUM_FEATURES,
        hidden_size: int = 128,
        latent_size: int = 64,
        seq_len: int = WINDOW_SIZE,
        num_classes: int = NUM_PREDICTION_CLASSES,
    ):
        super().__init__()

        self.input_size = input_size
        self.seq_len = seq_len
        self.num_classes = num_classes

        # Input projection
        self.input_proj = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.LayerNorm(hidden_size),
            nn.ReLU(),
            nn.Dropout(0.2),
        )

        # CNN branch
        self.conv_layers = nn.Sequential(
            nn.Conv1d(hidden_size, hidden_size, 7, padding=3),
            nn.BatchNorm1d(hidden_size),
            nn.ReLU(),
            ResBlock(hidden_size),
            SEBlock(hidden_size),
            ResBlock(hidden_size),
            SEBlock(hidden_size),
            nn.AdaptiveAvgPool1d(1),
        )

        # LSTM branch
        self.lstm = nn.LSTM(
            hidden_size,
            hidden_size // 2,
            num_layers=2,
            batch_first=True,
            bidirectional=True,
            dropout=0.2,
        )

        # Attention branch
        self.attention = nn.MultiheadAttention(hidden_size, 4, dropout=0.1, batch_first=True)
        self.attn_norm = nn.LayerNorm(hidden_size)

        # Fusion
        self.fusion = nn.Sequential(
            nn.Linear(hidden_size * 3, hidden_size),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(hidden_size, latent_size),
            nn.Tanh(),
        )

        # Classification head (prediction horizon)
        self.classifier = nn.Sequential(
            nn.Linear(latent_size, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Dropout(0.4),
            nn.Linear(128, 64),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(64, num_classes),
        )

        # Time-to-failure regression head (0–30 s, normalised to 0–1)
        self.ttf_regressor = nn.Sequential(
            nn.Linear(latent_size, 64),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Linear(32, 1),
            nn.Sigmoid(),
        )

        # Binary head (healthy vs any failure)
        self.binary_classifier = nn.Sequential(
            nn.Linear(latent_size, 32),
            nn.ReLU(),
            nn.Linear(32, 2),
        )

        # Confidence estimation
        self.confidence_head = nn.Sequential(
            nn.Linear(latent_size, 32),
            nn.ReLU(),
            nn.Linear(32, 1),
            nn.Sigmoid(),
        )

    def forward(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        x: (batch, seq_len, input_size)
        Returns dict with keys: class_logits, ttf, binary_logits, confidence, latent
        """
        # Project input features
        x = self.input_proj(x)  # (B, T, H)

        # CNN branch
        x_cnn = self.conv_layers(x.permute(0, 2, 1)).squeeze(-1)  # (B, H)

        # LSTM branch
        x_lstm, _ = self.lstm(x)
        x_lstm = x_lstm[:, -1, :]  # (B, H)

        # Attention branch
        x_attn, _ = self.attention(x, x, x)
        x_attn = self.attn_norm(x + x_attn).mean(dim=1)  # (B, H)

        # Fuse all three branches
        latent = self.fusion(torch.cat([x_cnn, x_lstm, x_attn], dim=1))  # (B, latent)

        return {
            "class_logits": self.classifier(latent),
            "ttf": self.ttf_regressor(latent),
            "binary_logits": self.binary_classifier(latent),
            "confidence": self.confidence_head(latent),
            "latent": latent,
        }

    def predict(self, x: torch.Tensor) -> torch.Tensor:
        return torch.argmax(self.forward(x)["class_logits"], dim=1)

    def predict_with_ttf(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        out = self.forward(x)
        class_pred = torch.argmax(out["class_logits"], dim=1)
        ttf_pred = out["ttf"].squeeze(-1) * 30.0  # back to seconds
        confidence = out["confidence"].squeeze(-1)
        return class_pred, ttf_pred, confidence
