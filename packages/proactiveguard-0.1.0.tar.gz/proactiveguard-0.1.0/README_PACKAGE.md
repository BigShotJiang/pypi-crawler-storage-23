# ProactiveGuard

**Predictive failure detection for distributed consensus systems.**

ProactiveGuard uses deep learning to predict node failures in etcd, Raft, and CockroachDB clusters *before* they happen — giving you 5–30 seconds to act rather than reacting after the fact.

[![PyPI version](https://badge.fury.io/py/proactiveguard.svg)](https://badge.fury.io/py/proactiveguard)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

---

## Why ProactiveGuard?

| | Timeout-based | Phi Accrual | **ProactiveGuard** |
|---|---|---|---|
| Detects crash failures | After timeout | After timeout | **Before failure** |
| Detects slow/byzantine | No | No | **Yes** |
| Recall on etcd simulation | — | 98% | **100%** |
| Predict time-to-failure | No | No | **Yes (5–30s ahead)** |

## Installation

```bash
pip install proactiveguard
```

With real etcd cluster support:
```bash
pip install "proactiveguard[etcd]"
```

## Quick Start

### Pre-trained model (etcd / Raft clusters)

```python
from proactiveguard import ProactiveGuard
from proactiveguard.collectors import PrometheusCollector

pg = ProactiveGuard.from_pretrained("etcd-raft-v1")

collector = PrometheusCollector("http://prometheus:9090")

for obs in collector.stream():
    result = pg.observe(obs.node_id, obs)
    if result and result.is_pre_failure:
        print(f"Warning: {result.node_id} — {result.status}")
        print(f"  Estimated time to failure: {result.time_to_failure:.0f}s")
        print(f"  Failure type: {result.failure_type}")
```

### Train on your own data

```python
import numpy as np
from proactiveguard import ProactiveGuard
from proactiveguard.engine import PREDICTION_HORIZONS

pg = ProactiveGuard(window_size=50)

# X: (n_samples, window_size, n_features)
# y: integer class labels from PREDICTION_HORIZONS
X_train = np.random.randn(1000, 50, 32).astype("float32")
y_train = np.random.randint(0, 9, size=1000)

pg.fit(X_train, y_train, epochs=50)

# Predict
labels = pg.predict(X_test)          # → ['healthy', 'degraded_10s', ...]
probs  = pg.predict_proba(X_test)    # → (n, 9) probability array

# Save / load
pg.save("my_model.pt")
pg = ProactiveGuard.load("my_model.pt")
```

### Feed raw metrics dict

```python
pg = ProactiveGuard.from_pretrained("etcd-raft-v1")

# Call observe() once per polling interval for each node
result = pg.observe("etcd-0", {
    "heartbeat_latency_ms": 45.0,
    "missed_heartbeats": 2,
    "response_rate": 0.8,
    "messages_dropped": 3,
    "term": 5,
    "commit_index": 1042,
    "is_leader": False,
})

if result:  # None until window_size observations collected
    print(result)
    # PredictionResult(node='etcd-0', status='degraded_10s', risk=0.82, confidence=0.91)
```

## Prediction Classes

| Class | Meaning |
|-------|---------|
| `healthy` | Node operating normally |
| `degraded_30s` | Predicted failure in ~30 seconds |
| `degraded_20s` | Predicted failure in ~20 seconds |
| `degraded_10s` | Predicted failure in ~10 seconds |
| `degraded_5s`  | Predicted failure in ~5 seconds |
| `failed_crash` | Node has crashed / stopped responding |
| `failed_slow`  | Node is severely degraded (slow) |
| `failed_byzantine` | Node exhibiting Byzantine behaviour |
| `failed_partition` | Node is network-partitioned |

## Collectors

### Prometheus (recommended)

```python
from proactiveguard.collectors import PrometheusCollector

collector = PrometheusCollector(
    prometheus_url="http://prometheus:9090",
    node_selector={"job": "etcd"},
    interval_s=5.0,
)

for obs in collector.stream():
    pg.observe(obs.node_id, obs)
```

### Direct etcd gRPC

```python
from proactiveguard.collectors import EtcdCollector  # requires pip install proactiveguard[etcd]

collector = EtcdCollector(
    endpoints=["http://etcd-0:2379", "http://etcd-1:2379", "http://etcd-2:2379"],
    interval_s=1.0,
)

for obs in collector.stream():
    pg.observe(obs.node_id, obs)
```

## Model Architecture

- **Input**: 50-step sliding window × 32 features per step
- **CNN branch**: 1-D ResNet with Squeeze-and-Excitation attention
- **LSTM branch**: Bidirectional 2-layer LSTM
- **Attention branch**: 4-head multi-head self-attention
- **Fusion**: Concat → MLP → latent representation
- **Output heads**: 9-class classification + time-to-failure regression + confidence estimation

## Research

ProactiveGuard is based on peer-reviewed research submitted to the *Journal of Supercomputing*.

Experimental results:
- **Google Cluster traces**: 100% recall
- **Backblaze hard-drive failures**: 100% recall
- **etcd/Raft simulation**: 100% recall vs. 98% for Phi Accrual

## License

MIT License. See [LICENSE](LICENSE) for details.
