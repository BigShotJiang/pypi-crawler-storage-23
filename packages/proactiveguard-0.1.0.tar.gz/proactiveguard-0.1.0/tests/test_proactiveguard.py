"""
Tests for the proactiveguard PyPI package.
Run with: pytest tests/test_proactiveguard.py -v
"""

import numpy as np
import pytest

from proactiveguard import Observation, PredictionResult, ProactiveGuard
from proactiveguard.engine import (
    HORIZON_NAMES,
    NUM_FEATURES,
    NUM_PREDICTION_CLASSES,
    PREDICTION_HORIZONS,
    WINDOW_SIZE,
    PredictiveModel,
    extract_features,
)
from proactiveguard.exceptions import (
    ModelNotTrainedError,
    WeightsNotFoundError,
)


# ── Fixtures ───────────────────────────────────────────────────────────────────

@pytest.fixture
def trained_pg():
    """A ProactiveGuard trained on minimal synthetic data."""
    pg = ProactiveGuard(window_size=WINDOW_SIZE)
    X = np.random.randn(80, WINDOW_SIZE, NUM_FEATURES).astype("float32")
    y = np.random.randint(0, NUM_PREDICTION_CLASSES, size=80)
    pg.fit(X, y, epochs=2, verbose=False)
    return pg


@pytest.fixture
def pretrained_pg():
    """Pre-trained model loaded from bundled weights."""
    return ProactiveGuard.from_pretrained("etcd-raft-v1")


@pytest.fixture
def healthy_window():
    """A window of 50 healthy-looking Observation objects."""
    obs_list = []
    for i in range(WINDOW_SIZE):
        obs_list.append(Observation(
            timestamp_ms=float(i * 150),
            node_id="node-0",
            heartbeat_latency_ms=20.0,
            latency_jitter_ms=2.0,
            response_rate=1.0,
            missed_heartbeats=0,
            messages_sent=10,
            messages_received=10,
            messages_dropped=0,
            is_leader=False,
            term=1,
            log_length=100,
            commit_index=99,
        ))
    return obs_list


# ── Engine tests ───────────────────────────────────────────────────────────────

class TestEngine:
    def test_prediction_horizons_complete(self):
        assert set(PREDICTION_HORIZONS.keys()) == {
            "healthy", "degraded_30s", "degraded_20s", "degraded_10s", "degraded_5s",
            "failed_crash", "failed_slow", "failed_byzantine", "failed_partition",
        }

    def test_horizon_names_bijection(self):
        assert len(HORIZON_NAMES) == NUM_PREDICTION_CLASSES
        for idx, name in HORIZON_NAMES.items():
            assert PREDICTION_HORIZONS[name] == idx

    def test_extract_features_shape(self, healthy_window):
        features = extract_features(healthy_window, window_size=WINDOW_SIZE)
        assert features.shape == (WINDOW_SIZE, NUM_FEATURES)
        assert features.dtype == np.float32

    def test_extract_features_partial_window(self, healthy_window):
        """Fewer observations than window_size should still work (zero-padded)."""
        features = extract_features(healthy_window[:10], window_size=WINDOW_SIZE)
        assert features.shape == (WINDOW_SIZE, NUM_FEATURES)

    def test_extract_features_values_in_range(self, healthy_window):
        features = extract_features(healthy_window)
        # Most normalised values should be in [0, 1] (tanh can be [-1, 1])
        assert features.max() <= 1.01
        assert features.min() >= -1.01

    def test_predictive_model_forward(self):
        import torch
        model = PredictiveModel()
        x = torch.randn(4, WINDOW_SIZE, NUM_FEATURES)
        out = model(x)
        assert "class_logits" in out
        assert out["class_logits"].shape == (4, NUM_PREDICTION_CLASSES)
        assert out["ttf"].shape == (4, 1)
        assert out["confidence"].shape == (4, 1)


# ── ProactiveGuard API tests ───────────────────────────────────────────────────

class TestProactiveGuard:
    def test_untrained_raises(self):
        pg = ProactiveGuard()
        X = np.random.randn(2, WINDOW_SIZE, NUM_FEATURES).astype("float32")
        with pytest.raises(ModelNotTrainedError):
            pg.predict(X)

    def test_fit_returns_self(self):
        pg = ProactiveGuard()
        X = np.random.randn(20, WINDOW_SIZE, NUM_FEATURES).astype("float32")
        y = np.zeros(20, dtype=int)
        result = pg.fit(X, y, epochs=1, verbose=False)
        assert result is pg

    def test_predict_shape_batch(self, trained_pg):
        X = np.random.randn(5, WINDOW_SIZE, NUM_FEATURES).astype("float32")
        labels = trained_pg.predict(X)
        assert labels.shape == (5,)
        for label in labels:
            assert label in PREDICTION_HORIZONS

    def test_predict_single_window(self, trained_pg):
        X = np.random.randn(WINDOW_SIZE, NUM_FEATURES).astype("float32")
        labels = trained_pg.predict(X)
        assert labels.shape == (1,)
        assert labels[0] in PREDICTION_HORIZONS

    def test_predict_proba_shape_and_sums(self, trained_pg):
        X = np.random.randn(4, WINDOW_SIZE, NUM_FEATURES).astype("float32")
        probs = trained_pg.predict_proba(X)
        assert probs.shape == (4, NUM_PREDICTION_CLASSES)
        np.testing.assert_allclose(probs.sum(axis=1), 1.0, atol=1e-5)
        assert (probs >= 0).all()

    def test_predict_with_ttf(self, trained_pg):
        X = np.random.randn(3, WINDOW_SIZE, NUM_FEATURES).astype("float32")
        labels, ttf, conf = trained_pg.predict_with_ttf(X)
        assert labels.shape == (3,)
        assert ttf.shape == (3,)
        assert conf.shape == (3,)
        assert (conf >= 0).all() and (conf <= 1).all()
        assert (ttf >= 0).all()

    def test_save_and_load(self, trained_pg, tmp_path):
        path = tmp_path / "model.pt"
        trained_pg.save(path)
        assert path.exists()

        pg2 = ProactiveGuard.load(path)
        assert pg2._trained

        X = np.random.randn(2, WINDOW_SIZE, NUM_FEATURES).astype("float32")
        labels_orig = trained_pg.predict(X)
        labels_load = pg2.predict(X)
        np.testing.assert_array_equal(labels_orig, labels_load)

    def test_repr(self, trained_pg):
        r = repr(trained_pg)
        assert "ProactiveGuard" in r
        assert "trained" in r


# ── Streaming API tests ────────────────────────────────────────────────────────

class TestStreamingAPI:
    def test_observe_returns_none_until_window_full(self, pretrained_pg):
        pretrained_pg.reset()
        for i in range(WINDOW_SIZE - 1):
            result = pretrained_pg.observe("node-x", {"heartbeat_latency_ms": 20.0})
            assert result is None, f"Expected None at step {i}"

    def test_observe_returns_result_when_window_full(self, pretrained_pg):
        pretrained_pg.reset()
        result = None
        for i in range(WINDOW_SIZE):
            result = pretrained_pg.observe("node-y", {"heartbeat_latency_ms": 20.0})
        assert isinstance(result, PredictionResult)

    def test_observe_with_observation_object(self, pretrained_pg, healthy_window):
        pretrained_pg.reset()
        result = None
        for obs in healthy_window:
            result = pretrained_pg.observe("node-z", obs)
        assert result is not None
        assert result.node_id == "node-z"

    def test_status_before_window_full(self, pretrained_pg):
        pretrained_pg.reset("node-s")
        assert pretrained_pg.status("node-s") is None

    def test_status_after_window_full(self, pretrained_pg, healthy_window):
        pretrained_pg.reset("node-t")
        for obs in healthy_window:
            pretrained_pg.observe("node-t", obs)
        assert pretrained_pg.status("node-t") is not None

    def test_reset_clears_state(self, pretrained_pg, healthy_window):
        for obs in healthy_window:
            pretrained_pg.observe("node-r", obs)
        pretrained_pg.reset("node-r")
        assert pretrained_pg.status("node-r") is None


# ── PredictionResult tests ─────────────────────────────────────────────────────

class TestPredictionResult:
    def test_healthy_flags(self):
        r = PredictionResult(
            node_id="n", status="healthy",
            risk_score=0.01, confidence=0.95
        )
        assert r.is_healthy
        assert not r.is_pre_failure
        assert not r.is_failed

    def test_degraded_flags(self):
        for status in ["degraded_30s", "degraded_20s", "degraded_10s", "degraded_5s"]:
            r = PredictionResult(node_id="n", status=status, risk_score=0.5, confidence=0.8)
            assert not r.is_healthy
            assert r.is_pre_failure
            assert not r.is_failed

    def test_failed_flags(self):
        for status in ["failed_crash", "failed_slow", "failed_byzantine", "failed_partition"]:
            r = PredictionResult(node_id="n", status=status, risk_score=0.99, confidence=0.97)
            assert not r.is_healthy
            assert not r.is_pre_failure
            assert r.is_failed

    def test_to_dict_keys(self):
        r = PredictionResult(node_id="n", status="healthy", risk_score=0.0, confidence=1.0)
        d = r.to_dict()
        for key in ("node_id", "status", "risk_score", "confidence",
                    "is_healthy", "is_pre_failure", "is_failed", "timestamp"):
            assert key in d


# ── Exceptions tests ───────────────────────────────────────────────────────────

class TestExceptions:
    def test_weights_not_found(self):
        with pytest.raises(WeightsNotFoundError):
            ProactiveGuard.from_pretrained("nonexistent-model")

    def test_model_not_trained_message(self):
        exc = ModelNotTrainedError()
        assert "fit()" in str(exc) or "from_pretrained" in str(exc)


# ── Pre-trained model smoke test ───────────────────────────────────────────────

class TestPretrained:
    def test_from_pretrained_loads(self, pretrained_pg):
        assert pretrained_pg._trained
        assert pretrained_pg._model is not None

    def test_pretrained_predict(self, pretrained_pg):
        X = np.random.randn(2, WINDOW_SIZE, NUM_FEATURES).astype("float32")
        labels = pretrained_pg.predict(X)
        assert all(l in PREDICTION_HORIZONS for l in labels)

    def test_pretrained_repr(self, pretrained_pg):
        assert "trained" in repr(pretrained_pg)
