BDF
===

.. automodule:: pathsim.solvers.bdf
   :members:
   :show-inheritance:
   :undoc-members:
