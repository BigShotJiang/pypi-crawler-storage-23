Operator
========

.. automodule:: pathsim.optim.operator
   :members:
   :show-inheritance:
   :undoc-members:
