Gilbert Realization
===================

.. automodule:: pathsim.utils.gilbert
   :members:
   :show-inheritance:
   :undoc-members:
