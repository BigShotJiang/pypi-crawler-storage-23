Function
========

.. automodule:: pathsim.blocks.function
   :members:
   :show-inheritance:
   :undoc-members:
