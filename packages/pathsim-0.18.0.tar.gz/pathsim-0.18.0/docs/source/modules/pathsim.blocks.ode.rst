ODE
===

.. automodule:: pathsim.blocks.ode
   :members:
   :show-inheritance:
   :undoc-members:
