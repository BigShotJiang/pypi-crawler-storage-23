LTI
===

.. automodule:: pathsim.blocks.lti
   :members:
   :show-inheritance:
   :undoc-members:
