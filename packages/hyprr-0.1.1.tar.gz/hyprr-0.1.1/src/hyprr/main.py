from .classes.hyprpaper import Hyprpaper

def main():
    hyprpaper = Hyprpaper()
    hyprpaper.change_wallpaper_randomly()

    hyprpaper.reload_environment()

if __name__ == "__main__": 
    main()
    
