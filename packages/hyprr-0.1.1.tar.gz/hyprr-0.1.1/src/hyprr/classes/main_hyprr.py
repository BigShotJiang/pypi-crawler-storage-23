from pathlib import Path
import subprocess

class Hyprr:
    def __init__(self):
        self.home = Path.home()
        self.config_dir = Path.home() / ".config/"

    @staticmethod
    def reload_environment():
        programs = [
            "hyprpaper",
            "waybar",
            "wofi",
        ]

        for program in programs:
            result = subprocess.run(
                f"pkill {program} && {program} & disown",
                shell=True,
                capture_output=True,
                text=True,
            )

            if result.returncode != 0:
                print(result.stderr)
