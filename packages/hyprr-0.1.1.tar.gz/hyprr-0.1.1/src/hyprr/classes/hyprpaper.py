from .main_hyprr import Hyprr
import random

class Hyprpaper(Hyprr):
    def __init__(self):
        super().__init__()
        self.wallpapers_dir = self.home / "Pictures/Wallpapers"

    def list_wallpapers(self):
        for wallpaper in self.wallpapers_dir.iterdir():
            yield wallpaper

    def change_wallpaper_manually(self):
        pass

    def change_wallpaper_randomly(self):
        wallpapers = [wallpaper for wallpaper in self.list_wallpapers()]
        wallpaper = random.choice(wallpapers)

        hyprpaper_conf = self.config_dir / "hypr/hyprpaper.conf"

        with open(hyprpaper_conf, "r") as f:
            file = f.read()
            file_lines = file.splitlines()

        while wallpaper.name in file:
            wallpaper = random.choice(wallpapers)

        new_line = f"    path = {wallpaper}"
        for index, line in enumerate(file_lines):
            if "path" in line:
                file_lines[index] = new_line

        with open(hyprpaper_conf, "w") as f:
            f.write("\n".join(file_lines) + "\n")
