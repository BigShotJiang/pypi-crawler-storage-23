"""emend - Python refactoring CLI tool."""

try:
    from emend._version import __version__
except ImportError:
    __version__ = "0.0.0+unknown"
