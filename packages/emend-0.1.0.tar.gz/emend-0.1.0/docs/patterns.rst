Pattern Syntax
==============

emend's ``search`` and ``replace`` commands use a pattern language based on Python syntax extended with **metavariables**.

Metavariables
-------------

A metavariable is a placeholder that matches any single expression or statement. They are written as ``$NAME`` where ``NAME`` is an uppercase identifier.

.. code-block:: bash

   # $X matches any single expression
   emend search 'print($X)' src/

   # Multiple metavariables
   emend search 'assertEqual($A, $B)' tests/

Metavariable rules
~~~~~~~~~~~~~~~~~~~

- ``$X`` -- matches any single expression node
- ``$_`` -- wildcard that matches any expression and is not captured
- ``$...ARGS`` -- matches zero or more arguments in a call (variadic)

Type constraints
----------------

Constrain what a metavariable can match by adding a type suffix:

.. code-block:: bash

   # Match only when argument is a string literal
   emend search 'print($X:str)' src/

   # Match only when argument is an integer literal
   emend search 'range($X:int)' src/

Negated type constraints
~~~~~~~~~~~~~~~~~~~~~~~~

Prefix the type with ``!`` to match anything *except* that type:

.. code-block:: bash

   # Match range() calls with non-integer arguments
   emend search 'range($X:!int)' src/

   # Match addition where left side is NOT a function call
   emend search '$A:!call + $B' src/

Basic patterns
--------------

Function calls
~~~~~~~~~~~~~~

.. code-block:: bash

   # Match any call to print() with one argument
   emend search 'print($X)' src/

   # Match any call to print() with two arguments
   emend search 'print($A, $B)' src/

   # Match any call to open() regardless of arguments
   emend search 'open($...)' src/

Assignments
~~~~~~~~~~~

.. code-block:: bash

   # Match any simple assignment
   emend search '$NAME = $VALUE' src/

   # Match augmented assignment
   emend search '$NAME += $VALUE' src/

Attribute access
~~~~~~~~~~~~~~~~

.. code-block:: bash

   emend search '$OBJ.method($X)' src/
   emend search 'self.$ATTR' src/

Return statements
~~~~~~~~~~~~~~~~~

.. code-block:: bash

   emend search 'return $X' src/
   emend search 'return None' src/

Raise statements
~~~~~~~~~~~~~~~~

.. code-block:: bash

   emend search 'raise $EXC($MSG)' src/
   emend search 'raise ValueError($X)' src/

Comparisons
~~~~~~~~~~~

.. code-block:: bash

   emend search '$A == $B' src/
   emend search '$X is None' src/
   emend search '$X is not None' src/

Compound statement patterns
---------------------------

Match compound statements by their header. The body is unconstrained unless explicitly specified.

If statements
~~~~~~~~~~~~~

.. code-block:: bash

   # Match any if statement with a specific condition pattern
   emend search 'if $COND:' src/

   # Match if-checks for None
   emend search 'if $X is None:' src/

For loops
~~~~~~~~~

.. code-block:: bash

   # Match any for loop
   emend search 'for $VAR in $ITER:' src/

   # Match enumerate loops
   emend search 'for $I, $V in enumerate($X):' src/

While loops
~~~~~~~~~~~

.. code-block:: bash

   emend search 'while $COND:' src/
   emend search 'while True:' src/

With statements
~~~~~~~~~~~~~~~

.. code-block:: bash

   # With context and alias
   emend search 'with $CTX as $VAR:' src/

   # With just context (no alias)
   emend search 'with $CTX:' src/

Try/except statements
~~~~~~~~~~~~~~~~~~~~~

.. code-block:: bash

   # Match any try block
   emend search 'try:' src/

   # Match except clauses
   emend search 'except $EXC:' src/
   emend search 'except $EXC as $VAR:' src/

Async compound statements
~~~~~~~~~~~~~~~~~~~~~~~~~

.. code-block:: bash

   # Match async for loops
   emend search 'async for $VAR in $ITER:' src/

   # Match async with statements
   emend search 'async with $CTX as $VAR:' src/
   emend search 'async with $CTX:' src/

Decorator patterns
------------------

Match decorated function definitions using multi-line patterns:

.. code-block:: bash

   # Find functions with any decorator
   emend search '@$DEC\ndef $FUNC($...ARGS):' src/

   # Find functions with a specific decorator
   emend search '@property\ndef $FUNC($...ARGS):' src/

   # Multiple decorators
   emend search '@$DEC1\n@$DEC2\ndef $FUNC($...ARGS):' src/

   # Async decorated functions
   emend search '@$DEC\nasync def $FUNC($...ARGS):' src/

Lambda patterns
---------------

Match lambda expressions:

.. code-block:: bash

   # Match single-argument lambdas
   emend search 'lambda $X: $EXPR' src/

   # Match multi-argument lambdas
   emend search 'lambda $X, $Y: $EXPR' src/

   # Match lambdas with star args
   emend search 'lambda *$ARGS: $EXPR' src/

   # Match lambdas that return a specific pattern
   emend search 'lambda $X: $X + 1' src/

Star expression patterns
------------------------

Match star and double-star unpacking expressions:

.. code-block:: bash

   # Match star unpacking
   emend search '*$X' src/

   # Match double-star dict unpacking
   emend search '**$X' src/

   # Match function calls with star/double-star args
   emend search 'func(*$ARGS, **$KWARGS)' src/

Dict patterns
-------------

Match dictionary literals with specific keys:

.. code-block:: bash

   # Exact dict match (all keys must be present, no extras)
   emend search "{'name': \$NAME, 'age': \$AGE}" src/

   # Partial dict match (extra keys allowed)
   emend search "{'type': 'user', ...}" src/

Chained comparison patterns
---------------------------

Match chained comparisons:

.. code-block:: bash

   # Two-operator chain
   emend search '$A < $B < $C' src/

   # Mixed operators
   emend search '$A <= $B < $C' src/

Walrus operator patterns
------------------------

Match walrus operator (``:=``) in various contexts:

.. code-block:: bash

   # Walrus in if conditions
   emend search 'if ($VAR := $EXPR):' src/

   # Walrus in comprehension filters
   emend search '[$X for $VAR in $ITER if ($TARGET := $EXPR)]' src/

Replacements
-----------

In ``replace``, the replacement string can reference captured metavariables:

.. code-block:: bash

   # Replace print with logger.info
   emend replace 'print($X)' 'logger.info($X)' src/ --apply

   # Swap arguments
   emend replace 'assertEqual($A, $B)' 'assertEqual($B, $A)' tests/ --apply

   # Convert assert style
   emend replace 'assertEqual($A, $B)' 'assert $A == $B' tests/ --apply

   # Add a wrapper
   emend replace 'open($PATH)' 'open($PATH, encoding="utf-8")' src/ --apply

Scope constraints
-----------------

``--in SCOPE``
~~~~~~~~~~~~~~

Restrict matches to within a named symbol:

.. code-block:: bash

   # Only match inside the process_request function
   emend search 'print($X)' app.py --in process_request

   # Only match inside MyClass.method
   emend search 'self.$ATTR' app.py --in MyClass.method

``--where PATTERN`` (alias for ``--inside``)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Scope filtering using a pattern. Alias for ``--inside`` with pattern support:

.. code-block:: bash

   # Only match inside async functions named fetch_*
   emend search 'await $X' src/ --where 'async def fetch_*'

``--scope-local``
~~~~~~~~~~~~~~~~~

Only match names that are locally defined (excludes imports):

.. code-block:: bash

   # Find local variables named 'config', not imported ones
   emend search 'config' src/ --scope-local

``--inside STRUCTURE``
~~~~~~~~~~~~~~~~~~~~~~

Only match inside a particular kind of block. Accepts both keywords and patterns:

+-------+-----------------------+
| Str.  | Matches               |
+=======+=======================+
| ``def``  | Any function def. |
+-------+-----------------------+
| ``class`` | Any class def.    |
+-------+-----------------------+
| ``for`` | Any for loop      |
+-------+-----------------------+
| ``while`` | Any while loop    |
+-------+-----------------------+
| ``if`` | Any if/elif/else block |
+-------+-----------------------+
| ``try`` | Any try/except block |
+-------+-----------------------+
| ``with`` | Any with statement |
+-------+-----------------------+

.. code-block:: bash

   # Only inside functions (keyword)
   emend search 'print($X)' src/ --inside def

   # Only inside try blocks (keyword)
   emend search 'raise $E' src/ --inside try

   # Only inside functions matching a name pattern
   emend search 'print($X)' src/ --inside 'def test_*'

   # Only inside async functions
   emend search 'await $X' src/ --inside 'async def fetch_*'

``--not-inside STRUCTURE``
~~~~~~~~~~~~~~~~~~~~~~~~~~~

Only match outside a particular kind of block. Also accepts patterns:

.. code-block:: bash

   # Not inside class bodies (keyword)
   emend replace '$X = $Y' '$X: int = $Y' src/ --not-inside class --apply

   # Not inside try blocks (pattern)
   emend search 'open($PATH)' src/ --not-inside 'try:'

   # Not inside test functions (name pattern)
   emend search 'print($X)' src/ --not-inside 'def test_*'

``--imported-from MODULE``
~~~~~~~~~~~~~~~~~~~~~~~~~~~

Only match when the root name in the pattern is imported from a specific module:

.. code-block:: bash

   # Match json.loads() only when json is actually imported from the json module
   emend search 'json.loads($X)' src/ --imported-from json

   # Match datetime usage only when from the datetime module
   emend search 'datetime.now()' src/ --imported-from datetime

Multi-file search
-----------------

The ``PATH`` argument accepts:

- A single file: ``src/api.py``
- A glob: ``src/**/*.py``
- A directory (searches all ``.py`` files recursively): ``src/``

.. code-block:: bash

   # Search all test files
   emend search 'assertEqual($A, $B)' tests/

   # Search with glob
   emend search 'print($X)' 'src/**/*.py'

JSON output
-----------

Use ``--json`` to get structured output including captured metavariables:

.. code-block:: bash

   emend search 'raise $EXC($MSG)' src/ --json

Output:

.. code-block:: json

   {
     "count": 3,
     "matches": [
       {
         "file": "src/api.py",
         "line": 42,
         "code": "raise ValueError(\"bad input\")",
         "captures": {
           "EXC": "ValueError",
           "MSG": "\"bad input\""
         }
       }
     ]
   }

Limitations
-----------

- Patterns match at the expression or statement level; they cannot span multiple statements
- ``$X:stmt`` type constraint is not yet fully implemented (see TODOS.md for details)
