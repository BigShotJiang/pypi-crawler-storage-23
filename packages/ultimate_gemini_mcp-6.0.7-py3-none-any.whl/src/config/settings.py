"""Configuration settings for the Ultimate Gemini MCP server."""

import os
from pathlib import Path
from typing import Any

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

from .constants import (
    DEFAULT_ENHANCEMENT_MODEL,
    DEFAULT_IMAGE_SIZE,
    DEFAULT_MODEL,
    DEFAULT_OUTPUT_DIR,
    DEFAULT_TIMEOUT,
    MAX_BATCH_SIZE,
)

_ENV_CONFIG = SettingsConfigDict(
    env_file=".env",
    env_file_encoding="utf-8",
    case_sensitive=False,
    extra="ignore",
)


class ServerConfig(BaseSettings):
    """Server configuration settings."""

    model_config = _ENV_CONFIG

    log_level: str = Field(default="INFO", description="Logging level")
    output_dir: str = Field(
        default=DEFAULT_OUTPUT_DIR, description="Directory for generated images"
    )


class APIConfig(BaseSettings):
    """API configuration for the Gemini 3 Pro Image server."""

    model_config = _ENV_CONFIG

    gemini_api_key: str = Field(
        default="",
        alias="GEMINI_API_KEY",
        description="Gemini API key (also accepts GOOGLE_API_KEY)",
    )
    default_model: str = Field(
        default=DEFAULT_MODEL, description="Default Gemini 3 Pro Image model"
    )
    enhancement_model: str = Field(
        default=DEFAULT_ENHANCEMENT_MODEL, description="Model for prompt enhancement"
    )
    enable_prompt_enhancement: bool = Field(
        default=False, description="Enable automatic prompt enhancement"
    )
    enable_batch_processing: bool = Field(default=True, description="Enable batch processing")
    request_timeout: int = Field(default=DEFAULT_TIMEOUT, description="API request timeout")
    max_batch_size: int = Field(
        default=MAX_BATCH_SIZE, description="Maximum batch size for parallel requests"
    )
    max_retries: int = Field(default=3, description="Maximum number of retries for failed requests")
    default_aspect_ratio: str = Field(default="1:1", description="Default aspect ratio")
    default_image_size: str = Field(
        default=DEFAULT_IMAGE_SIZE, description="Default image size (1K, 2K, 4K)"
    )
    default_output_format: str = Field(default="png", description="Default output format")
    enable_google_search: bool = Field(default=False, description="Enable Google Search grounding")
    response_modalities: list[str] = Field(
        default=["TEXT", "IMAGE"], description="Response modalities"
    )

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        if not self.gemini_api_key:
            self.gemini_api_key = os.getenv("GOOGLE_API_KEY", "")
        if not self.gemini_api_key:
            raise ValueError("GEMINI_API_KEY or GOOGLE_API_KEY environment variable is required")


class Settings:
    """Combined server and API configuration."""

    def __init__(self) -> None:
        self.server = ServerConfig()
        self.api = APIConfig()
        Path(self.server.output_dir).mkdir(parents=True, exist_ok=True)

    @property
    def output_dir(self) -> Path:
        """Output directory as a Path object."""
        return Path(self.server.output_dir)


_settings: Settings | None = None


def get_settings() -> Settings:
    """Return the global Settings instance, creating it on first call."""
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings
