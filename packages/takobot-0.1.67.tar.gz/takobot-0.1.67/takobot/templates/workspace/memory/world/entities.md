# World Entities

## Sources

- (new sources are appended automatically from world-watch items)
