# people/ — Person Notes

This directory stores markdown notes about people encountered by Tako.

Guidelines:

- One file per person, e.g. `alice.md`.
- Date-stamp updates when provenance matters.
- No secrets.

