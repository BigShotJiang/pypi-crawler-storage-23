import json


class ReportBuilder:
    def __init__(self):
        self._project_path = None
        self._files = []
        self._errors = []

    def start_operation(self, project_path):
        self._project_path = project_path

    def log_file_creation(self, path):
        self._files.append(path)

    def log_error(self, msg):
        self._errors.append(msg)

    def finalize(self):
        status = "error" if self._errors else "success"
        return {
            "status": status,
            "project_path": self._project_path,
            "files": self._files,
            "errors": self._errors,
        }

    def dump(self):
        print(json.dumps(self.finalize()))
