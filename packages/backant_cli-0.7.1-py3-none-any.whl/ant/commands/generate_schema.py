from typing import Dict, Literal, Optional
from pydantic import BaseModel, field_validator, model_validator


HttpMethod = Literal["GET", "POST", "PUT", "DELETE"]


class SubrouteSpec(BaseModel):
    type: HttpMethod = "GET"
    mock: Optional[object] = None

    @field_validator("type", mode="before")
    @classmethod
    def normalize_method(cls, v):
        return v.upper() if isinstance(v, str) else v


class RouteSpec(BaseModel):
    type: HttpMethod = "GET"
    mock: Optional[object] = None
    subroutes: Optional[Dict[str, SubrouteSpec]] = None

    @field_validator("type", mode="before")
    @classmethod
    def normalize_method(cls, v):
        return v.upper() if isinstance(v, str) else v

    @field_validator("subroutes", mode="before")
    @classmethod
    def validate_subroute_names(cls, v):
        if v is None:
            return v
        for name in v:
            if not name.isidentifier():
                raise ValueError(f"Invalid subroute name: '{name}' (must be a valid Python identifier)")
        return v


class ApiSpec(BaseModel):
    routes: Dict[str, RouteSpec]
    project: Optional[Dict] = None

    @field_validator("routes", mode="before")
    @classmethod
    def validate_route_names(cls, v):
        if not v:
            raise ValueError("'routes' cannot be empty")
        for name in v:
            if not name.isidentifier():
                raise ValueError(f"Invalid route name: '{name}' (must be a valid Python identifier)")
        return v


def validate_api_spec(json_data: dict) -> list:
    """
    Validate API spec using Pydantic. Returns a list of error strings.
    Error messages are specific enough for an AI to self-correct.
    """
    errors = []

    if not isinstance(json_data, dict):
        return ["Error: Spec must be a JSON object."]

    if "routes" not in json_data:
        return ["Error: Key 'routes' missing at top level."]

    routes = json_data.get("routes")
    if not isinstance(routes, dict):
        return ["Error: 'routes' must be an object."]

    if not routes:
        return ["Error: 'routes' cannot be empty."]

    for route_name, route_config in routes.items():
        if not route_name.isidentifier():
            errors.append(f"Error: Invalid route name '{route_name}' (must be a valid Python identifier).")
            continue

        if not isinstance(route_config, dict):
            errors.append(f"Error: Route '{route_name}' configuration must be an object.")
            continue

        method = route_config.get("type", "GET")
        if method.upper() not in ("GET", "POST", "PUT", "DELETE"):
            errors.append(f"Error: Invalid HTTP method '{method}' in route '{route_name}' (must be GET, POST, PUT, or DELETE).")

        subroutes = route_config.get("subroutes")
        if subroutes is not None:
            if not isinstance(subroutes, dict):
                errors.append(f"Error: 'subroutes' in route '{route_name}' must be an object.")
                continue
            for sub_name, sub_config in subroutes.items():
                if not sub_name.isidentifier():
                    errors.append(f"Error: Invalid subroute name '{sub_name}' in route '{route_name}' (must be a valid Python identifier).")
                    continue
                if not isinstance(sub_config, dict):
                    errors.append(f"Error: Subroute '{route_name}/{sub_name}' configuration must be an object.")
                    continue
                sub_method = sub_config.get("type", "GET")
                if sub_method.upper() not in ("GET", "POST", "PUT", "DELETE"):
                    errors.append(f"Error: Invalid HTTP method '{sub_method}' in subroute '{route_name}/{sub_name}' (must be GET, POST, PUT, or DELETE).")

    if errors:
        return errors

    try:
        ApiSpec(**json_data)
    except Exception as e:
        errors.append(f"Error: {e}")

    return errors
