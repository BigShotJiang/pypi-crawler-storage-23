import click
import shutil
import os
import json
import importlib.resources as pkg_resources
from ant.commands import (
    templates,
)  # Ensure 'templates' is a Python package (has __init__.py)
from ant.utils.report_builder import ReportBuilder


class APIGenerationError(Exception):
    """Custom exception for API generation errors."""
    pass


def _get_report_mode():
    ctx = click.get_current_context(silent=True)
    if ctx is not None:
        obj = ctx.find_root().obj
        if obj and obj.get("report"):
            return True
    return False


def _echo(msg, report_builder=None, err=False):
    if report_builder is None:
        report_builder = _get_report_mode()
        if report_builder:
            return
    click.echo(msg)


def _validate_and_parse_mock_data(mock_input, rb=None):
    """Validate and parse mock data from JSON string or file path."""
    try:
        if os.path.isfile(mock_input):
            with open(mock_input, 'r') as f:
                mock_data = json.load(f)
            if rb is None and not _get_report_mode():
                click.echo(f"Successfully loaded mock data from file: {mock_input}")
        else:
            mock_data = json.loads(mock_input)
            if rb is None and not _get_report_mode():
                click.echo("Successfully parsed mock data from JSON string")
        return mock_data
    except json.JSONDecodeError as e:
        msg = f"Error: Invalid JSON format - {e}"
        if rb:
            rb.log_error(msg)
        elif not _get_report_mode():
            click.echo(f"Error: {msg}")
        return None
    except FileNotFoundError:
        msg = f"Error: File not found - {mock_input}"
        if rb:
            rb.log_error(msg)
        elif not _get_report_mode():
            click.echo(msg)
        return None
    except Exception as e:
        msg = f"Error: {e}"
        if rb:
            rb.log_error(msg)
        elif not _get_report_mode():
            click.echo(msg)
        return None


def _parse_api_json(json_data):
    """Parse and normalize JSON into generation commands."""
    commands = []
    project_info = json_data.get('project', {})
    for route_name, route_config in json_data['routes'].items():
        commands.append({
            'type': 'route',
            'name': route_name.lower(),
            'method': route_config.get('type', 'GET'),
            'mock': route_config.get('mock')
        })
        subroutes = route_config.get('subroutes', {})
        for subroute_name, subroute_config in subroutes.items():
            commands.append({
                'type': 'subroute',
                'route': route_name.lower(),
                'name': subroute_name.lower(),
                'method': subroute_config.get('type', 'GET'),
                'mock': subroute_config.get('mock')
            })
    return commands, project_info


def _generate_route_from_command(route_cmd, base_dir, verbose=False, rb=None):
    """Generate a route from a command dictionary."""
    route_name = route_cmd['name']
    mock_data = route_cmd.get('mock')

    if verbose and not _get_report_mode():
        click.echo(f"Generating route: {route_name}")

    route_cap = route_name.capitalize()

    route_file = os.path.join(base_dir, f"api/routes/{route_name}_route.py")
    service_file = os.path.join(base_dir, f"api/services/{route_name}_service.py")
    repository_file = os.path.join(base_dir, f"api/repositories/{route_name}_repository.py")
    model_file = os.path.join(base_dir, f"api/models/{route_cap}_model.py")
    alchemy_file = os.path.join(base_dir, "api/startup/Alchemy.py")
    app_file = os.path.join(base_dir, "api/app.py")

    os.makedirs(os.path.dirname(route_file), exist_ok=True)
    os.makedirs(os.path.dirname(service_file), exist_ok=True)
    os.makedirs(os.path.dirname(repository_file), exist_ok=True)
    os.makedirs(os.path.dirname(model_file), exist_ok=True)

    with open(route_file, "w") as f:
        f.write(f"""from flask import Blueprint, jsonify
from services.{route_name}_service import my{route_cap}Service

{route_name}_bp = Blueprint("{route_name}", __name__, url_prefix="/{route_name}")

@{route_name}_bp.get("")
def {route_name}_route():
    response = my{route_cap}Service.get_{route_name}()
    return jsonify(response)
""")
    if rb:
        rb.log_file_creation(route_file)

    with open(service_file, "w") as f:
        if mock_data:
            mock_data_str = repr(mock_data)
            service_content = f"""from repositories.{route_name}_repository import {route_cap}Repository, my{route_cap}Repository
from helper.execution_tracking.APIException import APIException
from helper.execution_tracking.Logger import Logger, myLogger

class {route_cap}Service:
    logger: Logger = myLogger

    def __init__(self, {route_name}_repository: {route_cap}Repository) -> None:
        self.{route_name}_repository = {route_name}_repository

    def get_{route_name}(self):
        # Mock data provided during generation
        mock_data = {mock_data_str}
        return mock_data

my{route_cap}Service = {route_cap}Service(my{route_cap}Repository)
"""
        else:
            service_content = f"""from repositories.{route_name}_repository import {route_cap}Repository, my{route_cap}Repository
from helper.execution_tracking.APIException import APIException
from helper.execution_tracking.Logger import Logger, myLogger

class {route_cap}Service:
    logger: Logger = myLogger

    def __init__(self, {route_name}_repository: {route_cap}Repository) -> None:
        self.{route_name}_repository = {route_name}_repository

    def get_{route_name}(self):
        # TODO: Replace this placeholder with your actual implementation
        return "Your {route_name} route is working!"

my{route_cap}Service = {route_cap}Service(my{route_cap}Repository)
"""
        f.write(service_content)
    if rb:
        rb.log_file_creation(service_file)

    with open(repository_file, "w") as f:
        f.write(f"""from sqlalchemy.exc import IntegrityError
from helper.DBSession import myDB
from helper.execution_tracking.Logger import myLogger
from repositories.Repository import Repository
from models.Default_model import Default
from sqlalchemy import select
from models.{route_cap}_model import {route_cap}

class {route_cap}Repository(Repository):

    def get_by_id(self, id: int) -> {route_cap}:
        stmt = select({route_cap}).where({route_cap}.id == id)
        return myDB.execute(stmt).scalars().first()

    def add_{route_name}(
        self,
        model: str,
    ):
        {route_name} = {route_cap}(
            model=model,
        )
        try:
            self.add({route_name})
        except IntegrityError as e:
            self.logger.warning(
                f"Could not create default <{{model}}> because <{{e.detail}}>!"
            )
            raise e
        return {route_name}

    def delete_{route_name}(self, id: str):
        {route_name} = self.get_by_id(int(id))
        try:
            self.delete({route_name})
        except IntegrityError as e:
            self.logger.warning(
                f"Could not delete {route_name} <{{{route_name}.id}}> because <{{e.detail}}>!"
            )
            raise e
        return {route_name}

my{route_cap}Repository: {route_cap}Repository = {route_cap}Repository(myDB, myLogger)
""")
    if rb:
        rb.log_file_creation(repository_file)

    with open(model_file, "w") as f:
        f.write(f"""from dataclasses import dataclass
from sqlalchemy import Column, Integer, String
from startup.Alchemy import Base

@dataclass
class {route_cap}(Base):
    __tablename__ = "{route_name}"

    id: int = Column(Integer, primary_key=True)
    model: String = Column(String)
""")
    if rb:
        rb.log_file_creation(model_file)

    if os.path.exists(alchemy_file):
        with open(alchemy_file, "r") as f:
            lines = f.readlines()

        indentation = None
        for line in lines:
            if "import models." in line:
                indentation = line[:len(line) - len(line.lstrip())]
                break

        if indentation is None:
            for line in lines:
                if "def init_db():" in line:
                    indentation = line[:len(line) - len(line.lstrip())] + "    "
                    break

        import_line = f"{indentation}import models.{route_cap}_model\n"

        insert_index = None
        for i, line in enumerate(lines):
            if "import models." in line:
                insert_index = i

        if insert_index is not None:
            lines.insert(insert_index + 1, import_line)
        else:
            for i, line in enumerate(lines):
                if "def init_db():" in line:
                    lines.insert(i + 1, import_line)
                    break

        with open(alchemy_file, "w") as f:
            f.writelines(lines)

    if os.path.exists(app_file):
        with open(app_file, "r") as f:
            lines = f.readlines()

        for i, line in enumerate(lines):
            if "from dotenv import load_dotenv" in line:
                lines.insert(i + 1, f"from routes.{route_name}_route import {route_name}_bp\n")
                break

        for i, line in enumerate(lines):
            if "load_dotenv()" in line:
                indentation = line[:len(line) - len(line.lstrip())]
                lines.insert(i + 1, f"{indentation}app.register_blueprint({route_name}_bp)\n")
                break

        with open(app_file, "w") as f:
            f.writelines(lines)


def _generate_subroute_from_command(subroute_cmd, base_dir, verbose=False, rb=None):
    """Generate a subroute from a command dictionary."""
    route_name = subroute_cmd['route']
    subroute_name = subroute_cmd['name']
    method_type = subroute_cmd['method']
    mock_data = subroute_cmd.get('mock')

    if verbose and not _get_report_mode():
        click.echo(f"Generating subroute: {route_name}/{subroute_name} ({method_type})")

    route_cap = route_name.capitalize()

    route_file = os.path.join(base_dir, f"api/routes/{route_name}_route.py")
    service_file = os.path.join(base_dir, f"api/services/{route_name}_service.py")
    repository_file = os.path.join(base_dir, f"api/repositories/{route_name}_repository.py")

    _update_route_file_with_subroute(route_file, route_name, route_cap, subroute_name, subroute_name.capitalize(), method_type)
    _update_service_file_with_subroute(service_file, route_name, route_cap, subroute_name, subroute_name.capitalize(), method_type, mock_data)
    _update_repository_file_with_subroute(repository_file, route_name, route_cap, subroute_name, subroute_name.capitalize(), method_type)


def _execute_generation_commands(project_name, commands, verbose=False, rb=None):
    """Execute generation commands in proper order."""
    base_dir = os.path.join(os.getcwd(), project_name)

    if verbose and not _get_report_mode():
        click.echo(f"Starting API generation for project: {project_name}")
        click.echo(f"Total commands to execute: {len(commands)}")

    routes = [cmd for cmd in commands if cmd['type'] == 'route']
    subroutes = [cmd for cmd in commands if cmd['type'] == 'subroute']

    if verbose and not _get_report_mode():
        click.echo(f"Routes to generate: {len(routes)}")
        click.echo(f"Subroutes to generate: {len(subroutes)}")

    for route_cmd in routes:
        try:
            _generate_route_from_command(route_cmd, base_dir, verbose, rb=rb)
        except Exception as e:
            raise APIGenerationError(f"Failed to generate route '{route_cmd['name']}': {e}")

    for subroute_cmd in subroutes:
        try:
            _generate_subroute_from_command(subroute_cmd, base_dir, verbose, rb=rb)
        except Exception as e:
            raise APIGenerationError(f"Failed to generate subroute '{subroute_cmd['route']}/{subroute_cmd['name']}': {e}")

    if verbose and not _get_report_mode():
        click.echo("All commands executed successfully!")


@click.group()
def generate():
    """CLI command group for generating components."""
    pass


@click.command()
@click.argument("user_input")
@click.option("--mock", help="JSON string or path to JSON file for mock data. Examples: --mock '{\"users\":[{\"id\":1}]}' or --mock data.json")
@click.pass_context
def route(ctx, user_input, mock):
    """Generates API route, service, repository and model.

    When --mock is provided, the generated service will return the mock data
    instead of a placeholder message. This is useful for rapid prototyping
    and testing API endpoints with realistic data.

    Examples:

        ant generate route users

        ant generate route users --mock '{"users": [{"id": 1, "name": "John"}]}'

        ant generate route users --mock mock_data.json
    """
    report_mode = ctx.find_root().obj.get("report", False) if ctx.find_root().obj else False
    rb = ReportBuilder() if report_mode else None

    uic = user_input.capitalize()
    uil = user_input.lower()

    base_dir = os.getcwd()
    rb and rb.start_operation(base_dir)

    route_file = os.path.join(base_dir, f"api/routes/{uil}_route.py")
    service_file = os.path.join(base_dir, f"api/services/{uil}_service.py")
    repository_file = os.path.join(base_dir, f"api/repositories/{uil}_repository.py")
    model_file = os.path.join(base_dir, f"api/models/{uic}_model.py")
    alchemy_file = os.path.join(base_dir, "api/startup/Alchemy.py")
    app_file = os.path.join(base_dir, "api/app.py")

    mock_data = None
    if mock:
        mock_data = _validate_and_parse_mock_data(mock, rb=rb)
        if mock_data is None:
            if rb:
                rb.dump()
            return

    os.makedirs(os.path.dirname(route_file), exist_ok=True)
    os.makedirs(os.path.dirname(service_file), exist_ok=True)
    os.makedirs(os.path.dirname(repository_file), exist_ok=True)
    os.makedirs(os.path.dirname(model_file), exist_ok=True)

    with open(route_file, "w") as f:
        f.write(
            f"""from flask import Blueprint, jsonify
from services.{uil}_service import my{uic}Service

{uil}_bp = Blueprint("{uil}", __name__, url_prefix="/{uil}")

@{uil}_bp.get("")
def {uil}_route():
    response = my{uic}Service.get_{uil}()
    return jsonify(response)
"""
        )
    if rb:
        rb.log_file_creation(route_file)

    with open(service_file, "w") as f:
        if mock_data:
            mock_data_str = json.dumps(mock_data, indent=4)
            service_content = f"""from repositories.{uil}_repository import {uic}Repository, my{uic}Repository
from helper.execution_tracking.APIException import APIException
from helper.execution_tracking.Logger import Logger, myLogger

class {uic}Service:
    logger: Logger = myLogger

    def __init__(self, {uil}_repository: {uic}Repository) -> None:
        self.{uil}_repository = {uil}_repository

    def get_{uil}(self):
        # Mock data provided during generation
        mock_data = {mock_data_str}
        return mock_data

my{uic}Service = {uic}Service(my{uic}Repository)
"""
        else:
            service_content = f"""from repositories.{uil}_repository import {uic}Repository, my{uic}Repository
from helper.execution_tracking.APIException import APIException
from helper.execution_tracking.Logger import Logger, myLogger

class {uic}Service:
    logger: Logger = myLogger

    def __init__(self, {uil}_repository: {uic}Repository) -> None:
        self.{uil}_repository = {uil}_repository

    def get_{uil}(self):
        # TODO: Replace this placeholder with your actual implementation
        return "Your {uil} route is working!"

my{uic}Service = {uic}Service(my{uic}Repository)
"""
        f.write(service_content)
    if rb:
        rb.log_file_creation(service_file)

    with open(repository_file, "w") as f:
        f.write(
            f"""from sqlalchemy.exc import IntegrityError
from helper.DBSession import myDB
from helper.execution_tracking.Logger import myLogger
from repositories.Repository import Repository
from models.Default_model import Default
from sqlalchemy import select
from models.{uic}_model import {uic}

class {uic}Repository(Repository):

    def get_by_id(self, id: int) -> {uic}:
        stmt = select({uic}).where({uic}.id == id)
        return myDB.execute(stmt).scalars().first()

    def add_{uil}(
        self,
        model: str,
    ):
        {uil} = {uic}(
            model=model,
        )
        try:
            self.add({uil})
        except IntegrityError as e:
            self.logger.warning(
                f"Could not create default <{{model}}> because <{{e.detail}}>!"
            )
            raise e
        return {uil}

    def delete_{uil}(self, id: str):
        {uil} = self.get_by_id(int(id))
        try:
            self.delete({uil})
        except IntegrityError as e:
            self.logger.warning(
                f"Could not delete {uil} <{{{uil}.id}}> because <{{e.detail}}>!"
            )
            raise e
        return {uil}

my{uic}Repository: {uic}Repository = {uic}Repository(myDB, myLogger)
"""
        )
    if rb:
        rb.log_file_creation(repository_file)

    with open(model_file, "w") as f:
        f.write(
            f"""from dataclasses import dataclass
from sqlalchemy import Column, Integer, String
from startup.Alchemy import Base

@dataclass
class {uic}(Base):
    __tablename__ = "{uil}"

    id: int = Column(Integer, primary_key=True)
    model: String = Column(String)
"""
        )
    if rb:
        rb.log_file_creation(model_file)

    if os.path.exists(alchemy_file):
        with open(alchemy_file, "r") as f:
            lines = f.readlines()

        indentation = None
        for line in lines:
            if "import models." in line:
                indentation = line[
                    : len(line) - len(line.lstrip())
                ]
                break

        if indentation is None:
            for line in lines:
                if "def init_db():" in line:
                    indentation = (
                        line[: len(line) - len(line.lstrip())] + "    "
                    )
                    break

        import_line = f"{indentation}import models.{uic}_model\n"

        insert_index = None
        for i, line in enumerate(lines):
            if "import models." in line:
                insert_index = i

        if insert_index is not None:
            lines.insert(insert_index + 1, import_line)
        else:
            for i, line in enumerate(lines):
                if "def init_db():" in line:
                    lines.insert(i + 1, import_line)
                    break

        with open(alchemy_file, "w") as f:
            f.writelines(lines)

    if os.path.exists(app_file):
        with open(app_file, "r") as f:
            lines = f.readlines()

        for i, line in enumerate(lines):
            if "from dotenv import load_dotenv" in line:
                lines.insert(i + 1, f"from routes.{uil}_route import {uil}_bp\n")
                break

        for i, line in enumerate(lines):
            if "load_dotenv()" in line:
                indentation = line[
                    : len(line) - len(line.lstrip())
                ]
                lines.insert(i + 1, f"{indentation}app.register_blueprint({uil}_bp)\n")
                break

        with open(app_file, "w") as f:
            f.writelines(lines)

    if rb:
        rb.dump()
    elif mock_data:
        click.echo(
            f"Successfully generated route, service, repository, and model for '{uil}' with mock data!"
        )
    else:
        click.echo(
            f"Successfully generated route, service, repository, and model for '{uil}'!"
        )


@click.command()
@click.argument("route")
@click.argument("subroute")
@click.option("--type", "method_type", type=click.Choice(["GET", "POST"], case_sensitive=False), default="GET", help="HTTP method for the subroute (GET or POST)")
@click.option("--mock", help="JSON string or path to JSON file for mock data. Examples: --mock '{\"users\":[{\"id\":1}]}' or --mock data.json")
@click.pass_context
def subroute(ctx, route, subroute, method_type, mock):
    """Generates a subroute for an existing route.

    Adds a new endpoint to an existing route's blueprint, service, and repository.
    The subroute will be accessible at /{route}/{subroute}.

    Examples:

        ant generate subroute users profile --type GET

        ant generate subroute users create --type POST --mock '{"name": "John", "email": "john@example.com"}'

        ant generate subroute orders items --type GET --mock items_data.json
    """
    report_mode = ctx.find_root().obj.get("report", False) if ctx.find_root().obj else False
    rb = ReportBuilder() if report_mode else None

    mock_data = None
    if mock:
        mock_data = _validate_and_parse_mock_data(mock, rb=rb)
        if mock_data is None:
            if rb:
                rb.dump()
            return

    route_lower = route.lower()
    route_cap = route.capitalize()
    subroute_lower = subroute.lower()
    subroute_cap = subroute.capitalize()
    method_type = method_type.upper()

    base_dir = os.getcwd()
    rb and rb.start_operation(base_dir)

    route_file = os.path.join(base_dir, f"api/routes/{route_lower}_route.py")
    service_file = os.path.join(base_dir, f"api/services/{route_lower}_service.py")
    repository_file = os.path.join(base_dir, f"api/repositories/{route_lower}_repository.py")

    if not os.path.exists(route_file):
        msg = f"Error: Route '{route}' does not exist. Please generate the main route first using: ant generate route {route}"
        if rb:
            rb.log_error(msg)
            rb.dump()
        else:
            click.echo(msg)
        return

    if not os.path.exists(service_file):
        msg = f"Error: Service file for '{route}' does not exist."
        if rb:
            rb.log_error(msg)
            rb.dump()
        else:
            click.echo(msg)
        return

    if not os.path.exists(repository_file):
        msg = f"Error: Repository file for '{route}' does not exist."
        if rb:
            rb.log_error(msg)
            rb.dump()
        else:
            click.echo(msg)
        return

    _update_route_file_with_subroute(route_file, route_lower, route_cap, subroute_lower, subroute_cap, method_type)
    _update_service_file_with_subroute(service_file, route_lower, route_cap, subroute_lower, subroute_cap, method_type, mock_data)
    _update_repository_file_with_subroute(repository_file, route_lower, route_cap, subroute_lower, subroute_cap, method_type)

    if rb:
        rb.dump()
    elif mock_data:
        click.echo(f"Successfully generated {method_type} subroute '{subroute}' for route '{route}' with mock data!")
    else:
        click.echo(f"Successfully generated {method_type} subroute '{subroute}' for route '{route}'!")


def _update_route_file_with_subroute(route_file, route_lower, route_cap, subroute_lower, subroute_cap, method_type):
    """Update the route file to add a new subroute endpoint."""
    with open(route_file, 'r') as f:
        content = f.read()

    if f"def {route_lower}_{subroute_lower}_route" in content:
        if not _get_report_mode():
            click.echo(f"Warning: Subroute '{subroute_lower}' already exists in {route_file}")
        return

    if method_type == "GET":
        new_route = f"""
@{route_lower}_bp.get("/{subroute_lower}")
def {route_lower}_{subroute_lower}_route():
    response = my{route_cap}Service.get_{subroute_lower}()
    return jsonify(response)
"""
    else:
        new_route = f"""
@{route_lower}_bp.post("/{subroute_lower}")
def {route_lower}_{subroute_lower}_route():
    from flask import request
    data = request.get_json()
    response = my{route_cap}Service.create_{subroute_lower}(data)
    return jsonify(response)
"""

    with open(route_file, 'w') as f:
        f.write(content + new_route)


def _update_service_file_with_subroute(service_file, route_lower, route_cap, subroute_lower, subroute_cap, method_type, mock_data):
    """Update the service file to add a new subroute method."""
    with open(service_file, 'r') as f:
        content = f.read()

    method_name = f"get_{subroute_lower}" if method_type == "GET" else f"create_{subroute_lower}"
    if f"def {method_name}" in content:
        if not _get_report_mode():
            click.echo(f"Warning: Method '{method_name}' already exists in {service_file}")
        return

    if method_type == "GET":
        if mock_data:
            mock_data_str = repr(mock_data)
            new_method = f"""
    def get_{subroute_lower}(self):
        # Mock data provided during generation
        mock_data = {mock_data_str}
        return mock_data
"""
        else:
            new_method = f"""
    def get_{subroute_lower}(self):
        # TODO: Replace this placeholder with your actual implementation
        return f"Your {route_lower} {subroute_lower} route is working!"
"""
    else:
        if mock_data:
            mock_data_str = repr(mock_data)
            new_method = f"""
    def create_{subroute_lower}(self, data):
        # Mock data provided during generation
        mock_response = {mock_data_str}
        return mock_response
"""
        else:
            new_method = f"""
    def create_{subroute_lower}(self, data):
        # TODO: Replace this placeholder with your actual implementation
        return f"Successfully created {subroute_lower} for {route_lower} with data: {{data}}"
"""

    lines = content.split('\n')
    insert_index = -1

    for i, line in enumerate(lines):
        if f"my{route_cap}Service = {route_cap}Service(" in line:
            insert_index = i
            break

    if insert_index == -1:
        lines.append(new_method)
    else:
        lines.insert(insert_index, new_method)

    with open(service_file, 'w') as f:
        f.write('\n'.join(lines))


def _update_repository_file_with_subroute(repository_file, route_lower, route_cap, subroute_lower, subroute_cap, method_type):
    """Update the repository file to add a new subroute method."""
    with open(repository_file, 'r') as f:
        content = f.read()

    method_name = f"get_{subroute_lower}" if method_type == "GET" else f"add_{subroute_lower}"
    if f"def {method_name}" in content:
        if not _get_report_mode():
            click.echo(f"Warning: Method '{method_name}' already exists in {repository_file}")
        return

    if method_type == "GET":
        new_method = f"""
    def get_{subroute_lower}(self, id: int = None):
        if id:
            stmt = select({route_cap}).where({route_cap}.id == id)
            return myDB.execute(stmt).scalars().first()
        else:
            stmt = select({route_cap})
            return myDB.execute(stmt).scalars().all()
"""
    else:
        new_method = f"""
    def add_{subroute_lower}(self, data: dict):
        {route_lower} = {route_cap}(
            model=str(data),
        )
        try:
            self.add({route_lower})
        except IntegrityError as e:
            self.logger.warning(
                f"Could not create {subroute_lower} for {route_lower} because <{{e.detail}}>!"
            )
            raise e
        return {route_lower}
"""

    lines = content.split('\n')
    insert_index = -1

    for i, line in enumerate(lines):
        if f"my{route_cap}Repository: {route_cap}Repository = {route_cap}Repository(" in line:
            insert_index = i
            break

    if insert_index == -1:
        lines.append(new_method)
    else:
        lines.insert(insert_index, new_method)

    with open(repository_file, 'w') as f:
        f.write('\n'.join(lines))


@click.command()
@click.argument("project_name")
@click.option("--json", "json_input", help="JSON string or path to JSON file for full API generation. Examples: --json '{\"routes\":{\"users\":{\"type\":\"GET\"}}}' or --json api-spec.json")
@click.option("--verbose", "-v", is_flag=True, help="Show detailed generation progress")
@click.option("--dry-run", is_flag=True, help="Validate JSON without generating files")
@click.pass_context
def api(ctx, project_name, json_input, verbose, dry_run):
    """
    Generates a new backant backend project.

    With --json option, generates a complete API with routes and subroutes from JSON specification.

    Examples:

        ant generate api my-project

        ant generate api shop --json '{"routes": {"products": {"type": "GET", "subroutes": {"create": {"type": "POST"}}}}}'

        ant generate api ecommerce --json api-spec.json --verbose

        ant generate api test --json api.json --dry-run
    """
    report_mode = ctx.find_root().obj.get("report", False) if ctx.find_root().obj else False
    rb = ReportBuilder() if report_mode else None

    if json_input:
        if verbose and not report_mode:
            click.echo(f"Processing JSON input for project: {project_name}")

        try:
            json_data = _validate_and_parse_mock_data(json_input, rb=rb)
            if json_data is None:
                if rb:
                    rb.dump()
                return

            if verbose and not report_mode:
                click.echo("Validating JSON schema...")

            from ant.commands.generate_schema import validate_api_spec
            validation_errors = validate_api_spec(json_data)
            if validation_errors:
                if rb:
                    for err in validation_errors:
                        rb.log_error(err)
                    rb.dump()
                else:
                    click.echo("JSON validation failed:")
                    for error in validation_errors:
                        click.echo(f"   - {error}")
                return

            if verbose and not report_mode:
                click.echo("JSON validation passed")

            commands, project_info = _parse_api_json(json_data)

            if verbose and not report_mode:
                click.echo(f"Parsed {len(commands)} generation commands")
                if project_info:
                    project_desc = project_info.get('description', 'No description')
                    click.echo(f"Project description: {project_desc}")

            if dry_run:
                if not report_mode:
                    click.echo(f"DRY RUN: Would generate project '{project_name}' with:")
                    routes = [cmd for cmd in commands if cmd['type'] == 'route']
                    subroutes_list = [cmd for cmd in commands if cmd['type'] == 'subroute']
                    click.echo(f"   {len(routes)} main routes:")
                    for r in routes:
                        mock_info = " (with mock data)" if r.get('mock') else ""
                        click.echo(f"      - {r['name']} ({r['method']}){mock_info}")
                    click.echo(f"   {len(subroutes_list)} subroutes:")
                    for s in subroutes_list:
                        mock_info = " (with mock data)" if s.get('mock') else ""
                        click.echo(f"      - {s['route']}/{s['name']} ({s['method']}){mock_info}")
                    click.echo("Dry run completed - no files were created")
                return

            project_path = os.path.join(os.getcwd(), project_name)
            if os.path.exists(project_path):
                msg = f"Error: Directory '{project_name}' already exists."
                if rb:
                    rb.log_error(msg)
                    rb.dump()
                else:
                    click.echo(msg)
                return

            template_path = pkg_resources.files(templates) / "base"
            if not os.path.exists(template_path):
                msg = f"Error: Template directory '{template_path}' does not exist."
                if rb:
                    rb.log_error(msg)
                    rb.dump()
                else:
                    click.echo(msg)
                return

            if verbose and not report_mode:
                click.echo(f"Creating base project structure...")

            shutil.copytree(template_path, project_path)

            if rb:
                rb.start_operation(project_path)

            if verbose and not report_mode:
                click.echo(f"Base project created at: {project_path}")

            _execute_generation_commands(project_name, commands, verbose, rb=rb)

            if rb:
                rb.dump()
            else:
                click.echo(f"Successfully generated API project '{project_name}' from JSON!")
                if len(commands) > 0:
                    routes_count = len([cmd for cmd in commands if cmd['type'] == 'route'])
                    subroutes_count = len([cmd for cmd in commands if cmd['type'] == 'subroute'])
                    click.echo(f"   Generated: {routes_count} routes, {subroutes_count} subroutes")

        except APIGenerationError as e:
            msg = f"API Generation Error: {e}"
            if rb:
                rb.log_error(msg)
                rb.dump()
            else:
                click.echo(msg)
            return
        except Exception as e:
            msg = f"Unexpected error: {e}"
            if rb:
                rb.log_error(msg)
                rb.dump()
            else:
                click.echo(msg)
            return

    else:
        if verbose and not report_mode:
            click.echo(f"Creating standard project: {project_name}")

        template_path = pkg_resources.files(templates) / "base"
        project_path = os.path.join(os.getcwd(), project_name)

        if not os.path.exists(template_path):
            msg = f"Error: Template directory '{template_path}' does not exist."
            if rb:
                rb.log_error(msg)
                rb.dump()
            else:
                click.echo(msg)
            return

        if os.path.exists(project_path):
            msg = f"Error: Directory '{project_name}' already exists."
            if rb:
                rb.log_error(msg)
                rb.dump()
            else:
                click.echo(msg)
            return

        shutil.copytree(template_path, project_path)

        if rb:
            rb.start_operation(project_path)
            rb.dump()
        else:
            click.echo(f"Successfully created new project '{project_name}'")


generate.add_command(route)
generate.add_command(subroute)
generate.add_command(api)
