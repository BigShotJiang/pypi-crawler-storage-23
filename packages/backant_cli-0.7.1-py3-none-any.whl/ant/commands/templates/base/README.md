# Project Name

A Flask-based REST API generated with [backant-cli](https://github.com/backant/backant-cli).

## Requirements

- Docker
- Docker Compose

## Setup

1. **Copy the environment file:**
    ```bash
    cp api/.env.testing .env
    ```

2. **Update `.env` with your values:**
    ```env
    POSTGRES_USER=postgres
    POSTGRES_PASSWORD=test
    POSTGRES_DB=postgres
    DB_URL=postgres
    CLEAR_DB=True
    FLASK_APP=app.py
    FLASK_ENV=development
    TESTING=False
    ```
    > `DB_URL` must match the postgres service name in `docker-compose.yml` (default: `postgres`)

## Running the project

```bash
docker compose up --build
```

The API will be available at `http://localhost:5000`.

## Adding routes

Use the `ant` CLI from the project root:

```bash
ant generate route <route_name>
```

```bash
ant generate subroute <route_name> <subroute_name> --type GET
```

## Project Structure

```
project/
├── api/
│   ├── app.py               # Flask app factory
│   ├── routes/              # Blueprints
│   ├── services/            # Business logic
│   ├── repositories/        # Data access
│   ├── models/              # SQLAlchemy models
│   ├── schemas/             # Marshmallow schemas
│   ├── helper/              # Utilities and logging
│   ├── startup/             # DB and environment init
│   └── .env.testing         # Environment template
├── docker-compose.yml
├── Dockerfile
└── requirements.txt
```

## Running tests

```bash
cp api/.env.testing .env
pytest api/
```
