from marshmallow import fields, Schema


class PostDefaultSchema(Schema):
    model = fields.String(required=True)
