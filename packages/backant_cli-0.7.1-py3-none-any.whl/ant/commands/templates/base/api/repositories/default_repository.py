from sqlalchemy.exc import IntegrityError
from helper.DBSession import myDB
from helper.execution_tracking.Logger import myLogger
from repositories.Repository import Repository
from models.Default_model import Default


class DefaultRepository(Repository):

    def get_by_id(self, id: int) -> Default:
        stmt = select(Default).where(Default.id == id)
        return myDB.execute(stmt).scalars().first()

    def add_default(
        self,
        model: str,
    ):
        default = Default(
            model=model,
        )
        try:
            self.add(default)
        except IntegrityError as e:
            self.logger.warning(
                f"Could not create default <{model}> because <{e.detail}>!",
            )
            raise e
        return default

    def delete_default(self, id: str):
        default = self.get_by_id(int(id))
        try:
            self.delete(default)
        except IntegrityError as e:
            self.logger.warning(
                f"Could not delete default <{default.id}> because <{e.detail}>!",
            )
            raise e
        return default


myDefaultRepository: DefaultRepository = DefaultRepository(myDB, myLogger)
