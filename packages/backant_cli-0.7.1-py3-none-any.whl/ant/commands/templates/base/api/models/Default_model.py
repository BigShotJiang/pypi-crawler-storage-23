from dataclasses import dataclass

from sqlalchemy import (
    Column,
    Integer,
    String,
)


from startup.Alchemy import Base


@dataclass
class Default(Base):
    __tablename__ = "default"

    id: int = Column(Integer, primary_key=True)
    model: String = Column(String)
