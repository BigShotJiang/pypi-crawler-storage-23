import signal
from flask import Flask, jsonify
from flask_cors import CORS
import startup
from startup.Alchemy import init_db, db_session
from helper.execution_tracking.APIException import (
    APIException,
)
from routes.default_route import default_bp

from dotenv import load_dotenv


def shutdown(signum, frame):
    print("Caught SIGTERM, shutting down")
    # Finish any outstanding requests, then...
    exit(0)


def create_app():

    app = Flask(__name__)
    app.config["CORS_HEADERS"] = "Content-Type"

    CORS(app)

    init_db()

    load_dotenv()

    app.register_blueprint(default_bp)

    @app.teardown_appcontext
    def shutdown_session(exception=None):  # pylint: disable=W0613
        db_session.remove()

    @app.errorhandler(APIException)
    def invalid_api_usage(exception):
        return jsonify(exception.to_dict()), exception.status_code

    signal.signal(signal.SIGTERM, shutdown)
    return app
