import boto3
from botocore.exceptions import BotoCoreError, NoCredentialsError


class AWSClient:
    def __init__(
        self,
        aws_access_key_id=None,
        aws_secret_access_key=None,
        aws_session_token=None,
        region_name=None,
        profile_name=None,
    ):
        try:
            # Initialize the boto3 session based on the provided parameters or default to ECS task role credentials
            if profile_name:
                self.session = boto3.Session(
                    profile_name=profile_name, region_name=region_name
                )
            elif aws_access_key_id and aws_secret_access_key:
                self.session = boto3.Session(
                    aws_access_key_id=aws_access_key_id,
                    aws_secret_access_key=aws_secret_access_key,
                )
            else:
                # Default to using the ECS task role credentials if running in ECS and no credentials provided
                self.session = boto3.Session(region_name=region_name)
        except (BotoCoreError, NoCredentialsError) as e:
            print(f"Error initializing AWS session: {e}")
            raise
