def update_dict(old_dict, new_dict):
    for key, value in new_dict.items():
        old_dict[key] = value
    return old_dict


def remove_nan_values(data: dict) -> dict:
    # Create a new dictionary excluding values that contain "NaN"
    return {key: value for key, value in data.items() if value != "NaN"}
