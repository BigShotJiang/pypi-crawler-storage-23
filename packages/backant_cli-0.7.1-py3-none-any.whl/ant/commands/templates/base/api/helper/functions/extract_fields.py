import re


def extract_fields(reg_ex: str, json: dict):
    needed_fields = {}
    pattern = re.compile(reg_ex)
    for key, value in json.items():
        if pattern.match(key):
            needed_fields[key] = value
    return needed_fields
