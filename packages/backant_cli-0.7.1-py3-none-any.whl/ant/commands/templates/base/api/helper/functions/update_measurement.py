from helper.functions.update_dict import update_dict
from models.Default_model import Default


def update_measurement(db_default: Default, default: Default):
    db_default.json = update_dict(db_default.json, default.json)
