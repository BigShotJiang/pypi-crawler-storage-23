class APIException(Exception):
    def __init__(self, message=None, status_code=None, payload=None):
        self.status_code: int = 500
        self.message: str = "Ocurrió un error"
        super().__init__()
        if message is not None:
            self.message = message
        if status_code is not None:
            self.status_code = status_code
        self.payload = payload

    def to_dict(self):
        exception = dict(self.payload or ())
        exception["message"] = self.message
        return exception
