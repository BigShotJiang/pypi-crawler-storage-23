import subprocess
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(message)s")


def log_directory_contents(directory="."):
    try:
        # Run the `ls -la` command
        result = subprocess.run(
            ["ls", "-la", directory],
            text=True,  # Return output as a string
            capture_output=True,  # Capture stdout and stderr
            check=True,  # Raise exception on error
        )
        # Log the output
        logging.info("Directory contents:\n%s", result.stdout)
    except subprocess.CalledProcessError as e:
        # Log any error that occurs
        logging.error("Error running ls -la: %s", e.stderr)


# Example usage
