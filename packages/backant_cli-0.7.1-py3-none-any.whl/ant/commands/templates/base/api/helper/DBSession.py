# noqa: E722

from typing import List

from sqlalchemy import select
from sqlalchemy.engine import Result
from sqlalchemy.exc import ProgrammingError, DataError
from sqlalchemy.orm import scoped_session
from sqlalchemy.orm.exc import UnmappedInstanceError

from helper.execution_tracking.Logger import myLogger
from startup.Alchemy import db_session, Base


class DBSession:
    def __init__(self, session: scoped_session):
        self.session = session

    def execute(self, stmt: select) -> Result:
        try:
            return self.session.execute(stmt)
        except Exception as e:
            myLogger.warning(
                f"Failed to execute statement {stmt} to DB because of {e.args}"
            )

    def execute_commit(self, stmt: select):
        try:
            self.session.execute(stmt)
            self.session.commit()
        except Exception as e:
            myLogger.warning(
                f"Failed to execute statement {stmt} to DB because of {e.args}"
            )
            self.session.rollback()
            raise e

    def add(self, item: Base):
        try:
            self.session.add(item)
            self.session.commit()
        except Exception as e:
            myLogger.warning(f"Failed to write item to DB because of {e.args}")
            self.session.rollback()
            raise e

    def delete(self, item: Base):
        try:
            self.session.delete(item)
            self.session.commit()
        except Exception as e:
            myLogger.warning(f"Failed to delete item because of {e.args}")
            self.session.rollback()
            raise e

    def add_all(self, items: List[Base]):
        try:
            self.session.bulk_save_objects(items)
        except (UnmappedInstanceError, ProgrammingError, DataError) as e:
            myLogger.warning(
                f"Failed to write {len(items)} bulk to DB because of {e.args}"
            )
            self.session.rollback()
            raise e
        self.session.commit()

    def close(self):
        self.session.remove()


myDB = DBSession(db_session)
