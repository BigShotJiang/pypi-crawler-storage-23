import inspect
import logging

logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)


class Logger:
    def __add_callee_class(self, s: str):
        the_method = "Unknown"
        the_class = "Unknown"
        try:
            stack = inspect.stack()
            the_method = stack[2][0].f_code.co_name
            the_class = stack[2][0].f_locals["self"].__class__.__name__
        except KeyError:
            pass
        return f"{the_class}::{the_method}<{s}>"

    def exception(self, e: Exception):
        logging.exception(e)

    def info(self, info: str):
        info = self.__add_callee_class(info)
        logging.info(info)

    def warning(self, warning: str):
        warning = self.__add_callee_class(warning)
        logging.warning(warning)

    def debug(self, debug: str):
        debug = self.__add_callee_class(debug)
        logging.debug(debug)


myLogger = Logger()
