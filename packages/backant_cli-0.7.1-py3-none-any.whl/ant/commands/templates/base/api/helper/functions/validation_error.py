from marshmallow import ValidationError

from helper.execution_tracking.APIException import APIException
from helper.execution_tracking.Logger import myLogger


def validation_error(error: ValidationError) -> APIException:
    myLogger.info(error.messages)
    return APIException(status_code=400)
