from repositories.default_repository import DefaultRepository, myDefaultRepository
from helper.execution_tracking.APIException import APIException
from helper.execution_tracking.Logger import Logger, myLogger


class DefaultService:
    logger: Logger = myLogger

    def __init__(self, default_repository: DefaultRepository) -> None:
        self.default_repository = default_repository

    def get_default(self):
        return "Your backant backend is working"


myDefaultService = DefaultService(myDefaultRepository)
