from flask import Blueprint, jsonify, render_template, abort, url_for
from services.default_service import myDefaultService


default_bp = Blueprint("default", __name__, url_prefix="/")


@default_bp.get("")
def default_page():
    response = myDefaultService.get_default()
    return jsonify(response)
