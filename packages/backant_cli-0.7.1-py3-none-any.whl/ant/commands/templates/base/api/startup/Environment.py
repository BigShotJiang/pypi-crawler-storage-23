# pylint: disable=R0902

import os


class Environment:
    POSTGRES_USER = os.environ.get("POSTGRES_USER", None)
    POSTGRES_PASSWORD = os.environ.get("POSTGRES_PASSWORD", None)
    POSTGRES_DB = os.environ.get("POSTGRES_DB", None)
    DB_URL = os.environ.get("DB_URL", None)
    CLEAR_DB = os.environ.get("CLEAR_DB", None)
    CERT_URL = os.environ.get("CERT_URL", None)

    FLASK_APP = os.environ.get("FLASK_APP", None)
    FLASK_ENV = os.environ.get("FLASK_ENV", None)

    TESTING = os.environ.get("TESTING", True)

    NXTGN_BASE_URL = os.environ.get("NXTGN_BASE_URL", None)
    NXTGN_USER = os.environ.get("NXTGN_USER", None)
    NXTGN_PASSWORD = os.environ.get("NXTGN_PASSWORD", None)

    COGNITO_REGION = os.getenv("COGNITO_REGION", None)
    COGNITO_USERPOOL_ID = os.getenv("COGNITO_USERPOOL_ID", None)
    COGNITO_APP_CLIENT_ID = os.getenv("COGNITO_APP_CLIENT_ID", None)
    COGNITO_APP_CLIENT_SECRET = os.getenv("COGNITO_APP_CLIENT_SECRET", None)

    S3_ACCESS_KEY = os.getenv("S3_ACCESS_KEY", None)
    S3_SECRET_KEY = os.getenv("S3_SECRET_KEY", None)

    COGNITO_SECRET_ACCESS_KEY = os.getenv("COGNITO_SECRET_ACCESS_KEY", None)
    COGNITO_ACCESS_KEY_ID = os.getenv("COGNITO_ACCESS_KEY_ID", None)


myEnvironment = Environment()
