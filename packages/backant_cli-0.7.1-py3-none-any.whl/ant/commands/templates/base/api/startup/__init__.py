import os

from dotenv import load_dotenv

if os.environ.get("TESTING") == "True":
    load_dotenv(".env.testing", override=True)
else:
    load_dotenv()
