# pylint: disable=W0611,C0415,R0401

from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, scoped_session
from sqlalchemy.engine import make_url
from helper.execution_tracking.Logger import myLogger
from startup.Environment import myEnvironment
from psycopg2.extensions import register_adapter, AsIs
import json

db_user = myEnvironment.POSTGRES_USER
db_password = myEnvironment.POSTGRES_PASSWORD
db_url = myEnvironment.DB_URL
db = myEnvironment.POSTGRES_DB
testing = myEnvironment.TESTING


engine = create_engine(
    f"postgresql+psycopg2://{db_user}:{db_password}@{db_url}/{db}",
    # connect_args={"sslmode": ssl_mode, "sslrootcert": ssl_root_cert},
)

db_session = scoped_session(
    sessionmaker(autocommit=False, autoflush=False, bind=engine)
)


Base = declarative_base()


def adapt_dict(dict_var):
    return AsIs("'" + json.dumps(dict_var) + "'")


register_adapter(dict, adapt_dict)


def init_db():
    import models.Default_model

    if myEnvironment.CLEAR_DB == "True":
        Base.metadata.drop_all(engine)
    try:
        myLogger.info(f"Trying to create engine <{engine}>")
        Base.metadata.create_all(engine)
    except Exception as e:
        myLogger.warning(f"Could not connect to DB because of <{e}>")
        quit(1)
