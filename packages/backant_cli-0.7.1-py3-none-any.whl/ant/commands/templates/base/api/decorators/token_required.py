from functools import wraps
from flask import request
from helper.execution_tracking.Logger import myLogger as logger
from helper.execution_tracking.APIException import APIException


def token_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        auth_header = request.headers.get("Authorization", None)
        logger.debug(f"Request Headers: {request.headers}")
        if not auth_header:
            raise APIException(status_code=401)

        token = auth_header.split()[1]
        if not token:
            raise APIException(status_code=401)

        try:
            logger.debug(f"Decoded: {decoded_token}")
        except Exception as e:
            logger.debug(f"Exception: {e}")
            raise APIException(status_code=401)

        return f(*args, **kwargs)

    return decorated_function


def role_required(role):
    def decorator(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            auth_header = request.headers.get("Authorization", None)
            if not auth_header:
                raise APIException(status_code=401)

            token = auth_header.split()[1]
            if not token:
                raise APIException(status_code=401)

            return f(*args, **kwargs)

        return wrapped

    return decorator
