import click
import sys
import os
from ant.commands.generate import generate


@click.group(context_settings={"help_option_names": ["-h", "--help"]})
@click.option("--report", is_flag=True, default=False, help="Output machine-readable JSON report to stdout")
@click.pass_context
def main(ctx, report):
    """Main CLI entry point."""
    ctx.ensure_object(dict)
    ctx.obj["report"] = report


main.add_command(generate)

if __name__ == "__main__":
    main()
