# Starlex (Python)

This is a minimal Python package stub for `starlex` so we can publish to PyPI and reserve the package name.

## Build

```bash
uv run --with build python -m build
```

## Publish

```bash
uv publish --token "$PYPI_API_TOKEN"
```
