"""Near-real-time polling and change detection."""
