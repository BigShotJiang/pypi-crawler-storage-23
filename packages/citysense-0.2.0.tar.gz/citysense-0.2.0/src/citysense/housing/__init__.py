"""Housing: affordability, equity, tenure, rights."""
