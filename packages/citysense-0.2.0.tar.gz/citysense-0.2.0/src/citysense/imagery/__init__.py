"""Street-level and satellite imagery processing."""
