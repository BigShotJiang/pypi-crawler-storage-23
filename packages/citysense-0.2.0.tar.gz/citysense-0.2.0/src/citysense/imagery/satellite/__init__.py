"""Sentinel satellite imagery and spectral indices."""
