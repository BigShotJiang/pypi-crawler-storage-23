"""Tests for the thread_id / subject / 404-graceful-degradation logic
added to reply_to_email_google_oauth_async and reply_to_email_async."""

import base64
import json
from typing import Any, Dict, List
from unittest.mock import AsyncMock, patch, MagicMock

import httpx
import pytest

from dhisana.schemas.common import ReplyEmailContext, EmailRecipient


# ---------------------------------------------------------------------------
# Helpers – tiny fakes for the HTTP layer
# ---------------------------------------------------------------------------

def _make_response(status_code: int, json_body: Any = None) -> httpx.Response:
    """Build a minimal httpx.Response for mocking."""
    resp = httpx.Response(
        status_code=status_code,
        request=httpx.Request("GET", "https://example.com"),
        content=json.dumps(json_body or {}).encode(),
    )
    return resp


def _gmail_message(
    thread_id: str = "thread_abc",
    from_header: str = "Alice <alice@example.com>",
    to_header: str = "Bob <bob@example.com>",
    subject: str = "Hello",
    message_id_header: str = "<orig@example.com>",
) -> Dict[str, Any]:
    """Return a minimal Gmail message dict used as the fetch response."""
    return {
        "id": "msg_123",
        "threadId": thread_id,
        "payload": {
            "headers": [
                {"name": "From", "value": from_header},
                {"name": "To", "value": to_header},
                {"name": "Subject", "value": subject},
                {"name": "Message-ID", "value": message_id_header},
            ]
        },
    }


def _base_context(**overrides) -> ReplyEmailContext:
    """Build a ReplyEmailContext with sane defaults; override any field."""
    defaults = dict(
        message_id="msg_123",
        reply_body="Thanks!",
        sender_email="me@example.com",
        sender_name="Me",
    )
    defaults.update(overrides)
    return ReplyEmailContext(**defaults)


# ---------------------------------------------------------------------------
# OAuth path — reply_to_email_google_oauth_async
# ---------------------------------------------------------------------------

def _build_mock_async_client(get_side_effect=None, get_return=None, post_return=None):
    """Build a mock httpx.AsyncClient that works as ``async with`` context manager.

    The function creates a *factory* so that every ``async with httpx.AsyncClient(...)``
    call in the function under test gets a fresh mock that behaves identically.
    """

    def _factory(*args, **kwargs):
        mock_client = AsyncMock()
        if get_side_effect is not None:
            mock_client.get = AsyncMock(side_effect=get_side_effect)
        elif get_return is not None:
            mock_client.get = AsyncMock(return_value=get_return)
        if post_return is not None:
            mock_client.post = AsyncMock(return_value=post_return)
        mock_cm = AsyncMock()
        mock_cm.__aenter__ = AsyncMock(return_value=mock_client)
        mock_cm.__aexit__ = AsyncMock(return_value=False)
        return mock_cm

    return _factory


@pytest.mark.asyncio
async def test_oauth_reply_uses_context_thread_id_on_404():
    """When the original message returns 404 the context-supplied thread_id
    and subject should be used and the reply should succeed when explicit
    to_recipients are provided."""

    ctx = _base_context(
        thread_id="ctx_thread_999",
        subject="Ctx Subject",
        to_recipients=[EmailRecipient(email="alice@example.com", name="Alice")],
    )

    fetch_404 = _make_response(404)
    send_200 = _make_response(200, {"id": "sent_1", "threadId": "ctx_thread_999", "labelIds": []})

    def _get_side_effect(url, **kw):
        raise httpx.HTTPStatusError(
            "Not Found",
            request=httpx.Request("GET", url),
            response=fetch_404,
        )

    factory = _build_mock_async_client(
        get_side_effect=_get_side_effect,
        post_return=send_200,
    )

    with patch(
        "dhisana.utils.google_oauth_tools.get_google_access_token",
        return_value="fake_token",
    ), patch("dhisana.utils.google_oauth_tools.httpx.AsyncClient", side_effect=factory):
        from dhisana.utils.google_oauth_tools import reply_to_email_google_oauth_async

        result = await reply_to_email_google_oauth_async(ctx)

    assert result["message_id"] == "ctx_thread_999"
    assert "Re: Ctx Subject" in result["email_subject"]


@pytest.mark.asyncio
async def test_oauth_reply_404_no_recipients_raises():
    """When the original is 404 and no explicit recipients / fallback are
    provided, the function must raise with a clear 404-related message."""

    ctx = _base_context(
        thread_id="ctx_thread_999",
        subject="Ctx Subject",
        # No to_recipients, no fallback_recipient
    )

    fetch_404 = _make_response(404)
    send_200 = _make_response(200, {"id": "sent_1", "threadId": "ctx_thread_999", "labelIds": []})

    def _get_side_effect(url, **kw):
        raise httpx.HTTPStatusError(
            "Not Found",
            request=httpx.Request("GET", url),
            response=fetch_404,
        )

    factory = _build_mock_async_client(
        get_side_effect=_get_side_effect,
        post_return=send_200,
    )

    with patch(
        "dhisana.utils.google_oauth_tools.get_google_access_token",
        return_value="fake_token",
    ), patch("dhisana.utils.google_oauth_tools.httpx.AsyncClient", side_effect=factory):
        from dhisana.utils.google_oauth_tools import reply_to_email_google_oauth_async

        with pytest.raises(ValueError, match="404"):
            await reply_to_email_google_oauth_async(ctx)


@pytest.mark.asyncio
async def test_oauth_reply_normal_path_still_works():
    """Sanity check: when the original message is fetched successfully, the
    reply should work as before and use the original thread_id / subject."""

    original = _gmail_message(
        thread_id="orig_thread",
        from_header="Alice <alice@example.com>",
        to_header="Me <me@example.com>",
        subject="Original Subject",
    )
    ctx = _base_context(
        fallback_recipient="alice@example.com",
    )

    fetch_200 = _make_response(200, original)
    send_200 = _make_response(200, {"id": "sent_2", "threadId": "orig_thread", "labelIds": []})

    factory = _build_mock_async_client(
        get_return=fetch_200,
        post_return=send_200,
    )

    with patch(
        "dhisana.utils.google_oauth_tools.get_google_access_token",
        return_value="fake_token",
    ), patch("dhisana.utils.google_oauth_tools.httpx.AsyncClient", side_effect=factory):
        from dhisana.utils.google_oauth_tools import reply_to_email_google_oauth_async

        result = await reply_to_email_google_oauth_async(ctx)

    assert result["message_id"] == "orig_thread"
    assert result["email_subject"] == "Re: Original Subject"


# ---------------------------------------------------------------------------
# Schema tests
# ---------------------------------------------------------------------------

def test_reply_email_context_thread_id_default_none():
    """thread_id should default to None and be optional."""
    ctx = _base_context()
    assert ctx.thread_id is None


def test_reply_email_context_thread_id_set():
    """thread_id should accept a string value."""
    ctx = _base_context(thread_id="t_123")
    assert ctx.thread_id == "t_123"
