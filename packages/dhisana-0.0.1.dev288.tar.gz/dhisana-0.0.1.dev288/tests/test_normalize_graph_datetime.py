"""Tests for _normalize_graph_datetime in microsoft365_tools."""

import re

import pytest

from dhisana.utils.microsoft365_tools import _normalize_graph_datetime


# Regex asserting the format Microsoft Graph OData $filter expects:
# YYYY-MM-DDTHH:MM:SSZ  (no microseconds, no +00:00 offset)
_GRAPH_DT_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$")


class TestNormalizeGraphDatetime:
    """Microsoft Graph OData $filter requires datetimes without microseconds
    and with a 'Z' suffix instead of '+00:00'."""

    def test_strips_microseconds_and_offset(self):
        result = _normalize_graph_datetime("2026-02-27T00:36:36.946000+00:00")
        assert result == "2026-02-27T00:36:36Z"
        assert _GRAPH_DT_RE.match(result)

    def test_strips_microseconds_with_z(self):
        result = _normalize_graph_datetime("2026-02-27T04:02:49.210450Z")
        assert result == "2026-02-27T04:02:49Z"
        assert _GRAPH_DT_RE.match(result)

    def test_already_clean_z_format(self):
        result = _normalize_graph_datetime("2026-02-27T00:36:36Z")
        assert result == "2026-02-27T00:36:36Z"
        assert _GRAPH_DT_RE.match(result)

    def test_offset_without_microseconds(self):
        result = _normalize_graph_datetime("2026-02-27T00:36:36+00:00")
        assert result == "2026-02-27T00:36:36Z"
        assert _GRAPH_DT_RE.match(result)

    def test_non_utc_offset_converts_to_utc(self):
        # 2026-02-27T05:30:00+05:30 = 2026-02-27T00:00:00Z
        result = _normalize_graph_datetime("2026-02-27T05:30:00+05:30")
        assert result == "2026-02-27T00:00:00Z"
        assert _GRAPH_DT_RE.match(result)

    def test_naive_datetime_gets_z_suffix(self):
        result = _normalize_graph_datetime("2026-02-27T12:00:00")
        assert result == "2026-02-27T12:00:00Z"
        assert _GRAPH_DT_RE.match(result)

    def test_microseconds_only(self):
        result = _normalize_graph_datetime("2026-02-27T12:00:00.123456")
        assert result == "2026-02-27T12:00:00Z"
        assert _GRAPH_DT_RE.match(result)

    def test_isoformat_from_datetime_now(self):
        """Simulate the actual pattern used in send_email_using_microsoft_graph_async."""
        from datetime import datetime, timezone
        raw = datetime.now(timezone.utc).isoformat()
        # Raw isoformat has microseconds and +00:00
        result = _normalize_graph_datetime(raw)
        assert _GRAPH_DT_RE.match(result), (
            f"datetime.now().isoformat() produced '{raw}' which was normalised to "
            f"'{result}' — expected YYYY-MM-DDTHH:MM:SSZ"
        )
