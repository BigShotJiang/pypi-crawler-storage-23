import click

@click.group()
def main():
    """Crucible — humanoid robotics benchmarking."""
    pass

@main.command()
def login():
    """Authenticate with Crucible."""
    click.echo("login: not yet implemented")

@main.command()
def init():
    """Scaffold a crucible.yaml in the current directory."""
    click.echo("init: not yet implemented")

@main.command()
def deploy():
    """Upload policy and create a simulation job."""
    click.echo("deploy: not yet implemented")

@main.command()
def jobs():
    """List simulation jobs."""
    click.echo("jobs: not yet implemented")

@main.command()
@click.argument("job_id")
def logs(job_id: str):
    """Stream logs for a job."""
    click.echo(f"logs {job_id}: not yet implemented")

@main.command()
@click.argument("job_id")
def results(job_id: str):
    """Download results for a job."""
    click.echo(f"results {job_id}: not yet implemented")
