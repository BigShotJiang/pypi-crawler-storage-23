"""Local model endpoints for the Core edition."""
