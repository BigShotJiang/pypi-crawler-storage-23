"""Shared pytest fixtures for boj_api tests.

Provides reusable JSON payloads, mock responses, and pre-configured
client instances used across all test modules.  All fixture payloads
mirror the **real** BOJ API v1 JSON response format (flat status fields
at top level, ``RESULTSET`` key, parallel-array ``VALUES``).
"""

from typing import Any, Dict
from unittest.mock import MagicMock

import pytest

from boj_api import BOJClient

# ---------------------------------------------------------------------------
# Sample JSON payloads (mirror real BOJ API structure)
# ---------------------------------------------------------------------------


@pytest.fixture()
def code_api_success_payload() -> Dict[str, Any]:
    """Minimal successful Code API JSON response with 2 series."""
    return {
        "STATUS": 200,
        "MESSAGEID": "M181000I",
        "MESSAGE": "Successfully completed",
        "DATE": "2026-02-18T09:00:00.000+09:00",
        "PARAMETER": {
            "FORMAT": "JSON",
            "LANG": "JP",
            "DB": "CO",
            "STARTDATE": "202401",
            "ENDDATE": "202504",
            "STARTPOSITION": "",
        },
        "NEXTPOSITION": None,
        "RESULTSET": [
            {
                "SERIES_CODE": "TK99F0000601GCQ00000",
                "NAME_OF_TIME_SERIES_J": "D.I./Business Conditions/All Enterprises",
                "UNIT_J": "% points",
                "FREQUENCY": "QUARTERLY",
                "CATEGORY_J": "TANKAN",
                "LAST_UPDATE": 20260115,
                "VALUES": {
                    "SURVEY_DATES": [202401, 202402, 202403, 202404, 202501],
                    "VALUES": [12, 15, 14, 13, None],
                },
            },
            {
                "SERIES_CODE": "TK99F0000601GCQ01000",
                "NAME_OF_TIME_SERIES_J": "D.I./Manufacturing",
                "UNIT_J": "% points",
                "FREQUENCY": "QUARTERLY",
                "CATEGORY_J": "TANKAN",
                "LAST_UPDATE": 20260115,
                "VALUES": {
                    "SURVEY_DATES": [202401, 202402],
                    "VALUES": [8, 10],
                },
            },
        ],
    }


@pytest.fixture()
def code_api_empty_payload() -> Dict[str, Any]:
    """Code API response with status 200 but no matching data."""
    return {
        "STATUS": 200,
        "MESSAGEID": "M181030I",
        "MESSAGE": "Successfully completed, but no matching data found.",
        "DATE": "2026-02-18T09:01:00.000+09:00",
        "PARAMETER": {
            "FORMAT": "JSON",
            "LANG": "JP",
            "DB": "FM01",
            "STARTDATE": "",
            "ENDDATE": "",
            "STARTPOSITION": "",
        },
        "NEXTPOSITION": None,
        "RESULTSET": [],
    }


@pytest.fixture()
def code_api_paginated_page1() -> Dict[str, Any]:
    """First page of a paginated Code API response."""
    return {
        "STATUS": 200,
        "MESSAGEID": "M181000I",
        "MESSAGE": "Successfully completed",
        "DATE": "2026-02-18T09:00:00.000+09:00",
        "PARAMETER": {
            "FORMAT": "JSON",
            "LANG": "JP",
            "DB": "CO",
            "STARTDATE": "",
            "ENDDATE": "",
            "STARTPOSITION": "",
        },
        "NEXTPOSITION": 160,
        "RESULTSET": [
            {
                "SERIES_CODE": "SERIES_A",
                "NAME_OF_TIME_SERIES_J": "Series A",
                "FREQUENCY": "QUARTERLY",
                "LAST_UPDATE": 20260115,
                "VALUES": {
                    "SURVEY_DATES": [202401],
                    "VALUES": [1],
                },
            },
        ],
    }


@pytest.fixture()
def code_api_paginated_page2() -> Dict[str, Any]:
    """Second (final) page of a paginated Code API response."""
    return {
        "STATUS": 200,
        "MESSAGEID": "M181000I",
        "MESSAGE": "Successfully completed",
        "DATE": "2026-02-18T09:00:01.000+09:00",
        "PARAMETER": {
            "FORMAT": "JSON",
            "LANG": "JP",
            "DB": "CO",
            "STARTDATE": "",
            "ENDDATE": "",
            "STARTPOSITION": "160",
        },
        "NEXTPOSITION": None,
        "RESULTSET": [
            {
                "SERIES_CODE": "SERIES_B",
                "NAME_OF_TIME_SERIES_J": "Series B",
                "FREQUENCY": "QUARTERLY",
                "LAST_UPDATE": 20260115,
                "VALUES": {
                    "SURVEY_DATES": [202401],
                    "VALUES": [99],
                },
            },
        ],
    }


@pytest.fixture()
def layer_api_success_payload() -> Dict[str, Any]:
    """Successful Layer API JSON response."""
    return {
        "STATUS": 200,
        "MESSAGEID": "M181000I",
        "MESSAGE": "Successfully completed",
        "DATE": "2026-02-18T09:05:00.000+09:00",
        "PARAMETER": {
            "FORMAT": "JSON",
            "LANG": "JP",
            "DB": "BP01",
            "LAYER1": "1",
            "LAYER2": "1",
            "LAYER3": "1",
            "LAYER4": "",
            "LAYER5": "",
            "FREQUENCY": "M",
            "STARTDATE": "202504",
            "ENDDATE": "202509",
            "STARTPOSITION": "",
        },
        "NEXTPOSITION": None,
        "RESULTSET": [
            {
                "SERIES_CODE": "BPBP6JYNCB",
                "NAME_OF_TIME_SERIES_J": "Current account balance",
                "UNIT_J": "100 million yen",
                "FREQUENCY": "MONTHLY",
                "CATEGORY_J": "Balance of Payments",
                "LAST_UPDATE": 20260201,
                "VALUES": {
                    "SURVEY_DATES": [202504, 202505],
                    "VALUES": [12345.0, 12500.0],
                },
            },
        ],
    }


@pytest.fixture()
def metadata_api_success_payload() -> Dict[str, Any]:
    """Successful Metadata API JSON response."""
    return {
        "STATUS": 200,
        "MESSAGEID": "M181000I",
        "MESSAGE": "Successfully completed",
        "DATE": "2026-02-18T10:00:00.000+09:00",
        "DB": "FM08",
        "RESULTSET": [
            {
                "SERIES_CODE": "FXERD01",
                "NAME_OF_TIME_SERIES_J": "Tokyo USD/JPY Spot 9:00",
                "NAME_OF_TIME_SERIES": "US.Dollar/Yen Spot Rate at 9:00 in JST",
                "UNIT_J": "yen/dollar",
                "UNIT": "Yen per U.S. Dollar",
                "FREQUENCY": "DAILY",
                "CATEGORY_J": "Foreign Exchange Rates",
                "CATEGORY": "Foreign Exchange Rates",
                "LAYER1": 1,
                "LAYER2": 1,
                "LAYER3": 0,
                "LAYER4": 0,
                "LAYER5": 0,
                "START_OF_THE_TIME_SERIES": "19990101",
                "END_OF_THE_TIME_SERIES": "20260219",
                "LAST_UPDATE": "20260224",
                "NOTES_J": "",
                "NOTES": "",
            },
            {
                "SERIES_CODE": "FXERD02",
                "NAME_OF_TIME_SERIES_J": "Tokyo USD/JPY Spot High",
                "FREQUENCY": "DAILY",
                "LAYER1": 1,
                "LAYER2": 2,
                "LAYER3": 0,
                "LAYER4": 0,
                "LAYER5": 0,
                "START_OF_THE_TIME_SERIES": "19990101",
                "END_OF_THE_TIME_SERIES": "20260219",
                "LAST_UPDATE": "20260224",
            },
        ],
    }


@pytest.fixture()
def error_400_payload() -> Dict[str, Any]:
    """API error response: invalid DB name (status 400)."""
    return {
        "STATUS": 400,
        "MESSAGEID": "M181005E",
        "MESSAGE": "Invalid DB name.",
        "DATE": "2026-02-18T09:10:00.000+09:00",
    }


@pytest.fixture()
def error_500_payload() -> Dict[str, Any]:
    """API error response: unexpected server error (status 500)."""
    return {
        "STATUS": 500,
        "MESSAGEID": "M181090S",
        "MESSAGE": "Unexpected error.",
        "DATE": "2026-02-18T09:11:00.000+09:00",
    }


@pytest.fixture()
def error_503_payload() -> Dict[str, Any]:
    """API error response: database access error (status 503)."""
    return {
        "STATUS": 503,
        "MESSAGEID": "M181091S",
        "MESSAGE": "Database access error.",
        "DATE": "2026-02-18T09:12:00.000+09:00",
    }


@pytest.fixture()
def mock_session() -> MagicMock:
    """A pre-built MagicMock for ``requests.Session``."""
    session = MagicMock()
    session.headers = {}
    session.headers.update = MagicMock()
    return session


@pytest.fixture()
def client() -> BOJClient:
    """A BOJClient with retry_delay=0 to speed up tests."""
    return BOJClient(retry_delay=0.0, max_retries=1)
