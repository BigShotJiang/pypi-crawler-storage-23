"""Tests for boj_api.client — comprehensive coverage.

All HTTP calls are mocked via ``unittest.mock.patch`` on
``requests.Session.get`` so no real network traffic occurs.
"""

from typing import Any, Dict
from unittest.mock import MagicMock, patch

import pytest
import requests

from boj_api.client import (
    BOJClient,
    _merge_data_responses,
    _parse_data_response,
    _parse_metadata_response,
    _parse_parameter_info,
    _parse_result_info,
    _parse_series,
    _resolve_enum,
)
from boj_api.enums import Database, Format, Frequency, Language
from boj_api.exceptions import (
    BOJAPIError,
    DatabaseAccessError,
    InvalidParameterError,
    RateLimitError,
    ResponseParseError,
    ServerError,
)
from boj_api.models import DataResponse, Observation, ParameterInfo, ResultInfo, Series

# ======================================================================
# Helpers / internal function tests
# ======================================================================


class TestResolveEnum:
    """Tests for :func:`_resolve_enum`."""

    def test_enum_member(self) -> None:
        assert _resolve_enum(Database.FM08, Database) == "FM08"

    def test_raw_string(self) -> None:
        assert _resolve_enum("FM08", Database) == "FM08"

    def test_frequency_enum(self) -> None:
        assert _resolve_enum(Frequency.MONTHLY, Frequency) == "M"

    def test_format_enum(self) -> None:
        assert _resolve_enum(Format.CSV, Format) == "csv"


class TestParseResultInfo:
    """Tests for :func:`_parse_result_info`."""

    def test_normal(self) -> None:
        data = {
            "STATUS": 200,
            "MESSAGEID": "M181000I",
            "MESSAGE": "OK",
            "DATE": "2026-01-01",
        }
        result = _parse_result_info(data)
        assert result.status == 200
        assert result.message_id == "M181000I"

    def test_empty_dict(self) -> None:
        result = _parse_result_info({})
        assert result.status == 0
        assert result.message_id == ""


class TestParseParameterInfo:
    """Tests for :func:`_parse_parameter_info`."""

    def test_full(self) -> None:
        data = {
            "FORMAT": "json",
            "LANG": "jp",
            "DB": "CO",
            "LAYER1": "1",
            "FREQUENCY": "Q",
            "STARTDATE": "202401",
            "ENDDATE": "202504",
            "STARTPOSITION": "160",
        }
        p = _parse_parameter_info(data)
        assert p.format == "json"
        assert p.db == "CO"
        assert p.start_position == 160

    def test_empty_values(self) -> None:
        data = {
            "FORMAT": "",
            "LANG": "",
            "DB": "",
            "STARTPOSITION": "",
        }
        p = _parse_parameter_info(data)
        assert p.format is None
        assert p.start_position is None

    def test_invalid_start_position(self) -> None:
        data = {"STARTPOSITION": "abc"}
        p = _parse_parameter_info(data)
        assert p.start_position is None


class TestParseSeries:
    """Tests for :func:`_parse_series`."""

    def test_with_data(self) -> None:
        data = {
            "SERIES_CODE": "ABC",
            "NAME_OF_TIME_SERIES_J": "Test",
            "UNIT_J": "yen",
            "FREQUENCY": "MONTHLY",
            "LAST_UPDATE": 20260115,
            "VALUES": {
                "SURVEY_DATES": [202501, 202502],
                "VALUES": [100, None],
            },
        }
        s = _parse_series(data)
        assert s.series_code == "ABC"
        assert s.name_jp == "Test"
        assert len(s.observations) == 2
        assert s.observations[0].value == 100
        assert s.observations[0].date == 202501
        assert s.observations[1].value is None

    def test_empty_values(self) -> None:
        data = {
            "SERIES_CODE": "XYZ",
            "VALUES": {"SURVEY_DATES": [], "VALUES": []},
        }
        s = _parse_series(data)
        assert len(s.observations) == 0

    def test_missing_values_key(self) -> None:
        data = {"SERIES_CODE": "NO_DATA"}
        s = _parse_series(data)
        assert len(s.observations) == 0

    def test_english_fields(self) -> None:
        data = {
            "SERIES_CODE": "EN1",
            "NAME_OF_TIME_SERIES": "English Name",
            "UNIT": "JPY",
            "CATEGORY": "Test",
        }
        s = _parse_series(data)
        assert s.name_en == "English Name"
        assert s.unit_en == "JPY"
        assert s.category_en == "Test"

    def test_values_not_dict_ignored(self) -> None:
        data = {
            "SERIES_CODE": "MIX",
            "VALUES": "not_a_dict",
        }
        s = _parse_series(data)
        assert len(s.observations) == 0

    def test_float_values(self) -> None:
        data = {
            "SERIES_CODE": "FLT",
            "VALUES": {
                "SURVEY_DATES": [202501],
                "VALUES": [12345.678],
            },
        }
        s = _parse_series(data)
        assert s.observations[0].value == 12345.678


class TestParseDataResponse:
    """Tests for :func:`_parse_data_response`."""

    def test_success(self, code_api_success_payload: Dict[str, Any]) -> None:
        resp = _parse_data_response(code_api_success_payload)
        assert resp.result.status == 200
        assert len(resp.series) == 2
        assert resp.next_position is None
        assert resp.series[0].series_code == "TK99F0000601GCQ00000"
        assert len(resp.series[0].observations) == 5

    def test_empty(self, code_api_empty_payload: Dict[str, Any]) -> None:
        resp = _parse_data_response(code_api_empty_payload)
        assert resp.result.status == 200
        assert len(resp.series) == 0

    def test_paginated(self, code_api_paginated_page1: Dict[str, Any]) -> None:
        resp = _parse_data_response(code_api_paginated_page1)
        assert resp.next_position == 160

    def test_non_list_resultset(self) -> None:
        payload = {
            "STATUS": 200,
            "MESSAGEID": "X",
            "MESSAGE": "",
            "DATE": "",
            "PARAMETER": {},
            "NEXTPOSITION": None,
            "RESULTSET": "not_a_list",
        }
        resp = _parse_data_response(payload)
        assert resp.series == []

    def test_non_numeric_next_position(self) -> None:
        """NEXTPOSITION with a non-integer string falls back to None."""
        payload = {
            "STATUS": 200,
            "MESSAGEID": "X",
            "MESSAGE": "",
            "DATE": "",
            "PARAMETER": {},
            "NEXTPOSITION": "abc",
            "RESULTSET": [],
        }
        resp = _parse_data_response(payload)
        assert resp.next_position is None

    def test_parse_error_wraps_in_response_parse_error(self) -> None:
        """A non-BOJAPIError exception is wrapped in ResponseParseError."""
        payload: Any = None  # Trigger AttributeError in _parse_result_info
        with pytest.raises(ResponseParseError, match="Failed to parse data API response"):
            _parse_data_response(payload)  # type: ignore[arg-type]

    def test_parse_error_reraises_boj_api_error(self) -> None:
        """A BOJAPIError raised during parsing is re-raised as-is."""
        payload = {
            "STATUS": 200,
            "MESSAGEID": "X",
            "MESSAGE": "",
            "DATE": "",
            "PARAMETER": {},
            "NEXTPOSITION": None,
            "RESULTSET": [],
        }
        with (
            patch(
                "boj_api.client._parse_result_info",
                side_effect=InvalidParameterError(400, "E", "forced"),
            ),
            pytest.raises(InvalidParameterError),
        ):
            _parse_data_response(payload)


class TestParseMetadataResponse:
    """Tests for :func:`_parse_metadata_response`."""

    def test_success(self, metadata_api_success_payload: Dict[str, Any]) -> None:
        resp = _parse_metadata_response(metadata_api_success_payload)
        assert resp.result.status == 200
        assert resp.db == "FM08"
        assert len(resp.entries) == 2
        assert resp.entries[0].series_code == "FXERD01"
        assert resp.entries[0].start_of_series == "19990101"

    def test_parse_error_wraps_in_response_parse_error(self) -> None:
        """A non-BOJAPIError exception is wrapped in ResponseParseError."""
        payload: Any = None  # Trigger AttributeError in _parse_result_info
        with pytest.raises(ResponseParseError, match="Failed to parse metadata API response"):
            _parse_metadata_response(payload)  # type: ignore[arg-type]

    def test_parse_error_reraises_boj_api_error(self) -> None:
        """A BOJAPIError raised during metadata parsing is re-raised as-is."""
        payload = {
            "STATUS": 200,
            "MESSAGEID": "X",
            "MESSAGE": "",
            "DATE": "",
            "DB": "FM08",
            "RESULTSET": [],
        }
        with (
            patch(
                "boj_api.client._parse_result_info",
                side_effect=ServerError(500, "S", "forced"),
            ),
            pytest.raises(ServerError),
        ):
            _parse_metadata_response(payload)


class TestMergeDataResponses:
    """Tests for :func:`_merge_data_responses`."""

    def test_empty_raises(self) -> None:
        with pytest.raises(ValueError, match="empty"):
            _merge_data_responses([])

    def test_single_passthrough(self) -> None:
        result = ResultInfo(status=200, message_id="X", message="", date="")
        resp = DataResponse(result=result, parameters=ParameterInfo())
        merged = _merge_data_responses([resp])
        assert merged is resp

    def test_merge_two_pages(
        self,
        code_api_paginated_page1: Dict[str, Any],
        code_api_paginated_page2: Dict[str, Any],
    ) -> None:
        r1 = _parse_data_response(code_api_paginated_page1)
        r2 = _parse_data_response(code_api_paginated_page2)
        merged = _merge_data_responses([r1, r2])

        assert merged.result.status == 200
        assert merged.next_position is None  # last page has None
        assert len(merged.series) == 2
        codes = {s.series_code for s in merged.series}
        assert codes == {"SERIES_A", "SERIES_B"}

    def test_merge_same_series_extends_observations(self) -> None:
        result = ResultInfo(status=200, message_id="X", message="", date="")
        s1 = Series(series_code="S", observations=[Observation("202401", "1")])
        s2 = Series(series_code="S", observations=[Observation("202402", "2")])
        r1 = DataResponse(result=result, parameters=ParameterInfo(), series=[s1])
        r2 = DataResponse(result=result, parameters=ParameterInfo(), series=[s2])
        merged = _merge_data_responses([r1, r2])
        assert len(merged.series) == 1
        assert len(merged.series[0].observations) == 2


# ======================================================================
# BOJClient tests
# ======================================================================


class TestBOJClientInit:
    """Tests for client construction."""

    def test_defaults(self) -> None:
        c = BOJClient()
        assert c._lang == Language.JP
        assert c._fmt == Format.JSON
        assert c._timeout == 30.0
        assert c._max_retries == 3
        c.close()

    def test_custom_params(self) -> None:
        c = BOJClient(
            lang=Language.EN,
            fmt=Format.CSV,
            timeout=10.0,
            max_retries=5,
            retry_delay=2.0,
        )
        assert c._lang == Language.EN
        assert c._fmt == Format.CSV
        assert c._timeout == 10.0
        assert c._max_retries == 5
        assert c._retry_delay == 2.0
        c.close()

    def test_context_manager(self) -> None:
        with BOJClient() as c:
            assert c._session is not None


class TestBOJClientRequest:
    """Tests for the internal _request method."""

    def _make_mock_response(self, payload: Dict[str, Any], status_code: int = 200) -> MagicMock:
        mock_resp = MagicMock()
        mock_resp.status_code = status_code
        mock_resp.json.return_value = payload
        mock_resp.text = str(payload)
        return mock_resp

    @patch("boj_api.client.requests.Session")
    def test_successful_request(self, mock_session_cls: MagicMock) -> None:
        payload = {
            "STATUS": 200,
            "MESSAGEID": "M181000I",
            "MESSAGE": "OK",
            "DATE": "",
        }
        mock_session = MagicMock()
        mock_session.get.return_value = self._make_mock_response(payload)
        mock_session_cls.return_value = mock_session

        client = BOJClient(max_retries=1, retry_delay=0.0)
        client._session = mock_session
        result = client._request("/getDataCode", {"db": "CO"})
        assert result["STATUS"] == 200
        client.close()

    @patch("boj_api.client.requests.Session")
    def test_json_parse_error(self, mock_session_cls: MagicMock) -> None:
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.side_effect = ValueError("bad json")
        mock_resp.text = "<html>error</html>"

        mock_session = MagicMock()
        mock_session.get.return_value = mock_resp
        mock_session_cls.return_value = mock_session

        client = BOJClient(max_retries=1, retry_delay=0.0)
        client._session = mock_session
        with pytest.raises(ResponseParseError, match="Failed to decode JSON"):
            client._request("/getDataCode", {"db": "CO"})
        client.close()

    @patch("boj_api.client.requests.Session")
    def test_400_raises_invalid_parameter(self, mock_session_cls: MagicMock) -> None:
        payload = {
            "STATUS": 400,
            "MESSAGEID": "M181005E",
            "MESSAGE": "DB名が正しくありません。",
            "DATE": "",
        }
        mock_session = MagicMock()
        mock_session.get.return_value = self._make_mock_response(payload)
        mock_session_cls.return_value = mock_session

        client = BOJClient(max_retries=1, retry_delay=0.0)
        client._session = mock_session
        with pytest.raises(InvalidParameterError) as exc_info:
            client._request("/getDataCode", {"db": "BAD"})
        assert exc_info.value.status == 400
        assert exc_info.value.message_id == "M181005E"
        client.close()

    @patch("boj_api.client.requests.Session")
    def test_500_retries_then_raises(self, mock_session_cls: MagicMock) -> None:
        payload = {
            "STATUS": 500,
            "MESSAGEID": "M181090S",
            "MESSAGE": "予期しないエラー",
            "DATE": "",
        }
        mock_session = MagicMock()
        mock_session.get.return_value = self._make_mock_response(payload)
        mock_session_cls.return_value = mock_session

        client = BOJClient(max_retries=2, retry_delay=0.0)
        client._session = mock_session
        with pytest.raises(ServerError):
            client._request("/getDataCode", {"db": "CO"})
        # Should have been called twice (1 original + 1 retry)
        assert mock_session.get.call_count == 2
        client.close()

    @patch("boj_api.client.requests.Session")
    def test_503_retries_then_raises(self, mock_session_cls: MagicMock) -> None:
        payload = {
            "STATUS": 503,
            "MESSAGEID": "M181091S",
            "MESSAGE": "DB error",
            "DATE": "",
        }
        mock_session = MagicMock()
        mock_session.get.return_value = self._make_mock_response(payload)
        mock_session_cls.return_value = mock_session

        client = BOJClient(max_retries=3, retry_delay=0.0)
        client._session = mock_session
        with pytest.raises(DatabaseAccessError):
            client._request("/getDataCode", {"db": "CO"})
        assert mock_session.get.call_count == 3
        client.close()

    @patch("boj_api.client.requests.Session")
    def test_connection_error_raises_rate_limit(self, mock_session_cls: MagicMock) -> None:
        mock_session = MagicMock()
        mock_session.get.side_effect = requests.ConnectionError("refused")
        mock_session_cls.return_value = mock_session

        client = BOJClient(max_retries=2, retry_delay=0.0)
        client._session = mock_session
        with pytest.raises(RateLimitError, match="rate-limiting"):
            client._request("/getDataCode", {"db": "CO"})
        assert mock_session.get.call_count == 2
        client.close()

    @patch("boj_api.client.requests.Session")
    def test_timeout_retries_then_raises(self, mock_session_cls: MagicMock) -> None:
        mock_session = MagicMock()
        mock_session.get.side_effect = requests.Timeout("timed out")
        mock_session_cls.return_value = mock_session

        client = BOJClient(max_retries=2, retry_delay=0.0)
        client._session = mock_session
        with pytest.raises(BOJAPIError, match="timed out"):
            client._request("/getDataCode", {"db": "CO"})
        assert mock_session.get.call_count == 2
        client.close()

    @patch("boj_api.client.requests.Session")
    def test_generic_request_exception(self, mock_session_cls: MagicMock) -> None:
        mock_session = MagicMock()
        mock_session.get.side_effect = requests.RequestException("weird error")
        mock_session_cls.return_value = mock_session

        client = BOJClient(max_retries=1, retry_delay=0.0)
        client._session = mock_session
        with pytest.raises(BOJAPIError, match="weird error"):
            client._request("/getDataCode", {"db": "CO"})
        client.close()


class TestGetDataByCode:
    """Tests for :meth:`BOJClient.get_data_by_code`."""

    def _setup_client(self, payloads: Any) -> BOJClient:
        """Create a client with a mocked session returning *payloads*."""
        client = BOJClient(max_retries=1, retry_delay=0.0)
        mock_session = MagicMock()

        if isinstance(payloads, list):
            responses = []
            for p in payloads:
                r = MagicMock()
                r.status_code = 200
                r.json.return_value = p
                r.text = str(p)
                responses.append(r)
            mock_session.get.side_effect = responses
        else:
            mock_resp = MagicMock()
            mock_resp.status_code = 200
            mock_resp.json.return_value = payloads
            mock_resp.text = str(payloads)
            mock_session.get.return_value = mock_resp

        client._session = mock_session
        return client

    def test_basic_call(self, code_api_success_payload: Dict[str, Any]) -> None:
        client = self._setup_client(code_api_success_payload)
        resp = client.get_data_by_code(
            db=Database.CO,
            code=["TK99F0000601GCQ00000", "TK99F0000601GCQ01000"],
            start_date="202401",
            end_date="202504",
        )
        assert resp.result.status == 200
        assert len(resp.series) == 2
        assert resp.series[0].series_code == "TK99F0000601GCQ00000"
        client.close()

    def test_with_string_db(self, code_api_success_payload: Dict[str, Any]) -> None:
        client = self._setup_client(code_api_success_payload)
        resp = client.get_data_by_code(db="CO", code=["TK99F0000601GCQ00000"])
        assert resp.result.status == 200
        client.close()

    def test_lang_override(self, code_api_success_payload: Dict[str, Any]) -> None:
        client = self._setup_client(code_api_success_payload)
        client.get_data_by_code(
            db=Database.CO,
            code=["TK99F0000601GCQ00000"],
            lang=Language.EN,
        )
        # Verify the call was made with lang=en
        call_args = client._session.get.call_args
        assert "en" in call_args[1]["params"]["lang"]
        client.close()

    def test_format_override(self, code_api_success_payload: Dict[str, Any]) -> None:
        client = self._setup_client(code_api_success_payload)
        client.get_data_by_code(
            db=Database.CO,
            code=["TK99F0000601GCQ00000"],
            fmt=Format.CSV,
        )
        call_args = client._session.get.call_args
        assert call_args[1]["params"]["format"] == "csv"
        client.close()

    def test_null_observation_values(self, code_api_success_payload: Dict[str, Any]) -> None:
        client = self._setup_client(code_api_success_payload)
        resp = client.get_data_by_code(db=Database.CO, code=["TK99F0000601GCQ00000"])
        # The 5th observation in fixture has VALUE=None
        assert resp.series[0].observations[4].value is None
        client.close()

    def test_empty_result(self, code_api_empty_payload: Dict[str, Any]) -> None:
        client = self._setup_client(code_api_empty_payload)
        resp = client.get_data_by_code(db=Database.FM01, code=["NOSUCH"])
        assert resp.result.message_id == "M181030I"
        assert len(resp.series) == 0
        client.close()

    def test_auto_paginate(
        self,
        code_api_paginated_page1: Dict[str, Any],
        code_api_paginated_page2: Dict[str, Any],
    ) -> None:
        client = self._setup_client([code_api_paginated_page1, code_api_paginated_page2])
        resp = client.get_data_by_code(
            db=Database.CO,
            code=["SERIES_A", "SERIES_B"],
            auto_paginate=True,
        )
        assert resp.next_position is None
        assert len(resp.series) == 2
        assert client._session.get.call_count == 2
        client.close()

    def test_error_400(self, error_400_payload: Dict[str, Any]) -> None:
        client = self._setup_client(error_400_payload)
        with pytest.raises(InvalidParameterError) as exc_info:
            client.get_data_by_code(db="BAD", code=["X"])
        assert exc_info.value.status == 400
        client.close()

    def test_start_position(self, code_api_success_payload: Dict[str, Any]) -> None:
        """Explicit start_position is forwarded to the API."""
        client = self._setup_client(code_api_success_payload)
        client.get_data_by_code(
            db=Database.CO,
            code=["TK99F0000601GCQ00000"],
            start_position=42,
        )
        call_args = client._session.get.call_args
        assert call_args[1]["params"]["startPosition"] == "42"
        client.close()


class TestGetDataByLayer:
    """Tests for :meth:`BOJClient.get_data_by_layer`."""

    def _setup_client(self, payloads: Any) -> BOJClient:
        client = BOJClient(max_retries=1, retry_delay=0.0)
        mock_session = MagicMock()

        if isinstance(payloads, list):
            responses = []
            for p in payloads:
                r = MagicMock()
                r.status_code = 200
                r.json.return_value = p
                r.text = str(p)
                responses.append(r)
            mock_session.get.side_effect = responses
        else:
            mock_resp = MagicMock()
            mock_resp.status_code = 200
            mock_resp.json.return_value = payloads
            mock_resp.text = str(payloads)
            mock_session.get.return_value = mock_resp

        client._session = mock_session
        return client

    def test_basic_call(self, layer_api_success_payload: Dict[str, Any]) -> None:
        client = self._setup_client(layer_api_success_payload)
        resp = client.get_data_by_layer(
            db=Database.BP01,
            frequency=Frequency.MONTHLY,
            layer=[1, 1, 1],
            start_date="202504",
            end_date="202509",
        )
        assert resp.result.status == 200
        assert len(resp.series) == 1
        assert resp.series[0].series_code == "BPBP6JYNCB"
        client.close()

    def test_layer_param_formatting(self, layer_api_success_payload: Dict[str, Any]) -> None:
        client = self._setup_client(layer_api_success_payload)
        client.get_data_by_layer(
            db=Database.BP01,
            frequency=Frequency.MONTHLY,
            layer=[1, 1, "*"],
        )
        call_args = client._session.get.call_args
        assert call_args[1]["params"]["layer"] == "1,1,*"
        client.close()

    def test_wildcard_layer(self, layer_api_success_payload: Dict[str, Any]) -> None:
        client = self._setup_client(layer_api_success_payload)
        client.get_data_by_layer(
            db=Database.MD10,
            frequency=Frequency.QUARTERLY,
            layer=["*"],
        )
        call_args = client._session.get.call_args
        assert call_args[1]["params"]["layer"] == "*"
        client.close()

    def test_with_string_frequency(self, layer_api_success_payload: Dict[str, Any]) -> None:
        client = self._setup_client(layer_api_success_payload)
        client.get_data_by_layer(
            db=Database.BP01,
            frequency="M",
            layer=[1],
        )
        call_args = client._session.get.call_args
        assert call_args[1]["params"]["frequency"] == "M"
        client.close()

    def test_start_position(self, layer_api_success_payload: Dict[str, Any]) -> None:
        """Explicit start_position is forwarded to the API."""
        client = self._setup_client(layer_api_success_payload)
        client.get_data_by_layer(
            db=Database.BP01,
            frequency=Frequency.MONTHLY,
            layer=[1],
            start_position=100,
        )
        call_args = client._session.get.call_args
        assert call_args[1]["params"]["startPosition"] == "100"
        client.close()

    def test_auto_paginate(
        self,
        code_api_paginated_page1: Dict[str, Any],
        code_api_paginated_page2: Dict[str, Any],
    ) -> None:
        """Layer API auto-pagination follows NEXTPOSITION until exhausted."""
        # Re-use the code API paginated fixtures — the response shape is
        # identical for both Code and Layer APIs.
        client = self._setup_client([code_api_paginated_page1, code_api_paginated_page2])
        resp = client.get_data_by_layer(
            db=Database.BP01,
            frequency=Frequency.MONTHLY,
            layer=[1],
            auto_paginate=True,
        )
        assert resp.next_position is None
        assert len(resp.series) == 2
        assert client._session.get.call_count == 2
        client.close()


class TestGetMetadata:
    """Tests for :meth:`BOJClient.get_metadata`."""

    def _setup_client(self, payload: Dict[str, Any]) -> BOJClient:
        client = BOJClient(max_retries=1, retry_delay=0.0)
        mock_session = MagicMock()
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = payload
        mock_resp.text = str(payload)
        mock_session.get.return_value = mock_resp
        client._session = mock_session
        return client

    def test_basic_call(self, metadata_api_success_payload: Dict[str, Any]) -> None:
        client = self._setup_client(metadata_api_success_payload)
        resp = client.get_metadata(db=Database.FM08)
        assert resp.result.status == 200
        assert resp.db == "FM08"
        assert len(resp.entries) == 2
        assert resp.entries[0].series_code == "FXERD01"
        assert resp.entries[0].name_jp == "Tokyo USD/JPY Spot 9:00"
        assert resp.entries[0].frequency == "DAILY"
        assert resp.entries[0].start_of_series == "19990101"
        client.close()

    def test_lang_override(self, metadata_api_success_payload: Dict[str, Any]) -> None:
        client = self._setup_client(metadata_api_success_payload)
        client.get_metadata(db=Database.FM08, lang=Language.EN)
        call_args = client._session.get.call_args
        assert call_args[1]["params"]["lang"] == "en"
        client.close()

    def test_error_400(self, error_400_payload: Dict[str, Any]) -> None:
        client = self._setup_client(error_400_payload)
        with pytest.raises(InvalidParameterError):
            client.get_metadata(db="INVALID")
        client.close()


class TestCheckApiStatus:
    """Tests for :meth:`BOJClient._check_api_status`."""

    def test_200_does_not_raise(self) -> None:
        payload = {"STATUS": 200, "MESSAGEID": "M181000I", "MESSAGE": "OK"}
        BOJClient._check_api_status(payload)  # Should not raise

    def test_400_raises(self) -> None:
        payload = {"STATUS": 400, "MESSAGEID": "M181005E", "MESSAGE": "Bad"}
        with pytest.raises(InvalidParameterError):
            BOJClient._check_api_status(payload)

    def test_500_raises(self) -> None:
        payload = {"STATUS": 500, "MESSAGEID": "M181090S", "MESSAGE": "Error"}
        with pytest.raises(ServerError):
            BOJClient._check_api_status(payload)

    def test_503_raises(self) -> None:
        payload = {"STATUS": 503, "MESSAGEID": "M181091S", "MESSAGE": "DB Error"}
        with pytest.raises(DatabaseAccessError):
            BOJClient._check_api_status(payload)

    def test_missing_status_field(self) -> None:
        # Defaults to 200, should not raise
        BOJClient._check_api_status({})
