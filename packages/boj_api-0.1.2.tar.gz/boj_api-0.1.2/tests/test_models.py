"""Tests for boj_api.models."""

from boj_api.models import (
    DataResponse,
    MetadataEntry,
    MetadataResponse,
    Observation,
    ParameterInfo,
    ResultInfo,
    Series,
)


class TestResultInfo:
    """Tests for :class:`ResultInfo`."""

    def test_construction(self) -> None:
        info = ResultInfo(
            status=200,
            message_id="M181000I",
            message="OK",
            date="2026-01-01T00:00:00",
        )
        assert info.status == 200
        assert info.message_id == "M181000I"
        assert info.message == "OK"
        assert info.date == "2026-01-01T00:00:00"

    def test_error_status(self) -> None:
        info = ResultInfo(status=400, message_id="M181005E", message="Bad", date="")
        assert info.status == 400


class TestParameterInfo:
    """Tests for :class:`ParameterInfo`."""

    def test_defaults_are_none(self) -> None:
        p = ParameterInfo()
        assert p.format is None
        assert p.lang is None
        assert p.db is None
        assert p.layer1 is None
        assert p.layer5 is None
        assert p.frequency is None
        assert p.start_date is None
        assert p.end_date is None
        assert p.start_position is None

    def test_partial_construction(self) -> None:
        p = ParameterInfo(format="json", db="CO", start_date="202401")
        assert p.format == "json"
        assert p.db == "CO"
        assert p.start_date == "202401"
        assert p.lang is None


class TestObservation:
    """Tests for :class:`Observation`."""

    def test_with_value(self) -> None:
        obs = Observation(date="202401", value="12.5")
        assert obs.date == "202401"
        assert obs.value == "12.5"

    def test_null_value(self) -> None:
        obs = Observation(date="202402")
        assert obs.value is None

    def test_explicit_none(self) -> None:
        obs = Observation(date="202403", value=None)
        assert obs.value is None


class TestSeries:
    """Tests for :class:`Series`."""

    def test_minimal(self) -> None:
        s = Series(series_code="ABC123")
        assert s.series_code == "ABC123"
        assert s.observations == []
        assert s.name_jp is None
        assert s.name_en is None

    def test_with_observations(self) -> None:
        obs = [Observation("202401", "1"), Observation("202402", "2")]
        s = Series(series_code="XYZ", observations=obs)
        assert len(s.observations) == 2
        assert s.observations[0].value == "1"

    def test_full_fields(self) -> None:
        s = Series(
            series_code="S1",
            name_jp="テスト",
            name_en="Test",
            unit_jp="円",
            unit_en="JPY",
            frequency="MONTHLY",
            category_jp="テスト分類",
            category_en="Test Category",
            last_update="20260101",
        )
        assert s.name_jp == "テスト"
        assert s.unit_en == "JPY"
        assert s.last_update == "20260101"


class TestDataResponse:
    """Tests for :class:`DataResponse`."""

    def test_empty_response(self) -> None:
        result = ResultInfo(status=200, message_id="M181030I", message="OK", date="")
        resp = DataResponse(
            result=result,
            parameters=ParameterInfo(),
        )
        assert resp.series == []
        assert resp.next_position is None
        assert resp.raw == {}

    def test_with_series(self) -> None:
        result = ResultInfo(status=200, message_id="M181000I", message="OK", date="")
        s = Series(
            series_code="A",
            observations=[Observation("202401", "10")],
        )
        resp = DataResponse(
            result=result,
            parameters=ParameterInfo(db="CO"),
            series=[s],
            next_position=160,
            raw={"key": "value"},
        )
        assert len(resp.series) == 1
        assert resp.next_position == 160
        assert resp.raw == {"key": "value"}


class TestMetadataEntry:
    """Tests for :class:`MetadataEntry`."""

    def test_defaults(self) -> None:
        entry = MetadataEntry()
        assert entry.series_code is None
        assert entry.layer1 is None
        assert entry.start_of_series is None

    def test_full(self) -> None:
        entry = MetadataEntry(
            series_code="FXERD01",
            name_jp="ドル円",
            frequency="DAILY",
            layer1=1,
            layer2=1,
            start_of_series="19990101",
            end_of_series="20260219",
        )
        assert entry.series_code == "FXERD01"
        assert entry.start_of_series == "19990101"


class TestMetadataResponse:
    """Tests for :class:`MetadataResponse`."""

    def test_empty(self) -> None:
        result = ResultInfo(status=200, message_id="M181000I", message="OK", date="")
        resp = MetadataResponse(result=result, db="FM08")
        assert resp.entries == []
        assert resp.db == "FM08"

    def test_with_entries(self) -> None:
        result = ResultInfo(status=200, message_id="M181000I", message="OK", date="")
        entries = [
            MetadataEntry(series_code="A"),
            MetadataEntry(series_code="B"),
        ]
        resp = MetadataResponse(result=result, db="FM08", entries=entries)
        assert len(resp.entries) == 2
