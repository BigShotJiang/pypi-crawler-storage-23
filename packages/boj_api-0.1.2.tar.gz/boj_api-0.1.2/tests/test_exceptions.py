"""Tests for boj_api.exceptions."""

import pytest

from boj_api.exceptions import (
    BOJAPIError,
    DatabaseAccessError,
    InvalidParameterError,
    RateLimitError,
    ResponseParseError,
    ServerError,
)


class TestBOJAPIError:
    """Test the base exception and its attributes."""

    def test_basic_construction(self) -> None:
        exc = BOJAPIError("something went wrong")
        assert str(exc) == "something went wrong"
        assert exc.status is None
        assert exc.message_id is None
        assert exc.api_message is None

    def test_full_construction(self) -> None:
        exc = BOJAPIError(
            "Bad request",
            status=400,
            message_id="M181005E",
            api_message="DB名が正しくありません。",
        )
        assert exc.status == 400
        assert exc.message_id == "M181005E"
        assert exc.api_message == "DB名が正しくありません。"

    def test_is_exception(self) -> None:
        assert issubclass(BOJAPIError, Exception)


class TestInheritance:
    """Verify that all subclasses inherit from BOJAPIError."""

    @pytest.mark.parametrize(
        "cls",
        [
            InvalidParameterError,
            ServerError,
            DatabaseAccessError,
            RateLimitError,
            ResponseParseError,
        ],
    )
    def test_subclass_of_boj_api_error(self, cls: type) -> None:
        assert issubclass(cls, BOJAPIError)

    @pytest.mark.parametrize(
        "cls",
        [
            InvalidParameterError,
            ServerError,
            DatabaseAccessError,
            RateLimitError,
            ResponseParseError,
        ],
    )
    def test_subclass_of_exception(self, cls: type) -> None:
        assert issubclass(cls, Exception)


class TestExceptionAttributes:
    """Test that subclasses preserve all attributes."""

    def test_invalid_parameter_error(self) -> None:
        exc = InvalidParameterError(
            "bad param",
            status=400,
            message_id="M181001E",
            api_message="Invalid input parameters",
        )
        assert exc.status == 400
        assert exc.message_id == "M181001E"

    def test_server_error(self) -> None:
        exc = ServerError("server down", status=500, message_id="M181090S")
        assert exc.status == 500

    def test_database_access_error(self) -> None:
        exc = DatabaseAccessError("db error", status=503, message_id="M181091S")
        assert exc.status == 503

    def test_rate_limit_error(self) -> None:
        exc = RateLimitError("too fast")
        assert str(exc) == "too fast"

    def test_response_parse_error(self) -> None:
        exc = ResponseParseError("bad json", api_message="<html>...")
        assert exc.api_message == "<html>..."


class TestExceptionCatching:
    """Verify catch-by-base-class works."""

    def test_catch_invalid_parameter_as_base(self) -> None:
        with pytest.raises(BOJAPIError):
            raise InvalidParameterError("test", status=400)

    def test_catch_server_error_as_base(self) -> None:
        with pytest.raises(BOJAPIError):
            raise ServerError("test", status=500)

    def test_catch_database_access_as_base(self) -> None:
        with pytest.raises(BOJAPIError):
            raise DatabaseAccessError("test", status=503)
