"""Tests for boj_api.enums."""

import pytest

from boj_api.enums import Database, Format, Frequency, Language


class TestDatabase:
    """Tests for :class:`Database`."""

    def test_all_members_are_strings(self) -> None:
        for member in Database:
            assert isinstance(member.value, str)
            assert len(member.value) > 0

    def test_known_databases(self) -> None:
        assert Database.IR01.value == "IR01"
        assert Database.FM08.value == "FM08"
        assert Database.CO.value == "CO"
        assert Database.FF.value == "FF"
        assert Database.BP01.value == "BP01"
        assert Database.BIS.value == "BIS"
        assert Database.OT.value == "OT"

    def test_str_enum_behavior(self) -> None:
        # Database members should be usable as plain strings
        assert Database.FM08 == "FM08"
        assert Database.FM08.value == "FM08"

    def test_all_databases(self) -> None:
        # Verify complete coverage of all BOJ databases (50 DB codes)
        expected_count = 50
        assert len(Database) == expected_count

    def test_lookup_by_value(self) -> None:
        assert Database("IR01") is Database.IR01
        assert Database("CO") is Database.CO

    def test_invalid_value_raises(self) -> None:
        with pytest.raises(ValueError):
            Database("INVALID_DB")


class TestFormat:
    """Tests for :class:`Format`."""

    def test_json(self) -> None:
        assert Format.JSON.value == "json"

    def test_csv(self) -> None:
        assert Format.CSV.value == "csv"

    def test_only_two_members(self) -> None:
        assert len(Format) == 2

    def test_str_enum(self) -> None:
        assert Format.JSON == "json"


class TestLanguage:
    """Tests for :class:`Language`."""

    def test_jp(self) -> None:
        assert Language.JP.value == "jp"

    def test_en(self) -> None:
        assert Language.EN.value == "en"

    def test_only_two_members(self) -> None:
        assert len(Language) == 2


class TestFrequency:
    """Tests for :class:`Frequency`."""

    def test_all_values(self) -> None:
        expected = {
            "CY": Frequency.CALENDAR_YEAR,
            "FY": Frequency.FISCAL_YEAR,
            "CH": Frequency.SEMI_ANNUAL_CY,
            "FH": Frequency.SEMI_ANNUAL_FY,
            "Q": Frequency.QUARTERLY,
            "M": Frequency.MONTHLY,
            "W": Frequency.WEEKLY,
            "D": Frequency.DAILY,
        }
        for code, member in expected.items():
            assert member.value == code

    def test_count(self) -> None:
        assert len(Frequency) == 8

    def test_str_enum(self) -> None:
        assert Frequency.MONTHLY == "M"
        assert Frequency.QUARTERLY.value == "Q"

    def test_lookup_by_value(self) -> None:
        assert Frequency("M") is Frequency.MONTHLY
        assert Frequency("D") is Frequency.DAILY

    def test_invalid_raises(self) -> None:
        with pytest.raises(ValueError):
            Frequency("X")
