#!/usr/bin/env python3
"""Probe date param format across different frequencies."""
import requests

def probe(db, code, sd, ed):
    r = requests.get(
        "https://www.stat-search.boj.or.jp/api/v1/getDataCode",
        params={"db": db, "code": code, "format": "json", "lang": "jp",
                "startDate": sd, "endDate": ed},
    )
    d = r.json()
    status = d["STATUS"]
    msg = d.get("MESSAGE", "")[:60]
    count = 0
    rs = d.get("RESULTSET", [])
    if rs and isinstance(rs, list) and isinstance(rs[0], dict):
        count = len(rs[0].get("VALUES", {}).get("SURVEY_DATES", []))
    return status, count, msg

# Daily (FM08) — YYYYMM works
print("=== DAILY (FM08/FXERD01) ===")
for sd, ed in [("202602", "202602"), ("20260201", "20260210")]:
    s, c, m = probe("FM08", "FXERD01", sd, ed)
    print(f"  {sd!r:14} -> {s} obs={c} {m}")

# Monthly (BP01 via code) — what format?
print("\n=== MONTHLY (MD01) ===")
# MD01: Monetary base - try to find a code
import time
r = requests.get("https://www.stat-search.boj.or.jp/api/v1/getMetadata",
    params={"db": "MD01", "format": "json", "lang": "jp"})
meta = r.json()
codes = [e["SERIES_CODE"] for e in meta.get("RESULTSET", []) if e.get("SERIES_CODE") and e.get("FREQUENCY") == "MONTHLY"]
if codes:
    c0 = codes[0]
    print(f"  Using code: {c0}")
    time.sleep(0.5)
    for sd, ed in [("202401", "202412"), ("20240101", "20241231")]:
        s, c, m = probe("MD01", c0, sd, ed)
        print(f"  {sd!r:14} -> {s} obs={c} {m}")

# Quarterly (CO) — what format?
print("\n=== QUARTERLY (CO) ===")
time.sleep(0.5)
for sd, ed in [("202401", "202504"), ("2024Q1", "2025Q4"), ("20240101", "20250401")]:
    s, c, m = probe("CO", "TK99F0000601GCQ00000", sd, ed)
    print(f"  {sd!r:14} -> {s} obs={c} {m}")

# Yearly (try IR01)
print("\n=== ANNUAL (IR01) ===")
time.sleep(0.5)
r = requests.get("https://www.stat-search.boj.or.jp/api/v1/getMetadata",
    params={"db": "IR01", "format": "json", "lang": "jp"})
meta = r.json()
codes_cy = [e["SERIES_CODE"] for e in meta.get("RESULTSET", []) if e.get("SERIES_CODE") and "CALENDAR" in str(e.get("FREQUENCY", ""))]
codes_any = [e["SERIES_CODE"] for e in meta.get("RESULTSET", []) if e.get("SERIES_CODE")]
print(f"  CY codes: {codes_cy[:3]}, any codes: {codes_any[:3]}")
if codes_any:
    c0 = codes_any[0]
    time.sleep(0.5)
    for sd, ed in [("2024", "2025"), ("202401", "202512")]:
        s, c, m = probe("IR01", c0, sd, ed)
        print(f"  {sd!r:14} -> {s} obs={c} {m}")
