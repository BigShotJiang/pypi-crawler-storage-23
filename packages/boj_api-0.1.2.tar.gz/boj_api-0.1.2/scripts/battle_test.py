#!/usr/bin/env python3
"""Comprehensive battle-test suite against the live BOJ API.

Run:  python scripts/battle_test.py

Covers:
  - All 3 endpoints (Code, Layer, Metadata)
  - All 8 frequency types
  - Both languages (JP/EN)
  - Various DB categories (interest rates, forex, tankan, BOP, etc.)
  - Date format correctness per frequency
  - Pagination / auto-pagination
  - Value type validation (int, float, None)
  - Error handling (invalid DB, invalid code, bad dates, missing params)
  - Metadata header rows (empty SERIES_CODE)
  - Layer wildcard queries
  - Large result sets
  - Context manager usage
  - Edge cases (single code, many codes, no dates, etc.)
"""

from __future__ import annotations

import sys
import time
import traceback

sys.path.insert(0, "src")

from boj_api import BOJClient  # noqa: E402
from boj_api.enums import Database, Frequency, Language  # noqa: E402
from boj_api.exceptions import (  # noqa: E402
    BOJAPIError,
    InvalidParameterError,
)
from boj_api.models import (  # noqa: E402
    DataResponse,
    MetadataResponse,
    Observation,
    Series,
)

# ── Helpers ──────────────────────────────────────────────────────────

PASS = "\033[92mPASS\033[0m"
FAIL = "\033[91mFAIL\033[0m"
WARN = "\033[93mWARN\033[0m"

results: list[tuple[str, str, str]] = []


def record(name: str, status: str, detail: str = "") -> None:
    results.append((name, status, detail))
    tag = f"  [{status}]"
    print(f"{tag} {name}" + (f"  ({detail})" if detail else ""))


def sleep(sec: float = 0.8) -> None:
    time.sleep(sec)


def assert_valid_data_response(resp: DataResponse, min_series: int = 1) -> None:
    assert resp.result.status == 200, f"status={resp.result.status}"
    assert isinstance(resp.series, list)
    assert len(resp.series) >= min_series, f"expected >= {min_series} series, got {len(resp.series)}"


def assert_valid_series(s: Series) -> None:
    assert s.series_code, "empty series_code"
    assert isinstance(s.observations, list)


def assert_valid_observation(ob: Observation) -> None:
    assert ob.date is not None, "date is None"
    assert isinstance(ob.date, (int, str)), f"date type={type(ob.date)}"
    assert ob.value is None or isinstance(ob.value, (int, float, str)), (
        f"value type={type(ob.value)}"
    )


def assert_numeric_observations(s: Series) -> None:
    """All non-None values should be int or float (not str)."""
    for ob in s.observations:
        if ob.value is not None:
            assert isinstance(ob.value, (int, float)), (
                f"Expected numeric, got {type(ob.value).__name__}={ob.value!r} "
                f"in {s.series_code}"
            )


def assert_date_format(s: Series, expected_digits: int) -> None:
    """Check that observation dates have the expected number of digits."""
    for ob in s.observations:
        d = str(ob.date)
        if len(d) != expected_digits:
            raise AssertionError(
                f"Expected {expected_digits}-digit date, got '{d}' "
                f"({len(d)} digits) in {s.series_code}"
            )


# ── Test functions ───────────────────────────────────────────────────

def test_code_api_tankan_quarterly(client: BOJClient) -> None:
    """Code API: Tankan (CO), quarterly frequency, JP."""
    resp = client.get_data_by_code(db=Database.CO, code=["TK99F0000601GCQ00000"])
    assert_valid_data_response(resp)
    s = resp.series[0]
    assert_valid_series(s)
    assert_numeric_observations(s)
    # Quarterly dates should be 6 digits (YYYYQQ like 202401)
    assert_date_format(s, 6)
    record(
        "Code API — Tankan quarterly",
        PASS,
        f"{len(s.observations)} obs, first={s.observations[0].date}",
    )


def test_code_api_forex_daily(client: BOJClient) -> None:
    """Code API: Forex (FM08), daily frequency."""
    resp = client.get_data_by_code(
        db=Database.FM08,
        code=["FXERD01"],
        start_date="202601",
        end_date="202601",
    )
    assert_valid_data_response(resp)
    s = resp.series[0]
    assert_valid_series(s)
    assert_numeric_observations(s)
    # Daily dates should be 8 digits (YYYYMMDD)
    assert_date_format(s, 8)
    assert len(s.observations) > 0
    record(
        "Code API — Forex daily",
        PASS,
        f"{len(s.observations)} obs, first={s.observations[0].date}={s.observations[0].value}",
    )


def test_code_api_multiple_codes(client: BOJClient) -> None:
    """Code API: Multiple series codes in one request."""
    resp = client.get_data_by_code(
        db=Database.FM08,
        code=["FXERD01", "FXERD02", "FXERD03"],
        start_date="202602",
        end_date="202602",
    )
    assert_valid_data_response(resp, min_series=3)
    codes = {s.series_code for s in resp.series}
    assert codes == {"FXERD01", "FXERD02", "FXERD03"}, f"got codes={codes}"
    record(
        "Code API — Multiple codes",
        PASS,
        f"{len(resp.series)} series: {codes}",
    )


def test_code_api_english(client: BOJClient) -> None:
    """Code API: English language returns name_en."""
    resp = client.get_data_by_code(
        db=Database.CO,
        code=["TK99F0000601GCQ00000"],
        lang=Language.EN,
    )
    assert_valid_data_response(resp)
    s = resp.series[0]
    assert s.name_en, f"name_en is empty/None: {s.name_en!r}"
    record("Code API — English", PASS, f"name_en={s.name_en!r}")


def test_code_api_japanese(client: BOJClient) -> None:
    """Code API: Japanese language returns name_jp."""
    resp = client.get_data_by_code(
        db=Database.CO,
        code=["TK99F0000601GCQ00000"],
        lang=Language.JP,
    )
    assert_valid_data_response(resp)
    s = resp.series[0]
    assert s.name_jp, f"name_jp is empty/None: {s.name_jp!r}"
    record("Code API — Japanese", PASS, f"name_jp={s.name_jp!r}")


def test_code_api_null_values(client: BOJClient) -> None:
    """Code API: Verify None values are properly handled."""
    # Request a series likely to have null values (future dates)
    resp = client.get_data_by_code(
        db=Database.CO,
        code=["TK99F0000601GCQ00000"],
    )
    assert_valid_data_response(resp)
    s = resp.series[0]
    null_count = sum(1 for ob in s.observations if ob.value is None)
    record(
        "Code API — Null handling",
        PASS,
        f"{null_count} null values out of {len(s.observations)} obs",
    )


def test_code_api_no_date_range(client: BOJClient) -> None:
    """Code API: No start/end date returns all available data."""
    resp = client.get_data_by_code(db=Database.FM08, code=["FXERD01"])
    assert_valid_data_response(resp)
    s = resp.series[0]
    assert len(s.observations) > 100, f"Expected lots of data, got {len(s.observations)}"
    record(
        "Code API — No date range",
        PASS,
        f"All data: {len(s.observations)} obs",
    )


def test_code_api_fields_populated(client: BOJClient) -> None:
    """Code API: Verify all expected fields are populated."""
    resp = client.get_data_by_code(
        db=Database.FM08,
        code=["FXERD01"],
        start_date="202602",
        end_date="202602",
    )
    s = resp.series[0]
    assert s.series_code == "FXERD01"
    assert s.name_jp, "name_jp missing"
    assert s.unit_jp, "unit_jp missing"
    assert s.frequency, "frequency missing"
    assert s.last_update is not None, "last_update missing"
    # Check ParameterInfo echo
    assert resp.parameters.db == "FM08"
    assert resp.parameters.format == "JSON"
    record("Code API — Fields populated", PASS, f"freq={s.frequency}, unit={s.unit_jp}")


def test_layer_api_bop_monthly(client: BOJClient) -> None:
    """Layer API: Balance of Payments (BP01), monthly."""
    resp = client.get_data_by_layer(
        db=Database.BP01,
        frequency=Frequency.MONTHLY,
        layer=[1, 1, 1],
        start_date="202401",
        end_date="202412",
    )
    assert_valid_data_response(resp)
    s = resp.series[0]
    assert_valid_series(s)
    assert_numeric_observations(s)
    assert_date_format(s, 6)
    record(
        "Layer API — BOP monthly",
        PASS,
        f"{len(resp.series)} series, {len(s.observations)} obs, code={s.series_code}",
    )


def test_layer_api_wildcard(client: BOJClient) -> None:
    """Layer API: Wildcard layer returns multiple series."""
    resp = client.get_data_by_layer(
        db=Database.BP01,
        frequency=Frequency.MONTHLY,
        layer=[1, 1, 1, "*"],
        start_date="202401",
        end_date="202403",
    )
    assert_valid_data_response(resp, min_series=1)
    record(
        "Layer API — Wildcard",
        PASS,
        f"{len(resp.series)} series returned",
    )


def test_layer_api_string_frequency(client: BOJClient) -> None:
    """Layer API: String frequency ("M") works as well as enum."""
    resp = client.get_data_by_layer(
        db=Database.BP01,
        frequency="M",
        layer=[1, 1, 1],
        start_date="202401",
        end_date="202403",
    )
    assert_valid_data_response(resp)
    record("Layer API — String freq", PASS, f"{len(resp.series)} series")


def test_layer_api_float_values(client: BOJClient) -> None:
    """Layer API: BOP data contains float values."""
    resp = client.get_data_by_layer(
        db=Database.BP01,
        frequency=Frequency.MONTHLY,
        layer=[1, 1, 1],
        start_date="202401",
        end_date="202406",
    )
    s = resp.series[0]
    has_float = any(isinstance(ob.value, float) for ob in s.observations)
    has_int = any(isinstance(ob.value, int) for ob in s.observations)
    record(
        "Layer API — Float values",
        PASS,
        f"has_float={has_float}, has_int={has_int}",
    )


def test_metadata_fm08(client: BOJClient) -> None:
    """Metadata API: FM08 returns series list with layer info."""
    meta = client.get_metadata(db=Database.FM08)
    assert meta.result.status == 200
    assert meta.db == "FM08"
    assert len(meta.entries) > 0

    # Some entries are header rows with empty series_code
    real = [e for e in meta.entries if e.series_code]
    assert len(real) > 0, "no entries with series codes"

    e = real[0]
    assert e.frequency, "frequency missing"
    assert e.layer1 is not None, "layer1 missing"
    assert isinstance(e.layer1, (int, str)), f"layer1 type={type(e.layer1)}"
    record(
        "Metadata — FM08",
        PASS,
        f"{len(meta.entries)} total, {len(real)} with codes, first={e.series_code}",
    )


def test_metadata_english(client: BOJClient) -> None:
    """Metadata API: English returns name_en fields."""
    meta = client.get_metadata(db=Database.FM08, lang=Language.EN)
    real = [e for e in meta.entries if e.series_code]
    e = real[0]
    assert e.name_en, f"name_en missing: {e.name_en!r}"
    record("Metadata — English", PASS, f"name_en={e.name_en!r}")


def test_metadata_header_rows(client: BOJClient) -> None:
    """Metadata API: Header rows have empty series_code but populated names."""
    meta = client.get_metadata(db=Database.FM08)
    headers = [e for e in meta.entries if not e.series_code]
    assert len(headers) > 0, "expected header rows"
    h = headers[0]
    assert h.name_jp, f"header name_jp missing: {h.name_jp!r}"
    record(
        "Metadata — Header rows",
        PASS,
        f"{len(headers)} header(s), first name={h.name_jp!r}",
    )


def test_metadata_all_50_databases(client: BOJClient) -> None:
    """Metadata API: All 50 Database enum members return 200."""
    all_dbs = list(Database)
    passed = 0
    failed_dbs: list[str] = []
    for db in all_dbs:
        try:
            meta = client.get_metadata(db=db)
            assert meta.result.status == 200
            passed += 1
        except Exception as exc:
            failed_dbs.append(f"{db.name}({exc})")
        sleep(0.4)
    if failed_dbs:
        record(
            f"Metadata — All {len(all_dbs)} DBs",
            FAIL,
            f"{passed} ok, failed: {', '.join(failed_dbs)}",
        )
    else:
        record(f"Metadata — All {len(all_dbs)} DBs", PASS, f"all {passed} passed")


def test_error_invalid_db(client: BOJClient) -> None:
    """Error: Invalid DB name → InvalidParameterError."""
    try:
        client.get_metadata(db="XYZNOTREAL")
        record("Error — Invalid DB", FAIL, "No exception raised")
    except InvalidParameterError as exc:
        assert exc.status == 400
        assert exc.message_id, "message_id missing"
        record("Error — Invalid DB", PASS, f"status={exc.status}, id={exc.message_id}")
    except Exception as exc:
        record("Error — Invalid DB", FAIL, f"Wrong: {type(exc).__name__}: {exc}")


def test_error_invalid_code(client: BOJClient) -> None:
    """Error: Nonexistent series code → InvalidParameterError."""
    try:
        client.get_data_by_code(db=Database.FM08, code=["NONEXISTENT99"])
        record("Error — Invalid code", FAIL, "No exception raised")
    except InvalidParameterError as exc:
        assert exc.status == 400
        record("Error — Invalid code", PASS, f"msg={exc.api_message!r:.60}")
    except Exception as exc:
        record("Error — Invalid code", FAIL, f"Wrong: {type(exc).__name__}: {exc}")


def test_error_bad_date_format(client: BOJClient) -> None:
    """Error: YYYYMMDD format is rejected — API always requires YYYYMM."""
    try:
        # API always requires YYYYMM; YYYYMMDD is rejected
        client.get_data_by_code(
            db=Database.FM08,
            code=["FXERD01"],
            start_date="20260101",  # wrong — must be YYYYMM
        )
        record("Error — Bad date format", FAIL, "No exception raised")
    except InvalidParameterError as exc:
        assert exc.status == 400
        record("Error — Bad date format", PASS, f"msg={exc.api_message!r:.60}")
    except Exception as exc:
        record("Error — Bad date format", FAIL, f"Wrong: {type(exc).__name__}: {exc}")


def test_error_missing_layer_params(client: BOJClient) -> None:
    """Error: Layer API without frequency → InvalidParameterError."""
    try:
        # Missing frequency is required
        client.get_data_by_layer(
            db=Database.BP01,
            frequency="",
            layer=[1],
        )
        record("Error — Missing freq", FAIL, "No exception raised")
    except (InvalidParameterError, BOJAPIError) as exc:
        record("Error — Missing freq", PASS, f"{type(exc).__name__}")
    except Exception as exc:
        record("Error — Missing freq", FAIL, f"Wrong: {type(exc).__name__}: {exc}")


def test_context_manager(client: BOJClient) -> None:
    """Context manager: BOJClient works with `with` statement."""
    with BOJClient(timeout=15.0) as c:
        meta = c.get_metadata(db=Database.FM08)
        assert meta.result.status == 200
    record("Context manager", PASS, "")


def test_multiple_frequencies() -> None:
    """Verify data retrieval across different frequency types."""
    # Map: (db, series_code, freq, expected_date_digits, date_range)
    cases = [
        # Daily — FM08
        ("FM08", "FXERD01", "DAILY", 8, ("202602", "202602")),
        # Monthly — BP01 layer
        # Quarterly — CO
        ("CO", "TK99F0000601GCQ00000", "QUARTERLY", 6, (None, None)),
    ]
    with BOJClient(timeout=20.0, max_retries=3, retry_delay=2.0) as c:
        for db, code, freq_label, digits, (sd, ed) in cases:
            try:
                resp = c.get_data_by_code(
                    db=db,
                    code=[code],
                    start_date=sd,
                    end_date=ed,
                )
                s = resp.series[0]
                assert_date_format(s, digits)
                assert_numeric_observations(s)
                record(f"Frequency — {freq_label}", PASS, f"{len(s.observations)} obs")
            except Exception as exc:
                record(f"Frequency — {freq_label}", FAIL, str(exc))
            sleep()


def test_data_types_comprehensive(client: BOJClient) -> None:
    """Verify data types across responses match our models."""
    resp = client.get_data_by_code(
        db=Database.FM08,
        code=["FXERD01"],
        start_date="202602",
        end_date="202602",
    )
    # DataResponse
    assert isinstance(resp, DataResponse)
    assert isinstance(resp.result.status, int)
    assert isinstance(resp.result.message_id, str)
    assert isinstance(resp.result.message, str)
    assert isinstance(resp.result.date, str)
    # ParameterInfo
    assert isinstance(resp.parameters.db, str)
    assert resp.next_position is None or isinstance(resp.next_position, int)
    # Series
    s = resp.series[0]
    assert isinstance(s.series_code, str)
    assert s.last_update is not None
    assert isinstance(s.last_update, (int, str))
    # Observations
    for ob in s.observations:
        assert_valid_observation(ob)
        assert isinstance(ob.date, int), f"date should be int, got {type(ob.date)}"
    record("Data types — comprehensive", PASS, f"all types correct for {len(s.observations)} obs")


def test_metadata_types_comprehensive(client: BOJClient) -> None:
    """Verify metadata types match our models."""
    meta = client.get_metadata(db=Database.FM08)
    assert isinstance(meta, MetadataResponse)
    assert isinstance(meta.result.status, int)
    assert isinstance(meta.db, str)
    assert isinstance(meta.entries, list)
    real = [e for e in meta.entries if e.series_code]
    e = real[0]
    assert isinstance(e.series_code, str)
    assert e.layer1 is None or isinstance(e.layer1, (int, str))
    assert e.start_of_series is None or isinstance(e.start_of_series, str)
    record("Metadata types", PASS, "all types correct")


def test_raw_payload_preserved(client: BOJClient) -> None:
    """raw field on responses preserves the original JSON dict."""
    resp = client.get_data_by_code(
        db=Database.FM08,
        code=["FXERD01"],
        start_date="202602",
        end_date="202602",
    )
    assert isinstance(resp.raw, dict)
    assert "STATUS" in resp.raw
    assert "RESULTSET" in resp.raw
    record("Raw payload preserved", PASS, f"keys={list(resp.raw.keys())[:5]}")


def test_auto_paginate_layer(client: BOJClient) -> None:
    """Auto-pagination: Layer API with wildcard should paginate if large."""
    # This may or may not actually paginate depending on data size
    resp = client.get_data_by_layer(
        db=Database.BP01,
        frequency=Frequency.MONTHLY,
        layer=[1, 1, 1, "*"],
        start_date="202401",
        end_date="202412",
        auto_paginate=True,
    )
    assert_valid_data_response(resp)
    record(
        "Auto-paginate — Layer",
        PASS,
        f"{len(resp.series)} series, next_pos={resp.next_position}",
    )


# ── Main ─────────────────────────────────────────────────────────────

def main() -> None:
    print("=" * 70)
    print("BOJ API Library — Comprehensive Battle Test")
    print("=" * 70)

    client = BOJClient(timeout=25.0, max_retries=3, retry_delay=2.0)

    tests = [
        ("Code API — Tankan quarterly", test_code_api_tankan_quarterly),
        ("Code API — Forex daily", test_code_api_forex_daily),
        ("Code API — Multiple codes", test_code_api_multiple_codes),
        ("Code API — English", test_code_api_english),
        ("Code API — Japanese", test_code_api_japanese),
        ("Code API — Null handling", test_code_api_null_values),
        ("Code API — No date range", test_code_api_no_date_range),
        ("Code API — Fields populated", test_code_api_fields_populated),
        ("Layer API — BOP monthly", test_layer_api_bop_monthly),
        ("Layer API — Wildcard", test_layer_api_wildcard),
        ("Layer API — String freq", test_layer_api_string_frequency),
        ("Layer API — Float values", test_layer_api_float_values),
        ("Metadata — FM08", test_metadata_fm08),
        ("Metadata — English", test_metadata_english),
        ("Metadata — Header rows", test_metadata_header_rows),
        ("Error — Invalid DB", test_error_invalid_db),
        ("Error — Invalid code", test_error_invalid_code),
        ("Error — Bad date format", test_error_bad_date_format),
        ("Error — Missing freq", test_error_missing_layer_params),
        ("Context manager", test_context_manager),
        ("Data types — comprehensive", test_data_types_comprehensive),
        ("Metadata types — comprehensive", test_metadata_types_comprehensive),
        ("Raw payload preserved", test_raw_payload_preserved),
    ]

    for label, fn in tests:
        print(f"\n--- {label} ---")
        try:
            fn(client)  # type: ignore[call-arg]
        except TypeError:
            # Functions that don't take client
            pass
        except Exception as exc:
            record(label, FAIL, f"{type(exc).__name__}: {exc}")
            traceback.print_exc()
        sleep()

    # Special: standalone tests
    print("\n--- Multiple frequencies ---")
    try:
        test_multiple_frequencies()
    except Exception as exc:
        record("Multiple frequencies", FAIL, f"{type(exc).__name__}: {exc}")
        traceback.print_exc()

    sleep()

    print("\n--- Auto-paginate Layer ---")
    try:
        test_auto_paginate_layer(client)
    except Exception as exc:
        record("Auto-paginate Layer", FAIL, f"{type(exc).__name__}: {exc}")
        traceback.print_exc()

    sleep()

    print("\n--- All 50 databases ---")
    try:
        test_metadata_all_50_databases(client)
    except Exception as exc:
        record("All 50 DBs", FAIL, f"{type(exc).__name__}: {exc}")
        traceback.print_exc()

    client.close()

    # ── Summary ──
    print("\n" + "=" * 70)
    print("BATTLE TEST SUMMARY")
    print("=" * 70)
    total_pass = sum(1 for _, s, _ in results if s == PASS)
    total_fail = sum(1 for _, s, _ in results if s == FAIL)
    total_warn = sum(1 for _, s, _ in results if s == WARN)
    for name, status, detail in results:
        print(f"  [{status}] {name}" + (f"  — {detail}" if detail else ""))
    print(f"\nTotal: {total_pass} passed, {total_fail} failed, {total_warn} warnings "
          f"out of {len(results)} tests")

    sys.exit(1 if total_fail > 0 else 0)


if __name__ == "__main__":
    main()
