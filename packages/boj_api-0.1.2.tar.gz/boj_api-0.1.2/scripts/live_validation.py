#!/usr/bin/env python3
"""Live validation script — tests the boj_api library against the real BOJ API.

Run:  python scripts/live_validation.py

Tests:
  1. get_data_by_code  (CO database, Tankan)
  2. get_data_by_layer (BP01, Balance of Payments)
  3. get_metadata      (FM08, Forex)
  4. get_metadata for ALL 50 Database enum members
  5. English language override
  6. Error handling (invalid DB)
"""

from __future__ import annotations

import sys
import time
import traceback

# Ensure the local src/ is on the path
sys.path.insert(0, "src")

from boj_api import BOJClient  # noqa: E402
from boj_api.enums import Database, Language  # noqa: E402
from boj_api.exceptions import InvalidParameterError  # noqa: E402

PASS = "\033[92mPASS\033[0m"
FAIL = "\033[91mFAIL\033[0m"
SKIP = "\033[93mSKIP\033[0m"

results: list[tuple[str, str, str]] = []


def record(name: str, status: str, detail: str = "") -> None:
    results.append((name, status, detail))
    print(f"  [{status}] {name}" + (f"  ({detail})" if detail else ""))


def main() -> None:
    print("=" * 60)
    print("BOJ API Library — Live Validation")
    print("=" * 60)

    with BOJClient(timeout=30.0, max_retries=3, retry_delay=2.0) as client:

        # ----------------------------------------------------------
        # Test 1 — get_data_by_code (Tankan, CO)
        # ----------------------------------------------------------
        print("\n--- Test 1: get_data_by_code (CO / Tankan) ---")
        try:
            resp = client.get_data_by_code(
                db=Database.CO,
                code=["TK99F0000601GCQ00000"],
            )
            assert resp.result.status == 200, f"status={resp.result.status}"
            assert len(resp.series) >= 1, "no series"
            s = resp.series[0]
            assert s.series_code == "TK99F0000601GCQ00000"
            assert len(s.observations) > 0, "no observations"
            ob = s.observations[0]
            assert isinstance(ob.date, int), f"date type={type(ob.date)}"
            assert ob.value is None or isinstance(ob.value, (int, float)), (
                f"value type={type(ob.value)}"
            )
            record(
                "get_data_by_code (CO)",
                PASS,
                f"{len(s.observations)} obs, first date={ob.date}, value={ob.value}",
            )
        except Exception as exc:
            record("get_data_by_code (CO)", FAIL, str(exc))
            traceback.print_exc()

        time.sleep(1)

        # ----------------------------------------------------------
        # Test 2 — get_data_by_layer (BP01)
        # ----------------------------------------------------------
        print("\n--- Test 2: get_data_by_layer (BP01 / Balance of Payments) ---")
        try:
            resp = client.get_data_by_layer(
                db=Database.BP01,
                frequency="M",
                layer=[1, 1, 1],
                start_date="202401",
                end_date="202412",
            )
            assert resp.result.status == 200, f"status={resp.result.status}"
            assert len(resp.series) >= 1, "no series"
            s = resp.series[0]
            assert len(s.observations) > 0
            ob = s.observations[0]
            assert isinstance(ob.date, int)
            assert ob.value is None or isinstance(ob.value, (int, float))
            record(
                "get_data_by_layer (BP01)",
                PASS,
                f"{len(resp.series)} series, {len(s.observations)} obs, code={s.series_code}",
            )
        except Exception as exc:
            record("get_data_by_layer (BP01)", FAIL, str(exc))
            traceback.print_exc()

        time.sleep(1)

        # ----------------------------------------------------------
        # Test 3 — get_metadata (FM08)
        # ----------------------------------------------------------
        print("\n--- Test 3: get_metadata (FM08 / Forex Rates) ---")
        try:
            meta = client.get_metadata(db=Database.FM08)
            assert meta.result.status == 200
            assert meta.db == "FM08"
            assert len(meta.entries) > 0, "no entries"
            # First entry may be a header row with empty SERIES_CODE.
            # Find the first real series entry.
            real_entries = [e for e in meta.entries if e.series_code]
            assert len(real_entries) > 0, "no real series entries"
            e = real_entries[0]
            assert e.frequency, "empty frequency"
            assert isinstance(e.layer1, (int, str, type(None)))
            record(
                "get_metadata (FM08)",
                PASS,
                f"{len(meta.entries)} entries ({len(real_entries)} with codes), first={e.series_code}",
            )
        except Exception as exc:
            record("get_metadata (FM08)", FAIL, str(exc))
            traceback.print_exc()

        time.sleep(1)

        # ----------------------------------------------------------
        # Test 4 — English language override
        # ----------------------------------------------------------
        print("\n--- Test 4: English language override ---")
        try:
            resp = client.get_data_by_code(
                db=Database.CO,
                code=["TK99F0000601GCQ00000"],
                lang=Language.EN,
            )
            s = resp.series[0]
            assert s.name_en or s.name_jp, "no name"
            record(
                "English override",
                PASS,
                f"name_en={s.name_en!r}",
            )
        except Exception as exc:
            record("English override", FAIL, str(exc))
            traceback.print_exc()

        time.sleep(1)

        # ----------------------------------------------------------
        # Test 5 — Error handling (invalid DB)
        # ----------------------------------------------------------
        print("\n--- Test 5: Error handling (invalid DB) ---")
        try:
            client.get_metadata(db="XYZNOTREAL")
            record("Error handling", FAIL, "No exception raised")
        except InvalidParameterError as exc:
            record(
                "Error handling",
                PASS,
                f"InvalidParameterError status={exc.status}, id={exc.message_id}",
            )
        except Exception as exc:
            record("Error handling", FAIL, f"Wrong exception: {type(exc).__name__}: {exc}")

        time.sleep(1)

        # ----------------------------------------------------------
        # Test 6 — get_metadata for ALL Database enum members
        # ----------------------------------------------------------
        print("\n--- Test 6: get_metadata for all 50 databases ---")
        all_dbs = list(Database)
        passed = 0
        failed = 0
        for db in all_dbs:
            try:
                meta = client.get_metadata(db=db)
                assert meta.result.status == 200
                passed += 1
            except Exception as exc:
                failed += 1
                print(f"    FAIL: {db.name} — {exc}")
            time.sleep(0.5)  # be polite to the server
        record(
            f"All DBs metadata ({len(all_dbs)} total)",
            PASS if failed == 0 else FAIL,
            f"{passed} passed, {failed} failed",
        )

    # ----------------------------------------------------------
    # Summary
    # ----------------------------------------------------------
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    total_pass = sum(1 for _, s, _ in results if s == PASS)
    total_fail = sum(1 for _, s, _ in results if s == FAIL)
    for name, status, detail in results:
        print(f"  [{status}] {name}" + (f"  — {detail}" if detail else ""))
    print(f"\nTotal: {total_pass} passed, {total_fail} failed out of {len(results)}")

    sys.exit(1 if total_fail > 0 else 0)


if __name__ == "__main__":
    main()
