"""Data models for BOJ API responses.

All models are plain :mod:`dataclasses` with full type annotations.
They mirror the JSON structure returned by the three BOJ API endpoints
(Code API, Layer API, Metadata API) and are constructed by
:class:`~boj_api.client.BOJClient` from raw response dictionaries.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union

# ---------------------------------------------------------------------------
# Shared / common models
# ---------------------------------------------------------------------------


@dataclass
class ResultInfo:
    """Processing result information returned by every API response.

    Attributes:
        status: API status code (``200`` = OK, ``400`` / ``500`` / ``503`` = error).
        message_id: BOJ message identifier (e.g. ``"M181000I"``).
        message: Human-readable message describing the result.
        date: Timestamp of the response (Japan time, ISO-ish string).

    Example::

        >>> info = ResultInfo(status=200, message_id="M181000I",
        ...                   message="正常に終了しました。", date="2026-02-18T09:00:00")
        >>> info.status
        200
    """

    status: int
    message_id: str
    message: str
    date: str


@dataclass
class ParameterInfo:
    """Echo of the request parameters as returned in data API responses.

    The fields correspond to the parameter tags in the JSON/CSV output.
    Fields that were not set in the request will be ``None``.

    Attributes:
        format: Requested output format (``"json"`` or ``"csv"``).
        lang: Requested language (``"jp"`` or ``"en"``).
        db: Database name code.
        layer1: Layer 1 value (Layer API only).
        layer2: Layer 2 value (Layer API only).
        layer3: Layer 3 value (Layer API only).
        layer4: Layer 4 value (Layer API only).
        layer5: Layer 5 value (Layer API only).
        frequency: Frequency abbreviation (Layer API only).
        start_date: Requested start period string.
        end_date: Requested end period string.
        start_position: Requested pagination start position.
    """

    format: Optional[str] = None
    lang: Optional[str] = None
    db: Optional[str] = None
    layer1: Optional[str] = None
    layer2: Optional[str] = None
    layer3: Optional[str] = None
    layer4: Optional[str] = None
    layer5: Optional[str] = None
    frequency: Optional[str] = None
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    start_position: Optional[int] = None


# ---------------------------------------------------------------------------
# Code API / Layer API response models
# ---------------------------------------------------------------------------


@dataclass
class Observation:
    """A single time-series observation (date + value pair).

    Attributes:
        date: The survey date as returned by the API.  Typically an
            integer whose format depends on the frequency (e.g.
            ``20260210`` for daily, ``202501`` for monthly,
            ``202404`` for quarterly).  Stored as-is from the JSON.
        value: The data value, or ``None`` if the observation is
            missing (the API returns ``null``).  Numeric series
            produce ``int`` or ``float`` values.

    Example::

        >>> obs = Observation(date=202401, value=1.23)
        >>> obs.value
        1.23
    """

    date: Union[int, str]
    value: Optional[Union[int, float, str]] = None


@dataclass
class Series:
    """A single data series from a Code API or Layer API response.

    Attributes:
        series_code: Unique series identifier (without DB name prefix).
        name_jp: Series name in Japanese (``None`` when ``lang=en``).
        name_en: Series name in English (``None`` when ``lang=jp``).
        unit_jp: Unit label in Japanese (``None`` when ``lang=en``).
        unit_en: Unit label in English (``None`` when ``lang=jp``).
        frequency: Full frequency label (e.g. ``"MONTHLY"``).
        category_jp: Category in Japanese (``None`` when ``lang=en``).
        category_en: Category in English (``None`` when ``lang=jp``).
        last_update: Last update date string (``YYYYMMDD``).
        observations: List of time-series observations.

    Example::

        >>> s = Series(series_code="MADR1Z@D", frequency="DAILY",
        ...            observations=[Observation("20260101", "0.50")])
        >>> len(s.observations)
        1
    """

    series_code: str
    name_jp: Optional[str] = None
    name_en: Optional[str] = None
    unit_jp: Optional[str] = None
    unit_en: Optional[str] = None
    frequency: Optional[str] = None
    category_jp: Optional[str] = None
    category_en: Optional[str] = None
    last_update: Optional[Union[int, str]] = None
    observations: List[Observation] = field(default_factory=list)


@dataclass
class DataResponse:
    """Parsed response from the Code API or Layer API.

    Attributes:
        result: Processing result metadata (status, message, etc.).
        parameters: Echo of request parameters.
        next_position: If not ``None``, indicates that more data is available
            and provides the ``startPosition`` value for the next request.
        series: List of data series returned by the API.
        raw: The original deserialized JSON dictionary, preserved for
            debugging or advanced use.

    Example::

        >>> resp.result.status
        200
        >>> len(resp.series)
        2
        >>> resp.next_position  # None means all data was returned
    """

    result: ResultInfo
    parameters: ParameterInfo
    next_position: Optional[int] = None
    series: List[Series] = field(default_factory=list)
    raw: Dict[str, Any] = field(default_factory=dict, repr=False)


# ---------------------------------------------------------------------------
# Metadata API response models
# ---------------------------------------------------------------------------


@dataclass
class MetadataEntry:
    """A single entry from the Metadata API response.

    Attributes:
        series_code: Unique series identifier (may be empty for hierarchy-only rows).
        name_jp: Series name in Japanese.
        name_en: Series name in English.
        unit_jp: Unit label in Japanese.
        unit_en: Unit label in English.
        frequency: Full frequency label.
        category_jp: Category in Japanese.
        category_en: Category in English.
        layer1: Hierarchy layer 1 value.
        layer2: Hierarchy layer 2 value.
        layer3: Hierarchy layer 3 value.
        layer4: Hierarchy layer 4 value.
        layer5: Hierarchy layer 5 value.
        start_of_series: Earliest available date for this series.
        end_of_series: Latest available date for this series.
        last_update: Last update date string.
        notes_jp: Notes in Japanese.
        notes_en: Notes in English.
    """

    series_code: Optional[str] = None
    name_jp: Optional[str] = None
    name_en: Optional[str] = None
    unit_jp: Optional[str] = None
    unit_en: Optional[str] = None
    frequency: Optional[str] = None
    category_jp: Optional[str] = None
    category_en: Optional[str] = None
    layer1: Optional[Union[int, str]] = None
    layer2: Optional[Union[int, str]] = None
    layer3: Optional[Union[int, str]] = None
    layer4: Optional[Union[int, str]] = None
    layer5: Optional[Union[int, str]] = None
    start_of_series: Optional[str] = None
    end_of_series: Optional[str] = None
    last_update: Optional[Union[int, str]] = None
    notes_jp: Optional[str] = None
    notes_en: Optional[str] = None


@dataclass
class MetadataResponse:
    """Parsed response from the Metadata API.

    Attributes:
        result: Processing result metadata (status, message, etc.).
        db: Database name that was queried.
        entries: List of metadata entries for the database.
        raw: The original deserialized JSON dictionary.

    Example::

        >>> meta.result.status
        200
        >>> len(meta.entries)
        42
    """

    result: ResultInfo
    db: Optional[str] = None
    entries: List[MetadataEntry] = field(default_factory=list)
    raw: Dict[str, Any] = field(default_factory=dict, repr=False)
