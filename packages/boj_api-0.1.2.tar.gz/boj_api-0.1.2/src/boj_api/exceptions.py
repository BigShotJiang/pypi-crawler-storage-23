"""Custom exception hierarchy for the BOJ API client.

All exceptions inherit from :class:`BOJAPIError`, which itself inherits
from the built-in :class:`Exception`.  The hierarchy mirrors the HTTP
status codes returned by the BOJ API:

- **400** → :class:`InvalidParameterError`
- **500** → :class:`ServerError`
- **503** → :class:`DatabaseAccessError`

Each exception carries the original ``status``, ``message_id``, and
``message`` fields from the API response for programmatic inspection.
"""

from typing import Optional


class BOJAPIError(Exception):
    """Base exception for all BOJ API errors.

    Args:
        message: Human-readable error description.
        status: HTTP-like status code returned by the API (200/400/500/503).
        message_id: BOJ message identifier (e.g. ``"M181005E"``).
        api_message: Original message string from the API response.

    Attributes:
        status: The API status code.
        message_id: The BOJ message ID.
        api_message: The raw API message text.

    Example::

        try:
            client.get_data_by_code(db="BAD", code=["X"])
        except BOJAPIError as exc:
            print(exc.status, exc.message_id)
    """

    def __init__(
        self,
        message: str,
        status: Optional[int] = None,
        message_id: Optional[str] = None,
        api_message: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.message_id = message_id
        self.api_message = api_message


class InvalidParameterError(BOJAPIError):
    """Raised when the API returns status 400 (bad parameters).

    Common causes include invalid DB names, malformed series codes,
    incorrect date formats, or missing required parameters.

    Example::

        try:
            client.get_data_by_code(db="INVALID", code=["X"])
        except InvalidParameterError as exc:
            print(f"Fix your parameters: {exc.message_id}")
    """


class ServerError(BOJAPIError):
    """Raised when the API returns status 500 (unexpected server error).

    This is a transient error.  Retrying after a short delay may succeed.
    """


class DatabaseAccessError(BOJAPIError):
    """Raised when the API returns status 503 (database access error).

    This is a transient error.  Retrying after a short delay may succeed.
    """


class RateLimitError(BOJAPIError):
    """Raised when high-frequency access is detected or connection is refused.

    The BOJ API prohibits high-frequency access and may block clients
    that make too many requests in a short period.
    """


class ResponseParseError(BOJAPIError):
    """Raised when the API response cannot be parsed.

    This may indicate an unexpected change in the API response format
    or a network-level issue that corrupted the payload.
    """
