"""Constants for the BOJ API client.

This module defines base URLs, API endpoint paths, request limits,
and database name-to-description mappings used throughout the library.
"""

from typing import Dict

# ---------------------------------------------------------------------------
# Base URL & Endpoints
# ---------------------------------------------------------------------------

BASE_URL: str = "https://www.stat-search.boj.or.jp/api/v1"
"""Root URL for the BOJ Time-Series Statistics Search Site API (v1)."""

CODE_API_PATH: str = "/getDataCode"
"""Path segment for the Code API endpoint."""

LAYER_API_PATH: str = "/getDataLayer"
"""Path segment for the Layer API endpoint."""

METADATA_API_PATH: str = "/getMetadata"
"""Path segment for the Metadata API endpoint."""

# ---------------------------------------------------------------------------
# Request Limits (per the official API manual §II.4)
# ---------------------------------------------------------------------------

MAX_SERIES_PER_LAYER_FILTER: int = 1_250
"""Maximum number of series that a layer filter may resolve to."""

MAX_SERIES_PER_REQUEST: int = 250
"""Maximum series codes that can be returned in a single request."""

MAX_DATA_POINTS_PER_REQUEST: int = 60_000
"""Maximum data points (series x periods) per single request."""

# ---------------------------------------------------------------------------
# Date Range Limits
# ---------------------------------------------------------------------------

MIN_YEAR: int = 1850
"""Earliest year accepted by the API."""

MAX_YEAR: int = 2050
"""Latest year accepted by the API."""

# ---------------------------------------------------------------------------
# HTTP Defaults
# ---------------------------------------------------------------------------

DEFAULT_TIMEOUT: float = 30.0
"""Default HTTP request timeout in seconds."""

DEFAULT_MAX_RETRIES: int = 3
"""Default maximum number of retry attempts on transient errors."""

DEFAULT_RETRY_DELAY: float = 1.0
"""Default delay (in seconds) between retry attempts."""

# ---------------------------------------------------------------------------
# Database Descriptions (DB Name → Japanese description)
# ---------------------------------------------------------------------------

DB_DESCRIPTIONS: Dict[str, str] = {
    # Interest rates
    "IR01": "基準割引率および基準貸付利率",
    "IR02": "預金種類別店頭表示金利の平均年利率等",
    "IR03": "定期預金の預入期間別平均金利",
    "IR04": "貸出約定平均金利",
    # Market-related
    "FM01": "無担保コールO/N物レート（毎営業日）",
    "FM02": "短期金融市場金利",
    "FM03": "短期金融市場残高",
    "FM04": "コール市場残高",
    "FM05": "公社債発行・償還および現存額",
    "FM06": "公社債消化状況（利付国債）",
    "FM07": "（参考）国債窓口販売額・窓口販売率",
    "FM08": "外国為替市況",
    "FM09": "実効為替レート",
    # Payments and settlements
    "PS01": "各種決済",
    "PS02": "フェイルの発生状況",
    # Deposits, money, lending
    "MD01": "マネタリーベース",
    "MD02": "マネーストック",
    "MD03": "マネタリーサーベイ",
    "MD04": "（参考）マネーサプライ（M2+CD）増減と信用面の対応",
    "MD05": "通貨流通高",
    "MD06": "日銀当座預金増減要因と金融調節（実績）",
    "MD07": "準備預金額",
    "MD08": "業態別の日銀当座預金残高",
    "MD09": "マネタリーベースと日本銀行の取引",
    "MD10": "預金者別預金",
    "MD11": "預金・現金・貸出金",
    "MD12": "都道府県別預金・現金・貸出金",
    "MD13": "貸出・預金動向",
    "MD14": "定期預金の残高および新規受入高",
    "LA01": "貸出先別貸出金",
    "LA02": "日本銀行貸出",
    "LA03": "その他貸出残高",
    "LA04": "コミットメントライン契約額、利用額",
    "LA05": "主要銀行貸出動向アンケート調査",
    # Financial institution balance sheets
    "BS01": "日本銀行勘定",
    "BS02": "民間金融機関の資産・負債",
    # Flow of funds
    "FF": "資金循環",
    # Other BOJ-related
    "OB01": "日本銀行の対政府取引",
    "OB02": "日本銀行が受入れている担保の残高",
    # Tankan
    "CO": "短観",
    # Prices
    "PR01": "企業物価指数",
    "PR02": "企業向けサービス価格指数",
    "PR03": "製造業部門別投入・産出物価指数",
    "PR04": "＜サテライト指数＞最終需要・中間需要物価指数",
    # Public finance
    "PF01": "財政資金収支",
    "PF02": "政府債務",
    # Balance of payments / BIS
    "BP01": "国際収支統計",
    "BIS": "BIS国際資金取引統計および国際与信統計の日本分集計結果",
    "DER": "デリバティブ取引に関する定例市場報告",
    # Other
    "OT": "その他",
}
