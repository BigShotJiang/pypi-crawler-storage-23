"""boj_api — Python client for the Bank of Japan Time-Series Statistics API.

This package provides a typed, production-ready interface to all three
BOJ statistical data API endpoints:

- **Code API** (``getDataCode``): Fetch time-series data by series codes.
- **Layer API** (``getDataLayer``): Fetch time-series data by hierarchy layers.
- **Metadata API** (``getMetadata``): Fetch database metadata.

Example::

    from boj_api import BOJClient, Database, Frequency

    client = BOJClient()
    response = client.get_data_by_code(
        db=Database.FM08,
        code=["FXERD01"],
        start_date="202401",
        end_date="202412",
    )

Credit:
    This library uses the Bank of Japan Time-Series Statistics Search Site
    API. The content is not guaranteed by the Bank of Japan.
"""

from boj_api.client import BOJClient
from boj_api.enums import Database, Format, Frequency, Language
from boj_api.exceptions import (
    BOJAPIError,
    DatabaseAccessError,
    InvalidParameterError,
    ServerError,
)
from boj_api.models import (
    DataResponse,
    MetadataEntry,
    MetadataResponse,
    Observation,
    ParameterInfo,
    ResultInfo,
    Series,
)

__all__ = [
    # Exceptions
    "BOJAPIError",
    # Client
    "BOJClient",
    # Models
    "DataResponse",
    # Enums
    "Database",
    "DatabaseAccessError",
    "Format",
    "Frequency",
    "InvalidParameterError",
    "Language",
    "MetadataEntry",
    "MetadataResponse",
    "Observation",
    "ParameterInfo",
    "ResultInfo",
    "Series",
    "ServerError",
]

__version__ = "0.1.2"
