"""Enumerations for the BOJ API client.

Provides typed enums for all API parameter values: database identifiers,
output formats, languages, and data frequency types.
"""

from enum import Enum


class Database(str, Enum):
    """BOJ database identifiers.

    Each member corresponds to a ``DB`` parameter value accepted by the API.
    The enum *value* is the short code sent in requests (e.g. ``"IR01"``).

    Example::

        >>> Database.FM08
        <Database.FM08: 'FM08'>
        >>> Database.FM08.value
        'FM08'
    """

    # Interest rates (預金・貸出関連)
    IR01 = "IR01"
    IR02 = "IR02"
    IR03 = "IR03"
    IR04 = "IR04"

    # Market-related (マーケット関連)
    FM01 = "FM01"
    FM02 = "FM02"
    FM03 = "FM03"
    FM04 = "FM04"
    FM05 = "FM05"
    FM06 = "FM06"
    FM07 = "FM07"
    FM08 = "FM08"
    FM09 = "FM09"

    # Payments and settlements (決済関連)
    PS01 = "PS01"
    PS02 = "PS02"

    # Deposits, money supply, lending (預金・マネー・貸出)
    MD01 = "MD01"
    MD02 = "MD02"
    MD03 = "MD03"
    MD04 = "MD04"
    MD05 = "MD05"
    MD06 = "MD06"
    MD07 = "MD07"
    MD08 = "MD08"
    MD09 = "MD09"
    MD10 = "MD10"
    MD11 = "MD11"
    MD12 = "MD12"
    MD13 = "MD13"
    MD14 = "MD14"
    LA01 = "LA01"
    LA02 = "LA02"
    LA03 = "LA03"
    LA04 = "LA04"
    LA05 = "LA05"

    # Financial institution balance sheets (金融機関バランスシート)
    BS01 = "BS01"
    BS02 = "BS02"

    # Flow of funds (資金循環)
    FF = "FF"

    # Other BOJ-related (その他の日本銀行関連)
    OB01 = "OB01"
    OB02 = "OB02"

    # Tankan (短観)
    CO = "CO"

    # Prices (物価)
    PR01 = "PR01"
    PR02 = "PR02"
    PR03 = "PR03"
    PR04 = "PR04"

    # Public finance (財政関連)
    PF01 = "PF01"
    PF02 = "PF02"

    # Balance of payments / BIS (国際収支・BIS関連)
    BP01 = "BP01"
    BIS = "BIS"
    DER = "DER"

    # Other (その他)
    OT = "OT"


class Format(str, Enum):
    """Output file format for API responses.

    Example::

        >>> Format.JSON.value
        'json'
    """

    JSON = "json"
    CSV = "csv"


class Language(str, Enum):
    """Language setting for API responses.

    Example::

        >>> Language.EN.value
        'en'
    """

    JP = "jp"
    EN = "en"


class Frequency(str, Enum):
    """Data frequency (period type) for the Layer API.

    The API accepts short abbreviation codes.  Use these enum members
    as the ``frequency`` parameter in :meth:`BOJClient.get_data_by_layer`.

    Example::

        >>> Frequency.MONTHLY.value
        'M'
    """

    CALENDAR_YEAR = "CY"
    FISCAL_YEAR = "FY"
    SEMI_ANNUAL_CY = "CH"
    SEMI_ANNUAL_FY = "FH"
    QUARTERLY = "Q"
    MONTHLY = "M"
    WEEKLY = "W"
    DAILY = "D"
