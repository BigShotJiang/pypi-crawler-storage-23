"""BOJ API HTTP client.

This module provides :class:`BOJClient`, the primary entry point for
interacting with the Bank of Japan Time-Series Statistics Search Site API.
It wraps the three API endpoints — Code, Layer, and Metadata — with
automatic pagination, retry logic, gzip support, and structured response
parsing into :mod:`boj_api.models` dataclasses.
"""

import logging
import time
from typing import Any, Dict, List, Optional, Union

import requests

from boj_api.constants import (
    BASE_URL,
    CODE_API_PATH,
    DEFAULT_MAX_RETRIES,
    DEFAULT_RETRY_DELAY,
    DEFAULT_TIMEOUT,
    LAYER_API_PATH,
    METADATA_API_PATH,
)
from boj_api.enums import Database, Format, Frequency, Language
from boj_api.exceptions import (
    BOJAPIError,
    DatabaseAccessError,
    InvalidParameterError,
    RateLimitError,
    ResponseParseError,
    ServerError,
)
from boj_api.models import (
    DataResponse,
    MetadataEntry,
    MetadataResponse,
    Observation,
    ParameterInfo,
    ResultInfo,
    Series,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

_STATUS_EXCEPTION_MAP: Dict[int, type] = {
    400: InvalidParameterError,
    500: ServerError,
    503: DatabaseAccessError,
}


def _resolve_enum(value: Union[str, Any], enum_type: type) -> str:
    """Return the string value whether *value* is an enum member or plain str.

    Args:
        value: An enum member or a raw string.
        enum_type: The enum class (used only for documentation/intent).

    Returns:
        The string value suitable for an API parameter.
    """
    if isinstance(value, enum_type):
        return value.value  # type: ignore[no-any-return,attr-defined]
    return str(value)


def _parse_result_info(payload: Dict[str, Any]) -> ResultInfo:
    """Extract :class:`ResultInfo` from the top-level API response.

    The BOJ API returns status fields (``STATUS``, ``MESSAGEID``,
    ``MESSAGE``, ``DATE``) at the top level of every JSON response
    — they are **not** nested inside a ``RESULT`` wrapper.

    Args:
        payload: The full deserialized JSON response body.

    Returns:
        A populated :class:`ResultInfo` instance.
    """
    return ResultInfo(
        status=int(payload.get("STATUS", 0)),
        message_id=str(payload.get("MESSAGEID", "")),
        message=str(payload.get("MESSAGE", "")),
        date=str(payload.get("DATE", "")),
    )


def _parse_parameter_info(data: Dict[str, Any]) -> ParameterInfo:
    """Extract :class:`ParameterInfo` from a raw JSON dict.

    Args:
        data: The top-level ``PARAMETER`` dict from an API response.

    Returns:
        A populated :class:`ParameterInfo` instance.
    """
    sp_raw = data.get("STARTPOSITION")
    start_position: Optional[int] = None
    if sp_raw is not None and str(sp_raw).strip():
        try:
            start_position = int(sp_raw)
        except (ValueError, TypeError):
            start_position = None

    return ParameterInfo(
        format=data.get("FORMAT") or None,
        lang=data.get("LANG") or None,
        db=data.get("DB") or None,
        layer1=data.get("LAYER1") or None,
        layer2=data.get("LAYER2") or None,
        layer3=data.get("LAYER3") or None,
        layer4=data.get("LAYER4") or None,
        layer5=data.get("LAYER5") or None,
        frequency=data.get("FREQUENCY") or None,
        start_date=data.get("STARTDATE") or None,
        end_date=data.get("ENDDATE") or None,
        start_position=start_position,
    )


def _parse_series(data: Dict[str, Any]) -> Series:
    """Parse a single series object from the Code/Layer API JSON output.

    The BOJ API returns observations as parallel arrays inside a
    ``VALUES`` dict::

        {
            "VALUES": {
                "SURVEY_DATES": [202501, 202502, ...],
                "VALUES": [1234.5, 5678.9, ...]
            }
        }

    Args:
        data: A dict representing one series element.

    Returns:
        A populated :class:`Series` with its :class:`Observation` list.
    """
    observations: List[Observation] = []
    values_block = data.get("VALUES")
    if isinstance(values_block, dict):
        survey_dates = values_block.get("SURVEY_DATES", [])
        values = values_block.get("VALUES", [])
        if isinstance(survey_dates, list) and isinstance(values, list):
            for d, v in zip(survey_dates, values):
                observations.append(Observation(date=d, value=v))

    return Series(
        series_code=str(data.get("SERIES_CODE", "")),
        name_jp=data.get("NAME_OF_TIME_SERIES_J"),
        name_en=data.get("NAME_OF_TIME_SERIES"),
        unit_jp=data.get("UNIT_J"),
        unit_en=data.get("UNIT"),
        frequency=data.get("FREQUENCY"),
        category_jp=data.get("CATEGORY_J"),
        category_en=data.get("CATEGORY"),
        last_update=data.get("LAST_UPDATE"),
        observations=observations,
    )


def _parse_data_response(payload: Dict[str, Any]) -> DataResponse:
    """Parse the full JSON payload from the Code or Layer API.

    Args:
        payload: The deserialized JSON response body.

    Returns:
        A :class:`DataResponse` containing result info, parameters,
        pagination state, and all parsed data series.

    Raises:
        ResponseParseError: If the payload structure is unexpected.
    """
    try:
        result = _parse_result_info(payload)
        parameters = _parse_parameter_info(payload.get("PARAMETER", {}))

        np_raw = payload.get("NEXTPOSITION")
        next_position: Optional[int] = None
        if np_raw is not None:
            try:
                next_position = int(np_raw)
            except (ValueError, TypeError):
                next_position = None

        series_list: List[Series] = []
        raw_data_list = payload.get("RESULTSET", [])
        if isinstance(raw_data_list, list):
            for item in raw_data_list:
                if isinstance(item, dict):
                    series_list.append(_parse_series(item))

        return DataResponse(
            result=result,
            parameters=parameters,
            next_position=next_position,
            series=series_list,
            raw=payload,
        )
    except Exception as exc:
        if isinstance(exc, BOJAPIError):
            raise
        raise ResponseParseError(
            f"Failed to parse data API response: {exc}",
            api_message=str(exc),
        ) from exc


def _parse_metadata_entry(data: Dict[str, Any]) -> MetadataEntry:
    """Parse a single metadata entry from the Metadata API JSON output.

    Args:
        data: A dict representing one metadata element.

    Returns:
        A populated :class:`MetadataEntry`.
    """
    return MetadataEntry(
        series_code=data.get("SERIES_CODE") or None,
        name_jp=data.get("NAME_OF_TIME_SERIES_J"),
        name_en=data.get("NAME_OF_TIME_SERIES"),
        unit_jp=data.get("UNIT_J"),
        unit_en=data.get("UNIT"),
        frequency=data.get("FREQUENCY"),
        category_jp=data.get("CATEGORY_J"),
        category_en=data.get("CATEGORY"),
        layer1=data.get("LAYER1"),
        layer2=data.get("LAYER2"),
        layer3=data.get("LAYER3"),
        layer4=data.get("LAYER4"),
        layer5=data.get("LAYER5"),
        start_of_series=data.get("START_OF_THE_TIME_SERIES"),
        end_of_series=data.get("END_OF_THE_TIME_SERIES"),
        last_update=data.get("LAST_UPDATE"),
        notes_jp=data.get("NOTES_J"),
        notes_en=data.get("NOTES"),
    )


def _parse_metadata_response(payload: Dict[str, Any]) -> MetadataResponse:
    """Parse the full JSON payload from the Metadata API.

    Args:
        payload: The deserialized JSON response body.

    Returns:
        A :class:`MetadataResponse` containing result info, DB name,
        and all parsed metadata entries.

    Raises:
        ResponseParseError: If the payload structure is unexpected.
    """
    try:
        result = _parse_result_info(payload)

        entries: List[MetadataEntry] = []
        raw_data_list = payload.get("RESULTSET", [])
        if isinstance(raw_data_list, list):
            for item in raw_data_list:
                if isinstance(item, dict):
                    entries.append(_parse_metadata_entry(item))

        return MetadataResponse(
            result=result,
            db=payload.get("DB"),
            entries=entries,
            raw=payload,
        )
    except Exception as exc:
        if isinstance(exc, BOJAPIError):
            raise
        raise ResponseParseError(
            f"Failed to parse metadata API response: {exc}",
            api_message=str(exc),
        ) from exc


def _merge_data_responses(responses: List[DataResponse]) -> DataResponse:
    """Merge multiple paginated :class:`DataResponse` objects into one.

    The result info and parameters come from the first response.  Series
    with the same ``series_code`` are merged by concatenating their
    observation lists.  The final ``next_position`` is taken from the
    last response (should be ``None`` when pagination is complete).

    Args:
        responses: Ordered list of paginated responses to merge.

    Returns:
        A single :class:`DataResponse` combining all data.
    """
    if not responses:
        raise ValueError("Cannot merge an empty list of responses")

    if len(responses) == 1:
        return responses[0]

    merged_series_map: Dict[str, Series] = {}
    for resp in responses:
        for s in resp.series:
            if s.series_code in merged_series_map:
                merged_series_map[s.series_code].observations.extend(s.observations)
            else:
                # Make a shallow copy so we don't mutate the original
                merged_series_map[s.series_code] = Series(
                    series_code=s.series_code,
                    name_jp=s.name_jp,
                    name_en=s.name_en,
                    unit_jp=s.unit_jp,
                    unit_en=s.unit_en,
                    frequency=s.frequency,
                    category_jp=s.category_jp,
                    category_en=s.category_en,
                    last_update=s.last_update,
                    observations=list(s.observations),
                )

    return DataResponse(
        result=responses[0].result,
        parameters=responses[0].parameters,
        next_position=responses[-1].next_position,
        series=list(merged_series_map.values()),
        raw=responses[0].raw,
    )


# ---------------------------------------------------------------------------
# Public client
# ---------------------------------------------------------------------------


class BOJClient:
    """High-level client for the Bank of Japan Time-Series Statistics API.

    Wraps all three API endpoints (Code, Layer, Metadata) with automatic
    pagination, retry logic, gzip support, and structured response parsing.

    Args:
        lang: Default language for responses. Defaults to Japanese.
        fmt: Default output format. Defaults to JSON.
        timeout: HTTP request timeout in seconds.
        max_retries: Maximum retry attempts on transient (5xx) errors.
        retry_delay: Base delay in seconds between retries
            (doubles on each retry).

    Example::

        from boj_api import BOJClient, Database

        client = BOJClient()
        data = client.get_data_by_code(
            db=Database.FM08,
            code=["FXERD01"],
        )
    """

    def __init__(
        self,
        lang: Language = Language.JP,
        fmt: Format = Format.JSON,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        retry_delay: float = DEFAULT_RETRY_DELAY,
    ) -> None:
        self._lang = lang
        self._fmt = fmt
        self._timeout = timeout
        self._max_retries = max_retries
        self._retry_delay = retry_delay
        self._session = requests.Session()
        self._session.headers.update({"Accept-Encoding": "gzip"})

    # ------------------------------------------------------------------
    # Session lifecycle
    # ------------------------------------------------------------------

    def close(self) -> None:
        """Close the underlying HTTP session.

        It is good practice to call this when the client is no longer
        needed, or to use the client as a context manager instead.

        Example::

            client = BOJClient()
            try:
                data = client.get_data_by_code(...)
            finally:
                client.close()
        """
        self._session.close()

    def __enter__(self) -> "BOJClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # ------------------------------------------------------------------
    # Internal HTTP layer
    # ------------------------------------------------------------------

    def _request(self, path: str, params: Dict[str, str]) -> Dict[str, Any]:
        """Execute an HTTP GET request with retry logic.

        Args:
            path: API endpoint path (e.g. ``"/getDataCode"``).
            params: Query parameters dict.

        Returns:
            Deserialized JSON response body.

        Raises:
            BOJAPIError: On API-level errors (after checking status codes).
            RateLimitError: On ``ConnectionError`` suggesting rate-limiting.
            ResponseParseError: If the response body is not valid JSON.
        """
        url = BASE_URL + path
        last_exception: Optional[Exception] = None

        for attempt in range(1, self._max_retries + 1):
            try:
                logger.debug(
                    "Request attempt %d/%d: GET %s params=%s",
                    attempt,
                    self._max_retries,
                    url,
                    params,
                )
                response = self._session.get(url, params=params, timeout=self._timeout)

                # Try to parse JSON regardless of Content-Type
                # (errors always come back as JSON even for CSV requests)
                try:
                    payload: Dict[str, Any] = response.json()
                except ValueError as json_err:
                    raise ResponseParseError(
                        f"Failed to decode JSON response (HTTP {response.status_code})",
                        status=response.status_code,
                        api_message=response.text[:500],
                    ) from json_err

                # Check API-level status
                api_status = int(payload.get("STATUS", response.status_code))
                message_id = str(payload.get("MESSAGEID", ""))
                message = str(payload.get("MESSAGE", ""))

                if api_status in _STATUS_EXCEPTION_MAP:
                    exc_cls = _STATUS_EXCEPTION_MAP[api_status]

                    # Retry on transient server errors (500, 503)
                    if api_status >= 500 and attempt < self._max_retries:
                        delay = self._retry_delay * (2 ** (attempt - 1))
                        logger.warning(
                            "Transient API error %d (%s), retrying in %.1fs…",
                            api_status,
                            message_id,
                            delay,
                        )
                        time.sleep(delay)
                        continue

                    raise exc_cls(
                        f"BOJ API error {api_status}: [{message_id}] {message}",
                        status=api_status,
                        message_id=message_id,
                        api_message=message,
                    )

                return payload

            except requests.ConnectionError as conn_err:
                last_exception = conn_err
                if attempt < self._max_retries:
                    delay = self._retry_delay * (2 ** (attempt - 1))
                    logger.warning(
                        "Connection error (attempt %d/%d), retrying in %.1fs…",
                        attempt,
                        self._max_retries,
                        delay,
                    )
                    time.sleep(delay)
                else:
                    raise RateLimitError(
                        "Connection refused — possible rate-limiting by BOJ. "
                        "Reduce request frequency.",
                        api_message=str(conn_err),
                    ) from conn_err

            except requests.Timeout as timeout_err:
                last_exception = timeout_err
                if attempt < self._max_retries:
                    delay = self._retry_delay * (2 ** (attempt - 1))
                    logger.warning(
                        "Request timeout (attempt %d/%d), retrying in %.1fs…",
                        attempt,
                        self._max_retries,
                        delay,
                    )
                    time.sleep(delay)
                else:
                    raise BOJAPIError(
                        f"Request timed out after {self._max_retries} attempts",
                        api_message=str(timeout_err),
                    ) from timeout_err

            except BOJAPIError:
                raise

            except requests.RequestException as req_err:
                raise BOJAPIError(
                    f"HTTP request failed: {req_err}",
                    api_message=str(req_err),
                ) from req_err

        # Should not reach here, but just in case
        raise BOJAPIError(  # pragma: no cover
            f"Request failed after {self._max_retries} attempts",
            api_message=str(last_exception),
        )

    # ------------------------------------------------------------------
    # Public API methods
    # ------------------------------------------------------------------

    def get_data_by_code(
        self,
        db: Union[Database, str],
        code: List[str],
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        start_position: Optional[int] = None,
        auto_paginate: bool = False,
        lang: Optional[Language] = None,
        fmt: Optional[Format] = None,
    ) -> DataResponse:
        """Fetch time-series data via the Code API (``getDataCode``).

        Args:
            db: Target database identifier (enum or string).
            code: One or more series codes.  All codes must share the
                same frequency.
            start_date: Start period string.  The required format depends
                on the frequency of the requested series:

                * Daily / Monthly / Quarterly / Semi-annual → ``YYYYMM``
                  (e.g. ``"202401"``)
                * Annual (calendar-year or fiscal-year) → ``YYYY``
                  (e.g. ``"2024"``)

                ``YYYYMMDD`` is **never** accepted by the API.
            end_date: End period string (same format rules as *start_date*).
            start_position: Pagination start position (1-based index into
                the supplied code list).
            auto_paginate: If ``True``, automatically issue follow-up
                requests using ``NEXTPOSITION`` until all data has been
                retrieved.  A 1-second delay is inserted between pages
                to avoid rate-limiting.
            lang: Override the client-level language setting for this call.
            fmt: Override the client-level format setting for this call.

        Returns:
            Parsed :class:`~boj_api.models.DataResponse` containing all
            matched series and their observations.

        Raises:
            InvalidParameterError: If the API returns status 400.
            ServerError: If the API returns status 500.
            DatabaseAccessError: If the API returns status 503.
            ResponseParseError: If the response cannot be parsed.

        Example::

            response = client.get_data_by_code(
                db=Database.CO,
                code=["TK99F0000601GCQ00000"],
                start_date="202401",
                end_date="202504",
            )
            for s in response.series:
                print(s.series_code, len(s.observations))
        """
        effective_lang = _resolve_enum(lang or self._lang, Language)
        effective_fmt = _resolve_enum(fmt or self._fmt, Format)
        db_str = _resolve_enum(db, Database)

        params: Dict[str, str] = {
            "format": effective_fmt,
            "lang": effective_lang,
            "db": db_str,
            "code": ",".join(code),
        }
        if start_date is not None:
            params["startDate"] = start_date
        if end_date is not None:
            params["endDate"] = end_date
        if start_position is not None:
            params["startPosition"] = str(start_position)

        payload = self._request(CODE_API_PATH, params)
        self._check_api_status(payload)
        response = _parse_data_response(payload)

        if auto_paginate:
            responses = [response]
            while response.next_position is not None:
                logger.info(
                    "Auto-paginating Code API: next_position=%d",
                    response.next_position,
                )
                time.sleep(self._retry_delay)
                params["startPosition"] = str(response.next_position)
                payload = self._request(CODE_API_PATH, params)
                self._check_api_status(payload)
                response = _parse_data_response(payload)
                responses.append(response)
            response = _merge_data_responses(responses)

        return response

    def get_data_by_layer(
        self,
        db: Union[Database, str],
        frequency: Union[Frequency, str],
        layer: List[Union[int, str]],
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        start_position: Optional[int] = None,
        auto_paginate: bool = False,
        lang: Optional[Language] = None,
        fmt: Optional[Format] = None,
    ) -> DataResponse:
        """Fetch time-series data via the Layer API (``getDataLayer``).

        Args:
            db: Target database identifier (enum or string).
            frequency: Data frequency / period type (e.g.
                :attr:`Frequency.MONTHLY`).
            layer: Hierarchy layer specification as a list of 1-5 values.
                Each element is either an integer or the string ``"*"``
                (wildcard).  Example: ``[1, 1, "*"]``.
            start_date: Start period string.  Use ``YYYYMM`` for daily,
                monthly, quarterly, and semi-annual frequencies, or
                ``YYYY`` for annual (calendar-year / fiscal-year).
            end_date: End period string (same format rules as *start_date*).
            start_position: Pagination start position (DB-wide ordinal).
            auto_paginate: If ``True``, automatically follow
                ``NEXTPOSITION`` until all pages are retrieved.
            lang: Override the client-level language setting.
            fmt: Override the client-level format setting.

        Returns:
            Parsed :class:`~boj_api.models.DataResponse`.

        Raises:
            InvalidParameterError: If the API returns status 400.
            ServerError: If the API returns status 500.
            DatabaseAccessError: If the API returns status 503.
            ResponseParseError: If the response cannot be parsed.

        Example::

            response = client.get_data_by_layer(
                db=Database.BP01,
                frequency=Frequency.MONTHLY,
                layer=[1, 1, 1],
                start_date="202504",
                end_date="202509",
            )
        """
        effective_lang = _resolve_enum(lang or self._lang, Language)
        effective_fmt = _resolve_enum(fmt or self._fmt, Format)
        db_str = _resolve_enum(db, Database)
        freq_str = _resolve_enum(frequency, Frequency)

        layer_str = ",".join(str(lv) for lv in layer)

        params: Dict[str, str] = {
            "format": effective_fmt,
            "lang": effective_lang,
            "db": db_str,
            "frequency": freq_str,
            "layer": layer_str,
        }
        if start_date is not None:
            params["startDate"] = start_date
        if end_date is not None:
            params["endDate"] = end_date
        if start_position is not None:
            params["startPosition"] = str(start_position)

        payload = self._request(LAYER_API_PATH, params)
        self._check_api_status(payload)
        response = _parse_data_response(payload)

        if auto_paginate:
            responses = [response]
            while response.next_position is not None:
                logger.info(
                    "Auto-paginating Layer API: next_position=%d",
                    response.next_position,
                )
                time.sleep(self._retry_delay)
                params["startPosition"] = str(response.next_position)
                payload = self._request(LAYER_API_PATH, params)
                self._check_api_status(payload)
                response = _parse_data_response(payload)
                responses.append(response)
            response = _merge_data_responses(responses)

        return response

    def get_metadata(
        self,
        db: Union[Database, str],
        lang: Optional[Language] = None,
        fmt: Optional[Format] = None,
    ) -> MetadataResponse:
        """Fetch database metadata via the Metadata API (``getMetadata``).

        Args:
            db: Target database identifier (enum or string).
            lang: Override the client-level language setting.
            fmt: Override the client-level format setting.

        Returns:
            Parsed :class:`~boj_api.models.MetadataResponse` containing
            series codes, names, units, layer info, and date ranges.

        Raises:
            InvalidParameterError: If the API returns status 400.
            ServerError: If the API returns status 500.
            DatabaseAccessError: If the API returns status 503.
            ResponseParseError: If the response cannot be parsed.

        Example::

            meta = client.get_metadata(db=Database.FM08)
            for entry in meta.entries:
                print(entry.series_code, entry.name_jp)
        """
        effective_lang = _resolve_enum(lang or self._lang, Language)
        effective_fmt = _resolve_enum(fmt or self._fmt, Format)
        db_str = _resolve_enum(db, Database)

        params: Dict[str, str] = {
            "format": effective_fmt,
            "lang": effective_lang,
            "db": db_str,
        }

        payload = self._request(METADATA_API_PATH, params)
        self._check_api_status(payload)
        return _parse_metadata_response(payload)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _check_api_status(payload: Dict[str, Any]) -> None:
        """Raise an appropriate exception if the payload indicates an error.

        This is called after ``_request`` returns successfully (i.e. no
        HTTP-level error), to catch cases where the JSON was returned
        with a non-200 API status.

        Args:
            payload: The deserialized JSON response body.

        Raises:
            InvalidParameterError: For status 400.
            ServerError: For status 500.
            DatabaseAccessError: For status 503.
        """
        result_block = payload
        api_status = int(result_block.get("STATUS", 200))
        if api_status in _STATUS_EXCEPTION_MAP:
            exc_cls = _STATUS_EXCEPTION_MAP[api_status]
            message_id = str(result_block.get("MESSAGEID", ""))
            message = str(result_block.get("MESSAGE", ""))
            raise exc_cls(
                f"BOJ API error {api_status}: [{message_id}] {message}",
                status=api_status,
                message_id=message_id,
                api_message=message,
            )
