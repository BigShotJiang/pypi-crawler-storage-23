from enum import Enum


class ScoringTag(str, Enum):
    """Standard scoring tags supported by the analytics platform."""

    SCHEMA_VALIDITY = "score:schema_validity"
    RAG_FAITHFULNESS = "score:rag_faithfulness"
    VISION_HALLUCINATION = "score:vision_hallucination"
    TOXICITY = "score:toxicity"
    NUMERIC_SCORING = "score:numeric_scoring"
    ANSWER_CORRECTNESS = "score:answer_correctness"
