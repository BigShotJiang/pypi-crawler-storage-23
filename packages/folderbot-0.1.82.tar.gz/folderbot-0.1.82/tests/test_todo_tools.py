"""Tests for todo management tools."""

from pathlib import Path
from unittest.mock import MagicMock

import pytest

from folderbot.todo_store import TodoStore
from folderbot.tools.todo import (
    TodoAddRequest,
    TodoListRequest,
    TodoUpdateRequest,
    TodoRemoveRequest,
    todo_add,
    todo_list,
    todo_update,
    todo_remove,
)


def _make_context(md_path: Path, root: Path | None = None):
    """Create a mock BotContext with a real TodoStore."""
    store = TodoStore(md_path)
    context = MagicMock()
    context.user_id = 42
    services: dict = {"todo": store}
    if root is not None:
        folder_svc = MagicMock()
        folder_svc.root = root
        services["folder"] = folder_svc
    context.services = services
    return context, store


class TestTodoAddTool:
    """Tests for todo_add tool."""

    @pytest.mark.asyncio
    async def test_add_minimal(self, tmp_path: Path) -> None:
        ctx, store = _make_context(tmp_path / "todos.md")
        result = await todo_add(TodoAddRequest(title="Buy milk"), ctx)
        assert not result.is_error
        assert "Buy milk" in result.content
        items = store.list(user_id=42)
        assert len(items) == 1

    @pytest.mark.asyncio
    async def test_add_with_details(self, tmp_path: Path) -> None:
        ctx, store = _make_context(tmp_path / "todos.md")
        result = await todo_add(
            TodoAddRequest(
                title="Write report",
                description="Q1 sales report",
                effort="large",
                tags=["work", "urgent"],
            ),
            ctx,
        )
        assert not result.is_error
        items = store.list(user_id=42)
        assert items[0].effort == "large"
        assert items[0].tags == ["work", "urgent"]

    @pytest.mark.asyncio
    async def test_add_no_context(self) -> None:
        result = await todo_add(TodoAddRequest(title="Test"), None)
        assert result.is_error
        assert "not available" in result.content.lower()

    @pytest.mark.asyncio
    async def test_add_no_todo_service(self) -> None:
        ctx = MagicMock()
        ctx.services = {}
        result = await todo_add(TodoAddRequest(title="Test"), ctx)
        assert result.is_error


class TestTodoListTool:
    """Tests for todo_list tool."""

    @pytest.mark.asyncio
    async def test_list_empty(self, tmp_path: Path) -> None:
        ctx, _ = _make_context(tmp_path / "todos.md")
        result = await todo_list(TodoListRequest(), ctx)
        assert not result.is_error
        assert "no" in result.content.lower() or "empty" in result.content.lower()

    @pytest.mark.asyncio
    async def test_list_with_items(self, tmp_path: Path) -> None:
        ctx, store = _make_context(tmp_path / "todos.md")
        store.add(user_id=42, title="Task 1")
        store.add(user_id=42, title="Task 2")
        result = await todo_list(TodoListRequest(), ctx)
        assert not result.is_error
        assert "Task 1" in result.content
        assert "Task 2" in result.content

    @pytest.mark.asyncio
    async def test_list_with_effort_filter(self, tmp_path: Path) -> None:
        ctx, store = _make_context(tmp_path / "todos.md")
        store.add(user_id=42, title="Quick task", effort="tiny")
        store.add(user_id=42, title="Big task", effort="epic")
        result = await todo_list(TodoListRequest(max_effort="small"), ctx)
        assert not result.is_error
        assert "Quick task" in result.content
        assert "Big task" not in result.content

    @pytest.mark.asyncio
    async def test_list_with_tag_filter(self, tmp_path: Path) -> None:
        ctx, store = _make_context(tmp_path / "todos.md")
        store.add(user_id=42, title="Work task", tags=["work"])
        store.add(user_id=42, title="Home task", tags=["home"])
        result = await todo_list(TodoListRequest(tag="work"), ctx)
        assert not result.is_error
        assert "Work task" in result.content
        assert "Home task" not in result.content

    @pytest.mark.asyncio
    async def test_list_shows_stats(self, tmp_path: Path) -> None:
        ctx, store = _make_context(tmp_path / "todos.md")
        store.add(user_id=42, title="Task 1")
        item2 = store.add(user_id=42, title="Task 2")
        store.update(todo_id=item2.id, user_id=42, status="done")
        result = await todo_list(TodoListRequest(include_done=True), ctx)
        assert not result.is_error
        # Should show some kind of summary/stats
        assert "done" in result.content.lower() or "2" in result.content

    @pytest.mark.asyncio
    async def test_list_no_context(self) -> None:
        result = await todo_list(TodoListRequest(), None)
        assert result.is_error


class TestTodoUpdateTool:
    """Tests for todo_update tool."""

    @pytest.mark.asyncio
    async def test_update_status(self, tmp_path: Path) -> None:
        ctx, store = _make_context(tmp_path / "todos.md")
        item = store.add(user_id=42, title="Test")
        result = await todo_update(
            TodoUpdateRequest(todo_id=item.id, status="done"), ctx
        )
        assert not result.is_error
        assert "[x]" in result.content

    @pytest.mark.asyncio
    async def test_update_title(self, tmp_path: Path) -> None:
        ctx, store = _make_context(tmp_path / "todos.md")
        item = store.add(user_id=42, title="Old")
        result = await todo_update(TodoUpdateRequest(todo_id=item.id, title="New"), ctx)
        assert not result.is_error
        assert "New" in result.content

    @pytest.mark.asyncio
    async def test_update_nonexistent(self, tmp_path: Path) -> None:
        ctx, _ = _make_context(tmp_path / "todos.md")
        result = await todo_update(TodoUpdateRequest(todo_id=999, status="done"), ctx)
        assert result.is_error
        assert "not found" in result.content.lower()

    @pytest.mark.asyncio
    async def test_update_no_context(self) -> None:
        result = await todo_update(TodoUpdateRequest(todo_id=1, status="done"), None)
        assert result.is_error


class TestTodoRemoveTool:
    """Tests for todo_remove tool."""

    @pytest.mark.asyncio
    async def test_remove_existing(self, tmp_path: Path) -> None:
        ctx, store = _make_context(tmp_path / "todos.md")
        item = store.add(user_id=42, title="Test")
        result = await todo_remove(TodoRemoveRequest(todo_id=item.id), ctx)
        assert not result.is_error
        assert store.get(todo_id=item.id, user_id=42) is None

    @pytest.mark.asyncio
    async def test_remove_nonexistent(self, tmp_path: Path) -> None:
        ctx, _ = _make_context(tmp_path / "todos.md")
        result = await todo_remove(TodoRemoveRequest(todo_id=999), ctx)
        assert result.is_error
        assert "not found" in result.content.lower()

    @pytest.mark.asyncio
    async def test_remove_no_context(self) -> None:
        result = await todo_remove(TodoRemoveRequest(todo_id=1), None)
        assert result.is_error


SAMPLE_USER_TODO = """\
# TODO

## This Week

- [x] Order new bookshelf
- [ ] Buy picture frames
- [ ] Order kitchen supplies:
  - Spatula set
  - Knife strip

## Finance

- [ ] Research flights
- [x] Pay parking ticket
"""


class TestTodoListUserFiles:
    """Tests for todo_list reading hand-written TODO.md files."""

    @pytest.mark.asyncio
    async def test_list_reads_user_todo_files(self, tmp_path: Path) -> None:
        (tmp_path / "TODO.md").write_text(SAMPLE_USER_TODO)
        ctx, _ = _make_context(tmp_path / ".folderbot" / "todos.md", root=tmp_path)
        result = await todo_list(TodoListRequest(), ctx)
        assert not result.is_error
        assert "Buy picture frames" in result.content
        assert "Research flights" in result.content

    @pytest.mark.asyncio
    async def test_list_excludes_done_from_user_files(self, tmp_path: Path) -> None:
        (tmp_path / "TODO.md").write_text(SAMPLE_USER_TODO)
        ctx, _ = _make_context(tmp_path / ".folderbot" / "todos.md", root=tmp_path)
        result = await todo_list(TodoListRequest(), ctx)
        assert "Order new bookshelf" not in result.content
        assert "Pay parking ticket" not in result.content

    @pytest.mark.asyncio
    async def test_list_include_done_shows_all(self, tmp_path: Path) -> None:
        (tmp_path / "TODO.md").write_text(SAMPLE_USER_TODO)
        ctx, _ = _make_context(tmp_path / ".folderbot" / "todos.md", root=tmp_path)
        result = await todo_list(TodoListRequest(include_done=True), ctx)
        assert "Order new bookshelf" in result.content
        assert "Pay parking ticket" in result.content

    @pytest.mark.asyncio
    async def test_list_search_filters_user_todos(self, tmp_path: Path) -> None:
        (tmp_path / "TODO.md").write_text(SAMPLE_USER_TODO)
        ctx, _ = _make_context(tmp_path / ".folderbot" / "todos.md", root=tmp_path)
        result = await todo_list(TodoListRequest(search="flights"), ctx)
        assert "Research flights" in result.content
        assert "Buy picture frames" not in result.content

    @pytest.mark.asyncio
    async def test_list_shows_sections(self, tmp_path: Path) -> None:
        (tmp_path / "TODO.md").write_text(SAMPLE_USER_TODO)
        ctx, _ = _make_context(tmp_path / ".folderbot" / "todos.md", root=tmp_path)
        result = await todo_list(TodoListRequest(), ctx)
        assert "This Week" in result.content
        assert "Finance" in result.content

    @pytest.mark.asyncio
    async def test_list_combines_user_and_managed(self, tmp_path: Path) -> None:
        (tmp_path / "TODO.md").write_text(SAMPLE_USER_TODO)
        ctx, store = _make_context(tmp_path / ".folderbot" / "todos.md", root=tmp_path)
        store.add(user_id=42, title="Bot-managed task")
        result = await todo_list(TodoListRequest(), ctx)
        assert "Buy picture frames" in result.content
        assert "Bot-managed task" in result.content

    @pytest.mark.asyncio
    async def test_list_no_folder_root_still_works(self, tmp_path: Path) -> None:
        ctx, store = _make_context(tmp_path / "todos.md")
        store.add(user_id=42, title="Only managed")
        result = await todo_list(TodoListRequest(), ctx)
        assert "Only managed" in result.content

    @pytest.mark.asyncio
    async def test_list_shows_sub_items(self, tmp_path: Path) -> None:
        (tmp_path / "TODO.md").write_text(SAMPLE_USER_TODO)
        ctx, _ = _make_context(tmp_path / ".folderbot" / "todos.md", root=tmp_path)
        result = await todo_list(TodoListRequest(), ctx)
        assert "Spatula set" in result.content

    @pytest.mark.asyncio
    async def test_list_reads_fixture(self, tmp_path: Path) -> None:
        import shutil

        fixture = Path(__file__).parent / "fixtures" / "TODO.md"
        shutil.copy(fixture, tmp_path / "TODO.md")
        ctx, _ = _make_context(tmp_path / ".folderbot" / "todos.md", root=tmp_path)
        result = await todo_list(TodoListRequest(), ctx)
        assert not result.is_error
        assert "Buy picture frames" in result.content
        assert "Someday / Maybe" in result.content

    @pytest.mark.asyncio
    async def test_list_reads_non_todo_files(self, tmp_path: Path) -> None:
        (tmp_path / "ideas.md").write_text(
            "# Ideas\n## Projects\n- [ ] Build a robot\n- [ ] Learn Rust\n"
        )
        ctx, _ = _make_context(tmp_path / ".folderbot" / "todos.md", root=tmp_path)
        result = await todo_list(TodoListRequest(), ctx)
        assert "Build a robot" in result.content
        assert "Learn Rust" in result.content

    @pytest.mark.asyncio
    async def test_list_multiple_files_shows_filenames(self, tmp_path: Path) -> None:
        (tmp_path / "TODO.md").write_text("## Tasks\n- [ ] Task A\n")
        (tmp_path / "ideas.md").write_text("## Ideas\n- [ ] Idea B\n")
        ctx, _ = _make_context(tmp_path / ".folderbot" / "todos.md", root=tmp_path)
        result = await todo_list(TodoListRequest(), ctx)
        assert "TODO.md" in result.content
        assert "ideas.md" in result.content
        assert "Task A" in result.content
        assert "Idea B" in result.content

    @pytest.mark.asyncio
    async def test_list_single_file_no_filename_header(self, tmp_path: Path) -> None:
        (tmp_path / "TODO.md").write_text("## Tasks\n- [ ] Only task\n")
        ctx, _ = _make_context(tmp_path / ".folderbot" / "todos.md", root=tmp_path)
        result = await todo_list(TodoListRequest(), ctx)
        assert "Only task" in result.content
        assert "TODO.md" not in result.content
