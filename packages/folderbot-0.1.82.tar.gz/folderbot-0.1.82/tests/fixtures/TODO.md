# TODO

Master task list. Weekly plans live in [weekly/](weekly/).

---

## This Week (Feb 17 - 23)

- [x] **Order new bookshelf** — IKEA Kallax ordered Feb 18
- [ ] **Buy picture frames** — IKEA Tempelhof, 50x70cm black frames ~€15 each
- [ ] **Order kitchen supplies** (Amazon.de):
  - Silicone spatula set (~€12)
  - Magnetic knife strip (~€20)
  - Spice rack for cabinet door (~€15)
- [ ] **Schedule dentist appointment** — overdue by 3 months
- [x] Return broken headphones to MediaMarkt
- [ ] Fix dripping kitchen faucet
- [ ] Hang new curtains in bedroom
- [x] **Cancel unused gym membership** — cancelled Feb 18, saved €30/month

---

## Critical — Language Course (Deadline Sep 2026)

Research done Jan 30 — see [log](logs/2026-01-30.md#course-research)

**Primary option: Downtown Language School** (Mitte — walkable)
- Friedrichstraße 120, 10117 Berlin
- Intensive: Mon-Thu 9:00-12:00, €280/4 weeks, groups of 6-10
- Phone: 030 / 555 123 45

**Next actions:**
- [ ] Call school for placement test
- [ ] Enroll in course
- [ ] Schedule exam for September 2026

---

## Finance

- [x] Set up automatic €200/month transfer to savings — set up Feb 16
- [ ] Research vacation flights for summer trip (Jul 15-30)
  - 2 people: Berlin → Lisbon, return Barcelona
  - Budget: ~€400pp
- [x] Pay parking ticket (€35) — paid Feb 16
- [x] Cancel magazine subscription

---

## Health

- [ ] Bouldering session (local gym)
- [ ] Schedule eye exam — noticing vision changes
- [ ] **Resume physical therapy** — clinic emailed Feb 18, need to send insurance docs

---

## Shopping / Home

### Desk Setup
- [ ] **Buy monitor arm** — ergonomic setup for new desk
  - **Budget pick:** AmazonBasics (~€30)
  - **Mid-range:** Ergotron LX (~€120, lifetime warranty)
- [ ] **Buy desk lamp** — need good lighting for reading
  - BenQ ScreenBar (~€100)
  - IKEA Tertial (~€10, basic but works)

### Kitchen
- [ ] Buy airtight containers for pasta and rice
- [ ] Buy new cutting board (bamboo)
- [ ] Replace worn dish towels

### Other
- [ ] Get a haircut
- [ ] Buy winter gloves (leather, touchscreen-compatible)

---

## Career

- [ ] Update resume with current role
- [ ] Research conference talks for Q3
- [ ] Build side project with Rust
- [ ] Write blog post about async patterns

---

## Projects

- [ ] **Build home automation dashboard** — track temperature, humidity, energy usage across rooms
- [ ] **Organize photo archive** — 10 years of photos in random folders, need structure
- [ ] Automate weekly backup of important docs

---

## Someday / Maybe

- [ ] Learn woodworking basics
- [ ] Get a 3D printer
- [ ] Plan hiking trip in the Alps
- [ ] Build a mechanical keyboard

---

## Completed (Jan 2026)

### Week of Jan 27
- [x] Buy new backpack (~€80)
- [x] Install shelf brackets in office
- [x] Pay overdue electricity bill
- [x] Order 27" monitor (delivery Mar 15)
- [x] Cancel unused streaming service

### Earlier
- [x] Set up budget spreadsheet
- [x] Process tax documents for 2025
- [x] Create weekly planning template
