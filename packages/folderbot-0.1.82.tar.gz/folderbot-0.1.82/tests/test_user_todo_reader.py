"""Tests for UserTodoReader — parsing hand-written TODO.md files."""

from pathlib import Path

import pytest

from folderbot.user_todo_reader import UserTodo, parse_user_todos, find_todo_files

FIXTURE_PATH = Path(__file__).parent / "fixtures" / "TODO.md"


class TestUserTodoDataclass:
    def test_frozen(self) -> None:
        item = UserTodo(
            title="Test",
            done=False,
            section="Work",
            sub_items=(),
            line=1,
            file_path="TODO.md",
        )
        with pytest.raises(AttributeError):
            item.title = "changed"  # type: ignore[misc]


class TestParseBasic:
    def test_empty_content(self) -> None:
        assert parse_user_todos("") == []

    def test_no_checkboxes(self) -> None:
        assert parse_user_todos("# Hello\n\nSome text\n- a bullet\n") == []

    def test_single_unchecked_item(self) -> None:
        content = "## Tasks\n\n- [ ] Buy groceries\n"
        items = parse_user_todos(content)
        assert len(items) == 1
        assert items[0].title == "Buy groceries"
        assert items[0].done is False
        assert items[0].section == "Tasks"

    def test_single_checked_item(self) -> None:
        content = "## Done\n\n- [x] Pay bills\n"
        items = parse_user_todos(content)
        assert len(items) == 1
        assert items[0].done is True

    def test_uppercase_x(self) -> None:
        content = "## Done\n\n- [X] Pay bills\n"
        items = parse_user_todos(content)
        assert len(items) == 1
        assert items[0].done is True

    def test_item_without_section(self) -> None:
        content = "- [ ] Loose task\n"
        items = parse_user_todos(content)
        assert len(items) == 1
        assert items[0].section == ""

    def test_regular_list_items_ignored(self) -> None:
        content = "## Info\n\n- Friedrichstraße 120\n- Phone: 030 / 555\n"
        assert parse_user_todos(content) == []


class TestTitleParsing:
    def test_bold_stripped(self) -> None:
        content = "## Tasks\n- [ ] **Buy groceries** — at the store\n"
        items = parse_user_todos(content)
        assert items[0].title == "Buy groceries — at the store"

    def test_bold_in_middle(self) -> None:
        content = "## A\n- [ ] Go to **IKEA** for shelves\n"
        items = parse_user_todos(content)
        assert items[0].title == "Go to IKEA for shelves"

    def test_plain_title(self) -> None:
        content = "## A\n- [ ] Fix dripping kitchen faucet\n"
        items = parse_user_todos(content)
        assert items[0].title == "Fix dripping kitchen faucet"


class TestSubItems:
    def test_sub_items_captured(self) -> None:
        content = (
            "## Tasks\n- [ ] Order supplies:\n  - Item A (~€12)\n  - Item B (~€20)\n"
        )
        items = parse_user_todos(content)
        assert len(items) == 1
        assert items[0].sub_items == ("Item A (~€12)", "Item B (~€20)")

    def test_no_sub_items(self) -> None:
        content = "## A\n- [ ] Simple task\n"
        items = parse_user_todos(content)
        assert items[0].sub_items == ()

    def test_sub_items_stop_at_next_checkbox(self) -> None:
        content = "## A\n- [ ] Task A\n  - Sub A\n- [ ] Task B\n"
        items = parse_user_todos(content)
        assert len(items) == 2
        assert items[0].sub_items == ("Sub A",)
        assert items[1].sub_items == ()

    def test_sub_items_bold_stripped(self) -> None:
        content = (
            "## A\n"
            "- [ ] Buy monitor arm\n"
            "  - **Budget pick:** AmazonBasics (~€30)\n"
            "  - **Mid-range:** Ergotron LX (~€120)\n"
        )
        items = parse_user_todos(content)
        assert items[0].sub_items == (
            "Budget pick: AmazonBasics (~€30)",
            "Mid-range: Ergotron LX (~€120)",
        )


class TestSections:
    def test_h2_section(self) -> None:
        content = "## Finance\n\n- [ ] Pay bills\n"
        items = parse_user_todos(content)
        assert items[0].section == "Finance"

    def test_h2_with_decoration(self) -> None:
        content = "## Critical — Language Course (Deadline Sep 2026)\n\n- [ ] Enroll\n"
        items = parse_user_todos(content)
        assert items[0].section == "Critical — Language Course (Deadline Sep 2026)"

    def test_h3_subsection(self) -> None:
        content = "## Shopping / Home\n\n### Kitchen\n\n- [ ] Buy pots\n"
        items = parse_user_todos(content)
        assert items[0].section == "Shopping / Home > Kitchen"

    def test_h3_resets_on_new_h3(self) -> None:
        content = (
            "## Shopping\n### Kitchen\n- [ ] Buy pots\n### Bedroom\n- [ ] Buy pillows\n"
        )
        items = parse_user_todos(content)
        assert items[0].section == "Shopping > Kitchen"
        assert items[1].section == "Shopping > Bedroom"

    def test_h3_resets_on_new_h2(self) -> None:
        content = (
            "## Shopping\n### Kitchen\n- [ ] Buy pots\n## Career\n- [ ] Update resume\n"
        )
        items = parse_user_todos(content)
        assert items[0].section == "Shopping > Kitchen"
        assert items[1].section == "Career"

    def test_multiple_h2_sections(self) -> None:
        content = "## Work\n- [ ] Task A\n## Home\n- [ ] Task B\n## Fun\n- [ ] Task C\n"
        items = parse_user_todos(content)
        assert [i.section for i in items] == ["Work", "Home", "Fun"]


class TestLineNumbers:
    def test_line_numbers_1_indexed(self) -> None:
        content = "## Tasks\n\n- [ ] First\n- [ ] Second\n"
        items = parse_user_todos(content)
        assert items[0].line == 3
        assert items[1].line == 4

    def test_line_numbers_with_sub_items(self) -> None:
        content = "## A\n- [ ] Task A\n  - Sub 1\n  - Sub 2\n- [ ] Task B\n"
        items = parse_user_todos(content)
        assert items[0].line == 2
        assert items[1].line == 5


class TestFilePath:
    def test_file_path_stored(self) -> None:
        items = parse_user_todos("## A\n- [ ] Task\n", file_path="TODO.md")
        assert items[0].file_path == "TODO.md"

    def test_default_empty(self) -> None:
        items = parse_user_todos("## A\n- [ ] Task\n")
        assert items[0].file_path == ""


class TestFixtureFile:
    @pytest.fixture
    def items(self) -> list[UserTodo]:
        content = FIXTURE_PATH.read_text()
        return parse_user_todos(content, file_path="TODO.md")

    def test_total_count(self, items: list[UserTodo]) -> None:
        assert len(items) == 44

    def test_open_count(self, items: list[UserTodo]) -> None:
        open_items = [i for i in items if not i.done]
        assert len(open_items) == 30

    def test_done_count(self, items: list[UserTodo]) -> None:
        done_items = [i for i in items if i.done]
        assert len(done_items) == 14

    def test_this_week_items(self, items: list[UserTodo]) -> None:
        week = [i for i in items if i.section == "This Week (Feb 17 - 23)"]
        assert len(week) == 8

    def test_critical_items(self, items: list[UserTodo]) -> None:
        critical = [
            i
            for i in items
            if i.section == "Critical — Language Course (Deadline Sep 2026)"
        ]
        assert len(critical) == 3

    def test_finance_items(self, items: list[UserTodo]) -> None:
        finance = [i for i in items if i.section == "Finance"]
        assert len(finance) == 4

    def test_health_items(self, items: list[UserTodo]) -> None:
        health = [i for i in items if i.section == "Health"]
        assert len(health) == 3

    def test_shopping_desk_setup(self, items: list[UserTodo]) -> None:
        desk = [i for i in items if i.section == "Shopping / Home > Desk Setup"]
        assert len(desk) == 2

    def test_shopping_kitchen(self, items: list[UserTodo]) -> None:
        kitchen = [i for i in items if i.section == "Shopping / Home > Kitchen"]
        assert len(kitchen) == 3

    def test_shopping_other(self, items: list[UserTodo]) -> None:
        other = [i for i in items if i.section == "Shopping / Home > Other"]
        assert len(other) == 2

    def test_career_items(self, items: list[UserTodo]) -> None:
        career = [i for i in items if i.section == "Career"]
        assert len(career) == 4

    def test_projects_items(self, items: list[UserTodo]) -> None:
        projects = [i for i in items if i.section == "Projects"]
        assert len(projects) == 3

    def test_someday_items(self, items: list[UserTodo]) -> None:
        someday = [i for i in items if i.section == "Someday / Maybe"]
        assert len(someday) == 4

    def test_completed_week(self, items: list[UserTodo]) -> None:
        week = [
            i for i in items if i.section == "Completed (Jan 2026) > Week of Jan 27"
        ]
        assert len(week) == 5
        assert all(i.done for i in week)

    def test_completed_earlier(self, items: list[UserTodo]) -> None:
        earlier = [i for i in items if i.section == "Completed (Jan 2026) > Earlier"]
        assert len(earlier) == 3
        assert all(i.done for i in earlier)

    def test_sub_items_on_kitchen_supplies(self, items: list[UserTodo]) -> None:
        supplies = [i for i in items if "kitchen supplies" in i.title.lower()]
        assert len(supplies) == 1
        assert len(supplies[0].sub_items) == 3
        assert "Silicone spatula set (~€12)" in supplies[0].sub_items

    def test_sub_items_on_monitor_arm(self, items: list[UserTodo]) -> None:
        arm = [i for i in items if "monitor arm" in i.title.lower()]
        assert len(arm) == 1
        assert len(arm[0].sub_items) == 2

    def test_bold_stripped_from_titles(self, items: list[UserTodo]) -> None:
        for item in items:
            assert "**" not in item.title

    def test_all_file_paths(self, items: list[UserTodo]) -> None:
        assert all(i.file_path == "TODO.md" for i in items)

    def test_first_item(self, items: list[UserTodo]) -> None:
        first = items[0]
        assert first.title == "Order new bookshelf — IKEA Kallax ordered Feb 18"
        assert first.done is True
        assert first.section == "This Week (Feb 17 - 23)"
        assert first.line == 9


class TestFindTodoFiles:
    def test_finds_todo_md(self, tmp_path: Path) -> None:
        (tmp_path / "TODO.md").write_text("# TODO\n- [ ] Task\n")
        files = find_todo_files(tmp_path)
        assert len(files) == 1
        assert files[0].name == "TODO.md"

    def test_finds_any_md_with_checkboxes(self, tmp_path: Path) -> None:
        (tmp_path / "ideas.md").write_text("# Ideas\n- [ ] Build a robot\n")
        files = find_todo_files(tmp_path)
        assert len(files) == 1
        assert files[0].name == "ideas.md"

    def test_finds_shopping_list(self, tmp_path: Path) -> None:
        (tmp_path / "shopping.md").write_text("## Groceries\n- [x] Milk\n- [ ] Eggs\n")
        files = find_todo_files(tmp_path)
        assert len(files) == 1

    def test_finds_nested(self, tmp_path: Path) -> None:
        sub = tmp_path / "projects"
        sub.mkdir()
        (sub / "roadmap.md").write_text("# Roadmap\n- [ ] MVP\n")
        files = find_todo_files(tmp_path)
        assert len(files) == 1

    def test_finds_multiple_files(self, tmp_path: Path) -> None:
        (tmp_path / "TODO.md").write_text("- [ ] Task A\n")
        (tmp_path / "ideas.md").write_text("- [ ] Idea B\n")
        files = find_todo_files(tmp_path)
        assert len(files) == 2

    def test_skips_md_without_checkboxes(self, tmp_path: Path) -> None:
        (tmp_path / "notes.md").write_text("# Notes\nJust some text.\n")
        files = find_todo_files(tmp_path)
        assert len(files) == 0

    def test_skips_regular_lists(self, tmp_path: Path) -> None:
        (tmp_path / "list.md").write_text("# List\n- Item one\n- Item two\n")
        files = find_todo_files(tmp_path)
        assert len(files) == 0

    def test_excludes_hidden_dirs(self, tmp_path: Path) -> None:
        bot_dir = tmp_path / ".folderbot"
        bot_dir.mkdir()
        (bot_dir / "todos.md").write_text("- [ ] Hidden task\n")
        git_dir = tmp_path / ".git"
        git_dir.mkdir()
        (git_dir / "todo.md").write_text("- [ ] Git task\n")
        files = find_todo_files(tmp_path)
        assert len(files) == 0

    def test_ignores_non_md_files(self, tmp_path: Path) -> None:
        (tmp_path / "todo.txt").write_text("- [ ] buy groceries\n")
        files = find_todo_files(tmp_path)
        assert len(files) == 0

    def test_sorted_by_path(self, tmp_path: Path) -> None:
        (tmp_path / "TODO.md").write_text("- [ ] A\n")
        sub = tmp_path / "zzz"
        sub.mkdir()
        (sub / "ideas.md").write_text("- [ ] B\n")
        files = find_todo_files(tmp_path)
        assert files[0].parent == tmp_path
