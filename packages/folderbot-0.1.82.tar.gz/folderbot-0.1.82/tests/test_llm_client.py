"""Tests for the LLM client (instructor-based, provider-agnostic)."""

import asyncio
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from folderbot.config import Config, ReadRules, WatchConfig
from folderbot.llm_client import (
    AgentResponse,
    AskUserRequest,
    LLMClient,
    TokenUsage,
    ToolCallRequest,
    build_topic_history,
    trim_history_to_budget,
)
from folderbot.session_manager import Message
from folderbot.tools.base import ToolResult


def _msg(role: str, content: str, topic: str = "general") -> Message:
    """Create a test message."""
    return {
        "role": role,
        "content": content,
        "timestamp": "2026-01-01T00:00:00",
        "topic": topic,
    }


# ---------- Model tests ----------


class TestToolCallRequest:
    def test_basic(self):
        tc = ToolCallRequest(name="read_file", arguments={"path": "test.md"})
        assert tc.name == "read_file"
        assert tc.arguments == {"path": "test.md"}

    def test_empty_arguments_default(self):
        tc = ToolCallRequest(name="list_files")
        assert tc.arguments == {}

    def test_frozen(self):
        tc = ToolCallRequest(name="read_file", arguments={})
        with pytest.raises(Exception):
            tc.name = "other"


class TestAgentResponse:
    def test_direct_answer(self):
        r = AgentResponse(answer="Hello!")
        assert r.answer == "Hello!"
        assert r.tool_calls == []

    def test_tool_calls_only(self):
        r = AgentResponse(
            tool_calls=[ToolCallRequest(name="list_files", arguments={"path": "/"})]
        )
        assert r.answer is None
        assert len(r.tool_calls) == 1
        assert r.tool_calls[0].name == "list_files"

    def test_both_answer_and_tools(self):
        """LLM can return tool calls alongside a partial answer."""
        r = AgentResponse(
            answer="Let me check...",
            tool_calls=[ToolCallRequest(name="list_files")],
        )
        assert r.answer == "Let me check..."
        assert len(r.tool_calls) == 1

    def test_frozen(self):
        r = AgentResponse(answer="Hi")
        with pytest.raises(Exception):
            r.answer = "Changed"

    def test_topic_default(self):
        r = AgentResponse(answer="Hi")
        assert r.topic == "general"

    def test_topic_custom(self):
        r = AgentResponse(answer="Sunny today!", topic="weather")
        assert r.topic == "weather"

    def test_topic_spaces_normalized(self):
        r = AgentResponse(answer="test", topic="project planning")
        assert r.topic == "project_planning"

    def test_topic_uppercase_normalized(self):
        r = AgentResponse(answer="test", topic="Weather")
        assert r.topic == "weather"

    def test_topic_invalid_falls_back_to_general(self):
        r = AgentResponse(answer="test", topic="!!!")
        assert r.topic == "general"


# ---------- trim_history_to_budget tests (moved from test_claude_client.py) ----------


class TestTrimHistoryToBudget:
    def test_empty_history_returns_empty(self):
        assert trim_history_to_budget([], max_chars=1000) == []

    def test_history_within_budget_unchanged(self):
        history = [_msg("user", "Hello"), _msg("assistant", "Hi!")]
        result = trim_history_to_budget(history, max_chars=1000)
        assert result == history

    def test_history_exceeding_budget_drops_oldest_first(self):
        history = [
            _msg("user", "First"),
            _msg("assistant", "Reply1"),
            _msg("user", "Second"),
            _msg("assistant", "Reply2"),
        ]
        budget = len("Second") + len("Reply2") + 1
        result = trim_history_to_budget(history, max_chars=budget)
        assert len(result) == 2
        assert result[0]["content"] == "Second"
        assert result[1]["content"] == "Reply2"

    def test_drops_in_pairs_to_avoid_orphaned_messages(self):
        history = [
            _msg("user", "A" * 100),
            _msg("assistant", "B" * 100),
            _msg("user", "C" * 50),
            _msg("assistant", "D" * 50),
        ]
        budget = 150
        result = trim_history_to_budget(history, max_chars=budget)
        assert len(result) == 2
        assert result[0]["content"] == "C" * 50
        assert result[1]["content"] == "D" * 50

    def test_budget_zero_returns_empty(self):
        history = [_msg("user", "Hello"), _msg("assistant", "Hi!")]
        result = trim_history_to_budget(history, max_chars=0)
        assert result == []

    def test_single_pair_exceeding_budget_still_included(self):
        history = [
            _msg("user", "A" * 500),
            _msg("assistant", "B" * 500),
        ]
        result = trim_history_to_budget(history, max_chars=100)
        assert len(result) == 2

    def test_preserves_message_order(self):
        history = [
            _msg("user", "1"),
            _msg("assistant", "2"),
            _msg("user", "3"),
            _msg("assistant", "4"),
            _msg("user", "5"),
            _msg("assistant", "6"),
        ]
        result = trim_history_to_budget(history, max_chars=10000)
        contents = [m["content"] for m in result]
        assert contents == ["1", "2", "3", "4", "5", "6"]

    def test_odd_number_of_messages_handles_gracefully(self):
        history = [
            _msg("user", "A" * 100),
            _msg("assistant", "B" * 100),
            _msg("user", "C" * 50),
        ]
        budget = 100
        result = trim_history_to_budget(history, max_chars=budget)
        assert result[-1]["content"] == "C" * 50


# ---------- build_topic_history tests ----------


class TestBuildTopicHistory:
    def test_empty_history(self):
        assert build_topic_history([], max_chars=1000) == []

    def test_all_same_topic_returns_all(self):
        history = [
            _msg("user", "A", topic="weather"),
            _msg("assistant", "B", topic="weather"),
        ]
        result = build_topic_history(history, max_chars=10000)
        assert len(result) == 2

    def test_keeps_last_4_regardless_of_topic(self):
        """Last 4 messages are always kept even if off-topic."""
        history = [
            _msg("user", "old weather", topic="weather"),
            _msg("assistant", "old reply", topic="weather"),
            _msg("user", "recipe Q", topic="recipes"),
            _msg("assistant", "recipe A", topic="recipes"),
            _msg("user", "back to weather", topic="weather"),
            _msg("assistant", "weather reply", topic="weather"),
        ]
        result = build_topic_history(history, max_chars=10000)
        # Last 4 kept (2 recipes + 2 weather) + old weather backfilled
        assert len(result) == 6
        # The recipe messages are there because they're in the recency window
        contents = [m["content"] for m in result]
        assert "recipe Q" in contents
        assert "old weather" in contents

    def test_prioritizes_current_topic(self):
        """When budget is tight, same-topic messages are preferred over off-topic."""
        history = [
            _msg("user", "W" * 100, topic="weather"),
            _msg("assistant", "W" * 100, topic="weather"),
            _msg("user", "R" * 100, topic="recipes"),
            _msg("assistant", "R" * 100, topic="recipes"),
            _msg("user", "W2" * 50, topic="weather"),
            _msg("assistant", "W2" * 50, topic="weather"),
        ]
        # Budget fits last 4 (recency) + the old weather messages
        # but would be tight without recipes
        result = build_topic_history(history, max_chars=500)
        topics = [m["topic"] for m in result]
        # Last 4 are always kept (2 recipes + 2 weather at the end)
        # Then weather messages from earlier are preferred
        assert "weather" in topics

    def test_respects_budget(self):
        history = [
            _msg("user", "X" * 200, topic="a"),
            _msg("assistant", "X" * 200, topic="a"),
            _msg("user", "Y" * 200, topic="a"),
            _msg("assistant", "Y" * 200, topic="a"),
        ]
        result = build_topic_history(history, max_chars=500)
        total = sum(len(m["content"]) for m in result)
        assert total <= 500 or len(result) <= 4  # at least last 4 kept


# ---------- LLMClient tests ----------


@pytest.fixture
def mock_config(tmp_path: Path) -> Config:
    """Create a mock config for testing."""
    config = MagicMock(spec=Config)
    config.telegram_token = "test_token"
    config.api_key = "test_api_key"
    config.root_folder = tmp_path
    config.allowed_user_ids = [12345, 67890]
    config.read_rules = ReadRules()
    config.watch_config = WatchConfig()
    config.db_path = tmp_path / "sessions.db"
    config.todo_path = tmp_path / "todos.md"
    config.model = "anthropic/claude-sonnet-4-20250514"
    config.max_context_chars = 10000
    config.max_history_chars = 50000
    config.user_name = "User"
    config.tools = {}
    return config


@pytest.fixture
def llm_client(mock_config: Config) -> LLMClient:
    """Create an LLMClient with mocked instructor."""
    with patch("folderbot.llm_client.instructor") as mock_instr:
        mock_async_client = AsyncMock()
        mock_instr.from_provider.return_value = mock_async_client
        client = LLMClient(mock_config)
        return client


def _with_completion(agent_response: AgentResponse) -> tuple:
    """Wrap an AgentResponse with a mock completion for create_with_completion."""
    return (agent_response, _mock_completion())


class TestLLMClientInit:
    def test_model_without_provider_prefix_raises(self, mock_config: Config):
        """Model string without provider/ prefix should raise a clear error."""
        mock_config.model = "claude-sonnet-4-20250514"
        with patch("folderbot.llm_client.instructor"):
            with pytest.raises(ValueError, match="provider prefix"):
                LLMClient(mock_config)

    def test_empty_api_key_passes_none_to_instructor(self, mock_config: Config):
        """When api_key is empty, None should be passed to from_provider."""
        mock_config.api_key = ""
        with patch("folderbot.llm_client.instructor") as mock_instr:
            mock_instr.from_provider.return_value = AsyncMock()
            LLMClient(mock_config)
            _, kwargs = mock_instr.from_provider.call_args
            assert kwargs.get("api_key") is None

    def test_api_key_passed_when_set(self, mock_config: Config):
        """When api_key is set, it should be passed to from_provider."""
        mock_config.api_key = "sk-my-key"
        with patch("folderbot.llm_client.instructor") as mock_instr:
            mock_instr.from_provider.return_value = AsyncMock()
            LLMClient(mock_config)
            _, kwargs = mock_instr.from_provider.call_args
            assert kwargs.get("api_key") == "sk-my-key"


class TestLLMClientChat:
    @pytest.mark.asyncio
    async def test_simple_answer_no_tools(self, llm_client: LLMClient):
        """When LLM returns a direct answer, chat() returns it."""
        llm_client._client.create_with_completion = AsyncMock(
            return_value=_with_completion(
                AgentResponse(answer="Hello there!", topic="greeting")
            )
        )
        mock_context = MagicMock()

        response, tools_used, topic, _usage = await llm_client.chat(
            "Hi", mock_context, history=[]
        )

        assert response == "Hello there!"
        assert tools_used == []
        assert topic == "greeting"

    @pytest.mark.asyncio
    async def test_tool_call_then_answer(self, llm_client: LLMClient):
        """LLM requests a tool, gets result, then gives final answer."""
        llm_client._client.create_with_completion = AsyncMock(
            side_effect=[
                _with_completion(
                    AgentResponse(
                        tool_calls=[
                            ToolCallRequest(name="list_files", arguments={"path": "/"})
                        ]
                    )
                ),
                _with_completion(
                    AgentResponse(answer="Your folder has 2 files: a.md and b.md")
                ),
            ]
        )
        with patch.object(
            llm_client.tools,
            "execute_async",
            return_value=ToolResult(content="a.md\nb.md"),
        ):
            mock_context = MagicMock()
            response, tools_used, _topic, _usage = await llm_client.chat(
                "What's in my folder?", mock_context, history=[]
            )

        assert response == "Your folder has 2 files: a.md and b.md"
        assert tools_used == ["list_files"]

    @pytest.mark.asyncio
    async def test_multiple_tool_calls_in_sequence(self, llm_client: LLMClient):
        """LLM calls multiple tools across iterations."""
        llm_client._client.create_with_completion = AsyncMock(
            side_effect=[
                _with_completion(
                    AgentResponse(
                        tool_calls=[ToolCallRequest(name="list_files", arguments={})]
                    )
                ),
                _with_completion(
                    AgentResponse(
                        tool_calls=[
                            ToolCallRequest(
                                name="read_file", arguments={"path": "notes.md"}
                            )
                        ]
                    )
                ),
                _with_completion(AgentResponse(answer="Your notes say: buy groceries")),
            ]
        )
        with patch.object(
            llm_client.tools,
            "execute_async",
            side_effect=[
                ToolResult(content="notes.md"),
                ToolResult(content="buy groceries"),
            ],
        ):
            mock_context = MagicMock()
            response, tools_used, _topic, _usage = await llm_client.chat(
                "What do my notes say?", mock_context, history=[]
            )

        assert response == "Your notes say: buy groceries"
        assert tools_used == ["list_files", "read_file"]

    @pytest.mark.asyncio
    async def test_parallel_tool_calls_in_single_response(self, llm_client: LLMClient):
        """LLM requests multiple tools in a single response."""
        llm_client._client.create_with_completion = AsyncMock(
            side_effect=[
                _with_completion(
                    AgentResponse(
                        tool_calls=[
                            ToolCallRequest(
                                name="read_file", arguments={"path": "a.md"}
                            ),
                            ToolCallRequest(
                                name="read_file", arguments={"path": "b.md"}
                            ),
                        ]
                    )
                ),
                _with_completion(AgentResponse(answer="Both files are notes.")),
            ]
        )
        with patch.object(
            llm_client.tools,
            "execute_async",
            side_effect=[
                ToolResult(content="Content of a"),
                ToolResult(content="Content of b"),
            ],
        ):
            mock_context = MagicMock()
            response, tools_used, _topic, _usage = await llm_client.chat(
                "Read both files", mock_context, history=[]
            )

        assert response == "Both files are notes."
        assert tools_used == ["read_file", "read_file"]

    @pytest.mark.asyncio
    async def test_on_tool_use_callback(self, llm_client: LLMClient):
        """The on_tool_use callback is called for each tool."""
        llm_client._client.create_with_completion = AsyncMock(
            side_effect=[
                _with_completion(
                    AgentResponse(
                        tool_calls=[ToolCallRequest(name="list_files", arguments={})]
                    )
                ),
                _with_completion(AgentResponse(answer="Done.")),
            ]
        )
        callback = AsyncMock()

        with patch.object(
            llm_client.tools,
            "execute_async",
            return_value=ToolResult(content="files"),
        ):
            mock_context = MagicMock()
            await llm_client.chat(
                "List files", mock_context, history=[], on_tool_use=callback
            )

        callback.assert_called_once_with("list_files")

    @pytest.mark.asyncio
    async def test_max_iterations_limit(self, llm_client: LLMClient):
        """Agent loop stops after MAX_TOOL_ITERATIONS."""
        # Always return tool calls, never an answer
        llm_client._client.create_with_completion = AsyncMock(
            return_value=_with_completion(
                AgentResponse(
                    tool_calls=[ToolCallRequest(name="list_files", arguments={})]
                )
            )
        )
        with patch.object(
            llm_client.tools,
            "execute_async",
            return_value=ToolResult(content="files"),
        ):
            mock_context = MagicMock()
            response, tools_used, _topic, _usage = await llm_client.chat(
                "Loop forever", mock_context, history=[]
            )

        # Should have called tools MAX_TOOL_ITERATIONS times
        assert len(tools_used) == llm_client.MAX_TOOL_ITERATIONS
        # Should return empty string (no answer was given)
        assert response == ""

    @pytest.mark.asyncio
    async def test_tool_error_included_in_context(self, llm_client: LLMClient):
        """Tool errors are fed back to the LLM."""
        llm_client._client.create_with_completion = AsyncMock(
            side_effect=[
                _with_completion(
                    AgentResponse(
                        tool_calls=[
                            ToolCallRequest(
                                name="read_file", arguments={"path": "missing.md"}
                            )
                        ]
                    )
                ),
                _with_completion(AgentResponse(answer="That file doesn't exist.")),
            ]
        )
        with patch.object(
            llm_client.tools,
            "execute_async",
            return_value=ToolResult(content="File not found", is_error=True),
        ):
            mock_context = MagicMock()
            response, tools_used, _topic, _usage = await llm_client.chat(
                "Read missing.md", mock_context, history=[]
            )

        assert response == "That file doesn't exist."
        assert tools_used == ["read_file"]
        # Verify the error was included in the messages to the LLM
        second_call_messages = llm_client._client.create_with_completion.call_args_list[
            1
        ].kwargs["messages"]
        user_msg = second_call_messages[-1]["content"]
        assert "Error" in user_msg
        assert "File not found" in user_msg

    @pytest.mark.asyncio
    async def test_hallucination_guard_triggers_retry(self, llm_client: LLMClient):
        """If LLM claims action without tools, it retries with a warning."""
        llm_client._client.create_with_completion = AsyncMock(
            side_effect=[
                # First: claims action without calling tools
                _with_completion(
                    AgentResponse(answer="I've updated your file with the new content.")
                ),
                # Second: corrects itself and uses a tool
                _with_completion(
                    AgentResponse(
                        tool_calls=[
                            ToolCallRequest(
                                name="write_file",
                                arguments={"path": "test.md", "content": "new content"},
                            )
                        ]
                    )
                ),
                # Third: confirms with answer
                _with_completion(AgentResponse(answer="File updated.")),
            ]
        )
        with patch.object(
            llm_client.tools,
            "execute_async",
            return_value=ToolResult(content="Written successfully"),
        ):
            mock_context = MagicMock()
            response, tools_used, _topic, _usage = await llm_client.chat(
                "Update my file", mock_context, history=[]
            )

        assert response == "File updated."
        assert "write_file" in tools_used
        # Should have been called 3 times (guard triggered retry)
        assert llm_client._client.create_with_completion.call_count == 3

    @pytest.mark.asyncio
    async def test_history_passed_to_llm(self, llm_client: LLMClient):
        """Conversation history is included in messages to the LLM."""
        llm_client._client.create_with_completion = AsyncMock(
            return_value=_with_completion(
                AgentResponse(answer="I remember you said hello!")
            )
        )
        history = [
            _msg("user", "Hello"),
            _msg("assistant", "Hi!"),
        ]
        mock_context = MagicMock()
        await llm_client.chat("Do you remember?", mock_context, history=history)

        call_messages = llm_client._client.create_with_completion.call_args.kwargs[
            "messages"
        ]
        # Should include history messages (user, assistant) + new user message
        # System is passed separately via system kwarg
        user_msgs = [m for m in call_messages if m["role"] == "user"]
        assistant_msgs = [m for m in call_messages if m["role"] == "assistant"]
        assert len(user_msgs) >= 2  # history + new
        assert len(assistant_msgs) >= 1  # from history


class TestClaimsToolUse:
    """Test the hallucination detection heuristic."""

    def test_detects_file_write_claim(self, llm_client: LLMClient):
        assert llm_client._claims_tool_use("I've updated your notes.md file")

    def test_detects_schedule_claim(self, llm_client: LLMClient):
        assert llm_client._claims_tool_use("I've scheduled a daily reminder for you")

    def test_detects_file_creation(self, llm_client: LLMClient):
        assert llm_client._claims_tool_use("I've created a new file for you")

    def test_allows_informational_response(self, llm_client: LLMClient):
        assert not llm_client._claims_tool_use("Your folder contains 5 markdown files")

    def test_allows_suggestion(self, llm_client: LLMClient):
        assert not llm_client._claims_tool_use(
            "I suggest you create a new file for this"
        )

    def test_allows_explanation(self, llm_client: LLMClient):
        assert not llm_client._claims_tool_use("Here's what that means:")


class TestFormatToolsForPrompt:
    def test_formats_tool_descriptions(self, llm_client: LLMClient):
        """Tool descriptions are formatted for the system prompt."""
        tool_defs = [
            {
                "name": "list_files",
                "description": "List files in a directory",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "path": {
                            "type": "string",
                            "description": "Directory path",
                        }
                    },
                    "required": ["path"],
                },
            }
        ]
        result = llm_client._format_tools_for_prompt(tool_defs)
        assert "list_files" in result
        assert "List files in a directory" in result
        assert "path" in result


# ---------- AskUserRequest model tests ----------


class TestAskUserRequest:
    def test_basic(self):
        req = AskUserRequest(
            question="Which file?", options=["a.md", "b.md"], input_type="choice"
        )
        assert req.question == "Which file?"
        assert req.options == ["a.md", "b.md"]
        assert req.input_type == "choice"

    def test_defaults(self):
        req = AskUserRequest(question="Pick one")
        assert req.options == []
        assert req.input_type == "choice"

    def test_frozen(self):
        req = AskUserRequest(question="Test")
        with pytest.raises(Exception):
            req.question = "Changed"

    def test_confirm_type(self):
        req = AskUserRequest(
            question="Delete this?", input_type="confirm", options=["Yes", "No"]
        )
        assert req.input_type == "confirm"

    def test_text_type(self):
        req = AskUserRequest(question="What's the title?", input_type="text")
        assert req.input_type == "text"

    def test_location_type(self):
        req = AskUserRequest(question="Where's your office?", input_type="location")
        assert req.input_type == "location"


# ---------- ask_user in agent loop tests ----------


class TestAskUserInAgentLoop:
    @pytest.mark.asyncio
    async def test_ask_user_calls_callback(self, llm_client: LLMClient):
        """When LLM calls ask_user, the on_ask_user callback is invoked."""
        llm_client._client.create_with_completion = AsyncMock(
            side_effect=[
                _with_completion(
                    AgentResponse(
                        tool_calls=[
                            ToolCallRequest(
                                name="ask_user",
                                arguments={
                                    "question": "Which file?",
                                    "options": ["a.md", "b.md"],
                                    "input_type": "choice",
                                },
                            )
                        ]
                    )
                ),
                _with_completion(AgentResponse(answer="You chose a.md.")),
            ]
        )
        on_ask_user = AsyncMock(return_value="a.md")
        mock_context = MagicMock()

        response, tools_used, _topic, _usage = await llm_client.chat(
            "Read my file", mock_context, history=[], on_ask_user=on_ask_user
        )

        assert response == "You chose a.md."
        assert "ask_user" in tools_used
        on_ask_user.assert_called_once()
        # Verify the callback received an AskUserRequest
        call_arg = on_ask_user.call_args[0][0]
        assert isinstance(call_arg, AskUserRequest)
        assert call_arg.question == "Which file?"
        assert call_arg.options == ["a.md", "b.md"]

    @pytest.mark.asyncio
    async def test_ask_user_result_feeds_back_to_llm(self, llm_client: LLMClient):
        """The user's answer is included in the context for the next LLM call."""
        llm_client._client.create_with_completion = AsyncMock(
            side_effect=[
                _with_completion(
                    AgentResponse(
                        tool_calls=[
                            ToolCallRequest(
                                name="ask_user",
                                arguments={
                                    "question": "Which file?",
                                    "options": ["a.md", "b.md"],
                                },
                            )
                        ]
                    )
                ),
                _with_completion(AgentResponse(answer="Reading a.md for you.")),
            ]
        )
        on_ask_user = AsyncMock(return_value="a.md")
        mock_context = MagicMock()

        await llm_client.chat(
            "Read my file", mock_context, history=[], on_ask_user=on_ask_user
        )

        # Check the second LLM call includes the user's answer
        second_call = llm_client._client.create_with_completion.call_args_list[1]
        user_msg = second_call.kwargs["messages"][-1]["content"]
        assert "a.md" in user_msg
        assert "ask_user" in user_msg

    @pytest.mark.asyncio
    async def test_ask_user_without_callback_returns_error(self, llm_client: LLMClient):
        """When on_ask_user is None, ask_user returns an error result."""
        llm_client._client.create_with_completion = AsyncMock(
            side_effect=[
                _with_completion(
                    AgentResponse(
                        tool_calls=[
                            ToolCallRequest(
                                name="ask_user",
                                arguments={"question": "Which file?"},
                            )
                        ]
                    )
                ),
                _with_completion(
                    AgentResponse(answer="Sorry, I can't ask you interactively.")
                ),
            ]
        )
        mock_context = MagicMock()

        response, tools_used, _topic, _usage = await llm_client.chat(
            "Read my file", mock_context, history=[]
        )

        assert response == "Sorry, I can't ask you interactively."
        assert "ask_user" in tools_used
        # Verify error was fed back
        second_call = llm_client._client.create_with_completion.call_args_list[1]
        user_msg = second_call.kwargs["messages"][-1]["content"]
        assert "not available" in user_msg
        assert "Error" in user_msg

    @pytest.mark.asyncio
    async def test_ask_user_not_dispatched_to_folder_tools(self, llm_client: LLMClient):
        """ask_user should NOT go through FolderTools.execute_async."""
        llm_client._client.create_with_completion = AsyncMock(
            side_effect=[
                _with_completion(
                    AgentResponse(
                        tool_calls=[
                            ToolCallRequest(
                                name="ask_user",
                                arguments={
                                    "question": "Confirm?",
                                    "input_type": "confirm",
                                },
                            )
                        ]
                    )
                ),
                _with_completion(AgentResponse(answer="Done.")),
            ]
        )
        on_ask_user = AsyncMock(return_value="Yes")
        mock_context = MagicMock()

        with patch.object(llm_client.tools, "execute_async") as mock_execute:
            await llm_client.chat(
                "Do it", mock_context, history=[], on_ask_user=on_ask_user
            )
            mock_execute.assert_not_called()

    @pytest.mark.asyncio
    async def test_ask_user_timeout(self, llm_client: LLMClient):
        """When the callback raises TimeoutError, an error is fed back."""
        llm_client._client.create_with_completion = AsyncMock(
            side_effect=[
                _with_completion(
                    AgentResponse(
                        tool_calls=[
                            ToolCallRequest(
                                name="ask_user",
                                arguments={"question": "Pick one"},
                            )
                        ]
                    )
                ),
                _with_completion(AgentResponse(answer="You didn't respond in time.")),
            ]
        )
        on_ask_user = AsyncMock(side_effect=asyncio.TimeoutError())
        mock_context = MagicMock()

        response, tools_used, _topic, _usage = await llm_client.chat(
            "Help", mock_context, history=[], on_ask_user=on_ask_user
        )

        assert response == "You didn't respond in time."
        assert "ask_user" in tools_used
        # Verify timeout error was fed back
        second_call = llm_client._client.create_with_completion.call_args_list[1]
        user_msg = second_call.kwargs["messages"][-1]["content"]
        assert "did not respond" in user_msg

    @pytest.mark.asyncio
    async def test_ask_user_tracked_in_tools_used(self, llm_client: LLMClient):
        """ask_user appears in tools_used alongside regular tools."""
        llm_client._client.create_with_completion = AsyncMock(
            side_effect=[
                _with_completion(
                    AgentResponse(
                        tool_calls=[ToolCallRequest(name="list_files", arguments={})]
                    )
                ),
                _with_completion(
                    AgentResponse(
                        tool_calls=[
                            ToolCallRequest(
                                name="ask_user",
                                arguments={
                                    "question": "Which one?",
                                    "options": ["a.md", "b.md"],
                                },
                            )
                        ]
                    )
                ),
                _with_completion(AgentResponse(answer="Here's a.md.")),
            ]
        )
        on_ask_user = AsyncMock(return_value="a.md")

        with patch.object(
            llm_client.tools,
            "execute_async",
            return_value=ToolResult(content="a.md\nb.md"),
        ):
            mock_context = MagicMock()
            response, tools_used, _topic, _usage = await llm_client.chat(
                "Read a file", mock_context, history=[], on_ask_user=on_ask_user
            )

        assert tools_used == ["list_files", "ask_user"]

    @pytest.mark.asyncio
    async def test_ask_user_in_system_prompt(self, llm_client: LLMClient):
        """ask_user tool description is included in the system prompt."""
        system = llm_client._build_system_prompt()
        assert "ask_user" in system
        assert "question" in system
        assert "options" in system
        assert "input_type" in system

    @pytest.mark.asyncio
    async def test_current_date_in_system_prompt(self, llm_client: LLMClient):
        """System prompt includes the current date."""
        from datetime import date

        system = llm_client._build_system_prompt()
        today = date.today().strftime("%A, %B %d, %Y")
        assert today in system

    @pytest.mark.asyncio
    async def test_version_in_system_prompt(self, llm_client: LLMClient):
        """System prompt includes the folderbot version."""
        import folderbot

        system = llm_client._build_system_prompt()
        assert folderbot.__version__ in system

    @pytest.mark.asyncio
    async def test_last_upgraded_in_system_prompt(self, llm_client: LLMClient):
        """System prompt includes the last upgraded date."""
        system = llm_client._build_system_prompt()
        assert "last upgraded" in system

    @pytest.mark.asyncio
    async def test_folderbot_identity_in_system_prompt(self, llm_client: LLMClient):
        """System prompt establishes Folderbot identity."""
        system = llm_client._build_system_prompt()
        assert "Folderbot" in system


# ---------- TokenUsage model tests ----------


class TestTokenUsage:
    def test_basic(self):
        usage = TokenUsage(input_tokens=100, output_tokens=50)
        assert usage.input_tokens == 100
        assert usage.output_tokens == 50

    def test_frozen(self):
        usage = TokenUsage(input_tokens=100, output_tokens=50)
        with pytest.raises(AttributeError):
            usage.input_tokens = 200  # type: ignore[misc]

    def test_zero_tokens(self):
        usage = TokenUsage(input_tokens=0, output_tokens=0)
        assert usage.input_tokens == 0
        assert usage.output_tokens == 0


# ---------- chat() token usage return tests ----------


def _mock_completion(input_tokens: int = 100, output_tokens: int = 50) -> MagicMock:
    """Create a mock raw completion with usage data."""
    completion = MagicMock()
    completion.usage.input_tokens = input_tokens
    completion.usage.output_tokens = output_tokens
    return completion


class TestChatTokenUsage:
    @pytest.mark.asyncio
    async def test_simple_answer_returns_usage(self, llm_client: LLMClient):
        """chat() returns TokenUsage as the 4th element."""
        llm_client._client.create_with_completion = AsyncMock(
            return_value=(
                AgentResponse(answer="Hello!", topic="greeting"),
                _mock_completion(input_tokens=150, output_tokens=30),
            )
        )
        mock_context = MagicMock()

        response, tools_used, topic, usage = await llm_client.chat(
            "Hi", mock_context, history=[]
        )

        assert response == "Hello!"
        assert isinstance(usage, TokenUsage)
        assert usage.input_tokens == 150
        assert usage.output_tokens == 30

    @pytest.mark.asyncio
    async def test_token_usage_accumulates_across_iterations(
        self, llm_client: LLMClient
    ):
        """Token usage is summed across multiple agent loop iterations."""
        llm_client._client.create_with_completion = AsyncMock(
            side_effect=[
                (
                    AgentResponse(
                        tool_calls=[ToolCallRequest(name="list_files", arguments={})]
                    ),
                    _mock_completion(input_tokens=200, output_tokens=100),
                ),
                (
                    AgentResponse(answer="Here are your files."),
                    _mock_completion(input_tokens=300, output_tokens=50),
                ),
            ]
        )
        with patch.object(
            llm_client.tools,
            "execute_async",
            return_value=ToolResult(content="a.md\nb.md"),
        ):
            mock_context = MagicMock()
            response, tools_used, topic, usage = await llm_client.chat(
                "List files", mock_context, history=[]
            )

        assert usage.input_tokens == 500  # 200 + 300
        assert usage.output_tokens == 150  # 100 + 50

    @pytest.mark.asyncio
    async def test_max_iterations_returns_accumulated_usage(
        self, llm_client: LLMClient
    ):
        """Even when max iterations is hit, accumulated usage is returned."""
        llm_client._client.create_with_completion = AsyncMock(
            return_value=(
                AgentResponse(
                    tool_calls=[ToolCallRequest(name="list_files", arguments={})]
                ),
                _mock_completion(input_tokens=100, output_tokens=50),
            )
        )
        with patch.object(
            llm_client.tools,
            "execute_async",
            return_value=ToolResult(content="files"),
        ):
            mock_context = MagicMock()
            response, tools_used, topic, usage = await llm_client.chat(
                "Loop forever", mock_context, history=[]
            )

        assert usage.input_tokens == 100 * llm_client.MAX_TOOL_ITERATIONS
        assert usage.output_tokens == 50 * llm_client.MAX_TOOL_ITERATIONS


class TestMultimodalChat:
    """Tests for image support in chat()."""

    @pytest.mark.asyncio
    async def test_chat_with_images_sends_multimodal_content(
        self, llm_client: LLMClient
    ):
        """When images are provided, user message should include image blocks."""
        llm_client._client.create_with_completion = AsyncMock(
            return_value=_with_completion(
                AgentResponse(answer="I see a cat in the photo.")
            )
        )
        mock_context = MagicMock()
        images = [{"data": "dGVzdA==", "media_type": "image/jpeg"}]

        response, _, _, _ = await llm_client.chat(
            "What's in this photo?",
            mock_context,
            history=[],
            images=images,
        )

        assert response == "I see a cat in the photo."
        # Verify the messages sent to the API contain image blocks
        call_kwargs = llm_client._client.create_with_completion.call_args[1]
        messages = call_kwargs["messages"]
        user_msg = messages[-1]
        assert user_msg["role"] == "user"
        assert isinstance(user_msg["content"], list)
        types = [block["type"] for block in user_msg["content"]]
        assert "image" in types
        assert "text" in types
        img_block = next(b for b in user_msg["content"] if b["type"] == "image")
        assert img_block["source"]["type"] == "base64"
        assert img_block["source"]["media_type"] == "image/jpeg"
        assert img_block["source"]["data"] == "dGVzdA=="

    @pytest.mark.asyncio
    async def test_chat_without_images_sends_text_content(self, llm_client: LLMClient):
        """When no images, user message should be a plain string."""
        llm_client._client.create_with_completion = AsyncMock(
            return_value=_with_completion(AgentResponse(answer="Hello!"))
        )
        mock_context = MagicMock()

        await llm_client.chat("Hi", mock_context, history=[])

        call_kwargs = llm_client._client.create_with_completion.call_args[1]
        messages = call_kwargs["messages"]
        user_msg = messages[-1]
        assert isinstance(user_msg["content"], str)

    @pytest.mark.asyncio
    async def test_chat_with_multiple_images(self, llm_client: LLMClient):
        """Multiple images should all be included in the message."""
        llm_client._client.create_with_completion = AsyncMock(
            return_value=_with_completion(AgentResponse(answer="Two photos."))
        )
        mock_context = MagicMock()
        images = [
            {"data": "aW1hZ2Ux", "media_type": "image/jpeg"},
            {"data": "aW1hZ2Uy", "media_type": "image/png"},
        ]

        await llm_client.chat(
            "Compare these",
            mock_context,
            history=[],
            images=images,
        )

        call_kwargs = llm_client._client.create_with_completion.call_args[1]
        messages = call_kwargs["messages"]
        user_msg = messages[-1]
        assert isinstance(user_msg["content"], list)
        image_blocks = [b for b in user_msg["content"] if b["type"] == "image"]
        assert len(image_blocks) == 2
