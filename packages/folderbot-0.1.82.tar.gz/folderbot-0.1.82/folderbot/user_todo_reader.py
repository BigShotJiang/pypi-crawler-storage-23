"""Parse hand-written TODO.md files into structured items."""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

CHECKBOX_RE = re.compile(r"^- \[([xX ])\] (.+)$")
BOLD_RE = re.compile(r"\*\*(.+?)\*\*")
SUB_ITEM_RE = re.compile(r"^  - (.+)$")
H2_RE = re.compile(r"^## (.+)$")
H3_RE = re.compile(r"^### (.+)$")

HAS_CHECKBOX_RE = re.compile(r"^- \[[xX ]\] ", re.MULTILINE)


@dataclass(frozen=True)
class UserTodo:
    title: str
    done: bool
    section: str
    sub_items: tuple[str, ...]
    line: int
    file_path: str


def _strip_bold(text: str) -> str:
    return BOLD_RE.sub(r"\1", text)


def parse_user_todos(content: str, file_path: str = "") -> list[UserTodo]:
    if not content.strip():
        return []

    items: list[UserTodo] = []
    lines = content.split("\n")
    section = ""
    subsection = ""
    current_sub_items: list[str] = []
    current_item_data: dict | None = None

    def _flush() -> None:
        if current_item_data is not None:
            items.append(
                UserTodo(
                    title=current_item_data["title"],
                    done=current_item_data["done"],
                    section=current_item_data["section"],
                    sub_items=tuple(current_sub_items),
                    line=current_item_data["line"],
                    file_path=file_path,
                )
            )

    for line_idx, line in enumerate(lines):
        line_num = line_idx + 1

        h2_match = H2_RE.match(line)
        if h2_match:
            _flush()
            current_item_data = None
            current_sub_items = []
            section = h2_match.group(1).strip()
            subsection = ""
            continue

        h3_match = H3_RE.match(line)
        if h3_match:
            _flush()
            current_item_data = None
            current_sub_items = []
            subsection = h3_match.group(1).strip()
            continue

        checkbox_match = CHECKBOX_RE.match(line)
        if checkbox_match:
            _flush()
            current_sub_items = []
            char, raw_title = checkbox_match.groups()
            full_section = section
            if subsection:
                full_section = f"{section} > {subsection}"
            current_item_data = {
                "title": _strip_bold(raw_title).strip(),
                "done": char in ("x", "X"),
                "section": full_section,
                "line": line_num,
            }
            continue

        if current_item_data is not None:
            sub_match = SUB_ITEM_RE.match(line)
            if sub_match:
                current_sub_items.append(_strip_bold(sub_match.group(1)).strip())

    _flush()
    return items


def find_todo_files(root: Path) -> list[Path]:
    results: list[Path] = []
    for path in root.rglob("*.md"):
        if not path.is_file():
            continue
        rel = path.relative_to(root)
        if any(part.startswith(".") for part in rel.parts[:-1]):
            continue
        try:
            content = path.read_text(encoding="utf-8")
        except OSError:
            continue
        if HAS_CHECKBOX_RE.search(content):
            results.append(path)
    results.sort()
    return results
