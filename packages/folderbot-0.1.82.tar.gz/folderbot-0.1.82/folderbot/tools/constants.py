"""Shared constants for tool modules."""

MAX_FILE_READ_CHARS = 50_000
MAX_LIST_FILES = 100
