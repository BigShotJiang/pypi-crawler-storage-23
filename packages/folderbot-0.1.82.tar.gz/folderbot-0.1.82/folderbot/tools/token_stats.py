"""Token statistics with grouping, cost estimation, and time breakdowns."""

from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timedelta
from typing import Any, TYPE_CHECKING

from pydantic import BaseModel, Field

from ..session_manager import TokenUsageRecord
from .base import ToolResult
from .registry import folder_bot, get_service, get_services

if TYPE_CHECKING:
    from ..bot import BotContext

# Default prices per 1M tokens: (input_price, output_price)
DEFAULT_PRICES: dict[str, tuple[float, float]] = {
    "anthropic/claude-sonnet-4-20250514": (3.0, 15.0),
    "anthropic/claude-3-5-sonnet-20241022": (3.0, 15.0),
    "anthropic/claude-3-haiku-20240307": (0.25, 1.25),
    "anthropic/claude-3-opus-20240229": (15.0, 75.0),
    "openai/gpt-4o": (2.5, 10.0),
    "openai/gpt-4o-mini": (0.15, 0.60),
    "openai/gpt-4-turbo": (10.0, 30.0),
    "google/gemini-2.0-flash": (0.10, 0.40),
    "groq/llama-3.1-70b": (0.59, 0.79),
    "deepseek/deepseek-chat": (0.14, 0.28),
    "_default_": (3.0, 15.0),
}


def _estimate_cost(
    input_tokens: int,
    output_tokens: int,
    model: str,
    prices: dict[str, tuple[float, float]],
) -> float:
    """Estimate cost in USD for given token counts and model."""
    input_price, output_price = prices.get(model, prices.get("_default_", (3.0, 15.0)))
    return (input_tokens / 1_000_000) * input_price + (
        output_tokens / 1_000_000
    ) * output_price


def _group_records(
    records: list[TokenUsageRecord],
    group_by: str,
) -> dict[str, dict[str, Any]]:
    """Group token usage records by a dimension.

    Args:
        records: List of token usage records.
        group_by: Grouping dimension: day, week, month, hour, model, topic.

    Returns:
        Dict of group_key -> {input_tokens, output_tokens, count, models}.
    """
    groups: dict[str, dict[str, Any]] = defaultdict(
        lambda: {
            "input_tokens": 0,
            "output_tokens": 0,
            "count": 0,
            "models": set(),
        }
    )

    for r in records:
        if group_by == "day":
            key = r.created_at[:10]  # YYYY-MM-DD
        elif group_by == "month":
            key = r.created_at[:7]  # YYYY-MM
        elif group_by == "week":
            dt = datetime.fromisoformat(r.created_at)
            week_start = dt - timedelta(days=dt.weekday())
            key = week_start.strftime("%Y-%m-%d")
        elif group_by == "hour":
            key = r.created_at[:13]  # YYYY-MM-DDTHH
        elif group_by == "model":
            key = r.model
        elif group_by == "topic":
            key = r.topic
        else:
            key = "all"

        groups[key]["input_tokens"] += r.input_tokens
        groups[key]["output_tokens"] += r.output_tokens
        groups[key]["count"] += 1
        groups[key]["models"].add(r.model)

    return dict(groups)


def _period_to_since(period: str, days: int) -> str:
    """Convert period/days to an ISO datetime string for filtering."""
    now = datetime.now()
    if period == "today":
        since = now.replace(hour=0, minute=0, second=0, microsecond=0)
    elif period == "week":
        since = now - timedelta(days=7)
    elif period == "month":
        since = now - timedelta(days=30)
    elif period == "all":
        since = datetime(2000, 1, 1)
    else:
        since = now - timedelta(days=days)
    return since.isoformat()


class TokenStatsRequest(BaseModel, frozen=True):
    """Request for detailed token usage statistics."""

    period: str = Field(
        default="week",
        description=(
            "Time period: 'today', 'week', 'month', 'all', "
            "or use 'days' parameter for custom range."
        ),
    )
    days: int = Field(
        default=7,
        description="Custom lookback in days (used when period is not set).",
    )
    group_by: str | None = Field(
        default=None,
        description=(
            "Group results by: 'day', 'week', 'month', 'hour', 'model', or 'topic'. "
            "Leave empty for totals only."
        ),
    )


@folder_bot.tool(
    name="token_stats",
    request_type=TokenStatsRequest,
    response_type=ToolResult,
)
async def token_stats(
    request: TokenStatsRequest, _context: BotContext | None = None
) -> ToolResult:
    """Get detailed token usage statistics with cost estimates.

    Shows token consumption and estimated costs, with optional grouping
    by time period (day/week/month/hour), model, or topic. Use this when
    the user asks about their usage, costs, or consumption patterns.

    For "how much did I spend this month?" use period="month".
    For "show daily breakdown" use group_by="day".
    For "which model costs the most?" use group_by="model".
    """
    if _context is None:
        return ToolResult(content="Token stats not available.", is_error=True)

    session_manager = get_service(_context, "session")
    if session_manager is None:
        return ToolResult(content="Token stats not available.", is_error=True)

    # Load pricing (can be overridden via [tools.token_stats])
    prices = dict(DEFAULT_PRICES)
    services = get_services(_context)
    if services is not None:
        tool_cfg = services.get_tool_config("token_stats")
        custom_prices = tool_cfg.get("prices", {})
        for model, price_pair in custom_prices.items():
            if isinstance(price_pair, (list, tuple)) and len(price_pair) == 2:
                prices[model] = (float(price_pair[0]), float(price_pair[1]))

    since = _period_to_since(request.period, request.days)
    records = session_manager.get_token_usage(user_id=_context.user_id, since=since)

    if not records:
        return ToolResult(content=f"No token usage recorded for {request.period}.")

    # Calculate totals
    total_input = sum(r.input_tokens for r in records)
    total_output = sum(r.output_tokens for r in records)
    total_cost = sum(
        _estimate_cost(r.input_tokens, r.output_tokens, r.model, prices)
        for r in records
    )

    lines = [
        f"Token usage ({request.period}, {len(records)} calls):",
        f"  Input:  {total_input:,} tokens",
        f"  Output: {total_output:,} tokens",
        f"  Total:  {total_input + total_output:,} tokens",
        f"  Cost:   ${total_cost:.4f}",
    ]

    # Add grouped breakdown if requested
    if request.group_by:
        groups = _group_records(records, request.group_by)
        if groups:
            lines.append(f"\nBreakdown by {request.group_by}:")
            for key in sorted(groups.keys()):
                g = groups[key]
                g_cost = sum(
                    _estimate_cost(r.input_tokens, r.output_tokens, r.model, prices)
                    for r in records
                    if _record_matches_group(r, request.group_by, key)
                )
                lines.append(
                    f"  {key}: {g['input_tokens'] + g['output_tokens']:,} tokens "
                    f"({g['count']} calls, ${g_cost:.4f})"
                )

    return ToolResult(content="\n".join(lines))


def _record_matches_group(record: TokenUsageRecord, group_by: str, key: str) -> bool:
    """Check if a record belongs to a specific group."""
    if group_by == "day":
        return record.created_at[:10] == key
    elif group_by == "month":
        return record.created_at[:7] == key
    elif group_by == "hour":
        return record.created_at[:13] == key
    elif group_by == "week":
        dt = datetime.fromisoformat(record.created_at)
        week_start = dt - timedelta(days=dt.weekday())
        return week_start.strftime("%Y-%m-%d") == key
    elif group_by == "model":
        return record.model == key
    elif group_by == "topic":
        return record.topic == key
    return True
