"""Todo management tools for procrastinator-friendly task tracking."""

from __future__ import annotations

from typing import TYPE_CHECKING

from pydantic import BaseModel, Field

from .base import ToolResult
from .registry import folder_bot, get_root, get_service

if TYPE_CHECKING:
    from ..bot import BotContext
    from ..todo_store import TodoItem, TodoStore
    from ..user_todo_reader import UserTodo


def _format_item(item: TodoItem) -> str:
    status_icons = {"todo": "[ ]", "in_progress": "[~]", "done": "[x]"}
    icon = status_icons.get(item.status, "[ ]")
    tag_str = " ".join(f"+{t}" for t in item.tags) if item.tags else ""
    title_line = f"{icon} {item.title}"
    if tag_str:
        title_line += f" {tag_str}"
    parts = [title_line]
    if item.description:
        parts.append(f"    {item.description}")
    details: list[str] = []
    if item.effort != "medium":
        details.append(f"effort: {item.effort}")
    if item.status == "in_progress":
        details.append("status: in progress")
    if item.completed_at:
        details.append(f"completed: {item.completed_at[:10]}")
    if details:
        parts.append(f"    ({'; '.join(details)})")
    return "\n".join(parts)


def _format_user_todo(item: UserTodo) -> str:
    icon = "[x]" if item.done else "[ ]"
    parts = [f"{icon} {item.title}"]
    for sub in item.sub_items:
        parts.append(f"    - {sub}")
    return "\n".join(parts)


def _format_user_todos(
    items: list[UserTodo],
    *,
    include_done: bool = False,
    search: str | None = None,
) -> str:
    filtered = items
    if not include_done:
        filtered = [i for i in filtered if not i.done]
    if search:
        pattern = search.lower()
        filtered = [i for i in filtered if pattern in i.title.lower()]
    if not filtered:
        return ""

    files: dict[str, dict[str, list[UserTodo]]] = {}
    for item in filtered:
        fkey = item.file_path or "(unknown)"
        skey = item.section or "(No section)"
        files.setdefault(fkey, {}).setdefault(skey, []).append(item)

    multi_file = len(files) > 1
    parts: list[str] = []
    for file_path, sections in files.items():
        if multi_file:
            parts.append(f"## {file_path}")
        for section, section_items in sections.items():
            parts.append(f"### {section}")
            for item in section_items:
                parts.append(_format_user_todo(item))
    return "\n".join(parts)


def _scan_user_todos(context: BotContext | None) -> list[UserTodo]:
    from ..user_todo_reader import find_todo_files, parse_user_todos

    root = get_root(context)
    if root is None:
        return []
    todo_files = find_todo_files(root)
    all_items: list[UserTodo] = []
    for path in todo_files:
        try:
            content = path.read_text(encoding="utf-8")
            rel_path = str(path.relative_to(root))
            all_items.extend(parse_user_todos(content, file_path=rel_path))
        except OSError:
            continue
    return all_items


# --- Request Models ---


class TodoAddRequest(BaseModel, frozen=True):
    """Request to add a new todo item."""

    title: str = Field(description="Short title for the task")
    description: str = Field(
        default="",
        description="Optional longer description with details",
    )
    effort: str = Field(
        default="medium",
        description=(
            "Effort estimate: tiny (under 5 min), small (5-30 min), "
            "medium (30-60 min), large (1-3 hours), epic (half day+)"
        ),
    )
    tags: list[str] = Field(
        default_factory=list,
        description="Tags for categorization (e.g. work, home, errands)",
    )


class TodoListRequest(BaseModel, frozen=True):
    """Request to list todo items with optional filters."""

    status: str | None = Field(
        default=None,
        description="Filter by status: todo, in_progress, or done",
    )
    max_effort: str | None = Field(
        default=None,
        description=(
            "Maximum effort level to include. "
            "E.g. 'small' returns tiny and small tasks — "
            "perfect for 'what can I do in 30 minutes?'"
        ),
    )
    tag: str | None = Field(
        default=None,
        description="Filter by tag",
    )
    search: str | None = Field(
        default=None,
        description="Search in title and description",
    )
    include_done: bool = Field(
        default=False,
        description="Include completed tasks (excluded by default)",
    )


class TodoUpdateRequest(BaseModel, frozen=True):
    """Request to update an existing todo item."""

    todo_id: int = Field(description="ID of the todo to update")
    title: str | None = Field(default=None, description="New title")
    description: str | None = Field(default=None, description="New description")
    status: str | None = Field(
        default=None,
        description="New status: todo, in_progress, or done",
    )
    effort: str | None = Field(
        default=None,
        description="New effort level: tiny, small, medium, large, or epic",
    )
    tags: list[str] | None = Field(default=None, description="New tags list")


class TodoRemoveRequest(BaseModel, frozen=True):
    """Request to remove a todo item."""

    todo_id: int = Field(description="ID of the todo to remove")


# --- Tool Functions ---


@folder_bot.tool(
    name="todo_add",
    request_type=TodoAddRequest,
    response_type=ToolResult,
)
async def todo_add(
    request: TodoAddRequest, _context: BotContext | None = None
) -> ToolResult:
    """Add a new todo item.

    Use this when the user wants to track a task, reminder, or anything
    they need to get done. Estimate the effort naturally from what they say.
    """
    store: TodoStore | None = get_service(_context, "todo")
    if store is None:
        return ToolResult(
            content="Todo management not available: service not configured.",
            is_error=True,
        )
    try:
        item = store.add(
            user_id=_context.user_id if _context else 0,
            title=request.title,
            description=request.description,
            effort=request.effort,
            tags=request.tags if request.tags else None,
        )
        return ToolResult(content=f"Added todo #{item.id}:\n{_format_item(item)}")
    except ValueError as e:
        return ToolResult(content=f"Error adding todo: {e}", is_error=True)


@folder_bot.tool(
    name="todo_list",
    request_type=TodoListRequest,
    response_type=ToolResult,
)
async def todo_list(
    request: TodoListRequest, _context: BotContext | None = None
) -> ToolResult:
    """List todo items with optional filters.

    Use this to show the user's tasks. Supports filtering by status,
    effort level, tags, and text search. By default, completed tasks
    are hidden.

    For "what can I do in 30 minutes?" use max_effort="small".
    For "what's on my plate?" use no filters.
    For "show me work tasks" use tag="work".
    """
    store: TodoStore | None = get_service(_context, "todo")
    if store is None:
        return ToolResult(
            content="Todo management not available: service not configured.",
            is_error=True,
        )

    user_todos = _scan_user_todos(_context)
    user_section = _format_user_todos(
        user_todos,
        include_done=request.include_done,
        search=request.search,
    )

    user_id = _context.user_id if _context else 0
    managed_items = store.list(
        user_id=user_id,
        status=request.status,
        max_effort=request.max_effort,
        tag=request.tag,
        search=request.search,
        include_done=request.include_done,
    )

    if not user_section and not managed_items:
        if request.max_effort:
            return ToolResult(
                content=f"No tasks found with effort up to '{request.max_effort}'."
            )
        if request.tag:
            return ToolResult(content=f"No tasks found with tag '{request.tag}'.")
        if request.status:
            return ToolResult(content=f"No tasks with status '{request.status}'.")
        if request.search:
            return ToolResult(content=f"No tasks matching '{request.search}'.")
        return ToolResult(content="No active todos. Your list is empty!")

    parts: list[str] = []
    if user_section:
        parts.append(user_section)
    if managed_items:
        if user_section:
            parts.append("\n---\n### Managed")
        formatted = "\n\n".join(_format_item(i) for i in managed_items)
        parts.append(formatted)
        stats = store.stats(user_id)
        summary = (
            f"--- {stats['todo']} todo, {stats['in_progress']} in progress, "
            f"{stats['done']} done ({stats['total']} total) ---"
        )
        parts.append(summary)

    return ToolResult(content="\n".join(parts))


@folder_bot.tool(
    name="todo_update",
    request_type=TodoUpdateRequest,
    response_type=ToolResult,
)
async def todo_update(
    request: TodoUpdateRequest, _context: BotContext | None = None
) -> ToolResult:
    """Update an existing todo item.

    Use this to change a task's status, title, description, effort, or tags.
    Mark tasks as 'done' when the user completes them, or 'in_progress'
    when they start working on something.
    """
    store: TodoStore | None = get_service(_context, "todo")
    if store is None:
        return ToolResult(
            content="Todo management not available: service not configured.",
            is_error=True,
        )
    try:
        updated = store.update(
            todo_id=request.todo_id,
            user_id=_context.user_id if _context else 0,
            title=request.title,
            description=request.description,
            status=request.status,
            effort=request.effort,
            tags=request.tags,
        )
    except ValueError as e:
        return ToolResult(content=f"Error updating todo: {e}", is_error=True)

    if updated is None:
        return ToolResult(
            content=f"Todo #{request.todo_id} not found.",
            is_error=True,
        )
    return ToolResult(content=f"Updated todo #{updated.id}:\n{_format_item(updated)}")


@folder_bot.tool(
    name="todo_remove",
    request_type=TodoRemoveRequest,
    response_type=ToolResult,
)
async def todo_remove(
    request: TodoRemoveRequest, _context: BotContext | None = None
) -> ToolResult:
    """Remove a todo item permanently.

    Use this when the user wants to delete a task entirely (not just mark done).
    """
    store: TodoStore | None = get_service(_context, "todo")
    if store is None:
        return ToolResult(
            content="Todo management not available: service not configured.",
            is_error=True,
        )
    removed = store.remove(
        todo_id=request.todo_id,
        user_id=_context.user_id if _context else 0,
    )
    if not removed:
        return ToolResult(
            content=f"Todo #{request.todo_id} not found.",
            is_error=True,
        )
    return ToolResult(content=f"Removed todo #{request.todo_id}.")
