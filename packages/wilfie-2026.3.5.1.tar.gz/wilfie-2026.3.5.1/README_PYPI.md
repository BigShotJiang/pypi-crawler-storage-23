# Wilfie CLI

Wilfie is a command-line client for Wilfie APIs.

Use it to authenticate and run workspace, workflow, and WMS commands from your terminal.

## Install

```bash
uv tool install wilfie
```

Or with `pip`:

```bash
pip install wilfie
```

## Quickstart

Login with device flow:

```bash
wilfie auth login --client-id wilfie-cli
```

Check auth status:

```bash
wilfie auth status
```

List workspaces:

```bash
wilfie workspaces list
```

Run a WMS query:

```bash
wilfie wms query \
  --workspace <workspace_code> \
  --path facility-locations/search \
  --param query=A-01 \
  --param limit=25
```

Inspect fulfillment document lineage:

```bash
wilfie wms documents lineage \
  --workspace <workspace_code> \
  --kind fulfillment_order \
  --document-id <fulfillment_order_id> \
  --line-id <line_id> \
  --max-depth 8
```

Resolve a barcode and inspect tote outbound context:

```bash
wilfie wms barcodes resolve \
  --workspace <workspace_code> \
  --facility-id <facility_id> \
  --barcode <scan_value>

wilfie wms containers outbound-context \
  --workspace <workspace_code> \
  --container-id <container_id>
```

Run Shopify outbound reconcile (manual trigger):

```bash
wilfie wms reconcile outbound \
  --workspace <workspace_code> \
  --integration-connection-id <integration_connection_id> \
  --order-id gid://shopify/Order/123 \
  --dry-run
```

List open WMS issues for a facility:

```bash
wilfie wms issues list \
  --workspace <workspace_code> \
  --facility-id <facility_id> \
  --status open
```

Recompute WMS issues for a facility (admin/owner access required):

```bash
wilfie wms issues recompute \
  --workspace <workspace_code> \
  --facility-id <facility_id> \
  --dry-run
```

## Common Commands

- `wilfie auth login`
- `wilfie auth refresh`
- `wilfie auth logout`
- `wilfie workflows list --workspace <workspace_code>`
- `wilfie workflows execute --workspace <workspace_code> --workflow-id <id>`
- `wilfie wms facilities --workspace <workspace_code>`
- `wilfie wms skus --workspace <workspace_code>`
- `wilfie wms documents list --workspace <workspace_code> --kind fulfillment_order`
- `wilfie wms documents detail --workspace <workspace_code> --kind fulfillment_order --document-id <id>`
- `wilfie wms documents lineage --workspace <workspace_code> --kind fulfillment_order --document-id <id> --line-id <id>`
- `wilfie wms barcodes resolve --workspace <workspace_code> --facility-id <facility_id> --barcode <scan_value>`
- `wilfie wms containers outbound-context --workspace <workspace_code> --container-id <container_id>`
- `wilfie wms issues list --workspace <workspace_code> [--facility-id <facility_id>] [--status <open|ignored|resolved>]`
- `wilfie wms issues recompute --workspace <workspace_code> [--facility-id <facility_id>] [--scope <scope>] [--dry-run]`
- `wilfie wms reconcile outbound --workspace <workspace_code> --integration-connection-id <id> [--order-id <shopify_order_id>] [--fulfillment-order-id <shopify_fo_id>] [--dry-run]`

## Configuration

- Default API host is `https://wilfie.ai`.
- Use `--base-url` to target another environment.
- Output modes: `--output table` (default), `--output json`.

## Links

- Homepage: <https://wilfie.ai>
- Documentation: <https://github.com/gavincliffe/wilfie-flask-app/tree/main/docs>
