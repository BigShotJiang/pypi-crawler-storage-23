from ._spaces import EmptySpaces

__all__ = ["EmptySpaces"]
