from cognite.neat._data_model.rules._base import NeatRule


class CDFRule(NeatRule):
    """Rules for validating entire CDF."""
