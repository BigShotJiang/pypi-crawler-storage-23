"""Package-backed MCP adapter for data quality tools."""

from src.data_quality.mcp_impl import register_data_quality_tools

__all__ = ["register_data_quality_tools"]
