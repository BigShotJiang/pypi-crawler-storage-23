"""Tests for prompt template functions."""

from __future__ import annotations

from imager.prompts import (
    combine_prompt,
    create_prompt,
    diagram_enhance_prompt,
    diagram_prompt,
    edit_prompt,
    icon_prompt,
    story_character_prompt,
    story_scene_prompt,
)


class TestCreatePrompt:
    def test_passthrough(self):
        assert create_prompt("a red cat") == "a red cat"


class TestEditPrompt:
    def test_includes_instruction(self):
        result = edit_prompt("make it blue")
        assert "make it blue" in result
        assert "Preserve" in result


class TestIconPrompt:
    def test_includes_flat_style(self):
        result = icon_prompt("a gear")
        assert "flat-style" in result

    def test_includes_white_background(self):
        result = icon_prompt("a gear")
        assert "White" in result or "white" in result.lower()

    def test_includes_user_prompt(self):
        result = icon_prompt("a rocket ship")
        assert "a rocket ship" in result


class TestDiagramPrompt:
    def test_includes_user_prompt(self):
        result = diagram_prompt("class hierarchy")
        assert "class hierarchy" in result
        assert "diagram" in result.lower()


class TestDiagramEnhancePrompt:
    def test_includes_user_prompt(self):
        result = diagram_enhance_prompt("add colors")
        assert "add colors" in result
        assert "Enhance" in result


class TestCombinePrompt:
    def test_includes_user_prompt(self):
        result = combine_prompt("side by side")
        assert "side by side" in result
        assert "Combine" in result


class TestStoryCharacterPrompt:
    def test_includes_name_and_appearance(self):
        result = story_character_prompt("Alice", "tall with red hair")
        assert "Alice" in result
        assert "tall with red hair" in result


class TestStoryScenePrompt:
    def test_basic(self):
        result = story_scene_prompt(
            "The heroes arrive", "watercolor", ["Alice: tall", "Bob: short"],
        )
        assert "The heroes arrive" in result
        assert "watercolor" in result
        assert "Alice: tall" in result

    def test_with_scene_number(self):
        result = story_scene_prompt(
            "Battle", "oil painting", [],
            scene_number=3, total_scenes=5,
        )
        assert "scene 3 of 5" in result

    def test_with_setting(self):
        result = story_scene_prompt(
            "Intro", "digital", [],
            setting="A dark forest",
        )
        assert "A dark forest" in result

    def test_with_previous_scene(self):
        result = story_scene_prompt(
            "Next part", "anime", [],
            previous_scene="The door opened",
        )
        assert "The door opened" in result

    def test_continuity_instruction(self):
        result = story_scene_prompt("test", "style", [])
        assert "continuity" in result.lower()
