"""Shared test fixtures — mock API responses, temp dirs, fake images."""

from __future__ import annotations

import base64
import io
from unittest.mock import AsyncMock, patch

import pytest
from PIL import Image


# ---------------------------------------------------------------------------
# Tiny valid PNG (1×1 pixel, RGBA) for image processing tests
# ---------------------------------------------------------------------------

def _make_tiny_png() -> bytes:
    buf = io.BytesIO()
    Image.new("RGBA", (1, 1), (255, 0, 0, 128)).save(buf, format="PNG")
    return buf.getvalue()


TINY_PNG = _make_tiny_png()
TINY_PNG_B64 = base64.b64encode(TINY_PNG).decode()
TINY_PNG_DATA_URL = f"data:image/png;base64,{TINY_PNG_B64}"


# ---------------------------------------------------------------------------
# Fake API responses
# ---------------------------------------------------------------------------

FAKE_IMAGE_RESPONSE = {
    "choices": [
        {
            "message": {
                "images": [
                    {"image_url": {"url": TINY_PNG_DATA_URL}}
                ],
                "content": "A beautiful sunset over the ocean.",
            }
        }
    ],
    "usage": {"cost": 0.06},
    "model": "google/gemini-2.5-flash-image",
}

FAKE_NO_IMAGE_RESPONSE = {
    "choices": [
        {
            "message": {
                "content": "I cannot generate that image.",
            }
        }
    ],
    "usage": {},
    "model": "google/gemini-2.5-flash-image",
}

FAKE_CONTENT_LIST_RESPONSE = {
    "choices": [
        {
            "message": {
                "content": [
                    {"type": "text", "text": "Here is the image."},
                    {"type": "image_url", "image_url": {"url": TINY_PNG_DATA_URL}},
                ],
            }
        }
    ],
    "usage": {"cost": 0.10},
    "model": "google/gemini-2.5-flash-image",
}

FAKE_CREDITS = {"data": {"total_credits": 10.0, "total_usage": 3.5}}


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def mock_client():
    """An AsyncMock standing in for OpenRouterClient."""
    client = AsyncMock()
    client.generate_image.return_value = FAKE_IMAGE_RESPONSE
    client.get_credits.return_value = {"total_credits": 10.0, "total_usage": 3.5}
    return client


@pytest.fixture
def mock_get_client(mock_client):
    """Patch get_client() to return the mock client."""
    with patch("imager.operations.get_client", return_value=mock_client):
        yield mock_client


@pytest.fixture
def mock_api_key():
    """Patch get_api_key so client construction never fails."""
    with patch("imager.client.get_api_key", return_value="test-key-123"):
        yield
