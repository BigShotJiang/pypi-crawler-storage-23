"""Tests for business logic operations."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock, patch

import pytest

from imager.operations import (
    _extract_cost,
    _extract_images,
    _extract_text,
    _human_size,
    _make_result,
    create_icon,
    create_image,
    generate_story,
    get_credits,
    list_models,
)
from tests.conftest import (
    FAKE_CONTENT_LIST_RESPONSE,
    FAKE_IMAGE_RESPONSE,
    FAKE_NO_IMAGE_RESPONSE,
    TINY_PNG_DATA_URL,
)


# ---------------------------------------------------------------------------
# _extract_images()
# ---------------------------------------------------------------------------

class TestExtractImages:
    def test_from_images_array(self):
        imgs = _extract_images(FAKE_IMAGE_RESPONSE)
        assert len(imgs) == 1
        assert imgs[0].startswith("data:image/png")

    def test_from_content_list(self):
        imgs = _extract_images(FAKE_CONTENT_LIST_RESPONSE)
        assert len(imgs) == 1

    def test_empty_response(self):
        assert _extract_images({"choices": []}) == []

    def test_no_images_in_message(self):
        assert _extract_images(FAKE_NO_IMAGE_RESPONSE) == []


# ---------------------------------------------------------------------------
# _extract_text()
# ---------------------------------------------------------------------------

class TestExtractText:
    def test_string_content(self):
        text = _extract_text(FAKE_IMAGE_RESPONSE)
        assert text == "A beautiful sunset over the ocean."

    def test_list_content(self):
        text = _extract_text(FAKE_CONTENT_LIST_RESPONSE)
        assert "Here is the image" in text

    def test_empty_response(self):
        assert _extract_text({"choices": []}) == ""


# ---------------------------------------------------------------------------
# _extract_cost()
# ---------------------------------------------------------------------------

class TestExtractCost:
    def test_present(self):
        assert _extract_cost(FAKE_IMAGE_RESPONSE) == 0.06

    def test_missing(self):
        assert _extract_cost({"usage": {}}) is None

    def test_no_usage(self):
        assert _extract_cost({}) is None


# ---------------------------------------------------------------------------
# _human_size()
# ---------------------------------------------------------------------------

class TestHumanSize:
    def test_bytes(self):
        assert _human_size(500) == "500.0 B"

    def test_kb(self):
        assert _human_size(2048) == "2.0 KB"

    def test_mb(self):
        assert _human_size(1024 * 1024 * 3) == "3.0 MB"

    def test_gb(self):
        assert _human_size(1024**3 * 2) == "2.0 GB"


# ---------------------------------------------------------------------------
# _make_result()
# ---------------------------------------------------------------------------

class TestMakeResult:
    def test_builds_correct_dict(self, tmp_path):
        f = tmp_path / "test.png"
        f.write_bytes(b"x" * 1024)
        result = _make_result(f, FAKE_IMAGE_RESPONSE)
        assert result["file"] == str(f)
        assert result["size_bytes"] == 1024
        assert result["size_human"] == "1.0 KB"
        assert result["cost"] == 0.06
        assert result["model"] == "google/gemini-2.5-flash-image"
        assert "sunset" in result["text"]


# ---------------------------------------------------------------------------
# create_image()
# ---------------------------------------------------------------------------

class TestCreateImage:
    async def test_success(self, mock_get_client, tmp_path):
        result = await create_image(
            "a sunset", output_dir=str(tmp_path),
        )
        assert "file" in result
        assert result["cost"] == 0.06
        assert Path(result["file"]).exists()

    async def test_no_image_returns_error(self, mock_get_client, tmp_path):
        mock_get_client.generate_image.return_value = FAKE_NO_IMAGE_RESPONSE
        result = await create_image("bad prompt", output_dir=str(tmp_path))
        assert "error" in result
        assert result["error"] == "No image generated"

    async def test_invalid_aspect_ratio_raises(self, mock_get_client):
        with pytest.raises(ValueError, match="doesn't support"):
            await create_image("test", aspect_ratio="99:1")


# ---------------------------------------------------------------------------
# create_icon()
# ---------------------------------------------------------------------------

class TestCreateIcon:
    async def test_defaults_to_square(self, mock_get_client, tmp_path):
        result = await create_icon("gear", output_dir=str(tmp_path))
        # Should succeed — default is 1:1
        assert "file" in result

    async def test_fixed_size_model_picks_square(self, mock_get_client, tmp_path):
        """When using GPT-5 (fixed sizes), icon should pick 1024x1024."""
        result = await create_icon(
            "gear", model="gpt5", output_dir=str(tmp_path),
        )
        assert "file" in result
        # Verify the call used 1024x1024
        call_kwargs = mock_get_client.generate_image.call_args.kwargs
        # The image_config should have size=1024x1024
        cfg = call_kwargs.get("image_config", {})
        assert cfg.get("size") == "1024x1024"


# ---------------------------------------------------------------------------
# generate_story()
# ---------------------------------------------------------------------------

class TestGenerateStory:
    @pytest.fixture
    def storyboard(self, tmp_path):
        sb = {
            "title": "Test Story",
            "style": "watercolor",
            "characters": [
                {"name": "Alice", "appearance": "tall with red hair"},
            ],
            "scenes": [
                {"title": "Arrival", "prompt": "Alice arrives at the castle"},
            ],
        }
        path = tmp_path / "story.json"
        path.write_text(json.dumps(sb))
        return path

    async def test_generates_story(self, mock_get_client, storyboard, tmp_path):
        result = await generate_story(
            str(storyboard), output_dir=str(tmp_path),
        )
        assert result["title"] == "Test Story"
        assert len(result["scenes"]) == 1
        assert Path(result["gallery"]).exists()

    async def test_missing_character_name_raises(self, mock_get_client, tmp_path):
        sb = {"title": "Bad", "characters": [{"appearance": "tall"}], "scenes": []}
        path = tmp_path / "bad.json"
        path.write_text(json.dumps(sb))
        with pytest.raises(ValueError, match="missing required 'name'"):
            await generate_story(str(path))

    async def test_missing_character_appearance_raises(self, mock_get_client, tmp_path):
        sb = {"title": "Bad", "characters": [{"name": "Bob"}], "scenes": []}
        path = tmp_path / "bad.json"
        path.write_text(json.dumps(sb))
        with pytest.raises(ValueError, match="missing required 'appearance'"):
            await generate_story(str(path))

    async def test_gallery_html_escapes_title(self, mock_get_client, tmp_path):
        sb = {
            "title": '<script>alert("xss")</script>',
            "style": "cartoon",
            "characters": [],
            "scenes": [{"title": "Scene 1", "prompt": "A field"}],
        }
        path = tmp_path / "xss.json"
        path.write_text(json.dumps(sb))
        result = await generate_story(str(path), output_dir=str(tmp_path))
        gallery_html = Path(result["gallery"]).read_text()
        assert "<script>" not in gallery_html
        assert "&lt;script&gt;" in gallery_html


# ---------------------------------------------------------------------------
# get_credits()
# ---------------------------------------------------------------------------

class TestGetCredits:
    async def test_returns_formatted(self, mock_get_client):
        result = await get_credits()
        assert result["total_credits"] == 10.0
        assert result["total_usage"] == 3.5
        assert result["remaining"] == 6.5


# ---------------------------------------------------------------------------
# list_models()
# ---------------------------------------------------------------------------

class TestListModels:
    def test_returns_all_models(self):
        models = list_models()
        assert len(models) >= 4
        ids = {m["id"] for m in models}
        assert "google/gemini-2.5-flash-image" in ids

    def test_model_has_expected_keys(self):
        models = list_models()
        for m in models:
            assert "id" in m
            assert "name" in m
            assert "can_generate" in m
            assert "can_edit" in m
            assert "cost_note" in m
