"""Tests for model registry, validation, and resolution."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from imager.models import (
    COMMAND_DEFAULTS,
    MODEL_ALIASES,
    MODELS,
    ModelSpec,
    resolve_model,
)


# ---------------------------------------------------------------------------
# ModelSpec.validate()
# ---------------------------------------------------------------------------

class TestModelSpecValidate:
    def test_valid_aspect_ratio(self):
        spec = MODELS["google/gemini-2.5-flash-image"]
        assert spec.validate("16:9", None, None) == []

    def test_invalid_aspect_ratio(self):
        spec = MODELS["google/gemini-2.5-flash-image"]
        errors = spec.validate("99:1", None, None)
        assert len(errors) == 1
        assert "99:1" in errors[0]

    def test_valid_image_size(self):
        spec = MODELS["google/gemini-2.5-flash-image"]
        assert spec.validate(None, "2K", None) == []

    def test_invalid_image_size(self):
        spec = MODELS["google/gemini-2.5-flash-image"]
        errors = spec.validate(None, "8K", None)
        assert len(errors) == 1
        assert "8K" in errors[0]

    def test_fixed_size_accepted(self):
        """GPT-5 uses fixed_sizes instead of aspect_ratios."""
        spec = MODELS["openai/gpt-5-image"]
        assert spec.validate("1024x1024", None, None) == []

    def test_fixed_size_invalid(self):
        spec = MODELS["openai/gpt-5-image"]
        errors = spec.validate("800x600", None, None)
        assert len(errors) == 1

    def test_none_params_valid(self):
        spec = MODELS["google/gemini-2.5-flash-image"]
        assert spec.validate(None, None, None) == []

    def test_multiple_errors(self):
        spec = MODELS["google/gemini-2.5-flash-image"]
        errors = spec.validate("99:1", "8K", None)
        assert len(errors) == 2


class TestModelSpecSupports:
    def test_supports_aspect_ratio(self):
        spec = MODELS["google/gemini-2.5-flash-image"]
        assert spec.supports_aspect_ratio("1:1") is True
        assert spec.supports_aspect_ratio("99:1") is False

    def test_supports_image_size(self):
        spec = MODELS["google/gemini-2.5-flash-image"]
        assert spec.supports_image_size("1K") is True
        assert spec.supports_image_size("8K") is False

    def test_supports_format(self):
        spec = MODELS["black-forest-labs/flux.2-pro"]
        assert spec.supports_format("png") is True
        assert spec.supports_format("webp") is True
        assert spec.supports_format("bmp") is False


# ---------------------------------------------------------------------------
# resolve_model()
# ---------------------------------------------------------------------------

class TestResolveModel:
    def test_by_full_id(self):
        spec = resolve_model("google/gemini-2.5-flash-image")
        assert spec.id == "google/gemini-2.5-flash-image"

    def test_by_alias(self):
        spec = resolve_model("gemini")
        assert spec.id == "google/gemini-2.5-flash-image"

    def test_by_alias_flux(self):
        spec = resolve_model("flux")
        assert spec.id == "black-forest-labs/flux.2-pro"

    def test_unknown_raises(self):
        with pytest.raises(ValueError, match="Unknown model"):
            resolve_model("nonexistent-model")

    def test_none_uses_command_default(self):
        spec = resolve_model(None, command="create")
        assert spec.id == COMMAND_DEFAULTS["create"]

    def test_none_uses_config_override(self):
        with patch("imager.config.load_config", return_value={"default_model": "flux"}):
            spec = resolve_model(None, command="create")
            assert spec.id == "black-forest-labs/flux.2-pro"


# ---------------------------------------------------------------------------
# Registry integrity
# ---------------------------------------------------------------------------

class TestRegistry:
    def test_models_not_empty(self):
        assert len(MODELS) >= 4

    def test_all_models_have_id_matching_key(self):
        for key, spec in MODELS.items():
            assert key == spec.id

    def test_all_aliases_point_to_valid_models(self):
        for alias, model_id in MODEL_ALIASES.items():
            assert model_id in MODELS, f"Alias '{alias}' points to unknown model '{model_id}'"

    def test_command_defaults_are_valid_models(self):
        for cmd, model_id in COMMAND_DEFAULTS.items():
            assert model_id in MODELS, f"Command '{cmd}' defaults to unknown model '{model_id}'"
