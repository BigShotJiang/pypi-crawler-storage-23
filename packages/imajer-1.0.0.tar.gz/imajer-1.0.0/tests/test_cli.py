"""Tests for CLI commands via Typer test runner."""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest
import typer
from typer.testing import CliRunner

from imager.cli import _resolve_input, _show_result, app

runner = CliRunner()


# ---------------------------------------------------------------------------
# _resolve_input()
# ---------------------------------------------------------------------------

class TestResolveInput:
    def test_regular_path(self):
        assert _resolve_input("/some/path.png") == "/some/path.png"

    def test_stdin_dash(self, monkeypatch):
        monkeypatch.setattr("sys.stdin", type("FakeStdin", (), {"readline": lambda self: "/piped/path.png\n"})())
        assert _resolve_input("-") == "/piped/path.png"

    def test_stdin_empty_exits(self, monkeypatch):
        monkeypatch.setattr("sys.stdin", type("FakeStdin", (), {"readline": lambda self: "\n"})())
        with pytest.raises(typer.Exit):
            _resolve_input("-")


# ---------------------------------------------------------------------------
# _show_result()
# ---------------------------------------------------------------------------

class TestShowResult:
    def test_error_result_exits(self):
        with pytest.raises(typer.Exit):
            _show_result({"error": "Something went wrong"})

    def test_success_result(self, capsys, tmp_path):
        f = tmp_path / "test.png"
        f.write_bytes(b"x")
        _show_result({"file": str(f), "size_human": "1 B", "cost": 0.05})
        captured = capsys.readouterr()
        assert str(f) in captured.out

    def test_quiet_mode(self, capsys, tmp_path):
        f = tmp_path / "test.png"
        f.write_bytes(b"x")
        _show_result({"file": str(f), "size_human": "1 B"}, quiet=True)
        captured = capsys.readouterr()
        assert str(f) in captured.out


# ---------------------------------------------------------------------------
# CLI commands
# ---------------------------------------------------------------------------

class TestCreateCmd:
    def test_invokes_create(self):
        with patch("imager.cli.operations.create_image", new_callable=AsyncMock) as mock_create:
            mock_create.return_value = {"file": "/tmp/test.png", "size_human": "10 KB", "cost": 0.06}
            result = runner.invoke(app, ["create", "a cat"])
            assert result.exit_code == 0
            mock_create.assert_called_once()
            assert "a cat" == mock_create.call_args.args[0]


class TestModelsCmd:
    def test_lists_models(self):
        result = runner.invoke(app, ["models"])
        assert result.exit_code == 0


class TestCreditsCmd:
    def test_displays_credits(self):
        with patch("imager.cli.operations.get_credits", new_callable=AsyncMock) as mock_credits:
            mock_credits.return_value = {
                "total_credits": 10.0,
                "total_usage": 3.5,
                "remaining": 6.5,
            }
            result = runner.invoke(app, ["credits"])
            assert result.exit_code == 0
