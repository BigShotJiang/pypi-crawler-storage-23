"""Tests for configuration loading and API key resolution."""

from __future__ import annotations

import json

import pytest

from imager.config import get_api_key, get_default_model, load_config


# ---------------------------------------------------------------------------
# load_config()
# ---------------------------------------------------------------------------

class TestLoadConfig:
    def test_missing_file_returns_empty(self, monkeypatch, tmp_path):
        monkeypatch.setattr("imager.config.CONFIG_PATH", tmp_path / "nope.json")
        assert load_config() == {}

    def test_valid_json(self, monkeypatch, tmp_path):
        cfg_file = tmp_path / "config.json"
        cfg_file.write_text(json.dumps({"openrouter_api_key": "abc"}))
        monkeypatch.setattr("imager.config.CONFIG_PATH", cfg_file)
        assert load_config() == {"openrouter_api_key": "abc"}


# ---------------------------------------------------------------------------
# get_api_key()
# ---------------------------------------------------------------------------

class TestGetApiKey:
    def test_from_env_var(self, monkeypatch, tmp_path):
        monkeypatch.setenv("OPENROUTER_API_KEY", "env-key-123")
        monkeypatch.setattr("imager.config.CONFIG_PATH", tmp_path / "nope.json")
        assert get_api_key() == "env-key-123"

    def test_from_config_file(self, monkeypatch, tmp_path):
        monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)
        cfg_file = tmp_path / "config.json"
        cfg_file.write_text(json.dumps({"openrouter_api_key": "file-key-456"}))
        monkeypatch.setattr("imager.config.CONFIG_PATH", cfg_file)
        assert get_api_key() == "file-key-456"

    def test_env_takes_priority(self, monkeypatch, tmp_path):
        monkeypatch.setenv("OPENROUTER_API_KEY", "env-key")
        cfg_file = tmp_path / "config.json"
        cfg_file.write_text(json.dumps({"openrouter_api_key": "file-key"}))
        monkeypatch.setattr("imager.config.CONFIG_PATH", cfg_file)
        assert get_api_key() == "env-key"

    def test_missing_raises(self, monkeypatch, tmp_path):
        monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)
        monkeypatch.setattr("imager.config.CONFIG_PATH", tmp_path / "nope.json")
        with pytest.raises(RuntimeError, match="No OpenRouter API key"):
            get_api_key()


# ---------------------------------------------------------------------------
# get_default_model()
# ---------------------------------------------------------------------------

class TestGetDefaultModel:
    def test_hardcoded_default(self, monkeypatch, tmp_path):
        monkeypatch.setattr("imager.config.CONFIG_PATH", tmp_path / "nope.json")
        assert get_default_model("create") == "google/gemini-2.5-flash-image"

    def test_global_config_override(self, monkeypatch, tmp_path):
        cfg_file = tmp_path / "config.json"
        cfg_file.write_text(json.dumps({"default_model": "flux"}))
        monkeypatch.setattr("imager.config.CONFIG_PATH", cfg_file)
        assert get_default_model("create") == "flux"

    def test_per_command_override(self, monkeypatch, tmp_path):
        cfg_file = tmp_path / "config.json"
        cfg_file.write_text(json.dumps({
            "default_model": "flux",
            "model_overrides": {"icon": "gpt5"},
        }))
        monkeypatch.setattr("imager.config.CONFIG_PATH", cfg_file)
        # icon uses per-command override
        assert get_default_model("icon") == "gpt5"
        # create falls back to global
        assert get_default_model("create") == "flux"
