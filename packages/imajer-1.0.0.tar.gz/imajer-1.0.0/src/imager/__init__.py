"""Imager: Multi-model image generation via OpenRouter."""
