"""Diagram rendering pipeline — Kroki/Mermaid pre-render for hybrid mode."""

from __future__ import annotations

import tempfile
from pathlib import Path

import httpx

KROKI_URL = "https://kroki.io"

# Map file extensions and engine names to Kroki diagram types
ENGINE_MAP: dict[str, str] = {
    "mermaid": "mermaid",
    "mmd": "mermaid",
    "plantuml": "plantuml",
    "puml": "plantuml",
    "d2": "d2",
    "graphviz": "graphviz",
    "dot": "graphviz",
    "excalidraw": "excalidraw",
}


def _detect_engine(source_path: str, engine: str | None) -> str:
    """Detect diagram engine from file extension or explicit engine arg."""
    if engine:
        resolved = ENGINE_MAP.get(engine.lower(), engine.lower())
        return resolved

    ext = Path(source_path).suffix.lower().lstrip(".")
    resolved = ENGINE_MAP.get(ext)
    if resolved:
        return resolved

    raise ValueError(
        f"Cannot detect diagram engine from extension '.{ext}'. "
        f"Use --engine to specify one of: {', '.join(sorted(set(ENGINE_MAP.values())))}"
    )


async def render_diagram_source(
    source_path: str,
    engine: str | None = None,
    output_format: str = "png",
) -> Path:
    """Render a diagram source file via Kroki API.

    Returns path to the rendered image.
    """
    source_text = Path(source_path).read_text()
    diagram_type = _detect_engine(source_path, engine)

    # Use Kroki REST API
    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.post(
            f"{KROKI_URL}/{diagram_type}/{output_format}",
            headers={"Content-Type": "text/plain"},
            content=source_text,
        )

    if resp.status_code != 200:
        raise RuntimeError(
            f"Kroki rendering failed ({resp.status_code}): {resp.text[:200]}"
        )

    # Save to temp file
    suffix = f".{output_format}"
    tmp = tempfile.NamedTemporaryFile(
        prefix="imager_diagram_", suffix=suffix, delete=False,
    )
    tmp.write(resp.content)
    tmp.close()
    return Path(tmp.name)
