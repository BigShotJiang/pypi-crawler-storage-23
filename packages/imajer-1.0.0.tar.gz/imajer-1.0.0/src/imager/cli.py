"""Imager CLI — Typer application wrapping operations."""

from __future__ import annotations

import asyncio
import sys
from typing import Annotated, Optional

import typer
from rich.console import Console
from rich.table import Table

from imager import operations

app = typer.Typer(name="imager", no_args_is_help=True)
console = Console(stderr=True)  # Rich output to stderr, keep stdout for piping


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _resolve_input(path: str) -> str:
    """Resolve input path, reading from stdin if '-'."""
    if path == "-":
        line = sys.stdin.readline().strip()
        if not line:
            console.print("[red]Error:[/] No input received from stdin")
            raise typer.Exit(1)
        return line
    return path


def _show_result(result: dict, quiet: bool = False) -> None:
    """Display result and print file path to stdout."""
    if "error" in result:
        console.print(f"[red]Error:[/] {result['error']}")
        if result.get("text"):
            console.print(f"[dim]Model response:[/] {result['text']}")
        raise typer.Exit(1)

    file_path = result["file"]

    if not quiet:
        console.print(f"[green]✓[/] Saved to {file_path} ({result.get('size_human', '?')})")
        cost = result.get("cost")
        if cost is not None:
            console.print(f"  Cost: ${cost:.4f}")
        if result.get("text"):
            console.print(f"  [dim]{result['text'][:200]}[/]")

    # Always print path to stdout for piping
    typer.echo(file_path)


# ---------------------------------------------------------------------------
# create
# ---------------------------------------------------------------------------

@app.command("create")
def create_cmd(
    prompt: Annotated[str, typer.Argument(help="Text prompt for image generation")],
    model: Annotated[Optional[str], typer.Option("--model", "-m", help="Model name or alias")] = None,
    output: Annotated[Optional[str], typer.Option("--output", "-o", help="Output file path")] = None,
    output_dir: Annotated[Optional[str], typer.Option("--output-dir", "-d", help="Output directory")] = None,
    size: Annotated[Optional[str], typer.Option("--size", help="Aspect ratio (e.g. 16:9)")] = None,
    image_size: Annotated[Optional[str], typer.Option("--image-size", help="Resolution: 1K, 2K, 4K")] = None,
    fmt: Annotated[Optional[str], typer.Option("--format", "-f", help="Output format: png, jpg, webp")] = None,
    quality: Annotated[int, typer.Option("--quality", "-q", help="JPEG/WebP quality 0-100")] = 85,
    quiet: Annotated[bool, typer.Option("--quiet", help="Minimal output")] = False,
) -> None:
    """Generate an image from a text prompt."""
    result = asyncio.run(operations.create_image(
        prompt, model=model, aspect_ratio=size, image_size=image_size,
        output=output, output_dir=output_dir, target_format=fmt, quality=quality,
    ))
    _show_result(result, quiet)


# ---------------------------------------------------------------------------
# edit
# ---------------------------------------------------------------------------

@app.command("edit")
def edit_cmd(
    input_path: Annotated[str, typer.Argument(help="Input image path (or - for stdin)")],
    prompt: Annotated[str, typer.Argument(help="Edit instructions")],
    model: Annotated[Optional[str], typer.Option("--model", "-m")] = None,
    output: Annotated[Optional[str], typer.Option("--output", "-o")] = None,
    output_dir: Annotated[Optional[str], typer.Option("--output-dir", "-d")] = None,
    size: Annotated[Optional[str], typer.Option("--size")] = None,
    image_size: Annotated[Optional[str], typer.Option("--image-size")] = None,
    fmt: Annotated[Optional[str], typer.Option("--format", "-f")] = None,
    quality: Annotated[int, typer.Option("--quality", "-q")] = 85,
    quiet: Annotated[bool, typer.Option("--quiet")] = False,
) -> None:
    """Edit an existing image with a text prompt."""
    resolved = _resolve_input(input_path)
    result = asyncio.run(operations.edit_image(
        resolved, prompt, model=model, aspect_ratio=size, image_size=image_size,
        output=output, output_dir=output_dir, target_format=fmt, quality=quality,
    ))
    _show_result(result, quiet)


# ---------------------------------------------------------------------------
# icon
# ---------------------------------------------------------------------------

@app.command("icon")
def icon_cmd(
    prompt: Annotated[str, typer.Argument(help="Icon description")],
    model: Annotated[Optional[str], typer.Option("--model", "-m")] = None,
    output: Annotated[Optional[str], typer.Option("--output", "-o")] = None,
    output_dir: Annotated[Optional[str], typer.Option("--output-dir", "-d")] = None,
    size: Annotated[Optional[str], typer.Option("--size")] = None,
    image_size: Annotated[Optional[str], typer.Option("--image-size")] = None,
    fmt: Annotated[Optional[str], typer.Option("--format", "-f")] = None,
    quality: Annotated[int, typer.Option("--quality", "-q")] = 85,
    quiet: Annotated[bool, typer.Option("--quiet")] = False,
) -> None:
    """Generate an icon (1:1, flat style)."""
    result = asyncio.run(operations.create_icon(
        prompt, model=model, aspect_ratio=size, image_size=image_size,
        output=output, output_dir=output_dir, target_format=fmt, quality=quality,
    ))
    _show_result(result, quiet)


# ---------------------------------------------------------------------------
# diagram
# ---------------------------------------------------------------------------

@app.command("diagram")
def diagram_cmd(
    prompt: Annotated[str, typer.Argument(help="Diagram description or enhancement instructions")],
    source: Annotated[Optional[str], typer.Option("--source", "-s", help="Source file (Mermaid, PlantUML, D2)")] = None,
    engine: Annotated[Optional[str], typer.Option("--engine", "-e", help="Rendering engine: mermaid, plantuml, d2")] = None,
    model: Annotated[Optional[str], typer.Option("--model", "-m")] = None,
    output: Annotated[Optional[str], typer.Option("--output", "-o")] = None,
    output_dir: Annotated[Optional[str], typer.Option("--output-dir", "-d")] = None,
    size: Annotated[Optional[str], typer.Option("--size")] = None,
    image_size: Annotated[Optional[str], typer.Option("--image-size")] = None,
    fmt: Annotated[Optional[str], typer.Option("--format", "-f")] = None,
    quality: Annotated[int, typer.Option("--quality", "-q")] = 85,
    quiet: Annotated[bool, typer.Option("--quiet")] = False,
) -> None:
    """Create a diagram (direct LLM or hybrid Kroki+LLM)."""
    result = asyncio.run(operations.create_diagram(
        prompt, source=source, engine=engine, model=model,
        aspect_ratio=size, image_size=image_size,
        output=output, output_dir=output_dir, target_format=fmt, quality=quality,
    ))
    _show_result(result, quiet)


# ---------------------------------------------------------------------------
# combine
# ---------------------------------------------------------------------------

@app.command("combine")
def combine_cmd(
    images: Annotated[list[str], typer.Argument(help="Image paths to combine")],
    prompt: Annotated[str, typer.Option("--prompt", "-p", help="Composition instructions")] = "Combine these images naturally",
    model: Annotated[Optional[str], typer.Option("--model", "-m")] = None,
    output: Annotated[Optional[str], typer.Option("--output", "-o")] = None,
    output_dir: Annotated[Optional[str], typer.Option("--output-dir", "-d")] = None,
    size: Annotated[Optional[str], typer.Option("--size")] = None,
    image_size: Annotated[Optional[str], typer.Option("--image-size")] = None,
    fmt: Annotated[Optional[str], typer.Option("--format", "-f")] = None,
    quality: Annotated[int, typer.Option("--quality", "-q")] = 85,
    quiet: Annotated[bool, typer.Option("--quiet")] = False,
) -> None:
    """Combine multiple images into one composition."""
    resolved = [_resolve_input(p) for p in images]
    result = asyncio.run(operations.combine_images(
        resolved, prompt, model=model, aspect_ratio=size, image_size=image_size,
        output=output, output_dir=output_dir, target_format=fmt, quality=quality,
    ))
    _show_result(result, quiet)


# ---------------------------------------------------------------------------
# story
# ---------------------------------------------------------------------------

@app.command("story")
def story_cmd(
    storyboard: Annotated[str, typer.Argument(help="Path to storyboard JSON file")],
    model: Annotated[Optional[str], typer.Option("--model", "-m")] = None,
    output_dir: Annotated[Optional[str], typer.Option("--output-dir", "-d")] = None,
    fmt: Annotated[Optional[str], typer.Option("--format", "-f")] = None,
    quality: Annotated[int, typer.Option("--quality", "-q")] = 85,
    ref: Annotated[Optional[list[str]], typer.Option("--ref", help="Reference overrides: key=path")] = None,
    quiet: Annotated[bool, typer.Option("--quiet")] = False,
) -> None:
    """Generate a visual story from a storyboard JSON definition."""
    ref_overrides = {}
    if ref:
        for r in ref:
            if "=" in r:
                k, v = r.split("=", 1)
                ref_overrides[k] = v

    result = asyncio.run(operations.generate_story(
        storyboard, model=model, output_dir=output_dir,
        target_format=fmt, quality=quality, ref_overrides=ref_overrides or None,
    ))

    if not quiet:
        console.print(f"[green]✓[/] Story '{result['title']}' generated")
        console.print(f"  Output: {result['output_dir']}")
        console.print(f"  Gallery: {result['gallery']}")
        console.print(f"  Scenes: {len(result['scenes'])}")
        if result.get("total_cost"):
            console.print(f"  Total cost: ${result['total_cost']:.4f}")

    typer.echo(result["gallery"])


# ---------------------------------------------------------------------------
# models
# ---------------------------------------------------------------------------

@app.command("models")
def models_cmd() -> None:
    """List available image generation models."""
    models = operations.list_models()
    table = Table(title="Available Models")
    table.add_column("ID", style="cyan")
    table.add_column("Name")
    table.add_column("Gen", justify="center")
    table.add_column("Edit", justify="center")
    table.add_column("Sizes")
    table.add_column("Cost")

    for m in models:
        table.add_row(
            m["id"],
            m["name"],
            "✓" if m["can_generate"] else "✗",
            "✓" if m["can_edit"] else "✗",
            ", ".join(m["image_sizes"]) or ", ".join(m.get("fixed_sizes", [])) or "—",
            m["cost_note"],
        )
    console.print(table)


# ---------------------------------------------------------------------------
# credits
# ---------------------------------------------------------------------------

@app.command("credits")
def credits_cmd() -> None:
    """Check remaining OpenRouter credits."""
    result = asyncio.run(operations.get_credits())
    console.print(f"  Total credits:  ${result['total_credits']:.2f}")
    console.print(f"  Used:           ${result['total_usage']:.2f}")
    remaining = result["remaining"]
    style = "green" if remaining > 5 else "yellow" if remaining > 1 else "red"
    console.print(f"  Remaining:      [{style}]${remaining:.2f}[/{style}]")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main_cli() -> None:
    app()
