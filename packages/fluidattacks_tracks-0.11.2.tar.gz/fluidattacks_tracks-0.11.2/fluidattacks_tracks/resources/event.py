"""Tracks event resource."""

from collections.abc import AsyncGenerator, Mapping
from datetime import datetime
from typing import Literal, NotRequired, TypedDict

from fluidattacks_core import aio
from pydantic import BaseModel

from fluidattacks_tracks.client import TracksClient
from fluidattacks_tracks.utils import fire_and_forget


class TracksEvent(BaseModel):
    """Tracks event."""

    action: str
    author: str
    date: datetime
    id: str
    mechanism: str
    metadata: Mapping[str, object]
    object_id: str


class PageInfo(BaseModel):
    """Tracks page info."""

    end_cursor: str
    has_next_page: bool


class TracksResponse(BaseModel):
    """Tracks response."""

    events: tuple[TracksEvent, ...]
    page_info: PageInfo


ActionType = Literal["CREATE", "READ", "UPDATE", "DELETE"]


MechanismType = Literal[
    "API",
    "DESKTOP",
    "EMAIL",
    "FIXES",
    "FORCES",
    "JIRA",
    "MCP",
    "MELTS",
    "MESSAGING",
    "MIGRATION",
    "RETRIEVES",
    "SCHEDULER",
    "SMELLS",
    "TASK",
    "WEB",
]

BATCH_READ_MAX_OBJECT_IDS = 60
BATCH_READ_MAX_LIMIT = 100  # Matches API Query(gt=0, lt=1001)


class _BatchReadOptions(TypedDict):
    """Options for batch read requests."""

    end_date: datetime | None
    group_name: str
    object_: str
    page_limit: int
    start_date: datetime | None
    state_type: str | None


def _chunk_list(items: list[str], chunk_size: int) -> list[list[str]]:
    return [items[i : i + chunk_size] for i in range(0, len(items), chunk_size)]


def _build_batch_request_params(
    options: _BatchReadOptions,
    cursor_start_date: datetime | None,
) -> list[tuple[str, str | int]]:
    params: list[tuple[str, str | int]] = [
        ("object", options["object_"]),
        ("limit", options["page_limit"]),
    ]
    if options["state_type"] is not None:
        params.append(("state_type", options["state_type"]))
    if cursor_start_date is not None:
        params.append(("start_date", cursor_start_date.isoformat()))
    if options["end_date"] is not None:
        params.append(("end_date", options["end_date"].isoformat()))
    return params


def _accumulate_page_events(
    page: tuple[TracksEvent, ...],
    events_by_object: dict[str, list[TracksEvent]],
    seen_ids: set[str],
    collect_limit: int,
) -> int:
    useful_count = 0
    for event in page:
        if event.id in seen_ids:
            continue
        seen_ids.add(event.id)
        object_events = events_by_object.setdefault(event.object_id, [])
        if len(object_events) < collect_limit:
            object_events.append(event)
            useful_count += 1
    return useful_count


def _build_chunk_result(
    events_by_object: dict[str, list[TracksEvent]],
    chunk: list[str],
    chunk_set: set[str],
    per_object_limit: int,
) -> tuple[tuple[TracksEvent, ...], bool, datetime | None]:
    has_next_page = any(len(events_by_object.get(oid, [])) > per_object_limit for oid in chunk_set)
    end_cursor: datetime | None = None
    if has_next_page:
        end_cursor = min(
            events_by_object[oid][per_object_limit].date
            for oid in chunk_set
            if len(events_by_object.get(oid, [])) > per_object_limit
        )
    result_events: list[TracksEvent] = [
        event for oid in chunk for event in events_by_object.get(oid, [])[:per_object_limit]
    ]
    return (tuple(result_events), has_next_page, end_cursor)


class Event(TypedDict):
    """Tracks event."""

    action: ActionType
    author_anonymous: NotRequired[bool]
    author_ip: NotRequired[str]
    author_role: NotRequired[str]
    author_user_agent: NotRequired[str]
    author: str
    date: datetime
    mechanism: MechanismType
    metadata: Mapping[str, object]
    object_id: str
    object: str
    session_id: NotRequired[str]


class EventResource:
    """Tracks event resource."""

    def __init__(self, client: TracksClient) -> None:
        """Initialize the event resource."""
        self.client = client

    @fire_and_forget
    def create(self, event: Event) -> None:
        """Create an event."""
        self.client.post("/event", json=event)

    async def create_batch_async(self, events: list[Event]) -> None:
        """Create a batch of events."""
        await self.client.post_async("/events/batch", authenticated=True, json=events)

    async def read_pages(  # noqa: PLR0913
        self,
        *,
        after: str | None = None,
        end_date: datetime | None = None,
        group_name: str,
        limit: int = 100,
        object_: str,
        object_id: str | None = None,
        start_date: datetime | None = None,
        state_type: str | None = None,
    ) -> AsyncGenerator[TracksResponse]:
        """Read pages of events matching the given filters."""
        end_cursor = datetime.fromisoformat(after) if after else start_date
        has_next_page = True
        total_events = 0
        limit_with_offset = limit + 1  # Needed to check if there is a next page

        while has_next_page:
            response = await self.client.get_async(
                f"/groups/{group_name}/events",
                authenticated=True,
                params={
                    "limit": limit_with_offset,
                    "object": object_,
                    **({"end_date": end_date.isoformat()} if end_date else {}),
                    **({"object_id": object_id} if object_id else {}),
                    **({"start_date": end_cursor.isoformat()} if end_cursor else {}),
                    **({"state_type": state_type} if state_type else {}),
                },
            )
            response.raise_for_status()
            response_json: list[dict[str, object]] = await response.json()  # type: ignore[misc]
            has_next_page = len(response_json) == limit_with_offset
            events = tuple(TracksEvent.model_validate(event) for event in response_json)
            end_cursor = events[-1].date if events else None
            page_events = events[:-1] if has_next_page else events
            total_events += len(page_events)

            yield TracksResponse(
                events=page_events,
                page_info=PageInfo(
                    has_next_page=has_next_page,
                    end_cursor=end_cursor.isoformat() if end_cursor else "",
                ),
            )

            if total_events >= limit:
                break

    async def read(  # noqa: PLR0913
        self,
        *,
        after: str | None = None,
        end_date: datetime | None = None,
        group_name: str,
        limit: int = 100,
        object_: str,
        object_id: str | None = None,
        start_date: datetime | None = None,
        state_type: str | None = None,
    ) -> TracksResponse:
        """Read all events matching the given filters."""
        pages = [
            page
            async for page in self.read_pages(
                after=after,
                end_date=end_date,
                group_name=group_name,
                limit=limit,
                object_=object_,
                object_id=object_id,
                start_date=start_date,
                state_type=state_type,
            )
        ]

        return TracksResponse(
            events=tuple(event for page in pages for event in page.events),
            page_info=pages[-1].page_info,
        )

    async def _fetch_batch_page(
        self,
        options: _BatchReadOptions,
        chunk: list[str],
        cursor_start_date: datetime | None,
    ) -> tuple[TracksEvent, ...]:
        params = _build_batch_request_params(options, cursor_start_date)
        body: dict[str, object] = {"object_ids": chunk}
        response = await self.client.post_async(
            f"/groups/{options['group_name']}/events/batch",
            authenticated=True,
            params=params,
            json=body,
        )
        response.raise_for_status()
        response_json: list[dict[str, object]] = await response.json()  # type: ignore[misc]
        return tuple(TracksEvent.model_validate(event) for event in response_json)

    async def _fetch_chunk_paginated(
        self,
        options: _BatchReadOptions,
        chunk: list[str],
        per_object_limit: int,
    ) -> tuple[tuple[TracksEvent, ...], bool, datetime | None]:
        events_by_object: dict[str, list[TracksEvent]] = {}
        seen_ids: set[str] = set()
        cursor: datetime | None = options["start_date"]
        api_page_size = options["page_limit"]
        chunk_set = set(chunk)
        collect_limit = per_object_limit + 1
        active_chunk = list(chunk)

        while True:
            page = await self._fetch_batch_page(options, active_chunk, cursor)
            useful_this_page = _accumulate_page_events(
                page,
                events_by_object,
                seen_ids,
                collect_limit,
            )
            all_collected = all(
                len(events_by_object.get(oid, [])) >= collect_limit for oid in chunk_set
            )
            if all_collected or len(page) < api_page_size or not page:
                break
            if useful_this_page == 0:
                active_chunk = [
                    oid
                    for oid in active_chunk
                    if len(events_by_object.get(oid, [])) < collect_limit
                ]
                if not active_chunk or page[-1].date == cursor:
                    break
            cursor = page[-1].date

        return _build_chunk_result(
            events_by_object,
            chunk,
            chunk_set,
            per_object_limit,
        )

    async def read_batch(  # noqa: PLR0913
        self,
        *,
        end_date: datetime | None = None,
        group_name: str,
        limit: int = BATCH_READ_MAX_LIMIT,
        object_: str,
        object_ids: list[str],
        start_date: datetime | None = None,
        state_type: str | None = None,
    ) -> TracksResponse:
        """Read events for multiple object_ids via the batch API."""
        if not object_ids:
            return TracksResponse(
                events=(),
                page_info=PageInfo(has_next_page=False, end_cursor=""),
            )
        options: _BatchReadOptions = {
            "end_date": end_date,
            "group_name": group_name,
            "object_": object_,
            "page_limit": min(limit * BATCH_READ_MAX_OBJECT_IDS, BATCH_READ_MAX_LIMIT),
            "start_date": start_date,
            "state_type": state_type,
        }
        chunks = _chunk_list(object_ids, BATCH_READ_MAX_OBJECT_IDS)
        results = await aio.gather(
            [self._fetch_chunk_paginated(options, c, per_object_limit=limit) for c in chunks],
            concurrency_limit=5,
        )
        events = tuple(event for chunk_events, _, _ in results for event in chunk_events)
        any_has_next_page = any(has_more for _, has_more, _ in results)
        earliest_end_cursor = min(
            (
                end_cursor
                for _, has_more, end_cursor in results
                if has_more and end_cursor is not None
            ),
            default=None,
        )
        return TracksResponse(
            events=events,
            page_info=PageInfo(
                has_next_page=any_has_next_page,
                end_cursor=(
                    earliest_end_cursor.isoformat()
                    if any_has_next_page and earliest_end_cursor
                    else ""
                ),
            ),
        )
