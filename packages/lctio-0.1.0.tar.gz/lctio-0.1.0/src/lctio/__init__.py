"""Livermore Computed Tomography Input Output software (LCTIO).

This software is maintained at https://github.com/llnl/lctio,
copyright (c) 2026, Lawrence Livermore National Laboratory.

See LICENSE and NOTICE files for details.

SPDX-License-Identifier: BSD-3-Clause
"""
