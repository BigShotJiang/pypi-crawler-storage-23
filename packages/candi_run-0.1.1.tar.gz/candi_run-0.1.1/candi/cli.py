#!/usr/bin/env python3
"""
CandI - Control and Interface
Secure transparent remote execution platform.
"""

import sys


def main():
    print("CandI - Control and Interface")
    print("Secure transparent remote execution platform.")
    print()
    print("Full release coming soon.")
    print("https://github.com/candicli")
    print()
    print("Run 'candi --version' for version info.")


def version():
    from candi import __version__
    print(f"candi {__version__}")


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--version":
        version()
    else:
        main()

