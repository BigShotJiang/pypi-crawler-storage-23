"""
CandI - Control and Interface
Secure transparent remote execution platform.

Run any local tool against any remote environment.
Your credentials never leave your machine.

https://github.com/candicli
"""

__version__ = "0.1.0"
__author__ = "CandI Project"
__license__ = "Apache-2.0"


