import unittest
import sys
import pytest
from pathlib import Path

# Add project root to sys.path for imports
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from tests.setup_class import EndeeTestSetup
from llama_index_endee.base import EndeeVectorStore
from llama_index.core import StorageContext, VectorStoreIndex
from llama_index.core.vector_stores.types import VectorStoreQuery

try:
    from llama_index.embeddings.huggingface import HuggingFaceEmbedding
except ImportError:
    HuggingFaceEmbedding = None  # pip install llama-index-embeddings-huggingface


class TestEndeeVectorStore(EndeeTestSetup):
    def setUp(self):
        """Set up embedding model and other test-specific resources"""
        if HuggingFaceEmbedding is None:
            self.skipTest("HuggingFaceEmbedding not available; install llama-index-embeddings-huggingface")
        self.embed_model = HuggingFaceEmbedding(
            model_name="sentence-transformers/all-MiniLM-L6-v2",
            device="cpu"
        )

    def test_create_vector_store_from_params(self):
        """Test creating Endee vector store using from_params method"""
        try:
            # Create vector store
            vector_store = EndeeVectorStore.from_params(
                api_token=self.endee_api_token,
                index_name=self.test_index_name,
                dimension=self.dimension,
                space_type=self.space_type
            )
            
            # Verify vector store attributes
            self.assertIsNotNone(vector_store)
            self.assertEqual(vector_store.api_token, self.endee_api_token)
            self.assertEqual(vector_store.index_name, self.test_index_name)
            self.assertEqual(vector_store.dimension, self.dimension)
            self.assertEqual(vector_store.space_type, self.space_type)
            # Verify default values (precision passed through as-is; default float16)
            self.assertEqual(vector_store.precision, "float16")  # Default key
            
            # Verify index exists via vector store (base.py uses _endee_index from client)
            self.assertIsNotNone(vector_store.client)
            index_info = vector_store.describe()
            self.assertEqual(index_info["dimension"], self.dimension)
            self.assertEqual(index_info["space_type"], self.space_type)
            
        except Exception as e:
            self.fail(f"Vector store creation failed: {str(e)}")

    def test_create_vector_store_with_documents(self):
        """Test creating vector store and adding documents"""
        try:
            # Create vector store
            vector_store = EndeeVectorStore.from_params(
                api_token=self.endee_api_token,
                index_name=self.test_index_name,
                dimension=self.dimension,
                space_type=self.space_type
            )
            
            # Create storage context
            storage_context = StorageContext.from_defaults(vector_store=vector_store)
            
            # Create index with documents
            index = VectorStoreIndex.from_documents(
                self.test_documents,
                storage_context=storage_context,
                embed_model=self.embed_model
            )
            
            # Verify index was created
            self.assertIsNotNone(index)
            
            # Verify index properties via vector store (aligned with base.py)
            index_info = vector_store.describe()
            self.assertEqual(index_info["dimension"], self.dimension)
            self.assertEqual(index_info["space_type"], self.space_type)
            
            # Verify documents were added by performing a search via vector store
            test_query = "Python programming"
            query_embedding = self.embed_model.get_text_embedding(test_query)
            query = VectorStoreQuery(query_embedding=query_embedding, similarity_top_k=len(self.test_documents))
            result = vector_store.query(query)
            results = result.nodes
            self.assertGreater(len(results), 0, "No vectors found in index after adding documents")
            
            # Verify vector store has correct default precision (float16)
            self.assertEqual(vector_store.precision, "float16")
            
        except Exception as e:
            self.fail(f"Vector store creation with documents failed: {str(e)}")

    def test_create_vector_store_invalid_params(self):
        """Test that invalid token and missing required params raise; dimension/space_type depend on backend."""
        # Invalid dimension / invalid space_type: Endee client may accept or reject; don't require raise
        unique_index_name = f"{self.test_index_name}_invalid_dim"
        self.test_indexes.add(unique_index_name)
        try:
            vs = EndeeVectorStore.from_params(
                api_token=self.endee_api_token,
                index_name=unique_index_name,
                dimension=5,
                space_type=self.space_type,
            )
            self.assertIsNotNone(vs.client)
        except Exception:
            pass  # backend rejected invalid dimension

        unique_index_name = f"{self.test_index_name}_invalid_space"
        self.test_indexes.add(unique_index_name)
        try:
            vs = EndeeVectorStore.from_params(
                api_token=self.endee_api_token,
                index_name=unique_index_name,
                dimension=self.dimension,
                space_type="invalid_space",
            )
            self.assertIsNotNone(vs.client)
        except Exception:
            pass  # backend rejected invalid space_type

        # Invalid API token must raise
        unique_index_name = f"{self.test_index_name}_invalid_token"
        self.test_indexes.add(unique_index_name)
        with pytest.raises(Exception):
            EndeeVectorStore.from_params(
                api_token="invalid:invalid_key:india-west-1",
                index_name=unique_index_name,
                dimension=self.dimension,
                space_type=self.space_type,
            )

        # Missing required parameters must raise
        with pytest.raises(Exception):
            EndeeVectorStore.from_params(
                dimension=self.dimension,
                space_type=self.space_type,
            )
        with pytest.raises(Exception):
            EndeeVectorStore.from_params(
                api_token=self.endee_api_token,
                dimension=self.dimension,
                space_type=self.space_type,
            )

    def test_create_vector_store_with_precision(self):
        """Test creating vector store with precision (passed through as-is: float16, float32, int8d)."""
        try:
            unique_index_name = f"{self.test_index_name}_precision"
            for suffix in ("_float16", "_float32", "_int8d", "_default"):
                self.test_indexes.add(f"{unique_index_name}{suffix}")
            
            vector_store = EndeeVectorStore.from_params(
                api_token=self.endee_api_token,
                index_name=f"{unique_index_name}_float16",
                dimension=self.dimension,
                space_type=self.space_type,
                precision="float16",
            )
            self.assertIsNotNone(vector_store)
            self.assertEqual(vector_store.precision, "float16")
            
            vector_store_high = EndeeVectorStore.from_params(
                api_token=self.endee_api_token,
                index_name=f"{unique_index_name}_float32",
                dimension=self.dimension,
                space_type=self.space_type,
                precision="float32",
            )
            self.assertIsNotNone(vector_store_high)
            self.assertEqual(vector_store_high.precision, "float32")
            
            vector_store_low = EndeeVectorStore.from_params(
                api_token=self.endee_api_token,
                index_name=f"{unique_index_name}_int8d",
                dimension=self.dimension,
                space_type=self.space_type,
                precision="int8d",
            )
            self.assertIsNotNone(vector_store_low)
            self.assertEqual(vector_store_low.precision, "int8d")
            
            vector_store_default = EndeeVectorStore.from_params(
                api_token=self.endee_api_token,
                index_name=f"{unique_index_name}_default",
                dimension=self.dimension,
                space_type=self.space_type,
            )
            self.assertIsNotNone(vector_store_default)
            self.assertEqual(vector_store_default.precision, "float16")
        except Exception as e:
            self.fail(f"Vector store creation with precision failed: {str(e)}")

    def test_create_vector_store_with_m_ef_con(self):
        """Test creating vector store with M and ef_con (Endee.create_index params)."""
        try:
            unique_index_name = f"{self.test_index_name}_m_ef"
            self.test_indexes.add(unique_index_name)
            vector_store = EndeeVectorStore.from_params(
                api_token=self.endee_api_token,
                index_name=unique_index_name,
                dimension=self.dimension,
                space_type=self.space_type,
                M=16,
                ef_con=128,
            )
            self.assertIsNotNone(vector_store)
            self.assertIsNotNone(vector_store.client)
            index_info = vector_store.describe()
            self.assertEqual(index_info["dimension"], self.dimension)
        except Exception as e:
            self.fail(f"Vector store creation with M/ef_con failed: {str(e)}")

    def test_create_vector_store_with_precision_only(self):
        """Test creating vector store with precision (version not exposed in from_params)."""
        try:
            unique_index_name = f"{self.test_index_name}_precision_only"
            self.test_indexes.add(unique_index_name)
            vector_store = EndeeVectorStore.from_params(
                api_token=self.endee_api_token,
                index_name=unique_index_name,
                dimension=self.dimension,
                space_type=self.space_type,
                precision="float32",
            )
            self.assertIsNotNone(vector_store)
            self.assertEqual(vector_store.precision, "float32")
        except Exception as e:
            self.fail(f"Vector store creation with precision failed: {str(e)}")

    def test_create_hybrid_vector_store_from_params(self):
        """Test creating hybrid vector store (hybrid=True, sparse_dim, model_name)."""
        try:
            unique_index_name = f"{self.test_index_name}_hybrid"
            self.test_indexes.add(unique_index_name)
            vector_store = EndeeVectorStore.from_params(
                api_token=self.endee_api_token,
                index_name=unique_index_name,
                dimension=self.dimension,
                space_type=self.space_type,
                hybrid=True,
                sparse_dim=30522,
                model_name="splade_pp",
            )
            self.assertIsNotNone(vector_store)
            self.assertTrue(vector_store.hybrid)
            self.assertEqual(vector_store.sparse_dim, 30522)
            self.assertEqual(vector_store.model_name, "splade_pp")
            self.assertIsNotNone(vector_store.client)
            info = vector_store.describe()
            self.assertEqual(info["dimension"], self.dimension)
            self.assertTrue(info.get("is_hybrid", info.get("sparse_dim", 0) > 0))
        except ImportError as e:
            self.skipTest(f"Hybrid dependencies not available: {e}")
        except Exception as e:
            self.fail(f"Hybrid vector store creation failed: {str(e)}")

    def test_create_hybrid_vector_store_with_documents(self):
        """Test creating hybrid store and adding documents (dense + sparse)."""
        try:
            unique_index_name = f"{self.test_index_name}_hybrid_docs"
            self.test_indexes.add(unique_index_name)
            vector_store = EndeeVectorStore.from_params(
                api_token=self.endee_api_token,
                index_name=unique_index_name,
                dimension=self.dimension,
                space_type=self.space_type,
                hybrid=True,
                sparse_dim=30522,
                model_name="splade_pp",
            )
            storage_context = StorageContext.from_defaults(vector_store=vector_store)
            index = VectorStoreIndex.from_documents(
                self.test_documents[:3],
                storage_context=storage_context,
                embed_model=self.embed_model,
            )
            self.assertIsNotNone(index)
            info = vector_store.describe()
            self.assertEqual(info["dimension"], self.dimension)
            query_embedding = self.embed_model.get_text_embedding("Python programming")
            query = VectorStoreQuery(query_embedding=query_embedding, similarity_top_k=2)
            result = vector_store.query(query, hybrid=True)
            self.assertIsNotNone(result)
            self.assertGreaterEqual(len(result.nodes), 0)
        except ImportError as e:
            self.skipTest(f"Hybrid dependencies not available: {e}")
        except Exception as e:
            self.fail(f"Hybrid vector store with documents failed: {str(e)}")

if __name__ == '__main__':
    unittest.main()
