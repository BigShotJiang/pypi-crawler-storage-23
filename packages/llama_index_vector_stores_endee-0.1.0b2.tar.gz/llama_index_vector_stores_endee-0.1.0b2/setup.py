# myproject/setup.py

from setuptools import setup, find_packages

setup(
    name="llama-index-vector-stores-endee",
    version="0.1.0b2",
    packages=find_packages(include=['llama_index_endee', 'llama_index_endee.*']),
    install_requires=[
        # Core dependencies (required)
        "llama-index>=0.12.34",
        "endee>=0.1.13",
        "fastembed>=0.3.0",
    ],
    extras_require={
        # Optional: Install for GPU-accelerated hybrid search
        "gpu": [
            "fastembed-gpu>=0.3.0",
        ],
    },
    author="Endee Labs",
    author_email="vineet@endee.io",
    description="Vector Database for Fast ANN Searches",
    long_description=open('README.md').read(),
    long_description_content_type="text/markdown",
    url="https://endee.io",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
