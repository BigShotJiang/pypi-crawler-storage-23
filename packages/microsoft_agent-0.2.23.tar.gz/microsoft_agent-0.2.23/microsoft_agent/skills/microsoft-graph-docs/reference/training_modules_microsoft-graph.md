[ Skip to main content ](https://learn.microsoft.com/en-us/training/modules/microsoft-graph/?source=recommendations#main)
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/training/modules/microsoft-graph/?source=recommendations)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/training/modules/microsoft-graph/?source=recommendations)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/training/modules/microsoft-graph/?source=recommendations)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/training/modules/microsoft-graph/?source=recommendations)
[ Training  ](https://learn.microsoft.com/en-us/training/)
  * Products
    * [ Azure ](https://learn.microsoft.com/en-us/training/azure/)
    * [ Microsoft Foundry ](https://learn.microsoft.com/en-us/training/azure/ai-foundry/)
    * [ Dynamics 365 ](https://learn.microsoft.com/en-us/training/dynamics365/)
    * [ Defender ](https://learn.microsoft.com/en-us/training/defender/)
    * [ .NET ](https://learn.microsoft.com/en-us/training/dotnet/)
    * [ GitHub ](https://learn.microsoft.com/en-us/training/github/)
    * [ Microsoft 365 ](https://learn.microsoft.com/en-us/training/m365/)
    * [ Microsoft Entra ](https://learn.microsoft.com/en-us/training/entra/)
    * [ Microsoft Fabric ](https://learn.microsoft.com/en-us/training/fabric/)
    * [ Power Platform ](https://learn.microsoft.com/en-us/training/powerplatform/)
    * [ Purview ](https://learn.microsoft.com/en-us/training/purview/)
    * [ Teams ](https://learn.microsoft.com/en-us/training/teams/)
    * [ Browse all training ](https://learn.microsoft.com/en-us/training/browse/)
  * Career Paths
    * [ Administrator ](https://learn.microsoft.com/en-us/training/career-paths/administrator/)
    * [ AI Engineer ](https://learn.microsoft.com/en-us/training/career-paths/ai-engineer/)
    * [ App Maker ](https://learn.microsoft.com/en-us/training/career-paths/app-maker/)
    * [ Auditor ](https://learn.microsoft.com/en-us/training/career-paths/auditor/)
    * [ Business User ](https://learn.microsoft.com/en-us/training/career-paths/business-user/)
    * [ Data Analyst ](https://learn.microsoft.com/en-us/training/career-paths/data-analyst/)
    * [ Data Engineer ](https://learn.microsoft.com/en-us/training/career-paths/data-engineer/)
    * [ Data Scientist ](https://learn.microsoft.com/en-us/training/career-paths/data-scientist/)
    * [ Developer ](https://learn.microsoft.com/en-us/training/career-paths/developer/)
    * [ DevOps Engineer ](https://learn.microsoft.com/en-us/training/career-paths/devops-engineer/)
    * [ Functional Consultant ](https://learn.microsoft.com/en-us/training/career-paths/functional-consultant/)
    * [ Identity and Access Administrator ](https://learn.microsoft.com/en-us/training/career-paths/identity-and-access-admin/)
    * [ Information Security Administrator ](https://learn.microsoft.com/en-us/training/career-paths/information-protection-admin/)
    * [ Security Operations Analyst ](https://learn.microsoft.com/en-us/training/career-paths/security-operations-analyst/)
    * [ Security Engineer ](https://learn.microsoft.com/en-us/training/career-paths/security-engineer/)
    * [ Solutions Architect ](https://learn.microsoft.com/en-us/training/career-paths/solution-architect/)
  * [ Browse all training ](https://learn.microsoft.com/en-us/training/browse/)
  * Learn for Organizations
    * [ Microsoft Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations)
    * [ Structured learning (Plans) ](https://learn.microsoft.com/en-us/training/plans-on-microsoft-learn)
    * [ Watch training (Course videos) ](https://learn.microsoft.com/en-us/training/course-videos-on-shows)
    * [ Classroom training (TSP) ](https://learn.microsoft.com/en-us/training/training-services-partners)
    * [ Gamified training (Challenges) ](https://learn.microsoft.com/en-us/training/topics/event-challenges)
    * Resources
      * [ Event training (VTDs) ](https://events.microsoft.com/mvtd?wt.mc_id=lfo_content_webpage_wwl&language=English&deliverylanguage=English&clientTimeZone=1&startTime=08:00&endTime=17:00)
  * Educator Center
    * [ Overview ](https://learn.microsoft.com/en-us/training/educator-center/)
    * Professional development
      * [ Accessibility and inclusivity ](https://learn.microsoft.com/en-us/training/educator-center/topics/accessibility/)
      * [ AI for education ](https://learn.microsoft.com/en-us/training/educator-center/topics/ai-for-education/)
      * [ Cybersecurity ](https://learn.microsoft.com/en-us/training/educator-center/topics/cybersecurity)
      * [ Education leadership and staff collaboration ](https://learn.microsoft.com/en-us/training/educator-center/topics/education-leadership/)
      * [ Learning Accelerators ](https://learn.microsoft.com/en-us/training/educator-center/topics/learning-accelerators/)
      * [ Social emotional learning ](https://learn.microsoft.com/en-us/training/educator-center/topics/social-emotional-learning/)
      * [ STEM, coding, and esports ](https://learn.microsoft.com/en-us/training/educator-center/topics/stem/)
      * [ Browse all ](https://learn.microsoft.com/en-us/training/browse/?roles=k-12-educator%2Chigher-ed-educator%2Cschool-leader%2Cparent-guardian)
    * Product guides
      * [ Copilot in education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/copilot/)
      * [ Microsoft 365 for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/office/)
      * [ Microsoft Teams for Education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/teams/)
      * [ OneNote for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/onenote/)
      * [ Minecraft Education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/minecraft/)
      * [ Reading Progress ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/reading-progress/)
      * [ Search Progress and Coach ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/search-coach/)
      * [ Immersive Reader ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/immersive-reader/)
      * [ PowerPoint for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/powerpoint/)
      * [ Windows for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/windows/)
      * [ Browse all ](https://learn.microsoft.com/en-us/training/browse/?roles=k-12-educator%2Chigher-ed-educator%2Cschool-leader%2Cparent-guardian)
    * [ Instructor materials ](https://learn.microsoft.com/en-us/training/educator-center/instructor-materials/)
    * [ Educator programs ](https://learn.microsoft.com/en-us/training/educator-center/programs/)
  * Student Hub
    * [ Overview ](https://learn.microsoft.com/en-us/training/student-hub/)
    * [ Student certifications ](https://learn.microsoft.com/en-us/training/student-hub/certifications/)
  * [ FAQ & Help ](https://learn.microsoft.com/en-us/training/support/)
  * More
    * Products
      * [ Azure ](https://learn.microsoft.com/en-us/training/azure/)
      * [ Microsoft Foundry ](https://learn.microsoft.com/en-us/training/azure/ai-foundry/)
      * [ Dynamics 365 ](https://learn.microsoft.com/en-us/training/dynamics365/)
      * [ Defender ](https://learn.microsoft.com/en-us/training/defender/)
      * [ .NET ](https://learn.microsoft.com/en-us/training/dotnet/)
      * [ GitHub ](https://learn.microsoft.com/en-us/training/github/)
      * [ Microsoft 365 ](https://learn.microsoft.com/en-us/training/m365/)
      * [ Microsoft Entra ](https://learn.microsoft.com/en-us/training/entra/)
      * [ Microsoft Fabric ](https://learn.microsoft.com/en-us/training/fabric/)
      * [ Power Platform ](https://learn.microsoft.com/en-us/training/powerplatform/)
      * [ Purview ](https://learn.microsoft.com/en-us/training/purview/)
      * [ Teams ](https://learn.microsoft.com/en-us/training/teams/)
      * [ Browse all training ](https://learn.microsoft.com/en-us/training/browse/)
    * Career Paths
      * [ Administrator ](https://learn.microsoft.com/en-us/training/career-paths/administrator/)
      * [ AI Engineer ](https://learn.microsoft.com/en-us/training/career-paths/ai-engineer/)
      * [ App Maker ](https://learn.microsoft.com/en-us/training/career-paths/app-maker/)
      * [ Auditor ](https://learn.microsoft.com/en-us/training/career-paths/auditor/)
      * [ Business User ](https://learn.microsoft.com/en-us/training/career-paths/business-user/)
      * [ Data Analyst ](https://learn.microsoft.com/en-us/training/career-paths/data-analyst/)
      * [ Data Engineer ](https://learn.microsoft.com/en-us/training/career-paths/data-engineer/)
      * [ Data Scientist ](https://learn.microsoft.com/en-us/training/career-paths/data-scientist/)
      * [ Developer ](https://learn.microsoft.com/en-us/training/career-paths/developer/)
      * [ DevOps Engineer ](https://learn.microsoft.com/en-us/training/career-paths/devops-engineer/)
      * [ Functional Consultant ](https://learn.microsoft.com/en-us/training/career-paths/functional-consultant/)
      * [ Identity and Access Administrator ](https://learn.microsoft.com/en-us/training/career-paths/identity-and-access-admin/)
      * [ Information Security Administrator ](https://learn.microsoft.com/en-us/training/career-paths/information-protection-admin/)
      * [ Security Operations Analyst ](https://learn.microsoft.com/en-us/training/career-paths/security-operations-analyst/)
      * [ Security Engineer ](https://learn.microsoft.com/en-us/training/career-paths/security-engineer/)
      * [ Solutions Architect ](https://learn.microsoft.com/en-us/training/career-paths/solution-architect/)
    * [ Browse all training ](https://learn.microsoft.com/en-us/training/browse/)
    * Learn for Organizations
      * [ Microsoft Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations)
      * [ Structured learning (Plans) ](https://learn.microsoft.com/en-us/training/plans-on-microsoft-learn)
      * [ Watch training (Course videos) ](https://learn.microsoft.com/en-us/training/course-videos-on-shows)
      * [ Classroom training (TSP) ](https://learn.microsoft.com/en-us/training/training-services-partners)
      * [ Gamified training (Challenges) ](https://learn.microsoft.com/en-us/training/topics/event-challenges)
      * Resources
        * [ Event training (VTDs) ](https://events.microsoft.com/mvtd?wt.mc_id=lfo_content_webpage_wwl&language=English&deliverylanguage=English&clientTimeZone=1&startTime=08:00&endTime=17:00)
    * Educator Center
      * [ Overview ](https://learn.microsoft.com/en-us/training/educator-center/)
      * Professional development
        * [ Accessibility and inclusivity ](https://learn.microsoft.com/en-us/training/educator-center/topics/accessibility/)
        * [ AI for education ](https://learn.microsoft.com/en-us/training/educator-center/topics/ai-for-education/)
        * [ Cybersecurity ](https://learn.microsoft.com/en-us/training/educator-center/topics/cybersecurity)
        * [ Education leadership and staff collaboration ](https://learn.microsoft.com/en-us/training/educator-center/topics/education-leadership/)
        * [ Learning Accelerators ](https://learn.microsoft.com/en-us/training/educator-center/topics/learning-accelerators/)
        * [ Social emotional learning ](https://learn.microsoft.com/en-us/training/educator-center/topics/social-emotional-learning/)
        * [ STEM, coding, and esports ](https://learn.microsoft.com/en-us/training/educator-center/topics/stem/)
        * [ Browse all ](https://learn.microsoft.com/en-us/training/browse/?roles=k-12-educator%2Chigher-ed-educator%2Cschool-leader%2Cparent-guardian)
      * Product guides
        * [ Copilot in education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/copilot/)
        * [ Microsoft 365 for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/office/)
        * [ Microsoft Teams for Education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/teams/)
        * [ OneNote for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/onenote/)
        * [ Minecraft Education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/minecraft/)
        * [ Reading Progress ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/reading-progress/)
        * [ Search Progress and Coach ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/search-coach/)
        * [ Immersive Reader ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/immersive-reader/)
        * [ PowerPoint for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/powerpoint/)
        * [ Windows for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/windows/)
        * [ Browse all ](https://learn.microsoft.com/en-us/training/browse/?roles=k-12-educator%2Chigher-ed-educator%2Cschool-leader%2Cparent-guardian)
      * [ Instructor materials ](https://learn.microsoft.com/en-us/training/educator-center/instructor-materials/)
      * [ Educator programs ](https://learn.microsoft.com/en-us/training/educator-center/programs/)
    * Student Hub
      * [ Overview ](https://learn.microsoft.com/en-us/training/student-hub/)
      * [ Student certifications ](https://learn.microsoft.com/en-us/training/student-hub/certifications/)
    * [ FAQ & Help ](https://learn.microsoft.com/en-us/training/support/)


1%
  1. [ Learn ](https://learn.microsoft.com/en-us/)
  2. [ Training ](https://learn.microsoft.com/en-us/training/)
  3. [ Browse ](https://learn.microsoft.com/en-us/training/browse/)
  4. [ Implement user authentication and authorization ](https://learn.microsoft.com/en-us/training/paths/az-204-implement-authentication-authorization/)


  1. [ Learn ](https://learn.microsoft.com/en-us/)
  2. [ Training ](https://learn.microsoft.com/en-us/training/)
  3. [ Browse ](https://learn.microsoft.com/en-us/training/browse/)
  4. [ Implement user authentication and authorization ](https://learn.microsoft.com/en-us/training/paths/az-204-implement-authentication-authorization/)


[ Read in English ](https://learn.microsoft.com/en-us/training/modules/microsoft-graph/?source=recommendations)
![](https://learn.microsoft.com/en-us/training/achievements/microsoft-graph-explore.svg)
900 XP
# Explore Microsoft Graph
  * 36 min
  * Module
  * 8 Units


Feedback
Intermediate
Developer
Azure SDKs
Microsoft Graph
Learn how Microsoft Graph facilitates the access and flow of data and how to form queries through REST and code.
##  Learning objectives
After completing this module, you'll be able to:
  * Explain the benefits of using Microsoft Graph.
  * Perform operations on Microsoft Graph by using REST and SDKs.
  * Apply best practices to help your applications get the most out of Microsoft Graph.
  * Retrieve user profile information with the Microsoft Graph SDK


[Start](https://learn.microsoft.com/en-us/training/modules/microsoft-graph/1-introduction/) Add
Add to Collections Add to plan Add to Challenges
## Prerequisites
  * You should be familiar with developer concepts and terminology.
  * Experience working with OAuth.
  * An understanding of cloud computing and some experience with the Azure portal.


## This module is part of these learning paths
  * [Implement user authentication and authorization](https://learn.microsoft.com/training/paths/az-204-implement-authentication-authorization/)


  * [Introduction](https://learn.microsoft.com/en-us/training/modules/microsoft-graph/1-introduction) 3 min
  * [Discover Microsoft Graph](https://learn.microsoft.com/en-us/training/modules/microsoft-graph/2-microsoft-graph-overview) 3 min
  * [Query Microsoft Graph by using REST](https://learn.microsoft.com/en-us/training/modules/microsoft-graph/3-microsoft-graph-api) 3 min
  * [Query Microsoft Graph by using SDKs](https://learn.microsoft.com/en-us/training/modules/microsoft-graph/4-microsoft-graph-sdk) 3 min
  * [Apply best practices to Microsoft Graph](https://learn.microsoft.com/en-us/training/modules/microsoft-graph/5-microsoft-graph-best-practices) 3 min
  * [Exercise - Retrieve user profile information with the Microsoft Graph SDK](https://learn.microsoft.com/en-us/training/modules/microsoft-graph/5a-exercise-microsoft-graph-user-profile) 15 min
  * [Module assessment](https://learn.microsoft.com/en-us/training/modules/microsoft-graph/6-knowledge-check) 3 min
  * [Summary](https://learn.microsoft.com/en-us/training/modules/microsoft-graph/7-summary) 3 min


* * *
##  Module assessment
Assess your understanding of this module. Sign in and answer all questions correctly to earn a pass designation on your profile.
[Take the module assessment](https://learn.microsoft.com/training/modules/microsoft-graph/6-knowledge-check/)
**Note:** The author created this module with assistance from AI. [Learn more](https://learn.microsoft.com/principles-for-ai-generated-content)
[ Start ](https://learn.microsoft.com/en-us/training/modules/microsoft-graph/1-introduction/)
[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Ftraining%2Fmodules%2Fmicrosoft-graph%2F%3Fsource%3Drecommendations)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
