[ Skip to main content ](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#main) [ Skip to Ask Learn chat experience ](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0)
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0)
[ Microsoft Graph  ](https://learn.microsoft.com/en-us/graph/)
  * [ Guides ](https://learn.microsoft.com/en-us/graph/overview)
  * [ API Reference ](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0)
  * Resources
    * [ All resources ](https://developer.microsoft.com/en-us/graph/gallery)
    * [ Blog ](https://devblogs.microsoft.com/microsoft365dev/category/microsoft-graph/)
    * [ Changelog ](https://developer.microsoft.com/en-us/graph/changelog)
    * [ Community calls ](https://aka.ms/M365DevCalls)
    * [ Samples & SDKs ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Samples,SDKs)
    * [ Training ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Training)
    * [ Tools ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Tools)
    * [ Videos & podcasts ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Podcasts,Videos)
    * [ Support ](https://developer.microsoft.com/en-us/graph/support)
    * [ My apps ](https://go.microsoft.com/fwlink/?linkid=2083908)
    * Developer program
      * [ Join ](https://developer.microsoft.com/en-us/microsoft-365/dev-program)
      * [ Dashboard ](https://developer.microsoft.com/en-us/microsoft-365/profile)
      * [ Developer program docs ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program)
      * [ FAQ ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program-faq)
  * More
    * [ Guides ](https://learn.microsoft.com/en-us/graph/overview)
    * [ API Reference ](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0)
    * Resources
      * [ All resources ](https://developer.microsoft.com/en-us/graph/gallery)
      * [ Blog ](https://devblogs.microsoft.com/microsoft365dev/category/microsoft-graph/)
      * [ Changelog ](https://developer.microsoft.com/en-us/graph/changelog)
      * [ Community calls ](https://aka.ms/M365DevCalls)
      * [ Samples & SDKs ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Samples,SDKs)
      * [ Training ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Training)
      * [ Tools ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Tools)
      * [ Videos & podcasts ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Podcasts,Videos)
      * [ Support ](https://developer.microsoft.com/en-us/graph/support)
      * [ My apps ](https://go.microsoft.com/fwlink/?linkid=2083908)
      * Developer program
        * [ Join ](https://developer.microsoft.com/en-us/microsoft-365/dev-program)
        * [ Dashboard ](https://developer.microsoft.com/en-us/microsoft-365/profile)
        * [ Developer program docs ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program)
        * [ FAQ ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program-faq)


[ Download SDKs ](https://learn.microsoft.com/graph/sdks/sdks-overview) [ Open Graph Explorer ](https://developer.microsoft.com/en-us/graph/graph-explorer)
Search
Suggestions will filter as you type
  * [Overview of Microsoft Graph](https://learn.microsoft.com/en-us/graph/overview?view=graph-rest-1.0)
  * [Users you can reach](https://learn.microsoft.com/en-us/graph/users-you-can-reach?view=graph-rest-1.0)
  * [National cloud deployments](https://learn.microsoft.com/en-us/graph/deployments?view=graph-rest-1.0)
  * [Versioning and support](https://learn.microsoft.com/en-us/graph/versioning-and-support?view=graph-rest-1.0)
  * [Terms of use](https://learn.microsoft.com/en-us/legal/microsoft-apis/terms-of-use?context=graph%2Fcontext&view=graph-rest-1.0)
  *     * [Services and features](https://learn.microsoft.com/en-us/graph/overview-major-services?view=graph-rest-1.0)
    * [What's new](https://learn.microsoft.com/en-us/graph/whats-new-overview?view=graph-rest-1.0)
    * [API changelog](https://developer.microsoft.com/graph/changelog)
  *     * [Try the APIs](https://learn.microsoft.com/en-us/graph/graph-explorer/graph-explorer-overview?view=graph-rest-1.0)
    * [Quick start](https://developer.microsoft.com/graph/quick-start)
    * [Deploy in IaC with templates](https://learn.microsoft.com/en-us/graph/templates?toc=%2Fgraph%2Ftoc.json&view=graph-rest-1.0)
  *     * [Compliance](https://learn.microsoft.com/en-us/graph/compliance-concept-overview?view=graph-rest-1.0)
    * [Financials (preview)](https://learn.microsoft.com/en-us/graph/dynamics-business-central-concept-overview?view=graph-rest-1.0)
    * [Industry data ETL (preview)](https://learn.microsoft.com/en-us/graph/industrydata-concept-overview?view=graph-rest-1.0)
  *     *       * [Overview](https://learn.microsoft.com/en-us/graph/auth/?view=graph-rest-1.0)
      * [Basics](https://learn.microsoft.com/en-us/graph/auth/auth-concepts?view=graph-rest-1.0)
      * [Register your app](https://learn.microsoft.com/en-us/graph/auth-register-app-v2?view=graph-rest-1.0)
      * [Get access on behalf of a user](https://learn.microsoft.com/en-us/graph/auth-v2-user?view=graph-rest-1.0)
      * [Get access without a user](https://learn.microsoft.com/en-us/graph/auth-v2-service?view=graph-rest-1.0)
      *         * [Overview](https://learn.microsoft.com/en-us/graph/permissions-overview?view=graph-rest-1.0)
        * [Permissions reference](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0)
        * [Microsoft Entra built-in roles](https://learn.microsoft.com/en-us/entra/identity/role-based-access-control/permissions-reference?toc=%2Fgraph%2Ftoc.json&view=graph-rest-1.0)
        * [Best practices for Teams app permissions](https://learn.microsoft.com/en-us/graph/best-practices-graph-permission?view=graph-rest-1.0)
        * [Selected permissions in OneDrive and SharePoint](https://learn.microsoft.com/en-us/graph/permissions-selected-overview?view=graph-rest-1.0)
      * [Manage app access (CSPs)](https://learn.microsoft.com/en-us/graph/auth-cloudsolutionprovider?view=graph-rest-1.0)
      * [Limit mailbox access](https://learn.microsoft.com/en-us/exchange/permissions-exo/application-rbac?toc=%2Fgraph%2Ftoc.json&view=graph-rest-1.0)
      * [Resolve authorization errors](https://learn.microsoft.com/en-us/graph/resolve-auth-errors?view=graph-rest-1.0)
    * [Microsoft Graph activity logs](https://learn.microsoft.com/en-us/graph/microsoft-graph-activity-logs-overview?view=graph-rest-1.0)
    * [Configure Connected Services](https://learn.microsoft.com/en-us/graph/office-365-connected-services?view=graph-rest-1.0)
    * [Best practices](https://learn.microsoft.com/en-us/graph/best-practices-concept?view=graph-rest-1.0)
    * [Known issues](https://developer.microsoft.com/graph/known-issues)
    * [Errors](https://learn.microsoft.com/en-us/graph/errors?view=graph-rest-1.0)
    * [Microsoft Entra service limits](https://learn.microsoft.com/en-us/entra/identity/users/directory-service-limits-restrictions?toc=%2Fgraph%2Ftoc.json&view=graph-rest-1.0)
  * [API v1.0 reference](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0&preserve-view=true)
  * [API beta reference](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-beta&preserve-view=true)


Download PDF
Table of contents  Exit editor mode
  1. [ Learn ](https://learn.microsoft.com/en-us/?view=graph-rest-1.0)
  2. [ Microsoft Graph ](https://learn.microsoft.com/en-us/graph/?view=graph-rest-1.0)


  1. [Learn](https://learn.microsoft.com/en-us/?view=graph-rest-1.0)
  2. [Microsoft Graph](https://learn.microsoft.com/en-us/graph/?view=graph-rest-1.0)


Ask Learn Ask Learn Focus mode
Table of contents [ Read in English ](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0) Add to Collections Add to plan [ Edit ](https://github.com/microsoftgraph/microsoft-graph-docs-contrib/blob/main/concepts/permissions-reference.md)
* * *
#### Share via
[ Facebook ](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fpermissions-reference%3Fview%3Dgraph-rest-1.0%26WT.mc_id%3Dfacebook) [ x.com ](https://twitter.com/intent/tweet?original_referer=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fpermissions-reference%3Fview%3Dgraph-rest-1.0%26WT.mc_id%3Dtwitter&tw_p=tweetbutton&url=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fpermissions-reference%3Fview%3Dgraph-rest-1.0%26WT.mc_id%3Dtwitter) [ LinkedIn ](https://www.linkedin.com/feed/?shareActive=true&text=%0A%0D%0Ahttps%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fpermissions-reference%3Fview%3Dgraph-rest-1.0%26WT.mc_id%3Dlinkedin) Email
* * *
Copy Markdown Print
* * *
Note
Access to this page requires authorization. You can try [signing in](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0) or changing directories.
Access to this page requires authorization. You can try changing directories.
# Microsoft Graph permissions reference
Feedback
Summarize this article for me
##  In this article
  1. [All permissions](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#all-permissions)
  2. [Resource-specific consent (RSC) permissions](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#resource-specific-consent-rsc-permissions)
  3. [Related content](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#related-content)


For an app to access data in Microsoft Graph, the user or administrator must grant it the necessary permissions. This article lists the delegated and application permissions exposed by Microsoft Graph. For guidance about how to use the permissions, see the [Overview of Microsoft Graph permissions](https://learn.microsoft.com/en-us/graph/permissions-overview).
To read information about all Microsoft Graph permissions programmatically, sign in to an API client such as Graph Explorer using an account that has at least the _Application.Read.All_ permission and run the following request.
msgraph
Copy Try It
```
GET https://graph.microsoft.com/v1.0/servicePrincipals(appId='00000003-0000-0000-c000-000000000000')?$select=id,appId,displayName,appRoles,oauth2PermissionScopes,resourceSpecificApplicationPermissions

```

As a best practice, request the least privileged permissions that your app needs in order to access data and function correctly. Requesting permissions with more than the necessary privileges is poor security practice, which may cause users to refrain from consenting and affect your app's usage.
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#all-permissions)
## All permissions
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#accessreviewreadall)
### AccessReview.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | d07a8cc0-3d51-4b77-b3b0-32704d1f69fa | ebfcd32b-babb-40f4-a14b-42706e83bd28
DisplayText | Read all access reviews | Read all access reviews that user can access
Description | Allows the app to read access reviews, reviewers, decisions and settings in the organization, without a signed-in user. | Allows the app to read access reviews, reviewers, decisions and settings that the signed-in user has access to in the organization.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#accessreviewreadwriteall)
### AccessReview.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | ef5f7d5c-338f-44b0-86c3-351f46c8bb5f | e4aa47b9-9a69-4109-82ed-36ec70d85ff1
DisplayText | Manage all access reviews | Manage all access reviews that user can access
Description | Allows the app to read, update, delete and perform actions on access reviews, reviewers, decisions and settings in the organization, without a signed-in user. | Allows the app to read, update, delete and perform actions on access reviews, reviewers, decisions and settings that the signed-in user has access to in the organization.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#accessreviewreadwritemembership)
### AccessReview.ReadWrite.Membership
Expand table
Category | Application | Delegated
---|---|---
Identifier | 18228521-a591-40f1-b215-5fad4488c117 | 5af8c3f5-baca-439a-97b0-ea58a435e269
DisplayText | Manage access reviews for group and app memberships | Manage access reviews for group and app memberships
Description | Allows the app to read, update, delete and perform actions on access reviews, reviewers, decisions and settings in the organization for group and app memberships, without a signed-in user. | Allows the app to read, update, delete and perform actions on access reviews, reviewers, decisions and settings for group and app memberships that the signed-in user has access to in the organization.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#acronymreadall)
### Acronym.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 8c0aed2c-0c61-433d-b63c-6370ddc73248 | 9084c10f-a2d6-4713-8732-348def50fe02
DisplayText | Read all acronyms | Read all acronyms that the user can access
Description | Allows an app to read all acronyms without a signed-in user. | Allows an app to read all acronyms that the signed-in user can access.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#administrativeunitreadall)
### AdministrativeUnit.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 134fd756-38ce-4afd-ba33-e9623dbe66c2 | 3361d15d-be43-4de6-b441-3c746d05163d
DisplayText | Read all administrative units | Read administrative units
Description | Allows the app to read administrative units and administrative unit membership without a signed-in user. | Allows the app to read administrative units and administrative unit membership on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#administrativeunitreadwriteall)
### AdministrativeUnit.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 5eb59dd3-1da2-4329-8733-9dabdc435916 | 7b8a2d34-6b3f-4542-a343-54651608ad81
DisplayText | Read and write all administrative units | Read and write administrative units
Description | Allows the app to create, read, update, and delete administrative units and manage administrative unit membership without a signed-in user. | Allows the app to create, read, update, and delete administrative units and manage administrative unit membership on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentcardreadall)
### AgentCard.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | aec9e0a0-6f46-4150-a9f7-05e9e3e87399 | 73ea6732-992c-4292-98f7-9feff18d3ade
DisplayText | Read all agent cards in Agent Registry | Read agent cards in Agent Registry
Description | Allows the app to read all agent cards and their skills in your organization's Agent Registry without a signed-in user. | Allows the app to read agent cards and their skills in your organization's Agent Registry on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentcardreadwriteall)
### AgentCard.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | ef566853-42d6-45a5-bed9-5ccb82c98b4f | b0f726a8-0fa2-4ce2-937b-fd17a446261f
DisplayText | Read and write all agent cards in Agent Registry | Read and write agent cards in Agent Registry
Description | Allows the app to create, read, update, and delete all agent cards and manage their skills in your organization's Agent Registry without a signed-in user. | Allows the app to create, read, update, and delete agent cards and manage their skills in your organization's Agent Registry on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentcardreadwritemanagedby)
### AgentCard.ReadWrite.ManagedBy
Expand table
Category | Application | Delegated
---|---|---
Identifier | 9c4a07db-e0c1-4fb0-8e85-dfd8ae3b8201 | -
DisplayText | Read and write managed-by agent cards in Agent Registry | -
Description | Allows the app to read and update agent cards that designate the calling app as their manager and manage their skills in your organization's Agent Registry without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentcardmanifestreadall)
### AgentCardManifest.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 3ee18438-e6e5-4858-8f1c-d7b723b45213 | ada96a26-9579-4c29-a578-c3482a765716
DisplayText | Read all agent card manifests in Agent Registry | Read agent card manifests in Agent Registry
Description | Allows the app to read all agent card manifests in your organization's Agent Registry without a signed-in user. | Allows the app to read agent card manifests in your organization's Agent Registry on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentcardmanifestreadwriteall)
### AgentCardManifest.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 228b1a03-f7ca-4348-b50d-e8a547ab61af | 80151b1a-1c31-4846-ae0d-c79939ee13d1
DisplayText | Read and write all agent card manifests in Agent Registry | Read and write agent card manifests in Agent Registry
Description | Allows the app to read and write to all agent card manifests in your organization's Agent Registry without a signed-in user. | Allows the app to read and write agent card manifests in your organization's Agent Registry on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentcardmanifestreadwritemanagedby)
### AgentCardManifest.ReadWrite.ManagedBy
Expand table
Category | Application | Delegated
---|---|---
Identifier | 77f6034c-52f5-4526-9fa1-d55a67e72cc4 | -
DisplayText | Read and write managed-by agent card manifests in Agent Registry | -
Description | Allows the app to read and write agent card manifests that name it as manager in your organization's Agent Registry without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentcollectionreadall)
### AgentCollection.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | e65ee1da-d1d5-467b-bdd0-3e9bb94e6e0c | fa50be38-fdff-469c-96dc-ef5fce3c64bf
DisplayText | Read all collections in Agent Registry | Read collections in Agent Registry
Description | Allows the app to read all collections and their membership in your organization's Agent Registry without a signed-in user. | Allows the app to read collections and their membership in your organization's Agent Registry on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentcollectionreadglobal)
### AgentCollection.Read.Global
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | b14924c8-87f1-438a-81f2-dc370ba2f45d
DisplayText | - | Read global collection in Agent Registry
Description | - | Allows the app to read global collection and its membership in your organization's Agent Registry on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentcollectionreadquarantined)
### AgentCollection.Read.Quarantined
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 43acfda3-daf3-4aa4-955d-b051d0024e82
DisplayText | - | Read quarantined collection in Agent Registry
Description | - | Allows the app to read quarantined collection and its membership in your organization's Agent Registry on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentcollectionreadwriteall)
### AgentCollection.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | feb31d7d-a227-4487-898c-e014840d07b3 | 6d8a7002-a05e-4b95-a768-0e6f0badc6c8
DisplayText | Read and write all collections in Agent Registry | Read and write collections in Agent Registry
Description | Allows the app to create, read, update, and delete all collections and manage their membership in your organization's Agent Registry without a signed-in user. | Allows the app to create, read, update, and delete collections and manage their membership in your organization's Agent Registry on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentcollectionreadwriteglobal)
### AgentCollection.ReadWrite.Global
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | c001dd65-8a6b-4349-ab0c-4e8a410d28d2
DisplayText | - | Read and write global collection in Agent Registry
Description | - | Allows the app to read and update global collection and manage its membership in your organization's Agent Registry on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentcollectionreadwritemanagedby)
### AgentCollection.ReadWrite.ManagedBy
Expand table
Category | Application | Delegated
---|---|---
Identifier | 2e0fb698-9996-479f-926b-ce63f4397829 | -
DisplayText | Read and write managed-by collections in Agent Registry | -
Description | Allows the app to create, read, update, and delete collections that designate the calling app as their manager and manage their membership in your organization's Agent Registry without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentcollectionreadwritequarantined)
### AgentCollection.ReadWrite.Quarantined
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | ae331cc9-9f51-484b-a90b-124f2e4a6398
DisplayText | - | Read and write quarantined collection in Agent Registry
Description | - | Allows the app to read and update quarantined collection and manage its membership in your organization's Agent Registry on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentidentitycreateall)
### AgentIdentity.Create.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | ad25cc1d-84d8-47df-a08e-b34c2e800819 | -
DisplayText | Create agent identities without an agent blueprint parent | -
Description | Allows the app to create agent identities, even if the app is not the parent agent identity blueprint. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentidentitycreateasmanager)
### AgentIdentity.CreateAsManager
Expand table
Category | Application | Delegated
---|---|---
Identifier | 4c390976-b2b7-42e0-9187-c6be3bead001 | -
DisplayText | Create agent identities linked to itself. | -
Description | Allows the app to create linked agent identities without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentidentitydeleterestoreall)
### AgentIdentity.DeleteRestore.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 5b016f9b-18eb-41d4-869a-66931914d1c8 | c8ee41e5-35e7-4fe9-8ecb-93493adcac5b
DisplayText | Delete and restore agent identities | Delete and restore agent identities
Description | Allows the app to delete and restore agent identities without a signed-in user. | Allows the client to delete and restore agent identities.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentidentityenabledisableall)
### AgentIdentity.EnableDisable.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 69ee0943-4fa4-4ec8-8e52-d12e4ea661a3 | a501206a-e364-4a3f-be6e-765806d0e323
DisplayText | Enable or disable agent identities | Enable or disable agent identities
Description | Allows the app to enable or disable agent identities without a signed-in user. | Allows the client to enable or disable agent identities.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentidentityreadall)
### AgentIdentity.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | b2b8f011-2898-4234-9092-5059f6c1ebfa | 5e850691-d86a-4b24-bfa6-8a52fb37a0c1
DisplayText | Read all agent identities | Read all agent identities
Description | Allows the app to read all agent identities without a signed-in user. | Allows the client to read all agent identities.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentidentityreadwriteall)
### AgentIdentity.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | dcf7150a-88d4-4fe6-9be1-c2744c455397 | 4a4facd5-0ee1-49b7-a5b2-fdcc2491685e
DisplayText | Read and write all agent identities | Read and write all agent identities
Description | Allows the app read, update, and delete agent identities without a signed-in user. | Allows the client to read, update, and delete agent identities on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentidentityblueprintaddremovecredsall)
### AgentIdentityBlueprint.AddRemoveCreds.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 0510736e-bdfb-4b37-9a1f-89b4a074763a | 75b5feb2-bfe7-423f-907d-cc505186f246
DisplayText | Update agent identity blueprint credentials | Update agent identity blueprint credentials
Description | Allows updating agent identity blueprint credentials without a signed-in user. | Allows updating agent identity blueprint credentials on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentidentityblueprintcreate)
### AgentIdentityBlueprint.Create
Expand table
Category | Application | Delegated
---|---|---
Identifier | ea4b2453-ad2d-4d94-9155-10d5d9493ce9 | 8fc15edd-ba24-494e-9bf6-d38e1b7ba8fd
DisplayText | Create agent identity blueprints. | Create agent identity blueprints.
Description | Allows creating new agent identity blueprints without a signed-in user. | Allows creating new agent identity blueprints with a signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentidentityblueprintdeleterestoreall)
### AgentIdentityBlueprint.DeleteRestore.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 3f80b699-6405-4e36-a4df-4f19950ff91e | f12ba1f6-afb7-4685-9a30-21e8c3f551d8
DisplayText | Delete and restore agent identity blueprints. | Delete and restore agent identity blueprints.
Description | Allows deleting or restoring agent identity blueprints without a signed-in user. | Allows deleting or restoring agent identity blueprints with a signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentidentityblueprintreadall)
### AgentIdentityBlueprint.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 7547a7d1-36fa-4479-9c31-559a600eaa4f | 26512dc8-1364-4e9f-867c-6d8b22a9e162
DisplayText | Read all agent identity blueprints | Read all agent identity blueprints
Description | Allows the app to read all agent identity blueprints without a signed-in user. | Allows the client to read all agent identity blueprints.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentidentityblueprintreadwriteall)
### AgentIdentityBlueprint.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 7fddd33b-d884-4ec0-8696-72cff90ff825 | 4fd490fc-1467-48eb-8a4c-421597ab0402
DisplayText | Read and write all agent identity blueprints. | Read and write all agent identity blueprints.
Description | Allows the app to read, update, and delete agent identity blueprints without a signed-in user. | Allows the app to read, update, and delete agent identity blueprints on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentidentityblueprintupdateauthpropertiesall)
### AgentIdentityBlueprint.UpdateAuthProperties.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 19202363-278e-49c2-bf00-391e2ba00881 | 6f677aa9-25af-49a5-8a1d-628dc7f0d009
DisplayText | Update agent identity blueprint authorization and authentication properties | Update agent identity blueprint authorization and authentication properties
Description | Allows updating agent identity blueprint authorization and authentication properties without a signed-in user. | Allows updating agent identity blueprint authorization and authentication properties on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentidentityblueprintupdatebrandingall)
### AgentIdentityBlueprint.UpdateBranding.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 76232daa-a1e4-4544-b664-495a006513bf | 60960e31-67cb-4d25-9d36-4922109923a2
DisplayText | Update agent identity blueprint branding | Update agent identity blueprint branding
Description | Allows updating agent identity blueprint branding without a signed-in user. | Allows updating agent identity blueprint branding on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentidentityblueprintprincipalcreate)
### AgentIdentityBlueprintPrincipal.Create
Expand table
Category | Application | Delegated
---|---|---
Identifier | 8959696d-d07e-4916-9b1e-3ba9ce459161 | 00dcd896-6b23-42ce-b5de-c58493c05e22
DisplayText | Create agent identity blueprint service principals. | Create agent identity blueprint service principals.
Description | Allows creating new agent identity blueprint principals without a signed-in user. | Allows creating new agent identity blueprint principals with a signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentidentityblueprintprincipaldeleterestoreall)
### AgentIdentityBlueprintPrincipal.DeleteRestore.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | f86a2dd8-9298-4675-bd78-f5a3572da2d7 | 2c70023e-a482-4af2-9ff1-51ded53e6bad
DisplayText | Delete and restore agent identity blueprints. | Delete and restore agent identity blueprints.
Description | Allows deleting or restoring agent identity blueprints without a signed-in user. | Allows deleting or restoring agent identity blueprints with a signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentidentityblueprintprincipalenabledisableall)
### AgentIdentityBlueprintPrincipal.EnableDisable.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | a0bdd23d-8b19-4682-b428-574d96527c6f | e7475e0a-9f02-43e2-a250-5c2ea74ccd0e
DisplayText | Enable or disable agent identity blueprint principals. | Enable or disable agent identity blueprint principals.
Description | Allows enabling or disabling agent identity blueprint principals without a signed-in user. | Allows enabling or disabling agent identity blueprint principals with a signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentidentityblueprintprincipalreadall)
### AgentIdentityBlueprintPrincipal.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 9361dea9-4524-493d-941d-f1b65aaf6c7c | 88c856a2-de61-4632-b2d4-ac503cbc8dd2
DisplayText | Read agent identity blueprint principals. | Read agent identity blueprints principals.
Description | Allows reading agent identity blueprint principals without a signed-in user. | Allows reading agent identity blueprint principals with a signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentidentityblueprintprincipalreadwriteall)
### AgentIdentityBlueprintPrincipal.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 3bc933bc-8b4d-4cb6-ac49-b73774299250 | bf2cad6a-9082-438a-9a63-95fa2687af65
DisplayText | Read and write all agent identity blueprint principals. | Read and write all agent identity blueprint principals.
Description | Allows the app to read, update, and delete agent identity blueprint principals without a signed-in user. | Allows the app to read, update, and delete agent identity blueprint principals on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentiduserreadwriteall)
### AgentIdUser.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | b782c9ad-6f2b-4894-a21b-72bf22417f0a | ad57fb88-4658-4fd6-ab7d-e43184b08e4e
DisplayText | Read and write all agent ID users' full profiles | Read and write all agent ID users' full profiles
Description | Allows the app to read and update agent ID user profiles and read basic company properties without a signed in user. | Allows the app to read and write the full set of profile properties, reports, and managers of agent ID users in your organization, and read basic company properties, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentiduserreadwriteidentityparentedby)
### AgentIdUser.ReadWrite.IdentityParentedBy
Expand table
Category | Application | Delegated
---|---|---
Identifier | 4aa6e624-eee0-40ab-bdd8-f9639038a614 | 52a417d9-0b3c-4466-9a3b-66960de73d74
DisplayText | Read and write all agent ID users' full profiles | Read and write all agent ID users' full profiles
Description | Allows the app to read and update ID agent user profiles and read basic company properties without a signed in user. | Allows the app to read and write the full set of profile properties, reports, and managers of agent ID users in your organization, and read basic company properties, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentinstancereadall)
### AgentInstance.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 799a4732-85b8-4c67-b048-75f0e88a232b | 4c3c738a-2df0-4877-bf4a-f796950ff34c
DisplayText | Read all agent instances in Agent Registry | Read agent instances in Agent Registry
Description | Allows the app to read all agent instances and their related collections in your organization's Agent Registry without a signed-in user. | Allows the app to read agent instances and their related collections in your organization's Agent Registry on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentinstancereadwriteall)
### AgentInstance.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 07abdd95-78dc-4353-bd32-09f880ea43d0 | fc79e324-da24-497a-b5ec-e7de08320375
DisplayText | Read and write all agent instances in Agent Registry | Read and write agent instances in Agent Registry
Description | Allows the app to create, read, update, and delete all agent instances in your organization's Agent Registry without a signed-in user. | Allows the app to create, read, update, and delete agent instances in your organization's Agent Registry on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agentinstancereadwritemanagedby)
### AgentInstance.ReadWrite.ManagedBy
Expand table
Category | Application | Delegated
---|---|---
Identifier | 782ab1bf-24f1-4c27-8bbc-2006d42792a6 | -
DisplayText | Read and write managed-by agent instances in Agent Registry | -
Description | Allows the app to create, read, update, and delete agent instances that designate the calling app as their manager in your organization's Agent Registry without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agreementreadall)
### Agreement.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 2f3e6f8c-093b-4c57-a58b-ba5ce494a169 | af2819c9-df71-4dd3-ade7-4d7c9dc653b7
DisplayText | Read all terms of use agreements | Read all terms of use agreements
Description | Allows the app to read terms of use agreements, without a signed in user. | Allows the app to read terms of use agreements on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agreementreadwriteall)
### Agreement.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | c9090d00-6101-42f0-a729-c41074260d47 | ef4b5d93-3104-4664-9053-a5c49ab44218
DisplayText | Read and write all terms of use agreements | Read and write all terms of use agreements
Description | Allows the app to read and write terms of use agreements, without a signed in user. | Allows the app to read and write terms of use agreements on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agreementacceptanceread)
### AgreementAcceptance.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 0b7643bb-5336-476f-80b5-18fbfbc91806
DisplayText | - | Read user terms of use acceptance statuses
Description | - | Allows the app to read terms of use acceptance statuses on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#agreementacceptancereadall)
### AgreementAcceptance.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | d8e4ec18-f6c0-4620-8122-c8b1f2bf400e | a66a5341-e66e-4897-9d52-c2df58c2bfb9
DisplayText | Read all terms of use acceptance statuses | Read terms of use acceptance statuses that user can access
Description | Allows the app to read terms of use acceptance statuses, without a signed in user. | Allows the app to read terms of use acceptance statuses on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#aienterpriseinteractionread)
### AiEnterpriseInteraction.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 859cceb9-2ec2-4e48-bcd7-b8490b5248a5
DisplayText | - | Read user AI enterprise interactions.
Description | - | Allows the app to read user AI enterprise interactions, on behalf of the signed-in user.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#aienterpriseinteractionreadall)
### AiEnterpriseInteraction.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 839c90ab-5771-41ee-aef8-a562e8487c1e | -
DisplayText | Read all AI enterprise interactions. | -
Description | Allows the app to read all AI enterprise interactions. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#analyticsread)
### Analytics.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | e03cf23f-8056-446a-8994-7d93dfc8b50e
DisplayText | - | Read user activity statistics
Description | - | Allows the app to read the signed-in user's activity statistics, such as how much time the user has spent on emails, in meetings, or in chat sessions.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#apiconnectorsreadall)
### APIConnectors.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | b86848a7-d5b1-41eb-a9b4-54a4e6306e97 | 1b6ff35f-31df-4332-8571-d31ea5a4893f
DisplayText | Read API connectors for authentication flows | Read API connectors for authentication flows
Description | Allows the app to read the API connectors used in user authentication flows, without a signed-in user. | Allows the app to read the API connectors used in user authentication flows, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#apiconnectorsreadwriteall)
### APIConnectors.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 1dfe531a-24a6-4f1b-80f4-7a0dc5a0a171 | c67b52c5-7c69-48b6-9d48-7b3af3ded914
DisplayText | Read and write API connectors for authentication flows | Read and write API connectors for authentication flows
Description | Allows the app to read, create and manage the API connectors used in user authentication flows, without a signed-in user. | Allows the app to read, create and manage the API connectors used in user authentication flows, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#appcatalogreadall)
### AppCatalog.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | e12dae10-5a57-4817-b79d-dfbec5348930 | 88e58d74-d3df-44f3-ad47-e89edf4472e4
DisplayText | Read all app catalogs | Read all app catalogs
Description | Allows the app to read apps in the app catalogs without a signed-in user. | Allows the app to read the apps in the app catalogs.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#appcatalogreadwriteall)
### AppCatalog.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | dc149144-f292-421e-b185-5953f2e98d7f | 1ca167d5-1655-44a1-8adf-1414072e1ef9
DisplayText | Read and write to all app catalogs | Read and write to all app catalogs
Description | Allows the app to create, read, update, and delete apps in the app catalogs without a signed-in user. | Allows the app to create, read, update, and delete apps in the app catalogs.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#appcatalogsubmit)
### AppCatalog.Submit
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 3db89e36-7fa6-4012-b281-85f3d9d9fd2e
DisplayText | - | Submit application packages to the catalog and cancel pending submissions
Description | - | Allows the app to submit application packages to the catalog and cancel submissions that are pending review on behalf of the signed-in user.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#appcerttrustconfigurationreadall)
### AppCertTrustConfiguration.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | af281d3a-030d-4122-886e-146fb30a0413
DisplayText | - | Read the trusted certificate authority configuration for applications
Description | - | Allows the app to read the trusted certificate authority configuration which can be used to restrict application certificates based on their issuing authority, on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#appcerttrustconfigurationreadwriteall)
### AppCertTrustConfiguration.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 4bae2ed4-473e-4841-a493-9829cfd51d48
DisplayText | - | Read and write the trusted certificate authority configuration for applications
Description | - | Allows the app to create, read, update and delete the trusted certificate authority configuration which can be used to restrict application certificates based on their issuing authority, on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#application-remotedesktopconfigreadwriteall)
### Application-RemoteDesktopConfig.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 3be0012a-cc4e-426b-895b-f9c836bf6381 | ffa91d43-2ad8-45cc-b592-09caddeb24bb
DisplayText | Read and write the remote desktop security configuration for all apps | Read and write the remote desktop security configuration for apps
Description | Allows the app to read and write the remote desktop security configuration for all apps in your organization, without a signed-in user. | Allows the app to read and write other apps' remote desktop security configuration, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#applicationreadall)
### Application.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 9a5d68dd-52b0-4cc2-bd40-abcf44ac3a30 | c79f8feb-a9db-4090-85f9-90d820caa0eb
DisplayText | Read all applications | Read applications
Description | Allows the app to read all applications and service principals without a signed-in user. | Allows the app to read applications and service principals on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Application.Read.All_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#applicationreadupdateall)
### Application.ReadUpdate.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | fc023787-fd04-4e44-9bc7-d454f00c0f0a | 0586a906-4d89-4de8-b3c8-1aacdcc0c679
DisplayText | Read and update all apps | Read and update all apps
Description | Allows the app to read and update all apps in your organization, without a signed-in user. | Allows the app to read and update all apps in your organization, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#applicationreadwriteall)
### Application.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 1bfefb4e-e0b5-418b-a88f-73c46d2cc8e9 | bdfbf15f-ee85-4955-8675-146e8e5296b5
DisplayText | Read and write all applications | Read and write all applications
Description | Allows the app to create, read, update and delete applications and service principals without a signed-in user. Does not allow management of consent grants. | Allows the app to create, read, update and delete applications and service principals on behalf of the signed-in user. Does not allow management of consent grants.
AdminConsentRequired | Yes | Yes
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Application.ReadWrite.All_ delegated permission is available for consent in personal Microsoft accounts.
Permissions that allow managing credentials, such as _Application.ReadWrite.All_ , allow an application to act as other entities, and use the privileges they were granted. Use caution when granting any of these permissions.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#applicationreadwriteownedby)
### Application.ReadWrite.OwnedBy
Expand table
Category | Application | Delegated
---|---|---
Identifier | 18a4783c-866b-4cc7-a460-3d5e5662c884 | -
DisplayText | Manage apps that this app creates or owns | -
Description | Allows the app to create other applications, and fully manage those applications (read, update, update application secrets and delete), without a signed-in user. It cannot update any apps that it is not an owner of. | -
AdminConsentRequired | Yes | -
The _Application.ReadWrite.OwnedBy_ permission allows the same operations as _Application.ReadWrite.All_ but only on applications and service principals that the calling app is an owner of.
The _Application.ReadWrite.OwnedBy_ permission allows an app to call `GET /applications` and `GET /servicePrincipals` endpoints to list all applications and service principals in the tenant. This scope of access has been allowed for the permission.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#approleassignmentreadwriteall)
### AppRoleAssignment.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 06b708a9-e830-4db3-a914-8e69da51d44f | 84bccea3-f856-4a8a-967b-dbe0a3d53a64
DisplayText | Manage app permission grants and app role assignments | Manage app permission grants and app role assignments
Description | Allows the app to manage permission grants for application permissions to any API (including Microsoft Graph) and application assignments for any app, without a signed-in user. | Allows the app to manage permission grants for application permissions to any API (including Microsoft Graph) and application assignments for any app, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
Permissions that allow granting authorization, such as _AppRoleAssignment.ReadWrite.All_ , allow an application to grant additional privileges to itself, other applications, or any user. Use caution when granting any of these permissions.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#approvalsolutionread)
### ApprovalSolution.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | b0df437d-d341-4df0-aa3e-89ca81a1207f
DisplayText | - | Read approvals
Description | - | Allows the app to read approvals on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#approvalsolutionreadall)
### ApprovalSolution.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 9f265de7-8d5e-4e9a-a805-5e8bbc49656f | -
DisplayText | Read all approvals | -
Description | Allows the app to read all approvals and approval item subscriptions, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#approvalsolutionreadwrite)
### ApprovalSolution.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 6768d3af-4562-48ff-82d2-c5e19eb21b9c
DisplayText | - | Read, create, and respond to approvals
Description | - | Allows the app to provision, read, create, and respond to approvals on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#approvalsolutionreadwriteall)
### ApprovalSolution.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 45583558-1113-4d06-8969-e79a28edc9ad | -
DisplayText | Read all approvals and manage approval subscriptions | -
Description | Allows the app to read all approvals and create, update, or remove approval item subscriptions, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#approvalsolutionresponsereadwrite)
### ApprovalSolutionResponse.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 89d944f2-2011-44ad-830c-aa9bf5ef2319
DisplayText | - | Read and respond to approvals assigned to the current user
Description | - | Allows the app to read and respond to approvals on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#attacksimulationreadall)
### AttackSimulation.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 93283d0a-6322-4fa8-966b-8c121624760d | 104a7a4b-ca76-4677-b7e7-2f4bc482f381
DisplayText | Read attack simulation data of an organization | Read attack simulation data of an organization
Description | Allows the app to read attack simulation and training data for an organization without a signed-in user. | Allows the app to read attack simulation and training data for an organization for the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#attacksimulationreadwriteall)
### AttackSimulation.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | e125258e-8c8a-42a8-8f55-ab502afa52f3 | 27608d7c-2c66-4cad-a657-951d575f5a60
DisplayText | Read, create, and update all attack simulation data of an organization | Read, create, and update attack simulation data of an organization
Description | Allows the app to read, create, and update attack simulation and training data for an organization without a signed-in user. | Allows the app to read, create, and update attack simulation and training data for an organization for the signed-in user.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#auditactivityread)
### AuditActivity.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | 99bc85fb-e857-4220-9f8c-3a1c83148d2e | 16786f81-40d2-4116-bb26-d1a753bf0b20
DisplayText | Read activity audit log from the audit store. | Read activity audit log from the audit store.
Description | Read activity audit log from the audit store. | Read activity audit log from the audit store.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#auditactivitywrite)
### AuditActivity.Write
Expand table
Category | Application | Delegated
---|---|---
Identifier | f6318678-2713-4bb6-b123-233e7336c1bd | a78fd341-0672-4792-a8ae-a5925b2546eb
DisplayText | Upload activity audit logs to the audit store. | Upload activity audit logs to the audit store.
Description | Allows the application to upload bulk activity audit logs to the audit store. | Allows the application to upload bulk activity audit logs to the audit store.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#auditlogreadall)
### AuditLog.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | b0afded3-3588-46d8-8b3d-9842eff778da | e4c9e354-4dc5-45b8-9e7c-e1393b0b1a20
DisplayText | Read all audit log data | Read audit log data
Description | Allows the app to read and query your audit log activities, without a signed-in user. | Allows the app to read and query your audit log activities, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#auditlogsquery-crmreadall)
### AuditLogsQuery-CRM.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 20e6f8e4-ffac-4cf7-82f7-70ddb7564318 | ba78b16f-1e01-41b6-89ca-73e0a32b304c
DisplayText | Read audit logs data from Dynamics CRM workload | Read audit logs data from Dynamics CRM workload
Description | Allows the app to read and query audit logs from Dynamics CRM workload, without a signed-in user | Allows the app to read and query audit logs from Dynamics CRM workload, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#auditlogsquery-endpointreadall)
### AuditLogsQuery-Endpoint.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 0bc85aed-7b0b-437a-bac8-3b29a1b84c99 | ee3409fe-617f-43cf-bd1e-fc8b38049e69
DisplayText | Read audit logs data from Endpoint Data Loss Prevention workload | Read audit logs data from Endpoint Data Loss Prevention workload
Description | Allows the app to read and query audit logs from Endpoint Data Loss Prevention workload, without a signed-in user | Allows the app to read and query audit logs from Endpoint Data Loss Prevention workload, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#auditlogsquery-entrareadall)
### AuditLogsQuery-Entra.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 7276d950-48fc-4269-8348-f22f2bb296d0 | 5ff2f415-e0f1-4d11-bfd0-6d87c0f667fd
DisplayText | Read audit logs data from Entra (Azure AD) workload | Read audit logs data from Entra (Azure AD) workload
Description | Allows the app to read and query audit logs from Entra (Azure AD) workload, without a signed-in user | Allows the app to read and query audit logs from Entra (Azure AD) workload, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#auditlogsquery-exchangereadall)
### AuditLogsQuery-Exchange.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 6b0d2622-d34e-4470-935b-b96550e5ca8d | 6c8c71d2-c7e1-45b0-ac6d-1d2724fba6ae
DisplayText | Read audit logs data from Exchange workload | Read audit logs data from Exchange workload
Description | Allows the app to read and query audit logs from Exchange workload, without a signed-in user | Allows the app to read and query audit logs from Exchange workload, on behalf of a signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#auditlogsquery-onedrivereadall)
### AuditLogsQuery-OneDrive.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 8a169a81-841c-45fd-ad43-96aede8801a0 | 4a72c235-a50d-4870-b598-fd88fd1fa074
DisplayText | Read audit logs data from OneDrive workload | Read audit logs data from OneDrive workload
Description | Allows the app to read and query audit logs from OneDrive workload, without a signed-in user | Allows the app to read and query audit logs from OneDrive workload, on behalf of a signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#auditlogsquery-sharepointreadall)
### AuditLogsQuery-SharePoint.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 91c64a47-a524-4fce-9bf3-3d569a344ecf | 30630b65-ed12-4a81-9130-e3a964109fae
DisplayText | Read audit logs data from SharePoint workload | Read audit logs data from SharePoint workload
Description | Allows the app to read and query audit logs from SharePoint workload, without a signed-in user | Allows the app to read and query audit logs from SharePoint workload, on behalf of a signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#auditlogsqueryreadall)
### AuditLogsQuery.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 5e1e9171-754d-478c-812c-f1755a9a4c2d | 1d9e7ac3-0eca-442c-82f9-e92625af6e6d
DisplayText | Read audit logs data from all services | Read audit logs data from all services
Description | Allows the app to read and query audit logs from all services. | Allows the app to read and query audit logs from all services, on behalf of a signed-in user
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#authenticationcontextreadall)
### AuthenticationContext.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 381f742f-e1f8-4309-b4ab-e3d91ae4c5c1 | 57b030f1-8c35-469c-b0d9-e4a077debe70
DisplayText | Read all authentication context information | Read all authentication context information
Description | Allows the app to read the authentication context information in your organization without a signed-in user. | Allows the app to read all authentication context information in your organization on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#authenticationcontextreadwriteall)
### AuthenticationContext.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | a88eef72-fed0-4bf7-a2a9-f19df33f8b83 | ba6d575a-1344-4516-b777-1404f5593057
DisplayText | Read and write all authentication context information | Read and write all authentication context information
Description | Allows the app to read and update the authentication context information in your organization without a signed-in user. | Allows the app to read and update all authentication context information in your organization on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#backuprestore-configurationreadall)
### BackupRestore-Configuration.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 5fbb5982-3230-4882-93c0-2167523ce0c2 | 444ed4b6-0554-4dc6-8e9c-3f9a34ee3ff6
DisplayText | Read all backup configuration policies | Read backup configuration policies
Description | Allows the app to read all backup configurations, and lists of Microsoft 365 service resources to be backed-up, without a signed-in user. | Allows the app to read the backup configuration, and list of Microsoft 365 service resources to be backed-up, on behalf of the signed in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#backuprestore-configurationreadwriteall)
### BackupRestore-Configuration.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 18133149-5489-40ac-80f0-4b6fa85f6cdc | a0244d16-171c-4496-8ffb-7b9b6954d339
DisplayText | Read and edit all backup configuration policies | Read and edit backup configuration policies
Description | Allows the app to read and update the backup configuration, and list of Microsoft 365 service resources to be backed-up, without a signed-in user. | Allows the app to read and update the backup configuration, and list of Microsoft 365 service resources to be backed-up, on behalf of the signed in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#backuprestore-controlreadall)
### BackupRestore-Control.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 6fe20a79-0e15-45a1-b019-834c125993a0 | af598c63-4292-4437-b925-e996354d3854
DisplayText | Read the status of the M365 backup service | Read the status of the M365 backup service
Description | Allows the app to read the status of M365 backup service (enable/disable), without signed in user | Allows the app to read the status of M365 backup service (enable/disable), on behalf of the signed in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#backuprestore-controlreadwriteall)
### BackupRestore-Control.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | fb240865-88f8-4a1d-923f-98dbc7920860 | 96d46335-d92d-41b8-bc9f-273a692381ea
DisplayText | Update or read the status of the M365 backup service | Update or read the status of the M365 backup service
Description | Allows the app to update or read the status of M365 backup service (enable/disable), without signed in user | Allows the app to update or read the status of M365 backup service (enable/disable), on behalf of the signed in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#backuprestore-monitorreadall)
### BackupRestore-Monitor.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | ecae8511-f2d7-4be4-bdbf-91f244d45986 | b4e98de1-4600-4e90-b5e1-7c1dfef04e5c
DisplayText | Read all monitoring, quota and billing information for the tenant | Read monitoring, quota and billing information for the tenant
Description | Allows the app to monitor all backup and restore jobs, view quota usage and billing details, without a signed-in user. | Allows the app to monitor backup and restore jobs, view quota usage and billing details, on behalf of the signed in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#backuprestore-restorereadall)
### BackupRestore-Restore.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 87853aa5-0372-4710-b34b-cef27bb7156e | 94b36f78-434f-4904-8c08-421d9a9c1dc2
DisplayText | Read all restore sessions | Read restore sessions
Description | Allows the app to read all restore sessions, without a signed-in user. | Allows the app to read restore sessions, on behalf of the signed in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#backuprestore-restorereadwriteall)
### BackupRestore-Restore.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | bebd0841-a3d8-4313-a51d-731112c8ee41 | 9f89e109-94b9-4c9b-b4fc-98cdaa54f574
DisplayText | Read restore all sessions and start restore sessions from backups | Read restore sessions and start restore sessions from backups
Description | Allows the app to search all backup snapshots for Microsoft 365 resources, and restore Microsoft 365 resources from a backed-up snapshot, without a signed-in user. | Allows the app to search the backup snapshots for Microsoft 365 resources, and restore Microsoft 365 resources from a backed-up snapshot, on behalf of the signed in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#backuprestore-searchreadall)
### BackupRestore-Search.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | f6135c51-c766-4be1-9638-ed90c2ed2443 | 2b24830f-f435-446f-ab5a-b1e70d9a2eb5
DisplayText | Search for metadata properties in all backup snapshots | Search for metadata properties in backup snapshots
Description | Allows the app to search all backup snapshots for Microsoft 365 resources, without a signed-in user. | Allows the app to search the backup snapshots for Microsoft 365 resources, on behalf of the signed in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#billingconfigurationreadwriteall)
### BillingConfiguration.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 9e8be751-7eee-4c09-bcfd-d64f6b087fd8 | 2bf6d319-dfca-4c22-9879-f88dcfaee6be
DisplayText | Read and write application billing configuration | Read and write application billing configuration
Description | Allows the app to read and write the billing configuration on all applications without a signed-in user. | Allows the app to read and write the billing configuration on all applications on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#bitlockerkeyreadall)
### BitlockerKey.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 57f1cf28-c0c4-4ec3-9a30-19a2eaaf2f6e | b27a61ec-b99c-4d6a-b126-c4375d08ae30
DisplayText | Read all BitLocker keys | Read BitLocker keys
Description | Allows an app to read BitLocker keys for all devices, without a signed-in user. Allows read of the recovery key. | Allows the app to read BitLocker keys on behalf of the signed-in user, for their owned devices. Allows read of the recovery key.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#bitlockerkeyreadbasicall)
### BitlockerKey.ReadBasic.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | f690d423-6b29-4d04-98c6-694c42282419 | 5a107bfc-4f00-4e1a-b67e-66451267bc68
DisplayText | Read all BitLocker keys basic information | Read BitLocker keys basic information
Description | Allows an app to read basic BitLocker key properties for all devices, without a signed-in user. Does not allow read of the recovery key. | Allows the app to read basic BitLocker key properties on behalf of the signed-in user, for their owned devices. Does not allow read of the recovery key itself.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#bookingsmanageall)
### Bookings.Manage.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 6b22000a-1228-42ec-88db-b8c00399aecb | 7f36b48e-542f-4d3b-9bcb-8406f0ab9fdb
DisplayText | Manage bookings information | Manage bookings information
Description | Allows an app to read, write and manage bookings appointments, businesses, customers, services, and staff on behalf of the signed-in user. | Allows an app to read, write and manage bookings appointments, businesses, customers, services, and staff on behalf of the signed-in user.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#bookingsreadall)
### Bookings.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 6e98f277-b046-4193-a4f2-6bf6a78cd491 | 33b1df99-4b29-4548-9339-7a7b83eaeebc
DisplayText | Read all Bookings related resources. | Read bookings information
Description | Allows an app to read Bookings appointments, businesses, customers, services, and staff without a signed-in user. | Allows an app to read bookings appointments, businesses, customers, services, and staff on behalf of the signed-in user.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#bookingsreadwriteall)
### Bookings.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 0c4b2d20-7919-468d-8668-c54b09d4dee8 | 948eb538-f19d-4ec5-9ccc-f059e1ea4c72
DisplayText | Read and write bookings information | Read and write bookings information
Description | Allows an app to read and write bookings appointments, businesses, customers, services, and staff on behalf of the signed-in user. Does not allow create, delete and publish of booking businesses. | Allows an app to read and write bookings appointments, businesses, customers, services, and staff on behalf of the signed-in user. Does not allow create, delete and publish of booking businesses.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#bookingsappointmentreadwriteall)
### BookingsAppointment.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 9769393e-5a9f-4302-9e3d-7e018ecb64a7 | 02a5a114-36a6-46ff-a102-954d89d9ab02
DisplayText | Read and write all Bookings related resources. | Read and write booking appointments
Description | Allows an app to read and write Bookings appointments and customers, and additionally allows reading businesses, services, and staff without a signed-in user. | Allows an app to read and write bookings appointments and customers, and additionally allows read businesses information, services, and staff on behalf of the signed-in user.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#bookmarkreadall)
### Bookmark.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | be95e614-8ef3-49eb-8464-1c9503433b86 | 98b17b35-f3b1-4849-a85f-9f13733002f0
DisplayText | Read all bookmarks | Read all bookmarks that the user can access
Description | Allows an app to read all bookmarks without a signed-in user. | Allows an app to read all bookmarks that the signed-in user can access.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#browsersitelistsreadall)
### BrowserSiteLists.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | c5ee1f21-fc7f-4937-9af0-c91648ff9597 | fb9be2b7-a7fc-4182-aec1-eda4597c43d5
DisplayText | Read all browser site lists for your organization | Read browser site lists for your organization
Description | Allows an app to read all browser site lists configured for your organization, without a signed-in user. | Allows an app to read the browser site lists configured for your organization, on behalf of the signed-in user.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#browsersitelistsreadwriteall)
### BrowserSiteLists.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 8349ca94-3061-44d5-9bfb-33774ea5e4f9 | 83b34c85-95bf-497b-a04e-b58eca9d49d0
DisplayText | Read and write all browser site lists for your organization | Read and write browser site lists for your organization
Description | Allows an app to read and write all browser site lists configured for your organization, without a signed-in user. | Allows an app to read and write the browser site lists configured for your organization, on behalf of the signed-in user.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#businessscenarioconfigreadall)
### BusinessScenarioConfig.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | d16480b2-e469-4118-846b-d3d177327bee
DisplayText | - | Read business scenario configurations
Description | - | Allows the app to read the configurations of your organization's business scenarios, on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#businessscenarioconfigreadownedby)
### BusinessScenarioConfig.Read.OwnedBy
Expand table
Category | Application | Delegated
---|---|---
Identifier | acc0fc4d-2cd6-4194-8700-1768d8423d86 | c47e7b6e-d6f1-4be9-9ffd-1e00f3e32892
DisplayText | Read all business scenario configurations this app creates or owns | Read business scenario configurations this app creates or owns
Description | Allows the app to read the configurations of business scenarios it owns, without a signed-in user. | Allows the app to read the configurations of business scenarios it owns, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#businessscenarioconfigreadwriteall)
### BusinessScenarioConfig.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 755e785b-b658-446f-bb22-5a46abd029ea
DisplayText | - | Read and write business scenario configurations
Description | - | Allows the app to read and write the configurations of your organization's business scenarios, on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#businessscenarioconfigreadwriteownedby)
### BusinessScenarioConfig.ReadWrite.OwnedBy
Expand table
Category | Application | Delegated
---|---|---
Identifier | bbea195a-4c47-4a4f-bff2-cba399e11698 | b3b7fcff-b4d4-4230-bf6f-90bd91285395
DisplayText | Read and write all business scenario configurations this app creates or owns | Read and write business scenario configurations this app creates or owns
Description | Allows the app to create new business scenarios and fully manage the configurations of scenarios it owns, without a signed-in user. | Allows the app to create new business scenarios and fully manage the configurations of scenarios it owns, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#businessscenariodatareadownedby)
### BusinessScenarioData.Read.OwnedBy
Expand table
Category | Application | Delegated
---|---|---
Identifier | 6c0257fd-cffe-415b-8239-2d0d70fdaa9c | 25b265c4-5d34-4e44-952d-b567f6d3b96d
DisplayText | Read data for all business scenarios this app creates or owns | Read all data for business scenarios this app creates or owns
Description | Allows the app to read the data associated with the business scenarios it owns, without a signed-in user. | Allows the app to read all data associated with the business scenarios it owns. Data access will be attributed to the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#businessscenariodatareadwriteownedby)
### BusinessScenarioData.ReadWrite.OwnedBy
Expand table
Category | Application | Delegated
---|---|---
Identifier | f2d21f22-5d80-499e-91cc-0a8a4ce16f54 | 19932d57-2952-4c60-8634-3655c79fc527
DisplayText | Read and write data for all business scenarios this app creates or owns | Read and write all data for business scenarios this app creates or owns
Description | Allows the app to fully manage the data associated with the business scenarios it owns, without a signed-in user. | Allows the app to fully manage all data associated with the business scenarios it owns. Data access and changes will be attributed to the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#calendarsread)
### Calendars.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | 798ee544-9d2d-430c-a058-570e29e34338 | 465a38f9-76ea-45b9-9f34-9e8b0d4b0b42
DisplayText | Read calendars in all mailboxes | Read user calendars
Description | Allows the app to read events of all calendars without a signed-in user. | Allows the app to read events in user calendars.
AdminConsentRequired | Yes | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Calendars.Read_ delegated permission is available for consent in personal Microsoft accounts.
Administrators can configure [application access policy](https://learn.microsoft.com/en-us/graph/auth-limit-mailbox-access) to limit app access to _specific_ mailboxes and not to all the mailboxes in the organization, even if the app has been granted the _Calendars.Read_ application permission.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#calendarsreadshared)
### Calendars.Read.Shared
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 2b9c4092-424d-4249-948d-b43879977640
DisplayText | - | Read user and shared calendars
Description | - | Allows the app to read events in all calendars that the user can access, including delegate and shared calendars.
AdminConsentRequired | - | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Calendars.Read.Shared_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#calendarsreadbasic)
### Calendars.ReadBasic
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 662d75ba-a364-42ad-adee-f5f880ea4878
DisplayText | - | Read basic details of user calendars
Description | - | Allows the app to read events in user calendars, except for properties such as body, attachments, and extensions.
AdminConsentRequired | - | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Calendars.ReadBasic_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#calendarsreadbasicall)
### Calendars.ReadBasic.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 8ba4a692-bc31-4128-9094-475872af8a53 | -
DisplayText | Read basic details of calendars in all mailboxes | -
Description | Allows the app to read events of all calendars, except for properties such as body, attachments, and extensions, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#calendarsreadwrite)
### Calendars.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | ef54d2bf-783f-4e0f-bca1-3210c0444d99 | 1ec239c2-d7c9-4623-a91a-a9775856bb36
DisplayText | Read and write calendars in all mailboxes | Have full access to user calendars
Description | Allows the app to create, read, update, and delete events of all calendars without a signed-in user. | Allows the app to create, read, update, and delete events in user calendars.
AdminConsentRequired | Yes | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Calendars.ReadWrite_ delegated permission is available for consent in personal Microsoft accounts.
Administrators can configure [application access policy](https://learn.microsoft.com/en-us/graph/auth-limit-mailbox-access) to limit app access to specific mailboxes and not to all the mailboxes in the organization, even if the app has been granted the _Calendars.ReadWrite_ application permission.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#calendarsreadwriteshared)
### Calendars.ReadWrite.Shared
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 12466101-c9b8-439a-8589-dd09ee67e8e9
DisplayText | - | Read and write user and shared calendars
Description | - | Allows the app to create, read, update and delete events in all calendars in the organization user has permissions to access. This includes delegate and shared calendars.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#callaiinsightsreadall)
### CallAiInsights.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 792b782b-7822-4b92-8103-77e44f2f706c | e24bdaf9-83f8-468b-a144-c681ccb6caf4
DisplayText | Read all AI Insights for calls. | Read all AI Insights for calls.
Description | Allows the app to read all AI Insights for all calls, without a signed-in user. | Allows the app to read all AI Insights for calls, on behalf of the signed-in user.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#calldelegationread)
### CallDelegation.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 305b375b-00fe-48bf-81bc-e8d78954c1b6
DisplayText | - | Read delegation settings
Description | - | Allows the app to read delegation settings of you
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#calldelegationreadall)
### CallDelegation.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 5aa33e77-b893-495e-bdc5-4bf6f27d42a0 | -
DisplayText | Read delegation settings | -
Description | Allows the app to read delegation settings of you | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#calldelegationreadwrite)
### CallDelegation.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 599abf67-f72b-4b5f-98a3-cb38fe646118
DisplayText | - | Read and write delegation settings
Description | - | Allows the app to read and write delegation settings of you
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#calldelegationreadwriteall)
### CallDelegation.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 8d06abce-e69b-4122-ba60-4f901bb1db2f | -
DisplayText | Read and write delegation settings | -
Description | Allows the app to read and write delegation settings of you | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#callevents-emergencyreadall)
### CallEvents-Emergency.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | f0a35f91-2aa6-4a99-9d5a-5b6bcb66204e | -
DisplayText | Read all emergency call events | -
Description | Allows the app to read emergency call event information for all users in your organization without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#calleventsread)
### CallEvents.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 43431c03-960e-400f-87c6-8f910321dca3
DisplayText | - | Read call event data
Description | - | Allows the app to read call event information for an organization for the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#calleventsreadall)
### CallEvents.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 1abb026f-7572-49f6-9ddd-ad61cbba181e | -
DisplayText | Read all call events | -
Description | Allows the app to read call event information for all users in your organization, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#callrecord-pstncallsreadall)
### CallRecord-PstnCalls.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | a2611786-80b3-417e-adaa-707d4261a5f0 | -
DisplayText | Read PSTN and direct routing call log data | -
Description | Allows the app to read all PSTN and direct routing call log data without a signed-in user. | -
AdminConsentRequired | Yes | -
The _CallRecord-PstnCalls.Read.All_ permission grants an application access to [PSTN (calling plans)](https://learn.microsoft.com/en-us/graph/api/callrecords-callrecord-getpstncalls) and direct routing call logs. This includes potentially sensitive information about users as well as calls to and from external phone numbers.
  * Discretion should be used when granting these permissions to applications. Call records can provide insights into the operation of your business, and so can be a target for malicious actors. Only grant these permissions to applications you trust to meet your data protection requirements.
  * Make sure that you are compliant with the laws and regulations in your area regarding data protection and confidentiality of communications. Please see the [Terms of Use](https://learn.microsoft.com/en-us/legal/microsoft-apis/terms-of-use) and consult with your legal counsel for more information.


* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#callrecordingsreadall)
### CallRecordings.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | ce8fb1f1-5e1f-44a0-b102-4ec28454d0dc | 63d31bd6-bcf5-40ca-8283-ba4130a66405
DisplayText | Read all call recordings | Read all recordings of calls.
Description | Allows the app to read call recordings for all calls without a signed-in user. | Allows the app to read all recordings of calls, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#callrecordsreadall)
### CallRecords.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 45bbb07e-7321-4fd7-a8f6-3ff27e6a81c8 | -
DisplayText | Read all call records | -
Description | Allows the app to read call records for all calls and online meetings without a signed-in user. | -
AdminConsentRequired | Yes | -
The _CallRecords.Read.All_ permission grants an application privileged access to [callRecords](https://learn.microsoft.com/en-us/graph/api/resources/callrecords-callrecord) for every call and online meeting within your organization, including calls to and from external phone numbers. This includes potentially sensitive details about who participated in the call, as well as technical information pertaining to these calls and meetings that can be used for network troubleshooting, such as IP addresses, device details, and other network information.
  * Discretion should be used when granting these permissions to applications. Call records can provide insights into the operation of your business, and so can be a target for malicious actors. Only grant these permissions to applications you trust to meet your data protection requirements.
  * Make sure that you are compliant with the laws and regulations in your area regarding data protection and confidentiality of communications. Please see the [Terms of Use](https://learn.microsoft.com/en-us/legal/microsoft-apis/terms-of-use) and consult with your legal counsel for more information.


* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#callsaccessmediaall)
### Calls.AccessMedia.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | a7a681dc-756e-4909-b988-f160edc6655f | -
DisplayText | Access media streams in a call as an app | -
Description | Allows the app to get direct access to media streams in a call, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#callsinitiateall)
### Calls.Initiate.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 284383ee-7f6e-4e40-a2a8-e85dcb029101 | -
DisplayText | Initiate outgoing 1 to 1 calls from the app | -
Description | Allows the app to place outbound calls to a single user and transfer calls to users in your organization's directory, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#callsinitiategroupcallall)
### Calls.InitiateGroupCall.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 4c277553-8a09-487b-8023-29ee378d8324 | -
DisplayText | Initiate outgoing group calls from the app | -
Description | Allows the app to place outbound calls to multiple users and add participants to meetings in your organization, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#callsjoingroupcallall)
### Calls.JoinGroupCall.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | f6b49018-60ab-4f81-83bd-22caeabfed2d | -
DisplayText | Join group calls and meetings as an app | -
Description | Allows the app to join group calls and scheduled meetings in your organization, without a signed-in user. The app will be joined with the privileges of a directory user to meetings in your organization. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#callsjoingroupcallasguestall)
### Calls.JoinGroupCallAsGuest.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | fd7ccf6b-3d28-418b-9701-cd10f5cd2fd4 | -
DisplayText | Join group calls and meetings as a guest | -
Description | Allows the app to anonymously join group calls and scheduled meetings in your organization, without a signed-in user. The app will be joined as a guest to meetings in your organization. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#calltranscriptsreadall)
### CallTranscripts.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 4cd61b6d-8692-40bf-9d90-7f38db5e5fce | fbace248-5d8e-441c-85ca-cc19221a69a2
DisplayText | Read all call transcripts | Read all transcripts of calls.
Description | Allows the app to read call transcripts for all calls without a signed-in user. | Allows the app to read all transcripts of calls, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#changemanagementreadall)
### ChangeManagement.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 418dae40-2b65-4819-900c-519a04e4d278 | 4628dff5-c33e-4fde-b17a-b64e7acb1bed
DisplayText | Read Change Management items | Read Change Management items
Description | Allows to read all Change Management items. | Allows to read all Change Management items.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#channelcreate)
### Channel.Create
Expand table
Category | Application | Delegated
---|---|---
Identifier | f3a65bd4-b703-46df-8f7e-0174fea562aa | 101147cf-4178-4455-9d58-02b5c164e759
DisplayText | Create channels | Create channels
Description | Create channels in any team, without a signed-in user. | Create channels in any team, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#channeldeleteall)
### Channel.Delete.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 6a118a39-1227-45d4-af0c-ea7b40d210bc | cc83893a-e232-4723-b5af-bd0b01bcfe65
DisplayText | Delete channels | Delete channels
Description | Delete channels in any team, without a signed-in user. | Delete channels in any team, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#channelreadbasicall)
### Channel.ReadBasic.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 59a6b24b-4225-4393-8165-ebaec5f55d7a | 9d8982ae-4365-4f57-95e9-d6032a4c0b87
DisplayText | Read the names and descriptions of all channels | Read the names and descriptions of channels
Description | Read all channel names and channel descriptions, without a signed-in user. | Read channel names and channel descriptions, on behalf of the signed-in user.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#channelmemberreadall)
### ChannelMember.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 3b55498e-47ec-484f-8136-9013221c06a9 | 2eadaff8-0bce-4198-a6b9-2cfc35a30075
DisplayText | Read the members of all channels | Read the members of channels
Description | Read the members of all channels, without a signed-in user. | Read the members of channels, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#channelmemberreadwriteall)
### ChannelMember.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 35930dcf-aceb-4bd1-b99a-8ffed403c974 | 0c3e411a-ce45-4cd1-8f30-f99a3efa7b11
DisplayText | Add and remove members from all channels | Add and remove members from channels
Description | Add and remove members from all channels, without a signed-in user. Also allows changing a member's role, for example from owner to non-owner. | Add and remove members from channels, on behalf of the signed-in user. Also allows changing a member's role, for example from owner to non-owner.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#channelmessageedit)
### ChannelMessage.Edit
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 2b61aa8a-6d36-4b2f-ac7b-f29867937c53
DisplayText | - | Edit user's channel messages
Description | - | Allows an app to edit channel messages in Microsoft Teams, on behalf of the signed-in user.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#channelmessagereadall)
### ChannelMessage.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 7b2449af-6ccd-4f4d-9f78-e550c193f0d1 | 767156cb-16ae-4d10-8f8b-41b657c8c8c8
DisplayText | Read all channel messages | Read user channel messages
Description | Allows the app to read all channel messages in Microsoft Teams | Allows an app to read a channel's messages in Microsoft Teams, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#channelmessagereadwrite)
### ChannelMessage.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 5922d31f-46c8-4404-9eaf-2117e390a8a4
DisplayText | - | Read and write user channel messages
Description | - | Allows the app to read and write channel messages, on behalf of the signed-in user. This doesn't allow the app to edit the policyViolation of a channel message.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#channelmessagesend)
### ChannelMessage.Send
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | ebf0f66e-9fb1-49e4-a278-222f76911cf4
DisplayText | - | Send channel messages
Description | - | Allows an app to send channel messages in Microsoft Teams, on behalf of the signed-in user.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#channelmessageupdatepolicyviolationall)
### ChannelMessage.UpdatePolicyViolation.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 4d02b0cc-d90b-441f-8d82-4fb55c34d6bb | -
DisplayText | Flag channel messages for violating policy | -
Description | Allows the app to update Microsoft Teams channel messages by patching a set of Data Loss Prevention (DLP) policy violation properties to handle the output of DLP processing. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#channelsettingsreadall)
### ChannelSettings.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | c97b873f-f59f-49aa-8a0e-52b32d762124 | 233e0cf1-dd62-48bc-b65b-b38fe87fcf8e
DisplayText | Read the names, descriptions, and settings of all channels | Read the names, descriptions, and settings of channels
Description | Read all channel names, channel descriptions, and channel settings, without a signed-in user. | Read all channel names, channel descriptions, and channel settings, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#channelsettingsreadwriteall)
### ChannelSettings.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 243cded2-bd16-4fd6-a953-ff8177894c3d | d649fb7c-72b4-4eec-b2b4-b15acf79e378
DisplayText | Read and write the names, descriptions, and settings of all channels | Read and write the names, descriptions, and settings of channels
Description | Read and write the names, descriptions, and settings of all channels, without a signed-in user. | Read and write the names, descriptions, and settings of all channels, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#chatcreate)
### Chat.Create
Expand table
Category | Application | Delegated
---|---|---
Identifier | d9c48af6-9ad9-47ad-82c3-63757137b9af | 38826093-1258-4dea-98f0-00003be2b8d0
DisplayText | Create chats | Create chats
Description | Allows the app to create chats without a signed-in user. | Allows the app to create chats on behalf of the signed-in user.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#chatmanagedeletionall)
### Chat.ManageDeletion.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 9c7abde0-eacd-4319-bf9e-35994b1a1717 | bb64e6fc-6b6d-4752-aea0-dd922dbba588
DisplayText | Delete and recover deleted chats | Delete and recover deleted chats
Description | Allows the app to delete and recover deleted chats, without a signed-in user. | Allows the app to delete and recover deleted chats, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#chatread)
### Chat.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | f501c180-9344-439a-bca0-6cbf209fd270
DisplayText | - | Read user chat messages
Description | - | Allows an app to read 1 on 1 or group chats threads, on behalf of the signed-in user.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#chatreadall)
### Chat.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 6b7d71aa-70aa-4810-a8d9-5d9fb2830017 | -
DisplayText | Read all chat messages | -
Description | Allows the app to read all 1-to-1 or group chat messages in Microsoft Teams. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#chatreadwhereinstalled)
### Chat.Read.WhereInstalled
Expand table
Category | Application | Delegated
---|---|---
Identifier | 1c1b4c8e-3cc7-4c58-8470-9b92c9d5848b | -
DisplayText | Read all chat messages for chats where the associated Teams application is installed. | -
Description | Allows the app to read all one-to-one or group chat messages in Microsoft Teams for chats where the associated Teams application is installed, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#chatreadbasic)
### Chat.ReadBasic
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 9547fcb5-d03f-419d-9948-5928bbf71b0f
DisplayText | - | Read names and members of user chat threads
Description | - | Allows an app to read the members and descriptions of one-to-one and group chat threads, on behalf of the signed-in user.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#chatreadbasicall)
### Chat.ReadBasic.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | b2e060da-3baf-4687-9611-f4ebc0f0cbde | -
DisplayText | Read names and members of all chat threads | -
Description | Read names and members of all one-to-one and group chats in Microsoft Teams, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#chatreadbasicwhereinstalled)
### Chat.ReadBasic.WhereInstalled
Expand table
Category | Application | Delegated
---|---|---
Identifier | 818ba5bd-5b3e-4fe0-bbe6-aa4686669073 | -
DisplayText | Read names and members of all chat threads where the associated Teams application is installed. | -
Description | Allows the app to read names and members of all one-to-one and group chats in Microsoft Teams where the associated Teams application is installed, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#chatreadwrite)
### Chat.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 9ff7295e-131b-4d94-90e1-69fde507ac11
DisplayText | - | Read and write user chat messages
Description | - | Allows an app to read and write 1 on 1 or group chats threads, on behalf of the signed-in user.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#chatreadwriteall)
### Chat.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 294ce7c9-31ba-490a-ad7d-97a7d075e4ed | 7e9a077b-3711-42b9-b7cb-5fa5f3f7fea7
DisplayText | Read and write all chat messages | Read and write all chat messages
Description | Allows an app to read and write all chat messages in Microsoft Teams, without a signed-in user. | Allows an app to read and write all one-to-one and group chats in Microsoft Teams, without a signed-in user. Does not allow sending messages.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#chatreadwritewhereinstalled)
### Chat.ReadWrite.WhereInstalled
Expand table
Category | Application | Delegated
---|---|---
Identifier | ad73ce80-f3cd-40ce-b325-df12c33df713 | -
DisplayText | Read and write all chat messages for chats where the associated Teams application is installed. | -
Description | Allows the app to read and write all chat messages in Microsoft Teams for chats where the associated Teams application is installed, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#chatupdatepolicyviolationall)
### Chat.UpdatePolicyViolation.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 7e847308-e030-4183-9899-5235d7270f58 | -
DisplayText | Flag chat messages for violating policy | -
Description | Allows the app to update Microsoft Teams 1-to-1 or group chat messages by patching a set of Data Loss Prevention (DLP) policy violation properties to handle the output of DLP processing. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#chatmemberread)
### ChatMember.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | c5a9e2b1-faf6-41d4-8875-d381aa549b24
DisplayText | - | Read the members of chats
Description | - | Read the members of chats, on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#chatmemberreadall)
### ChatMember.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | a3410be2-8e48-4f32-8454-c29a7465209d | -
DisplayText | Read the members of all chats | -
Description | Read the members of all chats, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#chatmemberreadwhereinstalled)
### ChatMember.Read.WhereInstalled
Expand table
Category | Application | Delegated
---|---|---
Identifier | 93e7c9e4-54c5-4a41-b796-f2a5adaacda7 | -
DisplayText | Read the members of all chats where the associated Teams application is installed. | -
Description | Allows the app to read the members of all chats where the associated Teams application is installed, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#chatmemberreadwrite)
### ChatMember.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | dea13482-7ea6-488f-8b98-eb5bbecf033d
DisplayText | - | Add and remove members from chats
Description | - | Add and remove members from chats, on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#chatmemberreadwriteall)
### ChatMember.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 57257249-34ce-4810-a8a2-a03adf0c5693 | -
DisplayText | Add and remove members from all chats | -
Description | Add and remove members from all chats, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#chatmemberreadwritewhereinstalled)
### ChatMember.ReadWrite.WhereInstalled
Expand table
Category | Application | Delegated
---|---|---
Identifier | e32c2cd9-0124-4e44-88fc-772cd98afbdb | -
DisplayText | Add and remove members from all chats where the associated Teams application is installed. | -
Description | Allows the app to add and remove members from all chats where the associated Teams application is installed, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#chatmessageread)
### ChatMessage.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | cdcdac3a-fd45-410d-83ef-554db620e5c7
DisplayText | - | Read user chat messages
Description | - | Allows an app to read one-to-one and group chat messages, on behalf of the signed-in user.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#chatmessagereadall)
### ChatMessage.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | b9bb2381-47a4-46cd-aafb-00cb12f68504 | -
DisplayText | Read all chat messages | -
Description | Allows the app to read all one-to-one and group chats messages in Microsoft Teams, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#chatmessagesend)
### ChatMessage.Send
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 116b7235-7cc6-461e-b163-8e55691d839e
DisplayText | - | Send user chat messages
Description | - | Allows an app to send one-to-one and group chat messages in Microsoft Teams, on behalf of the signed-in user.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#cloudapp-discoveryreadall)
### CloudApp-Discovery.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 64a59178-dad3-4673-89db-84fdcd622fec | ad46d60e-1027-4b75-af88-7c14ccf43a19
DisplayText | Read all discovered cloud applications data | Read discovered cloud applications data
Description | Allows the app to read all details of discovered cloud apps in the organization, without a signed-in user. | Allows the app to read details of discovered cloud apps in the organization, on behalf of the signed in user.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#cloudpcreadall)
### CloudPC.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | a9e09520-8ed4-4cde-838e-4fdea192c227 | 5252ec4e-fd40-4d92-8c68-89dd1d3c6110
DisplayText | Read Cloud PCs | Read Cloud PCs
Description | Allows the app to read the properties of Cloud PCs, without a signed-in user. | Allows the app to read the properties of Cloud PCs on behalf of the signed-in user.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#cloudpcreadwriteall)
### CloudPC.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 3b4349e1-8cf5-45a3-95b7-69d1751d3e6a | 9d77138f-f0e2-47ba-ab33-cd246c8b79d1
DisplayText | Read and write Cloud PCs | Read and write Cloud PCs
Description | Allows the app to read and write the properties of Cloud PCs, without a signed-in user. | Allows the app to read and write the properties of Cloud PCs on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#communityreadall)
### Community.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 407f0cce-3212-441f-9f55-3bc91342cf86 | 12ae2e92-14b5-47b2-babb-4e890bbedc0a
DisplayText | Read all Viva Engage communities | Read all Viva Engage communities
Description | Allows the app to list Viva Engage communities, and to read their properties without a signed-in user. | Allows the app to list Viva Engage communities, and to read their properties on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#communityreadwriteall)
### Community.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 35d59e32-eab5-4553-9345-abb62b4c703c | 9e69467d-e0e2-402b-a926-3d796990197f
DisplayText | Read and write all Viva Engage communities | Read and write all Viva Engage communities
Description | Allows the app to create Viva Engage communities, read all community properties, update community properties, and delete communities without a signed-in user. | Allows the app to create Viva Engage communities and read all community properties on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#configurationmonitoringreadall)
### ConfigurationMonitoring.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | aca929ec-9830-44dc-bda1-85cf938aaa95 | c645bb69-adc4-4242-b620-02e635f03bf6
DisplayText | Read all Configuration Monitoring entities | Read all Configuration Monitoring entities
Description | Allows the app to read all Configuration Monitoring entities, without a signed-in user. | Allows the app to read all Configuration Monitoring entities on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#configurationmonitoringreadwriteall)
### ConfigurationMonitoring.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | cfa85bfb-2ee8-4e13-8e7f-489e57a015a1 | 54505ce9-e719-41f7-a7cc-dbe114e1d811
DisplayText | Read and write all Configuration Monitoring entities | Read and write all Configuration Monitoring entities
Description | Allows the app to read and write all Configuration Monitoring entities, without a signed-in user. | Allows the app to read and write all Configuration Monitoring entities on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#consentrequestcreate)
### ConsentRequest.Create
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | f2143d35-9b4b-480d-951c-d083e69eeb2c
DisplayText | - | Create consent requests
Description | - | Allows the app to read create consent requests on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#consentrequestread)
### ConsentRequest.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 5942b2f6-5a7b-40af-aa37-4b6ea5447506
DisplayText | - | Read consent requests created by the user
Description | - | Allows the app to read consent requests and approvals created by the signed-in user, on behalf of the signed-in user.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#consentrequestreadall)
### ConsentRequest.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 1260ad83-98fb-4785-abbb-d6cc1806fd41 | f3bfad56-966e-4590-a536-82ecf548ac1e
DisplayText | Read all consent requests | Read consent requests
Description | Allows the app to read consent requests and approvals without a signed-in user. | Allows the app to read consent requests and approvals on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#consentrequestreadapproveall)
### ConsentRequest.ReadApprove.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | e694a3a1-7878-46d8-8c29-3d195f6589f4
DisplayText | - | Read and approve consent requests
Description | - | Allows the app to read and approve consent requests on behalf of the signed in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#consentrequestreadwriteall)
### ConsentRequest.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 9f1b81a7-0223-4428-bfa4-0bcb5535f27d | 497d9dfa-3bd1-481a-baab-90895e54568c
DisplayText | Read and write all consent requests | Read and write consent requests
Description | Allows the app to read app consent requests and approvals, and deny or approve those requests without a signed-in user. | Allows the app to read app consent requests and approvals, and deny or approve those requests on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#contacts-onpremisessyncbehaviorreadwriteall)
### Contacts-OnPremisesSyncBehavior.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | c8948c23-e66b-42db-83fd-770b71ab78d2 | 1e4c6c41-0803-4f52-85ef-0a5d63ad8670
DisplayText | Read and update the on-premises sync behavior of contacts | Read and update the on-premises sync behavior of contacts
Description | Allows the app to update the on-premises sync behavior of all contacts in all mailboxes without a signed-in user. | Allows the app to read and update the on-premises sync behavior of contacts a user has permissions to, including their own and shared contacts.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#contactsread)
### Contacts.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | 089fe4d0-434a-44c5-8827-41ba8a0b17f5 | ff74d97f-43af-4b68-9f2a-b77ee6968c5d
DisplayText | Read contacts in all mailboxes | Read user contacts
Description | Allows the app to read all contacts in all mailboxes without a signed-in user. | Allows the app to read user contacts.
AdminConsentRequired | Yes | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Contacts.Read_ delegated permission is available for consent in personal Microsoft accounts.
Administrators can configure [application access policy](https://learn.microsoft.com/en-us/graph/auth-limit-mailbox-access) to limit app access to _specific_ mailboxes and not to all the mailboxes in the organization, even if the app has been granted the _Contacts.Read_ application permission.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#contactsreadshared)
### Contacts.Read.Shared
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 242b9d9e-ed24-4d09-9a52-f43769beb9d4
DisplayText | - | Read user and shared contacts
Description | - | Allows the app to read contacts a user has permissions to access, including their own and shared contacts.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#contactsreadwrite)
### Contacts.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | 6918b873-d17a-4dc1-b314-35f528134491 | d56682ec-c09e-4743-aaf4-1a3aac4caa21
DisplayText | Read and write contacts in all mailboxes | Have full access to user contacts
Description | Allows the app to create, read, update, and delete all contacts in all mailboxes without a signed-in user. | Allows the app to create, read, update, and delete user contacts.
AdminConsentRequired | Yes | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Contacts.ReadWrite_ delegated permission is available for consent in personal Microsoft accounts.
Administrators can configure [application access policy](https://learn.microsoft.com/en-us/graph/auth-limit-mailbox-access) to limit app access to specific mailboxes and not to all the mailboxes in the organization, even if the app has been granted the _Contacts.ReadWrite_ application permission.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#contactsreadwriteshared)
### Contacts.ReadWrite.Shared
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | afb6c84b-06be-49af-80bb-8f3f77004eab
DisplayText | - | Read and write user and shared contacts
Description | - | Allows the app to create, read, update, and delete contacts a user has permissions to, including their own and shared contacts.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#contentprocessall)
### Content.Process.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 5ad511bf-571c-4ef6-8c3c-85b94b85df98 | 7e2467d1-f874-46bb-828e-24cb06b29d3f
DisplayText | Process content for data security, governance and compliance | Process content for data security, governance and compliance
Description | Allows the app to process and evaluate content for data security, governance and compliance outcomes at tenant scope. | Allows the app to process and evaluate content for data security, governance and compliance outcomes at tenant scope.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#contentprocessuser)
### Content.Process.User
Expand table
Category | Application | Delegated
---|---|---
Identifier | 24ceb246-ad29-4680-90b4-3e91ffad15eb | 1d787a13-f750-4ad6-875a-fcbd2725596b
DisplayText | Process content for data security, governance and compliance | Process content for data security, governance and compliance
Description | Allows the app to process and evaluate content for data security, governance and compliance outcomes for a user. | Allows the app to process and evaluate content for data security, governance and compliance outcomes for a user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#contentactivityread)
### ContentActivity.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | 368425e7-6954-4f5a-9d92-90b75bd580c9 | 62c55b2f-a2b1-4312-8385-be57afd901b4
DisplayText | Read contents activity audit log from the audit store. | Read contents activity audit log from the audit store.
Description | Read contents activity audit log from the audit store. | Read contents activity audit log from the audit store.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#contentactivitywrite)
### ContentActivity.Write
Expand table
Category | Application | Delegated
---|---|---
Identifier | 2932e07a-3c29-44e4-bb36-6d0fc176387f | 948caae6-152a-48cd-a746-4844af30e8e9
DisplayText | Upload content activity audit logs to the audit store. | Upload contents activity audit logs to the audit store.
Description | Allows the application to upload bulk contents activity audit logs to the audit store. | Allows the application to upload bulk contents activity audit logs to the audit store.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#copilotconversationdelete)
### CopilotConversation.Delete
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | ed510a02-ac32-45f9-93e6-04864f7f7e47
DisplayText | - | Delete Microsoft 365 Copilot conversations
Description | - | Allows the app to delete Microsoft 365 Copilot conversations on behalf of the signed-in user.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#copilotpackagesreadall)
### CopilotPackages.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 72f0655d-6228-4ddc-8e1b-164973b9213b | a2dcfcb9-cbe8-4d42-812d-952e55cf7f3f
DisplayText | Read all packages information | Read all packages information
Description | Allows the app to read packages information without a signed-in user. | Allows the user to read the packages information
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#copilotpackagesreadwriteall)
### CopilotPackages.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | ed31732f-9495-47ed-ba3b-4ed0948c1c64 | e9c5fd18-ac15-43dd-9f5c-6f9611dd5604
DisplayText | Read and update all packages information | Read and update all packages information
Description | Allows the app to read and update packages information without a signed-in user. | Allows the user to read and update the packages information
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#copilotsettings-limitedmoderead)
### CopilotSettings-LimitedMode.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | aeb2982d-632d-4155-b533-18756ab6fdd8
DisplayText | - | Read organization-wide copilot limited mode setting
Description | - | Allows the app to read organization-wide copilot limited mode setting on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#copilotsettings-limitedmodereadwrite)
### CopilotSettings-LimitedMode.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 4704e5b2-0ada-4aa0-b18c-00ad7525bc06
DisplayText | - | Read and write organization-wide copilot limited mode setting
Description | - | Allows the app to read and write organization-wide copilot limited mode setting on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#crosstenantinformationreadbasicall)
### CrossTenantInformation.ReadBasic.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | cac88765-0581-4025-9725-5ebc13f729ee | 81594d25-e88e-49cf-ac8c-fecbff49f994
DisplayText | Read cross-tenant basic information | Read cross-tenant basic information
Description | Allows the application to obtain basic tenant information about another target tenant within the Azure AD ecosystem without a signed-in user. | Allows the application to obtain basic tenant information about another target tenant within the Azure AD ecosystem on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#crosstenantuserprofilesharingread)
### CrossTenantUserProfileSharing.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | cb1ba48f-d22b-4325-a07f-74135a62ee41
DisplayText | - | Read shared cross-tenant user profile and export data
Description | - | Allows the application to list and query user profile information associated with the current tenant on behalf of the signed-in user. It also permits the application to export external user data (e.g. customer content or system-generated logs), associated with the current tenant on behalf of the signed-in user.
AdminConsentRequired | - | Yes
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _CrossTenantUserProfileSharing.Read_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#crosstenantuserprofilesharingreadall)
### CrossTenantUserProfileSharing.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 8b919d44-6192-4f3d-8a3b-f86f8069ae3c | 759dcd16-3c90-463c-937e-abf89f991c18
DisplayText | Read all shared cross-tenant user profiles and export their data | Read all shared cross-tenant user profiles and export their data
Description | Allows the application to list and query any shared user profile information associated with the current tenant without a signed-in user. It also permits the application to export external user data (e.g. customer content or system-generated logs), for any user associated with the current tenant without a signed-in user. | Allows the application to list and query any shared user profile information associated with the current tenant on behalf of the signed-in user. It also permits the application to export external user data (e.g. customer content or system-generated logs), for any user associated with the current tenant on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _CrossTenantUserProfileSharing.Read.All_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#crosstenantuserprofilesharingreadwrite)
### CrossTenantUserProfileSharing.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | eed0129d-dc60-4f30-8641-daf337a39ffd
DisplayText | - | Read shared cross-tenant user profile and export or delete data
Description | - | Allows the application to list and query user profile information associated with the current tenant on behalf of the signed-in user. It also permits the application to export and remove external user data (e.g. customer content or system-generated logs), associated with the current tenant on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#crosstenantuserprofilesharingreadwriteall)
### CrossTenantUserProfileSharing.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 306785c5-c09b-4ba0-a4ee-023f3da165cb | 64dfa325-cbf8-48e3-938d-51224a0cac01
DisplayText | Read all shared cross-tenant user profiles and export or delete their data | Read all shared cross-tenant user profiles and export or delete their data
Description | Allows the application to list and query any shared user profile information associated with the current tenant without a signed-in user. It also permits the application to export and remove external user data (e.g. customer content or system-generated logs), for any user associated with the current tenant without a signed-in user. | Allows the application to list and query any shared user profile information associated with the current tenant on behalf of the signed-in user. It also permits the application to export and remove external user data (e.g. customer content or system-generated logs), for any user associated with the current tenant on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#customauthenticationextensionreadall)
### CustomAuthenticationExtension.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 88bb2658-5d9e-454f-aacd-a3933e079526 | b2052569-c98c-4f36-a5fb-43e5c111e6d0
DisplayText | Read all custom authentication extensions | Read your organization's custom authentication extensions
Description | Allows the app to read your organization's custom authentication extensions without a signed-in user. | Allows the app to read your organization's custom authentication extensions on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#customauthenticationextensionreadwriteall)
### CustomAuthenticationExtension.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | c2667967-7050-4e7e-b059-4cbbb3811d03 | 8dfcf82f-15d0-43b3-bc78-a958a13a5792
DisplayText | Read and write all custom authentication extensions | Read and write your organization's custom authentication extensions
Description | Allows the app to read or write your organization's custom authentication extensions without a signed-in user. | Allows the app to read or write your organization's custom authentication extensions on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#customauthenticationextensionreceivepayload)
### CustomAuthenticationExtension.Receive.Payload
Expand table
Category | Application | Delegated
---|---|---
Identifier | 214e810f-fda8-4fd7-a475-29461495eb00 | -
DisplayText | Receive custom authentication extension HTTP requests | -
Description | Allows custom authentication extensions associated with the app to receive HTTP requests triggered by an authentication event. The request can include information about a user, client and resource service principals, and other information about the authentication. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#customdetectionreadall)
### CustomDetection.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 673a007a-9e0f-4c97-b066-3c0164486909 | b13ff42e-f321-4d7d-a462-141c46a1b832
DisplayText | Read all custom detection rules | Read custom detection rules
Description | Allows the app to read custom detection rules without a signed-in user. | Allows the app to read custom detection rules on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#customdetectionreadwriteall)
### CustomDetection.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | e0fd9c8d-a12e-4cc9-9827-20c8c3cd6fb8 | c34088fb-0649-4714-af0b-bcbfec155897
DisplayText | Read and write all custom detection rules | Read and write custom detection rules
Description | Allows the app to read and write custom detection rules without a signed-in user. | Allows the app to read and write custom detection rules on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#customsecattributeassignmentreadall)
### CustomSecAttributeAssignment.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 3b37c5a4-1226-493d-bec3-5d6c6b866f3f | b46ffa80-fe3d-4822-9a1a-c200932d54d0
DisplayText | Read custom security attribute assignments | Read custom security attribute assignments
Description | Allows the app to read custom security attribute assignments for all principals in the tenant without a signed in user. | Allows the app to read custom security attribute assignments for all principals in the tenant on behalf of a signed in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#customsecattributeassignmentreadwriteall)
### CustomSecAttributeAssignment.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | de89b5e4-5b8f-48eb-8925-29c2b33bd8bd | ca46335e-8453-47cd-a001-8459884efeae
DisplayText | Read and write custom security attribute assignments | Read and write custom security attribute assignments
Description | Allows the app to read and write custom security attribute assignments for all principals in the tenant without a signed in user. | Allows the app to read and write custom security attribute assignments for all principals in the tenant on behalf of a signed in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#customsecattributeauditlogsreadall)
### CustomSecAttributeAuditLogs.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 2a4f026d-e829-4e84-bdbf-d981a2703059 | 1fcdeaab-b519-44dd-bffc-ed1fd15a24e0
DisplayText | Read all custom security attribute audit logs | Read custom security attribute audit logs
Description | Allows the app to read all audit logs for events that contain information about custom security attributes, without a signed-in user. | Allows the app to read audit logs for events that contain information about custom security attributes, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#customsecattributedefinitionreadall)
### CustomSecAttributeDefinition.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | b185aa14-d8d2-42c1-a685-0f5596613624 | ce026878-a0ff-4745-a728-d4fedd086c07
DisplayText | Read custom security attribute definitions | Read custom security attribute definitions
Description | Allows the app to read custom security attribute definitions for the tenant without a signed in user. | Allows the app to read custom security attribute definitions for the tenant on behalf of a signed in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#customsecattributedefinitionreadwriteall)
### CustomSecAttributeDefinition.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 12338004-21f4-4896-bf5e-b75dfaf1016d | 8b0160d4-5743-482b-bb27-efc0a485ca4a
DisplayText | Read and write custom security attribute definitions | Read and write custom security attribute definitions
Description | Allows the app to read and write custom security attribute definitions for the tenant without a signed in user. | Allows the app to read and write custom security attribute definitions for the tenant on behalf of a signed in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#customsecattributeprovisioningreadall)
### CustomSecAttributeProvisioning.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 9fd1f8bf-a443-4df6-bc2a-5d00c5ec7828 | 9ddd870d-077c-49e7-b3e3-6b3012a8a880
DisplayText | Read the provisioning configuration of all active custom security attributes | Read the provisioning configuration of all active custom security attributes
Description | Allows the app to read the provisioning configuration of all active custom security attributes without a signed-in user. | Allows the app to read the provisioning configuration of all active custom security attributes on behalf of a signed in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#customsecattributeprovisioningreadwriteall)
### CustomSecAttributeProvisioning.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 1db69e9c-8d0a-498d-a5df-11fd0b68ceab | 1140d9e4-6776-433e-a9e4-b9831adbb2e0
DisplayText | Read and edit the provisioning configuration of all active custom security attributes | Read and edit the provisioning configuration of all active custom security attributes
Description | Allows the app to read and edit the provisioning configuration of all active custom security attributes without a signed-in user. | Allows the app to read and edit the provisioning configuration of all active custom security attributes on behalf of a signed in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#customtagsreadall)
### CustomTags.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | ab8a5872-7c88-47a6-8141-7becce939190 | de6ea87d-10bd-467c-8682-d525a0c61b89
DisplayText | Read all custom tags data | Read all custom tags data
Description | Read custom tags data, without a signed-in user | Read custom tags data on behalf of the signed-in user
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#customtagsreadwriteall)
### CustomTags.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 2f503208-e509-4e39-974c-8cc16e5785c9 | 2f1bbe0a-f34b-4efb-9edb-8db8dcb50eca
DisplayText | Read and write custom tags data | Read and write custom tags data
Description | Read and write custom tags data, without a signed-in user | Read and write custom tags data on behalf of the signed-in user
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#delegatedadminrelationshipreadall)
### DelegatedAdminRelationship.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | f6e9e124-4586-492f-adc0-c6f96e4823fd | 0c0064ea-477b-4130-82a5-4c2cc4ff68aa
DisplayText | Read Delegated Admin relationships with customers | Read Delegated Admin relationships with customers
Description | Allows the app to read details of delegated admin relationships with customers like access details (that includes roles) and the duration as well as specific role assignments to security groups without a signed-in user. | Allows the app to read details of delegated admin relationships with customers like access details (that includes roles) and the duration as well as specific role assignments to security groups on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#delegatedadminrelationshipreadwriteall)
### DelegatedAdminRelationship.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | cc13eba4-8cd8-44c6-b4d4-f93237adce58 | 885f682f-a990-4bad-a642-36736a74b0c7
DisplayText | Manage Delegated Admin relationships with customers | Manage Delegated Admin relationships with customers
Description | Allows the app to manage (create-update-terminate) Delegated Admin relationships with customers and role assignments to security groups for active Delegated Admin relationships without a signed-in user. | Allows the app to manage (create-update-terminate) Delegated Admin relationships with customers as well as role assignments to security groups for active Delegated Admin relationships on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#delegatedpermissiongrantreadall)
### DelegatedPermissionGrant.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 81b4724a-58aa-41c1-8a55-84ef97466587 | a197cdc4-a8e8-4d49-9d35-4ca7c83887b4
DisplayText | Read all delegated permission grants | Read delegated permission grants
Description | Allows the app to read all delegated permission grants, without a signed-in user. | Allows the app to read delegated permission grants, on behalf of the signed in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#delegatedpermissiongrantreadwriteall)
### DelegatedPermissionGrant.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 8e8e4742-1d95-4f68-9d56-6ee75648c72a | 41ce6ca6-6826-4807-84f1-1c82854f7ee5
DisplayText | Manage all delegated permission grants | Manage all delegated permission grants
Description | Allows the app to manage permission grants for delegated permissions exposed by any API (including Microsoft Graph), without a signed-in user. | Allows the app to manage permission grants for delegated permissions exposed by any API (including Microsoft Graph), on behalf of the signed in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#devicecommand)
### Device.Command
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | bac3b9c2-b516-4ef4-bd3b-c2ef73d8d804
DisplayText | - | Communicate with user devices
Description | - | Allows the app to launch another app or communicate with another app on a user's device on behalf of the signed-in user.
AdminConsentRequired | - | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Device.Command_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#devicecreatefromownedtemplate)
### Device.CreateFromOwnedTemplate
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | edc92e89-a987-48a9-911a-a7b1967dd7b1
DisplayText | - | Create devices based on owned device templates
Description | - | Allows the app to create device objects based on device templates owned by the signed-in user, on behalf of the signed in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#deviceread)
### Device.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 11d4cd79-5ba5-460f-803f-e22c8ab85ccd
DisplayText | - | Read user devices
Description | - | Allows the app to read a user's list of devices on behalf of the signed-in user.
AdminConsentRequired | - | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Device.Read_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#devicereadall)
### Device.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 7438b122-aefc-4978-80ed-43db9fcc7715 | 951183d1-1a61-466f-a6d1-1fde911bfd95
DisplayText | Read all devices | Read all devices
Description | Allows the app to read your organization's devices' configuration information without a signed-in user. | Allows the app to read your organization's devices' configuration information on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Device.Read.All_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#devicereadwriteall)
### Device.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 1138cb37-bd11-4084-a2b7-9f71582aeddb | -
DisplayText | Read and write devices | -
Description | Allows the app to read and write all device properties without a signed in user. Does not allow device creation, device deletion or update of device alternative security identifiers. | -
AdminConsentRequired | Yes | -
Before December 3rd, 2020, when the application permission _Device.ReadWrite.All_ was granted, the [Device Managers](https://learn.microsoft.com/en-us/azure/active-directory/users-groups-roles/directory-assign-admin-roles#deprecated-roles) directory role was also assigned to the app's service principal. This directory role assignment is not removed automatically when the associated application permissions is revoked. To ensure that an application's access to read or write to devices is removed, customers must also remove any related directory roles that were granted to the application.
A service update disabling this behavior began rolling out on December 3rd, 2020. Deployment to all customers completed on January 11th, 2021. Directory roles are no longer automatically assigned when application permissions are granted.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#devicelocalcredentialreadall)
### DeviceLocalCredential.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 884b599e-4d48-43a5-ba94-15c414d00588 | 280b3b69-0437-44b1-bc20-3b2fca1ee3e9
DisplayText | Read device local credential passwords | Read device local credential passwords
Description | Allows the app to read device local credential properties including passwords, without a signed-in user. | Allows the app to read device local credential properties including passwords, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#devicelocalcredentialreadbasicall)
### DeviceLocalCredential.ReadBasic.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | db51be59-e728-414b-b800-e0f010df1a79 | 9917900e-410b-4d15-846e-42a357488545
DisplayText | Read device local credential properties | Read device local credential properties
Description | Allows the app to read device local credential properties excluding passwords, without a signed-in user. | Allows the app to read device local credential properties excluding passwords, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#devicemanagementappsreadall)
### DeviceManagementApps.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 7a6ee1e7-141e-4cec-ae74-d9db155731ff | 4edf5f54-4666-44af-9de9-0144fb4b6e8c
DisplayText | Read Microsoft Intune apps | Read Microsoft Intune apps
Description | Allows the app to read the properties, group assignments and status of apps, app configurations and app protection policies managed by Microsoft Intune, without a signed-in user. | Allows the app to read the properties, group assignments and status of apps, app configurations and app protection policies managed by Microsoft Intune.
AdminConsentRequired | Yes | Yes
Using the Microsoft Graph APIs to configure Intune controls and policies still requires that the Intune service is [correctly licensed](https://learn.microsoft.com/en-us/mem/intune/fundamentals/licenses) by the customer.
These permissions aren't supported for personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#devicemanagementappsreadwriteall)
### DeviceManagementApps.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 78145de6-330d-4800-a6ce-494ff2d33d07 | 7b3f05d5-f68c-4b8d-8c59-a2ecd12f24af
DisplayText | Read and write Microsoft Intune apps | Read and write Microsoft Intune apps
Description | Allows the app to read and write the properties, group assignments and status of apps, app configurations and app protection policies managed by Microsoft Intune, without a signed-in user. | Allows the app to read and write the properties, group assignments and status of apps, app configurations and app protection policies managed by Microsoft Intune.
AdminConsentRequired | Yes | Yes
Using the Microsoft Graph APIs to configure Intune controls and policies still requires that the Intune service is [correctly licensed](https://learn.microsoft.com/en-us/mem/intune/fundamentals/licenses) by the customer.
These permissions aren't supported for personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#devicemanagementcloudcareadall)
### DeviceManagementCloudCA.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 315b6e8c-d92a-4691-919d-00ce76d1344a | ac5c8443-d999-471f-9247-ce92cf5c5560
DisplayText | Read Microsoft Cloud PKI objects | Read Microsoft Cloud PKI objects
Description | Allows the app to read certification authority information without a signed-in user. | Allows the app to read certification authority information on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#devicemanagementcloudcareadwriteall)
### DeviceManagementCloudCA.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | f15eb2ba-ef8a-4f70-991d-da5d045154e2 | 93028c58-65aa-48db-a706-1fe4ada325ec
DisplayText | Read and write Microsoft Cloud PKI objects | Read and write Microsoft Cloud PKI objects
Description | Allows the app to read and write certification authority information without a signed-in user. | Allows the app to read and write certification authority information on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#devicemanagementconfigurationreadall)
### DeviceManagementConfiguration.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | dc377aa6-52d8-4e23-b271-2a7ae04cedf3 | f1493658-876a-4c87-8fa7-edb559b3476a
DisplayText | Read Microsoft Intune device configuration and policies | Read Microsoft Intune Device Configuration and Policies
Description | Allows the app to read properties of Microsoft Intune-managed device configuration and device compliance policies and their assignment to groups, without a signed-in user. | Allows the app to read properties of Microsoft Intune-managed device configuration and device compliance policies and their assignment to groups.
AdminConsentRequired | Yes | Yes
Using the Microsoft Graph APIs to configure Intune controls and policies still requires that the Intune service is [correctly licensed](https://learn.microsoft.com/en-us/mem/intune/fundamentals/licenses) by the customer.
These permissions aren't supported for personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#devicemanagementconfigurationreadwriteall)
### DeviceManagementConfiguration.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 9241abd9-d0e6-425a-bd4f-47ba86e767a4 | 0883f392-0a7a-443d-8c76-16a6d39c7b63
DisplayText | Read and write Microsoft Intune device configuration and policies | Read and write Microsoft Intune Device Configuration and Policies
Description | Allows the app to read and write properties of Microsoft Intune-managed device configuration and device compliance policies and their assignment to groups, without a signed-in user. | Allows the app to read and write properties of Microsoft Intune-managed device configuration and device compliance policies and their assignment to groups.
AdminConsentRequired | Yes | Yes
Using the Microsoft Graph APIs to configure Intune controls and policies still requires that the Intune service is [correctly licensed](https://learn.microsoft.com/en-us/mem/intune/fundamentals/licenses) by the customer.
These permissions aren't supported for personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#devicemanagementmanageddevicesprivilegedoperationsall)
### DeviceManagementManagedDevices.PrivilegedOperations.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 5b07b0dd-2377-4e44-a38d-703f09a0dc3c | 3404d2bf-2b13-457e-a330-c24615765193
DisplayText | Perform user-impacting remote actions on Microsoft Intune devices | Perform user-impacting remote actions on Microsoft Intune devices
Description | Allows the app to perform remote high impact actions such as wiping the device or resetting the passcode on devices managed by Microsoft Intune, without a signed-in user. | Allows the app to perform remote high impact actions such as wiping the device or resetting the passcode on devices managed by Microsoft Intune.
AdminConsentRequired | Yes | Yes
Using the Microsoft Graph APIs to configure Intune controls and policies still requires that the Intune service is [correctly licensed](https://learn.microsoft.com/en-us/mem/intune/fundamentals/licenses) by the customer.
These permissions aren't supported for personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#devicemanagementmanageddevicesreadall)
### DeviceManagementManagedDevices.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 2f51be20-0bb4-4fed-bf7b-db946066c75e | 314874da-47d6-4978-88dc-cf0d37f0bb82
DisplayText | Read Microsoft Intune devices | Read Microsoft Intune devices
Description | Allows the app to read the properties of devices managed by Microsoft Intune, without a signed-in user. | Allows the app to read the properties of devices managed by Microsoft Intune.
AdminConsentRequired | Yes | Yes
Using the Microsoft Graph APIs to configure Intune controls and policies still requires that the Intune service is [correctly licensed](https://learn.microsoft.com/en-us/mem/intune/fundamentals/licenses) by the customer.
These permissions aren't supported for personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#devicemanagementmanageddevicesreadwriteall)
### DeviceManagementManagedDevices.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 243333ab-4d21-40cb-a475-36241daa0842 | 44642bfe-8385-4adc-8fc6-fe3cb2c375c3
DisplayText | Read and write Microsoft Intune devices | Read and write Microsoft Intune devices
Description | Allows the app to read and write the properties of devices managed by Microsoft Intune, without a signed-in user. Does not allow high impact operations such as remote wipe and password reset on the device's owner | Allows the app to read and write the properties of devices managed by Microsoft Intune. Does not allow high impact operations such as remote wipe and password reset on the device's owner.
AdminConsentRequired | Yes | Yes
Using the Microsoft Graph APIs to configure Intune controls and policies still requires that the Intune service is [correctly licensed](https://learn.microsoft.com/en-us/mem/intune/fundamentals/licenses) by the customer.
These permissions aren't supported for personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#devicemanagementrbacreadall)
### DeviceManagementRBAC.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 58ca0d9a-1575-47e1-a3cb-007ef2e4583b | 49f0cc30-024c-4dfd-ab3e-82e137ee5431
DisplayText | Read Microsoft Intune RBAC settings | Read Microsoft Intune RBAC settings
Description | Allows the app to read the properties relating to the Microsoft Intune Role-Based Access Control (RBAC) settings, without a signed-in user. | Allows the app to read the properties relating to the Microsoft Intune Role-Based Access Control (RBAC) settings.
AdminConsentRequired | Yes | Yes
Using the Microsoft Graph APIs to configure Intune controls and policies still requires that the Intune service is [correctly licensed](https://learn.microsoft.com/en-us/mem/intune/fundamentals/licenses) by the customer.
These permissions aren't supported for personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#devicemanagementrbacreadwriteall)
### DeviceManagementRBAC.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | e330c4f0-4170-414e-a55a-2f022ec2b57b | 0c5e8a55-87a6-4556-93ab-adc52c4d862d
DisplayText | Read and write Microsoft Intune RBAC settings | Read and write Microsoft Intune RBAC settings
Description | Allows the app to read and write the properties relating to the Microsoft Intune Role-Based Access Control (RBAC) settings, without a signed-in user. | Allows the app to read and write the properties relating to the Microsoft Intune Role-Based Access Control (RBAC) settings.
AdminConsentRequired | Yes | Yes
Using the Microsoft Graph APIs to configure Intune controls and policies still requires that the Intune service is [correctly licensed](https://learn.microsoft.com/en-us/mem/intune/fundamentals/licenses) by the customer.
These permissions aren't supported for personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#devicemanagementscriptsreadall)
### DeviceManagementScripts.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | c7a5be92-2b3d-4540-8a67-c96dcaae8b43 | d32381d8-ee89-4220-9c83-b672aa68d404
DisplayText | Read Microsoft Intune Scripts | Read Microsoft Intune Scripts
Description | Allows the app to read Microsoft Intune device compliance scripts, device management scripts, device shell scripts, device custom attribute shell scripts and device health scripts, without a signed-in user. | Allows the app to read Microsoft Intune device compliance scripts, device management scripts, device shell scripts, device custom attribute shell scripts and device health scripts on behalf of the signed in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#devicemanagementscriptsreadwriteall)
### DeviceManagementScripts.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 9255e99d-faf5-445e-bbf7-cb71482737c4 | 8b9d79d0-ad75-4566-8619-f7500ecfcebe
DisplayText | Read and write Microsoft Intune Scripts | Read and write Microsoft Intune Scripts
Description | Allows the app to read and write Microsoft Intune device compliance scripts, device management scripts, device shell scripts, device custom attribute shell scripts and device health scripts, without a signed-in user. | Allows the app to read and write Microsoft Intune device compliance scripts, device management scripts, device shell scripts, device custom attribute shell scripts and device health scripts on behalf of the signed in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#devicemanagementserviceconfigreadall)
### DeviceManagementServiceConfig.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 06a5fe6d-c49d-46a7-b082-56b1b14103c7 | 8696daa5-bce5-4b2e-83f9-51b6defc4e1e
DisplayText | Read Microsoft Intune configuration | Read Microsoft Intune configuration
Description | Allows the app to read Microsoft Intune service properties including device enrollment and third party service connection configuration, without a signed-in user. | Allows the app to read Microsoft Intune service properties including device enrollment and third party service connection configuration.
AdminConsentRequired | Yes | Yes
Using the Microsoft Graph APIs to configure Intune controls and policies still requires that the Intune service is [correctly licensed](https://learn.microsoft.com/en-us/mem/intune/fundamentals/licenses) by the customer.
These permissions aren't supported for personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#devicemanagementserviceconfigreadwriteall)
### DeviceManagementServiceConfig.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 5ac13192-7ace-4fcf-b828-1a26f28068ee | 662ed50a-ac44-4eef-ad86-62eed9be2a29
DisplayText | Read and write Microsoft Intune configuration | Read and write Microsoft Intune configuration
Description | Allows the app to read and write Microsoft Intune service properties including device enrollment and third party service connection configuration, without a signed-in user. | Allows the app to read and write Microsoft Intune service properties including device enrollment and third party service connection configuration.
AdminConsentRequired | Yes | Yes
Using the Microsoft Graph APIs to configure Intune controls and policies still requires that the Intune service is [correctly licensed](https://learn.microsoft.com/en-us/mem/intune/fundamentals/licenses) by the customer.
These permissions aren't supported for personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#devicetemplatecreate)
### DeviceTemplate.Create
Expand table
Category | Application | Delegated
---|---|---
Identifier | abf6441f-0772-4932-96e7-0191478dd73a | 0b1717ff-3e42-4a73-8c29-e6b2e1093960
DisplayText | Create device template | Create device templates
Description | Allows the app to create device templates. The app is marked as owner of the created device template. As a member of owners, the app will be allowed to manage devices created from the template. | Allows the app to create device templates on behalf of the signed in user. The user is marked as owners of the created device template. As a member of owners, the user will be allowed to manage devices created from the template.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#devicetemplatereadall)
### DeviceTemplate.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | dd9febb5-0c6d-419f-b256-3afe12c6adeb | 2bcae0b0-aa93-48e4-a9e4-855482dffdcd
DisplayText | Read all device templates | Read all device templates
Description | Allows the app to read all device templates, without a signed-in user. | Allows the app to read all device templates, on behalf of the signed in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#devicetemplatereadwriteall)
### DeviceTemplate.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 9fadb66e-6421-4744-aede-4ab6fb98a884 | 2d372e98-f1ae-406c-a157-2ea83f6f5e4a
DisplayText | Read and write all device templates | Read and write all device templates
Description | Allows the app to create, read, update and delete any device template, without a signed-in user. It also allows the app to add or remove owners on any device template. | Allows the app to create, read, update and delete the device template, on behalf of the signed in user. It also allows the app to add or remove owners on any device template.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#directoryaccessasuserall)
### Directory.AccessAsUser.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 0e263e50-5827-48a4-b97c-d940288653c7
DisplayText | - | Access directory as the signed in user
Description | - | Allows the app to have the same access to information in the directory as the signed-in user.
AdminConsentRequired | - | Yes
Directory permissions grant broad access to directory (Microsoft Entra ID) resources such as [user](https://learn.microsoft.com/en-us/graph/api/resources/user), [group](https://learn.microsoft.com/en-us/graph/api/resources/group), and [device](https://learn.microsoft.com/en-us/graph/api/resources/device) in an organization. Whenever possible, choose permissions specific to these resources and avoid using directory permissions.
Directory permissions might be deprecated in the future.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#directoryreadall)
### Directory.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 7ab1d382-f21e-4acd-a863-ba3e13f7da61 | 06da0dbc-49e2-44d2-8312-53f166ab848a
DisplayText | Read directory data | Read directory data
Description | Allows the app to read data in your organization's directory, such as users, groups and apps, without a signed-in user. | Allows the app to read data in your organization's directory, such as users, groups and apps.
AdminConsentRequired | Yes | Yes
Directory permissions grant broad access to directory (Microsoft Entra ID) resources such as [user](https://learn.microsoft.com/en-us/graph/api/resources/user), [group](https://learn.microsoft.com/en-us/graph/api/resources/group), and [device](https://learn.microsoft.com/en-us/graph/api/resources/device) in an organization. Whenever possible, choose permissions specific to these resources and avoid using directory permissions.
Directory permissions might be deprecated in the future.
Before December 3rd, 2020, when the application permission _Directory.Read.All_ was granted, the [Directory Readers](https://learn.microsoft.com/en-us/entra/identity/role-based-access-control/permissions-reference#directory-writers) directory role was also assigned to the app's service principal. This directory role isn't removed automatically when the associated application permissions are revoked. To remove an application's access to read or write to the directory, customers must also remove any directory roles that were granted to the application.
A service update disabling this behavior began rolling out on December 3rd, 2020. Deployment to all customers completed on January 11th, 2021. Directory roles are no longer automatically assigned when application permissions are granted.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#directoryreadwriteall)
### Directory.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 19dbc75e-c2e2-444c-a770-ec69d8559fc7 | c5366453-9fb0-48a5-a156-24f0c49a4b84
DisplayText | Read and write directory data | Read and write directory data
Description | Allows the app to read and write data in your organization's directory, such as users, and groups, without a signed-in user. Does not allow user or group deletion. | Allows the app to read and write data in your organization's directory, such as users, and groups. It does not allow the app to delete users or groups, or reset user passwords.
AdminConsentRequired | Yes | Yes
Directory permissions grant broad access to directory (Microsoft Entra ID) resources such as [user](https://learn.microsoft.com/en-us/graph/api/resources/user), [group](https://learn.microsoft.com/en-us/graph/api/resources/group), and [device](https://learn.microsoft.com/en-us/graph/api/resources/device) in an organization. Whenever possible, choose permissions specific to these resources and avoid using directory permissions.
Directory permissions might be deprecated in the future.
Before December 3rd, 2020, when the application permission _Directory.ReadWrite.All_ was granted, the [Directory Writers](https://learn.microsoft.com/en-us/entra/identity/role-based-access-control/permissions-reference#directory-writers) directory role was also assigned. This directory role isn't removed automatically when the associated application permissions are revoked. To remove an application's access to read or write to the directory, customers must also remove any directory roles that were granted to the application.
A service update disabling this behavior began rolling out on December 3rd, 2020. Deployment to all customers completed on January 11, 2021. Directory roles are no longer automatically assigned when application permissions are granted.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#directoryrecommendationsreadall)
### DirectoryRecommendations.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | ae73097b-cb2a-4447-b064-5d80f6093921 | 34d3bd24-f6a6-468c-b67c-0c365c1d6410
DisplayText | Read all Azure AD recommendations | Read Azure AD recommendations
Description | Allows the app to read all Azure AD recommendations, without a signed-in user. | Allows the app to read Azure AD recommendations, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#directoryrecommendationsreadwriteall)
### DirectoryRecommendations.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 0e9eea12-4f01-45f6-9b8d-3ea4c8144158 | f37235e8-90a0-4189-93e2-e55b53867ccd
DisplayText | Read and update all Azure AD recommendations | Read and update Azure AD recommendations
Description | Allows the app to read and update all Azure AD recommendations, without a signed-in user. | Allows the app to read and update Azure AD recommendations, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#domain-internalfederationreadall)
### Domain-InternalFederation.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | c0e5a7b0-e8b7-40a7-b8e0-8249e6ea81d5 | 33203a2a-a761-40f0-8a7c-a7e74a9f8ac6
DisplayText | Read internal federation configuration for a domain. | Read internal federation configuration for a domain.
Description | Allows the app to read internal federation configuration for a domain. | Allows the app to read internal federation configuration for a domain.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#domain-internalfederationreadwriteall)
### Domain-InternalFederation.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 64d40371-8d58-4270-bc8a-b4a66de36b9a | 857bd3ea-490e-4284-88a7-a7de1893b6ee
DisplayText | Create, read, update and delete internal federation configuration for a domain. | Create, read, update and delete internal federation configuration for a domain.
Description | Allows the app to create, read, update and delete internal federation configuration for a domain. | Allows the app to create, read, update and delete internal federation configuration for a domain.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#domainreadall)
### Domain.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | dbb9058a-0e50-45d7-ae91-66909b5d4664 | 2f9ee017-59c1-4f1d-9472-bd5529a7b311
DisplayText | Read domains | Read domains.
Description | Allows the app to read all domain properties without a signed-in user. | Allows the app to read all domain properties on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#domainreadwriteall)
### Domain.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 7e05723c-0bb0-42da-be95-ae9f08a6e53c | 0b5d694c-a244-4bde-86e6-eb5cd07730fe
DisplayText | Read and write domains | Read and write domains
Description | Allows the app to read and write all domain properties without a signed in user. Also allows the app to add, verify and remove domains. | Allows the app to read and write all domain properties on behalf of the signed-in user. Also allows the app to add, verify and remove domains.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#easaccessasuserall)
### EAS.AccessAsUser.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | ff91d191-45a0-43fd-b837-bd682c4a0b0f
DisplayText | - | Access mailboxes via Exchange ActiveSync
Description | - | Allows the app to have the same access to mailboxes as the signed-in user via Exchange ActiveSync.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#ediscoveryreadall)
### eDiscovery.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 50180013-6191-4d1e-a373-e590ff4e66af | 99201db3-7652-4d5a-809a-bdb94f85fe3c
DisplayText | Read all eDiscovery objects | Read all eDiscovery objects
Description | Allows the app to read eDiscovery objects such as cases, custodians, review sets and other related objects without a signed-in user. | Allows the app to read eDiscovery objects such as cases, custodians, review sets and other related objects on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#ediscoveryreadwriteall)
### eDiscovery.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | b2620db1-3bf7-4c5b-9cb9-576d29eac736 | acb8f680-0834-4146-b69e-4ab1b39745ad
DisplayText | Read and write all eDiscovery objects | Read and write all eDiscovery objects
Description | Allows the app to read and write eDiscovery objects such as cases, custodians, review sets and other related objects without a signed-in user. | Allows the app to read and write eDiscovery objects such as cases, custodians, review sets and other related objects on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#eduadministrationread)
### EduAdministration.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 8523895c-6081-45bf-8a5d-f062a2f12c9f
DisplayText | - | Read education app settings
Description | - | Read the state and settings of all Microsoft education apps on behalf of the user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#eduadministrationreadall)
### EduAdministration.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 7c9db06a-ec2d-4e7b-a592-5a1e30992566 | -
DisplayText | Read Education app settings | -
Description | Read the state and settings of all Microsoft education apps. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#eduadministrationreadwrite)
### EduAdministration.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 63589852-04e3-46b4-bae9-15d5b1050748
DisplayText | - | Manage education app settings
Description | - | Manage the state and settings of all Microsoft education apps on behalf of the user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#eduadministrationreadwriteall)
### EduAdministration.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 9bc431c3-b8bc-4a8d-a219-40f10f92eff6 | -
DisplayText | Manage education app settings | -
Description | Manage the state and settings of all Microsoft education apps. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#eduassignmentsread)
### EduAssignments.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 091460c9-9c4a-49b2-81ef-1f3d852acce2
DisplayText | - | Read users' class assignments and their grades
Description | - | Allows the app to read assignments and their grades on behalf of the user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#eduassignmentsreadall)
### EduAssignments.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 4c37e1b6-35a1-43bf-926a-6f30f2cdf585 | -
DisplayText | Read all class assignments with grades | -
Description | Allows the app to read all class assignments with grades for all users without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#eduassignmentsreadbasic)
### EduAssignments.ReadBasic
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | c0b0103b-c053-4b2e-9973-9f3a544ec9b8
DisplayText | - | Read users' class assignments without grades
Description | - | Allows the app to read assignments without grades on behalf of the user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#eduassignmentsreadbasicall)
### EduAssignments.ReadBasic.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 6e0a958b-b7fc-4348-b7c4-a6ab9fd3dd0e | -
DisplayText | Read all class assignments without grades | -
Description | Allows the app to read all class assignments without grades for all users without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#eduassignmentsreadwrite)
### EduAssignments.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 2f233e90-164b-4501-8bce-31af2559a2d3
DisplayText | - | Read and write users' class assignments and their grades
Description | - | Allows the app to read and write assignments and their grades on behalf of the user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#eduassignmentsreadwriteall)
### EduAssignments.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 0d22204b-6cad-4dd0-8362-3e3f2ae699d9 | -
DisplayText | Create, read, update and delete all class assignments with grades | -
Description | Allows the app to create, read, update and delete all class assignments with grades for all users without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#eduassignmentsreadwritebasic)
### EduAssignments.ReadWriteBasic
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 2ef770a1-622a-47c4-93ee-28d6adbed3a0
DisplayText | - | Read and write users' class assignments without grades
Description | - | Allows the app to read and write assignments without grades on behalf of the user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#eduassignmentsreadwritebasicall)
### EduAssignments.ReadWriteBasic.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | f431cc63-a2de-48c4-8054-a34bc093af84 | -
DisplayText | Create, read, update and delete all class assignments without grades | -
Description | Allows the app to create, read, update and delete all class assignments without grades for all users without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#educurricularead)
### EduCurricula.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 484859e8-b9e2-4e92-b910-84db35dadd29
DisplayText | - | Read the user's class modules and resources
Description | - | Allows the app to read the user's modules and resources on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#educurriculareadall)
### EduCurricula.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 6cdb464c-3a03-40f8-900b-4cb7ea1da9c0 | -
DisplayText | Read all class modules and resources | -
Description | Allows the app to read all modules and resources, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#educurriculareadwrite)
### EduCurricula.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 4793c53b-df34-44fd-8d26-d15c517732f5
DisplayText | - | Read and write the user's class modules and resources
Description | - | Allows the app to read and write user's modules and resources on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#educurriculareadwriteall)
### EduCurricula.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 6a0c2318-d59d-4c7d-bf2e-5f3902dc2593 | -
DisplayText | Read and write all class modules and resources | -
Description | Allows the app to read and write all modules and resources, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#edureports-readingreadall)
### EduReports-Reading.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | ad248c30-1919-40c8-b3d2-304481894e88 | -
DisplayText | Read all tenant reading assignments submissions data | -
Description | Allows the app to read all tenant users reading assignments submissions data without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#edureports-readingreadanonymousall)
### EduReports-Reading.ReadAnonymous.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 040330d7-be7e-4130-b349-a6eb3a56e2f8 | -
DisplayText | Read all tenant reading assignments submissions data | -
Description | Allows the app to read all tenant users reading assignments submissions data (excludes student-identifying information) without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#edureports-reflectreadall)
### EduReports-Reflect.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | c5debf73-bdc8-473d-bf07-f4074ad05f71 | -
DisplayText | Read all tenant reflect check-ins submissions data | -
Description | Allows the app to read all tenant users reflect check-ins submissions data without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#edureports-reflectreadanonymousall)
### EduReports-Reflect.ReadAnonymous.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | f5d05dba-7ef0-46fc-b62c-a7282555f428 | -
DisplayText | Read all tenant reflect check-ins submissions data | -
Description | Allows the app to read all tenant users reflect check-ins submissions data (excludes responder-identifying information) without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#edurosterread)
### EduRoster.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | a4389601-22d9-4096-ac18-36a927199112
DisplayText | - | Read users' view of the roster
Description | - | Allows the app to read the structure of schools and classes in an organization's roster and education-specific information about users to be read on behalf of the user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#edurosterreadall)
### EduRoster.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | e0ac9e1b-cb65-4fc5-87c5-1a8bc181f648 | -
DisplayText | Read the organization's roster | -
Description | Allows the app to read the structure of schools and classes in the organization's roster and education-specific information about all users to be read. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#edurosterreadbasic)
### EduRoster.ReadBasic
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 5d186531-d1bf-4f07-8cea-7c42119e1bd9
DisplayText | - | Read a limited subset of users' view of the roster
Description | - | Allows the app to read a limited subset of the properties from the structure of schools and classes in an organization's roster and a limited subset of properties about users to be read on behalf of the user. Includes name, status, education role, email address and photo.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#edurosterreadbasicall)
### EduRoster.ReadBasic.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 0d412a8c-a06c-439f-b3ec-8abcf54d2f96 | -
DisplayText | Read a limited subset of the organization's roster | -
Description | Allows the app to read a limited subset of properties from both the structure of schools and classes in the organization's roster and education-specific information about all users. Includes name, status, role, email address and photo. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#edurosterreadwrite)
### EduRoster.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 359e19a6-e3fa-4d7f-bcab-d28ec592b51e
DisplayText | - | Read and write users' view of the roster
Description | - | Allows the app to read and write the structure of schools and classes in an organization's roster and education-specific information about users to be read and written on behalf of the user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#edurosterreadwriteall)
### EduRoster.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | d1808e82-ce13-47af-ae0d-f9b254e6d58a | -
DisplayText | Read and write the organization's roster | -
Description | Allows the app to read and write the structure of schools and classes in the organization's roster and education-specific information about all users to be read and written. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#email)
### email
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 64a6cdd6-aab1-4aaf-94b8-3cc8405e90d0
DisplayText | - | View users' email address
Description | - | Allows the app to read your users' primary email address
AdminConsentRequired | - | No
_email_ is an OpenID Connect (OIDC) scope.
You can use the OIDC scopes to specify artifacts that you want returned in Microsoft identity platform authorization and token requests. The Microsoft identity platform v1.0 and v2.0 endpoints support OIDC scopes differently.
With the Microsoft identity platform v1.0 endpoint, only the _openid_ scope is used. You specify it in the _scope_ parameter in an authorization request to return an ID token when you use the OpenID Connect protocol to sign in a user to your app. For more information, see [Microsoft identity platform and OAuth 2.0 authorization code flow](https://learn.microsoft.com/en-us/entra/identity-platform/v2-oauth2-auth-code-flow). To successfully return an ID token, you must also make sure that the _User.Read_ permission is configured when you register your app.
With the Microsoft identity platform v2.0 endpoint, you specify the _offline_access_ scope in the **scope** parameter to explicitly request a refresh token when using the OAuth 2.0 or OpenID Connect protocols. With OpenID Connect, you specify the _openid_ scope to request an ID token. You can also specify the _email_ scope, _profile_ scope, or both to return additional claims in the ID token. You don't need to specify the _User.Read_ permission to return an ID token with the v2.0 endpoint. For more information, see [OpenID Connect scopes](https://learn.microsoft.com/en-us/entra/identity-platform/scopes-oidc#openid-connect-scopes).
The Microsoft Authentication Library (MSAL) currently specifies _offline_access_ , _openid_ , _profile_ , and _email_ by default in authorization and token requests. Therefore, for the default case, if you specify these scopes explicitly, the Microsoft identity platform might return an error.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#engagementconversationmigrationall)
### EngagementConversation.Migration.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | e1d2136d-eaaf-427a-a7db-f97dbe847c27 | -
DisplayText | Read and write all Viva Engage conversations | -
Description | Allows the app to create Viva Engage conversations without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#engagementconversationreadall)
### EngagementConversation.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 2c495153-cd0e-41b4-9980-3bcecf1ca22f | c55541d9-2cdd-4fad-8ead-0c08fae5b0c8
DisplayText | Read all Viva Engage conversations | Read all Viva Engage conversations
Description | Allows the app to list Viva Engage conversations, and to read their properties without a signed-in user. | Allows the app to read Viva Engage conversations, and to read their properties on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#engagementconversationreadwriteall)
### EngagementConversation.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | bfbd4840-fba0-43a7-93a9-465b687e47d0 | ebbfd079-1634-4640-8618-68b19ebbed1d
DisplayText | Read and write all Viva Engage conversations | Read and write all Viva Engage conversations
Description | Allows the app to create Viva Engage conversations, read all conversation properties, update conversation properties, and delete conversations without a signed-in user. | Allows the app to create Viva Engage conversations and read all conversation properties on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#engagementmeetingconversationreadall)
### EngagementMeetingConversation.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | d746beae-b46e-446e-924a-5b805a5c4467 | 58c5819e-29bd-4400-ad52-82cd82a63fbd
DisplayText | Read all Viva Engage Teams QA conversations | Read all Viva Engage Teams QA conversations
Description | Allows the app to list Viva Engage Teams QA conversations, and to read their properties without a signed-in user. | Allows the app to read Viva Engage Teams QA conversations, and to read their properties on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#engagementroleread)
### EngagementRole.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 9f1da0fc-345c-4dfb-bab5-5215a073a417
DisplayText | - | Read a user's Viva Engage roles
Description | - | Allows the app to list a user's Viva Engage roles, on behalf of the signed-in user.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#engagementrolereadall)
### EngagementRole.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 30614864-4114-45ef-bdd9-0dd7894a1cc4 | 3cad91a5-8413-4c4a-acfe-dfeb83d1366d
DisplayText | Read all Viva Engage roles and role memberships | Read all Viva Engage roles and role memberships
Description | Allows the app to list all Viva Engage roles and role memberships without a signed-in user. | Allows the app to list all Viva Engage roles and role memberships on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#engagementrolereadwriteall)
### EngagementRole.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 3ede5358-7366-4da8-a2f7-472bf9c7cc34 | 4905982d-6459-4ccd-949c-949fefc0a8f2
DisplayText | Modify Viva Engage role membership | Modify Viva Engage role membership
Description | Allows the app to assign Viva Engage role to a user, and remove a Viva Engage role from a user without a signed-in user. | Allows the app to assign Viva Engage role to a user, and remove a Viva Engage role from a user behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#entitlementmanagementreadall)
### EntitlementManagement.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | c74fd47d-ed3c-45c3-9a9e-b8676de685d2 | 5449aa12-1393-4ea2-a7c7-d0e06c1a56b2
DisplayText | Read all entitlement management resources | Read all entitlement management resources
Description | Allows the app to read access packages and related entitlement management resources without a signed-in user. | Allows the app to read access packages and related entitlement management resources on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#entitlementmanagementreadwriteall)
### EntitlementManagement.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 9acd699f-1e81-4958-b001-93b1d2506e19 | ae7a573d-81d7-432b-ad44-4ed5c9d89038
DisplayText | Read and write all entitlement management resources | Read and write entitlement management resources
Description | Allows the app to read and write access packages and related entitlement management resources without a signed-in user. | Allows the app to request access to and management of access packages and related entitlement management resources on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#entitlementmgmt-subjectaccessreadwrite)
### EntitlementMgmt-SubjectAccess.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | e9fdcbbb-8807-410f-b9ec-8d5468c7c2ac
DisplayText | - | Read and write entitlement management resources related to self-service operations
Description | - | Allows the app to manage self-service entitlement management resources on behalf of the signed-in user. This includes operations such as requesting access and approving access of others.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#eventlistenerreadall)
### EventListener.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | b7f6385c-6ce6-4639-a480-e23c42ed9784 | f7dd3bed-5eec-48da-bc73-1c0ef50bc9a1
DisplayText | Read all authentication event listeners | Read your organization's authentication event listeners
Description | Allows the app to read your organization's authentication event listeners without a signed-in user. | Allows the app to read your organization's authentication event listeners on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#eventlistenerreadwriteall)
### EventListener.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 0edf5e9e-4ce8-468a-8432-d08631d18c43 | d11625a6-fe21-4fc6-8d3d-063eba5525ad
DisplayText | Read and write all authentication event listeners | Read and write your organization's authentication event listeners
Description | Allows the app to read or write your organization's authentication event listeners without a signed-in user. | Allows the app to read or write your organization's authentication event listeners on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#ewsaccessasuserall)
### EWS.AccessAsUser.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 9769c687-087d-48ac-9cb3-c37dde652038
DisplayText | - | Access mailboxes as the signed-in user via Exchange Web Services
Description | - | Allows the app to have the same access to mailboxes as the signed-in user via Exchange Web Services.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#exchangemessagetracereadall)
### ExchangeMessageTrace.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 89b20d8a-76e2-4057-867b-9961f800b9a4 | b2e7d27e-14e7-41ad-bb15-a88ceb9c3e90
DisplayText | Search the email message trace | Search the email message trace
Description | Allows the app to search the email message trace, without a signed-in user. | Allows the app to search the email message trace on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#externalconnectionreadall)
### ExternalConnection.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 1914711b-a1cb-4793-b019-c2ce0ed21b8c | a38267a5-26b6-4d76-9493-935b7599116b
DisplayText | Read all external connections | Read all external connections
Description | Allows the app to read all external connections without a signed-in user. | Allows the app to read all external connections on behalf of a signed-in user. The signed-in user must be an administrator.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#externalconnectionreadwriteall)
### ExternalConnection.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 34c37bc0-2b40-4d5e-85e1-2365cd256d79 | bbbbd9b3-3566-4931-ac37-2b2180d9e334
DisplayText | Read and write all external connections | Read and write all external connections
Description | Allows the app to read and write all external connections without a signed-in user. | Allows the app to read and write all external connections on behalf of a signed-in user. The signed-in user must be an administrator.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#externalconnectionreadwriteownedby)
### ExternalConnection.ReadWrite.OwnedBy
Expand table
Category | Application | Delegated
---|---|---
Identifier | f431331c-49a6-499f-be1c-62af19c34a9d | 4082ad95-c812-4f02-be92-780c4c4f1830
DisplayText | Read and write external connections | Read and write external connections
Description | Allows the app to read and write external connections without a signed-in user. The app can only read and write external connections that it is authorized to, or it can create new external connections. | Allows the app to read and write settings of external connections on behalf of a signed-in user. The signed-in user must be an administrator. The app can only read and write settings of connections that it is authorized to.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#externalitemreadall)
### ExternalItem.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 7a7cffad-37d2-4f48-afa4-c6ab129adcc2 | 922f9392-b1b7-483c-a4be-0089be7704fb
DisplayText | Read all external items | Read items in external datasets
Description | Allows the app to read all external items without a signed-in user. | Allow the app to read external datasets and content, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#externalitemreadwriteall)
### ExternalItem.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 38c3d6ee-69ee-422f-b954-e17819665354 | b02c54f8-eb48-4c50-a9f0-a149e5a2012f
DisplayText | Read and write items in external datasets | Read and write all external items
Description | Allow the app to read or write items in all external datasets that the app is authorized to access | Allows the app to read and write all external items on behalf of a signed-in user. The signed-in user must be an administrator.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#externalitemreadwriteownedby)
### ExternalItem.ReadWrite.OwnedBy
Expand table
Category | Application | Delegated
---|---|---
Identifier | 8116ae0f-55c2-452d-9944-d18420f5b2c8 | 4367b9d7-cee7-4995-853c-a0bdfe95c1f9
DisplayText | Read and write external items | Read and write external items
Description | Allows the app to read and write external items without a signed-in user. The app can only read external items of the connection that it is authorized to. | Allows the app to read and write external items on behalf of a signed-in user. The signed-in user must be an administrator. The app can only read external items of the connection that it is authorized to.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#externaluserprofilereadall)
### ExternalUserProfile.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 1987d7a0-d602-4262-ab90-cfdd43b37545 | 47167bec-55a7-4caf-9ecc-8d4566e3cfb1
DisplayText | Read all external user profiles | Read external user profiles
Description | Allows the app to read available properties of external user profiles, without a signed-in user. | Allows the app to read available properties of external user profiles, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#externaluserprofilereadwriteall)
### ExternalUserProfile.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 761327c9-d819-4c08-9a5f-874cd2826608 | c6068dc7-a791-46a4-a811-b8228e6649ab
DisplayText | Read and write all external user profiles | Read and write external user profiles
Description | Allows the app to read and write available properties of external user profiles, without a signed-in user. | Allows the app to read and write available properties of external user profiles, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#familyread)
### Family.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 3a1e4806-a744-4c70-80fc-223bf8582c46
DisplayText | - | Read your family info
Description | - | Allows the app to read your family information, members and their basic profile.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#fileingestioningest)
### FileIngestion.Ingest
Expand table
Category | Application | Delegated
---|---|---
Identifier | 65891b00-2fd9-4e33-be27-04a53132e3df | -
DisplayText | Ingest SharePoint and OneDrive content to make it available in the search index | -
Description | Allows the app to ingest SharePoint and OneDrive content to make it available in the search index, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#fileingestionhybridonboardingmanage)
### FileIngestionHybridOnboarding.Manage
Expand table
Category | Application | Delegated
---|---|---
Identifier | 766c601b-c009-4438-8290-c8b05fa00c4b | -
DisplayText | Manage onboarding for a Hybrid Cloud tenant | -
Description | Allows the app to manage onboarding for a Hybrid Cloud tenant, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#filesread)
### Files.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 10465720-29dd-4523-a11a-6a75c743c9d9
DisplayText | - | Read user files
Description | - | Allows the app to read the signed-in user's files.
AdminConsentRequired | - | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Files.Read_ delegated permission is available for consent in personal Microsoft accounts.
For personal accounts, _Files.Read_ also grant access to files shared with the signed-in user.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#filesreadall)
### Files.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 01d4889c-1287-42c6-ac1f-5d1e02578ef6 | df85f4d6-205c-4ac5-a5ea-6bf408dba283
DisplayText | Read files in all site collections | Read all files that user can access
Description | Allows the app to read all files in all site collections without a signed in user. | Allows the app to read all files the signed-in user can access.
AdminConsentRequired | Yes | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Files.Read.All_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#filesreadselected)
### Files.Read.Selected
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 5447fe39-cb82-4c1a-b977-520e67e724eb
DisplayText | - | Read files that the user selects (preview)
Description | - | (Preview) Allows the app to read files that the user selects. The app has access for several hours after the user selects a file.
AdminConsentRequired | - | No
The _Files.Read.Selected_ delegated permission is only valid on work or school accounts and is only exposed for working with [Office 365 file handlers (v1.0)](https://learn.microsoft.com/en-us/previous-versions/office/office-365-api/). It should not be used for directly calling Microsoft Graph APIs.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#filesreadwrite)
### Files.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 5c28f0bf-8a70-41f1-8ab2-9032436ddb65
DisplayText | - | Have full access to user files
Description | - | Allows the app to read, create, update and delete the signed-in user's files.
AdminConsentRequired | - | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Files.ReadWrite_ delegated permission is available for consent in personal Microsoft accounts.
For personal accounts, _Files.ReadWrite_ also grant access to files shared with the signed-in user.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#filesreadwriteall)
### Files.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 75359482-378d-4052-8f01-80520e7db3cd | 863451e7-0667-486c-a5d6-d135439485f0
DisplayText | Read and write files in all site collections | Have full access to all files user can access
Description | Allows the app to read, create, update and delete all files in all site collections without a signed in user. | Allows the app to read, create, update and delete all files the signed-in user can access.
AdminConsentRequired | Yes | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Files.ReadWrite.All_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#filesreadwriteappfolder)
### Files.ReadWrite.AppFolder
Expand table
Category | Application | Delegated
---|---|---
Identifier | b47b160b-1054-4efd-9ca0-e2f614696086 | 8019c312-3263-48e6-825e-2b833497195b
DisplayText | Have full access to the application's folder without a signed in user. | Have full access to the application's folder (preview)
Description | Allows the app to read, create, update and delete files in the application's folder without a signed in user. | (Preview) Allows the app to read, create, update and delete files in the application's folder.
AdminConsentRequired | Yes | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Files.ReadWrite.AppFolder_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#filesreadwriteselected)
### Files.ReadWrite.Selected
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 17dde5bd-8c17-420f-a486-969730c1b827
DisplayText | - | Read and write files that the user selects (preview)
Description | - | (Preview) Allows the app to read and write files that the user selects. The app has access for several hours after the user selects a file.
AdminConsentRequired | - | No
The _Files.ReadWrite.Selected_ delegated permission is only valid on work or school accounts and is only exposed for working with [Office 365 file handlers (v1.0)](https://learn.microsoft.com/en-us/previous-versions/office/office-365-api/). It should not be used for directly calling Microsoft Graph APIs.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#filesselectedoperationsselected)
### Files.SelectedOperations.Selected
Expand table
Category | Application | Delegated
---|---|---
Identifier | bd61925e-3bf4-4d62-bc0b-06b06c96d95c | ef2779dc-ef1b-4211-8310-8a0ac2450081
DisplayText | Access selected Files without a signed in user. | Access selected Files, on behalf of the signed-in user
Description | Allow the application to access a subset of files without a signed in user. The specific files and the permissions granted will be configured in SharePoint Online or OneDrive. | Allow the application to access files explicitly permissioned to the application on behalf of the signed in user. The specific files and the permissions granted will be configured in SharePoint Online or OneDrive.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#filestoragecontainermanageall)
### FileStorageContainer.Manage.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 527b6d64-cdf5-4b8b-b336-4aa0b8ca2ce5
DisplayText | - | Manage all file storage containers
Description | - | Allows the application to utilize the file storage container administration capabilities on behalf of an administrator user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#filestoragecontainerselected)
### FileStorageContainer.Selected
Expand table
Category | Application | Delegated
---|---|---
Identifier | 40dc41bc-0f7e-42ff-89bd-d9516947e474 | 085ca537-6565-41c2-aca7-db852babc212
DisplayText | Access selected file storage containers | Access selected file storage containers
Description | Allows the application to utilize the file storage container platform to manage containers, without a signed-in user. The specific file storage containers and the permissions granted to them will be configured in Microsoft 365 by the developer of each container type. | Allows the application to utilize the file storage container platform to manage containers on behalf of the signed in user. The specific file storage containers and the permissions granted to them will be configured in Microsoft 365 by the developer of each container type.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#filestoragecontainertypemanageall)
### FileStorageContainerType.Manage.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 8e6ec84c-5fcd-4cc7-ac8a-2296efc0ed9b
DisplayText | - | Manage file storage container types on behalf of the signed in user
Description | - | Allows the application to manage file storage container types on behalf of the signed in user. The user must be a SharePoint Embedded Admin or Global Admin.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#filestoragecontainertyperegmanageall)
### FileStorageContainerTypeReg.Manage.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | c319a7df-930e-44c0-a43b-7e5e9c7f4f24
DisplayText | - | Manage file storage container type registrations on behalf of the signed in user
Description | - | Allows the application to manage file storage container type registrations on behalf of the signed in user. The user must be a SharePoint Embedded Admin or Global Admin.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#filestoragecontainertyperegselected)
### FileStorageContainerTypeReg.Selected
Expand table
Category | Application | Delegated
---|---|---
Identifier | 2dcc6599-bd30-442b-8f11-90f88ad441dc | d1e4f63a-1569-475c-b9b2-bdc140405e38
DisplayText | Access selected file storage container type registrations | Access selected file storage container type registrations.
Description | Allows the application to manage file storage container type registrations without a signed-in user. | Allows the application to manage selected file storage container type registrations on behalf of the signed in user. The user must be a SharePoint Embedded Admin or Global Admin.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#financialsreadwriteall)
### Financials.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | f534bf13-55d4-45a9-8f3c-c92fe64d6131
DisplayText | - | Read and write financials data
Description | - | Allows the app to read and write financials data on behalf of the signed-in user.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#goals-exportreadall)
### Goals-Export.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 092211d9-ca1a-427b-813e-b79c7653fe71
DisplayText | - | Read all goals and export jobs that a user can access
Description | - | Allows the app to read all goals and export jobs that the signed-in user can access.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#goals-exportreadwriteall)
### Goals-Export.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 2edeb9fd-4228-480c-a26d-2ed52011cf3d
DisplayText | - | Have full access to all goals and export jobs a user can access
Description | - | Allows the app to read goals, create and read export jobs that the signed-in user can access.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#group-conversationreadall)
### Group-Conversation.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 4f0a8235-6f6f-4ec7-9500-34b452a4a0c3 | c92fbbc2-50e0-4842-93ef-385c3293ea3d
DisplayText | Read all group conversations | Read group conversations
Description | Allows the app to read conversations of the groups this app has access to without a signed-in user. | Allows the app to read group conversations that the signed-in user has access to.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#group-conversationreadwriteall)
### Group-Conversation.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 6679c91b-820a-4900-ab47-e97b197a89c4 | 302bcbb5-855a-4e49-ae20-94a331b0281e
DisplayText | Read and write all group conversations | Read and write group conversations
Description | Allows the app to read and write conversations of the groups this app has access to without a signed-in user. | Allows the app to read and write group conversations that the signed-in user has access to.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#group-onpremisessyncbehaviorreadwriteall)
### Group-OnPremisesSyncBehavior.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 2d9bd318-b883-40be-9df7-63ec4fcdc424 | 37e00479-5776-4659-aecf-4841ec5d590a
DisplayText | Read and update the on-premises sync behavior of groups | Read and update the on-premises sync behavior of groups
Description | Allows the app to update the on-premises sync behavior of all groups without a signed-in user. | Allows the app to read and update the on-premises sync behavior of groups on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#groupcreate)
### Group.Create
Expand table
Category | Application | Delegated
---|---|---
Identifier | bf7b1a76-6e77-406b-b258-bf5c7720e98f | -
DisplayText | Create groups | -
Description | Allows the app to create groups without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#groupreadall)
### Group.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 5b567255-7703-4780-807c-7be8301ae99b | 5f8c59db-677d-491f-a6b8-5f174b11ec1d
DisplayText | Read all groups | Read all groups
Description | Allows the app to read group properties and memberships, and read conversations for all groups, without a signed-in user. | Allows the app to list groups, and to read their properties and all group memberships on behalf of the signed-in user. Also allows the app to read calendar, conversations, files, and other group content for all groups the signed-in user can access.
AdminConsentRequired | Yes | Yes
For Microsoft 365 groups, _Group._ * permissions grant the app access to the contents of the group; for example, conversations, files, notes, and so on.
In some cases, an app might need extra permissions to read some group properties like `member` and `memberOf`. For example, if a group has one or more [service principals](https://learn.microsoft.com/en-us/graph/api/resources/serviceprincipal?view=graph-rest-beta&preserve-view=true) as members, the app also needs permissions to read service principals, otherwise Microsoft Graph returns an error or limited information. To read the full information, the app also needs permissions in the organization to read service principals. For more information, see [Limited information returned for inaccessible member objects](https://learn.microsoft.com/en-us/graph/permissions-overview#limited-information-returned-for-inaccessible-member-objects).
_Group._ * permissions are used to control access to [Microsoft Teams](https://learn.microsoft.com/en-us/graph/api/resources/teams-api-overview) resources and APIs. Personal Microsoft accounts are not supported.
_Group._ * permissions are also used to control access to [Microsoft Planner](https://learn.microsoft.com/en-us/graph/api/resources/planner-overview) resources and APIs. Only delegated permissions are supported for Microsoft Planner APIs; application permissions are not supported. Personal Microsoft accounts are not supported.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#groupreadwriteall)
### Group.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 62a82d76-70ea-41e2-9197-370581804d09 | 4e46008b-f24c-477d-8fff-7bb4ec7aafe0
DisplayText | Read and write all groups | Read and write all groups
Description | Allows the app to create groups, read all group properties and memberships, update group properties and memberships, and delete groups. Also allows the app to read and write conversations. All of these operations can be performed by the app without a signed-in user. | Allows the app to create groups and read all group properties and memberships on behalf of the signed-in user. Additionally allows group owners to manage their groups and allows group members to update group content.
AdminConsentRequired | Yes | Yes
For Microsoft 365 groups, _Group._ * permissions grant the app access to the contents of the group; for example, conversations, files, notes, and so on.
In some cases, an app may need extra properties to update some group properties and relationships like `member` and `memberOf`. For example, to add a [servicePrincipal](https://learn.microsoft.com/en-us/graph/api/resources/serviceprincipal?view=graph-rest-beta&preserve-view=true) object as a member, the app also needs permissions to write the service principal, otherwise Microsoft Graph returns an error. For more information, see [Limited information returned for inaccessible member objects](https://learn.microsoft.com/en-us/graph/permissions-overview#limited-information-returned-for-inaccessible-member-objects).
_Group._ * permissions are used to control access to [Microsoft Teams](https://learn.microsoft.com/en-us/graph/api/resources/teams-api-overview) resources and APIs. Personal Microsoft accounts are not supported.
_Group._ * permissions are also used to control access to [Microsoft Planner](https://learn.microsoft.com/en-us/graph/api/resources/planner-overview) resources and APIs. Only delegated permissions are supported for Microsoft Planner APIs; application permissions are not supported. Personal Microsoft accounts are not supported.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#groupmemberreadall)
### GroupMember.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 98830695-27a2-44f7-8c18-0c3ebc9698f6 | bc024368-1153-4739-b217-4326f2e966d0
DisplayText | Read all group memberships | Read group memberships
Description | Allows the app to read memberships and basic group properties for all groups without a signed-in user. | Allows the app to list groups, read basic group properties and read membership of all groups the signed-in user has access to.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#groupmemberreadwriteall)
### GroupMember.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | dbaae8cf-10b5-4b86-a4a1-f871c94c6695 | f81125ac-d3b7-4573-a3b2-7099cc39df9e
DisplayText | Read and write all group memberships | Read and write group memberships
Description | Allows the app to list groups, read basic properties, read and update the membership of the groups this app has access to without a signed-in user. Group properties and owners cannot be updated and groups cannot be deleted. | Allows the app to list groups, read basic properties, read and update the membership of the groups the signed-in user has access to. Group properties and owners cannot be updated and groups cannot be deleted.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#groupsettingsreadall)
### GroupSettings.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | f3c4f514-c65a-43f5-bfce-1735872258dd | 2eb2bc92-94ef-4c6b-b4ab-2a09bc975e0e
DisplayText | Read all group settings | Read all group settings that user can access
Description | Allows the app to read a list of tenant-level or group-specific group settings objects, without a signed-in user. | Allows the app to read a list of tenant-level or group-specific group settings objects, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#groupsettingsreadwriteall)
### GroupSettings.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 546168c3-1183-4281-9491-fafb24dea37e | c1691a6d-99e2-4cfa-b4b5-9e4d67dc0f36
DisplayText | Read and write all group settings | Read and write all group settings that user can access
Description | Allows the app to create, read, update, and delete on the list of tenant-level or group-specific group settings objects, without a signed-in user. | Allows the app to create, read, update, and delete on the list of tenant-level or group-specific group settings objects that you have access to in the organization, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#healthmonitoringalertreadall)
### HealthMonitoringAlert.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 5183ed5d-b7f8-4e9a-915e-dafb46b9cb62 | 74b4ff32-4917-4536-a66d-38a4861e6220
DisplayText | Read all scenario health monitoring alert | Read all scenario health monitoring alerts
Description | Allows the app to read all scenario health monitoring alerts, without a signed-in user. | Allows the app to read all scenario health monitoring alerts
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#healthmonitoringalertreadwriteall)
### HealthMonitoringAlert.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | ac29eb50-f2f9-4518-a117-4bef18e84c7d | b7c60f27-2195-4d5f-96a7-6b98bdfd9664
DisplayText | Read and write all scenario monitoring alerts | Read and write all scenario monitoring alerts
Description | Allows the app to read and write all scenario monitoring alerts, without a signed-in user. | Allows the app to read and write all scenario monitoring alerts, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#healthmonitoringalertconfigreadall)
### HealthMonitoringAlertConfig.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | bb424d73-e898-4c97-9d42-688c32810003 | fb873030-8626-47e6-96ff-8a5bff3b725f
DisplayText | Read all scenario health monitoring alert configurations | Read all scenario health monitoring alert configurations
Description | Allows the app to read all scenario health monitoring alert configurations, without a signed-in user. | Allows the app to read all scenario health monitoring alert configurations
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#healthmonitoringalertconfigreadwriteall)
### HealthMonitoringAlertConfig.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 432e76f0-8af6-4315-a853-66ab9538f480 | b3e5ebc6-1c23-4337-8286-3f27165addb4
DisplayText | Read and write all scenario monitoring alerts | Read and write all scenario monitoring alert configurations.
Description | Allows the app to read and write all scenario monitoring alerts, without a signed-in user. | Allows the app to read and write all scenario monitoring alert configurations, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#identityproviderreadall)
### IdentityProvider.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | e321f0bb-e7f7-481e-bb28-e3b0b32d4bd0 | 43781733-b5a7-4d1b-98f4-e8edff23e1a9
DisplayText | Read identity providers | Read identity providers
Description | Allows the app to read your organization's identity (authentication) providers' properties without a signed in user. | Allows the app to read your organization's identity (authentication) providers' properties on behalf of the user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#identityproviderreadwriteall)
### IdentityProvider.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 90db2b9a-d928-4d33-a4dd-8442ae3d41e4 | f13ce604-1677-429f-90bd-8a10b9f01325
DisplayText | Read and write identity providers | Read and write identity providers
Description | Allows the app to read and write your organization's identity (authentication) providers' properties without a signed in user. | Allows the app to read and write your organization's identity (authentication) providers' properties on behalf of the user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#identityriskeventreadall)
### IdentityRiskEvent.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 6e472fd1-ad78-48da-a0f0-97ab2c6b769e | 8f6a01e7-0391-4ee5-aa22-a3af122cef27
DisplayText | Read all identity risk event information | Read identity risk event information
Description | Allows the app to read the identity risk event information for your organization without a signed in user. | Allows the app to read identity risk event information for all users in your organization on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#identityriskeventreadwriteall)
### IdentityRiskEvent.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | db06fb33-1953-4b7b-a2ac-f1e2c854f7ae | 9e4862a5-b68f-479e-848a-4e07e25c9916
DisplayText | Read and write all risk detection information | Read and write risk event information
Description | Allows the app to read and update identity risk detection information for your organization without a signed-in user. Update operations include confirming risk event detections. | Allows the app to read and update identity risk event information for all users in your organization on behalf of the signed-in user. Update operations include confirming risk event detections.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#identityriskyagentreadall)
### IdentityRiskyAgent.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 4aadfb66-d49a-414a-a883-d8c240b6fa33 | 3215c57f-3faa-4295-95c2-6f14a5bc6124
DisplayText | Read all risky agents information | Read risky agents information
Description | Allows the app to read the risky agents information in your organization without a signed-in user. | Allows the app to read risky agents information in your organization, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#identityriskyagentreadwriteall)
### IdentityRiskyAgent.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | dca4e4fd-a7cf-4e6f-86d1-d1ec094d766e | d343bdeb-db6a-4e06-97da-9dafc2d61c60
DisplayText | Read and write risky agents information | Read and write risky agents information
Description | Allows the app to read and update risky agents information in your organization without a signed-in user. | Allows the app to read and update identity risky agents information for all agents in your organization on behalf of the signed-in user. Update operations include dismissing risky agents.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#identityriskyserviceprincipalreadall)
### IdentityRiskyServicePrincipal.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 607c7344-0eed-41e5-823a-9695ebe1b7b0 | ea5c4ab0-5a73-4f35-8272-5d5337884e5d
DisplayText | Read all identity risky service principal information | Read all identity risky service principal information
Description | Allows the app to read all risky service principal information for your organization, without a signed-in user. | Allows the app to read all identity risky service principal information for your organization, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#identityriskyserviceprincipalreadwriteall)
### IdentityRiskyServicePrincipal.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | cb8d6980-6bcb-4507-afec-ed6de3a2d798 | bb6f654c-d7fd-4ae3-85c3-fc380934f515
DisplayText | Read and write all identity risky service principal information | Read and write all identity risky service principal information
Description | Allows the app to read and update identity risky service principal for your organization, without a signed-in user. | Allows the app to read and update identity risky service principal information for all service principals in your organization, on behalf of the signed-in user. Update operations include dismissing risky service principals.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#identityriskyuserreadall)
### IdentityRiskyUser.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | dc5007c0-2d7d-4c42-879c-2dab87571379 | d04bb851-cb7c-4146-97c7-ca3e71baf56c
DisplayText | Read all identity risky user information | Read identity risky user information
Description | Allows the app to read the identity risky user information for your organization without a signed in user. | Allows the app to read identity risky user information for all users in your organization on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#identityriskyuserreadwriteall)
### IdentityRiskyUser.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 656f6061-f9fe-4807-9708-6a2e0934df76 | e0a7cdbb-08b0-4697-8264-0069786e9674
DisplayText | Read and write all risky user information | Read and write risky user information
Description | Allows the app to read and update identity risky user information for your organization without a signed-in user. Update operations include dismissing risky users. | Allows the app to read and update identity risky user information for all users in your organization on behalf of the signed-in user. Update operations include dismissing risky users.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#identityuserflowreadall)
### IdentityUserFlow.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 1b0c317f-dd31-4305-9932-259a8b6e8099 | 2903d63d-4611-4d43-99ce-a33f3f52e343
DisplayText | Read all identity user flows | Read all identity user flows
Description | Allows the app to read your organization's user flows, without a signed-in user. | Allows the app to read your organization's user flows, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#identityuserflowreadwriteall)
### IdentityUserFlow.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 65319a09-a2be-469d-8782-f6b07debf789 | 281892cc-4dbf-4e3a-b6cc-b21029bb4e82
DisplayText | Read and write all identity user flows | Read and write all identity user flows
Description | Allows the app to read or write your organization's user flows, without a signed-in user. | Allows the app to read or write your organization's user flows, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#imapaccessasuserall)
### IMAP.AccessAsUser.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 652390e4-393a-48de-9484-05f9b1212954
DisplayText | - | Read and write access to mailboxes via IMAP.
Description | - | Allows the app to have the same access to mailboxes as the signed-in user via IMAP protocol.
AdminConsentRequired | - | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _IMAP.AccessAsUser.All_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#industrydata-dataconnectorreadall)
### IndustryData-DataConnector.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 7ab52c2f-a2ee-4d98-9ebc-725e3934aae2 | d19c0de5-7ecb-4aba-b090-da35ebcd5425
DisplayText | View data connector definitions | View data connector definitions
Description | Allows the app to read data connectors without a signed-in user. | Allows the app to read data connectors on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#industrydata-dataconnectorreadwriteall)
### IndustryData-DataConnector.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | eda0971c-482e-4345-b28f-69c309cb8a34 | 5ce933ac-3997-4280-aed0-cc072e5c062a
DisplayText | Manage data connector definitions | Manage data connector definitions
Description | Allows the app to read and write data connectors without a signed-in user. | Allows the app to read and write data connectors on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#industrydata-dataconnectorupload)
### IndustryData-DataConnector.Upload
Expand table
Category | Application | Delegated
---|---|---
Identifier | 9334c44b-a7c6-4350-8036-6bf8e02b4c1f | fc47391d-ab2c-410f-9059-5600f7af660d
DisplayText | Upload files to a data connector | Upload files to a data connector
Description | Allows the app to upload data files to a data connector without a signed-in user. | Allows the app to upload data files to a data connector on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#industrydata-inboundflowreadall)
### IndustryData-InboundFlow.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 305f6ba2-049a-4b1b-88bb-fe7e08758a00 | cb0774da-a605-42af-959c-32f438fb38f4
DisplayText | View inbound flow definitions | View inbound flow definitions
Description | Allows the app to read inbound data flows without a signed-in user. | Allows the app to read inbound data flows on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#industrydata-inboundflowreadwriteall)
### IndustryData-InboundFlow.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | e688c61f-d4c6-4d64-a197-3bcf6ba1d6ad | 97044676-2cec-40ee-bd70-38df444c9e70
DisplayText | Manage inbound flow definitions | Manage inbound flow definitions
Description | Allows the app to read and write inbound data flows without a signed-in user. | Allows the app to read and write inbound data flows on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#industrydata-outboundflowreadall)
### IndustryData-OutboundFlow.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 61d0354c-5d88-483c-b974-a37ec3395a2c | 4741a003-8952-4be4-9217-33a0ac327122
DisplayText | View outbound flow definitions | View outbound flow definitions
Description | Allows the app to read outbound data flows without a signed-in user. | Allows the app to read outbound data flows on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#industrydata-outboundflowreadwriteall)
### IndustryData-OutboundFlow.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 24a65b4a-e501-47e2-8849-d679517887f0 | aeb68e0b-e562-4a1f-b6dd-3484ad0cbb4b
DisplayText | Manage outbound flow definitions | Manage outbound flow definitions
Description | Allows the app to read and write outbound data flows without a signed-in user. | Allows the app to read and write outbound data flows on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#industrydata-referencedefinitionreadall)
### IndustryData-ReferenceDefinition.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 6ee891c3-74a4-4148-8463-0c834375dfaf | a3f96ffe-cb84-40a8-ac85-582d7ef97c2a
DisplayText | View reference definitions | View reference definitions
Description | Allows the app to read reference definitions without a signed-in user. | Allows the app to read reference definitions on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#industrydata-referencedefinitionreadwriteall)
### IndustryData-ReferenceDefinition.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | bda16293-63d3-45b7-b16b-833841d27d56 | a757d430-be6d-430f-af57-28aabe79d247
DisplayText | Manage reference definitions | Manage reference definitions
Description | Allows the app to read and write reference definitions without a signed-in user. | Allows the app to read and write reference definitions on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#industrydata-runreadall)
### IndustryData-Run.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | f6f5d10b-3024-4d1d-b674-aae4df4a1a73 | 92685235-50c4-4702-b2c8-36043db6fa79
DisplayText | View current and previous runs | View current and previous runs
Description | Allows the app to read current and previous IndustryData runs without a signed-in user. | Allows the app to read current and previous IndustryData runs on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#industrydata-runstart)
### IndustryData-Run.Start
Expand table
Category | Application | Delegated
---|---|---
Identifier | 7e429772-5b5e-47c0-8fd6-7279294c8033 | f03a6d0e-0989-460f-80b2-e57c8561763e
DisplayText | View and start runs | View and start runs
Description | Allows the app to view and start IndustryData runs without a signed-in user. | Allows the app to view and start IndustryData runs on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#industrydata-sourcesystemreadall)
### IndustryData-SourceSystem.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | bc167a60-39fe-4865-8b44-78400fc6ed03 | 49b7016c-89ae-41e7-bd6f-b7170c5490bf
DisplayText | View source system definitions | View source system definitions
Description | Allows the app to read source system definitions without a signed-in user. | Allows the app to read source system definitions on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#industrydata-sourcesystemreadwriteall)
### IndustryData-SourceSystem.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 7d866958-e06e-4dd6-91c6-a086b3f5cfeb | 9599f005-05d6-4ea7-b1b1-4929768af5d0
DisplayText | Manage source system definitions | Manage source system definitions
Description | Allows the app to read and write source system definitions without a signed-in user. | Allows the app to read and write source system definitions on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#industrydata-timeperiodreadall)
### IndustryData-TimePeriod.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 7c55c952-b095-4c23-a522-022bce4cc1e3 | c9d51f28-8ccd-42b2-a836-fd8fe9ebf2ae
DisplayText | Read time period definitions | Read time period definitions
Description | Allows the app to read time period definitions without a signed-in user. | Allows the app to read time period definitions on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#industrydata-timeperiodreadwriteall)
### IndustryData-TimePeriod.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 7afa7744-a782-4a32-b8c2-e3db637e8de7 | b6d56528-3032-4f9d-830f-5a24a25e6661
DisplayText | Manage time period definitions | Manage time period definitions
Description | Allows the app to read and write time period definitions without a signed-in user. | Allows the app to read and write time period definitions on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#industrydatareadbasicall)
### IndustryData.ReadBasic.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 4f5ac95f-62fd-472c-b60f-125d24ca0bc5 | 60382b96-1f5e-46ea-a544-0407e489e588
DisplayText | View basic service and resource information | Read basic Industry Data service and resource definitions
Description | Allows the app to read basic service and resource information without a signed-in user. | Allows the app to read basic Industry Data service and resource information on behalf of the signed-in user.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#informationprotectionconfigread)
### InformationProtectionConfig.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 12f4bffb-b598-413c-984b-db99728f8b54
DisplayText | - | Read configurations for protecting organizational data applicable to the user
Description | - | Allows the app to read the configurations applicable to the signed-in user for protecting organizational data, on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#informationprotectionconfigreadall)
### InformationProtectionConfig.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 14f49b9f-4bf2-4d24-b80e-b27ec58409bd | -
DisplayText | Read all configurations for protecting organizational data applicable to users | -
Description | Allows the app to read all configurations applicable to users for protecting organizational data, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#informationprotectioncontentsignall)
### InformationProtectionContent.Sign.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | cbe6c7e4-09aa-4b8d-b3c3-2dbb59af4b54 | -
DisplayText | Sign digests for data | -
Description | Allows an app to sign digests for data without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#informationprotectioncontentwriteall)
### InformationProtectionContent.Write.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 287bd98c-e865-4e8c-bade-1a85523195b9 | -
DisplayText | Create protected content | -
Description | Allows the app to create protected content without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#informationprotectionpolicyread)
### InformationProtectionPolicy.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 4ad84827-5578-4e18-ad7a-86530b12f884
DisplayText | - | Read user sensitivity labels and label policies.
Description | - | Allows an app to read information protection sensitivity labels and label policy settings, on behalf of the signed-in user.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#informationprotectionpolicyreadall)
### InformationProtectionPolicy.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 19da66cb-0fb0-4390-b071-ebc76a349482 | -
DisplayText | Read all published labels and label policies for an organization. | -
Description | Allows an app to read published sensitivity labels and label policy settings for the entire organization or a specific user, without a signed in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#insights-usermetricreadall)
### Insights-UserMetric.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 34cbd96c-d824-4755-90d3-1008ef47efc1 | 7d249730-51a3-4180-8ec1-214f144f1bff
DisplayText | Read all user metrics insights | Read user metrics insights
Description | Allows an app to read all user metrics insights, such as daily and monthly active users, without a signed-in user. | Allows an app to read user metrics insights, such as daily and monthly active users, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#learningassignedcourseread)
### LearningAssignedCourse.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | ac08cdae-e845-41db-adf9-5899a0ec9ef6
DisplayText | - | Read user's assignments
Description | - | Allows the app to read data for the learner's assignments in the organization's directory, on behalf of the signed-in user.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#learningassignedcoursereadall)
### LearningAssignedCourse.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 535e6066-2894-49ef-ab33-e2c6d064bb81 | -
DisplayText | Read all assignments | -
Description | Allows the app to read data for all assignments in the organization's directory, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#learningassignedcoursereadwriteall)
### LearningAssignedCourse.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 236c1cbd-1187-427f-b0f5-b1852454973b | -
DisplayText | Read and write all assignments | -
Description | Allows the app to create, update, read and delete all assignments in the organization's directory, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#learningcontentreadall)
### LearningContent.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 8740813e-d8aa-4204-860e-2a0f8f84dbc8 | ea4c1fd9-6a9f-4432-8e5d-86e06cc0da77
DisplayText | Read all learning content | Read learning content
Description | Allows the app to read all learning content in the organization's directory, without a signed-in user. | Allows the app to read learning content in the organization's directory, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#learningcontentreadwriteall)
### LearningContent.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 444d6fcb-b738-41e5-b103-ac4f2a2628a3 | 53cec1c4-a65f-4981-9dc1-ad75dbf1c077
DisplayText | Manage all learning content | Manage learning content
Description | Allows the app to manage all learning content in the organization's directory, without a signed-in user. | Allows the app to manage learning content in the organization's directory, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#learningproviderread)
### LearningProvider.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | dd8ce36f-9245-45ea-a99e-8ac398c22861
DisplayText | - | Read learning provider
Description | - | Allows the app to read data for the learning provider in the organization's directory, on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#learningproviderreadwrite)
### LearningProvider.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 40c2eb57-abaf-49f5-9331-e90fd01f7130
DisplayText | - | Manage learning provider
Description | - | Allows the app to create, update, read, and delete data for the learning provider in the organization's directory, on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#learningselfinitiatedcourseread)
### LearningSelfInitiatedCourse.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | f6403ef7-4a96-47be-a190-69ba274c3f11
DisplayText | - | Read user's self-initiated courses
Description | - | Allows the app to read data for the learner's self-initiated courses in the organization's directory, on behalf of the signed-in user.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#learningselfinitiatedcoursereadall)
### LearningSelfInitiatedCourse.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 467524fc-ed22-4356-a910-af61191e3503 | -
DisplayText | Read all self-initiated courses | -
Description | Allows the app to read data for all self-initiated courses in the organization's directory, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#learningselfinitiatedcoursereadwriteall)
### LearningSelfInitiatedCourse.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 7654ed61-8965-4025-846a-0856ec02b5b0 | -
DisplayText | Read and write all self-initiated courses | -
Description | Allows the app to create, update, read and delete all self-initiated courses in the organization's directory, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#licenseassignmentreadall)
### LicenseAssignment.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | e2f98668-2877-4f38-a2f4-8202e0717aa1 | f395577a-0960-456b-979f-7228de0c5996
DisplayText | Read all license assignments. | Read all license assignments.
Description | Allows an app to read license assignments for users and groups, without a signed-in user. | Allows an app to read license assignments for users and groups, on behalf of the signed-in user.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#licenseassignmentreadwriteall)
### LicenseAssignment.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 5facf0c1-8979-4e95-abcf-ff3d079771c0 | f55016cc-149c-447e-8f21-7cf3ec1d6350
DisplayText | Manage all license assignments | Manage all license assignments
Description | Allows an app to manage license assignments for users and groups, without a signed-in user. | Allows an app to manage license assignments for users and groups, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#lifecycleworkflows-customextreadall)
### LifecycleWorkflows-CustomExt.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 2cb19e7d-9012-40bf-9a22-69fc776af8b0 | 2973a298-1d69-4f87-8d30-7025f0ec19d7
DisplayText | Read all Lifecycle workflows custom task extensionss | Read all Lifecycle workflows custom task extensions
Description | Allows the app to read all Lifecycle workflows custom task extensions without a signed-in user. | Allows the app to read all Lifecycle workflows custom task extensions on behalf of a signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#lifecycleworkflows-customextreadwriteall)
### LifecycleWorkflows-CustomExt.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 3351c766-bacc-4d93-94fa-f2c8b1986ee7 | ef6bafb1-3019-4a22-a332-103aff92225f
DisplayText | Read and write all Lifecycle workflows custom task extensions | Read and write all Lifecycle workflows custom task extensions
Description | Allows the app to create, update, list, read and delete all Lifecycle workflows custom task extensions without a signed-in user. | Allows the app to create, update, list, read and delete all Lifecycle workflows custom task extensions on behalf of a signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#lifecycleworkflows-reportsreadall)
### LifecycleWorkflows-Reports.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | fe615156-48b5-4c83-b613-e6e31a43c446 | 4d3d7f81-163f-426a-8432-5638d2e82083
DisplayText | Read all Lifecycle workflows reports | Read all Lifecycle workflows reports
Description | Allows the app to read all Lifecycle workflows reports without a signed-in user. | Allows the app to read all Lifecycle workflows reports on behalf of a signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#lifecycleworkflows-workflowactivate)
### LifecycleWorkflows-Workflow.Activate
Expand table
Category | Application | Delegated
---|---|---
Identifier | 3a87a643-13d2-47aa-8d6a-b0a8377cb03b | df1c25b3-072c-45cd-8403-c63441e4cca1
DisplayText | Run workflows on-demand in Lifecycle workflows | Run workflows on-demand in Lifecycle workflows
Description | Allows the app run workflows on-demand without a signed-in user. | Allows the app to run workflows on-demand on behalf of a signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#lifecycleworkflows-workflowreadall)
### LifecycleWorkflows-Workflow.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 03b0ad3e-fc2b-4ef1-b0ff-252e865cb608 | 7fabe5bd-2e47-4e61-b924-327117024e18
DisplayText | Read all workflows in Lifecycle workflows | Read all workflows in Lifecycle workflows
Description | Allows the app to list and read all workflows and tasks without a signed-in user. | Allows the app to list and read all workflows and tasks on behalf of a signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#lifecycleworkflows-workflowreadbasicall)
### LifecycleWorkflows-Workflow.ReadBasic.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 021ea6db-c06b-45c6-8c9c-c1cd9a37a483 | 789c445d-433c-4575-a1fc-367a58a1bd4a
DisplayText | List all workflows in Lifecycle workflows | List all workflows in Lifecycle workflows
Description | Allows the app to list all workflows without a signed-in user. | Allows the app to list all workflows on behalf of a signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#lifecycleworkflows-workflowreadwriteall)
### LifecycleWorkflows-Workflow.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 94c88098-1d9d-4c42-a356-4d5a95312554 | 29e49f0c-a053-4cc5-a4b1-7da0c8c1e643
DisplayText | Read and write all workflows in Lifecycle workflows | Read and write all workflows in Lifecycle workflows
Description | Allows the app to create, update, list, read and delete all workflows and tasks in lifecycle workflows without a signed-in user. | Allows the app to create, update, list, read and delete all workflows and tasks in lifecycle workflows on behalf of a signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#lifecycleworkflowsreadall)
### LifecycleWorkflows.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 7c67316a-232a-4b84-be22-cea2c0906404 | 9bcb9916-765a-42af-bf77-02282e26b01a
DisplayText | Read all lifecycle workflows resources | Read all lifecycle workflows resources
Description | Allows the app to list and read all workflows, tasks and related lifecycle workflows resources without a signed-in user. | Allows the app to list and read all workflows, tasks and related lifecycle workflows resources on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#lifecycleworkflowsreadwriteall)
### LifecycleWorkflows.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 5c505cf4-8424-4b8e-aa14-ee06e3bb23e3 | 84b9d731-7db8-4454-8c90-fd9e95350179
DisplayText | Read and write all lifecycle workflows resources | Read and write all lifecycle workflows resources
Description | Allows the app to create, update, list, read and delete all workflows, tasks and related lifecycle workflows resources without a signed-in user. | Allows the app to create, update, list, read and delete all workflows, tasks and related lifecycle workflows resources on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#listitemsselectedoperationsselected)
### ListItems.SelectedOperations.Selected
Expand table
Category | Application | Delegated
---|---|---
Identifier | de4e4161-a10a-4dfd-809c-e328d89aefeb | d6d361b3-211a-4191-9fa7-15f72de4aac4
DisplayText | Access selected ListItems without a signed in user. | Access selected ListItems, on behalf of the signed-in user
Description | Allow the application to access a subset of listitems without a signed in user. The specific listitems and the permissions granted will be configured in SharePoint Online. | Allow the application to access a subset of listitems on behalf of the signed in user. The specific listitems and the permissions granted will be configured in SharePoint Online.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#listsselectedoperationsselected)
### Lists.SelectedOperations.Selected
Expand table
Category | Application | Delegated
---|---|---
Identifier | 23c5a9bd-d900-4ecf-be26-a0689755d9e5 | 033b51ee-d6fa-4add-b627-ee680c7212b5
DisplayText | Access selected Lists without a signed in user. | Access selected Lists, on behalf of the signed-in user
Description | Allow the application to access a subset of lists without a signed in user. The specific lists and the permissions granted will be configured in SharePoint Online. | Allow the application to access a subset of lists on behalf of the signed in user. The specific lists and the permissions granted will be configured in SharePoint Online.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#mail-advancedreadwrite)
### Mail-Advanced.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | f3af82f6-18e0-4a41-8dc8-a03c11854a8d
DisplayText | - | Read and write the user's mail, including modifying existing non-draft mails
Description | - | Allows the app to create, read, update, and delete email, including contents of non-draft emails in user mailboxes, on behalf of the signed-in user. Does not include permission to send mail.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#mail-advancedreadwriteall)
### Mail-Advanced.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | e118f1da-5c1c-46cf-bff6-8858d786f46f | -
DisplayText | Read and write mail in all mailboxes, including modifying existing non-draft mails | -
Description | Allows the app to create, read, update, and delete all email, including contents of non-draft emails in user mailboxes, without a signed-in user. Does not include permission to send mail. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#mail-advancedreadwriteshared)
### Mail-Advanced.ReadWrite.Shared
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | bebf0bb6-2ff3-4295-a17d-f3561da294fb
DisplayText | - | Read and write all mail the user can access, including modifying existing non-draft mails
Description | - | Allows the app to create, read, update, and delete mail including contents of non-draft emails for all mails a user has permission to access, on behalf of the signed-in user. This includes their own and shared mail. Does not include permission to send mail.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#mailread)
### Mail.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | 810c84a8-4a9e-49e6-bf7d-12d183f40d01 | 570282fd-fa5c-430d-a7fd-fc8dc98a9dca
DisplayText | Read mail in all mailboxes | Read user mail
Description | Allows the app to read mail in all mailboxes without a signed-in user. | Allows the app to read the signed-in user's mailbox.
AdminConsentRequired | Yes | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Mail.Read_ delegated permission is available for consent in personal Microsoft accounts.
Administrators can configure [application access policy](https://learn.microsoft.com/en-us/graph/auth-limit-mailbox-access) to limit app access to _specific_ mailboxes and not to all the mailboxes in the organization, even if the app has been granted the _Mail.Read_ application permission.
_Mail.Read_ is valid valid for both Microsoft accounts and work or school accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#mailreadshared)
### Mail.Read.Shared
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 7b9103a5-4610-446b-9670-80643382c1fa
DisplayText | - | Read user and shared mail
Description | - | Allows the app to read mail a user can access, including their own and shared mail.
AdminConsentRequired | - | No
_Mail.Read.Shared_ is only valid for work or school accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#mailreadbasic)
### Mail.ReadBasic
Expand table
Category | Application | Delegated
---|---|---
Identifier | 6be147d2-ea4f-4b5a-a3fa-3eab6f3c140a | a4b8392a-d8d1-4954-a029-8e668a39a170
DisplayText | Read basic mail in all mailboxes | Read user basic mail
Description | Allows the app to read basic mail properties in all mailboxes without a signed-in user. Includes all properties except body, previewBody, attachments and any extended properties. | Allows the app to read email in the signed-in user's mailbox except body, previewBody, attachments and any extended properties.
AdminConsentRequired | Yes | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Mail.ReadBasic_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#mailreadbasicall)
### Mail.ReadBasic.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 693c5e45-0940-467d-9b8a-1022fb9d42ef | -
DisplayText | Read basic mail in all mailboxes | -
Description | Allows the app to read basic mail properties in all mailboxes without a signed-in user. Includes all properties except body, previewBody, attachments and any extended properties. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#mailreadbasicshared)
### Mail.ReadBasic.Shared
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | b11fa0e7-fdb7-4dc9-b1f1-59facd463480
DisplayText | - | Read user and shared basic mail
Description | - | Allows the app to read mail the signed-in user can access, including their own and shared mail, except for body, bodyPreview, uniqueBody, attachments, extensions, and any extended properties.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#mailreadwrite)
### Mail.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | e2a3a72e-5f79-4c64-b1b1-878b674786c9 | 024d486e-b451-40bb-833d-3e66d98c5c73
DisplayText | Read and write mail in all mailboxes | Read and write access to user mail
Description | Allows the app to create, read, update, and delete mail in all mailboxes without a signed-in user. Does not include permission to send mail. | Allows the app to create, read, update, and delete email in user mailboxes. Does not include permission to send mail.
AdminConsentRequired | Yes | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Mail.ReadWrite_ delegated permission is available for consent in personal Microsoft accounts.
Administrators can configure [application access policy](https://learn.microsoft.com/en-us/graph/auth-limit-mailbox-access) to limit app access to _specific_ mailboxes and not to all the mailboxes in the organization, even if the app has been granted the _Mail.ReadWrite_ application permission.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#mailreadwriteshared)
### Mail.ReadWrite.Shared
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 5df07973-7d5d-46ed-9847-1271055cbd51
DisplayText | - | Read and write user and shared mail
Description | - | Allows the app to create, read, update, and delete mail a user has permission to access, including their own and shared mail. Does not include permission to send mail.
AdminConsentRequired | - | No
_Mail.ReadWrite.Shared_ is only valid for work or school accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#mailsend)
### Mail.Send
Expand table
Category | Application | Delegated
---|---|---
Identifier | b633e1c5-b582-4048-a93e-9f11b44c7e96 | e383f46e-2787-4529-855e-0e479a3ffac0
DisplayText | Send mail as any user | Send mail as a user
Description | Allows the app to send mail as any user without a signed-in user. | Allows the app to send mail as users in the organization.
AdminConsentRequired | Yes | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Mail.Send_ delegated permission is available for consent in personal Microsoft accounts.
Administrators can configure [application access policy](https://learn.microsoft.com/en-us/graph/auth-limit-mailbox-access) to limit app access to _specific_ mailboxes and not to all the mailboxes in the organization, even if the app has been granted the _Mail.Send_ application permission.
_Mail.Send_ is valid valid for both Microsoft accounts and work or school accounts.
With the _Mail.Send_ permission, an app can send mail and save a copy to the user's Sent Items folder, even if the app isn't granted the _Mail.ReadWrite_ or _Mail.ReadWrite.Shared_ permission.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#mailsendshared)
### Mail.Send.Shared
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | a367ab51-6b49-43bf-a716-a1fb06d2a174
DisplayText | - | Send mail on behalf of others
Description | - | Allows the app to send mail as the signed-in user, including sending on-behalf of others.
AdminConsentRequired | - | No
_Mail.Send.Shared_ is only valid for work or school accounts.
With the _Mail.Send.Shared_ permission, an app can send mail and save a copy to the user's Sent Items folder, even if the app isn't granted the _Mail.ReadWrite_ or _Mail.ReadWrite.Shared_ permission.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#mailboxconfigitemread)
### MailboxConfigItem.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | 27d9d776-f4d2-426d-80ad-5f22f2b01b0a | dce2e6fc-0f4b-40da-94e2-14b4477f3d92
DisplayText | Read all users' UserConfiguration objects | Read user's UserConfiguration objects
Description | Allows the app to read all users' UserConfiguration objects. | Allows the app to read user's UserConfiguration objects, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#mailboxconfigitemreadwrite)
### MailboxConfigItem.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | aa6d92d4-b25a-4640-aefe-3e3231e5e736 | 7d461784-7715-4b09-9f90-91a6d8722652
DisplayText | Read and write all users' UserConfiguration objects | Read and write user's UserConfiguration objects
Description | Allows the app to create, read, update and delete all users' UserConfiguration objects. | Allows the app to create, read, update and delete user's UserConfiguration objects, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#mailboxfolderread)
### MailboxFolder.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 52dc2051-4958-4636-8f2a-281d39c6981c
DisplayText | - | Read a user's mailbox folders
Description | - | Allows the app to read the user's mailbox folders, on behalf of the signed-in user.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#mailboxfolderreadall)
### MailboxFolder.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 99280d24-a782-4793-93cc-0888549957f6 | -
DisplayText | Read all the users' mailbox folders | -
Description | Allows the app to read all the users' mailbox folders, without signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#mailboxfolderreadwrite)
### MailboxFolder.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 077fde41-7e0b-4c5b-bcd1-e9d743a30c80
DisplayText | - | Read and write a user's mailbox folders
Description | - | Allows the app to read and write the user's mailbox folders, on behalf of the signed-in user.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#mailboxfolderreadwriteall)
### MailboxFolder.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | fef87b92-8391-4589-9da7-eb93dab7dc8a | -
DisplayText | Read and write all the users' mailbox folders | -
Description | Allows the app to read and write all the users' mailbox folders, without signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#mailboxitemexport)
### MailboxItem.Export
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 58d3e7fa-3ce9-4a0c-9baa-0971f64709d9
DisplayText | - | Export a user's mailbox items
Description | - | Allows the app to export the user's mailbox items, on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#mailboxitemexportall)
### MailboxItem.Export.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 937550e9-33a3-494b-88ae-d9cd394b1fbb | -
DisplayText | Export all the users' mailbox items | -
Description | Allows the app to export all the users' mailbox items, without signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#mailboxitemimportexport)
### MailboxItem.ImportExport
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | df96e8a0-f4e1-4ecf-8d83-a429f822cbd6
DisplayText | - | Allows the app to perform backup and restore of mailbox items
Description | - | Allows the app to backup, restore, and modify mailbox items on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#mailboxitemimportexportall)
### MailboxItem.ImportExport.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 76577085-e73d-4f1d-b26a-85fb33892327 | -
DisplayText | Allows the app to perform backup and restore for all mailbox items | -
Description | Allows the app to backup, restore, and modify all mailbox items without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#mailboxitemread)
### MailboxItem.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 82305458-296d-4edd-8b0b-74dd74c34526
DisplayText | - | Read a user's mailbox items
Description | - | Allows the app to read the user's mailbox items, on behalf of the signed-in user.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#mailboxitemreadall)
### MailboxItem.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 7d9f353d-a7bd-4fbb-822a-26d5dd39a3ce | -
DisplayText | Read all the users' mailbox items | -
Description | Allows the app to read all the users' mailbox items, without signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#mailboxsettingsread)
### MailboxSettings.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | 40f97065-369a-49f4-947c-6a255697ae91 | 87f447af-9fa4-4c32-9dfa-4a57a73d18ce
DisplayText | Read all user mailbox settings | Read user mailbox settings
Description | Allows the app to read user's mailbox settings without a signed-in user. Does not include permission to send mail. | Allows the app to the read user's mailbox settings. Does not include permission to send mail.
AdminConsentRequired | Yes | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _MailboxSettings.Read_ delegated permission is available for consent in personal Microsoft accounts.
Administrators can configure [application access policy](https://learn.microsoft.com/en-us/graph/auth-limit-mailbox-access) to limit app access to _specific_ mailboxes and not to all the mailboxes in the organization, even if the app has been granted the _MailboxSettings.Read_ application permission.
_MailboxSettings.Read_ is valid valid for both Microsoft accounts and work or school accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#mailboxsettingsreadwrite)
### MailboxSettings.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | 6931bccd-447a-43d1-b442-00a195474933 | 818c620a-27a9-40bd-a6a5-d96f7d610b4b
DisplayText | Read and write all user mailbox settings | Read and write user mailbox settings
Description | Allows the app to create, read, update, and delete user's mailbox settings without a signed-in user. Does not include permission to send mail. | Allows the app to create, read, update, and delete user's mailbox settings. Does not include permission to send mail.
AdminConsentRequired | Yes | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _MailboxSettings.ReadWrite_ delegated permission is available for consent in personal Microsoft accounts.
Administrators can configure [application access policy](https://learn.microsoft.com/en-us/graph/auth-limit-mailbox-access) to limit app access to _specific_ mailboxes and not to all the mailboxes in the organization, even if the app has been granted the _MailboxSettings.ReadWrite_ application permission.
_MailboxSettings.ReadWrite_ is valid valid for both Microsoft accounts and work or school accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#managedtenantsreadall)
### ManagedTenants.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | dc34164e-6c4a-41a0-be89-3ae2fbad7cd3
DisplayText | - | Read all managed tenant information
Description | - | Allows the app to read all managed tenant information on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#managedtenantsreadwriteall)
### ManagedTenants.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | b31fa710-c9b3-4d9e-8f5e-8036eecddab9
DisplayText | - | Read and write all managed tenant information
Description | - | Allows the app to read and write all managed tenant information on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#memberreadhidden)
### Member.Read.Hidden
Expand table
Category | Application | Delegated
---|---|---
Identifier | 658aa5d8-239f-45c4-aa12-864f4fc7e490 | f6a3db3e-f7e8-4ed2-a414-557c8c9830be
DisplayText | Read all hidden memberships | Read hidden memberships
Description | Allows the app to read the memberships of hidden groups and administrative units without a signed-in user. | Allows the app to read the memberships of hidden groups and administrative units on behalf of the signed-in user, for those hidden groups and administrative units that the signed-in user has access to.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#multitenantorganizationreadall)
### MultiTenantOrganization.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 4f994bc0-31bb-44bb-b480-7a7c1be8c02e | 526aa72a-5878-49fe-bf4e-357973af9b06
DisplayText | Read all multi-tenant organization details and tenants | Read multi-tenant organization details and tenants
Description | Allows the app to read all multi-tenant organization details and tenants, without a signed-in user. | Allows the app to read multi-tenant organization details and tenants on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#multitenantorganizationreadbasicall)
### MultiTenantOrganization.ReadBasic.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | f9c2b2a7-3895-4b2e-80f6-c924b456e50b | 225db56b-15b2-4daa-acb3-0eec2bbe4849
DisplayText | Read multi-tenant organization basic details and active tenants | Read multi-tenant organization basic details and active tenants
Description | Allows the app to read multi-tenant organization basic details and active tenants, without a signed-in user. | Allows the app to read multi-tenant organization basic details and active tenants on behalf of the signed-in user.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#multitenantorganizationreadwriteall)
### MultiTenantOrganization.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 920def01-ca61-4d2d-b3df-105b46046a70 | 77af1528-84f3-4023-8d90-d219cd433108
DisplayText | Read and write all multi-tenant organization details and tenants | Read and write multi-tenant organization details and tenants
Description | Allows the app to read and write all multi-tenant organization details and tenants, without a signed-in user. | Allows the app to read and write multi-tenant organization details and tenants on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#mutualtlsoauthconfigurationreadall)
### MutualTlsOauthConfiguration.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 6daaff82-2880-496d-9d80-57e8e31195e2 | 51ae584e-e736-4718-897b-10af70f8e3cc
DisplayText | Read all configurations used for mutual-TLS client authentication. | Read all configurations used for mutual-TLS client authentication.
Description | Allows the app to read configuration used for OAuth 2.0 mutual-TLS client authentication, without a signed-in user. This includes reading trusted certificate authorities. | Allows the app to read configuration used for OAuth 2.0 mutual-TLS client authentication, on behalf of the signed-in user. This includes reading trusted certificate authorities.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#mutualtlsoauthconfigurationreadwriteall)
### MutualTlsOauthConfiguration.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 78bbf8cf-07d8-45ba-b0eb-1a7b48efbcf1 | a51115bc-f64f-498f-bcee-00dcd28f4a03
DisplayText | Read and write all configurations used for mutual-TLS client authentication. | Read and write all configurations used for mutual-TLS client authentication.
Description | Allows the app to read and update configuration used for OAuth 2.0 mutual-TLS client authentication, without a signed-in user. This includes reading and updating trusted certificate authorities. | Allows the app to read and update configuration used for OAuth 2.0 mutual-TLS client authentication, on behalf of the signed-in user. This includes adding and updating trusted certificate authorities.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#networkaccess-reportsreadall)
### NetworkAccess-Reports.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 40049381-3cc1-42af-94ec-5ce755db4b0d | b0c61509-cfc3-42bd-9bd4-66d81785fee4
DisplayText | Read all network access reports | Read all network access reports
Description | Allows the app to read all network access reports without a signed-in user. | Allows the app to read all network access reports on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#networkaccessreadall)
### NetworkAccess.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | e30060de-caa5-4331-99d3-6ac6c966a9a4 | 2f7013e0-ab4e-447f-a5e1-5d419950692d
DisplayText | Read all network access information | Read all network access information
Description | Allows the app to read all network access information and configuration settings without a signed-in user. | Allows the app to read all network access information on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#networkaccessreadwriteall)
### NetworkAccess.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | b10642fc-a6cf-4c46-87f9-e1f96c2a18aa | ae2df9c5-f18d-4ec4-a51b-bdeb807f177b
DisplayText | Read and write all network access information | Read and write all network access information
Description | Allows the app to read and write all network access information and configuration settings without a signed-in user. | Allows the app to read and write all network access information and configuration settings on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#networkaccessbranchreadall)
### NetworkAccessBranch.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 39ae4a24-1ef0-49e8-9d63-2a66f5c39edd | 4051c7fc-b429-4804-8d80-8f1f8c24a6f7
DisplayText | Read properties of all branches for network access | Read properties of branches for network access
Description | Allows the app to read your organization's network access branches, without a signed-in user. | Allows the app to read your organization's branches for network access on behalf of the signed-in user.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#networkaccessbranchreadwriteall)
### NetworkAccessBranch.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 8137102d-ec16-4191-aaf8-7aeda8026183 | b8a36cc2-b810-461a-baa4-a7281e50bd5c
DisplayText | Read and write properties of all branches for network access | Read and write properties of branches for network access
Description | Allows the app to read and write your organization's network access branches, without a signed-in user. | Allows the app to read and write your organization's branches for network access on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#networkaccesspolicyreadall)
### NetworkAccessPolicy.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 8a3d36bf-cb46-4bcc-bec9-8d92829dab84 | ba22922b-752c-446f-89d7-a2d92398fceb
DisplayText | Read all security and routing policies for network access | Read security and routing policies for network access
Description | Allows the app to read your organization's network access policies, without a signed-in user. | Allows the app to read your organization's security and routing network access policies on behalf of the signed-in user.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#networkaccesspolicyreadwriteall)
### NetworkAccessPolicy.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | f0c341be-8348-4989-8e43-660324294538 | b1fbad0f-ef6e-42ed-8676-bca7fa3e7291
DisplayText | Read and write all security and routing policies for network access | Read and write security and routing policies for network access
Description | Allows the app to read and write your organization's network access policies, without a signed-in user. | Allows the app to read and write your organization's security and routing network access policies on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#notescreate)
### Notes.Create
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 9d822255-d64d-4b7a-afdb-833b9a97ed02
DisplayText | - | Create user OneNote notebooks
Description | - | Allows the app to read the titles of OneNote notebooks and sections and to create new pages, notebooks, and sections on behalf of the signed-in user.
AdminConsentRequired | - | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Notes.Create_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#notesread)
### Notes.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 371361e4-b9e2-4a3f-8315-2a301a3b0a3d
DisplayText | - | Read user OneNote notebooks
Description | - | Allows the app to read OneNote notebooks on behalf of the signed-in user.
AdminConsentRequired | - | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Notes.Read_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#notesreadall)
### Notes.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 3aeca27b-ee3a-4c2b-8ded-80376e2134a4 | dfabfca6-ee36-4db2-8208-7a28381419b3
DisplayText | Read all OneNote notebooks | Read all OneNote notebooks that user can access
Description | Allows the app to read all the OneNote notebooks in your organization, without a signed-in user. | Allows the app to read OneNote notebooks that the signed-in user has access to in the organization.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#notesreadwrite)
### Notes.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 615e26af-c38a-4150-ae3e-c3b0d4cb1d6a
DisplayText | - | Read and write user OneNote notebooks
Description | - | Allows the app to read, share, and modify OneNote notebooks on behalf of the signed-in user.
AdminConsentRequired | - | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Notes.ReadWrite_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#notesreadwriteall)
### Notes.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 0c458cef-11f3-48c2-a568-c66751c238c0 | 64ac0503-b4fa-45d9-b544-71a463f05da0
DisplayText | Read and write all OneNote notebooks | Read and write all OneNote notebooks that user can access
Description | Allows the app to read all the OneNote notebooks in your organization, without a signed-in user. | Allows the app to read, share, and modify OneNote notebooks that the signed-in user has access to in the organization.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#notesreadwritecreatedbyapp)
### Notes.ReadWrite.CreatedByApp
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | ed68249d-017c-4df5-9113-e684c7f8760b
DisplayText | - | Limited notebook access (deprecated)
Description | - | This is deprecated! Do not use! This permission no longer has any effect. You can safely consent to it. No additional privileges will be granted to the app.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#notificationsreadwritecreatedbyapp)
### Notifications.ReadWrite.CreatedByApp
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 89497502-6e42-46a2-8cb2-427fd3df970a
DisplayText | - | Deliver and manage user notifications for this app
Description | - | Allows the app to deliver its notifications on behalf of signed-in users. Also allows the app to read, update, and delete the user's notification items for this app.
AdminConsentRequired | - | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Notifications.ReadWrite.CreatedByApp_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#offline_access)
### offline_access
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 7427e0e9-2fba-42fe-b0c0-848c9e6a8182
DisplayText | - | Maintain access to data you have given it access to
Description | - | Allows the app to see and update the data you gave it access to, even when users are not currently using the app. This does not give the app any additional permissions.
AdminConsentRequired | - | No
_offline_access_ is an OpenID Connect (OIDC) scope.
You can use the OIDC scopes to specify artifacts that you want returned in Microsoft identity platform authorization and token requests. The Microsoft identity platform v1.0 and v2.0 endpoints support OIDC scopes differently.
With the Microsoft identity platform v1.0 endpoint, only the _openid_ scope is used. You specify it in the _scope_ parameter in an authorization request to return an ID token when you use the OpenID Connect protocol to sign in a user to your app. For more information, see [Microsoft identity platform and OAuth 2.0 authorization code flow](https://learn.microsoft.com/en-us/entra/identity-platform/v2-oauth2-auth-code-flow). To successfully return an ID token, you must also make sure that the _User.Read_ permission is configured when you register your app.
With the Microsoft identity platform v2.0 endpoint, you specify the _offline_access_ scope in the **scope** parameter to explicitly request a refresh token when using the OAuth 2.0 or OpenID Connect protocols. With OpenID Connect, you specify the _openid_ scope to request an ID token. You can also specify the _email_ scope, _profile_ scope, or both to return additional claims in the ID token. You don't need to specify the _User.Read_ permission to return an ID token with the v2.0 endpoint. For more information, see [OpenID Connect scopes](https://learn.microsoft.com/en-us/entra/identity-platform/scopes-oidc#openid-connect-scopes).
The Microsoft Authentication Library (MSAL) currently specifies _offline_access_ , _openid_ , _profile_ , and _email_ by default in authorization and token requests. Therefore, for the default case, if you specify these scopes explicitly, the Microsoft identity platform might return an error.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#onlinemeetingaiinsightreadall)
### OnlineMeetingAiInsight.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | c0cf7895-985f-42d4-a693-b618f36674ad | 166741d6-eeb8-46fe-91f4-817d2af7bc88
DisplayText | Read all AI Insights for online meetings. | Read all AI Insights for online meetings.
Description | Allows the app to read all AI Insights for all online meetings, without a signed-in user. | Allows the app to read all AI Insights for online meetings, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#onlinemeetingaiinsightreadchat)
### OnlineMeetingAiInsight.Read.Chat
Expand table
Category | Application | Delegated
---|---|---
Identifier | 01892c31-3b66-4bcf-b5f5-bf0a03d5ed9f | -
DisplayText | Read all AI Insights for online meetings where the Teams application is installed. | -
Description | Allows the teams-app to read all aiInsights for online meetings where the Teams-app is installed, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#onlinemeetingartifactreadall)
### OnlineMeetingArtifact.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | df01ed3b-eb61-4eca-9965-6b3d789751b2 | 110e5abb-a10c-4b59-8b55-9b4daa4ef743
DisplayText | Read online meeting artifacts | Read user's online meeting artifacts
Description | Allows the app to read online meeting artifacts in your organization, without a signed-in user. | Allows the app to read online meeting artifacts on behalf of the signed-in user.
AdminConsentRequired | Yes | No
Administrators can configure [application access policy](https://learn.microsoft.com/en-us/graph/cloud-communication-online-meeting-application-access-policy) to allow apps to access online meetings on behalf of a user.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#onlinemeetingrecordingreadall)
### OnlineMeetingRecording.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | a4a08342-c95d-476b-b943-97e100569c8d | 190c2bb6-1fdd-4fec-9aa2-7d571b5e1fe3
DisplayText | Read all recordings of online meetings. | Read all recordings of online meetings.
Description | Allows the app to read all recordings of all online meetings, without a signed-in user. | Allows the app to read all recordings of online meetings, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
Administrators can configure [application access policy](https://learn.microsoft.com/en-us/graph/cloud-communication-online-meeting-application-access-policy) to allow apps to access online meetings on behalf of a user.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#onlinemeetingsread)
### OnlineMeetings.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 9be106e1-f4e3-4df5-bdff-e4bc531cbe43
DisplayText | - | Read user's online meetings
Description | - | Allows the app to read online meeting details on behalf of the signed-in user.
AdminConsentRequired | - | No
Administrators can configure [application access policy](https://learn.microsoft.com/en-us/graph/cloud-communication-online-meeting-application-access-policy) to allow apps to access online meetings on behalf of a user.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#onlinemeetingsreadall)
### OnlineMeetings.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | c1684f21-1984-47fa-9d61-2dc8c296bb70 | -
DisplayText | Read online meeting details | -
Description | Allows the app to read online meeting details in your organization, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#onlinemeetingsreadwrite)
### OnlineMeetings.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | a65f2972-a4f8-4f5e-afd7-69ccb046d5dc
DisplayText | - | Read and create user's online meetings
Description | - | Allows the app to read and create online meetings on behalf of the signed-in user.
AdminConsentRequired | - | No
Administrators can configure [application access policy](https://learn.microsoft.com/en-us/graph/cloud-communication-online-meeting-application-access-policy) to allow apps to access online meetings on behalf of a user.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#onlinemeetingsreadwriteall)
### OnlineMeetings.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | b8bb2037-6e08-44ac-a4ea-4674e010e2a4 | -
DisplayText | Read and create online meetings | -
Description | Allows the app to read and create online meetings as an application in your organization. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#onlinemeetingtranscriptreadall)
### OnlineMeetingTranscript.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | a4a80d8d-d283-4bd8-8504-555ec3870630 | 30b87d18-ebb1-45db-97f8-82ccb1f0190c
DisplayText | Read all transcripts of online meetings. | Read all transcripts of online meetings.
Description | Allows the app to read all transcripts of all online meetings, without a signed-in user. | Allows the app to read all transcripts of online meetings, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
Administrators can configure [application access policy](https://learn.microsoft.com/en-us/graph/cloud-communication-online-meeting-application-access-policy) to allow apps to access online meetings on behalf of a user.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#onpremdirectorysynchronizationreadall)
### OnPremDirectorySynchronization.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | bb70e231-92dc-4729-aff5-697b3f04be95 | f6609722-4100-44eb-b747-e6ca0536989d
DisplayText | Read all on-premises directory synchronization information | Read all on-premises directory synchronization information
Description | Allows the app to read all on-premises directory synchronization information for the organization, without a signed-in user. | Allows the app to read all on-premises directory synchronization information for the organization, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#onpremdirectorysynchronizationreadwriteall)
### OnPremDirectorySynchronization.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | c22a92cc-79bf-4bb1-8b6c-e0a05d3d80ce | c2d95988-7604-4ba1-aaed-38a5f82a51c7
DisplayText | Read and write all on-premises directory synchronization information | Read and write all on-premises directory synchronization information
Description | Allows the app to read and write all on-premises directory synchronization information for the organization, without a signed-in user. | Allows the app to read and write all on-premises directory synchronization information for the organization, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#onpremisespublishingprofilesreadwriteall)
### OnPremisesPublishingProfiles.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 0b57845e-aa49-4e6f-8109-ce654fffa618 | 8c4d5184-71c2-4bf8-bb9d-bc3378c9ad42
DisplayText | Manage on-premises published resources | Manage on-premises published resources
Description | Allows the app to create, view, update and delete on-premises published resources, on-premises agents and agent groups, as part of a hybrid identity configuration, without a signed in user. | Allows the app to manage hybrid identity service configuration by creating, viewing, updating and deleting on-premises published resources, on-premises agents and agent groups, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#openid)
### openid
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 37f7f235-527c-4136-accd-4a02d197296e
DisplayText | - | Sign users in
Description | - | Allows users to sign in to the app with their work or school accounts and allows the app to see basic user profile information.
AdminConsentRequired | - | No
_openid_ is an OpenID Connect (OIDC) scope.
You can use the OIDC scopes to specify artifacts that you want returned in Microsoft identity platform authorization and token requests. The Microsoft identity platform v1.0 and v2.0 endpoints support OIDC scopes differently.
With the Microsoft identity platform v1.0 endpoint, only the _openid_ scope is used. You specify it in the _scope_ parameter in an authorization request to return an ID token when you use the OpenID Connect protocol to sign in a user to your app. For more information, see [Microsoft identity platform and OAuth 2.0 authorization code flow](https://learn.microsoft.com/en-us/entra/identity-platform/v2-oauth2-auth-code-flow). To successfully return an ID token, you must also make sure that the _User.Read_ permission is configured when you register your app.
With the Microsoft identity platform v2.0 endpoint, you specify the _offline_access_ scope in the **scope** parameter to explicitly request a refresh token when using the OAuth 2.0 or OpenID Connect protocols. With OpenID Connect, you specify the _openid_ scope to request an ID token. You can also specify the _email_ scope, _profile_ scope, or both to return additional claims in the ID token. You don't need to specify the _User.Read_ permission to return an ID token with the v2.0 endpoint. For more information, see [OpenID Connect scopes](https://learn.microsoft.com/en-us/entra/identity-platform/scopes-oidc#openid-connect-scopes).
The Microsoft Authentication Library (MSAL) currently specifies _offline_access_ , _openid_ , _profile_ , and _email_ by default in authorization and token requests. Therefore, for the default case, if you specify these scopes explicitly, the Microsoft identity platform might return an error.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#organizationreadall)
### Organization.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 498476ce-e0fe-48b0-b801-37ba7e2685c6 | 4908d5b9-3fb2-4b1e-9336-1888b7937185
DisplayText | Read organization information | Read organization information
Description | Allows the app to read the organization and related resources, without a signed-in user. Related resources include things like subscribed skus and tenant branding information. | Allows the app to read the organization and related resources, on behalf of the signed-in user. Related resources include things like subscribed skus and tenant branding information.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#organizationreadwriteall)
### Organization.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 292d869f-3427-49a8-9dab-8c70152b74e9 | 46ca0847-7e6b-426e-9775-ea810a948356
DisplayText | Read and write organization information | Read and write organization information
Description | Allows the app to read and write the organization and related resources, without a signed-in user. Related resources include things like subscribed skus and tenant branding information. | Allows the app to read and write the organization and related resources, on behalf of the signed-in user. Related resources include things like subscribed skus and tenant branding information.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#organizationalbrandingreadall)
### OrganizationalBranding.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | eb76ac34-0d62-4454-b97c-185e4250dc20 | 9082f138-6f02-4f3a-9f4d-5f3c2ce5c688
DisplayText | Read organizational branding information | Read organizational branding information
Description | Allows the app to read the organizational branding information, without a signed-in user. | Allows the app to read the organizational branding information, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#organizationalbrandingreadwriteall)
### OrganizationalBranding.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | d2ebfbc1-a5f8-424b-83a6-56ab5927a73c | 15ce63de-b141-4c9a-a9a5-241bf27c6aaf
DisplayText | Read and write organizational branding information | Read and write organizational branding information
Description | Allows the app to read and write the organizational branding information, without a signed-in user. | Allows the app to read and write the organizational branding information, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#orgcontactreadall)
### OrgContact.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | e1a88a34-94c4-4418-be12-c87b00e26bea | 08432d1b-5911-483c-86df-7980af5cdee0
DisplayText | Read organizational contacts | Read organizational contacts
Description | Allows the app to read all organizational contacts without a signed-in user. These contacts are managed by the organization and are different from a user's personal contacts. | Allows the app to read all organizational contacts on behalf of the signed-in user. These contacts are managed by the organization and are different from a user's personal contacts.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#orgsettings-appsandservicesreadall)
### OrgSettings-AppsAndServices.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 56c84fa9-ea1f-4a15-90f2-90ef41ece2c9 | 1e9b7a7e-4d64-44ff-acf5-2e9651c1519f
DisplayText | Read organization-wide apps and services settings | Read organization-wide apps and services settings
Description | Allows the app to read organization-wide apps and services settings, without a signed-in user. | Allows the app to read organization-wide apps and services settings on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#orgsettings-appsandservicesreadwriteall)
### OrgSettings-AppsAndServices.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 4a8e4191-c1c8-45f8-b801-f9a1a5ee6ad3 | c167b0e7-47c0-48e8-9eee-9892f58018fa
DisplayText | Read and write organization-wide apps and services settings | Read and write organization-wide apps and services settings
Description | Allows the app to read and write organization-wide apps and services settings, without a signed-in user. | Allows the app to read and write organization-wide apps and services settings on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#orgsettings-dynamicsvoicereadall)
### OrgSettings-DynamicsVoice.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | c18ae2dc-d9f3-4495-a93f-18980a0e159f | 9862d930-5aec-4a98-8d4f-7277a8db9bcb
DisplayText | Read organization-wide Dynamics customer voice settings | Read organization-wide Dynamics customer voice settings
Description | Allows the app to read organization-wide Dynamics customer voice settings, without a signed-in user. | Allows the app to read organization-wide Dynamics customer voice settings on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#orgsettings-dynamicsvoicereadwriteall)
### OrgSettings-DynamicsVoice.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | c3f1cc32-8bbd-4ab6-bd33-f270e0d9e041 | 4cea26fb-6967-4234-82c4-c044414743f8
DisplayText | Read and write organization-wide Dynamics customer voice settings | Read and write organization-wide Dynamics customer voice settings
Description | Allows the app to read and write organization-wide Dynamics customer voice settings, without a signed-in user. | Allows the app to read and write organization-wide Dynamics customer voice settings on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#orgsettings-formsreadall)
### OrgSettings-Forms.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 434d7c66-07c6-4b1f-ab21-417cf2cdaaca | 210051a0-1ffc-435c-ae76-02d226d05752
DisplayText | Read organization-wide Microsoft Forms settings | Read organization-wide Microsoft Forms settings
Description | Allows the app to read organization-wide Microsoft Forms settings, without a signed-in user. | Allows the app to read organization-wide Microsoft Forms settings on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#orgsettings-formsreadwriteall)
### OrgSettings-Forms.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 2cb92fee-97a3-4034-8702-24a6f5d0d1e9 | 346c19ff-3fb2-4e81-87a0-bac9e33990c1
DisplayText | Read and write organization-wide Microsoft Forms settings | Read and write organization-wide Microsoft Forms settings
Description | Allows the app to read and write organization-wide Microsoft Forms settings, without a signed-in user. | Allows the app to read and write organization-wide Microsoft Forms settings on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#orgsettings-microsoft365installreadall)
### OrgSettings-Microsoft365Install.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 6cdf1fb1-b46f-424f-9493-07247caa22e2 | 8cbdb9f6-9c2e-451a-814d-ec606e5d0212
DisplayText | Read organization-wide Microsoft 365 apps installation settings | Read organization-wide Microsoft 365 apps installation settings
Description | Allows the app to read organization-wide Microsoft 365 apps installation settings, without a signed-in user. | Allows the app to read organization-wide Microsoft 365 apps installation settings on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#orgsettings-microsoft365installreadwriteall)
### OrgSettings-Microsoft365Install.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 83f7232f-763c-47b2-a097-e35d2cbe1da5 | 1ff35e91-19eb-42d8-aa2d-cc9891127ae5
DisplayText | Read and write organization-wide Microsoft 365 apps installation settings | Read and write organization-wide Microsoft 365 apps installation settings
Description | Allows the app to read and write organization-wide Microsoft 365 apps installation settings, without a signed-in user. | Allows the app to read and write organization-wide Microsoft 365 apps installation settings on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#orgsettings-todoreadall)
### OrgSettings-Todo.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | e4d9cd09-d858-4363-9410-abb96737f0cf | 7ff96f41-f022-45ba-acd8-ef3f03063d6b
DisplayText | Read organization-wide Microsoft To Do settings | Read organization-wide Microsoft To Do settings
Description | Allows the app to read organization-wide Microsoft To Do settings, without a signed-in user. | Allows the app to read organization-wide Microsoft To Do settings on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#orgsettings-todoreadwriteall)
### OrgSettings-Todo.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 5febc9da-e0d0-4576-bd13-ae70b2179a39 | 087502c2-5263-433e-abe3-8f77231a0627
DisplayText | Read and write organization-wide Microsoft To Do settings | Read and write organization-wide Microsoft To Do settings
Description | Allows the app to read and write organization-wide Microsoft To Do settings, without a signed-in user. | Allows the app to read and write organization-wide Microsoft To Do settings on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#partnerbillingreadall)
### PartnerBilling.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 7c3e1994-38ff-4412-a99b-9369f6bb7706 | 8804798e-5934-4e30-8ce3-ef88257cecd4
DisplayText | Read all billing data for your company's tenant | Read all billing data for your company's tenant
Description | Allows the app to read all of billing data from Microsoft for your company's tenant, without a signed-in user. This includes reading billed and unbilled azure usage and invoice reconciliation data. | Allows the app to read all of billing data from Microsoft for your company's tenant, on behalf of the signed-in user. This includes reading billed and unbilled Usage and Invoice reconciliation data.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#partnersecurityreadall)
### PartnerSecurity.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 21ffa320-2e7f-47d3-a466-7ff04d2dd68d | 5567b981-0bf1-4796-9038-0648b46e116d
DisplayText | Read security alerts of customer with CSP relationship | Read security alerts of customer with CSP relationship
Description | Allows the app to read security alerts of customer with CSP relationship, without a signed-in user. | Allows the app to read security alerts of customer with CSP relationship on behalf of the partner signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#partnersecurityreadwriteall)
### PartnerSecurity.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 04a2c935-5b4b-474a-be42-11f53111f271 | 0cd2c1f6-94a1-4075-ab8c-0b1aff2e1ad5
DisplayText | Read security alerts and update status of security alerts of customer with CSP relationship | Read security alerts and update status of security alerts of customer with CSP relationship
Description | Allows the app to read security alerts and update status of alerts of customer with CSP relationship, without a signed-in user. | Allows the app to read security alerts and update status of alerts of customer with CSP relationship on behalf of the partner signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#pendingexternaluserprofilereadall)
### PendingExternalUserProfile.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | bdfb26d9-bb36-49be-9b4c-b8cbf4b05808 | d88fd3fb-53d3-4c1c-8c39-787fcac2ed7a
DisplayText | Read all pending external user profiles | Read pending external user profiles
Description | Allows the app to read available properties of pending external user profiles, without a signed-in user. | Allows the app to read available properties of pending external user profiles, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#pendingexternaluserprofilereadwriteall)
### PendingExternalUserProfile.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 8363c2b8-6ff7-420b-9966-c5884c2d48bc | 93a1fb28-c908-4826-904e-0c74ad352b73
DisplayText | Read and write all pending external user profiles | Read and write pending external user profiles
Description | Allows the app to read and write available properties of pending external user profiles, without a signed-in user. | Allows the app to read and write available properties of pending external user profiles, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#peopleread)
### People.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | ba47897c-39ec-4d83-8086-ee8256fa737d
DisplayText | - | Read users' relevant people lists
Description | - | Allows the app to read a ranked list of relevant people of the signed-in user. The list includes local contacts, contacts from social networking, your organization's directory, and people from recent communications (such as email and Skype).
AdminConsentRequired | - | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _People.Read_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#peoplereadall)
### People.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | b528084d-ad10-4598-8b93-929746b4d7d6 | b89f9189-71a5-4e70-b041-9887f0bc7e4a
DisplayText | Read all users' relevant people lists | Read all users' relevant people lists
Description | Allows the app to read any user's scored list of relevant people, without a signed-in user. The list can include local contacts, contacts from social networking, your organization's directory, and people from recent communications (such as email and Skype). | Allows the app to read a scored list of relevant people of the signed-in user or other users in the signed-in user's organization. The list can include local contacts, contacts from social networking, your organization's directory, and people from recent communications (such as email and Skype).
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#peoplesettingsreadall)
### PeopleSettings.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | ef02f2e7-e22d-4c77-8614-8f765683b86e | ec762c5f-388b-4b16-8693-ac1efbc611bc
DisplayText | Read all tenant-wide people settings | Read tenant-wide people settings
Description | Allows the application to read tenant-wide people settings without a signed-in user. | Allows the application to read tenant-wide people settings on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#peoplesettingsreadwriteall)
### PeopleSettings.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | b6890674-9dd5-4e42-bb15-5af07f541ae1 | e67e6727-c080-415e-b521-e3f35d5248e9
DisplayText | Read and write all tenant-wide people settings | Read and write tenant-wide people settings
Description | Allows the application to read and write tenant-wide people settings without a signed-in user. | Allows the application to read and write tenant-wide people settings on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#placereadall)
### Place.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 913b9306-0ce1-42b8-9137-6a7df690a760 | cb8f45a0-5c2e-4ea1-b803-84b870a7d7ec
DisplayText | Read all company places | Read all company places
Description | Allows the app to read company places (conference rooms and room lists) for calendar events and other applications, without a signed-in user. | Allows the app to read your company's places (conference rooms and room lists) for calendar events and other applications, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#placereadwriteall)
### Place.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 4c06a06a-098a-4063-868e-5dfee3827264
DisplayText | - | Read and write organization places
Description | - | Allows the app to manage organization places (conference rooms and room lists) for calendar events and other applications, on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#placedevicereadall)
### PlaceDevice.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 8b724a84-ceac-4fd9-897e-e31ba8f2d7a3 | 4c7f93d2-6b0b-4e05-91aa-87842f0a2142
DisplayText | Read all workplace devices | Read all workplace devices
Description | Allows the app to read all workplace devices, without a signed-in user. | Allows the app to read all workplace devices, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#placedevicereadwriteall)
### PlaceDevice.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 2d510721-5c4e-43cd-bfdb-ac0f8819fb92 | eafd6a71-e95a-4f8a-bb6e-fb84ab7fbd9e
DisplayText | Read and write all workplace devices | Read and write all workplace devices
Description | Allows the app to read and write all workplace devices, without a signed-in user. | Allows the app to read and write all workplace devices, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#placedevicetelemetryreadwriteall)
### PlaceDeviceTelemetry.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 27fc435f-44e2-4b30-bf3c-e0ce74aed618 | -
DisplayText | Read and write telemetry for all workplace devices. | -
Description | Allows the app to read and write telemetry for all workplace devices, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#policyreadall)
### Policy.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 246dd0d5-5bd0-4def-940b-0421030a5b68 | 572fea84-0151-49b2-9301-11cb16974376
DisplayText | Read your organization's policies | Read your organization's policies
Description | Allows the app to read all your organization's policies without a signed in user. | Allows the app to read your organization's policies on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Policy.Read.All_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#policyreadauthenticationmethod)
### Policy.Read.AuthenticationMethod
Expand table
Category | Application | Delegated
---|---|---
Identifier | 8e3bc81b-d2f3-4b7b-838c-32c88218d2f0 | a6ff13ac-1851-4993-8ca9-a671d70de2d5
DisplayText | Read authentication method policies | Read authentication method policies
Description | Allows the app to read all authentication method policies for the tenant, without a signed-in user. | Allows the app to read the authentication method policies, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#policyreadconditionalaccess)
### Policy.Read.ConditionalAccess
Expand table
Category | Application | Delegated
---|---|---
Identifier | 37730810-e9ba-4e46-b07e-8ca78d182097 | 633e0fce-8c58-4cfb-9495-12bbd5a24f7c
DisplayText | Read your organization's conditional access policies | Read your organization's conditional access policies
Description | Allows the app to read your organization's conditional access policies, without a signed-in user. | Allows the app to read your organization's conditional access policies on behalf of the signed-in user.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#policyreaddeviceconfiguration)
### Policy.Read.DeviceConfiguration
Expand table
Category | Application | Delegated
---|---|---
Identifier | bdba4817-6ba1-4a7c-8a01-be9bc7c242dd | 3616a4b0-6746-49c4-a678-4c237599074d
DisplayText | Read your organization's device configuration policies | Read your organization's device configuration policies
Description | Allows the application to read your organization's device configuration policies without a signed-in user. For example, device registration policy can limit initial provisioning controls using quota restrictions, additional authentication and authorization checks. | Allows the app to read your organization's device configuration policies on behalf of the signed-in user. For example, device registration policy can limit initial provisioning controls using quota restrictions, additional authentication and authorization checks.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#policyreadidentityprotection)
### Policy.Read.IdentityProtection
Expand table
Category | Application | Delegated
---|---|---
Identifier | b21b72f6-4e6a-4533-9112-47eea9f97b28 | d146432f-b803-4ed4-8d42-ba74193a6ede
DisplayText | Read your organization's identity protection policy | Read your organization's identity protection policy
Description | Allows the app to read your organization's identity protection policy without a signed-in user. | Allows the app to read your organization's identity protection policy on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#policyreadpermissiongrant)
### Policy.Read.PermissionGrant
Expand table
Category | Application | Delegated
---|---|---
Identifier | 9e640839-a198-48fb-8b9a-013fd6f6cbcd | 414de6ea-2d92-462f-b120-6e2a809a6d01
DisplayText | Read consent and permission grant policies | Read consent and permission grant policies
Description | Allows the app to read policies related to consent and permission grants for applications, without a signed-in user. | Allows the app to read policies related to consent and permission grants for applications, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#policyreadwriteaccessreview)
### Policy.ReadWrite.AccessReview
Expand table
Category | Application | Delegated
---|---|---
Identifier | 77c863fd-06c0-47ce-a7eb-49773e89d319 | 4f5bc9c8-ea54-4772-973a-9ca119cb0409
DisplayText | Read and write your organization's directory access review default policy | Read and write your organization's directory access review default policy
Description | Allows the app to read and write your organization's directory access review default policy without a signed-in user. | Allows the app to read and write your organization's directory access review default policy on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#policyreadwriteapplicationconfiguration)
### Policy.ReadWrite.ApplicationConfiguration
Expand table
Category | Application | Delegated
---|---|---
Identifier | be74164b-cff1-491c-8741-e671cb536e13 | b27add92-efb2-4f16-84f5-8108ba77985c
DisplayText | Read and write your organization's application configuration policies | Read and write your organization's application configuration policies
Description | Allows the app to read and write your organization's application configuration policies, without a signed-in user. This includes policies such as activityBasedTimeoutPolicy, claimsMappingPolicy, homeRealmDiscoveryPolicy, tokenIssuancePolicy and tokenLifetimePolicy. | Allows the app to read and write your organization's application configuration policies on behalf of the signed-in user. This includes policies such as activityBasedTimeoutPolicy, claimsMappingPolicy, homeRealmDiscoveryPolicy, tokenIssuancePolicy and tokenLifetimePolicy.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#policyreadwriteauthenticationflows)
### Policy.ReadWrite.AuthenticationFlows
Expand table
Category | Application | Delegated
---|---|---
Identifier | 25f85f3c-f66c-4205-8cd5-de92dd7f0cec | edb72de9-4252-4d03-a925-451deef99db7
DisplayText | Read and write authentication flow policies | Read and write authentication flow policies
Description | Allows the app to read and write all authentication flow policies for the tenant, without a signed-in user. | Allows the app to read and write the authentication flow policies, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#policyreadwriteauthenticationmethod)
### Policy.ReadWrite.AuthenticationMethod
Expand table
Category | Application | Delegated
---|---|---
Identifier | 29c18626-4985-4dcd-85c0-193eef327366 | 7e823077-d88e-468f-a337-e18f1f0e6c7c
DisplayText | Read and write all authentication method policies | Read and write authentication method policies
Description | Allows the app to read and write all authentication method policies for the tenant, without a signed-in user. | Allows the app to read and write the authentication method policies, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Policy.ReadWrite.AuthenticationMethod_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#policyreadwriteauthorization)
### Policy.ReadWrite.Authorization
Expand table
Category | Application | Delegated
---|---|---
Identifier | fb221be6-99f2-473f-bd32-01c6a0e9ca3b | edd3c878-b384-41fd-95ad-e7407dd775be
DisplayText | Read and write your organization's authorization policy | Read and write your organization's authorization policy
Description | Allows the app to read and write your organization's authorization policy without a signed in user. For example, authorization policies can control some of the permissions that the out-of-the-box user role has by default. | Allows the app to read and write your organization's authorization policy on behalf of the signed-in user. For example, authorization policies can control some of the permissions that the out-of-the-box user role has by default.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#policyreadwriteconditionalaccess)
### Policy.ReadWrite.ConditionalAccess
Expand table
Category | Application | Delegated
---|---|---
Identifier | 01c0a623-fc9b-48e9-b794-0756f8e8f067 | ad902697-1014-4ef5-81ef-2b4301988e8c
DisplayText | Read and write your organization's conditional access policies | Read and write your organization's conditional access policies
Description | Allows the app to read and write your organization's conditional access policies, without a signed-in user. | Allows the app to read and write your organization's conditional access policies on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#policyreadwriteconsentrequest)
### Policy.ReadWrite.ConsentRequest
Expand table
Category | Application | Delegated
---|---|---
Identifier | 999f8c63-0a38-4f1b-91fd-ed1947bdd1a9 | 4d135e65-66b8-41a8-9f8b-081452c91774
DisplayText | Read and write your organization's consent request policy | Read and write consent request policy
Description | Allows the app to read and write your organization's consent requests policy without a signed-in user. | Allows the app to read and write your organization's consent requests policy on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#policyreadwritecrosstenantaccess)
### Policy.ReadWrite.CrossTenantAccess
Expand table
Category | Application | Delegated
---|---|---
Identifier | 338163d7-f101-4c92-94ba-ca46fe52447c | 014b43d0-6ed4-4fc6-84dc-4b6f7bae7d85
DisplayText | Read and write your organization's cross tenant access policies | Read and write your organization's cross tenant access policies
Description | Allows the app to read and write your organization's cross-tenant access policies and configuration for automatic user consent settings to suppress consent prompts for users of the other tenant on behalf of the signed-in user. | Allows the app to read and write your organization's cross-tenant access policies and configuration for automatic user consent settings to suppress consent prompts for users of the other tenant on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#policyreadwritecrosstenantcapability)
### Policy.ReadWrite.CrossTenantCapability
Expand table
Category | Application | Delegated
---|---|---
Identifier | a6325ae7-2b73-4dbd-abed-fbeacfbf8696 | 9ef7463f-1d39-406f-89ea-3483a4645e1c
DisplayText | Read and write your organization's M365 cross tenant access capabilities | Read and write your organization's M365 cross tenant access capabilities
Description | Allows the app to read and write your organization's M365 cross tenant access capabilities without a signed-in user. | Allows the app to read and write your organization's M365 cross tenant access capabilities on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#policyreadwritedeviceconfiguration)
### Policy.ReadWrite.DeviceConfiguration
Expand table
Category | Application | Delegated
---|---|---
Identifier | 230fb2d5-aa21-49c1-bfa7-ae1be179d867 | 40b534c3-9552-4550-901b-23879c90bcf9
DisplayText | Read and write your organization's device configuration policies | Read and write your organization's device configuration policies
Description | Allows the application to read and write your organization's device configuration policies without a signed-in user. For example, device registration policy can limit initial provisioning controls using quota restrictions, additional authentication and authorization checks. | Allows the app to read and write your organization's device configuration policies on behalf of the signed-in user. For example, device registration policy can limit initial provisioning controls using quota restrictions, additional authentication and authorization checks.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#policyreadwriteexternalidentities)
### Policy.ReadWrite.ExternalIdentities
Expand table
Category | Application | Delegated
---|---|---
Identifier | 03cc4f92-788e-4ede-b93f-199424d144a5 | b5219784-1215-45b5-b3f1-88fe1081f9c0
DisplayText | Read and write your organization's external identities policy | Read and write your organization's external identities policy
Description | Allows the application to read and update the organization's external identities policy without a signed-in user. For example, external identities policy controls if users invited to access resources in your organization via B2B collaboration or B2B direct connect are allowed to self-service leave. | Allows the application to read and update the organization's external identities policy on behalf of the signed-in user. For example, external identities policy controls if users invited to access resources in your organization via B2B collaboration or B2B direct connect are allowed to self-service leave.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#policyreadwritefeaturerollout)
### Policy.ReadWrite.FeatureRollout
Expand table
Category | Application | Delegated
---|---|---
Identifier | 2044e4f1-e56c-435b-925c-44cd8f6ba89a | 92a38652-f13b-4875-bc77-6e1dbb63e1b2
DisplayText | Read and write feature rollout policies | Read and write your organization's feature rollout policies
Description | Allows the app to read and write feature rollout policies without a signed-in user. Includes abilities to assign and remove users and groups to rollout of a specific feature. | Allows the app to read and write your organization's feature rollout policies on behalf of the signed-in user. Includes abilities to assign and remove users and groups to rollout of a specific feature.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#policyreadwritefedtokenvalidation)
### Policy.ReadWrite.FedTokenValidation
Expand table
Category | Application | Delegated
---|---|---
Identifier | 90bbca0b-227c-4cdc-8083-1c6cfb95bac6 | be1be369-4540-4ac9-8928-79de99f70d8f
DisplayText | Read and write your organization's federated token validation policy | Read and write your organization's federated token validation policy
Description | Allows the application to read and update the organization's federated token validation policy without a signed-in user. | Allows the application to read and update the organization's federated token validation policy on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#policyreadwriteidentityprotection)
### Policy.ReadWrite.IdentityProtection
Expand table
Category | Application | Delegated
---|---|---
Identifier | 2dcf8603-09eb-4078-b1ec-d30a1a76b873 | 7256e131-3efb-4323-9854-cf41c6021770
DisplayText | Read and write your organization's identity protection policy | Read and write your organization's identity protection policy
Description | Allows the app to read and write your organization's identity protection policy without a signed-in user. | Allows the app to read and write your organization's identity protection policy on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#policyreadwritemobilitymanagement)
### Policy.ReadWrite.MobilityManagement
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | a8ead177-1889-4546-9387-f25e658e2a79
DisplayText | - | Read and write your organization's mobility management policies
Description | - | Allows the app to read and write your organization's mobility management policies on behalf of the signed-in user. For example, a mobility management policy can set the enrollment scope for a given mobility management application.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#policyreadwritepermissiongrant)
### Policy.ReadWrite.PermissionGrant
Expand table
Category | Application | Delegated
---|---|---
Identifier | a402ca1c-2696-4531-972d-6e5ee4aa11ea | 2672f8bb-fd5e-42e0-85e1-ec764dd2614e
DisplayText | Manage consent and permission grant policies | Manage consent and permission grant policies
Description | Allows the app to manage policies related to consent and permission grants for applications, without a signed-in user. | Allows the app to manage policies related to consent and permission grants for applications, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#policyreadwritesecuritydefaults)
### Policy.ReadWrite.SecurityDefaults
Expand table
Category | Application | Delegated
---|---|---
Identifier | 1c6e93a6-28e2-4cbb-9f64-1a46a821124d | 0b2a744c-2abf-4f1e-ad7e-17a087e2be99
DisplayText | Read and write your organization's security defaults policy | Read and write your organization's security defaults policy
Description | Allows the app to read and write your organization's security defaults policy, without a signed-in user. | Allows the app to read and write your organization's security defaults policy on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#policyreadwritetrustframework)
### Policy.ReadWrite.TrustFramework
Expand table
Category | Application | Delegated
---|---|---
Identifier | 79a677f7-b79d-40d0-a36a-3e6f8688dd7a | cefba324-1a70-4a6e-9c1d-fd670b7ae392
DisplayText | Read and write your organization's trust framework policies | Read and write your organization's trust framework policies
Description | Allows the app to read and write your organization's trust framework policies without a signed in user. | Allows the app to read and write your organization's trust framework policies on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#popaccessasuserall)
### POP.AccessAsUser.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | d7b7f2d9-0f45-4ea1-9d42-e50810c06991
DisplayText | - | Read and write access to mailboxes via POP.
Description | - | Allows the app to have the same access to mailboxes as the signed-in user via POP protocol.
AdminConsentRequired | - | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _POP.AccessAsUser.All_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#presenceread)
### Presence.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 76bc735e-aecd-4a1d-8b4c-2b915deabb79
DisplayText | - | Read user's presence information
Description | - | Allows the app to read presence information on behalf of the signed-in user. Presence information includes activity, availability, status note, calendar out-of-office message, timezone and location.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#presencereadall)
### Presence.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | a70e0c2d-e793-494c-94c4-118fa0a67f42 | 9c7a330d-35b3-4aa1-963d-cb2b9f927841
DisplayText | Read presence information for all users | Read presence information of all users in your organization
Description | Allows the app to read presence information of all users in the directory without a signed-in user. Presence information includes activity, availability, status note, calendar out-of-office message, timezone and location. | Allows the app to read presence information of all users in the directory on behalf of the signed-in user. Presence information includes activity, availability, status note, calendar out-of-office message, timezone and location.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#presencereadwrite)
### Presence.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 8d3c54a7-cf58-4773-bf81-c0cd6ad522bb
DisplayText | - | Read and write a user's presence information
Description | - | Allows the app to read the presence information and write activity and availability on behalf of the signed-in user. Presence information includes activity, availability, status note, calendar out-of-office message, timezone and location.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#presencereadwriteall)
### Presence.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 83cded22-8297-4ff6-a7fa-e97e9545a259 | -
DisplayText | Read and write presence information for all users | -
Description | Allows the app to read all presence information and write activity and availability of all users in the directory without a signed-in user. Presence information includes activity, availability, status note, calendar out-of-office message, time zone and location. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#printconnectorreadall)
### PrintConnector.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | d69c2d6d-4f72-4f99-a6b9-663e32f8cf68
DisplayText | - | Read print connectors
Description | - | Allows the application to read print connectors on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#printconnectorreadwriteall)
### PrintConnector.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 79ef9967-7d59-4213-9c64-4b10687637d8
DisplayText | - | Read and write print connectors
Description | - | Allows the application to read and write print connectors on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#printercreate)
### Printer.Create
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 90c30bed-6fd1-4279-bf39-714069619721
DisplayText | - | Register printers
Description | - | Allows the application to create (register) printers on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#printerfullcontrolall)
### Printer.FullControl.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 93dae4bd-43a1-4a23-9a1a-92957e1d9121
DisplayText | - | Register, read, update, and unregister printers
Description | - | Allows the application to create (register), read, update, and delete (unregister) printers on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#printerreadall)
### Printer.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 9709bb33-4549-49d4-8ed9-a8f65e45bb0f | 3a736c8a-018e-460a-b60c-863b2683e8bf
DisplayText | Read printers | Read printers
Description | Allows the application to read printers without a signed-in user. | Allows the application to read printers on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#printerreadwriteall)
### Printer.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | f5b3f73d-6247-44df-a74c-866173fddab0 | 89f66824-725f-4b8f-928e-e1c5258dc565
DisplayText | Read and update printers | Read and update printers
Description | Allows the application to read and update printers without a signed-in user. Does not allow creating (registering) or deleting (unregistering) printers. | Allows the application to read and update printers on behalf of the signed-in user. Does not allow creating (registering) or deleting (unregistering) printers.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#printersharereadall)
### PrinterShare.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | ed11134d-2f3f-440d-a2e1-411efada2502
DisplayText | - | Read printer shares
Description | - | Allows the application to read printer shares on behalf of the signed-in user.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#printersharereadbasicall)
### PrinterShare.ReadBasic.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 5fa075e9-b951-4165-947b-c63396ff0a37
DisplayText | - | Read basic information about printer shares
Description | - | Allows the application to read basic information about printer shares on behalf of the signed-in user. Does not allow reading access control information.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#printersharereadwriteall)
### PrinterShare.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 06ceea37-85e2-40d7-bec3-91337a46038f
DisplayText | - | Read and write printer shares
Description | - | Allows the application to read and update printer shares on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#printjobcreate)
### PrintJob.Create
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 21f0d9c0-9f13-48b3-94e0-b6b231c7d320
DisplayText | - | Create print jobs
Description | - | Allows the application to create print jobs on behalf of the signed-in user and upload document content to print jobs that the signed-in user created.
AdminConsentRequired | - | No
In this to _PrintJob.Create_ , the app requires at least the _Printer.Read.All_ (or a more prviliged permission) because print jobs are stored within printers.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#printjobmanageall)
### PrintJob.Manage.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 58a52f47-9e36-4b17-9ebe-ce4ef7f3e6c8 | -
DisplayText | Perform advanced operations on print jobs | -
Description | Allows the application to perform advanced operations like redirecting a print job to another printer without a signed-in user. Also allows the application to read and update the metadata of print jobs. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#printjobread)
### PrintJob.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 248f5528-65c0-4c88-8326-876c7236df5e
DisplayText | - | Read user's print jobs
Description | - | Allows the application to read the metadata and document content of print jobs that the signed-in user created.
AdminConsentRequired | - | No
In this to _PrintJob.Read_ , the app requires at least the _Printer.Read.All_ (or a more prviliged permission) because print jobs are stored within printers.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#printjobreadall)
### PrintJob.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | ac6f956c-edea-44e4-bd06-64b1b4b9aec9 | afdd6933-a0d8-40f7-bd1a-b5d778e8624b
DisplayText | Read print jobs | Read print jobs
Description | Allows the application to read the metadata and document content of print jobs without a signed-in user. | Allows the application to read the metadata and document content of print jobs on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
In this to _PrintJob.Read.All_ , the app requires at least the _Printer.Read.All_ (or a more prviliged permission) because print jobs are stored within printers.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#printjobreadbasic)
### PrintJob.ReadBasic
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 6a71a747-280f-4670-9ca0-a9cbf882b274
DisplayText | - | Read basic information of user's print jobs
Description | - | Allows the application to read the metadata of print jobs that the signed-in user created. Does not allow access to print job document content.
AdminConsentRequired | - | No
In this to _PrintJob.ReadBasic_ , the app requires at least the _Printer.Read.All_ (or a more prviliged permission) because print jobs are stored within printers.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#printjobreadbasicall)
### PrintJob.ReadBasic.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | fbf67eee-e074-4ef7-b965-ab5ce1c1f689 | 04ce8d60-72ce-4867-85cf-6d82f36922f3
DisplayText | Read basic information for print jobs | Read basic information of print jobs
Description | Allows the application to read the metadata of print jobs without a signed-in user. Does not allow access to print job document content. | Allows the application to read the metadata of print jobs on behalf of the signed-in user. Does not allow access to print job document content.
AdminConsentRequired | Yes | Yes
In this to _PrintJob.ReadBasic.All_ , the app requires at least the _Printer.Read.All_ (or a more prviliged permission) because print jobs are stored within printers.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#printjobreadwrite)
### PrintJob.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | b81dd597-8abb-4b3f-a07a-820b0316ed04
DisplayText | - | Read and write user's print jobs
Description | - | Allows the application to read and update the metadata and document content of print jobs that the signed-in user created.
AdminConsentRequired | - | No
In this to _PrintJob.ReadWrite_ , the app requires at least the _Printer.Read.All_ (or a more prviliged permission) because print jobs are stored within printers.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#printjobreadwriteall)
### PrintJob.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 5114b07b-2898-4de7-a541-53b0004e2e13 | 036b9544-e8c5-46ef-900a-0646cc42b271
DisplayText | Read and write print jobs | Read and write print jobs
Description | Allows the application to read and update the metadata and document content of print jobs without a signed-in user. | Allows the application to read and update the metadata and document content of print jobs on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
In this to _PrintJob.ReadWrite.All_ , the app requires at least the _Printer.Read.All_ (or a more prviliged permission) because print jobs are stored within printers.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#printjobreadwritebasic)
### PrintJob.ReadWriteBasic
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 6f2d22f2-1cb6-412c-a17c-3336817eaa82
DisplayText | - | Read and write basic information of user's print jobs
Description | - | Allows the application to read and update the metadata of print jobs that the signed-in user created. Does not allow access to print job document content.
AdminConsentRequired | - | No
In this to _PrintJob.ReadWriteBasic_ , the app requires at least the _Printer.Read.All_ (or a more prviliged permission) because print jobs are stored within printers.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#printjobreadwritebasicall)
### PrintJob.ReadWriteBasic.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 57878358-37f4-4d3a-8c20-4816e0d457b1 | 3a0db2f6-0d2a-4c19-971b-49109b19ad3d
DisplayText | Read and write basic information for print jobs | Read and write basic information of print jobs
Description | Allows the application to read and update the metadata of print jobs without a signed-in user. Does not allow access to print job document content. | Allows the application to read and update the metadata of print jobs on behalf of the signed-in user. Does not allow access to print job document content.
AdminConsentRequired | Yes | Yes
In this to _PrintJob.ReadWriteBasic.All_ , the app requires at least the _Printer.Read.All_ (or a more prviliged permission) because print jobs are stored within printers.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#printsettingsreadall)
### PrintSettings.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | b5991872-94cf-4652-9765-29535087c6d8 | 490f32fd-d90f-4dd7-a601-ff6cdc1a3f6c
DisplayText | Read tenant-wide print settings | Read tenant-wide print settings
Description | Allows the application to read tenant-wide print settings without a signed-in user. | Allows the application to read tenant-wide print settings on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#printsettingsreadwriteall)
### PrintSettings.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 9ccc526a-c51c-4e5c-a1fd-74726ef50b8f
DisplayText | - | Read and write tenant-wide print settings
Description | - | Allows the application to read and write tenant-wide print settings on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#printtaskdefinitionreadwriteall)
### PrintTaskDefinition.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 456b71a7-0ee0-4588-9842-c123fcc8f664 | -
DisplayText | Read, write and update print task definitions | -
Description | Allows the application to read and update print task definitions without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#privilegedaccessreadazuread)
### PrivilegedAccess.Read.AzureAD
Expand table
Category | Application | Delegated
---|---|---
Identifier | 4cdc2547-9148-4295-8d11-be0db1391d6b | b3a539c9-59cb-4ad5-825a-041ddbdc2bdb
DisplayText | Read privileged access to Azure AD roles | Read privileged access to Azure AD
Description | Allows the app to read time-based assignment and just-in-time elevation (including scheduled elevation) of Azure AD built-in and custom administrative roles in your organization, without a signed-in user. | Allows the app to read time-based assignment and just-in-time elevation (including scheduled elevation) of Azure AD built-in and custom administrative roles, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#privilegedaccessreadazureadgroup)
### PrivilegedAccess.Read.AzureADGroup
Expand table
Category | Application | Delegated
---|---|---
Identifier | 01e37dc9-c035-40bd-b438-b2879c4870a6 | d329c81c-20ad-4772-abf9-3f6fdb7e5988
DisplayText | Read privileged access to Azure AD groups | Read privileged access to Azure AD groups
Description | Allows the app to read time-based assignment and just-in-time elevation (including scheduled elevation) of Azure AD groups in your organization, without a signed-in user. | Allows the app to read time-based assignment and just-in-time elevation (including scheduled elevation) of Azure AD groups, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#privilegedaccessreadazureresources)
### PrivilegedAccess.Read.AzureResources
Expand table
Category | Application | Delegated
---|---|---
Identifier | 5df6fe86-1be0-44eb-b916-7bd443a71236 | 1d89d70c-dcac-4248-b214-903c457af83a
DisplayText | Read privileged access to Azure resources | Read privileged access to Azure resources
Description | Allows the app to read time-based assignment and just-in-time elevation of user privileges to audit Azure resources in your organization, without a signed-in user. | Allows the app to read time-based assignment and just-in-time elevation of Azure resources (like your subscriptions, resource groups, storage, compute) on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#privilegedaccessreadwriteazuread)
### PrivilegedAccess.ReadWrite.AzureAD
Expand table
Category | Application | Delegated
---|---|---
Identifier | 854d9ab1-6657-4ec8-be45-823027bcd009 | 3c3c74f5-cdaa-4a97-b7e0-4e788bfcfb37
DisplayText | Read and write privileged access to Azure AD roles | Read and write privileged access to Azure AD
Description | Allows the app to request and manage time-based assignment and just-in-time elevation (including scheduled elevation) of Azure AD built-in and custom administrative roles in your organization, without a signed-in user. | Allows the app to request and manage just in time elevation (including scheduled elevation) of users to Azure AD built-in administrative roles, on behalf of signed-in users.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#privilegedaccessreadwriteazureadgroup)
### PrivilegedAccess.ReadWrite.AzureADGroup
Expand table
Category | Application | Delegated
---|---|---
Identifier | 2f6817f8-7b12-4f0f-bc18-eeaf60705a9e | 32531c59-1f32-461f-b8df-6f8a3b89f73b
DisplayText | Read and write privileged access to Azure AD groups | Read and write privileged access to Azure AD groups
Description | Allows the app to request and manage time-based assignment and just-in-time elevation (including scheduled elevation) of Azure AD groups in your organization, without a signed-in user. | Allows the app to request and manage time-based assignment and just-in-time elevation (including scheduled elevation) of Azure AD groups, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#privilegedaccessreadwriteazureresources)
### PrivilegedAccess.ReadWrite.AzureResources
Expand table
Category | Application | Delegated
---|---|---
Identifier | 6f9d5abc-2db6-400b-a267-7de22a40fb87 | a84a9652-ffd3-496e-a991-22ba5529156a
DisplayText | Read and write privileged access to Azure resources | Read and write privileged access to Azure resources
Description | Allows the app to request and manage time-based assignment and just-in-time elevation of Azure resources (like your subscriptions, resource groups, storage, compute) in your organization, without a signed-in user. | Allows the app to request and manage time-based assignment and just-in-time elevation of user privileges to manage Azure resources (like subscriptions, resource groups, storage, compute) on behalf of the signed-in users.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#privilegedassignmentschedulereadazureadgroup)
### PrivilegedAssignmentSchedule.Read.AzureADGroup
Expand table
Category | Application | Delegated
---|---|---
Identifier | cd4161cb-f098-48f8-a884-1eda9a42434c | 02a32cc4-7ab5-4b58-879a-0586e0f7c495
DisplayText | Read assignment schedules for access to Azure AD groups | Read assignment schedules for access to Azure AD groups
Description | Allows the app to read time-based assignment schedules for access to Azure AD groups, without a signed-in user. | Allows the app to read time-based assignment schedules for access to Azure AD groups, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#privilegedassignmentschedulereadwriteazureadgroup)
### PrivilegedAssignmentSchedule.ReadWrite.AzureADGroup
Expand table
Category | Application | Delegated
---|---|---
Identifier | 41202f2c-f7ab-45be-b001-85c9728b9d69 | 06dbc45d-6708-4ef0-a797-f797ee68bf4b
DisplayText | Read, create, and delete assignment schedules for access to Azure AD groups | Read, create, and delete assignment schedules for access to Azure AD groups
Description | Allows the app to read, create, and delete time-based assignment schedules for access to Azure AD groups, without a signed-in user. | Allows the app to read, create, and delete time-based assignment schedules for access to Azure AD groups, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#privilegedassignmentscheduleremoveazureadgroup)
### PrivilegedAssignmentSchedule.Remove.AzureADGroup
Expand table
Category | Application | Delegated
---|---|---
Identifier | 55d1104b-3821-413d-b3ca-e2393d333cd3 | ca5fe595-68ff-4dfd-907d-4509501a0e49
DisplayText | Delete assignment schedules for access to Azure AD groups | Delete assignment schedules for access to Azure AD groups
Description | Delete time-based assignment schedules for access to Azure AD groups, without a signed-in user. | Allows the app to delete time-based assignment schedules for access to Azure AD groups, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#privilegedeligibilityschedulereadazureadgroup)
### PrivilegedEligibilitySchedule.Read.AzureADGroup
Expand table
Category | Application | Delegated
---|---|---
Identifier | edb419d6-7edc-42a3-9345-509bfdf5d87c | 8f44f93d-ecef-46ae-a9bf-338508d44d6b
DisplayText | Read eligibility schedules for access to Azure AD groups | Read eligibility schedules for access to Azure AD groups
Description | Allows the app to read time-based eligibility schedules for access to Azure AD groups, without a signed-in user. | Allows the app to read time-based eligibility schedules for access to Azure AD groups, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#privilegedeligibilityschedulereadwriteazureadgroup)
### PrivilegedEligibilitySchedule.ReadWrite.AzureADGroup
Expand table
Category | Application | Delegated
---|---|---
Identifier | 618b6020-bca8-4de6-99f6-ef445fa4d857 | ba974594-d163-484e-ba39-c330d5897667
DisplayText | Read, create, and delete eligibility schedules for access to Azure AD groups | Read, create, and delete eligibility schedules for access to Azure AD groups
Description | Allows the app to read, create, and delete time-based eligibility schedules for access to Azure AD groups, without a signed-in user. | Allows the app to read, create, and delete time-based eligibility schedules for access to Azure AD groups, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#privilegedeligibilityscheduleremoveazureadgroup)
### PrivilegedEligibilitySchedule.Remove.AzureADGroup
Expand table
Category | Application | Delegated
---|---|---
Identifier | 55745561-7572-4314-a737-a2c2a1b0dd2e | c5ea9ab4-9b41-4c09-a400-53e652fb5096
DisplayText | Delete eligibility schedules for access to Azure AD groups | Delete eligibility schedules for access to Azure AD groups
Description | Delete time-based eligibility schedules for access to Azure AD groups, without a signed-in user. | Allows the app to delete time-based eligibility schedules for access to Azure AD groups, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#profile)
### profile
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 14dad69e-099b-42c9-810b-d002981feec1
DisplayText | - | View users' basic profile
Description | - | Allows the app to see your users' basic profile (e.g., name, picture, user name, email address)
AdminConsentRequired | - | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _profile_ delegated permission is available for consent in personal Microsoft accounts.
_profile_ is an OpenID Connect (OIDC) scope.
You can use the OIDC scopes to specify artifacts that you want returned in Azure AD authorization and token requests. They are supported differently by the Azure AD v1.0 and v2.0 endpoints.
With the Azure AD v1.0 endpoint, only the _openid_ scope is used. You specify it in the _scope_ parameter in an authorization request to return an ID token when you use the OpenID Connect protocol to sign in a user to your app. For more information, see [Authorize access to web applications using OpenID Connect and Azure Active Directory](https://learn.microsoft.com/en-us/azure/active-directory/develop/active-directory-protocols-openid-connect-code). To successfully return an ID token, you must also make sure that the _User.Read_ permission is configured when you register your app.
With the Azure AD v2.0 endpoint, you specify the _offline_access_ scope in the _scope_ parameter to explicitly request a refresh token when using the OAuth 2.0 or OpenID Connect protocols. With OpenID Connect, you specify the _openid_ scope to request an ID token. You can also specify the _email_ scope, _profile_ scope, or both to return additional claims in the ID token. You do not need to specify the _User.Read_ permission to return an ID token with the v2.0 endpoint. For more information, see [OpenID Connect scopes](https://learn.microsoft.com/en-us/azure/active-directory/develop/scopes-oidc#openid-connect-scopes).
The Microsoft Authentication Library (MSAL) currently specifies _offline_access_ , _openid_ , _profile_ , and _email_ by default in authorization and token requests. This means that, for the default case, if you specify these scopes explicitly, Azure AD may return an error.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#profilephotoreadall)
### ProfilePhoto.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | e24d31aa-e1ab-4c80-85fe-23018690335d | 469cd065-729e-4dee-b1fa-d92e0fab6310
DisplayText | Read profile photo of a user or group | Read profile photo of a user or group
Description | Allows the app to read all profile photos of users and groups, without a signed-in user | Allows the app to read all profile photos of users and groups, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#profilephotoreadwriteall)
### ProfilePhoto.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 27baa7f6-5dfb-4ba8-b1d3-1e812c143013 | f5b24df7-511e-48bb-ae88-643f023b55e1
DisplayText | Read and write profile photo of a user or group | Read and write profile photo of a user or group
Description | Allows the app to read and write all profile photos of users and groups, without a signed-in user | Allows the app to read and write all profile photos of users and groups, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#programcontrolreadall)
### ProgramControl.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | eedb7fdd-7539-4345-a38b-4839e4a84cbd | c492a2e1-2f8f-4caa-b076-99bbf6e40fe4
DisplayText | Read all programs | Read all programs that user can access
Description | Allows the app to read programs and program controls in the organization, without a signed-in user. | Allows the app to read programs and program controls that the signed-in user has access to in the organization.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#programcontrolreadwriteall)
### ProgramControl.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 60a901ed-09f7-4aa5-a16e-7dd3d6f9de36 | 50fd364f-9d93-4ae1-b170-300e87cccf84
DisplayText | Manage all programs | Manage all programs that user can access
Description | Allows the app to read, update, delete and perform actions on programs and program controls in the organization, without a signed-in user. | Allows the app to read, update, delete and perform actions on programs and program controls that the signed-in user has access to in the organization.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#protectionscopescomputeall)
### ProtectionScopes.Compute.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | e5a76501-dbb0-492c-ab55-5d09e8837263 | 98f5a27a-539a-48bc-a597-f78e9e1e76bf
DisplayText | Compute Purview policies at tenant scope | Compute Purview policies at tenant scope
Description | Allows the app to identify Purview data protection, compliance and governance policy scopes defined for all users across tenant. | Allows the app to identify Purview data protection, compliance and governance policy scopes defined for all users across tenant.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#protectionscopescomputeuser)
### ProtectionScopes.Compute.User
Expand table
Category | Application | Delegated
---|---|---
Identifier | fe696d63-5e1f-4515-8232-cccc316903c6 | 4fc04d16-a9fc-4c5e-8da4-79b6c33638a4
DisplayText | Compute Purview policies for an individual user | Compute Purview policies for an individual user
Description | Allows the app to identify Purview data protection, compliance and governance policy scopes defined for an individual user. | Allows the app to identify Purview data protection, compliance and governance policy scopes defined for an individual user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#provisioninglogreadall)
### ProvisioningLog.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 091937d3-3e38-47a1-8649-b2f99d3035f1 | 95aec97b-cf27-4a8d-a67d-42f60b5b38ef
DisplayText | Read all provisioning log data | Read provisioning log data
Description | Allows the app to read and query your provisioning log activities, without a signed-in user. | Allows the app to read and query your provisioning log activities, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#publickeyinfrastructurereadall)
### PublicKeyInfrastructure.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 214fda0c-514a-4650-b037-b562b1a66124 | 04a4b2a2-3f26-4fc8-87ee-9c46e68db175
DisplayText | Read all certificate based authentication configurations | Read certificate based authentication configurations
Description | Allows the application to read certificate-based authentication configuration such as all public key infrastructures (PKI) and certificate authorities (CA) configured for the organization, without a signed-in user. | Allows the application to read certificate-based authentication configuration such as all public key infrastructures (PKI) and certificate authorities (CA) configured for the organization, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#publickeyinfrastructurereadwriteall)
### PublicKeyInfrastructure.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | a2b63618-5350-462d-b1b3-ba6eb3684e26 | 3591b7f3-dba8-4bad-b667-7a64bd4f2b83
DisplayText | Read and write all certificate based authentication configurations | Read and write certificate based authentication configurations
Description | Allows the application to read and write certificate-based authentication configuration such as all public key infrastructures (PKI) and certificate authorities (CA) configured for the organization, without a signed-in user. | Allows the application to read and write certificate-based authentication configuration such as all public key infrastructures (PKI) and certificate authorities (CA) configured for the organization, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#qnareadall)
### QnA.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | ee49e170-1dd1-4030-b44c-61ad6e98f743 | f73fa04f-b9a5-4df9-8843-993ce928925e
DisplayText | Read all Question and Answers | Read all Questions and Answers that the user can access.
Description | Allows an app to read all question and answers, without a signed-in user. | Allows an app to read all question and answer sets that the signed-in user can access.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#realtimeactivityfeedreadall)
### RealTimeActivityFeed.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | abafe00f-ea87-4c63-b8a8-0e7bb0a88144 | db5d5bae-0c9e-444e-9390-8a5fea98c253
DisplayText | Access real-time enriched data in a meeting as an app | Access real-time enriched data in a meeting
Description | Allows the app to get direct access to real-time enriched data in a meeting, without a signed-in user. | Allows the app to get direct access to real-time enriched data in a meeting, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#recordsmanagementreadall)
### RecordsManagement.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | ac3a2b8e-03a3-4da9-9ce0-cbe28bf1accd | 07f995eb-fc67-4522-ad66-2b8ca8ea3efd
DisplayText | Read Records Management configuration, labels and policies | Read Records Management configuration, labels, and policies
Description | Allows the application to read any data from Records Management, such as configuration, labels, and policies without the signed in user. | Allows the application to read any data from Records Management, such as configuration, labels, and policies on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#recordsmanagementreadwriteall)
### RecordsManagement.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | eb158f57-df43-4751-8b21-b8932adb3d34 | f2833d75-a4e6-40ab-86d4-6dfe73c97605
DisplayText | Read and write Records Management configuration, labels and policies | Read and write Records Management configuration, labels, and policies
Description | Allow the application to create, update and delete any data from Records Management, such as configuration, labels, and policies without the signed in user. | Allow the application to create, update and delete any data from Records Management, such as configuration, labels, and policies on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#reportsreadall)
### Reports.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 230c1aed-a721-4c5d-9cb4-a90514e508ef | 02e97553-ed7b-43d0-ab3c-f8bace0d040c
DisplayText | Read all usage reports | Read all usage reports
Description | Allows an app to read all service usage reports without a signed-in user. Services that provide usage reports include Office 365 and Azure Active Directory. | Allows an app to read all service usage reports on behalf of the signed-in user. Services that provide usage reports include Office 365 and Azure Active Directory.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#reportsettingsreadall)
### ReportSettings.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | ee353f83-55ef-4b78-82da-555bfa2b4b95 | 84fac5f4-33a9-4100-aa38-a20c6d29e5e7
DisplayText | Read all admin report settings | Read admin report settings
Description | Allows the app to read all admin report settings, such as whether to display concealed information in reports, without a signed-in user. | Allows the app to read admin report settings, such as whether to display concealed information in reports, on behalf of the signed-in user
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#reportsettingsreadwriteall)
### ReportSettings.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 2a60023f-3219-47ad-baa4-40e17cd02a1d | b955410e-7715-4a88-a940-dfd551018df3
DisplayText | Read and write all admin report settings | Read and write admin report settings
Description | Allows the app to read and update all admin report settings, such as whether to display concealed information in reports, without a signed-in user. | Allows the app to read and update admin report settings, such as whether to display concealed information in reports, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#resourcespecificpermissiongrantreadforchat)
### ResourceSpecificPermissionGrant.ReadForChat
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | cb530fca-534b-4e72-aa74-bca7e8bbd06f
DisplayText | - | Read resource specific permissions granted on a chat
Description | - | Allows the app to read the resource specific permissions granted on the chat, on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#resourcespecificpermissiongrantreadforchatall)
### ResourceSpecificPermissionGrant.ReadForChat.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 2ff643d8-43e4-4a9b-88c1-86cb4a4b4c2f | -
DisplayText | Read resource specific permissions granted on a chat | -
Description | Allows the app to read the resource specific permissions granted on the chat without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#resourcespecificpermissiongrantreadforteam)
### ResourceSpecificPermissionGrant.ReadForTeam
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | eafad40c-bf7a-415a-b7f8-acdf5706b58f
DisplayText | - | Read resource specific permissions granted on a team
Description | - | Allows the app to read the resource specific permissions granted on the team, on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#resourcespecificpermissiongrantreadforteamall)
### ResourceSpecificPermissionGrant.ReadForTeam.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | ad4600ae-d900-42cb-a9a2-2415d05593d0 | -
DisplayText | Read resource specific permissions granted on a team | -
Description | Allows the app to read the resource specific permissions granted on the team without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#resourcespecificpermissiongrantreadforuser)
### ResourceSpecificPermissionGrant.ReadForUser
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | f1d91a8f-88e7-4774-8401-b668d5bca0c5
DisplayText | - | Read resource specific permissions granted on a user account
Description | - | Allows the app to read the resource specific permissions granted on a user account, on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#resourcespecificpermissiongrantreadforuserall)
### ResourceSpecificPermissionGrant.ReadForUser.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | acfca4d5-f49f-40ed-9648-84068b474c73 | -
DisplayText | Read all resource specific permissions granted on user accounts | -
Description | Allows the app to read all resource specific permissions granted on user accounts, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#riskpreventionprovidersreadall)
### RiskPreventionProviders.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 2a6baefd-edea-4ff6-b24e-bebcaa27a50d | e197c06f-ae7b-4398-b0a2-89f76ebca159
DisplayText | Read all identity risk prevention providers | Read all identity risk prevention providers
Description | Allows the app to read your organization's risk prevention providers, without a signed-in user. | Allows the app to read your organization's risk prevention providers, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#riskpreventionprovidersreadwriteall)
### RiskPreventionProviders.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 7fc7225d-eb37-4c39-90f3-a33a57cf1081 | 2a7babba-9623-4109-bc9c-79728cf3bb4f
DisplayText | Read and write all identity risk prevention providers | Read and write all identity risk prevention providers
Description | Allows the app to read and write your organization's risk prevention providers, without a signed-in user. | Allows the app to read and write your organization's risk prevention providers, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#roleassignmentschedulereaddirectory)
### RoleAssignmentSchedule.Read.Directory
Expand table
Category | Application | Delegated
---|---|---
Identifier | d5fe8ce8-684c-4c83-a52c-46e882ce4be1 | 344a729c-0285-42c6-9014-f12b9b8d6129
DisplayText | Read all active role assignments and role schedules for your company's directory | Read all active role assignments for your company's directory
Description | Allows the app to read the active role-based access control (RBAC) assignments and schedules for your company's directory, without a signed-in user. This includes reading directory role templates, and directory roles. | Allows the app to read the active role-based access control (RBAC) assignments for your company's directory, on behalf of the signed-in user. This includes reading directory role templates, and directory roles.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#roleassignmentschedulereadwritedirectory)
### RoleAssignmentSchedule.ReadWrite.Directory
Expand table
Category | Application | Delegated
---|---|---
Identifier | dd199f4a-f148-40a4-a2ec-f0069cc799ec | 8c026be3-8e26-4774-9372-8d5d6f21daff
DisplayText | Read, update, and delete all policies for privileged role assignments of your company's directory | Read, update, and delete all active role assignments for your company's directory
Description | Allows the app to read, update, and delete policies for privileged role-based access control (RBAC) assignments of your company's directory, without a signed-in user. | Allows the app to read and manage the active role-based access control (RBAC) assignments for your company's directory, on behalf of the signed-in user. This includes managing active directory role membership, and reading directory role templates, directory roles and active memberships.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#roleassignmentscheduleremovedirectory)
### RoleAssignmentSchedule.Remove.Directory
Expand table
Category | Application | Delegated
---|---|---
Identifier | d3495511-98b7-4df3-b317-4e35c19f6129 | f71cd05c-3fdb-4568-aef2-e1cf62ee20d4
DisplayText | Delete all active role assignments of your company's directory | Delete all active role assignments for your company's directory
Description | Delete all active privileged role-based access control (RBAC) assignments of your company's directory, without a signed-in user. | Allows the app to delete the active role-based access control (RBAC) assignments for your company's directory, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#roleeligibilityschedulereaddirectory)
### RoleEligibilitySchedule.Read.Directory
Expand table
Category | Application | Delegated
---|---|---
Identifier | ff278e11-4a33-4d0c-83d2-d01dc58929a5 | eb0788c2-6d4e-4658-8c9e-c0fb8053f03d
DisplayText | Read all eligible role assignments and role schedules for your company's directory | Read all eligible role assignments for your company's directory
Description | Allows the app to read the eligible role-based access control (RBAC) assignments and schedules for your company's directory, without a signed-in user. This includes reading directory role templates, and directory roles. | Allows the app to read the eligible role-based access control (RBAC) assignments for your company's directory, on behalf of the signed-in user. This includes reading directory role templates, and directory roles.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#roleeligibilityschedulereadwritedirectory)
### RoleEligibilitySchedule.ReadWrite.Directory
Expand table
Category | Application | Delegated
---|---|---
Identifier | fee28b28-e1f3-4841-818e-2704dc62245f | 62ade113-f8e0-4bf9-a6ba-5acb31db32fd
DisplayText | Read, update, and delete all eligible role assignments and schedules for your company's directory | Read, update, and delete all eligible role assignments for your company's directory
Description | Allows the app to read and manage the eligible role-based access control (RBAC) assignments and schedules for your company's directory, without a signed-in user. This includes managing eligible directory role membership, and reading directory role templates, directory roles and eligible memberships. | Allows the app to read and manage the eligible role-based access control (RBAC) assignments for your company's directory, on behalf of the signed-in user. This includes managing eligible directory role membership, and reading directory role templates, directory roles and eligible memberships.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#roleeligibilityscheduleremovedirectory)
### RoleEligibilitySchedule.Remove.Directory
Expand table
Category | Application | Delegated
---|---|---
Identifier | 79c7e69c-0d9f-4eff-97a8-49170a5a08ba | 58ac4fa2-b484-4d6e-ba97-beee2a574220
DisplayText | Delete all eligible role assignments of your company's directory | Delete all eligible role assignments for your company's directory
Description | Delete all eligible privileged role-based access control (RBAC) assignments of your company's directory, without a signed-in user. | Allows the app to delete the eligible role-based access control (RBAC) assignments for your company's directory, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#rolemanagementreadall)
### RoleManagement.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | c7fbd983-d9aa-4fa7-84b8-17382c103bc4 | 48fec646-b2ba-4019-8681-8eb31435aded
DisplayText | Read role management data for all RBAC providers | Read role management data for all RBAC providers
Description | Allows the app to read role-based access control (RBAC) settings for all RBAC providers without a signed-in user. This includes reading role definitions and role assignments. | Allows the app to read the role-based access control (RBAC) settings for all RBAC providers, on behalf of the signed-in user. This includes reading role definitions and role assignments.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#rolemanagementreadcloudpc)
### RoleManagement.Read.CloudPC
Expand table
Category | Application | Delegated
---|---|---
Identifier | 031a549a-bb80-49b6-8032-2068448c6a3c | 9619b88a-8a25-48a7-9571-d23be0337a79
DisplayText | Read Cloud PC RBAC settings | Read Cloud PC RBAC settings
Description | Allows the app to read the Cloud PC role-based access control (RBAC) settings, without a signed-in user. | Allows the app to read the Cloud PC role-based access control (RBAC) settings, on behalf of the signed-in user. This includes reading Cloud PC role definitions and role assignments.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#rolemanagementreaddefender)
### RoleManagement.Read.Defender
Expand table
Category | Application | Delegated
---|---|---
Identifier | 4d6e30d1-e64e-4ae7-bf9d-c706cc928cef | dd689728-6eb8-4deb-bd38-2924a935f3de
DisplayText | Read M365 Defender RBAC configuration | Read M365 Defender RBAC configuration
Description | Allows the app to read the role-based access control (RBAC) settings for your company's directory, without a signed-in user. | Allows the app to read the role-based access control (RBAC) settings for your company's directory, on behalf of the signed-in user. This includes reading M365 Defender role definitions and role assignments.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#rolemanagementreaddirectory)
### RoleManagement.Read.Directory
Expand table
Category | Application | Delegated
---|---|---
Identifier | 483bed4a-2ad3-4361-a73b-c83ccdbdc53c | 741c54c3-0c1e-44a1-818b-3f97ab4e8c83
DisplayText | Read all directory RBAC settings | Read directory RBAC settings
Description | Allows the app to read the role-based access control (RBAC) settings for your company's directory, without a signed-in user. This includes reading directory role templates, directory roles and memberships. | Allows the app to read the role-based access control (RBAC) settings for your company's directory, on behalf of the signed-in user. This includes reading directory role templates, directory roles and memberships.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#rolemanagementreadexchange)
### RoleManagement.Read.Exchange
Expand table
Category | Application | Delegated
---|---|---
Identifier | c769435f-f061-4d0b-8ff1-3d39870e5f85 | 3bc15058-7858-4141-b24f-ae43b4e80b52
DisplayText | Read Exchange Online RBAC configuration | Read Exchange Online RBAC configuration
Description | Allows the app to read the role-based access control (RBAC) configuration for your organization's Exchange Online service, without a signed-in user. This includes reading Exchange management role definitions, role groups, role group membership, role assignments, management scopes, and role assignment policies. | Allows the app to read the role-based access control (RBAC) settings for your organization's Exchange Online service, on behalf of the signed-in user. This includes reading Exchange management role definitions, role groups, role group membership, role assignments, management scopes, and role assignment policies.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#rolemanagementreadwritecloudpc)
### RoleManagement.ReadWrite.CloudPC
Expand table
Category | Application | Delegated
---|---|---
Identifier | 274d0592-d1b6-44bd-af1d-26d259bcb43a | 501d06f8-07b8-4f18-b5c6-c191a4af7a82
DisplayText | Read and write all Cloud PC RBAC settings | Read and write Cloud PC RBAC settings
Description | Allows the app to read and manage the Cloud PC role-based access control (RBAC) settings, without a signed-in user. This includes reading and managing Cloud PC role definitions and memberships. | Allows the app to read and manage the Cloud PC role-based access control (RBAC) settings, on behalf of the signed-in user. This includes reading and managing Cloud PC role definitions and role assignments.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#rolemanagementreadwritedefender)
### RoleManagement.ReadWrite.Defender
Expand table
Category | Application | Delegated
---|---|---
Identifier | 8b7e8c0a-7e9d-4049-97ec-04b5e1bcaf05 | d8914f8f-9f64-4bd1-b4d3-f5a701ed8457
DisplayText | Read M365 Defender RBAC configuration | Read M365 Defender RBAC configuration
Description | Allows the app to read the role-based access control (RBAC) settings for your company's directory, without a signed-in user. | Allows the app to read the role-based access control (RBAC) settings for your company's directory, on behalf of the signed-in user. This includes reading M365 Defender role definitions and role assignments.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#rolemanagementreadwritedirectory)
### RoleManagement.ReadWrite.Directory
Expand table
Category | Application | Delegated
---|---|---
Identifier | 9e3f62cf-ca93-4989-b6ce-bf83c28f9fe8 | d01b97e9-cbc0-49fe-810a-750afd5527a3
DisplayText | Read and write all directory RBAC settings | Read and write directory RBAC settings
Description | Allows the app to read and manage the role-based access control (RBAC) settings for your company's directory, without a signed-in user. This includes instantiating directory roles and managing directory role membership, and reading directory role templates, directory roles and memberships. | Allows the app to read and manage the role-based access control (RBAC) settings for your company's directory, on behalf of the signed-in user. This includes instantiating directory roles and managing directory role membership, and reading directory role templates, directory roles and memberships.
AdminConsentRequired | Yes | Yes
Permissions that allow granting authorization, such as _RoleManagement.ReadWrite.Directory_ , allow an application to grant additional privileges to itself, other applications, or any user. Use caution when granting any of these permissions.
With the _RoleManagement.ReadWrite.Directory_ permission an application can read and write `/directoryRoles` and `/roleManagement/directory/*`. This includes adding and removing members to and from Microsoft Entra roles, and working with PIM for Microsoft Entra roles APIs.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#rolemanagementreadwriteexchange)
### RoleManagement.ReadWrite.Exchange
Expand table
Category | Application | Delegated
---|---|---
Identifier | 025d3225-3f02-4882-b4c0-cd5b541a4e80 | c1499fe0-52b1-4b22-bed2-7a244e0e879f
DisplayText | Read and write Exchange Online RBAC configuration | Read and write Exchange Online RBAC configuration
Description | Allows the app to read and manage the role-based access control (RBAC) settings for your organization's Exchange Online service, without a signed-in user. This includes reading, creating, updating, and deleting Exchange management role definitions, role groups, role group membership, role assignments, management scopes, and role assignment policies. | Allows the app to read and manage the role-based access control (RBAC) settings for your organization's Exchange Online service, on behalf of the signed-in user. This includes reading, creating, updating, and deleting Exchange management role definitions, role groups, role group membership, role assignments, management scopes, and role assignment policies.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#rolemanagementalertreaddirectory)
### RoleManagementAlert.Read.Directory
Expand table
Category | Application | Delegated
---|---|---
Identifier | ef31918f-2d50-4755-8943-b8638c0a077e | cce71173-f76d-446e-97ff-efb2d82e11b1
DisplayText | Read all alert data for your company's directory | Read all alert data for your company's directory
Description | Allows the app to read all role-based access control (RBAC) alerts for your company's directory, without a signed-in user. This includes reading alert statuses, alert definitions, alert configurations and incidents that lead to an alert. | Allows the app to read the role-based access control (RBAC) alerts for your company's directory, on behalf of the signed-in user. This includes reading alert statuses, alert definitions, alert configurations and incidents that lead to an alert.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#rolemanagementalertreadwritedirectory)
### RoleManagementAlert.ReadWrite.Directory
Expand table
Category | Application | Delegated
---|---|---
Identifier | 11059518-d6a6-4851-98ed-509268489c4a | 435644c6-a5b1-40bf-8f52-fe8e5b53e19c
DisplayText | Read all alert data, configure alerts, and take actions on all alerts for your company's directory | Read all alert data, configure alerts, and take actions on all alerts for your company's directory
Description | Allows the app to read and manage all role-based access control (RBAC) alerts for your company's directory, without a signed-in user. This includes managing alert settings, initiating alert scans, dismissing alerts, remediating alert incidents, and reading alert statuses, alert definitions, alert configurations and incidents that lead to an alert. | Allows the app to read and manage the role-based access control (RBAC) alerts for your company's directory, on behalf of the signed-in user. This includes managing alert settings, initiating alert scans, dismissing alerts, remediating alert incidents, and reading alert statuses, alert definitions, alert configurations and incidents that lead to an alert.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#rolemanagementpolicyreadazureadgroup)
### RoleManagementPolicy.Read.AzureADGroup
Expand table
Category | Application | Delegated
---|---|---
Identifier | 69e67828-780e-47fd-b28c-7b27d14864e6 | 7e26fdff-9cb1-4e56-bede-211fe0e420e8
DisplayText | Read all policies in PIM for Groups | Read all policies in PIM for Groups
Description | Allows the app to read policies in Privileged Identity Management for Groups, without a signed-in user. | Allows the app to read policies in Privileged Identity Management for Groups, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#rolemanagementpolicyreaddirectory)
### RoleManagementPolicy.Read.Directory
Expand table
Category | Application | Delegated
---|---|---
Identifier | fdc4c997-9942-4479-bfcb-75a36d1138df | 3de2cdbe-0ff5-47d5-bdee-7f45b4749ead
DisplayText | Read all policies for privileged role assignments of your company's directory | Read all policies for privileged role assignments of your company's directory
Description | Allows the app to read policies for privileged role-based access control (RBAC) assignments of your company's directory, without a signed-in user. | Allows the app to read policies for privileged role-based access control (RBAC) assignments of your company's directory, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#rolemanagementpolicyreadwriteazureadgroup)
### RoleManagementPolicy.ReadWrite.AzureADGroup
Expand table
Category | Application | Delegated
---|---|---
Identifier | b38dcc4d-a239-4ed6-aa84-6c65b284f97c | 0da165c7-3f15-4236-b733-c0b0f6abe41d
DisplayText | Read, update, and delete all policies in PIM for Groups | Read, update, and delete all policies in PIM for Groups
Description | Allows the app to read, update, and delete policies in Privileged Identity Management for Groups, without a signed-in user. | Allows the app to read, update, and delete policies in Privileged Identity Management for Groups, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#rolemanagementpolicyreadwritedirectory)
### RoleManagementPolicy.ReadWrite.Directory
Expand table
Category | Application | Delegated
---|---|---
Identifier | 31e08e0a-d3f7-4ca2-ac39-7343fb83e8ad | 1ff1be21-34eb-448c-9ac9-ce1f506b2a68
DisplayText | Read, update, and delete all policies for privileged role assignments of your company's directory | Read, update, and delete all policies for privileged role assignments of your company's directory
Description | Allows the app to read, update, and delete policies for privileged role-based access control (RBAC) assignments of your company's directory, without a signed-in user. | Allows the app to read, update, and delete policies for privileged role-based access control (RBAC) assignments of your company's directory, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#schedule-workingtimereadwriteall)
### Schedule-WorkingTime.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 0b21c159-dbf4-4dbb-a6f6-490e412c716e | -
DisplayText | Trigger working time policies and read the working time status | -
Description | Allows the app to trigger the working time policies and read the working time status for other users in your organization, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#schedulereadall)
### Schedule.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 7b2ebf90-d836-437f-b90d-7b62722c4456 | fccf6dd8-5706-49fa-811f-69e2e1b585d0
DisplayText | Read all schedule items | Read user schedule items
Description | Allows the app to read all schedules, schedule groups, shifts and associated entities in the Teams or Shifts application without a signed-in user. | Allows the app to read schedule, schedule groups, shifts and associated entities in the Teams or Shifts application on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#schedulereadwriteall)
### Schedule.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | b7760610-0545-4e8a-9ec3-cce9e63db01c | 63f27281-c9d9-4f29-94dd-6942f7f1feb0
DisplayText | Read and write all schedule items | Read and write user schedule items
Description | Allows the app to manage all schedules, schedule groups, shifts and associated entities in the Teams or Shifts application without a signed-in user. | Allows the app to manage schedule, schedule groups, shifts and associated entities in the Teams or Shifts application on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#schedulepermissionsreadwriteall)
### SchedulePermissions.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 7239b71d-b402-4150-b13d-78ecfe8df441 | 07919803-6073-4cd8-bc55-28077db0ee10
DisplayText | Read/Write schedule permissions for a role | Read/Write schedule permissions for a role.
Description | Allows the app to read/write schedule permissions for a specific role in Shifts application without a signed-in user. | Allows the app to read/write schedule permissions for a specific role in Shifts application on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#searchconfigurationreadall)
### SearchConfiguration.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | ada977a5-b8b1-493b-9a91-66c206d76ecf | 7d307522-aa38-4cd0-bd60-90c6f0ac50bd
DisplayText | Read your organization's search configuration | Read your organization's search configuration
Description | Allows the app to read search configurations, without a signed-in user. | Allows the app to read search configuration, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#searchconfigurationreadwriteall)
### SearchConfiguration.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 0e778b85-fefa-466d-9eec-750569d92122 | b1a7d408-cab0-47d2-a2a5-a74a3733600d
DisplayText | Read and write your organization's search configuration | Read and write your organization's search configuration
Description | Allows the app to read and write search configurations, without a signed-in user. | Allows the app to read and write search configuration, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#securityactionsreadall)
### SecurityActions.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 5e0edab9-c148-49d0-b423-ac253e121825 | 1638cddf-07a4-4de2-8645-69c96cacad73
DisplayText | Read your organization's security actions | Read your organization's security actions
Description | Allows the app to read security actions, without a signed-in user. | Allows the app to read security actions, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#securityactionsreadwriteall)
### SecurityActions.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | f2bf083f-0179-402a-bedb-b2784de8a49b | dc38509c-b87d-4da0-bd92-6bec988bac4a
DisplayText | Read and update your organization's security actions | Read and update your organization's security actions
Description | Allows the app to read or update security actions, without a signed-in user. | Allows the app to read or update security actions, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#securityalertreadall)
### SecurityAlert.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 472e4a4d-bb4a-4026-98d1-0b0d74cb74a5 | bc257fb8-46b4-4b15-8713-01e91bfbe4ea
DisplayText | Read all security alerts | Read all security alerts
Description | Allows the app to read all security alerts, without a signed-in user. | Allows the app to read all security alerts, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#securityalertreadwriteall)
### SecurityAlert.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | ed4fca05-be46-441f-9803-1873825f8fdb | 471f2a7f-2a42-4d45-a2bf-594d0838070d
DisplayText | Read and write to all security alerts | Read and write to all security alerts
Description | Allows the app to read and write to all security alerts, without a signed-in user. | Allows the app to read and write to all security alerts, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#securityanalyzedmessagereadall)
### SecurityAnalyzedMessage.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | b48f7ac2-044d-4281-b02f-75db744d6f5f | 53e6783e-b127-4a35-ab3a-6a52d80a9077
DisplayText | Read metadata and detection details for all emails in your organization | Read metadata and detection details for emails in your organization
Description | Read email metadata and security detection details, without a signed-in user. | Read email metadata and security detection details on behalf of the signed in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#securityanalyzedmessagereadwriteall)
### SecurityAnalyzedMessage.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 04c55753-2244-4c25-87fc-704ab82a4f69 | 48eb8c83-6e58-46e7-a6d3-8805822f5940
DisplayText | Read metadata, detection details, and execute remediation actions on all emails in your organization | Read metadata, detection details, and execute remediation actions on emails in your organization
Description | Read email metadata and security detection details, and execute remediation actions like deleting an email, without a signed-in user. | Read email metadata, security detection details, and execute remediation actions like deleting an email, on behalf of the signed in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#securitycopilotworkspacesreadall)
### SecurityCopilotWorkspaces.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 84499c31-ac2e-44d3-a0cf-a6c386d4dfe8
DisplayText | - | Read all Security Copilot resources for the signed-in user
Description | - | Allows the app to read all Security Copilot signed-in user's resources on behalf of the signed-in user
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#securitycopilotworkspacesreadwriteall)
### SecurityCopilotWorkspaces.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 206291b0-2167-47a7-a640-6cdc1df710ba
DisplayText | - | Read and write individually owned Security Copilot resources of the signed-in user
Description | - | Allows the app to read and write Security Copilot resources owned by the signed-in user on their behalf.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#securityeventsreadall)
### SecurityEvents.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | bf394140-e372-4bf9-a898-299cfc7564e5 | 64733abd-851e-478a-bffb-e47a14b18235
DisplayText | Read your organization's security events | Read your organization's security events
Description | Allows the app to read your organization's security events without a signed-in user. | Allows the app to read your organization's security events on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#securityeventsreadwriteall)
### SecurityEvents.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | d903a879-88e0-4c09-b0c9-82f6a1333f84 | 6aedf524-7e1c-45a7-bd76-ded8cab8d0fc
DisplayText | Read and update your organization's security events | Read and update your organization's security events
Description | Allows the app to read your organization's security events without a signed-in user. Also allows the app to update editable properties in security events. | Allows the app to read your organization's security events on behalf of the signed-in user. Also allows the app to update editable properties in security events on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#securityidentitiesaccountreadall)
### SecurityIdentitiesAccount.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | c5bc96f5-b4a1-4cfc-8189-d5f0d772278f | 3e9ed69a-a48e-473c-8b97-413016703a37
DisplayText | Read all identity security available identity accounts | Read identity security available identity accounts
Description | Allows the app to read all the identity security available identity accounts without a signed-in user. | Allows the app to read all the identity security available identity accounts
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#securityidentitiesactionsreadwriteall)
### SecurityIdentitiesActions.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | af2bf46f-7bf1-4be3-8bad-e17e279e8462 | 818229ce-20e4-47bd-92f4-bc94dbb37a56
DisplayText | Read and perform all identity security available actions | Read and perform identity security available actions
Description | Allows the app to read and write identity security available actions without a signed-in user. | Allows the app to read and write identity security available actions on behalf of the signed-in identity.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#securityidentitiesautoconfigreadall)
### SecurityIdentitiesAutoConfig.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 58971758-9844-4fe4-9fba-7e4ce7a659bf | 8ff90903-1ecb-4f3a-b8b2-42120374ecd6
DisplayText | Read sensors window auditing configuration | Read sensors window auditing configuration
Description | Allows the app to read sensors window auditing configuration without a signed-in user | Allows the app to read the sensors window auditing configuration of the signed in user
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#securityidentitiesautoconfigreadwriteall)
### SecurityIdentitiesAutoConfig.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 4f1f0deb-08d1-4ffb-8cca-21dfc362b7c0 | b810fdb4-8733-43bd-9b37-fddb7215c69f
DisplayText | Read and write sensors window auditing configuration | Read and write sensors window auditing configuration
Description | Allows the app to read and write sensors window auditing configuration without a signed-in user | Allows the app to read and write the sensors window auditing configuration of the signed in user
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#securityidentitieshealthreadall)
### SecurityIdentitiesHealth.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | f8dcd971-5d83-4e1e-aa95-ef44611ad351 | a0d0da43-a6df-4416-b63d-99c79991aae8
DisplayText | Read all identity security health issues | Read identity security health issues
Description | Allows the app to read all the identity security health issues without a signed-in user. | Allows the app to read all the identity security health issues of signed user
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#securityidentitieshealthreadwriteall)
### SecurityIdentitiesHealth.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | ab03ddd5-7ae4-4f2e-8af8-86654f7e0a27 | 53e51eec-2d9b-4990-97f3-c9aa5d5652c3
DisplayText | Read and write all identity security health issues | Read and write identity security health issues
Description | Allows the app to read and write identity security health issues without a signed-in user. | Allows the app to read and write identity security health issues on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#securityidentitiessensorsreadall)
### SecurityIdentitiesSensors.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 5f0ffea2-f474-4cf2-9834-61cda2bcea5c | 2c221239-7c5c-4b30-9355-d84663bfcd96
DisplayText | Read all identity security sensors | Read identity security sensors
Description | Allows the app to read all the identity security sensors without a signed-in user. | Allows the app to read all the identity security sensors of signed user
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#securityidentitiessensorsreadwriteall)
### SecurityIdentitiesSensors.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | d4dcee6d-0774-412a-b06c-aeabbd99e816 | 087c3ad9-c2ca-4b82-9885-d5e25ce9e183
DisplayText | Read and write all identity security sensors | Read and write identity security sensors
Description | Allows the app to read and write identity security sensors without a signed-in user. | Allows the app to read and write identity security sensors on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#securityidentitiesuseractionsreadall)
### SecurityIdentitiesUserActions.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 3e5d0bee-973f-4736-a123-4e1ab146f3a8 | c7d0a939-da1c-4aca-80fa-d0a6cd924801
DisplayText | Read all identity security available user actions | Read identity security available user actions
Description | Allows the app to read all the identity security available user actions without a signed-in user. | Allows the app to read all the identity security available user actions of signed user
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#securityidentitiesuseractionsreadwriteall)
### SecurityIdentitiesUserActions.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | b4146a3a-dd4f-4af4-8d91-7cc0eef3d041 | bf230e97-1957-4df6-b3f6-57f9029eacdf
DisplayText | Read and perform all identity security available user actions | Read and perform identity security available user actions
Description | Allows the app to read and write identity security available user actions without a signed-in user. | Allows the app to read and write identity security available user actions on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#securityincidentreadall)
### SecurityIncident.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 45cc0394-e837-488b-a098-1918f48d186c | b9abcc4f-94fc-4457-9141-d20ce80ec952
DisplayText | Read all security incidents | Read incidents
Description | Allows the app to read all security incidents, without a signed-in user. | Allows the app to read security incidents, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#securityincidentreadwriteall)
### SecurityIncident.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 34bf0e97-1971-4929-b999-9e2442d941d7 | 128ca929-1a19-45e6-a3b8-435ec44a36ba
DisplayText | Read and write to all security incidents | Read and write to incidents
Description | Allows the app to read and write to all security incidents, without a signed-in user. | Allows the app to read and write security incidents, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#sensitivitylabelevaluate)
### SensitivityLabel.Evaluate
Expand table
Category | Application | Delegated
---|---|---
Identifier | 57f0b71b-a759-45a0-9a0f-cc099fbd9a44 | a4633e44-d355-4474-99df-8c2de6b0e39e
DisplayText | Evaluate sensitivity labels | Evaluate sensitivity labels
Description | Allow the app to determine if there is any sensitivity label to be applied automatically to the content or recommended to the user for manual application, without a signed-in user. | Allow the app to determine if there is any sensitivity label to be applied automatically to the content or recommended to the user for manual application, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#sensitivitylabelevaluateall)
### SensitivityLabel.Evaluate.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 986fa56a-6680-4aac-af09-4d1765376739 | a42e3c42-b31e-4919-b699-696dca5dc9e7
DisplayText | Evaluate labels tenant scope. | Evaluate labels tenant scope.
Description | Allows the app to evaluate all sensitivity label. | Allows the app to evaluate all sensitivity label.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#sensitivitylabelread)
### SensitivityLabel.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | 3b8e7aad-f6e3-4299-83f8-6fc6a5777f0b | 1aeb73ce-68d7-49b7-913a-eedc80844551
DisplayText | Get labels application scope. | Get labels user scope.
Description | Allows the app to get sensitivity labels. | Allows the app to get sensitivity labels.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#sensitivitylabelsreadall)
### SensitivityLabels.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | e46a01e9-b2cf-4d89-8424-bcdc6dd445ab | 8b377c27-ea19-4863-a948-8a8588c8f2c3
DisplayText | Get labels tenant scope. | Get labels app scope.
Description | Allows the app to get sensitivity labels. | Allows the app to get sensitivity labels.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#sentimentsurveyexportall)
### SentimentSurvey.Export.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 84fa35c1-f997-4c1c-894c-bb52108cfbbf | df9fd94d-51ff-443d-8f31-ae4dc1b5b8d8
DisplayText | Export all Sentiment Survey | Export all Sentiment Survey
Description | Allows the app to read all Sentiment Survey, without a signed-in user. | Allows the app to export all Sentiment Survey, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#serviceactivity-exchangereadall)
### ServiceActivity-Exchange.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 2b655018-450a-4845-81e7-d603b1ebffdb | 1fe7aa48-9373-4a47-8df3-168335e0f4c9
DisplayText | Read all Exchange service activity | Read all Exchange service activity
Description | Allows the app to read all Exchange service activity, without a signed-in user. | Allows the app to read all Exchange service activity, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#serviceactivity-microsoft365webreadall)
### ServiceActivity-Microsoft365Web.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | c766cb16-acc4-4663-ba09-6eedef5876c5 | d74c75b1-d5a9-479d-902d-92f8f99182c1
DisplayText | Read all Microsoft 365 Web service activity | Read all Microsoft 365 Web service activity
Description | Allows the app to read all Microsoft 365 Web service activity, without a signed-in user. | Allows the app to read all Microsoft 365 Web service activity, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#serviceactivity-onedrivereadall)
### ServiceActivity-OneDrive.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 57b4f899-b8c5-47c7-bdd3-c410c55602b7 | 347e3c16-30f3-4ac7-9b52-fc3c053de9c9
DisplayText | Read all One Drive service activity | Read all One Drive service activity
Description | Allows the app to read all One Drive service activity, without a signed-in user. | Allows the app to read all One Drive service activity, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#serviceactivity-teamsreadall)
### ServiceActivity-Teams.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 4dfee10b-fa4a-41b5-b34d-ccf54cc0c394 | 404d76f0-e10e-460a-92be-ef19600c54d1
DisplayText | Read all Teams service activity | Read all Teams service activity
Description | Allows the app to read all Teams service activity, without a signed-in user. | Allows the app to read all Teams service activity, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#servicehealthreadall)
### ServiceHealth.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 79c261e0-fe76-4144-aad5-bdc68fbe4037 | 55896846-df78-47a7-aa94-8d3d4442ca7f
DisplayText | Read service health | Read service health
Description | Allows the app to read your tenant's service health information, without a signed-in user. Health information may include service issues or service health overviews. | Allows the app to read your tenant's service health information on behalf of the signed-in user. Health information may include service issues or service health overviews.
AdminConsentRequired | Yes | Yes
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _ServiceHealth.Read.All_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#servicemessagereadall)
### ServiceMessage.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 1b620472-6534-4fe6-9df2-4680e8aa28ec | eda39fa6-f8cf-4c3c-a909-432c683e4c9b
DisplayText | Read service messages | Read service announcement messages
Description | Allows the app to read your tenant's service announcement messages, without a signed-in user. Messages may include information about new or changed features. | Allows the app to read your tenant's service announcement messages on behalf of the signed-in user. Messages may include information about new or changed features.
AdminConsentRequired | Yes | Yes
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _ServiceMessage.Read.All_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#servicemessageviewpointwrite)
### ServiceMessageViewpoint.Write
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 636e1b0b-1cc2-4b1c-9aa9-4eeed9b9761b
DisplayText | - | Update user status on service announcement messages
Description | - | Allows the app to update service announcement messages' user status on behalf of the signed-in user. The message status can be marked as read, archive, or favorite.
AdminConsentRequired | - | Yes
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _ServiceMessageViewpoint.Write_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#serviceprincipalendpointreadall)
### ServicePrincipalEndpoint.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 5256681e-b7f6-40c0-8447-2d9db68797a0 | 9f9ce928-e038-4e3b-8faf-7b59049a8ddc
DisplayText | Read service principal endpoints | Read service principal endpoints
Description | Allows the app to read service principal endpoints | Allows the app to read service principal endpoints
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#serviceprincipalendpointreadwriteall)
### ServicePrincipalEndpoint.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 89c8469c-83ad-45f7-8ff2-6e3d4285709e | 7297d82c-9546-4aed-91df-3d4f0a9b3ff0
DisplayText | Read and update service principal endpoints | Read and update service principal endpoints
Description | Allows the app to update service principal endpoints | Allows the app to update service principal endpoints
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#sharepointcrosstenantmigrationmanageall)
### SharePointCrossTenantMigration.Manage.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | a0521574-fcd8-4742-b29c-f796df57ea70 | c608c170-08b5-466b-a8fe-0b4074b01613
DisplayText | Read, write and manage SharePoint Cross-Tenant migration settings and tasks | Read, write and manage SharePoint Cross-Tenant migration settings and tasks
Description | Allows the app to read, write and manage your tenant's SharePoint Cross-Tenant migration settings and tasks, without a signed-in user. | Allows the app to read, write and manage your tenant's SharePoint Cross-Tenant migration settings and tasks, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#sharepointcrosstenantmigrationreadall)
### SharePointCrossTenantMigration.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | f5fa52a5-b9ab-4dc3-885e-9e5b4a67068e | 00dcb678-f9af-4e73-acb1-4f1657364629
DisplayText | Read SharePoint Cross-Tenant migration settings and tasks | Read SharePoint Cross-Tenant migration settings and tasks
Description | Allows the app to read your tenant's SharePoint Cross-Tenant migration settings and tasks, without a signed-in user. | Allows the app to read your tenant's SharePoint Cross-Tenant migration settings and tasks, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#sharepointtenantsettingsreadall)
### SharePointTenantSettings.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 83d4163d-a2d8-4d3b-9695-4ae3ca98f888 | 2ef70e10-5bfd-4ede-a5f6-67720500b258
DisplayText | Read SharePoint and OneDrive tenant settings | Read SharePoint and OneDrive tenant settings
Description | Allows the application to read the tenant-level settings of SharePoint and OneDrive, without a signed-in user. | Allows the application to read the tenant-level settings in SharePoint and OneDrive on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#sharepointtenantsettingsreadwriteall)
### SharePointTenantSettings.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 19b94e34-907c-4f43-bde9-38b1909ed408 | aa07f155-3612-49b8-a147-6c590df35536
DisplayText | Read and change SharePoint and OneDrive tenant settings | Read and change SharePoint and OneDrive tenant settings
Description | Allows the application to read and change the tenant-level settings of SharePoint and OneDrive, without a signed-in user. | Allows the application to read and change the tenant-level settings of SharePoint and OneDrive on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#shortnotesread)
### ShortNotes.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 50f66e47-eb56-45b7-aaa2-75057d9afe08
DisplayText | - | Read short notes of the signed-in user
Description | - | Allows the app to read all the short notes a sign-in user has access to.
AdminConsentRequired | - | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _ShortNotes.Read_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#shortnotesreadall)
### ShortNotes.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 0c7d31ec-31ca-4f58-b6ec-9950b6b0de69 | -
DisplayText | Read all users' short notes | -
Description | Allows the app to read all the short notes without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#shortnotesreadwrite)
### ShortNotes.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 328438b7-4c01-4c07-a840-e625a749bb89
DisplayText | - | Read, create, edit, and delete short notes of the signed-in user
Description | - | Allows the app to read, create, edit, and delete short notes of a signed-in user.
AdminConsentRequired | - | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _ShortNotes.ReadWrite_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#shortnotesreadwriteall)
### ShortNotes.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 842c284c-763d-4a97-838d-79787d129bab | -
DisplayText | Read, create, edit, and delete all users' short notes | -
Description | Allows the app to read, create, edit, and delete all the short notes without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#signinidentifierreadall)
### SignInIdentifier.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 28e1fe78-598f-4df4-b55e-18bf34218925 | 458e1edc-1e75-438c-8c7b-c32115c9d373
DisplayText | Read all sign-in identifiers | Read SignInIdentifiers
Description | Allows the app to read your organization's sign-in identifiers, without a signed-in user. | Allows the app to read your organization's sign-in identifiers, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#signinidentifierreadwriteall)
### SignInIdentifier.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 7fc588a2-ea2d-4d1f-bcf7-33c324b149b8 | b4673c3c-7b5a-4012-9826-7c7e3c8db6af
DisplayText | Read and write all sign-in identifiers | Read and write all sign-in identifiers
Description | Allows the app to read and write your organization's sign-in identifiers, without a signed-in user. | Allows the app to read and write your organization's sign-in identifiers, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#sitesarchiveall)
### Sites.Archive.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | e3530185-4080-478c-a4ab-39322704df58 | -
DisplayText | Archive/reactivate Site Collections without a signed in user. | -
Description | Allow the application to archive/reactivate site collections without a signed in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#sitescreateall)
### Sites.Create.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 80819dd8-2b3b-4551-a1ad-2700fc44f533 | 0e2e68e1-3f32-4e10-9281-f749e097fcbe
DisplayText | Create Site Collections without a signed in user. | Create Site Collections, on behalf of the signed-in user
Description | Allow the application to create site collections without a signed in user. Upon creation the application will be granted Sites.Selected(application) + FullControl to the newly created site. | Allow the application to create site collections on behalf of the signed in user. Upon creation the application will be granted Sites.Selected(delegated) + FullControl to the newly created site.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#sitesfullcontrolall)
### Sites.FullControl.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | a82116e5-55eb-4c41-a434-62fe8a61c773 | 5a54b8b3-347c-476d-8f8e-42d5c7424d29
DisplayText | Have full control of all site collections | Have full control of all site collections
Description | Allows the app to have full control of all site collections without a signed in user. | Allows the application to have full control of all site collections on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Sites.FullControl.All_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#sitesmanageall)
### Sites.Manage.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 0c0bf378-bf22-4481-8f81-9e89a9b4960a | 65e50fdc-43b7-4915-933e-e8138f11f40a
DisplayText | Create, edit, and delete items and lists in all site collections | Create, edit, and delete items and lists in all site collections
Description | Allows the app to create or delete document libraries and lists in all site collections without a signed in user. | Allows the application to create or delete document libraries and lists in all site collections on behalf of the signed-in user.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#sitesreadall)
### Sites.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 332a536c-c7ef-4017-ab91-336970924f0d | 205e70e5-aba6-4c52-a976-6d2d46c48043
DisplayText | Read items in all site collections | Read items in all site collections
Description | Allows the app to read documents and list items in all site collections without a signed in user. | Allows the application to read documents and list items in all site collections on behalf of the signed-in user
AdminConsentRequired | Yes | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Sites.Read.All_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#sitesreadwriteall)
### Sites.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 9492366f-7969-46a4-8d15-ed1a20078fff | 89fe6a52-be36-487e-b7d8-d061c450a026
DisplayText | Read and write items in all site collections | Edit or delete items in all site collections
Description | Allows the app to create, read, update, and delete documents and list items in all site collections without a signed in user. | Allows the application to edit or delete documents and list items in all site collections on behalf of the signed-in user.
AdminConsentRequired | Yes | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Sites.ReadWrite.All_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#sitesselected)
### Sites.Selected
Expand table
Category | Application | Delegated
---|---|---
Identifier | 883ea226-0bf2-4a8f-9f9d-92c9162a727d | f89c84ef-20d0-4b54-87e9-02e856d66d53
DisplayText | Access selected site collections | Access selected Sites, on behalf of the signed-in user
Description | Allow the application to access a subset of site collections without a signed in user. The specific site collections and the permissions granted will be configured in SharePoint Online. | Allow the application to access a subset of site collections on behalf of the signed-in user. The specific site collections and the permissions granted will be configured in SharePoint Online.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#smtpsend)
### SMTP.Send
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 258f6531-6087-4cc4-bb90-092c5fb3ed3f
DisplayText | - | Send emails from mailboxes using SMTP AUTH.
Description | - | Allows the app to be able to send emails from the user's mailbox using the SMTP AUTH client submission protocol.
AdminConsentRequired | - | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _SMTP.Send_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#spiffetrustdomainreadall)
### SpiffeTrustDomain.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | dcdfc277-41fd-4d68-ad0c-c3057235bd8e | 9b4aa4b1-aaf3-41b7-b743-698b27e77ff6
DisplayText | Read SPIFFE trust domains and child resources | Read SPIFFE trust domains and child resources
Description | Allows the app to read your organization's SPIFFE trust domains and child resources without a signed in user. | Allows the app to read your organization's SPIFFE trust domains and child resources on behalf of the user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#spiffetrustdomainreadwriteall)
### SpiffeTrustDomain.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 17b78cfd-eeff-447d-8bab-2795af00055a | 8ba47079-8c47-4bfe-b2ce-13f28ef37247
DisplayText | Read and write SPIFFE trust domains and child resources | Read and write SPIFFE trust domains and child resources
Description | Allows the app to read and write your organization's SPIFFE trust domains and child resources without a signed in user. | Allows the app to read and write your organization's SPIFFE trust domains and child resources on behalf of the user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#storylinereadwriteall)
### Storyline.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 6eff534b-699e-44d9-af61-a4182f0ec37e | fd1d61cb-4e4b-4d15-a6d2-161348681d84
DisplayText | Read and write all Viva Engage storylines | Read and write all Viva Engage storylines
Description | Allows the app to modify Viva Engage storylines, read all storylines properties, update storyline properties, and delete storyline properties without a signed-in user. | Allows the app to modify the Viva Engage storyline and read all storyline properties on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#subjectrightsrequestreadall)
### SubjectRightsRequest.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | ee1460f0-368b-4153-870a-4e1ca7e72c42 | 9c3af74c-fd0f-4db4-b17a-71939e2a9d77
DisplayText | Read all subject rights requests | Read subject rights requests
Description | Allows the app to read subject rights requests without a signed-in user. | Allows the app to read subject rights requests on behalf of the signed-in user
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#subjectrightsrequestreadwriteall)
### SubjectRightsRequest.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 8387eaa4-1a3c-41f5-b261-f888138e6041 | 2b8fcc74-bce1-4ae3-a0e8-60c53739299d
DisplayText | Read and write all subject rights requests | Read and write subject rights requests
Description | Allows the app to read and write subject rights requests without a signed in user. | Allows the app to read and write subject rights requests on behalf of the signed-in user
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#subscriptionreadall)
### Subscription.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 5f88184c-80bb-4d52-9ff2-757288b2e9b7
DisplayText | - | Read all webhook subscriptions
Description | - | Allows the app to read all webhook subscriptions on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#synchronizationreadall)
### Synchronization.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 5ba43d2f-fa88-4db2-bd1c-a67c5f0fb1ce | 7aa02aeb-824f-4fbe-a3f7-611f751f5b55
DisplayText | Read all Azure AD synchronization data. | Read all Azure AD synchronization data
Description | Allows the application to read Azure AD synchronization information, without a signed-in user. | Allows the app to read Azure AD synchronization information, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#synchronizationreadwriteall)
### Synchronization.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 9b50c33d-700f-43b1-b2eb-87e89b703581 | 7bb27fa3-ea8f-4d67-a916-87715b6188bd
DisplayText | Read and write all Azure AD synchronization data. | Read and write all Azure AD synchronization data
Description | Allows the application to configure the Azure AD synchronization service, without a signed-in user. | Allows the app to configure the Azure AD synchronization service, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#synchronizationdata-userupload)
### SynchronizationData-User.Upload
Expand table
Category | Application | Delegated
---|---|---
Identifier | db31e92a-b9ea-4d87-bf6a-75a37a9ca35a | 1a2e7420-4e92-4d2b-94cb-fb2952e9ddf7
DisplayText | Upload user data to the identity synchronization service | Upload user data to the identity synchronization service
Description | Allows the application to upload bulk user data to the identity synchronization service, without a signed-in user. | Allows the app to upload bulk user data to the identity synchronization service, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#synchronizationdata-useruploadownedby)
### SynchronizationData-User.Upload.OwnedBy
Expand table
Category | Application | Delegated
---|---|---
Identifier | 25c32ff3-849a-494b-b94f-20a8ac4e6774 | -
DisplayText | Upload user data to the identity sync service for apps that this application creates or owns | -
Description | Allows the application to upload bulk user data to the identity synchronization service for apps that this application creates or owns, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#tasksread)
### Tasks.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | f45671fb-e0fe-4b4b-be20-3d3ce43f1bcb
DisplayText | - | Read user's tasks and task lists
Description | - | Allows the app to read the signed-in user's tasks and task lists, including any shared with the user. Doesn't include permission to create, delete, or update anything.
AdminConsentRequired | - | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Tasks.Read_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#tasksreadall)
### Tasks.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | f10e1f91-74ed-437f-a6fd-d6ae88e26c1f | -
DisplayText | Read all users' tasks and tasklist | -
Description | Allows the app to read all users' tasks and task lists in your organization, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#tasksreadshared)
### Tasks.Read.Shared
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 88d21fd4-8e5a-4c32-b5e2-4a1c95f34f72
DisplayText | - | Read user and shared tasks
Description | - | Allows the app to read tasks a user has permissions to access, including their own and shared tasks.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#tasksreadwrite)
### Tasks.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 2219042f-cab5-40cc-b0d2-16b1540b4c5f
DisplayText | - | Create, read, update, and delete user's tasks and task lists
Description | - | Allows the app to create, read, update, and delete the signed-in user's tasks and task lists, including any shared with the user.
AdminConsentRequired | - | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Tasks.ReadWrite_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#tasksreadwriteall)
### Tasks.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 44e666d1-d276-445b-a5fc-8815eeb81d55 | -
DisplayText | Read and write all users' tasks and tasklists | -
Description | Allows the app to create, read, update and delete all users' tasks and task lists in your organization, without a signed-in user | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#tasksreadwriteshared)
### Tasks.ReadWrite.Shared
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | c5ddf11b-c114-4886-8558-8a4e557cd52b
DisplayText | - | Read and write user and shared tasks
Description | - | Allows the app to create, read, update, and delete tasks a user has permissions to, including their own and shared tasks.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamcreate)
### Team.Create
Expand table
Category | Application | Delegated
---|---|---
Identifier | 23fc2474-f741-46ce-8465-674744c5c361 | 7825d5d6-6049-4ce7-bdf6-3b8d53f4bcd0
DisplayText | Create teams | Create teams
Description | Allows the app to create teams without a signed-in user. | Allows the app to create teams on behalf of the signed-in user.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamreadbasicall)
### Team.ReadBasic.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 2280dda6-0bfd-44ee-a2f4-cb867cfc4c1e | 485be79e-c497-4b35-9400-0e3fa7f2a5d4
DisplayText | Get a list of all teams | Read the names and descriptions of teams
Description | Get a list of all teams, without a signed-in user. | Read the names and descriptions of teams, on behalf of the signed-in user.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teammemberreadall)
### TeamMember.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 660b7406-55f1-41ca-a0ed-0b035e182f3e | 2497278c-d82d-46a2-b1ce-39d4cdde5570
DisplayText | Read the members of all teams | Read the members of teams
Description | Read the members of all teams, without a signed-in user. | Read the members of teams, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teammemberreadwriteall)
### TeamMember.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 0121dc95-1b9f-4aed-8bac-58c5ac466691 | 4a06efd2-f825-4e34-813e-82a57b03d1ee
DisplayText | Add and remove members from all teams | Add and remove members from teams
Description | Add and remove members from all teams, without a signed-in user. Also allows changing a team member's role, for example from owner to non-owner. | Add and remove members from teams, on behalf of the signed-in user. Also allows changing a member's role, for example from owner to non-owner.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teammemberreadwritenonownerroleall)
### TeamMember.ReadWriteNonOwnerRole.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 4437522e-9a86-4a41-a7da-e380edd4a97d | 2104a4db-3a2f-4ea0-9dba-143d457dc666
DisplayText | Add and remove members with non-owner role for all teams | Add and remove members with non-owner role for all teams
Description | Add and remove members from all teams, without a signed-in user. Does not allow adding or removing a member with the owner role. Additionally, does not allow the app to elevate an existing member to the owner role. | Add and remove members from all teams, on behalf of the signed-in user. Does not allow adding or removing a member with the owner role. Additionally, does not allow the app to elevate an existing member to the owner role.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsactivityread)
### TeamsActivity.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 0e755559-83fb-4b44-91d0-4cc721b9323e
DisplayText | - | Read user's teamwork activity feed
Description | - | Allows the app to read the signed-in user's teamwork activity feed.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsactivityreadall)
### TeamsActivity.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 70dec828-f620-4914-aa83-a29117306807 | -
DisplayText | Read all users' teamwork activity feed | -
Description | Allows the app to read all users' teamwork activity feed, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsactivitysend)
### TeamsActivity.Send
Expand table
Category | Application | Delegated
---|---|---
Identifier | a267235f-af13-44dc-8385-c1dc93023186 | 7ab1d787-bae7-4d5d-8db6-37ea32df9186
DisplayText | Send a teamwork activity to any user | Send a teamwork activity as the user
Description | Allows the app to create new notifications in users' teamwork activity feeds without a signed in user. These notifications may not be discoverable or be held or governed by compliance policies. | Allows the app to create new notifications in users' teamwork activity feeds on behalf of the signed in user. These notifications may not be discoverable or be held or governed by compliance policies.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationmanageselectedforchat)
### TeamsAppInstallation.ManageSelectedForChat
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | d1ba22c6-3f02-4c91-addb-bc3399bcca88
DisplayText | - | Manage installation and permission grants of selected Teams apps in chats
Description | - | Allows the app to read, install, upgrade, and uninstall selected Teams apps in chats the signed-in user can access. Gives the ability to manage permission grants for accessing those specific chats' data.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationmanageselectedforchatall)
### TeamsAppInstallation.ManageSelectedForChat.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 22b74aab-d9e4-46f7-9424-f24b42307227 | -
DisplayText | Manage installation and permission grants of selected Teams apps in all chats | -
Description | Allows the app to read, install, upgrade, and uninstall selected Teams apps in any chat, without a signed-in user. Gives the ability to manage permission grants for accessing those specific chats' data. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationmanageselectedforteam)
### TeamsAppInstallation.ManageSelectedForTeam
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | c67b2d7e-6b80-4218-938a-05e73058e42d
DisplayText | - | Manage installation and permission grants of selected Teams apps in teams
Description | - | Allows the app to read, install, upgrade, and uninstall Teams apps in teams the signed-in user can access. Gives the ability to manage permission grants for accessing those specific teams' data.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationmanageselectedforteamall)
### TeamsAppInstallation.ManageSelectedForTeam.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | b448d252-1f26-4227-b6ff-21ab510975a2 | -
DisplayText | Manage installation and permission grants of selected Teams apps in all teams | -
Description | Allows the app to read, install, upgrade, and uninstall selected Teams apps in any team, without a signed-in user. Gives the ability to manage permission grants for accessing those specific teams' data. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationmanageselectedforuser)
### TeamsAppInstallation.ManageSelectedForUser
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 830c2bd9-c335-4caf-bf83-c07fa8a23ef1
DisplayText | - | Manage installation and permission grants of selected Teams apps in users' personal scope
Description | - | Allows the app to read, install, upgrade, and uninstall seleected Teams apps in user accounts, on behalf of the signed-in user. Gives the ability to manage permission grants for accessing those specific users' data.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationmanageselectedforuserall)
### TeamsAppInstallation.ManageSelectedForUser.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | e97a9235-5b3c-43c4-b37d-6786a173fae4 | -
DisplayText | Manage installation and permission grants of selected Teams apps for all user accounts | -
Description | Allows the app to read, install, upgrade, and uninstall selected Teams apps in any user account, without a signed-in user. Gives the ability to manage permission grants for accessing those specific users' data. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadall)
### TeamsAppInstallation.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 0fdf35a5-82f8-41ff-9ded-0b761cc73512 | -
DisplayText | Read installed Teams apps for all installation scopes | -
Description | Allows the app to read the Teams apps that are installed in any scope, without a signed-in user. Does not give the ability to read application-specific settings. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadforchat)
### TeamsAppInstallation.ReadForChat
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | bf3fbf03-f35f-4e93-963e-47e4d874c37a
DisplayText | - | Read installed Teams apps in chats
Description | - | Allows the app to read the Teams apps that are installed in chats the signed-in user can access. Does not give the ability to read application-specific settings.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadforchatall)
### TeamsAppInstallation.ReadForChat.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | cc7e7635-2586-41d6-adaa-a8d3bcad5ee5 | -
DisplayText | Read installed Teams apps for all chats | -
Description | Allows the app to read the Teams apps that are installed in any chat, without a signed-in user. Does not give the ability to read application-specific settings. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadforteam)
### TeamsAppInstallation.ReadForTeam
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 5248dcb1-f83b-4ec3-9f4d-a4428a961a72
DisplayText | - | Read installed Teams apps in teams
Description | - | Allows the app to read the Teams apps that are installed in teams the signed-in user can access. Does not give the ability to read application-specific settings.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadforteamall)
### TeamsAppInstallation.ReadForTeam.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 1f615aea-6bf9-4b05-84bd-46388e138537 | -
DisplayText | Read installed Teams apps for all teams | -
Description | Allows the app to read the Teams apps that are installed in any team, without a signed-in user. Does not give the ability to read application-specific settings. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadforuser)
### TeamsAppInstallation.ReadForUser
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | c395395c-ff9a-4dba-bc1f-8372ba9dca84
DisplayText | - | Read user's installed Teams apps
Description | - | Allows the app to read the Teams apps that are installed for the signed-in user. Does not give the ability to read application-specific settings.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadforuserall)
### TeamsAppInstallation.ReadForUser.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 9ce09611-f4f7-4abd-a629-a05450422a97 | -
DisplayText | Read installed Teams apps for all users | -
Description | Allows the app to read the Teams apps that are installed for any user, without a signed-in user. Does not give the ability to read application-specific settings. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadselectedforchat)
### TeamsAppInstallation.ReadSelectedForChat
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 0f3420c2-c6ec-46de-ab72-fd51267087d5
DisplayText | - | Read selected installed Teams apps in chats
Description | - | Allows the app to read the selected Teams apps that are installed in chats the signed-in user can access. Does not give the ability to read application-specific settings.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadselectedforchatall)
### TeamsAppInstallation.ReadSelectedForChat.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 53d40ddb-9b27-4c97-b800-985be6041990 | -
DisplayText | Read selected installed Teams apps in all chats | -
Description | Allows the app to read the selected Teams apps that are installed in any chat, without a signed-in user. Does not give the ability to read application-specific settings. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadselectedforteam)
### TeamsAppInstallation.ReadSelectedForTeam
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | b55df1c0-db20-435b-aef2-afe6ed487e16
DisplayText | - | Read selected installed Teams apps in teams
Description | - | Allows the app to read the selected Teams apps that are installed in teams the signed-in user can access. Does not give the ability to read application-specific settings.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadselectedforteamall)
### TeamsAppInstallation.ReadSelectedForTeam.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 93c6a289-70fd-489e-a053-6cf8f7d772f6 | -
DisplayText | Read selected installed Teams apps in all teams | -
Description | Allows the app to read the selected Teams apps that are installed in any team, without a signed-in user. Does not give the ability to read application-specific settings. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadselectedforuser)
### TeamsAppInstallation.ReadSelectedForUser
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | fe2e4e1d-101f-4fb2-9cb1-9d6659db45d4
DisplayText | - | Read user's selected installed Teams apps
Description | - | Allows the app to read the selected Teams apps that are installed for the signed-in user. Does not give the ability to read application-specific settings.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadselectedforuserall)
### TeamsAppInstallation.ReadSelectedForUser.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 44fb0e7c-1f9a-47f1-bb9e-7f92d48ed288 | -
DisplayText | Read selected installed Teams apps for all users | -
Description | Allows an app to read, install, upgrade, and uninstall selected apps to any user, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadwriteandconsentforchat)
### TeamsAppInstallation.ReadWriteAndConsentForChat
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | e1408a66-8f82-451b-a2f3-3c3e38f7413f
DisplayText | - | Manage installed Teams apps in chats
Description | - | Allows the app to read, install, upgrade, and uninstall Teams apps in chats the signed-in user can access. Gives the ability to manage permission grants for accessing those specific chats' data.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadwriteandconsentforchatall)
### TeamsAppInstallation.ReadWriteAndConsentForChat.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 6e74eff9-4a21-45d6-bc03-3a20f61f8281 | -
DisplayText | Manage installation and permission grants of Teams apps for all chats | -
Description | Allows the app to read, install, upgrade, and uninstall Teams apps in any chat, without a signed-in user. Gives the ability to manage permission grants for accessing those specific chats' data. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadwriteandconsentforteam)
### TeamsAppInstallation.ReadWriteAndConsentForTeam
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 946349d5-2a9d-4535-abc0-7beeacaedd1d
DisplayText | - | Manage installed Teams apps in teams
Description | - | Allows the app to read, install, upgrade, and uninstall Teams apps in teams the signed-in user can access. Gives the ability to manage permission grants for accessing those specific teams' data.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadwriteandconsentforteamall)
### TeamsAppInstallation.ReadWriteAndConsentForTeam.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | b0c13be0-8e20-4bc5-8c55-963c23a39ce9 | -
DisplayText | Manage installation and permission grants of Teams apps for all teams | -
Description | Allows the app to read, install, upgrade, and uninstall Teams apps in any team, without a signed-in user. Gives the ability to manage permission grants for accessing those specific teams' data. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadwriteandconsentforuser)
### TeamsAppInstallation.ReadWriteAndConsentForUser
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 2da62c49-dfbd-40df-ba16-fef3529d391c
DisplayText | - | Manage installation and permission grants of Teams apps in users' personal scope
Description | - | Allows the app to read, install, upgrade, and uninstall Teams apps in user accounts, on behalf of the signed-in user. Gives the ability to manage permission grants for accessing those specific users' data.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadwriteandconsentforuserall)
### TeamsAppInstallation.ReadWriteAndConsentForUser.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 32ca478f-f89e-41d0-aaf8-101deb7da510 | -
DisplayText | Manage installation and permission grants of Teams apps in a user account | -
Description | Allows the app to read, install, upgrade, and uninstall Teams apps in any user account, without a signed-in user. Gives the ability to manage permission grants for accessing those specific users' data. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadwriteandconsentselfforchat)
### TeamsAppInstallation.ReadWriteAndConsentSelfForChat
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | a0e0e18b-8fb2-458f-8130-da2d7cab9c75
DisplayText | - | Allow the Teams app to manage itself and its permission grants in chats
Description | - | Allows a Teams app to read, install, upgrade, and uninstall itself in chats the signed-in user can access, and manage its permission grants for accessing those specific chats' data.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadwriteandconsentselfforchatall)
### TeamsAppInstallation.ReadWriteAndConsentSelfForChat.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | ba1ba90b-2d8f-487e-9f16-80728d85bb5c | -
DisplayText | Allow the Teams app to manage itself and its permission grants for all chats | -
Description | Allows a Teams app to read, install, upgrade, and uninstall itself for any chat, without a signed-in user, and manage its permission grants for accessing those specific chats' data. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadwriteandconsentselfforteam)
### TeamsAppInstallation.ReadWriteAndConsentSelfForTeam
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 4a6bbf29-a0e1-4a4d-a7d1-cef17f772975
DisplayText | - | Allow the Teams app to manage itself and its permission grants in teams
Description | - | Allows a Teams app to read, install, upgrade, and uninstall itself in teams the signed-in user can access, and manage its permission grants for accessing those specific teams' data.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadwriteandconsentselfforteamall)
### TeamsAppInstallation.ReadWriteAndConsentSelfForTeam.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 1e4be56c-312e-42b8-a2c9-009600d732c0 | -
DisplayText | Allow the Teams app to manage itself and its permission grants for all teams | -
Description | Allows a Teams app to read, install, upgrade, and uninstall itself for any team, without a signed-in user, and manage its permission grants for accessing those specific teams' data. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadwriteandconsentselfforuser)
### TeamsAppInstallation.ReadWriteAndConsentSelfForUser
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 7a349935-c54d-44ab-ab66-1b460d315be7
DisplayText | - | Allow the Teams app to manage itself and its permission grants in user accounts
Description | - | Allows a Teams app to read, install, upgrade, and uninstall itself in user accounts, and manage its permission grants for accessing those specific users' data, on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadwriteandconsentselfforuserall)
### TeamsAppInstallation.ReadWriteAndConsentSelfForUser.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | a87076cf-6abd-4e56-8559-4dbdf41bef96 | -
DisplayText | Allow the Teams app to manage itself and its permission grants in all user accounts | -
Description | Allows a Teams app to read, install, upgrade, and uninstall itself for any user account, without a signed-in user, and manage its permission grants for accessing those specific users' data. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadwriteforchat)
### TeamsAppInstallation.ReadWriteForChat
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | aa85bf13-d771-4d5d-a9e6-bca04ce44edf
DisplayText | - | Manage installed Teams apps in chats
Description | - | Allows the app to read, install, upgrade, and uninstall Teams apps in chats the signed-in user can access. Does not give the ability to read application-specific settings.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadwriteforchatall)
### TeamsAppInstallation.ReadWriteForChat.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 9e19bae1-2623-4c4f-ab6e-2664615ff9a0 | -
DisplayText | Manage Teams apps for all chats | -
Description | Allows the app to read, install, upgrade, and uninstall Teams apps in any chat, without a signed-in user. Does not give the ability to read application-specific settings. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadwriteforteam)
### TeamsAppInstallation.ReadWriteForTeam
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 2e25a044-2580-450d-8859-42eeb6e996c0
DisplayText | - | Manage installed Teams apps in teams
Description | - | Allows the app to read, install, upgrade, and uninstall Teams apps in teams the signed-in user can access. Does not give the ability to read application-specific settings.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadwriteforteamall)
### TeamsAppInstallation.ReadWriteForTeam.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 5dad17ba-f6cc-4954-a5a2-a0dcc95154f0 | -
DisplayText | Manage Teams apps for all teams | -
Description | Allows the app to read, install, upgrade, and uninstall Teams apps in any team, without a signed-in user. Does not give the ability to read application-specific settings. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadwriteforuser)
### TeamsAppInstallation.ReadWriteForUser
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 093f8818-d05f-49b8-95bc-9d2a73e9a43c
DisplayText | - | Manage user's installed Teams apps
Description | - | Allows the app to read, install, upgrade, and uninstall Teams apps installed for the signed-in user. Does not give the ability to read application-specific settings.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadwriteforuserall)
### TeamsAppInstallation.ReadWriteForUser.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 74ef0291-ca83-4d02-8c7e-d2391e6a444f | -
DisplayText | Manage Teams apps for all users | -
Description | Allows the app to read, install, upgrade, and uninstall Teams apps for any user, without a signed-in user. Does not give the ability to read application-specific settings. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadwriteselectedforchat)
### TeamsAppInstallation.ReadWriteSelectedForChat
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 690aa3b6-4b71-41c2-a990-77a8c4768d2b
DisplayText | - | Manage selected Teams apps installed in chats
Description | - | Allows the app to read, install, upgrade, and uninstall selected Teams apps in chats the signed-in user can access. Does not give the ability to read application-specific settings.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadwriteselectedforchatall)
### TeamsAppInstallation.ReadWriteSelectedForChat.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 25bbeaad-04be-4207-83ed-a263aae76ddf | -
DisplayText | Manage selected installed Teams apps in all chats | -
Description | Allows the app to read, install, upgrade, and uninstall selected Teams apps in any chat, without a signed-in user. Does not give the ability to read application-specific settings. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadwriteselectedforteam)
### TeamsAppInstallation.ReadWriteSelectedForTeam
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 9131c833-9a49-4c54-b38f-615ecfc4fc69
DisplayText | - | Manage selected Teams apps installed in teams
Description | - | Allows the app to read, install, upgrade, and uninstall selected Teams apps in teams the signed-in user can access. Does not give the ability to read application-specific settings.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadwriteselectedforteamall)
### TeamsAppInstallation.ReadWriteSelectedForTeam.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 7b5823ae-d0f2-424d-b90c-d843ffada7d9 | -
DisplayText | Manage selected installed Teams apps in all teams | -
Description | Allows the app to read, install, upgrade, and uninstall selected Teams apps in any team, without a signed-in user. Does not give the ability to read application-specific settings. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadwriteselectedforuser)
### TeamsAppInstallation.ReadWriteSelectedForUser
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | ea819e27-c92a-4118-b83b-4540b125d744
DisplayText | - | Manage selected Teams apps installed for a user
Description | - | Allows the app to read, install, upgrade, and uninstall selected Teams apps installed for the signed in user. Does not give the ability to read application-specific settings.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadwriteselectedforuserall)
### TeamsAppInstallation.ReadWriteSelectedForUser.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 650a76ec-4118-4b25-9d3a-1f98048a5ee0 | -
DisplayText | Manage selected Teams apps installed for all users | -
Description | Allows the app to read, install, upgrade, and uninstall selected Teams apps for any user, without a signed-in user. Does not give the ability to read application-specific settings. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadwriteselfforchat)
### TeamsAppInstallation.ReadWriteSelfForChat
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 0ce33576-30e8-43b7-99e5-62f8569a4002
DisplayText | - | Allow the Teams app to manage itself in chats
Description | - | Allows a Teams app to read, install, upgrade, and uninstall itself in chats the signed-in user can access.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadwriteselfforchatall)
### TeamsAppInstallation.ReadWriteSelfForChat.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 73a45059-f39c-4baf-9182-4954ac0e55cf | -
DisplayText | Allow the Teams app to manage itself for all chats | -
Description | Allows a Teams app to read, install, upgrade, and uninstall itself for any chat, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadwriteselfforteam)
### TeamsAppInstallation.ReadWriteSelfForTeam
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 0f4595f7-64b1-4e13-81bc-11a249df07a9
DisplayText | - | Allow the app to manage itself in teams
Description | - | Allows a Teams app to read, install, upgrade, and uninstall itself to teams the signed-in user can access.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadwriteselfforteamall)
### TeamsAppInstallation.ReadWriteSelfForTeam.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 9f67436c-5415-4e7f-8ac1-3014a7132630 | -
DisplayText | Allow the Teams app to manage itself for all teams | -
Description | Allows a Teams app to read, install, upgrade, and uninstall itself in any team, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadwriteselfforuser)
### TeamsAppInstallation.ReadWriteSelfForUser
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 207e0cb1-3ce7-4922-b991-5a760c346ebc
DisplayText | - | Allow the Teams app to manage itself for a user
Description | - | Allows a Teams app to read, install, upgrade, and uninstall itself for the signed-in user.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsappinstallationreadwriteselfforuserall)
### TeamsAppInstallation.ReadWriteSelfForUser.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 908de74d-f8b2-4d6b-a9ed-2a17b3b78179 | -
DisplayText | Allow the app to manage itself for all users | -
Description | Allows a Teams app to read, install, upgrade, and uninstall itself to any user, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsettingsreadall)
### TeamSettings.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 242607bd-1d2c-432c-82eb-bdb27baa23ab | 48638b3c-ad68-4383-8ac4-e6880ee6ca57
DisplayText | Read all teams' settings | Read teams' settings
Description | Read all team's settings, without a signed-in user. | Read all teams' settings, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsettingsreadwriteall)
### TeamSettings.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | bdd80a03-d9bc-451d-b7c4-ce7c63fe3c8f | 39d65650-9d3e-4223-80db-a335590d027e
DisplayText | Read and change all teams' settings | Read and change teams' settings
Description | Read and change all teams' settings, without a signed-in user. | Read and change all teams' settings, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamspolicyuserassignreadwriteall)
### TeamsPolicyUserAssign.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 1801e8f4-cf09-4c4e-a1b5-036dfcca6c90 | 6997c35c-a586-440c-8a0b-4ffe5d118dc0
DisplayText | Read and Write Teams policy user assignment and unassigment for all policy types. | Read and Write Teams policy user assignment and unassigment for all policy types.
Description | Allow the app to read or write/update the policy assignment and unassigment for Teams users for all policy type categories. | Allow the app to read or write/update the policy assignment and unassigment for Teams users for all policy type categories.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsresourceaccountreadall)
### TeamsResourceAccount.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | b55aa226-33a1-4396-bcf4-edce5e7a31c1 | ea2cbd09-253c-4f69-a0e6-07383c5f07cc
DisplayText | Read Teams resource accounts | Read Teams resource accounts
Description | Allows the app to read your tenant's resource accounts without a signed-in user. | Allows the app to read your tenant's resource accounts on behalf of the signed-in admin user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamstabcreate)
### TeamsTab.Create
Expand table
Category | Application | Delegated
---|---|---
Identifier | 49981c42-fd7b-4530-be03-e77b21aed25e | a9ff19c2-f369-4a95-9a25-ba9d460efc8e
DisplayText | Create tabs in Microsoft Teams. | Create tabs in Microsoft Teams.
Description | Allows the app to create tabs in any team in Microsoft Teams, without a signed-in user. This does not grant the ability to read, modify or delete tabs after they are created, or give access to the content inside the tabs. | Allows the app to create tabs in any team in Microsoft Teams, on behalf of the signed-in user. This does not grant the ability to read, modify or delete tabs after they are created, or give access to the content inside the tabs.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamstabreadall)
### TeamsTab.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 46890524-499a-4bb2-ad64-1476b4f3e1cf | 59dacb05-e88d-4c13-a684-59f1afc8cc98
DisplayText | Read tabs in Microsoft Teams. | Read tabs in Microsoft Teams.
Description | Read the names and settings of tabs inside any team in Microsoft Teams, without a signed-in user. This does not give access to the content inside the tabs. | Read the names and settings of tabs inside any team in Microsoft Teams, on behalf of the signed-in user. This does not give access to the content inside the tabs.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamstabreadwriteall)
### TeamsTab.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | a96d855f-016b-47d7-b51c-1218a98d791c | b98bfd41-87c6-45cc-b104-e2de4f0dafb9
DisplayText | Read and write tabs in Microsoft Teams. | Read and write tabs in Microsoft Teams.
Description | Read and write tabs in any team in Microsoft Teams, without a signed-in user. This does not give access to the content inside the tabs. | Read and write tabs in any team in Microsoft Teams, on behalf of the signed-in user. This does not give access to the content inside the tabs.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamstabreadwriteforchat)
### TeamsTab.ReadWriteForChat
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | ee928332-e9c2-4747-b4a0-f8c164b68de6
DisplayText | - | Allow the Teams app to manage all tabs in chats
Description | - | Allows a Teams app to read, install, upgrade, and uninstall all tabs in chats the signed-in user can access.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamstabreadwriteforchatall)
### TeamsTab.ReadWriteForChat.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | fd9ce730-a250-40dc-bd44-8dc8d20f39ea | -
DisplayText | Allow the Teams app to manage all tabs for all chats | -
Description | Allows a Teams app to read, install, upgrade, and uninstall all tabs for any chat, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamstabreadwriteforteam)
### TeamsTab.ReadWriteForTeam
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | c975dd04-a06e-4fbb-9704-62daad77bb49
DisplayText | - | Allow the Teams app to manage all tabs in teams
Description | - | Allows a Teams app to read, install, upgrade, and uninstall all tabs to teams the signed-in user can access.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamstabreadwriteforteamall)
### TeamsTab.ReadWriteForTeam.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 6163d4f4-fbf8-43da-a7b4-060fe85ed148 | -
DisplayText | Allow the Teams app to manage all tabs for all teams | -
Description | Allows a Teams app to read, install, upgrade, and uninstall all tabs in any team, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamstabreadwriteforuser)
### TeamsTab.ReadWriteForUser
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | c37c9b61-7762-4bff-a156-afc0005847a0
DisplayText | - | Allow the Teams app to manage all tabs for a user
Description | - | Allows a Teams app to read, install, upgrade, and uninstall all tabs for the signed-in user.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamstabreadwriteforuserall)
### TeamsTab.ReadWriteForUser.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 425b4b59-d5af-45c8-832f-bb0b7402348a | -
DisplayText | Allow the app to manage all tabs for all users | -
Description | Allows a Teams app to read, install, upgrade, and uninstall all tabs for any user, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamstabreadwriteselfforchat)
### TeamsTab.ReadWriteSelfForChat
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 0c219d04-3abf-47f7-912d-5cca239e90e6
DisplayText | - | Allow the Teams app to manage only its own tabs in chats
Description | - | Allows a Teams app to read, install, upgrade, and uninstall its own tabs in chats the signed-in user can access.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamstabreadwriteselfforchatall)
### TeamsTab.ReadWriteSelfForChat.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 9f62e4a2-a2d6-4350-b28b-d244728c4f86 | -
DisplayText | Allow the Teams app to manage only its own tabs for all chats | -
Description | Allows a Teams app to read, install, upgrade, and uninstall its own tabs for any chat, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamstabreadwriteselfforteam)
### TeamsTab.ReadWriteSelfForTeam
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | f266662f-120a-4314-b26a-99b08617c7ef
DisplayText | - | Allow the Teams app to manage only its own tabs in teams
Description | - | Allows a Teams app to read, install, upgrade, and uninstall its own tabs to teams the signed-in user can access.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamstabreadwriteselfforteamall)
### TeamsTab.ReadWriteSelfForTeam.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 91c32b81-0ef0-453f-a5c7-4ce2e562f449 | -
DisplayText | Allow the Teams app to manage only its own tabs for all teams | -
Description | Allows a Teams app to read, install, upgrade, and uninstall its own tabs in any team, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamstabreadwriteselfforuser)
### TeamsTab.ReadWriteSelfForUser
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 395dfec1-a0b9-465f-a783-8250a430cb8c
DisplayText | - | Allow the Teams app to manage only its own tabs for a user
Description | - | Allows a Teams app to read, install, upgrade, and uninstall its own tabs for the signed-in user.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamstabreadwriteselfforuserall)
### TeamsTab.ReadWriteSelfForUser.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 3c42dec6-49e8-4a0a-b469-36cff0d9da93 | -
DisplayText | Allow the Teams app to manage only its own tabs for all users | -
Description | Allows a Teams app to read, install, upgrade, and uninstall its own tabs for any user, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamstelephonenumberreadall)
### TeamsTelephoneNumber.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 39b17d18-680c-41f4-b9c2-5f30629e7cb6 | 1bc6eab1-058d-4557-b011-d4c41cec88b7
DisplayText | Read Tenant-Acquired Telephone Number Details | Read Tenant-Acquired Telephone Number Details
Description | Allows the app to read your tenant's acquired telephone number details, without a signed-in user. Acquired telephone numbers may include attributes related to assigned object, emergency location, network site, etc. | Allows the app to read your tenant's acquired telephone number details on behalf of the signed-in admin user. Acquired telephone numbers may include attributes related to assigned object, emergency location, network site, etc.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamstelephonenumberreadwriteall)
### TeamsTelephoneNumber.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 0a42382f-155c-4eb1-9bdc-21548ccaa387 | 424b07a8-1209-4d17-9fe4-9018a93a1024
DisplayText | Read and Modify Tenant-Acquired Telephone Number Details | Read and Modify Tenant-Acquired Telephone Number Details
Description | Allows the app to read your tenant's acquired telephone number details, without a signed-in user. Acquired telephone numbers may include attributes related to assigned object, emergency location, network site, etc. | Allows the app to read and modify your tenant's acquired telephone number details on behalf of the signed-in admin user. Acquired telephone numbers may include attributes related to assigned object, emergency location, network site, etc.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamsuserconfigurationreadall)
### TeamsUserConfiguration.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | a91eadaf-2c3c-4362-908b-fb172d208fc6 | 5c469ce4-dab5-4afd-b9de-14f1ba4004a7
DisplayText | Read Teams user configurations | Read Teams user configurations
Description | Allows the app to read your tenant's user configurations, without a signed-in user. User configuration may include attributes related to user, such as telephone number, assigned policies, etc. | Allows the app to read your tenant's user configurations on behalf of the signed-in admin user. User configuration may include attributes related to user, such as telephone number, assigned policies, etc.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamtemplatesread)
### TeamTemplates.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | cd87405c-5792-4f15-92f7-debc0db6d1d6
DisplayText | - | Read available Teams templates
Description | - | Allows the app to read the available Teams templates, on behalf of the signed-in user.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamtemplatesreadall)
### TeamTemplates.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 6323133e-1f6e-46d4-9372-ac33a0870636 | -
DisplayText | Read all available Teams Templates | -
Description | Allows the app to read all available Teams Templates, without a signed-user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamworkmigrateall)
### Teamwork.Migrate.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | dfb0dd15-61de-45b2-be36-d6a69fba3c79 | -
DisplayText | Create chat and channel messages with anyone's identity and with any timestamp | -
Description | Allows the app to create chat and channel messages, without a signed in user. The app specifies which user appears as the sender, and can backdate the message to appear as if it was sent long ago. The messages can be sent to any chat or channel in the organization. | -
AdminConsentRequired | Yes | -
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _Teamwork.Migrate.All_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamworkreadall)
### Teamwork.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 75bcfbce-a647-4fba-ad51-b63d73b210f4 | 594f4bb6-c083-4cf9-8aa8-213823bdf351
DisplayText | Read organizational teamwork settings | Read organizational teamwork settings
Description | Allows the app to read all teamwork settings of the organization without a signed-in user. | Allows the app to read the teamwork settings of the organization, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamworkappsettingsreadall)
### TeamworkAppSettings.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 475ebe88-f071-4bd7-af2b-642952bd4986 | 44e060c4-bbdc-4256-a0b9-dcc0396db368
DisplayText | Read Teams app settings | Read Teams app settings
Description | Allows the app to read the Teams app settings without a signed-in user. | Allows the app to read the Teams app settings on behalf of the signed-in user.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamworkappsettingsreadwriteall)
### TeamworkAppSettings.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | ab5b445e-8f10-45f4-9c79-dd3f8062cc4e | 87c556f0-2bd9-4eed-bd74-5dd8af6eaf7e
DisplayText | Read and write Teams app settings | Read and write Teams app settings
Description | Allows the app to read and write the Teams app settings without a signed-in user. | Allows the app to read and write the Teams app settings on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamworkdevicereadall)
### TeamworkDevice.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 0591bafd-7c1c-4c30-a2a5-2b9aacb1dfe8 | b659488b-9d28-4208-b2be-1c6652b3c970
DisplayText | Read Teams devices | Read Teams devices
Description | Allow the app to read the management data for Teams devices, without a signed-in user. | Allow the app to read the management data for Teams devices on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamworkdevicereadwriteall)
### TeamworkDevice.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 79c02f5b-bd4f-4713-bc2c-a8a4a66e127b | ddd97ecb-5c31-43db-a235-0ee20e635c40
DisplayText | Read and write Teams devices | Read and write Teams devices
Description | Allow the app to read and write the management data for Teams devices, without a signed-in user. | Allow the app to read and write the management data for Teams devices on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamworktagread)
### TeamworkTag.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 57587d0b-8399-45be-b207-8050cec54575
DisplayText | - | Read tags in Teams
Description | - | Allows the app to read tags in Teams, on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamworktagreadall)
### TeamworkTag.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | b74fd6c4-4bde-488e-9695-eeb100e4907f | -
DisplayText | Read tags in Teams | -
Description | Allows the app to read tags in Teams without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamworktagreadwrite)
### TeamworkTag.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 539dabd7-b5b6-4117-b164-d60cd15a8671
DisplayText | - | Read and write tags in Teams
Description | - | Allows the app to read and write tags in Teams, on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamworktagreadwriteall)
### TeamworkTag.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | a3371ca5-911d-46d6-901c-42c8c7a937d8 | -
DisplayText | Read and write tags in Teams | -
Description | Allows the app to read and write tags in Teams without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamworktargetedmessagereadall)
### TeamworkTargetedMessage.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | b0cfd829-be18-4b31-bb0e-ec1df8197ba3 | -
DisplayText | Read all targeted messages of group chat or channel | -
Description | Allows the app to read all group chat or channel targeted messages in Microsoft Teams. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#teamworkuserinteractionreadall)
### TeamworkUserInteraction.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | b4d26916-07e0-4daf-9096-9f6d9174aa96
DisplayText | - | Read all of the possible Teams interactions between the user and other users
Description | - | Allows the app to read all of the possible Teams interactions between the signed-in user and other users
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#termstorereadall)
### TermStore.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | ea047cc2-df29-4f3e-83a3-205de61501ca | 297f747b-0005-475b-8fef-c890f5152b38
DisplayText | Read all term store data | Read term store data
Description | Allows the app to read all term store data, without a signed-in user. This includes all sets, groups and terms in the term store. | Allows the app to read the term store data that the signed-in user has access to. This includes all sets, groups and terms in the term store.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#termstorereadwriteall)
### TermStore.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | f12eb8d6-28e3-46e6-b2c0-b7e4dc69fc95 | 6c37c71d-f50f-4bff-8fd3-8a41da390140
DisplayText | Read and write all term store data | Read and write term store data
Description | Allows the app to read, edit or write all term store data, without a signed-in user. This includes all sets, groups and terms in the term store. | Allows the app to read or modify data that the signed-in user has access to. This includes all sets, groups and terms in the term store.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#threatassessmentreadall)
### ThreatAssessment.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | f8f035bb-2cce-47fb-8bf5-7baf3ecbee48 | -
DisplayText | Read threat assessment requests | -
Description | Allows an app to read your organization's threat assessment requests, without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#threatassessmentreadwriteall)
### ThreatAssessment.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | cac97e40-6730-457d-ad8d-4852fddab7ad
DisplayText | - | Read and write threat assessment requests
Description | - | Allows an app to read your organization's threat assessment requests on behalf of the signed-in user. Also allows the app to create new requests to assess threats received by your organization on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#threathuntingreadall)
### ThreatHunting.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | dd98c7f5-2d42-42d3-a0e4-633161547251 | b152eca8-ea73-4a48-8c98-1a6742673d99
DisplayText | Run hunting queries | Run hunting queries
Description | Allows the app to run hunting queries, without a signed-in user. | Allows the app to run hunting queries, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#threatindicatorsreadall)
### ThreatIndicators.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 197ee4e9-b993-4066-898f-d6aecc55125b | 9cc427b4-2004-41c5-aa22-757b755e9796
DisplayText | Read all threat indicators | Read all threat indicators
Description | Allows the app to read all the indicators for your organization, without a signed-in user. | Allows the app to read all the indicators for your organization, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#threatindicatorsreadwriteownedby)
### ThreatIndicators.ReadWrite.OwnedBy
Expand table
Category | Application | Delegated
---|---|---
Identifier | 21792b6c-c986-4ffc-85de-df9da54b52fa | 91e7d36d-022a-490f-a748-f8e011357b42
DisplayText | Manage threat indicators this app creates or owns | Manage threat indicators this app creates or owns
Description | Allows the app to create threat indicators, and fully manage those threat indicators (read, update and delete), without a signed-in user. It cannot update any threat indicators it does not own. | Allows the app to create threat indicators, and fully manage those threat indicators (read, update and delete), on behalf of the signed-in user. It cannot update any threat indicators it does not own.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#threatintelligencereadall)
### ThreatIntelligence.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | e0b77adb-e790-44a3-b0a0-257d06303687 | f266d9c0-ccb9-4fb8-a228-01ac0d8d6627
DisplayText | Read all Threat Intelligence Information | Read all threat intelligence information
Description | Allows the app to read threat intelligence information, such as indicators, observations, and and articles, without a signed in user. | Allows the app to read threat intelligence information, such as indicators, observations, and articles, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#threatsubmissionread)
### ThreatSubmission.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | fd5353c6-26dd-449f-a565-c4e16b9fce78
DisplayText | - | Read threat submissions
Description | - | Allows the app to read the threat submissions and threat submission policies owned by the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#threatsubmissionreadall)
### ThreatSubmission.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 86632667-cd15-4845-ad89-48a88e8412e1 | 7083913a-4966-44b6-9886-c5822a5fd910
DisplayText | Read all of the organization's threat submissions | Read all threat submissions
Description | Allows the app to read your organization's threat submissions and to view threat submission policies without a signed-in user. | Allows the app to read your organization's threat submissions and threat submission policies on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#threatsubmissionreadwrite)
### ThreatSubmission.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 68a3156e-46c9-443c-b85c-921397f082b5
DisplayText | - | Read and write threat submissions
Description | - | Allows the app to read the threat submissions and threat submission policies owned by the signed-in user. Also allows the app to create new threat submissions on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#threatsubmissionreadwriteall)
### ThreatSubmission.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | d72bdbf4-a59b-405c-8b04-5995895819ac | 8458e264-4eb9-4922-abe9-768d58f13c7f
DisplayText | Read and write all of the organization's threat submissions | Read and write all threat submissions
Description | Allows the app to read your organization's threat submissions and threat submission policies without a signed-in user. Also allows the app to create new threat submissions without a signed-in user. | Allows the app to read your organization's threat submissions and threat submission policies on behalf of the signed-in user. Also allows the app to create new threat submissions on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#threatsubmissionpolicyreadwriteall)
### ThreatSubmissionPolicy.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 926a6798-b100-4a20-a22f-a4918f13951d | 059e5840-5353-4c68-b1da-666a033fc5e8
DisplayText | Read and write all of the organization's threat submission policies | Read and write all threat submission policies
Description | Allows the app to read your organization's threat submission policies without a signed-in user. Also allows the app to create new threat submission policies without a signed-in user. | Allows the app to read your organization's threat submission policies on behalf of the signed-in user. Also allows the app to create new threat submission policies on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#topicreadall)
### Topic.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 79c4c76f-409a-4f98-884d-e2c09291ec26
DisplayText | - | Read topic items
Description | - | Allows the app to read topics data on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#trustframeworkkeysetreadall)
### TrustFrameworkKeySet.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | fff194f1-7dce-4428-8301-1badb5518201 | 7ad34336-f5b1-44ce-8682-31d7dfcd9ab9
DisplayText | Read trust framework key sets | Read trust framework key sets
Description | Allows the app to read trust framework key set properties without a signed-in user. | Allows the app to read trust framework key set properties on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#trustframeworkkeysetreadwriteall)
### TrustFrameworkKeySet.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 4a771c9a-1cf2-4609-b88e-3d3e02d539cd | 39244520-1e7d-4b4a-aee0-57c65826e427
DisplayText | Read and write trust framework key sets | Read and write trust framework key sets
Description | Allows the app to read and write trust framework key set properties without a signed-in user. | Allows the app to read and write trust framework key set properties on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#unifiedgroupmemberreadasguest)
### UnifiedGroupMember.Read.AsGuest
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 73e75199-7c3e-41bb-9357-167164dbb415
DisplayText | - | Read unified group memberships as guest
Description | - | Allows the app to read basic unified group properties, memberships and owners of the group the signed-in guest is a member of.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#user-converttointernalreadwriteall)
### User-ConvertToInternal.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 9d952b72-f741-4b40-9185-8c53076c2339 | 550e695c-7511-40f4-ac79-e8fb9c82552d
DisplayText | Convert an external user to internal member user | Convert an external user to internal memeber user
Description | Allow the app to convert an external user to an internal member user, without a signed-in user. | Allow the app to convert an external user to an internal member user, on behalf of signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#user-lifecycleinforeadall)
### User-LifeCycleInfo.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 8556a004-db57-4d7a-8b82-97a13428e96f | ed8d2a04-0374-41f1-aefe-da8ac87ccc87
DisplayText | Read all users' lifecycle information | Read all users' lifecycle information
Description | Allows the app to read the lifecycle information like employeeLeaveDateTime of users in your organization, without a signed-in user. | Allows the app to read the lifecycle information like employeeLeaveDateTime of users in your organization, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#user-lifecycleinforeadwriteall)
### User-LifeCycleInfo.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 925f1248-0f97-47b9-8ec8-538c54e01325 | 7ee7473e-bd4b-4c9f-987c-bd58481f5fa2
DisplayText | Read and write all users' lifecycle information | Read and write all users' lifecycle information
Description | Allows the app to read and write the lifecycle information like employeeLeaveDateTime of users in your organization, without a signed-in user. | Allows the app to read and write the lifecycle information like employeeLeaveDateTime of users in your organization, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#user-mailreadwriteall)
### User-Mail.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 280d0935-0796-47d1-8d26-273470a3f17a | 6166886a-9576-433b-8544-658177bdef1d
DisplayText | Read and write all secondary mail addresses for users | Read and write secondary mail addresses for users
Description | Allows the app to read and write secondary mail addresses for all users, without a signed-in user. | Allows the app to read and write secondary mail addresses for all users, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#user-onpremisessyncbehaviorreadwriteall)
### User-OnPremisesSyncBehavior.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | a94a502d-0281-4d15-8cd2-682ac9362c4c | 7ff9afdd-0cdb-439d-a61c-fea3e9339e89
DisplayText | Read and update the on-premises sync behavior of users | Read and update the on-premises sync behavior of users
Description | Allows the app to update the on-premises sync behavior of all users without a signed-in user. | Allows the app to read and update the on-premises sync behavior of users on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#user-passwordprofilereadwriteall)
### User-PasswordProfile.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | cc117bb9-00cf-4eb8-b580-ea2a878fe8f7 | 56760768-b641-451f-8906-e1b8ab31bca7
DisplayText | Read and write all password profiles and reset user passwords | Read and write password profiles and reset user passwords
Description | Allows the app to read and write password profiles and reset passwords for all users, without a signed-in user. | Allows the app to read and write password profiles and reset passwords for all users, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#user-phonereadwriteall)
### User-Phone.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 86ceff06-c822-49ff-989a-d912845ffe69 | e29d5979-5b06-4a7f-ae24-6a9348d2e1ff
DisplayText | Read and write all user mobile phone and business phones | Read and write user mobile phone and business phones
Description | Allows the app to read and write the mobile phone and business phones for all users, without a signed-in user. | Allows the app to read and write the mobile phone and business phones for all users, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userdeleterestoreall)
### User.DeleteRestore.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | eccc023d-eccf-4e7b-9683-8813ab36cecc | 4bb440cd-2cf2-4f90-8004-aa2acd2537c5
DisplayText | Delete and restore all users | Delete and restore users
Description | Allows the app to delete and restore all users, without a signed-in user. | Allows the app to delete and restore all users, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userenabledisableaccountall)
### User.EnableDisableAccount.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 3011c876-62b7-4ada-afa2-506cbbecc68c | f92e74e7-2563-467f-9dd0-902688cb5863
DisplayText | Enable and disable user accounts | Enable and disable user accounts
Description | Allows the app to enable and disable users' accounts, without a signed-in user. | Allows the app to enable and disable users' accounts, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userexportall)
### User.Export.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 405a51b5-8d8d-430b-9842-8be4b0e9f324 | 405a51b5-8d8d-430b-9842-8be4b0e9f324
DisplayText | Export user's data | Export user's data
Description | Allows the app to export data (e.g. customer content or system-generated logs), associated with any user in your company, when the app is used by a privileged user (e.g. a Company Administrator). | Allows the app to export data (e.g. customer content or system-generated logs), associated with any user in your company, when the app is used by a privileged user (e.g. a Company Administrator).
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userinviteall)
### User.Invite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 09850681-111b-4a89-9bed-3f2cae46d706 | 63dd7cd9-b489-4adf-a28c-ac38b9a0f962
DisplayText | Invite guest users to the organization | Invite guest users to the organization
Description | Allows the app to invite guest users to the organization, without a signed-in user. | Allows the app to invite guest users to the organization, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#usermanageidentitiesall)
### User.ManageIdentities.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | c529cfca-c91b-489c-af2b-d92990b66ce6 | 637d7bec-b31e-4deb-acc9-24275642a2c9
DisplayText | Manage all users' identities | Manage user identities
Description | Allows the app to read, update and delete identities that are associated with a user's account, without a signed in user. This controls the identities users can sign-in with. | Allows the app to read, update and delete identities that are associated with a user's account that the signed-in user has access to. This controls the identities users can sign-in with.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userread)
### User.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | e1fe6dd8-ba31-4d61-89e7-88639da4683d
DisplayText | - | Sign in and read user profile
Description | - | Allows users to sign-in to the app, and allows the app to read the profile of signed-in users. It also allows the app to read basic company information of signed-in users.
AdminConsentRequired | - | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _User.Read_ delegated permission is available for consent in personal Microsoft accounts.
The _User.Read_ permission also allows an app to read the basic company information of the signed-in user for a work or school account through the [organization resource](https://learn.microsoft.com/en-us/graph/api/resources/organization). Information in the following properties is available: **id** , **displayName** , and **verifiedDomains**.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userreadall)
### User.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | df021288-bdef-4463-88db-98f22de89214 | a154be20-db9c-4678-8ab7-66f6cc099a59
DisplayText | Read all users' full profiles | Read all users' full profiles
Description | Allows the app to read user profiles without a signed in user. | Allows the app to read the full set of profile properties, reports, and managers of other users in your organization, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _User.Read.All_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userreadbasicall)
### User.ReadBasic.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 97235f07-e226-4f63-ace3-39588e11d3a1 | b340eb25-3456-403f-be2f-af7a0d370277
DisplayText | Read all users' basic profiles | Read all users' basic profiles
Description | Allows the app to read a basic set of profile properties of other users in your organization without a signed-in user. Includes display name, first and last name, email address, open extensions, and photo. | Allows the app to read a basic set of profile properties of other users in your organization on behalf of the signed-in user. This includes display name, first and last name, email address and photo.
AdminConsentRequired | Yes | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _User.ReadBasic.All_ delegated permission is available for consent in personal Microsoft accounts.
The _User.ReadBasic.All_ permission constrains app access to reading a limited set of properties for other users' work or school accounts. This basic profile includes only the following properties:
  * displayName
  * givenName
  * id
  * mail
  * photo
  * securityIdentifier
  * surname
  * userPrincipalName


* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userreadwrite)
### User.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | b4e74841-8e56-480b-be8b-910348b18b4c
DisplayText | - | Read and write access to user profile
Description | - | Allows the app to read your profile. It also allows the app to update your profile information on your behalf.
AdminConsentRequired | - | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _User.ReadWrite_ delegated permission is available for consent in personal Microsoft accounts.
The _User.ReadWrite_ delegated permission allow the app to update the following profile properties for the signed-in user's work or school account:
  * aboutMe
  * birthday
  * hireDate
  * interests
  * mobilePhone
  * mySite
  * pastProjects
  * photo
  * preferredName
  * responsibilities
  * schools
  * skills


* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userreadwriteall)
### User.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 741f803b-c850-494e-b5df-cde7c675a1ca | 204e0828-b5ca-4ad8-b9f3-f32a958e7cc4
DisplayText | Read and write all users' full profiles | Read and write all users' full profiles
Description | Allows the app to read and update user profiles without a signed in user. | Allows the app to read and write the full set of profile properties, reports, and managers of other users in your organization, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _User.ReadWrite.All_ delegated permission is available for consent in personal Microsoft accounts.
The _User.ReadWrite.All_ delegated and application permissions allow the app to update all the declared properties for a user's work or school account except for their **passwordProfile** and **employeeLeaveDateTime**.
Updating sensitive properties is only allowed on non-admin users and users with lesser-privileged admin roles as indicated in [Who can perform sensitive actions](https://learn.microsoft.com/en-us/graph/api/resources/users?view=graph-rest-1.0#who-can-perform-sensitive-actions).
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userreadwritecrosscloud)
### User.ReadWrite.CrossCloud
Expand table
Category | Application | Delegated
---|---|---
Identifier | 5652f862-b626-407b-a3e6-248aeb95763c | -
DisplayText | Read and write profiles of users that originate from an external cloud. | -
Description | Allows the app to read and update external cloud user profiles without a signed in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userrevokesessionsall)
### User.RevokeSessions.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 77f3a031-c388-4f99-b373-dc68676a979e | fc30e98b-8810-4501-81f5-c20a3196387b
DisplayText | Revoke all sign in sessions for a user | Revoke all sign in sessions for a user
Description | Allow the app to revoke all sign in sessions for a user, without a signed-in user. | Allow the app to revoke all sign in sessions for a user, on behalf of a signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#useractivityreadwritecreatedbyapp)
### UserActivity.ReadWrite.CreatedByApp
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 47607519-5fb1-47d9-99c7-da4b48f369b1
DisplayText | - | Read and write app activity to users' activity feed
Description | - | Allows the app to read and report the signed-in user's activity in the app.
AdminConsentRequired | - | No
![personal Microsoft accounts](https://learn.microsoft.com/en-us/graph/images/permissions-reference/msa.svg) The _UserActivity.ReadWrite.CreatedByApp_ delegated permission is available for consent in personal Microsoft accounts.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthenticationmethodread)
### UserAuthenticationMethod.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 1f6b61c5-2f65-4135-9c9f-31c0f8d32b52
DisplayText | - | Read user authentication methods.
Description | - | Allows the app to read the signed-in user's authentication methods, including phone numbers and Authenticator app settings. This does not allow the app to see secret information like the signed-in user's passwords, or to sign-in or otherwise use the signed-in user's authentication methods.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthenticationmethodreadall)
### UserAuthenticationMethod.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 38d9df27-64da-44fd-b7c5-a6fbac20248f | aec28ec7-4d02-4e8c-b864-50163aea77eb
DisplayText | Read all users' authentication methods | Read all users' authentication methods
Description | Allows the app to read authentication methods of all users in your organization, without a signed-in user. Authentication methods include things like a user's phone numbers and Authenticator app settings. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods. | Allows the app to read authentication methods of all users in your organization that the signed-in user has access to. Authentication methods include things like a user's phone numbers and Authenticator app settings. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthenticationmethodreadwrite)
### UserAuthenticationMethod.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 48971fc1-70d7-4245-af77-0beb29b53ee2
DisplayText | - | Read and write user authentication methods
Description | - | Allows the app to read and write the signed-in user's authentication methods, including phone numbers and Authenticator app settings. This does not allow the app to see secret information like the signed-in user's passwords, or to sign-in or otherwise use the signed-in user's authentication methods.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthenticationmethodreadwriteall)
### UserAuthenticationMethod.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 50483e42-d915-4231-9639-7fdb7fd190e5 | b7887744-6746-4312-813d-72daeaee7e2d
DisplayText | Read and write all users' authentication methods | Read and write all users' authentication methods.
Description | Allows the application to read and write authentication methods of all users in your organization, without a signed-in user. Authentication methods include things like a user's phone numbers and Authenticator app settings. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods | Allows the app to read and write authentication methods of all users in your organization that the signed-in user has access to. Authentication methods include things like a user's phone numbers and Authenticator app settings. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-emailread)
### UserAuthMethod-Email.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 12b23cea-90c1-4873-9094-f45c5f290f86
DisplayText | - | Read the signed-in user's email authentication methods
Description | - | Allows the app to read the signed-in user's email authentication methods. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-emailreadall)
### UserAuthMethod-Email.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | a1e58be0-1095-422b-b067-73434bd7d40f | 76caaf3a-ebdb-40a3-9299-4196e636f290
DisplayText | Read all users' email methods | Read all users' email methods
Description | Allows the app to read email methods of all users in your organization, without a signed-in user. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods. | Allows the app to read email methods of all users in your organization that the signed-in user has access to. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-emailreadwrite)
### UserAuthMethod-Email.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 696aa421-62dc-4c99-be16-015b23444089
DisplayText | - | Read and write the signed-in user's email authentication methods
Description | - | Allows the app to read and write the signed-in user's email authentication methods. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-emailreadwriteall)
### UserAuthMethod-Email.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | e8ecb853-1435-4a49-95ba-ec5b31b11672 | 074f680f-c89e-45be-880e-5d0642860a1c
DisplayText | Read and write all users' email methods | Read and write all users' email methods.
Description | Allows the application to read and write email methods of all users in your organization, without a signed-in user. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods. | Allows the app to read and write email methods of all users in your organization that the signed-in user has access to. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-externalread)
### UserAuthMethod-External.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | d1739827-146b-4f7f-b52c-1c509253aa57
DisplayText | - | Read the signed-in user's external authentication methods
Description | - | Allows the app to read the signed-in user's external authentication methods. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-externalreadall)
### UserAuthMethod-External.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | d2c4289f-9f95-40da-ad43-eeb1506f0db7 | cbca9646-4c34-4cea-8e54-9a7088018820
DisplayText | Read all users' external authentication methods | Read all users' external authentication methods
Description | Allows the app to read external authentication methods of all users in your organization, without a signed-in user. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods. | Allows the app to read external authentication methods of all users in your organization that the signed-in user has access to. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-externalreadwrite)
### UserAuthMethod-External.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 28c2e8f9-828a-4691-a090-f2f0b7fc07b3
DisplayText | - | Read and write the signed-in user's external authentication methods
Description | - | Allows the app to read and write the signed-in user's external authentication methods. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-externalreadwriteall)
### UserAuthMethod-External.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | c7a22c2e-5b01-4129-8159-6c8be2c78f16 | 9d91805d-0f53-43e3-a0f3-303ad4f3056f
DisplayText | Read and write all users' external authentication methods | Read and write all users' external methods.
Description | Allows the application to read and write external authentication methods of all users in your organization, without a signed-in user. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods. | Allows the app to read and write external authentication methods of all users in your organization that the signed-in user has access to. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-hardwareoathread)
### UserAuthMethod-HardwareOATH.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | ccd2eb40-8874-44e6-8f96-335908b3cfdb
DisplayText | - | Read the signed-in user's HardwareOATH authentication methods
Description | - | Allows the app to read the signed-in user's HardwareOATH authentication methods. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-hardwareoathreadall)
### UserAuthMethod-HardwareOATH.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 7b544555-7811-49ff-8223-a56be870e33a | acd68c26-c283-4bf4-8b5c-200fc179bdd5
DisplayText | Read all users' HardwareOATH authentication methods | Read all users' HardwareOATH authentication methods
Description | Allows the app to read HardwareOATH authentication methods of all users in your organization, without a signed-in user. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods. | Allows the app to read HardwareOATH authentication methods of all users in your organization that the signed-in user has access to. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-hardwareoathreadwrite)
### UserAuthMethod-HardwareOATH.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 147ca97b-6686-4849-b37e-09d9b5ad45fc
DisplayText | - | Read and write the signed-in user's HardwareOATH authentication methods
Description | - | Allows the app to read and write the signed-in user's HardwareOATH authentication methods. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-hardwareoathreadwriteall)
### UserAuthMethod-HardwareOATH.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 7e9ebcc1-90aa-4471-8051-e68d6b4e9c89 | 480643f2-a162-43c5-a670-dc1494fc911b
DisplayText | Read and write all users' HardwareOATH authentication methods | Read and write all users' HardwareOATH methods.
Description | Allows the application to read and write HardwareOATH authentication methods of all users in your organization, without a signed-in user. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods. | Allows the app to read and write HardwareOATH authentication methods of all users in your organization that the signed-in user has access to. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-microsoftauthappread)
### UserAuthMethod-MicrosoftAuthApp.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | f14a567b-3280-4124-95a0-eca86006967e
DisplayText | - | Read the signed-in user's Microsoft Authenticator authentication methods
Description | - | Allows the app to read the signed-in user's Microsoft Authenticator authentication methods. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-microsoftauthappreadall)
### UserAuthMethod-MicrosoftAuthApp.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | a9c5f16e-e5ca-4e33-89ad-903fcfc01c23 | 7b627679-e2fd-4bfd-990e-989e2914d4e6
DisplayText | Read all users' Microsoft authentication methods | Read all users' Microsoft authentication methods
Description | Allows the app to read Microsoft authentication methods of all users in your organization, without a signed-in user. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods. | Allows the app to read Microsoft authentication methods of all users in your organization that the signed-in user has access to. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-microsoftauthappreadwrite)
### UserAuthMethod-MicrosoftAuthApp.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 9f7dfa0c-eb40-42be-8d45-8af4a9219c6f
DisplayText | - | Read and write the signed-in user's Microsoft Authenticator authentication methods
Description | - | Allows the app to read and write the signed-in user's Microsoft Authenticator authentication methods. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-microsoftauthappreadwriteall)
### UserAuthMethod-MicrosoftAuthApp.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | c833c349-a1ab-4b6d-94a2-fa9a8674420c | 1b7322b2-5cb3-4f13-928f-d7ca97c5fba9
DisplayText | Read and write all users' Microsoft Authentication methods | Read and write all users' Microsoft Authentication methods.
Description | Allows the application to read and write Microsoft Authentication methods of all users in your organization, without a signed-in user. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods. | Allows the app to read and write Microsoft Authentication methods of all users in your organization that the signed-in user has access to. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-passkeyread)
### UserAuthMethod-Passkey.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 828fcbda-0d26-431d-8bfb-83f217224621
DisplayText | - | Read the signed-in user's passkey authentication methods
Description | - | Allows the app to read the signed-in user's passkey authentication methods. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-passkeyreadall)
### UserAuthMethod-Passkey.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 72e00c1d-3e3d-43bb-a0b9-c435611bb1d2 | 14195339-1fe4-48a7-a0d3-a39eb9fd8958
DisplayText | Read all users' passkey authentication methods | Read all users' passkey authentication methods
Description | Allows the app to read passkey authentication methods of all users in your organization, without a signed-in user. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods. | Allows the app to read passkey authentication methods of all users in your organization that the signed-in user has access to. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-passkeyreadwrite)
### UserAuthMethod-Passkey.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | b2de7db9-10f7-4800-b04c-b5b91e4891d6
DisplayText | - | Read and write the signed-in user's passkey authentication methods
Description | - | Allows the app to read and write the signed-in user's passkey authentication methods. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-passkeyreadwriteall)
### UserAuthMethod-Passkey.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 0400e371-7db1-4338-a269-96069eb65227 | 64930478-d0ea-4671-ad72-fe0d9821df09
DisplayText | Read and write all users' passkey authentication methods | Read and write all users' passkey methods.
Description | Allows the application to read and write passkey authentication methods of all users in your organization, without a signed-in user. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods | Allows the app to read and write passkey authentication methods of all users in your organization that the signed-in user has access to. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-passwordread)
### UserAuthMethod-Password.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 7f0f82c3-de19-4ddc-810d-a2206d7637fd
DisplayText | - | Read the signed-in user's password authentication methods
Description | - | Allows the app to read the signed-in user's password authentication methods. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-passwordreadall)
### UserAuthMethod-Password.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 8d2c17ff-b93d-40d5-9def-d843680509cb | 4f69a4e2-2aa0-43a7-ad6b-98b4cda1f23f
DisplayText | Read all users' password authentication methods | Read all users' password authentication methods
Description | Allows the app to read password authentication methods of all users in your organization, without a signed-in user. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods. | Allows the app to read password authentication methods of all users in your organization that the signed-in user has access to. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-passwordreadwrite)
### UserAuthMethod-Password.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 60cce20d-d41e-4594-b391-84bbf8cc31f3
DisplayText | - | Read and write the signed-in user's password authentication methods
Description | - | Allows the app to read and write the signed-in user's password authentication methods. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-passwordreadwriteall)
### UserAuthMethod-Password.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | f6d38dfd-ec08-4995-8f07-23e929df0936 | 7f5b683d-df96-4690-a88d-6e336ed6dc7c
DisplayText | Read and write all users' password authentication methods | Read and write all users' password methods.
Description | Allows the application to read and write password authentication methods of all users in your organization, without a signed-in user. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods. | Allows the app to read and write password authentication methods of all users in your organization that the signed-in user has access to. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-phoneread)
### UserAuthMethod-Phone.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 43dab3b9-e8b4-424d-8e13-6a2ad2a625fa
DisplayText | - | Read the signed-in user's phone authentication methods
Description | - | Allows the app to read the signed-in user's phone authentication methods. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-phonereadall)
### UserAuthMethod-Phone.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | f529a223-ea70-43ec-b268-5012de2fbaa2 | 20cf4ae1-09b9-4d29-a6f8-43e1820ce60c
DisplayText | Read all users' phone authentication methods | Read all users' phone authentication methods
Description | Allows the app to read phone authentication methods of all users in your organization, without a signed-in user. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods. | Allows the app to read phone authentication methods of all users in your organization that the signed-in user has access to. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-phonereadwrite)
### UserAuthMethod-Phone.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 6c4aad61-f76b-46ad-a22c-57d4d3d962af
DisplayText | - | Read and write the signed-in user's phone authentication methods
Description | - | Allows the app to read and write the signed-in user's phone authentication methods. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-phonereadwriteall)
### UserAuthMethod-Phone.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 6e85d483-7092-4375-babe-0a94a8213a58 | 48c99302-9a24-4f27-a8a7-acef4debba14
DisplayText | Read and write all users' phone methods | Read and write all users' phone methods.
Description | Allows the application to read and write phone methods of all users in your organization, without a signed-in user. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods. | Allows the app to read and write Phone methods of all users in your organization that the signed-in user has access to. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-platformcredread)
### UserAuthMethod-PlatformCred.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 9c694582-e8f2-40e2-8353-fb43e2e0f12a
DisplayText | - | Read the signed-in user's platform credential authentication methods
Description | - | Allows the app to read the signed-in user's platform credential authentication methods. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-platformcredreadall)
### UserAuthMethod-PlatformCred.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 07c0b1e4-15bd-442f-834b-30f8291388d1 | 5936156c-f89b-4850-997d-026c4e6ce529
DisplayText | Read all users' platform credentials methods | Read all users' platform credentials methods
Description | Allows the app to read platform credentials methods of all users in your organization, without a signed-in user. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods. | Allows the app to read platform credentials methods of all users in your organization that the signed-in user has access to. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-platformcredreadwrite)
### UserAuthMethod-PlatformCred.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 70327f81-b953-43c9-92d3-131c74e4beb8
DisplayText | - | Read and write the signed-in user's platform credential authentication methods
Description | - | Allows the app to read and write the signed-in user's platform credential authentication methods. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-platformcredreadwriteall)
### UserAuthMethod-PlatformCred.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 1a87acf4-a9ca-4576-a974-452ea265d5f6 | cb11bf8c-dde1-4504-b6a5-31e1562b0749
DisplayText | Read and write all users' platform credentials methods | Read and write all users' platform credentials methods.
Description | Allows the application to read and write platform credentials methods of all users in your organization, without a signed-in user. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods. | Allows the app to read and write platform credentials methods of all users in your organization that the signed-in user has access to. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-qrread)
### UserAuthMethod-QR.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | d6893c31-9187-405c-8dfc-f700c8fc161a
DisplayText | - | Read the signed-in user's QR authentication methods
Description | - | Allows the app to read the signed-in user's QR authentication methods. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-qrreadall)
### UserAuthMethod-QR.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 9a45bc50-cddd-4ebe-bd9c-4f2eacf646ae | e4900dfb-ad17-410d-8ddb-7aebd8a6af1a
DisplayText | Read all users' QR methods | Read all users' QR methods
Description | Allows the app to read QR authentication methods of all users in your organization, without a signed-in user. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods. | Allows the app to read QR authentication methods of all users in your organization that the signed-in user has access to. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-qrreadwrite)
### UserAuthMethod-QR.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 651210da-18ce-4e42-b7db-302ff88e9326
DisplayText | - | Read and write the signed-in user's QR authentication methods
Description | - | Allows the app to read and write the signed-in user's QR authentication methods. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-qrreadwriteall)
### UserAuthMethod-QR.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 4869299f-18c3-40c8-98f2-222657e67db1 | db39086a-da7d-4cbd-9ac0-6816f9a80c95
DisplayText | Read and write all users' QR methods | Read and write all users' QR methods.
Description | Allows the application to read and write QR authentication methods of all users in your organization, without a signed-in user. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods. | Allows the app to read and write QR authentication methods of all users in your organization that the signed-in user has access to. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-softwareoathread)
### UserAuthMethod-SoftwareOATH.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 247f2733-6e3d-46ff-a904-f5fd58eb0d97
DisplayText | - | Read the signed-in user's SoftwareOATH authentication methods
Description | - | Allows the app to read the signed-in user's SoftwareOATH authentication methods. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-softwareoathreadall)
### UserAuthMethod-SoftwareOATH.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | a6b423df-a0c8-411d-a809-a4a5985d2939 | 3e366fa0-3097-4eb6-8294-3028f77eea6f
DisplayText | Read all users' SoftwareOATH methods | Read all users' SoftwareOATH methods
Description | Allows the app to read SoftwareOATH authentication methods of all users in your organization, without a signed-in user. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods. | Allows the app to read SoftwareOATH authentication methods of all users in your organization that the signed-in user has access to. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-softwareoathreadwrite)
### UserAuthMethod-SoftwareOATH.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 16721eb3-4493-4ae1-9542-264d9ffe3ce9
DisplayText | - | Read and write the signed-in user's SoftwareOATH authentication methods
Description | - | Allows the app to read and write the signed-in user's SoftwareOATH authentication methods. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-softwareoathreadwriteall)
### UserAuthMethod-SoftwareOATH.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 787442d4-3c6e-4e99-aa95-8ccca20a48ff | 5b34c8b5-2396-4b35-b284-83fb6a3e73ce
DisplayText | Read and write all users' SoftwareOATH methods | Read and write all users' SoftwareOATH methods.
Description | Allows the application to read and write SoftwareOATH authentication methods of all users in your organization, without a signed-in user. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods. | Allows the app to read and write SoftwareOATH authentication methods of all users in your organization that the signed-in user has access to. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-tapread)
### UserAuthMethod-TAP.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 84ded88f-26ba-49d6-b776-efec398de692
DisplayText | - | Read the signed-in user's Temporary Access Pass authentication methods
Description | - | Allows the app to read the signed-in user's Temporary Access Pass authentication methods. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-tapreadall)
### UserAuthMethod-TAP.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | bf82209c-b22b-4747-ac88-a68be99032cf | 6976c635-c9c2-41e6-a21d-e6913a155273
DisplayText | Read all users' Temporary Access Pass methods | Read all users' Temporary Access Pass methods
Description | Allows the app to read Temporary Access Pass authentication methods of all users in your organization, without a signed-in user. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods. | Allows the app to read Temporary Access Pass authentication methods of all users in your organization that the signed-in user has access to. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-tapreadwrite)
### UserAuthMethod-TAP.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 2424436d-902f-4651-a1c7-b3b93147c960
DisplayText | - | Read and write the signed-in user's Temporary Access Pass authentication methods
Description | - | Allows the app to read and write the signed-in user's Temporary Access Pass authentication methods. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-tapreadwriteall)
### UserAuthMethod-TAP.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 627169a8-8c15-451c-861a-5b80e383de5c | 05de4a66-e51a-4312-842a-30c8094698d2
DisplayText | Read and write all users' Temporary Access Pass methods | Read and write all users' Temporary Access Pass methods.
Description | Allows the application to read and write Temporary Access Pass authentication methods of all users in your organization, without a signed-in user. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods. | Allows the app to read and write Temporary Access Pass authentication methods of all users in your organization that the signed-in user has access to. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-windowshelloread)
### UserAuthMethod-WindowsHello.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | efe2b5aa-3a8e-486c-b0be-cc4d185c1b40
DisplayText | - | Read the signed-in user's Windows Hello methods
Description | - | Allows the app to read the signed-in user's Windows Hello authentication methods. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-windowshelloreadall)
### UserAuthMethod-WindowsHello.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 9b8dd4c7-8cca-4ef5-a34a-9c2c75fcc934 | ff37d46d-b88a-4e0c-85ee-7e26c37b18eb
DisplayText | Read all users' Windows Hello methods | Read all users' Windows Hello methods
Description | Allows the app to read Windows Hello authentication methods of all users in your organization, without a signed-in user. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods. | Allows the app to read Windows Hello authentication methods of all users in your organization that the signed-in user has access to. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-windowshelloreadwrite)
### UserAuthMethod-WindowsHello.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | f11e1db9-d419-4a24-b677-792723ffd727
DisplayText | - | Read and write the signed-in user's Windows Hello authentication methods
Description | - | Allows the app to read and write the signed-in user's Windows Hello authentication methods. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userauthmethod-windowshelloreadwriteall)
### UserAuthMethod-WindowsHello.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | f14eee8a-713e-45aa-8223-2ab74632db1a | 13eae17d-aaa4-47b8-aaee-0eb33c6e2450
DisplayText | Read and write all users' Windows Hello authentication methods | Read and write all users' Windows Hello methods.
Description | Allows the application to read and write Windows Hello authentication methods of all users in your organization, without a signed-in user. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods. | Allows the app to read and write Windows Hello authentication methods of all users in your organization that the signed-in user has access to. This does not allow the app to see secret information like passwords, or to sign-in or otherwise use the authentication methods.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#usercloudclipboardread)
### UserCloudClipboard.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 61e8a09a-087f-4e36-8c8c-1c77c5228017
DisplayText | - | Read cloud clipboard items
Description | - | Allows the app to read cloud clipboard data on behalf of the signed-in user.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#usernotificationreadwritecreatedbyapp)
### UserNotification.ReadWrite.CreatedByApp
Expand table
Category | Application | Delegated
---|---|---
Identifier | 4e774092-a092-48d1-90bd-baad67c7eb47 | 26e2f3e8-b2a1-47fc-9620-89bb5b042024
DisplayText | Deliver and manage all user's notifications | Deliver and manage user's notifications
Description | Allows the app to send, read, update and delete user's notifications, without a signed-in user. | Allows the app to send, read, update and delete user's notifications.
AdminConsentRequired | Yes | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#usershiftpreferencesreadall)
### UserShiftPreferences.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | de023814-96df-4f53-9376-1e2891ef5a18 | -
DisplayText | Read all user shift preferences | -
Description | Allows the app to read all users' shift schedule preferences without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#usershiftpreferencesreadwriteall)
### UserShiftPreferences.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | d1eec298-80f3-49b0-9efb-d90e224798ac | -
DisplayText | Read and write all user shift preferences | -
Description | Allows the app to manage all users' shift schedule preferences without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userteamworkread)
### UserTeamwork.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 834bcc1c-762f-41b0-bb91-1cdc323ee4bf
DisplayText | - | Read user teamwork settings
Description | - | Allows the app to read the teamwork settings of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userteamworkreadall)
### UserTeamwork.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | fbcd7ef1-df0d-4e05-bb28-93424a89c6df | -
DisplayText | Read all user teamwork settings | -
Description | Allows the app to read all user teamwork settings without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#usertimelineactivitywritecreatedbyapp)
### UserTimelineActivity.Write.CreatedByApp
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 367492fc-594d-4972-a9b5-0d58c622c91c
DisplayText | - | Write app activity to users' timeline
Description | - | Allows the app to report the signed-in user's app activity information to Microsoft Timeline.
AdminConsentRequired | - | No
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userwindowssettingsreadall)
### UserWindowsSettings.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 77e07bab-1b34-40a5-bb6c-4b197b3f6027
DisplayText | - | Read windows settings for all devices
Description | - | Allows the app to read a user's windows settings which are stored in cloud and their values on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#userwindowssettingsreadwriteall)
### UserWindowsSettings.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | dcb1026d-b7e1-4d31-9f61-6724d5140bf9
DisplayText | - | Read and write windows settings for all devices
Description | - | Allows the app to read and write a user's windows settings which are stored in cloud and their values on behalf of the signed-in user.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#verifiedid-profilereadall)
### VerifiedId-Profile.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | e227c591-dd64-4a8a-a033-816167f7c938 | 604b2056-41ed-4c56-aad5-1241d4ef7333
DisplayText | Read Verified Id profiles | Read Verified Id profiles
Description | This role can read Verified Id profiles in a tenant. | This role can read Verified Id profiles in a tenant.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#verifiedid-profilereadwriteall)
### VerifiedId-Profile.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | e4a9cb5e-4767-48f8-9029-decf26a54456
DisplayText | - | Read and write Verified Id profiles
Description | - | This role can read and write Verified Id profiles in a tenant.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#virtualappointmentread)
### VirtualAppointment.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 27470298-d3b8-4b9c-aad4-6334312a3eac
DisplayText | - | Read a user's virtual appointments
Description | - | Allows an application to read virtual appointments for the signed-in user. Only an organizer or participant user can read their virtual appointments.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#virtualappointmentreadall)
### VirtualAppointment.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | d4f67ec2-59b5-4bdc-b4af-d78f6f9c1954 | -
DisplayText | Read all virtual appointments for users, as authorized by online meetings application access policy | -
Description | Allows the application to read virtual appointments for all users, without a signed-in user. The app must also be authorized to access an individual user's data by the online meetings application access policy. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#virtualappointmentreadwrite)
### VirtualAppointment.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 2ccc2926-a528-4b17-b8bb-860eed29d64c
DisplayText | - | Read and write a user's virtual appointments
Description | - | Allows an application to read and write virtual appointments for the signed-in user. Only an organizer or participant user can read and write their virtual appointments.
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#virtualappointmentreadwriteall)
### VirtualAppointment.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | bf46a256-f47d-448f-ab78-f226fff08d40 | -
DisplayText | Read-write all virtual appointments for users, as authorized by online meetings app access policy | -
Description | Allows the application to read and write virtual appointments for all users, without a signed-in user. The app must also be authorized to access an individual user's data by the online meetings application access policy. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#virtualappointmentnotificationsend)
### VirtualAppointmentNotification.Send
Expand table
Category | Application | Delegated
---|---|---
Identifier | 97e45b36-1250-48e4-bd70-2df6dab7e94a | 20d02fff-a0ef-49e7-a46e-019d4a6523b7
DisplayText | Send notification regarding virtual appointments as any user | Send notification regarding virtual appointments for the signed-in user
Description | Allows the application to send notification regarding virtual appointments as any user, without a signed-in user. The app must also be authorized to access an individual user's data by the online meetings application access policy. | Allows an application to send notifications for virtual appointments for the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#virtualeventread)
### VirtualEvent.Read
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | 6b616635-ae58-433a-a918-8c45e4f304dc
DisplayText | - | Read your virtual events
Description | - | Allows the app to read virtual events created by you
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#virtualeventreadall)
### VirtualEvent.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 1dccb351-c4e4-4e09-a8d1-7a9ecbf027cc | -
DisplayText | Read all users' virtual events | -
Description | Allows the app to read all virtual events without a signed-in user. | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#virtualeventreadwrite)
### VirtualEvent.ReadWrite
Expand table
Category | Application | Delegated
---|---|---
Identifier | - | d38d189c-e29b-4344-8b3b-829bfa81380b
DisplayText | - | Read and write your virtual events
Description | - | Allows the app to read and write virtual events for you
AdminConsentRequired | - | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#virtualeventregistration-anonreadwriteall)
### VirtualEventRegistration-Anon.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 23211fc1-f9d1-4e8e-8e9e-08a5d0a109bb | -
DisplayText | Read and write anonymous users' virtual event registrations | -
Description | Allows the app to read and write anonymous users' virtual event registrations, without a signed-in user | -
AdminConsentRequired | Yes | -
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#windowsupdatesreadwriteall)
### WindowsUpdates.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 7dd1be58-6e76-4401-bf8d-31d1e8180d5b | 11776c0c-6138-4db3-a668-ee621bea2555
DisplayText | Read and write all Windows update deployment settings | Read and write all Windows update deployment settings
Description | Allows the app to read and write all Windows update deployment settings for the organization without a signed-in user. | Allows the app to read and write all Windows update deployment settings for the organization on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#workforceintegrationreadall)
### WorkforceIntegration.Read.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | f10b94b9-37d1-4c88-8b7e-bf75a1152d39 | f1ccd5a7-6383-466a-8db8-1a656f7d06fa
DisplayText | Read workforce integrations | Read workforce integrations
Description | Allows the app to read workforce integrations without a signed-in user. | Allows the app to read workforce integrations, to synchronize data from Microsoft Teams Shifts, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#workforceintegrationreadwriteall)
### WorkforceIntegration.ReadWrite.All
Expand table
Category | Application | Delegated
---|---|---
Identifier | 202bf709-e8e6-478e-bcfd-5d63c50b68e3 | 08c4b377-0d23-4a8b-be2a-23c1c1d88545
DisplayText | Read and write workforce integrations | Read and write workforce integrations
Description | Allows the app to manage workforce integrations to synchronize data from Microsoft Teams Shifts, without a signed-in user. | Allows the app to manage workforce integrations, to synchronize data from Microsoft Teams Shifts, on behalf of the signed-in user.
AdminConsentRequired | Yes | Yes
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#resource-specific-consent-rsc-permissions)
## Resource-specific consent (RSC) permissions
Learn more about [RSC authorization framework and RSC permissions](https://learn.microsoft.com/en-us/microsoftteams/platform/graph-api/rsc/resource-specific-consent).
* * *
Expand table
Name | ID | Display text | Description
---|---|---|---
AiEnterpriseInteraction.Read.User | 10d712aa-b4cd-4472-b0ba-6196e04c344f | Read user AI enterprise interactions. | Allows the app to read user AI enterprise interactions, without a signed-in user.
CallAiInsights.Read.Chat | ff9d3910-ca91-4e7f-843f-d44ab36a961a | Read all AI Insights for calls where the Teams application is installed. | Allows the teams-app to read all aiInsights for calls where the Teams-app is installed, without a signed-in user.
CallRecordings.Read.Chat | 22748df0-bd8c-4626-aad9-6dab421b33e4 | Read all recordings of calls where the Teams application is installed. | Allows the teams-app to read all recordings of calls where the Teams-app is installed, without a signed-in user.
Calls.AccessMedia.Chat | e716890c-c30a-4ac3-a0e3-551e7d9e8deb | Access media streams in calls associated with this chat or meeting | Allows the app to access media streams in calls associated with this chat or meeting, without a signed-in user.
Calls.JoinGroupCalls.Chat | a01e73f1-94da-4f6d-9b73-02e4ea65560b | Join calls associated with this chat or meeting | Allows the app to join calls associated with this chat or meeting, without a signed-in user.
CallTranscripts.Read.Chat | 7990a5df-4c51-43ea-939c-3e8b18d6ddad | Read all transcripts of calls where the Teams app is installed. | Allows the Teams app to read all transcripts of calls where the Teams-app is installed, without a signed-in user.
Channel.Create.Group | 65af85d7-62bb-4339-a206-7160fd427454 | Create channels in this team | Allows the app to create channels in this team, without a signed-in user.
Channel.Delete.Group | 4432e57d-0983-4c17-881c-235c529f96dc | Delete this team's channels | Allows the app to delete this team's channels, without a signed-in user.
ChannelMeeting.ReadBasic.Group | 6c13459c-facc-4b0a-93cb-63f0dff28046 | Read basic properties of the channel meetings in this team | Allows the app to read basic properties, such as name, schedule, organizer, join link, and start or end notifications, of channel meetings in this team, without a signed-in user.
ChannelMeetingNotification.Send.Group | bbb12bdb-71e6-4602-9f5e-b1172c505746 | Send notifications in all the channel meetings associated with this team | Allows the app to send notifications inside all the channel meetings associated with this team, without a signed-in user.
ChannelMeetingParticipant.Read.Group | bd118236-e8f5-4bec-a62d-89a623717e05 | Read the participants of this team's channel meetings | Allows the app to read participant information, including name, role, id, joined and left times, of channel meetings associated with this team, without a signed-in user.
ChannelMeetingRecording.Read.Group | 30a40618-9b50-4764-b62e-b04023a8f5f3 | Read the recordings of all channel meetings associated with this team | Allows the app to read recordings of all the channel meetings associated with this team, without a signed-in user.
ChannelMeetingTranscript.Read.Group | 37e59e88-1a46-482b-b623-0a4aa6abdf67 | Read the transcripts of all channel meetings associated with this team | Allows the app to read transcripts of all the channel meetings associated with this team, without a signed-in user.
ChannelMember.Read.Group | 7e3614f5-3467-419c-9c63-dd0bbd2a88f9 | Read the members of channels of a team | Read the members of channels of a team, without a signed-in user
ChannelMember.ReadWrite.Group | 1342a0fc-cd33-4c75-ad65-d5defcfc7232 | Read and write the members of channels of a team | Read and write the members of channels of a team, without a signed-in user
ChannelMessage.Read.Group | 19103a54-c397-4bcd-be5a-ef111e0406fa | Read this team's channel messages | Allows the app to read this team's channel's messages, without a signed-in user.
ChannelMessage.Send.Group | 3e38d437-815b-4368-9f19-e39dea9a6c7f | Send messages to this team's channels | Allows the app to send messages to this team's channels, without a signed-in user.
ChannelSettings.Read.Group | 0a7b3084-8d18-46f5-8aef-b5b829292c6f | Read the names, descriptions, and settings of this team's channels | Allows the app to read this team's channel names, channel descriptions, and channel settings, without a signed-in user.
ChannelSettings.ReadWrite.Group | d057ad03-b27b-49f7-8219-e0d4a706da55 | Update the names, descriptions, and settings of this team's channels | Allows the app to update and read the names, descriptions, and settings of this team's channels, without a signed-in user.
Chat.Manage.Chat | 4a14842e-6bb6-4088-b21a-7d0a24f835a6 | Manage this chat | Allows the app to manage the chat, the chat's members and grant access to the chat's data, without a signed-in user.
Chat.ManageDeletion.Chat | b827a2af-24b2-4f61-9eb3-8788e66a0d86 | Delete and recover deleted chat | Allows the app to delete and recover deleted chat, without a signed-in user.
ChatMember.Read.Chat | e854bbc6-07e3-45cc-af99-b6e78fab5b80 | Read this chat's members | Allows the app to read the members of this chat, without a signed-in user.
ChatMessage.Read.Chat | 9398c3de-3f6b-4958-90f3-5098714ff50c | Read this chat's messages | Allows the app to read this chat's messages, without a signed-in user.
ChatMessage.Send.Chat | 19cbeeb2-02a0-49d7-95cd-ab0841beed7f | Send messages to this chat | Allows the app to send messages to this chat, without a signed-in user.
ChatMessageReadReceipt.Read.Chat | a236cb34-7076-45a1-9381-22db8111a3d3 | Read the ID of the last seen message in this chat | Allows the app to read the ID of the last message seen by the users in this chat.
ChatSettings.Read.Chat | 40d35d7c-9cc3-4f2d-912b-464457412a00 | Read this chat's settings | Allows the app to read this chat's settings, without a signed-in user.
ChatSettings.ReadWrite.Chat | ed928a9c-7530-496a-a624-4c0a460ab3ed | Read and write this chat's settings | Allows the app to read and write this chat's settings, without a signed-in user.
Member.Read.Group | 0a8ce3c7-89dd-46cf-b2c3-5ef0064437a8 | Read this group's members | Allows the app to read the basic profile of this group's members, without a signed-in user.
OnlineMeeting.Read.Chat | f991ed3f-9617-4d8d-b06c-d18d9fcbcf2a | Read this meeting and subscribe to meeting call updates . | Allows the app to read this meeting and subscribe to meeting call updates.
OnlineMeeting.ReadBasic.Chat | eda8d262-4e6e-4ff6-a7ba-a2fb50535165 | Read basic properties of meetings associated with this chat | Allows the app to read basic properties, such as name, schedule, organizer, join link, and start or end notifications, of meetings associated with this chat, without a signed-in user.
OnlineMeeting.ReadWrite.Chat | 93400bb4-2282-4371-a745-a86d64c966d0 | Manage this meeting and subscribe to meeting call updates. | Allows the app to manage this online meeting, and subscribe to meeting call updates.
OnlineMeetingArtifact.Read.Chat | c5d06837-8c0d-42fc-9e49-545e3f941261 | Read virtual event artifacts | Read attendance reports & attendance records for this webinar or town hall.
OnlineMeetingNotification.Send.Chat | d9837fe0-9c31-4faa-8acb-b10874560161 | Send notifications in the meetings associated with this chat | Allows the app to send notifications inside meetings associated with this chat, without a signed-in user.
OnlineMeetingParticipant.Read.Chat | 6324a770-185c-4b4f-be13-2d9a1668e6eb | Read the participants of the meetings associated with this chat | Allows the app to read participant information, including name, role, id, joined and left times, of meetings associated with this chat, without a signed-in user.
OnlineMeetingRecording.Read.Chat | d20f0153-08ff-48a9-b299-96a8d1131d1d | Read the recordings of the meetings associated with this chat | Allows the app to read recordings of the meetings associated with this chat, without a signed-in user.
OnlineMeetingTranscript.Read.Chat | 8c477e19-f0f7-45f9-ae72-604f77a599e3 | Read the transcripts of the meetings associated with this chat | Allows the app to read transcripts of the meetings associated with this chat, without a signed-in user.
Owner.Read.Group | 70d5316c-9b27-4057-a650-3b0fe49002ab | Read this group's owners | Allows the app to read the basic profile of this group's owners, without a signed-in user.
Team.Read.Group | 41027e3b-d156-4913-bb0d-06cbbe931eb7 | Read this team's metadata | Allows the app to read this team's metadata, without a signed-in user.
TeamMember.Read.Group | b8731755-de22-4604-be08-93e1e5c2d2d6 | Read this team's members | Allows the app to read the members of this team, without a signed-in user.
TeamsActivity.Send.Chat | 119b5846-be45-44cd-87d7-bfc566330e11 | Send activity feed notifications to users in this chat | Allows the app to create new notifications in the teamwork activity feeds of the users in this chat, without a signed-in user.
TeamsActivity.Send.Group | d4539c25-0937-4095-b844-b97228dd8655 | Send activity feed notifications to users in this team | Allows the app to create new notifications in the teamwork activity feeds of the users in this team, without a signed-in user.
TeamsActivity.Send.User | 483c432d-7210-44e7-a362-954c0c5e4108 | Send activity feed notifications to this user | Allows the app to create new notifications in the teamwork activity feed of this user, without a signed-in user.
TeamsAppInstallation.Read.Chat | b60343cd-f77a-4c4f-8036-41938b1abd8b | Read which apps are installed in this chat | Allows the app to read the Teams apps that are installed in this chat along with the permissions granted to each app, without a signed-in user.
TeamsAppInstallation.Read.Group | ba4beb29-863b-4f02-8969-37a289cd91c0 | Read which apps are installed in this team | Allows the app to read the Teams apps that are installed in this team, without a signed-in user.
TeamsAppInstallation.Read.User | 39a4b5e8-1aa6-4da4-877a-d2345944028d | Read installed Teams apps for a user | Allows the app to read the Teams apps that are installed in user's personal scope, without a signed-in user. Does not give the ability to read application-specific settings.
TeamSettings.Edit.Group | 33f7a028-d012-4bd9-b40f-3c970d089bc8 | Edit this team's settings | Allows the app to edit this team's settings, without a signed-in user.
TeamSettings.Read.Group | 87909ea6-7b07-42cf-b3a0-b8bd8e7072a8 | Read this team's settings | Allows the app to read this team's settings, without a signed-in user.
TeamSettings.ReadWrite.Group | 13451d84-ced2-4d45-9b0d-98688b90e5bf | Read and write this team's settings | Allows the app to read and write this team's settings, without a signed-in user.
TeamsTab.Create.Chat | 0029d2bb-fc98-4712-9310-69dd5fcc94d5 | Create tabs in this chat | Allows the app to create tabs in this chat, without a signed-in user.
TeamsTab.Create.Group | c4d7203b-1e46-4c4a-95f9-862779aa39e1 | Create tabs in this team | Allows the app to create tabs in this team, without a signed-in user.
TeamsTab.Delete.Chat | fa50d890-02fe-4696-b82b-110dc7f7382a | Delete this chat's tabs | Allows the app to delete this chat's tabs, without a signed-in user.
TeamsTab.Delete.Group | cc2e79a6-9a86-45cc-91c1-41c15745287e | Delete this team's tabs | Allows the app to delete this team's tabs, without a signed-in user.
TeamsTab.Read.Chat | aa07ff41-1317-4f07-8edb-a1558e9bfc84 | Read this chat's tabs | Allows the app to read this chat's tabs, without a signed-in user.
TeamsTab.Read.Group | 60d920d0-44e7-44f4-a811-1a172a2ea5b3 | Read this team's tabs | Allows the app to read this team's tabs, without a signed-in user.
TeamsTab.ReadWrite.Chat | d583f4d7-57da-4b2c-9744-253e9ec3c7be | Manage this chat's tabs | Allows the app to manage this chat's tabs, without a signed-in user.
TeamsTab.ReadWrite.Group | 717ca3a4-bc73-47f8-b613-4d43e657fa9c | Manage this team's tabs | Allows the app to manage this team's tabs, without a signed-in user.
VirtualEvent.Read.Chat | 298266a0-fbf7-4804-b988-5a54e61566c8 | Read virtual event details | Read information for this webinars or town halls, including schedules, speakers, and event settings and webinar registrations.
VirtualEventRegistration-Anon.ReadWrite.Chat | 0e646cc8-6b07-4030-9a41-a7db4644b4cc | Manage virtual event registrations | Register attendees and cancel registrations for this webinar.
* * *
[](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#related-content)
## Related content
  * [Overview of Microsoft Graph permissions](https://learn.microsoft.com/en-us/graph/permissions-overview)
  * [Grant or revoke Microsoft Graph permissions programmatically](https://learn.microsoft.com/en-us/graph/permissions-grant-via-msgraph)


* * *
## Feedback
Was this page helpful?
Yes No No
Need help with this topic?
Want to try using Ask Learn to clarify or guide you through this topic?
Ask Learn Ask Learn
Suggest a fix?
* * *
##  Additional resources
[ AI Apps & Agents Dev Days ](https://aka.ms/AIAppsandAgentsLearn)
Feb 27, 1 AM - Feb 27, 1 AM
Experiment with what's next in AI-driven apps and agent design
[ Register now ](https://aka.ms/AIAppsandAgentsLearn)
* * *
  * Last updated on 02/23/2026


##  In this article
  1. [All permissions](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#all-permissions)
  2. [Resource-specific consent (RSC) permissions](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#resource-specific-consent-rsc-permissions)
  3. [Related content](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0#related-content)


Was this page helpful?
Yes No No
Need help with this topic?
Want to try using Ask Learn to clarify or guide you through this topic?
Ask Learn Ask Learn
Suggest a fix?
##
Ask Learn
Preview
Ask Learn is an AI assistant that can answer questions, clarify concepts, and define terms using trusted Microsoft documentation.
Please sign in to use Ask Learn.
[ Sign in ](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0)
[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fpermissions-reference%3Fview%3Dgraph-rest-1.0)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
