[ Skip to main content ](https://learn.microsoft.com/en-us/graph/toolkit/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0&tabs=html#main) [ Skip to Ask Learn chat experience ](https://learn.microsoft.com/en-us/graph/toolkit/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0&tabs=html)
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/graph/toolkit/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0&tabs=html)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/graph/toolkit/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0&tabs=html)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/graph/toolkit/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0&tabs=html)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/graph/toolkit/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0&tabs=html)
[ Microsoft Graph  ](https://learn.microsoft.com/en-us/graph/)
  * [ Guides ](https://learn.microsoft.com/en-us/graph/overview)
  * [ API Reference ](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0)
  * Resources
    * [ All resources ](https://developer.microsoft.com/en-us/graph/gallery)
    * [ Blog ](https://devblogs.microsoft.com/microsoft365dev/category/microsoft-graph/)
    * [ Changelog ](https://developer.microsoft.com/en-us/graph/changelog)
    * [ Community calls ](https://aka.ms/M365DevCalls)
    * [ Samples & SDKs ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Samples,SDKs)
    * [ Training ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Training)
    * [ Tools ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Tools)
    * [ Videos & podcasts ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Podcasts,Videos)
    * [ Support ](https://developer.microsoft.com/en-us/graph/support)
    * [ My apps ](https://go.microsoft.com/fwlink/?linkid=2083908)
    * Developer program
      * [ Join ](https://developer.microsoft.com/en-us/microsoft-365/dev-program)
      * [ Dashboard ](https://developer.microsoft.com/en-us/microsoft-365/profile)
      * [ Developer program docs ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program)
      * [ FAQ ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program-faq)
  * More
    * [ Guides ](https://learn.microsoft.com/en-us/graph/overview)
    * [ API Reference ](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0)
    * Resources
      * [ All resources ](https://developer.microsoft.com/en-us/graph/gallery)
      * [ Blog ](https://devblogs.microsoft.com/microsoft365dev/category/microsoft-graph/)
      * [ Changelog ](https://developer.microsoft.com/en-us/graph/changelog)
      * [ Community calls ](https://aka.ms/M365DevCalls)
      * [ Samples & SDKs ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Samples,SDKs)
      * [ Training ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Training)
      * [ Tools ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Tools)
      * [ Videos & podcasts ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Podcasts,Videos)
      * [ Support ](https://developer.microsoft.com/en-us/graph/support)
      * [ My apps ](https://go.microsoft.com/fwlink/?linkid=2083908)
      * Developer program
        * [ Join ](https://developer.microsoft.com/en-us/microsoft-365/dev-program)
        * [ Dashboard ](https://developer.microsoft.com/en-us/microsoft-365/profile)
        * [ Developer program docs ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program)
        * [ FAQ ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program-faq)


[ Download SDKs ](https://learn.microsoft.com/graph/sdks/sdks-overview) [ Open Graph Explorer ](https://developer.microsoft.com/en-us/graph/graph-explorer)
Search
Suggestions will filter as you type
  * [Overview of Microsoft Graph](https://learn.microsoft.com/en-us/graph/overview?view=graph-rest-1.0)
  * [Users you can reach](https://learn.microsoft.com/en-us/graph/users-you-can-reach?view=graph-rest-1.0)
  * [National cloud deployments](https://learn.microsoft.com/en-us/graph/deployments?view=graph-rest-1.0)
  * [Versioning and support](https://learn.microsoft.com/en-us/graph/versioning-and-support?view=graph-rest-1.0)
  * [Terms of use](https://learn.microsoft.com/en-us/legal/microsoft-apis/terms-of-use?context=graph%2Fcontext&view=graph-rest-1.0)
  *     * [Services and features](https://learn.microsoft.com/en-us/graph/overview-major-services?view=graph-rest-1.0)
    * [What's new](https://learn.microsoft.com/en-us/graph/whats-new-overview?view=graph-rest-1.0)
    * [API changelog](https://developer.microsoft.com/graph/changelog)
  *     * [Try the APIs](https://learn.microsoft.com/en-us/graph/graph-explorer/graph-explorer-overview?view=graph-rest-1.0)
    * [Quick start](https://developer.microsoft.com/graph/quick-start)
    *       * [Overview](https://learn.microsoft.com/en-us/graph/toolkit/overview?view=graph-rest-1.0)
      * [Permissions](https://learn.microsoft.com/en-us/graph/toolkit/permissions?view=graph-rest-1.0)
      * [Upgrade to the latest version](https://learn.microsoft.com/en-us/graph/toolkit/upgrade?view=graph-rest-1.0)
    * [Deploy in IaC with templates](https://learn.microsoft.com/en-us/graph/templates?toc=%2Fgraph%2Ftoc.json&view=graph-rest-1.0)
  *     * [Compliance](https://learn.microsoft.com/en-us/graph/compliance-concept-overview?view=graph-rest-1.0)
    * [Financials (preview)](https://learn.microsoft.com/en-us/graph/dynamics-business-central-concept-overview?view=graph-rest-1.0)
    * [Industry data ETL (preview)](https://learn.microsoft.com/en-us/graph/industrydata-concept-overview?view=graph-rest-1.0)
  *     * [Microsoft Graph activity logs](https://learn.microsoft.com/en-us/graph/microsoft-graph-activity-logs-overview?view=graph-rest-1.0)
    * [Configure Connected Services](https://learn.microsoft.com/en-us/graph/office-365-connected-services?view=graph-rest-1.0)
    * [Best practices](https://learn.microsoft.com/en-us/graph/best-practices-concept?view=graph-rest-1.0)
    * [Known issues](https://developer.microsoft.com/graph/known-issues)
    * [Errors](https://learn.microsoft.com/en-us/graph/errors?view=graph-rest-1.0)
    * [Microsoft Entra service limits](https://learn.microsoft.com/en-us/entra/identity/users/directory-service-limits-restrictions?toc=%2Fgraph%2Ftoc.json&view=graph-rest-1.0)
  * [API v1.0 reference](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0&preserve-view=true)
  * [API beta reference](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-beta&preserve-view=true)


Download PDF
Table of contents  Exit editor mode
  1. [ Learn ](https://learn.microsoft.com/en-us/?view=graph-rest-1.0)
  2. [ Microsoft Graph ](https://learn.microsoft.com/en-us/graph/?view=graph-rest-1.0)


  1. [Learn](https://learn.microsoft.com/en-us/?view=graph-rest-1.0)
  2. [Microsoft Graph](https://learn.microsoft.com/en-us/graph/?view=graph-rest-1.0)


Ask Learn Ask Learn Focus mode
Table of contents [ Read in English ](https://learn.microsoft.com/en-us/graph/toolkit/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0&tabs=html) Add to Collections Add to plan [ Edit ](https://github.com/microsoftgraph/microsoft-graph-docs-contrib/blob/main/concepts/toolkit/overview.md)
* * *
#### Share via
[ Facebook ](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Ftoolkit%2Foverview%3Fcontext%3Dgraph%252Fapi%252F1.0%26view%3Dgraph-rest-1.0%26tabs%3Dhtml%26WT.mc_id%3Dfacebook) [ x.com ](https://twitter.com/intent/tweet?original_referer=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Ftoolkit%2Foverview%3Fcontext%3Dgraph%252Fapi%252F1.0%26view%3Dgraph-rest-1.0%26tabs%3Dhtml%26WT.mc_id%3Dtwitter&tw_p=tweetbutton&url=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Ftoolkit%2Foverview%3Fcontext%3Dgraph%252Fapi%252F1.0%26view%3Dgraph-rest-1.0%26tabs%3Dhtml%26WT.mc_id%3Dtwitter) [ LinkedIn ](https://www.linkedin.com/feed/?shareActive=true&text=%0A%0D%0Ahttps%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Ftoolkit%2Foverview%3Fcontext%3Dgraph%252Fapi%252F1.0%26view%3Dgraph-rest-1.0%26tabs%3Dhtml%26WT.mc_id%3Dlinkedin) Email
* * *
Copy Markdown Print
* * *
Note
Access to this page requires authorization. You can try [signing in](https://learn.microsoft.com/en-us/graph/toolkit/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0&tabs=html) or changing directories.
Access to this page requires authorization. You can try changing directories.
# Microsoft Graph Toolkit overview
Feedback
Summarize this article for me
##  In this article
  1. [Why use Microsoft Graph Toolkit?](https://learn.microsoft.com/en-us/graph/toolkit/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0&tabs=html#why-use-microsoft-graph-toolkit)
  2. [Who should use it?](https://learn.microsoft.com/en-us/graph/toolkit/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0&tabs=html#who-should-use-it)
  3. [What's in Microsoft Graph Toolkit?](https://learn.microsoft.com/en-us/graph/toolkit/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0&tabs=html#whats-in-microsoft-graph-toolkit)
  4. [Where can I use it?](https://learn.microsoft.com/en-us/graph/toolkit/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0&tabs=html#where-can-i-use-it)
  5. [Next steps](https://learn.microsoft.com/en-us/graph/toolkit/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0&tabs=html#next-steps)


The Microsoft Graph Toolkit is deprecated. The retirement period begins September 1, 2025, with full retirement planned for August 28, 2026. Developers should migrate to using the Microsoft Graph SDKs or other supported Microsoft Graph tools for building web experiences. For more information, see the [deprecation announcement](https://devblogs.microsoft.com/microsoft365dev/microsoft-graph-toolkit-retirement/).
Microsoft Graph Toolkit is a collection of reusable, framework-agnostic components and authentication providers for accessing and working with Microsoft Graph. The components are fully functional right out of the box, with built-in providers that authenticate with and fetch data from Microsoft Graph.
Microsoft Graph Toolkit makes it easy to use Microsoft Graph in your application. In the following example, a signed-in user and their calendar events are displayed with just two lines of code by using the [Login](https://learn.microsoft.com/en-us/graph/toolkit/components/login) and [Agenda](https://learn.microsoft.com/en-us/graph/toolkit/components/agenda) components.
  * [HTML](https://learn.microsoft.com/en-us/graph/toolkit/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0&tabs=html#tabpanel_1_html)
  * [React](https://learn.microsoft.com/en-us/graph/toolkit/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0&tabs=html#tabpanel_1_react)


[Open this example in mgt.dev](https://mgt.dev/?path=/story/samples-embed--login-to-show-agenda&source=docs).
[Open this example in mgt.dev](https://mgt.dev/?path=/story/samples-embed--login-to-show-agenda-react&source=docs).
[](https://learn.microsoft.com/en-us/graph/toolkit/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0&tabs=html#why-use-microsoft-graph-toolkit)
## Why use Microsoft Graph Toolkit?
Microsoft Graph Toolkit enables you to quickly and easily integrate common experiences powered by Microsoft Graph into your own application. The toolkit:
  * **Cuts development time**. The work to connect to Microsoft Graph APIs and render the data in a UI that looks and feels like a Microsoft 365 experience is done for you, with no customization required.
  * **Works everywhere**. All components are based on web standards and work seamlessly with any modern browser and web framework (such as React, Angular, or Vue).
  * **Is beautiful but flexible**. The components are designed to look and feel like Microsoft 365 experiences but are also customizable by using [CSS custom properties](https://learn.microsoft.com/en-us/graph/toolkit/customize-components/style) and [templating](https://learn.microsoft.com/en-us/graph/toolkit/customize-components/templates).


[](https://learn.microsoft.com/en-us/graph/toolkit/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0&tabs=html#who-should-use-it)
## Who should use it?
Microsoft Graph Toolkit is great for developers of all experience levels that want to develop an app that connects to and accesses data from Microsoft Graph, such as a:
  * Web app
  * Microsoft Teams tab
  * Progressive Web App (PWA)
  * Electron app
  * SharePoint web part


[](https://learn.microsoft.com/en-us/graph/toolkit/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0&tabs=html#whats-in-microsoft-graph-toolkit)
## What's in Microsoft Graph Toolkit?
[](https://learn.microsoft.com/en-us/graph/toolkit/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0&tabs=html#components)
### Components
Microsoft Graph Toolkit includes a collection of web components for the most commonly built experiences powered by Microsoft Graph APIs.
The components are also available as [React components](https://learn.microsoft.com/en-us/graph/toolkit/get-started/mgt-react).
Expand table
Component | Description
---|---
[Agenda](https://learn.microsoft.com/en-us/graph/toolkit/components/agenda) | Displays events in a user's or group's calendar.
[Chat (preview)](https://learn.microsoft.com/en-us/graph/toolkit/components/chat) | Displays a 1:1 or a group conversation from Microsoft Teams
[File](https://learn.microsoft.com/en-us/graph/toolkit/components/file) | Represents a file or folder with an icon, a file name, an author, and more.
[File list](https://learn.microsoft.com/en-us/graph/toolkit/components/file-list) | Displays a list of multiple files or folders.
[Get](https://learn.microsoft.com/en-us/graph/toolkit/components/get) | Lets you make a GET query to any Microsoft Graph API directly in your HTML.
[Login](https://learn.microsoft.com/en-us/graph/toolkit/components/login) | A button and a flyout control to authenticate a user with the Microsoft Identity platform and display the user's profile information when they sign in.
[New chat (preview)](https://learn.microsoft.com/en-us/graph/toolkit/components/new-chat) | A form to create a new 1:1 or group conversation in Microsoft Teams
[People](https://learn.microsoft.com/en-us/graph/toolkit/components/people) | Displays a group of people or contacts by their photos or initials.
[People picker](https://learn.microsoft.com/en-us/graph/toolkit/components/people-picker) | Search for people and renders the list of results.
[Person](https://learn.microsoft.com/en-us/graph/toolkit/components/person) | Displays a person or contact by their photo, name, and/or email address.
[Person card](https://learn.microsoft.com/en-us/graph/toolkit/components/person-card) | A flyout used on the person component to display more profile information about a user.
[Picker](https://learn.microsoft.com/en-us/graph/toolkit/components/picker) | Renders a dropdown control that allows a selection of a single resource from an array of resources.
[Planner tasks](https://learn.microsoft.com/en-us/graph/toolkit/components/planner) | Displays and enables adding, removing, completing, or editing of tasks from Microsoft Planner or Microsoft To Do.
[Search box](https://learn.microsoft.com/en-us/graph/toolkit/components/search-box) | Search for Microsoft Teams channels to select a channel from a rendered list of results.
[Search results](https://learn.microsoft.com/en-us/graph/toolkit/components/search-results) | Lets you make a query to the search endpoint of Microsoft Graph directly in your HTML.
[Taxonomy picker](https://learn.microsoft.com/en-us/graph/toolkit/components/taxonomy-picker) | Use the taxonomy picker component to query the Microsoft Graph API for Taxonomy and render a dropdown control with terms.
[Teams Channel picker](https://learn.microsoft.com/en-us/graph/toolkit/components/teams-channel-picker) | Search for Microsoft Teams channels to select a channel from a rendered list of results.
[To Do](https://learn.microsoft.com/en-us/graph/toolkit/components/todo) | Displays and enables adding, removing, completing, or editing of tasks from Microsoft To Do.
[](https://learn.microsoft.com/en-us/graph/toolkit/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0&tabs=html#providers)
### Providers
[Providers](https://learn.microsoft.com/en-us/graph/toolkit/providers/providers) enable authentication, provide the implementation for acquiring access tokens on various platforms, and expose a Microsoft Graph client for calling the Microsoft Graph APIs. The components work best when used with a provider, but the providers can be used on their own.
Expand table
Providers | Description
---|---
[Custom](https://learn.microsoft.com/en-us/graph/toolkit/providers/custom) | Creates a custom provider to enable authentication and access to Microsoft Graph by using your application's existing authentication code.
[Electron](https://learn.microsoft.com/en-us/graph/toolkit/providers/electron) | Authenticates and provides Microsoft Graph access to components inside of Electron apps.
[MSAL2](https://learn.microsoft.com/en-us/graph/toolkit/providers/msal2) | Uses msal-browser to sign in users and acquire tokens to use with Microsoft Graph.
[Proxy](https://learn.microsoft.com/en-us/graph/toolkit/providers/proxy) | Allows the use of backend authentication by routing all calls to Microsoft Graph through your backend.
[SharePoint](https://learn.microsoft.com/en-us/graph/toolkit/providers/sharepoint) | Authenticates and provides Microsoft Graph access to components inside of SharePoint web parts.
[TeamsFx](https://learn.microsoft.com/en-us/graph/toolkit/providers/teamsfx) | Use the TeamsFx provider inside your Microsoft Teams applications to provide Microsoft Graph Toolkit components access to Microsoft Graph.
[](https://learn.microsoft.com/en-us/graph/toolkit/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0&tabs=html#where-can-i-use-it)
## Where can I use it?
Microsoft Graph Toolkit is supported in the following browsers:
Expand table
![Edge](https://learn.microsoft.com/en-us/graph/toolkit/images/edgeicon.png) | ![Firefox](https://learn.microsoft.com/en-us/graph/toolkit/images/firefoxicon.png) | ![Chrome](https://learn.microsoft.com/en-us/graph/toolkit/images/chromeicon.png) | ![Safari](https://learn.microsoft.com/en-us/graph/toolkit/images/safariicon.png) | ![Opera](https://learn.microsoft.com/en-us/graph/toolkit/images/operaicon.png) | ![Samsung Internet](https://learn.microsoft.com/en-us/graph/toolkit/images/samsunginterneticon.png)
---|---|---|---|---|---
**Edge** | **Firefox** | **Chrome** | **Safari** | **Opera** | **Samsung**
[](https://learn.microsoft.com/en-us/graph/toolkit/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0&tabs=html#next-steps)
## Next steps
  * Try out the components in the [playground](https://mgt.dev).
  * [Get started](https://learn.microsoft.com/en-us/graph/toolkit/get-started/overview) with Microsoft Graph Toolkit.
  * Check out Microsoft Graph Toolkit on [GitHub](https://aka.ms/mgt).


* * *
## Feedback
Was this page helpful?
Yes No No
Need help with this topic?
Want to try using Ask Learn to clarify or guide you through this topic?
Ask Learn Ask Learn
Suggest a fix?
* * *
##  Additional resources
  * [ Permissions in Microsoft Graph Toolkit - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/toolkit/permissions?source=recommendations)
Get an overview of how Microsoft Graph Toolkit manages permissions.
  * [ Use Graph Explorer to try Microsoft Graph APIs - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/graph-explorer/graph-explorer-overview?source=recommendations)
Try Microsoft Graph APIs on the default sample tenant to explore capabilities, or sign in to your tenant and use it as a prototyping tool to fulfill your app scenarios.
  * [ SharePoint provider - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/toolkit/providers/sharepoint?source=recommendations)
Use the SharePoint provider inside your SharePoint web parts to power the components with Microsoft Graph access.
  * [ Microsoft Graph tutorials - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/tutorials/?source=recommendations)
Create a basic application that accesses data via Microsoft Graph in 30 minutes by using a step-by-step Microsoft Graph tutorial.
  * [ Microsoft Graph REST API v1.0 endpoint reference - Microsoft Graph v1.0 ](https://learn.microsoft.com/en-us/graph/api/overview?source=recommendations)
Find reference content for Microsoft Graph REST APIs in the v1.0 endpoint, which includes APIs in general availability (GA) status.
  * [ Get started with Microsoft Graph Toolkit - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/toolkit/get-started/overview?source=recommendations)
Learn how to set up your Microsoft 365 tenant and development environment to use Microsoft Graph Toolkit. Install npm packages for components and providers.
  * [ Get component in Microsoft Graph Toolkit - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/toolkit/components/get?source=recommendations)
A Get component allows you to make any GET query from Microsoft Graph directly in your HTML.
  * [ Microsoft Graph SDK overview - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview?source=recommendations)
Learn about the Microsoft Graph SDKs.


Show 5 more
Module
[ Get started with Microsoft Graph Toolkit - Training ](https://learn.microsoft.com/en-us/training/modules/msgraph-toolkit-intro/?source=recommendations)
Learn how to use Microsoft Graph Toolkit, a set of web components and authentication providers to connect your web app to Microsoft Graph and load data from Microsoft 365. You can use Microsoft Graph Toolkit in any JavaScript framework.
Certification
[ Microsoft Certified: Power Platform Developer Associate - Certifications ](https://learn.microsoft.com/en-us/credentials/certifications/power-platform-developer-associate/?source=recommendations)
Demonstrate how to simplify, automate, and transform business tasks and processes using Microsoft Power Platform Developer.
[ AI Apps & Agents Dev Days ](https://aka.ms/AIAppsandAgentsLearn)
Feb 27, 1 AM - Feb 27, 1 AM
Experiment with what's next in AI-driven apps and agent design
[ Register now ](https://aka.ms/AIAppsandAgentsLearn)
* * *
  * Last updated on 09/04/2025


##  In this article
  1. [Why use Microsoft Graph Toolkit?](https://learn.microsoft.com/en-us/graph/toolkit/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0&tabs=html#why-use-microsoft-graph-toolkit)
  2. [Who should use it?](https://learn.microsoft.com/en-us/graph/toolkit/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0&tabs=html#who-should-use-it)
  3. [What's in Microsoft Graph Toolkit?](https://learn.microsoft.com/en-us/graph/toolkit/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0&tabs=html#whats-in-microsoft-graph-toolkit)
  4. [Where can I use it?](https://learn.microsoft.com/en-us/graph/toolkit/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0&tabs=html#where-can-i-use-it)
  5. [Next steps](https://learn.microsoft.com/en-us/graph/toolkit/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0&tabs=html#next-steps)


Was this page helpful?
Yes No No
Need help with this topic?
Want to try using Ask Learn to clarify or guide you through this topic?
Ask Learn Ask Learn
Suggest a fix?
##
Ask Learn
Preview
Ask Learn is an AI assistant that can answer questions, clarify concepts, and define terms using trusted Microsoft documentation.
Please sign in to use Ask Learn.
[ Sign in ](https://learn.microsoft.com/en-us/graph/toolkit/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0&tabs=html)
[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Ftoolkit%2Foverview%3Fcontext%3Dgraph%252Fapi%252F1.0%26view%3Dgraph-rest-1.0)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
