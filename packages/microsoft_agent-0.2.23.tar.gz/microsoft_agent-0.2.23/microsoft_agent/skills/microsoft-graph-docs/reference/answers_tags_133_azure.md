[ Skip to main content ](https://learn.microsoft.com/en-us/answers/tags/133/azure#main)
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/answers/tags/133/azure)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/answers/tags/133/azure)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/answers/tags/133/azure)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/answers/tags/133/azure)
[ Q&A  ](https://learn.microsoft.com/en-us/answers/)
  * [ Questions ](https://learn.microsoft.com/en-us/answers/questions/)
  * [ Tags ](https://learn.microsoft.com/en-us/answers/tags/)
  * [ Help ](https://learn.microsoft.com/en-us/answers/support/)
  * More
    * [ Questions ](https://learn.microsoft.com/en-us/answers/questions/)
    * [ Tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ Help ](https://learn.microsoft.com/en-us/answers/support/)


[ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/?id=aHR0cHM6Ly9hdXRob3JpbmctZG9jcy1taWNyb3NvZnQucG9vbHBhcnR5LmJpei9kZXZyZWwvMjQxYTUyMzktZmUyYi00NzE1LTk3N2UtMTM5OGM0ODdhMzJj&styleGuideLabel=Azure)
![](https://learn.microsoft.com/en-us/media/logos/logo_azure.svg)
Microsoft Q&A
#  Azure
138,846 questions
A cloud computing platform and infrastructure for building, deploying and managing applications and services through a worldwide network of Microsoft-managed datacenters.
Sign in to follow  Follow
Filters
## Filter
* * *
### Content
[ All questions 138.8K  ](https://learn.microsoft.com/en-us/answers/tags/133/azure?filterby=null) [ No answers 17.3K  ](https://learn.microsoft.com/en-us/answers/tags/133/azure?filterby=unanswered) [ Has answers 121.5K  ](https://learn.microsoft.com/en-us/answers/tags/133/azure?filterby=answered) [ No answers or comments 1.1K  ](https://learn.microsoft.com/en-us/answers/tags/133/azure?filterby=withoutengagement) [ With accepted answer 43.4K  ](https://learn.microsoft.com/en-us/answers/tags/133/azure?filterby=withacceptedanswer) [ With recommended answer 93  ](https://learn.microsoft.com/en-us/answers/tags/133/azure?filterby=withrecommendedanswer)
##  138,846 questions with Azure-related tags
Sort by:  Updated
[Updated](https://learn.microsoft.com/en-us/answers/tags/133/azure?orderby=updatedat&page=1) [Created](https://learn.microsoft.com/en-us/answers/tags/133/azure?orderby=createdat&page=1) [Answers](https://learn.microsoft.com/en-us/answers/tags/133/azure?orderby=answercount&page=1)
0 answers
##  [ I have granted permission in App registration to an App but it is showing SMTP error ](https://learn.microsoft.com/en-us/answers/questions/5790793/i-have-granted-permission-in-app-registration-to-a)
We are integrating a PHP web application to send emails via SMTP using the modern OAuth 2.0 (XOAUTH2) flow for the account: ******@bayebusinesssolutions.com. The Issue: We have successfully registered the Azure App. We have successfully granted Admin…
Azure App Service
[ Azure App Service ](https://learn.microsoft.com/en-us/answers/tags/436/azure-app-service/)
Azure App Service is a service used to create and deploy scalable, mission-critical web apps.
9,719 questions
Sign in to follow  Follow
asked Feb 27, 2026, 1:19 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(252.8,%2071%,%2034%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EFB%3C/text%3E%3C/svg%3E)
[Faruq Bello](https://learn.microsoft.com/en-us/users/na/?userid=79f7b146-8c1b-46f7-8af9-12fa41d95406) 20 Reputation points
asked Feb 27, 2026, 1:19 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(252.8,%2071%,%2034%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EFB%3C/text%3E%3C/svg%3E)
[Faruq Bello](https://learn.microsoft.com/en-us/users/na/?userid=79f7b146-8c1b-46f7-8af9-12fa41d95406) 20 Reputation points
1 answer
##  [ Connectivity issue with hosted server on hyper-v while migrating to azure using azure migrate ](https://learn.microsoft.com/en-us/answers/questions/5786149/connectivity-issue-with-hosted-server-on-hyper-v-w)
For testing purposes, we have deployed an Azure VM with the Hyper‑V role enabled and are hosting a Windows Server 2008 R2 SP1 virtual machine on it. We are now attempting to migrate the Server 2008 VM to Azure using the Azure Migrate appliance. The…
Azure Migrate
[ Azure Migrate ](https://learn.microsoft.com/en-us/answers/tags/116/azure-migrate/)
A central hub of Azure cloud migration services and tools to discover, assess, and migrate workloads to the cloud.
1,056 questions
Sign in to follow  Follow
asked Feb 24, 2026, 1:50 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(51.2,%2074%,%2014%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EMM%3C/text%3E%3C/svg%3E)
[Manvi MS Admin](https://learn.microsoft.com/en-us/users/na/?userid=f1bcbabd-67a4-40cc-acb0-4a07fd953b8b) 0 Reputation points
commented Feb 27, 2026, 1:19 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(51.2,%2074%,%2014%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EMM%3C/text%3E%3C/svg%3E)
[Manvi MS Admin](https://learn.microsoft.com/en-us/users/na/?userid=f1bcbabd-67a4-40cc-acb0-4a07fd953b8b) 0 Reputation points
One of the answers was accepted by the question author.
##  [ Why it is so difficult to find the Plan Information for VM Deployment using Azure Marketplace Azure Powershell? ](https://learn.microsoft.com/en-us/answers/questions/5789314/why-it-is-so-difficult-to-find-the-plan-informatio)
Hi, I always struggle to find the appropriate Plan block for a given image for my IaC code blaokc, without having to actually deploy manually. "plan": { "name": "cis-windows-server2025-l1-gen2", …
Azure Virtual Machines
[ Azure Virtual Machines ](https://learn.microsoft.com/en-us/answers/tags/94/azure-virtual-machines/)
An Azure service that is used to provision Windows and Linux virtual machines.
9,903 questions
Sign in to follow  Follow
asked Feb 25, 2026, 10:15 PM
![](https://learn.microsoft.com/api/profile-avatar-storage/images/FIFqiIwAwka1FNS9nDE2sg.png?8DB0E4)
[Rajesh Swarnkar](https://learn.microsoft.com/en-us/users/na/?userid=886a8114-008c-46c2-b514-d4bd9c3136b2) 1,051 Reputation points
commented Feb 27, 2026, 12:53 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(262.40000000000003,%2096%,%2035%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EAY%3C/text%3E%3C/svg%3E)
[Ankit Yadav](https://learn.microsoft.com/en-us/users/na/?userid=8b2f9683-34a8-4b44-a7ee-9780f7021c11) 11,815 Reputation points • Microsoft External Staff • Moderator
1 answer
##  [ Clarification on Transferring Azure Reservations During Tenant Change ](https://learn.microsoft.com/en-us/answers/questions/5789297/clarification-on-transferring-azure-reservations-d)
Hi We are planning to move our Azure subscription to a different tenant and would like to understand the impact on our existing reservations. Could you please clarify the following: Will our existing Azure VM reservations automatically move when the…
Azure Cost Management
[ Azure Cost Management ](https://learn.microsoft.com/en-us/answers/tags/118/azure-cost-management/)
A Microsoft offering that enables tracking of cloud usage and expenditures for Azure and other cloud providers.
4,774 questions
Sign in to follow  Follow
asked Feb 25, 2026, 9:53 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(89.60000000000001,%2047%,%2018%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ECS%3C/text%3E%3C/svg%3E)
[Cheedella, Satyanarayana](https://learn.microsoft.com/en-us/users/na/?userid=d28476e7-98e0-4f3c-b100-dd9ad0c386c6) 0 Reputation points
commented Feb 27, 2026, 12:52 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(70.4,%206%,%2016%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ESS%3C/text%3E%3C/svg%3E)
[Siva shunmugam Nadessin](https://learn.microsoft.com/en-us/users/na/?userid=2e206cef-67ed-4d39-9f7a-f4f13b404667) 5,790 Reputation points • Microsoft External Staff • Moderator
1 answer
##  [ FSLogix CloudKerberosTicketRetrievalEnabled Not Working with Azure AD Joined VMs - Per-User Authentication Issue ](https://learn.microsoft.com/en-us/answers/questions/5781969/fslogix-cloudkerberosticketretrievalenabled-not-wo)
Environment: Azure Virtual Desktop (AVD) Pooled Host Pool Windows 11 Enterprise 25H2 (build 26100.1150) VMs: Azure AD Joined (pure cloud, no on-premises AD or Hybrid Join) FSLogix Version: 3.26.126.19110 Storage: Azure Files with Private Endpoint …
Azure Virtual Desktop
[ Azure Virtual Desktop ](https://learn.microsoft.com/en-us/answers/tags/221/azure-virtual-desktop/)
A Microsoft desktop and app virtualization service that runs on Azure. Previously known as Windows Virtual Desktop.
2,061 questions
Sign in to follow  Follow
asked Feb 20, 2026, 1:29 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(259.20000000000005,%2047%,%2035%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ESS%3C/text%3E%3C/svg%3E)
[Sergey Shapoval](https://learn.microsoft.com/en-us/users/na/?userid=8b1c47d5-fc8b-4d1e-a063-267da1c6d571) 0 Reputation points
commented Feb 27, 2026, 12:51 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(262.40000000000003,%2096%,%2035%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EAY%3C/text%3E%3C/svg%3E)
[Ankit Yadav](https://learn.microsoft.com/en-us/users/na/?userid=8b2f9683-34a8-4b44-a7ee-9780f7021c11) 11,815 Reputation points • Microsoft External Staff • Moderator
1 answer
##  [ 715-123420 error code on deploying GPT4.1 mini models ](https://learn.microsoft.com/en-us/answers/questions/5789762/715-123420-error-code-on-deploying-gpt4-1-mini-mod)
I have been getting the error code 715-123420 when deploying resources for use with content understanding, specifically GPT4.1 mini. This has only been happening since around 24/02/2026 and reading other articles it could something to do with fraud…
Foundry Tools
[ Foundry Tools ](https://learn.microsoft.com/en-us/answers/tags/1580/foundry-tools/)
Formerly known as Azure AI Services or Azure Cognitive Services is a unified collection of prebuilt AI capabilities within the Microsoft Foundry platform
44 questions
Sign in to follow  Follow
asked Feb 26, 2026, 6:25 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(22.400000000000002,%2075%,%2012%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EOK%3C/text%3E%3C/svg%3E)
[Oisin Kelly](https://learn.microsoft.com/en-us/users/na/?userid=0facf775-3370-4ebf-bc2b-62de1aac0a63) 0 Reputation points
commented Feb 27, 2026, 12:50 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(86.4,%204%,%2018%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EPS%3C/text%3E%3C/svg%3E)
[Paul Slade](https://learn.microsoft.com/en-us/users/na/?userid=27eedabc-0abc-420e-b224-d5bec6ba919c) 0 Reputation points
0 answers
##  [ Custom domain verification failing ](https://learn.microsoft.com/en-us/answers/questions/5789200/custom-domain-verification-failing)
Despite matching exactly with domain record. It fails to verify the custom domain.
Azure Communication Services
[ Azure Communication Services ](https://learn.microsoft.com/en-us/answers/tags/128/azure-communication-services/)
An Azure communication platform for deploying applications across devices and platforms.
1,573 questions
Sign in to follow  Follow
asked Feb 25, 2026, 7:48 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(313.6,%2057.00000000000001%,%2040%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ESM%3C/text%3E%3C/svg%3E)
[Subroto M](https://learn.microsoft.com/en-us/users/na/?userid=ab98c573-366e-405b-be00-e7831979e97a) 0 Reputation points
commented Feb 27, 2026, 12:44 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(80,%207.000000000000001%,%2017%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EPM%3C/text%3E%3C/svg%3E)
[Praneeth Maddali](https://learn.microsoft.com/en-us/users/na/?userid=bb2507a8-63fa-48d8-aaa7-3570a11fbcc3) 5,180 Reputation points • Microsoft External Staff • Moderator
3 answers
##  [ Error Code RequestDisallowedByAzureMessage: Resource was disallowed by Azure: This policy maintains a set of best available regions... ](https://learn.microsoft.com/en-us/answers/questions/5789117/error-code-requestdisallowedbyazuremessage-resourc)
I'm using the student subscription and I receive this error whenever I try to create a Static Web App that will be used to host a React frontend. I am aware of the regions available through my student subscription which are:…
Azure Static Web Apps
[ Azure Static Web Apps ](https://learn.microsoft.com/en-us/answers/tags/448/static-web-apps/)
An Azure service that provides streamlined full-stack web app development.
1,339 questions
Sign in to follow  Follow
asked Feb 25, 2026, 6:10 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(220.8,%2082%,%2031%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EST%3C/text%3E%3C/svg%3E)
[Sean Tisdale](https://learn.microsoft.com/en-us/users/na/?userid=698ac2ed-c566-40dd-b705-3095acfd74b2) 0 Reputation points
commented Feb 27, 2026, 12:43 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(80,%207.000000000000001%,%2017%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EPM%3C/text%3E%3C/svg%3E)
[Praneeth Maddali](https://learn.microsoft.com/en-us/users/na/?userid=bb2507a8-63fa-48d8-aaa7-3570a11fbcc3) 5,180 Reputation points • Microsoft External Staff • Moderator
0 answers
##  [ App Service (Linux) with VNet integration cannot reach Azure OpenAI private endpoint — Connection error ](https://learn.microsoft.com/en-us/answers/questions/5789113/app-service-\(linux\)-with-vnet-integration-cannot-r)
I need the Web App to call Azure OpenAI over a private endpoint so that traffic never leaves the Microsoft network. The configuration matches the documentation, but the app cannot connect when using the private endpoint URL. Setup Region: East US 2…
Azure App Service
[ Azure App Service ](https://learn.microsoft.com/en-us/answers/tags/436/azure-app-service/)
Azure App Service is a service used to create and deploy scalable, mission-critical web apps.
9,719 questions
Sign in to follow  Follow
asked Feb 25, 2026, 6:07 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(131.20000000000002,%2092%,%2022%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EPS%3C/text%3E%3C/svg%3E)
[Parsa Samandi](https://learn.microsoft.com/en-us/users/na/?userid=419255c2-368d-4018-a436-a4a79f00c455) 0 Reputation points
commented Feb 27, 2026, 12:42 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(80,%207.000000000000001%,%2017%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EPM%3C/text%3E%3C/svg%3E)
[Praneeth Maddali](https://learn.microsoft.com/en-us/users/na/?userid=bb2507a8-63fa-48d8-aaa7-3570a11fbcc3) 5,180 Reputation points • Microsoft External Staff • Moderator
0 answers
##  [ Getting error "No connection matching model: gpt-5.1" ](https://learn.microsoft.com/en-us/answers/questions/5789737/getting-error-no-connection-matching-model-gpt-5-1)
I am using OpenAI SDK (.NET) for connecting to Azure foundry and creating agents using AzureAssistantClient. I have model deployed in Azure Foundry with gpt 5.1 but when I create thread run and tried to call GetRunAsync to get the status of the run, it…
Foundry Tools
[ Foundry Tools ](https://learn.microsoft.com/en-us/answers/tags/1580/foundry-tools/)
Formerly known as Azure AI Services or Azure Cognitive Services is a unified collection of prebuilt AI capabilities within the Microsoft Foundry platform
44 questions
Sign in to follow  Follow
asked Feb 26, 2026, 5:54 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(272,%2028.000000000000004%,%2036%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ENG%3C/text%3E%3C/svg%3E)
[Nishant Gupta](https://learn.microsoft.com/en-us/users/na/?userid=8528b799-8c03-4126-99fe-0ed7e08ccb62) 0 Reputation points • Microsoft Employee
commented Feb 27, 2026, 12:41 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(176,%2016%,%2027%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ESC%3C/text%3E%3C/svg%3E)
[SRILAKSHMI C](https://learn.microsoft.com/en-us/users/na/?userid=d551a661-9581-42ac-9cfd-2bf53cccf48b) 14,655 Reputation points • Microsoft External Staff • Moderator
0 answers
##  [ Azure Direct Routing – Unable to connect Yeastar SBC to ACS ](https://learn.microsoft.com/en-us/answers/questions/5787647/azure-direct-routing-unable-to-connect-yeastar-sbc)
We are trying to configure Direct Routing between Azure Communication Services (ACS) and a Yeastar PBX (acting as Session Border Controller). Current setup: Azure Communication Services resource created Custom domain verified:XXXXX Direct Routing…
Azure Communication Services
[ Azure Communication Services ](https://learn.microsoft.com/en-us/answers/tags/128/azure-communication-services/)
An Azure communication platform for deploying applications across devices and platforms.
1,573 questions
Sign in to follow  Follow
asked Feb 25, 2026, 12:13 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(188.79999999999998,%2093%,%2028%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EAA%3C/text%3E%3C/svg%3E)
[Anvenssa AI](https://learn.microsoft.com/en-us/users/na/?userid=e59eb939-1d71-42f4-ac07-eca631968f70) 0 Reputation points
edited the question Feb 27, 2026, 12:39 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(80,%207.000000000000001%,%2017%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EPM%3C/text%3E%3C/svg%3E)
[Praneeth Maddali](https://learn.microsoft.com/en-us/users/na/?userid=bb2507a8-63fa-48d8-aaa7-3570a11fbcc3) 5,180 Reputation points • Microsoft External Staff • Moderator
1 answer
##  [ How do I successfully create FSLogix profiles given the following: ](https://learn.microsoft.com/en-us/answers/questions/5784623/how-do-i-successfully-create-fslogix-profiles-give)
For simplicity's sake, here's the CoPilot summary of my problem, it concerns an Azure Virtual Desktop setup with Azure Files running a share for my FSLogix profiles. I can map to the FSLogix drive (it shows up in "net use" but not in File…
Azure Virtual Desktop
[ Azure Virtual Desktop ](https://learn.microsoft.com/en-us/answers/tags/221/azure-virtual-desktop/)
A Microsoft desktop and app virtualization service that runs on Azure. Previously known as Windows Virtual Desktop.
2,061 questions
Sign in to follow  Follow
asked Feb 22, 2026, 11:55 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(102.4,%2067%,%2019%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EAT%3C/text%3E%3C/svg%3E)
[Ashley Tym](https://learn.microsoft.com/en-us/users/na/?userid=326e7154-6b8e-4c1d-b8eb-24c85202b73e) 0 Reputation points
commented Feb 27, 2026, 12:37 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(262.40000000000003,%2096%,%2035%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EAY%3C/text%3E%3C/svg%3E)
[Ankit Yadav](https://learn.microsoft.com/en-us/users/na/?userid=8b2f9683-34a8-4b44-a7ee-9780f7021c11) 11,815 Reputation points • Microsoft External Staff • Moderator
2 answers
##  [ Unable to Resize VM ](https://learn.microsoft.com/en-us/answers/questions/5789075/unable-to-resize-vm)
Hi, I'm getting the following error when I try to resize my VM: Failed to resize virtual machine 'vmavdpusw20001' to size 'Standard D2s v4'. Error: Operation could not be completed as it results in exceeding approved standardBasv2Family Cores quota.…
Azure Virtual Machines
[ Azure Virtual Machines ](https://learn.microsoft.com/en-us/answers/tags/94/azure-virtual-machines/)
An Azure service that is used to provision Windows and Linux virtual machines.
9,903 questions
Sign in to follow  Follow
asked Feb 25, 2026, 4:55 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(313.6,%2021%,%2040%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ES%3C/text%3E%3C/svg%3E)
[Shane](https://learn.microsoft.com/en-us/users/na/?userid=98acdc21-1f65-4c76-93fb-ea8db3f5dde6) 0 Reputation points
commented Feb 27, 2026, 12:35 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(313.6,%2021%,%2040%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ES%3C/text%3E%3C/svg%3E)
[Shane](https://learn.microsoft.com/en-us/users/na/?userid=98acdc21-1f65-4c76-93fb-ea8db3f5dde6) 0 Reputation points
2 answers
##  [ How to upgrade our SQL VM to SQL 2022 version and also how entra ids will be enabled ](https://learn.microsoft.com/en-us/answers/questions/5778263/how-to-upgrade-our-sql-vm-to-sql-2022-version-and)
Hello Team, We are seeing that in S360 that we have to upgrade sql to 2022 and entra id enabled, but when we have cross checked ACCDEV01 machine is showing there but it is a virtual machine not and sql virtual machine i.e. accdev01, could you please…
Azure SQL Database
[ Azure SQL Database ](https://learn.microsoft.com/en-us/answers/tags/51/azure-sql-database/)
An Azure relational database service.
6,759 questions
Sign in to follow  Follow
asked Feb 17, 2026, 12:32 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(150.4,%2047%,%2024%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ENM%3C/text%3E%3C/svg%3E)
[NAVEEN Mittal](https://learn.microsoft.com/en-us/users/na/?userid=a4d747f1-3301-44c3-9562-cec6161f4b78) 130 Reputation points • Microsoft External Staff
commented Feb 27, 2026, 12:31 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(166.4,%2095%,%2026%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ESD%3C/text%3E%3C/svg%3E)
[Saraswathi Devadula](https://learn.microsoft.com/en-us/users/na/?userid=52959f0a-08b1-411d-9661-d5e44cadbcd5) 14,395 Reputation points • Microsoft External Staff • Moderator
1 answer
##  [ Graph API - required permissions for createSession ](https://learn.microsoft.com/en-us/answers/questions/5790771/graph-api-required-permissions-for-createsession)
Hi support, I've tried createSession POST https://graph.microsoft.com/v1.0/drives/<myDriveID>/items/<myWorkbookID>/workbook/createSession based on…
Azure App Configuration
[ Azure App Configuration ](https://learn.microsoft.com/en-us/answers/tags/129/azure-app-configuration/)
An Azure service that provides hosted, universal storage for Azure app configurations.
344 questions
Sign in to follow  Follow
asked Feb 27, 2026, 12:27 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(38.4,%2071%,%2013%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EYM%3C/text%3E%3C/svg%3E)
[Yu, Miseon](https://learn.microsoft.com/en-us/users/na/?userid=a1c2f71c-73a9-4b56-833d-e567972132c8) 0 Reputation points
answered Feb 27, 2026, 12:28 AM
![](https://learn.microsoft.com/en-us/media/profile/user-copilot.png)
Q&A Assist
0 answers
##  [ ADF pipelines failing immediately ](https://learn.microsoft.com/en-us/answers/questions/5786501/adf-pipelines-failing-immediately)
Our pipelines in ADF began failing last week. They fail around 1s after triggering with the same error message: "Operation on target <pipeline name> failed: Invalid dataset reference. Name:…
Azure Data Factory
[ Azure Data Factory ](https://learn.microsoft.com/en-us/answers/tags/194/azure-data-factory/)
An Azure service for ingesting, preparing, and transforming data at scale.
12,072 questions
Sign in to follow  Follow
asked Feb 24, 2026, 7:52 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(275.2,%2095%,%2036%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EGA%3C/text%3E%3C/svg%3E)
[Gareth Andrews](https://learn.microsoft.com/en-us/users/na/?userid=869d5501-2e8c-4c73-afb1-53172d094386) 5 Reputation points
commented Feb 27, 2026, 12:26 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(28.799999999999997,%2097%,%2012%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EKL%3C/text%3E%3C/svg%3E)
[K, Leon](https://learn.microsoft.com/en-us/users/na/?userid=0dbb9a97-0e66-48c4-82db-028263ed6c9f) 0 Reputation points
1 answer
##  [ Microsoft Foundry (new) Error ](https://learn.microsoft.com/en-us/answers/questions/5785910/microsoft-foundry-\(new\)-error)
Region : Japan using Microsoft Foundry (new) I've checked all the access control roles in the Azure portal. Is this perhaps a temporary outage? Today, selecting an agent from Microsoft Foundry produces the error shown in the image below. There were no…
Foundry Tools
[ Foundry Tools ](https://learn.microsoft.com/en-us/answers/tags/1580/foundry-tools/)
Formerly known as Azure AI Services or Azure Cognitive Services is a unified collection of prebuilt AI capabilities within the Microsoft Foundry platform
44 questions
Sign in to follow  Follow
asked Feb 23, 2026, 8:10 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(16,%2036%,%2011%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EG%3C/text%3E%3C/svg%3E)
[GNHD_TKR](https://learn.microsoft.com/en-us/users/na/?userid=c05fcf36-4710-45a5-9439-cb19e2c16a0d) 20 Reputation points
commented Feb 27, 2026, 12:21 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(16,%2036%,%2011%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EG%3C/text%3E%3C/svg%3E)
[GNHD_TKR](https://learn.microsoft.com/en-us/users/na/?userid=c05fcf36-4710-45a5-9439-cb19e2c16a0d) 20 Reputation points
1 answer
##  [ I can't access azure with my student credentials ](https://learn.microsoft.com/en-us/answers/questions/5790211/i-cant-access-azure-with-my-student-credentials)
I am required to use azure to complete assignments for my class I am in but when I attempt to login it takes me to a screen saying I am ineligible to renew azure for students
Azure DevOps
[ Azure DevOps ](https://learn.microsoft.com/en-us/answers/tags/768/azure-devops/)
1,231 questions
Sign in to follow  Follow
asked Feb 26, 2026, 12:04 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(179.20000000000002,%2068%,%2027%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EKS%3C/text%3E%3C/svg%3E)
[Kristian S Landreth](https://learn.microsoft.com/en-us/users/na/?userid=5e6b6865-5b65-464f-977e-f72361e4248c) 0 Reputation points
edited an answer Feb 27, 2026, 12:18 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(73.60000000000001,%2077%,%2017%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ERM%3C/text%3E%3C/svg%3E)
[Rakesh Mishra](https://learn.microsoft.com/en-us/users/na/?userid=a237720b-ab02-4f0f-acb8-31535a1e98bc) 6,255 Reputation points • Microsoft External Staff • Moderator
One of the answers was accepted by the question author.
##  [ Dall-E3 Model retirement and it's upgrade ](https://learn.microsoft.com/en-us/answers/questions/5757775/dall-e3-model-retirement-and-its-upgrade)
We are currently using the DALL·E 3 model with version 3.0. Its retirement date is 18-Feb-2026, and the Version Upgrade Policy is set to “Once a new default version is available.” When we try to edit the deployment, we only see the default version 3.0,…
Azure AI services
[ Azure AI services ](https://learn.microsoft.com/en-us/answers/tags/441/ai-services/)
A group of Azure services, SDKs, and APIs designed to make apps more intelligent, engaging, and discoverable.
4,384 questions
Sign in to follow  Follow
asked Feb 2, 2026, 8:39 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(304,%2071%,%2039%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EBK%3C/text%3E%3C/svg%3E)
[Bipin Kadam](https://learn.microsoft.com/en-us/users/na/?userid=95714a7a-b5ab-4fc3-8917-c90698068b0b) 40 Reputation points
commented Feb 27, 2026, 12:13 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(176,%2016%,%2027%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ESC%3C/text%3E%3C/svg%3E)
[SRILAKSHMI C](https://learn.microsoft.com/en-us/users/na/?userid=d551a661-9581-42ac-9cfd-2bf53cccf48b) 14,655 Reputation points • Microsoft External Staff • Moderator
3 answers
##  [ Generalized server nightmare ](https://learn.microsoft.com/en-us/answers/questions/5790656/generalized-server-nightmare)
I created an image of my server and then deleted the image on accident. Is there any way to get the data off of the disks on the generalized server still?
Azure Virtual Machines
[ Azure Virtual Machines ](https://learn.microsoft.com/en-us/answers/tags/94/azure-virtual-machines/)
An Azure service that is used to provision Windows and Linux virtual machines.
9,903 questions
Sign in to follow  Follow
asked Feb 26, 2026, 9:00 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(51.2,%2062%,%2014%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EBB%3C/text%3E%3C/svg%3E)
[Brian Betsill](https://learn.microsoft.com/en-us/users/na/?userid=b16aab62-739c-4ec5-bc0a-41bb95a9ea0c) 0 Reputation points
answered Feb 27, 2026, 12:01 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(262.40000000000003,%2096%,%2035%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EAY%3C/text%3E%3C/svg%3E)
[Ankit Yadav](https://learn.microsoft.com/en-us/users/na/?userid=8b2f9683-34a8-4b44-a7ee-9780f7021c11) 11,815 Reputation points • Microsoft External Staff • Moderator
  * [ ](https://learn.microsoft.com/en-us/answers/tags/133/azure?page=0)
  * [ 1 ](https://learn.microsoft.com/en-us/answers/tags/133/azure?page=1)
  * ...
  * [ 1 ](https://learn.microsoft.com/en-us/answers/tags/133/azure?page=1)
  * [ 2 ](https://learn.microsoft.com/en-us/answers/tags/133/azure?page=2)
  * [ 3 ](https://learn.microsoft.com/en-us/answers/tags/133/azure?page=3)
  * [ 4 ](https://learn.microsoft.com/en-us/answers/tags/133/azure?page=4)
  * ...
  * [ 6943 ](https://learn.microsoft.com/en-us/answers/tags/133/azure?page=6943)
  * [ ](https://learn.microsoft.com/en-us/answers/tags/133/azure?page=2)


[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fanswers%2Ftags%2F133%2Fazure)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Code of Conduct](https://aka.ms/msftqacodeconduct)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
